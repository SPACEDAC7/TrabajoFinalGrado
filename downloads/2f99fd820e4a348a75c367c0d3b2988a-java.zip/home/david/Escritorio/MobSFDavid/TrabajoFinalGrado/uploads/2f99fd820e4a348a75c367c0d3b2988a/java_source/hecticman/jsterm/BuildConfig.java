/*
 * Decompiled with CFR 0_115.
 */
package hecticman.jsterm;

public final class BuildConfig {
    public static final boolean DEBUG = true;
}

