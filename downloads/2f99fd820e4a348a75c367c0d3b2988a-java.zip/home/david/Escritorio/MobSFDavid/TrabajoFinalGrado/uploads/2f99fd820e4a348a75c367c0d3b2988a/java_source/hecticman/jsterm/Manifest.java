/*
 * Decompiled with CFR 0_115.
 */
package hecticman.jsterm;

public final class Manifest {

    public static final class permission {
        public static final String APPEND_TO_PATH = "hecticman.jsterm.permission.APPEND_TO_PATH";
        public static final String PREPEND_TO_PATH = "hecticman.jsterm.permission.PREPEND_TO_PATH";
        public static final String RUN_SCRIPT = "hecticman.jsterm.permission.RUN_SCRIPT";
    }

}

