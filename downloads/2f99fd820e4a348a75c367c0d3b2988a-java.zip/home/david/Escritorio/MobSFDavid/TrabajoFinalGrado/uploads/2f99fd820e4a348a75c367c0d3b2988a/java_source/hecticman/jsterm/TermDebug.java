/*
 * Decompiled with CFR 0_115.
 */
package hecticman.jsterm;

public class TermDebug {
    public static final boolean DEBUG = false;
    public static final String LOG_TAG = "Term";
}

