/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package hecticman.jsterm.compat;

import android.os.Build;

public class AndroidCompat {
    public static final int SDK = Integer.valueOf(Build.VERSION.SDK);
}

