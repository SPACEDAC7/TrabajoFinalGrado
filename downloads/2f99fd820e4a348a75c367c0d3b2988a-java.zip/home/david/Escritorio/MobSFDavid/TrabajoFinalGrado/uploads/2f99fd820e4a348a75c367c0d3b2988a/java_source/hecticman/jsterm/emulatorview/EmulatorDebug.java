/*
 * Decompiled with CFR 0_115.
 */
package hecticman.jsterm.emulatorview;

class EmulatorDebug {
    public static final boolean DEBUG = false;
    public static final boolean LOG_CHARACTERS_FLAG = false;
    public static final boolean LOG_IME = false;
    public static final String LOG_TAG = "EmulatorView";
    public static final boolean LOG_UNKNOWN_ESCAPE_SEQUENCES = false;

    EmulatorDebug() {
    }
}

