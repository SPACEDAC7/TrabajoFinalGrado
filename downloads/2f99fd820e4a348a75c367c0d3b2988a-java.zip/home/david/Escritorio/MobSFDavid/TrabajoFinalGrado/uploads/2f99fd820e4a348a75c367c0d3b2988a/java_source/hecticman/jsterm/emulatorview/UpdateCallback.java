/*
 * Decompiled with CFR 0_115.
 */
package hecticman.jsterm.emulatorview;

public interface UpdateCallback {
    public void onUpdate();
}

