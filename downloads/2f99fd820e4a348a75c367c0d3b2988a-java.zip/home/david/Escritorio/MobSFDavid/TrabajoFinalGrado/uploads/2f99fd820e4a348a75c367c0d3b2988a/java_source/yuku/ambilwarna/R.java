/*
 * Decompiled with CFR 0_115.
 */
package yuku.ambilwarna;

public final class R {

    public static final class array {
        public static final int control_keys_short_names = 2131099668;
        public static final int entries_actionbar_preference = 2131099650;
        public static final int entries_backaction_preference = 2131099660;
        public static final int entries_color_preference = 2131099658;
        public static final int entries_controlkey_preference = 2131099662;
        public static final int entries_cursorblink_preference = 2131099652;
        public static final int entries_cursorstyle_preference = 2131099654;
        public static final int entries_fnkey_preference = 2131099664;
        public static final int entries_fontsize_preference = 2131099656;
        public static final int entries_ime_preference = 2131099666;
        public static final int entries_sdcard_preference = 2131099672;
        public static final int entries_statusbar_preference = 2131099648;
        public static final int entries_termtype_preference = 2131099670;
        public static final int entryvalues_actionbar_preference = 2131099651;
        public static final int entryvalues_backaction_preference = 2131099661;
        public static final int entryvalues_color_preference = 2131099659;
        public static final int entryvalues_controlkey_preference = 2131099663;
        public static final int entryvalues_cursorblink_preference = 2131099653;
        public static final int entryvalues_cursorstyle_preference = 2131099655;
        public static final int entryvalues_fnkey_preference = 2131099665;
        public static final int entryvalues_fontsize_preference = 2131099657;
        public static final int entryvalues_ime_preference = 2131099667;
        public static final int entryvalues_sdcard_preference = 2131099673;
        public static final int entryvalues_statusbar_preference = 2131099649;
        public static final int fn_keys_short_names = 2131099669;
        public static final int sd_card_paths = 2131099671;
    }

    public static final class attr {
    }

    public static final class bool {
        public static final int pref_allow_prepend_path_default = 2131230728;
        public static final int pref_close_window_on_process_exit_default = 2131230725;
        public static final int pref_do_path_extensions_default = 2131230727;
        public static final int pref_statusbar_default = 2131230722;
        public static final int pref_use_specific_color_default = 2131230723;
        public static final int pref_utf8_by_default_default = 2131230724;
        public static final int pref_verify_path_default = 2131230726;
        public static final int pref_wakelock_default = 2131230720;
        public static final int pref_wifilock_default = 2131230721;
    }

    public static final class dimen {
        public static final int ambilwarna_hsvHeight = 2131034112;
        public static final int ambilwarna_hsvWidth = 2131034113;
        public static final int ambilwarna_hueWidth = 2131034114;
        public static final int ambilwarna_spacer = 2131034115;
    }

    public static final class drawable {
        public static final int ambilwarna_arrow_down = 2130837504;
        public static final int ambilwarna_arrow_right = 2130837505;
        public static final int ambilwarna_cursor = 2130837506;
        public static final int ambilwarna_hue = 2130837507;
        public static final int ambilwarna_target = 2130837508;
        public static final int atari_small = 2130837509;
        public static final int atari_small_nodpi = 2130837510;
        public static final int btn_close_window = 2130837511;
        public static final int close_background = 2130837512;
        public static final int ic_launcher = 2130837513;
        public static final int ic_menu_add = 2130837514;
        public static final int ic_menu_back = 2130837515;
        public static final int ic_menu_close_clear_cancel = 2130837516;
        public static final int ic_menu_forward = 2130837517;
        public static final int ic_menu_preferences = 2130837518;
        public static final int ic_menu_windows = 2130837519;
        public static final int ic_stat_service_notification_icon = 2130837520;
    }

    public static final class id {
        public static final int ambilwarna_cursor = 2131492867;
        public static final int ambilwarna_state = 2131492869;
        public static final int ambilwarna_target = 2131492868;
        public static final int ambilwarna_viewContainer = 2131492864;
        public static final int ambilwarna_viewHue = 2131492866;
        public static final int ambilwarna_viewSatBri = 2131492865;
        public static final int ambilwarna_warnaBaru = 2131492871;
        public static final int ambilwarna_warnaLama = 2131492870;
        public static final int menu_capture_screen = 2131492884;
        public static final int menu_close_window = 2131492877;
        public static final int menu_new_window = 2131492876;
        public static final int menu_preferences = 2131492881;
        public static final int menu_reset = 2131492882;
        public static final int menu_send_email = 2131492883;
        public static final int menu_special_keys = 2131492880;
        public static final int menu_toggle_soft_keyboard = 2131492879;
        public static final int menu_window_list = 2131492878;
        public static final int view_flipper = 2131492872;
        public static final int window_list_close = 2131492875;
        public static final int window_list_label = 2131492873;
        public static final int window_list_separator = 2131492874;
    }

    public static final class integer {
        public static final int pref_actionbar_default = 2131296256;
    }

    public static final class layout {
        public static final int ambilwarna_dialog = 2130903040;
        public static final int term_activity = 2130903041;
        public static final int window_list_item = 2130903042;
        public static final int window_list_new_window = 2130903043;
    }

    public static final class menu {
        public static final int main = 2131427328;
    }

    public static final class string {
        public static final int advanced_preferences = 2131165302;
        public static final int application_terminal = 2131165199;
        public static final int cancel = 2131165215;
        public static final int capture_screen = 2131165208;
        public static final int capture_screen_failed = 2131165210;
        public static final int capture_screen_saved = 2131165209;
        public static final int capture_screen_sdcard_notfound = 2131165211;
        public static final int close_window = 2131165202;
        public static final int color_preferences = 2131165260;
        public static final int commands_history = 2131165228;
        public static final int commands_history_no_session = 2131165229;
        public static final int confirm_default_color_preference = 2131165265;
        public static final int confirm_new_color_preference = 2131165264;
        public static final int confirm_window_close_message = 2131165316;
        public static final int control_key_dialog_control_disabled_text = 2131165313;
        public static final int control_key_dialog_control_text = 2131165312;
        public static final int control_key_dialog_fn_disabled_text = 2131165315;
        public static final int control_key_dialog_fn_text = 2131165314;
        public static final int control_key_dialog_title = 2131165311;
        public static final int copy_all = 2131165224;
        public static final int dialog_title_actionbar_preference = 2131165247;
        public static final int dialog_title_backaction_preference = 2131165279;
        public static final int dialog_title_color_preference = 2131165263;
        public static final int dialog_title_controlkey_preference = 2131165282;
        public static final int dialog_title_cursorblink_preference = 2131165253;
        public static final int dialog_title_cursorstyle_preference = 2131165250;
        public static final int dialog_title_exportpath_preference = 2131165301;
        public static final int dialog_title_fnkey_preference = 2131165285;
        public static final int dialog_title_fontsize_preference = 2131165259;
        public static final int dialog_title_ime_preference = 2131165288;
        public static final int dialog_title_initialcommand_preference = 2131165295;
        public static final int dialog_title_sdcard_preference = 2131165236;
        public static final int dialog_title_shell_preference = 2131165292;
        public static final int dialog_title_statusbar_preference = 2131165244;
        public static final int dialog_title_termtype_preference = 2131165298;
        public static final int disable_wakelock = 2131165219;
        public static final int disable_wifilock = 2131165221;
        public static final int edit_text = 2131165222;
        public static final int enable_wakelock = 2131165218;
        public static final int enable_wifilock = 2131165220;
        public static final int general_preferences = 2131165233;
        public static final int keyboard_preferences = 2131165276;
        public static final int new_window = 2131165201;
        public static final int next_window = 2131165205;
        public static final int ok = 2131165214;
        public static final int paste = 2131165225;
        public static final int perm_append_to_path = 2131165319;
        public static final int perm_prepend_to_path = 2131165321;
        public static final int perm_run_script = 2131165317;
        public static final int permdesc_append_to_path = 2131165320;
        public static final int permdesc_prepend_to_path = 2131165322;
        public static final int permdesc_run_script = 2131165318;
        public static final int pref_back_color_default = 2131165190;
        public static final int pref_backaction_default = 2131165191;
        public static final int pref_color_default = 2131165188;
        public static final int pref_controlkey_default = 2131165192;
        public static final int pref_cursorblink_default = 2131165186;
        public static final int pref_cursorstyle_default = 2131165185;
        public static final int pref_exportpath_default = 2131165198;
        public static final int pref_fnkey_default = 2131165193;
        public static final int pref_fontsize_default = 2131165187;
        public static final int pref_fore_color_default = 2131165189;
        public static final int pref_ime_default = 2131165194;
        public static final int pref_initialcommand_default = 2131165196;
        public static final int pref_sdcard_default = 2131165184;
        public static final int pref_shell_default = 2131165195;
        public static final int pref_termtype_default = 2131165197;
        public static final int preferences = 2131165200;
        public static final int prev_window = 2131165204;
        public static final int process_exit_message = 2131165232;
        public static final int reset = 2131165206;
        public static final int reset_msg = 2131165216;
        public static final int reset_toast_notification = 2131165217;
        public static final int screen_preferences = 2131165241;
        public static final int select_text = 2131165223;
        public static final int send_control_key = 2131165226;
        public static final int send_email = 2131165207;
        public static final int send_fn_key = 2131165227;
        public static final int service_notify_text = 2131165231;
        public static final int shell_preferences = 2131165289;
        public static final int special_keys = 2131165212;
        public static final int summary_actionbar_preference = 2131165246;
        public static final int summary_allow_prepend_path_preference = 2131165310;
        public static final int summary_backaction_preference = 2131165278;
        public static final int summary_basic_color_preference = 2131165267;
        public static final int summary_close_window_on_process_exit_preference = 2131165304;
        public static final int summary_color_preference = 2131165262;
        public static final int summary_controlkey_preference = 2131165281;
        public static final int summary_cursorblink_preference = 2131165252;
        public static final int summary_cursorstyle_preference = 2131165249;
        public static final int summary_do_path_extensions_preference = 2131165308;
        public static final int summary_exportpath_preference = 2131165300;
        public static final int summary_fnkey_preference = 2131165284;
        public static final int summary_fontsize_preference = 2131165258;
        public static final int summary_ime_preference = 2131165287;
        public static final int summary_initialcommand_preference = 2131165294;
        public static final int summary_sdcard_preference = 2131165235;
        public static final int summary_shell_preference = 2131165291;
        public static final int summary_specific_back_color_preference = 2131165275;
        public static final int summary_specific_color_preference = 2131165269;
        public static final int summary_specific_fore_color_preference = 2131165273;
        public static final int summary_statusbar_preference = 2131165243;
        public static final int summary_termtype_preference = 2131165297;
        public static final int summary_use_specific_color_preference = 2131165271;
        public static final int summary_utf8_by_default_preference = 2131165256;
        public static final int summary_verify_path_preference = 2131165306;
        public static final int summary_wakelock_preference = 2131165238;
        public static final int summary_wifilock_preference = 2131165240;
        public static final int text_preferences = 2131165254;
        public static final int title_actionbar_preference = 2131165245;
        public static final int title_allow_prepend_path_preference = 2131165309;
        public static final int title_backaction_preference = 2131165277;
        public static final int title_basic_color_preference = 2131165266;
        public static final int title_close_window_on_process_exit_preference = 2131165303;
        public static final int title_color_preference = 2131165261;
        public static final int title_controlkey_preference = 2131165280;
        public static final int title_cursorblink_preference = 2131165251;
        public static final int title_cursorstyle_preference = 2131165248;
        public static final int title_do_path_extensions_preference = 2131165307;
        public static final int title_exportpath_preference = 2131165299;
        public static final int title_fnkey_preference = 2131165283;
        public static final int title_fontsize_preference = 2131165257;
        public static final int title_ime_preference = 2131165286;
        public static final int title_initialcommand_preference = 2131165293;
        public static final int title_sdcard_preference = 2131165234;
        public static final int title_shell_preference = 2131165290;
        public static final int title_specific_back_color_preference = 2131165274;
        public static final int title_specific_color_preference = 2131165268;
        public static final int title_specific_fore_color_preference = 2131165272;
        public static final int title_statusbar_preference = 2131165242;
        public static final int title_termtype_preference = 2131165296;
        public static final int title_use_specific_color_preference = 2131165270;
        public static final int title_utf8_by_default_preference = 2131165255;
        public static final int title_verify_path_preference = 2131165305;
        public static final int title_wakelock_preference = 2131165237;
        public static final int title_wifilock_preference = 2131165239;
        public static final int toggle_soft_keyboard = 2131165213;
        public static final int window_list = 2131165203;
        public static final int window_title = 2131165230;
    }

    public static final class style {
        public static final int Theme = 2131361792;
        public static final int Theme_Holo = 2131361793;
        public static final int Theme_Holo_ActionBarOverlay = 2131361794;
        public static final int Theme_Holo_NoActionBar = 2131361796;
        public static final int Widget_ActionBarOverlay = 2131361795;
    }

    public static final class styleable {
        public static final int[] EmulatorView = new int[0];
    }

    public static final class xml {
        public static final int color_preferences = 2130968576;
        public static final int preferences = 2130968577;
    }

}

