/*
 * Decompiled with CFR 0_115.
 */
package b.a.a;

import b.a.a.c;
import b.a.a.h;
import b.a.a.i;

final class a
implements Runnable {
    final i a;
    final c b;

    a(c c2) {
        this.b = c2;
        this.a = new i();
    }

    @Override
    public final void run() {
        h h2 = this.a.a();
        if (h2 == null) {
            throw new IllegalStateException("No pending post available");
        }
        this.b.a(h2);
    }
}

