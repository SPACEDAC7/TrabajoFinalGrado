/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Looper
 *  android.os.Message
 *  android.util.Log
 */
package b.a.a;

import android.os.Looper;
import android.os.Message;
import android.util.Log;
import b.a.a.b;
import b.a.a.d;
import b.a.a.e;
import b.a.a.f;
import b.a.a.g;
import b.a.a.h;
import b.a.a.i;
import b.a.a.j;
import b.a.a.k;
import b.a.a.l;
import b.a.a.m;
import b.a.a.n;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;

public class c {
    public static String a = "Event";
    static volatile c b;
    private static final d d;
    private static final Map<Class<?>, List<Class<?>>> e;
    final ExecutorService c;
    private final Map<Class<?>, CopyOnWriteArrayList<m>> f;
    private final Map<Object, List<Class<?>>> g;
    private final Map<Class<?>, Object> h;
    private final ThreadLocal<a> i;
    private final f j;
    private final b k;
    private final b.a.a.a l;
    private final l m;
    private final boolean n;
    private final boolean o;
    private final boolean p;
    private final boolean q;
    private final boolean r;
    private final boolean s;

    static {
        d = new d();
        e = new HashMap();
    }

    public c() {
        this(d);
    }

    private c(d d2) {
        this.i = new ThreadLocal<a>(){

            @Override
            protected final /* synthetic */ Object initialValue() {
                return new a();
            }
        };
        this.f = new HashMap();
        this.g = new HashMap();
        this.h = new ConcurrentHashMap();
        this.j = new f(this, Looper.getMainLooper());
        this.k = new b(this);
        this.l = new b.a.a.a(this);
        this.m = new l(d2.h);
        this.o = d2.a;
        this.p = d2.b;
        this.q = d2.c;
        this.r = d2.d;
        this.n = d2.e;
        this.s = d2.f;
        this.c = d2.g;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static c a() {
        if (b == null) {
            synchronized (c.class) {
                if (b == null) {
                    b = new c();
                }
            }
        }
        return b;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void a(m object, Object object2) {
        try {
            object.b.a.invoke(object.a, object2);
            return;
        }
        catch (InvocationTargetException var3_4) {
            Throwable throwable = var3_4.getCause();
            if (object2 instanceof j) {
                if (!this.o) return;
                {
                    Log.e((String)a, (String)("SubscriberExceptionEvent subscriber " + object.a.getClass() + " threw an exception"), (Throwable)throwable);
                    object = (j)object2;
                    Log.e((String)a, (String)("Initial event " + object.c + " caused exception in " + object.d), (Throwable)object.b);
                    return;
                }
            }
            if (this.n) {
                throw new e("Invoking subscriber failed", throwable);
            }
            if (this.o) {
                Log.e((String)a, (String)("Could not dispatch event: " + object2.getClass() + " to subscribing class " + object.a.getClass()), (Throwable)throwable);
            }
            if (!this.q) return;
            this.b(new j(this, throwable, object2, object.a));
            return;
        }
        catch (IllegalAccessException var1_2) {
            throw new IllegalStateException("Unexpected exception", var1_2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void a(m object, Object object2, boolean bl2) {
        switch (.a[object.b.b.ordinal()]) {
            default: {
                throw new IllegalStateException("Unknown thread mode: " + (Object)((Object)object.b.b));
            }
            case 1: {
                this.a((m)object, object2);
                return;
            }
            case 2: {
                if (bl2) {
                    this.a((m)object, object2);
                    return;
                }
                f f2 = this.j;
                object = h.a((m)object, object2);
                synchronized (f2) {
                    f2.a.a((h)object);
                    if (!f2.b) {
                        f2.b = true;
                        if (!f2.sendMessage(f2.obtainMessage())) {
                            throw new e("Could not send handler message");
                        }
                    }
                    return;
                }
            }
            case 3: {
                if (!bl2) {
                    this.a((m)object, object2);
                    return;
                }
                b b2 = this.k;
                object = h.a((m)object, object2);
                synchronized (b2) {
                    b2.a.a((h)object);
                    if (!b2.c) {
                        b2.c = true;
                        b2.b.c.execute(b2);
                    }
                    return;
                }
            }
            case 4: 
        }
        b.a.a.a a2 = this.l;
        object = h.a((m)object, object2);
        a2.a.a((h)object);
        a2.b.c.execute(a2);
    }

    private static void a(List<Class<?>> list, Class<?>[] arrclass) {
        for (Class class_ : arrclass) {
            if (list.contains(class_)) continue;
            list.add(class_);
            c.a(list, class_.getInterfaces());
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean a(Object var1_1, a var2_3, Class<?> var3_4) {
        synchronized (this) {
            var3_4 = this.f.get(var3_4);
            ** if (var3_4 == null || var3_4.isEmpty()) goto lbl6
        }
lbl-1000: // 1 sources:
        {
            var3_4 = var3_4.iterator();
            ** GOTO lbl7
        }
lbl6: // 1 sources:
        return false;
lbl7: // 2 sources:
        while (var3_4.hasNext()) {
            var4_5 = (m)var3_4.next();
            var2_3.e = var1_1;
            var2_3.d = var4_5;
            this.a(var4_5, var1_1, var2_3.c);
            var5_6 = var2_3.f;
            if (!var5_6) continue;
        }
        return true;
        finally {
            var2_3.e = null;
            var2_3.d = null;
            var2_3.f = false;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static List<Class<?>> b(Class<?> class_) {
        Map map = e;
        synchronized (map) {
            List list;
            List list2 = list = e.get(class_);
            if (list != null) return list2;
            list = new ArrayList();
            for (list2 = class_; list2 != null; list2 = list2.getSuperclass()) {
                list.add((Object)list2);
                c.a(list, list2.getInterfaces());
            }
            e.put(class_, list);
            return list;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final <T> T a(Class<T> class_) {
        Map map = this.h;
        synchronized (map) {
            class_ = class_.cast(this.h.get(class_));
            return (T)class_;
        }
    }

    final void a(h h2) {
        Object object = h2.a;
        m m2 = h2.b;
        h.a(h2);
        if (m2.d) {
            this.a(m2, object);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final void a(Object var1_1) {
        // MONITORENTER : this
        var2_2 = this.g.get(var1_1);
        if (var2_2 == null) {
            Log.w((String)c.a, (String)("Subscriber to unregister was not registered before: " + var1_1.getClass()));
            return;
        }
        var2_2 = var2_2.iterator();
        block3 : do lbl-1000: // 3 sources:
        {
            if (!var2_2.hasNext()) {
                this.g.remove(var1_1);
                // MONITOREXIT : this
                return;
            }
            var3_3 = (Class)var2_2.next();
            if ((var3_3 = (List)this.f.get(var3_3)) == null) ** GOTO lbl-1000
            var5_5 = var3_3.size();
            var6_6 = 0;
            do {
                if (var6_6 >= var5_5) continue block3;
                var4_4 = (m)var3_3.get(var6_6);
                if (var4_4.a == var1_1) {
                    var4_4.d = false;
                    var3_3.remove(var6_6);
                    --var6_6;
                    --var5_5;
                }
                ++var6_6;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final void a(Object var1_1, boolean var2_2) {
        // MONITORENTER : this
        var5_3 = this.m.a(var1_1.getClass()).iterator();
        block8 : do {
            if (!var5_3.hasNext()) {
                // MONITOREXIT : this
                return;
            }
            var4_5 = var5_3.next();
            var6_6 = var4_5.c;
            var3_4 = this.f.get(var6_6);
            var7_7 = new m(var1_1, (k)var4_5);
            if (var3_4 == null) {
                var3_4 = new CopyOnWriteArrayList<E>();
                this.f.put(var6_6, (CopyOnWriteArrayList)var3_4);
            } else if (var3_4.contains(var7_7)) {
                throw new e("Subscriber " + var1_1.getClass() + " already registered to event " + var6_6);
            }
            var9_9 = var3_4.size();
            var8_8 = 0;
            do {
                if (var8_8 > var9_9) ** GOTO lbl23
                if (var8_8 == var9_9 || var7_7.c > ((m)var3_4.get((int)var8_8)).c) {
                    var3_4.add(var8_8, var7_7);
lbl23: // 2 sources:
                    var3_4 = var4_5 = this.g.get(var1_1);
                    if (var4_5 == null) {
                        var3_4 = new ArrayList<Class<?>>();
                        this.g.put(var1_1, var3_4);
                    }
                    var3_4.add(var6_6);
                    if (!var2_2) continue block8;
                    var3_4 = this.h;
                    // MONITORENTER : var3_4
                    var4_5 = this.h.get(var6_6);
                    // MONITOREXIT : var3_4
                    if (var4_5 == null) continue block8;
                    var10_10 = Looper.getMainLooper() == Looper.myLooper();
                    this.a(var7_7, var4_5, var10_10);
                    continue block8;
                }
                ++var8_8;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void b(Object var1_1) {
        var2_3 = this.i.get();
        var3_4 = var2_3.a;
        var3_4.add(var1_1);
        if (var2_3.b) return;
        if (Looper.getMainLooper() != Looper.myLooper()) ** GOTO lbl13
        var8_5 = true;
lbl7: // 2 sources:
        do {
            var2_3.c = var8_5;
            var2_3.b = true;
            if (var2_3.f) {
                throw new e("Internal error. Abort state was not reset");
            }
            ** GOTO lbl23
            break;
        } while (true);
lbl13: // 1 sources:
        var8_5 = false;
        ** while (true)
        {
            if (var8_5) ** GOTO lbl23
            block7 : do {
                if (this.p) {
                    Log.d((String)c.a, (String)("No subscribers registered for event " + var4_6));
                }
                if (!this.r || var4_6 == g.class || var4_6 == j.class) ** GOTO lbl23
                this.b(new g(this, var1_1));
lbl23: // 4 sources:
                if (var3_4.isEmpty()) break block6;
                var1_1 = var3_4.remove(0);
                var4_6 = var1_1.getClass();
                if (!this.s) break;
                var5_7 = c.b(var4_6);
                var7_9 = var5_7.size();
                var6_8 = 0;
                var8_5 = false;
                do {
                    if (var6_8 >= var7_9) continue block7;
                    var8_5 |= this.a(var1_1, var2_3, var5_7.get(var6_8));
                    ++var6_8;
                } while (true);
                break;
            } while (true);
            var8_5 = this.a(var1_1, var2_3, var4_6);
            continue;
        }
        var2_3.b = false;
        var2_3.c = false;
        return;
        catch (Throwable var1_2) {
            var2_3.b = false;
            var2_3.c = false;
            throw var1_2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void c(Object object) {
        Map map = this.h;
        synchronized (map) {
            this.h.put(object.getClass(), object);
        }
        this.b(object);
    }

    static final class a {
        final List<Object> a = new ArrayList<Object>();
        boolean b;
        boolean c;
        m d;
        Object e;
        boolean f;

        a() {
        }
    }

}

