/*
 * Decompiled with CFR 0_115.
 */
package b.a.a;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class d {
    private static final ExecutorService i = Executors.newCachedThreadPool();
    boolean a = true;
    boolean b = true;
    boolean c = true;
    boolean d = true;
    boolean e;
    boolean f = true;
    ExecutorService g = i;
    List<Class<?>> h;

    d() {
    }
}

