/*
 * Decompiled with CFR 0_115.
 */
package b.a.a;

public final class e
extends RuntimeException {
    public e(String string) {
        super(string);
    }

    public e(String string, Throwable throwable) {
        super(string, throwable);
    }
}

