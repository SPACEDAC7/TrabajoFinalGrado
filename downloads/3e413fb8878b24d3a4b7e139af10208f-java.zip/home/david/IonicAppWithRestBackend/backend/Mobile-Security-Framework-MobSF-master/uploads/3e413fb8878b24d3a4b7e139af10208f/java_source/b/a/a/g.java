/*
 * Decompiled with CFR 0_115.
 */
package b.a.a;

import b.a.a.c;

public final class g {
    public final c a;
    public final Object b;

    public g(c c2, Object object) {
        this.a = c2;
        this.b = object;
    }
}

