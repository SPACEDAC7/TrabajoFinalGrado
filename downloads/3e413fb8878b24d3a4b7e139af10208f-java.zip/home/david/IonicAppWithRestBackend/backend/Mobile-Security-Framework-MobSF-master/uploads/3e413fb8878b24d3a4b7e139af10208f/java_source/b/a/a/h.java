/*
 * Decompiled with CFR 0_115.
 */
package b.a.a;

import b.a.a.m;
import java.util.ArrayList;
import java.util.List;

final class h {
    private static final List<h> d = new ArrayList<h>();
    Object a;
    m b;
    h c;

    private h(Object object, m m2) {
        this.a = object;
        this.b = m2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static h a(m m2, Object object) {
        List<h> list = d;
        synchronized (list) {
            int n2 = d.size();
            if (n2 > 0) {
                h h2 = d.remove(n2 - 1);
                h2.a = object;
                h2.b = m2;
                h2.c = null;
                return h2;
            }
            return new h(object, m2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void a(h h2) {
        h2.a = null;
        h2.b = null;
        h2.c = null;
        List<h> list = d;
        synchronized (list) {
            if (d.size() < 10000) {
                d.add(h2);
            }
            return;
        }
    }
}

