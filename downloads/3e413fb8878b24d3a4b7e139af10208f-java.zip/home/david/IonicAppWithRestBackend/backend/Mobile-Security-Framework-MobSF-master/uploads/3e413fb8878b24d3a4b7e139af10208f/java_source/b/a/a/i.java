/*
 * Decompiled with CFR 0_115.
 */
package b.a.a;

import b.a.a.h;

final class i {
    private h a;
    private h b;

    i() {
    }

    final h a() {
        synchronized (this) {
            h h2 = this.a;
            if (this.a != null) {
                this.a = this.a.c;
                if (this.a == null) {
                    this.b = null;
                }
            }
            return h2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    final void a(h h2) {
        synchronized (this) {
            if (h2 == null) {
                throw new NullPointerException("null cannot be enqueued");
            }
            if (this.b != null) {
                this.b.c = h2;
                this.b = h2;
            } else {
                if (this.a != null) {
                    throw new IllegalStateException("Head present, but no tail");
                }
                this.b = h2;
                this.a = h2;
            }
            this.notifyAll();
            return;
        }
    }

    final h b() {
        synchronized (this) {
            if (this.a == null) {
                this.wait(1000);
            }
            h h2 = this.a();
            return h2;
        }
    }
}

