/*
 * Decompiled with CFR 0_115.
 */
package b.a.a;

import b.a.a.c;

public final class j {
    public final c a;
    public final Throwable b;
    public final Object c;
    public final Object d;

    public j(c c2, Throwable throwable, Object object, Object object2) {
        this.a = c2;
        this.b = throwable;
        this.c = object;
        this.d = object2;
    }
}

