/*
 * Decompiled with CFR 0_115.
 */
package b.a.a;

import b.a.a.n;
import java.lang.reflect.Method;

final class k {
    final Method a;
    final n b;
    final Class<?> c;
    String d;

    k(Method method, n n2, Class<?> class_) {
        this.a = method;
        this.b = n2;
        this.c = class_;
    }

    private void a() {
        synchronized (this) {
            if (this.d == null) {
                StringBuilder stringBuilder = new StringBuilder(64);
                stringBuilder.append(this.a.getDeclaringClass().getName());
                stringBuilder.append('#').append(this.a.getName());
                stringBuilder.append('(').append(this.c.getName());
                this.d = stringBuilder.toString();
            }
            return;
        }
    }

    public final boolean equals(Object object) {
        if (object instanceof k) {
            this.a();
            object = (k)object;
            super.a();
            return this.d.equals(object.d);
        }
        return false;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }
}

