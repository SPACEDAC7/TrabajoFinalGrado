/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package b.a.a;

import android.util.Log;
import b.a.a.c;
import b.a.a.e;
import b.a.a.k;
import b.a.a.n;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

final class l {
    private static final Map<String, List<k>> a = new HashMap<String, List<k>>();
    private final Map<Class<?>, Class<?>> b = new ConcurrentHashMap();

    l(List<Class<?>> object) {
        if (object != null) {
            object = object.iterator();
            while (object.hasNext()) {
                Class class_ = (Class)object.next();
                this.b.put(class_, class_);
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    final List<k> a(Class<?> var1_1) {
        var4_2 = var1_1.getName();
        var2_3 = l.a;
        // MONITORENTER : var2_3
        var3_4 = l.a.get(var4_2);
        // MONITOREXIT : var2_3
        if (var3_4 != null) {
            return var3_4;
        }
        var5_5 = new ArrayList<k>();
        var6_6 = new HashSet<String>();
        var7_7 = new StringBuilder();
        var3_4 = var1_1;
        do {
            if (!(var3_4 == null || (var2_3 = var3_4.getName()).startsWith("java.") || var2_3.startsWith("javax.") || var2_3.startsWith("android."))) {
                var8_8 = var3_4.getDeclaredMethods();
                var13_13 = var8_8.length;
            } else {
                if (var5_5.isEmpty()) {
                    throw new e("Subscriber " + var1_1 + " has no public methods called onEvent");
                }
                var1_1 = l.a;
                // MONITORENTER : var1_1
                l.a.put(var4_2, var5_5);
                // MONITOREXIT : var1_1
                return var5_5;
            }
            for (var12_12 = 0; var12_12 < var13_13; ++var12_12) {
                var9_9 = var8_8[var12_12];
                var10_10 = var9_9.getName();
                if (!var10_10.startsWith("onEvent")) continue;
                var14_14 = var9_9.getModifiers();
                if ((var14_14 & 1) == 0 || (var14_14 & 5192) != 0) ** GOTO lbl53
                var11_11 = var9_9.getParameterTypes();
                if (var11_11.length != 1) continue;
                var2_3 = var10_10.substring(7);
                if (var2_3.length() != 0) ** GOTO lbl36
                var2_3 = n.a;
                ** GOTO lbl44
lbl36: // 1 sources:
                if (!var2_3.equals("MainThread")) ** GOTO lbl39
                var2_3 = n.b;
                ** GOTO lbl44
lbl39: // 1 sources:
                if (!var2_3.equals("BackgroundThread")) ** GOTO lbl42
                var2_3 = n.c;
                ** GOTO lbl44
lbl42: // 1 sources:
                if (var2_3.equals("Async")) {
                    var2_3 = n.d;
lbl44: // 4 sources:
                    var11_11 = var11_11[0];
                    var7_7.setLength(0);
                    var7_7.append(var10_10);
                    var7_7.append('>').append(var11_11.getName());
                    if (!var6_6.add(var7_7.toString())) continue;
                    var5_5.add(new k(var9_9, (n)var2_3, var11_11));
                    continue;
                }
                if (this.b.containsKey(var3_4)) continue;
                throw new e("Illegal onEvent method, check for typos: " + var9_9);
lbl53: // 1 sources:
                if (this.b.containsKey(var3_4)) continue;
                Log.d((String)c.a, (String)("Skipping method (not public, static or abstract): " + var3_4 + "." + var10_10));
            }
            var3_4 = var3_4.getSuperclass();
        } while (true);
    }
}

