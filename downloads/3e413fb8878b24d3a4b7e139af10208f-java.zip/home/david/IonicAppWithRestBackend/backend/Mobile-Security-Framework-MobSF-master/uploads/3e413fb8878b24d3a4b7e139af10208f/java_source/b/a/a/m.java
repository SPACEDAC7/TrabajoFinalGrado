/*
 * Decompiled with CFR 0_115.
 */
package b.a.a;

import b.a.a.k;

final class m {
    final Object a;
    final k b;
    final int c;
    volatile boolean d;

    m(Object object, k k2) {
        this.a = object;
        this.b = k2;
        this.c = 0;
        this.d = true;
    }

    public final boolean equals(Object object) {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (object instanceof m) {
            object = (m)object;
            bl3 = bl2;
            if (this.a == object.a) {
                bl3 = bl2;
                if (this.b.equals(object.b)) {
                    bl3 = true;
                }
            }
        }
        return bl3;
    }

    public final int hashCode() {
        return this.a.hashCode() + this.b.d.hashCode();
    }
}

