/*
 * Decompiled with CFR 0_115.
 */
package b.a.a;

public enum n {
    a,
    b,
    c,
    d;
    

    private n() {
    }
}

