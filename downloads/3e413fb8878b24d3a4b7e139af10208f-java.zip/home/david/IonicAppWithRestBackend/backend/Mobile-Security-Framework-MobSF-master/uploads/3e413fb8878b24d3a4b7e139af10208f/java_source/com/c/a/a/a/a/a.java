/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.res.Configuration
 */
package com.c.a.a.a.a;

import android.content.res.Configuration;

public interface a {
    public void onConfigurationChanged(Configuration var1);

    public void onCreate();

    public void onLowMemory();

    public void onTerminate();

    public void onTrimMemory(int var1);
}

