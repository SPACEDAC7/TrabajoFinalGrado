/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.res.Configuration
 */
package com.c.a.a.a.a;

import android.content.res.Configuration;
import com.c.a.a.a.a.a;

public class b
implements a {
    @Override
    public void onConfigurationChanged(Configuration configuration) {
    }

    @Override
    public void onCreate() {
    }

    @Override
    public void onLowMemory() {
    }

    @Override
    public void onTerminate() {
    }

    @Override
    public void onTrimMemory(int n2) {
    }
}

