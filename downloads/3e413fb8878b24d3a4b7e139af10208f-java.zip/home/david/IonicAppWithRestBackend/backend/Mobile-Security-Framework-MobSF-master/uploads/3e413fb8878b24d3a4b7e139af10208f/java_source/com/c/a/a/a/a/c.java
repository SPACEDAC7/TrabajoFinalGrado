/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Application
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.util.Log
 */
package com.c.a.a.a.a;

import android.annotation.TargetApi;
import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;
import android.util.Log;
import com.c.a.a.a.a.a;
import com.c.a.a.a.a.b;
import com.c.a.a.a.a.d;
import com.c.a.a.a.a.e;
import java.io.File;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashSet;

public abstract class c<T extends a>
extends Application {
    private final String a;
    private final int b;
    private T c;

    protected c(int n2) {
        this(b.class.getName(), n2);
    }

    public c(String string, int n2) {
        this.a = string;
        this.b = n2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private T b() {
        Object object;
        int n2 = 1;
        int n3 = (this.b & 1) != 0 ? 1 : 0;
        if (n3 != 0) {
            File file = new File("/data/local/tmp/exopackage/" + this.getPackageName() + "/secondary-dex");
            File[] arrfile = new File[]();
            object = new HashSet();
            File[] arrfile2 = file.listFiles();
            if (arrfile2 != null) {
                for (File file2 : arrfile2) {
                    if (file2.getName().equals("metadata.txt")) continue;
                    if (!file2.getName().endsWith(".dex.jar")) {
                        Log.w((String)"ExopackageDexLoader", (String)("Skipping unexpected file in exopackage directory: " + file2.getName()));
                        continue;
                    }
                    arrfile.add(file2);
                    object.add(file2.getName().replaceFirst("\\.jar$", ".dex"));
                }
            }
            File file3 = this.getDir("exopackage_dex_opt", 0);
            e.a(this.getClassLoader(), file3, arrfile);
            arrfile = file3.listFiles();
            if (arrfile != null) {
                for (File file4 : arrfile) {
                    if (object.contains(file4.getName()) || file4.delete()) continue;
                    Log.w((String)"ExopackageDexLoader", (String)("Failed to delete stale odex: " + file4.getAbsolutePath()));
                }
            }
        }
        n3 = (this.b & 2) != 0 ? n2 : 0;
        if (n3 != 0) {
            d.a((Context)this);
        }
        try {
            object = (a)Class.forName(this.a).getConstructor(Application.class).newInstance(new Object[]{this});
        }
        catch (Exception var1_10) {
            throw new RuntimeException(var1_10);
        }
        return (T)object;
    }

    private void c() {
        synchronized (this) {
            if (this.c == null) {
                this.c = this.b();
            }
            return;
        }
    }

    public void a() {
    }

    protected final void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        this.a();
        this.c();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.c != null) {
            this.c.onConfigurationChanged(configuration);
        }
    }

    public final void onCreate() {
        super.onCreate();
        this.c();
        this.c.onCreate();
    }

    public final void onLowMemory() {
        super.onLowMemory();
        if (this.c != null) {
            this.c.onLowMemory();
        }
    }

    public final void onTerminate() {
        super.onTerminate();
        if (this.c != null) {
            this.c.onTerminate();
        }
    }

    @TargetApi(value=14)
    public final void onTrimMemory(int n2) {
        super.onTrimMemory(n2);
        if (this.c != null) {
            this.c.onTrimMemory(n2);
        }
    }
}

