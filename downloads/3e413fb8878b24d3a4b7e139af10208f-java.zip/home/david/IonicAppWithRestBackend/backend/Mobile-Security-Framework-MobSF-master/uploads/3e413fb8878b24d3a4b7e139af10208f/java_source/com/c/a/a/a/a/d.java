/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.util.Log
 */
package com.c.a.a.a.a;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

public final class d {
    private static boolean a = false;
    private static String b = null;
    private static File c = null;
    private static Map<String, String> d = new HashMap<String, String>();
    private static Map<String, String> e = new HashMap<String, String>();

    private static File a() {
        return new File(b + Build.CPU_ABI + "/metadata.txt");
    }

    public static void a(Context context) {
        File file;
        if (a) {
            Log.d((String)"ExopackageSoLoader", (String)"init() already called, so nothing to do.");
            return;
        }
        b = "/data/local/tmp/exopackage/" + context.getPackageName() + "/native-libs/";
        if (d.a().exists() || (file = d.b()) == null || file.exists()) {
            d.b(context);
            d.a(d.a(), d);
            d.a(d.b(), e);
            a = true;
            return;
        }
        throw new RuntimeException("Either 'native' exopackage is not turned on for this build, or the installation did not complete successfully.");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void a(File var0, Map<String, String> var1_2) {
        if (var0 == null) return;
        if (!var0.exists()) {
            return;
        }
        var0 = new BufferedReader(new FileReader((File)var0));
        try {
            while ((var2_4 = var0.readLine()) != null) {
                if ((var2_4 = var2_4.trim()).isEmpty()) continue;
                var3_5 = var2_4.indexOf(32);
                if (var3_5 == -1) {
                    throw new RuntimeException("Error parsing metadata.txt; invalid line: " + var2_4);
                }
                var1_2.put(var2_4.substring(0, var3_5), var2_4.substring(var3_5 + 1));
            }
            ** GOTO lbl22
        }
        catch (Throwable var1_3) {
            try {
                var0.close();
                throw var1_3;
            }
            catch (IOException var0_1) {
                throw new RuntimeException(var0_1);
            }
lbl22: // 2 sources:
            var0.close();
            return;
        }
    }

    private static File b() {
        if (Build.CPU_ABI2.equals("unknown")) {
            return null;
        }
        return new File(b + Build.CPU_ABI2 + "/metadata.txt");
    }

    private static void b(Context arrfile) {
        c = arrfile = arrfile.getDir("exo-libs", 0);
        arrfile = arrfile.listFiles();
        int n2 = arrfile.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrfile[i2].delete();
        }
    }
}

