/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  dalvik.system.BaseDexClassLoader
 *  dalvik.system.DexClassLoader
 *  dalvik.system.PathClassLoader
 */
package com.c.a.a.a.a;

import android.annotation.TargetApi;
import dalvik.system.BaseDexClassLoader;
import dalvik.system.DexClassLoader;
import dalvik.system.PathClassLoader;
import java.io.File;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;

public final class e {
    private e() {
    }

    @TargetApi(value=14)
    private static Object a(BaseDexClassLoader baseDexClassLoader) {
        return e.a((Object)baseDexClassLoader, BaseDexClassLoader.class, "pathList");
    }

    private static Object a(Object object) {
        return e.a(object, object.getClass(), "dexElements");
    }

    private static Object a(Object object, Class<?> class_, String string) {
        class_ = class_.getDeclaredField(string);
        class_.setAccessible(true);
        return class_.get(object);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object a(Object object, Object object2) {
        Object object3 = object.getClass().getComponentType();
        int n2 = Array.getLength(object);
        int n3 = Array.getLength(object2) + n2;
        object3 = Array.newInstance(object3, n3);
        int n4 = 0;
        while (n4 < n3) {
            if (n4 < n2) {
                Array.set(object3, n4, Array.get(object, n4));
            } else {
                Array.set(object3, n4, Array.get(object2, n4 - n2));
            }
            ++n4;
        }
        return object3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void a(DexClassLoader dexClassLoader, PathClassLoader pathClassLoader) {
        try {
            dexClassLoader.loadClass("foo");
        }
        catch (ClassNotFoundException var2_2) {}
        Object object = e.a((Object)pathClassLoader, PathClassLoader.class, "mPaths");
        Object object2 = e.a((Object)dexClassLoader, DexClassLoader.class, "mRawDexPath");
        Object object3 = object.getClass().getComponentType();
        int n2 = Array.getLength(object);
        int n3 = n2 + 1;
        object3 = Array.newInstance(object3, n3);
        int n4 = 0;
        do {
            if (n4 >= n3) {
                e.a((Object)pathClassLoader, PathClassLoader.class, "mPaths", object3);
                e.a((Object)pathClassLoader, PathClassLoader.class, "mFiles", e.a(e.a((Object)pathClassLoader, PathClassLoader.class, "mFiles"), e.a((Object)dexClassLoader, DexClassLoader.class, "mFiles")));
                e.a((Object)pathClassLoader, PathClassLoader.class, "mZips", e.a(e.a((Object)pathClassLoader, PathClassLoader.class, "mZips"), e.a((Object)dexClassLoader, DexClassLoader.class, "mZips")));
                e.a((Object)pathClassLoader, PathClassLoader.class, "mDexs", e.a(e.a((Object)pathClassLoader, PathClassLoader.class, "mDexs"), e.a((Object)dexClassLoader, DexClassLoader.class, "mDexs")));
                return;
            }
            if (n4 < n2) {
                Array.set(object3, n4, Array.get(object, n4));
            } else {
                Array.set(object3, n4, object2);
            }
            ++n4;
        } while (true);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void a(ClassLoader classLoader, File file, List<File> object) {
        new e();
        object = object.iterator();
        while (object.hasNext()) {
            Object object2 = new DexClassLoader(((File)object.next()).getAbsolutePath(), file.getAbsolutePath(), null, classLoader);
            Object object3 = (PathClassLoader)classLoader;
            if (e.a()) {
                object2 = e.a(e.a(e.a((BaseDexClassLoader)object3)), e.a(e.a((BaseDexClassLoader)object2)));
                object3 = e.a((BaseDexClassLoader)object3);
                e.a(object3, object3.getClass(), "dexElements", object2);
                continue;
            }
            e.a((DexClassLoader)object2, (PathClassLoader)object3);
            continue;
        }
        return;
        catch (NoSuchFieldException noSuchFieldException) {
            throw new RuntimeException(noSuchFieldException);
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new RuntimeException(illegalAccessException);
        }
    }

    private static void a(Object object, Class<?> class_, String string, Object object2) {
        class_ = class_.getDeclaredField(string);
        class_.setAccessible(true);
        class_.set(object, object2);
    }

    private static boolean a() {
        try {
            Class.forName("dalvik.system.BaseDexClassLoader");
            return true;
        }
        catch (ClassNotFoundException var0) {
            return false;
        }
    }
}

