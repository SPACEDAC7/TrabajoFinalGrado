/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 */
package com.c.b;

import a.a.a.a.d;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.c.b.c;

public abstract class a
extends BroadcastReceiver {
    public abstract c a();

    /*
     * Enabled aggressive block sorting
     */
    public void onReceive(Context context, Intent intent) {
        c c2 = this.a();
        if (!"com.facebook.GET_PHONE_ID".equals(intent.getAction()) || c2 == null || !d.a(context, this.getResultExtras(true))) {
            return;
        }
        context = new Bundle();
        context.putLong("timestamp", c2.b);
        this.setResult(-1, c2.a, (Bundle)context);
    }
}

