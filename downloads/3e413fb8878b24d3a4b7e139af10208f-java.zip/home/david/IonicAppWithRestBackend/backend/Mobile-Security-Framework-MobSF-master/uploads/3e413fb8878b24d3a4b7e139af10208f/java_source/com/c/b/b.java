/*
 * Decompiled with CFR 0_115.
 */
package com.c.b;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class b {
    private static final Set<String> a;

    static {
        HashSet<String> hashSet = new HashSet<String>();
        hashSet.add("ijxLJi1yGs1JpL-X1SExmchvork");
        hashSet.add("xW-31ZG6ZwTfBH_Zj1NTcv6gAhE");
        hashSet.add("Sr9mhPKOEwo6NysnYn803dZ3UiY");
        hashSet.add("OKD31QX-GP7GT780Psqq8xDb15k");
        a = Collections.unmodifiableSet(hashSet);
    }

    public static boolean a(String string) {
        return a.contains(string);
    }
}

