/*
 * Decompiled with CFR 0_115.
 */
package com.c.b;

public final class c {
    public final String a;
    public final long b;

    public c(String string, long l2) {
        this.a = string;
        this.b = l2;
    }

    public final String toString() {
        return this.a + " : " + this.b;
    }
}

