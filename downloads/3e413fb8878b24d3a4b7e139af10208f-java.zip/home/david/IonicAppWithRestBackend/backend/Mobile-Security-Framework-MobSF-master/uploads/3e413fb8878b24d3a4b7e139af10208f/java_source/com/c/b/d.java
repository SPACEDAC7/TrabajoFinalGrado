/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.PendingIntent
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Parcelable
 */
package com.c.b;

import a.a.a.a.a.a;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.design.widget.AppBarLayout;
import com.c.b.b;
import com.c.b.e;
import com.c.b.f;
import com.whatsapp.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class d {
    private final Context a;
    private final f b;
    private final AppBarLayout.b c;

    public d(Context context, f f2) {
        this.a = a.d.a(context).getApplicationContext();
        this.b = a.d.a(f2);
        this.c = null;
    }

    @SuppressLint(value={"PackageManagerGetSignatures"})
    private List<String> b() {
        Object object = this.a.getPackageManager().getInstalledPackages(0);
        ArrayList<String> arrayList = new ArrayList<String>();
        String string = this.a.getPackageName();
        object = object.iterator();
        while (object.hasNext()) {
            PackageInfo packageInfo = (PackageInfo)object.next();
            if (packageInfo.packageName.equals(string)) continue;
            try {}
            catch (PackageManager.NameNotFoundException var5_6) {
                Log.d("could not find package; packageName=" + packageInfo.packageName, (Throwable)var5_6);
                continue;
            }
            PackageInfo packageInfo2 = this.a.getPackageManager().getPackageInfo(packageInfo.packageName, 64);
            if (!b.a(a.a.a.a.d.a(packageInfo2))) continue;
            arrayList.add(packageInfo2.packageName);
        }
        return arrayList;
    }

    public final void a() {
        Object object = this.b();
        Log.d("found " + object.size() + " trusted packages: " + object);
        object = object.iterator();
        while (object.hasNext()) {
            String string = (String)object.next();
            Intent intent = new Intent();
            intent.setAction("com.facebook.GET_PHONE_ID");
            intent.setPackage(string);
            string = PendingIntent.getActivity((Context)this.a, (int)0, (Intent)new Intent(), (int)134217728);
            Bundle bundle = new Bundle();
            bundle.putParcelable("auth", (Parcelable)string);
            this.a.sendOrderedBroadcast(intent, null, (BroadcastReceiver)new e(this.b, this.c), null, 1, null, bundle);
        }
    }
}

