/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 */
package com.c.b;

import a.a.a.a.a.a;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import com.c.b.c;
import com.c.b.f;
import com.whatsapp.util.Log;

public final class e
extends BroadcastReceiver {
    private final f a;
    private final AppBarLayout.b b;

    public e(f f2, AppBarLayout.b b2) {
        this.a = a.d.a(f2);
        this.b = b2;
    }

    public final void onReceive(Context object, Intent object2) {
        if (this.getResultCode() == -1) {
            object = new c(this.getResultData(), this.getResultExtras(true).getLong("timestamp", Long.MAX_VALUE));
            Log.d("received phone id from " + object2.getPackage() + ": " + object);
            object2.getPackage();
            object2 = this.a.a();
            if (object.a != null && object.b < object2.b) {
                this.a.a((c)object);
                Log.i("updated phone id from " + object2 + " to " + object);
            }
            return;
        }
        Log.d("unsuccessful phone id query to " + object2.getPackage());
    }
}

