/*
 * Decompiled with CFR 0_115.
 */
package com.c.b;

import com.c.b.c;

public interface f {
    public c a();

    public void a(c var1);
}

