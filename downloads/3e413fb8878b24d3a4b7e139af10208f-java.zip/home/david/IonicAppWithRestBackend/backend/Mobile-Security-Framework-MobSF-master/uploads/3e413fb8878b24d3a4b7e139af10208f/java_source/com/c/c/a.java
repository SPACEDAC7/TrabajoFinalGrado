/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.os.SystemClock
 *  android.view.Choreographer
 *  android.view.Choreographer$FrameCallback
 */
package com.c.c;

import android.annotation.TargetApi;
import android.os.SystemClock;
import android.view.Choreographer;
import com.c.c.c;
import com.c.c.g;

@TargetApi(value=16)
public final class a
extends g {
    final Choreographer a;
    final Choreographer.FrameCallback b;
    boolean c;
    long d;

    public a(Choreographer choreographer) {
        this.a = choreographer;
        this.b = new Choreographer.FrameCallback(){

            public final void doFrame(long l2) {
                if (!a.this.c || a.this.e == null) {
                    return;
                }
                l2 = SystemClock.uptimeMillis();
                a.this.e.a(l2 - a.this.d);
                a.this.d = l2;
                a.this.a.postFrameCallback(a.this.b);
            }
        };
    }

    @Override
    public final void a() {
        if (this.c) {
            return;
        }
        this.c = true;
        this.d = SystemClock.uptimeMillis();
        this.a.removeFrameCallback(this.b);
        this.a.postFrameCallback(this.b);
    }

    @Override
    public final void b() {
        this.c = false;
        this.a.removeFrameCallback(this.b);
    }

}

