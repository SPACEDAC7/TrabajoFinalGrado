/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.SystemClock
 */
package com.c.c;

import android.os.Handler;
import android.os.SystemClock;
import com.c.c.c;
import com.c.c.g;

public final class b
extends g {
    final Handler a;
    final Runnable b;
    boolean c;
    long d;

    public b(Handler handler) {
        this.a = handler;
        this.b = new Runnable(){

            @Override
            public final void run() {
                if (!b.this.c || b.this.e == null) {
                    return;
                }
                long l2 = SystemClock.uptimeMillis();
                b.this.e.a(l2 - b.this.d);
                b.this.a.post(b.this.b);
            }
        };
    }

    @Override
    public final void a() {
        if (this.c) {
            return;
        }
        this.c = true;
        this.d = SystemClock.uptimeMillis();
        this.a.removeCallbacks(this.b);
        this.a.post(this.b);
    }

    @Override
    public final void b() {
        this.c = false;
        this.a.removeCallbacks(this.b);
    }

}

