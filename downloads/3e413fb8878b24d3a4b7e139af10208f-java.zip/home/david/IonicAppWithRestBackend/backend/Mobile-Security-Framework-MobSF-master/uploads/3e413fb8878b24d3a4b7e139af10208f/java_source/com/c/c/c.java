/*
 * Decompiled with CFR 0_115.
 */
package com.c.c;

import android.support.design.widget.AppBarLayout;
import com.c.c.d;
import com.c.c.e;
import com.c.c.f;
import com.c.c.g;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

public class c {
    public final Map<String, d> a = new HashMap<String, d>();
    private final Set<d> b = new CopyOnWriteArraySet<d>();
    private final g c;
    private final CopyOnWriteArraySet<AppBarLayout.b> d = new CopyOnWriteArraySet();
    private boolean e = true;

    public c(g g2) {
        if (g2 == null) {
            throw new IllegalArgumentException("springLooper is required");
        }
        this.c = g2;
        this.c.a(this);
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void a(double var1_1) {
        var27_2 = this.d.iterator();
        while (var27_2.hasNext()) {
            var27_2.next();
        }
        block1 : for (d var28_18 : this.b) {
            block18 : {
                block20 : {
                    block19 : {
                        if (!var28_18.a() || !var28_18.i) {
                            var31_19 = true;
lbl8: // 2 sources:
                            do {
                                if (!var31_19) break block18;
                                var5_6 = var1_1 / 1000.0;
                                var33_4 = var28_18.a();
                                if (var33_4 && var28_18.i) continue block1;
                                var3_5 = var5_6;
                                if (var5_6 > 0.064) {
                                    var3_5 = 0.064;
                                }
                                var28_18.k = var3_5 + var28_18.k;
                                var11_9 = var28_18.a.b;
                                var13_10 = var28_18.a.a;
                                var5_6 = var28_18.d.a;
                                var3_5 = var28_18.d.b;
                                var9_8 = var28_18.f.a;
                                var7_7 = var28_18.f.b;
                                while (var28_18.k >= 0.001) {
                                    var28_18.k -= 0.001;
                                    if (var28_18.k < 0.001) {
                                        var28_18.e.a = var5_6;
                                        var28_18.e.b = var3_5;
                                    }
                                    var15_11 = (var28_18.h - var9_8) * var11_9 - var13_10 * var3_5;
                                    var23_15 = var3_5 + 0.001 * var15_11 * 0.5;
                                    var17_12 = (var28_18.h - (0.001 * var3_5 * 0.5 + var5_6)) * var11_9 - var13_10 * var23_15;
                                    var25_16 = var3_5 + 0.001 * var17_12 * 0.5;
                                    var19_13 = (var28_18.h - (0.001 * var23_15 * 0.5 + var5_6)) * var11_9 - var13_10 * var25_16;
                                    var9_8 = var5_6 + 0.001 * var25_16;
                                    var7_7 = 0.001 * var19_13 + var3_5;
                                    var21_14 = var28_18.h;
                                    var5_6 += ((var23_15 + var25_16) * 2.0 + var3_5 + var7_7) * 0.16666666666666666 * 0.001;
                                    var3_5 += (var15_11 + (var17_12 + var19_13) * 2.0 + ((var21_14 - var9_8) * var11_9 - var13_10 * var7_7)) * 0.16666666666666666 * 0.001;
                                }
                                break block19;
                                break;
                            } while (true);
                        }
                        var31_19 = false;
                        ** continue;
                    }
                    var28_18.f.a = var9_8;
                    var28_18.f.b = var7_7;
                    var28_18.d.a = var5_6;
                    var28_18.d.b = var3_5;
                    if (var28_18.k > 0.0) {
                        var3_5 = var28_18.k / 0.001;
                        var28_18.d.a = var28_18.d.a * var3_5 + var28_18.e.a * (1.0 - var3_5);
                        var29_17 = var28_18.d;
                        var5_6 = var28_18.d.b;
                        var29_17.b = (1.0 - var3_5) * var28_18.e.b + var5_6 * var3_5;
                    }
                    if (var28_18.a()) ** GOTO lbl61
                    var32_3 = var33_4;
                    if (!var28_18.b) ** GOTO lbl69
                    if (var28_18.a.b <= 0.0 || (var28_18.g >= var28_18.h || var28_18.d.a <= var28_18.h) && (var28_18.g <= var28_18.h || var28_18.d.a >= var28_18.h)) ** GOTO lbl82
                    var31_19 = true;
lbl58: // 2 sources:
                    do {
                        var32_3 = var33_4;
                        if (!var31_19) ** GOTO lbl69
lbl61: // 2 sources:
                        if (var11_9 > 0.0) {
                            var28_18.g = var28_18.h;
                            var28_18.d.a = var28_18.h;
lbl64: // 2 sources:
                            do {
                                if (0.0 != var28_18.d.b) {
                                    var28_18.d.b = 0.0;
                                    var28_18.l.a(var28_18.c);
                                }
                                var32_3 = true;
lbl69: // 3 sources:
                                if (var28_18.i) {
                                    var28_18.i = false;
                                }
                                var31_19 = false;
                                if (var32_3) {
                                    var28_18.i = true;
                                    var31_19 = true;
                                }
                                for (f var30_20 : var28_18.j) {
                                    var30_20.a(var28_18);
                                    if (!var31_19) continue;
                                    var30_20.a();
                                }
                                continue block1;
                                break;
                            } while (true);
                        }
                        break block20;
                        break;
                    } while (true);
lbl82: // 1 sources:
                    var31_19 = false;
                    ** continue;
                }
                var28_18.g = var28_18.h = var28_18.d.a;
                ** continue;
            }
            this.b.remove(var28_18);
        }
        if (this.b.isEmpty()) {
            this.e = true;
        }
        var27_2 = this.d.iterator();
        while (var27_2.hasNext()) {
            var27_2.next();
        }
        if (!this.e) return;
        this.c.b();
    }

    final void a(String string) {
        d d2 = this.a.get(string);
        if (d2 == null) {
            throw new IllegalArgumentException("springId " + string + " does not reference a registered spring");
        }
        this.b.add(d2);
        if (this.e) {
            this.e = false;
            this.c.a();
        }
    }
}

