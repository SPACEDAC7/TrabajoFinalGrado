/*
 * Decompiled with CFR 0_115.
 */
package com.c.c;

import com.c.c.c;
import com.c.c.e;
import com.c.c.f;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

public final class d {
    private static int m = 0;
    e a;
    boolean b;
    public final String c;
    public final a d = new a(0);
    final a e = new a(0);
    final a f = new a(0);
    double g;
    double h;
    boolean i = true;
    CopyOnWriteArraySet<f> j = new CopyOnWriteArraySet();
    double k = 0.0;
    final c l;
    private double n = 0.005;
    private double o = 0.005;

    public d(c object) {
        this.l = object;
        object = new StringBuilder("spring:");
        int n2 = m;
        m = n2 + 1;
        this.c = object.append(n2).toString();
        this.a(e.c);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final d a(double d2) {
        if (this.h != d2 || !this.a()) {
            this.g = this.d.a;
            this.h = d2;
            this.l.a(this.c);
            Iterator<f> iterator = this.j.iterator();
            while (iterator.hasNext()) {
                iterator.next();
            }
        }
        return this;
    }

    public final d a(e e2) {
        if (e2 == null) {
            throw new IllegalArgumentException("springConfig is required");
        }
        this.a = e2;
        return this;
    }

    public final d a(f f2) {
        this.j.add(f2);
        return this;
    }

    public final boolean a() {
        if (Math.abs(this.d.b) <= this.n) {
            a a2 = this.d;
            if (Math.abs(this.h - a2.a) <= this.o || this.a.b == 0.0) {
                return true;
            }
        }
        return false;
    }

    public final d b() {
        this.j.clear();
        return this;
    }

    public static final class a {
        public double a;
        double b;

        private a() {
        }

        /* synthetic */ a(byte by2) {
            this();
        }
    }

}

