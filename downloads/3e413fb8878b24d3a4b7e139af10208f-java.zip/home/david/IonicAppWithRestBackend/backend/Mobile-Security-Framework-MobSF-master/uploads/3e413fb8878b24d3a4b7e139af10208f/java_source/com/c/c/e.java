/*
 * Decompiled with CFR 0_115.
 */
package com.c.c;

public final class e {
    public static e c = new e(230.2, 22.0);
    public double a;
    public double b;

    public e(double d2, double d3) {
        this.b = d2;
        this.a = d3;
    }
}

