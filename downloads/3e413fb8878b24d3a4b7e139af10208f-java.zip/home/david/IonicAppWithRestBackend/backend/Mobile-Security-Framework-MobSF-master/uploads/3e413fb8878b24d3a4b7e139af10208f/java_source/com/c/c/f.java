/*
 * Decompiled with CFR 0_115.
 */
package com.c.c;

import com.c.c.d;

public class f {
    public void a() {
    }

    public void a(d d2) {
    }
}

