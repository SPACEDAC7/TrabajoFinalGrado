/*
 * Decompiled with CFR 0_115.
 */
package com.c.c;

import com.c.c.c;

public abstract class g {
    protected c e;

    public abstract void a();

    public final void a(c c2) {
        this.e = c2;
    }

    public abstract void b();
}

