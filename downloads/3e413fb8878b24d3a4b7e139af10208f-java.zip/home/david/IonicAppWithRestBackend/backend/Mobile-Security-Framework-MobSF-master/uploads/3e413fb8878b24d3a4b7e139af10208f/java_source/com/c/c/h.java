/*
 * Decompiled with CFR 0_115.
 */
package com.c.c;

import com.c.c.c;
import com.c.c.g;

public final class h
extends c {
    public h(g g2) {
        super(g2);
    }
}

