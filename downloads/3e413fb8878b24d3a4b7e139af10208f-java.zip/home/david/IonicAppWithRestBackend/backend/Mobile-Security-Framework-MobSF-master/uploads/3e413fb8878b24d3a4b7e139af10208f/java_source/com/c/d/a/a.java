/*
 * Decompiled with CFR 0_115.
 */
package com.c.d.a;

import java.io.IOException;

public final class a
extends IOException {
    public a() {
        super("CodedOutputStream was writing to a flat byte array and ran out of space.");
    }

    public a(IOException iOException) {
        super(iOException);
    }

    public a(Exception exception) {
        super("Unexpected " + exception.getClass().getSimpleName() + ": " + exception.getMessage(), exception);
    }
}

