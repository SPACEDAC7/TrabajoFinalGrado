/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.annotation.TargetApi
 *  android.media.MediaFormat
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.media.MediaFormat;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.Metadata;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class Format
implements Parcelable {
    public static final Parcelable.Creator<Format> CREATOR = new Parcelable.Creator<Format>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new Format(parcel);
        }
    };
    public final String a;
    public final int b;
    public final String c;
    public final Metadata d;
    public final String e;
    public final String f;
    public final int g;
    public final List<byte[]> h;
    public final DrmInitData i;
    public final int j;
    public final int k;
    public final float l;
    public final int m;
    public final float n;
    public final int o;
    public final byte[] p;
    public final int q;
    public final int r;
    public final int s;
    public final int t;
    public final int u;
    public final long v;
    public final int w;
    public final String x;
    public final int y;
    private int z;

    /*
     * Enabled aggressive block sorting
     */
    Format(Parcel parcel) {
        this.a = parcel.readString();
        this.e = parcel.readString();
        this.f = parcel.readString();
        this.c = parcel.readString();
        this.b = parcel.readInt();
        this.g = parcel.readInt();
        this.j = parcel.readInt();
        this.k = parcel.readInt();
        this.l = parcel.readFloat();
        this.m = parcel.readInt();
        this.n = parcel.readFloat();
        int n2 = parcel.readInt() != 0 ? 1 : 0;
        byte[] arrby = n2 != 0 ? parcel.createByteArray() : null;
        this.p = arrby;
        this.o = parcel.readInt();
        this.q = parcel.readInt();
        this.r = parcel.readInt();
        this.s = parcel.readInt();
        this.t = parcel.readInt();
        this.u = parcel.readInt();
        this.w = parcel.readInt();
        this.x = parcel.readString();
        this.y = parcel.readInt();
        this.v = parcel.readLong();
        int n3 = parcel.readInt();
        this.h = new ArrayList<byte[]>(n3);
        n2 = 0;
        do {
            if (n2 >= n3) {
                this.i = (DrmInitData)parcel.readParcelable(DrmInitData.class.getClassLoader());
                this.d = (Metadata)parcel.readParcelable(Metadata.class.getClassLoader());
                return;
            }
            this.h.add(parcel.createByteArray());
            ++n2;
        } while (true);
    }

    public Format(String list, String string, String string2, String string3, int n2, int n3, int n4, int n5, float f2, int n6, float f3, byte[] arrby, int n7, int n8, int n9, int n10, int n11, int n12, int n13, String string4, int n14, long l2, List<byte[]> list2, DrmInitData drmInitData, Metadata metadata) {
        this.a = list;
        this.e = string;
        this.f = string2;
        this.c = string3;
        this.b = n2;
        this.g = n3;
        this.j = n4;
        this.k = n5;
        this.l = f2;
        this.m = n6;
        this.n = f3;
        this.p = arrby;
        this.o = n7;
        this.q = n8;
        this.r = n9;
        this.s = n10;
        this.t = n11;
        this.u = n12;
        this.w = n13;
        this.x = string4;
        this.y = n14;
        this.v = l2;
        list = list2;
        if (list2 == null) {
            list = Collections.emptyList();
        }
        this.h = list;
        this.i = drmInitData;
        this.d = metadata;
    }

    public static Format a(String string, int n2, int n3, List<byte[]> list, float f2) {
        return Format.a(null, string, -1, n2, n3, list, -1, f2, null, -1, null);
    }

    public static Format a(String string, long l2) {
        return new Format(null, null, string, null, -1, -1, -1, -1, -1.0f, -1, -1.0f, null, -1, -1, -1, -1, -1, -1, 0, null, -1, l2, null, null, null);
    }

    public static Format a(String string, String string2, int n2, int n3, int n4, int n5, int n6, int n7, int n8, List<byte[]> list, DrmInitData drmInitData, int n9, String string3, Metadata metadata) {
        return new Format(string, null, string2, null, n2, n3, -1, -1, -1.0f, -1, -1.0f, null, -1, n4, n5, n6, n7, n8, n9, string3, -1, Long.MAX_VALUE, list, drmInitData, metadata);
    }

    public static Format a(String string, String string2, int n2, int n3, int n4, int n5, int n6, List<byte[]> list, DrmInitData drmInitData, int n7, String string3) {
        return Format.a(string, string2, n2, n3, n4, n5, n6, -1, -1, list, drmInitData, n7, string3, null);
    }

    public static Format a(String string, String string2, int n2, int n3, int n4, int n5, List<byte[]> list, DrmInitData drmInitData, String string3) {
        return Format.a(string, string2, n2, n3, n4, n5, -1, list, drmInitData, 0, string3);
    }

    public static Format a(String string, String string2, int n2, int n3, int n4, List<byte[]> list, int n5, float f2, byte[] arrby, int n6, DrmInitData drmInitData) {
        return new Format(string, null, string2, null, -1, n2, n3, n4, -1.0f, n5, f2, arrby, n6, -1, -1, -1, -1, -1, 0, null, -1, Long.MAX_VALUE, list, drmInitData, null);
    }

    public static Format a(String string, String string2, int n2, String string3, DrmInitData drmInitData) {
        return Format.a(string, string2, n2, string3, drmInitData, Long.MAX_VALUE);
    }

    private static Format a(String string, String string2, int n2, String string3, DrmInitData drmInitData, long l2) {
        return new Format(string, null, string2, null, -1, -1, -1, -1, -1.0f, -1, -1.0f, null, -1, -1, -1, -1, -1, -1, n2, string3, -1, l2, null, drmInitData, null);
    }

    public static Format a(String string, String string2, DrmInitData drmInitData) {
        return new Format(string, null, string2, null, -1, -1, -1, -1, -1.0f, -1, -1.0f, null, -1, -1, -1, -1, -1, -1, 0, null, -1, Long.MAX_VALUE, null, drmInitData, null);
    }

    public static Format a(String string, String string2, String string3, DrmInitData drmInitData) {
        return Format.a(string, string2, 0, string3, drmInitData, 0);
    }

    public static Format a(String string, String string2, List<byte[]> list, String string3, DrmInitData drmInitData) {
        return new Format(string, null, string2, null, -1, -1, -1, -1, -1.0f, -1, -1.0f, null, -1, -1, -1, -1, -1, -1, 0, string3, -1, Long.MAX_VALUE, list, drmInitData, null);
    }

    @TargetApi(value=16)
    private static void a(MediaFormat mediaFormat, String string, int n2) {
        if (n2 != -1) {
            mediaFormat.setInteger(string, n2);
        }
    }

    public final int a() {
        if (this.j == -1 || this.k == -1) {
            return -1;
        }
        return this.j * this.k;
    }

    public final Format a(long l2) {
        return new Format(this.a, this.e, this.f, this.c, this.b, this.g, this.j, this.k, this.l, this.m, this.n, this.p, this.o, this.q, this.r, this.s, this.t, this.u, this.w, this.x, this.y, l2, this.h, this.i, this.d);
    }

    @SuppressLint(value={"InlinedApi"})
    @TargetApi(value=16)
    public final MediaFormat b() {
        MediaFormat mediaFormat = new MediaFormat();
        mediaFormat.setString("mime", this.f);
        String string = this.x;
        if (string != null) {
            mediaFormat.setString("language", string);
        }
        Format.a(mediaFormat, "max-input-size", this.g);
        Format.a(mediaFormat, "width", this.j);
        Format.a(mediaFormat, "height", this.k);
        float f2 = this.l;
        if (f2 != -1.0f) {
            mediaFormat.setFloat("frame-rate", f2);
        }
        Format.a(mediaFormat, "rotation-degrees", this.m);
        Format.a(mediaFormat, "channel-count", this.q);
        Format.a(mediaFormat, "sample-rate", this.r);
        Format.a(mediaFormat, "encoder-delay", this.t);
        Format.a(mediaFormat, "encoder-padding", this.u);
        for (int i2 = 0; i2 < this.h.size(); ++i2) {
            mediaFormat.setByteBuffer("csd-" + i2, ByteBuffer.wrap(this.h.get(i2)));
        }
        return mediaFormat;
    }

    public final int describeContents() {
        return 0;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        boolean bl2 = false;
        if (this == object) {
            return true;
        }
        boolean bl3 = bl2;
        if (object == null) return bl3;
        bl3 = bl2;
        if (this.getClass() != object.getClass()) return bl3;
        object = (Format)object;
        bl3 = bl2;
        if (this.b != object.b) return bl3;
        bl3 = bl2;
        if (this.g != object.g) return bl3;
        bl3 = bl2;
        if (this.j != object.j) return bl3;
        bl3 = bl2;
        if (this.k != object.k) return bl3;
        bl3 = bl2;
        if (this.l != object.l) return bl3;
        bl3 = bl2;
        if (this.m != object.m) return bl3;
        bl3 = bl2;
        if (this.n != object.n) return bl3;
        bl3 = bl2;
        if (this.o != object.o) return bl3;
        bl3 = bl2;
        if (this.q != object.q) return bl3;
        bl3 = bl2;
        if (this.r != object.r) return bl3;
        bl3 = bl2;
        if (this.s != object.s) return bl3;
        bl3 = bl2;
        if (this.t != object.t) return bl3;
        bl3 = bl2;
        if (this.u != object.u) return bl3;
        bl3 = bl2;
        if (this.v != object.v) return bl3;
        bl3 = bl2;
        if (this.w != object.w) return bl3;
        bl3 = bl2;
        if (!o.a(this.a, object.a)) return bl3;
        bl3 = bl2;
        if (!o.a(this.x, object.x)) return bl3;
        bl3 = bl2;
        if (this.y != object.y) return bl3;
        bl3 = bl2;
        if (!o.a(this.e, object.e)) return bl3;
        bl3 = bl2;
        if (!o.a(this.f, object.f)) return bl3;
        bl3 = bl2;
        if (!o.a(this.c, object.c)) return bl3;
        bl3 = bl2;
        if (!o.a(this.i, object.i)) return bl3;
        bl3 = bl2;
        if (!o.a(this.d, object.d)) return bl3;
        bl3 = bl2;
        if (!Arrays.equals(this.p, object.p)) return bl3;
        bl3 = bl2;
        if (this.h.size() != object.h.size()) return bl3;
        int n2 = 0;
        while (n2 < this.h.size()) {
            bl3 = bl2;
            if (!Arrays.equals(this.h.get(n2), object.h.get(n2))) return bl3;
            ++n2;
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int hashCode() {
        int n2 = 0;
        if (this.z != 0) return this.z;
        int n3 = this.a == null ? 0 : this.a.hashCode();
        int n4 = this.e == null ? 0 : this.e.hashCode();
        int n5 = this.f == null ? 0 : this.f.hashCode();
        int n6 = this.c == null ? 0 : this.c.hashCode();
        int n7 = this.b;
        int n8 = this.j;
        int n9 = this.k;
        int n10 = this.q;
        int n11 = this.r;
        int n12 = this.x == null ? 0 : this.x.hashCode();
        int n13 = this.y;
        int n14 = this.i == null ? 0 : this.i.hashCode();
        if (this.d != null) {
            n2 = this.d.hashCode();
        }
        this.z = (n14 + ((n12 + ((((((n6 + (n5 + (n4 + (n3 + 527) * 31) * 31) * 31) * 31 + n7) * 31 + n8) * 31 + n9) * 31 + n10) * 31 + n11) * 31) * 31 + n13) * 31) * 31 + n2;
        return this.z;
    }

    public final String toString() {
        return "Format(" + this.a + ", " + this.e + ", " + this.f + ", " + this.b + ", " + this.x + ", [" + this.j + ", " + this.k + ", " + this.l + "], [" + this.q + ", " + this.r + "])";
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.a);
        parcel.writeString(this.e);
        parcel.writeString(this.f);
        parcel.writeString(this.c);
        parcel.writeInt(this.b);
        parcel.writeInt(this.g);
        parcel.writeInt(this.j);
        parcel.writeInt(this.k);
        parcel.writeFloat(this.l);
        parcel.writeInt(this.m);
        parcel.writeFloat(this.n);
        n2 = this.p != null ? 1 : 0;
        parcel.writeInt(n2);
        if (this.p != null) {
            parcel.writeByteArray(this.p);
        }
        parcel.writeInt(this.o);
        parcel.writeInt(this.q);
        parcel.writeInt(this.r);
        parcel.writeInt(this.s);
        parcel.writeInt(this.t);
        parcel.writeInt(this.u);
        parcel.writeInt(this.w);
        parcel.writeString(this.x);
        parcel.writeInt(this.y);
        parcel.writeLong(this.v);
        int n3 = this.h.size();
        parcel.writeInt(n3);
        n2 = 0;
        do {
            if (n2 >= n3) {
                parcel.writeParcelable((Parcelable)this.i, 0);
                parcel.writeParcelable((Parcelable)this.d, 0);
                return;
            }
            parcel.writeByteArray(this.h.get(n2));
            ++n2;
        } while (true);
    }

}

