/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

import com.google.android.exoplayer2.i.o;
import java.util.UUID;

public final class a {
    public static final int a;
    public static final UUID b;
    public static final UUID c;
    public static final UUID d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        int n2 = o.a < 23 ? 1020 : 6396;
        a = n2;
        b = new UUID(0, 0);
        c = new UUID(-1301668207276963122L, -6645017420763422227L);
        d = new UUID(-7348484286925749626L, -6083546864340672619L);
    }

    public static long a(long l2) {
        if (l2 == -9223372036854775807L) {
            return -9223372036854775807L;
        }
        return l2 / 1000;
    }

    public static long b(long l2) {
        if (l2 == -9223372036854775807L) {
            return -9223372036854775807L;
        }
        return 1000 * l2;
    }
}

