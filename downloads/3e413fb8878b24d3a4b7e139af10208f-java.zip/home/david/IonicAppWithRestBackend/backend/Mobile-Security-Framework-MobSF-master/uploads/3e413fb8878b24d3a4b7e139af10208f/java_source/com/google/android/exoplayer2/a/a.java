/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.a;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.i.h;
import com.google.android.exoplayer2.i.i;
import java.nio.ByteBuffer;

public final class a {
    private static final int[] a = new int[]{1, 2, 3, 6};
    private static final int[] b = new int[]{48000, 44100, 32000};
    private static final int[] c = new int[]{24000, 22050, 16000};
    private static final int[] d = new int[]{2, 1, 2, 3, 3, 4, 4, 5};
    private static final int[] e = new int[]{32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 448, 512, 576, 640};
    private static final int[] f = new int[]{69, 87, 104, 121, 139, 174, 208, 243, 278, 348, 417, 487, 557, 696, 835, 975, 1114, 1253, 1393};

    public static int a() {
        return 1536;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int a(ByteBuffer byteBuffer) {
        int n2;
        if ((byteBuffer.get(byteBuffer.position() + 4) & 192) >> 6 == 3) {
            n2 = 6;
            do {
                return n2 * 256;
                break;
            } while (true);
        }
        n2 = a[(byteBuffer.get(byteBuffer.position() + 4) & 48) >> 4];
        return n2 * 256;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static int a(byte[] arrby) {
        if (arrby.length < 5) {
            return -1;
        }
        int n2 = (arrby[4] & 192) >> 6;
        int n3 = arrby[4] & 63;
        int n4 = n3 / 2;
        if (n2 < 0) return -1;
        if (n2 >= b.length) return -1;
        if (n3 < 0) return -1;
        if (n4 >= f.length) return -1;
        if ((n2 = b[n2]) == 44100) {
            return (f[n4] + n3 % 2) * 2;
        }
        n3 = e[n4];
        if (n2 != 32000) return n3 * 4;
        return n3 * 6;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Format a(h h2, String string) {
        int n2 = 1;
        h2.b(32);
        int n3 = h2.c(2);
        h2.b(14);
        int n4 = h2.c(3);
        if ((n4 & 1) != 0 && n4 != 1) {
            h2.b(2);
        }
        if ((n4 & 4) != 0) {
            h2.b(2);
        }
        if (n4 == 2) {
            h2.b(2);
        }
        boolean bl2 = h2.a();
        n4 = d[n4];
        if (bl2) {
            do {
                return Format.a(null, "audio/ac3", -1, -1, n4 + n2, b[n3], null, null, string);
                break;
            } while (true);
        }
        n2 = 0;
        return Format.a(null, "audio/ac3", -1, -1, n4 + n2, b[n3], null, null, string);
    }

    public static Format a(i i2, String string, String string2, DrmInitData drmInitData) {
        int n2;
        int n3 = i2.e();
        int n4 = b[(n3 & 192) >> 6];
        int n5 = i2.e();
        n3 = n2 = d[(n5 & 56) >> 3];
        if ((n5 & 4) != 0) {
            n3 = n2 + 1;
        }
        return Format.a(string, "audio/ac3", -1, -1, n3, n4, null, drmInitData, string2);
    }

    public static int b(byte[] arrby) {
        return (((arrby[2] & 7) << 8) + (arrby[3] & 255) + 1) * 2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Format b(h h2, String string) {
        h2.b(32);
        int n2 = h2.c(2);
        if (n2 == 3) {
            n2 = c[h2.c(2)];
        } else {
            h2.b(2);
            n2 = b[n2];
        }
        int n3 = h2.c(3);
        boolean bl2 = h2.a();
        int n4 = d[n3];
        if (bl2) {
            n3 = 1;
            return Format.a(null, "audio/eac3", -1, -1, n4 + n3, n2, null, null, string);
        }
        n3 = 0;
        return Format.a(null, "audio/eac3", -1, -1, n4 + n3, n2, null, null, string);
    }

    public static Format b(i i2, String string, String string2, DrmInitData drmInitData) {
        int n2;
        i2.d(2);
        int n3 = i2.e();
        int n4 = b[(n3 & 192) >> 6];
        int n5 = i2.e();
        n3 = n2 = d[(n5 & 14) >> 1];
        if ((n5 & 1) != 0) {
            n3 = n2 + 1;
        }
        return Format.a(string, "audio/eac3", -1, -1, n3, n4, null, drmInitData, string2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int c(byte[] arrby) {
        int n2;
        if ((arrby[4] & 192) >> 6 == 3) {
            n2 = 6;
            do {
                return n2 * 256;
                break;
            } while (true);
        }
        n2 = a[(arrby[4] & 48) >> 4];
        return n2 * 256;
    }
}

