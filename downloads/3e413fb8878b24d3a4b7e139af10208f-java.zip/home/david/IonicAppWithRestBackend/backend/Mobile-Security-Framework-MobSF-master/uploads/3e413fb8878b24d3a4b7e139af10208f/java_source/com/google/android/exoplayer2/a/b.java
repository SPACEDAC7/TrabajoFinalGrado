/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 */
package com.google.android.exoplayer2.a;

import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import java.util.Arrays;

@TargetApi(value=21)
public final class b {
    public static final b a = new b(new int[]{2}, 2);
    final int[] b;
    private final int c;

    /*
     * Enabled aggressive block sorting
     */
    private b(int[] arrn, int n2) {
        if (arrn != null) {
            this.b = Arrays.copyOf(arrn, arrn.length);
            Arrays.sort(this.b);
        } else {
            this.b = new int[0];
        }
        this.c = n2;
    }

    public static b a(Context context) {
        if ((context = context.registerReceiver(null, new IntentFilter("android.media.action.HDMI_AUDIO_PLUG"))) == null || context.getIntExtra("android.media.extra.AUDIO_PLUG_STATE", 0) == 0) {
            return a;
        }
        return new b(context.getIntArrayExtra("android.media.extra.ENCODINGS"), context.getIntExtra("android.media.extra.MAX_CHANNEL_COUNT", 0));
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        object = (b)object;
        if (!Arrays.equals(this.b, object.b)) return false;
        if (this.c == object.c) return true;
        return false;
    }

    public final int hashCode() {
        return this.c + Arrays.hashCode(this.b) * 31;
    }

    public final String toString() {
        return "AudioCapabilities[maxChannelCount=" + this.c + ", supportedEncodings=" + Arrays.toString(this.b) + "]";
    }
}

