/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.google.android.exoplayer2.a;

import android.os.Handler;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.b.d;

public interface c {
    public void a(int var1);

    public void b(Format var1);

    public void c(d var1);

    public void d(d var1);

    public static final class a {
        final Handler a;
        final c b;

        /*
         * Enabled aggressive block sorting
         */
        public a(Handler handler, c c2) {
            handler = c2 != null ? a.a.a.a.d.b(handler) : null;
            this.a = handler;
            this.b = c2;
        }

        public final void a(final d d2) {
            if (this.b != null) {
                this.a.post(new Runnable(){

                    @Override
                    public final void run() {
                        d2.a();
                        a.this.b.d(d2);
                    }
                });
            }
        }

    }

}

