/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.AudioAttributes
 *  android.media.AudioAttributes$Builder
 *  android.media.AudioFormat
 *  android.media.AudioFormat$Builder
 *  android.media.AudioTimestamp
 *  android.media.AudioTrack
 *  android.media.PlaybackParams
 *  android.os.ConditionVariable
 *  android.os.SystemClock
 *  android.util.Log
 */
package com.google.android.exoplayer2.a;

import android.annotation.TargetApi;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTimestamp;
import android.media.AudioTrack;
import android.media.PlaybackParams;
import android.os.ConditionVariable;
import android.os.SystemClock;
import android.support.v4.app.Fragment;
import android.util.Log;
import com.google.android.exoplayer2.i.o;
import java.lang.reflect.Method;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class d {
    public static boolean a = false;
    public static boolean b = false;
    private int A;
    private long B;
    private long C;
    private boolean D;
    private long E;
    private Method F;
    private long G;
    private long H;
    private int I;
    private long J;
    private long K;
    private long L;
    private byte[] M;
    private int N;
    private ByteBuffer O;
    private ByteBuffer P;
    private boolean Q;
    private boolean R;
    private long S;
    final com.google.android.exoplayer2.a.b c;
    final a d;
    int e;
    int f;
    int g;
    int h;
    int i;
    boolean j;
    int k;
    int l;
    long m;
    int n;
    int o;
    float p;
    boolean q;
    int r;
    boolean s;
    private final e t;
    private final ConditionVariable u;
    private final long[] v;
    private AudioTrack w;
    private AudioTrack x;
    private ByteBuffer y;
    private int z;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public d(com.google.android.exoplayer2.a.b b2, e e2) {
        this.c = b2;
        this.t = e2;
        this.u = new ConditionVariable(true);
        if (o.a >= 18) {
            try {
                this.F = AudioTrack.class.getMethod("getLatency", null);
            }
            catch (NoSuchMethodException var1_2) {}
        }
        this.d = o.a >= 23 ? new c() : (o.a >= 19 ? new b() : new a(0));
        this.v = new long[10];
        this.p = 1.0f;
        this.o = 0;
        this.g = 3;
        this.r = 0;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static int a(String var0) {
        var1_1 = -1;
        switch (var0.hashCode()) {
            case 187078296: {
                if (var0.equals("audio/ac3")) {
                    var1_1 = 0;
                    ** break;
                }
                ** GOTO lbl16
            }
            case 1504578661: {
                if (var0.equals("audio/eac3")) {
                    var1_1 = 1;
                    ** break;
                }
                ** GOTO lbl16
            }
            case -1095064472: {
                if (var0.equals("audio/vnd.dts")) {
                    var1_1 = 2;
                }
            }
lbl16: // 8 sources:
            default: {
                ** GOTO lbl21
            }
            case 1505942594: 
        }
        if (var0.equals("audio/vnd.dts.hd")) {
            var1_1 = 3;
        }
lbl21: // 4 sources:
        switch (var1_1) {
            default: {
                return 0;
            }
            case 0: {
                return 5;
            }
            case 1: {
                return 6;
            }
            case 2: {
                return 7;
            }
            case 3: 
        }
        return 8;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static ByteBuffer a(ByteBuffer byteBuffer, int n2, ByteBuffer byteBuffer2) {
        ByteBuffer byteBuffer3;
        int n3;
        int n4;
        int n5;
        block15 : {
            n5 = byteBuffer.position();
            n3 = byteBuffer.limit();
            n4 = n3 - n5;
            switch (n2) {
                default: {
                    throw new IllegalStateException();
                }
                case 3: {
                    n4 <<= 1;
                    break;
                }
                case Integer.MIN_VALUE: {
                    n4 = n4 / 3 << 1;
                    break;
                }
                case 1073741824: {
                    n4 /= 2;
                }
            }
            if (byteBuffer2 != null) {
                byteBuffer3 = byteBuffer2;
                if (byteBuffer2.capacity() >= n4) break block15;
            }
            byteBuffer3 = ByteBuffer.allocateDirect(n4);
        }
        byteBuffer3.position(0);
        byteBuffer3.limit(n4);
        switch (n2) {
            default: {
                throw new IllegalStateException();
            }
            case 3: {
                for (n4 = n5; n4 < n3; ++n4) {
                    byteBuffer3.put(0);
                    byteBuffer3.put((byte)((byteBuffer.get(n4) & 255) - 128));
                }
                break;
            }
            case Integer.MIN_VALUE: {
                for (int i2 = n5; i2 < n3; i2 += 3) {
                    byteBuffer3.put(byteBuffer.get(i2 + 1));
                    byteBuffer3.put(byteBuffer.get(i2 + 2));
                }
                break;
            }
            case 1073741824: {
                while (n5 < n3) {
                    byteBuffer3.put(byteBuffer.get(n5 + 2));
                    byteBuffer3.put(byteBuffer.get(n5 + 3));
                    n5 += 4;
                }
                break block5;
            }
        }
        byteBuffer3.position(0);
        return byteBuffer3;
    }

    private boolean i() {
        if (o.a < 23 && (this.i == 5 || this.i == 6)) {
            return true;
        }
        return false;
    }

    final long a(long l2) {
        return 1000000 * l2 / (long)this.e;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final long a(boolean bl2) {
        long l2;
        long l3;
        if (!this.f()) return Long.MIN_VALUE;
        if (this.o == 0) return Long.MIN_VALUE;
        int n2 = 1;
        if (n2 == 0) {
            return Long.MIN_VALUE;
        }
        if (this.x.getPlayState() == 3 && (l3 = this.d.c()) != 0) {
            l2 = System.nanoTime() / 1000;
            if (l2 - this.C >= 30000) {
                this.v[this.z] = l3 - l2;
                this.z = (this.z + 1) % 10;
                if (this.A < 10) {
                    ++this.A;
                }
                this.C = l2;
                this.B = 0;
                for (n2 = 0; n2 < this.A; this.B += this.v[n2] / (long)this.A, ++n2) {
                }
            }
            if (!this.i() && l2 - this.E >= 500000) {
                this.D = this.d.d();
                if (this.D) {
                    long l4 = this.d.e() / 1000;
                    long l5 = this.d.f();
                    if (l4 < this.K) {
                        this.D = false;
                    } else if (Math.abs(l4 - l2) > 5000000) {
                        String string = "Spurious audio timestamp (system clock mismatch): " + l5 + ", " + l4 + ", " + l2 + ", " + l3;
                        if (b) {
                            throw new Fragment.a(string);
                        }
                        Log.w((String)"AudioTrack", (String)string);
                        this.D = false;
                    } else if (Math.abs(this.a(l5) - l3) > 5000000) {
                        String string = "Spurious audio timestamp (frame position mismatch): " + l5 + ", " + l4 + ", " + l2 + ", " + l3;
                        if (b) {
                            throw new Fragment.a(string);
                        }
                        Log.w((String)"AudioTrack", (String)string);
                        this.D = false;
                    }
                }
                if (this.F != null && !this.j) {
                    try {
                        this.L = (long)((Integer)this.F.invoke((Object)this.x, null)).intValue() * 1000 - this.m;
                        this.L = Math.max(this.L, 0);
                        if (this.L > 5000000) {
                            Log.w((String)"AudioTrack", (String)("Ignoring impossibly large audio latency: " + this.L));
                            this.L = 0;
                        }
                    }
                    catch (Exception var2_9) {
                        this.F = null;
                    }
                }
                this.E = l2;
            }
        }
        l3 = System.nanoTime() / 1000;
        if (this.D) {
            return this.a(this.b((long)((float)(l3 - this.d.e() / 1000) * this.d.g())) + this.d.f()) + this.J;
        }
        l3 = this.A == 0 ? this.d.c() + this.J : l3 + this.B + this.J;
        l2 = l3;
        if (bl2) return l2;
        return l3 - this.L;
    }

    public final void a() {
        this.q = true;
        if (this.f()) {
            this.K = System.nanoTime() / 1000;
            this.x.play();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final boolean a(ByteBuffer var1_1, long var2_4) {
        if (!this.f()) {
            this.u.block();
            if (this.s) {
                var5_5 = this.e;
                var6_6 = this.f;
                var7_7 = this.i;
                var8_8 = this.l;
                var9_9 = this.r;
                this.x = new AudioTrack(new AudioAttributes.Builder().setUsage(1).setContentType(3).setFlags(16).build(), new AudioFormat.Builder().setChannelMask(var6_6).setEncoding(var7_7).setSampleRate(var5_5).build(), var8_8, 1, var9_9);
            } else {
                this.x = this.r == 0 ? new AudioTrack(this.g, this.e, this.f, this.i, this.l, 1) : new AudioTrack(this.g, this.e, this.f, this.i, this.l, 1, this.r);
            }
            if ((var5_5 = this.x.getState()) != 1) {
                try {
                    this.x.release();
                }
                catch (Exception var1_2) {}
                throw new d(var5_5, this.e, this.f, this.l);
                throw new d(var5_5, this.e, this.f, this.l);
                finally {
                    this.x = null;
                    throw new d(var5_5, this.e, this.f, this.l);
                }
            }
            var5_5 = this.x.getAudioSessionId();
            if (d.a && o.a < 21) {
                if (this.w != null && var5_5 != this.w.getAudioSessionId()) {
                    this.e();
                }
                if (this.w == null) {
                    this.w = new AudioTrack(this.g, 4000, 4, 2, 2, 0, var5_5);
                }
            }
            if (this.r != var5_5) {
                this.r = var5_5;
                this.t.a(var5_5);
            }
            this.d.a(this.x, this.i());
            this.c();
            this.R = false;
            if (this.q) {
                this.a();
            }
        }
        var14_10 = this.R;
        this.R = this.b();
        if (var14_10 && !this.R && this.x.getPlayState() != 1) {
            var10_11 = SystemClock.elapsedRealtime();
            var12_12 = this.S;
            this.t.a(this.l, com.google.android.exoplayer2.a.a(this.m), var10_11 - var12_12);
        }
        var5_5 = this.O == null ? 1 : 0;
        var14_10 = var5_5 != 0 || this.O == var1_1;
        a.a.a.a.d.b(var14_10);
        this.O = var1_1;
        if (this.i() && (this.x.getPlayState() == 2 || this.x.getPlayState() == 1 && this.d.b() != 0)) ** GOTO lbl-1000
        var4_13 = var1_1;
        if (var5_5 == 0) ** GOTO lbl91
        if (this.O.hasRemaining()) ** GOTO lbl52
        this.O = null;
        var14_10 = true;
        ** GOTO lbl136
lbl52: // 1 sources:
        var14_10 = this.i != this.h;
        this.Q = var14_10;
        if (this.Q) {
            var14_10 = this.i == 2;
            a.a.a.a.d.b(var14_10);
            var1_1 = this.P = d.a(this.O, this.h, this.P);
        }
        if (this.j && this.I == 0) {
            var5_5 = this.i;
            if (var5_5 == 7 || var5_5 == 8) {
                var5_5 = com.google.android.exoplayer2.a.e.a(var1_1);
            } else if (var5_5 == 5) {
                var5_5 = com.google.android.exoplayer2.a.a.a();
            } else {
                if (var5_5 != 6) throw new IllegalStateException("Unexpected audio encoding: " + var5_5);
                var5_5 = com.google.android.exoplayer2.a.a.a(var1_1);
            }
            this.I = var5_5;
        }
        if (this.o == 0) {
            this.J = Math.max(0, var2_4);
            this.o = 1;
        } else {
            var10_11 = this.J + this.a(this.g());
            if (this.o == 1 && Math.abs(var10_11 - var2_4) > 200000) {
                Log.e((String)"AudioTrack", (String)("Discontinuity detected [expected " + var10_11 + ", got " + var2_4 + "]"));
                this.o = 2;
            }
            if (this.o == 2) {
                this.J = var2_4 - var10_11 + this.J;
                this.o = 1;
                this.t.a();
            }
        }
        var4_13 = var1_1;
        if (o.a < 21) {
            var5_5 = var1_1.remaining();
            if (this.M == null || this.M.length < var5_5) {
                this.M = new byte[var5_5];
            }
            var6_6 = var1_1.position();
            var1_1.get(this.M, 0, var5_5);
            var1_1.position(var6_6);
            this.N = 0;
            var4_13 = var1_1;
        }
lbl91: // 4 sources:
        if (this.Q) {
            var4_13 = this.P;
        }
        var6_6 = var4_13.remaining();
        var5_5 = 0;
        if (o.a >= 21) ** GOTO lbl103
        var7_7 = (int)(this.G - this.d.b() * (long)this.k);
        if ((var7_7 = this.l - var7_7) > 0) {
            var5_5 = Math.min(var6_6, var7_7);
            if ((var5_5 = this.x.write(this.M, this.N, var5_5)) >= 0) {
                this.N += var5_5;
            }
            var4_13.position(var4_13.position() + var5_5);
        }
        ** GOTO lbl125
lbl103: // 1 sources:
        if (!this.s) ** GOTO lbl124
        var1_1 = this.x;
        if (this.y == null) {
            this.y = ByteBuffer.allocate(16);
            this.y.order(ByteOrder.BIG_ENDIAN);
            this.y.putInt(1431633921);
        }
        if (this.n == 0) {
            this.y.putInt(4, var6_6);
            this.y.putLong(8, 1000 * var2_4);
            this.y.position(0);
            this.n = var6_6;
        }
        if ((var7_7 = this.y.remaining()) <= 0) ** GOTO lbl-1000
        var5_5 = var1_1.write(this.y, var7_7, 1);
        if (var5_5 < 0) {
            this.n = 0;
        } else if (var5_5 < var7_7) {
            var5_5 = 0;
        } else lbl-1000: // 2 sources:
        {
            this.n = (var5_5 = var1_1.write(var4_13, var6_6, 1)) < 0 ? 0 : (this.n -= var5_5);
        }
        ** GOTO lbl125
lbl124: // 1 sources:
        var5_5 = this.x.write(var4_13, var6_6, 1);
lbl125: // 5 sources:
        if (var5_5 < 0) {
            throw new f(var5_5);
        }
        if (!this.j) {
            this.G += (long)var5_5;
        }
        if (var5_5 == var6_6) {
            if (this.j) {
                this.H += (long)this.I;
            }
            this.O = null;
            var14_10 = true;
        } else lbl-1000: // 2 sources:
        {
            var14_10 = false;
        }
lbl136: // 3 sources:
        this.S = SystemClock.elapsedRealtime();
        return var14_10;
    }

    final long b(long l2) {
        return (long)this.e * l2 / 1000000;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean b() {
        if (!this.f()) return false;
        if (this.g() > this.d.b()) return true;
        if (!this.i() || this.x.getPlayState() != 2 || this.x.getPlaybackHeadPosition() != 0) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    final void c() {
        if (!this.f()) return;
        if (o.a >= 21) {
            this.x.setVolume(this.p);
            return;
        }
        AudioTrack audioTrack = this.x;
        float f2 = this.p;
        audioTrack.setStereoVolume(f2, f2);
    }

    public final void d() {
        if (this.f()) {
            this.G = 0;
            this.H = 0;
            this.I = 0;
            this.O = null;
            this.y = null;
            this.n = 0;
            this.o = 0;
            this.L = 0;
            this.h();
            if (this.x.getPlayState() == 3) {
                this.x.pause();
            }
            final AudioTrack audioTrack = this.x;
            this.x = null;
            this.d.a(null, false);
            this.u.close();
            new Thread(){

                @Override
                public final void run() {
                    try {
                        audioTrack.flush();
                        audioTrack.release();
                        return;
                    }
                    finally {
                        d.this.u.open();
                    }
                }
            }.start();
        }
    }

    final void e() {
        if (this.w == null) {
            return;
        }
        final AudioTrack audioTrack = this.w;
        this.w = null;
        new Thread(){

            @Override
            public final void run() {
                audioTrack.release();
            }
        }.start();
    }

    final boolean f() {
        if (this.x != null) {
            return true;
        }
        return false;
    }

    final long g() {
        if (this.j) {
            return this.H;
        }
        return this.G / (long)this.k;
    }

    final void h() {
        this.B = 0;
        this.A = 0;
        this.z = 0;
        this.C = 0;
        this.D = false;
        this.E = 0;
    }

    static class a {
        protected AudioTrack a;
        private boolean b;
        private int c;
        private long d;
        private long e;
        private long f;
        private long g;
        private long h;
        private long i;

        private a() {
        }

        /* synthetic */ a(byte by2) {
            this();
        }

        public final void a() {
            if (this.g != -9223372036854775807L) {
                return;
            }
            this.a.pause();
        }

        public final void a(long l2) {
            this.h = this.b();
            this.g = SystemClock.elapsedRealtime() * 1000;
            this.i = l2;
            this.a.stop();
        }

        public void a(AudioTrack audioTrack, boolean bl2) {
            this.a = audioTrack;
            this.b = bl2;
            this.g = -9223372036854775807L;
            this.d = 0;
            this.e = 0;
            this.f = 0;
            if (audioTrack != null) {
                this.c = audioTrack.getSampleRate();
            }
        }

        public void a(PlaybackParams playbackParams) {
            throw new UnsupportedOperationException();
        }

        public final long b() {
            long l2;
            if (this.g != -9223372036854775807L) {
                long l3 = (SystemClock.elapsedRealtime() * 1000 - this.g) * (long)this.c / 1000000;
                return Math.min(this.i, l3 + this.h);
            }
            int n2 = this.a.getPlayState();
            if (n2 == 1) {
                return 0;
            }
            long l4 = l2 = 0xFFFFFFFFL & (long)this.a.getPlaybackHeadPosition();
            if (this.b) {
                if (n2 == 2 && l2 == 0) {
                    this.f = this.d;
                }
                l4 = l2 + this.f;
            }
            if (this.d > l4) {
                ++this.e;
            }
            this.d = l4;
            return l4 + (this.e << 32);
        }

        public final long c() {
            return this.b() * 1000000 / (long)this.c;
        }

        public boolean d() {
            return false;
        }

        public long e() {
            throw new UnsupportedOperationException();
        }

        public long f() {
            throw new UnsupportedOperationException();
        }

        public float g() {
            return 1.0f;
        }
    }

    @TargetApi(value=19)
    static class b
    extends a {
        private final AudioTimestamp b = new AudioTimestamp();
        private long c;
        private long d;
        private long e;

        public b() {
            super(0);
        }

        @Override
        public void a(AudioTrack audioTrack, boolean bl2) {
            super.a(audioTrack, bl2);
            this.c = 0;
            this.d = 0;
            this.e = 0;
        }

        @Override
        public final boolean d() {
            boolean bl2 = this.a.getTimestamp(this.b);
            if (bl2) {
                long l2 = this.b.framePosition;
                if (this.d > l2) {
                    ++this.c;
                }
                this.d = l2;
                this.e = l2 + (this.c << 32);
            }
            return bl2;
        }

        @Override
        public final long e() {
            return this.b.nanoTime;
        }

        @Override
        public final long f() {
            return this.e;
        }
    }

    @TargetApi(value=23)
    static final class c
    extends b {
        private PlaybackParams b;
        private float c = 1.0f;

        private void h() {
            if (this.a != null && this.b != null) {
                this.a.setPlaybackParams(this.b);
            }
        }

        @Override
        public final void a(AudioTrack audioTrack, boolean bl2) {
            super.a(audioTrack, bl2);
            this.h();
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final void a(PlaybackParams playbackParams) {
            if (playbackParams == null) {
                playbackParams = new PlaybackParams();
            }
            this.b = playbackParams = playbackParams.allowDefaults();
            this.c = playbackParams.getSpeed();
            this.h();
        }

        @Override
        public final float g() {
            return this.c;
        }
    }

    public static final class d
    extends Exception {
        public final int a;

        public d(int n2, int n3, int n4, int n5) {
            super("AudioTrack init failed: " + n2 + ", Config(" + n3 + ", " + n4 + ", " + n5 + ")");
            this.a = n2;
        }
    }

    public static interface e {
        public void a();

        public void a(int var1);

        public void a(int var1, long var2, long var4);
    }

    public static final class f
    extends Exception {
        public final int a;

        public f(int n2) {
            super("AudioTrack write failed: " + n2);
            this.a = n2;
        }
    }

}

