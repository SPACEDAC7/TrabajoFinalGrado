/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.a;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.i.h;
import java.nio.ByteBuffer;

public final class e {
    private static final int[] a = new int[]{1, 2, 2, 2, 2, 3, 3, 4, 4, 5, 6, 6, 6, 7, 8, 8};
    private static final int[] b = new int[]{-1, 8000, 16000, 32000, -1, -1, 11025, 22050, 44100, -1, -1, 12000, 24000, 48000, -1, -1};
    private static final int[] c = new int[]{64, 112, 128, 192, 224, 256, 384, 448, 512, 640, 768, 896, 1024, 1152, 1280, 1536, 1920, 2048, 2304, 2560, 2688, 2816, 2823, 2944, 3072, 3840, 4096, 6144, 7680};

    public static int a(ByteBuffer byteBuffer) {
        int n2 = byteBuffer.position();
        byte by2 = byteBuffer.get(n2 + 4);
        return ((byteBuffer.get(n2 + 5) & 252) >> 2 | (by2 & 1) << 6) + 1 << 5;
    }

    public static int a(byte[] arrby) {
        return ((arrby[4] & 1) << 6 | (arrby[5] & 252) >> 2) + 1 << 5;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Format a(byte[] object, String string) {
        int n2;
        object = new h((byte[])object);
        object.b(60);
        int n3 = object.c(6);
        int n4 = a[n3];
        n3 = object.c(4);
        int n5 = b[n3];
        n3 = object.c(5);
        n3 = n3 >= c.length ? -1 : c[n3] * 1000 / 2;
        object.b(10);
        if (object.c(2) > 0) {
            n2 = 1;
            return Format.a(null, "audio/vnd.dts", n3, -1, n4 + n2, n5, null, null, string);
        }
        n2 = 0;
        return Format.a(null, "audio/vnd.dts", n3, -1, n4 + n2, n5, null, null, string);
    }

    public static int b(byte[] arrby) {
        return ((arrby[5] & 2) << 12 | (arrby[6] & 255) << 4 | (arrby[7] & 240) >> 4) + 1;
    }
}

