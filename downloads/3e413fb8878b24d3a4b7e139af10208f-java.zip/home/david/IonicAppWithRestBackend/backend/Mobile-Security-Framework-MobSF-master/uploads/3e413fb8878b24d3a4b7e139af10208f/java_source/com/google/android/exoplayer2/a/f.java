/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.AudioTrack
 *  android.media.MediaCodec
 *  android.media.MediaCodecInfo
 *  android.media.MediaCodecInfo$AudioCapabilities
 *  android.media.MediaCodecInfo$CodecCapabilities
 *  android.media.MediaCrypto
 *  android.media.MediaFormat
 *  android.media.PlaybackParams
 *  android.os.Handler
 *  android.view.Surface
 */
package com.google.android.exoplayer2.a;

import android.annotation.TargetApi;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.media.PlaybackParams;
import android.os.Handler;
import android.view.Surface;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.a.c;
import com.google.android.exoplayer2.a.d;
import com.google.android.exoplayer2.b;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.k;
import com.google.android.exoplayer2.l;
import java.nio.ByteBuffer;
import java.util.Arrays;

@TargetApi(value=16)
public final class f
extends com.google.android.exoplayer2.d.b
implements com.google.android.exoplayer2.i.f {
    private final c.a k;
    private final d l;
    private boolean m;
    private MediaFormat n;
    private int o;
    private long p;
    private boolean q;

    public f(com.google.android.exoplayer2.d.c c2, Handler handler, c c3, com.google.android.exoplayer2.a.b b2) {
        super(1, c2, true);
        this.l = new d(b2, new a(0));
        this.k = new c.a(handler, c3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(String string) {
        Object object = this.l;
        if (object.c == null) return false;
        object = object.c;
        int n2 = d.a(string);
        if (Arrays.binarySearch(object.b, n2) < 0) return false;
        return true;
    }

    protected static void s() {
    }

    protected static void t() {
    }

    protected static void u() {
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final int a(com.google.android.exoplayer2.d.c var1_1, Format var2_2) {
        var7_3 = false;
        var3_4 = var2_2.f;
        if (!a.a.a.a.d.d(var3_4)) {
            return 0;
        }
        var5_5 = o.a >= 21 ? 16 : 0;
        if (this.a(var3_4) && var1_1.a() != null) {
            return var5_5 | 4 | 3;
        }
        if ((var1_1 = var1_1.a(var3_4, false)) == null) {
            return 1;
        }
        if (o.a < 21) ** GOTO lbl-1000
        if (var2_2.r == -1) ** GOTO lbl29
        var4_6 = var2_2.r;
        if (var1_1.e == null) {
            var1_1.a("sampleRate.caps");
            var4_6 = 0;
        } else {
            var3_4 = var1_1.e.getAudioCapabilities();
            if (var3_4 == null) {
                var1_1.a("sampleRate.aCaps");
                var4_6 = 0;
            } else if (!var3_4.isSampleRateSupported(var4_6)) {
                var1_1.a("sampleRate.support, " + var4_6);
                var4_6 = 0;
            } else {
                var4_6 = 1;
            }
        }
        var6_7 = var7_3;
        if (var4_6 == 0) ** GOTO lbl48
lbl29: // 2 sources:
        if (var2_2.q == -1) ** GOTO lbl-1000
        var4_6 = var2_2.q;
        if (var1_1.e == null) {
            var1_1.a("channelCount.caps");
            var4_6 = 0;
        } else {
            var2_2 = var1_1.e.getAudioCapabilities();
            if (var2_2 == null) {
                var1_1.a("channelCount.aCaps");
                var4_6 = 0;
            } else if (var2_2.getMaxInputChannelCount() < var4_6) {
                var1_1.a("channelCount.support, " + var4_6);
                var4_6 = 0;
            } else {
                var4_6 = 1;
            }
        }
        var6_7 = var7_3;
        if (var4_6 != 0) lbl-1000: // 3 sources:
        {
            var6_7 = true;
        }
lbl48: // 4 sources:
        if (var6_7) {
            var4_6 = 3;
            return var4_6 | (var5_5 | 4);
        }
        var4_6 = 2;
        return var4_6 | (var5_5 | 4);
    }

    @Override
    protected final com.google.android.exoplayer2.d.a a(com.google.android.exoplayer2.d.c c2, Format format, boolean bl2) {
        com.google.android.exoplayer2.d.a a2;
        if (this.a(format.f) && (a2 = c2.a()) != null) {
            this.m = true;
            return a2;
        }
        this.m = false;
        return super.a(c2, format, bl2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(int n2, Object object) {
        switch (n2) {
            default: {
                super.a(n2, object);
                return;
            }
            case 2: {
                d d2 = this.l;
                float f2 = ((Float)object).floatValue();
                if (d2.p == f2) return;
                d2.p = f2;
                d2.c();
                return;
            }
            case 3: {
                d d3 = this.l;
                object = (PlaybackParams)object;
                d3.d.a((PlaybackParams)object);
                return;
            }
            case 4: {
                n2 = (Integer)object;
                object = this.l;
                if (object.g == n2) return;
                object.g = n2;
                if (object.s) return;
                object.d();
                object.r = 0;
                return;
            }
        }
    }

    @Override
    protected final void a(long l2, boolean bl2) {
        super.a(l2, bl2);
        this.l.d();
        this.p = l2;
        this.q = true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final void a(MediaCodec var1_1, MediaFormat var2_2) {
        var5_3 = 12;
        var12_4 = true;
        var3_5 = this.n != null ? 1 : 0;
        var1_1 = var3_5 != 0 ? this.n.getString("mime") : "audio/raw";
        if (var3_5 != 0) {
            var2_2 = this.n;
        }
        var7_6 = var2_2.getInteger("channel-count");
        var8_7 = var2_2.getInteger("sample-rate");
        var2_2 = this.l;
        var6_8 = this.o;
        switch (var7_6) {
            default: {
                throw new IllegalArgumentException("Unsupported channel count: " + var7_6);
            }
            case 1: {
                var3_5 = 4;
                break;
            }
            case 2: {
                var3_5 = 12;
                break;
            }
            case 3: {
                var3_5 = 28;
                break;
            }
            case 4: {
                var3_5 = 204;
                break;
            }
            case 5: {
                var3_5 = 220;
                break;
            }
            case 6: {
                var3_5 = 252;
                break;
            }
            case 7: {
                var3_5 = 1276;
                break;
            }
            case 8: {
                var3_5 = com.google.android.exoplayer2.a.a;
                break;
            }
        }
        var4_9 = var3_5;
        if (o.a <= 23) {
            var4_9 = var3_5;
            if ("foster".equals(o.b)) {
                var4_9 = var3_5;
                if ("NVIDIA".equals(o.c)) {
                    var4_9 = var3_5;
                    switch (var7_6) {
                        default: {
                            var4_9 = var3_5;
                            break;
                        }
                        case 7: {
                            var4_9 = com.google.android.exoplayer2.a.a;
                            break;
                        }
                        case 3: 
                        case 5: {
                            var4_9 = 252;
                        }
                        case 4: 
                        case 6: 
                    }
                }
            }
        }
        var11_10 = "audio/raw".equals(var1_1) == false;
        if (o.a > 25) ** GOTO lbl-1000
        if ("fugu".equals(o.b) && var11_10 && var7_6 == 1) {
            var4_9 = var5_3;
        }
        if (var11_10) lbl-1000: // 2 sources:
        {
            var3_5 = d.a((String)var1_1);
        } else {
            if (var6_8 != 3 && var6_8 != 2 && var6_8 != Integer.MIN_VALUE) {
                if (var6_8 != 1073741824) throw new IllegalArgumentException("Unsupported PCM encoding: " + var6_8);
            }
            var3_5 = var6_8;
        }
        if (var2_2.f() && var2_2.h == var3_5 && var2_2.e == var8_7) {
            if (var2_2.f == var4_9) return;
        }
        var2_2.d();
        var2_2.h = var3_5;
        var2_2.j = var11_10;
        var2_2.e = var8_7;
        var2_2.f = var4_9;
        if (!var11_10) {
            var3_5 = 2;
        }
        var2_2.i = var3_5;
        var2_2.k = var7_6 * 2;
        if (var11_10) {
            var3_5 = var2_2.i == 5 || var2_2.i == 6 ? 20480 : 49152;
        } else {
            var5_3 = AudioTrack.getMinBufferSize((int)var8_7, (int)var4_9, (int)var2_2.i);
            if (var5_3 == -2) {
                var12_4 = false;
            }
            a.a.a.a.d.b(var12_4);
            var3_5 = var5_3 << 2;
            var4_9 = (int)var2_2.b(250000) * var2_2.k;
            var5_3 = (int)Math.max((long)var5_3, var2_2.b(750000) * (long)var2_2.k);
            if (var3_5 < var4_9) {
                var3_5 = var4_9;
            } else if (var3_5 > var5_3) {
                var3_5 = var5_3;
            }
        }
        var2_2.l = var3_5;
        var9_11 = var11_10 != false ? -9223372036854775807L : var2_2.a((long)var2_2.l / (long)var2_2.k);
        var2_2.m = var9_11;
    }

    @Override
    protected final void a(com.google.android.exoplayer2.d.a a2, MediaCodec mediaCodec, Format format, MediaCrypto mediaCrypto) {
        if (this.m) {
            this.n = format.b();
            this.n.setString("mime", "audio/raw");
            mediaCodec.configure(this.n, null, mediaCrypto, 0);
            this.n.setString("mime", format.f);
            return;
        }
        mediaCodec.configure(format.b(), null, mediaCrypto, 0);
        this.n = null;
    }

    @Override
    protected final void a(String string, long l2, long l3) {
        c.a a2 = this.k;
        if (a2.b != null) {
            a2.a.post(new Runnable(string, l2, l3){
                final /* synthetic */ String a;
                final /* synthetic */ long b;
                final /* synthetic */ long c;

                @Override
                public final void run() {
                }
            });
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(boolean bl2) {
        int n2;
        boolean bl3 = false;
        super.a(bl2);
        Object object = this.k;
        com.google.android.exoplayer2.b.d d2 = this.j;
        if (object.b != null) {
            object.a.post(new Runnable(d2){
                final /* synthetic */ com.google.android.exoplayer2.b.d a;

                @Override
                public final void run() {
                    a.this.b.c(this.a);
                }
            });
        }
        if ((n2 = this.b.b) != 0) {
            object = this.l;
            bl2 = bl3;
            if (o.a >= 21) {
                bl2 = true;
            }
            a.a.a.a.d.b(bl2);
            if (object.s && object.r == n2) return;
            {
                object.s = true;
                object.r = n2;
                object.d();
                return;
            }
        } else {
            object = this.l;
            if (!object.s) return;
            {
                object.s = false;
                object.r = 0;
                object.d();
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected final boolean a(long l2, long l3, MediaCodec object, ByteBuffer byteBuffer, int n2, int n3, long l4, boolean bl2) {
        void var5_5;
        if (this.m && (n3 & 2) != 0) {
            object.releaseOutputBuffer(n2, false);
            return true;
        }
        if (bl2) {
            object.releaseOutputBuffer(n2, false);
            object = this.j;
            ++object.e;
            object = this.l;
            if (object.o != 1) return true;
            object.o = 2;
            return true;
        }
        try {
            if (!this.l.a(byteBuffer, l4)) return false;
            object.releaseOutputBuffer(n2, false);
            object = this.j;
            ++object.d;
            return true;
        }
        catch (d.d var5_4) {
            throw b.a((Exception)var5_5, this.c);
        }
        catch (d.f var5_6) {
            throw b.a((Exception)var5_5, this.c);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void b(Format format) {
        super.b(format);
        c.a a2 = this.k;
        if (a2.b != null) {
            a2.a.post(new Runnable(format){
                final /* synthetic */ Format a;

                @Override
                public final void run() {
                    a.this.b.b(this.a);
                }
            });
        }
        int n2 = "audio/raw".equals(format.f) ? format.s : 2;
        this.o = n2;
    }

    @Override
    public final com.google.android.exoplayer2.i.f c() {
        return this;
    }

    @Override
    public final boolean k() {
        if (this.l.b() || super.k()) {
            return true;
        }
        return false;
    }

    @Override
    public final boolean l() {
        if (super.l() && !this.l.b()) {
            return true;
        }
        return false;
    }

    @Override
    protected final void p() {
        super.p();
        this.l.a();
    }

    @Override
    protected final void q() {
        d d2 = this.l;
        d2.q = false;
        if (d2.f()) {
            d2.h();
            d2.d.a();
        }
        super.q();
    }

    @Override
    protected final void r() {
        try {
            d d2 = this.l;
            d2.d();
            d2.e();
            d2.r = 0;
            d2.q = false;
        }
        catch (Throwable var1_3) {
            try {
                super.r();
                throw var1_3;
            }
            finally {
                this.j.a();
                this.k.a(this.j);
            }
        }
        try {
            super.r();
            return;
        }
        finally {
            this.j.a();
            this.k.a(this.j);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long v() {
        long l2 = this.l.a(this.l());
        if (l2 != Long.MIN_VALUE) {
            if (!this.q) {
                l2 = Math.max(this.p, l2);
            }
            this.p = l2;
            this.q = false;
        }
        return this.p;
    }

    @Override
    protected final void w() {
        d d2 = this.l;
        if (d2.f()) {
            d2.d.a(d2.g());
            d2.n = 0;
        }
    }

    final class a
    implements d.e {
        private a() {
        }

        /* synthetic */ a(byte by2) {
            this();
        }

        @Override
        public final void a() {
            f.t();
            f.this.q = true;
        }

        @Override
        public final void a(int n2) {
            c.a a2 = f.this.k;
            if (a2.b != null) {
                a2.a.post(new Runnable(n2){
                    final /* synthetic */ int a;

                    @Override
                    public final void run() {
                        a.this.b.a(this.a);
                    }
                });
            }
            f.s();
        }

        @Override
        public final void a(int n2, long l2, long l3) {
            c.a a2 = f.this.k;
            if (a2.b != null) {
                a2.a.post(new Runnable(n2, l2, l3){
                    final /* synthetic */ int a;
                    final /* synthetic */ long b;
                    final /* synthetic */ long c;

                    @Override
                    public final void run() {
                    }
                });
            }
            f.u();
        }
    }

}

