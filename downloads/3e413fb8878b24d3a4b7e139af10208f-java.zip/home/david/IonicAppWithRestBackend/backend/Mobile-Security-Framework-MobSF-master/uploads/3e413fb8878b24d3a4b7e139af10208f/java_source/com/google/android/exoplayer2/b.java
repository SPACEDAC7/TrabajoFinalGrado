/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

import a.a.a.a.d;
import java.io.IOException;

public final class b
extends Exception {
    public final int a;
    public final int b;

    private b(int n2, Throwable throwable, int n3) {
        super(null, throwable);
        this.a = n2;
        this.b = n3;
    }

    public static b a(IOException iOException) {
        return new b(0, iOException, -1);
    }

    public static b a(Exception exception, int n2) {
        return new b(1, exception, n2);
    }

    static b a(RuntimeException runtimeException) {
        return new b(2, runtimeException, -1);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final Exception a() {
        boolean bl2 = true;
        if (this.a != 1) {
            bl2 = false;
        }
        d.b(bl2);
        return (Exception)this.getCause();
    }
}

