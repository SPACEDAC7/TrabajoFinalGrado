/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.b;

public abstract class a {
    public int a;

    public void a() {
        this.a = 0;
    }

    public final void a(int n2) {
        this.a |= n2;
    }

    protected final boolean b(int n2) {
        if ((this.a & n2) == n2) {
            return true;
        }
        return false;
    }

    public final boolean c() {
        return this.b(4);
    }

    public final boolean c_() {
        return this.b(Integer.MIN_VALUE);
    }

    public final boolean d() {
        return this.b(1);
    }
}

