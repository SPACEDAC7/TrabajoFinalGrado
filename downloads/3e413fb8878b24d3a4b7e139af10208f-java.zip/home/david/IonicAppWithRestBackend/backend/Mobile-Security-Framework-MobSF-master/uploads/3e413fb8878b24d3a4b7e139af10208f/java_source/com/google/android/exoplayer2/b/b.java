/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.MediaCodec
 *  android.media.MediaCodec$CryptoInfo
 */
package com.google.android.exoplayer2.b;

import android.media.MediaCodec;
import com.google.android.exoplayer2.i.o;

public final class b {
    public byte[] a;
    public byte[] b;
    public int c;
    public int[] d;
    public int[] e;
    public int f;
    public final MediaCodec.CryptoInfo g;

    /*
     * Enabled aggressive block sorting
     */
    public b() {
        MediaCodec.CryptoInfo cryptoInfo = o.a >= 16 ? new MediaCodec.CryptoInfo() : null;
        this.g = cryptoInfo;
    }
}

