/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.b;

public interface c<I, O, E extends Exception> {
    public I a();

    public void a(I var1);

    public O b();

    public void c();

    public void d();
}

