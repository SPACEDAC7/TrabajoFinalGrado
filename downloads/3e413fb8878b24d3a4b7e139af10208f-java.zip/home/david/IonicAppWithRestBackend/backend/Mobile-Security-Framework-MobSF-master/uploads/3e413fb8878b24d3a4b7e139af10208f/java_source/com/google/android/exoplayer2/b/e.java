/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.b;

import com.google.android.exoplayer2.b.a;
import com.google.android.exoplayer2.b.b;
import java.nio.Buffer;
import java.nio.ByteBuffer;

public class e
extends a {
    public final b b = new b();
    public ByteBuffer c;
    public long d;
    private final int e;

    public e(int n2) {
        this.e = n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private ByteBuffer d(int n2) {
        int n3;
        if (this.e == 1) {
            return ByteBuffer.allocate(n2);
        }
        if (this.e == 2) {
            return ByteBuffer.allocateDirect(n2);
        }
        if (this.c == null) {
            n3 = 0;
            do {
                throw new IllegalStateException("Buffer too small (" + n3 + " < " + n2 + ")");
                break;
            } while (true);
        }
        n3 = this.c.capacity();
        throw new IllegalStateException("Buffer too small (" + n3 + " < " + n2 + ")");
    }

    @Override
    public final void a() {
        super.a();
        if (this.c != null) {
            this.c.clear();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void c(int n2) {
        if (this.c == null) {
            this.c = this.d(n2);
            return;
        } else {
            int n3;
            int n4 = this.c.capacity();
            if (n4 >= (n2 = (n3 = this.c.position()) + n2)) return;
            {
                ByteBuffer byteBuffer = this.d(n2);
                if (n3 > 0) {
                    this.c.position(0);
                    this.c.limit(n3);
                    byteBuffer.put(this.c);
                }
                this.c = byteBuffer;
                return;
            }
        }
    }

    public final boolean e() {
        return this.b(1073741824);
    }

    public final void f() {
        this.c.flip();
    }
}

