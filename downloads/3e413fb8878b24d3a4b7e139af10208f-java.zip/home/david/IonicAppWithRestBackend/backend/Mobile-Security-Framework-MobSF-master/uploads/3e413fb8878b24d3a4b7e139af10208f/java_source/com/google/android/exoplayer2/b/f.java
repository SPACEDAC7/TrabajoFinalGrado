/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.b;

import com.google.android.exoplayer2.b.a;

public abstract class f
extends a {
    public long b;
    public int c;
}

