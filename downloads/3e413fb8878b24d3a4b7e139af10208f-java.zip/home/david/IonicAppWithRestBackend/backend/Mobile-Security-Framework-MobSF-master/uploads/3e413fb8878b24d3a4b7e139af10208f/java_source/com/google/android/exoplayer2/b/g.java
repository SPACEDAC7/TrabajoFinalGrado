/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.b;

import a.a.a.a.d;
import com.google.android.exoplayer2.b.c;
import com.google.android.exoplayer2.b.e;
import com.google.android.exoplayer2.b.f;
import java.util.LinkedList;

public abstract class g<I extends e, O extends f, E extends Exception>
implements c<I, O, E> {
    public final I[] a;
    public int b;
    private final Thread c;
    private final Object d;
    private final LinkedList<I> e;
    private final LinkedList<O> f;
    private final O[] g;
    private int h;
    private I i;
    private E j;
    private boolean k;
    private boolean l;
    private int m;

    public g(I[] arrI, O[] arrO) {
        int n2;
        int n3 = 0;
        this.d = new Object();
        this.e = new LinkedList();
        this.f = new LinkedList();
        this.a = arrI;
        this.b = 2;
        for (n2 = 0; n2 < this.b; ++n2) {
            this.a[n2] = this.f();
        }
        this.g = arrO;
        this.h = 2;
        for (n2 = n3; n2 < this.h; ++n2) {
            this.g[n2] = this.g();
        }
        this.c = new Thread(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public final void run() {
                g g2 = g.this;
                try {
                    boolean bl2;
                    while (bl2 = g2.e()) {
                    }
                    return;
                }
                catch (InterruptedException var1_2) {
                    throw new IllegalStateException(var1_2);
                }
            }
        };
        this.c.start();
    }

    @Override
    private void a(I i2) {
        i2.a();
        I[] arrI = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        arrI[n2] = i2;
    }

    private void b(O o2) {
        o2.a();
        O[] arrO = this.g;
        int n2 = this.h;
        this.h = n2 + 1;
        arrO[n2] = o2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private I h() {
        Object object = this.d;
        synchronized (object) {
            Object object2;
            this.j();
            boolean bl2 = this.i == null;
            d.b(bl2);
            if (this.b == 0) {
                object2 = null;
            } else {
                int n2;
                object2 = this.a;
                this.b = n2 = this.b - 1;
                object2 = object2[n2];
            }
            object2 = this.i = object2;
            return (I)object2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private O i() {
        Object object = this.d;
        synchronized (object) {
            this.j();
            if (this.f.isEmpty()) {
                return null;
            }
            f f2 = (f)this.f.removeFirst();
            return (O)f2;
        }
    }

    private void j() {
        if (this.j != null) {
            throw this.j;
        }
    }

    private void k() {
        if (this.l()) {
            this.d.notify();
        }
    }

    private boolean l() {
        if (!this.e.isEmpty() && this.h > 0) {
            return true;
        }
        return false;
    }

    public abstract E a(I var1, O var2);

    @Override
    public final /* synthetic */ Object a() {
        return this.h();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void a(O o2) {
        Object object = this.d;
        synchronized (object) {
            this.b(o2);
            this.k();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final /* synthetic */ void a(Object object) {
        e e2 = (e)object;
        object = this.d;
        synchronized (object) {
            this.j();
            boolean bl2 = e2 == this.i;
            d.a(bl2);
            this.e.addLast((e)e2);
            this.k();
            this.i = null;
            return;
        }
    }

    @Override
    public final /* synthetic */ Object b() {
        return this.i();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void c() {
        Object object = this.d;
        synchronized (object) {
            this.k = true;
            this.m = 0;
            if (this.i != null) {
                this.a((O)this.i);
                this.i = null;
            }
            while (!this.e.isEmpty()) {
                this.a((O)((e)this.e.removeFirst()));
            }
            while (!this.f.isEmpty()) {
                this.b((f)this.f.removeFirst());
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void d() {
        Object object = this.d;
        synchronized (object) {
            this.l = true;
            this.d.notify();
        }
        try {
            this.c.join();
            return;
        }
        catch (InterruptedException var1_2) {
            Thread.currentThread().interrupt();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    final boolean e() {
        int n2;
        Object object = this.d;
        // MONITORENTER : object
        while (!this.l && !this.l()) {
            this.d.wait();
        }
        if (this.l) {
            // MONITOREXIT : object
            return false;
        }
        e e2 = (e)this.e.removeFirst();
        Object object2 = this.g;
        this.h = n2 = this.h - 1;
        object2 = object2[n2];
        this.k = false;
        // MONITOREXIT : object
        if (e2.c()) {
            object2.a(4);
        } else {
            if (e2.c_()) {
                object2.a(Integer.MIN_VALUE);
            }
            this.j = this.a(e2, object2);
            if (this.j != null) {
                object = this.d;
                // MONITORENTER : object
                // MONITOREXIT : object
                return false;
            }
        }
        object = this.d;
        // MONITORENTER : object
        if (this.k) {
            this.b(object2);
        } else if (object2.c_()) {
            ++this.m;
            this.b(object2);
        } else {
            object2.c = this.m;
            this.m = 0;
            this.f.addLast((Object)object2);
        }
        this.a((O)e2);
        // MONITOREXIT : object
        return true;
    }

    public abstract I f();

    public abstract O g();

}

