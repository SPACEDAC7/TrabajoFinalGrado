/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.i.f;
import com.google.android.exoplayer2.k;
import com.google.android.exoplayer2.l;
import com.google.android.exoplayer2.n;

public interface c {
    public int a();

    public void a(int var1);

    public void a(int var1, long var2);

    public void a(long var1);

    public void a(a var1);

    public void a(com.google.android.exoplayer2.e.b var1, boolean var2, boolean var3);

    public void a(boolean var1);

    public /* varargs */ void a(c ... var1);

    public void b(a var1);

    public /* varargs */ void b(c ... var1);

    public boolean b();

    public void c();

    public void d();

    public n e();

    public int f();

    public long g();

    public long h();

    public long i();

    public static interface a {
        public void a(com.google.android.exoplayer2.b var1);

        public void a(boolean var1, int var2);

        public void c();

        public void j_();

        public void k_();
    }

    public static interface b {
        public int a();

        public void a(int var1);

        public void a(int var1, Object var2);

        public void a(long var1);

        public void a(long var1, long var3);

        public void a(l var1, Format[] var2, com.google.android.exoplayer2.e.c var3, long var4, boolean var6, long var7);

        public void a(Format[] var1, com.google.android.exoplayer2.e.c var2, long var3);

        public k b();

        public f c();

        public int d();

        public void e();

        public com.google.android.exoplayer2.e.c f();

        public boolean g();

        public void h();

        public boolean i();

        public void j();

        public boolean k();

        public boolean l();

        public void m();

        public void n();
    }

    public static final class c {
        public final b a;
        public final int b;
        public final Object c;

        public c(b b2, int n2, Object object) {
            this.a = b2;
            this.b = n2;
            this.c = object;
        }
    }

}

