/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.i.o;

public final class a
implements m {
    public final int a;
    public final int[] b;
    public final long[] c;
    public final long[] d;
    public final long[] e;
    private final long f;

    public a(int[] arrn, long[] arrl, long[] arrl2, long[] arrl3) {
        this.b = arrn;
        this.c = arrl;
        this.d = arrl2;
        this.e = arrl3;
        this.a = arrn.length;
        this.f = arrl2[this.a - 1] + arrl3[this.a - 1];
    }

    @Override
    public final long a(long l2) {
        return this.c[o.a(this.e, l2, true)];
    }

    @Override
    public final long b() {
        return this.f;
    }

    @Override
    public final boolean b_() {
        return true;
    }
}

