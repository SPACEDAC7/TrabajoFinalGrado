/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 */
package com.google.android.exoplayer2.c.a;

import android.util.Pair;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.a.d;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.i;
import java.util.Collections;

final class a
extends d {
    private boolean a;
    private boolean c;
    private int d;

    public a(n n2) {
        super(n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(i object, long l2) {
        int n2 = object.e();
        if (n2 == 0 && !this.c) {
            byte[] arrby = new byte[object.b()];
            object.a(arrby, 0, arrby.length);
            object = com.google.android.exoplayer2.i.a.a(arrby);
            object = Format.a(null, "audio/mp4a-latm", -1, -1, (Integer)object.second, (Integer)object.first, Collections.singletonList(arrby), null, null);
            this.b.a((Format)object);
            this.c = true;
            return;
        } else {
            if (this.d == 10 && n2 != 1) return;
            {
                n2 = object.b();
                this.b.a((i)object, n2);
                this.b.a(l2, 1, n2, 0, null);
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final boolean a(i object) {
        if (this.a) {
            object.d(1);
            return true;
        }
        int n2 = object.e();
        this.d = n2 >> 4 & 15;
        if (this.d == 7 || this.d == 8) {
            object = this.d == 7 ? "audio/g711-alaw" : "audio/g711-mlaw";
            n2 = (n2 & 1) == 1 ? 2 : 3;
            object = Format.a(null, (String)object, -1, -1, 1, 8000, n2, null, null, 0, null);
            this.b.a((Format)object);
            this.c = true;
        } else if (this.d != 10) {
            throw new d.a("Audio format not supported: " + this.d);
        }
        this.a = true;
        return true;
    }
}

