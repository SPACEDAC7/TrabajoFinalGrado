/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.a;

import com.google.android.exoplayer2.c.a.a;
import com.google.android.exoplayer2.c.a.c;
import com.google.android.exoplayer2.c.a.e;
import com.google.android.exoplayer2.c.f;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.i;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.o;

public final class b
implements f,
m {
    public static final i a = new i(){

        @Override
        public final f[] a() {
            return new f[]{new b()};
        }
    };
    private static final int e = o.e("FLV");
    public int b;
    public int c;
    public long d;
    private final com.google.android.exoplayer2.i.i f = new com.google.android.exoplayer2.i.i(4);
    private final com.google.android.exoplayer2.i.i g = new com.google.android.exoplayer2.i.i(9);
    private final com.google.android.exoplayer2.i.i h = new com.google.android.exoplayer2.i.i(11);
    private final com.google.android.exoplayer2.i.i i = new com.google.android.exoplayer2.i.i();
    private h j;
    private int k = 1;
    private int l;
    private a m;
    private e n;
    private c o;

    /*
     * Enabled aggressive block sorting
     */
    private com.google.android.exoplayer2.i.i b(g g2) {
        if (this.c > this.i.d()) {
            this.i.a(new byte[Math.max(this.i.d() << 1, this.c)], 0);
        } else {
            this.i.c(0);
        }
        this.i.b(this.c);
        g2.b(this.i.a, 0, this.c);
        return this.i;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(g var1_1, l var2_2) {
        block6 : do {
            switch (this.k) {
                default: {
                    continue block6;
                }
                case 1: {
                    if (!var1_1.a(this.g.a, 0, 9, true)) {
                        return -1;
                    }
                    this.g.c(0);
                    this.g.d(4);
                    var4_4 = this.g.e();
                    var3_3 = (var4_4 & 4) != 0;
                    var4_4 = (var4_4 & 1) != 0 ? 1 : 0;
                    if (!var3_3) ** GOTO lbl-1000
                    if (this.m == null) {
                        this.m = new a(this.j.a(8));
                    }
                    if (var4_4 != 0) lbl-1000: // 2 sources:
                    {
                        if (this.n == null) {
                            this.n = new e(this.j.a(9));
                        }
                    }
                    if (this.o == null) {
                        this.o = new c();
                    }
                    this.j.b();
                    this.j.a(this);
                    this.l = this.g.k() - 9 + 4;
                    this.k = 2;
                    var3_3 = true;
                    if (var3_3) continue block6;
                    return -1;
                }
                case 2: {
                    var1_1.b(this.l);
                    this.l = 0;
                    this.k = 3;
                    continue block6;
                }
                case 3: {
                    if (!var1_1.a(this.h.a, 0, 11, true)) {
                        return -1;
                    }
                    this.h.c(0);
                    this.b = this.h.e();
                    this.c = this.h.h();
                    this.d = this.h.h();
                    this.d = ((long)(this.h.e() << 24) | this.d) * 1000;
                    this.h.d(3);
                    this.k = 4;
                    var3_3 = true;
                    if (var3_3) continue block6;
                    return -1;
                }
                case 4: 
            }
            if (this.b == 8 && this.m != null) {
                this.m.b(this.b(var1_1), this.d);
                var3_3 = true;
            } else if (this.b == 9 && this.n != null) {
                this.n.b(this.b(var1_1), this.d);
                var3_3 = true;
            } else if (this.b == 18 && this.o != null) {
                this.o.b(this.b(var1_1), this.d);
                var3_3 = true;
            } else {
                var1_1.b(this.c);
                var3_3 = false;
            }
            this.l = 4;
            this.k = 2;
            if (var3_3) return 0;
        } while (true);
    }

    @Override
    public final long a(long l2) {
        return 0;
    }

    @Override
    public final void a(long l2, long l3) {
        this.k = 1;
        this.l = 0;
    }

    @Override
    public final void a(h h2) {
        this.j = h2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final boolean a(g g2) {
        g2.c(this.f.a, 0, 3);
        this.f.c(0);
        if (this.f.h() != e) {
            return false;
        }
        g2.c(this.f.a, 0, 2);
        this.f.c(0);
        if ((this.f.f() & 250) != 0) return false;
        g2.c(this.f.a, 0, 4);
        this.f.c(0);
        int n2 = this.f.k();
        g2.a();
        g2.c(n2);
        g2.c(this.f.a, 0, 4);
        this.f.c(0);
        if (this.f.k() != 0) return false;
        return true;
    }

    @Override
    public final long b() {
        return this.o.a;
    }

    @Override
    public final boolean b_() {
        return false;
    }

}

