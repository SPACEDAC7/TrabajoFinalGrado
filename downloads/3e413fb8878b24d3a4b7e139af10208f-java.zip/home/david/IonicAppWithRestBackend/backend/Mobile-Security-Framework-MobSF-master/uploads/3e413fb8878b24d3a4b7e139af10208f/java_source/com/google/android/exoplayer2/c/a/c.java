/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.a;

import com.google.android.exoplayer2.c.a.d;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

final class c
extends d {
    long a = -9223372036854775807L;

    public c() {
        super(null);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Object a(com.google.android.exoplayer2.i.i i2, int n2) {
        boolean bl2 = true;
        switch (n2) {
            default: {
                return null;
            }
            case 0: {
                return c.b(i2);
            }
            case 1: {
                if (i2.e() == 1) {
                    do {
                        return bl2;
                        break;
                    } while (true);
                }
                bl2 = false;
                return bl2;
            }
            case 2: {
                return c.c(i2);
            }
            case 3: {
                HashMap<String, Object> hashMap = new HashMap<String, Object>();
                do {
                    String string = c.c(i2);
                    n2 = i2.e();
                    HashMap<String, Object> hashMap2 = hashMap;
                    if (n2 == 9) return hashMap2;
                    hashMap.put(string, c.a(i2, n2));
                } while (true);
            }
            case 8: {
                return c.e(i2);
            }
            case 10: {
                return c.d(i2);
            }
            case 11: 
        }
        Date date = new Date((long)c.b(i2).doubleValue());
        i2.d(2);
        return date;
    }

    private static Double b(com.google.android.exoplayer2.i.i i2) {
        return Double.longBitsToDouble(i2.m());
    }

    private static String c(com.google.android.exoplayer2.i.i i2) {
        int n2 = i2.f();
        int n3 = i2.b;
        i2.d(n2);
        return new String(i2.a, n3, n2);
    }

    private static ArrayList<Object> d(com.google.android.exoplayer2.i.i i2) {
        int n2 = i2.o();
        ArrayList<Object> arrayList = new ArrayList<Object>(n2);
        for (int i3 = 0; i3 < n2; ++i3) {
            arrayList.add(c.a(i2, i2.e()));
        }
        return arrayList;
    }

    private static HashMap<String, Object> e(com.google.android.exoplayer2.i.i i2) {
        int n2 = i2.o();
        HashMap<String, Object> hashMap = new HashMap<String, Object>(n2);
        for (int i3 = 0; i3 < n2; ++i3) {
            hashMap.put(c.c(i2), c.a(i2, i2.e()));
        }
        return hashMap;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final void a(com.google.android.exoplayer2.i.i hashMap, long l2) {
        if (hashMap.e() != 2) {
            throw new i();
        }
        if (!"onMetaData".equals(c.c(hashMap))) {
            return;
        }
        if (hashMap.e() != 8) {
            throw new i();
        }
        if (!(hashMap = c.e(hashMap)).containsKey("duration")) return;
        double d2 = (Double)hashMap.get("duration");
        if (d2 <= 0.0) return;
        this.a = (long)(d2 * 1000000.0);
    }

    @Override
    protected final boolean a(com.google.android.exoplayer2.i.i i2) {
        return true;
    }
}

