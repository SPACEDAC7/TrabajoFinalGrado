/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.a;

import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i;

abstract class d {
    protected final n b;

    protected d(n n2) {
        this.b = n2;
    }

    protected abstract void a(com.google.android.exoplayer2.i.i var1, long var2);

    protected abstract boolean a(com.google.android.exoplayer2.i.i var1);

    public final void b(com.google.android.exoplayer2.i.i i2, long l2) {
        if (this.a(i2)) {
            this.a(i2, l2);
        }
    }

    public static final class a
    extends i {
        public a(String string) {
            super(string);
        }
    }

}

