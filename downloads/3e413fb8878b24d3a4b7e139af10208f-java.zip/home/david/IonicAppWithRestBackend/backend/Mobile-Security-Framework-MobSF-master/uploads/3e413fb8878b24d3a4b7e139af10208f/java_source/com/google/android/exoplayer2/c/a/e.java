/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.a;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.a.d;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.g;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.j.a;
import java.util.List;

final class e
extends d {
    private final i a = new i(g.a);
    private final i c = new i(4);
    private int d;
    private boolean e;
    private int f;

    public e(n n2) {
        super(n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(i object, long l2) {
        int n2 = 1;
        int n3 = object.e();
        long l3 = object.h();
        if (n3 == 0 && !this.e) {
            i i2 = new i(new byte[object.b()]);
            object.a(i2.a, 0, object.b());
            object = a.a(i2);
            this.d = object.b;
            object = Format.a("video/avc", object.c, object.d, object.a, object.e);
            this.b.a((Format)object);
            this.e = true;
            return;
        }
        if (n3 != 1) return;
        {
            byte[] arrby = this.c.a;
            arrby[0] = 0;
            arrby[1] = 0;
            arrby[2] = 0;
            int n4 = this.d;
            n3 = 0;
            while (object.b() > 0) {
                object.a(this.c.a, 4 - n4, this.d);
                this.c.c(0);
                int n5 = this.c.o();
                this.a.c(0);
                this.b.a(this.a, 4);
                this.b.a((i)object, n5);
                n3 = n3 + 4 + n5;
            }
        }
        object = this.b;
        if (this.f != 1) {
            n2 = 0;
        }
        object.a(l3 * 1000 + l2, n2, n3, 0, null);
    }

    @Override
    protected final boolean a(i i2) {
        int n2 = i2.e();
        int n3 = n2 >> 4 & 15;
        if ((n2 &= 15) != 7) {
            throw new d.a("Video format not supported: " + n2);
        }
        this.f = n3;
        if (n3 != 5) {
            return true;
        }
        return false;
    }
}

