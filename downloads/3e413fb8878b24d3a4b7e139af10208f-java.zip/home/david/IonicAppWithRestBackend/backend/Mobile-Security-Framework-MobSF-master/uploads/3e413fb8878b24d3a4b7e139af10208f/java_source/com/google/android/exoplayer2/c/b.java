/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.h.d;
import java.io.EOFException;
import java.util.Arrays;

public final class b
implements g {
    private static final byte[] a = new byte[4096];
    private final d b;
    private final long c;
    private long d;
    private byte[] e;
    private int f;
    private int g;

    public b(d d2, long l2, long l3) {
        this.b = d2;
        this.d = l2;
        this.c = l3;
        this.e = new byte[8192];
    }

    private int a(byte[] arrby, int n2, int n3, int n4, boolean bl2) {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        if ((n2 = this.b.a(arrby, n2 + n4, n3 - n4)) == -1) {
            if (n4 == 0 && bl2) {
                return -1;
            }
            throw new EOFException();
        }
        return n4 + n2;
    }

    private boolean a(int n2, boolean bl2) {
        int n3 = this.f + n2;
        if (n3 > this.e.length) {
            this.e = Arrays.copyOf(this.e, Math.max(this.e.length << 1, n3));
        }
        n3 = Math.min(this.g - this.f, n2);
        while (n3 < n2) {
            int n4;
            n3 = n4 = this.a(this.e, this.f, n2, n3, bl2);
            if (n4 != -1) continue;
            return false;
        }
        this.f += n2;
        this.g = Math.max(this.g, this.f);
        return true;
    }

    private int d(int n2) {
        n2 = Math.min(this.g, n2);
        this.e(n2);
        return n2;
    }

    private int d(byte[] arrby, int n2, int n3) {
        if (this.g == 0) {
            return 0;
        }
        n3 = Math.min(this.g, n3);
        System.arraycopy(this.e, 0, arrby, n2, n3);
        this.e(n3);
        return n3;
    }

    private void e(int n2) {
        this.g -= n2;
        this.f = 0;
        System.arraycopy(this.e, n2, this.e, 0, this.g);
    }

    private void f(int n2) {
        if (n2 != -1) {
            this.d += (long)n2;
        }
    }

    @Override
    public final int a(int n2) {
        int n3;
        int n4 = n3 = this.d(n2);
        if (n3 == 0) {
            n4 = this.a(a, 0, Math.min(n2, a.length), 0, true);
        }
        this.f(n4);
        return n4;
    }

    @Override
    public final int a(byte[] arrby, int n2, int n3) {
        int n4;
        int n5 = n4 = this.d(arrby, n2, n3);
        if (n4 == 0) {
            n5 = this.a(arrby, n2, n3, 0, true);
        }
        this.f(n5);
        return n5;
    }

    @Override
    public final void a() {
        this.f = 0;
    }

    @Override
    public final boolean a(byte[] arrby, int n2, int n3, boolean bl2) {
        int n4 = this.d(arrby, n2, n3);
        while (n4 < n3 && n4 != -1) {
            n4 = this.a(arrby, n2, n3, n4, bl2);
        }
        this.f(n4);
        if (n4 != -1) {
            return true;
        }
        return false;
    }

    @Override
    public final long b() {
        return this.d + (long)this.f;
    }

    @Override
    public final void b(int n2) {
        int n3 = this.d(n2);
        while (n3 < n2 && n3 != -1) {
            n3 = this.a(a, - n3, Math.min(n2, a.length + n3), n3, false);
        }
        this.f(n3);
    }

    @Override
    public final void b(byte[] arrby, int n2, int n3) {
        this.a(arrby, n2, n3, false);
    }

    @Override
    public final boolean b(byte[] arrby, int n2, int n3, boolean bl2) {
        if (!this.a(n3, bl2)) {
            return false;
        }
        System.arraycopy(this.e, this.f - n3, arrby, n2, n3);
        return true;
    }

    @Override
    public final long c() {
        return this.d;
    }

    @Override
    public final void c(int n2) {
        this.a(n2, false);
    }

    @Override
    public final void c(byte[] arrby, int n2, int n3) {
        this.b(arrby, n2, n3, false);
    }

    @Override
    public final long d() {
        return this.c;
    }
}

