/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.b;

final class a {
    final int a;
    final long b;

    private a(int n2, long l2) {
        this.a = n2;
        this.b = l2;
    }

    /* synthetic */ a(int n2, long l2, byte by2) {
        this(n2, l2);
    }
}

