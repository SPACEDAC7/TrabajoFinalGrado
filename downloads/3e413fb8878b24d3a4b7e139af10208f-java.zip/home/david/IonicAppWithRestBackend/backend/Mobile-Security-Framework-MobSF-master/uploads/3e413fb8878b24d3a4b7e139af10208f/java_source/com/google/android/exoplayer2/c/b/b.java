/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.b;

import com.google.android.exoplayer2.c.b.a;
import com.google.android.exoplayer2.c.b.c;
import com.google.android.exoplayer2.c.b.f;
import com.google.android.exoplayer2.c.g;
import java.util.Stack;

final class b {
    final byte[] a = new byte[8];
    final Stack<a> b = new Stack();
    final f c = new f();
    c d;
    int e;
    int f;
    long g;

    b() {
    }

    final long a(g g2, int n2) {
        g2.b(this.a, 0, n2);
        long l2 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            l2 = l2 << 8 | (long)(this.a[i2] & 255);
        }
        return l2;
    }
}

