/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.b;

import com.google.android.exoplayer2.c.g;

interface c {
    public int a(int var1);

    public void a(int var1, double var2);

    public void a(int var1, int var2, g var3);

    public void a(int var1, long var2);

    public void a(int var1, long var2, long var4);

    public void a(int var1, String var2);

    public boolean b(int var1);

    public void c(int var1);
}

