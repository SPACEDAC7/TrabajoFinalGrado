/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 */
package com.google.android.exoplayer2.c.b;

import android.util.SparseArray;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.b.c;
import com.google.android.exoplayer2.c.b.e;
import com.google.android.exoplayer2.c.f;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.i;
import com.google.android.exoplayer2.i.o;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Stack;
import java.util.UUID;

public final class d
implements f {
    private static final byte[] F;
    private static final byte[] G;
    private static final UUID H;
    public static final com.google.android.exoplayer2.c.i a;
    int A;
    int B;
    int C;
    boolean D;
    h E;
    private final com.google.android.exoplayer2.c.b.b I;
    private final com.google.android.exoplayer2.i.i J;
    private final com.google.android.exoplayer2.i.i K;
    private final com.google.android.exoplayer2.i.i L;
    private final com.google.android.exoplayer2.i.i M;
    private final com.google.android.exoplayer2.i.i N;
    private final com.google.android.exoplayer2.i.i O;
    private final com.google.android.exoplayer2.i.i P;
    private ByteBuffer Q;
    private long R = -1;
    private int S;
    private boolean T;
    private boolean U;
    private boolean V;
    private boolean W;
    private byte X;
    private int Y;
    private int Z;
    private int aa;
    private boolean ab;
    final com.google.android.exoplayer2.c.b.f b;
    final SparseArray<b> c;
    final com.google.android.exoplayer2.i.i d;
    final com.google.android.exoplayer2.i.i e;
    long f;
    long g = -1;
    long h = -9223372036854775807L;
    long i = -9223372036854775807L;
    long j = -9223372036854775807L;
    b k;
    boolean l;
    int m;
    long n;
    boolean o;
    long p = -1;
    long q = -9223372036854775807L;
    com.google.android.exoplayer2.i.e r;
    com.google.android.exoplayer2.i.e s;
    boolean t;
    int u;
    long v;
    long w;
    int x;
    int y;
    int[] z;

    static {
        a = new com.google.android.exoplayer2.c.i(){

            @Override
            public final f[] a() {
                return new f[]{new d()};
            }
        };
        F = new byte[]{49, 10, 48, 48, 58, 48, 48, 58, 48, 48, 44, 48, 48, 48, 32, 45, 45, 62, 32, 48, 48, 58, 48, 48, 58, 48, 48, 44, 48, 48, 48, 10};
        G = new byte[]{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32};
        H = new UUID(0x100000000001000L, -9223371306706625679L);
    }

    public d() {
        this(new com.google.android.exoplayer2.c.b.b());
    }

    private d(com.google.android.exoplayer2.c.b.b b2) {
        this.I = b2;
        this.I.d = new a(0);
        this.b = new com.google.android.exoplayer2.c.b.f();
        this.c = new SparseArray();
        this.d = new com.google.android.exoplayer2.i.i(4);
        this.L = new com.google.android.exoplayer2.i.i(ByteBuffer.allocate(4).putInt(-1).array());
        this.e = new com.google.android.exoplayer2.i.i(4);
        this.J = new com.google.android.exoplayer2.i.i(com.google.android.exoplayer2.i.g.a);
        this.K = new com.google.android.exoplayer2.i.i(4);
        this.M = new com.google.android.exoplayer2.i.i();
        this.N = new com.google.android.exoplayer2.i.i();
        this.O = new com.google.android.exoplayer2.i.i(8);
        this.P = new com.google.android.exoplayer2.i.i();
    }

    static int a(int n2) {
        switch (n2) {
            default: {
                return 0;
            }
            case 160: 
            case 174: 
            case 183: 
            case 187: 
            case 224: 
            case 225: 
            case 18407: 
            case 19899: 
            case 20532: 
            case 20533: 
            case 25152: 
            case 28032: 
            case 30320: 
            case 290298740: 
            case 357149030: 
            case 374648427: 
            case 408125543: 
            case 440786851: 
            case 475249515: 
            case 524531317: {
                return 1;
            }
            case 131: 
            case 136: 
            case 155: 
            case 159: 
            case 176: 
            case 179: 
            case 186: 
            case 215: 
            case 231: 
            case 241: 
            case 251: 
            case 16980: 
            case 17029: 
            case 17143: 
            case 18401: 
            case 18408: 
            case 20529: 
            case 20530: 
            case 21420: 
            case 21432: 
            case 21680: 
            case 21682: 
            case 21690: 
            case 21930: 
            case 22186: 
            case 22203: 
            case 25188: 
            case 2352003: 
            case 2807729: {
                return 2;
            }
            case 134: 
            case 17026: 
            case 2274716: {
                return 3;
            }
            case 161: 
            case 163: 
            case 16981: 
            case 18402: 
            case 21419: 
            case 25506: 
            case 30322: {
                return 4;
            }
            case 181: 
            case 17545: 
        }
        return 5;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int a(g g2, n n2, int n3) {
        int n4 = this.M.b();
        if (n4 > 0) {
            n3 = Math.min(n3, n4);
            n2.a(this.M, n3);
        } else {
            n3 = n2.a(g2, n3, false);
        }
        this.S += n3;
        this.aa += n3;
        return n3;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static int[] a(int[] arrn, int n2) {
        if (arrn == null) {
            return new int[n2];
        }
        int[] arrn2 = arrn;
        if (arrn.length >= n2) return arrn2;
        return new int[Math.max(arrn.length << 1, n2)];
    }

    private void b() {
        this.S = 0;
        this.aa = 0;
        this.Z = 0;
        this.T = false;
        this.U = false;
        this.W = false;
        this.Y = 0;
        this.X = 0;
        this.V = false;
        this.M.a();
    }

    static boolean b(int n2) {
        if (n2 == 357149030 || n2 == 524531317 || n2 == 475249515 || n2 == 374648427) {
            return true;
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(g var1_1, l var2_2) {
        this.ab = false;
        var10_3 = 1;
        block8 : do lbl-1000: // 3 sources:
        {
            if (var10_3 == 0) {
                if (var10_3 == 0) return -1;
                return 0;
            }
            if (this.ab != false) return 0;
            var6_6 = this.I;
            var15_12 = var6_6.d != null;
            a.a.a.a.d.b(var15_12);
            do {
                if (var6_6.b.isEmpty() || var1_1.c() < var6_6.b.peek().b) ** GOTO lbl16
                var6_6.d.c(var6_6.b.pop().a);
                var8_8 = 1;
                ** GOTO lbl20
lbl16: // 1 sources:
                if (var6_6.e != 0) ** GOTO lbl52
                var11_10 = var13_11 = var6_6.c.a(var1_1, true, false, 4);
                if (var13_11 != -2) ** GOTO lbl46
                ** GOTO lbl39
lbl20: // 6 sources:
                do {
                    var10_3 = var8_8;
                    if (var8_8 == 0) ** GOTO lbl-1000
                    var11_10 = var1_1.c();
                    if (this.o) {
                        this.R = var11_10;
                        var2_2.a = this.p;
                        this.o = false;
                        var9_9 = 1;
                    } else if (this.l && this.R != -1) {
                        var2_2.a = this.R;
                        this.R = -1;
                        var9_9 = 1;
                    } else {
                        var9_9 = 0;
                    }
                    var10_3 = var8_8;
                    if (var9_9 == 0) continue block8;
                    return 1;
                    break;
                } while (true);
lbl39: // 1 sources:
                var1_1.a();
                do {
                    var1_1.c(var6_6.a, 0, 4);
                    var8_8 = com.google.android.exoplayer2.c.b.f.a(var6_6.a[0]);
                    if (var8_8 != -1 && var8_8 <= 4 && var6_6.d.b(var9_9 = (int)com.google.android.exoplayer2.c.b.f.a(var6_6.a, var8_8, false))) {
                        var1_1.b(var8_8);
                        var11_10 = var9_9;
lbl46: // 2 sources:
                        if (var11_10 != -1) break;
                        return -1;
                    }
                    var1_1.b(1);
                } while (true);
                var6_6.f = (int)var11_10;
                var6_6.e = 1;
lbl52: // 2 sources:
                if (var6_6.e == 1) {
                    var6_6.g = var6_6.c.a(var1_1, false, true, 8);
                    var6_6.e = 2;
                }
                var8_8 = var6_6.d.a(var6_6.f);
                switch (var8_8) {
                    default: {
                        throw new i("Invalid element type " + var8_8);
                    }
                    case 1: {
                        var11_10 = var1_1.c();
                        var13_11 = var6_6.g;
                        var6_6.b.add(new com.google.android.exoplayer2.c.b.a(var6_6.f, var13_11 + var11_10, 0));
                        var6_6.d.a(var6_6.f, var11_10, var6_6.g);
                        var6_6.e = 0;
                        var8_8 = 1;
                        ** GOTO lbl20
                    }
                    case 2: {
                        if (var6_6.g > 8) {
                            throw new i("Invalid integer size: " + var6_6.g);
                        }
                        var6_6.d.a(var6_6.f, var6_6.a(var1_1, (int)var6_6.g));
                        var6_6.e = 0;
                        var8_8 = 1;
                        ** GOTO lbl20
                    }
                    case 5: {
                        if (var6_6.g != 4 && var6_6.g != 8) {
                            throw new i("Invalid float size: " + var6_6.g);
                        }
                        var5_5 = var6_6.d;
                        var8_8 = var6_6.f;
                        var9_9 = (int)var6_6.g;
                        var11_10 = var6_6.a(var1_1, var9_9);
                        var3_4 = var9_9 == 4 ? (double)Float.intBitsToFloat((int)var11_10) : Double.longBitsToDouble(var11_10);
                        var5_5.a(var8_8, var3_4);
                        var6_6.e = 0;
                        var8_8 = 1;
                        ** GOTO lbl20
                    }
                    case 3: {
                        if (var6_6.g > Integer.MAX_VALUE) {
                            throw new i("String element size: " + var6_6.g);
                        }
                        var7_7 = var6_6.d;
                        var8_8 = var6_6.f;
                        var9_9 = (int)var6_6.g;
                        if (var9_9 == 0) {
                            var5_5 = "";
                        } else {
                            var5_5 = new byte[var9_9];
                            var1_1.b((byte[])var5_5, 0, var9_9);
                            var5_5 = new String((byte[])var5_5);
                        }
                        var7_7.a(var8_8, (String)var5_5);
                        var6_6.e = 0;
                        var8_8 = 1;
                        ** GOTO lbl20
                    }
                    case 4: {
                        var6_6.d.a(var6_6.f, (int)var6_6.g, var1_1);
                        var6_6.e = 0;
                        var8_8 = 1;
                        ** continue;
                    }
                    case 0: 
                }
                var1_1.b((int)var6_6.g);
                var6_6.e = 0;
            } while (true);
            break;
        } while (true);
    }

    final long a(long l2) {
        if (this.h == -9223372036854775807L) {
            throw new i("Can't scale timecode prior to timecodeScale being set.");
        }
        return o.a(l2, this.h, 1000);
    }

    @Override
    public final void a(long l2, long l3) {
        this.q = -9223372036854775807L;
        this.u = 0;
        com.google.android.exoplayer2.c.b.b b2 = this.I;
        b2.e = 0;
        b2.b.clear();
        b2.c.a();
        this.b.a();
        this.b();
    }

    /*
     * Enabled aggressive block sorting
     */
    final void a(b b2, long l2) {
        if ("S_TEXT/UTF8".equals(b2.a)) {
            byte[] arrby;
            byte[] arrby2 = this.N.a;
            long l3 = this.w;
            if (l3 == -9223372036854775807L) {
                arrby = G;
            } else {
                int n2 = (int)(l3 / 3600000000L);
                int n3 = (int)((l3 -= (long)n2 * 3600000000L) / 60000000);
                int n4 = (int)((l3 -= (long)(60000000 * n3)) / 1000000);
                int n5 = (int)((l3 - (long)(1000000 * n4)) / 1000);
                arrby = o.c(String.format(Locale.US, "%02d:%02d:%02d,%03d", n2, n3, n4, n5));
            }
            System.arraycopy(arrby, 0, arrby2, 19, 12);
            b2.y.a(this.N, this.N.c);
            this.aa += this.N.c;
        }
        b2.y.a(l2, this.C, this.aa, 0, b2.g);
        this.ab = true;
        this.b();
    }

    final void a(g g2, int n2) {
        if (this.d.c >= n2) {
            return;
        }
        if (this.d.d() < n2) {
            this.d.a(Arrays.copyOf(this.d.a, Math.max(this.d.a.length << 1, n2)), this.d.c);
        }
        g2.b(this.d.a, this.d.c, n2 - this.d.c);
        this.d.b(n2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final void a(g var1_1, b var2_2, int var3_3) {
        if ("S_TEXT/UTF8".equals(var2_2.a)) {
            var7_4 = d.F.length + var3_3;
            if (this.N.d() < var7_4) {
                this.N.a = Arrays.copyOf(d.F, var7_4 + var3_3);
            }
            var1_1.b(this.N.a, d.F.length, var3_3);
            this.N.c(0);
            this.N.b(var7_4);
            return;
        }
        var5_6 = var2_2.y;
        if (this.T) ** GOTO lbl77
        if (!var2_2.e) ** GOTO lbl56
        this.C &= -1073741825;
        if (!this.U) {
            var1_1.b(this.d.a, 0, 1);
            ++this.S;
            if ((this.d.a[0] & 128) == 128) {
                throw new i("Extension bit is set in signal byte");
            }
            this.X = this.d.a[0];
            this.U = true;
        }
        var7_5 = (this.X & 1) == 1 ? 1 : 0;
        if (var7_5 == 0) ** GOTO lbl76
        var7_5 = (this.X & 2) == 2 ? 1 : 0;
        this.C |= 1073741824;
        if (!this.V) {
            var1_1.b(this.O.a, 0, 8);
            this.S += 8;
            this.V = true;
            var6_7 = this.d.a;
            var8_8 = var7_5 != 0 ? 128 : 0;
            var6_7[0] = (byte)(var8_8 | 8);
            this.d.c(0);
            var5_6.a(this.d, 1);
            ++this.aa;
            this.O.c(0);
            var5_6.a(this.O, 8);
            this.aa += 8;
        }
        if (var7_5 == 0) ** GOTO lbl76
        if (!this.W) {
            var1_1.b(this.d.a, 0, 1);
            ++this.S;
            this.d.c(0);
            this.Y = this.d.e();
            this.W = true;
        }
        var7_5 = this.Y << 2;
        this.d.a(var7_5);
        var1_1.b(this.d.a, 0, var7_5);
        this.S = var7_5 + this.S;
        var4_9 = (short)(this.Y / 2 + 1);
        var10_10 = var4_9 * 6 + 2;
        if (this.Q == null || this.Q.capacity() < var10_10) {
            this.Q = ByteBuffer.allocate(var10_10);
        }
        this.Q.position(0);
        this.Q.putShort(var4_9);
        var8_8 = 0;
        ** GOTO lbl59
lbl56: // 1 sources:
        if (var2_2.f != null) {
            this.M.a(var2_2.f, var2_2.f.length);
        }
        ** GOTO lbl76
lbl59: // 2 sources:
        for (var7_5 = 0; var7_5 < this.Y; ++var7_5) {
            var9_11 = this.d.o();
            if (var7_5 % 2 == 0) {
                this.Q.putShort((short)(var9_11 - var8_8));
            } else {
                this.Q.putInt(var9_11 - var8_8);
            }
            var8_8 = var9_11;
        }
        var7_5 = var3_3 - this.S - var8_8;
        if (this.Y % 2 == 1) {
            this.Q.putInt(var7_5);
        } else {
            this.Q.putShort((short)var7_5);
            this.Q.putInt(0);
        }
        this.P.a(this.Q.array(), var10_10);
        var5_6.a(this.P, var10_10);
        this.aa += var10_10;
lbl76: // 4 sources:
        this.T = true;
lbl77: // 2 sources:
        var3_3 = this.M.c + var3_3;
        if (!"V_MPEG4/ISO/AVC".equals(var2_2.a) && !"V_MPEGH/ISO/HEVC".equals(var2_2.a)) {
            while (this.S < var3_3) {
                this.a(var1_1, var5_6, var3_3 - this.S);
            }
        } else {
            var6_7 = this.K.a;
            var6_7[0] = 0;
            var6_7[1] = 0;
            var6_7[2] = 0;
            var7_5 = var2_2.z;
            var8_8 = 4 - var2_2.z;
            while (this.S < var3_3) {
                if (this.Z == 0) {
                    var9_11 = Math.min(var7_5, this.M.b());
                    var1_1.b(var6_7, var8_8 + var9_11, var7_5 - var9_11);
                    if (var9_11 > 0) {
                        this.M.a(var6_7, var8_8, var9_11);
                    }
                    this.S += var7_5;
                    this.K.c(0);
                    this.Z = this.K.o();
                    this.J.c(0);
                    var5_6.a(this.J, 4);
                    this.aa += 4;
                    continue;
                }
                this.Z -= this.a(var1_1, var5_6, this.Z);
            }
        }
        if ("A_VORBIS".equals(var2_2.a) == false) return;
        this.L.c(0);
        var5_6.a(this.L, 4);
        this.aa += 4;
    }

    @Override
    public final void a(h h2) {
        this.E = h2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final boolean a(g var1_1) {
        var2_2 = new e();
        var7_3 = var1_1.d();
        var5_4 = var7_3 == -1 || var7_3 > 1024 ? 1024 : var7_3;
        var3_5 = (int)var5_4;
        var1_1.c(var2_2.a.a, 0, 4);
        var5_4 = var2_2.a.i();
        var2_2.b = 4;
        while (var5_4 != 440786851) {
            var2_2.b = var4_6 = var2_2.b + 1;
            if (var4_6 == var3_5) return false;
            var1_1.c(var2_2.a.a, 0, 1);
            var5_4 = var5_4 << 8 & -256 | (long)(var2_2.a.a[0] & 255);
        }
        var5_4 = var2_2.a(var1_1);
        var9_7 = var2_2.b;
        if (var5_4 == Long.MIN_VALUE) return false;
        if (var7_3 == -1 || var9_7 + var5_4 < var7_3) ** GOTO lbl22
        return false;
lbl-1000: // 1 sources:
        {
            if (var7_3 != 0) {
                var1_1.c((int)var7_3);
                var2_2.b = (int)(var7_3 + (long)var2_2.b);
            }
lbl22: // 4 sources:
            if ((long)var2_2.b >= var9_7 + var5_4) {
                if ((long)var2_2.b != var5_4 + var9_7) return false;
                return true;
            }
            if (var2_2.a(var1_1) == Long.MIN_VALUE) return false;
            var7_3 = var2_2.a(var1_1);
            if (var7_3 < 0) return false;
            ** while (var7_3 <= Integer.MAX_VALUE)
        }
lbl29: // 1 sources:
        return false;
    }

    final class a
    implements c {
        private a() {
        }

        /* synthetic */ a(byte by2) {
            this();
        }

        @Override
        public final int a(int n2) {
            return d.a(n2);
        }

        @Override
        public final void a(int n2, double d2) {
            d d3 = d.this;
            switch (n2) {
                default: {
                    return;
                }
                case 17545: {
                    d3.i = (long)d2;
                    return;
                }
                case 181: 
            }
            d3.k.s = (int)d2;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        @Override
        public final void a(int var1_1, int var2_2, g var3_3) {
            var4_4 = d.this;
            switch (var1_1) {
                default: {
                    throw new i("Unexpected id: " + var1_1);
                }
                case 21419: {
                    Arrays.fill(var4_4.e.a, 0);
                    var3_3.b(var4_4.e.a, 4 - var2_2, var2_2);
                    var4_4.e.c(0);
                    var4_4.m = (int)var4_4.e.i();
                    return;
                }
                case 25506: {
                    var4_4.k.h = new byte[var2_2];
                    var3_3.b(var4_4.k.h, 0, var2_2);
                    return;
                }
                case 30322: {
                    var4_4.k.o = new byte[var2_2];
                    var3_3.b(var4_4.k.o, 0, var2_2);
                    return;
                }
                case 16981: {
                    var4_4.k.f = new byte[var2_2];
                    var3_3.b(var4_4.k.f, 0, var2_2);
                    return;
                }
                case 18402: {
                    var4_4.k.g = new byte[var2_2];
                    var3_3.b(var4_4.k.g, 0, var2_2);
                    return;
                }
                case 161: 
                case 163: 
            }
            if (var4_4.u == 0) {
                var4_4.A = (int)var4_4.b.a(var3_3, false, true, 8);
                var4_4.B = var4_4.b.a;
                var4_4.w = -9223372036854775807L;
                var4_4.u = 1;
                var4_4.d.a();
            }
            if ((var5_5 = (b)var4_4.c.get(var4_4.A)) == null) {
                var3_3.b(var2_2 - var4_4.B);
                var4_4.u = 0;
                return;
            }
            if (var4_4.u != 1) ** GOTO lbl83
            var4_4.a(var3_3, 3);
            var7_6 = (var4_4.d.a[2] & 6) >> 1;
            if (var7_6 != 0) ** GOTO lbl46
            var4_4.y = 1;
            var4_4.z = d.a(var4_4.z, 1);
            var4_4.z[0] = var2_2 - var4_4.B - 3;
            ** GOTO lbl72
lbl46: // 1 sources:
            if (var1_1 != 163) {
                throw new i("Lacing only supported in SimpleBlocks.");
            }
            var4_4.a(var3_3, 4);
            var4_4.y = (var4_4.d.a[3] & 255) + 1;
            var4_4.z = d.a(var4_4.z, var4_4.y);
            if (var7_6 != 2) ** GOTO lbl55
            var2_2 = (var2_2 - var4_4.B - 4) / var4_4.y;
            Arrays.fill(var4_4.z, 0, var4_4.y, var2_2);
            ** GOTO lbl72
lbl55: // 1 sources:
            if (var7_6 == 1) {
                var9_9 = 0;
                var7_6 = 4;
                for (var8_8 = 0; var8_8 < var4_4.y - 1; var9_9 += var4_4.z[var8_8], ++var8_8) {
                    var4_4.z[var8_8] = 0;
                    var10_10 = var7_6;
                    do {
                        var7_6 = var10_10 + 1;
                        var4_4.a(var3_3, var7_6);
                        var11_11 = var4_4.d.a[var7_6 - 1] & 255;
                        var6_7 = var4_4.z;
                        var6_7[var8_8] = var6_7[var8_8] + var11_11;
                        var10_10 = var7_6;
                    } while (var11_11 == 255);
                }
                var4_4.z[var4_4.y - 1] = var2_2 - var4_4.B - var7_6 - var9_9;
            }
            ** GOTO lbl94
lbl72: // 4 sources:
            do {
                var2_2 = var4_4.d.a[0];
                var7_6 = var4_4.d.a[1];
                var4_4.v = var4_4.q + var4_4.a(var2_2 << 8 | var7_6 & 255);
                var2_2 = (var4_4.d.a[2] & 8) == 8 ? 1 : 0;
                var7_6 = var5_5.c == 2 || var1_1 == 163 && (var4_4.d.a[2] & 128) == 128 ? 1 : 0;
                var7_6 = var7_6 != 0 ? 1 : 0;
                var2_2 = var2_2 != 0 ? Integer.MIN_VALUE : 0;
                var4_4.C = var2_2 | var7_6;
                var4_4.u = 2;
                var4_4.x = 0;
lbl83: // 2 sources:
                if (var1_1 != 163) {
                    var4_4.a(var3_3, var5_5, var4_4.z[0]);
                    return;
                }
                do {
                    if (var4_4.x >= var4_4.y) {
                        var4_4.u = 0;
                        return;
                    }
                    var4_4.a(var3_3, var5_5, var4_4.z[var4_4.x]);
                    var4_4.a(var5_5, var4_4.v + (long)(var4_4.x * var5_5.d / 1000));
                    ++var4_4.x;
                } while (true);
                break;
            } while (true);
lbl94: // 1 sources:
            if (var7_6 != 3) throw new i("Unexpected lacing value: " + var7_6);
            var9_9 = 0;
            var7_6 = 4;
            var8_8 = 0;
            do {
                if (var8_8 < var4_4.y - 1) {
                    var4_4.z[var8_8] = 0;
                    var11_11 = var7_6 + 1;
                    var4_4.a(var3_3, var11_11);
                    if (var4_4.d.a[var11_11 - 1] == 0) {
                        throw new i("No valid varint length mask found");
                    }
                } else {
                    var4_4.z[var4_4.y - 1] = var2_2 - var4_4.B - var7_6 - var9_9;
                    ** continue;
                }
                var16_15 = 0;
                var10_10 = 0;
                do {
                    var7_6 = var11_11;
                    var14_14 = var16_15;
                    if (var10_10 >= 8) ** GOTO lbl128
                    var12_12 = 1 << 7 - var10_10;
                    if ((var4_4.d.a[var11_11 - 1] & var12_12) != 0) {
                        var13_13 = var11_11 - 1;
                        var4_4.a(var3_3, var11_11 += var10_10);
                        var6_7 = var4_4.d.a;
                        var16_15 = var6_7[var13_13] & 255 & ~ var12_12;
                        for (var7_6 = var13_13 + 1; var7_6 < var11_11; ++var7_6) {
                            var16_15 = var16_15 << 8 | (long)(var4_4.d.a[var7_6] & 255);
                        }
                        var7_6 = var11_11;
                        var14_14 = var16_15;
                        if (var8_8 > 0) {
                            var14_14 = var16_15 - ((1 << var10_10 * 7 + 6) - 1);
                            var7_6 = var11_11;
                        }
lbl128: // 4 sources:
                        if (var14_14 < Integer.MIN_VALUE) throw new i("EBML lacing sample size out of range.");
                        if (var14_14 <= Integer.MAX_VALUE) break;
                        throw new i("EBML lacing sample size out of range.");
                    }
                    ++var10_10;
                } while (true);
                var10_10 = (int)var14_14;
                var6_7 = var4_4.z;
                if (var8_8 != 0) {
                    var10_10 += var4_4.z[var8_8 - 1];
                }
                var6_7[var8_8] = var10_10;
                var9_9 += var4_4.z[var8_8];
                ++var8_8;
            } while (true);
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        @Override
        public final void a(int n2, long l2) {
            boolean bl2 = true;
            boolean bl3 = true;
            Object object = d.this;
            switch (n2) {
                default: {
                    return;
                }
                case 17143: {
                    if (l2 == 1) return;
                    throw new i("EBMLReadVersion " + l2 + " not supported");
                }
                case 17029: {
                    if (l2 < 1) throw new i("DocTypeReadVersion " + l2 + " not supported");
                    if (l2 <= 2) return;
                    throw new i("DocTypeReadVersion " + l2 + " not supported");
                }
                case 21420: {
                    object.n = object.g + l2;
                    return;
                }
                case 2807729: {
                    object.h = l2;
                    return;
                }
                case 176: {
                    object.k.j = (int)l2;
                    return;
                }
                case 186: {
                    object.k.k = (int)l2;
                    return;
                }
                case 21680: {
                    object.k.l = (int)l2;
                    return;
                }
                case 21690: {
                    object.k.m = (int)l2;
                    return;
                }
                case 21682: {
                    object.k.n = (int)l2;
                    return;
                }
                case 215: {
                    object.k.b = (int)l2;
                    return;
                }
                case 136: {
                    object = object.k;
                    if (l2 != 1) {
                        bl3 = false;
                    }
                    object.v = bl3;
                    return;
                }
                case 21930: {
                    object = object.k;
                    bl3 = l2 == 1 ? bl2 : false;
                    object.w = bl3;
                    return;
                }
                case 131: {
                    object.k.c = (int)l2;
                    return;
                }
                case 2352003: {
                    object.k.d = (int)l2;
                    return;
                }
                case 22186: {
                    object.k.t = l2;
                    return;
                }
                case 22203: {
                    object.k.u = l2;
                    return;
                }
                case 159: {
                    object.k.q = (int)l2;
                    return;
                }
                case 25188: {
                    object.k.r = (int)l2;
                    return;
                }
                case 251: {
                    object.D = true;
                    return;
                }
                case 20529: {
                    if (l2 == 0) return;
                    throw new i("ContentEncodingOrder " + l2 + " not supported");
                }
                case 20530: {
                    if (l2 == 1) return;
                    throw new i("ContentEncodingScope " + l2 + " not supported");
                }
                case 16980: {
                    if (l2 == 3) return;
                    throw new i("ContentCompAlgo " + l2 + " not supported");
                }
                case 18401: {
                    if (l2 == 5) return;
                    throw new i("ContentEncAlgo " + l2 + " not supported");
                }
                case 18408: {
                    if (l2 == 1) return;
                    throw new i("AESSettingsCipherMode " + l2 + " not supported");
                }
                case 179: {
                    object.r.a(object.a(l2));
                    return;
                }
                case 241: {
                    if (object.t) return;
                    object.s.a(l2);
                    object.t = true;
                    return;
                }
                case 231: {
                    object.q = object.a(l2);
                    return;
                }
                case 155: {
                    object.w = object.a(l2);
                    return;
                }
                case 21432: 
            }
            switch ((int)l2) {
                default: {
                    return;
                }
                case 0: {
                    object.k.p = 0;
                    return;
                }
                case 1: {
                    object.k.p = 2;
                    return;
                }
                case 3: 
            }
            object.k.p = 1;
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        @Override
        public final void a(int n2, long l2, long l3) {
            d d2 = d.this;
            switch (n2) {
                default: {
                    return;
                }
                case 408125543: {
                    if (d2.g != -1 && d2.g != l2) {
                        throw new i("Multiple Segment elements not supported");
                    }
                    d2.g = l2;
                    d2.f = l3;
                    return;
                }
                case 19899: {
                    d2.m = -1;
                    d2.n = -1;
                    return;
                }
                case 475249515: {
                    d2.r = new com.google.android.exoplayer2.i.e();
                    d2.s = new com.google.android.exoplayer2.i.e();
                    return;
                }
                case 187: {
                    d2.t = false;
                    return;
                }
                case 524531317: {
                    if (d2.l) return;
                    if (d2.p != -1) {
                        d2.o = true;
                        return;
                    }
                    d2.E.a(new m.a(d2.j));
                    d2.l = true;
                    return;
                }
                case 160: {
                    d2.D = false;
                    return;
                }
                case 20533: {
                    d2.k.e = true;
                    return;
                }
                case 174: 
            }
            d2.k = new b(0);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final void a(int n2, String string) {
            d d2 = d.this;
            switch (n2) {
                case 17026: {
                    if (!"webm".equals(string) && !"matroska".equals(string)) {
                        throw new i("DocType " + string + " not supported");
                    }
                }
                default: {
                    return;
                }
                case 134: {
                    d2.k.a = string;
                    return;
                }
                case 2274716: 
            }
            d2.k.x = string;
        }

        @Override
        public final boolean b(int n2) {
            return d.b(n2);
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        @Override
        public final void c(int var1_1) {
            var7_2 = d.this;
            switch (var1_1) {
                default: {
                    return;
                }
                case 357149030: {
                    if (var7_2.h == -9223372036854775807L) {
                        var7_2.h = 1000000;
                    }
                    if (var7_2.i == -9223372036854775807L) return;
                    var7_2.j = var7_2.a(var7_2.i);
                    return;
                }
                case 19899: {
                    if (var7_2.m == -1) throw new i("Mandatory element SeekID or SeekPosition not found");
                    if (var7_2.n == -1) {
                        throw new i("Mandatory element SeekID or SeekPosition not found");
                    }
                    if (var7_2.m != 475249515) return;
                    var7_2.p = var7_2.n;
                    return;
                }
                case 475249515: {
                    if (var7_2.l != false) return;
                    var5_3 = var7_2.E;
                    if (var7_2.g == -1 || var7_2.j == -9223372036854775807L || var7_2.r == null || var7_2.r.a == 0 || var7_2.s == null || var7_2.s.a != var7_2.r.a) {
                        var7_2.r = null;
                        var7_2.s = null;
                        var4_5 = new int[](var7_2.j);
                    } else {
                        var10_7 = var7_2.r.a;
                        var4_5 = new int[var10_7];
                        var6_9 = new long[var10_7];
                        var8_13 = new long[var10_7];
                        var9_15 = new long[var10_7];
                        for (var1_1 = 0; var1_1 < var10_7; ++var1_1) {
                            var9_15[var1_1] = var7_2.r.a(var1_1);
                            var6_9[var1_1] = var7_2.g + var7_2.s.a(var1_1);
                        }
                        for (var1_1 = 0; var1_1 < var10_7 - 1; ++var1_1) {
                            var4_5[var1_1] = (int)(var6_9[var1_1 + 1] - var6_9[var1_1]);
                            var8_13[var1_1] = var9_15[var1_1 + 1] - var9_15[var1_1];
                        }
                        var4_5[var10_7 - 1] = (int)(var7_2.g + var7_2.f - var6_9[var10_7 - 1]);
                        var8_13[var10_7 - 1] = var7_2.j - var9_15[var10_7 - 1];
                        var7_2.r = null;
                        var7_2.s = null;
                        var4_5 = new com.google.android.exoplayer2.c.a((int[])var4_5, var6_9, var8_13, var9_15);
                    }
                    var5_3.a((m)var4_5);
                    var7_2.l = true;
                    return;
                }
                case 160: {
                    if (var7_2.u != 2) return;
                    if (!var7_2.D) {
                        var7_2.C |= 1;
                    }
                    var7_2.a((b)var7_2.c.get(var7_2.A), var7_2.v);
                    var7_2.u = 0;
                    return;
                }
                case 25152: {
                    if (var7_2.k.e == false) return;
                    if (var7_2.k.g == null) {
                        throw new i("Encrypted Track found but ContentEncKeyID was not found");
                    }
                    var7_2.k.i = new DrmInitData(new DrmInitData.SchemeData[]{new DrmInitData.SchemeData(com.google.android.exoplayer2.a.b, "video/webm", var7_2.k.g)});
                    return;
                }
                case 28032: {
                    if (var7_2.k.e == false) return;
                    if (var7_2.k.f == null) return;
                    throw new i("Combining encryption and compression is not supported");
                }
                case 174: {
                    var4_6 = var7_2.k.a;
                    var1_1 = "V_VP8".equals(var4_6) != false || "V_VP9".equals(var4_6) != false || "V_MPEG2".equals(var4_6) != false || "V_MPEG4/ISO/SP".equals(var4_6) != false || "V_MPEG4/ISO/ASP".equals(var4_6) != false || "V_MPEG4/ISO/AP".equals(var4_6) != false || "V_MPEG4/ISO/AVC".equals(var4_6) != false || "V_MPEGH/ISO/HEVC".equals(var4_6) != false || "V_MS/VFW/FOURCC".equals(var4_6) != false || "V_THEORA".equals(var4_6) != false || "A_OPUS".equals(var4_6) != false || "A_VORBIS".equals(var4_6) != false || "A_AAC".equals(var4_6) != false || "A_MPEG/L2".equals(var4_6) != false || "A_MPEG/L3".equals(var4_6) != false || "A_AC3".equals(var4_6) != false || "A_EAC3".equals(var4_6) != false || "A_TRUEHD".equals(var4_6) != false || "A_DTS".equals(var4_6) != false || "A_DTS/EXPRESS".equals(var4_6) != false || "A_DTS/LOSSLESS".equals(var4_6) != false || "A_FLAC".equals(var4_6) != false || "A_MS/ACM".equals(var4_6) != false || "A_PCM/INT/LIT".equals(var4_6) != false || "S_TEXT/UTF8".equals(var4_6) != false || "S_VOBSUB".equals(var4_6) != false || "S_HDMV/PGS".equals(var4_6) != false ? 1 : 0;
                    if (var1_1 == 0) ** GOTO lbl362
                    var8_14 = var7_2.k;
                    var9_16 = var7_2.E;
                    var13_17 = var7_2.k.b;
                    var11_18 = -1;
                    var10_8 = -1;
                    var5_4 = null;
                    var4_6 = var8_14.a;
                    var1_1 = -1;
                    switch (var4_6.hashCode()) {
                        case 82338133: {
                            if (var4_6.equals("V_VP8")) {
                                var1_1 = 0;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 82338134: {
                            if (var4_6.equals("V_VP9")) {
                                var1_1 = 1;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 1809237540: {
                            if (var4_6.equals("V_MPEG2")) {
                                var1_1 = 2;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -2095575984: {
                            if (var4_6.equals("V_MPEG4/ISO/SP")) {
                                var1_1 = 3;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -538363189: {
                            if (var4_6.equals("V_MPEG4/ISO/ASP")) {
                                var1_1 = 4;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -2095576542: {
                            if (var4_6.equals("V_MPEG4/ISO/AP")) {
                                var1_1 = 5;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -538363109: {
                            if (var4_6.equals("V_MPEG4/ISO/AVC")) {
                                var1_1 = 6;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 855502857: {
                            if (var4_6.equals("V_MPEGH/ISO/HEVC")) {
                                var1_1 = 7;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -1373388978: {
                            if (var4_6.equals("V_MS/VFW/FOURCC")) {
                                var1_1 = 8;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 444813526: {
                            if (var4_6.equals("V_THEORA")) {
                                var1_1 = 9;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -1730367663: {
                            if (var4_6.equals("A_VORBIS")) {
                                var1_1 = 10;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 1951062397: {
                            if (var4_6.equals("A_OPUS")) {
                                var1_1 = 11;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 62923557: {
                            if (var4_6.equals("A_AAC")) {
                                var1_1 = 12;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -1482641358: {
                            if (var4_6.equals("A_MPEG/L2")) {
                                var1_1 = 13;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -1482641357: {
                            if (var4_6.equals("A_MPEG/L3")) {
                                var1_1 = 14;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 62923603: {
                            if (var4_6.equals("A_AC3")) {
                                var1_1 = 15;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 1950749482: {
                            if (var4_6.equals("A_EAC3")) {
                                var1_1 = 16;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -1784763192: {
                            if (var4_6.equals("A_TRUEHD")) {
                                var1_1 = 17;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 62927045: {
                            if (var4_6.equals("A_DTS")) {
                                var1_1 = 18;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 542569478: {
                            if (var4_6.equals("A_DTS/EXPRESS")) {
                                var1_1 = 19;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -356037306: {
                            if (var4_6.equals("A_DTS/LOSSLESS")) {
                                var1_1 = 20;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 1950789798: {
                            if (var4_6.equals("A_FLAC")) {
                                var1_1 = 21;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -1985379776: {
                            if (var4_6.equals("A_MS/ACM")) {
                                var1_1 = 22;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 725957860: {
                            if (var4_6.equals("A_PCM/INT/LIT")) {
                                var1_1 = 23;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case 1422270023: {
                            if (var4_6.equals("S_TEXT/UTF8")) {
                                var1_1 = 24;
                                ** break;
                            }
                            ** GOTO lbl205
                        }
                        case -425012669: {
                            if (var4_6.equals("S_VOBSUB")) {
                                var1_1 = 25;
                            }
                        }
lbl205: // 54 sources:
                        default: {
                            ** GOTO lbl210
                        }
                        case 99146302: 
                    }
                    if (var4_6.equals("S_HDMV/PGS")) {
                        var1_1 = 26;
                    }
lbl210: // 4 sources:
                    switch (var1_1) {
                        default: {
                            throw new i("Unrecognized codec identifier.");
                        }
                        case 0: {
                            var4_6 = "video/x-vnd.on2.vp8";
                            var1_1 = var11_18;
                            break;
                        }
                        case 1: {
                            var4_6 = "video/x-vnd.on2.vp9";
                            var1_1 = var11_18;
                            break;
                        }
                        case 2: {
                            var4_6 = "video/mpeg2";
                            var1_1 = var11_18;
                            break;
                        }
                        case 3: 
                        case 4: 
                        case 5: {
                            var6_10 = "video/mp4v-es";
                            var4_6 = var8_14.h == null ? null : Collections.singletonList(var8_14.h);
                            var5_4 = var4_6;
                            var4_6 = var6_10;
                            var1_1 = var11_18;
                            break;
                        }
                        case 6: {
                            var4_6 = "video/avc";
                            var6_11 = com.google.android.exoplayer2.j.a.a(new com.google.android.exoplayer2.i.i(var8_14.h));
                            var5_4 = var6_11.a;
                            var8_14.z = var6_11.b;
                            var1_1 = var11_18;
                            break;
                        }
                        case 7: {
                            var4_6 = "video/hevc";
                            var6_12 = com.google.android.exoplayer2.j.b.a(new com.google.android.exoplayer2.i.i(var8_14.h));
                            var5_4 = var6_12.a;
                            var8_14.z = var6_12.b;
                            var1_1 = var11_18;
                            break;
                        }
                        case 8: {
                            var5_4 = b.a(new com.google.android.exoplayer2.i.i(var8_14.h));
                            var4_6 = var5_4 == null ? "video/x-unknown" : "video/wvc1";
                            var1_1 = var11_18;
                            break;
                        }
                        case 9: {
                            var4_6 = "video/x-unknown";
                            var1_1 = var11_18;
                            break;
                        }
                        case 10: {
                            var4_6 = "audio/vorbis";
                            var1_1 = 8192;
                            var5_4 = b.a(var8_14.h);
                            break;
                        }
                        case 11: {
                            var4_6 = "audio/opus";
                            var1_1 = 5760;
                            var5_4 = new ArrayList<byte[]>(3);
                            var5_4.add((byte[])var8_14.h);
                            var5_4.add(ByteBuffer.allocate(8).order(ByteOrder.nativeOrder()).putLong(var8_14.t).array());
                            var5_4.add(ByteBuffer.allocate(8).order(ByteOrder.nativeOrder()).putLong(var8_14.u).array());
                            break;
                        }
                        case 12: {
                            var4_6 = "audio/mp4a-latm";
                            var5_4 = Collections.singletonList(var8_14.h);
                            var1_1 = var11_18;
                            break;
                        }
                        case 13: {
                            var4_6 = "audio/mpeg-L2";
                            var1_1 = 4096;
                            break;
                        }
                        case 14: {
                            var4_6 = "audio/mpeg";
                            var1_1 = 4096;
                            break;
                        }
                        case 15: {
                            var4_6 = "audio/ac3";
                            var1_1 = var11_18;
                            break;
                        }
                        case 16: {
                            var4_6 = "audio/eac3";
                            var1_1 = var11_18;
                            break;
                        }
                        case 17: {
                            var4_6 = "audio/true-hd";
                            var1_1 = var11_18;
                            break;
                        }
                        case 18: 
                        case 19: {
                            var4_6 = "audio/vnd.dts";
                            var1_1 = var11_18;
                            break;
                        }
                        case 20: {
                            var4_6 = "audio/vnd.dts.hd";
                            var1_1 = var11_18;
                            break;
                        }
                        case 21: {
                            var4_6 = "audio/x-flac";
                            var5_4 = Collections.singletonList(var8_14.h);
                            var1_1 = var11_18;
                            break;
                        }
                        case 22: {
                            var4_6 = "audio/raw";
                            if (!b.b(new com.google.android.exoplayer2.i.i(var8_14.h))) {
                                throw new i("Non-PCM MS/ACM is unsupported");
                            }
                            var12_19 = o.b(var8_14.r);
                            var1_1 = var11_18;
                            var10_8 = var12_19;
                            if (var12_19 != 0) break;
                            throw new i("Unsupported PCM bit depth: " + var8_14.r);
                        }
                        case 23: {
                            var4_6 = "audio/raw";
                            var12_19 = o.b(var8_14.r);
                            var1_1 = var11_18;
                            var10_8 = var12_19;
                            if (var12_19 != 0) break;
                            throw new i("Unsupported PCM bit depth: " + var8_14.r);
                        }
                        case 24: {
                            var4_6 = "application/x-subrip";
                            var1_1 = var11_18;
                            break;
                        }
                        case 25: {
                            var4_6 = "application/vobsub";
                            var5_4 = Collections.singletonList(var8_14.h);
                            var1_1 = var11_18;
                            break;
                        }
                        case 26: {
                            var4_6 = "application/pgs";
                            var1_1 = var11_18;
                        }
                    }
                    var11_18 = var8_14.w != false ? 1 : 0;
                    var12_19 = var8_14.v != false ? 2 : 0;
                    var11_18 = var11_18 | 0 | var12_19;
                    if (a.a.a.a.d.d((String)var4_6)) {
                        var4_6 = Format.a(Integer.toString(var13_17), (String)var4_6, -1, var1_1, var8_14.q, var8_14.s, var10_8, var5_4, var8_14.i, var11_18, var8_14.x);
                    } else if (a.a.a.a.d.e((String)var4_6)) {
                        if (var8_14.n == 0) {
                            var10_8 = var8_14.l == -1 ? var8_14.j : var8_14.l;
                            var8_14.l = var10_8;
                            var10_8 = var8_14.m == -1 ? var8_14.k : var8_14.m;
                            var8_14.m = var10_8;
                        }
                        var2_21 = var3_20 = -1.0f;
                        if (var8_14.l != -1) {
                            var2_21 = var3_20;
                            if (var8_14.m != -1) {
                                var2_21 = (float)(var8_14.k * var8_14.l) / (float)(var8_14.j * var8_14.m);
                            }
                        }
                        var4_6 = Format.a(Integer.toString(var13_17), (String)var4_6, var1_1, var8_14.j, var8_14.k, var5_4, -1, var2_21, var8_14.o, var8_14.p, var8_14.i);
                    } else if ("application/x-subrip".equals(var4_6)) {
                        var4_6 = Format.a(Integer.toString(var13_17), (String)var4_6, var11_18, var8_14.x, var8_14.i);
                    } else {
                        if (!"application/vobsub".equals(var4_6)) {
                            if ("application/pgs".equals(var4_6) == false) throw new i("Unexpected MIME type.");
                        }
                        var4_6 = Format.a(Integer.toString(var13_17), (String)var4_6, var5_4, var8_14.x, var8_14.i);
                    }
                    var8_14.y = var9_16.a(var8_14.b);
                    var8_14.y.a((Format)var4_6);
                    var7_2.c.put(var7_2.k.b, (Object)var7_2.k);
lbl362: // 2 sources:
                    var7_2.k = null;
                    return;
                }
                case 374648427: 
            }
            if (var7_2.c.size() == 0) {
                throw new i("No valid tracks were found");
            }
            var7_2.E.b();
        }
    }

    static final class b {
        public String a;
        public int b;
        public int c;
        public int d;
        public boolean e;
        public byte[] f;
        public byte[] g;
        public byte[] h;
        public DrmInitData i;
        public int j = -1;
        public int k = -1;
        public int l = -1;
        public int m = -1;
        public int n = 0;
        public byte[] o = null;
        public int p = -1;
        public int q = 1;
        public int r = -1;
        public int s = 8000;
        public long t = 0;
        public long u = 0;
        public boolean v;
        public boolean w = true;
        String x = "eng";
        public n y;
        public int z;

        private b() {
        }

        /* synthetic */ b(byte by2) {
            this();
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        static List<byte[]> a(com.google.android.exoplayer2.i.i var0) {
            var0.d(16);
            if (var0.j() != 826496599) {
                return null;
            }
            var1_2 = var0.b + 20;
            var0 = var0.a;
            ** while (var1_2 < var0.length - 4)
lbl-1000: // 1 sources:
            {
                if (var0[var1_2] == 0 && var0[var1_2 + 1] == 0 && var0[var1_2 + 2] == 1 && var0[var1_2 + 3] == 15) {
                    return Collections.singletonList(Arrays.copyOfRange(var0, var1_2, var0.length));
                }
                ** GOTO lbl14
                catch (ArrayIndexOutOfBoundsException var0_1) {
                    throw new i("Error parsing FourCC VC1 codec private");
                }
lbl14: // 1 sources:
                ++var1_2;
                continue;
            }
lbl-1000: // 1 sources:
            {
                throw new i("Failed to find FourCC VC1 initialization data");
            }
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        static List<byte[]> a(byte[] var0) {
            var5_2 = 0;
            if (var0[0] != 2) {
                throw new i("Error parsing vorbis codec private");
            }
            var3_3 = 0;
            var4_4 = 1;
            while (var0[var4_4] == -1) {
                ++var4_4;
                var3_3 += 255;
            }
            var6_8 = var4_4 + 1;
            var7_5 = var3_3 + var0[var4_4];
            var4_4 = var6_8;
            var3_3 = var5_2;
            while (var0[var4_4] == -1) {
                var3_3 += 255;
                ++var4_4;
            }
            var5_2 = var4_4 + 1;
            var4_4 = var0[var4_4];
            if (var0[var5_2] == true) ** GOTO lbl24
            try {
                throw new i("Error parsing vorbis codec private");
lbl24: // 1 sources:
                var1_6 = new byte[var7_5];
                System.arraycopy(var0, var5_2, var1_6, 0, var7_5);
                var5_2 = var7_5 + var5_2;
            }
            catch (ArrayIndexOutOfBoundsException var0_1) {
                throw new i("Error parsing vorbis codec private");
            }
            if (var0[var5_2] != 3) {
                throw new i("Error parsing vorbis codec private");
            }
            if (var0[var3_3 = var3_3 + var4_4 + var5_2] != 5) {
                throw new i("Error parsing vorbis codec private");
            }
            var2_7 = new byte[var0.length - var3_3];
            System.arraycopy(var0, var3_3, var2_7, 0, var0.length - var3_3);
            var0 = new ArrayList<E>(2);
            var0.add(var1_6);
            var0.add(var2_7);
            return var0;
        }

        static boolean b(com.google.android.exoplayer2.i.i i2) {
            block5 : {
                long l2;
                long l3;
                try {
                    int n2 = i2.g();
                    if (n2 == 1) {
                        return true;
                    }
                    if (n2 != 65534) break block5;
                }
                catch (ArrayIndexOutOfBoundsException var0_1) {
                    throw new i("Error parsing MS/ACM codec private");
                }
                i2.c(24);
                if (i2.m() != H.getMostSignificantBits() || (l3 = i2.m()) != (l2 = H.getLeastSignificantBits())) {
                    return false;
                }
            }
            return false;
            return true;
        }
    }

}

