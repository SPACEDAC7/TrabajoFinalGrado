/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.b;

import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.i.i;

final class e {
    final i a = new i(8);
    int b;

    final long a(g g2) {
        int n2 = 0;
        g2.c(this.a.a, 0, 1);
        int n3 = this.a.a[0] & 255;
        if (n3 == 0) {
            return Long.MIN_VALUE;
        }
        int n4 = 128;
        int n5 = 0;
        while ((n3 & n4) == 0) {
            ++n5;
            n4 >>= 1;
        }
        n3 = ~ n4 & n3;
        g2.c(this.a.a, 1, n5);
        n4 = n2;
        n2 = n3;
        while (n4 < n5) {
            n2 = (n2 << 8) + (this.a.a[n4 + 1] & 255);
            ++n4;
        }
        this.b += n5 + 1;
        return n2;
    }
}

