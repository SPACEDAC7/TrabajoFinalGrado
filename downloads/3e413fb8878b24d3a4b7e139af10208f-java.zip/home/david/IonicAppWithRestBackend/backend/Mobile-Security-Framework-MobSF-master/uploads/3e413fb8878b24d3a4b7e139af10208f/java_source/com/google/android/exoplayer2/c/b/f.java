/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.b;

import com.google.android.exoplayer2.c.g;

final class f {
    private static final long[] b = new long[]{128, 64, 32, 16, 8, 4, 2, 1};
    int a;
    private final byte[] c = new byte[8];
    private int d;

    public static int a(int n2) {
        for (int i2 = 0; i2 < b.length; ++i2) {
            if ((b[i2] & (long)n2) == 0) continue;
            return i2 + 1;
        }
        return -1;
    }

    public static long a(byte[] arrby, int n2, boolean bl2) {
        long l2;
        long l3 = l2 = (long)arrby[0] & 255;
        if (bl2) {
            l3 = l2 & (b[n2 - 1] ^ -1);
        }
        for (int i2 = 1; i2 < n2; ++i2) {
            l3 = l3 << 8 | (long)arrby[i2] & 255;
        }
        return l3;
    }

    public final long a(g g2, boolean bl2, boolean bl3, int n2) {
        if (this.d == 0) {
            if (!g2.a(this.c, 0, 1, bl2)) {
                return -1;
            }
            this.a = f.a(this.c[0] & 255);
            if (this.a == -1) {
                throw new IllegalStateException("No valid varint length mask found");
            }
            this.d = 1;
        }
        if (this.a > n2) {
            this.d = 0;
            return -2;
        }
        if (this.a != 1) {
            g2.b(this.c, 1, this.a - 1);
        }
        this.d = 0;
        return f.a(this.c, this.a, bl3);
    }

    public final void a() {
        this.d = 0;
        this.a = 0;
    }
}

