/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

import com.google.android.exoplayer2.c.f;
import com.google.android.exoplayer2.c.i;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

public final class c
implements i {
    private static List<Class<? extends f>> a;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public c() {
        synchronized (c.class) {
            if (a == null) {
                ArrayList<Class<? extends f>> arrayList;
                arrayList = new ArrayList<Class<? extends f>>();
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.b.d").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_13) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.d.e").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_12) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.d.g").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_11) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.c.b").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_10) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.f.c").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_9) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.f.a").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_8) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.f.s").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_7) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.a.b").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_6) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.e.c").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_5) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.f.n").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_4) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.c.g.a").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_3) {}
                try {
                    arrayList.add(Class.forName("com.google.android.exoplayer2.ext.flac.FlacExtractor").asSubclass(f.class));
                }
                catch (ClassNotFoundException var2_2) {}
                a = arrayList;
            }
            return;
        }
    }

    @Override
    public final f[] a() {
        f[] arrf = new f[a.size()];
        for (int i2 = 0; i2 < arrf.length; ++i2) {
            try {
                arrf[i2] = a.get(i2).getConstructor(new Class[0]).newInstance(new Object[0]);
            }
            catch (Exception var1_2) {
                throw new IllegalStateException("Unexpected error creating default extractor", var1_2);
            }
        }
        return arrf;
    }
}

