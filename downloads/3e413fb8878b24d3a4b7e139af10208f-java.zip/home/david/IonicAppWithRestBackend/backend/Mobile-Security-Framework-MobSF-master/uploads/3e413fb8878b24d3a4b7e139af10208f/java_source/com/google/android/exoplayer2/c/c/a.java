/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.c;

import com.google.android.exoplayer2.c.c.b;

final class a
implements b.a {
    private final long a;
    private final int b;
    private final long c;

    /*
     * Enabled aggressive block sorting
     */
    public a(long l2, int n2, long l3) {
        this.a = l2;
        this.b = n2;
        l2 = l3 == -1 ? -9223372036854775807L : this.b(l3);
        this.c = l2;
    }

    @Override
    public final long a(long l2) {
        if (this.c == -9223372036854775807L) {
            return 0;
        }
        return this.a + (long)this.b * l2 / 8000000;
    }

    @Override
    public final long b() {
        return this.c;
    }

    @Override
    public final long b(long l2) {
        return (Math.max(0, l2 - this.a) * 1000000 << 3) / (long)this.b;
    }

    @Override
    public final boolean b_() {
        if (this.c != -9223372036854775807L) {
            return true;
        }
        return false;
    }
}

