/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.c;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.c.c;
import com.google.android.exoplayer2.c.c.d;
import com.google.android.exoplayer2.c.f;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.j;
import com.google.android.exoplayer2.c.k;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.Metadata;
import java.io.EOFException;

public final class b
implements f {
    public static final com.google.android.exoplayer2.c.i a = new com.google.android.exoplayer2.c.i(){

        @Override
        public final f[] a() {
            return new f[]{new b()};
        }
    };
    private static final int b = o.e("Xing");
    private static final int c = o.e("Info");
    private static final int d = o.e("VBRI");
    private final long e = -9223372036854775807L;
    private final com.google.android.exoplayer2.i.i f = new com.google.android.exoplayer2.i.i(10);
    private final k g = new k();
    private final j h = new j();
    private h i;
    private n j;
    private int k;
    private Metadata l;
    private a m;
    private long n = -9223372036854775807L;
    private long o;
    private int p;

    public b() {
        this(0);
    }

    private b(byte by2) {
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean a(g g2, boolean bl2) {
        int n2;
        byte[] arrby;
        boolean bl3;
        int n3;
        int n4;
        int n5;
        boolean bl4 = false;
        int n6 = bl2 ? 4096 : 131072;
        g2.a();
        if (g2.c() != 0) {
            n4 = 0;
            n2 = 0;
            n3 = 0;
            n5 = 0;
        } else {
            n3 = 0;
            do {
                g2.c(this.f.a, 0, 10);
                this.f.c(0);
                if (this.f.h() != com.google.android.exoplayer2.metadata.id3.a.a) break;
                this.f.d(3);
                n5 = this.f.n();
                n4 = n5 + 10;
                if (this.l == null) {
                    arrby = new byte[n4];
                    System.arraycopy(this.f.a, 0, arrby, 0, 10);
                    g2.c(arrby, 10, n5);
                    new com.google.android.exoplayer2.metadata.id3.a();
                    this.l = com.google.android.exoplayer2.metadata.id3.a.a(arrby, n4);
                    if (this.l != null) {
                        this.h.a(this.l);
                    }
                } else {
                    g2.c(n5);
                }
                n3 += n4;
            } while (true);
            g2.a();
            g2.c(n3);
            n2 = (int)g2.b();
            if (!bl2) {
                g2.b(n2);
            }
            n3 = 0;
            n5 = 0;
            n4 = 0;
        }
        while (g2.b(arrby = this.f.a, 0, 4, bl3 = n5 > 0)) {
            int n7;
            this.f.c(0);
            int n8 = this.f.k();
            if (n3 != 0 && (n8 & -128000) != (n3 & -128000) || (n7 = k.a(n8)) == -1) {
                n3 = n4 + 1;
                if (n4 == n6) {
                    bl3 = bl4;
                    if (bl2) return bl3;
                    throw new i("Searched too many bytes.");
                }
                if (bl2) {
                    g2.a();
                    g2.c(n2 + n3);
                    n4 = n3;
                    n5 = 0;
                    n3 = 0;
                    continue;
                }
                g2.b(1);
                n4 = n3;
                n5 = 0;
                n3 = 0;
                continue;
            }
            int n9 = n5 + 1;
            if (n9 == 1) {
                k.a(n8, this.g);
                n5 = n8;
            } else {
                n5 = n3;
                if (n9 == 4) break;
            }
            g2.c(n7 - 4);
            n3 = n5;
            n5 = n9;
        }
        if (bl2) {
            g2.b(n2 + n4);
        } else {
            g2.a();
        }
        this.k = n3;
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final int a(g var1_1, l var2_3) {
        if (this.k == 0) {
            this.a(var1_1, false);
        }
        if (this.m != null) ** GOTO lbl89
        var4_4 = new com.google.android.exoplayer2.i.i(this.g.c);
        var1_1.c(var4_4.a, 0, this.g.c);
        var10_5 = var1_1.c();
        var14_6 = var1_1.d();
        var3_7 = null;
        if ((this.g.a & 1) == 0) ** GOTO lbl15
        var5_8 = this.g.e != 1 ? 36 : 21;
        ** GOTO lbl16
        catch (EOFException var1_2) {
            return -1;
        }
lbl15: // 1 sources:
        var5_8 = this.g.e != 1 ? 21 : 13;
lbl16: // 2 sources:
        if (var4_4.c >= var5_8 + 4) {
            var4_4.c(var5_8);
            var6_9 = var4_4.k();
        } else {
            var6_9 = 0;
        }
        if (var6_9 != b.b && var6_9 != b.c) ** GOTO lbl54
        var2_3 = this.g;
        var6_9 = var2_3.g;
        var7_10 = var2_3.d;
        var10_5 += (long)var2_3.c;
        var8_12 = var4_4.k();
        if ((var8_12 & 1) != 1 || (var9_14 = var4_4.o()) == 0) {
            var2_3 = null;
        } else {
            var12_16 = o.a(var9_14, (long)var6_9 * 1000000, (long)var7_10);
            if ((var8_12 & 6) != 6) {
                var2_3 = new d(var10_5, var12_16, var14_6);
            } else {
                var16_17 = var4_4.o();
                var4_4.d(1);
                var3_7 = new long[99];
                for (var6_9 = 0; var6_9 < 99; ++var6_9) {
                    var3_7[var6_9] = var4_4.e();
                }
                var2_3 = new d(var10_5, var12_16, var14_6, var3_7, var16_17, var2_3.c);
            }
        }
        if (var2_3 != null && !this.h.a()) {
            var1_1.a();
            var1_1.c(var5_8 + 141);
            var1_1.c(this.f.a, 0, 3);
            this.f.c(0);
            var3_7 = this.h;
            var6_9 = this.f.h();
            var5_8 = var6_9 >> 12;
            if (var5_8 > 0 || (var6_9 &= 4095) > 0) {
                var3_7.a = var5_8;
                var3_7.b = var6_9;
            }
        }
        var1_1.b(this.g.c);
        ** GOTO lbl78
lbl54: // 1 sources:
        var2_3 = var3_7;
        if (var4_4.c < 40) ** GOTO lbl78
        var4_4.c(36);
        var2_3 = var3_7;
        if (var4_4.k() != b.d) ** GOTO lbl78
        var2_3 = this.g;
        var4_4.d(10);
        var5_8 = var4_4.k();
        if (var5_8 > 0) ** GOTO lbl65
        var2_3 = null;
        ** GOTO lbl118
lbl65: // 1 sources:
        var6_9 = var2_3.d;
        var12_16 = var5_8;
        var5_8 = var6_9 >= 32000 ? 1152 : 576;
        var16_18 = o.a(var12_16, (long)var5_8 * 1000000, (long)var6_9);
        var7_11 = var4_4.f();
        var8_13 = var4_4.f();
        var9_15 = var4_4.f();
        var4_4.d(2);
        var2_3 = new long[var7_11 + 1];
        var3_7 = new long[var7_11 + 1];
        var2_3[0] = 0;
        var3_7[0] = var10_5 += (long)var2_3.c;
        ** GOTO lbl121
lbl78: // 4 sources:
        do {
            var3_7 = var2_3;
            if (var2_3 == null) {
                var1_1.a();
                var1_1.c(this.f.a, 0, 4);
                this.f.c(0);
                k.a(this.f.k(), this.g);
                var3_7 = new com.google.android.exoplayer2.c.c.a(var1_1.c(), this.g.f, var14_6);
            }
            this.m = var3_7;
            this.i.a(this.m);
            this.j.a(Format.a(null, this.g.b, -1, 4096, this.g.e, this.g.d, -1, this.h.a, this.h.b, null, null, 0, null, this.l));
lbl89: // 2 sources:
            if (this.p == 0) {
                var1_1.a();
                if (!var1_1.b(this.f.a, 0, 4, true)) {
                    return -1;
                }
                this.f.c(0);
                var5_8 = this.f.k();
                if ((-128000 & var5_8) != (this.k & -128000) || k.a(var5_8) == -1) {
                    var1_1.b(1);
                    this.k = 0;
                    return 0;
                }
                k.a(var5_8, this.g);
                if (this.n == -9223372036854775807L) {
                    this.n = this.m.b(var1_1.c());
                    if (this.e != -9223372036854775807L) {
                        var10_5 = this.m.b(0);
                        var12_16 = this.n;
                        this.n = this.e - var10_5 + var12_16;
                    }
                }
                this.p = this.g.c;
            }
            if ((var5_8 = this.j.a(var1_1, this.p, true)) == -1) {
                return -1;
            }
            this.p -= var5_8;
            if (this.p > 0) {
                return 0;
            }
            var10_5 = this.n;
            var12_16 = this.o * 1000000 / (long)this.g.d;
            this.j.a(var12_16 + var10_5, 1, this.g.c, 0, null);
            this.o += (long)this.g.g;
            this.p = 0;
            return 0;
            break;
        } while (true);
lbl118: // 3 sources:
        do {
            var1_1.b(this.g.c);
            ** continue;
            break;
        } while (true);
lbl121: // 2 sources:
        for (var6_9 = 1; var6_9 < var2_3.length; ++var6_9) {
            switch (var9_15) {
                default: {
                    var2_3 = null;
                    ** GOTO lbl118
                }
                case 1: {
                    var5_8 = var4_4.e();
                    break;
                }
                case 2: {
                    var5_8 = var4_4.f();
                    break;
                }
                case 3: {
                    var5_8 = var4_4.h();
                    break;
                }
                case 4: {
                    var5_8 = var4_4.o();
                }
            }
            var2_3[var6_9] = (long)var6_9 * var16_18 / (long)var7_11;
            var12_16 = var14_6 == -1 ? var10_5 : Math.min(var14_6, var10_5 += (long)(var5_8 * var8_13));
            var3_7[var6_9] = var12_16;
        }
        var2_3 = new c((long[])var2_3, var3_7, var16_18);
        ** while (true)
    }

    @Override
    public final void a(long l2, long l3) {
        this.k = 0;
        this.n = -9223372036854775807L;
        this.o = 0;
        this.p = 0;
    }

    @Override
    public final void a(h h2) {
        this.i = h2;
        this.j = this.i.a(0);
        this.i.b();
    }

    @Override
    public final boolean a(g g2) {
        return this.a(g2, true);
    }

    static interface a
    extends m {
        public long b(long var1);
    }

}

