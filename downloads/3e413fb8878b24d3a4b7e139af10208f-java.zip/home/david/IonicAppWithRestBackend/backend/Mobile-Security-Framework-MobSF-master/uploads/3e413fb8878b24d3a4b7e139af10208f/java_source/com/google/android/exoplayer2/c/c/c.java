/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.c;

import com.google.android.exoplayer2.c.c.b;
import com.google.android.exoplayer2.i.o;

final class c
implements b.a {
    private final long[] a;
    private final long[] b;
    private final long c;

    c(long[] arrl, long[] arrl2, long l2) {
        this.a = arrl;
        this.b = arrl2;
        this.c = l2;
    }

    @Override
    public final long a(long l2) {
        return this.b[o.a(this.a, l2, true)];
    }

    @Override
    public final long b() {
        return this.c;
    }

    @Override
    public final long b(long l2) {
        return this.a[o.a(this.b, l2, true)];
    }

    @Override
    public final boolean b_() {
        return true;
    }
}

