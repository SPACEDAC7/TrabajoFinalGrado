/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.c;

import com.google.android.exoplayer2.c.c.b;
import com.google.android.exoplayer2.i.o;

final class d
implements b.a {
    private final long a;
    private final long b;
    private final long c;
    private final long[] d;
    private final long e;
    private final int f;

    d(long l2, long l3, long l4) {
        this(l2, l3, l4, null, 0, 0);
    }

    d(long l2, long l3, long l4, long[] arrl, long l5, int n2) {
        this.a = l2;
        this.b = l3;
        this.c = l4;
        this.d = arrl;
        this.e = l5;
        this.f = n2;
    }

    private long a(int n2) {
        return this.b * (long)n2 / 100;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a(long l2) {
        float f2;
        float f3 = 256.0f;
        float f4 = 0.0f;
        if (!this.b_()) {
            return this.a;
        }
        float f5 = (float)l2 * 100.0f / (float)this.b;
        if (f5 <= 0.0f) {
            f2 = 0.0f;
        } else {
            f2 = f3;
            if (f5 < 100.0f) {
                int n2 = (int)f5;
                f2 = n2 == 0 ? f4 : (float)this.d[n2 - 1];
                if (n2 < 99) {
                    f3 = this.d[n2];
                }
                f2 = (f3 - f2) * (f5 - (float)n2) + f2;
            }
        }
        long l3 = Math.round((double)f2 * 0.00390625 * (double)this.e);
        long l4 = this.a;
        if (this.c != -1) {
            l2 = this.c - 1;
            return Math.min(l4 + l3, l2);
        }
        l2 = this.a - (long)this.f + this.e - 1;
        return Math.min(l4 + l3, l2);
    }

    @Override
    public final long b() {
        return this.b;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long b(long l2) {
        if (!this.b_()) return 0;
        if (l2 < this.a) {
            return 0;
        }
        double d2 = 256.0 * (double)(l2 - this.a) / (double)this.e;
        int n2 = o.a(this.d, (long)d2, false) + 1;
        long l3 = this.a(n2);
        l2 = n2 == 0 ? 0 : this.d[n2 - 1];
        long l4 = n2 == 99 ? 256 : this.d[n2];
        long l5 = this.a(n2 + 1);
        if (l4 == l2) {
            l2 = 0;
            return l3 + l2;
        }
        l2 = (long)((double)(l5 - l3) * (d2 - (double)l2) / (double)(l4 - l2));
        return l3 + l2;
    }

    @Override
    public final boolean b_() {
        if (this.d != null) {
            return true;
        }
        return false;
    }
}

