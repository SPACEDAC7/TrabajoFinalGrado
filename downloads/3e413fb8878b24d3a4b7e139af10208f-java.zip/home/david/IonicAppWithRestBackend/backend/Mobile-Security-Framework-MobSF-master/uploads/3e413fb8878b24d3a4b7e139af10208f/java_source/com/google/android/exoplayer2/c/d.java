/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.b.e;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.f;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.o;
import java.io.EOFException;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicInteger;

public final class d
implements n {
    public final int a;
    public final b b;
    public final LinkedBlockingDeque<com.google.android.exoplayer2.h.a> c;
    public final a d;
    public final i e;
    public long f;
    public Format g;
    public c h;
    private final com.google.android.exoplayer2.h.b i;
    private final AtomicInteger j;
    private long k;
    private long l;
    private com.google.android.exoplayer2.h.a m;
    private int n;
    private boolean o;
    private boolean p;

    public d(com.google.android.exoplayer2.h.b b2) {
        this.i = b2;
        this.a = b2.b;
        this.b = new b();
        this.c = new LinkedBlockingDeque();
        this.d = new a(0);
        this.e = new i(32);
        this.j = new AtomicInteger();
        this.n = this.a;
        this.o = true;
    }

    private int a(int n2) {
        if (this.n == this.a) {
            this.n = 0;
            this.m = this.i.a();
            this.c.add(this.m);
        }
        return Math.min(n2, this.a - this.n);
    }

    private boolean b() {
        return this.j.compareAndSet(0, 1);
    }

    private void c() {
        if (!this.j.compareAndSet(1, 0)) {
            this.d();
        }
    }

    private void d() {
        b b2 = this.b;
        b2.b = 0;
        b2.c = 0;
        b2.d = 0;
        b2.a = 0;
        this.i.a(this.c.toArray(new com.google.android.exoplayer2.h.a[this.c.size()]));
        this.c.clear();
        this.i.b();
        this.f = 0;
        this.l = 0;
        this.m = null;
        this.n = this.a;
        this.o = true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final int a(g g2, int n2, boolean bl2) {
        if (!this.b()) {
            if ((n2 = g2.a(n2)) != -1) {
                return n2;
            }
            if (bl2) {
                return -1;
            }
            throw new EOFException();
        }
        try {
            n2 = this.a(n2);
            byte[] arrby = this.m.a;
            com.google.android.exoplayer2.h.a a2 = this.m;
            int n3 = this.n;
            n2 = g2.a(arrby, a2.b + n3, n2);
            if (n2 == -1) {
                if (bl2) {
                    this.c();
                    return -1;
                }
                throw new EOFException();
            }
            this.n += n2;
            this.l += (long)n2;
            this.c();
            return n2;
        }
        catch (Throwable var1_2) {
            this.c();
            throw var1_2;
        }
    }

    public final void a() {
        if (this.j.getAndSet(2) == 0) {
            this.d();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final void a(long var1_1, int var3_2, int var4_3, int var5_4, byte[] var6_5) {
        block9 : {
            if (!this.b()) {
                this.b.b(var1_1);
                return;
            }
            if (!this.p) ** GOTO lbl17
            if ((var3_2 & 1) != 0) {
                var15_7 = this.b.c(var1_1);
                if (var15_7) break block9;
            }
            this.c();
            return;
        }
        this.p = false;
lbl17: // 2 sources:
        if (!(var15_7 = this.o)) ** GOTO lbl23
        if ((var3_2 & 1) == 0) {
            this.c();
            return;
        }
        try {
            this.o = false;
lbl23: // 2 sources:
            var7_8 = this.k;
            var9_9 = this.l;
            var11_10 = var4_3;
            var13_11 = var5_4;
            this.b.a(var1_1 + var7_8, var3_2, var9_9 - var11_10 - var13_11, var4_3, var6_5);
            return;
        }
        finally {
            this.c();
        }
    }

    public final void a(long l2, byte[] arrby, int n2) {
        int n3;
        for (int i2 = 0; i2 < n2; i2 += n3) {
            this.b(l2);
            int n4 = (int)(l2 - this.f);
            n3 = Math.min(n2 - i2, this.a - n4);
            com.google.android.exoplayer2.h.a a2 = this.c.peek();
            System.arraycopy(a2.a, a2.b + n4, arrby, i2, n3);
            l2 += (long)n3;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(Format format) {
        Format format2;
        long l2 = this.k;
        if (format == null) {
            format2 = null;
        } else {
            format2 = format;
            if (l2 != 0) {
                format2 = format;
                if (format.v != Long.MAX_VALUE) {
                    format2 = format.a(l2 + format.v);
                }
            }
        }
        boolean bl2 = this.b.a(format2);
        if (this.h != null && bl2) {
            this.h.a();
        }
    }

    @Override
    public final void a(i i2, int n2) {
        if (!this.b()) {
            i2.d(n2);
            return;
        }
        for (int i3 = n2; i3 > 0; i3 -= n2) {
            n2 = this.a(i3);
            byte[] arrby = this.m.a;
            com.google.android.exoplayer2.h.a a2 = this.m;
            int n3 = this.n;
            i2.a(arrby, a2.b + n3, n2);
            this.n += n2;
            this.l += (long)n2;
        }
        this.c();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(boolean bl2) {
        Object object = this.j;
        int n2 = bl2 ? 0 : 2;
        n2 = object.getAndSet(n2);
        this.d();
        object = this.b;
        object.e = Long.MIN_VALUE;
        object.f = Long.MIN_VALUE;
        if (n2 == 2) {
            this.g = null;
        }
    }

    public final boolean a(long l2) {
        if ((l2 = this.b.a(l2)) == -1) {
            return false;
        }
        this.b(l2);
        return true;
    }

    public final void b(long l2) {
        int n2 = (int)(l2 - this.f) / this.a;
        for (int i2 = 0; i2 < n2; ++i2) {
            this.i.a(this.c.remove());
            this.f += (long)this.a;
        }
    }

    public static final class a {
        public int a;
        public long b;
        public long c;
        public byte[] d;

        private a() {
        }

        /* synthetic */ a(byte by2) {
            this();
        }
    }

    public static final class b {
        int a;
        int b;
        int c;
        int d;
        long e = Long.MIN_VALUE;
        long f = Long.MIN_VALUE;
        private int g = 1000;
        private int[] h = new int[this.g];
        private long[] i = new long[this.g];
        private int[] j = new int[this.g];
        private int[] k = new int[this.g];
        private long[] l = new long[this.g];
        private byte[][] m = new byte[this.g][];
        private Format[] n = new Format[this.g];
        private boolean o = true;
        private Format p;
        private int q;

        public final int a() {
            return this.b + this.a;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public final int a(f f2, e e2, Format format, a a2) {
            int n2 = -5;
            synchronized (this) {
                if (this.a == 0) {
                    if (this.p == null) return -3;
                    if (e2 != null) {
                        if (this.p == format) return -3;
                    }
                    f2.a = this.p;
                } else if (e2 == null || this.n[this.c] != format) {
                    f2.a = this.n[this.c];
                } else {
                    long l2;
                    e2.d = this.l[this.c];
                    e2.a = this.k[this.c];
                    a2.a = this.j[this.c];
                    a2.b = this.i[this.c];
                    a2.d = this.m[this.c];
                    this.e = Math.max(this.e, e2.d);
                    --this.a;
                    ++this.c;
                    ++this.b;
                    if (this.c == this.g) {
                        this.c = 0;
                    }
                    if (this.a > 0) {
                        l2 = this.i[this.c];
                    } else {
                        l2 = a2.b;
                        n2 = a2.a;
                        l2 += (long)n2;
                    }
                    a2.c = l2;
                    return -4;
                }
                return n2;
            }
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public final long a(long l2) {
            long l3 = -1;
            synchronized (this) {
                long l4;
                block11 : {
                    l4 = l3;
                    if (this.a == 0) return l4;
                    l4 = this.l[this.c];
                    if (l2 >= l4) break block11;
                    return l3;
                }
                l4 = l3;
                if (l2 > this.f) return l4;
                int n2 = 0;
                int n3 = this.c;
                int n4 = -1;
                do {
                    block12 : {
                        if (n3 == this.d || this.l[n3] > l2) break;
                        if ((this.k[n3] & 1) == 0) break block12;
                        n4 = n2;
                    }
                    n3 = (n3 + 1) % this.g;
                    ++n2;
                } while (true);
                l4 = l3;
                if (n4 == -1) return l4;
                try {
                    this.a -= n4;
                    this.c = (this.c + n4) % this.g;
                    this.b += n4;
                    l4 = this.i[this.c];
                    return l4;
                }
                catch (Throwable var3_7) {
                    throw var3_7;
                }
                finally {
                }
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public final void a(long l2, int n2, long l3, int n3, byte[] arrby) {
            synchronized (this) {
                boolean bl2 = !this.o;
                a.a.a.a.d.b(bl2);
                this.b(l2);
                this.l[this.d] = l2;
                this.i[this.d] = l3;
                this.j[this.d] = n3;
                this.k[this.d] = n2;
                this.m[this.d] = arrby;
                this.n[this.d] = this.p;
                this.h[this.d] = this.q;
                ++this.a;
                if (this.a == this.g) {
                    n2 = this.g + 1000;
                    arrby = new int[n2];
                    long[] arrl = new long[n2];
                    long[] arrl2 = new long[n2];
                    int[] arrn = new int[n2];
                    int[] arrn2 = new int[n2];
                    byte[][] arrarrby = new byte[n2][];
                    Format[] arrformat = new Format[n2];
                    n3 = this.g - this.c;
                    System.arraycopy(this.i, this.c, arrl, 0, n3);
                    System.arraycopy(this.l, this.c, arrl2, 0, n3);
                    System.arraycopy(this.k, this.c, arrn, 0, n3);
                    System.arraycopy(this.j, this.c, arrn2, 0, n3);
                    System.arraycopy(this.m, this.c, arrarrby, 0, n3);
                    System.arraycopy(this.n, this.c, arrformat, 0, n3);
                    System.arraycopy(this.h, this.c, arrby, 0, n3);
                    int n4 = this.c;
                    System.arraycopy(this.i, 0, arrl, n3, n4);
                    System.arraycopy(this.l, 0, arrl2, n3, n4);
                    System.arraycopy(this.k, 0, arrn, n3, n4);
                    System.arraycopy(this.j, 0, arrn2, n3, n4);
                    System.arraycopy(this.m, 0, arrarrby, n3, n4);
                    System.arraycopy(this.n, 0, arrformat, n3, n4);
                    System.arraycopy(this.h, 0, arrby, n3, n4);
                    this.i = arrl;
                    this.l = arrl2;
                    this.k = arrn;
                    this.j = arrn2;
                    this.m = arrarrby;
                    this.n = arrformat;
                    this.h = arrby;
                    this.c = 0;
                    this.d = this.g;
                    this.a = this.g;
                    this.g = n2;
                } else {
                    ++this.d;
                    if (this.d == this.g) {
                        this.d = 0;
                    }
                }
                return;
            }
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public final boolean a(Format format) {
            boolean bl2 = false;
            synchronized (this) {
                if (format == null) {
                    this.o = true;
                    return bl2;
                }
                this.o = false;
                if (o.a(format, this.p)) return bl2;
                this.p = format;
                return true;
            }
        }

        public final void b(long l2) {
            synchronized (this) {
                this.f = Math.max(this.f, l2);
                return;
            }
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public final boolean b() {
            synchronized (this) {
                int n2 = this.a;
                if (n2 != 0) return false;
                return true;
            }
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public final Format c() {
            synchronized (this) {
                block6 : {
                    boolean bl2 = this.o;
                    if (!bl2) break block6;
                    return null;
                }
                Format format = this.p;
                return format;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public final boolean c(long l2) {
            boolean bl2 = false;
            boolean bl3 = false;
            synchronized (this) {
                int n2;
                long l3 = this.e;
                if (l3 >= l2) return bl3;
                for (n2 = this.a; n2 > 0 && this.l[(this.c + n2 - 1) % this.g] >= l2; --n2) {
                }
                int n3 = this.b;
                n2 = this.a() - (n2 + n3);
                bl3 = bl2;
                if (n2 >= 0) {
                    bl3 = bl2;
                    if (n2 <= this.a) {
                        bl3 = true;
                    }
                }
                a.a.a.a.d.a(bl3);
                if (n2 != 0) {
                    this.a -= n2;
                    this.d = (this.d + this.g - n2) % this.g;
                    this.f = Long.MIN_VALUE;
                    n2 = this.a - 1;
                    while (n2 >= 0) {
                        n3 = (this.c + n2) % this.g;
                        this.f = Math.max(this.f, this.l[n3]);
                        if (((n3 = this.k[n3]) & 1) != 0) return true;
                        --n2;
                    }
                    return true;
                }
                if (this.b == 0) return true;
                return true;
            }
        }

        public final long d() {
            synchronized (this) {
                long l2 = Math.max(this.e, this.f);
                return l2;
            }
        }
    }

    public static interface c {
        public void a();
    }

}

