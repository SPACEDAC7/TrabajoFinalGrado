/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.d;

import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.o;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class a {
    public static final int A;
    public static final int B;
    public static final int C;
    public static final int D;
    public static final int E;
    public static final int F;
    public static final int G;
    public static final int H;
    public static final int I;
    public static final int J;
    public static final int K;
    public static final int L;
    public static final int M;
    public static final int N;
    public static final int O;
    public static final int P;
    public static final int Q;
    public static final int R;
    public static final int S;
    public static final int T;
    public static final int U;
    public static final int V;
    public static final int W;
    public static final int X;
    public static final int Y;
    public static final int Z;
    public static final int a;
    public static final int aA;
    public static final int aB;
    public static final int aC;
    public static final int aD;
    public static final int aE;
    public static final int aF;
    public static final int aG;
    public static final int aH;
    public static final int aI;
    public static final int aJ;
    public static final int aK;
    public static final int aL;
    public static final int aM;
    public static final int aN;
    public static final int aO;
    public static final int aa;
    public static final int ab;
    public static final int ac;
    public static final int ad;
    public static final int ae;
    public static final int af;
    public static final int ag;
    public static final int ah;
    public static final int ai;
    public static final int aj;
    public static final int ak;
    public static final int al;
    public static final int am;
    public static final int an;
    public static final int ao;
    public static final int ap;
    public static final int aq;
    public static final int ar;
    public static final int as;
    public static final int at;
    public static final int au;
    public static final int av;
    public static final int aw;
    public static final int ax;
    public static final int ay;
    public static final int az;
    public static final int b;
    public static final int c;
    public static final int d;
    public static final int e;
    public static final int f;
    public static final int g;
    public static final int h;
    public static final int i;
    public static final int j;
    public static final int k;
    public static final int l;
    public static final int m;
    public static final int n;
    public static final int o;
    public static final int p;
    public static final int q;
    public static final int r;
    public static final int s;
    public static final int t;
    public static final int u;
    public static final int v;
    public static final int w;
    public static final int x;
    public static final int y;
    public static final int z;
    public final int aP;

    static {
        a = o.e("ftyp");
        b = o.e("avc1");
        c = o.e("avc3");
        d = o.e("hvc1");
        e = o.e("hev1");
        f = o.e("s263");
        g = o.e("d263");
        h = o.e("mdat");
        i = o.e("mp4a");
        j = o.e(".mp3");
        k = o.e("wave");
        l = o.e("lpcm");
        m = o.e("sowt");
        n = o.e("ac-3");
        o = o.e("dac3");
        p = o.e("ec-3");
        q = o.e("dec3");
        r = o.e("dtsc");
        s = o.e("dtsh");
        t = o.e("dtsl");
        u = o.e("dtse");
        v = o.e("ddts");
        w = o.e("tfdt");
        x = o.e("tfhd");
        y = o.e("trex");
        z = o.e("trun");
        A = o.e("sidx");
        B = o.e("moov");
        C = o.e("mvhd");
        D = o.e("trak");
        E = o.e("mdia");
        F = o.e("minf");
        G = o.e("stbl");
        H = o.e("avcC");
        I = o.e("hvcC");
        J = o.e("esds");
        K = o.e("moof");
        L = o.e("traf");
        M = o.e("mvex");
        N = o.e("mehd");
        O = o.e("tkhd");
        P = o.e("edts");
        Q = o.e("elst");
        R = o.e("mdhd");
        S = o.e("hdlr");
        T = o.e("stsd");
        U = o.e("pssh");
        V = o.e("sinf");
        W = o.e("schm");
        X = o.e("schi");
        Y = o.e("tenc");
        Z = o.e("encv");
        aa = o.e("enca");
        ab = o.e("frma");
        ac = o.e("saiz");
        ad = o.e("saio");
        ae = o.e("sbgp");
        af = o.e("sgpd");
        ag = o.e("uuid");
        ah = o.e("senc");
        ai = o.e("pasp");
        aj = o.e("TTML");
        ak = o.e("vmhd");
        al = o.e("mp4v");
        am = o.e("stts");
        an = o.e("stss");
        ao = o.e("ctts");
        ap = o.e("stsc");
        aq = o.e("stsz");
        ar = o.e("stz2");
        as = o.e("stco");
        at = o.e("co64");
        au = o.e("tx3g");
        av = o.e("wvtt");
        aw = o.e("stpp");
        ax = o.e("c608");
        ay = o.e("samr");
        az = o.e("sawb");
        aA = o.e("udta");
        aB = o.e("meta");
        aC = o.e("ilst");
        aD = o.e("mean");
        aE = o.e("name");
        aF = o.e("data");
        aG = o.e("emsg");
        aH = o.e("st3d");
        aI = o.e("sv3d");
        aJ = o.e("proj");
        aK = o.e("vp08");
        aL = o.e("vp09");
        aM = o.e("vpcC");
        aN = o.e("camm");
        aO = o.e("alac");
    }

    public a(int n2) {
        this.aP = n2;
    }

    public static int a(int n2) {
        return n2 >> 24 & 255;
    }

    public static int b(int n2) {
        return 16777215 & n2;
    }

    public static String c(int n2) {
        return "" + (char)(n2 >>> 24) + (char)(n2 >> 16 & 255) + (char)(n2 >> 8 & 255) + (char)(n2 & 255);
    }

    public String toString() {
        return a.c(this.aP);
    }

    static final class a
    extends a {
        public final long aQ;
        public final List<b> aR;
        public final List<a> aS;

        public a(int n2, long l2) {
            super(n2);
            this.aQ = l2;
            this.aR = new ArrayList<b>();
            this.aS = new ArrayList<a>();
        }

        public final void a(a a2) {
            this.aS.add(a2);
        }

        public final void a(b b2) {
            this.aR.add(b2);
        }

        public final b d(int n2) {
            int n3 = this.aR.size();
            for (int i2 = 0; i2 < n3; ++i2) {
                b b2 = this.aR.get(i2);
                if (b2.aP != n2) continue;
                return b2;
            }
            return null;
        }

        public final a e(int n2) {
            int n3 = this.aS.size();
            for (int i2 = 0; i2 < n3; ++i2) {
                a a2 = this.aS.get(i2);
                if (a2.aP != n2) continue;
                return a2;
            }
            return null;
        }

        @Override
        public final String toString() {
            return a.c(this.aP) + " leaves: " + Arrays.toString(this.aR.toArray()) + " containers: " + Arrays.toString(this.aS.toArray());
        }
    }

    static final class b
    extends a {
        public final i aQ;

        public b(int n2, i i2) {
            super(n2);
            this.aQ = i2;
        }
    }

}

