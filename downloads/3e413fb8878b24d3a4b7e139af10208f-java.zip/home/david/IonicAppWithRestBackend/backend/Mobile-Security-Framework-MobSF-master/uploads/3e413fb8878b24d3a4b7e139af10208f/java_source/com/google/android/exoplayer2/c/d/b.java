/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  android.util.Pair
 */
package com.google.android.exoplayer2.c.d;

import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.d.a;
import com.google.android.exoplayer2.c.d.l;
import com.google.android.exoplayer2.c.j;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.i;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.Metadata;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class b {
    private static final int a = o.e("vide");
    private static final int b = o.e("soun");
    private static final int c = o.e("text");
    private static final int d = o.e("sbtl");
    private static final int e = o.e("subt");
    private static final int f = o.e("clcp");
    private static final int g = o.e("cenc");
    private static final int h = o.e("meta");

    private static int a(com.google.android.exoplayer2.i.i i2) {
        int n2 = i2.e();
        int n3 = n2 & 127;
        while ((n2 & 128) == 128) {
            n2 = i2.e();
            n3 = n3 << 7 | n2 & 127;
        }
        return n3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int a(com.google.android.exoplayer2.i.i var0, int var1_1, int var2_2, c var3_3, int var4_4) {
        var9_5 = var0.b;
        block0 : do {
            if (var9_5 - var1_1 >= var2_2) return 0;
            var0.c(var9_5);
            var12_12 = var0.k();
            var15_15 = var12_12 > 0;
            a.a.a.a.d.a(var15_15, (Object)"childAtomSize should be positive");
            if (var0.k() != com.google.android.exoplayer2.c.d.a.V) ** GOTO lbl48
            var11_11 = 0;
            var5_6 = null;
            var6_7 = null;
            var10_10 = var9_5 + 8;
            block1 : do {
                if (var10_10 - var9_5 < var12_12) {
                    var0.c(var10_10);
                    var13_13 = var0.k();
                    var14_14 = var0.k();
                    if (var14_14 == com.google.android.exoplayer2.c.d.a.ab) {
                        var7_8 = var0.k();
                        var8_9 = var11_11;
                    } else if (var14_14 == com.google.android.exoplayer2.c.d.a.W) {
                        var0.d(4);
                        if (var0.k() == b.g) {
                            var8_9 = 1;
                            var7_8 = var6_7;
                        } else {
                            var8_9 = 0;
                            var7_8 = var6_7;
                        }
                    } else {
                        var7_8 = var6_7;
                        var8_9 = var11_11;
                        if (var14_14 == com.google.android.exoplayer2.c.d.a.X) {
                            var8_9 = var10_10 + 8;
                            break block0;
                        }
                    }
                } else {
                    if (var11_11 != 0) {
                        var15_15 = var6_7 != null;
                        a.a.a.a.d.a(var15_15, (Object)"frma atom is mandatory");
                        var15_15 = var5_6 != null;
                        a.a.a.a.d.a(var15_15, (Object)"schi->tenc atom is mandatory");
                        var5_6 = Pair.create((Object)var6_7, (Object)var5_6);
                    } else {
                        var5_6 = null;
                    }
                    if (var5_6 != null) {
                        var3_3.a[var4_4] = (com.google.android.exoplayer2.c.d.j)var5_6.second;
                        return (Integer)var5_6.first;
                    }
lbl48: // 3 sources:
                    var9_5 += var12_12;
                    continue block0;
                }
lbl50: // 6 sources:
                do {
                    var10_10 += var13_13;
                    var6_7 = var7_8;
                    var11_11 = var8_9;
                    continue block1;
                    break;
                } while (true);
                break;
            } while (true);
            break;
        } while (true);
        while (var8_9 - var10_10 < var13_13) {
            var0.c(var8_9);
            var14_14 = var0.k();
            if (var0.k() != com.google.android.exoplayer2.c.d.a.Y) ** GOTO lbl68
            var0.d(6);
            var15_15 = var0.e() == 1;
            var8_9 = var0.e();
            var5_6 = new byte[16];
            var0.a((byte[])var5_6, 0, 16);
            var5_6 = new com.google.android.exoplayer2.c.d.j(var15_15, var8_9, (byte[])var5_6);
            var7_8 = var6_7;
            var8_9 = var11_11;
            ** GOTO lbl50
lbl68: // 1 sources:
            var8_9 += var14_14;
        }
        var5_6 = null;
        var7_8 = var6_7;
        var8_9 = var11_11;
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Pair<long[], long[]> a(a.a object) {
        if (object == null || (object = object.d(com.google.android.exoplayer2.c.d.a.Q)) == null) {
            return Pair.create((Object)null, (Object)null);
        }
        object = object.aQ;
        object.c(8);
        int n2 = com.google.android.exoplayer2.c.d.a.a(object.k());
        int n3 = object.o();
        long[] arrl = new long[n3];
        long[] arrl2 = new long[n3];
        int n4 = 0;
        while (n4 < n3) {
            long l2 = n2 == 1 ? object.q() : object.i();
            arrl[n4] = l2;
            l2 = n2 == 1 ? object.m() : (long)object.k();
            arrl2[n4] = l2;
            byte[] arrby = object.a;
            int n5 = object.b;
            object.b = n5 + 1;
            n5 = arrby[n5];
            arrby = object.a;
            int n6 = object.b;
            object.b = n6 + 1;
            if ((short)((n5 & 255) << 8 | arrby[n6] & 255) != 1) {
                throw new IllegalArgumentException("Unsupported media rate.");
            }
            object.d(2);
            ++n4;
        }
        return Pair.create((Object)arrl, (Object)arrl2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static Pair<String, byte[]> a(com.google.android.exoplayer2.i.i var0, int var1_1) {
        var2_2 = null;
        var0.c(var1_1 + 8 + 4);
        var0.d(1);
        b.a(var0);
        var0.d(2);
        var1_1 = var0.e();
        if ((var1_1 & 128) != 0) {
            var0.d(2);
        }
        if ((var1_1 & 64) != 0) {
            var0.d(var0.f());
        }
        if ((var1_1 & 32) != 0) {
            var0.d(2);
        }
        var0.d(1);
        b.a(var0);
        switch (var0.e()) {
            case 107: {
                return Pair.create((Object)"audio/mpeg", (Object)null);
            }
            case 32: {
                var2_2 = "video/mp4v-es";
                ** break;
            }
            case 33: {
                var2_2 = "video/avc";
                ** break;
            }
            case 35: {
                var2_2 = "video/hevc";
                ** break;
            }
            case 64: 
            case 102: 
            case 103: 
            case 104: {
                var2_2 = "audio/mp4a-latm";
                ** break;
            }
            case 165: {
                var2_2 = "audio/ac3";
                ** break;
            }
            case 166: {
                var2_2 = "audio/eac3";
            }
lbl35: // 7 sources:
            default: {
                var0.d(12);
                var0.d(1);
                var1_1 = b.a(var0);
                var3_3 = new byte[var1_1];
                var0.a(var3_3, 0, var1_1);
                return Pair.create((Object)var2_2, (Object)var3_3);
            }
            case 169: 
            case 172: {
                return Pair.create((Object)"audio/vnd.dts", (Object)null);
            }
            case 170: 
            case 171: 
        }
        return Pair.create((Object)"audio/vnd.dts.hd", (Object)null);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static c a(com.google.android.exoplayer2.i.i var0, int var1_1, int var2_2, String var3_3, DrmInitData var4_4, boolean var5_5) {
        block42 : {
            var0.c(12);
            var19_6 = var0.k();
            var11_7 = new c(var19_6);
            var16_8 = 0;
            block5 : while (var16_8 < var19_6) {
                block43 : {
                    var20_21 = var0.b;
                    var21_20 = var0.k();
                    var26_26 = var21_20 > 0;
                    a.a.a.a.d.a(var26_26, (Object)"childAtomSize should be positive");
                    var15_17 = var0.k();
                    if (var15_17 != com.google.android.exoplayer2.c.d.a.b && var15_17 != com.google.android.exoplayer2.c.d.a.c && var15_17 != com.google.android.exoplayer2.c.d.a.Z && var15_17 != com.google.android.exoplayer2.c.d.a.al && var15_17 != com.google.android.exoplayer2.c.d.a.d && var15_17 != com.google.android.exoplayer2.c.d.a.e && var15_17 != com.google.android.exoplayer2.c.d.a.f && var15_17 != com.google.android.exoplayer2.c.d.a.aK && var15_17 != com.google.android.exoplayer2.c.d.a.aL) ** GOTO lbl24
                    var0.c(var20_21 + 8);
                    var0.d(24);
                    var18_19 = var0.f();
                    var22_23 = var0.f();
                    var6_9 = 1.0f;
                    var0.d(50);
                    var13_15 = var0.b;
                    var14_16 = var15_17;
                    if (var15_17 == com.google.android.exoplayer2.c.d.a.Z) {
                        var14_16 = b.a(var0, var20_21, var21_20, var11_7, var16_8);
                        var0.c(var13_15);
                    }
                    ** GOTO lbl84
lbl24: // 1 sources:
                    if (var15_17 != com.google.android.exoplayer2.c.d.a.i && var15_17 != com.google.android.exoplayer2.c.d.a.aa && var15_17 != com.google.android.exoplayer2.c.d.a.n && var15_17 != com.google.android.exoplayer2.c.d.a.p && var15_17 != com.google.android.exoplayer2.c.d.a.r && var15_17 != com.google.android.exoplayer2.c.d.a.u && var15_17 != com.google.android.exoplayer2.c.d.a.s && var15_17 != com.google.android.exoplayer2.c.d.a.t && var15_17 != com.google.android.exoplayer2.c.d.a.ay && var15_17 != com.google.android.exoplayer2.c.d.a.az && var15_17 != com.google.android.exoplayer2.c.d.a.l && var15_17 != com.google.android.exoplayer2.c.d.a.m && var15_17 != com.google.android.exoplayer2.c.d.a.j && var15_17 != com.google.android.exoplayer2.c.d.a.aO) ** GOTO lbl64
                    var0.c(var20_21 + 8);
                    if (var5_5) {
                        var0.d(8);
                        var14_16 = var0.f();
                        var0.d(6);
                    } else {
                        var0.d(16);
                        var14_16 = 0;
                    }
                    if (var14_16 != 0 && var14_16 != 1) ** GOTO lbl52
                    var17_18 = var0.f();
                    var0.d(6);
                    var7_10 = var0.a;
                    var12_14 = var0.b;
                    var0.b = var12_14 + 1;
                    var12_14 = var7_10[var12_14];
                    var7_10 = var0.a;
                    var13_15 = var0.b;
                    var0.b = var13_15 + 1;
                    var18_19 = (var12_14 & 255) << 8 | var7_10[var13_15] & 255;
                    var0.b += 2;
                    var12_14 = var18_19;
                    var13_15 = var17_18;
                    if (var14_16 == 1) {
                        var0.d(16);
                        var13_15 = var17_18;
                        var12_14 = var18_19;
                    }
                    ** GOTO lbl57
lbl52: // 1 sources:
                    if (var14_16 == 2) {
                        var0.d(16);
                        var12_14 = (int)Math.round(Double.longBitsToDouble(var0.m()));
                        var13_15 = var0.o();
                        var0.d(20);
lbl57: // 2 sources:
                        var17_18 = var0.b;
                        var14_16 = var15_17;
                        if (var15_17 == com.google.android.exoplayer2.c.d.a.aa) {
                            var14_16 = b.a(var0, var20_21, var21_20, var11_7, var16_8);
                            var0.c(var17_18);
                        }
                        var7_10 = var14_16 == com.google.android.exoplayer2.c.d.a.n ? "audio/ac3" : (var14_16 == com.google.android.exoplayer2.c.d.a.p ? "audio/eac3" : (var14_16 == com.google.android.exoplayer2.c.d.a.r ? "audio/vnd.dts" : (var14_16 == com.google.android.exoplayer2.c.d.a.s || var14_16 == com.google.android.exoplayer2.c.d.a.t ? "audio/vnd.dts.hd" : (var14_16 == com.google.android.exoplayer2.c.d.a.u ? "audio/vnd.dts.hd;profile=lbr" : (var14_16 == com.google.android.exoplayer2.c.d.a.ay ? "audio/3gpp" : (var14_16 == com.google.android.exoplayer2.c.d.a.az ? "audio/amr-wb" : (var14_16 == com.google.android.exoplayer2.c.d.a.l || var14_16 == com.google.android.exoplayer2.c.d.a.m ? "audio/raw" : (var14_16 == com.google.android.exoplayer2.c.d.a.j ? "audio/mpeg" : (var14_16 == com.google.android.exoplayer2.c.d.a.aO ? "audio/alac" : null)))))))));
                    }
                    ** GOTO lbl180
lbl64: // 1 sources:
                    if (var15_17 == com.google.android.exoplayer2.c.d.a.aj) {
                        var11_7.b = Format.a(Integer.toString(var1_1), "application/ttml+xml", 0, var3_3, var4_4);
                    } else if (var15_17 == com.google.android.exoplayer2.c.d.a.au) {
                        var11_7.b = Format.a(Integer.toString(var1_1), "application/x-quicktime-tx3g", 0, var3_3, var4_4);
                    } else if (var15_17 == com.google.android.exoplayer2.c.d.a.av) {
                        var11_7.b = Format.a(Integer.toString(var1_1), "application/x-mp4-vtt", 0, var3_3, var4_4);
                    } else if (var15_17 == com.google.android.exoplayer2.c.d.a.aw) {
                        var11_7.b = Format.a(Integer.toString(var1_1), "application/ttml+xml", var3_3, var4_4);
                    } else if (var15_17 == com.google.android.exoplayer2.c.d.a.ax) {
                        var11_7.b = Format.a(Integer.toString(var1_1), "application/x-mp4-cea-608", 0, var3_3, var4_4);
                        var11_7.d = 1;
                    } else if (var15_17 == com.google.android.exoplayer2.c.d.a.aN) {
                        var11_7.b = Format.a(Integer.toString(var1_1), "application/x-camera-motion", var4_4);
                    }
                    ** GOTO lbl180
                    break block42;
lbl84: // 1 sources:
                    var8_11 = null;
                    var7_10 = null;
                    var9_12 = null;
                    var17_18 = -1;
                    var12_14 = 0;
                    var15_17 = var13_15;
                    var13_15 = var17_18;
                    block6 : do {
                        if (var15_17 - var20_21 >= var21_20) ** GOTO lbl164
                        var0.c(var15_17);
                        var24_25 = var0.b;
                        var23_22 = var0.k();
                        if (var23_22 == 0 && var0.b - var20_21 == var21_20) ** GOTO lbl164
                        var26_26 = var23_22 > 0;
                        a.a.a.a.d.a(var26_26, (Object)"childAtomSize should be positive");
                        var17_18 = var0.k();
                        if (var17_18 != com.google.android.exoplayer2.c.d.a.H) ** GOTO lbl111
                        var26_26 = var7_10 == null;
                        a.a.a.a.d.b(var26_26);
                        var7_10 = "video/avc";
                        var0.c(var24_25 + 8);
                        var10_13 = com.google.android.exoplayer2.j.a.a(var0);
                        var8_11 = var10_13.a;
                        var11_7.c = var10_13.b;
                        if (var12_14 == 0) {
                            var6_9 = var10_13.e;
                        }
                        ** GOTO lbl167
lbl111: // 1 sources:
                        if (var17_18 != com.google.android.exoplayer2.c.d.a.I) ** GOTO lbl120
                        var26_26 = var7_10 == null;
                        a.a.a.a.d.b(var26_26);
                        var7_10 = "video/hevc";
                        var0.c(var24_25 + 8);
                        var10_13 = com.google.android.exoplayer2.j.b.a(var0);
                        var8_11 = var10_13.a;
                        var11_7.c = var10_13.b;
                        ** GOTO lbl167
lbl120: // 1 sources:
                        if (var17_18 != com.google.android.exoplayer2.c.d.a.aM) ** GOTO lbl125
                        var26_26 = var7_10 == null;
                        a.a.a.a.d.b(var26_26);
                        var7_10 = var14_16 == com.google.android.exoplayer2.c.d.a.aK ? "video/x-vnd.on2.vp8" : "video/x-vnd.on2.vp9";
                        ** GOTO lbl167
lbl125: // 1 sources:
                        if (var17_18 != com.google.android.exoplayer2.c.d.a.g) ** GOTO lbl130
                        var26_26 = var7_10 == null;
                        a.a.a.a.d.b(var26_26);
                        var7_10 = "video/3gpp";
                        ** GOTO lbl167
lbl130: // 1 sources:
                        if (var17_18 != com.google.android.exoplayer2.c.d.a.J) ** GOTO lbl137
                        var26_26 = var7_10 == null;
                        a.a.a.a.d.b(var26_26);
                        var8_11 = b.a(var0, var24_25);
                        var7_10 = (String)var8_11.first;
                        var8_11 = Collections.singletonList(var8_11.second);
                        ** GOTO lbl167
lbl137: // 1 sources:
                        if (var17_18 != com.google.android.exoplayer2.c.d.a.ai) ** GOTO lbl144
                        var0.c(var24_25 + 8);
                        var12_14 = var0.o();
                        var17_18 = var0.o();
                        var6_9 = (float)var12_14 / (float)var17_18;
                        var12_14 = 1;
                        ** GOTO lbl167
lbl144: // 1 sources:
                        if (var17_18 == com.google.android.exoplayer2.c.d.a.aI) {
                            var17_18 = var24_25 + 8;
                            break;
                        }
                        if (var17_18 != com.google.android.exoplayer2.c.d.a.aH) ** GOTO lbl167
                        var17_18 = var0.e();
                        var0.d(3);
                        if (var17_18 != 0) ** GOTO lbl167
                        switch (var0.e()) {
                            default: {
                                break;
                            }
                            case 0: {
                                var13_15 = 0;
                                break;
                            }
                            case 1: {
                                var13_15 = 1;
                                break;
                            }
                            case 2: {
                                var13_15 = 2;
                                break;
                            }
                        }
                        ** GOTO lbl167
lbl164: // 2 sources:
                        if (var7_10 != null) {
                            var11_7.b = Format.a(Integer.toString(var1_1), (String)var7_10, -1, var18_19, var22_23, var8_11, var2_2, var6_9, (byte[])var9_12, var13_15, var4_4);
                        }
                        break block43;
lbl167: // 11 sources:
                        do {
                            var15_17 += var23_22;
                            continue block6;
                            break;
                        } while (true);
                        break;
                    } while (true);
                    while (var17_18 - var24_25 < var23_22) {
                        var0.c(var17_18);
                        var25_24 = var0.k();
                        if (var0.k() != com.google.android.exoplayer2.c.d.a.aJ) ** GOTO lbl176
                        var9_12 = Arrays.copyOfRange(var0.a, var17_18, var25_24 + var17_18);
                        ** GOTO lbl167
lbl176: // 1 sources:
                        var17_18 += var25_24;
                    }
                    var9_12 = null;
                    ** continue;
                }
lbl181: // 3 sources:
                do {
                    var0.c(var20_21 + var21_20);
                    ++var16_8;
                    continue block5;
                    break;
                } while (true);
            }
            return var11_7;
        }
        var8_11 = null;
        var14_16 = var13_15;
        var13_15 = var17_18;
        block10 : do {
            if (var13_15 - var20_21 >= var21_20) ** GOTO lbl234
            var0.c(var13_15);
            var18_19 = var0.k();
            var26_26 = var18_19 > 0;
            a.a.a.a.d.a(var26_26, (Object)"childAtomSize should be positive");
            var22_23 = var0.k();
            if (var22_23 != com.google.android.exoplayer2.c.d.a.J && (!var5_5 || var22_23 != com.google.android.exoplayer2.c.d.a.k)) ** GOTO lbl203
            if (var22_23 != com.google.android.exoplayer2.c.d.a.J) ** GOTO lbl201
            var15_17 = var13_15;
            ** GOTO lbl240
lbl201: // 1 sources:
            var15_17 = var0.b;
            break;
lbl203: // 1 sources:
            if (var22_23 == com.google.android.exoplayer2.c.d.a.o) {
                var0.c(var13_15 + 8);
                var11_7.b = com.google.android.exoplayer2.a.a.a(var0, Integer.toString(var1_1), var3_3, var4_4);
                var9_12 = var7_10;
                var17_18 = var14_16;
                var15_17 = var12_14;
            } else if (var22_23 == com.google.android.exoplayer2.c.d.a.q) {
                var0.c(var13_15 + 8);
                var11_7.b = com.google.android.exoplayer2.a.a.b(var0, Integer.toString(var1_1), var3_3, var4_4);
                var9_12 = var7_10;
                var17_18 = var14_16;
                var15_17 = var12_14;
            } else if (var22_23 == com.google.android.exoplayer2.c.d.a.v) {
                var11_7.b = Format.a(Integer.toString(var1_1), var7_10, -1, -1, var14_16, var12_14, null, var4_4, var3_3);
                var9_12 = var7_10;
                var17_18 = var14_16;
                var15_17 = var12_14;
            } else {
                var9_12 = var7_10;
                var17_18 = var14_16;
                var15_17 = var12_14;
                if (var22_23 == com.google.android.exoplayer2.c.d.a.aO) {
                    var8_11 = new byte[var18_19];
                    var0.c(var13_15);
                    var0.a(var8_11, 0, var18_19);
                    var9_12 = var7_10;
                    var17_18 = var14_16;
                    var15_17 = var12_14;
                }
            }
            ** GOTO lbl256
lbl234: // 1 sources:
            if (var11_7.b != null || var7_10 == null) ** GOTO lbl181
            var13_15 = "audio/raw".equals(var7_10) != false ? 2 : -1;
            var9_12 = Integer.toString(var1_1);
            var8_11 = var8_11 == null ? null : Collections.singletonList(var8_11);
            var11_7.b = Format.a((String)var9_12, var7_10, -1, -1, var14_16, var12_14, var13_15, var8_11, var4_4, 0, var3_3);
            ** continue;
lbl240: // 3 sources:
            do {
                if (var15_17 != -1) {
                    var7_10 = b.a(var0, var15_17);
                    var9_12 = (String)var7_10.first;
                    var10_13 = (byte[])var7_10.second;
                    var7_10 = var9_12;
                    var8_11 = var10_13;
                    if ("audio/mp4a-latm".equals(var9_12)) {
                        var7_10 = com.google.android.exoplayer2.i.a.a(var10_13);
                        var12_14 = (Integer)var7_10.first;
                        var14_16 = (Integer)var7_10.second;
                        var8_11 = var10_13;
                        var7_10 = var9_12;
                    }
                }
                var15_17 = var12_14;
                var17_18 = var14_16;
                var9_12 = var7_10;
lbl256: // 5 sources:
                var13_15 += var18_19;
                var7_10 = var9_12;
                var14_16 = var17_18;
                var12_14 = var15_17;
                continue block10;
                break;
            } while (true);
            break;
        } while (true);
        while (var15_17 - var13_15 < var18_19) {
            var0.c(var15_17);
            var17_18 = var0.k();
            var26_26 = var17_18 > 0;
            a.a.a.a.d.a(var26_26, (Object)"childAtomSize should be positive");
            if (var0.k() == com.google.android.exoplayer2.c.d.a.J) ** GOTO lbl240
            var15_17 += var17_18;
        }
        var15_17 = -1;
        ** while (true)
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static com.google.android.exoplayer2.c.d.i a(a.a var0, a.b var1_1, long var2_2, DrmInitData var4_3, boolean var5_4) {
        block11 : {
            var7_5 = var0.e(com.google.android.exoplayer2.c.d.a.E);
            var6_6 = var7_5.d((int)com.google.android.exoplayer2.c.d.a.S).aQ;
            var6_6.c(16);
            var8_7 = var6_6.k();
            if (var8_7 == b.b) {
                var8_7 = 1;
            } else if (var8_7 == b.a) {
                var8_7 = 2;
            } else if (var8_7 == b.c || var8_7 == b.d || var8_7 == b.e || var8_7 == b.f) {
                var8_7 = 3;
            } else {
                if (var8_7 != b.h) return null;
                var8_7 = 4;
            }
            if (var8_7 == -1) {
                return null;
            }
            var6_6 = var0.d((int)com.google.android.exoplayer2.c.d.a.O).aQ;
            var6_6.c(8);
            var14_8 = com.google.android.exoplayer2.c.d.a.a(var6_6.k());
            var9_9 = var14_8 == 0 ? 8 : 16;
            var6_6.d(var9_9);
            var13_10 = var6_6.k();
            var6_6.d(4);
            var12_11 = 1;
            var15_12 = var6_6.b;
            var9_9 = var14_8 == 0 ? 4 : 8;
            var10_13 = 0;
            do {
                var11_14 = var12_11;
                if (var10_13 >= var9_9) ** GOTO lbl34
                if (var6_6.a[var15_12 + var10_13] != -1) {
                    var11_14 = 0;
lbl34: // 2 sources:
                    if (var11_14 == 0) break;
                    var6_6.d(var9_9);
                    var16_15 = -9223372036854775807L;
                    break block11;
                }
                ++var10_13;
            } while (true);
            var18_16 = var14_8 == 0 ? var6_6.i() : var6_6.q();
            var16_15 = var18_16;
            if (var18_16 == 0) {
                var16_15 = -9223372036854775807L;
            }
        }
        var6_6.d(16);
        var9_9 = var6_6.k();
        var10_13 = var6_6.k();
        var6_6.d(4);
        var11_14 = var6_6.k();
        var12_11 = var6_6.k();
        var9_9 = var9_9 == 0 && var10_13 == 65536 && var11_14 == -65536 && var12_11 == 0 ? 90 : (var9_9 == 0 && var10_13 == -65536 && var11_14 == 65536 && var12_11 == 0 ? 270 : (var9_9 == -65536 && var10_13 == 0 && var11_14 == 0 && var12_11 == -65536 ? 180 : 0));
        var6_6 = new f(var13_10, var16_15, var9_9);
        if (var2_2 == -9223372036854775807L) {
            var2_2 = var6_6.b;
        }
        var1_1 = var1_1.aQ;
        var1_1.c(8);
        var9_9 = com.google.android.exoplayer2.c.d.a.a(var1_1.k()) == 0 ? 8 : 16;
        var1_1.d(var9_9);
        var16_15 = var1_1.i();
        var2_2 = var2_2 == -9223372036854775807L ? -9223372036854775807L : o.a(var2_2, 1000000, var16_15);
        var1_1 = var7_5.e(com.google.android.exoplayer2.c.d.a.F).e(com.google.android.exoplayer2.c.d.a.G);
        var7_5 = var7_5.d((int)com.google.android.exoplayer2.c.d.a.R).aQ;
        var7_5.c(8);
        var10_13 = com.google.android.exoplayer2.c.d.a.a(var7_5.k());
        var9_9 = var10_13 == 0 ? 8 : 16;
        var7_5.d(var9_9);
        var18_16 = var7_5.i();
        var9_9 = var10_13 == 0 ? 4 : 8;
        var7_5.d(var9_9);
        var9_9 = var7_5.f();
        var7_5 = Pair.create((Object)var18_16, (Object)("" + (char)((var9_9 >> 10 & 31) + 96) + (char)((var9_9 >> 5 & 31) + 96) + (char)((var9_9 & 31) + 96)));
        var1_1 = b.a(var1_1.d((int)com.google.android.exoplayer2.c.d.a.T).aQ, var6_6.a, var6_6.c, (String)var7_5.second, var4_3, var5_4);
        var0 = b.a(var0.e(com.google.android.exoplayer2.c.d.a.P));
        if (var1_1.b != null) return new com.google.android.exoplayer2.c.d.i(var6_6.a, var8_7, (Long)var7_5.first, var16_15, var2_2, var1_1.b, var1_1.d, var1_1.a, var1_1.c, (long[])var0.first, (long[])var0.second);
        return null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static l a(com.google.android.exoplayer2.c.d.i var0, a.a var1_1, j var2_2) {
        var3_3 = var1_1.d(com.google.android.exoplayer2.c.d.a.aq);
        if (var3_3 != null) {
            var4_4 = new d((a.b)var3_3);
        } else {
            var3_3 = var1_1.d(com.google.android.exoplayer2.c.d.a.ar);
            if (var3_3 == null) {
                throw new i("Track has no sample table size information");
            }
            var4_4 = new e((a.b)var3_3);
        }
        if ((var28_5 = var4_4.a()) == 0) {
            return new l(new long[0], new int[0], 0, new long[0], new int[0]);
        }
        var37_6 = false;
        var3_3 = var5_7 = var1_1.d(com.google.android.exoplayer2.c.d.a.as);
        if (var5_7 == null) {
            var37_6 = true;
            var3_3 = var1_1.d(com.google.android.exoplayer2.c.d.a.at);
        }
        var6_8 = var3_3.aQ;
        var7_9 = var1_1.d((int)com.google.android.exoplayer2.c.d.a.ap).aQ;
        var9_10 = var1_1.d((int)com.google.android.exoplayer2.c.d.a.am).aQ;
        var3_3 = var1_1.d(com.google.android.exoplayer2.c.d.a.an);
        var3_3 = var3_3 != null ? var3_3.aQ : null;
        var5_7 = (var1_1 = var1_1.d(com.google.android.exoplayer2.c.d.a.ao)) != null ? var1_1.aQ : null;
        var10_11 = new a((com.google.android.exoplayer2.i.i)var7_9, (com.google.android.exoplayer2.i.i)var6_8, var37_6);
        var9_10.c(12);
        var19_12 = var9_10.o() - 1;
        var20_13 = var9_10.o();
        var15_14 = var9_10.o();
        var13_15 = 0;
        if (var5_7 != null) {
            var5_7.c(12);
            var13_15 = var5_7.o();
        }
        if (var3_3 != null) {
            var3_3.c(12);
            var11_16 = var3_3.o();
            if (var11_16 > 0) {
                var14_17 = var3_3.o() - 1;
                var1_1 = var3_3;
                var12_18 = var11_16;
                var11_16 = var14_17;
            } else {
                var14_17 = -1;
                var1_1 = null;
                var12_18 = var11_16;
                var11_16 = var14_17;
            }
        } else {
            var11_16 = -1;
            var1_1 = var3_3;
            var12_18 = 0;
        }
        var14_17 = var4_4.c() != false && "audio/raw".equals(var0.f.f) != false && var19_12 == 0 && var13_15 == 0 && var12_18 == 0 ? 1 : 0;
        if (var14_17 != 0) {
            var1_1 = new long[var10_11.a];
            var3_3 = new int[var10_11.a];
            while (var10_11.a()) {
                var1_1[var10_11.b] = var10_11.d;
                var3_3[var10_11.b] = var10_11.c;
            }
            var4_4 = a.a.a.a.d.a(var4_4.b(), var1_1, (int[])var3_3, (long)var15_14);
            var1_1 = var4_4.a;
            var3_3 = var4_4.b;
            var11_16 = var4_4.c;
            var5_7 = var4_4.d;
            var4_4 = var4_4.e;
            var29_24 = 0;
        } else {
            var6_8 = new long[var28_5];
            var3_3 = new int[var28_5];
            var7_9 = new long[var28_5];
            var8_19 = new int[var28_5];
            var31_20 = 0;
            var16_22 = 0;
            var23_23 = 0;
            var14_17 = var13_15;
            var29_24 = 0;
            var24_25 = 0;
            var17_26 = 0;
            var13_15 = var15_14;
            var21_27 = var11_16;
            var22_28 = var12_18;
            var12_18 = var13_15;
            var13_15 = var24_25;
            var11_16 = var14_17;
            var15_14 = var23_23;
            for (var18_21 = 0; var18_21 < var28_5; ++var18_21, var31_20 += var35_32, --var17_26) {
                while (var17_26 == 0) {
                    a.a.a.a.d.b(var10_11.a());
                    var31_20 = var10_11.d;
                    var17_26 = var10_11.c;
                }
                var25_29 = var15_14;
                var24_25 = var11_16;
                var23_23 = var16_22;
                if (var5_7 != null) {
                    while (var16_22 == 0 && var11_16 > 0) {
                        var16_22 = var5_7.o();
                        var15_14 = var5_7.k();
                        --var11_16;
                    }
                    var23_23 = var16_22 - 1;
                    var24_25 = var11_16;
                    var25_29 = var15_14;
                }
                var6_8[var18_21] = var31_20;
                var3_3[var18_21] = var4_4.b();
                var26_31 = var13_15;
                if (var3_3[var18_21] > var13_15) {
                    var26_31 = var3_3[var18_21];
                }
                var7_9[var18_21] = (long)var25_29 + var29_24;
                var11_16 = var1_1 == null ? 1 : 0;
                var8_19[var18_21] = var11_16;
                var14_17 = var22_28;
                var27_30 = var21_27;
                if (var18_21 == var21_27) {
                    var8_19[var18_21] = 1;
                    var11_16 = var22_28 - 1;
                    if (var11_16 > 0) {
                        var27_30 = var1_1.o() - 1;
                        var14_17 = var11_16;
                    } else {
                        var14_17 = var11_16;
                        var27_30 = var21_27;
                    }
                }
                var33_33 = var12_18;
                var13_15 = var20_13 - 1;
                if (var13_15 == 0 && var19_12 > 0) {
                    var12_18 = var9_10.o();
                    var11_16 = var9_10.o();
                    --var19_12;
                } else {
                    var11_16 = var12_18;
                    var12_18 = var13_15;
                }
                var35_32 = var3_3[var18_21];
                var20_13 = var12_18;
                var12_18 = var11_16;
                var29_24 = var33_33 + var29_24;
                var15_14 = var25_29;
                var11_16 = var24_25;
                var16_22 = var23_23;
                var13_15 = var26_31;
                var22_28 = var14_17;
                var21_27 = var27_30;
            }
            var37_6 = var16_22 == 0;
            a.a.a.a.d.a(var37_6);
            while (var11_16 > 0) {
                var37_6 = var5_7.o() == 0;
                a.a.a.a.d.a(var37_6);
                var5_7.k();
                --var11_16;
            }
            if (var22_28 != 0 || var20_13 != 0 || var17_26 != 0 || var19_12 != 0) {
                Log.w((String)"AtomParsers", (String)("Inconsistent stbl box for track " + var0.a + ": remainingSynchronizationSamples " + var22_28 + ", remainingSamplesAtTimestampDelta " + var20_13 + ", remainingSamplesInChunk " + var17_26 + ", remainingTimestampDeltaChanges " + var19_12));
            }
            var4_4 = var8_19;
            var5_7 = var7_9;
            var11_16 = var13_15;
            var1_1 = var6_8;
        }
        if (var0.i == null || var2_2.a()) {
            o.a((long[])var5_7, var0.c);
            return new l(var1_1, (int[])var3_3, var11_16, (long[])var5_7, var4_4);
        }
        if (var0.i.length == 1 && var0.b == 1 && var5_7.length >= 2) {
            var33_33 = var0.j[0];
            var31_20 = o.a(var0.i[0], var0.c, var0.d) + var33_33;
            if (var5_7[0] <= var33_33 && var33_33 < var5_7[1] && var5_7[var5_7.length - 1] < var31_20 && var31_20 <= var29_24) {
                var33_33 = o.a(var33_33 - var5_7[0], (long)var0.f.r, var0.c);
                var29_24 = o.a(var29_24 - var31_20, (long)var0.f.r, var0.c);
                if ((var33_33 != 0 || var29_24 != 0) && var33_33 <= Integer.MAX_VALUE && var29_24 <= Integer.MAX_VALUE) {
                    var2_2.a = (int)var33_33;
                    var2_2.b = (int)var29_24;
                    o.a((long[])var5_7, var0.c);
                    return new l(var1_1, (int[])var3_3, var11_16, (long[])var5_7, var4_4);
                }
            }
        }
        if (var0.i.length == 1 && var0.i[0] == 0) {
            var12_18 = 0;
            while (var12_18 < var5_7.length) {
                var5_7[var12_18] = o.a(var5_7[var12_18] - var0.j[0], 1000000, var0.c);
                ++var12_18;
            }
            return new l(var1_1, (int[])var3_3, var11_16, (long[])var5_7, var4_4);
        }
        var15_14 = 0;
        var13_15 = 0;
        var14_17 = 0;
        var12_18 = 0;
        do {
            if (var15_14 >= var0.i.length) ** GOTO lbl191
            var29_24 = var0.j[var15_14];
            if (var29_24 == -1) ** GOTO lbl202
            var31_20 = o.a(var0.i[var15_14], var0.c, var0.d);
            var18_21 = o.a((long[])var5_7, var29_24, true, true);
            var16_22 = o.a((long[])var5_7, var31_20 + var29_24, true, false);
            var17_26 = var12_18 + (var16_22 - var18_21);
            var12_18 = var14_17 != var18_21 ? 1 : 0;
            var14_17 = var12_18 | var13_15;
            var12_18 = var17_26;
            var13_15 = var16_22;
            ** GOTO lbl205
lbl191: // 1 sources:
            var14_17 = var12_18 != var28_5 ? 1 : 0;
            var16_22 = var13_15 | var14_17;
            var2_2 = var16_22 != 0 ? new long[var12_18] : var1_1;
            var6_8 = var16_22 != 0 ? new int[var12_18] : var3_3;
            if (var16_22 != 0) {
                var11_16 = 0;
            }
            var7_9 = var16_22 != 0 ? new int[var12_18] : var4_4;
            var8_19 = new long[var12_18];
            var29_24 = 0;
            var12_18 = 0;
            break;
lbl202: // 1 sources:
            var16_22 = var14_17;
            var14_17 = var13_15;
            var13_15 = var16_22;
lbl205: // 2 sources:
            ++var15_14;
            var16_22 = var13_15;
            var13_15 = var14_17;
            var14_17 = var16_22;
        } while (true);
        for (var13_15 = 0; var13_15 < var0.i.length; ++var13_15, var29_24 += var33_33) {
            var31_20 = var0.j[var13_15];
            var33_33 = var0.i[var13_15];
            var15_14 = var12_18;
            var14_17 = var11_16;
            if (var31_20 != -1) {
                var35_32 = o.a(var33_33, var0.c, var0.d);
                var14_17 = o.a((long[])var5_7, var31_20, true, true);
                var17_26 = o.a((long[])var5_7, var31_20 + var35_32, true, false);
                if (var16_22 != 0) {
                    var15_14 = var17_26 - var14_17;
                    System.arraycopy(var1_1, var14_17, var2_2, var12_18, var15_14);
                    System.arraycopy(var3_3, var14_17, var6_8, var12_18, var15_14);
                    System.arraycopy(var4_4, var14_17, var7_9, var12_18, var15_14);
                }
                var15_14 = var11_16;
                var11_16 = var12_18;
                var12_18 = var15_14;
                while (var14_17 < var17_26) {
                    var35_32 = o.a(var29_24, 1000000, var0.d);
                    var8_19[var11_16] = (int)(o.a(var5_7[var14_17] - var31_20, 1000000, var0.c) + var35_32);
                    var15_14 = var12_18;
                    if (var16_22 != 0) {
                        var15_14 = var12_18;
                        if (var6_8[var11_16] > var12_18) {
                            var15_14 = var3_3[var14_17];
                        }
                    }
                    ++var11_16;
                    ++var14_17;
                    var12_18 = var15_14;
                }
                var14_17 = var12_18;
                var15_14 = var11_16;
            }
            var12_18 = var15_14;
            var11_16 = var14_17;
        }
        var13_15 = 0;
        for (var12_18 = 0; var12_18 < var7_9.length && var13_15 == 0; var13_15 |= var14_17, ++var12_18) {
            var14_17 = (var7_9[var12_18] & true) != 0 ? 1 : 0;
        }
        if (var13_15 != 0) return new l(var2_2, (int[])var6_8, var11_16, var8_19, (int[])var7_9);
        throw new i("The edited sample sequence does not contain a sync sample.");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Metadata a(a.b object, boolean bl2) {
        if (!bl2) {
            object = object.aQ;
            object.c(8);
            block0 : while (object.b() >= 8) {
                int n2 = object.b;
                int n3 = object.k();
                if (object.k() == com.google.android.exoplayer2.c.d.a.aB) {
                    object.c(n2);
                    object.d(12);
                } else {
                    object.d(n3 - 8);
                    continue;
                }
                while (object.b < n2 + n3) {
                    int n4 = object.b;
                    int n5 = object.k();
                    if (object.k() == com.google.android.exoplayer2.c.d.a.aC) {
                        object.c(n4);
                        object.d(8);
                        ArrayList<Metadata.Entry> arrayList = new ArrayList<Metadata.Entry>();
                        while (object.b < n4 + n5) {
                            Metadata.Entry entry = com.google.android.exoplayer2.c.d.f.a((com.google.android.exoplayer2.i.i)object);
                            if (entry == null) continue;
                            arrayList.add(entry);
                        }
                        if (arrayList.isEmpty()) break block0;
                        return new Metadata(arrayList);
                    }
                    object.d(n5 - 8);
                }
                break block0;
            }
        }
        return null;
    }

    static final class a {
        public final int a;
        public int b;
        public int c;
        public long d;
        private final boolean e;
        private final com.google.android.exoplayer2.i.i f;
        private final com.google.android.exoplayer2.i.i g;
        private int h;
        private int i;

        /*
         * Enabled aggressive block sorting
         */
        public a(com.google.android.exoplayer2.i.i i2, com.google.android.exoplayer2.i.i i3, boolean bl2) {
            boolean bl3 = true;
            this.g = i2;
            this.f = i3;
            this.e = bl2;
            i3.c(12);
            this.a = i3.o();
            i2.c(12);
            this.i = i2.o();
            bl2 = i2.k() == 1 ? bl3 : false;
            a.a.a.a.d.b(bl2, (Object)"first_chunk must be 1");
            this.b = -1;
        }

        /*
         * Enabled aggressive block sorting
         */
        public final boolean a() {
            int n2;
            this.b = n2 = this.b + 1;
            if (n2 == this.a) {
                return false;
            }
            long l2 = this.e ? this.f.q() : this.f.i();
            this.d = l2;
            if (this.b == this.h) {
                this.c = this.g.o();
                this.g.d(4);
                this.i = n2 = this.i - 1;
                n2 = n2 > 0 ? this.g.o() - 1 : -1;
                this.h = n2;
            }
            return true;
        }
    }

    static interface b {
        public int a();

        public int b();

        public boolean c();
    }

    static final class c {
        public final com.google.android.exoplayer2.c.d.j[] a;
        public Format b;
        public int c;
        public int d;

        public c(int n2) {
            this.a = new com.google.android.exoplayer2.c.d.j[n2];
            this.d = 0;
        }
    }

    static final class d
    implements b {
        private final int a;
        private final int b;
        private final com.google.android.exoplayer2.i.i c;

        public d(a.b b2) {
            this.c = b2.aQ;
            this.c.c(12);
            this.a = this.c.o();
            this.b = this.c.o();
        }

        @Override
        public final int a() {
            return this.b;
        }

        @Override
        public final int b() {
            if (this.a == 0) {
                return this.c.o();
            }
            return this.a;
        }

        @Override
        public final boolean c() {
            if (this.a != 0) {
                return true;
            }
            return false;
        }
    }

    static final class e
    implements b {
        private final com.google.android.exoplayer2.i.i a;
        private final int b;
        private final int c;
        private int d;
        private int e;

        public e(a.b b2) {
            this.a = b2.aQ;
            this.a.c(12);
            this.c = this.a.o() & 255;
            this.b = this.a.o();
        }

        @Override
        public final int a() {
            return this.b;
        }

        @Override
        public final int b() {
            if (this.c == 8) {
                return this.a.e();
            }
            if (this.c == 16) {
                return this.a.f();
            }
            int n2 = this.d;
            this.d = n2 + 1;
            if (n2 % 2 == 0) {
                this.e = this.a.e();
                return (this.e & 240) >> 4;
            }
            return this.e & 15;
        }

        @Override
        public final boolean c() {
            return false;
        }
    }

    static final class f {
        final int a;
        final long b;
        final int c;

        public f(int n2, long l2, int n3) {
            this.a = n2;
            this.b = l2;
            this.c = n3;
        }
    }

}

