/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.d;

final class c {
    public final int a;
    public final int b;
    public final int c;
    public final int d;

    public c(int n2, int n3, int n4, int n5) {
        this.a = n2;
        this.b = n3;
        this.c = n4;
        this.d = n5;
    }
}

