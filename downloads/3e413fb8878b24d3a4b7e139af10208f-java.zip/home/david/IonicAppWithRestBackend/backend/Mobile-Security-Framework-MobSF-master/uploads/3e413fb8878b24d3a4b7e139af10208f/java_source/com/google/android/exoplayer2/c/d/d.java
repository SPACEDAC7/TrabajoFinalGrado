/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.d;

public final class d {
    public final long[] a;
    public final int[] b;
    public final int c;
    public final long[] d;
    public final int[] e;

    private d(long[] arrl, int[] arrn, int n2, long[] arrl2, int[] arrn2) {
        this.a = arrl;
        this.b = arrn;
        this.c = n2;
        this.d = arrl2;
        this.e = arrn2;
    }

    public /* synthetic */ d(long[] arrl, int[] arrn, int n2, long[] arrl2, int[] arrn2, byte by2) {
        this(arrl, arrn, n2, arrl2, arrn2);
    }
}

