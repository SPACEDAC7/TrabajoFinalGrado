/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  android.util.Pair
 *  android.util.SparseArray
 */
package com.google.android.exoplayer2.c.d;

import a.a.a.a.d;
import android.util.Log;
import android.util.Pair;
import android.util.SparseArray;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.d.a;
import com.google.android.exoplayer2.c.d.c;
import com.google.android.exoplayer2.c.d.j;
import com.google.android.exoplayer2.c.d.k;
import com.google.android.exoplayer2.c.f;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.i;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.Metadata;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.UUID;

public final class e
implements f {
    public static final com.google.android.exoplayer2.c.i a = new com.google.android.exoplayer2.c.i(){

        @Override
        public final f[] a() {
            return new f[]{new e()};
        }
    };
    private static final int b = o.e("seig");
    private static final byte[] c = new byte[]{-94, 57, 79, 82, 90, -101, 79, 20, -94, 68, 108, 66, 124, 100, -115, -12};
    private int A;
    private int B;
    private h C;
    private n D;
    private n E;
    private boolean F;
    private final int d = 0;
    private final com.google.android.exoplayer2.c.d.i e = null;
    private final SparseArray<b> f = new SparseArray();
    private final com.google.android.exoplayer2.i.i g = new com.google.android.exoplayer2.i.i(com.google.android.exoplayer2.i.g.a);
    private final com.google.android.exoplayer2.i.i h = new com.google.android.exoplayer2.i.i(4);
    private final com.google.android.exoplayer2.i.i i = new com.google.android.exoplayer2.i.i(1);
    private final com.google.android.exoplayer2.i.i j = new com.google.android.exoplayer2.i.i(1);
    private final com.google.android.exoplayer2.i.n k = null;
    private final com.google.android.exoplayer2.i.i l = new com.google.android.exoplayer2.i.i(16);
    private final byte[] m = new byte[16];
    private final Stack<a.a> n = new Stack();
    private final LinkedList<a> o = new LinkedList();
    private int p;
    private int q;
    private long r;
    private int s;
    private com.google.android.exoplayer2.i.i t;
    private long u;
    private int v;
    private long w = -9223372036854775807L;
    private long x = -9223372036854775807L;
    private b y;
    private int z;

    public e() {
        this(0);
    }

    private e(byte by2) {
        this('\u0000');
    }

    private e(char c2) {
        this.a();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static DrmInitData a(List<a.b> list) {
        int n2 = list.size();
        int n3 = 0;
        Object object = null;
        while (n3 < n2) {
            byte[] arrby = list.get(n3);
            ArrayList<DrmInitData.SchemeData> arrayList = object;
            if (arrby.aP == com.google.android.exoplayer2.c.d.a.U) {
                arrayList = object;
                if (object == null) {
                    arrayList = new ArrayList<DrmInitData.SchemeData>();
                }
                arrby = arrby.aQ.a;
                object = new com.google.android.exoplayer2.i.i(arrby);
                if (object.c < 32) {
                    object = null;
                } else {
                    object.c(0);
                    if (object.k() != object.b() + 4) {
                        object = null;
                    } else if (object.k() != com.google.android.exoplayer2.c.d.a.U) {
                        object = null;
                    } else {
                        int n4 = com.google.android.exoplayer2.c.d.a.a(object.k());
                        if (n4 > 1) {
                            Log.w((String)"PsshAtomUtil", (String)("Unsupported pssh version: " + n4));
                            object = null;
                        } else {
                            UUID uUID = new UUID(object.m(), object.m());
                            if (n4 == 1) {
                                object.d(object.o() << 4);
                            }
                            if ((n4 = object.o()) != object.b()) {
                                object = null;
                            } else {
                                byte[] arrby2 = new byte[n4];
                                object.a(arrby2, 0, n4);
                                object = Pair.create((Object)uUID, (Object)arrby2);
                            }
                        }
                    }
                }
                object = object == null ? null : (UUID)object.first;
                if (object == null) {
                    Log.w((String)"FragmentedMp4Extractor", (String)"Skipped pssh atom (failed to extract uuid)");
                } else {
                    arrayList.add(new DrmInitData.SchemeData((UUID)object, "video/mp4", arrby));
                }
            }
            ++n3;
            object = arrayList;
        }
        return null;
    }

    private void a() {
        this.p = 0;
        this.s = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(long l2) {
        while (!this.n.isEmpty() && this.n.peek().aQ == l2) {
            SparseArray sparseArray;
            int n2;
            a.a a2;
            Object object;
            int n3;
            boolean bl2;
            Object object2;
            long l3;
            Object object3 = this.n.pop();
            if (object3.aP == com.google.android.exoplayer2.c.d.a.B) {
                bl2 = this.e == null;
                d.b(bl2, (Object)"Unexpected moov box.");
                object = e.a(object3.aR);
                a2 = object3.e(com.google.android.exoplayer2.c.d.a.M);
                sparseArray = new SparseArray();
                l3 = -9223372036854775807L;
                n2 = a2.aR.size();
            } else {
                if (object3.aP == com.google.android.exoplayer2.c.d.a.K) {
                    this.a((a.a)object3);
                    continue;
                }
                if (this.n.isEmpty()) continue;
                this.n.peek().a((a.a)object3);
                continue;
            }
            for (n3 = 0; n3 < n2; ++n3) {
                object2 = a2.aR.get(n3);
                if (object2.aP == com.google.android.exoplayer2.c.d.a.y) {
                    object2 = object2.aQ;
                    object2.c(12);
                    object2 = Pair.create((Object)object2.k(), (Object)new c(object2.o() - 1, object2.o(), object2.o(), object2.k()));
                    sparseArray.put(((Integer)object2.first).intValue(), object2.second);
                    continue;
                }
                if (object2.aP != com.google.android.exoplayer2.c.d.a.N) continue;
                object2 = object2.aQ;
                object2.c(8);
                l3 = com.google.android.exoplayer2.c.d.a.a(object2.k()) == 0 ? object2.i() : object2.q();
            }
            a2 = new SparseArray();
            n2 = object3.aS.size();
            for (n3 = 0; n3 < n2; ++n3) {
                object2 = object3.aS.get(n3);
                if (object2.aP != com.google.android.exoplayer2.c.d.a.D || (object2 = com.google.android.exoplayer2.c.d.b.a((a.a)object2, object3.d(com.google.android.exoplayer2.c.d.a.C), l3, (DrmInitData)object, false)) == null) continue;
                a2.put(object2.a, object2);
            }
            n2 = a2.size();
            if (this.f.size() == 0) {
                for (n3 = 0; n3 < n2; ++n3) {
                    object3 = (com.google.android.exoplayer2.c.d.i)a2.valueAt(n3);
                    object = new b(this.C.a(n3));
                    object.a((com.google.android.exoplayer2.c.d.i)object3, (c)sparseArray.get(object3.a));
                    this.f.put(object3.a, object);
                    this.w = Math.max(this.w, object3.e);
                }
                this.b();
                this.C.b();
                continue;
            }
            bl2 = this.f.size() == n2;
            d.b(bl2);
            for (n3 = 0; n3 < n2; ++n3) {
                object3 = (com.google.android.exoplayer2.c.d.i)a2.valueAt(n3);
                ((b)this.f.get(object3.a)).a((com.google.android.exoplayer2.c.d.i)object3, (c)sparseArray.get(object3.a));
            }
        }
        this.a();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(a.a var1_1) {
        var3_2 = this.f;
        var31_3 = this.d;
        var4_4 = this.m;
        var32_5 = var1_1.aS.size();
        var19_6 = 0;
        do {
            block35 : {
                block36 : {
                    if (var19_6 >= var32_5) ** GOTO lbl42
                    var5_8 = var1_1.aS.get(var19_6);
                    if (var5_8.aP != com.google.android.exoplayer2.c.d.a.L) ** GOTO lbl235
                    var6_9 = var5_8.d((int)com.google.android.exoplayer2.c.d.a.x).aQ;
                    var6_9.c(8);
                    var20_23 = com.google.android.exoplayer2.c.d.a.b(var6_9.k());
                    var16_20 = var6_9.k();
                    if ((var31_3 & 16) != 0) {
                        var16_20 = 0;
                    }
                    if ((var2_7 = (b)var3_2.get(var16_20)) == null) {
                        var2_7 = null;
                    } else {
                        if ((var20_23 & 1) != 0) {
                            var2_7.a.c = var34_33 = var6_9.q();
                            var2_7.a.d = var34_33;
                        }
                        var7_10 = var2_7.d;
                        var16_20 = (var20_23 & 2) != 0 ? var6_9.o() - 1 : var7_10.a;
                        var17_19 = (var20_23 & 8) != 0 ? var6_9.o() : var7_10.b;
                        var18_21 = (var20_23 & 16) != 0 ? var6_9.o() : var7_10.c;
                        var20_23 = (var20_23 & 32) != 0 ? var6_9.o() : var7_10.d;
                        var2_7.a.a = new c(var16_20, var17_19, var18_21, var20_23);
                    }
                    if (var2_7 == null) ** GOTO lbl235
                    var6_9 = var2_7.a;
                    var34_33 = var6_9.s;
                    var2_7.a();
                    if (var5_8.d(com.google.android.exoplayer2.c.d.a.w) != null && (var31_3 & 2) == 0) {
                        var7_10 = var5_8.d((int)com.google.android.exoplayer2.c.d.a.w).aQ;
                        var7_10.c(8);
                        var34_33 = com.google.android.exoplayer2.c.d.a.a(var7_10.k()) == 1 ? var7_10.q() : var7_10.i();
                    }
                    var16_20 = 0;
                    var17_19 = 0;
                    var7_10 = var5_8.aR;
                    var33_34 = var7_10.size();
                    var18_21 = 0;
                    ** GOTO lbl54
lbl42: // 1 sources:
                    var1_1 = e.a(var1_1.aR);
                    if (var1_1 == null) return;
                    var17_19 = this.f.size();
                    var16_20 = 0;
                    while (var16_20 < var17_19) {
                        var3_2 = (b)this.f.valueAt(var16_20);
                        var2_7 = var3_2.b;
                        var3_2 = var3_2.c.f;
                        var2_7.a(new Format(var3_2.a, var3_2.e, var3_2.f, var3_2.c, var3_2.b, var3_2.g, var3_2.j, var3_2.k, var3_2.l, var3_2.m, var3_2.n, var3_2.p, var3_2.o, var3_2.q, var3_2.r, var3_2.s, var3_2.t, var3_2.u, var3_2.w, var3_2.x, var3_2.y, var3_2.v, var3_2.h, (DrmInitData)var1_1, var3_2.d));
                        ++var16_20;
                    }
                    return;
lbl54: // 2 sources:
                    while (var18_21 < var33_34) {
                        var8_11 = (a.b)var7_10.get(var18_21);
                        if (var8_11.aP != com.google.android.exoplayer2.c.d.a.z) ** GOTO lbl-1000
                        var8_11 = var8_11.aQ;
                        var8_11.c(12);
                        var20_23 = var8_11.o();
                        if (var20_23 > 0) {
                            var17_19 = var16_20 + 1;
                            var16_20 = var20_23 += var17_19;
                        } else lbl-1000: // 2 sources:
                        {
                            var20_23 = var16_20;
                            var16_20 = var17_19;
                            var17_19 = var20_23;
                        }
                        var20_23 = var18_21 + 1;
                        var18_21 = var17_19;
                        var17_19 = var16_20;
                        var16_20 = var18_21;
                        var18_21 = var20_23;
                    }
                    var2_7.g = 0;
                    var2_7.f = 0;
                    var2_7.e = 0;
                    var8_11 = var2_7.a;
                    var8_11.e = var16_20;
                    var8_11.f = var17_19;
                    if (var8_11.h == null || var8_11.h.length < var16_20) {
                        var8_11.g = new long[var16_20];
                        var8_11.h = new int[var16_20];
                    }
                    if (var8_11.i == null || var8_11.i.length < var17_19) {
                        var16_20 = var17_19 * 125 / 100;
                        var8_11.i = new int[var16_20];
                        var8_11.j = new int[var16_20];
                        var8_11.k = new long[var16_20];
                        var8_11.l = new boolean[var16_20];
                        var8_11.n = new boolean[var16_20];
                    }
                    var17_19 = 0;
                    var16_20 = 0;
                    var20_23 = 0;
                    do {
                        if (var20_23 >= var33_34) ** GOTO lbl125
                        var8_11 = (a.b)var7_10.get(var20_23);
                        if (var8_11.aP != com.google.android.exoplayer2.c.d.a.z) ** GOTO lbl143
                        var8_11 = var8_11.aQ;
                        var8_11.c(8);
                        var25_26 = com.google.android.exoplayer2.c.d.a.b(var8_11.k());
                        var9_12 = var2_7.c;
                        var10_13 = var2_7.a;
                        var11_14 = var10_13.a;
                        var10_13.h[var17_19] = var8_11.o();
                        var10_13.g[var17_19] = var10_13.c;
                        if ((var25_26 & 1) != 0) {
                            var12_15 = var10_13.g;
                            var12_15[var17_19] = var12_15[var17_19] + (long)var8_11.k();
                        }
                        var21_22 = (var25_26 & 4) != 0 ? 1 : 0;
                        var18_21 = var11_14.d;
                        if (var21_22 != 0) {
                            var18_21 = var8_11.o();
                        }
                        var22_25 = (var25_26 & 256) != 0;
                        var23_24 = (var25_26 & 512) != 0;
                        var24_27 = (var25_26 & 1024) != 0;
                        var25_26 = (var25_26 & 2048) != 0 ? 1 : 0;
                        var38_35 = var9_12.i != null && var9_12.i.length == 1 && var9_12.i[0] == 0 ? o.a(var9_12.j[0], 1000, var9_12.c) : 0;
                        var12_15 = var10_13.i;
                        var13_16 = var10_13.j;
                        var14_17 = var10_13.k;
                        var15_18 = var10_13.l;
                        var26_29 = var9_12.b == 2 && (var31_3 & 1) != 0;
                        var30_32 = var16_20 + var10_13.h[var17_19];
                        var40_38 = var9_12.c;
                        var36_36 = var17_19 > 0 ? var10_13.s : var34_33;
                        ** GOTO lbl147
lbl125: // 1 sources:
                        var7_10 = var5_8.d(com.google.android.exoplayer2.c.d.a.ac);
                        if (var7_10 == null) break block35;
                        var2_7 = var2_7.c.h[var6_9.a.a];
                        var7_10 = var7_10.aQ;
                        var20_23 = var2_7.b;
                        var7_10.c(8);
                        if ((com.google.android.exoplayer2.c.d.a.b(var7_10.k()) & 1) == 1) {
                            var7_10.d(8);
                        }
                        var17_19 = var7_10.e();
                        var21_22 = var7_10.o();
                        if (var21_22 != var6_9.f) {
                            throw new i("Length mismatch: " + var21_22 + ", " + var6_9.f);
                        }
                        var16_20 = 0;
                        if (var17_19 == 0) break;
                        var42_37 = var17_19 > var20_23;
                        Arrays.fill(var6_9.n, 0, var21_22, var42_37);
                        var18_21 = var17_19 * var21_22 + 0;
                        break block36;
lbl143: // 1 sources:
                        var18_21 = var17_19;
                        var17_19 = var16_20;
                        var16_20 = var18_21;
                        ** GOTO lbl161
lbl147: // 2 sources:
                        for (var27_28 = var16_20; var27_28 < var30_32; var36_36 += (long)var28_31, ++var27_28) {
                            var28_31 = var22_25 != false ? var8_11.o() : var11_14.b;
                            var29_30 = var23_24 != false ? var8_11.o() : var11_14.c;
                            var16_20 = var27_28 == 0 && var21_22 != 0 ? var18_21 : (var24_27 != false ? var8_11.k() : var11_14.d);
                            var13_16[var27_28] = var25_26 != 0 ? (int)((long)(var8_11.k() * 1000) / var40_38) : 0;
                            var14_17[var27_28] = o.a(var36_36, 1000, var40_38) - var38_35;
                            var12_15[var27_28] = var29_30;
                            var42_37 = (var16_20 >> 16 & 1) == 0 && (var26_29 == false || var27_28 == 0);
                            var15_18[var27_28] = var42_37;
                        }
                        var10_13.s = var36_36;
                        var18_21 = var30_32;
                        var16_20 = var17_19 + 1;
                        var17_19 = var18_21;
lbl161: // 2 sources:
                        var18_21 = var16_20;
                        ++var20_23;
                        var16_20 = var17_19;
                        var17_19 = var18_21;
                    } while (true);
                    var2_7 = var6_9.n;
                    var17_19 = 0;
                    do {
                        var18_21 = var16_20;
                        if (var17_19 >= var21_22) break;
                        var18_21 = var7_10.e();
                        var42_37 = var18_21 > var20_23;
                        var2_7[var17_19] = var42_37;
                        ++var17_19;
                        var16_20 += var18_21;
                    } while (true);
                }
                var6_9.a(var18_21);
            }
            if ((var2_7 = var5_8.d(com.google.android.exoplayer2.c.d.a.ad)) != null) {
                var2_7 = var2_7.aQ;
                var2_7.c(8);
                var16_20 = var2_7.k();
                if ((com.google.android.exoplayer2.c.d.a.b(var16_20) & 1) == 1) {
                    var2_7.d(8);
                }
                if ((var17_19 = var2_7.o()) != 1) {
                    throw new i("Unexpected saio entry count: " + var17_19);
                }
                var16_20 = com.google.android.exoplayer2.c.d.a.a(var16_20);
                var36_36 = var6_9.d;
                var34_33 = var16_20 == 0 ? var2_7.i() : var2_7.q();
                var6_9.d = var34_33 + var36_36;
            }
            if ((var2_7 = var5_8.d(com.google.android.exoplayer2.c.d.a.ah)) != null) {
                e.a(var2_7.aQ, 0, (k)var6_9);
            }
            var7_10 = var5_8.d(com.google.android.exoplayer2.c.d.a.ae);
            var2_7 = var5_8.d(com.google.android.exoplayer2.c.d.a.af);
            if (var7_10 != null && var2_7 != null) {
                var7_10 = var7_10.aQ;
                var2_7 = var2_7.aQ;
                var7_10.c(8);
                var16_20 = var7_10.k();
                if (var7_10.k() == e.b) {
                    if (com.google.android.exoplayer2.c.d.a.a(var16_20) == 1) {
                        var7_10.d(4);
                    }
                    if (var7_10.k() != 1) {
                        throw new i("Entry count in sbgp != 1 (unsupported).");
                    }
                    var2_7.c(8);
                    var16_20 = var2_7.k();
                    if (var2_7.k() == e.b) {
                        if ((var16_20 = com.google.android.exoplayer2.c.d.a.a(var16_20)) == 1) {
                            if (var2_7.i() == 0) {
                                throw new i("Variable length decription in sgpd found (unsupported)");
                            }
                        } else if (var16_20 >= 2) {
                            var2_7.d(4);
                        }
                        if (var2_7.i() != 1) {
                            throw new i("Entry count in sgpd != 1 (unsupported).");
                        }
                        var2_7.d(2);
                        var16_20 = var2_7.e() == 1 ? 1 : 0;
                        if (var16_20 != 0) {
                            var16_20 = var2_7.e();
                            var7_10 = new byte[16];
                            var2_7.a((byte[])var7_10, 0, 16);
                            var6_9.m = true;
                            var6_9.o = new j(true, var16_20, (byte[])var7_10);
                        }
                    }
                }
            }
            var17_19 = var5_8.aR.size();
            for (var16_20 = 0; var16_20 < var17_19; ++var16_20) {
                var2_7 = var5_8.aR.get(var16_20);
                if (var2_7.aP != com.google.android.exoplayer2.c.d.a.ag) continue;
                var2_7 = var2_7.aQ;
                var2_7.c(8);
                var2_7.a(var4_4, 0, 16);
                if (!Arrays.equals(var4_4, e.c)) continue;
                e.a((com.google.android.exoplayer2.i.i)var2_7, 16, (k)var6_9);
            }
lbl235: // 3 sources:
            ++var19_6;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(com.google.android.exoplayer2.i.i i2, int n2, k k2) {
        i2.c(n2 + 8);
        n2 = com.google.android.exoplayer2.c.d.a.b(i2.k());
        if ((n2 & 1) != 0) {
            throw new i("Overriding TrackEncryptionBox parameters is unsupported.");
        }
        boolean bl2 = (n2 & 2) != 0;
        n2 = i2.o();
        if (n2 != k2.f) {
            throw new i("Length mismatch: " + n2 + ", " + k2.f);
        }
        Arrays.fill(k2.n, 0, n2, bl2);
        k2.a(i2.b());
        i2.a(k2.q.a, 0, k2.p);
        k2.q.c(0);
        k2.r = false;
    }

    private void b() {
        if ((this.d & 4) != 0 && this.D == null) {
            this.D = this.C.a(this.f.size());
            this.D.a(Format.a("application/x-emsg", Long.MAX_VALUE));
        }
        if ((this.d & 8) != 0 && this.E == null) {
            this.E = this.C.a(this.f.size() + 1);
            this.E.a(Format.a(null, "application/cea-608", 0, null, null));
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(g var1_1, l var2_2) {
        block59 : {
            block57 : {
                block58 : {
                    block5 : do {
                        switch (this.p) {
                            default: {
                                if (this.p != 3) break block57;
                                if (this.y == null) {
                                    var4_4 = this.f;
                                    var2_2 = null;
                                    var11_11 = Long.MAX_VALUE;
                                    var8_8 = var4_4.size();
                                    for (var7_7 = 0; var7_7 < var8_8; ++var7_7) {
                                        var3_3 = (b)var4_4.valueAt(var7_7);
                                        if (var3_3.g == var3_3.a.e || (var13_12 = var3_3.a.g[var3_3.g]) >= var11_11) continue;
                                        var2_2 = var3_3;
                                        var11_11 = var13_12;
                                    }
                                    break;
                                }
                                break block58;
                            }
                            case 0: {
                                if (this.s == 0) {
                                    if (!var1_1.a(this.l.a, 0, 8, true)) {
                                        return -1;
                                    }
                                    this.s = 8;
                                    this.l.c(0);
                                    this.r = this.l.i();
                                    this.q = this.l.k();
                                }
                                if (this.r == 1) {
                                    var1_1.b(this.l.a, 8, 8);
                                    this.s += 8;
                                    this.r = this.l.q();
                                }
                                if (this.r < (long)this.s) {
                                    throw new i("Atom size less than header length (unsupported).");
                                }
                                var11_11 = var1_1.c() - (long)this.s;
                                if (this.q == com.google.android.exoplayer2.c.d.a.K) {
                                    var8_8 = this.f.size();
                                    for (var7_7 = 0; var7_7 < var8_8; ++var7_7) {
                                        var2_2 = ((b)this.f.valueAt((int)var7_7)).a;
                                        var2_2.b = var11_11;
                                        var2_2.d = var11_11;
                                        var2_2.c = var11_11;
                                    }
                                }
                                if (this.q == com.google.android.exoplayer2.c.d.a.h) {
                                    this.y = null;
                                    this.u = this.r + var11_11;
                                    if (!this.F) {
                                        this.C.a(new m.a(this.w));
                                        this.F = true;
                                    }
                                    this.p = 2;
                                } else {
                                    var7_7 = this.q;
                                    var7_7 = var7_7 == com.google.android.exoplayer2.c.d.a.B || var7_7 == com.google.android.exoplayer2.c.d.a.D || var7_7 == com.google.android.exoplayer2.c.d.a.E || var7_7 == com.google.android.exoplayer2.c.d.a.F || var7_7 == com.google.android.exoplayer2.c.d.a.G || var7_7 == com.google.android.exoplayer2.c.d.a.K || var7_7 == com.google.android.exoplayer2.c.d.a.L || var7_7 == com.google.android.exoplayer2.c.d.a.M || var7_7 == com.google.android.exoplayer2.c.d.a.P ? 1 : 0;
                                    if (var7_7 != 0) {
                                        var11_11 = var1_1.c() + this.r - 8;
                                        this.n.add(new a.a(this.q, var11_11));
                                        if (this.r == (long)this.s) {
                                            this.a(var11_11);
                                        } else {
                                            this.a();
                                        }
                                    } else {
                                        var7_7 = this.q;
                                        var7_7 = var7_7 == com.google.android.exoplayer2.c.d.a.S || var7_7 == com.google.android.exoplayer2.c.d.a.R || var7_7 == com.google.android.exoplayer2.c.d.a.C || var7_7 == com.google.android.exoplayer2.c.d.a.A || var7_7 == com.google.android.exoplayer2.c.d.a.T || var7_7 == com.google.android.exoplayer2.c.d.a.w || var7_7 == com.google.android.exoplayer2.c.d.a.x || var7_7 == com.google.android.exoplayer2.c.d.a.O || var7_7 == com.google.android.exoplayer2.c.d.a.y || var7_7 == com.google.android.exoplayer2.c.d.a.z || var7_7 == com.google.android.exoplayer2.c.d.a.U || var7_7 == com.google.android.exoplayer2.c.d.a.ac || var7_7 == com.google.android.exoplayer2.c.d.a.ad || var7_7 == com.google.android.exoplayer2.c.d.a.ah || var7_7 == com.google.android.exoplayer2.c.d.a.ag || var7_7 == com.google.android.exoplayer2.c.d.a.ae || var7_7 == com.google.android.exoplayer2.c.d.a.af || var7_7 == com.google.android.exoplayer2.c.d.a.Q || var7_7 == com.google.android.exoplayer2.c.d.a.N || var7_7 == com.google.android.exoplayer2.c.d.a.aG ? 1 : 0;
                                        if (var7_7 != 0) {
                                            if (this.s != 8) {
                                                throw new i("Leaf atom defines extended atom size (unsupported).");
                                            }
                                            if (this.r > Integer.MAX_VALUE) {
                                                throw new i("Leaf atom with length > 2147483647 (unsupported).");
                                            }
                                            this.t = new com.google.android.exoplayer2.i.i((int)this.r);
                                            System.arraycopy(this.l.a, 0, this.t.a, 0, 8);
                                            this.p = 1;
                                        } else {
                                            if (this.r > Integer.MAX_VALUE) {
                                                throw new i("Skipping atom with length > 2147483647 (unsupported).");
                                            }
                                            this.t = null;
                                            this.p = 1;
                                        }
                                    }
                                }
                                if ((var7_7 = 1) != 0) continue block5;
                                return -1;
                            }
                            case 1: {
                                var7_7 = (int)this.r - this.s;
                                if (this.t != null) {
                                    var1_1.b(this.t.a, 8, var7_7);
                                    var2_2 = new a.b(this.q, this.t);
                                    var11_11 = var1_1.c();
                                    if (!this.n.isEmpty()) {
                                        this.n.peek().a((a.b)var2_2);
                                    } else {
                                        if (var2_2.aP == com.google.android.exoplayer2.c.d.a.A) {
                                            var2_2 = var2_2.aQ;
                                            var2_2.c(8);
                                            var7_7 = com.google.android.exoplayer2.c.d.a.a(var2_2.k());
                                            var2_2.d(4);
                                            var19_15 = var2_2.i();
                                            if (var7_7 == 0) {
                                                var13_12 = var2_2.i();
                                                var11_11 = var2_2.i() + var11_11;
                                            } else {
                                                var13_12 = var2_2.q();
                                                var11_11 = var2_2.q() + var11_11;
                                            }
                                            var17_14 = o.a(var13_12, 1000000, var19_15);
                                            var2_2.d(2);
                                            var8_8 = var2_2.f();
                                            var3_3 = new int[var8_8];
                                            var4_4 = new long[var8_8];
                                            var5_5 = new long[var8_8];
                                            var6_6 = new long[var8_8];
                                            var15_13 = var13_12;
                                            var13_12 = var17_14;
                                            break block59;
                                        }
                                        if (var2_2.aP == com.google.android.exoplayer2.c.d.a.aG) {
                                            var2_2 = var2_2.aQ;
                                            if (this.D != null) {
                                                var2_2.c(12);
                                                var2_2.r();
                                                var2_2.r();
                                                var11_11 = var2_2.i();
                                                var11_11 = o.a(var2_2.i(), 1000000, var11_11);
                                                var2_2.c(12);
                                                var7_7 = var2_2.b();
                                                this.D.a((com.google.android.exoplayer2.i.i)var2_2, var7_7);
                                                if (this.x != -9223372036854775807L) {
                                                    this.D.a(var11_11 + this.x, 1, var7_7, 0, null);
                                                } else {
                                                    this.o.addLast(new a(var11_11, var7_7));
                                                    this.v += var7_7;
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    var1_1.b(var7_7);
                                }
lbl125: // 5 sources:
                                do {
                                    this.a(var1_1.c());
                                    continue block5;
                                    break;
                                } while (true);
                            }
                            case 2: {
                                var2_2 = null;
                                var11_11 = Long.MAX_VALUE;
                                var8_8 = this.f.size();
                                for (var7_7 = 0; var7_7 < var8_8; ++var7_7) {
                                    var3_3 = ((b)this.f.valueAt((int)var7_7)).a;
                                    if (!var3_3.r || var3_3.d >= var11_11) continue;
                                    var11_11 = var3_3.d;
                                    var2_2 = (b)this.f.valueAt(var7_7);
                                }
                                if (var2_2 == null) {
                                    this.p = 3;
                                    continue block5;
                                }
                                var7_7 = (int)(var11_11 - var1_1.c());
                                if (var7_7 < 0) {
                                    throw new i("Offset to encryption data was negative.");
                                }
                                var1_1.b(var7_7);
                                var2_2 = var2_2.a;
                                var1_1.b(var2_2.q.a, 0, var2_2.p);
                                var2_2.q.c(0);
                                var2_2.r = false;
                                continue block5;
                            }
                        }
                        if (var2_2 != null) break;
                        var7_7 = (int)(this.u - var1_1.c());
                        if (var7_7 < 0) {
                            throw new i("Offset to end of mdat was negative.");
                        }
                        var1_1.b(var7_7);
                        this.a();
                        var7_7 = 0;
                        if (var7_7 != 0) return 0;
                    } while (true);
                    var7_7 = var8_8 = (int)(var2_2.a.g[var2_2.g] - var1_1.c());
                    if (var8_8 < 0) {
                        Log.w((String)"FragmentedMp4Extractor", (String)"Ignoring negative offset to sample data.");
                        var7_7 = 0;
                    }
                    var1_1.b(var7_7);
                    this.y = var2_2;
                }
                this.z = this.y.a.i[this.y.e];
                if (this.y.a.m) {
                    var4_4 = this.y;
                    var5_5 = var4_4.a;
                    var3_3 = var5_5.q;
                    var7_7 = var5_5.a.a;
                    var2_2 = var5_5.o != null ? var5_5.o : var4_4.c.h[var7_7];
                    var8_8 = var2_2.b;
                    var23_17 = var5_5.n[var4_4.e];
                    var2_2 = this.j.a;
                    var7_7 = var23_17 != false ? 128 : 0;
                    var2_2[0] = (byte)(var7_7 | var8_8);
                    this.j.c(0);
                    var2_2 = var4_4.b;
                    var2_2.a(this.j, 1);
                    var2_2.a((com.google.android.exoplayer2.i.i)var3_3, var8_8);
                    if (!var23_17) {
                        var7_7 = var8_8 + 1;
                    } else {
                        var7_7 = var3_3.f();
                        var3_3.d(-2);
                        var7_7 = var7_7 * 6 + 2;
                        var2_2.a((com.google.android.exoplayer2.i.i)var3_3, var7_7);
                        var7_7 = var8_8 + 1 + var7_7;
                    }
                    this.A = var7_7;
                    this.z += this.A;
                } else {
                    this.A = 0;
                }
                if (this.y.c.g == 1) {
                    this.z -= 8;
                    var1_1.b(8);
                }
                this.p = 4;
                this.B = 0;
            }
            var3_3 = this.y.a;
            var5_5 = this.y.c;
            var4_4 = this.y.b;
            var8_8 = this.y.e;
            if (var5_5.k == 0) ** GOTO lbl212
            var2_2 = this.h.a;
            var2_2[0] = 0;
            var2_2[1] = false;
            var2_2[2] = false;
            var7_7 = var5_5.k;
            var9_9 = 4 - var5_5.k;
            ** GOTO lbl234
lbl212: // 2 sources:
            while (this.A < this.z) {
                this.A = var4_4.a(var1_1, this.z - this.A, false) + this.A;
            }
            ** GOTO lbl261
        }
        for (var7_7 = 0; var7_7 < var8_8; var11_11 += (long)var3_3[var7_7], ++var7_7) {
            var9_9 = var2_2.k();
            if ((Integer.MIN_VALUE & var9_9) != 0) {
                throw new i("Unhandled indirect reference");
            }
            var21_16 = var2_2.i();
            var3_3[var7_7] = var9_9 & Integer.MAX_VALUE;
            var4_4[var7_7] = var11_11;
            var6_6[var7_7] = var13_12;
            var13_12 = o.a(var15_13 += var21_16, 1000000, var19_15);
            var5_5[var7_7] = var13_12 - var6_6[var7_7];
            var2_2.d(4);
        }
        var2_2 = Pair.create((Object)var17_14, (Object)new com.google.android.exoplayer2.c.a(var3_3, var4_4, var5_5, var6_6));
        this.x = (Long)var2_2.first;
        this.C.a((m)var2_2.second);
        this.F = true;
        ** while (true)
lbl234: // 5 sources:
        while (this.A < this.z) {
            if (this.B == 0) {
                var1_1.b(this.h.a, var9_9, var7_7);
                this.h.c(0);
                this.B = this.h.o();
                this.g.c(0);
                var4_4.a(this.g, 4);
                this.A += 4;
                this.z += var9_9;
                if (this.E == null) continue;
                var2_2 = this.i.a;
                var1_1.c(var2_2, 0, 1);
                if ((var2_2[0] & 31) != 6) continue;
                this.i.a(this.B);
                var1_1.b(var2_2, 0, this.B);
                var4_4.a(this.i, this.B);
                this.A += this.B;
                this.B = 0;
                var10_10 = com.google.android.exoplayer2.i.g.a(var2_2, this.i.c);
                this.i.c(1);
                this.i.b(var10_10);
                d.a(var3_3.b(var8_8) * 1000, this.i, this.E);
                continue;
            }
            var10_10 = var4_4.a(var1_1, this.B, false);
            this.A += var10_10;
            this.B -= var10_10;
        }
lbl261: // 2 sources:
        var11_11 = var3_3.b(var8_8) * 1000;
        var7_7 = var3_3.m != false ? 1073741824 : 0;
        var8_8 = var3_3.l[var8_8] != false ? 1 : 0;
        var9_9 = var3_3.a.a;
        var2_2 = null;
        if (var3_3.m) {
            var2_2 = var3_3.o != null ? var3_3.o.c : var5_5.h[var9_9].c;
        }
        if (this.k != null) {
            var11_11 = this.k.b(var11_11);
        }
        var4_4.a(var11_11, var7_7 | var8_8, this.z, 0, var2_2);
        while (!this.o.isEmpty()) {
            var2_2 = this.o.removeFirst();
            this.v -= var2_2.b;
            this.D.a(var2_2.a + var11_11, 1, var2_2.b, this.v, null);
        }
        var2_2 = this.y;
        ++var2_2.e;
        var2_2 = this.y;
        ++var2_2.f;
        if (this.y.f == var3_3.h[this.y.g]) {
            var2_2 = this.y;
            ++var2_2.g;
            this.y.f = 0;
            this.y = null;
        }
        this.p = 3;
        return 0;
    }

    @Override
    public final void a(long l2, long l3) {
        int n2 = this.f.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            ((b)this.f.valueAt(i2)).a();
        }
        this.o.clear();
        this.v = 0;
        this.n.clear();
        this.a();
    }

    @Override
    public final void a(h object) {
        this.C = object;
        if (this.e != null) {
            object = new b(object.a(0));
            object.a(this.e, new c(0, 0, 0, 0));
            this.f.put(0, object);
            this.b();
            this.C.b();
        }
    }

    @Override
    public final boolean a(g g2) {
        return com.google.android.exoplayer2.c.d.h.a(g2);
    }

    static final class a {
        public final long a;
        public final int b;

        public a(long l2, int n2) {
            this.a = l2;
            this.b = n2;
        }
    }

    static final class b {
        public final k a = new k();
        public final n b;
        public com.google.android.exoplayer2.c.d.i c;
        public c d;
        public int e;
        public int f;
        public int g;

        public b(n n2) {
            this.b = n2;
        }

        public final void a() {
            k k2 = this.a;
            k2.e = 0;
            k2.s = 0;
            k2.m = false;
            k2.r = false;
            k2.o = null;
            this.e = 0;
            this.g = 0;
            this.f = 0;
        }

        public final void a(com.google.android.exoplayer2.c.d.i i2, c c2) {
            this.c = d.b(i2);
            this.d = d.b(c2);
            this.b.a(i2.f);
            this.a();
        }
    }

}

