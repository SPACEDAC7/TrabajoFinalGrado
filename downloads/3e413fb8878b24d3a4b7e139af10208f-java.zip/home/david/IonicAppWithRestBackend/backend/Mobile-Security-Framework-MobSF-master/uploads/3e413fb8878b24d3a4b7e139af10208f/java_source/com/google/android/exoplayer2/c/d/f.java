/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.google.android.exoplayer2.c.d;

import android.util.Log;
import com.google.android.exoplayer2.c.d.a;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.id3.CommentFrame;
import com.google.android.exoplayer2.metadata.id3.Id3Frame;
import com.google.android.exoplayer2.metadata.id3.TextInformationFrame;

final class f {
    private static final int A;
    private static final int B;
    private static final int C;
    private static final String[] D;
    private static final int a;
    private static final int b;
    private static final int c;
    private static final int d;
    private static final int e;
    private static final int f;
    private static final int g;
    private static final int h;
    private static final int i;
    private static final int j;
    private static final int k;
    private static final int l;
    private static final int m;
    private static final int n;
    private static final int o;
    private static final int p;
    private static final int q;
    private static final int r;
    private static final int s;
    private static final int t;
    private static final int u;
    private static final int v;
    private static final int w;
    private static final int x;
    private static final int y;
    private static final int z;

    static {
        a = o.e("nam");
        b = o.e("trk");
        c = o.e("cmt");
        d = o.e("day");
        e = o.e("ART");
        f = o.e("too");
        g = o.e("alb");
        h = o.e("com");
        i = o.e("wrt");
        j = o.e("lyr");
        k = o.e("gen");
        l = o.e("covr");
        m = o.e("gnre");
        n = o.e("grp");
        o = o.e("disk");
        p = o.e("trkn");
        q = o.e("tmpo");
        r = o.e("cpil");
        s = o.e("aART");
        t = o.e("sonm");
        u = o.e("soal");
        v = o.e("soar");
        w = o.e("soaa");
        x = o.e("soco");
        y = o.e("rtng");
        z = o.e("pgap");
        A = o.e("sosn");
        B = o.e("tvsh");
        C = o.e("----");
        D = new String[]{"Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal", "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial", "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise", "AlternRock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic", "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta", "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes", "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock", "Folk", "Folk-Rock", "National Folk", "Swing", "Fast Fusion", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass", "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic", "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove", "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle", "Duet", "Punk Rock", "Drum Solo", "A capella", "Euro-House", "Dance Hall", "Goa", "Drum & Bass", "Club-House", "Hardcore", "Terror", "Indie", "BritPop", "Negerpunk", "Polsk Punk", "Beat", "Christian Gangsta Rap", "Heavy Metal", "Black Metal", "Crossover", "Contemporary Christian", "Christian Rock", "Merengue", "Salsa", "Thrash Metal", "Anime", "Jpop", "Synthpop"};
    }

    /*
     * Exception decompiling
     */
    public static Metadata.Entry a(i var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 18[TRYBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private static Id3Frame a(int n2, String string, i i2, boolean bl2, boolean bl3) {
        int n3 = f.b(i2);
        if (bl3) {
            n3 = Math.min(1, n3);
        }
        if (n3 >= 0) {
            if (bl2) {
                return new TextInformationFrame(string, null, Integer.toString(n3));
            }
            return new CommentFrame("und", string, Integer.toString(n3));
        }
        Log.w((String)"MetadataUtil", (String)("Failed to parse uint8 attribute: " + a.c(n2)));
        return null;
    }

    private static Id3Frame a(i i2, int n2) {
        int n3 = -1;
        int n4 = -1;
        String string = null;
        String string2 = null;
        while (i2.b < n2) {
            int n5 = i2.b;
            int n6 = i2.k();
            int n7 = i2.k();
            i2.d(4);
            if (n7 == a.aD) {
                string2 = i2.f(n6 - 12);
                continue;
            }
            if (n7 == a.aE) {
                string = i2.f(n6 - 12);
                continue;
            }
            if (n7 == a.aF) {
                n3 = n6;
                n4 = n5;
            }
            i2.d(n6 - 12);
        }
        if (!"com.apple.iTunes".equals(string2) || !"iTunSMPB".equals(string) || n4 == -1) {
            return null;
        }
        i2.c(n4);
        i2.d(16);
        return new CommentFrame("und", string, i2.f(n3 - 16));
    }

    private static TextInformationFrame a(int n2, String string, i i2) {
        int n3 = i2.k();
        if (i2.k() == a.aF) {
            i2.d(8);
            return new TextInformationFrame(string, null, i2.f(n3 - 16));
        }
        Log.w((String)"MetadataUtil", (String)("Failed to parse text attribute: " + a.c(n2)));
        return null;
    }

    private static int b(i i2) {
        i2.d(4);
        if (i2.k() == a.aF) {
            i2.d(8);
            return i2.e();
        }
        Log.w((String)"MetadataUtil", (String)"Failed to parse uint8 attribute value");
        return -1;
    }

    private static TextInformationFrame b(int n2, String string, i object) {
        int n3 = object.k();
        if (object.k() == a.aF && n3 >= 22) {
            object.d(10);
            n3 = object.f();
            if (n3 > 0) {
                String string2 = String.valueOf(n3);
                n2 = object.f();
                object = string2;
                if (n2 > 0) {
                    object = string2 + "/" + n2;
                }
                return new TextInformationFrame(string, null, (String)object);
            }
        }
        Log.w((String)"MetadataUtil", (String)("Failed to parse index/count attribute: " + a.c(n2)));
        return null;
    }
}

