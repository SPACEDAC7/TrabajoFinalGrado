/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.d;

import a.a.a.a.d;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.d.a;
import com.google.android.exoplayer2.c.d.b;
import com.google.android.exoplayer2.c.f;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.i;
import com.google.android.exoplayer2.c.j;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.Metadata;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public final class g
implements f,
m {
    public static final i a = new i(){

        @Override
        public final f[] a() {
            return new f[]{new g()};
        }
    };
    private static final int b = o.e("qt  ");
    private final com.google.android.exoplayer2.i.i c = new com.google.android.exoplayer2.i.i(com.google.android.exoplayer2.i.g.a);
    private final com.google.android.exoplayer2.i.i d = new com.google.android.exoplayer2.i.i(4);
    private final com.google.android.exoplayer2.i.i e = new com.google.android.exoplayer2.i.i(16);
    private final Stack<a.a> f = new Stack();
    private int g;
    private int h;
    private long i;
    private int j;
    private com.google.android.exoplayer2.i.i k;
    private int l;
    private int m;
    private h n;
    private a[] o;
    private long p;
    private boolean q;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void b(long var1_1) {
        do {
            if (this.f.isEmpty() || this.f.peek().aQ != var1_1) ** GOTO lbl16
            var6_6 = this.f.pop();
            if (var6_6.aP != com.google.android.exoplayer2.c.d.a.B) ** GOTO lbl13
            var7_7 = new ArrayList<a>();
            var8_8 = new j();
            var3_3 = var6_6.d(com.google.android.exoplayer2.c.d.a.aA);
            if (var3_3 == null) ** GOTO lbl19
            var4_4 = b.a((a.b)var3_3, this.q);
            if (var4_4 != null) {
                var8_8.a(var4_4);
            }
            ** GOTO lbl20
lbl13: // 1 sources:
            if (this.f.isEmpty()) continue;
            this.f.peek().a(var6_6);
            continue;
lbl16: // 1 sources:
            if (this.g == 2) return;
            this.c();
            return;
lbl19: // 1 sources:
            var4_4 = null;
lbl20: // 2 sources:
            var14_14 = -9223372036854775807L;
            for (var11_11 = 0; var11_11 < var6_6.aS.size(); ++var11_11) {
                var3_3 = var6_6.aS.get(var11_11);
                var16_2 = var14_14;
                if (var3_3.aP == com.google.android.exoplayer2.c.d.a.D) {
                    var9_9 = b.a((a.a)var3_3, var6_6.d(com.google.android.exoplayer2.c.d.a.C), -9223372036854775807L, null, this.q);
                    var16_2 = var14_14;
                    if (var9_9 != null) {
                        var3_3 = b.a(var9_9, var3_3.e(com.google.android.exoplayer2.c.d.a.E).e(com.google.android.exoplayer2.c.d.a.F).e(com.google.android.exoplayer2.c.d.a.G), var8_8);
                        var16_2 = var14_14;
                        if (var3_3.a != 0) {
                            var10_10 = new a(var9_9, (com.google.android.exoplayer2.c.d.l)var3_3, this.n.a(var11_11));
                            var12_12 = var3_3.d;
                            var3_3 = var9_9.f;
                            var3_3 = var5_5 = new Format(var3_3.a, var3_3.e, var3_3.f, var3_3.c, var3_3.b, var12_12 + 30, var3_3.j, var3_3.k, var3_3.l, var3_3.m, var3_3.n, var3_3.p, var3_3.o, var3_3.q, var3_3.r, var3_3.s, var3_3.t, var3_3.u, var3_3.w, var3_3.x, var3_3.y, var3_3.v, var3_3.h, var3_3.i, var3_3.d);
                            if (var9_9.b == 1) {
                                if (var8_8.a()) {
                                    var12_12 = var8_8.a;
                                    var13_13 = var8_8.b;
                                    var3_3 = new Format(var5_5.a, var5_5.e, var5_5.f, var5_5.c, var5_5.b, var5_5.g, var5_5.j, var5_5.k, var5_5.l, var5_5.m, var5_5.n, var5_5.p, var5_5.o, var5_5.q, var5_5.r, var5_5.s, var12_12, var13_13, var5_5.w, var5_5.x, var5_5.y, var5_5.v, var5_5.h, var5_5.i, var5_5.d);
                                } else {
                                    var3_3 = var5_5;
                                }
                                if (var4_4 != null) {
                                    var3_3 = new Format(var3_3.a, var3_3.e, var3_3.f, var3_3.c, var3_3.b, var3_3.g, var3_3.j, var3_3.k, var3_3.l, var3_3.m, var3_3.n, var3_3.p, var3_3.o, var3_3.q, var3_3.r, var3_3.s, var3_3.t, var3_3.u, var3_3.w, var3_3.x, var3_3.y, var3_3.v, var3_3.h, var3_3.i, var4_4);
                                }
                            }
                            var10_10.c.a((Format)var3_3);
                            var16_2 = Math.max(var14_14, var9_9.e);
                            var7_7.add(var10_10);
                        }
                    }
                }
                var14_14 = var16_2;
            }
            this.p = var14_14;
            this.o = var7_7.toArray(new a[var7_7.size()]);
            this.n.b();
            this.n.a(this);
            this.f.clear();
            this.g = 2;
        } while (true);
    }

    private void c() {
        this.g = 0;
        this.j = 0;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(com.google.android.exoplayer2.c.g var1_1, l var2_2) {
        do lbl-1000: // 3 sources:
        {
            switch (this.g) {
                default: {
                    throw new IllegalStateException();
                }
                case 0: {
                    if (this.j == 0) {
                        if (!var1_1.a(this.e.a, 0, 8, true)) {
                            return -1;
                        }
                        this.j = 8;
                        this.e.c(0);
                        this.i = this.e.i();
                        this.h = this.e.k();
                    }
                    if (this.i == 1) {
                        var1_1.b(this.e.a, 8, 8);
                        this.j += 8;
                        this.i = this.e.q();
                    }
                    var5_5 = (var5_5 = this.h) == com.google.android.exoplayer2.c.d.a.B || var5_5 == com.google.android.exoplayer2.c.d.a.D || var5_5 == com.google.android.exoplayer2.c.d.a.E || var5_5 == com.google.android.exoplayer2.c.d.a.F || var5_5 == com.google.android.exoplayer2.c.d.a.G || var5_5 == com.google.android.exoplayer2.c.d.a.P ? 1 : 0;
                    if (var5_5 != 0) {
                        var10_6 = var1_1.c() + this.i - (long)this.j;
                        this.f.add(new a.a(this.h, var10_6));
                        if (this.i == (long)this.j) {
                            this.b(var10_6);
                        } else {
                            this.c();
                        }
                    } else {
                        var5_5 = this.h;
                        var5_5 = var5_5 == com.google.android.exoplayer2.c.d.a.R || var5_5 == com.google.android.exoplayer2.c.d.a.C || var5_5 == com.google.android.exoplayer2.c.d.a.S || var5_5 == com.google.android.exoplayer2.c.d.a.T || var5_5 == com.google.android.exoplayer2.c.d.a.am || var5_5 == com.google.android.exoplayer2.c.d.a.an || var5_5 == com.google.android.exoplayer2.c.d.a.ao || var5_5 == com.google.android.exoplayer2.c.d.a.Q || var5_5 == com.google.android.exoplayer2.c.d.a.ap || var5_5 == com.google.android.exoplayer2.c.d.a.aq || var5_5 == com.google.android.exoplayer2.c.d.a.ar || var5_5 == com.google.android.exoplayer2.c.d.a.as || var5_5 == com.google.android.exoplayer2.c.d.a.at || var5_5 == com.google.android.exoplayer2.c.d.a.O || var5_5 == com.google.android.exoplayer2.c.d.a.a || var5_5 == com.google.android.exoplayer2.c.d.a.aA ? 1 : 0;
                        if (var5_5 != 0) {
                            var16_3 = this.j == 8;
                            d.b(var16_3);
                            var16_3 = this.i <= Integer.MAX_VALUE;
                            d.b(var16_3);
                            this.k = new com.google.android.exoplayer2.i.i((int)this.i);
                            System.arraycopy(this.e.a, 0, this.k.a, 0, 8);
                            this.g = 1;
                        } else {
                            this.k = null;
                            this.g = 1;
                        }
                    }
                    if ((var5_5 = 1) != 0) ** GOTO lbl-1000
                    return -1;
                }
                case 1: {
                    var10_6 = this.i - (long)this.j;
                    var12_7 = var1_1.c();
                    if (this.k == null) ** GOTO lbl65
                    var1_1.b(this.k.a, this.j, (int)var10_6);
                    if (this.h != com.google.android.exoplayer2.c.d.a.a) ** GOTO lbl61
                    var3_4 = this.k;
                    var3_4.c(8);
                    if (var3_4.k() != g.b) ** GOTO lbl52
                    var16_3 = true;
                    ** GOTO lbl58
lbl52: // 1 sources:
                    var3_4.d(4);
                    while (var3_4.b() > 0) {
                        if (var3_4.k() != g.b) continue;
                        var16_3 = true;
                        ** GOTO lbl58
                    }
                    var16_3 = false;
lbl58: // 3 sources:
                    this.q = var16_3;
                    var5_5 = 0;
                    ** GOTO lbl94
lbl61: // 1 sources:
                    if (this.f.isEmpty()) break;
                    this.f.peek().a(new a.b(this.h, this.k));
                    var5_5 = 0;
                    ** GOTO lbl94
lbl65: // 1 sources:
                    if (var10_6 < 262144) {
                        var1_1.b((int)var10_6);
                        var5_5 = 0;
                    } else {
                        var2_2.a = var1_1.c() + var10_6;
                        var5_5 = 1;
                    }
                    ** GOTO lbl94
                }
                case 2: {
                    var6_8 = -1;
                    var10_6 = Long.MAX_VALUE;
                    var5_5 = 0;
                    while (var5_5 < this.o.length) {
                        var3_4 = this.o[var5_5];
                        var8_10 = var3_4.d;
                        var12_7 = var10_6;
                        var7_9 = var6_8;
                        if (var8_10 != var3_4.b.a) {
                            var14_11 = var3_4.b.b[var8_10];
                            var12_7 = var10_6;
                            var7_9 = var6_8;
                            if (var14_11 < var10_6) {
                                var12_7 = var14_11;
                                var7_9 = var5_5;
                            }
                        }
                        ++var5_5;
                        var10_6 = var12_7;
                        var6_8 = var7_9;
                    }
                    return -1;
                }
            }
            var5_5 = 0;
lbl94: // 5 sources:
            this.b(var12_7 + var10_6);
            if (var5_5 == 0 || this.g == 2) continue;
            return 1;
        } while ((var5_5 = 0) == 0);
        return 1;
    }

    @Override
    public final long a(long l2) {
        long l3 = Long.MAX_VALUE;
        a[] arra = this.o;
        int n2 = arra.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            long l4;
            int n3;
            com.google.android.exoplayer2.c.d.l l5 = arra[i2].b;
            int n4 = n3 = l5.a(l2);
            if (n3 == -1) {
                n4 = l5.b(l2);
            }
            if ((l4 = l5.b[n4]) >= l3) continue;
            l3 = l4;
        }
        return l3;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(long l2, long l3) {
        this.f.clear();
        this.j = 0;
        this.l = 0;
        this.m = 0;
        if (l2 == 0) {
            this.c();
            return;
        } else {
            if (this.o == null) return;
            {
                a[] arra = this.o;
                int n2 = arra.length;
                int n3 = 0;
                while (n3 < n2) {
                    int n4;
                    a a2 = arra[n3];
                    com.google.android.exoplayer2.c.d.l l4 = a2.b;
                    int n5 = n4 = l4.a(l3);
                    if (n4 == -1) {
                        n5 = l4.b(l3);
                    }
                    a2.d = n5;
                    ++n3;
                }
                return;
            }
        }
    }

    @Override
    public final void a(h h2) {
        this.n = h2;
    }

    @Override
    public final boolean a(com.google.android.exoplayer2.c.g g2) {
        return com.google.android.exoplayer2.c.d.h.b(g2);
    }

    @Override
    public final long b() {
        return this.p;
    }

    @Override
    public final boolean b_() {
        return true;
    }

    static final class a {
        public final com.google.android.exoplayer2.c.d.i a;
        public final com.google.android.exoplayer2.c.d.l b;
        public final n c;
        public int d;

        public a(com.google.android.exoplayer2.c.d.i i2, com.google.android.exoplayer2.c.d.l l2, n n2) {
            this.a = i2;
            this.b = l2;
            this.c = n2;
        }
    }

}

