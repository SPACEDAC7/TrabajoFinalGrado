/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.d;

import com.google.android.exoplayer2.c.d.a;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.o;

final class h {
    private static final int[] a = new int[]{o.e("isom"), o.e("iso2"), o.e("iso3"), o.e("iso4"), o.e("iso5"), o.e("iso6"), o.e("avc1"), o.e("hvc1"), o.e("hev1"), o.e("mp41"), o.e("mp42"), o.e("3g2a"), o.e("3g2b"), o.e("3gr6"), o.e("3gs6"), o.e("3ge6"), o.e("3gg6"), o.e("M4V "), o.e("M4A "), o.e("f4v "), o.e("kddi"), o.e("M4VP"), o.e("qt  "), o.e("MSNV")};

    public static boolean a(g g2) {
        return h.a(g2, true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static boolean a(g var0, boolean var1_1) {
        block15 : {
            var14_2 = var0.d();
            if (var14_2 != -1) {
                var12_3 = var14_2;
                if (var14_2 <= 4096) break block15;
            }
            var12_3 = 4096;
        }
        var8_4 = (int)var12_3;
        var2_5 = new i(64);
        var5_6 = 0;
        var17_7 = false;
        var4_8 = 0;
        block0 : do {
            var16_9 = var17_7;
            if (var4_8 >= var8_4) return false;
            var6_11 = 8;
            var2_5.a(8);
            var0.c(var2_5.a, 0, 8);
            var14_2 = var2_5.i();
            var9_13 = var2_5.k();
            var12_3 = var14_2;
            if (var14_2 == 1) {
                var6_11 = 16;
                var0.c(var2_5.a, 8, 8);
                var2_5.b(16);
                var12_3 = var2_5.q();
            }
            if (var12_3 < (long)var6_11) {
                return false;
            }
            var4_8 = var7_12 = var4_8 + var6_11;
            if (var9_13 == a.B) continue;
            if (var9_13 != a.K && var9_13 != a.M) ** GOTO lbl33
            var16_9 = true;
            ** GOTO lbl41
lbl33: // 1 sources:
            var16_9 = var17_7;
            if ((long)var7_12 + var12_3 - (long)var6_11 >= (long)var8_4) ** GOTO lbl41
            var4_8 = (int)(var12_3 - (long)var6_11);
            var6_11 = var7_12 + var4_8;
            if (var9_13 != a.a) ** GOTO lbl44
            if (var4_8 < 8) {
                return false;
            }
            ** GOTO lbl48
lbl41: // 2 sources:
            if (var5_6 == 0) return false;
            if (var1_1 != var16_9) return false;
            return true;
lbl44: // 1 sources:
            if (var4_8 != 0) {
                var0.c(var4_8);
            }
            var4_8 = var6_11;
            continue;
lbl48: // 1 sources:
            var2_5.a(var4_8);
            var0.c(var2_5.a, 0, var4_8);
            var9_13 = var4_8 / 4;
            var7_12 = 0;
            block1 : do {
                var4_8 = var5_6;
                if (var7_12 >= var9_13) ** GOTO lbl71
                if (var7_12 == 1) {
                    var2_5.d(4);
                } else {
                    var10_14 = var2_5.k();
                    if (var10_14 >>> 8 == o.e("3gp")) {
                        var4_8 = 1;
                        break;
                    }
                    var3_10 = h.a;
                    var11_15 = var3_10.length;
                    break block0;
                }
                do {
                    ++var7_12;
                    continue block1;
                    break;
                } while (true);
                break;
            } while (true);
lbl68: // 3 sources:
            do {
                if (var4_8 == 0) ** continue;
                var4_8 = 1;
lbl71: // 2 sources:
                if (var4_8 == 0) {
                    return false;
                }
                var5_6 = var4_8;
                var4_8 = var6_11;
                continue block0;
                break;
            } while (true);
            break;
        } while (true);
        for (var4_8 = 0; var4_8 < var11_15; ++var4_8) {
            if (var3_10[var4_8] != var10_14) continue;
            var4_8 = 1;
            ** GOTO lbl68
        }
        var4_8 = 0;
        ** while (true)
    }

    public static boolean b(g g2) {
        return h.a(g2, false);
    }
}

