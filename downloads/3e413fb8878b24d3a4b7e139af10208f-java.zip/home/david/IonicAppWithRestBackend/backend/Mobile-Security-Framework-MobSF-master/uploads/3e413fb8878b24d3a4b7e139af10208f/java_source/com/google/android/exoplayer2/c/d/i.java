/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.d;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.d.j;

public final class i {
    public final int a;
    public final int b;
    public final long c;
    public final long d;
    public final long e;
    public final Format f;
    public final int g;
    public final j[] h;
    public final long[] i;
    public final long[] j;
    public final int k;

    public i(int n2, int n3, long l2, long l3, long l4, Format format, int n4, j[] arrj, int n5, long[] arrl, long[] arrl2) {
        this.a = n2;
        this.b = n3;
        this.c = l2;
        this.d = l3;
        this.e = l4;
        this.f = format;
        this.g = n4;
        this.h = arrj;
        this.k = n5;
        this.i = arrl;
        this.j = arrl2;
    }
}

