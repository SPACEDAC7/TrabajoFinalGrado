/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.d;

public final class j {
    public final boolean a;
    public final int b;
    public final byte[] c;

    public j(boolean bl2, int n2, byte[] arrby) {
        this.a = bl2;
        this.b = n2;
        this.c = arrby;
    }
}

