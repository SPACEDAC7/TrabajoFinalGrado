/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.d;

import com.google.android.exoplayer2.c.d.c;
import com.google.android.exoplayer2.c.d.j;
import com.google.android.exoplayer2.i.i;

final class k {
    public c a;
    public long b;
    public long c;
    public long d;
    public int e;
    public int f;
    public long[] g;
    public int[] h;
    public int[] i;
    public int[] j;
    public long[] k;
    public boolean[] l;
    public boolean m;
    public boolean[] n;
    public j o;
    public int p;
    public i q;
    public boolean r;
    public long s;

    k() {
    }

    public final void a(int n2) {
        if (this.q == null || this.q.c < n2) {
            this.q = new i(n2);
        }
        this.p = n2;
        this.m = true;
        this.r = true;
    }

    public final long b(int n2) {
        return this.k[n2] + (long)this.j[n2];
    }
}

