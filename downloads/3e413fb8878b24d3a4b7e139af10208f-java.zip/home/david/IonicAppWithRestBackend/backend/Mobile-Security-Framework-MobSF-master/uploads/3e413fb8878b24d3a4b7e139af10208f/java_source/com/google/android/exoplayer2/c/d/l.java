/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.d;

import a.a.a.a.d;

final class l {
    public final int a;
    public final long[] b;
    public final int[] c;
    public final int d;
    public final long[] e;
    public final int[] f;

    /*
     * Enabled aggressive block sorting
     */
    public l(long[] arrl, int[] arrn, int n2, long[] arrl2, int[] arrn2) {
        boolean bl2 = true;
        boolean bl3 = arrn.length == arrl2.length;
        d.a(bl3);
        bl3 = arrl.length == arrl2.length;
        d.a(bl3);
        bl3 = arrn2.length == arrl2.length ? bl2 : false;
        d.a(bl3);
        this.b = arrl;
        this.c = arrn;
        this.d = n2;
        this.e = arrl2;
        this.f = arrn2;
        this.a = arrl.length;
    }

    public final int a(long l2) {
        for (int i2 = com.google.android.exoplayer2.i.o.a((long[])this.e, (long)l2, (boolean)false); i2 >= 0; --i2) {
            if ((this.f[i2] & 1) == 0) continue;
            return i2;
        }
        return -1;
    }

    public final int b(long l2) {
        for (int i2 = com.google.android.exoplayer2.i.o.a((long[])this.e, (long)l2, (boolean)true, (boolean)false); i2 < this.e.length; ++i2) {
            if ((this.f[i2] & 1) == 0) continue;
            return i2;
        }
        return -1;
    }
}

