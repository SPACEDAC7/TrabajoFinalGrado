/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.i;
import java.io.EOFException;

public final class e
implements n {
    @Override
    public final int a(g g2, int n2, boolean bl2) {
        if ((n2 = g2.a(n2)) == -1) {
            if (bl2) {
                return -1;
            }
            throw new EOFException();
        }
        return n2;
    }

    @Override
    public final void a(long l2, int n2, int n3, int n4, byte[] arrby) {
    }

    @Override
    public final void a(Format format) {
    }

    @Override
    public final void a(i i2, int n2) {
        i2.d(n2);
    }
}

