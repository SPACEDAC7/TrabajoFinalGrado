/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

import a.a.a.a.d;
import com.google.android.exoplayer2.c.e.e;
import com.google.android.exoplayer2.c.e.f;
import com.google.android.exoplayer2.c.e.h;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.m;
import java.io.EOFException;
import java.io.IOException;

final class a
implements f {
    final long a;
    final long b;
    final h c;
    long d;
    private final e e = new e();
    private int f;
    private long g;
    private long h;
    private long i;
    private long j;
    private long k;
    private long l;

    /*
     * Enabled aggressive block sorting
     */
    public a(long l2, long l3, h h2, int n2, long l4) {
        boolean bl2 = l2 >= 0 && l3 > l2;
        d.a(bl2);
        this.c = h2;
        this.a = l2;
        this.b = l3;
        if ((long)n2 == l3 - l2) {
            this.d = l4;
            this.f = 3;
            return;
        }
        this.f = 0;
    }

    private long a(g g2, long l2, long l3) {
        this.e.a(g2, false);
        while (this.e.c < l2) {
            g2.b(this.e.h + this.e.i);
            l3 = this.e.c;
            this.e.a(g2, false);
        }
        g2.a();
        return l3;
    }

    private boolean a(g g2, long l2) {
        int n2 = 2048;
        l2 = Math.min(3 + l2, this.b);
        byte[] arrby = new byte[2048];
        do {
            int n3 = n2;
            if (g2.c() + (long)n2 > l2) {
                n3 = n2 = (int)(l2 - g2.c());
                if (n2 < 4) {
                    return false;
                }
            }
            g2.b(arrby, 0, n3, false);
            for (n2 = 0; n2 < n3 - 3; ++n2) {
                if (arrby[n2] != 79 || arrby[n2 + 1] != 103 || arrby[n2 + 2] != 103 || arrby[n2 + 3] != 83) continue;
                g2.b(n2);
                return true;
            }
            g2.b(n3 - 3);
            n2 = n3;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final long a(g var1_1) {
        var2_2 = 1;
        switch (this.f) {
            default: {
                throw new IllegalStateException();
            }
            case 3: {
                return -1;
            }
            case 0: {
                this.g = var1_1.c();
                this.f = 1;
                var6_3 = var4_4 = this.b - 65307;
                if (var4_4 > this.g) return var6_3;
            }
            case 1: {
                if (!this.a(var1_1, this.b)) {
                    throw new EOFException();
                }
                this.e.a();
                while ((this.e.b & 4) != 4 && var1_1.c() < this.b) {
                    this.e.a(var1_1, false);
                    var1_1.b(this.e.h + this.e.i);
                }
                this.d = this.e.c;
                this.f = 3;
                return this.g;
            }
            case 2: 
        }
        if (this.h != 0) ** GOTO lbl27
        var4_5 = 0;
        ** GOTO lbl65
lbl27: // 1 sources:
        var6_3 = this.h;
        if (this.i != this.j) ** GOTO lbl31
        var4_5 = - this.k + 2;
        ** GOTO lbl62
lbl31: // 1 sources:
        var4_5 = var1_1.c();
        if (this.a(var1_1, this.j)) ** GOTO lbl37
        if (this.i == var4_5) {
            throw new IOException("No ogg page can be found.");
        }
        var4_5 = this.i;
        ** GOTO lbl62
lbl37: // 1 sources:
        this.e.a(var1_1, false);
        var1_1.a();
        var3_6 = this.e.h + this.e.i;
        if ((var6_3 -= this.e.c) >= 0 && var6_3 <= 72000) ** GOTO lbl60
        if (var6_3 >= 0) ** GOTO lbl45
        this.j = var4_5;
        this.l = this.e.c;
        ** GOTO lbl-1000
lbl45: // 1 sources:
        this.i = var1_1.c() + (long)var3_6;
        this.k = this.e.c;
        if (this.j - this.i + (long)var3_6 < 100000) {
            var1_1.b(var3_6);
            var4_5 = - this.k + 2;
        } else if (this.j - this.i < 100000) {
            this.j = this.i;
            var4_5 = this.i;
        } else {
            if (var6_3 <= 0) {
                var2_2 = 2;
            }
            var4_5 = var2_2 * var3_6;
            var4_5 = Math.min(Math.max(var1_1.c() - var4_5 + var6_3 * (this.j - this.i) / (this.l - this.k), this.i), this.j - 1);
        }
        ** GOTO lbl62
lbl60: // 1 sources:
        var1_1.b(var3_6);
        var4_5 = - this.e.c + 2;
lbl62: // 6 sources:
        var6_3 = var4_5;
        if (var4_5 >= 0) return var6_3;
        var4_5 = this.a(var1_1, this.h, - var4_5 + 2);
lbl65: // 2 sources:
        this.f = 3;
        return - var4_5 + 2;
    }

    @Override
    public final /* synthetic */ m a() {
        if (this.d != 0) {
            return new a(0);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a_(long l2) {
        boolean bl2 = this.f == 3 || this.f == 2;
        d.a(bl2);
        l2 = l2 == 0 ? 0 : this.c.b(l2);
        this.h = l2;
        this.f = 2;
        this.i = this.a;
        this.j = this.b;
        this.k = 0;
        this.l = this.d;
        return this.h;
    }

    final class a
    implements m {
        private a() {
        }

        /* synthetic */ a(byte by2) {
            this();
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        public final long a(long l2) {
            if (l2 == 0) {
                return a.this.a;
            }
            l2 = a.this.c.b(l2);
            a a2 = a.this;
            long l3 = a.this.a;
            l2 = l3 = l2 * (a2.b - a2.a) / a2.d - 30000 + l3;
            if (l3 < a2.a) {
                l2 = a2.a;
            }
            l3 = l2;
            if (l2 < a2.b) return l3;
            return a2.b - 1;
        }

        @Override
        public final long b() {
            return a.this.c.a(a.this.d);
        }

        @Override
        public final boolean b_() {
            return true;
        }
    }

}

