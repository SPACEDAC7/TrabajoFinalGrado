/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.e.f;
import com.google.android.exoplayer2.c.e.h;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.i.d;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.o;
import java.util.Arrays;
import java.util.Collections;

final class b
extends h {
    d a;
    private a d;

    b() {
    }

    private static boolean a(byte[] arrby) {
        boolean bl2 = false;
        if (arrby[0] == -1) {
            bl2 = true;
        }
        return bl2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final long a(i var1_1) {
        block12 : {
            block11 : {
                var3_2 = 1;
                if (!b.a(var1_1.a)) {
                    return -1;
                }
                var4_3 = (var1_1.a[2] & 255) >> 4;
                block0 : switch (var4_3) {
                    default: {
                        var2_4 = -1;
                        return var2_4;
                    }
                    case 1: {
                        var2_4 = 192;
                        return var2_4;
                    }
                    case 2: 
                    case 3: 
                    case 4: 
                    case 5: {
                        var2_4 = 576 << var4_3 - 2;
                        return var2_4;
                    }
                    case 6: 
                    case 7: {
                        var1_1.d(4);
                        var6_5 = var1_1.a[var1_1.b];
                        for (var2_4 = 7; var2_4 >= 0; --var2_4) {
                            if (((long)(1 << var2_4) & var6_5) != 0) continue;
                            if (var2_4 < 6) {
                                var6_5 &= (long)((1 << var2_4) - 1);
                                var2_4 = 7 - var2_4;
                            } else {
                                if (var2_4 != 7) break block0;
                                var2_4 = 1;
                            }
                            break block11;
                        }
                        break;
                    }
                    case 8: 
                    case 9: 
                    case 10: 
                    case 11: 
                    case 12: 
                    case 13: 
                    case 14: 
                    case 15: {
                        var2_4 = 256 << var4_3 - 8;
                        return var2_4;
                    }
                }
                var2_4 = 0;
            }
            var8_6 = var6_5;
            if (var2_4 != 0) ** GOTO lbl38
            throw new NumberFormatException("Invalid UTF-8 sequence first byte: " + var6_5);
lbl-1000: // 1 sources:
            {
                var8_6 = var8_6 << 6 | (long)(var5_7 & 63);
                ++var3_2;
lbl38: // 2 sources:
                if (var3_2 >= var2_4) break block12;
                ** while (((var5_7 = var1_1.a[var1_1.b + var3_2]) & 192) == 128)
            }
lbl40: // 1 sources:
            throw new NumberFormatException("Invalid UTF-8 sequence continuation byte: " + var8_6);
        }
        var1_1.b += var2_4;
        var2_4 = var4_3 == 6 ? var1_1.e() : var1_1.f();
        var1_1.c(0);
        return ++var2_4;
    }

    @Override
    protected final void a(boolean bl2) {
        super.a(bl2);
        if (bl2) {
            this.a = null;
            this.d = null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final boolean a(i object, long l2, h.a object2) {
        int n2;
        Object object3 = object.a;
        if (this.a == null) {
            this.a = new d((byte[])object3);
            object = Arrays.copyOfRange((byte[])object3, 9, object.c);
            object[4] = -128;
            object = Collections.singletonList(object);
            object3 = this.a;
            n2 = object3.g;
            object2.a = Format.a(null, "audio/x-flac", -1, object3.e * n2, this.a.f, this.a.e, object, null, null);
            return true;
        } else if ((object3[0] & 127) == 3) {
            object2 = this.d = new a();
            object.d(1);
            int n3 = object.h() / 18;
            object2.a = new long[n3];
            object2.b = new long[n3];
            for (n2 = 0; n2 < n3; ++n2) {
                object2.a[n2] = object.m();
                object2.b[n2] = object.m();
                object.d(2);
            }
            return true;
        } else {
            if (!b.a((byte[])object3)) return true;
            {
                if (this.d == null) return false;
                {
                    this.d.c = l2;
                    object2.b = this.d;
                }
                return false;
            }
        }
    }

    final class a
    implements f,
    m {
        long[] a;
        long[] b;
        long c;
        private long e;

        public a() {
            this.c = -1;
            this.e = -1;
        }

        @Override
        public final long a(long l2) {
            l2 = b.this.b(l2);
            int n2 = o.a(this.a, l2, true);
            l2 = this.c;
            return this.b[n2] + l2;
        }

        @Override
        public final long a(g g2) {
            if (this.e >= 0) {
                long l2 = - this.e + 2;
                this.e = -1;
                return l2;
            }
            return -1;
        }

        @Override
        public final m a() {
            return this;
        }

        @Override
        public final long a_(long l2) {
            l2 = b.this.b(l2);
            int n2 = o.a(this.a, l2, true);
            this.e = this.a[n2];
            return l2;
        }

        @Override
        public final long b() {
            d d2 = b.this.a;
            return d2.h * 1000000 / (long)d2.e;
        }

        @Override
        public final boolean b_() {
            return true;
        }
    }

}

