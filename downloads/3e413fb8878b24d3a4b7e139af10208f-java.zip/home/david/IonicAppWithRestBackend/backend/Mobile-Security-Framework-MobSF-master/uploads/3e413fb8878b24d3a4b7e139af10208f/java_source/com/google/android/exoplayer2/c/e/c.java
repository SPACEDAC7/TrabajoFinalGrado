/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

import com.google.android.exoplayer2.c.e.b;
import com.google.android.exoplayer2.c.e.e;
import com.google.android.exoplayer2.c.e.g;
import com.google.android.exoplayer2.c.e.h;
import com.google.android.exoplayer2.c.e.j;
import com.google.android.exoplayer2.c.f;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i;

public class c
implements f {
    public static final com.google.android.exoplayer2.c.i a = new com.google.android.exoplayer2.c.i(){

        @Override
        public final f[] a() {
            return new f[]{new c()};
        }
    };
    private h b;

    @Override
    public final int a(com.google.android.exoplayer2.c.g g2, l l2) {
        h h2 = this.b;
        switch (h2.c) {
            default: {
                throw new IllegalStateException();
            }
            case 0: {
                return h2.a(g2);
            }
            case 1: {
                g2.b((int)h2.b);
                h2.c = 2;
                return 0;
            }
            case 2: 
        }
        return h2.a(g2, l2);
    }

    @Override
    public final void a(long l2, long l3) {
        this.b.a(l2, l3);
    }

    @Override
    public final void a(com.google.android.exoplayer2.c.h h2) {
        n n2 = h2.a(0);
        h2.b();
        this.b.a(h2, n2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final boolean a(com.google.android.exoplayer2.c.g g2) {
        try {
            Object object = new e();
            if (!object.a(g2, true)) return false;
            if ((object.b & 2) != 2) {
                return false;
            }
            int n2 = Math.min(object.i, 8);
            object = new com.google.android.exoplayer2.i.i(n2);
            g2.c(object.a, 0, n2);
            object.c(0);
            n2 = object.b() >= 5 && object.e() == 127 && object.i() == 1179402563 ? 1 : 0;
            if (n2 != 0) {
                this.b = new b();
                return true;
            }
            object.c(0);
            if (j.b((com.google.android.exoplayer2.i.i)object)) {
                this.b = new j();
                return true;
            }
            object.c(0);
            if (!g.b((com.google.android.exoplayer2.i.i)object)) return false;
            this.b = new g();
            return true;
        }
        catch (i var1_2) {
            return false;
        }
    }

}

