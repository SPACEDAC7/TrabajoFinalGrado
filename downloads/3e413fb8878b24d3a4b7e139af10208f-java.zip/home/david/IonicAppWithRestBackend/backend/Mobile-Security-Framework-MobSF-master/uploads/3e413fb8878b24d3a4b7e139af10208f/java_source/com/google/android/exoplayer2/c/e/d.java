/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

import com.google.android.exoplayer2.c.e.e;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.i.i;

final class d {
    final e a = new e();
    final i b = new i(new byte[65025], 0);
    int c = -1;
    boolean d;
    private int e;

    d() {
    }

    private int a(int n2) {
        int n3;
        int n4;
        int n5 = 0;
        this.e = 0;
        do {
            n3 = n5;
            if (this.e + n2 >= this.a.g) break;
            int[] arrn = this.a.j;
            n3 = this.e;
            this.e = n3 + 1;
            n4 = arrn[n3 + n2];
            n5 = n3 = n5 + n4;
        } while (n4 == 255);
        return n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean a(g g2) {
        boolean bl2 = g2 != null;
        a.a.a.a.d.b(bl2);
        if (this.d) {
            this.d = false;
            this.b.a();
        }
        while (!this.d) {
            int n2;
            int n3;
            if (this.c < 0) {
                if (!this.a.a(g2, true)) {
                    return false;
                }
                n2 = this.a.h;
                if ((this.a.b & 1) == 1 && this.b.c == 0) {
                    n2 += this.a(0);
                    n3 = this.e + 0;
                } else {
                    n3 = 0;
                }
                g2.b(n2);
                this.c = n3;
            }
            n3 = this.a(this.c);
            n2 = this.c + this.e;
            if (n3 > 0) {
                g2.b(this.b.a, this.b.c, n3);
                this.b.b(n3 + this.b.c);
                bl2 = this.a.j[n2 - 1] != 255;
                this.d = bl2;
            }
            if (n2 == this.a.g) {
                n2 = -1;
            }
            this.c = n2;
        }
        return true;
    }
}

