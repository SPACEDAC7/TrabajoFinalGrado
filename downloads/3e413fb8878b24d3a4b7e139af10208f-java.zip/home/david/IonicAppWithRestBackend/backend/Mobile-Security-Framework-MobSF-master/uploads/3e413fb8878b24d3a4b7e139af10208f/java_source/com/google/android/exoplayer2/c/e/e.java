/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.i;
import com.google.android.exoplayer2.i.o;
import java.io.EOFException;

final class e {
    private static final int k = o.e("OggS");
    public int a;
    public int b;
    public long c;
    public long d;
    public long e;
    public long f;
    public int g;
    public int h;
    public int i;
    public final int[] j = new int[255];
    private final com.google.android.exoplayer2.i.i l = new com.google.android.exoplayer2.i.i(255);

    e() {
    }

    public final void a() {
        this.a = 0;
        this.b = 0;
        this.c = 0;
        this.d = 0;
        this.e = 0;
        this.f = 0;
        this.g = 0;
        this.h = 0;
        this.i = 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean a(g g2, boolean bl2) {
        int n2 = 0;
        this.l.a();
        this.a();
        int n3 = g2.d() == -1 || g2.d() - g2.b() >= 27 ? 1 : 0;
        if (n3 == 0 || !g2.b(this.l.a, 0, 27, true)) {
            if (!bl2) throw new EOFException();
            return false;
        }
        if (this.l.i() != (long)k) {
            if (bl2) return false;
            throw new i("expected OggS capture pattern at begin of page");
        }
        this.a = this.l.e();
        if (this.a != 0) {
            if (bl2) return false;
            throw new i("unsupported bit stream revision");
        }
        this.b = this.l.e();
        com.google.android.exoplayer2.i.i i2 = this.l;
        byte[] arrby = i2.a;
        n3 = i2.b;
        i2.b = n3 + 1;
        long l2 = arrby[n3];
        arrby = i2.a;
        n3 = i2.b;
        i2.b = n3 + 1;
        long l3 = arrby[n3];
        arrby = i2.a;
        n3 = i2.b;
        i2.b = n3 + 1;
        long l4 = arrby[n3];
        arrby = i2.a;
        n3 = i2.b;
        i2.b = n3 + 1;
        long l5 = arrby[n3];
        arrby = i2.a;
        n3 = i2.b;
        i2.b = n3 + 1;
        long l6 = arrby[n3];
        arrby = i2.a;
        n3 = i2.b;
        i2.b = n3 + 1;
        long l7 = arrby[n3];
        arrby = i2.a;
        n3 = i2.b;
        i2.b = n3 + 1;
        long l8 = arrby[n3];
        arrby = i2.a;
        n3 = i2.b;
        i2.b = n3 + 1;
        this.c = ((long)arrby[n3] & 255) << 56 | (l2 & 255 | (l3 & 255) << 8 | (l4 & 255) << 16 | (l5 & 255) << 24 | (l6 & 255) << 32 | (l7 & 255) << 40 | (l8 & 255) << 48);
        this.d = this.l.j();
        this.e = this.l.j();
        this.f = this.l.j();
        this.g = this.l.e();
        this.h = this.g + 27;
        this.l.a();
        g2.c(this.l.a, 0, this.g);
        n3 = n2;
        while (n3 < this.g) {
            this.j[n3] = this.l.e();
            this.i += this.j[n3];
            ++n3;
        }
        return true;
    }
}

