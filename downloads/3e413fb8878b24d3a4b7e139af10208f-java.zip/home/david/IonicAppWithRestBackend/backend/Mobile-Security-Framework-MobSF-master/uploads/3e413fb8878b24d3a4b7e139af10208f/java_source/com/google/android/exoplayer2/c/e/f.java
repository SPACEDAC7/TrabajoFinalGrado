/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.m;

interface f {
    public long a(g var1);

    public m a();

    public long a_(long var1);
}

