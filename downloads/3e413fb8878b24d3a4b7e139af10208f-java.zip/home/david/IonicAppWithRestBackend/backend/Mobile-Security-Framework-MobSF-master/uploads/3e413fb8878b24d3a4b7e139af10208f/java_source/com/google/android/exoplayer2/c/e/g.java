/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.e.h;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.o;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class g
extends h {
    private static final int a = o.e("Opus");
    private static final byte[] d = new byte[]{79, 112, 117, 115, 72, 101, 97, 100};
    private boolean e;

    g() {
    }

    private static void a(List<byte[]> list, int n2) {
        long l2 = (long)n2 * 1000000000 / 48000;
        list.add(ByteBuffer.allocate(8).order(ByteOrder.nativeOrder()).putLong(l2).array());
    }

    public static boolean b(i i2) {
        if (i2.b() < d.length) {
            return false;
        }
        byte[] arrby = new byte[d.length];
        i2.a(arrby, 0, d.length);
        return Arrays.equals(arrby, d);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final long a(i arrby) {
        int n2;
        arrby = arrby.a;
        int n3 = arrby[0] & 255;
        switch (n3 & 3) {
            default: {
                n2 = arrby[1] & 63;
                break;
            }
            case 0: {
                n2 = 1;
                break;
            }
            case 1: 
            case 2: {
                n2 = 2;
            }
        }
        int n4 = (n3 >>= 3) & 3;
        if (n3 >= 16) {
            n3 = 2500 << n4;
            return this.b(n3 * n2);
        }
        if (n3 >= 12) {
            n3 = 10000 << (n4 & 1);
            return this.b(n3 * n2);
        }
        if (n4 == 3) {
            n3 = 60000;
            return this.b(n3 * n2);
        }
        n3 = 10000 << n4;
        return this.b(n3 * n2);
    }

    @Override
    protected final void a(boolean bl2) {
        super.a(bl2);
        if (bl2) {
            this.e = false;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final boolean a(i arrby, long l2, h.a a2) {
        if (!this.e) {
            arrby = Arrays.copyOf(arrby.a, arrby.c);
            byte by2 = arrby[9];
            byte by3 = arrby[11];
            byte by4 = arrby[10];
            ArrayList<byte[]> arrayList = new ArrayList<byte[]>(3);
            arrayList.add(arrby);
            g.a(arrayList, (by3 & 255) << 8 | by4 & 255);
            g.a(arrayList, 3840);
            a2.a = Format.a(null, "audio/opus", -1, -1, by2 & 255, 48000, arrayList, null, null);
            this.e = true;
            return true;
        }
        boolean bl2 = arrby.k() == a;
        arrby.c(0);
        return bl2;
    }
}

