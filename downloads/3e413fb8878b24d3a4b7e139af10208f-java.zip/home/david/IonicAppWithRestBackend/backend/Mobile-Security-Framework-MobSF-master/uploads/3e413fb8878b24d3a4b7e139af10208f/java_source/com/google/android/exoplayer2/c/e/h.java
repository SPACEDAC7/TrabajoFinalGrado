/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.e.d;
import com.google.android.exoplayer2.c.e.e;
import com.google.android.exoplayer2.c.e.f;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.i;

abstract class h {
    private d a;
    long b;
    int c;
    private n d;
    private com.google.android.exoplayer2.c.h e;
    private f f;
    private long g;
    private long h;
    private int i;
    private a j;
    private long k;
    private boolean l;
    private boolean m;

    h() {
    }

    /*
     * Enabled aggressive block sorting
     */
    final int a(g g2) {
        boolean bl2 = true;
        while (bl2) {
            boolean bl3;
            if (!this.a.a(g2)) {
                this.c = 3;
                return -1;
            }
            this.k = g2.c() - this.b;
            bl2 = bl3 = this.a(this.a.b, this.b, this.j);
            if (!bl3) continue;
            this.b = g2.c();
            bl2 = bl3;
        }
        this.i = this.j.a.r;
        if (!this.m) {
            this.d.a(this.j.a);
            this.m = true;
        }
        if (this.j.b != null) {
            this.f = this.j.b;
        } else if (g2.d() == -1) {
            this.f = new b(0);
        } else {
            e e2 = this.a.a;
            this.f = new com.google.android.exoplayer2.c.e.a(this.b, g2.d(), this, e2.h + e2.i, e2.c);
        }
        this.j = null;
        this.c = 2;
        return 0;
    }

    final int a(g object, l object2) {
        long l2 = this.f.a((g)object);
        if (l2 >= 0) {
            object2.a = l2;
            return 1;
        }
        if (l2 < -1) {
            this.c(- l2 + 2);
        }
        if (!this.l) {
            object2 = this.f.a();
            this.e.a((m)object2);
            this.l = true;
        }
        if (this.k > 0 || this.a.a((g)object)) {
            this.k = 0;
            object = this.a.b;
            l2 = this.a((i)object);
            if (l2 >= 0 && this.h + l2 >= this.g) {
                long l3 = this.a(this.h);
                this.d.a((i)object, object.c);
                this.d.a(l3, 1, object.c, 0, null);
                this.g = -1;
            }
            this.h += l2;
            return 0;
        }
        this.c = 3;
        return -1;
    }

    protected final long a(long l2) {
        return 1000000 * l2 / (long)this.i;
    }

    protected abstract long a(i var1);

    /*
     * Enabled aggressive block sorting
     */
    final void a(long l2, long l3) {
        boolean bl2 = false;
        d d2 = this.a;
        d2.a.a();
        d2.b.a();
        d2.c = -1;
        d2.d = false;
        if (l2 == 0) {
            if (!this.l) {
                bl2 = true;
            }
            this.a(bl2);
            return;
        } else {
            if (this.c == 0) return;
            {
                this.g = this.f.a_(l3);
                this.c = 2;
                return;
            }
        }
    }

    final void a(com.google.android.exoplayer2.c.h h2, n n2) {
        this.e = h2;
        this.d = n2;
        this.a = new d();
        this.a(true);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a(boolean bl2) {
        if (bl2) {
            this.j = new a();
            this.b = 0;
            this.c = 0;
        } else {
            this.c = 1;
        }
        this.g = -1;
        this.h = 0;
    }

    protected abstract boolean a(i var1, long var2, a var4);

    protected final long b(long l2) {
        return (long)this.i * l2 / 1000000;
    }

    protected void c(long l2) {
        this.h = l2;
    }

    static final class a {
        Format a;
        f b;

        a() {
        }
    }

    static final class b
    implements f {
        private b() {
        }

        /* synthetic */ b(byte by2) {
            this();
        }

        @Override
        public final long a(g g2) {
            return -1;
        }

        @Override
        public final m a() {
            return new m.a(-9223372036854775807L);
        }

        @Override
        public final long a_(long l2) {
            return 0;
        }
    }

}

