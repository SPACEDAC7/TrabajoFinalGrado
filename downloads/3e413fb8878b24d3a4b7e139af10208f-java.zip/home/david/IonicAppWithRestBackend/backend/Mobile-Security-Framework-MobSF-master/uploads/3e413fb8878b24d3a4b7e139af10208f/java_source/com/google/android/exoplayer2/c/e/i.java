/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

import a.a.a.a.d;

public final class i {
    public final byte[] a;
    private final int b;
    private int c;
    private int d;

    public i(byte[] arrby) {
        this(arrby, arrby.length);
    }

    private i(byte[] arrby, int n2) {
        this.a = arrby;
        this.b = n2 << 3;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int a(int n2) {
        int n3;
        int n4;
        int n5;
        int n6;
        boolean bl2 = this.b() + n2 <= this.b;
        d.b(bl2);
        if (n2 == 0) {
            return 0;
        }
        if (this.d != 0) {
            n5 = Math.min(n2, 8 - this.d);
            n6 = 255 >>> 8 - n5 & this.a[this.c] >>> this.d;
            this.d += n5;
            n4 = n5;
            n3 = n6;
            if (this.d == 8) {
                ++this.c;
                this.d = 0;
                n3 = n6;
                n4 = n5;
            }
        } else {
            n4 = 0;
            n3 = 0;
        }
        if (n2 - n4 > 7) {
            n6 = (n2 - n4) / 8;
            for (n5 = 0; n5 < n6; n4 += 8, ++n5) {
                long l2 = n3;
                byte[] arrby = this.a;
                n3 = this.c;
                this.c = n3 + 1;
                n3 = (int)(l2 | ((long)arrby[n3] & 255) << n4);
            }
            n5 = n3;
            n3 = n4;
            n4 = n5;
        } else {
            n5 = n4;
            n4 = n3;
            n3 = n5;
        }
        n5 = n4;
        if (n2 > n3) {
            n5 = n4 | (255 >>> 8 - (n2 -= n3) & this.a[this.c]) << n3;
            this.d += n2;
        }
        return n5;
    }

    public final boolean a() {
        if (this.a(1) == 1) {
            return true;
        }
        return false;
    }

    public final int b() {
        return (this.c << 3) + this.d;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void b(int n2) {
        boolean bl2 = this.b() + n2 <= this.b;
        d.b(bl2);
        this.c += n2 / 8;
        this.d += n2 % 8;
        if (this.d > 7) {
            ++this.c;
            this.d -= 8;
        }
    }
}

