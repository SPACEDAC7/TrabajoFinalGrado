/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

import a.a.a.a.d;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.e.h;
import com.google.android.exoplayer2.c.e.i;
import com.google.android.exoplayer2.c.e.k;
import com.google.android.exoplayer2.c.e.l;
import com.google.android.exoplayer2.c.e.m;
import com.google.android.exoplayer2.c.e.n;
import java.util.ArrayList;
import java.util.Arrays;

final class j
extends h {
    private a a;
    private int d;
    private boolean e;
    private n f;
    private l g;

    j() {
    }

    public static boolean b(com.google.android.exoplayer2.i.i i2) {
        try {
            boolean bl2 = d.a(1, i2, true);
            return bl2;
        }
        catch (com.google.android.exoplayer2.i var0_1) {
            return false;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final long a(com.google.android.exoplayer2.i.i i2) {
        int n2 = 0;
        if ((i2.a[0] & 1) == 1) {
            return -1;
        }
        int n3 = i2.a[0];
        a a2 = this.a;
        int n4 = a2.e;
        n3 = !a2.d[n3 >> 1 & 255 >>> 8 - n4].a ? a2.a.g : a2.a.h;
        if (this.e) {
            n2 = (this.d + n3) / 4;
        }
        long l2 = n2;
        i2.b(i2.c + 4);
        i2.a[i2.c - 4] = (byte)(l2 & 255);
        i2.a[i2.c - 3] = (byte)(l2 >>> 8 & 255);
        i2.a[i2.c - 2] = (byte)(l2 >>> 16 & 255);
        i2.a[i2.c - 1] = (byte)(l2 >>> 24 & 255);
        this.e = true;
        this.d = n3;
        return n2;
    }

    @Override
    protected final void a(boolean bl2) {
        super.a(bl2);
        if (bl2) {
            this.a = null;
            this.f = null;
            this.g = null;
        }
        this.d = 0;
        this.e = false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final boolean a(com.google.android.exoplayer2.i.i var1_1, long var2_2, h.a var4_3) {
        if (this.a != null) {
            return false;
        }
        if (this.f != null) ** GOTO lbl18
        d.a(1, (com.google.android.exoplayer2.i.i)var1_1, false);
        var2_2 = var1_1.j();
        var7_4 = var1_1.e();
        var16_7 = var1_1.j();
        var8_9 = var1_1.l();
        var9_12 = var1_1.l();
        var10_14 = var1_1.l();
        var12_16 = var1_1.e();
        var11_18 = (int)Math.pow(2.0, var12_16 & 15);
        var12_16 = (int)Math.pow(2.0, (var12_16 & 240) >> 4);
        var18_20 = (var1_1.e() & 1) > 0;
        this.f = new n(var2_2, var7_4, var16_7, var8_9, var9_12, var10_14, var11_18, var12_16, var18_20, Arrays.copyOf(var1_1.a, var1_1.c));
        var1_1 = null;
        ** GOTO lbl36
lbl18: // 1 sources:
        if (this.g == null) {
            d.a(3, (com.google.android.exoplayer2.i.i)var1_1, false);
            var5_22 = var1_1.e((int)var1_1.j());
            var7_5 = var5_22.length();
            var2_2 = var1_1.j();
            var6_24 = new String[(int)var2_2];
            var8_10 = var7_5 + 11 + 4;
            var7_5 = 0;
            while ((long)var7_5 < var2_2) {
                var6_24[var7_5] = var1_1.e((int)var1_1.j());
                var8_10 = var8_10 + 4 + var6_24[var7_5].length();
                ++var7_5;
            }
            if ((var1_1.e() & 1) == 0) {
                throw new com.google.android.exoplayer2.i("framing bit expected to be set");
            }
            this.g = new l(var5_22, var6_24, var8_10 + 1);
            var1_1 = null;
        }
        ** GOTO lbl45
lbl36: // 3 sources:
        do {
            this.a = var1_1;
            if (this.a == null) {
                return true;
            }
            var1_1 = new ArrayList<E>();
            var1_1.add(this.a.a.j);
            var1_1.add(this.a.c);
            var4_3.a = Format.a(null, "audio/vorbis", this.a.a.e, 65025, this.a.a.b, (int)this.a.a.c, var1_1, null, null);
            return true;
            break;
        } while (true);
lbl45: // 1 sources:
        var5_23 = new byte[var1_1.c];
        System.arraycopy(var1_1.a, 0, var5_23, 0, var1_1.c);
        var11_19 = this.f.b;
        d.a(5, (com.google.android.exoplayer2.i.i)var1_1, false);
        var12_17 = var1_1.e();
        var6_25 = new i(var1_1.a);
        var6_25.b(var1_1.b << 3);
        var7_6 = 0;
        do {
            if (var7_6 >= var12_17 + 1) ** GOTO lbl67
            if (var6_25.a(24) != 5653314) {
                throw new com.google.android.exoplayer2.i("expected code book to start with [0x56, 0x43, 0x42] at " + var6_25.b());
            }
            var13_26 = var6_25.a(16);
            var14_27 = var6_25.a(24);
            var1_1 = new long[var14_27];
            var18_21 = var6_25.a();
            if (var18_21) ** GOTO lbl64
            var19_29 = var6_25.a();
            ** GOTO lbl69
lbl64: // 1 sources:
            var8_11 = var6_25.a(5) + 1;
            var9_13 = 0;
            ** GOTO lbl73
lbl67: // 1 sources:
            var8_11 = var6_25.a(6);
            break;
lbl69: // 2 sources:
            for (var8_11 = 0; var8_11 < var1_1.length; ++var8_11) {
                var1_1[var8_11] = var19_29 != false && var6_25.a() == false ? (m)0 : (m)((long)(var6_25.a(5) + 1));
            }
            ** GOTO lbl80
lbl73: // 2 sources:
            while (var9_13 < var1_1.length) {
                var15_28 = var6_25.a(d.a(var14_27 - var9_13));
                for (var10_15 = 0; var10_15 < var15_28 && var9_13 < var1_1.length; ++var10_15, ++var9_13) {
                    var1_1[var9_13] = var8_11;
                }
                ++var8_11;
            }
lbl80: // 2 sources:
            if ((var8_11 = var6_25.a(4)) > 2) {
                throw new com.google.android.exoplayer2.i("lookup type greater than 2 not decodable: " + var8_11);
            }
            if (var8_11 == 1 || var8_11 == 2) {
                var6_25.b(32);
                var6_25.b(32);
                var9_13 = var6_25.a(4);
                var6_25.b(1);
                if (var8_11 == 1) {
                    if (var13_26 != 0) {
                        var2_2 = var14_27;
                        var16_8 = var13_26;
                        var2_2 = (long)Math.floor(Math.pow(var2_2, 1.0 / (double)var16_8));
                    } else {
                        var2_2 = 0;
                    }
                } else {
                    var2_2 = var14_27 * var13_26;
                }
                var6_25.b((int)(var2_2 * (long)(var9_13 + 1)));
            }
            new k(var13_26, var14_27, (long[])var1_1, var8_11, var18_21);
            ++var7_6;
        } while (true);
        for (var7_6 = 0; var7_6 < var8_11 + 1; ++var7_6) {
            if (var6_25.a(16) == 0) continue;
            throw new com.google.android.exoplayer2.i("placeholder of time domain transforms not zeroed out");
        }
        d.c(var6_25);
        d.b(var6_25);
        d.a(var11_19, var6_25);
        var1_1 = d.a(var6_25);
        if (!var6_25.a()) {
            throw new com.google.android.exoplayer2.i("framing bit after modes not set as expected");
        }
        var7_6 = d.a(var1_1.length - 1);
        var1_1 = new a(this.f, this.g, var5_23, (m[])var1_1, var7_6);
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void c(long l2) {
        int n2 = 0;
        super.c(l2);
        boolean bl2 = l2 != 0;
        this.e = bl2;
        if (this.f != null) {
            n2 = this.f.g;
        }
        this.d = n2;
    }

    static final class a {
        public final n a;
        public final l b;
        public final byte[] c;
        public final m[] d;
        public final int e;

        public a(n n2, l l2, byte[] arrby, m[] arrm, int n3) {
            this.a = n2;
            this.b = l2;
            this.c = arrby;
            this.d = arrm;
            this.e = n3;
        }
    }

}

