/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

public final class k {
    public final int a;
    public final int b;
    public final long[] c;
    public final int d;
    public final boolean e;

    public k(int n2, int n3, long[] arrl, int n4, boolean bl2) {
        this.a = n2;
        this.b = n3;
        this.c = arrl;
        this.d = n4;
        this.e = bl2;
    }
}

