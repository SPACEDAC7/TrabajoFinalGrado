/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

public final class l {
    public final String a;
    public final String[] b;
    public final int c;

    public l(String string, String[] arrstring, int n2) {
        this.a = string;
        this.b = arrstring;
        this.c = n2;
    }
}

