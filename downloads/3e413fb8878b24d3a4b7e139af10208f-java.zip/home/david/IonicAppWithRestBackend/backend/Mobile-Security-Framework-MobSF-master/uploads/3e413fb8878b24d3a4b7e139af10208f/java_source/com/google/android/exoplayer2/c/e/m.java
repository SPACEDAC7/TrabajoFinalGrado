/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

public final class m {
    public final boolean a;
    public final int b;
    public final int c;
    public final int d;

    public m(boolean bl2, int n2, int n3, int n4) {
        this.a = bl2;
        this.b = n2;
        this.c = n3;
        this.d = n4;
    }
}

