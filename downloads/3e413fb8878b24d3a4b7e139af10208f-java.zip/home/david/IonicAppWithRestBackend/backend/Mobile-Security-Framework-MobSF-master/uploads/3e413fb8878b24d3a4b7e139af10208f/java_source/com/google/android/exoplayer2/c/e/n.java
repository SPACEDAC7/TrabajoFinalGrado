/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.e;

public final class n {
    public final long a;
    public final int b;
    public final long c;
    public final int d;
    public final int e;
    public final int f;
    public final int g;
    public final int h;
    public final boolean i;
    public final byte[] j;

    public n(long l2, int n2, long l3, int n3, int n4, int n5, int n6, int n7, boolean bl2, byte[] arrby) {
        this.a = l2;
        this.b = n2;
        this.c = l3;
        this.d = n3;
        this.e = n4;
        this.f = n5;
        this.g = n6;
        this.h = n7;
        this.i = bl2;
        this.j = arrby;
    }
}

