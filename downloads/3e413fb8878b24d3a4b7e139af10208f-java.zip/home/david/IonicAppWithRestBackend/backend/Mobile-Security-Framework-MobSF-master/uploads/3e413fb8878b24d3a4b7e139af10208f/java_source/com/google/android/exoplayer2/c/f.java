/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.l;

public interface f {
    public int a(g var1, l var2);

    public void a(long var1, long var3);

    public void a(h var1);

    public boolean a(g var1);
}

