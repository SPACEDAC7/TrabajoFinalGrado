/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.a.a;
import com.google.android.exoplayer2.c.f.f;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.i;

final class b
implements f {
    long a;
    private final com.google.android.exoplayer2.i.h b = new com.google.android.exoplayer2.i.h(new byte[8]);
    private final i c;
    private final String d;
    private n e;
    private int f;
    private int g;
    private boolean h;
    private long i;
    private Format j;
    private int k;
    private boolean l;

    public b() {
        this(null);
    }

    public b(String string) {
        this.c = new i(this.b.a);
        this.f = 0;
        this.d = string;
    }

    @Override
    public final void a() {
        this.f = 0;
        this.g = 0;
        this.h = false;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.a = l2;
    }

    @Override
    public final void a(h h2, t.c c2) {
        this.e = h2.a(c2.a());
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(i i2) {
        block5 : while (i2.b() > 0) {
            int n2;
            block10 : {
                boolean bl2;
                switch (this.f) {
                    default: {
                        continue block5;
                    }
                    case 0: {
                        break;
                    }
                    case 1: {
                        Object object = this.c.a;
                        n2 = Math.min(i2.b(), 8 - this.g);
                        i2.a((byte[])object, this.g, n2);
                        this.g += n2;
                        n2 = this.g == 8 ? 1 : 0;
                        if (n2 == 0) continue block5;
                        if (this.j == null) {
                            this.b.b(40);
                            bl2 = this.b.c(5) == 16;
                            this.l = bl2;
                            object = this.b;
                            com.google.android.exoplayer2.i.h h2 = this.b;
                            n2 = h2.b;
                            object.a(h2.c + (n2 << 3) - 45);
                            object = this.l ? a.b(this.b, this.d) : a.a(this.b, this.d);
                            this.j = object;
                            this.e.a(this.j);
                        }
                        n2 = this.l ? a.b(this.b.a) : a.a(this.b.a);
                        this.k = n2;
                        n2 = this.l ? a.c(this.b.a) : a.a();
                        this.i = (int)((long)n2 * 1000000 / (long)this.j.r);
                        this.c.c(0);
                        this.e.a(this.c, 8);
                        this.f = 2;
                        continue block5;
                    }
                    case 2: {
                        n2 = Math.min(i2.b(), this.k - this.g);
                        this.e.a(i2, n2);
                        this.g = n2 + this.g;
                        if (this.g != this.k) continue block5;
                        this.e.a(this.a, 1, this.k, 0, null);
                        this.a += this.i;
                        this.f = 0;
                        continue block5;
                    }
                }
                while (i2.b() > 0) {
                    if (!this.h) {
                        bl2 = i2.e() == 11;
                        this.h = bl2;
                        continue;
                    }
                    n2 = i2.e();
                    if (n2 == 119) {
                        this.h = false;
                        n2 = 1;
                        break block10;
                    }
                    bl2 = n2 == 11;
                    this.h = bl2;
                }
                n2 = 0;
            }
            if (n2 == 0) continue;
            this.f = 1;
            this.c.a[0] = 11;
            this.c.a[1] = 119;
            this.g = 2;
        }
    }

    @Override
    public final void b() {
    }
}

