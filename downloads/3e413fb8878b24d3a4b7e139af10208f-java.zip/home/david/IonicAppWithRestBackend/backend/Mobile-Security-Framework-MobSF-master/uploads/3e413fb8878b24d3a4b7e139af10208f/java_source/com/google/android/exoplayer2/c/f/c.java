/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import com.google.android.exoplayer2.c.f;
import com.google.android.exoplayer2.c.f.d;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.i;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.i.o;

public final class c
implements f {
    public static final i a = new i(){

        @Override
        public final f[] a() {
            return new f[]{new c()};
        }
    };
    private static final int b = o.e("ID3");
    private final long c = 0;
    private final com.google.android.exoplayer2.i.i d = new com.google.android.exoplayer2.i.i(200);
    private d e;
    private boolean f;

    public c() {
        this(0);
    }

    private c(byte by2) {
    }

    @Override
    public final int a(g g2, l l2) {
        int n2 = g2.a(this.d.a, 0, 200);
        if (n2 == -1) {
            return -1;
        }
        this.d.c(0);
        this.d.b(n2);
        if (!this.f) {
            this.e.a = this.c;
            this.f = true;
        }
        this.e.a(this.d);
        return 0;
    }

    @Override
    public final void a(long l2, long l3) {
        this.f = false;
        this.e.c();
    }

    @Override
    public final void a(h h2) {
        this.e = new d();
        this.e.a(h2, new t.c(0, 1));
        h2.b();
        h2.a(new m.a(-9223372036854775807L));
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean a(g g2) {
        int n2;
        com.google.android.exoplayer2.i.i i2 = new com.google.android.exoplayer2.i.i(10);
        com.google.android.exoplayer2.i.h h2 = new com.google.android.exoplayer2.i.h(i2.a);
        int n3 = 0;
        do {
            g2.c(i2.a, 0, 10);
            i2.c(0);
            if (i2.h() != b) break;
            i2.d(3);
            n2 = i2.n();
            n3 += n2 + 10;
            g2.c(n2);
        } while (true);
        g2.a();
        g2.c(n3);
        int n4 = 0;
        n2 = 0;
        int n5 = n3;
        do {
            g2.c(i2.a, 0, 2);
            i2.c(0);
            if ((i2.f() & 65526) != 65520) {
                g2.a();
                if (++n5 - n3 >= 8192) return false;
                {
                    g2.c(n5);
                    n2 = 0;
                    n4 = 0;
                    continue;
                }
            }
            if (++n4 >= 4 && n2 > 188) {
                return true;
            }
            g2.c(i2.a, 0, 4);
            h2.a(14);
            int n6 = h2.c(13);
            if (n6 <= 6) {
                return false;
            }
            g2.c(n6 - 6);
            n2 += n6;
        } while (true);
    }

}

