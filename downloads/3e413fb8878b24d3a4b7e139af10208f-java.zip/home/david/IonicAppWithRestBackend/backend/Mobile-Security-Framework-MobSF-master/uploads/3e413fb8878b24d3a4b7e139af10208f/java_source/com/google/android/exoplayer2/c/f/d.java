/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  android.util.Pair
 */
package com.google.android.exoplayer2.c.f;

import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.e;
import com.google.android.exoplayer2.c.f.f;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.a;
import com.google.android.exoplayer2.i.i;
import java.util.Arrays;
import java.util.Collections;

final class d
implements f {
    private static final byte[] b = new byte[]{73, 68, 51};
    long a;
    private final boolean c;
    private final com.google.android.exoplayer2.i.h d = new com.google.android.exoplayer2.i.h(new byte[7]);
    private final i e = new i(Arrays.copyOf(b, 10));
    private final String f;
    private n g;
    private n h;
    private int i;
    private int j;
    private int k;
    private boolean l;
    private boolean m;
    private long n;
    private int o;
    private n p;
    private long q;

    public d() {
        this(true, null);
    }

    public d(boolean bl2, String string) {
        this.c();
        this.c = bl2;
        this.f = string;
    }

    private void a(n n2, long l2, int n3, int n4) {
        this.i = 3;
        this.j = n3;
        this.p = n2;
        this.q = l2;
        this.o = n4;
    }

    private boolean a(i i2, byte[] arrby, int n2) {
        int n3 = Math.min(i2.b(), n2 - this.j);
        i2.a(arrby, this.j, n3);
        this.j = n3 + this.j;
        if (this.j == n2) {
            return true;
        }
        return false;
    }

    @Override
    public final void a() {
        this.c();
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.a = l2;
    }

    @Override
    public final void a(h h2, t.c c2) {
        this.g = h2.a(c2.a());
        if (this.c) {
            this.h = h2.a(c2.a());
            this.h.a(Format.a(null, "application/id3", null));
            return;
        }
        this.h = new e();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(i var1_1) {
        block12 : while (var1_1.b() > 0) {
            block19 : {
                switch (this.i) {
                    default: {
                        ** break;
                    }
                    case 0: {
                        var2_2 = var1_1.a;
                        var4_4 = var1_1.b;
                        var6_6 = var1_1.c;
                        break;
                    }
                    case 1: {
                        if (!this.a(var1_1, this.e.a, 10)) continue block12;
                        this.h.a(this.e, 10);
                        this.e.c(6);
                        this.a(this.h, 0, 10, this.e.n() + 10);
                        ** break;
                    }
                    case 2: {
                        var4_4 = this.l != false ? 7 : 5;
                        if (!this.a(var1_1, this.d.a, var4_4)) continue block12;
                        this.d.a(0);
                        if (!this.m) {
                            var4_4 = var5_5 = this.d.c(2) + 1;
                            if (var5_5 != 2) {
                                Log.w((String)"AdtsReader", (String)("Detected audio object type: " + var5_5 + ", but assuming AAC LC."));
                                var4_4 = 2;
                            }
                            var5_5 = this.d.c(4);
                            this.d.b(1);
                            var2_2 = a.a(var4_4, var5_5, this.d.c(3));
                            var3_3 = a.a((byte[])var2_2);
                            var2_2 = Format.a(null, "audio/mp4a-latm", -1, -1, (Integer)var3_3.second, (Integer)var3_3.first, Collections.singletonList(var2_2), null, this.f);
                            this.n = 1024000000 / (long)var2_2.r;
                            this.g.a((Format)var2_2);
                            this.m = true;
                        } else {
                            this.d.b(10);
                        }
                        this.d.b(4);
                        var4_4 = var5_5 = this.d.c(13) - 2 - 5;
                        if (this.l) {
                            var4_4 = var5_5 - 2;
                        }
                        this.a(this.g, this.n, 0, var4_4);
                        ** break;
                    }
                    case 3: {
                        var4_4 = Math.min(var1_1.b(), this.o - this.j);
                        this.p.a(var1_1, var4_4);
                        this.j = var4_4 + this.j;
                        if (this.j != this.o) continue block12;
                        this.p.a(this.a, 1, this.o, 0, null);
                        this.a += this.q;
                        this.c();
                        ** break;
                    }
                }
                block13 : while (var4_4 < var6_6) {
                    var5_5 = var4_4 + 1;
                    var4_4 = var2_2[var4_4] & 255;
                    if (this.k == 512 && var4_4 >= 240 && var4_4 != 255) {
                        var7_7 = (var4_4 & 1) == 0;
                        this.l = var7_7;
                        this.i = 2;
                        this.j = 0;
                        break block19;
                    }
                    switch (var4_4 | this.k) {
                        default: {
                            if (this.k == 256) break;
                            this.k = 256;
                            var4_4 = var5_5 - 1;
                            continue block13;
                        }
                        case 511: {
                            this.k = 512;
                            var4_4 = var5_5;
                            continue block13;
                        }
                        case 329: {
                            this.k = 768;
                            var4_4 = var5_5;
                            continue block13;
                        }
                        case 836: {
                            this.k = 1024;
                            var4_4 = var5_5;
                            continue block13;
                        }
                        case 1075: {
                            this.i = 1;
                            this.j = d.b.length;
                            this.o = 0;
                            this.e.c(0);
                            break block19;
                        }
                    }
                    var4_4 = var5_5;
                }
                var5_5 = var4_4;
            }
            var1_1.c(var5_5);
            ** break;
lbl89: // 5 sources:
        }
    }

    @Override
    public final void b() {
    }

    final void c() {
        this.i = 0;
        this.j = 0;
        this.k = 256;
    }
}

