/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.f.f;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.i;

final class e
implements f {
    private final i a = new i(new byte[15]);
    private final String b;
    private n c;
    private int d;
    private int e;
    private int f;
    private long g;
    private Format h;
    private int i;
    private long j;

    public e(String string) {
        this.a.a[0] = 127;
        this.a.a[1] = -2;
        this.a.a[2] = -128;
        this.a.a[3] = 1;
        this.d = 0;
        this.b = string;
    }

    @Override
    public final void a() {
        this.d = 0;
        this.e = 0;
        this.f = 0;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.j = l2;
    }

    @Override
    public final void a(h h2, t.c c2) {
        this.c = h2.a(c2.a());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(i var1_1) {
        block5 : while (var1_1.b() > 0) {
            switch (this.d) {
                default: {
                    continue block5;
                }
                case 0: {
                    while (var1_1.b() > 0) {
                        this.f <<= 8;
                        this.f |= var1_1.e();
                        if (this.f != 2147385345) continue;
                        this.f = 0;
                        var3_3 = 1;
                        ** GOTO lbl14
                    }
                    var3_3 = 0;
lbl14: // 2 sources:
                    if (var3_3 == 0) continue block5;
                    this.e = 4;
                    this.d = 1;
                    continue block5;
                }
                case 1: {
                    var2_2 = this.a.a;
                    var3_3 = Math.min(var1_1.b(), 15 - this.e);
                    var1_1.a(var2_2, this.e, var3_3);
                    this.e += var3_3;
                    var3_3 = this.e == 15 ? 1 : 0;
                    if (var3_3 == 0) continue block5;
                    var2_2 = this.a.a;
                    if (this.h == null) {
                        this.h = com.google.android.exoplayer2.a.e.a(var2_2, this.b);
                        this.c.a(this.h);
                    }
                    this.i = com.google.android.exoplayer2.a.e.b(var2_2);
                    this.g = (int)((long)com.google.android.exoplayer2.a.e.a(var2_2) * 1000000 / (long)this.h.r);
                    this.a.c(0);
                    this.c.a(this.a, 15);
                    this.d = 2;
                    continue block5;
                }
                case 2: 
            }
            var3_3 = Math.min(var1_1.b(), this.i - this.e);
            this.c.a(var1_1, var3_3);
            this.e = var3_3 + this.e;
            if (this.e != this.i) continue;
            this.c.a(this.j, 1, this.i, 0, null);
            this.j += this.g;
            this.d = 0;
        }
    }

    @Override
    public final void b() {
    }
}

