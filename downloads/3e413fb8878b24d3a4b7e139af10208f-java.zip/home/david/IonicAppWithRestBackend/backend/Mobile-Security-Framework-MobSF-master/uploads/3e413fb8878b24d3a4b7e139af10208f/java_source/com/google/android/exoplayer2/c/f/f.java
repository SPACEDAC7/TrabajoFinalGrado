/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.i.i;

public interface f {
    public void a();

    public void a(long var1, boolean var3);

    public void a(h var1, t.c var2);

    public void a(i var1);

    public void b();
}

