/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 */
package com.google.android.exoplayer2.c.f;

import android.util.Pair;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.f.f;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.i;
import java.util.Arrays;
import java.util.Collections;

final class g
implements f {
    private static final double[] b = new double[]{23.976023976023978, 24.0, 25.0, 29.97002997002997, 30.0, 50.0, 59.94005994005994, 60.0};
    private n a;
    private boolean c;
    private long d;
    private final boolean[] e = new boolean[4];
    private final a f = new a();
    private boolean g;
    private long h;
    private long i;
    private boolean j;
    private boolean k;
    private long l;
    private long m;

    @Override
    public final void a() {
        com.google.android.exoplayer2.i.g.a(this.e);
        a a2 = this.f;
        a2.a = false;
        a2.b = 0;
        a2.c = 0;
        this.j = false;
        this.g = false;
        this.h = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(long l2, boolean bl2) {
        bl2 = l2 != -9223372036854775807L;
        this.j = bl2;
        if (this.j) {
            this.i = l2;
        }
    }

    @Override
    public final void a(h h2, t.c c2) {
        this.a = h2.a(c2.a());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(i var1_1) {
        var12_2 = var1_1.b;
        var14_3 = var1_1.c;
        var7_4 = var1_1.a;
        this.h += (long)var1_1.b();
        this.a.a(var1_1, var1_1.b());
        var11_5 = var12_2;
        do {
            if ((var12_2 = com.google.android.exoplayer2.i.g.a(var7_4, var12_2, var14_3, this.e)) == var14_3) {
                if (this.c != false) return;
                this.f.a(var7_4, var11_5, var14_3);
                return;
            }
            var13_12 = var1_1.a[var12_2 + 3] & 255;
            if (this.c) ** GOTO lbl67
            var15_13 = var12_2 - var11_5;
            if (var15_13 > 0) {
                this.f.a(var7_4, var11_5, var12_2);
            }
            var11_5 = var15_13 < 0 ? - var15_13 : 0;
            var8_9 = this.f;
            if (!var8_9.a) ** GOTO lbl27
            if (var8_9.c != 0 || var13_12 != 181) ** GOTO lbl23
            var8_9.c = var8_9.b;
            ** GOTO lbl29
lbl23: // 1 sources:
            var8_9.b -= var11_5;
            var8_9.a = false;
            var11_5 = 1;
            ** GOTO lbl30
lbl27: // 1 sources:
            if (var13_12 == 179) {
                var8_9.a = true;
            }
lbl29: // 4 sources:
            var11_5 = 0;
lbl30: // 2 sources:
            if (var11_5 != 0) {
                var8_9 = this.f;
                var9_10 = Arrays.copyOf(var8_9.d, var8_9.b);
                var16_15 = var9_10[4];
                var11_5 = var9_10[5] & 255;
                var15_13 = var9_10[6];
                var16_15 = var11_5 >> 4 | (var16_15 & 255) << 4;
                var11_5 = (var11_5 & 15) << 8 | var15_13 & 255;
                var6_8 = 1.0f;
                switch ((var9_10[7] & 240) >> 4) {
                    case 2: {
                        var6_8 = (float)(var11_5 * 4) / (float)(var16_15 * 3);
                        break;
                    }
                    case 3: {
                        var6_8 = (float)(var11_5 << 4) / (float)(var16_15 * 9);
                        break;
                    }
                    case 4: {
                        var6_8 = (float)(var11_5 * 121) / (float)(var16_15 * 100);
                    }
                }
                var10_11 = Format.a("video/mpeg2", var16_15, var11_5, Collections.singletonList(var9_10), var6_8);
                var19_16 = 0;
                var11_5 = (var9_10[7] & 15) - 1;
                var17_14 = var19_16;
                if (var11_5 >= 0) {
                    var17_14 = var19_16;
                    if (var11_5 < g.b.length) {
                        var4_7 = g.b[var11_5];
                        var15_13 = var8_9.c;
                        var11_5 = (var9_10[var15_13 + 9] & 96) >> 5;
                        var15_13 = var9_10[var15_13 + 9] & 31;
                        var2_6 = var4_7;
                        if (var11_5 != var15_13) {
                            var2_6 = var4_7 * (((double)var11_5 + 1.0) / (double)(var15_13 + 1));
                        }
                        var17_14 = (long)(1000000.0 / var2_6);
                    }
                }
                var8_9 = Pair.create((Object)var10_11, (Object)var17_14);
                this.a.a((Format)var8_9.first);
                this.d = (Long)var8_9.second;
                this.c = true;
            }
lbl67: // 4 sources:
            if (this.c && (var13_12 == 184 || var13_12 == 0)) {
                var15_13 = var14_3 - var12_2;
                if (this.g) {
                    var11_5 = this.k != false ? 1 : 0;
                    var16_15 = (int)(this.h - this.l);
                    this.a.a(this.m, var11_5, var16_15 - var15_13, var15_13, null);
                    this.k = false;
                }
                if (var13_12 == 184) {
                    this.g = false;
                    this.k = true;
                } else {
                    var17_14 = this.j != false ? this.i : this.m + this.d;
                    this.m = var17_14;
                    this.l = this.h - (long)var15_13;
                    this.j = false;
                    this.g = true;
                }
            }
            var13_12 = var12_2 + 3;
            var11_5 = var12_2;
            var12_2 = var13_12;
        } while (true);
    }

    @Override
    public final void b() {
    }

    static final class a {
        boolean a;
        public int b;
        public int c;
        public byte[] d = new byte[128];

        public final void a(byte[] arrby, int n2, int n3) {
            if (!this.a) {
                return;
            }
            if (this.d.length < this.b + (n3 -= n2)) {
                this.d = Arrays.copyOf(this.d, this.b + n3 << 1);
            }
            System.arraycopy(arrby, n2, this.d, this.b, n3);
            this.b = n3 + this.b;
        }
    }

}

