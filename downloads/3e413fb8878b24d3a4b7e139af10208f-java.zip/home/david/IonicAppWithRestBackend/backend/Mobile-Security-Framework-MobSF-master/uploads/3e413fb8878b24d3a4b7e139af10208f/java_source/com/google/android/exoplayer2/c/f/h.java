/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 */
package com.google.android.exoplayer2.c.f;

import android.util.SparseArray;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.f.f;
import com.google.android.exoplayer2.c.f.l;
import com.google.android.exoplayer2.c.f.q;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.g;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.j;
import java.util.ArrayList;
import java.util.Arrays;

final class h
implements f {
    private final boolean a;
    private final boolean b;
    private final l c;
    private final l d;
    private final l e;
    private long f;
    private final boolean[] g = new boolean[3];
    private n h;
    private q i;
    private a j;
    private boolean k;
    private long l;
    private final i m;

    public h(boolean bl2, boolean bl3) {
        this.a = bl2;
        this.b = bl3;
        this.c = new l(7);
        this.d = new l(8);
        this.e = new l(6);
        this.m = new i();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(byte[] var1_1, int var2_2, int var3_3) {
        if (!this.k || this.j.c) {
            this.c.a((byte[])var1_1, var2_2, var3_3);
            this.d.a((byte[])var1_1, var2_2, var3_3);
        }
        this.e.a((byte[])var1_1, var2_2, var3_3);
        var4_4 = this.j;
        if (var4_4.k == false) return;
        if (var4_4.g.length < var4_4.h + (var3_3 -= var2_2)) {
            var4_4.g = Arrays.copyOf(var4_4.g, var4_4.h + var3_3 << 1);
        }
        System.arraycopy(var1_1, var2_2, var4_4.g, var4_4.h, var3_3);
        var4_4.h = var3_3 + var4_4.h;
        var4_4.f.a(var4_4.g, 0, var4_4.h);
        if (var4_4.f.b(8) == false) return;
        var4_4.f.a(1);
        var10_5 = var4_4.f.c(2);
        var4_4.f.a(5);
        if (var4_4.f.b() == false) return;
        var4_4.f.d();
        if (var4_4.f.b() == false) return;
        var11_6 = var4_4.f.d();
        if (!var4_4.c) {
            var4_4.k = false;
            var1_1 = var4_4.n;
            var1_1.e = var11_6;
            var1_1.b = true;
            return;
        }
        if (var4_4.f.b() == false) return;
        var12_7 = var4_4.f.d();
        if (var4_4.e.indexOfKey(var12_7) < 0) {
            var4_4.k = false;
            return;
        }
        var5_8 = (g.a)var4_4.e.get(var12_7);
        var1_1 = (g.b)var4_4.d.get(var5_8.b);
        if (var1_1.e) {
            if (var4_4.f.b(2) == false) return;
            var4_4.f.a(2);
        }
        if (var4_4.f.b(var1_1.g) == false) return;
        var15_9 = false;
        var18_10 = false;
        var19_11 = false;
        var13_12 = var4_4.f.c(var1_1.g);
        var16_13 = var19_11;
        var14_14 = var18_10;
        if (!var1_1.f) {
            if (var4_4.f.b(1) == false) return;
            var17_15 = var4_4.f.a();
            var16_13 = var19_11;
            var14_14 = var18_10;
            var15_9 = var17_15;
            if (var17_15) {
                if (var4_4.f.b(1) == false) return;
                var16_13 = var4_4.f.a();
                var14_14 = true;
                var15_9 = var17_15;
            }
        }
        var17_15 = var4_4.i == 5;
        var8_16 = 0;
        if (var17_15) {
            if (var4_4.f.b() == false) return;
            var8_16 = var4_4.f.d();
        }
        var7_17 = 0;
        var9_18 = 0;
        if (var1_1.h != 0) ** GOTO lbl78
        if (var4_4.f.b(var1_1.i) == false) return;
        var6_19 = var4_4.f.c(var1_1.i);
        var3_3 = var9_18;
        var2_2 = var6_19;
        if (!var5_8.c) ** GOTO lbl-1000
        var3_3 = var9_18;
        var2_2 = var6_19;
        if (var15_9) ** GOTO lbl-1000
        if (var4_4.f.b() == false) return;
        var2_2 = var4_4.f.c();
        var9_18 = 0;
        var3_3 = 0;
        var7_17 = var6_19;
        var6_19 = var2_2;
        var2_2 = var9_18;
        ** GOTO lbl101
lbl78: // 1 sources:
        var3_3 = var9_18;
        var2_2 = var7_17;
        if (var1_1.h != 1) ** GOTO lbl-1000
        var3_3 = var9_18;
        var2_2 = var7_17;
        if (var1_1.j) ** GOTO lbl-1000
        if (var4_4.f.b() == false) return;
        var3_3 = var6_19 = var4_4.f.c();
        var2_2 = var7_17;
        if (!var5_8.c) ** GOTO lbl-1000
        var3_3 = var6_19;
        var2_2 = var7_17;
        if (!var15_9) {
            if (var4_4.f.b() == false) return;
            var2_2 = var4_4.f.c();
            var3_3 = var6_19;
            var6_19 = 0;
            var7_17 = 0;
        } else lbl-1000: // 6 sources:
        {
            var9_18 = 0;
            var6_19 = 0;
            var7_17 = var2_2;
            var2_2 = var9_18;
        }
lbl101: // 3 sources:
        var5_8 = var4_4.n;
        var5_8.c = var1_1;
        var5_8.d = var10_5;
        var5_8.e = var11_6;
        var5_8.f = var13_12;
        var5_8.g = var12_7;
        var5_8.h = var15_9;
        var5_8.i = var14_14;
        var5_8.j = var16_13;
        var5_8.k = var17_15;
        var5_8.l = var8_16;
        var5_8.m = var7_17;
        var5_8.n = var6_19;
        var5_8.o = var3_3;
        var5_8.p = var2_2;
        var5_8.a = true;
        var5_8.b = true;
        var4_4.k = false;
    }

    @Override
    public final void a() {
        g.a(this.g);
        this.c.a();
        this.d.a();
        this.e.a();
        this.j.a();
        this.f = 0;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.l = l2;
    }

    @Override
    public final void a(com.google.android.exoplayer2.c.h h2, t.c c2) {
        this.h = h2.a(c2.a());
        this.j = new a(this.h, this.a, this.b);
        this.i = new q(h2.a(c2.a()));
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void a(i var1_1) {
        block17 : {
            block18 : {
                block16 : {
                    block15 : {
                        block14 : {
                            var5_2 = var1_1.b;
                            var6_3 = var1_1.c;
                            var2_4 = var1_1.a;
                            this.f += (long)var1_1.b();
                            this.h.a((i)var1_1, var1_1.b());
                            block0 : do {
                                if ((var7_8 = g.a(var2_4, var5_2, var6_3, this.g)) == var6_3) {
                                    this.a(var2_4, var5_2, var6_3);
                                    return;
                                }
                                var8_9 = g.b(var2_4, var7_8);
                                var10_11 = var7_8 - var5_2;
                                if (var10_11 > 0) {
                                    this.a(var2_4, var5_2, var7_8);
                                }
                                var9_10 = var6_3 - var7_8;
                                var12_13 = this.f - (long)var9_10;
                                if (var10_11 >= 0) break;
                                var5_2 = - var10_11;
lbl18: // 2 sources:
                                do {
                                    var14_14 = this.l;
                                    if (!this.k || this.j.c) {
                                        this.c.b(var5_2);
                                        this.d.b(var5_2);
                                        if (this.k) break block14;
                                        if (this.c.a && this.d.a) {
                                            var1_1 = new ArrayList<byte[]>();
                                            var1_1.add((byte[])Arrays.copyOf(this.c.b, this.c.c));
                                            var1_1.add(Arrays.copyOf(this.d.b, this.d.c));
                                            var3_6 = g.a(this.c.b, 3, this.c.c);
                                            var4_7 = g.d(this.d.b, this.d.c);
                                            this.h.a(Format.a("video/avc", var3_6.b, var3_6.c, var1_1, var3_6.d));
                                            this.k = true;
                                            this.j.a((g.b)var3_6);
                                            this.j.a((g.a)var4_7);
                                            this.c.a();
                                            this.d.a();
                                        }
                                    }
lbl36: // 8 sources:
                                    do {
                                        if (this.e.b(var5_2)) {
                                            var5_2 = g.a(this.e.b, this.e.c);
                                            this.m.a(this.e.b, var5_2);
                                            this.m.c(4);
                                            this.i.a(var14_14, this.m);
                                        }
                                        var1_1 = this.j;
                                        if (var1_1.i == 9) ** GOTO lbl51
                                        if (!var1_1.c) ** GOTO lbl62
                                        var3_6 = var1_1.n;
                                        var4_7 = var1_1.m;
                                        if (!var3_6.a || var4_7.a && var3_6.f == var4_7.f && var3_6.g == var4_7.g && var3_6.h == var4_7.h && (!var3_6.i || !var4_7.i || var3_6.j == var4_7.j) && (var3_6.d == var4_7.d || var3_6.d != 0 && var4_7.d != 0) && (var3_6.c.h != 0 || var4_7.c.h != 0 || var3_6.m == var4_7.m && var3_6.n == var4_7.n) && (var3_6.c.h != 1 || var4_7.c.h != 1 || var3_6.o == var4_7.o && var3_6.p == var4_7.p) && var3_6.k == var4_7.k && (!var3_6.k || !var4_7.k || var3_6.l == var4_7.l)) break block15;
                                        var5_2 = 1;
lbl49: // 2 sources:
                                        do {
                                            if (var5_2 == 0) ** GOTO lbl62
lbl51: // 2 sources:
                                            if (!var1_1.o) ** GOTO lbl58
                                            var10_11 = (int)(var12_13 - var1_1.j);
                                            if (!var1_1.r) break block16;
                                            var5_2 = 1;
lbl55: // 2 sources:
                                            do {
                                                var11_12 = (int)(var1_1.j - var1_1.p);
                                                var1_1.a.a(var1_1.q, var5_2, var11_12, var9_10 + var10_11, null);
lbl58: // 2 sources:
                                                var1_1.p = var1_1.j;
                                                var1_1.q = var1_1.l;
                                                var1_1.r = false;
                                                var1_1.o = true;
lbl62: // 3 sources:
                                                var16_5 = var1_1.r;
                                                if (var1_1.i == 5) ** GOTO lbl-1000
                                                if (!var1_1.b || var1_1.i != 1) break block17;
                                                var3_6 = var1_1.n;
                                                if (!var3_6.b || var3_6.e != 7 && var3_6.e != 2) break block18;
                                                var5_2 = 1;
lbl68: // 2 sources:
                                                while (var5_2 != 0) lbl-1000: // 2 sources:
                                                {
                                                    var5_2 = 1;
lbl70: // 2 sources:
                                                    do {
                                                        var1_1.r = var5_2 | var16_5;
                                                        var14_14 = this.l;
                                                        if (!this.k || this.j.c) {
                                                            this.c.a(var8_9);
                                                            this.d.a(var8_9);
                                                        }
                                                        this.e.a(var8_9);
                                                        var1_1 = this.j;
                                                        var1_1.i = var8_9;
                                                        var1_1.l = var14_14;
                                                        var1_1.j = var12_13;
                                                        if (var1_1.b && var1_1.i == 1 || var1_1.c && (var1_1.i == 5 || var1_1.i == 1 || var1_1.i == 2)) {
                                                            var3_6 = var1_1.m;
                                                            var1_1.m = var1_1.n;
                                                            var1_1.n = var3_6;
                                                            var1_1.n.a();
                                                            var1_1.h = 0;
                                                            var1_1.k = true;
                                                        }
                                                        var5_2 = var7_8 + 3;
                                                        continue block0;
                                                        break;
                                                    } while (true);
                                                    continue block0;
                                                }
                                                break block17;
                                                break;
                                            } while (true);
                                            break;
                                        } while (true);
                                        break;
                                    } while (true);
                                    break;
                                } while (true);
                                break;
                            } while (true);
                            var5_2 = 0;
                            ** while (true)
                        }
                        if (!this.c.a) ** GOTO lbl100
                        var1_1 = g.a(this.c.b, 3, this.c.c);
                        this.j.a((g.b)var1_1);
                        this.c.a();
                        ** GOTO lbl36
lbl100: // 1 sources:
                        if (!this.d.a) ** GOTO lbl36
                        var1_1 = g.d(this.d.b, this.d.c);
                        this.j.a((g.a)var1_1);
                        this.d.a();
                        ** while (true)
                    }
                    var5_2 = 0;
                    ** while (true)
                }
                var5_2 = 0;
                ** while (true)
            }
            var5_2 = 0;
            ** GOTO lbl68
        }
        var5_2 = 0;
        ** while (true)
    }

    @Override
    public final void b() {
    }

    static final class com.google.android.exoplayer2.c.f.h$a {
        final n a;
        final boolean b;
        final boolean c;
        final SparseArray<g.b> d;
        final SparseArray<g.a> e;
        final j f;
        byte[] g;
        int h;
        int i;
        long j;
        boolean k;
        long l;
        a m;
        a n;
        boolean o;
        long p;
        long q;
        boolean r;

        public com.google.android.exoplayer2.c.f.h$a(n n2, boolean bl2, boolean bl3) {
            this.a = n2;
            this.b = bl2;
            this.c = bl3;
            this.d = new SparseArray();
            this.e = new SparseArray();
            this.m = new a(0);
            this.n = new a(0);
            this.g = new byte[128];
            this.f = new j(this.g, 0, 0);
            this.a();
        }

        public final void a() {
            this.k = false;
            this.o = false;
            this.n.a();
        }

        public final void a(g.a a2) {
            this.e.append(a2.a, (Object)a2);
        }

        public final void a(g.b b2) {
            this.d.append(b2.a, (Object)b2);
        }

        static final class a {
            boolean a;
            boolean b;
            g.b c;
            int d;
            int e;
            int f;
            int g;
            boolean h;
            boolean i;
            boolean j;
            boolean k;
            int l;
            int m;
            int n;
            int o;
            int p;

            private a() {
            }

            /* synthetic */ a(byte by2) {
                this();
            }

            public final void a() {
                this.b = false;
                this.a = false;
            }
        }

    }

}

