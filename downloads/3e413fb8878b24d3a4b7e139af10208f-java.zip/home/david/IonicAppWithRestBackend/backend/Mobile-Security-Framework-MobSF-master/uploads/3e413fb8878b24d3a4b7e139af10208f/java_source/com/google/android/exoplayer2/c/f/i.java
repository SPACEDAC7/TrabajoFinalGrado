/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.google.android.exoplayer2.c.f;

import android.util.Log;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.f.f;
import com.google.android.exoplayer2.c.f.l;
import com.google.android.exoplayer2.c.f.q;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.g;
import com.google.android.exoplayer2.i.j;
import java.util.Collections;

final class i
implements f {
    private n a;
    private a b;
    private q c;
    private boolean d;
    private final boolean[] e = new boolean[3];
    private final l f = new l(32);
    private final l g = new l(33);
    private final l h = new l(34);
    private final l i = new l(39);
    private final l j = new l(40);
    private long k;
    private long l;
    private final com.google.android.exoplayer2.i.i m = new com.google.android.exoplayer2.i.i();

    /*
     * Enabled aggressive block sorting
     */
    private void a(byte[] arrby, int n2, int n3) {
        if (this.d) {
            a a2 = this.b;
            if (a2.e) {
                int n4 = n2 + 2 - a2.c;
                if (n4 < n3) {
                    boolean bl2 = (arrby[n4] & 128) != 0;
                    a2.f = bl2;
                    a2.e = false;
                } else {
                    a2.c += n3 - n2;
                }
            }
        } else {
            this.f.a(arrby, n2, n3);
            this.g.a(arrby, n2, n3);
            this.h.a(arrby, n2, n3);
        }
        this.i.a(arrby, n2, n3);
        this.j.a(arrby, n2, n3);
    }

    @Override
    public final void a() {
        g.a(this.e);
        this.f.a();
        this.g.a();
        this.h.a();
        this.i.a();
        this.j.a();
        a a2 = this.b;
        a2.e = false;
        a2.f = false;
        a2.g = false;
        a2.h = false;
        a2.i = false;
        this.k = 0;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.l = l2;
    }

    @Override
    public final void a(h h2, t.c c2) {
        this.a = h2.a(c2.a());
        this.b = new a(this.a);
        this.c = new q(h2.a(c2.a()));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(com.google.android.exoplayer2.i.i var1_1) {
        block48 : {
            block0 : do {
                if (var1_1.b() <= 0) return;
                var10_10 = var1_1.b;
                var17_16 = var1_1.c;
                var4_4 = var1_1.a;
                this.k += (long)var1_1.b();
                this.a.a(var1_1, var1_1.b());
                block1 : do {
                    if (var10_10 >= var17_16) continue block0;
                    var18_19 = g.a(var4_4, var10_10, var17_16, this.e);
                    if (var18_19 == var17_16) {
                        this.a(var4_4, var10_10, var17_16);
                        return;
                    }
                    var19_18 = g.c(var4_4, var18_19);
                    var11_11 = var18_19 - var10_10;
                    if (var11_11 > 0) {
                        this.a(var4_4, var10_10, var18_19);
                    }
                    var20_21 = var17_16 - var18_19;
                    var24_24 = this.k - (long)var20_21;
                    var12_12 = var11_11 < 0 ? - var11_11 : 0;
                    var26_25 = this.l;
                    if (!this.d) ** GOTO lbl36
                    var5_5 = this.b;
                    if (!var5_5.i || !var5_5.f) ** GOTO lbl28
                    var5_5.l = var5_5.b;
                    var5_5.i = false;
                    ** GOTO lbl102
lbl28: // 1 sources:
                    if (!var5_5.g && !var5_5.f) ** GOTO lbl102
                    if (var5_5.h) {
                        var5_5.a((int)(var24_24 - var5_5.a) + var20_21);
                    }
                    var5_5.j = var5_5.a;
                    var5_5.k = var5_5.d;
                    var5_5.h = true;
                    var5_5.l = var5_5.b;
                    ** GOTO lbl102
lbl36: // 1 sources:
                    this.f.b(var12_12);
                    this.g.b(var12_12);
                    this.h.b(var12_12);
                    if (this.f.a && this.g.a && this.h.a) {
                        var5_5 = this.a;
                        var7_7 = this.f;
                        var8_8 = this.g;
                        var9_9 = this.h;
                        var6_6 = new byte[var7_7.c + var8_8.c + var9_9.c];
                        System.arraycopy(var7_7.b, 0, var6_6, 0, var7_7.c);
                        System.arraycopy(var8_8.b, 0, var6_6, var7_7.c, var8_8.c);
                        System.arraycopy(var9_9.b, 0, var6_6, var7_7.c + var8_8.c, var9_9.c);
                        var7_7 = new j(var8_8.b, 0, var8_8.c);
                        var7_7.a(44);
                        var14_14 = var7_7.c(3);
                        var7_7.a(1);
                        var7_7.a(88);
                        var7_7.a(8);
                        var10_10 = 0;
                        for (var13_13 = 0; var13_13 < var14_14; ++var13_13) {
                            var11_11 = var10_10;
                            if (var7_7.a()) {
                                var11_11 = var10_10 + 89;
                            }
                            var10_10 = var11_11;
                            if (!var7_7.a()) continue;
                            var10_10 = var11_11 + 8;
                        }
                        var7_7.a(var10_10);
                        if (var14_14 > 0) {
                            var7_7.a((8 - var14_14) * 2);
                        }
                        var7_7.d();
                        var11_11 = var7_7.d();
                        if (var11_11 == 3) {
                            var7_7.a(1);
                        }
                        var13_13 = var7_7.d();
                        var15_15 = var7_7.d();
                        if (var7_7.a()) {
                            var16_17 = var7_7.d();
                            var21_20 = var7_7.d();
                            var22_23 = var7_7.d();
                            var23_22 = var7_7.d();
                            var10_10 = var11_11 == 1 || var11_11 == 2 ? 2 : 1;
                            var11_11 = var11_11 == 1 ? 2 : 1;
                            var11_11 = var15_15 - var11_11 * (var22_23 + var23_22);
                            var13_13 -= var10_10 * (var16_17 + var21_20);
                        } else {
                            var11_11 = var15_15;
                        }
                        var7_7.d();
                        var7_7.d();
                        var21_20 = var7_7.d();
                        var10_10 = var7_7.a() != false ? 0 : var14_14;
                        while (var10_10 <= var14_14) {
                            var7_7.d();
                            var7_7.d();
                            var7_7.d();
                            ++var10_10;
                        }
                        var7_7.d();
                        var7_7.d();
                        var7_7.d();
                        var7_7.d();
                        var7_7.d();
                        var7_7.d();
                        if (var7_7.a() && var7_7.a()) {
                            break block0;
                        }
                        break block48;
                    }
lbl102: // 6 sources:
                    do {
                        if (this.i.b(var12_12)) {
                            var10_10 = g.a(this.i.b, this.i.c);
                            this.m.a(this.i.b, var10_10);
                            this.m.d(5);
                            this.c.a(var26_25, this.m);
                        }
                        if (this.j.b(var12_12)) {
                            var10_10 = g.a(this.j.b, this.j.c);
                            this.m.a(this.j.b, var10_10);
                            this.m.d(5);
                            this.c.a(var26_25, this.m);
                        }
                        var26_25 = this.l;
                        if (this.d) {
                            var5_5 = this.b;
                            var5_5.f = false;
                            var5_5.g = false;
                            var5_5.d = var26_25;
                            var5_5.c = 0;
                            var5_5.a = var24_24;
                            if (var19_18 >= 32) {
                                if (!var5_5.i && var5_5.h) {
                                    var5_5.a(var20_21);
                                    var5_5.h = false;
                                }
                                if (var19_18 <= 34) {
                                    var28_26 = var5_5.i == false;
                                    var5_5.g = var28_26;
                                    var5_5.i = true;
                                }
                            }
                            var28_26 = var19_18 >= 16 && var19_18 <= 21;
                            var5_5.b = var28_26;
                            var28_26 = var5_5.b != false || var19_18 <= 9;
                            var5_5.e = var28_26;
                        } else {
                            this.f.a(var19_18);
                            this.g.a(var19_18);
                            this.h.a(var19_18);
                        }
                        this.i.a(var19_18);
                        this.j.a(var19_18);
                        var10_10 = var18_19 + 3;
                        continue block1;
                        break;
                    } while (true);
                    break;
                } while (true);
                break;
            } while (true);
            for (var10_10 = 0; var10_10 < 4; ++var10_10) {
                var14_14 = 0;
                while (var14_14 < 6) {
                    if (!var7_7.a()) {
                        var7_7.d();
                    } else {
                        var16_17 = Math.min(64, 1 << (var10_10 << 1) + 4);
                        if (var10_10 > 1) {
                            var7_7.c();
                        }
                        for (var15_15 = 0; var15_15 < var16_17; ++var15_15) {
                            var7_7.c();
                        }
                    }
                    var15_15 = var10_10 == 3 ? 3 : 1;
                    var14_14 = var15_15 + var14_14;
                }
            }
        }
        var7_7.a(2);
        if (var7_7.a()) {
            var7_7.a(8);
            var7_7.d();
            var7_7.d();
            var7_7.a(1);
        }
        var22_23 = var7_7.d();
        var15_15 = 0;
        var28_26 = false;
        for (var10_10 = 0; var10_10 < var22_23; ++var10_10) {
            if (var10_10 != 0) {
                var28_26 = var7_7.a();
            }
            if (var28_26) {
                var7_7.a(1);
                var7_7.d();
                var16_17 = 0;
                do {
                    var14_14 = var15_15;
                    if (var16_17 <= var15_15) {
                        if (var7_7.a()) {
                            var7_7.a(1);
                        }
                        ++var16_17;
                        continue;
                    }
                    break;
                    break;
                } while (true);
            } else {
                var15_15 = var7_7.d();
                var23_22 = var7_7.d();
                var16_17 = var15_15 + var23_22;
                for (var14_14 = 0; var14_14 < var15_15; ++var14_14) {
                    var7_7.d();
                    var7_7.a(1);
                }
                var15_15 = 0;
                do {
                    var14_14 = var16_17;
                    if (var15_15 >= var23_22) break;
                    var7_7.d();
                    var7_7.a(1);
                    ++var15_15;
                } while (true);
            }
            var15_15 = var14_14;
        }
        if (var7_7.a()) {
            for (var10_10 = 0; var10_10 < var7_7.d(); ++var10_10) {
                var7_7.a(var21_20 + 4 + 1);
            }
        }
        var7_7.a(2);
        var2_2 = var3_3 = 1.0f;
        if (var7_7.a()) {
            var2_2 = var3_3;
            if (var7_7.a()) {
                var10_10 = var7_7.c(8);
                if (var10_10 == 255) {
                    var10_10 = var7_7.c(16);
                    var14_14 = var7_7.c(16);
                    var2_2 = var3_3;
                    if (var10_10 != 0) {
                        var2_2 = var3_3;
                        if (var14_14 != 0) {
                            var2_2 = (float)var10_10 / (float)var14_14;
                        }
                    }
                } else if (var10_10 < g.b.length) {
                    var2_2 = g.b[var10_10];
                } else {
                    Log.w((String)"H265Reader", (String)("Unexpected aspect_ratio_idc value: " + var10_10));
                    var2_2 = var3_3;
                }
            }
        }
        var5_5.a(Format.a("video/hevc", var13_13, var11_11, Collections.singletonList(var6_6), var2_2));
        this.d = true;
        ** while (true)
    }

    @Override
    public final void b() {
    }

    static final class a {
        long a;
        boolean b;
        int c;
        long d;
        boolean e;
        boolean f;
        boolean g;
        boolean h;
        boolean i;
        long j;
        long k;
        boolean l;
        private final n m;

        public a(n n2) {
            this.m = n2;
        }

        /*
         * Enabled aggressive block sorting
         */
        final void a(int n2) {
            int n3 = this.l ? 1 : 0;
            int n4 = (int)(this.a - this.j);
            this.m.a(this.k, n3, n4, n2, null);
        }
    }

}

