/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.google.android.exoplayer2.c.f;

import android.util.Log;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.f.f;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.i;

final class j
implements f {
    private final i a = new i(10);
    private n b;
    private boolean c;
    private long d;
    private int e;
    private int f;

    @Override
    public final void a() {
        this.c = false;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        if (!bl2) {
            return;
        }
        this.c = true;
        this.d = l2;
        this.e = 0;
        this.f = 0;
    }

    @Override
    public final void a(h h2, t.c c2) {
        this.b = h2.a(c2.a());
        this.b.a(Format.a(null, "application/id3", null));
    }

    @Override
    public final void a(i i2) {
        if (!this.c) {
            return;
        }
        int n2 = i2.b();
        if (this.f < 10) {
            int n3 = Math.min(n2, 10 - this.f);
            System.arraycopy(i2.a, i2.b, this.a.a, this.f, n3);
            if (n3 + this.f == 10) {
                this.a.c(0);
                if (73 != this.a.e() || 68 != this.a.e() || 51 != this.a.e()) {
                    Log.w((String)"Id3Reader", (String)"Discarding invalid ID3 tag");
                    this.c = false;
                    return;
                }
                this.a.d(3);
                this.e = this.a.n() + 10;
            }
        }
        n2 = Math.min(n2, this.e - this.f);
        this.b.a(i2, n2);
        this.f = n2 + this.f;
    }

    @Override
    public final void b() {
        if (!this.c || this.e == 0 || this.f != this.e) {
            return;
        }
        this.b.a(this.d, 1, this.e, 0, null);
        this.c = false;
    }
}

