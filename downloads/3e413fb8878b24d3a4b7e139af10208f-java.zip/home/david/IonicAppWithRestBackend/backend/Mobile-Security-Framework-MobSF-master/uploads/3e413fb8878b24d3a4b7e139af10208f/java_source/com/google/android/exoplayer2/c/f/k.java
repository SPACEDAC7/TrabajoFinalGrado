/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.f.f;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.i;

final class k
implements f {
    private final i a = new i(4);
    private final com.google.android.exoplayer2.c.k b;
    private final String c;
    private n d;
    private int e = 0;
    private int f;
    private boolean g;
    private boolean h;
    private long i;
    private int j;
    private long k;

    public k() {
        this(null);
    }

    public k(String string) {
        this.a.a[0] = -1;
        this.b = new com.google.android.exoplayer2.c.k();
        this.c = string;
    }

    @Override
    public final void a() {
        this.e = 0;
        this.f = 0;
        this.h = false;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.k = l2;
    }

    @Override
    public final void a(h h2, t.c c2) {
        this.d = h2.a(c2.a());
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(i i2) {
        block5 : while (i2.b() > 0) {
            int n2;
            switch (this.e) {
                Object object;
                default: {
                    continue block5;
                }
                case 0: {
                    object = i2.a;
                    int n3 = i2.c;
                    for (n2 = i2.b; n2 < n3; ++n2) {
                        boolean bl2 = (object[n2] & 255) == 255;
                        boolean bl3 = this.h && (object[n2] & 224) == 224;
                        this.h = bl2;
                        if (!bl3) continue;
                        i2.c(n2 + 1);
                        this.h = false;
                        this.a.a[1] = object[n2];
                        this.f = 2;
                        this.e = 1;
                        continue block5;
                    }
                    i2.c(n3);
                    continue block5;
                }
                case 1: {
                    n2 = Math.min(i2.b(), 4 - this.f);
                    i2.a(this.a.a, this.f, n2);
                    this.f = n2 + this.f;
                    if (this.f < 4) continue block5;
                    this.a.c(0);
                    if (!com.google.android.exoplayer2.c.k.a(this.a.k(), this.b)) {
                        this.f = 0;
                        this.e = 1;
                        continue block5;
                    }
                    this.j = this.b.c;
                    if (!this.g) {
                        this.i = 1000000 * (long)this.b.g / (long)this.b.d;
                        object = Format.a(null, this.b.b, -1, 4096, this.b.e, this.b.d, null, null, this.c);
                        this.d.a((Format)object);
                        this.g = true;
                    }
                    this.a.c(0);
                    this.d.a(this.a, 4);
                    this.e = 2;
                    continue block5;
                }
                case 2: 
            }
            n2 = Math.min(i2.b(), this.j - this.f);
            this.d.a(i2, n2);
            this.f = n2 + this.f;
            if (this.f < this.j) continue;
            this.d.a(this.k, 1, this.j, 0, null);
            this.k += this.i;
            this.f = 0;
            this.e = 0;
        }
        return;
    }

    @Override
    public final void b() {
    }
}

