/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import a.a.a.a.d;
import java.util.Arrays;

final class l {
    boolean a;
    public byte[] b;
    public int c;
    private final int d;
    private boolean e;

    public l(int n2) {
        this.d = n2;
        this.b = new byte[131];
        this.b[2] = 1;
    }

    public final void a() {
        this.e = false;
        this.a = false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2) {
        boolean bl2 = true;
        boolean bl3 = !this.e;
        d.b(bl3);
        bl3 = n2 == this.d ? bl2 : false;
        this.e = bl3;
        if (this.e) {
            this.c = 3;
            this.a = false;
        }
    }

    public final void a(byte[] arrby, int n2, int n3) {
        if (!this.e) {
            return;
        }
        if (this.b.length < this.c + (n3 -= n2)) {
            this.b = Arrays.copyOf(this.b, this.c + n3 << 1);
        }
        System.arraycopy(arrby, n2, this.b, this.c, n3);
        this.c = n3 + this.c;
    }

    public final boolean b(int n2) {
        if (!this.e) {
            return false;
        }
        this.c -= n2;
        this.e = false;
        this.a = true;
        return true;
    }
}

