/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 */
package com.google.android.exoplayer2.c.f;

import android.util.SparseArray;
import com.google.android.exoplayer2.c.f.b;
import com.google.android.exoplayer2.c.f.f;
import com.google.android.exoplayer2.c.f.g;
import com.google.android.exoplayer2.c.f.k;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.i;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;

public final class n
implements com.google.android.exoplayer2.c.f {
    public static final i a = new i(){

        @Override
        public final com.google.android.exoplayer2.c.f[] a() {
            return new com.google.android.exoplayer2.c.f[]{new n()};
        }
    };
    private final com.google.android.exoplayer2.i.n b;
    private final SparseArray<a> c;
    private final com.google.android.exoplayer2.i.i d;
    private boolean e;
    private boolean f;
    private boolean g;
    private h h;

    public n() {
        this(new com.google.android.exoplayer2.i.n(0));
    }

    private n(com.google.android.exoplayer2.i.n n2) {
        this.b = n2;
        this.d = new com.google.android.exoplayer2.i.i(4096);
        this.c = new SparseArray();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(com.google.android.exoplayer2.c.g var1_1, l var2_2) {
        if (!var1_1.b(this.d.a, 0, 4, true)) {
            return -1;
        }
        this.d.c(0);
        var5_3 = this.d.k();
        if (var5_3 == 441) {
            return -1;
        }
        if (var5_3 == 442) {
            var1_1.c(this.d.a, 0, 10);
            this.d.c(9);
            var1_1.b((this.d.e() & 7) + 14);
            return 0;
        }
        if (var5_3 == 443) {
            var1_1.c(this.d.a, 0, 2);
            this.d.c(0);
            var1_1.b(this.d.f() + 6);
            return 0;
        }
        if ((var5_3 & -256) >> 8 != 1) {
            var1_1.b(1);
            return 0;
        }
        var2_2 = var4_4 = (a)this.c.get(var5_3 &= 255);
        if (this.e) ** GOTO lbl51
        var3_5 = var4_4;
        if (var4_4 == null) {
            var3_5 = null;
            if (!this.f && var5_3 == 189) {
                var2_2 = new b();
                this.f = true;
            } else if (!this.f && (var5_3 & 224) == 192) {
                var2_2 = new k();
                this.f = true;
            } else {
                var2_2 = var3_5;
                if (!this.g) {
                    var2_2 = var3_5;
                    if ((var5_3 & 240) == 224) {
                        var2_2 = new g();
                        this.g = true;
                    }
                }
            }
            var3_5 = var4_4;
            if (var2_2 != null) {
                var3_5 = new t.c(var5_3, 256);
                var2_2.a(this.h, (t.c)var3_5);
                var3_5 = new a((f)var2_2, this.b);
                this.c.put(var5_3, var3_5);
            }
        }
        if (this.f && this.g) ** GOTO lbl-1000
        var2_2 = var3_5;
        if (var1_1.c() > 0x100000) lbl-1000: // 2 sources:
        {
            this.e = true;
            this.h.b();
            var2_2 = var3_5;
        }
lbl51: // 4 sources:
        var1_1.c(this.d.a, 0, 2);
        this.d.c(0);
        var5_3 = this.d.f() + 6;
        if (var2_2 == null) {
            var1_1.b(var5_3);
            return 0;
        }
        this.d.a(var5_3);
        var1_1.b(this.d.a, 0, var5_3);
        this.d.c(6);
        var1_1 = this.d;
        var1_1.a(var2_2.c.a, 0, 3);
        var2_2.c.a(0);
        var2_2.c.b(8);
        var2_2.d = var2_2.c.a();
        var2_2.e = var2_2.c.a();
        var2_2.c.b(6);
        var2_2.g = var2_2.c.c(8);
        var1_1.a(var2_2.c.a, 0, var2_2.g);
        var2_2.c.a(0);
        var2_2.h = 0;
        if (var2_2.d) {
            var2_2.c.b(4);
            var6_6 = var2_2.c.c(3);
            var2_2.c.b(1);
            var8_7 = var2_2.c.c(15) << 15;
            var2_2.c.b(1);
            var10_8 = var2_2.c.c(15);
            var2_2.c.b(1);
            if (!var2_2.f && var2_2.e) {
                var2_2.c.b(4);
                var12_9 = var2_2.c.c(3);
                var2_2.c.b(1);
                var14_10 = var2_2.c.c(15) << 15;
                var2_2.c.b(1);
                var16_11 = var2_2.c.c(15);
                var2_2.c.b(1);
                var2_2.b.a(var12_9 << 30 | var14_10 | var16_11);
                var2_2.f = true;
            }
            var2_2.h = var2_2.b.a(var6_6 << 30 | var8_7 | var10_8);
        }
        var2_2.a.a(var2_2.h, true);
        var2_2.a.a((com.google.android.exoplayer2.i.i)var1_1);
        var2_2.a.b();
        this.d.b(this.d.d());
        return 0;
    }

    @Override
    public final void a(long l2, long l3) {
        this.b.b = -9223372036854775807L;
        for (int i2 = 0; i2 < this.c.size(); ++i2) {
            a a2 = (a)this.c.valueAt(i2);
            a2.f = false;
            a2.a.a();
        }
    }

    @Override
    public final void a(h h2) {
        this.h = h2;
        h2.a(new m.a(-9223372036854775807L));
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final boolean a(com.google.android.exoplayer2.c.g g2) {
        byte[] arrby = new byte[14];
        g2.c(arrby, 0, 14);
        if (442 != ((arrby[0] & 255) << 24 | (arrby[1] & 255) << 16 | (arrby[2] & 255) << 8 | arrby[3] & 255)) {
            return false;
        }
        if ((arrby[4] & 196) != 68) return false;
        if ((arrby[6] & 4) != 4) return false;
        if ((arrby[8] & 4) != 4) return false;
        if ((arrby[9] & 1) != 1) return false;
        if ((arrby[12] & 3) != 3) return false;
        g2.c(arrby[13] & 7);
        g2.c(arrby, 0, 3);
        byte by2 = arrby[0];
        byte by3 = arrby[1];
        if (1 != (arrby[2] & 255 | ((by2 & 255) << 16 | (by3 & 255) << 8))) return false;
        return true;
    }

    static final class a {
        final f a;
        final com.google.android.exoplayer2.i.n b;
        final com.google.android.exoplayer2.i.h c;
        boolean d;
        boolean e;
        boolean f;
        int g;
        long h;

        public a(f f2, com.google.android.exoplayer2.i.n n2) {
            this.a = f2;
            this.b = n2;
            this.c = new com.google.android.exoplayer2.i.h(new byte[64]);
        }
    }

}

