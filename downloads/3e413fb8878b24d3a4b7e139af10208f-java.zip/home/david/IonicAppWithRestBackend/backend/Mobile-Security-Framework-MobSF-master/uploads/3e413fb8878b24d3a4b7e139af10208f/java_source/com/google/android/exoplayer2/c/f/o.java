/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.n;

public interface o {
    public void a(i var1);

    public void a(n var1, h var2, t.c var3);
}

