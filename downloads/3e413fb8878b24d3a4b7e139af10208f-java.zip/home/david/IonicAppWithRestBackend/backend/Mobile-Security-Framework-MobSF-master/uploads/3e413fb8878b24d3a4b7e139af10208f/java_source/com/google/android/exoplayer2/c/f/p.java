/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import com.google.android.exoplayer2.c.f.o;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.n;

public final class p
implements t {
    private final o a;
    private final i b;
    private int c;
    private int d;
    private boolean e;
    private boolean f;

    public p(o o2) {
        this.a = o2;
        this.b = new i(32);
    }

    @Override
    public final void a() {
        this.f = true;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(i i2, boolean bl2) {
        int n2 = bl2 ? i2.e() + i2.b : -1;
        if (this.f) {
            if (!bl2) {
                return;
            }
            this.f = false;
            i2.c(n2);
            this.d = 0;
        }
        while (i2.b() > 0) {
            if (this.d < 3) {
                if (this.d == 0) {
                    n2 = i2.e();
                    i2.c(i2.b - 1);
                    if (n2 == 255) {
                        this.f = true;
                        return;
                    }
                }
                n2 = Math.min(i2.b(), 3 - this.d);
                i2.a(this.b.a, this.d, n2);
                this.d = n2 + this.d;
                if (this.d != 3) continue;
                this.b.a(3);
                this.b.d(1);
                n2 = this.b.e();
                int n3 = this.b.e();
                bl2 = (n2 & 128) != 0;
                this.e = bl2;
                this.c = ((n2 & 15) << 8 | n3) + 3;
                if (this.b.d() >= this.c) continue;
                byte[] arrby = this.b.a;
                this.b.a(Math.min(4098, Math.max(this.c, arrby.length << 1)));
                System.arraycopy(arrby, 0, this.b.a, 0, 3);
                continue;
            }
            n2 = Math.min(i2.b(), this.c - this.d);
            i2.a(this.b.a, this.d, n2);
            this.d = n2 + this.d;
            if (this.d != this.c) continue;
            if (this.e) {
                if (com.google.android.exoplayer2.i.o.a(this.b.a, this.c, -1) != 0) {
                    this.f = true;
                    return;
                }
                this.b.a(this.c - 4);
            } else {
                this.b.a(this.c);
            }
            this.a.a(this.b);
            this.d = 0;
        }
    }

    @Override
    public final void a(n n2, h h2, t.c c2) {
        this.a.a(n2, h2, c2);
        this.f = true;
    }
}

