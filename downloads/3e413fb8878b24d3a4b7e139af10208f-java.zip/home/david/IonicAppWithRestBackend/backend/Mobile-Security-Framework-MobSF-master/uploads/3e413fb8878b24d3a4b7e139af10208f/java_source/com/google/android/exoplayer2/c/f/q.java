/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import a.a.a.a.d;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.i;

final class q {
    private final n a;

    public q(n n2) {
        this.a = n2;
        n2.a(Format.a(null, "application/cea-608", 0, null, null));
    }

    public final void a(long l2, i i2) {
        d.a(l2, i2, this.a);
    }
}

