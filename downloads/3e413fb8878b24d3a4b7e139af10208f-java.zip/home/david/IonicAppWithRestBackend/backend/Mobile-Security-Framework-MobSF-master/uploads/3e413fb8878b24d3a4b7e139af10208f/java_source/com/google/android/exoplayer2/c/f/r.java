/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.f.o;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i.i;

public final class r
implements o {
    private com.google.android.exoplayer2.i.n a;
    private n b;
    private boolean c;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(i object) {
        long l2 = -9223372036854775807L;
        if (!this.c) {
            if (this.a.a() == -9223372036854775807L) {
                return;
            }
            this.b.a(Format.a("application/x-scte35", this.a.a()));
            this.c = true;
        }
        int n2 = object.b();
        this.b.a((i)object, n2);
        object = this.b;
        com.google.android.exoplayer2.i.n n3 = this.a;
        if (n3.b != -9223372036854775807L) {
            l2 = n3.b;
        } else if (n3.a != Long.MAX_VALUE) {
            l2 = n3.a;
        }
        object.a(l2, 1, n2, 0, null);
    }

    @Override
    public final void a(com.google.android.exoplayer2.i.n n2, h h2, t.c c2) {
        this.a = n2;
        this.b = h2.a(c2.a());
        this.b.a(Format.a(null, "application/x-scte35", null));
    }
}

