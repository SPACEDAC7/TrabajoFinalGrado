/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 *  android.util.SparseBooleanArray
 *  android.util.SparseIntArray
 */
package com.google.android.exoplayer2.c.f;

import a.a.a.a.d;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.util.SparseIntArray;
import com.google.android.exoplayer2.c.f;
import com.google.android.exoplayer2.c.f.o;
import com.google.android.exoplayer2.c.f.p;
import com.google.android.exoplayer2.c.f.t;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.i;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.i.n;
import java.util.Arrays;

public final class s
implements f {
    public static final i a = new i(){

        @Override
        public final f[] a() {
            return new f[]{new s()};
        }
    };
    private static final long b = com.google.android.exoplayer2.i.o.e("AC-3");
    private static final long c = com.google.android.exoplayer2.i.o.e("EAC3");
    private static final long d = com.google.android.exoplayer2.i.o.e("HEVC");
    private final boolean e;
    private final n f;
    private final com.google.android.exoplayer2.i.i g;
    private final com.google.android.exoplayer2.i.h h;
    private final SparseIntArray i;
    private final t.b j;
    private final SparseArray<t> k;
    private final SparseBooleanArray l;
    private h m;
    private boolean n;
    private t o;

    public s() {
        this(new n(0));
    }

    private s(n n2) {
        this(n2, new t.b());
    }

    private s(n n2, t.b b2) {
        this.f = n2;
        this.j = d.b(b2);
        this.e = false;
        this.g = new com.google.android.exoplayer2.i.i(940);
        this.h = new com.google.android.exoplayer2.i.h(new byte[3]);
        this.l = new SparseBooleanArray();
        this.k = new SparseArray();
        this.i = new SparseIntArray();
        this.d();
    }

    private void d() {
        this.l.clear();
        this.k.clear();
        SparseArray sparseArray = new SparseArray();
        int n2 = sparseArray.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            this.k.put(sparseArray.keyAt(i2), sparseArray.valueAt(i2));
        }
        this.k.put(0, (Object)new p(new a()));
        this.o = null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(g var1_1, l var2_2) {
        var4_3 = 0;
        var2_2 = this.g.a;
        if (940 - this.g.b < 188) {
            var3_4 = this.g.b();
            if (var3_4 > 0) {
                System.arraycopy(var2_2, this.g.b, var2_2, 0, var3_4);
            }
            this.g.a(var2_2, var3_4);
        }
        while (this.g.b() < 188) {
            var3_4 = this.g.c;
            var5_5 = var1_1.a(var2_2, var3_4, 940 - var3_4);
            if (var5_5 == -1) {
                return -1;
            }
            this.g.b(var3_4 + var5_5);
        }
        var5_5 = this.g.c;
        for (var3_4 = this.g.b; var3_4 < var5_5 && var2_2[var3_4] != 71; ++var3_4) {
        }
        this.g.c(var3_4);
        var6_6 = var3_4 + 188;
        var3_4 = var4_3;
        if (var6_6 > var5_5) return var3_4;
        this.g.d(1);
        this.g.a(this.h, 3);
        if (this.h.a()) {
            this.g.c(var6_6);
            return 0;
        }
        var8_7 = this.h.a();
        this.h.b(1);
        var4_3 = this.h.c(13);
        this.h.b(2);
        var9_8 = this.h.a();
        var10_9 = this.h.a();
        var3_4 = this.h.c(4);
        if (this.e) ** GOTO lbl-1000
        var7_10 = this.i.get(var4_3, var3_4 - 1);
        this.i.put(var4_3, var3_4);
        if (var7_10 != var3_4) ** GOTO lbl42
        if (var10_9) {
            this.g.c(var6_6);
            return 0;
        }
        ** GOTO lbl-1000
lbl42: // 1 sources:
        if (var3_4 != (var7_10 + 1) % 16) {
            var3_4 = 1;
        } else lbl-1000: // 3 sources:
        {
            var3_4 = 0;
        }
        if (var9_8) {
            var7_10 = this.g.e();
            this.g.d(var7_10);
        }
        if (var10_9 && (var1_1 = (t)this.k.get(var4_3)) != null) {
            if (var3_4 != 0) {
                var1_1.a();
            }
            this.g.b(var6_6);
            var1_1.a(this.g, var8_7);
            var8_7 = this.g.b <= var6_6;
            d.b(var8_7);
            this.g.b(var5_5);
        }
        this.g.c(var6_6);
        return 0;
    }

    @Override
    public final void a(long l2, long l3) {
        this.f.b = -9223372036854775807L;
        this.g.a();
        this.i.clear();
        this.d();
    }

    @Override
    public final void a(h h2) {
        this.m = h2;
        h2.a(new m.a(-9223372036854775807L));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final boolean a(g g2) {
        boolean bl2 = false;
        byte[] arrby = this.g.a;
        g2.c(arrby, 0, 940);
        int n2 = 0;
        do {
            boolean bl3 = bl2;
            if (n2 >= 188) return bl3;
            int n3 = 0;
            do {
                if (n3 == 5) {
                    g2.b(n2);
                    return true;
                }
                if (arrby[n3 * 188 + n2] != 71) break;
                ++n3;
            } while (true);
            ++n2;
        } while (true);
    }

    final class a
    implements o {
        private final com.google.android.exoplayer2.i.h b;

        public a() {
            this.b = new com.google.android.exoplayer2.i.h(new byte[4]);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final void a(com.google.android.exoplayer2.i.i i2) {
            if (i2.e() != 0) {
                return;
            }
            i2.d(7);
            int n2 = i2.b() / 4;
            int n3 = 0;
            while (n3 < n2) {
                i2.a(this.b, 4);
                int n4 = this.b.c(16);
                this.b.b(3);
                if (n4 == 0) {
                    this.b.b(13);
                } else {
                    n4 = this.b.c(13);
                    s.this.k.put(n4, (Object)new p(new b(n4)));
                }
                ++n3;
            }
        }

        @Override
        public final void a(n n2, h h2, t.c c2) {
        }
    }

    final class b
    implements o {
        private final com.google.android.exoplayer2.i.h b;
        private final int c;

        public b(int n2) {
            this.b = new com.google.android.exoplayer2.i.h(new byte[5]);
            this.c = n2;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final void a(com.google.android.exoplayer2.i.i i2) {
            Object object;
            if (i2.e() != 2) {
                return;
            }
            i2.d(9);
            i2.a(this.b, 2);
            this.b.b(4);
            i2.d(this.b.c(12));
            if (s.this.e && s.this.o == null) {
                object = new t.a(21, null, new byte[0]);
                s.this.o = s.this.j.a(21, (t.a)object);
                s.this.o.a(s.this.f, s.this.m, new t.c(21, 8192));
            }
            int n2 = i2.b();
            do {
                Object object2;
                int n3;
                int n4;
                int n5;
                int n6;
                int n7;
                int n8;
                int n9;
                if (n2 > 0) {
                    i2.a(this.b, 5);
                    n3 = this.b.c(8);
                    this.b.b(3);
                    n5 = this.b.c(13);
                    this.b.b(4);
                    n6 = this.b.c(12);
                    n7 = i2.b;
                    n9 = n7 + n6;
                    n4 = -1;
                    object = null;
                } else {
                    if (s.this.e) {
                        if (!s.this.n) {
                            s.this.m.b();
                        }
                    } else {
                        s.this.k.remove(0);
                        s.this.k.remove(this.c);
                        s.this.m.b();
                    }
                    s.this.n = true;
                    return;
                }
                while (i2.b < n9) {
                    int n10 = i2.e();
                    int n11 = i2.e();
                    int n12 = i2.b;
                    if (n10 == 5) {
                        long l2 = i2.i();
                        if (l2 == b) {
                            n8 = 129;
                            object2 = object;
                        } else if (l2 == c) {
                            n8 = 135;
                            object2 = object;
                        } else {
                            object2 = object;
                            n8 = n4;
                            if (l2 == d) {
                                n8 = 36;
                                object2 = object;
                            }
                        }
                    } else if (n10 == 106) {
                        n8 = 129;
                        object2 = object;
                    } else if (n10 == 122) {
                        n8 = 135;
                        object2 = object;
                    } else if (n10 == 123) {
                        n8 = 138;
                        object2 = object;
                    } else {
                        object2 = object;
                        n8 = n4;
                        if (n10 == 10) {
                            object2 = new String(i2.a, i2.b, 3).trim();
                            n8 = n4;
                        }
                    }
                    i2.d(n11 + n12 - i2.b);
                    object = object2;
                    n4 = n8;
                }
                i2.c(n9);
                object = new t.a(n4, (String)object, Arrays.copyOfRange(i2.a, n7, n9));
                n8 = n3 == 6 ? object.a : n3;
                n2 -= n6 + 5;
                n4 = s.this.e ? n8 : n5;
                if (s.this.l.get(n4)) continue;
                s.this.l.put(n4, true);
                if (s.this.e && n8 == 21) {
                    object = s.this.o;
                } else {
                    object = object2 = s.this.j.a(n8, (t.a)object);
                    if (object2 != null) {
                        object2.a(s.this.f, s.this.m, new t.c(n4, 8192));
                        object = object2;
                    }
                }
                if (object == null) continue;
                s.this.k.put(n5, object);
            } while (true);
        }

        @Override
        public final void a(n n2, h h2, t.c c2) {
        }
    }

}

