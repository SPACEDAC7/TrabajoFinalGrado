/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.f;

import com.google.android.exoplayer2.c.f.d;
import com.google.android.exoplayer2.c.f.e;
import com.google.android.exoplayer2.c.f.f;
import com.google.android.exoplayer2.c.f.g;
import com.google.android.exoplayer2.c.f.h;
import com.google.android.exoplayer2.c.f.i;
import com.google.android.exoplayer2.c.f.j;
import com.google.android.exoplayer2.c.f.k;
import com.google.android.exoplayer2.c.f.m;
import com.google.android.exoplayer2.c.f.o;
import com.google.android.exoplayer2.c.f.p;
import com.google.android.exoplayer2.c.f.r;
import com.google.android.exoplayer2.i.n;

public interface t {
    public void a();

    public void a(com.google.android.exoplayer2.i.i var1, boolean var2);

    public void a(n var1, com.google.android.exoplayer2.c.h var2, c var3);

    public static final class a {
        public final int a;
        public final String b;
        public final byte[] c;

        public a(int n2, String string, byte[] arrby) {
            this.a = n2;
            this.b = string;
            this.c = arrby;
        }
    }

    public static final class b {
        final int a = 0;

        public b() {
            this(0);
        }

        private b(byte by2) {
        }

        private boolean a(int n2) {
            if ((this.a & n2) != 0) {
                return true;
            }
            return false;
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public final t a(int n2, a a2) {
            switch (n2) {
                default: {
                    return null;
                }
                case 3: 
                case 4: {
                    return new m(new k(a2.b));
                }
                case 15: {
                    if (this.a(2)) return null;
                    return new m(new d(false, a2.b));
                }
                case 129: 
                case 135: {
                    return new m(new com.google.android.exoplayer2.c.f.b(a2.b));
                }
                case 130: 
                case 138: {
                    return new m(new e(a2.b));
                }
                case 2: {
                    return new m(new g());
                }
                case 27: {
                    if (this.a(4)) return null;
                    return new m(new h(this.a(1), this.a(8)));
                }
                case 36: {
                    return new m(new i());
                }
                case 134: {
                    if (this.a(16)) return null;
                    return new p(new r());
                }
                case 21: 
            }
            return new m(new j());
        }
    }

    public static final class c {
        private final int a;
        private final int b;
        private int c;

        public c(int n2, int n3) {
            this.a = n2;
            this.b = n3;
        }

        public final int a() {
            int n2 = this.a;
            int n3 = this.b;
            int n4 = this.c;
            this.c = n4 + 1;
            return n2 + n3 * n4;
        }
    }

}

