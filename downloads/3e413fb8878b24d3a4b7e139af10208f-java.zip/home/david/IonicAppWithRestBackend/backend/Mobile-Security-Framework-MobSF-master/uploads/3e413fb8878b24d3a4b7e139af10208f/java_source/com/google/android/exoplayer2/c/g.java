/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

public interface g {
    public int a(int var1);

    public int a(byte[] var1, int var2, int var3);

    public void a();

    public boolean a(byte[] var1, int var2, int var3, boolean var4);

    public long b();

    public void b(int var1);

    public void b(byte[] var1, int var2, int var3);

    public boolean b(byte[] var1, int var2, int var3, boolean var4);

    public long c();

    public void c(int var1);

    public void c(byte[] var1, int var2, int var3);

    public long d();
}

