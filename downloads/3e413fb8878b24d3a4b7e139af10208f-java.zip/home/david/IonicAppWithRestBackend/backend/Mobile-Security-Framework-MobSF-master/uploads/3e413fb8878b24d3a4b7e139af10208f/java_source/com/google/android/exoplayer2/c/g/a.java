/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.google.android.exoplayer2.c.g;

import a.a.a.a.d;
import android.util.Log;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.f;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.c.g.b;
import com.google.android.exoplayer2.c.g.c;
import com.google.android.exoplayer2.c.h;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.c.n;
import com.google.android.exoplayer2.i;
import com.google.android.exoplayer2.i.o;

public final class a
implements f,
m {
    public static final com.google.android.exoplayer2.c.i a = new com.google.android.exoplayer2.c.i(){

        @Override
        public final f[] a() {
            return new f[]{new a()};
        }
    };
    private h b;
    private n c;
    private b d;
    private int e;
    private int f;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int a(g g2, l object) {
        long l2;
        int n2;
        int n3;
        if (this.d == null) {
            this.d = d.a(g2);
            if (this.d == null) {
                throw new i("Unsupported or unrecognized wav header.");
            }
            object = this.d;
            n2 = object.b;
            n3 = object.e;
            object = Format.a(null, "audio/raw", object.a * (n2 * n3), 32768, this.d.a, this.d.b, this.d.f, null, null, 0, null);
            this.c.a((Format)object);
            this.e = this.d.d;
        }
        object = this.d;
        n2 = object.g != 0 && object.h != 0 ? 1 : 0;
        if (n2 == 0) {
            b b2 = this.d;
            d.b(g2);
            d.b(b2);
            g2.a();
            com.google.android.exoplayer2.i.i i2 = new com.google.android.exoplayer2.i.i(8);
            object = c.a(g2, i2);
            while (object.a != o.e("data")) {
                Log.w((String)"WavHeaderReader", (String)("Ignoring unknown WAV chunk: " + object.a));
                l2 = 8 + object.b;
                if (object.a == o.e("RIFF")) {
                    l2 = 12;
                }
                if (l2 > Integer.MAX_VALUE) {
                    throw new i("Chunk is too large (~2GB+) to skip; id: " + object.a);
                }
                g2.b((int)l2);
                object = c.a(g2, i2);
            }
            g2.b(8);
            l2 = g2.c();
            long l3 = object.b;
            b2.g = l2;
            b2.h = l3;
            this.b.a(this);
        }
        if ((n2 = this.c.a(g2, 32768 - this.f, true)) != -1) {
            this.f += n2;
        }
        if ((n3 = this.f / this.e) > 0) {
            object = this.d;
            l2 = (g2.c() - (long)this.f) * 1000000 / (long)object.c;
            this.f -= (n3 *= this.e);
            this.c.a(l2, 1, n3, this.f, null);
        }
        if (n2 == -1) {
            return -1;
        }
        return 0;
    }

    @Override
    public final long a(long l2) {
        b b2 = this.d;
        l2 = Math.min((long)b2.c * l2 / 1000000 / (long)b2.d * (long)b2.d, b2.h - (long)b2.d);
        return b2.g + l2;
    }

    @Override
    public final void a(long l2, long l3) {
        this.f = 0;
    }

    @Override
    public final void a(h h2) {
        this.b = h2;
        this.c = h2.a(0);
        this.d = null;
        h2.b();
    }

    @Override
    public final boolean a(g g2) {
        if (d.a(g2) != null) {
            return true;
        }
        return false;
    }

    @Override
    public final long b() {
        b b2 = this.d;
        return b2.h / (long)b2.d * 1000000 / (long)b2.b;
    }

    @Override
    public final boolean b_() {
        return true;
    }

}

