/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c.g;

import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.i.i;

public final class c {
    public final int a;
    public final long b;

    private c(int n2, long l2) {
        this.a = n2;
        this.b = l2;
    }

    public static c a(g g2, i i2) {
        g2.c(i2.a, 0, 8);
        i2.c(0);
        return new c(i2.k(), i2.j());
    }
}

