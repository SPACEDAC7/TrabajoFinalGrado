/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.c.n;

public interface h {
    public n a(int var1);

    public void a(m var1);

    public void b();
}

