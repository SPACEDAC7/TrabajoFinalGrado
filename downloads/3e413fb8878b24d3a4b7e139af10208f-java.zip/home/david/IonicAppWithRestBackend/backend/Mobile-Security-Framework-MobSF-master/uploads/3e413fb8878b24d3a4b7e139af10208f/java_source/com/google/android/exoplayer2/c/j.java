/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.id3.CommentFrame;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class j {
    private static final Pattern c = Pattern.compile("^ [0-9a-fA-F]{8} ([0-9a-fA-F]{8}) ([0-9a-fA-F]{8})");
    public int a = -1;
    public int b = -1;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private boolean a(String object, String string) {
        if (!"iTunSMPB".equals(object)) {
            return false;
        }
        object = c.matcher(string);
        if (!object.find()) return false;
        try {
            int n2 = Integer.parseInt(object.group(1), 16);
            int n3 = Integer.parseInt(object.group(2), 16);
            if (n2 <= 0) {
                if (n3 <= 0) return false;
            }
            this.a = n2;
            this.b = n3;
            return true;
        }
        catch (NumberFormatException var1_2) {
            return false;
        }
    }

    public final boolean a() {
        if (this.a != -1 && this.b != -1) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean a(Metadata metadata) {
        boolean bl2 = false;
        int n2 = 0;
        do {
            boolean bl3 = bl2;
            if (n2 >= metadata.a.length) return bl3;
            Metadata.Entry entry = metadata.a[n2];
            if (entry instanceof CommentFrame) {
                entry = (CommentFrame)entry;
                if (this.a(entry.b, entry.c)) {
                    return true;
                }
            }
            ++n2;
        } while (true);
    }
}

