/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

public final class k {
    private static final String[] h = new String[]{"audio/mpeg-L1", "audio/mpeg-L2", "audio/mpeg"};
    private static final int[] i = new int[]{44100, 48000, 32000};
    private static final int[] j = new int[]{32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448};
    private static final int[] k = new int[]{32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256};
    private static final int[] l = new int[]{32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384};
    private static final int[] m = new int[]{32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320};
    private static final int[] n = new int[]{8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160};
    public int a;
    public String b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;

    /*
     * Enabled aggressive block sorting
     */
    public static int a(int n2) {
        if ((n2 & -2097152) != -2097152) {
            return -1;
        }
        int n3 = n2 >>> 19 & 3;
        if (n3 == 1) return -1;
        int n4 = n2 >>> 17 & 3;
        if (n4 == 0) return -1;
        int n5 = n2 >>> 12 & 15;
        if (n5 == 0) return -1;
        if (n5 == 15) return -1;
        int n6 = n2 >>> 10 & 3;
        if (n6 == 3) return -1;
        n6 = i[n6];
        if (n3 == 2) {
            n6 /= 2;
        } else if (n3 == 0) {
            n6 /= 4;
        }
        int n7 = n2 >>> 9 & 1;
        if (n4 == 3) {
            if (n3 == 3) {
                n2 = j[n5 - 1];
                return n2 * 12000 / n6 + n7 << 2;
            }
            n2 = k[n5 - 1];
            return n2 * 12000 / n6 + n7 << 2;
        }
        n2 = n3 == 3 ? (n4 == 2 ? l[n5 - 1] : m[n5 - 1]) : n[n5 - 1];
        if (n3 == 3) {
            return 144000 * n2 / n6 + n7;
        }
        if (n4 == 1) {
            n3 = 72000;
            return n3 * n2 / n6 + n7;
        }
        n3 = 144000;
        return n3 * n2 / n6 + n7;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static boolean a(int var0, k var1_1) {
        var8_2 = 2;
        if ((var0 & -2097152) != -2097152) {
            return false;
        }
        var9_3 = var0 >>> 19 & 3;
        if (var9_3 == 1) {
            return false;
        }
        var10_4 = var0 >>> 17 & 3;
        if (var10_4 == 0) {
            return false;
        }
        var3_5 = var0 >>> 12 & 15;
        if (var3_5 == 0) return false;
        if (var3_5 == 15) {
            return false;
        }
        var4_6 = var0 >>> 10 & 3;
        if (var4_6 == 3) {
            return false;
        }
        var4_6 = k.i[var4_6];
        if (var9_3 == 2) {
            var4_6 /= 2;
        } else if (var9_3 == 0) {
            var4_6 /= 4;
        }
        var11_7 = var0 >>> 9 & 1;
        if (var10_4 != 3) ** GOTO lbl30
        var3_5 = var9_3 == 3 ? k.j[var3_5 - 1] : k.k[var3_5 - 1];
        var6_8 = var3_5 * 12000 / var4_6;
        var5_9 = 384;
        var6_8 = var6_8 + var11_7 << 2;
        ** GOTO lbl47
lbl30: // 1 sources:
        if (var9_3 != 3) ** GOTO lbl35
        var3_5 = var10_4 == 2 ? k.l[var3_5 - 1] : k.m[var3_5 - 1];
        var5_9 = 1152;
        var6_8 = var3_5;
        ** GOTO lbl-1000
lbl35: // 1 sources:
        var7_10 = k.n[var3_5 - 1];
        var3_5 = var10_4 == 1 ? 576 : 1152;
        var5_9 = var3_5;
        var6_8 = var7_10;
        if (var10_4 == 1) {
            var6_8 = 72000;
            var5_9 = var3_5;
            var3_5 = var7_10;
        } else lbl-1000: // 2 sources:
        {
            var3_5 = var6_8;
            var6_8 = 144000;
        }
        var6_8 = var6_8 * var3_5 / var4_6 + var11_7;
lbl47: // 2 sources:
        var2_11 = k.h[3 - var10_4];
        var7_10 = var8_2;
        if ((var0 >> 6 & 3) == 3) {
            var7_10 = 1;
        }
        var1_1.a = var9_3;
        var1_1.b = var2_11;
        var1_1.c = var6_8;
        var1_1.d = var4_6;
        var1_1.e = var7_10;
        var1_1.f = var3_5 * 1000;
        var1_1.g = var5_9;
        return true;
    }
}

