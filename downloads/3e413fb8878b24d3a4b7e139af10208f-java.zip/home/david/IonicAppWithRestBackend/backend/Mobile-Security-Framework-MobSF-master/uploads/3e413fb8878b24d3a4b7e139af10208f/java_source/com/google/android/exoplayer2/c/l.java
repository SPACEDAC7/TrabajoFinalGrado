/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

public final class l {
    public long a;
}

