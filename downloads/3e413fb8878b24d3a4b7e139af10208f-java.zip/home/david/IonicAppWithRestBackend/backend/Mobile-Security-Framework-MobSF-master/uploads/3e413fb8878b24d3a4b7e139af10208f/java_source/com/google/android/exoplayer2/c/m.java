/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

public interface m {
    public long a(long var1);

    public long b();

    public boolean b_();

    public static final class a
    implements m {
        private final long a;

        public a(long l2) {
            this.a = l2;
        }

        @Override
        public final long a(long l2) {
            return 0;
        }

        @Override
        public final long b() {
            return this.a;
        }

        @Override
        public final boolean b_() {
            return false;
        }
    }

}

