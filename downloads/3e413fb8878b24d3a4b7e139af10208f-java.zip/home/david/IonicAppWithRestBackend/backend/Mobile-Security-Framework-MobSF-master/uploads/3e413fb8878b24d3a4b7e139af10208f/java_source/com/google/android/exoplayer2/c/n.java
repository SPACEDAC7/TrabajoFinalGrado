/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.c;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.g;
import com.google.android.exoplayer2.i.i;

public interface n {
    public int a(g var1, int var2, boolean var3);

    public void a(long var1, int var3, int var4, int var5, byte[] var6);

    public void a(Format var1);

    public void a(i var1, int var2);
}

