/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.os.Handler
 *  android.os.Message
 *  android.util.Log
 */
package com.google.android.exoplayer2;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.google.android.exoplayer2.a;
import com.google.android.exoplayer2.b;
import com.google.android.exoplayer2.c;
import com.google.android.exoplayer2.e;
import com.google.android.exoplayer2.g;
import com.google.android.exoplayer2.g.f;
import com.google.android.exoplayer2.g.i;
import com.google.android.exoplayer2.h;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.n;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

final class d
implements c {
    final com.google.android.exoplayer2.g.h a;
    final CopyOnWriteArraySet<c.a> b;
    boolean c;
    boolean d;
    int e;
    int f;
    boolean g;
    n h;
    Object i;
    com.google.android.exoplayer2.e.g j;
    com.google.android.exoplayer2.g.g k;
    e.b l;
    private final c.b[] m;
    private final com.google.android.exoplayer2.g.g n;
    private final Handler o;
    private final e p;
    private final n.b q;
    private final n.a r;
    private int s;
    private long t;

    /*
     * Enabled aggressive block sorting
     */
    @SuppressLint(value={"HandlerLeak"})
    public d(c.b[] arrb, com.google.android.exoplayer2.g.h h2, h h3) {
        Log.i((String)"ExoPlayerImpl", (String)("Init 2.2.0 [" + o.e + "]"));
        boolean bl2 = arrb.length > 0;
        a.a.a.a.d.b(bl2);
        this.m = a.a.a.a.d.b(arrb);
        this.a = a.a.a.a.d.b(h2);
        this.d = false;
        this.e = 1;
        this.b = new CopyOnWriteArraySet();
        this.n = new com.google.android.exoplayer2.g.g(new f[arrb.length]);
        this.h = n.a;
        this.q = new n.b();
        this.r = new n.a();
        this.j = com.google.android.exoplayer2.e.g.a;
        this.k = this.n;
        this.o = new Handler(){

            /*
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            public final void handleMessage(Message iterator) {
                Object object = d.this;
                switch (iterator.what) {
                    default: {
                        return;
                    }
                    case 1: {
                        object.e = iterator.arg1;
                        iterator = object.b.iterator();
                        while (iterator.hasNext()) {
                            iterator.next().a(object.d, object.e);
                        }
                        return;
                    }
                    case 2: {
                        boolean bl2 = iterator.arg1 != 0;
                        object.g = bl2;
                        iterator = object.b.iterator();
                        while (iterator.hasNext()) {
                            iterator.next();
                        }
                        return;
                    }
                    case 3: {
                        iterator = (i)iterator.obj;
                        object.c = true;
                        object.j = iterator.a;
                        object.k = iterator.b;
                        object.a.a(iterator.c);
                        iterator = object.b.iterator();
                        while (iterator.hasNext()) {
                            iterator.next().k_();
                        }
                        return;
                    }
                    case 4: {
                        int n2;
                        object.f = n2 = object.f - 1;
                        if (n2 != 0) return;
                        object.l = (e.b)iterator.obj;
                        if (iterator.arg1 == 0) return;
                        iterator = object.b.iterator();
                        while (iterator.hasNext()) {
                            iterator.next().c();
                        }
                        return;
                    }
                    case 5: {
                        if (object.f != 0) return;
                        object.l = (e.b)iterator.obj;
                        iterator = object.b.iterator();
                        while (iterator.hasNext()) {
                            iterator.next().c();
                        }
                        return;
                    }
                    case 6: {
                        iterator = (e.d)iterator.obj;
                        object.h = iterator.a;
                        object.i = iterator.b;
                        object.l = iterator.c;
                        object.f -= iterator.d;
                        iterator = object.b.iterator();
                        while (iterator.hasNext()) {
                            iterator.next().j_();
                        }
                        return;
                    }
                    case 7: 
                }
                iterator = (b)iterator.obj;
                object = object.b.iterator();
                while (object.hasNext()) {
                    ((c.a)object.next()).a((b)((Object)iterator));
                }
            }
        };
        this.l = new e.b(0, 0);
        this.p = new e(arrb, h2, h3, this.d, this.o, this.l, this);
    }

    @Override
    public final int a() {
        return this.e;
    }

    @Override
    public final void a(int n2) {
        this.a(n2, -9223372036854775807L);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(int n2, long l2) {
        if (n2 < 0 || !this.h.a() && n2 >= this.h.b()) {
            throw new g(this.h, n2, l2);
        }
        ++this.f;
        this.s = n2;
        if (l2 == -9223372036854775807L) {
            this.t = 0;
            this.p.a(this.h, n2, -9223372036854775807L);
            return;
        } else {
            this.t = l2;
            this.p.a(this.h, n2, a.b(l2));
            Iterator<c.a> iterator = this.b.iterator();
            while (iterator.hasNext()) {
                iterator.next().c();
            }
        }
    }

    @Override
    public final void a(long l2) {
        this.a(this.f(), l2);
    }

    @Override
    public final void a(c.a a2) {
        this.b.add(a2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(com.google.android.exoplayer2.e.b b2, boolean bl2, boolean bl3) {
        Iterator<c.a> iterator;
        if (bl3) {
            if (!this.h.a() || this.i != null) {
                this.h = n.a;
                this.i = null;
                iterator = this.b.iterator();
                while (iterator.hasNext()) {
                    ((c.a)iterator.next()).j_();
                }
            }
            if (this.c) {
                this.c = false;
                this.j = com.google.android.exoplayer2.e.g.a;
                this.k = this.n;
                this.a.a(null);
                iterator = this.b.iterator();
                while (iterator.hasNext()) {
                    iterator.next().k_();
                }
            }
        }
        iterator = this.p.a;
        int n2 = bl2 ? 1 : 0;
        iterator.obtainMessage(0, n2, 0, (Object)b2).sendToTarget();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(boolean bl2) {
        if (this.d != bl2) {
            this.d = bl2;
            Object object = this.p.a;
            int n2 = bl2 ? 1 : 0;
            object.obtainMessage(1, n2, 0).sendToTarget();
            object = this.b.iterator();
            while (object.hasNext()) {
                ((c.a)object.next()).a(bl2, this.e);
            }
        }
    }

    @Override
    public final /* varargs */ void a(c.c ... arrc) {
        e e2 = this.p;
        if (e2.b) {
            Log.w((String)"ExoPlayerImplInternal", (String)"Ignoring messages sent after release.");
            return;
        }
        ++e2.c;
        e2.a.obtainMessage(10, (Object)arrc).sendToTarget();
    }

    @Override
    public final void b(c.a a2) {
        this.b.remove(a2);
    }

    @Override
    public final /* varargs */ void b(c.c ... arrc) {
        this.p.a(arrc);
    }

    @Override
    public final boolean b() {
        return this.d;
    }

    @Override
    public final void c() {
        this.a(this.f());
    }

    @Override
    public final void d() {
        this.p.a();
        this.o.removeCallbacksAndMessages((Object)null);
    }

    @Override
    public final n e() {
        return this.h;
    }

    @Override
    public final int f() {
        if (this.h.a() || this.f > 0) {
            return this.s;
        }
        return this.h.a((int)this.l.a, (n.a)this.r, (boolean)false).c;
    }

    @Override
    public final long g() {
        if (this.h.a()) {
            return -9223372036854775807L;
        }
        return a.a(this.h.a((int)this.f(), (n.b)this.q, (long)0).i);
    }

    @Override
    public final long h() {
        if (this.h.a() || this.f > 0) {
            return this.t;
        }
        this.h.a(this.l.a, this.r, false);
        return a.a(this.r.e) + a.a(this.l.c);
    }

    @Override
    public final long i() {
        if (this.h.a() || this.f > 0) {
            return this.t;
        }
        this.h.a(this.l.a, this.r, false);
        return a.a(this.r.e) + a.a(this.l.d);
    }

}

