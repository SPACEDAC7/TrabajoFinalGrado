/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.MediaCodecInfo
 *  android.media.MediaCodecInfo$CodecCapabilities
 *  android.media.MediaCodecInfo$CodecProfileLevel
 *  android.media.MediaCodecInfo$VideoCapabilities
 *  android.util.Log
 */
package com.google.android.exoplayer2.d;

import a.a.a.a.d;
import android.annotation.TargetApi;
import android.media.MediaCodecInfo;
import android.util.Log;
import com.google.android.exoplayer2.i.o;

@TargetApi(value=16)
public final class a {
    public final String a;
    public final boolean b;
    public final boolean c;
    public final String d;
    public final MediaCodecInfo.CodecCapabilities e;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    a(String var1_1, String var2_2, MediaCodecInfo.CodecCapabilities var3_3) {
        var6_4 = true;
        super();
        this.a = d.b(var1_1);
        this.d = var2_2;
        this.e = var3_3;
        if (var3_3 == null) ** GOTO lbl-1000
        var4_5 = o.a >= 19 && var3_3.isFeatureSupported("adaptive-playback") != false;
        if (var4_5) {
            var5_6 = true;
        } else lbl-1000: // 2 sources:
        {
            var5_6 = false;
        }
        this.b = var5_6;
        if (var3_3 == null) ** GOTO lbl-1000
        var4_5 = o.a >= 21 && var3_3.isFeatureSupported("tunneled-playback") != false;
        if (var4_5) {
            var5_6 = var6_4;
        } else lbl-1000: // 2 sources:
        {
            var5_6 = false;
        }
        this.c = var5_6;
    }

    public static a a(String string, String string2, MediaCodecInfo.CodecCapabilities codecCapabilities) {
        return new a(string, string2, codecCapabilities);
    }

    @TargetApi(value=21)
    private static boolean a(MediaCodecInfo.VideoCapabilities videoCapabilities, int n2, int n3, double d2) {
        if (d2 == -1.0 || d2 <= 0.0) {
            return videoCapabilities.isSizeSupported(n2, n3);
        }
        return videoCapabilities.areSizeAndRateSupported(n2, n3, d2);
    }

    public final void a(String string) {
        Log.d((String)"MediaCodecInfo", (String)("NoSupport [" + string + "] [" + this.a + ", " + this.d + "] [" + o.e + "]"));
    }

    @TargetApi(value=21)
    public final boolean a(int n2, int n3, double d2) {
        if (this.e == null) {
            this.a("sizeAndRate.caps");
            return false;
        }
        Object object = this.e.getVideoCapabilities();
        if (object == null) {
            this.a("sizeAndRate.vCaps");
            return false;
        }
        if (!a.a((MediaCodecInfo.VideoCapabilities)object, n2, n3, d2)) {
            if (n2 >= n3 || !a.a((MediaCodecInfo.VideoCapabilities)object, n3, n2, d2)) {
                this.a("sizeAndRate.support, " + n2 + "x" + n3 + "x" + d2);
                return false;
            }
            object = "sizeAndRate.rotated, " + n2 + "x" + n3 + "x" + d2;
            Log.d((String)"MediaCodecInfo", (String)("AssumedSupport [" + (String)object + "] [" + this.a + ", " + this.d + "] [" + o.e + "]"));
        }
        return true;
    }

    public final MediaCodecInfo.CodecProfileLevel[] a() {
        if (this.e == null || this.e.profileLevels == null) {
            return new MediaCodecInfo.CodecProfileLevel[0];
        }
        return this.e.profileLevels;
    }
}

