/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.MediaCodec
 *  android.media.MediaCodec$BufferInfo
 *  android.media.MediaCodec$CodecException
 *  android.media.MediaCrypto
 *  android.media.MediaFormat
 *  android.os.Looper
 *  android.os.SystemClock
 *  android.util.Log
 */
package com.google.android.exoplayer2.d;

import android.annotation.TargetApi;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Looper;
import android.os.SystemClock;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.FloatingActionButton;
import android.util.Log;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.b.e;
import com.google.android.exoplayer2.d.c;
import com.google.android.exoplayer2.d.d;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.f;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.k;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

@TargetApi(value=16)
public abstract class b
extends k {
    private static final byte[] k = o.f("0000016742C00BDA259000000168CE0F13200000016588840DCE7118A0002FBF1C31C3275D78");
    private boolean A;
    private boolean B;
    private boolean C;
    private boolean D;
    private ByteBuffer[] E;
    private ByteBuffer[] F;
    private long G;
    private int H;
    private int I;
    private boolean J;
    private boolean K;
    private int L;
    private int M;
    private boolean N;
    private boolean O;
    private boolean P;
    private boolean Q;
    private boolean R;
    private boolean S;
    public MediaCodec i;
    public com.google.android.exoplayer2.b.d j;
    private final c l;
    private final AppBarLayout.b<FloatingActionButton> m;
    private final boolean n;
    private final e o;
    private final f p;
    private final List<Long> q;
    private final MediaCodec.BufferInfo r;
    private Format s;
    private AppBarLayout.b<FloatingActionButton> t;
    private AppBarLayout.b<FloatingActionButton> u;
    private boolean v;
    private boolean w;
    private boolean x;
    private boolean y;
    private boolean z;

    /*
     * Enabled aggressive block sorting
     */
    public b(int n2, c c2, boolean bl2) {
        super(n2);
        boolean bl3 = o.a >= 16;
        a.a.a.a.d.b(bl3);
        this.l = a.a.a.a.d.b(c2);
        this.m = null;
        this.n = bl2;
        this.o = new e(0);
        this.p = new f();
        this.q = new ArrayList<Long>();
        this.r = new MediaCodec.BufferInfo();
        this.L = 0;
        this.M = 0;
    }

    private void a(a a2) {
        throw com.google.android.exoplayer2.b.a(a2, this.c);
    }

    /*
     * Exception decompiling
     */
    private boolean s() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl109 : TryStatement: try { 2[TRYBLOCK]

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps.apply(RemoveDeterministicJumps.java:35)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:519)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private void t() {
        if (this.M == 2) {
            this.z();
            this.x();
            return;
        }
        this.Q = true;
        this.w();
    }

    public void A() {
    }

    @Override
    public final int a(Format format) {
        try {
            int n2 = this.a(this.l, format);
            return n2;
        }
        catch (d.b var1_2) {
            throw com.google.android.exoplayer2.b.a(var1_2, this.c);
        }
    }

    public abstract int a(c var1, Format var2);

    public com.google.android.exoplayer2.d.a a(c c2, Format format, boolean bl2) {
        return c2.a(format.f, bl2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(long var1_1, long var3_2) {
        if (this.Q) {
            return;
        }
        if (this.s == null && this.a(this.p, null) == -5) {
            this.b(this.p.a);
        }
        this.x();
        if (this.i != null) ** GOTO lbl10
        if (this.s != null) {
            this.e.a(var1_1);
        }
        ** GOTO lbl52
lbl10: // 1 sources:
        a.a.a.a.a.f.a("drainAndFeed");
        while (this.I < 0) {
            block17 : {
                this.I = this.i.dequeueOutputBuffer(this.r, 0);
                if (this.I < 0) ** GOTO lbl31
                if (!this.D) ** GOTO lbl20
                this.D = false;
                this.i.releaseOutputBuffer(this.I, false);
                this.I = -1;
                var6_4 = 1;
                ** GOTO lbl48
lbl20: // 1 sources:
                if ((this.r.flags & 4) == 0) ** GOTO lbl24
                this.t();
                this.I = -1;
                ** GOTO lbl55
lbl24: // 1 sources:
                var5_3 = this.F[this.I];
                if (var5_3 != null) {
                    var5_3.position(this.r.offset);
                    var5_3.limit(this.r.offset + this.r.size);
                }
                var8_6 = this.r.presentationTimeUs;
                var7_5 = this.q.size();
                ** GOTO lbl58
lbl31: // 1 sources:
                if (this.I == -2) {
                    var5_3 = this.i.getOutputFormat();
                    if (this.y && var5_3.getInteger("width") == 32 && var5_3.getInteger("height") == 32) {
                        this.D = true;
                    } else {
                        if (this.B) {
                            var5_3.setInteger("channel-count", 1);
                        }
                        this.a(this.i, (MediaFormat)var5_3);
                    }
                    var6_4 = 1;
                } else if (this.I == -3) {
                    this.F = this.i.getOutputBuffers();
                    var6_4 = 1;
                } else {
                    if (this.z && (this.P || this.M == 2)) {
                        this.t();
                    }
                    var6_4 = 0;
                }
lbl48: // 6 sources:
                while (var6_4 == 0) {
                    while (this.s()) {
                    }
                    a.a.a.a.a.f.a();
lbl52: // 2 sources:
                    this.j.a();
                    return;
                }
                continue;
lbl55: // 2 sources:
                do {
                    var6_4 = 0;
                    ** GOTO lbl48
                    break;
                } while (true);
lbl58: // 2 sources:
                for (var6_4 = 0; var6_4 < var7_5; ++var6_4) {
                    if (this.q.get(var6_4) != var8_6) continue;
                    this.q.remove(var6_4);
                    var10_7 = true;
                    break block17;
                }
                var10_7 = false;
            }
            this.J = var10_7;
            break;
        }
        ** while (!this.a((long)var1_1, (long)var3_2, (MediaCodec)this.i, (ByteBuffer)this.F[this.I], (int)this.I, (int)this.r.flags, (long)this.r.presentationTimeUs, (boolean)this.J))
lbl68: // 1 sources:
        var8_6 = this.r.presentationTimeUs;
        this.I = -1;
        var6_4 = 1;
        ** GOTO lbl48
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(long l2, boolean bl2) {
        this.P = false;
        this.Q = false;
        if (this.i != null) {
            this.G = -9223372036854775807L;
            this.H = -1;
            this.I = -1;
            this.S = true;
            this.R = false;
            this.J = false;
            this.q.clear();
            this.C = false;
            this.D = false;
            if (this.x || this.A && this.O) {
                this.z();
                this.x();
            } else if (this.M != 0) {
                this.z();
                this.x();
            } else {
                this.i.flush();
                this.N = false;
            }
            if (this.K && this.s != null) {
                this.L = 1;
            }
        }
    }

    public void a(MediaCodec mediaCodec, MediaFormat mediaFormat) {
    }

    public abstract void a(com.google.android.exoplayer2.d.a var1, MediaCodec var2, Format var3, MediaCrypto var4);

    public void a(String string, long l2, long l3) {
    }

    @Override
    public void a(boolean bl2) {
        this.j = new com.google.android.exoplayer2.b.d();
    }

    public abstract boolean a(long var1, long var3, MediaCodec var5, ByteBuffer var6, int var7, int var8, long var9, boolean var11);

    public boolean a(boolean bl2, Format format, Format format2) {
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void b(Format b2) {
        Format format = this.s;
        this.s = b2;
        DrmInitData drmInitData = this.s.i;
        b2 = format == null ? null : format.i;
        boolean bl2 = !o.a(drmInitData, b2);
        if (bl2) {
            if (this.s.i != null) {
                if (this.m == null) {
                    throw com.google.android.exoplayer2.b.a(new IllegalStateException("Media requires a DrmSessionManager"), this.c);
                }
                b2 = this.m;
                Looper.myLooper();
                drmInitData = this.s.i;
                this.u = b2.j();
                if (this.u == this.t) {
                    // empty if block
                }
            } else {
                this.u = null;
            }
        }
        if (this.u == this.t && this.i != null && this.a(this.v, format, this.s)) {
            this.K = true;
            this.L = 1;
            boolean bl3 = this.y && this.s.j == format.j && this.s.k == format.k;
            this.C = bl3;
            return;
        }
        if (this.N) {
            this.M = 1;
            return;
        }
        this.z();
        this.x();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean k() {
        if (this.s != null && !this.R) {
            boolean bl2 = this.g ? this.h : this.e.a();
            if (bl2 || this.I >= 0 || this.G != -9223372036854775807L && SystemClock.elapsedRealtime() < this.G) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean l() {
        return this.Q;
    }

    @Override
    public final int o() {
        return 4;
    }

    @Override
    public void p() {
    }

    @Override
    public void q() {
    }

    @Override
    public void r() {
        this.s = null;
        try {
            this.z();
            return;
        }
        finally {
            this.t = null;
            this.u = null;
        }
    }

    public void w() {
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    public final void x() {
        var12_1 = false;
        if (!this.y()) lbl-1000: // 2 sources:
        {
            do {
                return;
                break;
            } while (true);
        }
        this.t = this.u;
        var4_2 = this.s.f;
        if (this.t == null) ** GOTO lbl117
        var5_3 = this.t.f();
        if (var5_3 == 0) {
            throw com.google.android.exoplayer2.b.a(this.t.i(), this.c);
        }
        ** while (var5_3 != 3 && var5_3 != 4)
lbl12: // 1 sources:
        var3_4 = ((FloatingActionButton)this.t.g()).D;
        var10_5 = this.t.h();
lbl14: // 2 sources:
        do {
            block29 : {
                block28 : {
                    block27 : {
                        block26 : {
                            block25 : {
                                block24 : {
                                    block23 : {
                                        var1_9 = var2_6 = this.a(this.l, this.s, var10_5);
                                        if (var2_6 != null) break block23;
                                        var1_9 = var2_6;
                                        if (!var10_5) break block23;
                                        var1_9 = var2_6;
                                        try {
                                            var1_9 = var2_6 = this.a(this.l, this.s, false);
                                            if (var2_6 == null) break block23;
                                            var1_9 = var2_6;
                                            Log.w((String)"MediaCodecRenderer", (String)("Drm session requires secure decoder for " + (String)var4_2 + ", but no secure decoder available. Trying to proceed with " + var2_6.a + "."));
                                            var1_9 = var2_6;
                                        }
                                        catch (d.b var2_8) {
                                            ** continue;
                                        }
                                    }
lbl28: // 2 sources:
                                    do {
                                        if (var1_9 == null) {
                                            this.a(new a(this.s, null, var10_5, -49999));
                                        }
                                        var2_6 = var1_9.a;
                                        this.v = var1_9.b;
                                        var4_2 = this.s;
                                        if (o.a >= 21 || !var4_2.h.isEmpty() || !"OMX.MTK.VIDEO.DECODER.AVC".equals(var2_6)) break block24;
                                        var11_11 = true;
lbl36: // 2 sources:
                                        do {
                                            this.w = var11_11;
                                            if (o.a >= 18 && (o.a != 18 || !"OMX.SEC.avc.dec".equals(var2_6) && !"OMX.SEC.avc.dec.secure".equals(var2_6)) && (o.a != 19 || !o.d.startsWith("SM-G800") || !"OMX.Exynos.avc.dec".equals(var2_6) && !"OMX.Exynos.avc.dec.secure".equals(var2_6))) break block25;
                                            var11_11 = true;
lbl40: // 2 sources:
                                            do {
                                                this.x = var11_11;
                                                if (o.a >= 24 || !"OMX.Nvidia.h264.decode".equals(var2_6) && !"OMX.Nvidia.h264.decode.secure".equals(var2_6) || !"flounder".equals(o.b) && !"flounder_lte".equals(o.b) && !"grouper".equals(o.b) && !"tilapia".equals(o.b)) break block26;
                                                var11_11 = true;
lbl44: // 2 sources:
                                                do {
                                                    this.y = var11_11;
                                                    if (o.a > 17 || !"OMX.rk.video_decoder.avc".equals(var2_6) && !"OMX.allwinner.video.decoder.avc".equals(var2_6)) break block27;
                                                    var11_11 = true;
lbl48: // 2 sources:
                                                    do {
                                                        this.z = var11_11;
                                                        if ((o.a > 23 || !"OMX.google.vorbis.decoder".equals(var2_6)) && (o.a > 19 || !"hb2000".equals(o.b) || !"OMX.amlogic.avc.decoder.awesome".equals(var2_6) && !"OMX.amlogic.avc.decoder.awesome.secure".equals(var2_6))) break block28;
                                                        var11_11 = true;
lbl52: // 2 sources:
                                                        do {
                                                            this.A = var11_11;
                                                            var4_2 = this.s;
                                                            var11_11 = var12_1;
                                                            if (o.a <= 18) {
                                                                var11_11 = var12_1;
                                                                if (var4_2.q == 1) {
                                                                    var11_11 = var12_1;
                                                                    if ("OMX.MTK.AUDIO.DECODER.MP3".equals(var2_6)) {
                                                                        var11_11 = true;
                                                                    }
                                                                }
                                                            }
                                                            this.B = var11_11;
                                                            var6_12 = SystemClock.elapsedRealtime();
                                                            a.a.a.a.a.f.a("createCodec:" + (String)var2_6);
                                                            this.i = MediaCodec.createByCodecName((String)var2_6);
                                                            a.a.a.a.a.f.a();
                                                            a.a.a.a.a.f.a("configureCodec");
                                                            this.a((com.google.android.exoplayer2.d.a)var1_9, this.i, this.s, var3_4);
                                                            a.a.a.a.a.f.a();
                                                            a.a.a.a.a.f.a("startCodec");
                                                            this.i.start();
                                                            a.a.a.a.a.f.a();
                                                            var8_13 = SystemClock.elapsedRealtime();
                                                            this.a((String)var2_6, var8_13, var8_13 - var6_12);
                                                            this.E = this.i.getInputBuffers();
                                                            this.F = this.i.getOutputBuffers();
lbl78: // 2 sources:
                                                            ** while (this.d == 2)
lbl-1000: // 1 sources:
                                                            {
                                                                var6_12 = SystemClock.elapsedRealtime() + 1000;
lbl80: // 2 sources:
                                                                do {
                                                                    this.G = var6_12;
                                                                    this.H = -1;
                                                                    this.I = -1;
                                                                    this.S = true;
                                                                    var1_9 = this.j;
                                                                    ++var1_9.a;
                                                                    return;
                                                                    break;
                                                                } while (true);
lbl88: // 1 sources:
                                                                break block29;
                                                            }
                                                            break;
                                                        } while (true);
                                                        break;
                                                    } while (true);
                                                    break;
                                                } while (true);
                                                break;
                                            } while (true);
                                            break;
                                        } while (true);
                                        break;
                                    } while (true);
                                    catch (d.b var2_7) {
                                        var1_9 = null;
lbl91: // 2 sources:
                                        do {
                                            this.a(new a(this.s, (Throwable)var2_6, var10_5, -49998));
                                            ** continue;
                                            break;
                                        } while (true);
                                    }
                                }
                                var11_11 = false;
                                ** continue;
                            }
                            var11_11 = false;
                            ** continue;
                        }
                        var11_11 = false;
                        ** continue;
                    }
                    var11_11 = false;
                    ** continue;
                }
                var11_11 = false;
                ** continue;
                catch (Exception var1_10) {
                    this.a(new a(this.s, (Throwable)var1_10, var10_5, (String)var2_6));
                    ** GOTO lbl78
                }
            }
            var6_12 = -9223372036854775807L;
            ** continue;
            break;
        } while (true);
lbl117: // 1 sources:
        var10_5 = false;
        var3_4 = null;
        ** while (true)
    }

    public boolean y() {
        if (this.i == null && this.s != null) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void z() {
        if (this.i == null) return;
        this.G = -9223372036854775807L;
        this.H = -1;
        this.I = -1;
        this.R = false;
        this.J = false;
        this.q.clear();
        this.E = null;
        this.F = null;
        this.K = false;
        this.N = false;
        this.v = false;
        this.w = false;
        this.x = false;
        this.y = false;
        this.z = false;
        this.A = false;
        this.B = false;
        this.C = false;
        this.D = false;
        this.O = false;
        this.L = 0;
        this.M = 0;
        com.google.android.exoplayer2.b.d d2 = this.j;
        ++d2.b;
        try {
            this.i.stop();
        }
        catch (Throwable throwable) {
            try {
                this.i.release();
                throw throwable;
            }
            finally {
                this.i = null;
                if (this.t != null && this.u != this.t) {
                    this.t = null;
                }
            }
        }
        this.i.release();
        return;
        finally {
            this.i = null;
            if (this.t != null && this.u != this.t) {
                this.t = null;
            }
        }
    }

    public static final class a
    extends Exception {
        public final String a;
        public final boolean b;
        public final String c;
        public final String d;

        /*
         * Enabled aggressive block sorting
         */
        public a(Format object, Throwable throwable, boolean bl2, int n2) {
            super("Decoder init failed: [" + n2 + "], " + object, throwable);
            this.a = object.f;
            this.b = bl2;
            this.c = null;
            object = n2 < 0 ? "neg_" : "";
            this.d = "com.google.android.exoplayer.MediaCodecTrackRenderer_" + (String)object + Math.abs(n2);
        }

        public a(Format object, Throwable throwable, boolean bl2, String string) {
            Object var5_5 = null;
            super("Decoder init failed: " + string + ", " + object, throwable);
            this.a = object.f;
            this.b = bl2;
            this.c = string;
            object = var5_5;
            if (o.a >= 21) {
                object = var5_5;
                if (throwable instanceof MediaCodec.CodecException) {
                    object = ((MediaCodec.CodecException)throwable).getDiagnosticInfo();
                }
            }
            this.d = object;
        }
    }

}

