/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.d;

import com.google.android.exoplayer2.d.a;
import com.google.android.exoplayer2.d.d;

public interface c {
    public static final c a = new c(){

        @Override
        public final a a() {
            return d.a();
        }

        @Override
        public final a a(String string, boolean bl2) {
            return d.a(string, bl2);
        }
    };

    public a a();

    public a a(String var1, boolean var2);

}

