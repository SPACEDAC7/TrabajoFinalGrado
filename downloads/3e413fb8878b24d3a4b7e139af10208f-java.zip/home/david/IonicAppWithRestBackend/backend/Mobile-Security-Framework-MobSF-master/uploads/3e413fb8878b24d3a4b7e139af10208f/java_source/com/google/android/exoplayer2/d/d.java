/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.annotation.TargetApi
 *  android.media.MediaCodecInfo
 *  android.media.MediaCodecInfo$CodecCapabilities
 *  android.media.MediaCodecInfo$CodecProfileLevel
 *  android.media.MediaCodecList
 *  android.text.TextUtils
 *  android.util.Log
 *  android.util.Pair
 *  android.util.SparseIntArray
 */
package com.google.android.exoplayer2.d;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import android.util.SparseIntArray;
import com.google.android.exoplayer2.i.o;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressLint(value={"InlinedApi"})
@TargetApi(value=16)
public final class d {
    private static final com.google.android.exoplayer2.d.a a;
    private static final Pattern b;
    private static final HashMap<a, List<com.google.android.exoplayer2.d.a>> c;
    private static final SparseIntArray d;
    private static final SparseIntArray e;
    private static final Map<String, Integer> f;
    private static int g;

    static {
        Object object;
        a = new com.google.android.exoplayer2.d.a("OMX.google.raw.decoder", null, null);
        b = Pattern.compile("^\\D?(\\d+)$");
        c = new HashMap();
        g = -1;
        d = object = new SparseIntArray();
        object.put(66, 1);
        d.put(77, 2);
        d.put(88, 4);
        d.put(100, 8);
        e = object = new SparseIntArray();
        object.put(10, 1);
        e.put(11, 4);
        e.put(12, 8);
        e.put(13, 16);
        e.put(20, 32);
        e.put(21, 64);
        e.put(22, 128);
        e.put(30, 256);
        e.put(31, 512);
        e.put(32, 1024);
        e.put(40, 2048);
        e.put(41, 4096);
        e.put(42, 8192);
        e.put(50, 16384);
        e.put(51, 32768);
        e.put(52, 65536);
        f = object = new HashMap();
        object.put("L30", 1);
        f.put("L60", 4);
        f.put("L63", 16);
        f.put("L90", 64);
        f.put("L93", 256);
        f.put("L120", 1024);
        f.put("L123", 4096);
        f.put("L150", 16384);
        f.put("L153", 65536);
        f.put("L156", 262144);
        f.put("L180", 1048576);
        f.put("L183", 4194304);
        f.put("L186", 16777216);
        f.put("H30", 2);
        f.put("H60", 8);
        f.put("H63", 32);
        f.put("H90", 128);
        f.put("H93", 512);
        f.put("H120", 2048);
        f.put("H123", 8192);
        f.put("H150", 32768);
        f.put("H153", 131072);
        f.put("H156", 524288);
        f.put("H180", 2097152);
        f.put("H183", 8388608);
        f.put("H186", 33554432);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static Pair<Integer, Integer> a(String var0) {
        var3_1 = 0;
        if (var0 == null) {
            return null;
        }
        var1_2 = var0.split("\\.");
        var2_3 = var1_2[0];
        switch (var2_3.hashCode()) {
            case 3199032: {
                if (!var2_3.equals("hev1")) ** GOTO lbl18
                ** GOTO lbl25
            }
            case 3214780: {
                if (!var2_3.equals("hvc1")) ** GOTO lbl18
                var3_1 = 1;
                ** GOTO lbl25
            }
            case 3006243: {
                if (!var2_3.equals("avc1")) ** GOTO lbl18
                var3_1 = 2;
                ** GOTO lbl25
            }
lbl18: // 4 sources:
            default: {
                ** GOTO lbl-1000
            }
            case 3006244: 
        }
        if (var2_3.equals("avc2")) {
            var3_1 = 3;
        } else lbl-1000: // 2 sources:
        {
            var3_1 = -1;
        }
lbl25: // 5 sources:
        switch (var3_1) {
            default: {
                return null;
            }
            case 0: 
            case 1: {
                if (var1_2.length < 4) {
                    Log.w((String)"MediaCodecUtil", (String)("Ignoring malformed HEVC codec string: " + (String)var0));
                    return null;
                }
                var2_3 = d.b.matcher(var1_2[1]);
                if (!var2_3.matches()) {
                    Log.w((String)"MediaCodecUtil", (String)("Ignoring malformed HEVC codec string: " + (String)var0));
                    return null;
                }
                var0 = var2_3.group(1);
                if ("1".equals(var0)) {
                    var3_1 = 1;
                } else {
                    if (!"2".equals(var0)) {
                        Log.w((String)"MediaCodecUtil", (String)("Unknown HEVC profile string: " + (String)var0));
                        return null;
                    }
                    var3_1 = 2;
                }
                if ((var0 = d.f.get(var1_2[3])) != null) return new Pair((Object)var3_1, var0);
                Log.w((String)"MediaCodecUtil", (String)("Unknown HEVC level string: " + var2_3.group(1)));
                return null;
            }
            case 2: 
            case 3: 
        }
        return d.a((String)var0, var1_2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Pair<Integer, Integer> a(String var0, String[] var1_1) {
        block6 : {
            if (var1_1.length < 2) {
                Log.w((String)"MediaCodecUtil", (String)("Ignoring malformed AVC codec string: " + (String)var0));
                return null;
            }
            try {
                if (var1_1[1].length() != 6) break block6;
                var2_3 = Integer.parseInt(var1_1[1].substring(0, 2), 16);
                var4_4 = Integer.parseInt(var1_1[1].substring(4), 16);
            }
            catch (NumberFormatException var1_2) {
                Log.w((String)"MediaCodecUtil", (String)("Ignoring malformed AVC codec string: " + (String)var0));
                return null;
            }
            var0 = var4_4;
            var1_1 = var2_3;
            ** GOTO lbl23
        }
        if (var1_1.length < 3) {
            Log.w((String)"MediaCodecUtil", (String)("Ignoring malformed AVC codec string: " + (String)var0));
            return null;
        }
        var2_3 = Integer.parseInt((String)var1_1[1]);
        var3_5 = Integer.parseInt((String)var1_1[2]);
        var1_1 = var2_3;
        var0 = var3_5;
lbl23: // 2 sources:
        if ((var2_3 = Integer.valueOf(d.d.get(var1_1.intValue()))) == null) {
            Log.w((String)"MediaCodecUtil", (String)("Unknown AVC profile: " + var1_1));
            return null;
        }
        var1_1 = d.e.get(var0.intValue());
        if (var1_1 != null) return new Pair((Object)var2_3, var1_1);
        Log.w((String)"MediaCodecUtil", (String)("Unknown AVC level: " + var0));
        return null;
    }

    public static com.google.android.exoplayer2.d.a a() {
        return a;
    }

    public static com.google.android.exoplayer2.d.a a(String object, boolean bl2) {
        if ((object = d.b((String)object, bl2)).isEmpty()) {
            return null;
        }
        return (com.google.android.exoplayer2.d.a)object.get(0);
    }

    /*
     * Exception decompiling
     */
    private static List<com.google.android.exoplayer2.d.a> a(a var0, c var1_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl102 : TryStatement: try { 6[TRYBLOCK]

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps.apply(RemoveDeterministicJumps.java:35)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:519)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static int b() {
        int n2 = 0;
        if (g != -1) return g;
        MediaCodecInfo.CodecProfileLevel[] arrcodecProfileLevel = d.a("video/avc", false);
        if (arrcodecProfileLevel != null) {
            arrcodecProfileLevel = arrcodecProfileLevel.a();
            int n3 = arrcodecProfileLevel.length;
            int n4 = 0;
            for (int i2 = 0; i2 < n3; ++i2) {
                switch (arrcodecProfileLevel[i2].level) {
                    default: {
                        n2 = -1;
                        break;
                    }
                    case 1: {
                        n2 = 25344;
                        break;
                    }
                    case 2: {
                        n2 = 25344;
                        break;
                    }
                    case 8: {
                        n2 = 101376;
                        break;
                    }
                    case 16: {
                        n2 = 101376;
                        break;
                    }
                    case 32: {
                        n2 = 101376;
                        break;
                    }
                    case 64: {
                        n2 = 202752;
                        break;
                    }
                    case 128: {
                        n2 = 414720;
                        break;
                    }
                    case 256: {
                        n2 = 414720;
                        break;
                    }
                    case 512: {
                        n2 = 921600;
                        break;
                    }
                    case 1024: {
                        n2 = 1310720;
                        break;
                    }
                    case 2048: {
                        n2 = 2097152;
                        break;
                    }
                    case 4096: {
                        n2 = 2097152;
                        break;
                    }
                    case 8192: {
                        n2 = 2228224;
                        break;
                    }
                    case 16384: {
                        n2 = 5652480;
                        break;
                    }
                    case 32768: {
                        n2 = 9437184;
                    }
                }
                n4 = Math.max(n2, n4);
            }
            n2 = o.a >= 21 ? 345600 : 172800;
            n2 = Math.max(n4, n2);
        }
        g = n2;
        return g;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static List<com.google.android.exoplayer2.d.a> b(String list, boolean bl2) {
        synchronized (d.class) {
            List<com.google.android.exoplayer2.d.a> list2;
            a a2 = new a((String)((Object)list), bl2);
            Object object = c.get(a2);
            if (object != null) {
                return object;
            }
            object = o.a >= 21 ? new e(bl2) : new d(0);
            object = list2 = d.a(a2, (c)object);
            if (bl2) {
                object = list2;
                if (list2.isEmpty()) {
                    object = list2;
                    if (21 <= o.a) {
                        object = list2;
                        if (o.a <= 23 && !(object = d.a(a2, new d(0))).isEmpty()) {
                            Log.w((String)"MediaCodecUtil", (String)("MediaCodecList API didn't list secure decoder for: " + list + ". Assuming: " + object.get((int)0).a));
                        }
                    }
                }
            }
            list = Collections.unmodifiableList(object);
            c.put(a2, list);
            return list;
        }
    }

    static final class a {
        public final String a;
        public final boolean b;

        public a(String string, boolean bl2) {
            this.a = string;
            this.b = bl2;
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public final boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (object == null) return false;
            if (object.getClass() != a.class) {
                return false;
            }
            object = (a)object;
            if (!TextUtils.equals((CharSequence)this.a, (CharSequence)object.a)) return false;
            if (this.b == object.b) return true;
            return false;
        }

        /*
         * Enabled aggressive block sorting
         */
        public final int hashCode() {
            int n2;
            int n3 = this.a == null ? 0 : this.a.hashCode();
            if (this.b) {
                n2 = 1231;
                return n2 + (n3 + 31) * 31;
            }
            n2 = 1237;
            return n2 + (n3 + 31) * 31;
        }
    }

    public static final class b
    extends Exception {
        private b(Throwable throwable) {
            super("Failed to query underlying media codecs", throwable);
        }

        /* synthetic */ b(Throwable throwable, byte by2) {
            this(throwable);
        }
    }

    static interface c {
        public int a();

        public MediaCodecInfo a(int var1);

        public boolean a(String var1, MediaCodecInfo.CodecCapabilities var2);

        public boolean b();
    }

    static final class d
    implements c {
        private d() {
        }

        /* synthetic */ d(byte by2) {
            this();
        }

        @Override
        public final int a() {
            return MediaCodecList.getCodecCount();
        }

        @Override
        public final MediaCodecInfo a(int n2) {
            return MediaCodecList.getCodecInfoAt((int)n2);
        }

        @Override
        public final boolean a(String string, MediaCodecInfo.CodecCapabilities codecCapabilities) {
            return "video/avc".equals(string);
        }

        @Override
        public final boolean b() {
            return false;
        }
    }

    @TargetApi(value=21)
    static final class e
    implements c {
        private final int a;
        private MediaCodecInfo[] b;

        /*
         * Enabled aggressive block sorting
         */
        public e(boolean bl2) {
            int n2 = bl2 ? 1 : 0;
            this.a = n2;
        }

        private void c() {
            if (this.b == null) {
                this.b = new MediaCodecList(this.a).getCodecInfos();
            }
        }

        @Override
        public final int a() {
            this.c();
            return this.b.length;
        }

        @Override
        public final MediaCodecInfo a(int n2) {
            this.c();
            return this.b[n2];
        }

        @Override
        public final boolean a(String string, MediaCodecInfo.CodecCapabilities codecCapabilities) {
            return codecCapabilities.isFeatureSupported("secure-playback");
        }

        @Override
        public final boolean b() {
            return true;
        }
    }

}

