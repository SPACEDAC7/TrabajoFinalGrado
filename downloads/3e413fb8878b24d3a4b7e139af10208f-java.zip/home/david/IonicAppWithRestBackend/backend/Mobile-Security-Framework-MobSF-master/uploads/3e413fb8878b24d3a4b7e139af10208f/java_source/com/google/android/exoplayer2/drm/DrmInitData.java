/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.drm;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.a;
import com.google.android.exoplayer2.i.o;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

public final class DrmInitData
implements Parcelable,
Comparator<SchemeData> {
    public static final Parcelable.Creator<DrmInitData> CREATOR = new Parcelable.Creator<DrmInitData>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new DrmInitData(parcel);
        }
    };
    public final SchemeData[] a;
    public final int b;
    private int c;

    DrmInitData(Parcel parcel) {
        this.a = (SchemeData[])parcel.createTypedArray(SchemeData.CREATOR);
        this.b = this.a.length;
    }

    public DrmInitData(List<SchemeData> list) {
        this(false, list.toArray(new SchemeData[list.size()]));
    }

    private /* varargs */ DrmInitData(boolean bl2, SchemeData ... arrschemeData) {
        if (bl2) {
            arrschemeData = (SchemeData[])arrschemeData.clone();
        }
        Arrays.sort(arrschemeData, this);
        for (int i2 = 1; i2 < arrschemeData.length; ++i2) {
            if (!arrschemeData[i2 - 1].e.equals(arrschemeData[i2].e)) continue;
            throw new IllegalArgumentException("Duplicate data for uuid: " + arrschemeData[i2].e);
        }
        this.a = arrschemeData;
        this.b = arrschemeData.length;
    }

    public /* varargs */ DrmInitData(SchemeData ... arrschemeData) {
        this(true, arrschemeData);
    }

    @Override
    public final /* synthetic */ int compare(Object object, Object object2) {
        object = (SchemeData)object;
        object2 = (SchemeData)object2;
        if (a.b.equals(((SchemeData)object).e)) {
            if (a.b.equals(((SchemeData)object2).e)) {
                return 0;
            }
            return 1;
        }
        return ((SchemeData)object).e.compareTo(((SchemeData)object2).e);
    }

    public final int describeContents() {
        return 0;
    }

    @Override
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        return Arrays.equals(this.a, ((DrmInitData)object).a);
    }

    public final int hashCode() {
        if (this.c == 0) {
            this.c = Arrays.hashCode(this.a);
        }
        return this.c;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeTypedArray(this.a, 0);
    }

    public static final class SchemeData
    implements Parcelable {
        public static final Parcelable.Creator<SchemeData> CREATOR = new Parcelable.Creator<SchemeData>(){

            public final /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new SchemeData(parcel);
            }
        };
        public final String a;
        public final byte[] b;
        public final boolean c;
        private int d;
        private final UUID e;

        /*
         * Enabled aggressive block sorting
         */
        SchemeData(Parcel parcel) {
            this.e = new UUID(parcel.readLong(), parcel.readLong());
            this.a = parcel.readString();
            this.b = parcel.createByteArray();
            boolean bl2 = parcel.readByte() != 0;
            this.c = bl2;
        }

        public SchemeData(UUID uUID, String string, byte[] arrby) {
            this(uUID, string, arrby, 0);
        }

        private SchemeData(UUID uUID, String string, byte[] arrby, byte by2) {
            this.e = d.b(uUID);
            this.a = d.b(string);
            this.b = d.b(arrby);
            this.c = false;
        }

        public final int describeContents() {
            return 0;
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public final boolean equals(Object object) {
            if (!(object instanceof SchemeData)) {
                return false;
            }
            if (object == this) {
                return true;
            }
            object = (SchemeData)object;
            if (!this.a.equals(object.a)) return false;
            if (!o.a(this.e, object.e)) return false;
            if (!Arrays.equals(this.b, object.b)) return false;
            return true;
        }

        public final int hashCode() {
            if (this.d == 0) {
                this.d = (this.e.hashCode() * 31 + this.a.hashCode()) * 31 + Arrays.hashCode(this.b);
            }
            return this.d;
        }

        /*
         * Enabled aggressive block sorting
         */
        public final void writeToParcel(Parcel parcel, int n2) {
            parcel.writeLong(this.e.getMostSignificantBits());
            parcel.writeLong(this.e.getLeastSignificantBits());
            parcel.writeString(this.a);
            parcel.writeByteArray(this.b);
            n2 = this.c ? 1 : 0;
            parcel.writeByte((byte)n2);
        }

    }

}

