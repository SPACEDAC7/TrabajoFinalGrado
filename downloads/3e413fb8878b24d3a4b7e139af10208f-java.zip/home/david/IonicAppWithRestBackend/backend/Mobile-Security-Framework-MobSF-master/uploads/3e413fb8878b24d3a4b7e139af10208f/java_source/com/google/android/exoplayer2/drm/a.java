/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 */
package com.google.android.exoplayer2.drm;

import android.content.Intent;

public class a
extends Exception {
    public final Intent a;

    public a(String string, Intent intent) {
        super(string);
        this.a = intent;
    }
}

