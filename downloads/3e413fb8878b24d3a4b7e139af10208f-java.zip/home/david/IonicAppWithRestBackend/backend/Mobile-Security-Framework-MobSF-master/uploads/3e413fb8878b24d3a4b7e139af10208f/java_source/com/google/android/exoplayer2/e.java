/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.os.Message
 *  android.os.SystemClock
 *  android.util.Log
 *  android.util.Pair
 */
package com.google.android.exoplayer2;

import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.f;
import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c;
import com.google.android.exoplayer2.c.i;
import com.google.android.exoplayer2.e.a;
import com.google.android.exoplayer2.e.b;
import com.google.android.exoplayer2.e.d;
import com.google.android.exoplayer2.h;
import com.google.android.exoplayer2.h.d;
import com.google.android.exoplayer2.h.g;
import com.google.android.exoplayer2.i.f;
import com.google.android.exoplayer2.i.k;
import com.google.android.exoplayer2.i.m;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.l;
import com.google.android.exoplayer2.n;
import java.util.PriorityQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

final class e
implements Handler.Callback,
f.a,
b$a,
d$a {
    private long A;
    private a B;
    private a C;
    private a D;
    private n E;
    final Handler a;
    boolean b;
    int c;
    private final c.b[] d;
    private final com.google.android.exoplayer2.k[] e;
    private final com.google.android.exoplayer2.g.h f;
    private final h g;
    private final m h;
    private final HandlerThread i;
    private final Handler j;
    private final com.google.android.exoplayer2.c k;
    private final n.b l;
    private final n.a m;
    private b n;
    private c.b o;
    private f p;
    private com.google.android.exoplayer2.e.b q;
    private c.b[] r;
    private boolean s;
    private boolean t;
    private boolean u;
    private int v;
    private int w;
    private long x;
    private int y;
    private c z;

    public e(c.b[] arrb, com.google.android.exoplayer2.g.h h2, h h3, boolean bl2, Handler handler, b b2, com.google.android.exoplayer2.c c2) {
        this.d = arrb;
        this.f = h2;
        this.g = h3;
        this.s = bl2;
        this.j = handler;
        this.v = 1;
        this.n = b2;
        this.k = c2;
        this.e = new com.google.android.exoplayer2.k[arrb.length];
        for (int i2 = 0; i2 < arrb.length; ++i2) {
            arrb[i2].a(i2);
            this.e[i2] = arrb[i2].b();
        }
        this.h = new m();
        this.r = new c.b[0];
        this.l = new n.b();
        this.m = new n.a();
        h2.a = this;
        this.i = new k("ExoPlayerImplInternal:Handler");
        this.i.start();
        this.a = new Handler(this.i.getLooper(), (Handler.Callback)this);
    }

    private int a(int n2, n n3, n n4) {
        int n5 = -1;
        int n6 = n2;
        n2 = n5;
        while (n2 == -1 && n6 < n3.c() - 1) {
            n2 = n4.a(n3.a((int)(++n6), (n.a)this.m, (boolean)true).b);
        }
        return n2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private long a(int var1_1, long var2_2) {
        this.c();
        this.t = false;
        this.a(2);
        if (this.D != null) {
            var4_4 = this.D;
            var6_5 = null;
        } else {
            if (this.B != null) {
                this.B.d();
                var5_3 = null;
            } else {
                var5_3 = null;
            }
            do {
                if (this.D != var5_3 || this.D != this.C) {
                    var4_4 = this.r;
                    var7_6 = var4_4.length;
                    for (var1_1 = 0; var1_1 < var7_6; ++var1_1) {
                        var4_4[var1_1].n();
                    }
                    this.r = new c.b[0];
                    this.p = null;
                    this.o = null;
                    this.D = null;
                }
                if (var5_3 != null) {
                    var5_3.k = null;
                    this.B = var5_3;
                    this.C = var5_3;
                    this.b((a)var5_3);
                    var8_7 = var2_2;
                    if (this.D.j) {
                        var8_7 = this.D.a.a(var2_2);
                    }
                    this.a(var8_7);
                    this.g();
                    var2_2 = var8_7;
                } else {
                    this.B = null;
                    this.C = null;
                    this.D = null;
                    this.a(var2_2);
                }
                this.a.sendEmptyMessage(2);
                return var2_2;
                break;
            } while (true);
        }
        do {
            var5_3 = var6_5;
            if (var4_4 == null) ** continue;
            if (var4_4.f == var1_1 && var4_4.i) {
                var6_5 = var4_4;
            } else {
                var4_4.d();
            }
            var4_4 = var4_4.k;
        } while (true);
    }

    private Pair<Integer, Long> a(c c2) {
        n n2 = c2.a;
        if (n2.a()) {
            n2 = this.E;
        }
        try {
            Pair<Integer, Long> pair = this.b(n2, c2.b, c2.c);
            if (this.E == n2) {
                return pair;
            }
        }
        catch (IndexOutOfBoundsException var2_3) {
            throw new com.google.android.exoplayer2.g(this.E, c2.b, c2.c);
        }
        int n3 = this.E.a(n2.a((int)((Integer)pair.first).intValue(), (n.a)this.m, (boolean)true).b);
        if (n3 != -1) {
            return Pair.create((Object)n3, (Object)pair.second);
        }
        n3 = this.a((Integer)pair.first, n2, this.E);
        if (n3 != -1) {
            return this.b(this.E.a((int)n3, (n.a)this.m, (boolean)false).c);
        }
        return null;
    }

    private Pair<Integer, Long> a(n n2, int n3, long l2, long l3) {
        a.a.a.a.d.a(n3, n2.b());
        n2.a(n3, this.l, l3);
        l3 = l2;
        if (l2 == -9223372036854775807L) {
            l3 = l2 = this.l.h;
            if (l2 == -9223372036854775807L) {
                return null;
            }
        }
        n3 = this.l.f;
        l2 = n2.a((int)n3, (n.a)this.m, (boolean)false).d;
        for (l3 = this.l.j + l3; l2 != -9223372036854775807L && l3 >= l2 && n3 < this.l.g; l3 -= l2) {
            l2 = n2.a((int)(++n3), (n.a)this.m, (boolean)false).d;
        }
        return Pair.create((Object)n3, (Object)l3);
    }

    private void a(int n2) {
        if (this.v != n2) {
            this.v = n2;
            this.j.obtainMessage(1, n2, 0).sendToTarget();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(long l2) {
        l2 = this.D == null ? 60000000 + l2 : this.D.a() + l2;
        this.A = l2;
        this.h.a(this.A);
        c.b[] arrb = this.r;
        int n2 = arrb.length;
        int n3 = 0;
        while (n3 < n2) {
            arrb[n3].a(this.A);
            ++n3;
        }
    }

    private void a(long l2, long l3) {
        this.a.removeMessages(2);
        l2 = l2 + l3 - SystemClock.elapsedRealtime();
        if (l2 <= 0) {
            this.a.sendEmptyMessage(2);
            return;
        }
        this.a.sendEmptyMessageDelayed(2, l2);
    }

    private static void a(c.b b2) {
        if (b2.d() == 2) {
            b2.m();
        }
    }

    private static void a(a a2) {
        while (a2 != null) {
            a2.d();
            a2 = a2.k;
        }
    }

    private void a(Object object, int n2) {
        this.n = new b(0, 0);
        this.b(object, n2);
        this.n = new b(0, -9223372036854775807L);
        this.a(4);
        this.b(false);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(boolean bl2) {
        if (this.u != bl2) {
            this.u = bl2;
            Handler handler = this.j;
            int n2 = bl2 ? 1 : 0;
            handler.obtainMessage(2, n2, 0).sendToTarget();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(boolean[] arrbl, int n2) {
        this.r = new c.b[n2];
        int n3 = 0;
        n2 = 0;
        while (n2 < this.d.length) {
            c.b b2 = this.d[n2];
            Object object = this.D.m.b.b[n2];
            int n4 = n3;
            if (object != null) {
                this.r[n3] = b2;
                if (b2.d() == 0) {
                    l l2 = this.D.m.d[n2];
                    n4 = this.s && this.v == 3 ? 1 : 0;
                    boolean bl2 = !arrbl[n2] && n4 != 0;
                    Format[] arrformat = new Format[object.b()];
                    for (int i2 = 0; i2 < arrformat.length; ++i2) {
                        arrformat[i2] = object.a(i2);
                    }
                    b2.a(l2, arrformat, this.D.c[n2], this.A, bl2, this.D.a());
                    object = b2.c();
                    if (object != null) {
                        if (this.p != null) {
                            throw com.google.android.exoplayer2.b.a(new IllegalStateException("Multiple renderer media clocks enabled."));
                        }
                        this.p = object;
                        this.o = b2;
                    }
                    if (n4 != 0) {
                        b2.e();
                    }
                }
                n4 = n3 + 1;
            }
            ++n2;
            n3 = n4;
        }
    }

    private Pair<Integer, Long> b(int n2) {
        return this.b(this.E, n2, -9223372036854775807L);
    }

    private Pair<Integer, Long> b(n n2, int n3, long l2) {
        return this.a(n2, n3, l2, 0);
    }

    private void b() {
        int n2 = 0;
        this.t = false;
        c.b[] arrb = this.h;
        if (!arrb.a) {
            arrb.a = true;
            arrb.c = m.b(arrb.b);
        }
        arrb = this.r;
        int n3 = arrb.length;
        while (n2 < n3) {
            arrb[n2].e();
            ++n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(a a2) {
        if (this.D == a2) {
            return;
        }
        boolean[] arrbl = new boolean[this.d.length];
        int n2 = 0;
        int n3 = 0;
        do {
            if (n2 >= this.d.length) {
                this.D = a2;
                this.j.obtainMessage(3, (Object)a2.m).sendToTarget();
                this.a(arrbl, n3);
                return;
            }
            c.b b2 = this.d[n2];
            boolean bl2 = b2.d() != 0;
            arrbl[n2] = bl2;
            com.google.android.exoplayer2.g.f f2 = a2.m.b.b[n2];
            int n4 = n3;
            if (f2 != null) {
                n4 = n3 + 1;
            }
            if (arrbl[n2] && (f2 == null || b2.i() && b2.f() == this.D.c[n2])) {
                if (b2 == this.o) {
                    this.h.a(this.p.v());
                    this.p = null;
                    this.o = null;
                }
                e.a(b2);
                b2.n();
            }
            ++n2;
            n3 = n4;
        } while (true);
    }

    private void b(Object object, int n2) {
        this.j.obtainMessage(6, (Object)new d(this.E, object, this.n, n2)).sendToTarget();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void b(boolean var1_1) {
        this.a.removeMessages(2);
        this.t = false;
        this.h.a();
        this.p = null;
        this.o = null;
        this.A = 60000000;
        var3_2 = this.r;
        var5_3 = var3_2.length;
        var4_4 = 0;
        do {
            if (var4_4 >= var5_3) ** GOTO lbl19
            var2_6 = var3_2[var4_4];
            try {
                e.a(var2_6);
                var2_6.n();
            }
            catch (RuntimeException var2_7) {}
            ** GOTO lbl-1000
lbl19: // 1 sources:
            this.r = new c.b[0];
            if (this.D != null) {
                var2_9 = this.D;
            } else {
                var2_11 = this.B;
            }
            e.a((a)var2_10);
            this.B = null;
            this.C = null;
            this.D = null;
            this.a(false);
            if (var1_1 == false) return;
            if (this.q != null) {
                this.q.i = null;
                this.q = null;
            }
            this.E = null;
            return;
            catch (com.google.android.exoplayer2.b var2_12) {}
lbl-1000: // 2 sources:
            {
                Log.e((String)"ExoPlayerImplInternal", (String)"Stop failed.", (Throwable)var2_8);
            }
            ++var4_4;
        } while (true);
    }

    private boolean b(long l2) {
        if (l2 == -9223372036854775807L || this.n.c < l2 || this.D.k != null && this.D.k.i) {
            return true;
        }
        return false;
    }

    private void c() {
        this.h.a();
        c.b[] arrb = this.r;
        int n2 = arrb.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            e.a(arrb[i2]);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void d() {
        Object object;
        if (this.D == null) {
            return;
        }
        long l2 = this.D.a.g();
        if (l2 != -9223372036854775807L) {
            this.a(l2);
        } else {
            if (this.o != null && !this.o.l()) {
                this.A = this.p.v();
                this.h.a(this.A);
            } else {
                this.A = this.h.v();
            }
            object = this.D;
            l2 = this.A - object.a();
        }
        this.n.c = l2;
        this.x = SystemClock.elapsedRealtime() * 1000;
        l2 = this.r.length == 0 ? Long.MIN_VALUE : this.D.a.h();
        object = this.n;
        long l3 = l2;
        if (l2 == Long.MIN_VALUE) {
            l3 = this.E.a((int)this.D.f, (n.a)this.m, (boolean)false).d;
        }
        object.d = l3;
    }

    private void e() {
        this.b(true);
        this.g.a(true);
        this.a(1);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void f() {
        if (this.B == null || this.B.i || this.C != null && this.C.k != this.B) return;
        c.b[] arrb = this.r;
        int n2 = arrb.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            if (arrb[i2].g()) continue;
            return;
        }
        this.B.a.c();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void g() {
        long l2 = !this.B.i ? 0 : this.B.a.f();
        if (l2 == Long.MIN_VALUE) {
            this.a(false);
            return;
        }
        Object object = this.B;
        h h2 = this.g;
        int n2 = (l2 -= this.A - object.a()) > h2.c ? 0 : (l2 < h2.b ? 2 : 1);
        boolean bl2 = h2.a.d() >= h2.g;
        boolean bl3 = h2.h;
        boolean bl4 = n2 == 2 || n2 == 1 && h2.h && !bl2;
        h2.h = bl4;
        if (h2.f != null && h2.h != bl3) {
            if (h2.h) {
                FloatingActionButton var3_8 = h2.f;
                object = var3_8.k;
                synchronized (object) {
                    var3_8.l.add(0);
                    var3_8.m = Math.max(var3_8.m, 0);
                }
            } else {
                h2.f.c();
            }
        }
        bl4 = h2.h;
        this.a(bl4);
        if (bl4) {
            this.B.l = false;
            this.B.a.e();
            return;
        }
        this.B.l = true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a() {
        synchronized (this) {
            boolean bl2 = this.b;
            if (!bl2) {
                this.a.sendEmptyMessage(5);
                while (!(bl2 = this.b)) {
                    try {
                        this.wait();
                    }
                    catch (InterruptedException var1_2) {
                        Thread.currentThread().interrupt();
                    }
                }
                this.i.quit();
            }
            return;
        }
    }

    @Override
    public final void a(com.google.android.exoplayer2.e.d d2) {
        this.a.obtainMessage(7, (Object)d2).sendToTarget();
    }

    @Override
    public final void a(n n2) {
        this.a.obtainMessage(6, (Object)Pair.create((Object)n2, (Object)null)).sendToTarget();
    }

    public final void a(n n2, int n3, long l2) {
        this.a.obtainMessage(3, (Object)new c(n2, n3, l2)).sendToTarget();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final /* varargs */ void a(c.c ... arrc) {
        // MONITORENTER : this
        if (this.b) {
            Log.w((String)"ExoPlayerImplInternal", (String)"Ignoring messages sent after release.");
            return;
        }
        int n2 = this.c;
        this.c = n2 + 1;
        this.a.obtainMessage(10, (Object)arrc).sendToTarget();
        do {
            int n3;
            if ((n3 = this.w) > n2) {
                // MONITOREXIT : this
                return;
            }
            try {
                this.wait();
                continue;
            }
            catch (InterruptedException var1_2) {
                Thread.currentThread().interrupt();
                continue;
            }
            break;
        } while (true);
    }

    public final /* synthetic */ void b(com.google.android.exoplayer2.e.d d2) {
        this.a.obtainMessage(8, (Object)d2).sendToTarget();
    }

    /*
     * Exception decompiling
     */
    public final boolean handleMessage(Message var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    static final class a {
        public final com.google.android.exoplayer2.e.d a;
        public final Object b;
        public final com.google.android.exoplayer2.e.c[] c;
        public final boolean[] d;
        public final long e;
        public int f;
        public long g;
        public boolean h;
        public boolean i;
        public boolean j;
        public a k;
        public boolean l;
        public com.google.android.exoplayer2.g.i m;
        private final c.b[] n;
        private final com.google.android.exoplayer2.k[] o;
        private final com.google.android.exoplayer2.g.h p;
        private final h q;
        private final com.google.android.exoplayer2.e.b r;
        private com.google.android.exoplayer2.g.i s;

        /*
         * Enabled aggressive block sorting
         */
        public a(c.b[] object, com.google.android.exoplayer2.k[] arrk, long l2, com.google.android.exoplayer2.g.h h2, h h3, com.google.android.exoplayer2.e.b b2, Object object2, int n2, boolean bl2, long l3) {
            this.n = object;
            this.o = arrk;
            this.e = l2;
            this.p = h2;
            this.q = h3;
            this.r = b2;
            this.b = a.a.a.a.d.b(object2);
            this.f = n2;
            this.h = bl2;
            this.g = l3;
            this.c = new com.google.android.exoplayer2.e.c[object.length];
            this.d = new boolean[object.length];
            object = h3.a;
            bl2 = n2 == 0;
            a.a.a.a.d.a(bl2);
            this.a = new com.google.android.exoplayer2.e.a(b2.a, new com.whatsapp.h.a(b2.b.a), b2.c.a(), b2.d, b2.e, b2.f, b2, (com.google.android.exoplayer2.h.b)object, b2.h);
        }

        public final long a() {
            return this.e - this.g;
        }

        public final long a(long l2) {
            return this.a(l2, false, new boolean[this.n.length]);
        }

        /*
         * Enabled aggressive block sorting
         */
        public final long a(long l2, boolean bl2, boolean[] object) {
            int n2;
            boolean[] arrbl;
            int n3 = 0;
            com.google.android.exoplayer2.g.g g2 = this.m.b;
            for (n2 = 0; n2 < g2.a; ++n2) {
                arrbl = this.d;
                boolean bl3 = !bl2 && this.m.a(this.s, n2);
                arrbl[n2] = bl3;
            }
            l2 = this.a.a(g2.a(), this.d, this.c, (boolean[])object, l2);
            this.s = this.m;
            this.j = false;
            for (n2 = 0; n2 < this.c.length; ++n2) {
                if (this.c[n2] != null) {
                    bl2 = g2.b[n2] != null;
                    a.a.a.a.d.b(bl2);
                    this.j = true;
                    continue;
                }
                bl2 = g2.b[n2] == null;
                a.a.a.a.d.b(bl2);
            }
            object = this.q;
            arrbl = this.n;
            object.g = 0;
            n2 = n3;
            do {
                if (n2 >= arrbl.length) {
                    object.a.a(object.g);
                    return l2;
                }
                if (g2.b[n2] != null) {
                    object.g += o.c(arrbl[n2].a());
                }
                ++n2;
            } while (true);
        }

        public final void a(int n2, boolean bl2) {
            this.f = n2;
            this.h = bl2;
        }

        public final boolean b() {
            if (this.i && (!this.j || this.a.h() == Long.MIN_VALUE)) {
                return true;
            }
            return false;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public final boolean c() {
            var1_1 = this.p.a(this.o, this.a.d());
            var2_2 = this.s;
            if (var2_2 == null) {
                var3_3 = 0;
lbl5: // 2 sources:
                do {
                    if (var3_3 != 0) {
                        return false;
                    }
                    this.m = var1_1;
                    return true;
                    break;
                } while (true);
            }
            var3_3 = 0;
            while (var3_3 < var1_1.b.a) {
                if (!var1_1.a(var2_2, var3_3)) {
                    var3_3 = 0;
                    ** continue;
                }
                ++var3_3;
            }
            return false;
        }

        public final void d() {
            try {
                com.google.android.exoplayer2.e.a a2 = (com.google.android.exoplayer2.e.a)this.a;
                Object object = a2.d;
                g g2 = a2.c;
                object = new Runnable((a$b)object){
                    final /* synthetic */ a$b a;

                    @Override
                    public final void run() {
                        a$b b2 = this.a;
                        if (b2.a != null) {
                            b2.a = null;
                        }
                        int n2 = a.this.h.size();
                        for (int i2 = 0; i2 < n2; ++i2) {
                            ((com.google.android.exoplayer2.c.d)a.this.h.valueAt(i2)).a();
                        }
                    }
                };
                if (g2.b != null) {
                    g2.b.a(true);
                }
                g2.a.submit((Runnable)object);
                g2.a.shutdown();
                a2.g.removeCallbacksAndMessages((Object)null);
                a2.u = true;
                return;
            }
            catch (RuntimeException var1_2) {
                Log.e((String)"ExoPlayerImplInternal", (String)"Period release failed.", (Throwable)var1_2);
                return;
            }
        }
    }

    public static final class b {
        public final int a;
        public final long b;
        public volatile long c;
        public volatile long d;

        public b(int n2, long l2) {
            this.a = n2;
            this.b = l2;
            this.c = l2;
            this.d = l2;
        }
    }

    static final class c {
        public final n a;
        public final int b;
        public final long c;

        public c(n n2, int n3, long l2) {
            this.a = n2;
            this.b = n3;
            this.c = l2;
        }
    }

    public static final class d {
        public final n a;
        public final Object b;
        public final b c;
        public final int d;

        public d(n n2, Object object, b b2, int n3) {
            this.a = n2;
            this.b = object;
            this.c = b2;
            this.d = n3;
        }
    }

}

