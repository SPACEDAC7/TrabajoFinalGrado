/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.MediaCodec
 *  android.media.MediaCodec$CryptoInfo
 *  android.net.Uri
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.SystemClock
 *  android.util.SparseArray
 */
package com.google.android.exoplayer2.e;

import android.media.MediaCodec;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.support.design.widget.AppBarLayout;
import android.util.SparseArray;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.c.d;
import com.google.android.exoplayer2.c.l;
import com.google.android.exoplayer2.c.m;
import com.google.android.exoplayer2.e.b;
import com.google.android.exoplayer2.e.d;
import com.google.android.exoplayer2.e.e;
import com.google.android.exoplayer2.e.f;
import com.google.android.exoplayer2.e.g;
import com.google.android.exoplayer2.e.h;
import com.google.android.exoplayer2.h.g;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.n;
import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.LinkedBlockingDeque;

public final class a
implements d.c,
com.google.android.exoplayer2.c.h,
d,
g.a<a> {
    private final com.google.android.exoplayer2.h.b A;
    private final Runnable B;
    private boolean C;
    private int D;
    private long E;
    private long F;
    private int G;
    final b.a a;
    final String b;
    public final com.google.android.exoplayer2.h.g c;
    public final b d;
    final com.google.android.exoplayer2.i.c e;
    final Runnable f;
    public final Handler g;
    final SparseArray<com.google.android.exoplayer2.c.d> h;
    d.a i;
    m j;
    boolean k;
    boolean l;
    boolean m;
    g n;
    long o;
    boolean[] p;
    boolean[] q;
    boolean r;
    long s;
    boolean t;
    public boolean u;
    private final Uri v;
    private final com.google.android.exoplayer2.h.d w;
    private final int x;
    private final Handler y;
    private final AppBarLayout.b z;

    public a(Uri uri, com.google.android.exoplayer2.h.d d2, com.google.android.exoplayer2.c.f[] arrf, int n2, Handler handler, AppBarLayout.b b2, b.a a2, com.google.android.exoplayer2.h.b b3, String string) {
        this.v = uri;
        this.w = d2;
        this.x = n2;
        this.y = handler;
        this.z = b2;
        this.a = a2;
        this.A = b3;
        this.b = string;
        this.c = new com.google.android.exoplayer2.h.g("Loader:ExtractorMediaPeriod");
        this.d = new b(arrf, this);
        this.e = new com.google.android.exoplayer2.i.c();
        this.B = new Runnable(){

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final void run() {
                int n2;
                a a2 = a.this;
                if (a2.u || a2.l || a2.j == null || !a2.k) return;
                int n3 = a2.h.size();
                for (n2 = 0; n2 < n3; ++n2) {
                    if (((com.google.android.exoplayer2.c.d)a2.h.valueAt((int)n2)).b.c() == null) return;
                    {
                        continue;
                    }
                }
                a2.e.b();
                f[] arrf = new f[n3];
                a2.q = new boolean[n3];
                a2.p = new boolean[n3];
                a2.o = a2.j.b();
                n2 = 0;
                do {
                    if (n2 >= n3) {
                        a2.n = new g(arrf);
                        a2.l = true;
                        a2.a.a(new e(a2.o, a2.j.b_()));
                        a2.i.a(a2);
                        return;
                    }
                    Object object = ((com.google.android.exoplayer2.c.d)a2.h.valueAt((int)n2)).b.c();
                    arrf[n2] = new f(new Format[]{object});
                    object = object.f;
                    boolean bl2 = a.a.a.a.d.e((String)object) || a.a.a.a.d.d((String)object);
                    a2.q[n2] = bl2;
                    a2.r = bl2 | a2.r;
                    ++n2;
                } while (true);
            }
        };
        this.f = new Runnable(){

            @Override
            public final void run() {
                if (!a.this.u) {
                    a.this.i.b(a.this);
                }
            }
        };
        this.g = new Handler();
        this.F = -9223372036854775807L;
        this.h = new SparseArray();
        this.E = -1;
    }

    @Override
    private void a(a a2) {
        if (this.E == -1) {
            this.E = a2.a;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void k() {
        int n2;
        a a2 = new a(this.v, this.w, this.d, this.e);
        if (this.l) {
            a.a.a.a.d.b(this.j());
            if (this.o != -9223372036854775807L && this.F >= this.o) {
                this.t = true;
                this.F = -9223372036854775807L;
                return;
            }
            a2.a(this.j.a(this.F), this.F);
            this.F = -9223372036854775807L;
        }
        this.G = this.l();
        int n3 = n2 = this.x;
        if (n2 == -1) {
            n3 = !this.l || this.E != -1 || this.j != null && this.j.b() != -9223372036854775807L ? 3 : 6;
        }
        com.google.android.exoplayer2.h.g g2 = this.c;
        Looper looper = Looper.myLooper();
        boolean bl2 = looper != null;
        a.a.a.a.d.b(bl2);
        new g.b(g2, looper, (g.c)a2, (g.a)this, n3, SystemClock.elapsedRealtime()).a(0);
    }

    private int l() {
        int n2 = this.h.size();
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            n3 += ((com.google.android.exoplayer2.c.d)this.h.valueAt((int)i2)).b.a();
        }
        return n3;
    }

    private long m() {
        long l2 = Long.MIN_VALUE;
        int n2 = this.h.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            l2 = Math.max(l2, ((com.google.android.exoplayer2.c.d)this.h.valueAt((int)i2)).b.d());
        }
        return l2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final /* synthetic */ int a(g.c c2, IOException object) {
        int n2;
        int n3 = 1;
        c2 = (a)c2;
        this.a((a)c2);
        if (this.y != null && this.z != null) {
            this.y.post(new Runnable((IOException)object){
                final /* synthetic */ IOException a;

                @Override
                public final void run() {
                }
            });
        }
        if (object instanceof h) {
            return 3;
        }
        boolean bl2 = this.l() > this.G;
        if (this.E == -1 && (this.j == null || this.j.b() == -9223372036854775807L)) {
            this.s = 0;
            this.m = this.l;
            int n4 = this.h.size();
            for (n2 = 0; n2 < n4; ++n2) {
                object = (com.google.android.exoplayer2.c.d)this.h.valueAt(n2);
                boolean bl3 = !this.l || this.p[n2];
                object.a(bl3);
            }
            c2.a(0, 0);
        }
        this.G = this.l();
        n2 = n3;
        if (bl2) return n2;
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a(long l2) {
        block8 : {
            if (!this.j.b_()) {
                l2 = 0;
            }
            this.s = l2;
            int n2 = this.h.size();
            boolean bl2 = !this.j();
            int n3 = 0;
            while (bl2) {
                if (n3 < n2) {
                    if (this.p[n3]) {
                        bl2 = ((com.google.android.exoplayer2.c.d)this.h.valueAt(n3)).a(l2);
                    }
                    ++n3;
                    continue;
                }
                break block8;
            }
            if (!bl2) {
                this.F = l2;
                this.t = false;
                if (this.c.a()) {
                    this.c.b();
                } else {
                    for (n3 = 0; n3 < n2; ++n3) {
                        ((com.google.android.exoplayer2.c.d)this.h.valueAt(n3)).a(this.p[n3]);
                    }
                }
            }
        }
        this.m = false;
        return l2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final long a(com.google.android.exoplayer2.g.f[] var1_1, boolean[] var2_2, com.google.android.exoplayer2.e.c[] var3_3, boolean[] var4_4, long var5_5) {
        var9_6 = 0;
        a.a.a.a.d.b(this.l);
        for (var7_7 = 0; var7_7 < var1_1.length; ++var7_7) {
            if (var3_3[var7_7] == null || var1_1[var7_7] != null && var2_2[var7_7] != false) continue;
            var8_8 = ((c)var3_3[var7_7]).a;
            a.a.a.a.d.b(this.p[var8_8]);
            --this.D;
            this.p[var8_8] = false;
            ((com.google.android.exoplayer2.c.d)this.h.valueAt(var8_8)).a();
            var3_3[var7_7] = null;
        }
        var7_7 = 0;
        for (var8_8 = 0; var8_8 < var1_1.length; ++var8_8) {
            if (var3_3[var8_8] != null || var1_1[var8_8] == null) continue;
            var2_2 = var1_1[var8_8];
            var13_9 = var2_2.b() == 1;
            a.a.a.a.d.b(var13_9);
            var13_9 = var2_2.b(0) == 0;
            a.a.a.a.d.b(var13_9);
            var7_7 = this.n.a(var2_2.a());
            var13_9 = this.p[var7_7] == false;
            a.a.a.a.d.b(var13_9);
            ++this.D;
            this.p[var7_7] = true;
            var3_3[var8_8] = new c(var7_7);
            var4_4[var8_8] = true;
            var7_7 = 1;
        }
        if (!this.C) {
            var10_10 = this.h.size();
            for (var8_8 = 0; var8_8 < var10_10; ++var8_8) {
                if (this.p[var8_8]) continue;
                ((com.google.android.exoplayer2.c.d)this.h.valueAt(var8_8)).a();
            }
        }
        if (this.D != 0) ** GOTO lbl42
        this.m = false;
        var11_11 = var5_5;
        if (this.c.a()) {
            this.c.b();
            var11_11 = var5_5;
        }
        ** GOTO lbl57
lbl42: // 1 sources:
        if (!this.C) ** GOTO lbl46
        var11_11 = var5_5;
        if (var7_7 == 0) ** GOTO lbl57
        ** GOTO lbl-1000
lbl46: // 1 sources:
        var11_11 = var5_5;
        if (var5_5 != 0) lbl-1000: // 2 sources:
        {
            var5_5 = this.a(var5_5);
            var7_7 = var9_6;
            do {
                var11_11 = var5_5;
                if (var7_7 >= var3_3.length) break;
                if (var3_3[var7_7] != null) {
                    var4_4[var7_7] = true;
                }
                ++var7_7;
            } while (true);
        }
lbl57: // 5 sources:
        this.C = true;
        return var11_11;
    }

    @Override
    public final com.google.android.exoplayer2.c.n a(int n2) {
        com.google.android.exoplayer2.c.d d2;
        com.google.android.exoplayer2.c.d d3 = d2 = (com.google.android.exoplayer2.c.d)this.h.get(n2);
        if (d2 == null) {
            d3 = new com.google.android.exoplayer2.c.d(this.A);
            d3.h = this;
            this.h.put(n2, (Object)d3);
        }
        return d3;
    }

    @Override
    public final void a() {
        this.g.post(this.B);
    }

    @Override
    public final void a(m m2) {
        this.j = m2;
        this.g.post(this.B);
    }

    @Override
    public final void a(d.a a2) {
        this.i = a2;
        this.e.a();
        this.k();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final /* synthetic */ void a(g.c c2) {
        this.a((a)c2);
        this.t = true;
        if (this.o == -9223372036854775807L) {
            long l2 = this.m();
            l2 = l2 == Long.MIN_VALUE ? 0 : (l2 += 10000);
            this.o = l2;
            this.a.a(new e(this.o, this.j.b_()));
        }
    }

    @Override
    public final /* synthetic */ void a(g.c c2, boolean bl2) {
        this.a((a)c2);
        if (!bl2 && this.D > 0) {
            int n2 = this.h.size();
            for (int i2 = 0; i2 < n2; ++i2) {
                ((com.google.android.exoplayer2.c.d)this.h.valueAt(i2)).a(this.p[i2]);
            }
            this.i.b(this);
        }
    }

    @Override
    public final void b() {
        this.k = true;
        this.g.post(this.B);
    }

    @Override
    public final void c() {
        this.i();
    }

    @Override
    public final g d() {
        return this.n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final boolean e() {
        if (this.t) return false;
        if (this.l && this.D == 0) {
            return false;
        }
        boolean bl2 = this.e.a();
        if (this.c.a()) return bl2;
        this.k();
        return true;
    }

    @Override
    public final long f() {
        if (this.D == 0) {
            return Long.MIN_VALUE;
        }
        return this.h();
    }

    @Override
    public final long g() {
        if (this.m) {
            this.m = false;
            return this.s;
        }
        return -9223372036854775807L;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long h() {
        long l2;
        if (this.t) {
            return Long.MIN_VALUE;
        }
        if (this.j()) {
            return this.F;
        }
        if (this.r) {
            l2 = Long.MAX_VALUE;
            int n2 = this.h.size();
            for (int i2 = 0; i2 < n2; ++i2) {
                if (!this.q[i2]) continue;
                l2 = Math.min(l2, ((com.google.android.exoplayer2.c.d)this.h.valueAt((int)i2)).b.d());
            }
        } else {
            l2 = this.m();
        }
        long l3 = l2;
        if (l2 != Long.MIN_VALUE) return l3;
        return this.s;
    }

    final void i() {
        com.google.android.exoplayer2.h.g g2 = this.c;
        if (g2.c != null) {
            throw g2.c;
        }
        if (g2.b != null) {
            g.b<? extends g.c> b2 = g2.b;
            int n2 = g2.b.a;
            if (b2.b != null && b2.c > n2) {
                throw b2.b;
            }
        }
    }

    final boolean j() {
        if (this.F != -9223372036854775807L) {
            return true;
        }
        return false;
    }

    final class a
    implements g.c {
        long a;
        private final Uri c;
        private final com.google.android.exoplayer2.h.d d;
        private final b e;
        private final com.google.android.exoplayer2.i.c f;
        private final l g;
        private volatile boolean h;
        private boolean i;
        private long j;

        public a(Uri uri, com.google.android.exoplayer2.h.d d2, b b2, com.google.android.exoplayer2.i.c c2) {
            this.c = a.a.a.a.d.b(uri);
            this.d = a.a.a.a.d.b(d2);
            this.e = a.a.a.a.d.b(b2);
            this.f = c2;
            this.g = new l();
            this.i = true;
            this.a = -1;
        }

        @Override
        public final void a() {
            this.h = true;
        }

        public final void a(long l2, long l3) {
            this.g.a = l2;
            this.j = l3;
            this.i = true;
        }

        @Override
        public final boolean b() {
            return this.h;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive exception aggregation
         */
        @Override
        public final void c() {
            var4_1 = 0;
            block8 : while (var4_1 == 0 && !this.h) {
                block15 : {
                    var6_7 = this.g.a;
                    this.a = this.d.a(new com.google.android.exoplayer2.h.e(this.c, var6_7, a.this.b));
                    if (this.a != -1) {
                        this.a += var6_7;
                    }
                    var1_2 = new com.google.android.exoplayer2.c.b(this.d, var6_7, this.a);
                    var2_4 = this.e.a((com.google.android.exoplayer2.c.g)var1_2, this.d.a());
                    if (!this.i) break block15;
                    var2_4.a(var6_7, this.j);
                    this.i = false;
                }
                while (var4_1 == 0) {
                    if (this.h) break;
                    this.f.c();
                    var4_1 = var5_6 = var2_4.a((com.google.android.exoplayer2.c.g)var1_2, this.g);
                    if (var1_2.c() <= 0x100000 + var6_7) continue;
                    var6_7 = var1_2.c();
                    this.f.b();
                    a.this.g.post(a.this.f);
                    continue;
                }
                if (var4_1 == 1) {
                    var4_1 = 0;
lbl28: // 2 sources:
                    do {
                        o.a(this.d);
                        continue block8;
                        break;
                    } while (true);
                }
                this.g.a = var1_2.c();
                ** continue;
                catch (Throwable var1_3) {
                    var2_4 = null;
lbl35: // 4 sources:
                    do {
                        if (var4_1 != 1 && var2_4 != null) {
                            this.g.a = var2_4.c();
                        }
                        o.a(this.d);
                        throw var1_2;
                        break;
                    } while (true);
                }
            }
            return;
            catch (Throwable var2_5) {
                var3_8 = var1_2;
                var1_2 = var2_5;
                var2_4 = var3_8;
                ** GOTO lbl35
            }
            catch (Throwable var3_9) {
                var2_4 = var1_2;
                var1_2 = var3_9;
                ** GOTO lbl35
            }
            catch (Throwable var3_10) {
                var2_4 = var1_2;
                var1_2 = var3_10;
                ** continue;
            }
        }
    }

    static final class b {
        com.google.android.exoplayer2.c.f a;
        private final com.google.android.exoplayer2.c.f[] b;
        private final com.google.android.exoplayer2.c.h c;

        public b(com.google.android.exoplayer2.c.f[] arrf, com.google.android.exoplayer2.c.h h2) {
            this.b = arrf;
            this.c = h2;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public final com.google.android.exoplayer2.c.f a(com.google.android.exoplayer2.c.g g2, Uri uri) {
            if (this.a != null) {
                return this.a;
            }
            for (com.google.android.exoplayer2.c.f f2 : this.b) {
                try {
                    if (!f2.a(g2)) continue;
                    this.a = f2;
                    break;
                }
                catch (EOFException var4_8) {}
                continue;
                finally {
                    g2.a();
                }
            }
            if (this.a == null) {
                throw new h("None of the available extractors (" + o.a(this.b) + ") could read the stream.", uri);
            }
            this.a.a(this.c);
            return this.a;
        }
    }

    final class c
    implements com.google.android.exoplayer2.e.c {
        final int a;

        public c(int n2) {
            this.a = n2;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int a(com.google.android.exoplayer2.f arrn, com.google.android.exoplayer2.b.e object) {
            long l2;
            int n2;
            int[] arrn2 = a.this;
            int n3 = this.a;
            if (arrn2.m || arrn2.j()) {
                return -3;
            }
            com.google.android.exoplayer2.c.d d2 = (com.google.android.exoplayer2.c.d)arrn2.h.valueAt(n3);
            boolean bl2 = arrn2.t;
            long l3 = arrn2.s;
            switch (d2.b.a((com.google.android.exoplayer2.f)arrn, (com.google.android.exoplayer2.b.e)object, d2.g, d2.d)) {
                default: {
                    throw new IllegalStateException();
                }
                case -3: {
                    if (bl2) {
                        object.a = 4;
                        return -4;
                    }
                    return -3;
                }
                case -5: {
                    d2.g = arrn.a;
                    return -5;
                }
                case -4: 
            }
            if (object.d < l3) {
                object.a(Integer.MIN_VALUE);
            }
            if (object.e()) {
                Object object2;
                block23 : {
                    block22 : {
                        d.a a2 = d2.d;
                        l3 = a2.b;
                        d2.e.a(1);
                        d2.a(l3, d2.e.a, 1);
                        l3 = 1 + l3;
                        n2 = d2.e.a[0];
                        n3 = (n2 & 128) != 0 ? 1 : 0;
                        n2 &= 127;
                        if (object.b.a == null) {
                            object.b.a = new byte[16];
                        }
                        d2.a(l3, object.b.a, n2);
                        l3 += (long)n2;
                        if (n3 != 0) {
                            d2.e.a(2);
                            d2.a(l3, d2.e.a, 2);
                            l3 += 2;
                            n2 = d2.e.f();
                        } else {
                            n2 = 1;
                        }
                        if ((arrn2 = object.b.d) != null) {
                            arrn = arrn2;
                            if (arrn2.length >= n2) break block22;
                        }
                        arrn = new int[n2];
                    }
                    if ((object2 = object.b.e) != null) {
                        arrn2 = object2;
                        if (object2.length >= n2) break block23;
                    }
                    arrn2 = new int[n2];
                }
                if (n3 != 0) {
                    n3 = n2 * 6;
                    d2.e.a(n3);
                    d2.a(l3, d2.e.a, n3);
                    l2 = n3;
                    d2.e.c(0);
                    for (n3 = 0; n3 < n2; ++n3) {
                        arrn[n3] = d2.e.f();
                        arrn2[n3] = d2.e.o();
                    }
                    l3 += l2;
                } else {
                    arrn[0] = 0;
                    arrn2[0] = a2.a - (int)(l3 - a2.b);
                }
                object2 = object.b;
                byte[] arrby = a2.d;
                byte[] arrby2 = object.b.a;
                object2.f = n2;
                object2.d = arrn;
                object2.e = arrn2;
                object2.b = arrby;
                object2.a = arrby2;
                object2.c = 1;
                if (o.a >= 16) {
                    object2.g.set(object2.f, object2.d, object2.e, object2.b, object2.a, object2.c);
                }
                n3 = (int)(l3 - a2.b);
                a2.b += (long)n3;
                a2.a -= n3;
            }
            object.c(d2.d.a);
            l3 = d2.d.b;
            arrn = object.c;
            n3 = d2.d.a;
            do {
                if (n3 <= 0) {
                    d2.b(d2.d.c);
                    return -4;
                }
                d2.b(l3);
                n2 = (int)(l3 - d2.f);
                int n4 = Math.min(n3, d2.a - n2);
                object = d2.c.peek();
                arrn.put(object.a, object.b + n2, n4);
                l2 = n4;
                n3 -= n4;
                l3 = l2 + l3;
            } while (true);
        }

        @Override
        public final void a(long l2) {
            ((com.google.android.exoplayer2.c.d)a.this.h.valueAt(this.a)).a(l2);
        }

        @Override
        public final boolean a() {
            a a2 = a.this;
            int n2 = this.a;
            if (a2.t || !a2.j() && !((com.google.android.exoplayer2.c.d)a2.h.valueAt((int)n2)).b.b()) {
                return true;
            }
            return false;
        }

        @Override
        public final void b() {
            a.this.i();
        }
    }

}

