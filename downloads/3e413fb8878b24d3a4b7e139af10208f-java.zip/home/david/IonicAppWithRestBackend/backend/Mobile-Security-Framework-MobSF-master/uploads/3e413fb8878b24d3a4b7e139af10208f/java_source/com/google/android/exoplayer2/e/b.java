/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Handler
 */
package com.google.android.exoplayer2.e;

import android.net.Uri;
import android.os.Handler;
import android.support.design.widget.AppBarLayout;
import com.google.android.exoplayer2.c.i;
import com.google.android.exoplayer2.h.d;
import com.google.android.exoplayer2.n;

public final class b
implements a {
    public final Uri a;
    public final d.a b;
    public final i c;
    public final int d;
    public final Handler e;
    public final AppBarLayout.b f;
    final n.a g;
    public final String h;
    public a i;
    public n j;
    boolean k;

    public b(Uri uri, d.a a2, i i2, Handler handler) {
        this(uri, a2, i2, handler, 0);
    }

    private b(Uri uri, d.a a2, i i2, Handler handler, byte by2) {
        this.a = uri;
        this.b = a2;
        this.c = i2;
        this.d = -1;
        this.e = handler;
        this.f = null;
        this.h = null;
        this.g = new n.a();
    }

    @Override
    public final void a(n n2) {
        boolean bl2 = false;
        if (n2.a((int)0, (n.a)this.g, (boolean)false).d != -9223372036854775807L) {
            bl2 = true;
        }
        if (this.k && !bl2) {
            return;
        }
        this.j = n2;
        this.k = bl2;
        this.i.a(this.j);
    }

    public static interface a {
        public void a(n var1);
    }

}

