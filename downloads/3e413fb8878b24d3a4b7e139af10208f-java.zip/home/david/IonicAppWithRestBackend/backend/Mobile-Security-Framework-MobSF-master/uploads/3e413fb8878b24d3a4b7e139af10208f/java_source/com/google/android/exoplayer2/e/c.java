/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.e;

import com.google.android.exoplayer2.b.e;
import com.google.android.exoplayer2.f;

public interface c {
    public int a(f var1, e var2);

    public void a(long var1);

    public boolean a();

    public void b();
}

