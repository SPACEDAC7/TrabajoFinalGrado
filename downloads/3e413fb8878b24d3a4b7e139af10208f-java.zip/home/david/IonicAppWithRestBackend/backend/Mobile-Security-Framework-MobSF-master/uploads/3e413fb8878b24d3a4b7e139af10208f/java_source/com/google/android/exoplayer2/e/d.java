/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.e;

import com.google.android.exoplayer2.e.c;
import com.google.android.exoplayer2.e.g;
import com.google.android.exoplayer2.g.f;

public interface d {
    public long a(long var1);

    public long a(f[] var1, boolean[] var2, c[] var3, boolean[] var4, long var5);

    public void a(a var1);

    public void c();

    public g d();

    public boolean e();

    public long f();

    public long g();

    public long h();

    public static interface a
    extends a<d> {
        public void a(d var1);

        public void b(T var1);
    }

}

