/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.e;

import a.a.a.a.d;
import com.google.android.exoplayer2.n;

public final class e
extends n {
    private static final Object b = new Object();
    private final long c;
    private final long d;
    private final long e;
    private final long f;
    private final boolean g;
    private final boolean h;

    private e(long l2, long l3, boolean bl2) {
        this.c = l2;
        this.d = l3;
        this.e = 0;
        this.f = 0;
        this.g = bl2;
        this.h = false;
    }

    public e(long l2, boolean bl2) {
        this(l2, l2, bl2);
    }

    @Override
    public final int a(Object object) {
        if (b.equals(object)) {
            return 0;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final n.a a(int n2, n.a a2, boolean bl2) {
        d.a(n2, 1);
        Object object = bl2 ? b : null;
        long l2 = this.c;
        long l3 = - this.e;
        a2.a = object;
        a2.b = object;
        a2.c = 0;
        a2.d = l2;
        a2.e = l3;
        return a2;
    }

    @Override
    public final n.b a(int n2, n.b b2, long l2) {
        long l3;
        d.a(n2, 1);
        long l4 = l3 = this.f;
        if (this.h) {
            l4 = l2 = l3 + l2;
            if (l2 > this.d) {
                l4 = -9223372036854775807L;
            }
        }
        boolean bl2 = this.g;
        boolean bl3 = this.h;
        l2 = this.d;
        l3 = this.e;
        b2.a = null;
        b2.b = -9223372036854775807L;
        b2.c = -9223372036854775807L;
        b2.d = bl2;
        b2.e = bl3;
        b2.h = l4;
        b2.i = l2;
        b2.f = 0;
        b2.g = 0;
        b2.j = l3;
        return b2;
    }

    @Override
    public final int b() {
        return 1;
    }

    @Override
    public final int c() {
        return 1;
    }
}

