/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.e;

import a.a.a.a.d;
import com.google.android.exoplayer2.Format;
import java.util.Arrays;

public final class f {
    public final int a;
    public final Format[] b;
    private int c;

    public /* varargs */ f(Format ... arrformat) {
        d.b(true);
        this.b = arrformat;
        this.a = 1;
    }

    public final int a(Format format) {
        for (int i2 = 0; i2 < this.b.length; ++i2) {
            if (format != this.b[i2]) continue;
            return i2;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (f)object;
        if (this.a != object.a) return false;
        if (Arrays.equals(this.b, object.b)) return true;
        return false;
    }

    public final int hashCode() {
        if (this.c == 0) {
            this.c = Arrays.hashCode(this.b) + 527;
        }
        return this.c;
    }
}

