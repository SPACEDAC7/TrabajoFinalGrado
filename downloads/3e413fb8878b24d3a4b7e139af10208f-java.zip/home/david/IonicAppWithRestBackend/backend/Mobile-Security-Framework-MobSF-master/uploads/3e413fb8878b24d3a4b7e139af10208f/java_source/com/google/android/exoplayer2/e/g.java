/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.e;

import com.google.android.exoplayer2.e.f;
import java.util.Arrays;

public final class g {
    public static final g a = new g(new f[0]);
    public final int b;
    public final f[] c;
    private int d;

    public /* varargs */ g(f ... arrf) {
        this.c = arrf;
        this.b = arrf.length;
    }

    public final int a(f f2) {
        for (int i2 = 0; i2 < this.b; ++i2) {
            if (this.c[i2] != f2) continue;
            return i2;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (g)object;
        if (this.b != object.b) return false;
        if (Arrays.equals(this.c, object.c)) return true;
        return false;
    }

    public final int hashCode() {
        if (this.d == 0) {
            this.d = Arrays.hashCode(this.c);
        }
        return this.d;
    }
}

