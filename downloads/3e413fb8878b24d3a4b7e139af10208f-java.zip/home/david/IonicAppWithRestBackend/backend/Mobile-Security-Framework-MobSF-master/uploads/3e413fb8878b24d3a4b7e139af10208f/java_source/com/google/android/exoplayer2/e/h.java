/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.google.android.exoplayer2.e;

import android.net.Uri;
import com.google.android.exoplayer2.i;

public final class h
extends i {
    public final Uri a;

    public h(String string, Uri uri) {
        super(string);
        this.a = uri;
    }
}

