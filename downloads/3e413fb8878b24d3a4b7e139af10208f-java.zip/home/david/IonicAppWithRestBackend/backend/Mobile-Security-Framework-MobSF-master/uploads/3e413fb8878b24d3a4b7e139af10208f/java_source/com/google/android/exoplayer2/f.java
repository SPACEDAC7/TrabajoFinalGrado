/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

import com.google.android.exoplayer2.Format;

public final class f {
    public Format a;
}

