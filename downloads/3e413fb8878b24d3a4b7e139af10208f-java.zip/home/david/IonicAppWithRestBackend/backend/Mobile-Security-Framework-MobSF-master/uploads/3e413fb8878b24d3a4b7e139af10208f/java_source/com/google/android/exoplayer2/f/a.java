/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.Typeface
 *  android.view.accessibility.CaptioningManager
 *  android.view.accessibility.CaptioningManager$CaptionStyle
 */
package com.google.android.exoplayer2.f;

import android.annotation.TargetApi;
import android.graphics.Typeface;
import android.view.accessibility.CaptioningManager;
import com.google.android.exoplayer2.i.o;

public final class a {
    public static final a a = new a(-1, -16777216, 0, 0, -1, null);
    public final int b;
    public final int c;
    public final int d;
    public final int e;
    public final int f;
    public final Typeface g;

    private a(int n2, int n3, int n4, int n5, int n6, Typeface typeface) {
        this.b = n2;
        this.c = n3;
        this.d = n4;
        this.e = n5;
        this.f = n6;
        this.g = typeface;
    }

    /*
     * Enabled aggressive block sorting
     */
    @TargetApi(value=19)
    public static a a(CaptioningManager.CaptionStyle captionStyle) {
        int n2;
        if (o.a < 21) return new a(captionStyle.foregroundColor, captionStyle.backgroundColor, 0, captionStyle.edgeType, captionStyle.edgeColor, captionStyle.getTypeface());
        int n3 = captionStyle.hasForegroundColor() ? captionStyle.foregroundColor : a.a.b;
        int n4 = captionStyle.hasBackgroundColor() ? captionStyle.backgroundColor : a.a.c;
        int n5 = captionStyle.hasWindowColor() ? captionStyle.windowColor : a.a.d;
        int n6 = captionStyle.hasEdgeType() ? captionStyle.edgeType : a.a.e;
        if (captionStyle.hasEdgeColor()) {
            n2 = captionStyle.edgeColor;
            return new a(n3, n4, n5, n6, n2, captionStyle.getTypeface());
        }
        n2 = a.a.f;
        return new a(n3, n4, n5, n6, n2, captionStyle.getTypeface());
    }
}

