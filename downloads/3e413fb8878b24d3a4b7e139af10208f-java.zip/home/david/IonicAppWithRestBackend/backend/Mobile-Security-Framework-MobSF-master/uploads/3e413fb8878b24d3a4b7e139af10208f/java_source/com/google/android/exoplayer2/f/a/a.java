/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.SpannableString
 *  android.text.SpannableStringBuilder
 *  android.text.style.CharacterStyle
 *  android.text.style.UnderlineSpan
 */
package com.google.android.exoplayer2.f.a;

import android.text.Layout;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.CharacterStyle;
import android.text.style.UnderlineSpan;
import com.google.android.exoplayer2.f.a.d;
import com.google.android.exoplayer2.f.a.f;
import com.google.android.exoplayer2.f.b;
import com.google.android.exoplayer2.f.e;
import com.google.android.exoplayer2.f.i;
import com.google.android.exoplayer2.f.j;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public final class a
extends d {
    private static final int[] b = new int[]{11, 1, 3, 12, 14, 5, 7, 9};
    private static final int[] c = new int[]{0, 4, 8, 12, 16, 20, 24, 28};
    private static final int[] d = new int[]{-1, -16711936, -16776961, -16711681, -65536, -256, -65281};
    private static final int[] e = new int[]{32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 225, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 233, 93, 237, 243, 250, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 231, 247, 209, 241, 9632};
    private static final int[] f = new int[]{174, 176, 189, 191, 8482, 162, 163, 9834, 224, 32, 232, 226, 234, 238, 244, 251};
    private static final int[] g = new int[]{193, 201, 211, 218, 220, 252, 8216, 161, 42, 39, 8212, 169, 8480, 8226, 8220, 8221, 192, 194, 199, 200, 202, 203, 235, 206, 207, 239, 212, 217, 249, 219, 171, 187};
    private static final int[] h = new int[]{195, 227, 205, 204, 236, 210, 242, 213, 245, 123, 125, 92, 94, 95, 124, 126, 196, 228, 214, 246, 223, 165, 164, 9474, 197, 229, 216, 248, 9484, 9488, 9492, 9496};
    private final com.google.android.exoplayer2.i.i i;
    private final int j;
    private final int k;
    private final LinkedList<a> l;
    private a m;
    private List<b> n;
    private List<b> o;
    private int p;
    private int q;
    private boolean r;
    private byte s;
    private byte t;

    /*
     * Exception decompiling
     */
    public a(String var1_1, int var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:486)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private static char a(byte by2) {
        return (char)e[(by2 & 127) - 32];
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    private void a(int n2) {
        if (this.p == n2) {
            return;
        }
        this.p = n2;
        this.j();
        if (n2 != 1) {
            if (n2 != 0) return;
        }
        this.n = null;
    }

    private List<b> i() {
        ArrayList<b> arrayList = new ArrayList<b>();
        for (int i2 = 0; i2 < this.l.size(); ++i2) {
            b b2 = this.l.get(i2).d();
            if (b2 == null) continue;
            arrayList.add(b2);
        }
        return arrayList;
    }

    private void j() {
        this.m.a(this.p, this.q);
        this.l.clear();
        this.l.add(this.m);
    }

    /*
     * Exception decompiling
     */
    @Override
    protected final void a(i var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[SWITCH]], but top level block is 7[SWITCH]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public final void c() {
        super.c();
        this.n = null;
        this.o = null;
        this.a(0);
        this.j();
        this.q = 4;
        this.r = false;
        this.s = 0;
        this.t = 0;
    }

    @Override
    public final void d() {
    }

    @Override
    protected final boolean e() {
        if (this.n != this.o) {
            return true;
        }
        return false;
    }

    @Override
    protected final e f() {
        this.o = this.n;
        return new f(this.n);
    }

    static final class com.google.android.exoplayer2.f.a.a$a {
        final List<CharacterStyle> a = new ArrayList<CharacterStyle>();
        final List<a> b = new ArrayList<a>();
        final List<SpannableString> c = new LinkedList<SpannableString>();
        final SpannableStringBuilder d = new SpannableStringBuilder();
        int e;
        int f;
        int g;
        int h;
        int i;
        private int j;

        public com.google.android.exoplayer2.f.a.a$a(int n2, int n3) {
            this.a(n2, n3);
        }

        /*
         * Enabled aggressive block sorting
         */
        private SpannableString e() {
            int n2;
            int n3 = this.d.length();
            for (n2 = 0; n2 < this.a.size(); ++n2) {
                this.d.setSpan((Object)this.a.get(n2), 0, n3, 33);
            }
            for (n2 = 0; n2 < this.b.size(); ++n2) {
                a a2 = this.b.get(n2);
                int n4 = n2 < this.b.size() - a2.c ? this.b.get((int)(a2.c + n2)).b : n3;
                this.d.setSpan((Object)a2.a, a2.b, n4, 33);
            }
            if (this.i != -1) {
                this.d.setSpan((Object)new UnderlineSpan(), this.i, n3, 33);
            }
            return new SpannableString((CharSequence)this.d);
        }

        public final void a(char c2) {
            this.d.append(c2);
        }

        public final void a(int n2, int n3) {
            this.a.clear();
            this.b.clear();
            this.c.clear();
            this.d.clear();
            this.e = 15;
            this.f = 0;
            this.g = 0;
            this.j = n2;
            this.h = n3;
            this.i = -1;
        }

        public final void a(CharacterStyle characterStyle) {
            this.a.add(characterStyle);
        }

        public final void a(CharacterStyle characterStyle, int n2) {
            this.b.add(new a(characterStyle, this.d.length(), n2));
        }

        public final boolean a() {
            if (this.a.isEmpty() && this.b.isEmpty() && this.c.isEmpty() && this.d.length() == 0) {
                return true;
            }
            return false;
        }

        public final void b() {
            int n2 = this.d.length();
            if (n2 > 0) {
                this.d.delete(n2 - 1, n2);
            }
        }

        public final void c() {
            this.c.add(this.e());
            this.d.clear();
            this.a.clear();
            this.b.clear();
            this.i = -1;
            int n2 = Math.min(this.h, this.e);
            while (this.c.size() >= n2) {
                this.c.remove(0);
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public final b d() {
            float f2;
            int n2;
            int n3 = 2;
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
            for (n2 = 0; n2 < this.c.size(); ++n2) {
                spannableStringBuilder.append((CharSequence)this.c.get(n2));
                spannableStringBuilder.append('\n');
            }
            spannableStringBuilder.append((CharSequence)this.e());
            if (spannableStringBuilder.length() == 0) {
                return null;
            }
            n2 = this.f + this.g;
            int n4 = 32 - n2 - spannableStringBuilder.length();
            int n5 = n2 - n4;
            if (this.j == 2 && Math.abs(n5) < 3) {
                f2 = 0.5f;
                n2 = 1;
            } else if (this.j == 2 && n5 > 0) {
                f2 = (float)(32 - n4) / 32.0f * 0.8f + 0.1f;
                n2 = 2;
            } else {
                f2 = (float)n2 / 32.0f * 0.8f + 0.1f;
                n2 = 0;
            }
            if (this.j != 1 && this.e <= 7) {
                n4 = this.e;
                n3 = 0;
                return new b((CharSequence)spannableStringBuilder, Layout.Alignment.ALIGN_NORMAL, n4, 1, n3, f2, n2, Float.MIN_VALUE);
            }
            n4 = this.e - 15 - 2;
            return new b((CharSequence)spannableStringBuilder, Layout.Alignment.ALIGN_NORMAL, n4, 1, n3, f2, n2, Float.MIN_VALUE);
        }

        public final String toString() {
            return this.d.toString();
        }

        static final class a {
            public final CharacterStyle a;
            public final int b;
            public final int c;

            public a(CharacterStyle characterStyle, int n2, int n3) {
                this.a = characterStyle;
                this.b = n2;
                this.c = n3;
            }
        }

    }

}

