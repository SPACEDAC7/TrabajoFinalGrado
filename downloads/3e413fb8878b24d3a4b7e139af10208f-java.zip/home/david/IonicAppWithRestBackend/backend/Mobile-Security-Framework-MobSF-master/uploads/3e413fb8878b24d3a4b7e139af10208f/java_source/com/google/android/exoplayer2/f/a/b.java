/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 */
package com.google.android.exoplayer2.f.a;

import android.text.Layout;

final class b
extends com.google.android.exoplayer2.f.b
implements Comparable<b> {
    public final int k;

    public b(CharSequence charSequence, Layout.Alignment alignment, float f2, int n2, float f3, int n3, boolean bl2, int n4, int n5) {
        super(charSequence, alignment, f2, 0, n2, f3, n3, Float.MIN_VALUE, bl2, n4);
        this.k = n5;
    }
}

