/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.SpannableString
 *  android.text.SpannableStringBuilder
 *  android.text.style.BackgroundColorSpan
 *  android.text.style.ForegroundColorSpan
 *  android.text.style.StyleSpan
 *  android.text.style.UnderlineSpan
 *  android.util.Log
 */
package com.google.android.exoplayer2.f.a;

import android.graphics.Color;
import android.text.Layout;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import com.google.android.exoplayer2.f.a.d;
import com.google.android.exoplayer2.f.a.f;
import com.google.android.exoplayer2.f.e;
import com.google.android.exoplayer2.f.i;
import com.google.android.exoplayer2.f.j;
import com.google.android.exoplayer2.i.h;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public final class c
extends d {
    private final com.google.android.exoplayer2.i.i b = new com.google.android.exoplayer2.i.i();
    private final h c = new h();
    private final int d;
    private final a[] e;
    private a f;
    private List<com.google.android.exoplayer2.f.b> g;
    private List<com.google.android.exoplayer2.f.b> h;
    private b i;
    private int j;

    public c(int n2) {
        int n3 = n2;
        if (n2 == -1) {
            n3 = 1;
        }
        this.d = n3;
        this.e = new a[8];
        for (n2 = 0; n2 < 8; ++n2) {
            this.e[n2] = new a();
        }
        this.f = this.e[0];
        this.k();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    private void a(int n2) {
        switch (n2) {
            default: {
                Log.w((String)"Cea708Decoder", (String)("Invalid C1 command: " + n2));
                return;
            }
            case 128: 
            case 129: 
            case 130: 
            case 131: 
            case 132: 
            case 133: 
            case 134: 
            case 135: {
                if (this.j == (n2 -= 128)) return;
                {
                    this.j = n2;
                    this.f = this.e[n2];
                    return;
                }
            }
            case 142: {
                return;
            }
            case 136: {
                n2 = 1;
                while (n2 <= 8) {
                    if (this.c.a()) {
                        this.e[8 - n2].c();
                    }
                    ++n2;
                }
                return;
            }
            case 137: {
                n2 = 1;
                while (n2 <= 8) {
                    if (this.c.a()) {
                        this.e[8 - n2].j = true;
                    }
                    ++n2;
                }
                return;
            }
            case 138: {
                n2 = 1;
                while (n2 <= 8) {
                    if (this.c.a()) {
                        this.e[8 - n2].j = false;
                    }
                    ++n2;
                }
                return;
            }
            case 139: {
                n2 = 1;
                while (n2 <= 8) {
                    if (this.c.a()) {
                        a a2 = this.e[8 - n2];
                        boolean bl2 = !a2.j;
                        a2.j = bl2;
                    }
                    ++n2;
                }
                return;
            }
            case 140: {
                n2 = 1;
                while (n2 <= 8) {
                    if (this.c.a()) {
                        this.e[8 - n2].b();
                    }
                    ++n2;
                }
                return;
            }
            case 141: {
                this.c.b(8);
                return;
            }
            case 143: {
                this.k();
                return;
            }
            case 144: {
                if (!this.f.i) {
                    this.c.b(16);
                    return;
                }
                this.c.c(4);
                this.c.c(2);
                this.c.c(2);
                boolean bl3 = this.c.a();
                boolean bl4 = this.c.a();
                this.c.c(3);
                this.c.c(3);
                this.f.a(bl3, bl4);
                return;
            }
            case 145: {
                if (!this.f.i) {
                    this.c.b(24);
                    return;
                }
                n2 = this.c.c(2);
                n2 = a.a(this.c.c(2), this.c.c(2), this.c.c(2), n2);
                int n3 = this.c.c(2);
                n3 = a.a(this.c.c(2), this.c.c(2), this.c.c(2), n3);
                this.c.b(2);
                a.a(this.c.c(2), this.c.c(2), this.c.c(2));
                this.f.b(n2, n3);
                return;
            }
            case 146: {
                if (!this.f.i) {
                    this.c.b(16);
                    return;
                }
                this.c.b(4);
                this.c.c(4);
                this.c.b(2);
                this.c.c(6);
                a.d();
                return;
            }
            case 151: {
                if (!this.f.i) {
                    this.c.b(32);
                    return;
                }
                n2 = this.c.c(2);
                n2 = a.a(this.c.c(2), this.c.c(2), this.c.c(2), n2);
                this.c.c(2);
                a.a(this.c.c(2), this.c.c(2), this.c.c(2));
                this.c.a();
                this.c.a();
                this.c.c(2);
                this.c.c(2);
                int n4 = this.c.c(2);
                this.c.b(8);
                this.f.a(n2, n4);
                return;
            }
            case 152: 
            case 153: 
            case 154: 
            case 155: 
            case 156: 
            case 157: 
            case 158: 
            case 159: {
                a a3 = this.e[n2 - 152];
                this.c.b(2);
                boolean bl5 = this.c.a();
                boolean bl6 = this.c.a();
                this.c.a();
                int n5 = this.c.c(3);
                boolean bl7 = this.c.a();
                int n6 = this.c.c(7);
                int n7 = this.c.c(8);
                int n8 = this.c.c(4);
                int n9 = this.c.c(4);
                this.c.b(2);
                this.c.c(6);
                this.c.b(2);
                int n10 = this.c.c(3);
                n2 = this.c.c(3);
                a3.i = true;
                a3.j = bl5;
                a3.q = bl6;
                a3.k = n5;
                a3.l = bl7;
                a3.m = n6;
                a3.n = n7;
                a3.o = n8;
                if (a3.p != n9 + 1) {
                    a3.p = n9 + 1;
                    while (bl6 && a3.g.size() >= a3.p || a3.g.size() >= 15) {
                        a3.g.remove(0);
                    }
                }
                if (n10 != 0 && a3.r != n10) {
                    a3.r = n10;
                    n5 = n10 - 1;
                    a3.a(a.e[n5], a.d[n5]);
                }
                if (n2 == 0 || a3.s == n2) return;
                a3.s = n2;
                a3.a(false, false);
                a3.b(a.a, a.f[n2 - 1]);
                return;
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void i() {
        if (this.i == null) {
            return;
        }
        if (this.i.d != (this.i.b << 1) - 1) {
            Log.w((String)"Cea708Decoder", (String)("DtvCcPacket ended prematurely; size is " + ((this.i.b << 1) - 1) + ", but current index is " + this.i.d + " (sequence number " + this.i.a + ")"));
        }
        this.c.a(this.i.c, this.i.d);
        var3_1 = this.c.c(3);
        var4_2 = this.c.c(5);
        var2_3 = var3_1;
        if (var3_1 == 7) {
            this.c.b(2);
            var2_3 = var3_1 + this.c.c(6);
        }
        if (var4_2 != 0) ** GOTO lbl16
        if (var2_3 != 0) {
            Log.w((String)"Cea708Decoder", (String)("serviceNumber is non-zero (" + var2_3 + ") when blockSize is 0"));
        }
        ** GOTO lbl-1000
lbl16: // 1 sources:
        if (var2_3 != this.d) lbl-1000: // 3 sources:
        {
            do {
                this.i = null;
                return;
                break;
            } while (true);
        }
        block36 : do {
            var1_4 = this.c;
            if ((var1_4.d - var1_4.b << 3) - var1_4.c <= 0) ** continue;
            var2_3 = this.c.c(8);
            if (var2_3 != 16) {
                if (var2_3 <= 31) {
                    switch (var2_3) {
                        case 0: 
                        case 14: {
                            continue block36;
                        }
                        default: {
                            if (var2_3 < 17 || var2_3 > 23) break;
                            Log.w((String)"Cea708Decoder", (String)("Currently unsupported COMMAND_EXT1 Command: " + var2_3));
                            this.c.b(8);
                            continue block36;
                        }
                        case 3: {
                            this.g = this.j();
                            continue block36;
                        }
                        case 8: {
                            var1_4 = this.f;
                            var2_3 = var1_4.h.length();
                            if (var2_3 <= 0) continue block36;
                            var1_4.h.delete(var2_3 - 1, var2_3);
                            continue block36;
                        }
                        case 12: {
                            this.k();
                            continue block36;
                        }
                        case 13: {
                            this.f.a('\n');
                            continue block36;
                        }
                    }
                    if (var2_3 >= 24 && var2_3 <= 31) {
                        Log.w((String)"Cea708Decoder", (String)("Currently unsupported COMMAND_P16 Command: " + var2_3));
                        this.c.b(16);
                        continue;
                    }
                    Log.w((String)"Cea708Decoder", (String)("Invalid C0 command: " + var2_3));
                    continue;
                }
                if (var2_3 <= 127) {
                    if (var2_3 == 127) {
                        this.f.a('\u266b');
                        continue;
                    }
                    this.f.a((char)(var2_3 & 255));
                    continue;
                }
                if (var2_3 <= 159) {
                    this.a(var2_3);
                    this.g = this.j();
                    continue;
                }
                if (var2_3 <= 255) {
                    this.f.a((char)(var2_3 & 255));
                    continue;
                }
                Log.w((String)"Cea708Decoder", (String)("Invalid base command: " + var2_3));
                continue;
            }
            var2_3 = this.c.c(8);
            if (var2_3 <= 31) {
                if (var2_3 <= 15) continue;
                if (var2_3 <= 15) {
                    this.c.b(8);
                    continue;
                }
                if (var2_3 <= 23) {
                    this.c.b(16);
                    continue;
                }
                if (var2_3 > 31) continue;
                this.c.b(24);
                continue;
            }
            if (var2_3 <= 127) {
                switch (var2_3) {
                    default: {
                        Log.w((String)"Cea708Decoder", (String)("Invalid G2 character: " + var2_3));
                        continue block36;
                    }
                    case 32: {
                        this.f.a(' ');
                        continue block36;
                    }
                    case 33: {
                        this.f.a('\u00a0');
                        continue block36;
                    }
                    case 37: {
                        this.f.a('\u2026');
                        continue block36;
                    }
                    case 42: {
                        this.f.a('\u0160');
                        continue block36;
                    }
                    case 44: {
                        this.f.a('\u0152');
                        continue block36;
                    }
                    case 48: {
                        this.f.a('\u2588');
                        continue block36;
                    }
                    case 49: {
                        this.f.a('\u2018');
                        continue block36;
                    }
                    case 50: {
                        this.f.a('\u2019');
                        continue block36;
                    }
                    case 51: {
                        this.f.a('\u201c');
                        continue block36;
                    }
                    case 52: {
                        this.f.a('\u201d');
                        continue block36;
                    }
                    case 53: {
                        this.f.a('\u2022');
                        continue block36;
                    }
                    case 57: {
                        this.f.a('\u2122');
                        continue block36;
                    }
                    case 58: {
                        this.f.a('\u0161');
                        continue block36;
                    }
                    case 60: {
                        this.f.a('\u0153');
                        continue block36;
                    }
                    case 61: {
                        this.f.a('\u2120');
                        continue block36;
                    }
                    case 63: {
                        this.f.a('\u0178');
                        continue block36;
                    }
                    case 118: {
                        this.f.a('\u215b');
                        continue block36;
                    }
                    case 119: {
                        this.f.a('\u215c');
                        continue block36;
                    }
                    case 120: {
                        this.f.a('\u215d');
                        continue block36;
                    }
                    case 121: {
                        this.f.a('\u215e');
                        continue block36;
                    }
                    case 122: {
                        this.f.a('\u2502');
                        continue block36;
                    }
                    case 123: {
                        this.f.a('\u2510');
                        continue block36;
                    }
                    case 124: {
                        this.f.a('\u2514');
                        continue block36;
                    }
                    case 125: {
                        this.f.a('\u2500');
                        continue block36;
                    }
                    case 126: {
                        this.f.a('\u2518');
                        continue block36;
                    }
                    case 127: 
                }
                this.f.a('\u250c');
                continue;
            }
            if (var2_3 <= 159) {
                if (var2_3 <= 135) {
                    this.c.b(32);
                    continue;
                }
                if (var2_3 <= 143) {
                    this.c.b(40);
                    continue;
                }
                if (var2_3 > 159) continue;
                this.c.b(2);
                var2_3 = this.c.c(6);
                this.c.b(var2_3 << 3);
                continue;
            }
            if (var2_3 <= 255) {
                if (var2_3 == 160) {
                    this.f.a('\u33c4');
                    continue;
                }
                Log.w((String)"Cea708Decoder", (String)("Invalid G3 character: " + var2_3));
                this.f.a('_');
                continue;
            }
            Log.w((String)"Cea708Decoder", (String)("Invalid extended command: " + var2_3));
        } while (true);
    }

    private List<com.google.android.exoplayer2.f.b> j() {
        ArrayList<com.google.android.exoplayer2.f.a.b> arrayList = new ArrayList<com.google.android.exoplayer2.f.a.b>();
        for (int i2 = 0; i2 < 8; ++i2) {
            if (this.e[i2].a() || !this.e[i2].j) continue;
            arrayList.add(this.e[i2].e());
        }
        Collections.sort(arrayList);
        return Collections.unmodifiableList(arrayList);
    }

    private void k() {
        for (int i2 = 0; i2 < 8; ++i2) {
            this.e[i2].b();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(i arrby) {
        this.b.a(arrby.c.array(), arrby.c.limit());
        while (this.b.b() >= 3) {
            b b2;
            int n2 = this.b.e() & 7;
            int n3 = n2 & 3;
            n2 = (n2 & 4) == 4 ? 1 : 0;
            byte by2 = (byte)this.b.e();
            byte by3 = (byte)this.b.e();
            if (n3 != 2 && n3 != 3) continue;
            if (n2 == 0) {
                this.i();
                continue;
            }
            if (n3 == 3) {
                this.i();
                n2 = n3 = by2 & 63;
                if (n3 == 0) {
                    n2 = 64;
                }
                this.i = new b((by2 & 192) >> 6, n2);
                arrby = this.i.c;
                b2 = this.i;
                n2 = b2.d;
                b2.d = n2 + 1;
                arrby[n2] = by3;
            } else {
                boolean bl2 = n3 == 2;
                a.a.a.a.d.a(bl2);
                if (this.i == null) {
                    Log.e((String)"Cea708Decoder", (String)"Encountered DTVCC_PACKET_DATA before DTVCC_PACKET_START");
                    continue;
                }
                arrby = this.i.c;
                b2 = this.i;
                n2 = b2.d;
                b2.d = n2 + 1;
                arrby[n2] = by2;
                arrby = this.i.c;
                b2 = this.i;
                n2 = b2.d;
                b2.d = n2 + 1;
                arrby[n2] = by3;
            }
            if (this.i.d != (this.i.b << 1) - 1) continue;
            this.i();
        }
        return;
    }

    @Override
    public final void c() {
        super.c();
        this.g = null;
        this.h = null;
        this.j = 0;
        this.f = this.e[this.j];
        this.k();
        this.i = null;
    }

    @Override
    protected final boolean e() {
        if (this.g != this.h) {
            return true;
        }
        return false;
    }

    @Override
    protected final e f() {
        this.h = this.g;
        return new f(this.g);
    }

    static final class a {
        public static final int a = a.a(2, 2, 2, 0);
        public static final int b = a.a(0, 0, 0, 0);
        public static final int c = a.a(0, 0, 0, 3);
        static final int[] d = new int[]{0, 0, 0, 0, 0, 2, 0};
        static final int[] e;
        static final int[] f;
        private static final int[] t;
        private static final int[] u;
        private static final boolean[] v;
        private static final int[] w;
        private static final int[] x;
        private int A;
        private int B;
        private int C;
        private int D;
        private int E;
        private int F;
        final List<SpannableString> g = new LinkedList<SpannableString>();
        final SpannableStringBuilder h = new SpannableStringBuilder();
        boolean i;
        boolean j;
        int k;
        boolean l;
        int m;
        int n;
        int o;
        int p;
        boolean q;
        int r;
        int s;
        private int y;
        private int z;

        static {
            t = new int[]{0, 0, 0, 0, 0, 0, 2};
            u = new int[]{3, 3, 3, 3, 3, 3, 1};
            v = new boolean[]{false, false, false, true, true, true, false};
            e = new int[]{b, c, b, b, c, b, b};
            w = new int[]{0, 1, 2, 3, 4, 3, 4};
            x = new int[]{0, 0, 0, 0, 0, 3, 3};
            f = new int[]{b, b, b, b, b, c, c};
        }

        public a() {
            this.b();
        }

        public static int a(int n2, int n3, int n4) {
            return a.a(n2, n3, n4, 0);
        }

        /*
         * Enabled aggressive block sorting
         */
        public static int a(int n2, int n3, int n4, int n5) {
            int n6 = 255;
            a.a.a.a.d.a(n2, 4);
            a.a.a.a.d.a(n3, 4);
            a.a.a.a.d.a(n4, 4);
            a.a.a.a.d.a(n5, 4);
            switch (n5) {
                default: {
                    n5 = 255;
                    break;
                }
                case 0: 
                case 1: {
                    n5 = 255;
                    break;
                }
                case 2: {
                    n5 = 127;
                    break;
                }
                case 3: {
                    n5 = 0;
                }
            }
            n2 = n2 > 1 ? 255 : 0;
            n3 = n3 > 1 ? 255 : 0;
            if (n4 > 1) {
                n4 = n6;
                return Color.argb((int)n5, (int)n2, (int)n3, (int)n4);
            }
            n4 = 0;
            return Color.argb((int)n5, (int)n2, (int)n3, (int)n4);
        }

        public static void d() {
        }

        private SpannableString f() {
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder((CharSequence)this.h);
            int n2 = spannableStringBuilder.length();
            if (n2 > 0) {
                if (this.A != -1) {
                    spannableStringBuilder.setSpan((Object)new StyleSpan(2), this.A, n2, 33);
                }
                if (this.B != -1) {
                    spannableStringBuilder.setSpan((Object)new UnderlineSpan(), this.B, n2, 33);
                }
                if (this.C != -1) {
                    spannableStringBuilder.setSpan((Object)new ForegroundColorSpan(this.D), this.C, n2, 33);
                }
                if (this.E != -1) {
                    spannableStringBuilder.setSpan((Object)new BackgroundColorSpan(this.F), this.E, n2, 33);
                }
            }
            return new SpannableString((CharSequence)spannableStringBuilder);
        }

        public final void a(char c2) {
            if (c2 == '\n') {
                this.g.add(this.f());
                this.h.clear();
                if (this.A != -1) {
                    this.A = 0;
                }
                if (this.B != -1) {
                    this.B = 0;
                }
                if (this.C != -1) {
                    this.C = 0;
                }
                if (this.E != -1) {
                    this.E = 0;
                }
                while (this.q && this.g.size() >= this.p || this.g.size() >= 15) {
                    this.g.remove(0);
                }
            } else {
                this.h.append(c2);
            }
        }

        public final void a(int n2, int n3) {
            this.z = n2;
            this.y = n3;
        }

        /*
         * Enabled aggressive block sorting
         */
        public final void a(boolean bl2, boolean bl3) {
            if (this.A != -1) {
                if (!bl2) {
                    this.h.setSpan((Object)new StyleSpan(2), this.A, this.h.length(), 33);
                    this.A = -1;
                }
            } else if (bl2) {
                this.A = this.h.length();
            }
            if (this.B != -1) {
                if (bl3) return;
                {
                    this.h.setSpan((Object)new UnderlineSpan(), this.B, this.h.length(), 33);
                    this.B = -1;
                    return;
                }
            } else {
                if (!bl3) return;
                {
                    this.B = this.h.length();
                    return;
                }
            }
        }

        public final boolean a() {
            if (!this.i || this.g.isEmpty() && this.h.length() == 0) {
                return true;
            }
            return false;
        }

        public final void b() {
            this.c();
            this.i = false;
            this.j = false;
            this.k = 4;
            this.l = false;
            this.m = 0;
            this.n = 0;
            this.o = 0;
            this.p = 15;
            this.q = true;
            this.y = 0;
            this.r = 0;
            this.s = 0;
            this.z = b;
            this.D = a;
            this.F = b;
        }

        public final void b(int n2, int n3) {
            if (this.C != -1 && this.D != n2) {
                this.h.setSpan((Object)new ForegroundColorSpan(this.D), this.C, this.h.length(), 33);
            }
            if (n2 != a) {
                this.C = this.h.length();
                this.D = n2;
            }
            if (this.E != -1 && this.F != n3) {
                this.h.setSpan((Object)new BackgroundColorSpan(this.F), this.E, this.h.length(), 33);
            }
            if (n3 != b) {
                this.E = this.h.length();
                this.F = n3;
            }
        }

        public final void c() {
            this.g.clear();
            this.h.clear();
            this.A = -1;
            this.B = -1;
            this.C = -1;
            this.E = -1;
        }

        /*
         * Enabled aggressive block sorting
         */
        public final com.google.android.exoplayer2.f.a.b e() {
            Layout.Alignment alignment;
            float f2;
            int n2;
            float f3;
            boolean bl2 = false;
            if (this.a()) {
                return null;
            }
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
            for (n2 = 0; n2 < this.g.size(); ++n2) {
                spannableStringBuilder.append((CharSequence)this.g.get(n2));
                spannableStringBuilder.append('\n');
            }
            spannableStringBuilder.append((CharSequence)this.f());
            switch (this.y) {
                default: {
                    throw new IllegalArgumentException("Unexpected justification value: " + this.y);
                }
                case 0: 
                case 3: {
                    alignment = Layout.Alignment.ALIGN_NORMAL;
                    break;
                }
                case 1: {
                    alignment = Layout.Alignment.ALIGN_OPPOSITE;
                    break;
                }
                case 2: {
                    alignment = Layout.Alignment.ALIGN_CENTER;
                }
            }
            if (this.l) {
                f3 = (float)this.n / 99.0f;
                f2 = (float)this.m / 99.0f;
            } else {
                f3 = (float)this.n / 209.0f;
                f2 = (float)this.m / 74.0f;
            }
            n2 = this.o % 3 == 0 ? 0 : (this.o % 3 == 1 ? 1 : 2);
            int n3 = this.o / 3 == 0 ? 0 : (this.o / 3 == 1 ? 1 : 2);
            if (this.z != b) {
                bl2 = true;
            }
            return new com.google.android.exoplayer2.f.a.b((CharSequence)spannableStringBuilder, alignment, f2 * 0.9f + 0.05f, n2, f3 * 0.9f + 0.05f, n3, bl2, this.z, this.k);
        }
    }

    static final class b {
        public final int a;
        public final int b;
        public final byte[] c;
        int d;

        public b(int n2, int n3) {
            this.a = n2;
            this.b = n3;
            this.c = new byte[n3 * 2 - 1];
            this.d = 0;
        }
    }

}

