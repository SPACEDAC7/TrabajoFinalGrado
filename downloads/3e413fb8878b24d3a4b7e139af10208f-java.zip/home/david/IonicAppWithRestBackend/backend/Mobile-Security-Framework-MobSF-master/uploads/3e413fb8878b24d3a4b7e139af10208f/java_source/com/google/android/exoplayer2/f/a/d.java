/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f.a;

import com.google.android.exoplayer2.f.e;
import com.google.android.exoplayer2.f.f;
import com.google.android.exoplayer2.f.i;
import com.google.android.exoplayer2.f.j;
import java.util.LinkedList;
import java.util.TreeSet;

abstract class d
implements f {
    final LinkedList<j> a;
    private final LinkedList<i> b;
    private final TreeSet<i> c;
    private i d;
    private long e;

    public d() {
        int n2;
        int n3 = 0;
        this.b = new LinkedList();
        for (n2 = 0; n2 < 10; ++n2) {
            this.b.add(new i());
        }
        this.a = new LinkedList();
        for (n2 = n3; n2 < 2; ++n2) {
            this.a.add(new com.google.android.exoplayer2.f.a.e(this));
        }
        this.c = new TreeSet();
    }

    private void c(i i2) {
        i2.a();
        this.b.add(i2);
    }

    @Override
    public final /* synthetic */ Object a() {
        return this.h();
    }

    @Override
    public void a(long l2) {
        this.e = l2;
    }

    @Override
    protected abstract void a(i var1);

    @Override
    public final /* synthetic */ void a(Object object) {
        this.b((i)object);
    }

    @Override
    public final /* synthetic */ Object b() {
        return this.g();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void b(i i2) {
        boolean bl2 = true;
        boolean bl3 = i2 != null;
        a.a.a.a.d.a(bl3);
        bl3 = i2 == this.d ? bl2 : false;
        a.a.a.a.d.a(bl3);
        this.c.add(i2);
        this.d = null;
    }

    @Override
    public void c() {
        this.e = 0;
        while (!this.c.isEmpty()) {
            this.c(this.c.pollFirst());
        }
        if (this.d != null) {
            this.c(this.d);
            this.d = null;
        }
    }

    @Override
    public void d() {
    }

    protected abstract boolean e();

    protected abstract e f();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public j g() {
        if (!this.a.isEmpty()) ** GOTO lbl4
        return null;
lbl-1000: // 2 sources:
        {
            this.c(var1_1);
lbl4: // 2 sources:
            if (this.c.isEmpty() != false) return null;
            if (this.c.first().d > this.e) return null;
            var1_1 = this.c.pollFirst();
            if (var1_1.c()) {
                var2_3 = this.a.pollFirst();
                var2_3.a(4);
                this.c(var1_1);
                return var2_3;
            }
            this.a(var1_1);
            if (!this.e()) ** GOTO lbl-1000
            var2_2 = this.f();
            ** while (var1_1.c_())
        }
lbl16: // 1 sources:
        var3_4 = this.a.pollFirst();
        var3_4.a(var1_1.d, var2_2, Long.MAX_VALUE);
        this.c(var1_1);
        return var3_4;
    }

    /*
     * Enabled aggressive block sorting
     */
    public i h() {
        boolean bl2 = this.d == null;
        a.a.a.a.d.b(bl2);
        if (this.b.isEmpty()) {
            return null;
        }
        this.d = this.b.pollFirst();
        return this.d;
    }
}

