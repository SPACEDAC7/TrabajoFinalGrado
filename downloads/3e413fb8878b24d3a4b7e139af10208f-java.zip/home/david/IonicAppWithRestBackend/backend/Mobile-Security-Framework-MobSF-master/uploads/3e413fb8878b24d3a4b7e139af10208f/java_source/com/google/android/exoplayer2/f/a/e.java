/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f.a;

import com.google.android.exoplayer2.f.a.d;
import com.google.android.exoplayer2.f.j;
import java.util.LinkedList;

public final class e
extends j {
    private final d d;

    public e(d d2) {
        this.d = d2;
    }

    @Override
    public final void e() {
        d d2 = this.d;
        this.a();
        d2.a.add(this);
    }
}

