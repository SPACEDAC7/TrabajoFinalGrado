/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 */
package com.google.android.exoplayer2.f;

import android.text.Layout;

public class b {
    public final CharSequence a;
    public final Layout.Alignment b;
    public final float c;
    public final int d;
    public final int e;
    public final float f;
    public final int g;
    public final float h;
    public final boolean i;
    public final int j;

    public b(CharSequence charSequence) {
        this(charSequence, null, Float.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE);
    }

    public b(CharSequence charSequence, Layout.Alignment alignment, float f2, int n2, int n3, float f3, int n4, float f4) {
        this(charSequence, alignment, f2, n2, n3, f3, n4, f4, false, -16777216);
    }

    public b(CharSequence charSequence, Layout.Alignment alignment, float f2, int n2, int n3, float f3, int n4, float f4, boolean bl2, int n5) {
        this.a = charSequence;
        this.b = alignment;
        this.c = f2;
        this.d = n2;
        this.e = n3;
        this.f = f3;
        this.g = n4;
        this.h = f4;
        this.i = bl2;
        this.j = n5;
    }
}

