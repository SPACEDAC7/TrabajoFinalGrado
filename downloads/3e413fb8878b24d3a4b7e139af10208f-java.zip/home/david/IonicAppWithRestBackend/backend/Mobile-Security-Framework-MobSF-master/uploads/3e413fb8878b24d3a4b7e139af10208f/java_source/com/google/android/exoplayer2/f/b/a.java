/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Html
 *  android.text.TextUtils
 *  android.util.Log
 */
package com.google.android.exoplayer2.f.b;

import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.exoplayer2.f.b.b;
import com.google.android.exoplayer2.f.c;
import com.google.android.exoplayer2.f.e;
import com.google.android.exoplayer2.i.i;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class a
extends c {
    private static final Pattern c = Pattern.compile("\\s*((?:(\\d+):)?(\\d+):(\\d+),(\\d+))\\s*-->\\s*((?:(\\d+):)?(\\d+):(\\d+),(\\d+))?\\s*");
    private final StringBuilder d = new StringBuilder();

    public a() {
        super("SubripDecoder");
    }

    private static long a(Matcher matcher, int n2) {
        return (Long.parseLong(matcher.group(n2 + 1)) * 60 * 60 * 1000 + Long.parseLong(matcher.group(n2 + 2)) * 60 * 1000 + Long.parseLong(matcher.group(n2 + 3)) * 1000 + Long.parseLong(matcher.group(n2 + 4))) * 1000;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private b b(byte[] var1_1, int var2_2) {
        var3_3 = new ArrayList<com.google.android.exoplayer2.f.b>();
        var4_4 = new com.google.android.exoplayer2.i.e();
        var1_1 = new i((byte[])var1_1, var2_2);
        do {
            if ((var5_5 = var1_1.s()) == null) {
                var1_1 = new com.google.android.exoplayer2.f.b[var3_3.size()];
                var3_3.toArray(var1_1);
                return new b(var1_1, Arrays.copyOf(var4_4.b, var4_4.a));
            }
            if (var5_5.length() == 0) continue;
            try {
                Integer.parseInt(var5_5);
            }
            catch (NumberFormatException var6_7) {
                Log.w((String)"SubripDecoder", (String)("Skipping invalid index: " + var5_5));
                continue;
            }
            var5_5 = var1_1.s();
            var6_6 = a.c.matcher(var5_5);
            if (!var6_6.matches()) ** GOTO lbl31
            var4_4.a(a.a(var6_6, 1));
            if (!TextUtils.isEmpty((CharSequence)var6_6.group(6))) {
                var4_4.a(a.a(var6_6, 6));
                var2_2 = 1;
            } else {
                var2_2 = 0;
            }
            this.d.setLength(0);
            while (!TextUtils.isEmpty((CharSequence)(var5_5 = var1_1.s()))) {
                if (this.d.length() > 0) {
                    this.d.append("<br>");
                }
                this.d.append(var5_5.trim());
            }
            ** GOTO lbl33
lbl31: // 1 sources:
            Log.w((String)"SubripDecoder", (String)("Skipping invalid timing: " + var5_5));
            continue;
lbl33: // 1 sources:
            var3_3.add(new com.google.android.exoplayer2.f.b((CharSequence)Html.fromHtml((String)this.d.toString())));
            if (var2_2 == 0) continue;
            var3_3.add(null);
        } while (true);
    }

    @Override
    protected final /* synthetic */ e a(byte[] arrby, int n2) {
        return this.b(arrby, n2);
    }
}

