/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f.b;

import a.a.a.a.d;
import com.google.android.exoplayer2.f.e;
import com.google.android.exoplayer2.i.o;
import java.util.Collections;
import java.util.List;

final class b
implements e {
    private final com.google.android.exoplayer2.f.b[] a;
    private final long[] b;

    public b(com.google.android.exoplayer2.f.b[] arrb, long[] arrl) {
        this.a = arrb;
        this.b = arrl;
    }

    @Override
    public final int a(long l2) {
        int n2 = o.a(this.b, l2, false, false);
        if (n2 < this.b.length) {
            return n2;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a_(int n2) {
        boolean bl2 = true;
        boolean bl3 = n2 >= 0;
        d.a(bl3);
        bl3 = n2 < this.b.length ? bl2 : false;
        d.a(bl3);
        return this.b[n2];
    }

    @Override
    public final int b() {
        return this.b.length;
    }

    @Override
    public final List<com.google.android.exoplayer2.f.b> b(long l2) {
        int n2 = o.a(this.b, l2, false);
        if (n2 == -1 || this.a[n2] == null) {
            return Collections.emptyList();
        }
        return Collections.singletonList(this.a[n2]);
    }
}

