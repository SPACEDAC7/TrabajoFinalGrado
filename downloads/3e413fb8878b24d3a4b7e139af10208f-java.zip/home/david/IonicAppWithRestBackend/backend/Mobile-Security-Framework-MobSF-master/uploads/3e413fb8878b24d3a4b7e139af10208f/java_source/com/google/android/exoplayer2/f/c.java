/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f;

import com.google.android.exoplayer2.f.d;
import com.google.android.exoplayer2.f.e;
import com.google.android.exoplayer2.f.f;
import com.google.android.exoplayer2.f.g;
import com.google.android.exoplayer2.f.i;
import com.google.android.exoplayer2.f.j;
import java.nio.ByteBuffer;

public abstract class c
extends com.google.android.exoplayer2.b.g<i, j, g>
implements f {
    private final String c;

    /*
     * Enabled aggressive block sorting
     */
    public c(String arrI) {
        int n2 = 0;
        super((com.google.android.exoplayer2.b.e[])new i[2], (com.google.android.exoplayer2.b.f[])new j[2]);
        this.c = arrI;
        boolean bl2 = this.b == this.a.length;
        a.a.a.a.d.b(bl2);
        arrI = this.a;
        int n3 = arrI.length;
        while (n2 < n3) {
            arrI[n2].c(1024);
            ++n2;
        }
        return;
    }

    @Override
    private g a(i i2, j j2) {
        try {
            Object object = i2.c;
            object = this.a(object.array(), object.limit());
            j2.a(i2.d, (e)object, i2.e);
            return null;
        }
        catch (g var1_2) {
            return var1_2;
        }
    }

    @Override
    public abstract e a(byte[] var1, int var2);

    @Override
    public final void a(long l2) {
    }

    @Override
    protected final void a(j j2) {
        super.a(j2);
    }

    @Override
    protected final /* synthetic */ com.google.android.exoplayer2.b.e f() {
        return new i();
    }

    @Override
    protected final /* synthetic */ com.google.android.exoplayer2.b.f g() {
        return new d(this);
    }
}

