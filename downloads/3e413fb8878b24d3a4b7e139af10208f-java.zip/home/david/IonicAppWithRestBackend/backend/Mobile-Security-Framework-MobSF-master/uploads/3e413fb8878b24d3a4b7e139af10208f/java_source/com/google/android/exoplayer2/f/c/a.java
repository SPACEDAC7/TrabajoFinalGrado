/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  android.util.Pair
 *  org.xmlpull.v1.XmlPullParser
 *  org.xmlpull.v1.XmlPullParserException
 *  org.xmlpull.v1.XmlPullParserFactory
 */
package com.google.android.exoplayer2.f.c;

import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer2.f.c;
import com.google.android.exoplayer2.f.c.b;
import com.google.android.exoplayer2.f.c.d;
import com.google.android.exoplayer2.f.e;
import com.google.android.exoplayer2.f.g;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public final class a
extends c {
    private static final Pattern c = Pattern.compile("^([0-9][0-9]+):([0-9][0-9]):([0-9][0-9])(?:(\\.[0-9]+)|:([0-9][0-9])(?:\\.([0-9]+))?)?$");
    private static final Pattern d = Pattern.compile("^([0-9]+(?:\\.[0-9]+)?)(h|m|s|ms|f|t)$");
    private static final Pattern e = Pattern.compile("^(([0-9]*.)?[0-9]+)(px|em|%)$");
    private static final Pattern f = Pattern.compile("^(\\d+\\.?\\d*?)% (\\d+\\.?\\d*?)%$");
    private static final a g = new a(30.0f, 1, 1);
    private final XmlPullParserFactory h;

    public a() {
        super("TtmlDecoder");
        try {
            this.h = XmlPullParserFactory.newInstance();
            this.h.setNamespaceAware(true);
            return;
        }
        catch (XmlPullParserException var1_1) {
            throw new RuntimeException("Couldn't create XmlPullParserFactory instance", (Throwable)var1_1);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static long a(String var0, a var1_1) {
        var6_2 = 0.0;
        var14_3 = a.c.matcher(var0);
        if (var14_3.matches()) {
            var8_4 = Long.parseLong(var14_3.group(1)) * 3600;
            var10_5 = Long.parseLong(var14_3.group(2)) * 60;
            var12_6 = Long.parseLong(var14_3.group(3));
            var0 = var14_3.group(4);
            var2_7 = var0 != null ? Double.parseDouble(var0) : 0.0;
            var0 = var14_3.group(5);
            var4_9 = var0 != null ? (double)((float)Long.parseLong(var0) / var1_1.a) : 0.0;
            var0 = var14_3.group(6);
            if (var0 == null) return (long)((var4_9 + (var12_6 + (var8_4 + var10_5) + var2_7) + var6_2) * 1000000.0);
            var6_2 = (double)Long.parseLong(var0) / (double)var1_1.b / (double)var1_1.a;
            return (long)((var4_9 + (var12_6 + (var8_4 + var10_5) + var2_7) + var6_2) * 1000000.0);
        }
        var14_3 = a.d.matcher(var0);
        if (var14_3.matches() == false) throw new g("Malformed time expression: " + var0);
        var4_10 = Double.parseDouble(var14_3.group(1));
        var0 = var14_3.group(2);
        var15_11 = -1;
        switch (var0.hashCode()) {
            case 104: {
                if (var0.equals("h")) {
                    var15_11 = 0;
                    ** break;
                }
                ** GOTO lbl44
            }
            case 109: {
                if (var0.equals("m")) {
                    var15_11 = 1;
                    ** break;
                }
                ** GOTO lbl44
            }
            case 115: {
                if (var0.equals("s")) {
                    var15_11 = 2;
                    ** break;
                }
                ** GOTO lbl44
            }
            case 3494: {
                if (var0.equals("ms")) {
                    var15_11 = 3;
                    ** break;
                }
                ** GOTO lbl44
            }
            case 102: {
                if (var0.equals("f")) {
                    var15_11 = 4;
                }
            }
lbl44: // 12 sources:
            default: {
                ** GOTO lbl49
            }
            case 116: 
        }
        if (var0.equals("t")) {
            var15_11 = 5;
        }
lbl49: // 4 sources:
        var2_8 = var4_10;
        switch (var15_11) {
            default: {
                var2_8 = var4_10;
                ** GOTO lbl65
            }
            case 0: {
                var2_8 = var4_10 * 3600.0;
                ** GOTO lbl65
            }
            case 1: {
                var2_8 = var4_10 * 60.0;
                ** GOTO lbl65
            }
            case 3: {
                var2_8 = var4_10 / 1000.0;
                ** GOTO lbl65
            }
            case 4: {
                var2_8 = var4_10 / (double)var1_1.a;
            }
lbl65: // 6 sources:
            case 2: {
                return (long)(var2_8 * 1000000.0);
            }
            case 5: 
        }
        var2_8 = var4_10 / (double)var1_1.c;
        return (long)(var2_8 * 1000000.0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static Pair<String, com.google.android.exoplayer2.f.c.c> a(XmlPullParser object) {
        String string;
        float f2;
        float f3;
        float f4;
        block8 : {
            string = a.a.a.a.d.c((XmlPullParser)object, "id");
            Object object2 = a.a.a.a.d.c((XmlPullParser)object, "origin");
            object = a.a.a.a.d.c((XmlPullParser)object, "extent");
            if (object2 == null || string == null) {
                return null;
            }
            Matcher matcher = f.matcher((CharSequence)object2);
            if (matcher.matches()) {
                try {
                    f3 = Float.parseFloat(matcher.group(1)) / 100.0f;
                    f4 = Float.parseFloat(matcher.group(2));
                    f4 /= 100.0f;
                }
                catch (NumberFormatException var6_5) {
                    Log.w((String)"TtmlDecoder", (String)("Ignoring region with malformed origin: '" + (String)object2 + "'"), (Throwable)var6_5);
                    f4 = Float.MIN_VALUE;
                    f3 = Float.MIN_VALUE;
                }
            } else {
                f4 = Float.MIN_VALUE;
                f3 = Float.MIN_VALUE;
            }
            if (object == null) return null;
            object2 = f.matcher((CharSequence)object);
            if (object2.matches()) {
                try {
                    f2 = Float.parseFloat(object2.group(1));
                    f2 /= 100.0f;
                    break block8;
                }
                catch (NumberFormatException var5_3) {
                    Log.w((String)"TtmlDecoder", (String)("Ignoring malformed region extent: '" + (String)object + "'"), (Throwable)var5_3);
                }
            }
            f2 = Float.MIN_VALUE;
        }
        if (f3 == Float.MIN_VALUE) return null;
        return new Pair((Object)string, (Object)new com.google.android.exoplayer2.f.c.c(f3, f4, 0, f2));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static b a(XmlPullParser var0, b var1_1, Map<String, com.google.android.exoplayer2.f.c.c> var2_2, a var3_3) {
        var16_4 = -9223372036854775807L;
        var12_5 = -9223372036854775807L;
        var14_6 = -9223372036854775807L;
        var4_7 = "";
        var5_8 = null;
        var11_9 = var0.getAttributeCount();
        var7_10 = a.a(var0, null);
        for (var10_11 = 0; var10_11 < var11_9; ++var10_11) {
            var8_13 = var0.getAttributeName(var10_11);
            var6_12 = var0.getAttributeValue(var10_11);
            var9_14 = -1;
            switch (var8_13.hashCode()) {
                case 93616297: {
                    if (var8_13.equals("begin")) {
                        var9_14 = 0;
                        ** break;
                    }
                    ** GOTO lbl31
                }
                case 100571: {
                    if (var8_13.equals("end")) {
                        var9_14 = 1;
                        ** break;
                    }
                    ** GOTO lbl31
                }
                case 99841: {
                    if (var8_13.equals("dur")) {
                        var9_14 = 2;
                        ** break;
                    }
                    ** GOTO lbl31
                }
                case 109780401: {
                    if (var8_13.equals("style")) {
                        var9_14 = 3;
                    }
                }
lbl31: // 10 sources:
                default: {
                    ** GOTO lbl36
                }
                case -934795532: 
            }
            if (var8_13.equals("region")) {
                var9_14 = 4;
            }
lbl36: // 4 sources:
            switch (var9_14) {
                case 0: {
                    var18_15 = a.a((String)var6_12, var3_3);
                    var12_5 = var14_6;
                    var14_6 = var18_15;
                    ** GOTO lbl73
                }
                case 1: {
                    var18_15 = a.a((String)var6_12, var3_3);
                    var14_6 = var12_5;
                    var12_5 = var18_15;
                    ** GOTO lbl73
                }
                case 2: {
                    var18_15 = a.a((String)var6_12, var3_3);
                    var16_4 = var12_5;
                    var12_5 = var14_6;
                    var14_6 = var16_4;
                    var16_4 = var18_15;
                    ** GOTO lbl73
                }
                case 3: {
                    if ((var6_12 = var6_12.split("\\s+")).length <= 0) ** GOTO lbl61
                    var5_8 = var6_12;
                    var18_15 = var12_5;
                    var12_5 = var14_6;
                    var14_6 = var18_15;
                    ** GOTO lbl73
                }
lbl61: // 2 sources:
                default: {
                    ** GOTO lbl-1000
                }
                case 4: 
            }
            if (var2_2.containsKey(var6_12)) {
                var4_7 = var6_12;
                var18_15 = var12_5;
                var12_5 = var14_6;
                var14_6 = var18_15;
            } else lbl-1000: // 2 sources:
            {
                var18_15 = var14_6;
                var14_6 = var12_5;
                var12_5 = var18_15;
            }
lbl73: // 6 sources:
            var18_15 = var14_6;
            var14_6 = var12_5;
            var12_5 = var18_15;
        }
        var20_16 = var12_5;
        if (var1_1 == null) ** GOTO lbl-1000
        var20_16 = var12_5;
        if (var1_1.d == -9223372036854775807L) ** GOTO lbl-1000
        var18_15 = var12_5;
        if (var12_5 != -9223372036854775807L) {
            var18_15 = var12_5 + var1_1.d;
        }
        var20_16 = var18_15;
        if (var14_6 != -9223372036854775807L) {
            var12_5 = var14_6 + var1_1.d;
        } else lbl-1000: // 3 sources:
        {
            var12_5 = var14_6;
            var18_15 = var20_16;
        }
        if (var12_5 != -9223372036854775807L) return new b(var0.getName(), null, var18_15, var12_5, var7_10, var5_8, (String)var4_7);
        if (var16_4 != -9223372036854775807L) {
            var12_5 = var16_4 + var18_15;
            return new b(var0.getName(), null, var18_15, var12_5, var7_10, var5_8, (String)var4_7);
        }
        if (var1_1 == null) return new b(var0.getName(), null, var18_15, var12_5, var7_10, var5_8, (String)var4_7);
        if (var1_1.e == -9223372036854775807L) return new b(var0.getName(), null, var18_15, var12_5, var7_10, var5_8, (String)var4_7);
        var12_5 = var1_1.e;
        return new b(var0.getName(), null, var18_15, var12_5, var7_10, var5_8, (String)var4_7);
    }

    private static d a(d d2) {
        d d3 = d2;
        if (d2 == null) {
            d3 = new d();
        }
        return d3;
    }

    /*
     * Exception decompiling
     */
    private static d a(XmlPullParser var0, d var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Map<String, d> a(XmlPullParser xmlPullParser, Map<String, d> map, Map<String, com.google.android.exoplayer2.f.c.c> map2) {
        int n2;
        do {
            Object object;
            xmlPullParser.next();
            if (a.a.a.a.d.b(xmlPullParser, "style")) {
                String[] arrstring = a.a.a.a.d.c(xmlPullParser, "style");
                object = a.a(xmlPullParser, new d());
                if (arrstring != null) {
                    arrstring = arrstring.split("\\s+");
                    int n3 = arrstring.length;
                    for (n2 = 0; n2 < n3; ++n2) {
                        object.a(map.get(arrstring[n2]));
                    }
                }
                if (object.l != null) {
                    map.put(object.l, (d)object);
                }
            } else if (a.a.a.a.d.b(xmlPullParser, "region") && (object = a.a(xmlPullParser)) != null) {
                map2.put((String)object.first, (com.google.android.exoplayer2.f.c.c)object.second);
            }
            n2 = xmlPullParser.getEventType() == 3 ? 1 : 0;
            if (n2 == 0 || !xmlPullParser.getName().equals("head")) continue;
            return map;
        } while ((n2 = 0) == 0);
        return map;
    }

    /*
     * Exception decompiling
     */
    private com.google.android.exoplayer2.f.c.e b(byte[] var1_1, int var2_4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl25 : TryStatement: try { 1[TRYBLOCK]

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps.apply(RemoveDeterministicJumps.java:35)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:519)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    protected final /* synthetic */ e a(byte[] arrby, int n2) {
        return this.b(arrby, n2);
    }

    static final class a {
        final float a;
        final int b;
        final int c;

        a(float f2, int n2, int n3) {
            this.a = f2;
            this.b = n2;
            this.c = n3;
        }
    }

}

