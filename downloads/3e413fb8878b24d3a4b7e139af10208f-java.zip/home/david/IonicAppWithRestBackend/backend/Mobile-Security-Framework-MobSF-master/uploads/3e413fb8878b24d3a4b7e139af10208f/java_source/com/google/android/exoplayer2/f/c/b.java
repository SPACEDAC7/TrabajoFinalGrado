/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.SpannableStringBuilder
 *  android.text.style.AbsoluteSizeSpan
 *  android.text.style.AlignmentSpan
 *  android.text.style.AlignmentSpan$Standard
 *  android.text.style.BackgroundColorSpan
 *  android.text.style.ForegroundColorSpan
 *  android.text.style.RelativeSizeSpan
 *  android.text.style.StrikethroughSpan
 *  android.text.style.StyleSpan
 *  android.text.style.TypefaceSpan
 *  android.text.style.UnderlineSpan
 */
package com.google.android.exoplayer2.f.c;

import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.AlignmentSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import com.google.android.exoplayer2.f.c.d;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

final class b {
    public final String a;
    public final String b;
    public final boolean c;
    public final long d;
    public final long e;
    public final d f;
    public final String g;
    private final String[] h;
    private final HashMap<String, Integer> i;
    private final HashMap<String, Integer> j;
    private List<b> k;

    /*
     * Enabled aggressive block sorting
     */
    b(String string, String string2, long l2, long l3, d d2, String[] arrstring, String string3) {
        this.a = string;
        this.b = string2;
        this.f = d2;
        this.h = arrstring;
        boolean bl2 = string2 != null;
        this.c = bl2;
        this.d = l2;
        this.e = l3;
        this.g = a.a.a.a.d.b(string3);
        this.i = new HashMap();
        this.j = new HashMap();
    }

    static SpannableStringBuilder a(SpannableStringBuilder spannableStringBuilder) {
        int n2;
        int n3;
        int n4 = spannableStringBuilder.length();
        for (n2 = 0; n2 < n4; ++n2) {
            if (spannableStringBuilder.charAt(n2) != ' ') continue;
            for (n3 = n2 + 1; n3 < spannableStringBuilder.length() && spannableStringBuilder.charAt(n3) == ' '; ++n3) {
            }
            if ((n3 -= n2 + 1) <= 0) continue;
            spannableStringBuilder.delete(n2, n2 + n3);
            n4 -= n3;
        }
        n2 = n4;
        if (n4 > 0) {
            n2 = n4;
            if (spannableStringBuilder.charAt(0) == ' ') {
                spannableStringBuilder.delete(0, 1);
                n2 = n4 - 1;
            }
        }
        n4 = n2;
        for (n2 = 0; n2 < n4 - 1; ++n2) {
            n3 = n4;
            if (spannableStringBuilder.charAt(n2) == '\n') {
                n3 = n4;
                if (spannableStringBuilder.charAt(n2 + 1) == ' ') {
                    spannableStringBuilder.delete(n2 + 1, n2 + 2);
                    n3 = n4 - 1;
                }
            }
            n4 = n3;
        }
        n2 = n4;
        if (n4 > 0) {
            n2 = n4;
            if (spannableStringBuilder.charAt(n4 - 1) == ' ') {
                spannableStringBuilder.delete(n4 - 1, n4);
                n2 = n4 - 1;
            }
        }
        for (n4 = 0; n4 < n2 - 1; ++n4) {
            n3 = n2;
            if (spannableStringBuilder.charAt(n4) == ' ') {
                n3 = n2;
                if (spannableStringBuilder.charAt(n4 + 1) == '\n') {
                    spannableStringBuilder.delete(n4, n4 + 1);
                    n3 = n2 - 1;
                }
            }
            n2 = n3;
        }
        if (n2 > 0 && spannableStringBuilder.charAt(n2 - 1) == '\n') {
            spannableStringBuilder.delete(n2 - 1, n2);
        }
        return spannableStringBuilder;
    }

    private static SpannableStringBuilder a(String string, Map<String, SpannableStringBuilder> map) {
        if (!map.containsKey(string)) {
            map.put(string, new SpannableStringBuilder());
        }
        return map.get(string);
    }

    private b a(int n2) {
        if (this.k == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.k.get(n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(TreeSet<Long> treeSet, boolean bl2) {
        boolean bl3 = "p".equals(this.a);
        if (bl2 || bl3) {
            if (this.d != -9223372036854775807L) {
                treeSet.add(this.d);
            }
            if (this.e != -9223372036854775807L) {
                treeSet.add(this.e);
            }
        }
        if (this.k == null) {
            return;
        }
        int n2 = 0;
        while (n2 < this.k.size()) {
            b b2 = this.k.get(n2);
            boolean bl4 = bl2 || bl3;
            b2.a(treeSet, bl4);
            ++n2;
        }
    }

    private int b() {
        if (this.k == null) {
            return 0;
        }
        return this.k.size();
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final void a(long l2, boolean bl2, String iterator, Map<String, SpannableStringBuilder> entry) {
        String string;
        this.i.clear();
        this.j.clear();
        Object object = string = this.g;
        if ("".equals(string)) {
            object = iterator;
        }
        if (this.c && bl2) {
            b.a((String)object, entry).append((CharSequence)this.b);
            return;
        }
        if ("br".equals(this.a) && bl2) {
            b.a((String)object, entry).append('\n');
            return;
        }
        if ("metadata".equals(this.a)) return;
        if (!(this.d == -9223372036854775807L && this.e == -9223372036854775807L || this.d <= l2 && this.e == -9223372036854775807L || this.d == -9223372036854775807L && l2 < this.e)) {
            if (this.d > l2) return;
            if (l2 >= this.e) return;
        }
        int n2 = 1;
        if (n2 == 0) return;
        boolean bl3 = "p".equals(this.a);
        for (Map.Entry entry2 : entry.entrySet()) {
            this.i.put((String)entry2.getKey(), ((SpannableStringBuilder)entry2.getValue()).length());
        }
        for (n2 = 0; n2 < this.b(); ++n2) {
            iterator = this.a(n2);
            boolean bl4 = bl2 || bl3;
            iterator.a(l2, bl4, (String)object, (Map<String, SpannableStringBuilder>)entry);
        }
        if (bl3) {
            iterator = b.a((String)object, entry);
            for (n2 = iterator.length() - 1; n2 >= 0 && iterator.charAt(n2) == ' '; --n2) {
            }
            if (n2 >= 0 && iterator.charAt(n2) != '\n') {
                iterator.append('\n');
            }
        }
        iterator = entry.entrySet().iterator();
        while (iterator.hasNext()) {
            entry = iterator.next();
            this.j.put((String)entry.getKey(), ((SpannableStringBuilder)entry.getValue()).length());
        }
    }

    public final void a(b b2) {
        if (this.k == null) {
            this.k = new ArrayList<b>();
        }
        this.k.add(b2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final void a(Map<String, d> var1_1, Map<String, SpannableStringBuilder> var2_2) {
        var5_3 = this.j.entrySet().iterator();
        block5 : do {
            block32 : {
                if (var5_3.hasNext() == false) return;
                var3_4 = var5_3.next();
                var4_5 = var3_4.getKey();
                var8_8 = this.i.containsKey(var4_5) != false ? this.i.get(var4_5) : 0;
                var6_6 = var2_2.get(var4_5);
                var10_10 = var3_4.getValue();
                if (var8_8 != var10_10) {
                    var4_5 = this.f;
                    var7_7 = this.h;
                    if (var4_5 == null && var7_7 == null) {
                        var3_4 = null;
                    } else if (var4_5 == null && var7_7.length == 1) {
                        var3_4 = var1_1.get(var7_7[0]);
                    } else if (var4_5 == null && var7_7.length > 1) {
                        var4_5 = new d();
                        var11_11 = var7_7.length;
                        var9_9 = 0;
                        do {
                            var3_4 = var4_5;
                            if (var9_9 < var11_11) {
                                var4_5.a(var1_1.get(var7_7[var9_9]));
                                ++var9_9;
                                continue;
                            }
                            break;
                            break;
                        } while (true);
                    } else if (var4_5 != null && var7_7 != null && var7_7.length == 1) {
                        var3_4 = var4_5.a(var1_1.get(var7_7[0]));
                    } else {
                        var3_4 = var4_5;
                        if (var4_5 != null) {
                            var3_4 = var4_5;
                            if (var7_7 != null) {
                                var3_4 = var4_5;
                                if (var7_7.length > 1) {
                                    var11_11 = var7_7.length;
                                    var9_9 = 0;
                                    do {
                                        var3_4 = var4_5;
                                        if (var9_9 >= var11_11) break;
                                        var4_5.a(var1_1.get(var7_7[var9_9]));
                                        ++var9_9;
                                    } while (true);
                                }
                            }
                        }
                    }
                    if (var3_4 != null) {
                        if (var3_4.a() != -1) {
                            var6_6.setSpan((Object)new StyleSpan(var3_4.a()), var8_8, var10_10, 33);
                        }
                        var9_9 = var3_4.f == 1 ? 1 : 0;
                        if (var9_9 != 0) {
                            var6_6.setSpan((Object)new StrikethroughSpan(), var8_8, var10_10, 33);
                        }
                        var9_9 = var3_4.g == 1 ? 1 : 0;
                        if (var9_9 != 0) {
                            var6_6.setSpan((Object)new UnderlineSpan(), var8_8, var10_10, 33);
                        }
                        if (var3_4.c) {
                            if (!var3_4.c) {
                                throw new IllegalStateException("Font color has not been defined.");
                            }
                            var6_6.setSpan((Object)new ForegroundColorSpan(var3_4.b), var8_8, var10_10, 33);
                        }
                        if (var3_4.e) {
                            if (!var3_4.e) {
                                throw new IllegalStateException("Background color has not been defined.");
                            }
                            var6_6.setSpan((Object)new BackgroundColorSpan(var3_4.d), var8_8, var10_10, 33);
                        }
                        if (var3_4.a != null) {
                            var6_6.setSpan((Object)new TypefaceSpan(var3_4.a), var8_8, var10_10, 33);
                        }
                        if (var3_4.n != null) {
                            var6_6.setSpan((Object)new AlignmentSpan.Standard(var3_4.n), var8_8, var10_10, 33);
                        }
                        switch (var3_4.j) {
                            case 1: {
                                var6_6.setSpan((Object)new AbsoluteSizeSpan((int)var3_4.k, true), var8_8, var10_10, 33);
                                ** break;
                            }
                            case 2: {
                                var6_6.setSpan((Object)new RelativeSizeSpan(var3_4.k), var8_8, var10_10, 33);
                            }
lbl73: // 3 sources:
                            default: {
                                break block32;
                            }
                            case 3: 
                        }
                        var6_6.setSpan((Object)new RelativeSizeSpan(var3_4.k / 100.0f), var8_8, var10_10, 33);
                    }
                }
            }
            var8_8 = 0;
            do {
                if (var8_8 >= this.b()) continue block5;
                this.a(var8_8).a(var1_1, var2_2);
                ++var8_8;
            } while (true);
            break;
        } while (true);
    }

    public final long[] a() {
        Object object = new TreeSet<Long>();
        this.a((TreeSet<Long>)object, false);
        long[] arrl = new long[object.size()];
        object = object.iterator();
        int n2 = 0;
        while (object.hasNext()) {
            arrl[n2] = (Long)object.next();
            ++n2;
        }
        return arrl;
    }
}

