/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f.c;

final class c {
    public final float a;
    public final float b;
    public final int c;
    public final float d;

    public c() {
        this(Float.MIN_VALUE, Float.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE);
    }

    public c(float f2, float f3, int n2, float f4) {
        this.a = f2;
        this.b = f3;
        this.c = n2;
        this.d = f4;
    }
}

