/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 */
package com.google.android.exoplayer2.f.c;

import android.text.Layout;

public final class d {
    String a;
    int b;
    boolean c;
    int d;
    boolean e;
    int f = -1;
    int g = -1;
    int h = -1;
    int i = -1;
    int j = -1;
    float k;
    String l;
    d m;
    Layout.Alignment n;

    /*
     * Enabled aggressive block sorting
     */
    public final int a() {
        int n2 = 0;
        if (this.h == -1 && this.i == -1) {
            return -1;
        }
        int n3 = this.h == 1 ? 1 : 0;
        if (this.i == 1) {
            n2 = 2;
        }
        return n3 | n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final d a(int n2) {
        boolean bl2 = this.m == null;
        a.a.a.a.d.b(bl2);
        this.b = n2;
        this.c = true;
        return this;
    }

    public final d a(d d2) {
        if (d2 != null) {
            if (!this.c && d2.c) {
                this.a(d2.b);
            }
            if (this.h == -1) {
                this.h = d2.h;
            }
            if (this.i == -1) {
                this.i = d2.i;
            }
            if (this.a == null) {
                this.a = d2.a;
            }
            if (this.f == -1) {
                this.f = d2.f;
            }
            if (this.g == -1) {
                this.g = d2.g;
            }
            if (this.n == null) {
                this.n = d2.n;
            }
            if (this.j == -1) {
                this.j = d2.j;
                this.k = d2.k;
            }
            if (!this.e && d2.e) {
                this.b(d2.d);
            }
        }
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final d a(boolean bl2) {
        int n2 = 1;
        boolean bl3 = this.m == null;
        a.a.a.a.d.b(bl3);
        if (!bl2) {
            n2 = 0;
        }
        this.f = n2;
        return this;
    }

    public final d b(int n2) {
        this.d = n2;
        this.e = true;
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final d b(boolean bl2) {
        int n2 = 1;
        boolean bl3 = this.m == null;
        a.a.a.a.d.b(bl3);
        if (!bl2) {
            n2 = 0;
        }
        this.g = n2;
        return this;
    }
}

