/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.SpannableStringBuilder
 */
package com.google.android.exoplayer2.f.c;

import android.text.Layout;
import android.text.SpannableStringBuilder;
import com.google.android.exoplayer2.f.c.b;
import com.google.android.exoplayer2.f.c.c;
import com.google.android.exoplayer2.f.c.d;
import com.google.android.exoplayer2.i.o;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

final class e
implements com.google.android.exoplayer2.f.e {
    private final b a;
    private final long[] b;
    private final Map<String, d> c;
    private final Map<String, c> d;

    public e(b b2, Map<String, d> map, Map<String, c> map2) {
        this.a = b2;
        this.d = map2;
        this.c = Collections.unmodifiableMap(map);
        this.b = b2.a();
    }

    @Override
    public final int a(long l2) {
        int n2 = o.a(this.b, l2, false, false);
        if (n2 < this.b.length) {
            return n2;
        }
        return -1;
    }

    @Override
    public final long a_(int n2) {
        return this.b[n2];
    }

    @Override
    public final int b() {
        return this.b.length;
    }

    @Override
    public final List<com.google.android.exoplayer2.f.b> b(long l2) {
        Object object = this.a;
        Map<String, d> object22 = this.c;
        Map<String, c> map = this.d;
        TreeMap<String, SpannableStringBuilder> treeMap = new TreeMap<String, SpannableStringBuilder>();
        object.a(l2, false, object.g, treeMap);
        object.a(object22, treeMap);
        object = new ArrayList();
        for (Map.Entry entry : treeMap.entrySet()) {
            c c2 = map.get(entry.getKey());
            object.add(new com.google.android.exoplayer2.f.b((CharSequence)b.a((SpannableStringBuilder)entry.getValue()), null, c2.b, c2.c, Integer.MIN_VALUE, c2.a, Integer.MIN_VALUE, c2.d));
        }
        return object;
    }
}

