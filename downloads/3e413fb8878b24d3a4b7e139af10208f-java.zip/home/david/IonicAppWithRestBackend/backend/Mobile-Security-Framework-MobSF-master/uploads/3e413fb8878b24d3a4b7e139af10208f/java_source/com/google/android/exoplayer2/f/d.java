/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f;

import com.google.android.exoplayer2.f.c;
import com.google.android.exoplayer2.f.j;

final class d
extends j {
    private final c d;

    public d(c c2) {
        this.d = c2;
    }

    @Override
    public final void e() {
        this.d.a(this);
    }
}

