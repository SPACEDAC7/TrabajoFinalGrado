/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f.d;

import com.google.android.exoplayer2.f.c;
import com.google.android.exoplayer2.f.d.b;
import com.google.android.exoplayer2.f.e;
import com.google.android.exoplayer2.i.i;

public final class a
extends c {
    private final i c = new i();

    public a() {
        super("Tx3gDecoder");
    }

    @Override
    protected final e a(byte[] arrby, int n2) {
        this.c.a(arrby, n2);
        n2 = this.c.f();
        if (n2 == 0) {
            return b.a;
        }
        return new b(new com.google.android.exoplayer2.f.b(this.c.e(n2)));
    }
}

