/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f.d;

import a.a.a.a.d;
import com.google.android.exoplayer2.f.e;
import java.util.Collections;
import java.util.List;

final class b
implements e {
    public static final b a = new b();
    private final List<com.google.android.exoplayer2.f.b> b;

    private b() {
        this.b = Collections.emptyList();
    }

    public b(com.google.android.exoplayer2.f.b b2) {
        this.b = Collections.singletonList(b2);
    }

    @Override
    public final int a(long l2) {
        if (l2 < 0) {
            return 0;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a_(int n2) {
        boolean bl2 = n2 == 0;
        d.a(bl2);
        return 0;
    }

    @Override
    public final int b() {
        return 1;
    }

    @Override
    public final List<com.google.android.exoplayer2.f.b> b(long l2) {
        if (l2 >= 0) {
            return this.b;
        }
        return Collections.emptyList();
    }
}

