/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f;

import com.google.android.exoplayer2.f.b;
import java.util.List;

public interface e {
    public int a(long var1);

    public long a_(int var1);

    public int b();

    public List<b> b(long var1);
}

