/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 */
package com.google.android.exoplayer2.f.e;

import android.text.TextUtils;
import com.google.android.exoplayer2.f.e.d;
import com.google.android.exoplayer2.i.b;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.o;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class a {
    private static final Pattern a = Pattern.compile("\\[voice=\"([^\"]*)\"\\]");
    private final i b = new i();
    private final StringBuilder c = new StringBuilder();

    /*
     * Enabled aggressive block sorting
     */
    private static String a(i i2, StringBuilder charSequence) {
        void var1_3;
        String string;
        a.b(i2);
        if (i2.b() == 0) {
            return var1_3;
        }
        String string2 = string = a.b(i2, charSequence);
        if (!"".equals(string)) {
            return var1_3;
        }
        return "" + (char)i2.e();
    }

    private static String b(i i2, StringBuilder stringBuilder) {
        boolean bl2 = false;
        stringBuilder.setLength(0);
        int n2 = i2.b;
        int n3 = i2.c;
        while (n2 < n3 && !bl2) {
            char c2 = i2.a[n2];
            if (c2 >= 'A' && c2 <= 'Z' || c2 >= 'a' && c2 <= 'z' || c2 >= '0' && c2 <= '9' || c2 == '#' || c2 == '-' || c2 == '.' || c2 == '_') {
                ++n2;
                stringBuilder.append(c2);
                continue;
            }
            bl2 = true;
        }
        i2.d(n2 - i2.b);
        return stringBuilder.toString();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void b(i var0) {
        var2_1 = 1;
        while (var0.b() > 0) {
            if (var2_1 == 0) return;
            var2_1 = var0.b;
            switch (var0.a[var2_1]) {
                default: {
                    var2_1 = 0;
                    break;
                }
                case '\t': 
                case '\n': 
                case '\f': 
                case '\r': 
                case ' ': {
                    var0.d(1);
                    var2_1 = 1;
                }
            }
            if (var2_1 != 0) ** GOTO lbl-1000
            var2_1 = var0.b;
            var3_3 = var0.c;
            var1_2 = var0.a;
            if (var2_1 + 2 > var3_3) ** GOTO lbl-1000
            var4_4 = var2_1 + 1;
            if (var1_2[var2_1] == 47 && var1_2[var4_4] == 42) {
                ++var4_4;
                while (var4_4 + 1 < var3_3) {
                    var6_6 = var4_4 + 1;
                    var5_5 = var3_3;
                    var2_1 = var6_6;
                    if (var1_2[var4_4] == '*') {
                        var5_5 = var3_3;
                        var2_1 = var6_6;
                        if (var1_2[var6_6] == '/') {
                            var2_1 = var5_5 = var6_6 + 1;
                        }
                    }
                    var3_3 = var5_5;
                    var4_4 = var2_1;
                }
                var0.d(var3_3 - var0.b);
                var2_1 = 1;
            } else lbl-1000: // 2 sources:
            {
                var2_1 = 0;
            }
            if (var2_1 != 0) lbl-1000: // 2 sources:
            {
                var2_1 = 1;
                continue;
            }
            var2_1 = 0;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final d a(i var1_1) {
        block24 : {
            this.c.setLength(0);
            var8_2 = var1_1.b;
            while (!TextUtils.isEmpty((CharSequence)var1_1.s())) {
            }
            this.b.a(var1_1.a, var1_1.b);
            this.b.c(var8_2);
            var2_3 = this.b;
            var3_4 = this.c;
            a.b((i)var2_3);
            if (var2_3.b() < 5) {
                return null;
            }
            if (!"::cue".equals(var2_3.e(5))) {
                return null;
            }
            var8_2 = var2_3.b;
            var4_7 = a.a((i)var2_3, var3_4);
            if (var4_7 == null) {
                return null;
            }
            if (!"{".equals(var4_7)) ** GOTO lbl22
            var2_3.c(var8_2);
            var1_1 = "";
            ** GOTO lbl27
lbl22: // 1 sources:
            var1_1 = null;
            if (!"(".equals(var4_7)) ** GOTO lbl55
            var10_9 = var2_3.c;
            var8_2 = 0;
            ** GOTO lbl51
lbl27: // 2 sources:
            do {
                if (var1_1 == null) return null;
                if (!"{".equals(a.a(this.b, this.c))) {
                    return null;
                }
                var4_7 = new d();
                if (!"".equals(var1_1)) {
                    var8_2 = var1_1.indexOf(91);
                    var2_3 = var1_1;
                    if (var8_2 != -1) {
                        var2_3 = a.a.matcher(var1_1.substring(var8_2));
                        if (var2_3.matches()) {
                            var4_7.d = var2_3.group(1);
                        }
                        var2_3 = var1_1.substring(0, var8_2);
                    }
                    var1_1 = var2_3.split("\\.");
                    var2_3 = var1_1[0];
                    var8_2 = var2_3.indexOf(35);
                    if (var8_2 != -1) {
                        var4_7.b = var2_3.substring(0, var8_2);
                        var4_7.a = var2_3.substring(var8_2 + 1);
                    } else {
                        var4_7.b = var2_3;
                    }
                    if (var1_1.length > 1) {
                        var4_7.c = Arrays.asList((String[])Arrays.copyOfRange(var1_1, 1, var1_1.length));
                    }
                }
                break block24;
                break;
            } while (true);
lbl51: // 2 sources:
            for (var9_8 = var2_3.b; var9_8 < var10_9 && var8_2 == 0; ++var9_8) {
                var8_2 = var2_3.a[var9_8] == ')' ? 1 : 0;
            }
            var1_1 = var2_3.e(var9_8 - 1 - var2_3.b).trim();
lbl55: // 2 sources:
            if (")".equals(var2_3 = a.a((i)var2_3, var3_4)) == false) return null;
            ** while (var2_3 != null)
lbl57: // 1 sources:
            return null;
        }
        var1_1 = null;
        var9_8 = 0;
        do {
            block25 : {
                if (var9_8 != 0) {
                    if ("}".equals(var1_1) == false) return null;
                    return var4_7;
                }
                var10_9 = this.b.b;
                var3_6 = a.a(this.b, this.c);
                var8_2 = var3_6 == null || "}".equals(var3_6) != false ? 1 : 0;
                var9_8 = var8_2;
                var1_1 = var3_6;
                if (var8_2 != 0) continue;
                this.b.c(var10_9);
                var5_10 = this.b;
                var7_13 = this.c;
                a.b(var5_10);
                var6_11 = a.b(var5_10, var7_13);
                var9_8 = var8_2;
                var1_1 = var3_6;
                if ("".equals(var6_11)) continue;
                var9_8 = var8_2;
                var1_1 = var3_6;
                if (!":".equals(a.a(var5_10, var7_13))) continue;
                a.b(var5_10);
                var1_1 = new StringBuilder();
                var9_8 = 0;
                while (var9_8 == 0) {
                    var10_9 = var5_10.b;
                    var2_3 = a.a(var5_10, var7_13);
                    if (var2_3 == null) {
                        var2_3 = null;
                        break block25;
                    }
                    if ("}".equals(var2_3) || ";".equals(var2_3)) {
                        var5_10.c(var10_9);
                        var9_8 = 1;
                        continue;
                    }
                    var1_1.append((String)var2_3);
                }
                var2_3 = var1_1.toString();
            }
            var9_8 = var8_2;
            var1_1 = var3_6;
            if (var2_3 == null) continue;
            var9_8 = var8_2;
            var1_1 = var3_6;
            if ("".equals(var2_3)) continue;
            var10_9 = var5_10.b;
            var7_14 = a.a(var5_10, var7_13);
            if (!";".equals(var7_14)) {
                var9_8 = var8_2;
                var1_1 = var3_6;
                if (!"}".equals(var7_14)) continue;
                var5_10.c(var10_9);
            }
            if ("color".equals(var6_11)) {
                var4_7.f = b.b((String)var2_3);
                var4_7.g = true;
                var9_8 = var8_2;
                var1_1 = var3_6;
                continue;
            }
            if ("background-color".equals(var6_11)) {
                var4_7.h = b.b((String)var2_3);
                var4_7.i = true;
                var9_8 = var8_2;
                var1_1 = var3_6;
                continue;
            }
            if ("text-decoration".equals(var6_11)) {
                var9_8 = var8_2;
                var1_1 = var3_6;
                if (!"underline".equals(var2_3)) continue;
                var4_7.k = 1;
                var9_8 = var8_2;
                var1_1 = var3_6;
                continue;
            }
            if ("font-family".equals(var6_11)) {
                var4_7.e = o.d((String)var2_3);
                var9_8 = var8_2;
                var1_1 = var3_6;
                continue;
            }
            if ("font-weight".equals(var6_11)) {
                var9_8 = var8_2;
                var1_1 = var3_6;
                if (!"bold".equals(var2_3)) continue;
                var4_7.l = 1;
                var9_8 = var8_2;
                var1_1 = var3_6;
                continue;
            }
            var9_8 = var8_2;
            var1_1 = var3_6;
            if (!"font-style".equals(var6_11)) continue;
            var9_8 = var8_2;
            var1_1 = var3_6;
            if (!"italic".equals(var2_3)) continue;
            var4_7.m = 1;
            var9_8 = var8_2;
            var1_1 = var3_6;
        } while (true);
    }
}

