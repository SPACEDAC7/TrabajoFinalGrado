/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f.e;

import com.google.android.exoplayer2.f.c;
import com.google.android.exoplayer2.f.e.e;
import com.google.android.exoplayer2.f.e.f;
import com.google.android.exoplayer2.f.g;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.o;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class b
extends c {
    private static final int c = o.e("payl");
    private static final int d = o.e("sttg");
    private static final int e = o.e("vttc");
    private final i f = new i();
    private final e.a g = new e.a();

    public b() {
        super("Mp4WebvttDecoder");
    }

    private static com.google.android.exoplayer2.f.b a(i i2, e.a a2, int n2) {
        a2.a();
        while (n2 > 0) {
            if (n2 < 8) {
                throw new g("Incomplete vtt cue box header found.");
            }
            int n3 = i2.k();
            int n4 = i2.k();
            String string = new String(i2.a, i2.b, n3 -= 8);
            i2.d(n3);
            n3 = n2 - 8 - n3;
            if (n4 == d) {
                f.a(string, a2);
                n2 = n3;
                continue;
            }
            n2 = n3;
            if (n4 != c) continue;
            f.a(null, string.trim(), a2, Collections.<com.google.android.exoplayer2.f.e.d>emptyList());
            n2 = n3;
        }
        return a2.b();
    }

    @Override
    protected final /* synthetic */ com.google.android.exoplayer2.f.e a(byte[] object, int n2) {
        this.f.a((byte[])object, n2);
        object = new ArrayList();
        while (this.f.b() > 0) {
            if (this.f.b() < 8) {
                throw new g("Incomplete Mp4Webvtt Top Level box header found.");
            }
            n2 = this.f.k();
            if (this.f.k() == e) {
                object.add(b.a(this.f, this.g, n2 - 8));
                continue;
            }
            this.f.d(n2 - 8);
        }
        return new com.google.android.exoplayer2.f.e.c((List<com.google.android.exoplayer2.f.b>)object);
    }
}

