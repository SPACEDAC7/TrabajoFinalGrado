/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f.e;

import a.a.a.a.d;
import com.google.android.exoplayer2.f.b;
import com.google.android.exoplayer2.f.e;
import java.util.Collections;
import java.util.List;

final class c
implements e {
    private final List<b> a;

    public c(List<b> list) {
        this.a = Collections.unmodifiableList(list);
    }

    @Override
    public final int a(long l2) {
        if (l2 < 0) {
            return 0;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a_(int n2) {
        boolean bl2 = n2 == 0;
        d.a(bl2);
        return 0;
    }

    @Override
    public final int b() {
        return 1;
    }

    @Override
    public final List<b> b(long l2) {
        if (l2 >= 0) {
            return this.a;
        }
        return Collections.emptyList();
    }
}

