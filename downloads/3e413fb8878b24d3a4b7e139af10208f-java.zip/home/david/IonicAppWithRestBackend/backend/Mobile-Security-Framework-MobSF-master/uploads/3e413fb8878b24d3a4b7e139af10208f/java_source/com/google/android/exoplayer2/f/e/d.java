/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 */
package com.google.android.exoplayer2.f.e;

import android.text.Layout;
import java.util.Collections;
import java.util.List;

final class d {
    String a = "";
    String b = "";
    List<String> c = Collections.emptyList();
    String d = "";
    String e = null;
    int f;
    boolean g = false;
    int h;
    boolean i = false;
    int j = -1;
    int k = -1;
    int l = -1;
    int m = -1;
    int n = -1;
    float o;
    Layout.Alignment p = null;

    static int a(int n2, String string, String string2, int n3) {
        if (string.isEmpty() || n2 == -1) {
            return n2;
        }
        if (string.equals(string2)) {
            return n2 + n3;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int a() {
        int n2 = 0;
        if (this.l == -1 && this.m == -1) {
            return -1;
        }
        int n3 = this.l == 1 ? 1 : 0;
        if (this.m == 1) {
            n2 = 2;
        }
        return n3 | n2;
    }
}

