/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.SpannableStringBuilder
 *  android.util.Log
 */
package com.google.android.exoplayer2.f.e;

import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.util.Log;
import com.google.android.exoplayer2.f.b;

final class e
extends b {
    public final long k;
    public final long l;

    public e(long l2, long l3, CharSequence charSequence, Layout.Alignment alignment, float f2, int n2, int n3, float f3, int n4, float f4) {
        super(charSequence, alignment, f2, n2, n3, f3, n4, f4);
        this.k = l2;
        this.l = l3;
    }

    public e(CharSequence charSequence) {
        this(charSequence, 0);
    }

    private e(CharSequence charSequence, byte by2) {
        this(0, 0, charSequence, null, Float.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE);
    }

    public static final class a {
        long a;
        long b;
        SpannableStringBuilder c;
        Layout.Alignment d;
        float e;
        int f;
        int g;
        float h;
        int i;
        float j;

        public a() {
            this.a();
        }

        public final void a() {
            this.a = 0;
            this.b = 0;
            this.c = null;
            this.d = null;
            this.e = Float.MIN_VALUE;
            this.f = Integer.MIN_VALUE;
            this.g = Integer.MIN_VALUE;
            this.h = Float.MIN_VALUE;
            this.i = Integer.MIN_VALUE;
            this.j = Float.MIN_VALUE;
        }

        /*
         * Enabled aggressive block sorting
         */
        public final e b() {
            if (this.h == Float.MIN_VALUE) return new e(this.a, this.b, (CharSequence)this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
            if (this.i != Integer.MIN_VALUE) return new e(this.a, this.b, (CharSequence)this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
            if (this.d == null) {
                this.i = Integer.MIN_VALUE;
                return new e(this.a, this.b, (CharSequence)this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
            }
            switch (.a[this.d.ordinal()]) {
                default: {
                    Log.w((String)"WebvttCueBuilder", (String)("Unrecognized alignment: " + (Object)this.d));
                    this.i = 0;
                    return new e(this.a, this.b, (CharSequence)this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
                }
                case 1: {
                    this.i = 0;
                    return new e(this.a, this.b, (CharSequence)this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
                }
                case 2: {
                    this.i = 1;
                    return new e(this.a, this.b, (CharSequence)this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
                }
                case 3: 
            }
            this.i = 2;
            return new e(this.a, this.b, (CharSequence)this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
        }
    }

}

