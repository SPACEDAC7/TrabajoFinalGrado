/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.SpannableStringBuilder
 *  android.text.style.AbsoluteSizeSpan
 *  android.text.style.AlignmentSpan
 *  android.text.style.AlignmentSpan$Standard
 *  android.text.style.BackgroundColorSpan
 *  android.text.style.ForegroundColorSpan
 *  android.text.style.RelativeSizeSpan
 *  android.text.style.StrikethroughSpan
 *  android.text.style.StyleSpan
 *  android.text.style.TypefaceSpan
 *  android.text.style.UnderlineSpan
 *  android.util.Log
 */
package com.google.android.exoplayer2.f.e;

import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.AlignmentSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import com.google.android.exoplayer2.f.e.d;
import com.google.android.exoplayer2.f.e.e;
import com.google.android.exoplayer2.f.e.h;
import com.google.android.exoplayer2.i.i;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class f {
    public static final Pattern a = Pattern.compile("^(\\S+)\\s+-->\\s+(\\S+)(.*)?$");
    private static final Pattern b = Pattern.compile("(\\S+?):(\\S+)");
    private final StringBuilder c = new StringBuilder();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int a(String var0) {
        var2_1 = 0;
        var1_2 = -1;
        switch (var0.hashCode()) {
            case 109757538: {
                if (var0.equals("start")) {
                    var1_2 = 0;
                    ** break;
                }
                ** GOTO lbl17
            }
            case -1364013995: {
                if (var0.equals("center")) {
                    var1_2 = 1;
                    ** break;
                }
                ** GOTO lbl17
            }
            case -1074341483: {
                if (var0.equals("middle")) {
                    var1_2 = 2;
                }
            }
lbl17: // 8 sources:
            default: {
                ** GOTO lbl22
            }
            case 100571: 
        }
        if (var0.equals("end")) {
            var1_2 = 3;
        }
lbl22: // 4 sources:
        switch (var1_2) {
            default: {
                Log.w((String)"WebvttCueParser", (String)("Invalid anchor value: " + var0));
                var2_1 = Integer.MIN_VALUE;
            }
            case 0: {
                return var2_1;
            }
            case 1: 
            case 2: {
                return 1;
            }
            case 3: 
        }
        return 2;
    }

    /*
     * Exception decompiling
     */
    static void a(String var0, e.a var1_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void a(String var0, a var1_1, SpannableStringBuilder var2_2, List<d> var3_3, List<b> var4_4) {
        var8_5 = var1_1.b;
        var9_6 = var2_2.length();
        var5_7 = var1_1.a;
        switch (var5_7.hashCode()) {
            case 98: {
                if (!var5_7.equals("b")) ** GOTO lbl29
                var6_8 = 0;
                ** GOTO lbl36
            }
            case 105: {
                if (!var5_7.equals("i")) ** GOTO lbl29
                var6_8 = 1;
                ** GOTO lbl36
            }
            case 117: {
                if (!var5_7.equals("u")) ** GOTO lbl29
                var6_8 = 2;
                ** GOTO lbl36
            }
            case 99: {
                if (!var5_7.equals("c")) ** GOTO lbl29
                var6_8 = 3;
                ** GOTO lbl36
            }
            case 3314158: {
                if (!var5_7.equals("lang")) ** GOTO lbl29
                var6_8 = 4;
                ** GOTO lbl36
            }
            case 118: {
                if (!var5_7.equals("v")) ** GOTO lbl29
                var6_8 = 5;
                ** GOTO lbl36
            }
lbl29: // 7 sources:
            default: {
                ** GOTO lbl-1000
            }
            case 0: 
        }
        if (var5_7.equals("")) {
            var6_8 = 6;
        } else lbl-1000: // 2 sources:
        {
            var6_8 = -1;
        }
lbl36: // 8 sources:
        switch (var6_8) {
            default: {
                return;
            }
            case 0: {
                var2_2.setSpan((Object)new StyleSpan(1), var8_5, var9_6, 33);
                break;
            }
            case 1: {
                var2_2.setSpan((Object)new StyleSpan(2), var8_5, var9_6, 33);
                break;
            }
            case 2: {
                var2_2.setSpan((Object)new UnderlineSpan(), var8_5, var9_6, 33);
            }
            case 3: 
            case 4: 
            case 5: 
            case 6: 
        }
        var4_4.clear();
        f.a(var3_3, (String)var0, var1_1, var4_4);
        var10_9 = var4_4.size();
        var6_8 = 0;
        while (var6_8 < var10_9) {
            block33 : {
                var0 = var4_4.get((int)var6_8).b;
                if (var0 != null) {
                    if (var0.a() != -1) {
                        var2_2.setSpan((Object)new StyleSpan(var0.a()), var8_5, var9_6, 33);
                    }
                    var7_10 = var0.j == 1;
                    if (var7_10) {
                        var2_2.setSpan((Object)new StrikethroughSpan(), var8_5, var9_6, 33);
                    }
                    var7_10 = var0.k == 1;
                    if (var7_10) {
                        var2_2.setSpan((Object)new UnderlineSpan(), var8_5, var9_6, 33);
                    }
                    if (var0.g) {
                        if (!var0.g) {
                            throw new IllegalStateException("Font color not defined");
                        }
                        var2_2.setSpan((Object)new ForegroundColorSpan(var0.f), var8_5, var9_6, 33);
                    }
                    if (var0.i) {
                        if (!var0.i) {
                            throw new IllegalStateException("Background color not defined.");
                        }
                        var2_2.setSpan((Object)new BackgroundColorSpan(var0.h), var8_5, var9_6, 33);
                    }
                    if (var0.e != null) {
                        var2_2.setSpan((Object)new TypefaceSpan(var0.e), var8_5, var9_6, 33);
                    }
                    if (var0.p != null) {
                        var2_2.setSpan((Object)new AlignmentSpan.Standard(var0.p), var8_5, var9_6, 33);
                    }
                    switch (var0.n) {
                        case 1: {
                            var2_2.setSpan((Object)new AbsoluteSizeSpan((int)var0.o, true), var8_5, var9_6, 33);
                            ** break;
                        }
                        case 2: {
                            var2_2.setSpan((Object)new RelativeSizeSpan(var0.o), var8_5, var9_6, 33);
                        }
lbl81: // 3 sources:
                        default: {
                            break block33;
                        }
                        case 3: 
                    }
                    var2_2.setSpan((Object)new RelativeSizeSpan(var0.o / 100.0f), var8_5, var9_6, 33);
                }
            }
            ++var6_8;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static void a(String var0, String var1_1, e.a var2_2, List<d> var3_3) {
        var6_4 = new SpannableStringBuilder();
        var7_5 = new Stack<a>();
        var8_6 = new ArrayList<b>();
        var10_7 = 0;
        do {
            if (var10_7 >= var1_1.length()) ** GOTO lbl127
            var4_8 = var1_1.charAt(var10_7);
            switch (var4_8) {
                default: {
                    var6_4.append(var4_8);
                    ++var10_7;
                    ** break;
                }
                case '<': {
                    if (var10_7 + 1 >= var1_1.length()) {
                        ++var10_7;
                        ** break;
                    }
                    var12_12 = var1_1.charAt(var10_7 + 1) == '/' ? 1 : 0;
                    var11_11 = var1_1.indexOf(62, var10_7 + 1);
                    var11_11 = var11_11 == -1 ? var1_1.length() : ++var11_11;
                    var13_13 = var1_1.charAt(var11_11 - 2) == '/' ? 1 : 0;
                    var14_14 = var12_12 != 0 ? 2 : 1;
                    var15_15 = var13_13 != 0 ? var11_11 - 2 : var11_11 - 1;
                    var9_10 = var1_1.substring(var14_14 + var10_7, var15_15);
                    var5_9 = var9_10.trim();
                    var5_9 = var5_9.isEmpty() != false ? null : var5_9.split("[ \\.]")[0];
                    if (var5_9 != null) {
                        var10_7 = -1;
                        switch (var5_9.hashCode()) {
                            case 98: {
                                if (!var5_9.equals("b")) break;
                                var10_7 = 0;
                                break;
                            }
                            case 99: {
                                if (!var5_9.equals("c")) break;
                                var10_7 = 1;
                                break;
                            }
                            case 105: {
                                if (!var5_9.equals("i")) break;
                                var10_7 = 2;
                                break;
                            }
                            case 3314158: {
                                if (!var5_9.equals("lang")) break;
                                var10_7 = 3;
                                break;
                            }
                            case 117: {
                                if (!var5_9.equals("u")) break;
                                var10_7 = 4;
                                break;
                            }
                            case 118: {
                                if (!var5_9.equals("v")) break;
                                var10_7 = 5;
                                break;
                            }
                        }
                        switch (var10_7) {
                            default: {
                                var10_7 = 0;
                                break;
                            }
                            case 0: 
                            case 1: 
                            case 2: 
                            case 3: 
                            case 4: 
                            case 5: {
                                var10_7 = 1;
                            }
                        }
                        if (var10_7 != 0) {
                            if (var12_12 != 0) {
                                while (!var7_5.isEmpty()) {
                                    var9_10 = (a)var7_5.pop();
                                    f.a(var0, (a)var9_10, var6_4, var3_3, var8_6);
                                    if (!var9_10.a.equals(var5_9)) continue;
                                }
                                var10_7 = var11_11;
                                ** break;
                            }
                            if (var13_13 == 0) {
                                var7_5.push(a.a((String)var9_10, var6_4.length()));
                                var10_7 = var11_11;
                                ** break;
                            }
                        }
                    }
                    ** GOTO lbl134
                }
                case '&': {
                    var13_13 = var1_1.indexOf(59, var10_7 + 1);
                    var12_12 = var1_1.indexOf(32, var10_7 + 1);
                    if (var13_13 == -1) {
                        var11_11 = var12_12;
                    } else {
                        var11_11 = var13_13;
                        if (var12_12 != -1) {
                            var11_11 = Math.min(var13_13, var12_12);
                        }
                    }
                    if (var11_11 == -1) ** GOTO lbl122
                    var5_9 = var1_1.substring(var10_7 + 1, var11_11);
                    var10_7 = -1;
                    switch (var5_9.hashCode()) {
                        case 3464: {
                            if (var5_9.equals("lt")) {
                                var10_7 = 0;
                                ** break;
                            }
                            ** GOTO lbl98
                        }
                        case 3309: {
                            if (var5_9.equals("gt")) {
                                var10_7 = 1;
                                ** break;
                            }
                            ** GOTO lbl98
                        }
                        case 3374865: {
                            if (var5_9.equals("nbsp")) {
                                var10_7 = 2;
                            }
                        }
lbl98: // 8 sources:
                        default: {
                            ** GOTO lbl103
                        }
                        case 96708: 
                    }
                    if (var5_9.equals("amp")) {
                        var10_7 = 3;
                    }
lbl103: // 4 sources:
                    switch (var10_7) {
                        default: {
                            Log.w((String)"WebvttCueParser", (String)("ignoring unsupported entity: '&" + var5_9 + ";'"));
                            break;
                        }
                        case 0: {
                            var6_4.append('<');
                            break;
                        }
                        case 1: {
                            var6_4.append('>');
                            break;
                        }
                        case 2: {
                            var6_4.append(' ');
                            break;
                        }
                        case 3: {
                            var6_4.append('&');
                        }
                    }
                    if (var11_11 == var12_12) {
                        var6_4.append((CharSequence)" ");
                    }
                    var10_7 = var11_11 + 1;
                    ** break;
lbl122: // 1 sources:
                    var6_4.append(var4_8);
                    ++var10_7;
                    ** break;
lbl125: // 6 sources:
                    break;
                }
            }
            continue;
lbl127: // 1 sources:
            do {
                if (var7_5.isEmpty()) {
                    f.a(var0, a.a(), var6_4, var3_3, var8_6);
                    var2_2.c = var6_4;
                    return;
                }
                f.a(var0, (a)var7_5.pop(), var6_4, var3_3, var8_6);
            } while (true);
lbl134: // 1 sources:
            var10_7 = var11_11;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(List<d> list, String string, a a2, List<b> list2) {
        int n2 = list.size();
        int n3 = 0;
        do {
            int n4;
            if (n3 >= n2) {
                Collections.sort(list2);
                return;
            }
            d d2 = list.get(n3);
            String string2 = a2.a;
            String[] arrstring = a2.d;
            String string3 = a2.c;
            n4 = d2.a.isEmpty() && d2.b.isEmpty() && d2.c.isEmpty() && d2.d.isEmpty() ? (string2.isEmpty() ? 1 : 0) : ((n4 = d.a(d.a(d.a(0, d2.a, string, 1073741824), d2.b, string2, 2), d2.d, string3, 4)) == -1 || !Arrays.asList(arrstring).containsAll(d2.c) ? 0 : (n4 += d2.c.size() << 2));
            if (n4 > 0) {
                list2.add(new b(n4, d2));
            }
            ++n3;
        } while (true);
    }

    private static boolean a(String string, Matcher object, i i2, e.a a2, StringBuilder stringBuilder, List<d> list) {
        try {
            a2.a = h.a(object.group(1));
            a2.b = h.a(object.group(2));
        }
        catch (NumberFormatException var0_1) {
            Log.w((String)"WebvttCueParser", (String)("Skipping cue with bad header: " + object.group()));
            return false;
        }
        f.a(object.group(3), a2);
        stringBuilder.setLength(0);
        while ((object = i2.s()) != null && !object.isEmpty()) {
            if (stringBuilder.length() > 0) {
                stringBuilder.append("\n");
            }
            stringBuilder.append(object.trim());
        }
        f.a(string, stringBuilder.toString(), a2, list);
        return true;
    }

    final boolean a(i i2, e.a a2, List<d> list) {
        String string = i2.s();
        Object object = a.matcher(string);
        if (object.matches()) {
            return f.a(null, (Matcher)object, i2, a2, this.c, list);
        }
        object = i2.s();
        if ((object = a.matcher((CharSequence)object)).matches()) {
            return f.a(string.trim(), (Matcher)object, i2, a2, this.c, list);
        }
        return false;
    }

    static final class a {
        private static final String[] e = new String[0];
        public final String a;
        public final int b;
        public final String c;
        public final String[] d;

        private a(String string, int n2, String string2, String[] arrstring) {
            this.b = n2;
            this.a = string;
            this.c = string2;
            this.d = arrstring;
        }

        public static a a() {
            return new a("", 0, "", new String[0]);
        }

        /*
         * Enabled aggressive block sorting
         */
        public static a a(String string, int n2) {
            String[] arrstring = string.trim();
            if (arrstring.isEmpty()) {
                return null;
            }
            int n3 = arrstring.indexOf(" ");
            if (n3 == -1) {
                string = "";
            } else {
                string = arrstring.substring(n3).trim();
                arrstring = arrstring.substring(0, n3);
            }
            arrstring = arrstring.split("\\.");
            String string2 = arrstring[0];
            if (arrstring.length > 1) {
                arrstring = Arrays.copyOfRange(arrstring, 1, arrstring.length);
                return new a(string2, n2, string, arrstring);
            }
            arrstring = e;
            return new a(string2, n2, string, arrstring);
        }
    }

    static final class b
    implements Comparable<b> {
        public final int a;
        public final d b;

        public b(int n2, d d2) {
            this.a = n2;
            this.b = d2;
        }
    }

}

