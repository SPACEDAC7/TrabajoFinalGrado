/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 */
package com.google.android.exoplayer2.f.e;

import android.text.TextUtils;
import com.google.android.exoplayer2.f.c;
import com.google.android.exoplayer2.f.e.a;
import com.google.android.exoplayer2.f.e.d;
import com.google.android.exoplayer2.f.e.e;
import com.google.android.exoplayer2.f.e.f;
import com.google.android.exoplayer2.f.e.h;
import com.google.android.exoplayer2.f.e.i;
import java.util.ArrayList;
import java.util.List;

public final class g
extends c {
    private final f c = new f();
    private final com.google.android.exoplayer2.i.i d = new com.google.android.exoplayer2.i.i();
    private final e.a e = new e.a();
    private final a f = new a();
    private final List<d> g = new ArrayList<d>();

    public g() {
        super("WebvttDecoder");
    }

    private static int a(com.google.android.exoplayer2.i.i i2) {
        int n2 = 0;
        int n3 = -1;
        while (n3 == -1) {
            n2 = i2.b;
            String string = i2.s();
            if (string == null) {
                n3 = 0;
                continue;
            }
            if ("STYLE".equals(string)) {
                n3 = 2;
                continue;
            }
            if ("NOTE".startsWith(string)) {
                n3 = 1;
                continue;
            }
            n3 = 3;
        }
        i2.c(n2);
        return n3;
    }

    private static void b(com.google.android.exoplayer2.i.i i2) {
        while (!TextUtils.isEmpty((CharSequence)i2.s())) {
        }
    }

    @Override
    protected final /* synthetic */ com.google.android.exoplayer2.f.e a(byte[] object, int n2) {
        this.d.a((byte[])object, n2);
        this.e.a();
        this.g.clear();
        h.a(this.d);
        while (!TextUtils.isEmpty((CharSequence)this.d.s())) {
        }
        object = new ArrayList();
        while ((n2 = g.a(this.d)) != 0) {
            if (n2 == 1) {
                g.b(this.d);
                continue;
            }
            if (n2 == 2) {
                if (!object.isEmpty()) {
                    throw new com.google.android.exoplayer2.f.g("A style block was found after the first cue.");
                }
                this.d.s();
                d d2 = this.f.a(this.d);
                if (d2 == null) continue;
                this.g.add(d2);
                continue;
            }
            if (n2 != 3 || !this.c.a(this.d, this.e, this.g)) continue;
            object.add(this.e.b());
            this.e.a();
        }
        return new i((List<e>)object);
    }
}

