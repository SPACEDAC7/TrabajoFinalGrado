/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f.e;

import com.google.android.exoplayer2.f.g;
import com.google.android.exoplayer2.i.i;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class h {
    private static final Pattern a = Pattern.compile("^NOTE(( |\t).*)?$");
    private static final Pattern b = Pattern.compile("^\ufeff?WEBVTT(( |\t).*)?$");

    public static long a(String arrstring) {
        long l2 = 0;
        arrstring = arrstring.split("\\.", 2);
        String[] arrstring2 = arrstring[0].split(":");
        int n2 = arrstring2.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            l2 = l2 * 60 + Long.parseLong(arrstring2[i2]);
        }
        return (Long.parseLong(arrstring[1]) + l2 * 1000) * 1000;
    }

    public static void a(i object) {
        if ((object = object.s()) == null || !b.matcher((CharSequence)object).matches()) {
            throw new g("Expected WEBVTT. Got " + (String)object);
        }
    }

    public static float b(String string) {
        if (!string.endsWith("%")) {
            throw new NumberFormatException("Percentages must end with %");
        }
        return Float.parseFloat(string.substring(0, string.length() - 1)) / 100.0f;
    }
}

