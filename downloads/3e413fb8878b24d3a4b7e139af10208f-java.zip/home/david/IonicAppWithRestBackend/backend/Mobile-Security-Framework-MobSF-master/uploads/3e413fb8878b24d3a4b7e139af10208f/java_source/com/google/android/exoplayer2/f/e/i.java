/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.SpannableStringBuilder
 */
package com.google.android.exoplayer2.f.e;

import a.a.a.a.d;
import android.text.SpannableStringBuilder;
import com.google.android.exoplayer2.f.b;
import com.google.android.exoplayer2.f.e.e;
import com.google.android.exoplayer2.i.o;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class i
implements com.google.android.exoplayer2.f.e {
    private final List<e> a;
    private final int b;
    private final long[] c;
    private final long[] d;

    public i(List<e> list) {
        this.a = list;
        this.b = list.size();
        this.c = new long[this.b * 2];
        for (int i2 = 0; i2 < this.b; ++i2) {
            e e2 = list.get(i2);
            int n2 = i2 << 1;
            this.c[n2] = e2.k;
            this.c[n2 + 1] = e2.l;
        }
        this.d = Arrays.copyOf(this.c, this.c.length);
        Arrays.sort(this.d);
    }

    @Override
    public final int a(long l2) {
        int n2 = o.a(this.d, l2, false, false);
        if (n2 < this.d.length) {
            return n2;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a_(int n2) {
        boolean bl2 = true;
        boolean bl3 = n2 >= 0;
        d.a(bl3);
        bl3 = n2 < this.d.length ? bl2 : false;
        d.a(bl3);
        return this.d[n2];
    }

    @Override
    public final int b() {
        return this.d.length;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final List<b> b(long l2) {
        e e2 = null;
        int n2 = 0;
        e e3 = null;
        ArrayList<e> arrayList = null;
        while (n2 < this.b) {
            e e4;
            if (this.c[n2 << 1] <= l2 && l2 < this.c[(n2 << 1) + 1]) {
                if (arrayList == null) {
                    arrayList = new ArrayList<e>();
                }
                e4 = this.a.get(n2);
                boolean bl2 = e4.c == Float.MIN_VALUE && e4.f == Float.MIN_VALUE;
                if (bl2) {
                    if (e3 == null) {
                        e3 = e2;
                        e2 = e4;
                    } else if (e2 == null) {
                        e2 = new SpannableStringBuilder();
                        e2.append(e3.a).append((CharSequence)"\n").append(e4.a);
                        e4 = e3;
                        e3 = e2;
                        e2 = e4;
                    } else {
                        e2.append((CharSequence)"\n").append(e4.a);
                        e4 = e3;
                        e3 = e2;
                        e2 = e4;
                    }
                } else {
                    arrayList.add(e4);
                    e4 = e3;
                    e3 = e2;
                    e2 = e4;
                }
            } else {
                e4 = e3;
                e3 = e2;
                e2 = e4;
            }
            ++n2;
            e4 = e2;
            e2 = e3;
            e3 = e4;
        }
        return Collections.emptyList();
    }
}

