/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f;

import com.google.android.exoplayer2.b.c;
import com.google.android.exoplayer2.f.g;
import com.google.android.exoplayer2.f.i;
import com.google.android.exoplayer2.f.j;

public interface f
extends c<i, j, g> {
    @Override
    public void a(long var1);
}

