/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f;

public final class g
extends Exception {
    public g(String string) {
        super(string);
    }

    public g(String string, Throwable throwable) {
        super(string, throwable);
    }
}

