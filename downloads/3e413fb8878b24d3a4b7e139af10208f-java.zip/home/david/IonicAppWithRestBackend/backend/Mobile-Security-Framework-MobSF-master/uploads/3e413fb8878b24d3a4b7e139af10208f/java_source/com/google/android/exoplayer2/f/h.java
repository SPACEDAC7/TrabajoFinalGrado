/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.f.f;
import java.lang.reflect.Constructor;

public interface h {
    public static final h a = new h(){

        /*
         * Exception decompiling
         */
        private static Class<?> a(String var0) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        @Override
        public final boolean a(Format format) {
            if (.a(format.f) != null) {
                return true;
            }
            return false;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public final f b(Format object) {
            Class class_;
            try {
                class_ = .a(object.f);
                if (class_ == null) {
                    throw new IllegalArgumentException("Attempted to create decoder for unsupported format");
                }
                if (object.f.equals("application/cea-608") || object.f.equals("application/x-mp4-cea-608")) {
                    return (f)class_.asSubclass(f.class).getConstructor(String.class, Integer.TYPE).newInstance(object.f, object.y);
                }
            }
            catch (Exception var1_2) {
                throw new IllegalStateException("Unexpected error instantiating decoder", var1_2);
            }
            if (!object.f.equals("application/cea-708")) return (f)class_.asSubclass(f.class).getConstructor(new Class[0]).newInstance(new Object[0]);
            return (f)class_.asSubclass(f.class).getConstructor(Integer.TYPE).newInstance(object.y);
        }
    };

    public boolean a(Format var1);

    public f b(Format var1);

}

