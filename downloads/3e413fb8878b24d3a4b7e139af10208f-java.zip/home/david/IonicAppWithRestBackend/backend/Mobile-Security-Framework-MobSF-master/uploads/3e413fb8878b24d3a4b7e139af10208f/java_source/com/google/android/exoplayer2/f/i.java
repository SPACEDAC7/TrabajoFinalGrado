/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f;

import com.google.android.exoplayer2.b.e;

public final class i
extends e
implements Comparable<i> {
    public long e;

    public i() {
        super(1);
    }
}

