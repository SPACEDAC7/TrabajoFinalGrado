/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.f;

import com.google.android.exoplayer2.b.f;
import com.google.android.exoplayer2.f.b;
import com.google.android.exoplayer2.f.e;
import java.util.List;

public abstract class j
extends f
implements e {
    private e d;
    private long e;

    @Override
    public final int a(long l2) {
        return this.d.a(l2 - this.e);
    }

    @Override
    public final void a() {
        super.a();
        this.d = null;
    }

    public final void a(long l2, e e2, long l3) {
        this.b = l2;
        this.d = e2;
        l2 = l3;
        if (l3 == Long.MAX_VALUE) {
            l2 = this.b;
        }
        this.e = l2;
    }

    @Override
    public final long a_(int n2) {
        return this.d.a_(n2) + this.e;
    }

    @Override
    public final int b() {
        return this.d.b();
    }

    @Override
    public final List<b> b(long l2) {
        return this.d.b(l2 - this.e);
    }

    public abstract void e();
}

