/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.Looper
 *  android.os.Message
 */
package com.google.android.exoplayer2.f;

import a.a.a.a.d;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.b;
import com.google.android.exoplayer2.b.e;
import com.google.android.exoplayer2.f;
import com.google.android.exoplayer2.f.g;
import com.google.android.exoplayer2.f.h;
import com.google.android.exoplayer2.f.i;
import com.google.android.exoplayer2.f.j;
import java.util.Collections;
import java.util.List;

public final class k
extends com.google.android.exoplayer2.k
implements Handler.Callback {
    private final Handler i;
    private final a j;
    private final h k;
    private final f l;
    private boolean m;
    private boolean n;
    private com.google.android.exoplayer2.f.f o;
    private i p;
    private j q;
    private j r;
    private int s;

    public k(a a2, Looper looper) {
        this(a2, looper, h.a);
    }

    /*
     * Enabled aggressive block sorting
     */
    private k(a a2, Looper looper, h h2) {
        super(3);
        this.j = d.b(a2);
        a2 = looper == null ? null : new Handler(looper, (Handler.Callback)this);
        this.i = a2;
        this.k = h2;
        this.l = new f();
    }

    private void a(List<com.google.android.exoplayer2.f.b> list) {
        if (this.i != null) {
            this.i.obtainMessage(0, list).sendToTarget();
            return;
        }
        this.b(list);
    }

    private void b(List<com.google.android.exoplayer2.f.b> list) {
        this.j.a(list);
    }

    private void s() {
        this.p = null;
        this.s = -1;
        if (this.q != null) {
            this.q.e();
            this.q = null;
        }
        if (this.r != null) {
            this.r.e();
            this.r = null;
        }
    }

    private long t() {
        if (this.s == -1 || this.s >= this.q.b()) {
            return Long.MAX_VALUE;
        }
        return this.q.a_(this.s);
    }

    @Override
    public final int a(Format format) {
        if (this.k.a(format)) {
            return 3;
        }
        if ("text".equals(d.f(format.f))) {
            return 1;
        }
        return 0;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final void a(long var1_1, long var3_2) {
        if (this.n) {
            return;
        }
        if (this.r == null) {
            this.o.a(var1_1);
            this.r = (j)this.o.b();
        }
        if (this.d != 2) return;
        var6_3 = 0;
        var7_4 = 0;
        if (this.q != null) {
            var3_2 = this.t();
            var6_3 = var7_4;
            while (var3_2 <= var1_1) {
                ++this.s;
                var3_2 = this.t();
                var6_3 = 1;
            }
        }
        ** GOTO lbl21
        catch (g var5_5) {
            throw b.a(var5_5, this.c);
        }
lbl21: // 1 sources:
        var7_4 = var6_3;
        if (this.r != null) {
            if (this.r.c()) {
                var7_4 = var6_3;
                if (var6_3 == 0) {
                    var7_4 = var6_3;
                    if (this.t() == Long.MAX_VALUE) {
                        if (this.q != null) {
                            this.q.e();
                            this.q = null;
                        }
                        this.r.e();
                        this.r = null;
                        this.n = true;
                        var7_4 = var6_3;
                    }
                }
            } else {
                var7_4 = var6_3;
                if (this.r.b <= var1_1) {
                    if (this.q != null) {
                        this.q.e();
                    }
                    this.q = this.r;
                    this.r = null;
                    this.s = this.q.a(var1_1);
                    var7_4 = 1;
                }
            }
        }
        if (var7_4 != 0) {
            this.a(this.q.b(var1_1));
        }
        block7 : do {
            try {
                while (this.m == false) {
                    if (this.p == null) {
                        this.p = (i)this.o.a();
                        if (this.p == null) return;
                    }
                    if ((var6_3 = this.a(this.l, this.p)) != -4) continue block7;
                    var5_6 = this.p;
                    var5_6.a &= Integer.MAX_VALUE;
                    if (this.p.c()) {
                        this.m = true;
                    } else {
                        this.p.e = this.l.a.v;
                        this.p.f();
                    }
                    this.o.a(this.p);
                    this.p = null;
                }
                return;
            }
            catch (g var5_7) {
                throw b.a(var5_7, this.c);
            }
        } while (var6_3 != -3);
    }

    @Override
    protected final void a(long l2, boolean bl2) {
        this.a(Collections.<com.google.android.exoplayer2.f.b>emptyList());
        this.s();
        this.o.c();
        this.m = false;
        this.n = false;
    }

    @Override
    protected final void a(Format[] arrformat) {
        if (this.o != null) {
            this.o.d();
            this.p = null;
        }
        this.o = this.k.b(arrformat[0]);
    }

    public final boolean handleMessage(Message message) {
        switch (message.what) {
            default: {
                return false;
            }
            case 0: 
        }
        this.b((List)message.obj);
        return true;
    }

    @Override
    public final boolean k() {
        return true;
    }

    @Override
    public final boolean l() {
        return this.n;
    }

    @Override
    protected final void r() {
        this.a(Collections.<com.google.android.exoplayer2.f.b>emptyList());
        this.s();
        this.o.d();
        this.o = null;
        super.r();
    }

    public static interface a {
        public void a(List<com.google.android.exoplayer2.f.b> var1);
    }

}

