/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

import com.google.android.exoplayer2.n;

public final class g
extends IllegalStateException {
    public final n a;
    public final int b;
    public final long c;

    public g(n n2, int n3, long l2) {
        this.a = n2;
        this.b = n3;
        this.c = l2;
    }
}

