/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.g;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.e.f;
import com.google.android.exoplayer2.g.b;
import com.google.android.exoplayer2.h.c;

public final class a
extends b {
    private final c f;
    private final int g;
    private final long h;
    private final long i;
    private final long j;
    private final float k;
    private int l;
    private int m;

    /*
     * Enabled aggressive block sorting
     */
    public a(f f2, int[] arrn, c c2, int n2, long l2, long l3, long l4, float f3) {
        block2 : {
            super(f2, arrn);
            this.f = c2;
            this.g = n2;
            this.h = 1000 * l2;
            this.i = 1000 * l3;
            this.j = 1000 * l4;
            this.k = f3;
            l2 = this.f.a();
            l2 = l2 == -1 ? (long)this.g : (long)((float)l2 * this.k);
            int n3 = 0;
            for (n2 = 0; n2 < this.b; ++n2) {
                boolean bl2;
                if (Long.MIN_VALUE != Long.MIN_VALUE && (bl2 = this.e[n2] > Long.MIN_VALUE)) continue;
                if ((long)this.d[n2].b > l2) {
                    n3 = n2;
                    continue;
                }
                break block2;
            }
            n2 = n3;
        }
        this.l = n2;
        this.m = 1;
    }
}

