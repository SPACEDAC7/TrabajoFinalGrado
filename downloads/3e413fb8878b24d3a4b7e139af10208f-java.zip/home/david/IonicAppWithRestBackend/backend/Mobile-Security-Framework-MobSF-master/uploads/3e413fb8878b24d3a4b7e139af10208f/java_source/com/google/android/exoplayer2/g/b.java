/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.g;

import a.a.a.a.d;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.g.f;
import java.util.Arrays;
import java.util.Comparator;

public abstract class b
implements f {
    protected final com.google.android.exoplayer2.e.f a;
    protected final int b;
    protected final int[] c;
    final Format[] d;
    final long[] e;
    private int f;

    /*
     * Enabled aggressive block sorting
     */
    public /* varargs */ b(com.google.android.exoplayer2.e.f f2, int ... arrn) {
        int n2;
        int n3 = 0;
        boolean bl2 = arrn.length > 0;
        d.b(bl2);
        this.a = d.b(f2);
        this.b = arrn.length;
        this.d = new Format[this.b];
        for (n2 = 0; n2 < arrn.length; ++n2) {
            Format[] arrformat = this.d;
            int n4 = arrn[n2];
            arrformat[n2] = f2.b[n4];
        }
        Arrays.sort(this.d, new a(0));
        this.c = new int[this.b];
        n2 = n3;
        do {
            if (n2 >= this.b) {
                this.e = new long[this.b];
                return;
            }
            this.c[n2] = f2.a(this.d[n2]);
            ++n2;
        } while (true);
    }

    @Override
    public final Format a(int n2) {
        return this.d[n2];
    }

    @Override
    public final com.google.android.exoplayer2.e.f a() {
        return this.a;
    }

    @Override
    public final int b() {
        return this.c.length;
    }

    @Override
    public final int b(int n2) {
        return this.c[n2];
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (b)object;
        if (this.a != object.a) return false;
        if (Arrays.equals(this.c, object.c)) return true;
        return false;
    }

    public int hashCode() {
        if (this.f == 0) {
            this.f = System.identityHashCode(this.a) * 31 + Arrays.hashCode(this.c);
        }
        return this.f;
    }

    static final class a
    implements Comparator<Format> {
        private a() {
        }

        /* synthetic */ a(byte by2) {
            this();
        }
    }

}

