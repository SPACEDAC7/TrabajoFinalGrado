/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  android.text.TextUtils
 */
package com.google.android.exoplayer2.g;

import android.graphics.Point;
import android.text.TextUtils;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.e.g;
import com.google.android.exoplayer2.g.e;
import com.google.android.exoplayer2.g.f;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.k;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public final class c
extends e {
    private static final int[] b = new int[0];
    private final f.a c;
    private final AtomicReference<a> d;

    public c() {
        this(null);
    }

    public c(f.a a2) {
        this.c = a2;
        this.d = new AtomicReference<a>(new a());
    }

    private static int a(int n2, int n3) {
        int n4 = -1;
        if (n2 == -1) {
            n2 = n4;
            if (n3 == -1) {
                n2 = 0;
            }
            return n2;
        }
        if (n3 == -1) {
            return 1;
        }
        return n2 - n3;
    }

    private static int a(com.google.android.exoplayer2.e.f f2, int[] arrn, int n2, String string, int n3, int n4, List<Integer> list) {
        int n5 = 0;
        for (int i2 = 0; i2 < list.size(); ++i2) {
            int n6 = list.get(i2);
            if (!c.a(f2.b[n6], string, arrn[n6], n2, n3, n4)) continue;
            ++n5;
        }
        return n5;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static f a(g var0, int[][] var1_1, int var2_2, int var3_3, int var4_4, int var5_5, boolean var6_6, boolean var7_7, boolean var8_8) {
        var9_9 = null;
        var16_10 = 0;
        var18_11 = 0;
        var21_12 = -1;
        var20_13 = -1;
        var19_14 = 0;
        block0 : do {
            if (var18_11 >= var0.b) return null;
            var10_15 = var0.c[var18_11];
            var11_16 = c.a(var10_15, var4_4, var5_5, var6_6);
            var12_17 = var1_1[var18_11];
            var15_20 = 0;
            do {
                if (var15_20 >= var10_15.a) ** GOTO lbl34
                if (!c.a(var12_17[var15_20], var8_8)) ** GOTO lbl36
                var13_18 = var10_15.b[var15_20];
                var22_22 = !(var11_16.contains(var15_20) == false || var13_18.j != -1 && var13_18.j > var2_2 || var13_18.k != -1 && var13_18.k > var3_3);
                if (!var22_22 && !var7_7) ** GOTO lbl36
                var14_19 = var22_22 != false ? 2 : 1;
                var17_21 = var14_19;
                if (c.a(var12_17[var15_20], false)) {
                    var17_21 = var14_19 + 1000;
                }
                var14_19 = var17_21 > var19_14 ? 1 : 0;
                if (var17_21 != var19_14) ** GOTO lbl28
                var14_19 = var13_18.a() != var21_12 ? c.a(var13_18.a(), var21_12) : c.a(var13_18.b, var20_13);
                var14_19 = var22_22 ? (var14_19 > 0 ? 1 : 0) : (var14_19 < 0 ? 1 : 0);
                if (var14_19 == 0) ** GOTO lbl36
lbl28: // 2 sources:
                var20_13 = var13_18.b;
                var21_12 = var13_18.a();
                var9_9 = var10_15;
                var14_19 = var15_20;
                var19_14 = var17_21;
                ** GOTO lbl37
lbl34: // 1 sources:
                ++var18_11;
                continue block0;
lbl36: // 3 sources:
                var14_19 = var16_10;
lbl37: // 2 sources:
                ++var15_20;
                var16_10 = var14_19;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static f a(g var0, int[][] var1_1, String var2_2, String var3_3, boolean var4_4) {
        var5_5 = null;
        var11_6 = 0;
        var13_7 = 0;
        var14_8 = 0;
        block0 : do {
            if (var13_7 >= var0.b) return null;
            var6_9 = var0.c[var13_7];
            var7_10 = var1_1[var13_7];
            var10_13 = 0;
            do {
                if (var10_13 >= var6_9.a) ** GOTO lbl32
                if (!c.a(var7_10[var10_13], var4_4)) ** GOTO lbl34
                var8_11 = var6_9.b[var10_13];
                var9_12 = (var8_11.w & 1) != 0 ? 1 : 0;
                var12_14 = (var8_11.w & 2) != 0 ? 1 : 0;
                if (!c.a(var8_11, var2_2)) ** GOTO lbl19
                var9_12 = var9_12 != 0 ? 6 : (var12_14 == 0 ? 5 : 4);
                ** GOTO lbl24
lbl19: // 1 sources:
                if (var9_12 == 0) ** GOTO lbl22
                var9_12 = 3;
                ** GOTO lbl24
lbl22: // 1 sources:
                if (var12_14 == 0) ** GOTO lbl34
                var9_12 = c.a(var8_11, var3_3) != false ? 2 : 1;
lbl24: // 3 sources:
                var12_14 = var9_12;
                if (c.a(var7_10[var10_13], false)) {
                    var12_14 = var9_12 + 1000;
                }
                if (var12_14 <= var14_8) ** GOTO lbl34
                var5_5 = var6_9;
                var9_12 = var10_13;
                var14_8 = var12_14;
                ** GOTO lbl35
lbl32: // 1 sources:
                ++var13_7;
                continue block0;
lbl34: // 3 sources:
                var9_12 = var11_6;
lbl35: // 2 sources:
                ++var10_13;
                var11_6 = var9_12;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static f a(g var0, int[][] var1_1, String var2_2, boolean var3_3) {
        var13_4 = 0;
        var11_5 = 0;
        var10_6 = 0;
        var4_7 = null;
        block0 : do {
            if (var13_4 >= var0.b) return null;
            var5_8 = var0.c[var13_4];
            var6_9 = var1_1[var13_4];
            var9_12 = 0;
            do {
                if (var9_12 >= var5_8.a) ** GOTO lbl23
                if (!c.a(var6_9[var9_12], var3_3)) ** GOTO lbl25
                var7_10 = var5_8.b[var9_12];
                var8_11 = (var7_10.w & 1) != 0 ? 1 : 0;
                var8_11 = c.a(var7_10, var2_2) ? (var8_11 != 0 ? 4 : 3) : (var8_11 != 0 ? 2 : 1);
                var12_13 = var8_11;
                if (c.a(var6_9[var9_12], false)) {
                    var12_13 = var8_11 + 1000;
                }
                if (var12_13 <= var11_5) ** GOTO lbl25
                var8_11 = var9_12;
                var4_7 = var5_8;
                ** GOTO lbl27
lbl23: // 1 sources:
                ++var13_4;
                continue block0;
lbl25: // 2 sources:
                var8_11 = var10_6;
                var12_13 = var11_5;
lbl27: // 2 sources:
                ++var9_12;
                var11_5 = var12_13;
                var10_6 = var8_11;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static f a(g var0, int[][] var1_1, boolean var2_2) {
        var11_3 = 0;
        var8_4 = 0;
        var7_5 = 0;
        var3_6 = null;
        block0 : do {
            if (var11_3 >= var0.b) return null;
            var4_7 = var0.c[var11_3];
            var5_8 = var1_1[var11_3];
            var6_9 = 0;
            do {
                if (var6_9 >= var4_7.a) ** GOTO lbl22
                if (!c.a(var5_8[var6_9], var2_2)) ** GOTO lbl24
                var9_10 = (var4_7.b[var6_9].w & 1) != 0 ? 1 : 0;
                var10_11 = var9_10 != 0 ? 2 : 1;
                var9_10 = var10_11;
                if (c.a(var5_8[var6_9], false)) {
                    var9_10 = var10_11 + 1000;
                }
                if (var9_10 <= var8_4) ** GOTO lbl24
                var7_5 = var6_9;
                var3_6 = var4_7;
                ** GOTO lbl25
lbl22: // 1 sources:
                ++var11_3;
                continue block0;
lbl24: // 2 sources:
                var9_10 = var8_4;
lbl25: // 2 sources:
                ++var6_9;
                var8_4 = var9_10;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static List<Integer> a(com.google.android.exoplayer2.e.f var0, int var1_1, int var2_2, boolean var3_3) {
        var5_4 = new ArrayList<Integer>(var0.a);
        for (var7_5 = 0; var7_5 < var0.a; ++var7_5) {
            var5_4.add(var7_5);
        }
        if (var1_1 == Integer.MAX_VALUE) return var5_4;
        if (var2_2 == Integer.MAX_VALUE) {
            return var5_4;
        }
        var7_5 = Integer.MAX_VALUE;
        var8_6 = 0;
        while (var8_6 < var0.a) {
            var6_8 = var0.b[var8_6];
            var9_9 = var7_5;
            if (var6_8.j <= 0) ** GOTO lbl36
            var9_9 = var7_5;
            if (var6_8.k <= 0) ** GOTO lbl36
            var11_11 = var6_8.j;
            var12_12 = var6_8.k;
            if (!var3_3) ** GOTO lbl-1000
            var9_9 = var11_11 > var12_12 ? 1 : 0;
            var10_10 = var1_1 > var2_2 ? 1 : 0;
            if (var9_9 != var10_10) {
                var9_9 = var1_1;
                var10_10 = var2_2;
            } else lbl-1000: // 2 sources:
            {
                var9_9 = var2_2;
                var10_10 = var1_1;
            }
            var4_7 = var11_11 * var9_9 >= var12_12 * var10_10 ? new Point(var10_10, o.a(var10_10 * var12_12, var11_11)) : new Point(o.a(var9_9 * var11_11, var12_12), var9_9);
            var10_10 = var6_8.j * var6_8.k;
            var9_9 = var7_5;
            if (var6_8.j >= (int)((float)var4_7.x * 0.98f)) {
                var9_9 = var7_5;
                if (var6_8.k >= (int)((float)var4_7.y * 0.98f)) {
                    var9_9 = var7_5;
                    if (var10_10 < var7_5) {
                        var9_9 = var10_10;
                    }
                }
            }
lbl36: // 9 sources:
            ++var8_6;
            var7_5 = var9_9;
        }
        return var5_4;
    }

    private static boolean a(int n2, boolean bl2) {
        if ((n2 &= 3) == 3 || bl2 && n2 == 2) {
            return true;
        }
        return false;
    }

    private static boolean a(Format format, String string) {
        if (string != null && string.equals(o.b(format.x))) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean a(Format format, String string, int n2, int n3, int n4, int n5) {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (!c.a(n2, false)) return bl3;
        bl3 = bl2;
        if ((n2 & n3) == 0) return bl3;
        if (string != null) {
            bl3 = bl2;
            if (!o.a(format.f, string)) return bl3;
        }
        if (format.j != -1) {
            bl3 = bl2;
            if (format.j > n4) return bl3;
        }
        if (format.k == -1) return true;
        bl3 = bl2;
        if (format.k > n5) return bl3;
        return true;
    }

    private static void b(com.google.android.exoplayer2.e.f f2, int[] arrn, int n2, String string, int n3, int n4, List<Integer> list) {
        for (int i2 = list.size() - 1; i2 >= 0; --i2) {
            int n5 = list.get(i2);
            if (c.a(f2.b[n5], string, arrn[n5], n2, n3, n4)) continue;
            list.remove(i2);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final f[] a(k[] var1_1, g[] var2_2, int[][][] var3_3) {
        block14 : {
            block16 : {
                block15 : {
                    var6_4 = new f[var1_1.length];
                    var7_5 = this.d.get();
                    var16_6 = 0;
                    while (var16_6 < var1_1.length) {
                        switch (var1_1[var16_6].a) {
                            default: {
                                var6_4[var16_6] = c.a(var2_2[var16_6], var3_3[var16_6], var7_5.h);
                                break;
                            }
                            case 2: {
                                var5_8 = var1_1[var16_6];
                                var8_9 = var2_2[var16_6];
                                var9_10 = var3_3[var16_6];
                                var22_23 = var7_5.e;
                                var23_22 = var7_5.f;
                                var26_27 = var7_5.d;
                                var27_26 = var7_5.c;
                                var24_25 = var7_5.i;
                                var25_24 = var7_5.j;
                                var28_29 = var7_5.k;
                                var10_11 = this.c;
                                var29_28 = var7_5.g;
                                var30_30 = var7_5.h;
                                var4_7 = null;
                                if (var10_11 != null) {
                                    var17_17 = var26_27 != false ? 12 : 8;
                                    var18_19 = var27_26 != false && (var5_8.o() & var17_17) != 0;
                                    var19_18 = 0;
lbl28: // 2 sources:
                                    if (var19_18 < var8_9.b) {
                                        var11_12 = var8_9.c[var19_18];
                                        var12_13 = var9_10[var19_18];
                                        if (var11_12.a < 2) {
                                            var4_7 = c.b;
                                            break block14;
                                        }
                                        var13_14 = c.a(var11_12, var24_25, var25_24, var28_29);
                                        if (var13_14.size() < 2) {
                                            var4_7 = c.b;
                                            break block14;
                                        }
                                        var4_7 = null;
                                        if (var18_19) break block15;
                                        var14_15 = new HashSet<Object>();
                                        var15_16 = 0;
                                        for (var20_21 = 0; var20_21 < var13_14.size(); ++var20_21) {
                                            var21_20 = var13_14.get(var20_21);
                                            var5_8 = var11_12.b[var21_20].f;
                                            if (var14_15.contains(var5_8)) continue;
                                            var14_15.add(var5_8);
                                            var21_20 = c.a(var11_12, var12_13, var17_17, (String)var5_8, var22_23, var23_22, var13_14);
                                            if (var21_20 <= var15_16) continue;
                                            var4_7 = var5_8;
                                            var15_16 = var21_20;
                                        }
                                        break block16;
                                    }
                                    var4_7 = null;
                                }
lbl54: // 4 sources:
                                var5_8 = var4_7;
                                if (var4_7 == null) {
                                    var5_8 = c.a(var8_9, var9_10, var22_23, var23_22, var24_25, var25_24, var28_29, var29_28, var30_30);
                                }
                                var6_4[var16_6] = var5_8;
                                break;
                            }
                            case 1: {
                                var6_4[var16_6] = c.a(var2_2[var16_6], var3_3[var16_6], var7_5.a, var7_5.h);
                                break;
                            }
                            case 3: {
                                var6_4[var16_6] = c.a(var2_2[var16_6], var3_3[var16_6], var7_5.b, var7_5.a, var7_5.h);
                                break;
                            }
                        }
                        ++var16_6;
                    }
                    return var6_4;
                }
                var4_7 = null;
            }
            c.b(var11_12, var12_13, var17_17, (String)var4_7, var22_23, var23_22, var13_14);
            var4_7 = var13_14.size() < 2 ? c.b : o.a(var13_14);
        }
        if (var4_7.length <= 0) ** GOTO lbl77
        var4_7 = var10_11.a(var11_12, var4_7);
        ** GOTO lbl54
lbl77: // 1 sources:
        ++var19_18;
        ** GOTO lbl28
    }

    public static final class a {
        public final String a = null;
        public final String b = null;
        public final boolean c = false;
        public final boolean d = true;
        public final int e = Integer.MAX_VALUE;
        public final int f = Integer.MAX_VALUE;
        public final boolean g = true;
        public final boolean h = true;
        public final int i = Integer.MAX_VALUE;
        public final int j = Integer.MAX_VALUE;
        public final boolean k = true;

        public a() {
            this(0);
        }

        private a(byte by2) {
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public final boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (object == null) return false;
            if (this.getClass() != object.getClass()) {
                return false;
            }
            object = (a)object;
            if (this.c != object.c) return false;
            if (this.d != object.d) return false;
            if (this.e != object.e) return false;
            if (this.f != object.f) return false;
            if (this.g != object.g) return false;
            if (this.h != object.h) return false;
            if (this.k != object.k) return false;
            if (this.i != object.i) return false;
            if (this.j != object.j) return false;
            if (!TextUtils.equals((CharSequence)this.a, (CharSequence)object.a)) return false;
            if (TextUtils.equals((CharSequence)this.b, (CharSequence)object.b)) return true;
            return false;
        }

        /*
         * Enabled aggressive block sorting
         */
        public final int hashCode() {
            int n2 = 1;
            int n3 = this.a.hashCode();
            int n4 = this.b.hashCode();
            int n5 = this.c ? 1 : 0;
            int n6 = this.d ? 1 : 0;
            int n7 = this.e;
            int n8 = this.f;
            int n9 = this.g ? 1 : 0;
            int n10 = this.h ? 1 : 0;
            if (this.k) {
                return (((n10 + (n9 + (((n6 + (n5 + (n3 * 31 + n4) * 31) * 31) * 31 + n7) * 31 + n8) * 31) * 31) * 31 + n2) * 31 + this.i) * 31 + this.j;
            }
            n2 = 0;
            return (((n10 + (n9 + (((n6 + (n5 + (n3 * 31 + n4) * 31) * 31) * 31 + n7) * 31 + n8) * 31) * 31) * 31 + n2) * 31 + this.i) * 31 + this.j;
        }
    }

}

