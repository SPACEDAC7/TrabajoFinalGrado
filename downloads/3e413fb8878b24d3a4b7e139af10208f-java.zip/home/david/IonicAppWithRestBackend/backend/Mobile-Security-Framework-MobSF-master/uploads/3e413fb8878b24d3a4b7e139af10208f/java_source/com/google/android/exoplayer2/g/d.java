/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.g;

import com.google.android.exoplayer2.e.f;
import com.google.android.exoplayer2.g.b;

public final class d
extends b {
    private final int f = 0;
    private final Object g = null;

    public d(f f2, int n2) {
        this(f2, n2, 0);
    }

    private d(f f2, int n2, byte by2) {
        super(f2, n2);
    }
}

