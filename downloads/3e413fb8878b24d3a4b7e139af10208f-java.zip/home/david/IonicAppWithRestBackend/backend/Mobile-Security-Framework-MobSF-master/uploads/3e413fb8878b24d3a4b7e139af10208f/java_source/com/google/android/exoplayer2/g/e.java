/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 *  android.util.SparseBooleanArray
 */
package com.google.android.exoplayer2.g;

import android.support.design.widget.FloatingActionButton;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.g.f;
import com.google.android.exoplayer2.g.g;
import com.google.android.exoplayer2.g.h;
import com.google.android.exoplayer2.g.i;
import com.google.android.exoplayer2.k;
import com.google.android.exoplayer2.l;
import java.util.Arrays;
import java.util.Map;

public abstract class e
extends h {
    private final SparseArray<Map<com.google.android.exoplayer2.e.g, FloatingActionButton>> b = new SparseArray();
    private final SparseBooleanArray c = new SparseBooleanArray();
    private int d = 0;
    private a e;

    public final a a() {
        return this.e;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final i a(k[] var1_1, com.google.android.exoplayer2.e.g var2_2) {
        var7_3 = new int[var1_1.length + 1];
        var9_4 = new com.google.android.exoplayer2.e.f[var1_1.length + 1][];
        var4_5 = new int[var1_1.length + 1][][];
        for (var12_6 = 0; var12_6 < var9_4.length; ++var12_6) {
            var9_4[var12_6] = new com.google.android.exoplayer2.e.f[var2_2.b];
            var4_5[var12_6] = new int[var2_2.b][];
        }
        var6_7 = new int[var1_1.length];
        for (var12_6 = 0; var12_6 < var6_7.length; ++var12_6) {
            var6_7[var12_6] = var1_1[var12_6].o();
        }
        var15_8 = 0;
        block2 : do {
            if (var15_8 >= var2_2.b) {
                var5_12 = new com.google.android.exoplayer2.e.g[var1_1.length];
                var8_13 = new int[var1_1.length];
                for (var12_6 = 0; var12_6 < var1_1.length; ++var12_6) {
                    var13_14 = var7_3[var12_6];
                    var5_12[var12_6] = new com.google.android.exoplayer2.e.g(Arrays.copyOf(var9_4[var12_6], var13_14));
                    var4_5[var12_6] = (int[][])Arrays.copyOf(var4_5[var12_6], var13_14);
                    var8_13[var12_6] = var1_1[var12_6].a;
                }
                var12_6 = var7_3[var1_1.length];
                var9_4 = new com.google.android.exoplayer2.e.g(Arrays.copyOf(var9_4[var1_1.length], var12_6));
                var7_3 = this.a((k[])var1_1, (com.google.android.exoplayer2.e.g[])var5_12, var4_5);
                break;
            }
            var5_12 = var2_2.c[var15_8];
            var14_15 = var1_1.length;
            var13_14 = 0;
            var12_6 = 0;
            block4 : do {
                if (var12_6 < var1_1.length) ** GOTO lbl35
                var13_14 = var14_15;
                ** GOTO lbl48
lbl35: // 1 sources:
                var3_11 = var1_1[var12_6];
                var16_10 = 0;
                do {
                    if (var16_10 >= var5_12.a) ** GOTO lbl46
                    var17_9 = var3_11.a(var5_12.b[var16_10]) & 3;
                    if (var17_9 <= var13_14) ** GOTO lbl62
                    var13_14 = var12_6;
                    if (var17_9 == 3) ** GOTO lbl48
                    var14_15 = var17_9;
                    var13_14 = var12_6;
                    ** GOTO lbl65
lbl46: // 1 sources:
                    ++var12_6;
                    continue block4;
lbl48: // 2 sources:
                    if (var13_14 == var1_1.length) {
                        var3_11 = new int[var5_12.a];
                    } else {
                        var8_13 = var1_1[var13_14];
                        var3_11 = new int[var5_12.a];
                        for (var12_6 = 0; var12_6 < var5_12.a; ++var12_6) {
                            var3_11[var12_6] = var8_13.a(var5_12.b[var12_6]);
                        }
                    }
                    var12_6 = var7_3[var13_14];
                    var9_4[var13_14][var12_6] = var5_12;
                    var4_5[var13_14][var12_6] = var3_11;
                    var7_3[var13_14] = var7_3[var13_14] + 1;
                    ++var15_8;
                    continue block2;
lbl62: // 1 sources:
                    var17_9 = var14_15;
                    var14_15 = var13_14;
                    var13_14 = var17_9;
lbl65: // 2 sources:
                    var17_9 = var16_10 + 1;
                    var16_10 = var13_14;
                    var13_14 = var14_15;
                    var14_15 = var16_10;
                    var16_10 = var17_9;
                } while (true);
                break;
            } while (true);
            break;
        } while (true);
        for (var12_6 = 0; var12_6 < var1_1.length; ++var12_6) {
            if (this.c.get(var12_6)) {
                var7_3[var12_6] = null;
                continue;
            }
            var10_16 = var5_12[var12_6];
            var3_11 = (Map)this.b.get(var12_6);
            var3_11 = var3_11 == null ? null : (FloatingActionButton)var3_11.get(var10_16);
            if (var3_11 == null) continue;
            var11_17 = var3_11.c;
            var13_14 = var3_11.d;
            var7_3[var12_6] = var11_17.a(var10_16.c[var13_14], var3_11.e);
        }
        var6_7 = new a((int[])var8_13, (com.google.android.exoplayer2.e.g[])var5_12, (int[])var6_7, var4_5, (com.google.android.exoplayer2.e.g)var9_4);
        var8_13 = new l[var1_1.length];
        for (var12_6 = 0; var12_6 < var1_1.length; ++var12_6) {
            var3_11 = var7_3[var12_6] != null ? l.a : null;
            var8_13[var12_6] = var3_11;
        }
        var16_10 = this.d;
        if (var16_10 == 0) return new i(var2_2, new g((f[])var7_3), var6_7, var8_13);
        var12_6 = -1;
        var14_15 = -1;
        var13_14 = 0;
        block9 : do {
            block19 : {
                if (var13_14 >= var1_1.length) ** GOTO lbl106
                var17_9 = var1_1[var13_14].a;
                var3_11 = var7_3[var13_14];
                if (var17_9 != 1 && var17_9 != 2 || var3_11 == null) break;
                var9_4 = var4_5[var13_14];
                var10_16 = var5_12[var13_14];
                if (var3_11 != null) ** GOTO lbl104
                var15_8 = 0;
                ** GOTO lbl108
lbl104: // 1 sources:
                var18_18 = var10_16.a(var3_11.a());
                ** GOTO lbl129
lbl106: // 1 sources:
                var13_14 = 1;
                ** GOTO lbl119
lbl108: // 3 sources:
                do {
                    if (var15_8 == 0) break block9;
                    if (var17_9 != 1) ** GOTO lbl117
                    if (var12_6 == -1) ** GOTO lbl114
                    var13_14 = 0;
                    ** GOTO lbl119
lbl114: // 1 sources:
                    var12_6 = var14_15;
                    var14_15 = var13_14;
                    break block19;
lbl117: // 1 sources:
                    if (var14_15 != -1) {
                        var13_14 = 0;
lbl119: // 3 sources:
                        var15_8 = var12_6 != -1 && var14_15 != -1 ? 1 : 0;
                        if ((var15_8 & var13_14) == 0) return new i(var2_2, new g((f[])var7_3), var6_7, var8_13);
                        var8_13[var12_6] = var1_1 = new l(var16_10);
                        var8_13[var14_15] = var1_1;
                        return new i(var2_2, new g((f[])var7_3), var6_7, var8_13);
                    }
                    var14_15 = var13_14;
                    var15_8 = var12_6;
                    var12_6 = var14_15;
                    var14_15 = var15_8;
                    break block19;
                    break;
                } while (true);
lbl129: // 2 sources:
                for (var15_8 = 0; var15_8 < var3_11.b(); ++var15_8) {
                    if ((var9_4[var18_18][var3_11.b(var15_8)] & 16) == 16) continue;
                    var15_8 = 0;
                    ** GOTO lbl108
                }
                var15_8 = 1;
                ** continue;
            }
lbl136: // 2 sources:
            do {
                ++var13_14;
                var15_8 = var14_15;
                var14_15 = var12_6;
                var12_6 = var15_8;
                continue block9;
                break;
            } while (true);
            break;
        } while (true);
        var15_8 = var12_6;
        var12_6 = var14_15;
        var14_15 = var15_8;
        ** while (true)
    }

    @Override
    public final void a(Object object) {
        this.e = (a)object;
    }

    protected abstract f[] a(k[] var1, com.google.android.exoplayer2.e.g[] var2, int[][][] var3);

    public static final class a {
        public final int a;
        private final int[] b;
        private final com.google.android.exoplayer2.e.g[] c;
        private final int[] d;
        private final int[][][] e;
        private final com.google.android.exoplayer2.e.g f;

        a(int[] arrn, com.google.android.exoplayer2.e.g[] arrg, int[] arrn2, int[][][] arrn3, com.google.android.exoplayer2.e.g g2) {
            this.b = arrn;
            this.c = arrg;
            this.e = arrn3;
            this.d = arrn2;
            this.f = g2;
            this.a = arrg.length;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public final int a(int var1_1) {
            var4_2 = 0;
            var5_3 = 0;
            block4 : do {
                if (var4_2 >= this.a) return var5_3;
                var3_5 = var5_3;
                if (this.b[var4_2] != var1_1) ** GOTO lbl21
                var2_4 = this.e[var4_2];
                var3_5 = 0;
                var6_6 = 0;
                do {
                    var7_7 = var3_5;
                    if (var6_6 >= var2_4.length) ** GOTO lbl20
                    for (var7_7 = 0; var7_7 < var2_4[var6_6].length; ++var7_7) {
                        switch (var2_4[var6_6][var7_7] & 3) {
                            default: {
                                var8_8 = 1;
                                break;
                            }
                            case 3: {
                                var7_7 = 3;
lbl20: // 2 sources:
                                var3_5 = Math.max(var5_3, var7_7);
lbl21: // 2 sources:
                                ++var4_2;
                                var5_3 = var3_5;
                                continue block4;
                            }
                            case 2: {
                                var8_8 = 2;
                            }
                        }
                        var3_5 = Math.max(var3_5, var8_8);
                    }
                    ++var6_6;
                } while (true);
                break;
            } while (true);
        }
    }

}

