/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.g;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.h.c;

public interface f {
    public Format a(int var1);

    public com.google.android.exoplayer2.e.f a();

    public int b();

    public int b(int var1);

    public static final class a {
        final c a;
        final int b;
        final int c;
        final int d;
        final int e;
        final float f;

        public a(c c2) {
            this(c2, 0);
        }

        private a(c c2, byte by2) {
            this.a = c2;
            this.b = 800000;
            this.c = 10000;
            this.d = 25000;
            this.e = 25000;
            this.f = 0.75f;
        }

        public final /* synthetic */ f a(com.google.android.exoplayer2.e.f f2, int[] arrn) {
            return new com.google.android.exoplayer2.g.a(f2, arrn, this.a, this.b, this.c, this.d, this.e, this.f);
        }
    }

}

