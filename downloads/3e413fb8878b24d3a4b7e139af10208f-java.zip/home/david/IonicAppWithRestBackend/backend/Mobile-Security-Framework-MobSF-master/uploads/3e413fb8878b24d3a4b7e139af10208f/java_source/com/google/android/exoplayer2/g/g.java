/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.g;

import com.google.android.exoplayer2.g.f;
import java.util.Arrays;

public final class g {
    public final int a;
    public final f[] b;
    private int c;

    public /* varargs */ g(f ... arrf) {
        this.b = arrf;
        this.a = arrf.length;
    }

    public final f[] a() {
        return (f[])this.b.clone();
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        object = (g)object;
        return Arrays.equals(this.b, object.b);
    }

    public final int hashCode() {
        if (this.c == 0) {
            this.c = Arrays.hashCode(this.b) + 527;
        }
        return this.c;
    }
}

