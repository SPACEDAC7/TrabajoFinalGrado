/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.g;

import android.support.design.widget.f;
import com.google.android.exoplayer2.e.g;
import com.google.android.exoplayer2.g.i;
import com.google.android.exoplayer2.k;

public abstract class h {
    public f.a a;

    public abstract i a(k[] var1, g var2);

    public abstract void a(Object var1);
}

