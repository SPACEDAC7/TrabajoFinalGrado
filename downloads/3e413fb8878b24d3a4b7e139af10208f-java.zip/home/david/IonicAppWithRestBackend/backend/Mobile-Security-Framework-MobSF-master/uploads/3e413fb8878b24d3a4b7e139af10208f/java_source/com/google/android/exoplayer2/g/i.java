/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.g;

import com.google.android.exoplayer2.g.f;
import com.google.android.exoplayer2.g.g;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.l;

public final class i {
    public final com.google.android.exoplayer2.e.g a;
    public final g b;
    public final Object c;
    public final l[] d;

    public i(com.google.android.exoplayer2.e.g g2, g g3, Object object, l[] arrl) {
        this.a = g2;
        this.b = g3;
        this.c = object;
        this.d = arrl;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean a(i i2, int n2) {
        if (i2 == null || !o.a(this.b.b[n2], i2.b.b[n2]) || !o.a(this.d[n2], i2.d[n2])) {
            return false;
        }
        return true;
    }
}

