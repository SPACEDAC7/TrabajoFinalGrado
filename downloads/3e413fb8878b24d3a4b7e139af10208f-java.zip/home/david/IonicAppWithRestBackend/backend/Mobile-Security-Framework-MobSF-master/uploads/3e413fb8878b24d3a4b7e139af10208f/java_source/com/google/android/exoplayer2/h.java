/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

import android.support.design.widget.FloatingActionButton;
import com.google.android.exoplayer2.h.b;

public final class h {
    final b a;
    final long b;
    final long c;
    final long d;
    final long e;
    final FloatingActionButton f;
    int g;
    boolean h;

    public h() {
        this(new b());
    }

    private h(b b2) {
        this(b2, 0);
    }

    private h(b b2, byte by2) {
        this(b2, '\u0000');
    }

    private h(b b2, char c2) {
        this.a = b2;
        this.b = 15000000;
        this.c = 30000000;
        this.d = 2500000;
        this.e = 5000000;
        this.f = null;
    }

    final void a(boolean bl2) {
        this.g = 0;
        if (this.f != null && this.h) {
            this.f.c();
        }
        this.h = false;
        if (bl2) {
            this.a.c();
        }
    }
}

