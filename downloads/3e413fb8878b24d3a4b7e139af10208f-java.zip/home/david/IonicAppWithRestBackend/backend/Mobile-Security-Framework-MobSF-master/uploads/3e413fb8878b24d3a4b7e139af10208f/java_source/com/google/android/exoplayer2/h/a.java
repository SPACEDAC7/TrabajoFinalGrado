/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.h;

public final class a {
    public final byte[] a;
    public final int b;

    public a(byte[] arrby) {
        this.a = arrby;
        this.b = 0;
    }
}

