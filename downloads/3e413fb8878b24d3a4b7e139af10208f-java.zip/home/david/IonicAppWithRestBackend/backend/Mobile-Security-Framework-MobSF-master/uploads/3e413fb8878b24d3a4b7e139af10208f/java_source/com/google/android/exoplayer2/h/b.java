/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.h;

import a.a.a.a.d;
import com.google.android.exoplayer2.h.a;
import com.google.android.exoplayer2.i.o;
import java.util.Arrays;

public final class b {
    final boolean a;
    public final int b;
    final byte[] c;
    final a[] d;
    int e;
    int f;
    int g;
    a[] h;

    public b() {
        this(0);
    }

    private b(byte by2) {
        d.a(true);
        d.a(true);
        this.a = true;
        this.b = 65536;
        this.g = 0;
        this.h = new a[100];
        this.c = null;
        this.d = new a[1];
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final a a() {
        synchronized (this) {
            int n2;
            ++this.f;
            if (this.g <= 0) return new a(new byte[this.b]);
            Object object = this.h;
            this.g = n2 = this.g - 1;
            object = object[n2];
            this.h[this.g] = null;
            return object;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(int n2) {
        synchronized (this) {
            boolean bl2 = n2 < this.e;
            this.e = n2;
            if (bl2) {
                this.b();
            }
            return;
        }
    }

    public final void a(a a2) {
        synchronized (this) {
            this.d[0] = a2;
            this.a(this.d);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(a[] arra) {
        synchronized (this) {
            if (this.g + arra.length >= this.h.length) {
                this.h = Arrays.copyOf(this.h, Math.max(this.h.length << 1, this.g + arra.length));
            }
            int n2 = arra.length;
            int n3 = 0;
            do {
                if (n3 >= n2) {
                    this.f -= arra.length;
                    this.notifyAll();
                    return;
                }
                a a2 = arra[n3];
                boolean bl2 = a2.a == this.c || a2.a.length == this.b;
                d.a(bl2);
                a[] arra2 = this.h;
                int n4 = this.g;
                this.g = n4 + 1;
                arra2[n4] = a2;
                ++n3;
            } while (true);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    public final void b() {
        var4_1 = 0;
        synchronized (this) {
            block10 : {
                var5_2 = Math.max(0, o.a(this.e, this.b) - this.f);
                var3_3 = this.g;
                if (var5_2 < var3_3) break block10;
lbl7: // 3 sources:
                do {
                    return;
                    break;
                } while (true);
            }
            var3_3 = var5_2;
            if (this.c == null) ** GOTO lbl38
            var6_4 = this.g - 1;
            var3_3 = var4_1;
            var4_1 = var6_4;
            while (var3_3 <= var4_1) {
                var1_5 = this.h[var3_3];
                if (var1_5.a != this.c) break block11;
            }
            {
                block12 : {
                    block11 : {
                        ++var3_3;
                        continue;
                    }
                    var2_7 = this.h[var4_1];
                    if (var2_7.a == this.c) break block12;
                    --var4_1;
                    continue;
                }
                this.h[var3_3] = var2_7;
                this.h[var4_1] = var1_5;
                --var4_1;
                ++var3_3;
                continue;
            }
            if ((var3_3 = Math.max(var5_2, var3_3)) >= this.g) ** GOTO lbl7
lbl38: // 2 sources:
            Arrays.fill(this.h, var3_3, this.g, null);
            this.g = var3_3;
            ** continue;
        }
    }

    public final void c() {
        synchronized (this) {
            if (this.a) {
                this.a(0);
            }
            return;
        }
    }

    public final int d() {
        synchronized (this) {
            int n2 = this.f;
            int n3 = this.b;
            return n2 * n3;
        }
    }
}

