/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.SystemClock
 */
package com.google.android.exoplayer2.h;

import a.a.a.a.d;
import android.os.Handler;
import android.os.SystemClock;
import android.support.design.widget.AppBarLayout;
import com.google.android.exoplayer2.h.f;
import com.google.android.exoplayer2.h.h;
import com.google.android.exoplayer2.i.l;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public final class c
implements c,
h<Object> {
    final Handler a = null;
    final AppBarLayout.b b = null;
    final l c = new l();
    int d;
    long e;
    long f;
    long g;
    long h;
    long i = -1;

    public c() {
        this(0);
    }

    private c(byte by2) {
        this('\u0000');
    }

    private c(char c2) {
    }

    public final long a() {
        synchronized (this) {
            long l2 = this.i;
            return l2;
        }
    }

    @Override
    public final void a(int n2) {
        synchronized (this) {
            this.f += (long)n2;
            return;
        }
    }

    @Override
    public final void b() {
        synchronized (this) {
            if (this.d == 0) {
                this.e = SystemClock.elapsedRealtime();
            }
            ++this.d;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void c() {
        int n2 = 0;
        synchronized (this) {
            long l2;
            boolean bl2 = this.d > 0;
            d.b(bl2);
            long l3 = SystemClock.elapsedRealtime();
            int n3 = (int)(l3 - this.e);
            this.g += (long)n3;
            this.h += this.f;
            if (n3 > 0) {
                int n4;
                Object object;
                float f2 = this.f * 8000 / (long)n3;
                Object object2 = this.c;
                int n5 = (int)Math.sqrt(this.f);
                if (object2.f != 1) {
                    Collections.sort(object2.d, l.a);
                    object2.f = 1;
                }
                if (object2.i > 0) {
                    object = object2.e;
                    object2.i = n4 = object2.i - 1;
                    object = object[n4];
                } else {
                    object = new l.a(0);
                }
                n4 = object2.g;
                object2.g = n4 + 1;
                object.a = n4;
                object.b = n5;
                object.c = f2;
                object2.d.add((l.a)object);
                object2.h += n5;
                while (object2.h > object2.c) {
                    n5 = object2.h - object2.c;
                    object = object2.d.get(0);
                    if (object.b <= n5) {
                        object2.h -= object.b;
                        object2.d.remove(0);
                        if (object2.i >= 5) continue;
                        l.a[] arra = object2.e;
                        n5 = object2.i;
                        object2.i = n5 + 1;
                        arra[n5] = object;
                        continue;
                    }
                    object.b -= n5;
                    object2.h -= n5;
                }
                if (this.g >= 2000 || this.h >= 524288) {
                    block18 : {
                        object = this.c;
                        if (object.f != 0) {
                            Collections.sort(object.d, l.b);
                            object.f = 0;
                        }
                        f2 = object.h;
                        n5 = 0;
                        while (n2 < object.d.size()) {
                            object2 = object.d.get(n2);
                            if ((float)(n5 += object2.b) >= 0.5f * f2) {
                                f2 = object2.c;
                                break block18;
                            }
                            ++n2;
                        }
                        f2 = object.d.isEmpty() ? Float.NaN : object.d.get((int)(object.d.size() - 1)).c;
                    }
                    l2 = Float.isNaN(f2) ? -1 : (long)f2;
                    this.i = l2;
                }
            }
            l2 = this.f;
            long l4 = this.i;
            if (this.a != null && this.b != null) {
                this.a.post((Runnable)new f(this, n3, l2, l4));
            }
            this.d = n2 = this.d - 1;
            if (n2 > 0) {
                this.e = l3;
            }
            this.f = 0;
            return;
        }
    }
}

