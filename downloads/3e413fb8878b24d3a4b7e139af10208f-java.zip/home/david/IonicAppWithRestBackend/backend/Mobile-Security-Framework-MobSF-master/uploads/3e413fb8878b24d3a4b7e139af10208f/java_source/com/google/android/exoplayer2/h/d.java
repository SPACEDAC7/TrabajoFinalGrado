/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.google.android.exoplayer2.h;

import android.net.Uri;
import com.google.android.exoplayer2.h.e;

public interface d {
    public int a(byte[] var1, int var2, int var3);

    public long a(e var1);

    public Uri a();

    public void b();

    public static final class a {
        public final com.whatsapp.m.a a;

        public a(com.whatsapp.m.a a2) {
            this.a = a2;
        }
    }

}

