/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.google.android.exoplayer2.h;

import a.a.a.a.d;
import android.net.Uri;
import java.util.Arrays;

public final class e {
    public final Uri a;
    public final byte[] b;
    public final long c;
    public final long d;
    public final long e;
    public final String f;
    public final int g;

    private e(Uri uri, long l2, long l3, String string) {
        this(uri, l2, l3, string, 0);
    }

    /*
     * Enabled aggressive block sorting
     */
    private e(Uri uri, long l2, long l3, String string, byte by2) {
        boolean bl2 = true;
        boolean bl3 = l2 >= 0;
        d.a(bl3);
        bl3 = l3 >= 0;
        d.a(bl3);
        bl3 = bl2;
        if (-1 <= 0) {
            bl3 = -1 == -1 ? bl2 : false;
        }
        d.a(bl3);
        this.a = uri;
        this.b = null;
        this.c = l2;
        this.d = l3;
        this.e = -1;
        this.f = string;
        this.g = 0;
    }

    public e(Uri uri, long l2, String string) {
        this(uri, l2, l2, string);
    }

    public final String toString() {
        return "DataSpec[" + (Object)this.a + ", " + Arrays.toString(this.b) + ", " + this.c + ", " + this.d + ", " + this.e + ", " + this.f + ", " + this.g + "]";
    }
}

