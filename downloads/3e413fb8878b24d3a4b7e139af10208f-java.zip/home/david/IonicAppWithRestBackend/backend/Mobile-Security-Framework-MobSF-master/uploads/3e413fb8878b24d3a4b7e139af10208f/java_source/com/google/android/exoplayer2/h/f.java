/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.h;

import com.google.android.exoplayer2.h.c;

final class f
implements Runnable {
    final /* synthetic */ int a;
    final /* synthetic */ long b;
    final /* synthetic */ long c;
    final /* synthetic */ c d;

    f(c c2, int n2, long l2, long l3) {
        this.d = c2;
        this.a = n2;
        this.b = l2;
        this.c = l3;
    }

    @Override
    public final void run() {
    }
}

