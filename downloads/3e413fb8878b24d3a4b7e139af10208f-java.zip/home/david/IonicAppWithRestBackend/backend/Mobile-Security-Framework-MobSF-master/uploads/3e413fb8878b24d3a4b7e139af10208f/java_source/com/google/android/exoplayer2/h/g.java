/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  android.os.SystemClock
 *  android.util.Log
 */
package com.google.android.exoplayer2.h;

import a.a.a.a.a.f;
import a.a.a.a.d;
import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import com.google.android.exoplayer2.i.o;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public final class g {
    public final ExecutorService a;
    public b<? extends c> b;
    public IOException c;

    public g(String string) {
        this.a = o.a(string);
    }

    public final boolean a() {
        if (this.b != null) {
            return true;
        }
        return false;
    }

    public final void b() {
        this.b.a(false);
    }

    public static interface a<T extends c> {
        public int a(T var1, IOException var2);

        public void a(T var1);

        public void a(T var1, boolean var2);
    }

    @SuppressLint(value={"HandlerLeak"})
    public final class b<T extends c>
    extends Handler
    implements Runnable {
        public final int a;
        public IOException b;
        public int c;
        final /* synthetic */ g d;
        private final T e;
        private final a<T> f;
        private final long g;
        private volatile Thread h;
        private volatile boolean i;

        /*
         * WARNING - Possible parameter corruption
         */
        public b(Looper l2, T looper, a<T> t2, int a2, long n2) {
            void var2_2;
            void var3_3;
            void var6_6;
            void var4_4;
            void var5_5;
            this.d = (g)l2;
            super((Looper)var2_2);
            this.e = var3_3;
            this.f = var4_4;
            this.a = var5_5;
            this.g = var6_6;
        }

        private void a() {
            this.b = null;
            this.d.a.submit(this.d.b);
        }

        private void b() {
            this.d.b = null;
        }

        /*
         * Enabled aggressive block sorting
         */
        public final void a(long l2) {
            boolean bl2 = this.d.b == null;
            d.b(bl2);
            this.d.b = this;
            if (l2 > 0) {
                this.sendEmptyMessageDelayed(0, l2);
                return;
            }
            this.a();
        }

        /*
         * Enabled aggressive block sorting
         */
        public final void a(boolean bl2) {
            this.i = bl2;
            this.b = null;
            if (this.hasMessages(0)) {
                this.removeMessages(0);
                if (!bl2) {
                    this.sendEmptyMessage(1);
                }
            } else {
                this.e.a();
                if (this.h != null) {
                    this.h.interrupt();
                }
            }
            if (bl2) {
                this.b();
                SystemClock.elapsedRealtime();
                this.f.a(this.e, true);
            }
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public final void handleMessage(Message message) {
            if (this.i) {
                return;
            }
            if (message.what == 0) {
                this.a();
                return;
            }
            if (message.what == 4) {
                throw (Error)message.obj;
            }
            this.b();
            SystemClock.elapsedRealtime();
            if (this.e.b()) {
                this.f.a(this.e, false);
                return;
            }
            switch (message.what) {
                default: {
                    return;
                }
                case 1: {
                    this.f.a(this.e, false);
                    return;
                }
                case 2: {
                    this.f.a(this.e);
                    return;
                }
                case 3: 
            }
            this.b = (IOException)message.obj;
            int n2 = this.f.a(this.e, this.b);
            if (n2 == 3) {
                this.d.c = this.b;
                return;
            }
            if (n2 == 2) return;
            n2 = n2 == 1 ? 1 : this.c + 1;
            this.c = n2;
            this.a(Math.min((this.c - 1) * 1000, 5000));
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        @Override
        public final void run() {
            this.h = Thread.currentThread();
            if (this.e.b()) ** GOTO lbl12
            f.a("load:" + this.e.getClass().getSimpleName());
            this.e.c();
            {
                catch (Throwable var1_1) {
                    f.a();
                    throw var1_1;
                }
            }
            try {
                f.a();
lbl12: // 2 sources:
                if (this.i != false) return;
                this.sendEmptyMessage(2);
                return;
            }
            catch (IOException var1_2) {
                if (this.i != false) return;
                this.obtainMessage(3, (Object)var1_2).sendToTarget();
                return;
            }
            catch (InterruptedException var1_3) {
                d.b(this.e.b());
                if (this.i != false) return;
                this.sendEmptyMessage(2);
                return;
            }
            catch (Exception var1_4) {
                Log.e((String)"LoadTask", (String)"Unexpected exception loading stream", (Throwable)var1_4);
                if (this.i != false) return;
                this.obtainMessage(3, (Object)new com.c.d.a.a(var1_4)).sendToTarget();
                return;
            }
            catch (Error var1_5) {
                Log.e((String)"LoadTask", (String)"Unexpected error loading stream", (Throwable)var1_5);
                if (this.i != false) throw var1_5;
                this.obtainMessage(4, (Object)var1_5).sendToTarget();
                throw var1_5;
            }
        }
    }

    public static interface c {
        public void a();

        public boolean b();

        public void c();
    }

}

