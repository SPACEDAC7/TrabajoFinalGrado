/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.h;

public interface h<S> {
    public void a(int var1);

    public void b();

    public void c();
}

