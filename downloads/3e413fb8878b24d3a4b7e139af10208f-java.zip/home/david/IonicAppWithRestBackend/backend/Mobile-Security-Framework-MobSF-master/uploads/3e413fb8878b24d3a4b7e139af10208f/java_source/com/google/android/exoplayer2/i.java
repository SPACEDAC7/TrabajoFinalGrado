/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

import java.io.IOException;

public class i
extends IOException {
    public i() {
    }

    public i(String string) {
        super(string);
    }

    public i(String string, Throwable throwable) {
        super(string, throwable);
    }
}

