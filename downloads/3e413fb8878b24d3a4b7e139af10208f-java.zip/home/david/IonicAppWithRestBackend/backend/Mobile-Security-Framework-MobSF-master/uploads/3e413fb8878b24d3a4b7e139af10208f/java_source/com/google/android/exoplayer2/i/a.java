/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 */
package com.google.android.exoplayer2.i;

import a.a.a.a.d;
import android.util.Pair;
import com.google.android.exoplayer2.i.h;

public final class a {
    private static final byte[] a = new byte[]{0, 0, 0, 1};
    private static final int[] b = new int[]{96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350};
    private static final int[] c = new int[]{0, 1, 2, 3, 4, 5, 6, 8, -1, -1, -1, 7, 8, -1, 8, -1};

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static Pair<Integer, Integer> a(byte[] var0) {
        var5_1 = true;
        var0 = new h((byte[])var0);
        var1_2 = var0.c(5);
        var2_3 = var0.c(4);
        if (var2_3 == 15) {
            var2_3 = var0.c(24);
        } else {
            var4_4 = var2_3 < 13;
            d.a(var4_4);
            var2_3 = a.b[var2_3];
        }
        var3_5 = var0.c(4);
        if (var1_2 != 5 && var1_2 != 29) ** GOTO lbl-1000
        var1_2 = var0.c(4);
        if (var1_2 == 15) {
            var1_2 = var0.c(24);
        } else {
            var4_4 = var1_2 < 13;
            d.a(var4_4);
            var1_2 = a.b[var1_2];
        }
        var2_3 = var1_2;
        if (var0.c(5) == 22) {
            var2_3 = var0.c(4);
        } else lbl-1000: // 2 sources:
        {
            var1_2 = var2_3;
            var2_3 = var3_5;
        }
        var4_4 = (var2_3 = a.c[var2_3]) != -1 ? var5_1 : false;
        d.a(var4_4);
        return Pair.create((Object)var1_2, (Object)var2_3);
    }

    public static byte[] a(int n2, int n3, int n4) {
        return new byte[]{(byte)(n2 << 3 & 248 | n3 >> 1 & 7), (byte)(n3 << 7 & 128 | n4 << 3 & 120)};
    }

    public static byte[] a(byte[] arrby, int n2, int n3) {
        byte[] arrby2 = new byte[a.length + n3];
        System.arraycopy(a, 0, arrby2, 0, a.length);
        System.arraycopy(arrby, n2, arrby2, a.length, n3);
        return arrby2;
    }
}

