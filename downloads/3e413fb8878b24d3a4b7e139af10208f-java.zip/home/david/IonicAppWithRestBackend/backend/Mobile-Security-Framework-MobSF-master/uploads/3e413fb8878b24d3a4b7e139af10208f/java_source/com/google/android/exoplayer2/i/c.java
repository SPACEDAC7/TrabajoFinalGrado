/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.i;

public final class c {
    private boolean a;

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean a() {
        boolean bl2 = true;
        synchronized (this) {
            block6 : {
                boolean bl3 = this.a;
                if (!bl3) break block6;
                return false;
            }
            this.a = true;
            this.notifyAll();
            return bl2;
        }
    }

    public final boolean b() {
        synchronized (this) {
            boolean bl2 = this.a;
            this.a = false;
            return bl2;
        }
    }

    public final void c() {
        synchronized (this) {
            while (!this.a) {
                this.wait();
            }
            return;
        }
    }
}

