/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.i;

import com.google.android.exoplayer2.i.h;

public final class d {
    public final int a;
    public final int b;
    public final int c;
    public final int d;
    public final int e;
    public final int f;
    public final int g;
    public final long h;

    public d(byte[] object) {
        object = new h((byte[])object);
        object.a(136);
        this.a = object.c(16);
        this.b = object.c(16);
        this.c = object.c(24);
        this.d = object.c(24);
        this.e = object.c(20);
        this.f = object.c(3) + 1;
        this.g = object.c(5) + 1;
        this.h = object.c(36);
    }
}

