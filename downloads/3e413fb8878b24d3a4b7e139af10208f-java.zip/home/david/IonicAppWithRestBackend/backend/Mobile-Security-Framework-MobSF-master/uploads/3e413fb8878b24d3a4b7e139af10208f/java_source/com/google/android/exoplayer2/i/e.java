/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.i;

import java.util.Arrays;

public final class e {
    public int a;
    public long[] b = new long[32];

    public e() {
        this(0);
    }

    private e(byte by2) {
    }

    public final long a(int n2) {
        if (n2 < 0 || n2 >= this.a) {
            throw new IndexOutOfBoundsException("Invalid index " + n2 + ", size is " + this.a);
        }
        return this.b[n2];
    }

    public final void a(long l2) {
        if (this.a == this.b.length) {
            this.b = Arrays.copyOf(this.b, this.a << 1);
        }
        long[] arrl = this.b;
        int n2 = this.a;
        this.a = n2 + 1;
        arrl[n2] = l2;
    }
}

