/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.i;

public interface f {
    public long v();
}

