/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.google.android.exoplayer2.i;

import a.a.a.a.d;
import android.util.Log;
import com.google.android.exoplayer2.i.j;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.util.Arrays;

public final class g {
    public static final byte[] a = new byte[]{0, 0, 0, 1};
    public static final float[] b = new float[]{1.0f, 1.0f, 1.0909091f, 0.90909094f, 1.4545455f, 1.2121212f, 2.1818182f, 1.8181819f, 2.909091f, 2.4242425f, 1.6363636f, 1.3636364f, 1.939394f, 1.6161616f, 1.3333334f, 1.5f, 2.0f};
    private static final Object c = new Object();
    private static int[] d = new int[10];

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static int a(byte[] arrby, int n2) {
        int n3 = 0;
        Object object = c;
        synchronized (object) {
            int n4 = 0;
            int n5 = 0;
            do {
                int n6;
                block11 : {
                    if (n5 >= n2) {
                        int n7 = n2 - n4;
                        n6 = 0;
                        n5 = 0;
                        n2 = n3;
                        do {
                            if (n2 >= n4) {
                                System.arraycopy(arrby, n5, arrby, n6, n7 - n6);
                                return n7;
                            }
                            n3 = d[n2] - n5;
                            System.arraycopy(arrby, n5, arrby, n6, n3);
                            int n8 = (n6 += n3) + 1;
                            arrby[n6] = 0;
                            n6 = n8 + 1;
                            arrby[n8] = 0;
                            n5 += n3 + 3;
                            ++n2;
                        } while (true);
                    }
                    while (n5 < n2 - 2) {
                        if (arrby[n5] == 0 && arrby[n5 + 1] == 0 && arrby[n5 + 2] == 3) {
                            n6 = n5;
                            break block11;
                        }
                        ++n5;
                    }
                    n6 = n2;
                }
                n5 = n6;
                if (n6 >= n2) continue;
                if (d.length <= n4) {
                    d = Arrays.copyOf(d, d.length << 1);
                }
                g.d[n4] = n6;
                n5 = n6 + 3;
                ++n4;
            } while (true);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static int a(byte[] arrby, int n2, int n3, boolean[] arrbl) {
        boolean bl2 = true;
        int n4 = n3 - n2;
        boolean bl3 = n4 >= 0;
        d.b(bl3);
        if (n4 == 0) {
            return n3;
        }
        if (arrbl != null) {
            if (arrbl[0]) {
                g.a(arrbl);
                return n2 - 3;
            }
            if (n4 > 1 && arrbl[1] && arrby[n2] == 1) {
                g.a(arrbl);
                return n2 - 2;
            }
            if (n4 > 2 && arrbl[2] && arrby[n2] == 0 && arrby[n2 + 1] == 1) {
                g.a(arrbl);
                return n2 - 1;
            }
        }
        n2 += 2;
        while (n2 < n3 - 1) {
            int n5 = n2;
            if ((arrby[n2] & 254) == 0) {
                if (arrby[n2 - 2] == 0 && arrby[n2 - 1] == 0 && arrby[n2] == 1) {
                    if (arrbl == null) return n2 - 2;
                    g.a(arrbl);
                    return n2 - 2;
                }
                n5 = n2 - 2;
            }
            n2 = n5 + 3;
        }
        if (arrbl == null) return n3;
        bl3 = n4 > 2 ? arrby[n3 - 3] == 0 && arrby[n3 - 2] == 0 && arrby[n3 - 1] == 1 : (n4 == 2 ? arrbl[2] && arrby[n3 - 2] == 0 && arrby[n3 - 1] == 1 : arrbl[1] && arrby[n3 - 1] == 1);
        arrbl[0] = bl3;
        bl3 = n4 > 1 ? arrby[n3 - 2] == 0 && arrby[n3 - 1] == 0 : arrbl[2] && arrby[n3 - 1] == 0;
        arrbl[1] = bl3;
        bl3 = arrby[n3 - 1] == 0 ? bl2 : false;
        arrbl[2] = bl3;
        return n3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static b a(byte[] var0, int var1_1, int var2_2) {
        var0 = new j((byte[])var0, var1_1, var2_2);
        var0.a(8);
        var1_1 = var0.c(8);
        var0.a(16);
        var11_3 = var0.d();
        var18_4 = false;
        if (var1_1 != 100 && var1_1 != 110 && var1_1 != 122 && var1_1 != 244 && var1_1 != 44 && var1_1 != 83 && var1_1 != 86 && var1_1 != 118 && var1_1 != 128 && var1_1 != 138) ** GOTO lbl17
        var10_5 = var0.d();
        if (var10_5 == 3) {
            var18_4 = var0.a();
        }
        var0.d();
        var0.d();
        var0.a(1);
        if (!var0.a()) ** GOTO lbl34
        var2_2 = var10_5 != 3 ? 8 : 12;
        ** GOTO lbl20
lbl17: // 1 sources:
        var18_4 = false;
        var5_6 = 1;
        ** GOTO lbl35
lbl20: // 3 sources:
        for (var5_6 = 0; var5_6 < var2_2; ++var5_6) {
            if (!var0.a()) continue;
            var6_7 = var5_6 < 6 ? 16 : 64;
            var9_10 = 8;
            var8_9 = 8;
            for (var7_8 = 0; var7_8 < var6_7; ++var7_8) {
                var1_1 = var9_10;
                if (var9_10 != 0) {
                    var1_1 = (var0.c() + var8_9 + 256) % 256;
                }
                if (var1_1 != 0) {
                    var8_9 = var1_1;
                }
                var9_10 = var1_1;
            }
        }
lbl34: // 2 sources:
        var5_6 = var10_5;
lbl35: // 2 sources:
        var9_10 = var0.d();
        var10_5 = var0.d();
        var6_7 = 0;
        var19_11 = false;
        if (var10_5 == 0) {
            var2_2 = var0.d() + 4;
        } else {
            var2_2 = var6_7;
            if (var10_5 == 1) {
                var20_12 = var0.a();
                var0.c();
                var0.c();
                var16_19 = var0.d();
                var1_1 = 0;
                do {
                    var2_2 = var6_7;
                    var19_11 = var20_12;
                    if ((long)var1_1 >= var16_19) break;
                    var0.d();
                    ++var1_1;
                } while (true);
            }
        }
        var0.d();
        var0.a(1);
        var7_8 = var0.d();
        var6_7 = var0.d();
        var20_12 = var0.a();
        var1_1 = var20_12 != false ? 1 : 0;
        if (!var20_12) {
            var0.a(1);
        }
        var0.a(1);
        var7_8 = var7_8 + 1 << 4;
        var8_9 = (2 - var1_1) * (var6_7 + 1) << 4;
        if (var0.a()) {
            var14_13 = var0.d();
            var15_14 = var0.d();
            var12_15 = var0.d();
            var13_16 = var0.d();
            if (var5_6 == 0) {
                var5_6 = 1;
                var1_1 = var20_12 != false ? 1 : 0;
                var6_7 = 2 - var1_1;
                var1_1 = var5_6;
                var5_6 = var6_7;
            } else {
                var1_1 = var5_6 == 3 ? 1 : 2;
                var5_6 = var5_6 == 1 ? 2 : 1;
                var6_7 = var20_12 != false ? 1 : 0;
                var5_6 = (2 - var6_7) * var5_6;
            }
            var1_1 = var7_8 - var1_1 * (var14_13 + var15_14);
            var5_6 = var8_9 - var5_6 * (var12_15 + var13_16);
        } else {
            var1_1 = var7_8;
            var5_6 = var8_9;
        }
        var4_17 = 1.0f;
        if (var0.a() && var0.a()) {
            var6_7 = var0.c(8);
            if (var6_7 == 255) {
                var6_7 = var0.c(16);
                var7_8 = var0.c(16);
                var3_18 = var4_17;
                if (var6_7 == 0) return new b(var11_3, var1_1, var5_6, var3_18, var18_4, var20_12, var9_10 + 4, var10_5, var2_2, var19_11);
                var3_18 = var4_17;
                if (var7_8 == 0) return new b(var11_3, var1_1, var5_6, var3_18, var18_4, var20_12, var9_10 + 4, var10_5, var2_2, var19_11);
                var3_18 = (float)var6_7 / (float)var7_8;
                return new b(var11_3, var1_1, var5_6, var3_18, var18_4, var20_12, var9_10 + 4, var10_5, var2_2, var19_11);
            }
            if (var6_7 < g.b.length) {
                var3_18 = g.b[var6_7];
                return new b(var11_3, var1_1, var5_6, var3_18, var18_4, var20_12, var9_10 + 4, var10_5, var2_2, var19_11);
            }
            Log.w((String)"NalUnitUtil", (String)("Unexpected aspect_ratio_idc value: " + var6_7));
        }
        var3_18 = 1.0f;
        return new b(var11_3, var1_1, var5_6, var3_18, var18_4, var20_12, var9_10 + 4, var10_5, var2_2, var19_11);
    }

    public static void a(ByteBuffer byteBuffer) {
        int n2 = byteBuffer.position();
        int n3 = 0;
        int n4 = 0;
        while (n3 + 1 < n2) {
            int n5;
            int n6 = byteBuffer.get(n3) & 255;
            if (n4 == 3) {
                n5 = n4;
                if (n6 == 1) {
                    n5 = n4;
                    if ((byteBuffer.get(n3 + 1) & 31) == 7) {
                        ByteBuffer byteBuffer2 = byteBuffer.duplicate();
                        byteBuffer2.position(n3 - 3);
                        byteBuffer2.limit(n2);
                        byteBuffer.position(0);
                        byteBuffer.put(byteBuffer2);
                        return;
                    }
                }
            } else {
                n5 = n4;
                if (n6 == 0) {
                    n5 = n4 + 1;
                }
            }
            n4 = n5;
            if (n6 != 0) {
                n4 = 0;
            }
            ++n3;
        }
        byteBuffer.clear();
    }

    public static void a(boolean[] arrbl) {
        arrbl[0] = false;
        arrbl[1] = false;
        arrbl[2] = false;
    }

    public static int b(byte[] arrby, int n2) {
        return arrby[n2 + 3] & 31;
    }

    public static int c(byte[] arrby, int n2) {
        return (arrby[n2 + 3] & 126) >> 1;
    }

    public static a d(byte[] object, int n2) {
        object = new j((byte[])object, 3, n2);
        object.a(8);
        n2 = object.d();
        int n3 = object.d();
        object.a(1);
        return new a(n2, n3, object.a());
    }

    public static final class a {
        public final int a;
        public final int b;
        public final boolean c;

        public a(int n2, int n3, boolean bl2) {
            this.a = n2;
            this.b = n3;
            this.c = bl2;
        }
    }

    public static final class b {
        public final int a;
        public final int b;
        public final int c;
        public final float d;
        public final boolean e;
        public final boolean f;
        public final int g;
        public final int h;
        public final int i;
        public final boolean j;

        public b(int n2, int n3, int n4, float f2, boolean bl2, boolean bl3, int n5, int n6, int n7, boolean bl4) {
            this.a = n2;
            this.b = n3;
            this.c = n4;
            this.d = f2;
            this.e = bl2;
            this.f = bl3;
            this.g = n5;
            this.h = n6;
            this.i = n7;
            this.j = bl4;
        }
    }

}

