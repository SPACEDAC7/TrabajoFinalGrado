/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.i;

import a.a.a.a.d;

public final class h {
    public byte[] a;
    public int b;
    public int c;
    public int d;

    public h() {
    }

    public h(byte[] arrby) {
        this(arrby, arrby.length);
    }

    private h(byte[] arrby, int n2) {
        this.a = arrby;
        this.d = n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b() {
        boolean bl2 = this.b >= 0 && this.c >= 0 && this.c < 8 && (this.b < this.d || this.b == this.d && this.c == 0);
        d.b(bl2);
    }

    public final void a(int n2) {
        this.b = n2 / 8;
        this.c = n2 - (this.b << 3);
        this.b();
    }

    public final void a(byte[] arrby, int n2) {
        this.a = arrby;
        this.b = 0;
        this.c = 0;
        this.d = n2;
    }

    public final boolean a() {
        if (this.c(1) == 1) {
            return true;
        }
        return false;
    }

    public final void b(int n2) {
        this.b += n2 / 8;
        this.c += n2 % 8;
        if (this.c > 7) {
            ++this.b;
            this.c -= 8;
        }
        this.b();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int c(int n2) {
        int n3;
        if (n2 == 0) {
            return 0;
        }
        int n4 = n2 / 8;
        int n5 = 0;
        int n6 = n2;
        n2 = n5;
        for (n3 = 0; n3 < n4; n2 |= (n5 & 255) << (n6 -= 8), ++this.b, ++n3) {
            n5 = this.c != 0 ? (this.a[this.b] & 255) << this.c | (this.a[this.b + 1] & 255) >>> 8 - this.c : this.a[this.b];
        }
        if (n6 > 0) {
            n5 = this.c + n6;
            n3 = (byte)(255 >> 8 - n6);
            if (n5 > 8) {
                n2 = n3 & ((this.a[this.b] & 255) << n5 - 8 | (this.a[this.b + 1] & 255) >> 16 - n5) | n2;
                ++this.b;
            } else {
                n2 = n3 = n3 & (this.a[this.b] & 255) >> 8 - n5 | n2;
                if (n5 == 8) {
                    ++this.b;
                    n2 = n3;
                }
            }
            this.c = n5 % 8;
        }
        this.b();
        return n2;
    }
}

