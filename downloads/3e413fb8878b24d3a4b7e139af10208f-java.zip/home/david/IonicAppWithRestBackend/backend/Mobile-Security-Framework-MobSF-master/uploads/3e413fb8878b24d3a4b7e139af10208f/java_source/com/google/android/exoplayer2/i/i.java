/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.i;

import a.a.a.a.d;
import com.google.android.exoplayer2.i.h;
import com.google.android.exoplayer2.i.o;
import java.nio.charset.Charset;

public final class i {
    public byte[] a;
    public int b;
    public int c;

    public i() {
    }

    public i(int n2) {
        this.a = new byte[n2];
        this.c = n2;
    }

    public i(byte[] arrby) {
        this.a = arrby;
        this.c = arrby.length;
    }

    public i(byte[] arrby, int n2) {
        this.a = arrby;
        this.c = n2;
    }

    public final void a() {
        this.b = 0;
        this.c = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2) {
        byte[] arrby = this.d() < n2 ? new byte[n2] : this.a;
        this.a(arrby, n2);
    }

    public final void a(h h2, int n2) {
        this.a(h2.a, 0, n2);
        h2.a(0);
    }

    public final void a(byte[] arrby, int n2) {
        this.a = arrby;
        this.c = n2;
        this.b = 0;
    }

    public final void a(byte[] arrby, int n2, int n3) {
        System.arraycopy(this.a, this.b, arrby, n2, n3);
        this.b += n3;
    }

    public final int b() {
        return this.c - this.b;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void b(int n2) {
        boolean bl2 = n2 >= 0 && n2 <= this.a.length;
        d.a(bl2);
        this.c = n2;
    }

    public final int c() {
        return this.b;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void c(int n2) {
        boolean bl2 = n2 >= 0 && n2 <= this.c;
        d.a(bl2);
        this.b = n2;
    }

    public final int d() {
        if (this.a == null) {
            return 0;
        }
        return this.a.length;
    }

    public final void d(int n2) {
        this.c(this.b + n2);
    }

    public final int e() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        return arrby[n2] & 255;
    }

    public final String e(int n2) {
        Object object = Charset.defaultCharset();
        object = new String(this.a, this.b, n2, (Charset)object);
        this.b += n2;
        return object;
    }

    public final int f() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        n2 = arrby[n2];
        arrby = this.a;
        int n3 = this.b;
        this.b = n3 + 1;
        return (n2 & 255) << 8 | arrby[n3] & 255;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String f(int n2) {
        if (n2 == 0) {
            return "";
        }
        int n3 = this.b + n2 - 1;
        n3 = n3 < this.c && this.a[n3] == 0 ? n2 - 1 : n2;
        String string = new String(this.a, this.b, n3);
        this.b += n2;
        return string;
    }

    public final int g() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        n2 = arrby[n2];
        arrby = this.a;
        int n3 = this.b;
        this.b = n3 + 1;
        return n2 & 255 | (arrby[n3] & 255) << 8;
    }

    public final int h() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        n2 = arrby[n2];
        arrby = this.a;
        int n3 = this.b;
        this.b = n3 + 1;
        n3 = arrby[n3];
        arrby = this.a;
        int n4 = this.b;
        this.b = n4 + 1;
        return (n2 & 255) << 16 | (n3 & 255) << 8 | arrby[n4] & 255;
    }

    public final long i() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        long l2 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l3 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l4 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        return (l2 & 255) << 24 | (l3 & 255) << 16 | (l4 & 255) << 8 | (long)arrby[n2] & 255;
    }

    public final long j() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        long l2 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l3 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l4 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        return l2 & 255 | (l3 & 255) << 8 | (l4 & 255) << 16 | ((long)arrby[n2] & 255) << 24;
    }

    public final int k() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        n2 = arrby[n2];
        arrby = this.a;
        int n3 = this.b;
        this.b = n3 + 1;
        n3 = arrby[n3];
        arrby = this.a;
        int n4 = this.b;
        this.b = n4 + 1;
        n4 = arrby[n4];
        arrby = this.a;
        int n5 = this.b;
        this.b = n5 + 1;
        return (n2 & 255) << 24 | (n3 & 255) << 16 | (n4 & 255) << 8 | arrby[n5] & 255;
    }

    public final int l() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        n2 = arrby[n2];
        arrby = this.a;
        int n3 = this.b;
        this.b = n3 + 1;
        n3 = arrby[n3];
        arrby = this.a;
        int n4 = this.b;
        this.b = n4 + 1;
        n4 = arrby[n4];
        arrby = this.a;
        int n5 = this.b;
        this.b = n5 + 1;
        return n2 & 255 | (n3 & 255) << 8 | (n4 & 255) << 16 | (arrby[n5] & 255) << 24;
    }

    public final long m() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        long l2 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l3 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l4 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l5 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l6 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l7 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l8 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        return (l2 & 255) << 56 | (l3 & 255) << 48 | (l4 & 255) << 40 | (l5 & 255) << 32 | (l6 & 255) << 24 | (l7 & 255) << 16 | (l8 & 255) << 8 | (long)arrby[n2] & 255;
    }

    public final int n() {
        return this.e() << 21 | this.e() << 14 | this.e() << 7 | this.e();
    }

    public final int o() {
        int n2 = this.k();
        if (n2 < 0) {
            throw new IllegalStateException("Top bit not zero: " + n2);
        }
        return n2;
    }

    public final int p() {
        int n2 = this.l();
        if (n2 < 0) {
            throw new IllegalStateException("Top bit not zero: " + n2);
        }
        return n2;
    }

    public final long q() {
        long l2 = this.m();
        if (l2 < 0) {
            throw new IllegalStateException("Top bit not zero: " + l2);
        }
        return l2;
    }

    public final String r() {
        int n2;
        if (this.b() == 0) {
            return null;
        }
        for (n2 = this.b; n2 < this.c && this.a[n2] != 0; ++n2) {
        }
        String string = new String(this.a, this.b, n2 - this.b);
        this.b = n2;
        if (this.b < this.c) {
            ++this.b;
        }
        return string;
    }

    public final String s() {
        int n2;
        if (this.b() == 0) {
            return null;
        }
        for (n2 = this.b; n2 < this.c && !o.a(this.a[n2]); ++n2) {
        }
        if (n2 - this.b >= 3 && this.a[this.b] == -17 && this.a[this.b + 1] == -69 && this.a[this.b + 2] == -65) {
            this.b += 3;
        }
        String string = new String(this.a, this.b, n2 - this.b);
        this.b = n2;
        if (this.b == this.c) {
            return string;
        }
        if (this.a[this.b] == 13) {
            ++this.b;
            if (this.b == this.c) {
                return string;
            }
        }
        if (this.a[this.b] == 10) {
            ++this.b;
        }
        return string;
    }
}

