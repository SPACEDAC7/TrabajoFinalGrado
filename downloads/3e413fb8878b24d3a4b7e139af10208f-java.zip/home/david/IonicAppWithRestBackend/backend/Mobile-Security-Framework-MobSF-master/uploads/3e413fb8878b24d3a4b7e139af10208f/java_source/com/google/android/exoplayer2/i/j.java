/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.i;

import a.a.a.a.d;

public final class j {
    private byte[] a;
    private int b;
    private int c;
    private int d;

    public j(byte[] arrby, int n2, int n3) {
        this.a(arrby, n2, n3);
    }

    private boolean d(int n2) {
        if (2 <= n2 && n2 < this.b && this.a[n2] == 3 && this.a[n2 - 2] == 0 && this.a[n2 - 1] == 0) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void e() {
        boolean bl2 = this.c >= 0 && this.d >= 0 && this.d < 8 && (this.c < this.b || this.c == this.b && this.d == 0);
        d.b(bl2);
    }

    public final void a(int n2) {
        int n3 = this.c;
        this.c += n2 / 8;
        this.d += n2 % 8;
        if (this.d > 7) {
            ++this.c;
            this.d -= 8;
        }
        n2 = n3 + 1;
        while (n2 <= this.c) {
            n3 = n2;
            if (this.d(n2)) {
                ++this.c;
                n3 = n2 + 2;
            }
            n2 = n3 + 1;
        }
        this.e();
    }

    public final void a(byte[] arrby, int n2, int n3) {
        this.a = arrby;
        this.c = n2;
        this.b = n3;
        this.d = 0;
        this.e();
    }

    public final boolean a() {
        if (this.c(1) == 1) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean b() {
        int n2 = this.c;
        int n3 = this.d;
        int n4 = 0;
        while (this.c < this.b && !this.a()) {
            ++n4;
        }
        boolean bl2 = this.c == this.b;
        this.c = n2;
        this.d = n3;
        if (!bl2 && this.b((n4 << 1) + 1)) {
            return true;
        }
        return false;
    }

    public final boolean b(int n2) {
        int n3 = this.c;
        int n4 = this.c + n2 / 8;
        int n5 = this.d + n2 % 8;
        n2 = n4;
        int n6 = n5;
        if (n5 > 7) {
            n2 = n4 + 1;
            n6 = n5 - 8;
        }
        n4 = n3 + 1;
        while (n4 <= n2 && n2 < this.b) {
            n5 = n2;
            n3 = n4;
            if (this.d(n4)) {
                n5 = n2 + 1;
                n3 = n4 + 2;
            }
            n4 = n3 + 1;
            n2 = n5;
        }
        if (n2 < this.b || n2 == this.b && n6 == 0) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final int c() {
        int n2;
        int n3 = this.d();
        if (n3 % 2 == 0) {
            n2 = -1;
            do {
                return n2 * ((n3 + 1) / 2);
                break;
            } while (true);
        }
        n2 = 1;
        return n2 * ((n3 + 1) / 2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int c(int n2) {
        int n3;
        int n4;
        if (n2 == 0) {
            return 0;
        }
        int n5 = n2 / 8;
        int n6 = 0;
        int n7 = n2;
        n2 = n6;
        for (n4 = 0; n4 < n5; n2 |= (n3 & 255) << (n7 -= 8), ++n4) {
            n6 = this.d(this.c + 1) ? this.c + 2 : this.c + 1;
            n3 = this.d != 0 ? (this.a[this.c] & 255) << this.d | (this.a[n6] & 255) >>> 8 - this.d : this.a[this.c];
            this.c = n6;
        }
        if (n7 > 0) {
            n6 = this.d + n7;
            n7 = (byte)(255 >> 8 - n7);
            n4 = this.d(this.c + 1) ? this.c + 2 : this.c + 1;
            if (n6 > 8) {
                n2 = ((this.a[this.c] & 255) << n6 - 8 | (this.a[n4] & 255) >> 16 - n6) & n7 | n2;
                this.c = n4;
            } else {
                n2 = n7 = (this.a[this.c] & 255) >> 8 - n6 & n7 | n2;
                if (n6 == 8) {
                    this.c = n4;
                    n2 = n7;
                }
            }
            this.d = n6 % 8;
        }
        this.e();
        return n2;
    }

    public final int d() {
        int n2 = 0;
        int n3 = 0;
        while (!this.a()) {
            ++n3;
        }
        if (n3 > 0) {
            n2 = this.c(n3);
        }
        return (1 << n3) - 1 + n2;
    }
}

