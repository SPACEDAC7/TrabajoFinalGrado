/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.HandlerThread
 *  android.os.Process
 */
package com.google.android.exoplayer2.i;

import android.os.HandlerThread;
import android.os.Process;

public final class k
extends HandlerThread {
    private final int a = -16;

    public k(String string) {
        super(string);
    }

    public final void run() {
        Process.setThreadPriority((int)this.a);
        super.run();
    }
}

