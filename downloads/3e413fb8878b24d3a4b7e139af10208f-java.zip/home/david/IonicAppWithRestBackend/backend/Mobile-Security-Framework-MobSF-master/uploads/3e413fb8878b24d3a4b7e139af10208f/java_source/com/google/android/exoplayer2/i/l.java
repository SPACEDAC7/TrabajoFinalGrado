/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.i;

import java.util.ArrayList;
import java.util.Comparator;

public final class l {
    public static final Comparator<a> a = new Comparator<a>(){};
    public static final Comparator<a> b = new Comparator<a>(){};
    public final int c = 2000;
    public final ArrayList<a> d = new ArrayList();
    public final a[] e = new a[5];
    public int f = -1;
    public int g;
    public int h;
    public int i;

    public static final class a {
        public int a;
        public int b;
        public float c;

        private a() {
        }

        public /* synthetic */ a(byte by2) {
            this();
        }
    }

}

