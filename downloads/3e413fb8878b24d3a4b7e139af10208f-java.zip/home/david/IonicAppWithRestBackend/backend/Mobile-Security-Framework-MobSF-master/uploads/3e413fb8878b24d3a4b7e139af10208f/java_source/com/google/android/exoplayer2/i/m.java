/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.SystemClock
 */
package com.google.android.exoplayer2.i;

import android.os.SystemClock;
import com.google.android.exoplayer2.i.f;

public final class m
implements f {
    public boolean a;
    public long b;
    public long c;

    public static long b(long l2) {
        return SystemClock.elapsedRealtime() * 1000 - l2;
    }

    public final void a() {
        if (this.a) {
            this.b = m.b(this.c);
            this.a = false;
        }
    }

    public final void a(long l2) {
        this.b = l2;
        this.c = m.b(l2);
    }

    @Override
    public final long v() {
        if (this.a) {
            return m.b(this.c);
        }
        return this.b;
    }
}

