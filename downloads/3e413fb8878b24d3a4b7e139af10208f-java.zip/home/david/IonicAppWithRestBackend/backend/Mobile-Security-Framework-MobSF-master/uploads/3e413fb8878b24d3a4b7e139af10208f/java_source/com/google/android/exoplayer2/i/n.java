/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.i;

public final class n {
    public final long a;
    public volatile long b;
    private long c;

    public n(long l2) {
        this.a = l2;
        this.b = -9223372036854775807L;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final long a() {
        long l2 = -9223372036854775807L;
        if (this.a == Long.MAX_VALUE) {
            return 0;
        }
        if (this.b == -9223372036854775807L) return l2;
        return this.c;
    }

    public final long a(long l2) {
        if (l2 == -9223372036854775807L) {
            return -9223372036854775807L;
        }
        if (this.b != -9223372036854775807L) {
            long l3 = this.b * 90000 / 1000000;
            long l4 = (0x100000000L + l3) / 0x200000000L;
            long l5 = (l4 - 1) * 0x200000000L + l2;
            l2 = l4 * 0x200000000L + l2;
            if (Math.abs(l5 - l3) < Math.abs(l2 - l3)) {
                l2 = l5;
            }
        }
        return this.b(l2 * 1000000 / 90000);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final long b(long l2) {
        if (l2 == -9223372036854775807L) {
            return -9223372036854775807L;
        }
        if (this.b != -9223372036854775807L) {
            this.b = l2;
            return this.c + l2;
        }
        if (this.a != Long.MAX_VALUE) {
            this.c = this.a - l2;
        }
        synchronized (this) {
            this.b = l2;
            this.notifyAll();
            return this.c + l2;
        }
    }
}

