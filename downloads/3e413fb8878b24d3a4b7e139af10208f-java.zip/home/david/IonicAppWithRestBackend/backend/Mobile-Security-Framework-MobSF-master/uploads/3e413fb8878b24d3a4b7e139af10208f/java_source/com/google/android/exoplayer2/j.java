/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

public final class j {
    public static final int[] AspectRatioFrameLayout = new int[]{2130771974};
    public static final int AspectRatioFrameLayout_resize_mode = 0;
    public static final int[] PlaybackControlView = new int[]{2130771968, 2130771970, 2130771975, 2130771976};
    public static final int PlaybackControlView_controller_layout_id = 0;
    public static final int PlaybackControlView_fastforward_increment = 1;
    public static final int PlaybackControlView_rewind_increment = 2;
    public static final int PlaybackControlView_show_timeout = 3;
    public static final int[] SimpleExoPlayerView = new int[]{2130771968, 2130771970, 2130771973, 2130771974, 2130771975, 2130771976, 2130771977, 2130772255, 2130772256, 2130772257};
    public static final int SimpleExoPlayerView_controller_layout_id = 0;
    public static final int SimpleExoPlayerView_default_artwork = 8;
    public static final int SimpleExoPlayerView_fastforward_increment = 1;
    public static final int SimpleExoPlayerView_player_layout_id = 2;
    public static final int SimpleExoPlayerView_resize_mode = 3;
    public static final int SimpleExoPlayerView_rewind_increment = 4;
    public static final int SimpleExoPlayerView_show_timeout = 5;
    public static final int SimpleExoPlayerView_surface_type = 6;
    public static final int SimpleExoPlayerView_use_artwork = 7;
    public static final int SimpleExoPlayerView_use_controller = 9;
}

