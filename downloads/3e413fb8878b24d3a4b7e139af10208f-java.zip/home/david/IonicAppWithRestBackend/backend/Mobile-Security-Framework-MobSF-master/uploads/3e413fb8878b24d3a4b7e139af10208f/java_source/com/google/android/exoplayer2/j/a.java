/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.j;

import com.google.android.exoplayer2.i;
import com.google.android.exoplayer2.i.g;
import java.util.ArrayList;
import java.util.List;

public final class a {
    public final List<byte[]> a;
    public final int b;
    public final int c;
    public final int d;
    public final float e;

    private a(List<byte[]> list, int n2, int n3, int n4, float f2) {
        this.a = list;
        this.b = n2;
        this.c = n3;
        this.d = n4;
        this.e = f2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static a a(com.google.android.exoplayer2.i.i var0) {
        var4_2 = -1;
        var5_3 = 0;
        try {
            var0.d(4);
            var6_4 = (var0.e() & 3) + 1;
            if (var6_4 == 3) {
                throw new IllegalStateException();
            }
            var2_5 = new ArrayList<byte[]>();
            var7_6 = var0.e() & 31;
            for (var3_7 = 0; var3_7 < var7_6; ++var3_7) {
                var2_5.add(a.b((com.google.android.exoplayer2.i.i)var0));
            }
            var8_8 = var0.e();
            for (var3_7 = var5_3; var3_7 < var8_8; ++var3_7) {
                var2_5.add(a.b((com.google.android.exoplayer2.i.i)var0));
            }
            var1_9 = 1.0f;
            ** if (var7_6 <= 0) goto lbl-1000
        }
        catch (ArrayIndexOutOfBoundsException var0_1) {
            throw new i("Error parsing AVC config", var0_1);
        }
lbl-1000: // 1 sources:
        {
            var0 = (byte[])var2_5.get(0);
            var0 = g.a((byte[])var2_5.get(0), var6_4, var0.length);
            var3_7 = var0.b;
            var4_2 = var0.c;
            var1_9 = var0.d;
            return new a(var2_5, var6_4, var3_7, var4_2, var1_9);
        }
lbl-1000: // 1 sources:
        {
        }
        var5_3 = -1;
        var3_7 = var4_2;
        var4_2 = var5_3;
        return new a(var2_5, var6_4, var3_7, var4_2, var1_9);
    }

    private static byte[] b(com.google.android.exoplayer2.i.i i2) {
        int n2 = i2.f();
        int n3 = i2.b;
        i2.d(n2);
        return com.google.android.exoplayer2.i.a.a(i2.a, n3, n2);
    }
}

