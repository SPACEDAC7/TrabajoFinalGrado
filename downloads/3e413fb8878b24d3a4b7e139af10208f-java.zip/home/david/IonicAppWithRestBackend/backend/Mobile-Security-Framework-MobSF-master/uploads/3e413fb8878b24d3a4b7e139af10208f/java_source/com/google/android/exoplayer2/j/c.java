/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.graphics.Point
 *  android.media.MediaCodec
 *  android.media.MediaCodec$OnFrameRenderedListener
 *  android.media.MediaCodecInfo
 *  android.media.MediaCodecInfo$CodecCapabilities
 *  android.media.MediaCodecInfo$CodecProfileLevel
 *  android.media.MediaCodecInfo$VideoCapabilities
 *  android.media.MediaCrypto
 *  android.media.MediaFormat
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.util.Log
 *  android.util.Pair
 *  android.view.Surface
 */
package com.google.android.exoplayer2.j;

import a.a.a.a.a.f;
import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Point;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.util.Pair;
import android.view.Surface;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.j.d;
import com.google.android.exoplayer2.j.e;
import com.google.android.exoplayer2.k;
import com.google.android.exoplayer2.l;
import java.nio.ByteBuffer;

@TargetApi(value=16)
public final class c
extends com.google.android.exoplayer2.d.b {
    private static final int[] l = new int[]{1920, 1600, 1440, 1280, 960, 854, 640, 540, 480};
    private int A;
    private float B;
    private int C;
    private int D;
    private int E;
    private float F;
    private int G;
    private int H;
    private int I;
    private float J;
    private boolean K;
    private int L;
    b k;
    private final d m;
    private final e.a n;
    private final long o;
    private final int p;
    private final boolean q;
    private Format[] r;
    private a s;
    private Surface t;
    private int u;
    private boolean v;
    private long w;
    private long x;
    private int y;
    private int z;

    public c(Context context, com.google.android.exoplayer2.d.c c2, Handler handler, e e2) {
        boolean bl2 = false;
        super(2, c2, false);
        this.o = 5000;
        this.p = 50;
        this.m = new d(context);
        this.n = new e.a(handler, e2);
        boolean bl3 = bl2;
        if (o.a <= 22) {
            bl3 = bl2;
            if ("foster".equals(o.b)) {
                bl3 = bl2;
                if ("NVIDIA".equals(o.c)) {
                    bl3 = true;
                }
            }
        }
        this.q = bl3;
        this.w = -9223372036854775807L;
        this.C = -1;
        this.D = -1;
        this.F = -1.0f;
        this.B = -1.0f;
        this.u = 1;
        this.u();
    }

    private void B() {
        if (this.y > 0) {
            long l2 = SystemClock.elapsedRealtime();
            long l3 = this.x;
            e.a a2 = this.n;
            int n2 = this.y;
            if (a2.b != null) {
                a2.a.post(new Runnable(a2, n2, l2 - l3){
                    final /* synthetic */ int a;
                    final /* synthetic */ long b;
                    final /* synthetic */ e.a c;

                    public final void run() {
                    }
                });
            }
            this.y = 0;
            this.x = l2;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int a(String var0, int var1_1, int var2_2) {
        var4_3 = 2;
        if (var1_1 == -1) return -1;
        if (var2_2 == -1) {
            return -1;
        }
        switch (var0.hashCode()) {
            case -1664118616: {
                if (!var0.equals("video/3gpp")) ** GOTO lbl26
                var3_4 = 0;
                ** GOTO lbl33
            }
            case 1187890754: {
                if (!var0.equals("video/mp4v-es")) ** GOTO lbl26
                var3_4 = 1;
                ** GOTO lbl33
            }
            case 1331836730: {
                if (!var0.equals("video/avc")) ** GOTO lbl26
                var3_4 = 2;
                ** GOTO lbl33
            }
            case 1599127256: {
                if (!var0.equals("video/x-vnd.on2.vp8")) ** GOTO lbl26
                var3_4 = 3;
                ** GOTO lbl33
            }
            case -1662541442: {
                if (!var0.equals("video/hevc")) ** GOTO lbl26
                var3_4 = 4;
                ** GOTO lbl33
            }
lbl26: // 6 sources:
            default: {
                ** GOTO lbl-1000
            }
            case 1599127257: 
        }
        if (var0.equals("video/x-vnd.on2.vp9")) {
            var3_4 = 5;
        } else lbl-1000: // 2 sources:
        {
            var3_4 = -1;
        }
lbl33: // 7 sources:
        switch (var3_4) {
            default: {
                return -1;
            }
            case 0: 
            case 1: {
                var1_1 *= var2_2;
                var2_2 = var4_3;
                return var1_1 * 3 / (var2_2 * 2);
            }
            case 2: {
                if ("BRAVIA 4K 2015".equals(o.d)) {
                    return -1;
                }
                var1_1 = o.a(var1_1, 16) * o.a(var2_2, 16) << 4 << 4;
                var2_2 = var4_3;
                return var1_1 * 3 / (var2_2 * 2);
            }
            case 3: {
                var2_2 = var4_3;
                return (var1_1 *= var2_2) * 3 / (var2_2 * 2);
            }
            case 4: 
            case 5: 
        }
        var2_2 = 4;
        return (var1_1 *= var2_2) * 3 / (var2_2 * 2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Point a(com.google.android.exoplayer2.d.a a2, Format format) {
        int n2;
        int n3;
        boolean bl2 = format.k > format.j;
        int n4 = bl2 ? format.k : format.j;
        int n5 = bl2 ? format.j : format.k;
        float f2 = (float)n5 / (float)n4;
        int[] arrn = l;
        int n6 = arrn.length;
        int n7 = 0;
        while (n7 < n6) {
            int n8 = arrn[n7];
            n2 = (int)((float)n8 * f2);
            if (n8 <= n4) return null;
            if (n2 <= n5) {
                return null;
            }
            if (o.a >= 21) {
                MediaCodecInfo.VideoCapabilities videoCapabilities;
                n3 = bl2 ? n2 : n8;
                if (!bl2) {
                    n8 = n2;
                }
                if (a2.e == null) {
                    a2.a("align.caps");
                    videoCapabilities = null;
                } else {
                    videoCapabilities = a2.e.getVideoCapabilities();
                    if (videoCapabilities == null) {
                        a2.a("align.vCaps");
                        videoCapabilities = null;
                    } else {
                        n2 = videoCapabilities.getWidthAlignment();
                        int n9 = videoCapabilities.getHeightAlignment();
                        videoCapabilities = new Point(o.a(n3, n2) * n2, o.a(n8, n9) * n9);
                    }
                }
                float f3 = format.l;
                MediaCodecInfo.VideoCapabilities videoCapabilities2 = videoCapabilities;
                if (a2.a(videoCapabilities.x, videoCapabilities.y, f3)) return videoCapabilities2;
            } else {
                n3 = o.a(n8, 16) << 4;
                if (n3 * (n2 = o.a(n2, 16) << 4) <= com.google.android.exoplayer2.d.d.b()) {
                    n4 = bl2 ? n2 : n3;
                }
            }
            ++n7;
        }
        return null;
        if (bl2) {
            return new Point(n4, n3);
        }
        n3 = n2;
        return new Point(n4, n3);
    }

    private void a(MediaCodec object, int n2) {
        this.v();
        f.a("releaseOutputBuffer");
        object.releaseOutputBuffer(n2, true);
        f.a();
        object = this.j;
        ++object.d;
        this.z = 0;
        this.s();
    }

    @TargetApi(value=21)
    private void a(MediaCodec object, int n2, long l2) {
        this.v();
        f.a("releaseOutputBuffer");
        object.releaseOutputBuffer(n2, l2);
        f.a();
        object = this.j;
        ++object.d;
        this.z = 0;
        this.s();
    }

    private static boolean a(Format format, Format format2) {
        if (format.f.equals(format2.f) && c.d(format) == c.d(format2)) {
            return true;
        }
        return false;
    }

    private static int c(Format format) {
        if (format.g != -1) {
            return format.g;
        }
        return c.a(format.f, format.j, format.k);
    }

    private static int d(Format format) {
        if (format.m == -1) {
            return 0;
        }
        return format.m;
    }

    private void t() {
        MediaCodec mediaCodec;
        this.v = false;
        if (o.a >= 23 && this.K && (mediaCodec = this.i) != null) {
            this.k = new b(mediaCodec, 0);
        }
    }

    private void u() {
        this.G = -1;
        this.H = -1;
        this.J = -1.0f;
        this.I = -1;
    }

    private void v() {
        if (this.G != this.C || this.H != this.D || this.I != this.E || this.J != this.F) {
            e.a a2 = this.n;
            int n2 = this.C;
            int n3 = this.D;
            int n4 = this.E;
            float f2 = this.F;
            if (a2.b != null) {
                a2.a.post(new Runnable(a2, n2, n3, n4, f2){
                    final /* synthetic */ int a;
                    final /* synthetic */ int b;
                    final /* synthetic */ int c;
                    final /* synthetic */ float d;
                    final /* synthetic */ e.a e;

                    public final void run() {
                        this.e.b.a(this.a, this.b, this.c, this.d);
                    }
                });
            }
            this.G = this.C;
            this.H = this.D;
            this.I = this.E;
            this.J = this.F;
        }
    }

    @Override
    protected final void A() {
        if (o.a < 23 && this.K) {
            this.s();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final int a(com.google.android.exoplayer2.d.c var1_1, Format var2_2) {
        var9_3 = 0;
        var3_4 = var2_2.f;
        if (!a.a.a.a.d.e((String)var3_4)) {
            return 0;
        }
        var4_5 = var2_2.i;
        if (var4_5 != null) {
            var8_6 = 0;
            var11_7 = false;
            do {
                var12_8 = var11_7;
                if (var8_6 < var4_5.b) {
                    var11_7 |= var4_5.a[var8_6].c;
                    ++var8_6;
                    continue;
                }
                break;
                break;
            } while (true);
        } else {
            var12_8 = false;
        }
        if ((var3_4 = var1_1.a((String)var3_4, var12_8)) == null) {
            return 1;
        }
        var4_5 = var2_2.c;
        if (var4_5 != null && var3_4.d != null) ** GOTO lbl23
        var11_7 = true;
        ** GOTO lbl72
lbl23: // 1 sources:
        if (var4_5 == null) ** GOTO lbl-1000
        var1_1 = var4_5.trim();
        if (var1_1.startsWith("avc1") || var1_1.startsWith("avc3")) {
            var1_1 = "video/avc";
        } else if (var1_1.startsWith("hev1") || var1_1.startsWith("hvc1")) {
            var1_1 = "video/hevc";
        } else if (var1_1.startsWith("vp9")) {
            var1_1 = "video/x-vnd.on2.vp9";
        } else if (var1_1.startsWith("vp8")) {
            var1_1 = "video/x-vnd.on2.vp8";
        } else if (var1_1.startsWith("mp4a")) {
            var1_1 = "audio/mp4a-latm";
        } else if (var1_1.startsWith("ac-3") || var1_1.startsWith("dac3")) {
            var1_1 = "audio/ac3";
        } else if (var1_1.startsWith("ec-3") || var1_1.startsWith("dec3")) {
            var1_1 = "audio/eac3";
        } else if (var1_1.startsWith("dtsc") || var1_1.startsWith("dtse")) {
            var1_1 = "audio/vnd.dts";
        } else if (var1_1.startsWith("dtsh") || var1_1.startsWith("dtsl")) {
            var1_1 = "audio/vnd.dts.hd";
        } else if (var1_1.startsWith("opus")) {
            var1_1 = "audio/opus";
        } else if (var1_1.startsWith("vorbis")) {
            var1_1 = "audio/vorbis";
        } else lbl-1000: // 2 sources:
        {
            var1_1 = null;
        }
        if (var1_1 != null) ** GOTO lbl62
        var11_7 = true;
        ** GOTO lbl72
lbl62: // 1 sources:
        if (var3_4.d.equals(var1_1)) ** GOTO lbl66
        var3_4.a("codec.mime " + (String)var4_5 + ", " + (String)var1_1);
        var11_7 = false;
        ** GOTO lbl72
lbl66: // 1 sources:
        var5_10 = com.google.android.exoplayer2.d.d.a((String)var4_5);
        if (var5_10 != null) {
            var6_11 = var3_4.a();
            var10_9 = var6_11.length;
        } else {
            var11_7 = true;
lbl72: // 6 sources:
            do {
                var12_8 = var11_7;
                if (var11_7) {
                    var12_8 = var11_7;
                    if (var2_2.j > 0) {
                        var12_8 = var11_7;
                        if (var2_2.k > 0) {
                            if (o.a >= 21) {
                                var12_8 = var3_4.a(var2_2.j, var2_2.k, var2_2.l);
                            } else {
                                var11_7 = var2_2.j * var2_2.k <= com.google.android.exoplayer2.d.d.b();
                                var12_8 = var11_7;
                                if (!var11_7) {
                                    Log.d((String)"MediaCodecVideoRenderer", (String)("FalseCheck [legacyFrameSize, " + var2_2.j + "x" + var2_2.k + "] [" + o.e + "]"));
                                    var12_8 = var11_7;
                                }
                            }
                        }
                    }
                }
                var8_6 = var3_4.b != false ? 8 : 4;
                if (var3_4.c) {
                    var9_3 = 16;
                }
                if (var12_8) {
                    var10_9 = 3;
                    return var9_3 | var8_6 | var10_9;
                }
                var10_9 = 2;
                return var9_3 | var8_6 | var10_9;
                break;
            } while (true);
        }
        for (var8_6 = 0; var8_6 < var10_9; ++var8_6) {
            var7_12 = var6_11[var8_6];
            if (var7_12.profile != (Integer)var5_10.first || var7_12.level < (Integer)var5_10.second) continue;
            var11_7 = true;
            ** GOTO lbl72
        }
        var3_4.a("codec.profileLevel, " + (String)var4_5 + ", " + (String)var1_1);
        var11_7 = false;
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(int n2, Object object) {
        if (n2 == 1) {
            if (this.t != (object = (Surface)object)) {
                this.t = object;
                n2 = this.d;
                if (n2 == 1 || n2 == 2) {
                    this.z();
                    this.x();
                }
            }
            this.t();
            this.u();
            return;
        } else {
            if (n2 != 5) {
                super.a(n2, object);
                return;
            }
            this.u = (Integer)object;
            object = this.i;
            if (object == null) return;
            {
                object.setVideoScalingMode(this.u);
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(long l2, boolean bl2) {
        super.a(l2, bl2);
        this.t();
        this.z = 0;
        l2 = bl2 && this.o > 0 ? SystemClock.elapsedRealtime() + this.o : -9223372036854775807L;
        this.w = l2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(MediaCodec mediaCodec, MediaFormat mediaFormat) {
        int n2 = mediaFormat.containsKey("crop-right") && mediaFormat.containsKey("crop-left") && mediaFormat.containsKey("crop-bottom") && mediaFormat.containsKey("crop-top") ? 1 : 0;
        int n3 = n2 != 0 ? mediaFormat.getInteger("crop-right") - mediaFormat.getInteger("crop-left") + 1 : mediaFormat.getInteger("width");
        this.C = n3;
        n2 = n2 != 0 ? mediaFormat.getInteger("crop-bottom") - mediaFormat.getInteger("crop-top") + 1 : mediaFormat.getInteger("height");
        this.D = n2;
        this.F = this.B;
        if (o.a >= 21) {
            if (this.A == 90 || this.A == 270) {
                n2 = this.C;
                this.C = this.D;
                this.D = n2;
                this.F = 1.0f / this.F;
            }
        } else {
            this.E = this.A;
        }
        mediaCodec.setVideoScalingMode(this.u);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final void a(com.google.android.exoplayer2.d.a var1_1, MediaCodec var2_2, Format var3_3, MediaCrypto var4_4) {
        var5_5 = this.r;
        var9_6 = var3_3.j;
        var8_7 = var3_3.k;
        var7_8 = c.c(var3_3);
        if (var5_5.length == 1) {
            var1_1 = new a(var9_6, var8_7, var7_8);
lbl7: // 2 sources:
            do {
                var1_1 = this.s = var1_1;
                var16_9 = this.q;
                var7_8 = this.L;
                var3_3 = var3_3.b();
                var3_3.setInteger("max-width", var1_1.a);
                var3_3.setInteger("max-height", var1_1.b);
                if (var1_1.c != -1) {
                    var3_3.setInteger("max-input-size", var1_1.c);
                }
                if (var16_9) {
                    var3_3.setInteger("auto-frc", 0);
                }
                if (var7_8 != 0) {
                    var3_3.setFeatureEnabled("tunneled-playback", true);
                    var3_3.setInteger("audio-session-id", var7_8);
                }
                var2_2.configure((MediaFormat)var3_3, this.t, var4_4, 0);
                if (o.a < 23) return;
                if (this.K == false) return;
                this.k = new b(var2_2, 0);
                return;
                break;
            } while (true);
        }
        var10_10 = 0;
        var15_11 = var5_5.length;
        var11_12 = 0;
        do {
            if (var11_12 >= var15_11) ** GOTO lbl39
            var6_13 = var5_5[var11_12];
            if (!c.a(var3_3, var6_13)) ** GOTO lbl55
            var12_14 = var6_13.j == -1 || var6_13.k == -1 ? 1 : 0;
            var10_10 = Math.max(var9_6, var6_13.j);
            var9_6 = Math.max(var8_7, var6_13.k);
            var8_7 = Math.max(var7_8, c.c(var6_13));
            var7_8 = var12_14 |= var10_10;
            ** GOTO lbl62
lbl39: // 1 sources:
            var13_15 = var7_8;
            var12_14 = var8_7;
            var11_12 = var9_6;
            if (var10_10 != 0) {
                Log.w((String)"MediaCodecVideoRenderer", (String)("Resolutions unknown. Codec max resolution: " + var9_6 + "x" + var8_7));
                var1_1 = c.a((com.google.android.exoplayer2.d.a)var1_1, var3_3);
                var13_15 = var7_8;
                var12_14 = var8_7;
                var11_12 = var9_6;
                if (var1_1 != null) {
                    var11_12 = Math.max(var9_6, var1_1.x);
                    var12_14 = Math.max(var8_7, var1_1.y);
                    var13_15 = Math.max(var7_8, c.a(var3_3.f, var11_12, var12_14));
                    Log.w((String)"MediaCodecVideoRenderer", (String)("Codec max resolution adjusted to: " + var11_12 + "x" + var12_14));
                }
            }
            var1_1 = new a(var11_12, var12_14, var13_15);
            ** continue;
lbl55: // 1 sources:
            var12_14 = var7_8;
            var13_15 = var8_7;
            var14_16 = var9_6;
            var7_8 = var10_10;
            var8_7 = var12_14;
            var9_6 = var13_15;
            var10_10 = var14_16;
lbl62: // 2 sources:
            var12_14 = var11_12 + 1;
            var11_12 = var10_10;
            var10_10 = var7_8;
            var7_8 = var8_7;
            var8_7 = var9_6;
            var9_6 = var11_12;
            var11_12 = var12_14;
        } while (true);
    }

    @Override
    protected final void a(String string, long l2, long l3) {
        e.a a2 = this.n;
        if (a2.b != null) {
            a2.a.post(new Runnable(a2, string, l2, l3){
                final /* synthetic */ String a;
                final /* synthetic */ long b;
                final /* synthetic */ long c;
                final /* synthetic */ e.a d;

                public final void run() {
                }
            });
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(boolean bl2) {
        super.a(bl2);
        this.L = this.b.b;
        bl2 = this.L != 0;
        this.K = bl2;
        Object object = this.n;
        com.google.android.exoplayer2.b.d d2 = this.j;
        if (object.b != null) {
            object.a.post(new Runnable((e.a)object, d2){
                final /* synthetic */ com.google.android.exoplayer2.b.d a;
                final /* synthetic */ e.a b;

                public final void run() {
                    this.b.b.a(this.a);
                }
            });
        }
        object = this.m;
        object.h = false;
        if (object.b) {
            object.a.b.sendEmptyMessage(1);
        }
    }

    @Override
    protected final void a(Format[] arrformat) {
        this.r = arrformat;
        super.a(arrformat);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected final boolean a(long var1_1, long var3_2, MediaCodec var5_3, ByteBuffer var6_4, int var7_6, int var8_7, long var9_8, boolean var11_9) {
        if (var11_9) {
            f.a("skipVideoBuffer");
            var5_3.releaseOutputBuffer(var7_6, false);
            f.a();
            var5_3 = this.j;
            ++var5_3.e;
            return true;
        }
        if (!this.v) {
            if (o.a >= 21) {
                this.a((MediaCodec)var5_3, var7_6, System.nanoTime());
                return true;
            }
            this.a((MediaCodec)var5_3, var7_6);
            return true;
        }
        if (this.d != 2) {
            return false;
        }
        var12_10 = SystemClock.elapsedRealtime();
        var16_11 = System.nanoTime();
        var12_10 = var16_11 + (var9_8 - var1_1 - (var12_10 * 1000 - var3_2)) * 1000;
        var6_4 = this.m;
        var14_12 = var9_8 * 1000;
        if (!var6_4.h) ** GOTO lbl37
        if (var9_8 != var6_4.e) {
            ++var6_4.k;
            var6_4.f = var6_4.g;
        }
        if (var6_4.k >= 6) {
            var1_1 = (var14_12 - var6_4.j) / var6_4.k;
            var3_2 = var6_4.f + var1_1;
            if (var6_4.a(var3_2, var12_10)) {
                var6_4.h = false;
                var1_1 = var12_10;
                var3_2 = var14_12;
            } else {
                var1_1 = var6_4.i + var3_2 - var6_4.j;
            }
        } else {
            if (var6_4.a(var14_12, var12_10)) {
                var6_4.h = false;
            }
lbl37: // 4 sources:
            var1_1 = var12_10;
            var3_2 = var14_12;
        }
        if (!var6_4.h) {
            var6_4.j = var14_12;
            var6_4.i = var12_10;
            var6_4.k = 0;
            var6_4.h = true;
        }
        var6_4.e = var9_8;
        var6_4.g = var3_2;
        var3_2 = var1_1;
        if (var6_4.a != null) {
            if (var6_4.a.a == 0) {
                var3_2 = var1_1;
            } else {
                var3_2 = var6_4.a.a;
                var12_10 = var6_4.c;
                if (var1_1 <= (var3_2 += (var1_1 - var3_2) / var12_10 * var12_10)) {
                    var9_8 = var3_2 - var12_10;
                } else {
                    var9_8 = var3_2;
                    var3_2 = var12_10 + var3_2;
                }
                if (var3_2 - var1_1 >= var1_1 - var9_8) {
                    var3_2 = var9_8;
                }
                var3_2 -= var6_4.d;
            }
        }
        var8_7 = (var1_1 = (var3_2 - var16_11) / 1000) < -30000 ? 1 : 0;
        if (var8_7 != 0) {
            f.a("dropVideoBuffer");
            var5_3.releaseOutputBuffer(var7_6, false);
            f.a();
            var5_3 = this.j;
            ++var5_3.f;
            ++this.y;
            ++this.z;
            this.j.g = Math.max(this.z, this.j.g);
            if (this.y != this.p) return true;
            this.B();
            return true;
        }
        if (o.a >= 21) {
            if (var1_1 >= 50000) return false;
            this.a((MediaCodec)var5_3, var7_6, var3_2);
            return true;
        }
        if (var1_1 >= 30000) return false;
        if (var1_1 > 11000) {
            try {
                Thread.sleep((var1_1 - 10000) / 1000);
            }
            catch (InterruptedException var6_5) {
                Thread.currentThread().interrupt();
            }
        }
        this.a((MediaCodec)var5_3, var7_6);
        return true;
    }

    @Override
    protected final boolean a(boolean bl2, Format format, Format format2) {
        if (c.a(format, format2) && format2.j <= this.s.a && format2.k <= this.s.b && format2.g <= this.s.c && (bl2 || format.j == format2.j && format.k == format2.k)) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void b(Format format) {
        super.b(format);
        e.a a2 = this.n;
        if (a2.b != null) {
            a2.a.post(new Runnable(a2, format){
                final /* synthetic */ Format a;
                final /* synthetic */ e.a b;

                public final void run() {
                    this.b.b.a(this.a);
                }
            });
        }
        float f2 = format.n == -1.0f ? 1.0f : format.n;
        this.B = f2;
        this.A = c.d(format);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean k() {
        if ((this.v || super.y()) && super.k()) {
            this.w = -9223372036854775807L;
            return true;
        } else {
            if (this.w == -9223372036854775807L) {
                return false;
            }
            if (SystemClock.elapsedRealtime() < this.w) return true;
            {
                this.w = -9223372036854775807L;
                return false;
            }
        }
    }

    @Override
    protected final void p() {
        super.p();
        this.y = 0;
        this.x = SystemClock.elapsedRealtime();
    }

    @Override
    protected final void q() {
        this.w = -9223372036854775807L;
        this.B();
        super.q();
    }

    @Override
    protected final void r() {
        this.C = -1;
        this.D = -1;
        this.F = -1.0f;
        this.B = -1.0f;
        this.u();
        d d2 = this.m;
        if (d2.b) {
            d2.a.b.sendEmptyMessage(2);
        }
        this.k = null;
        try {
            super.r();
            return;
        }
        finally {
            this.j.a();
            this.n.a(this.j);
        }
    }

    final void s() {
        if (!this.v) {
            this.v = true;
            e.a a2 = this.n;
            Surface surface = this.t;
            if (a2.b != null) {
                a2.a.post(new Runnable(a2, surface){
                    final /* synthetic */ Surface a;
                    final /* synthetic */ e.a b;

                    public final void run() {
                        this.b.b.a(this.a);
                    }
                });
            }
        }
    }

    @Override
    protected final boolean y() {
        if (super.y() && this.t != null && this.t.isValid()) {
            return true;
        }
        return false;
    }

    static final class a {
        public final int a;
        public final int b;
        public final int c;

        public a(int n2, int n3, int n4) {
            this.a = n2;
            this.b = n3;
            this.c = n4;
        }
    }

    @TargetApi(value=23)
    final class b
    implements MediaCodec.OnFrameRenderedListener {
        private b(MediaCodec mediaCodec) {
            mediaCodec.setOnFrameRenderedListener((MediaCodec.OnFrameRenderedListener)this, new Handler());
        }

        /* synthetic */ b(MediaCodec mediaCodec, byte by2) {
            this(mediaCodec);
        }

        public final void onFrameRendered(MediaCodec mediaCodec, long l2, long l3) {
            if (this != c.this.k) {
                return;
            }
            c.this.s();
        }
    }

}

