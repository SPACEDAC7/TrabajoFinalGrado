/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.os.Message
 *  android.view.Choreographer
 *  android.view.Choreographer$FrameCallback
 *  android.view.Display
 *  android.view.WindowManager
 */
package com.google.android.exoplayer2.j;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.view.Choreographer;
import android.view.Display;
import android.view.WindowManager;

@TargetApi(value=16)
public final class d {
    final a a;
    final boolean b;
    final long c;
    final long d;
    long e;
    long f;
    long g;
    boolean h;
    long i;
    long j;
    long k;

    public d() {
        this(-1.0, false);
    }

    private d(double d2, boolean bl2) {
        this.b = bl2;
        if (bl2) {
            this.a = a.a();
            this.c = (long)(1.0E9 / d2);
            this.d = this.c * 80 / 100;
            return;
        }
        this.a = null;
        this.c = -1;
        this.d = -1;
    }

    public d(Context context) {
        this(((WindowManager)context.getSystemService("window")).getDefaultDisplay().getRefreshRate(), true);
    }

    final boolean a(long l2, long l3) {
        long l4 = this.j;
        if (Math.abs(l3 - this.i - (l2 - l4)) > 20000000) {
            return true;
        }
        return false;
    }

    static final class a
    implements Handler.Callback,
    Choreographer.FrameCallback {
        private static final a c = new a();
        public volatile long a;
        final Handler b;
        private final HandlerThread d = new HandlerThread("ChoreographerOwner:Handler");
        private Choreographer e;
        private int f;

        private a() {
            this.d.start();
            this.b = new Handler(this.d.getLooper(), (Handler.Callback)this);
            this.b.sendEmptyMessage(0);
        }

        public static a a() {
            return c;
        }

        public final void doFrame(long l2) {
            this.a = l2;
            this.e.postFrameCallbackDelayed((Choreographer.FrameCallback)this, 500);
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public final boolean handleMessage(Message message) {
            boolean bl2 = true;
            switch (message.what) {
                default: {
                    return false;
                }
                case 0: {
                    this.e = Choreographer.getInstance();
                    return true;
                }
                case 1: {
                    ++this.f;
                    if (this.f != 1) return bl2;
                    this.e.postFrameCallback((Choreographer.FrameCallback)this);
                    return true;
                }
                case 2: 
            }
            --this.f;
            if (this.f != 0) return bl2;
            this.e.removeFrameCallback((Choreographer.FrameCallback)this);
            this.a = 0;
            return true;
        }
    }

}

