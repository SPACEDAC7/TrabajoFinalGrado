/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.view.Surface
 */
package com.google.android.exoplayer2.j;

import android.os.Handler;
import android.view.Surface;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.b.d;

public interface e {
    public void a(int var1, int var2, int var3, float var4);

    public void a(Surface var1);

    public void a(Format var1);

    public void a(d var1);

    public void b(d var1);

    public static final class a {
        final Handler a;
        final e b;

        /*
         * Enabled aggressive block sorting
         */
        public a(Handler handler, e e2) {
            handler = e2 != null ? a.a.a.a.d.b(handler) : null;
            this.a = handler;
            this.b = e2;
        }

        public final void a(final d d2) {
            if (this.b != null) {
                this.a.post(new Runnable(){

                    @Override
                    public final void run() {
                        d2.a();
                        a.this.b.b(d2);
                    }
                });
            }
        }

    }

}

