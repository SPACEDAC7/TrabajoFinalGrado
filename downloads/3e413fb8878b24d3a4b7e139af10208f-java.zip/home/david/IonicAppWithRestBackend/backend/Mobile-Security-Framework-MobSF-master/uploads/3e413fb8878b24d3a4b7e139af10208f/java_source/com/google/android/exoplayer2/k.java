/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

import a.a.a.a.d;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.b.e;
import com.google.android.exoplayer2.c;
import com.google.android.exoplayer2.f;
import com.google.android.exoplayer2.l;

public abstract class k
implements c.b {
    public final int a;
    public l b;
    public int c;
    public int d;
    public com.google.android.exoplayer2.e.c e;
    long f;
    public boolean g;
    public boolean h;

    public k(int n2) {
        this.a = n2;
        this.g = true;
    }

    @Override
    public final int a() {
        return this.a;
    }

    public abstract int a(Format var1);

    /*
     * Enabled aggressive block sorting
     */
    public final int a(f f2, e object) {
        int n2 = this.e.a(f2, (e)object);
        if (n2 != -4) {
            if (n2 != -5) return n2;
            object = f2.a;
            if (object.v == Long.MAX_VALUE) return n2;
            f2.a = object.a(object.v + this.f);
            return n2;
        }
        if (object.c()) {
            this.g = true;
            if (!this.h) return -3;
            return -4;
        }
        object.d += this.f;
        return n2;
    }

    @Override
    public final void a(int n2) {
        this.c = n2;
    }

    @Override
    public void a(int n2, Object object) {
    }

    @Override
    public final void a(long l2) {
        this.h = false;
        this.g = false;
        this.a(l2, false);
    }

    public void a(long l2, boolean bl2) {
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(l l2, Format[] arrformat, com.google.android.exoplayer2.e.c c2, long l3, boolean bl2, long l4) {
        boolean bl3 = this.d == 0;
        d.b(bl3);
        this.b = l2;
        this.d = 1;
        this.a(bl2);
        this.a(arrformat, c2, l4);
        this.a(l3, bl2);
    }

    public void a(boolean bl2) {
    }

    public void a(Format[] arrformat) {
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(Format[] arrformat, com.google.android.exoplayer2.e.c c2, long l2) {
        boolean bl2 = !this.h;
        d.b(bl2);
        this.e = c2;
        this.g = false;
        this.f = l2;
        this.a(arrformat);
    }

    @Override
    public final k b() {
        return this;
    }

    @Override
    public com.google.android.exoplayer2.i.f c() {
        return null;
    }

    @Override
    public final int d() {
        return this.d;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void e() {
        boolean bl2 = true;
        if (this.d != 1) {
            bl2 = false;
        }
        d.b(bl2);
        this.d = 2;
        this.p();
    }

    @Override
    public final com.google.android.exoplayer2.e.c f() {
        return this.e;
    }

    @Override
    public final boolean g() {
        return this.g;
    }

    @Override
    public final void h() {
        this.h = true;
    }

    @Override
    public final boolean i() {
        return this.h;
    }

    @Override
    public final void j() {
        this.e.b();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void m() {
        boolean bl2 = this.d == 2;
        d.b(bl2);
        this.d = 1;
        this.q();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void n() {
        boolean bl2 = true;
        if (this.d != 1) {
            bl2 = false;
        }
        d.b(bl2);
        this.d = 0;
        this.r();
        this.e = null;
        this.h = false;
    }

    public int o() {
        return 0;
    }

    public void p() {
    }

    public void q() {
    }

    public void r() {
    }
}

