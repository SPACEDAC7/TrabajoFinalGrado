/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

public final class l {
    public static final l a = new l(0);
    public final int b;

    public l(int n2) {
        this.b = n2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (l)object;
        if (this.b == object.b) return true;
        return false;
    }

    public final int hashCode() {
        return this.b;
    }
}

