/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.graphics.SurfaceTexture
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.Log
 *  android.view.Surface
 *  android.view.SurfaceHolder
 *  android.view.SurfaceHolder$Callback
 *  android.view.SurfaceView
 *  android.view.TextureView
 *  android.view.TextureView$SurfaceTextureListener
 */
package com.google.android.exoplayer2;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.os.Looper;
import android.support.design.widget.f;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.a.f;
import com.google.android.exoplayer2.c;
import com.google.android.exoplayer2.d;
import com.google.android.exoplayer2.d.c;
import com.google.android.exoplayer2.f.k;
import com.google.android.exoplayer2.h;
import com.google.android.exoplayer2.j.e;
import com.google.android.exoplayer2.n;
import java.util.ArrayList;
import java.util.List;

@TargetApi(value=16)
public final class m
implements com.google.android.exoplayer2.c {
    Format a;
    Format b;
    Surface c;
    k.a d;
    b e;
    com.google.android.exoplayer2.a.c f;
    e g;
    com.google.android.exoplayer2.b.d h;
    com.google.android.exoplayer2.b.d i;
    int j;
    private final com.google.android.exoplayer2.c k;
    private final c.b[] l;
    private final a m;
    private final Handler n = new Handler();
    private final int o;
    private final int p;
    private boolean q;
    private int r;
    private SurfaceHolder s;
    private TextureView t;
    private int u;
    private float v;

    /*
     * Enabled aggressive block sorting
     */
    public m(Context arrb, com.google.android.exoplayer2.g.h h2, h h3) {
        this.m = new a(0);
        ArrayList<com.google.android.exoplayer2.k> arrayList = new ArrayList<com.google.android.exoplayer2.k>();
        Handler handler = this.n;
        a a2 = this.m;
        arrayList.add(new com.google.android.exoplayer2.j.c((Context)arrb, c.a, handler, a2));
        a2 = this.m;
        arrayList.add(new f(c.a, handler, a2, com.google.android.exoplayer2.a.b.a((Context)arrb)));
        arrayList.add(new k(this.m, handler.getLooper()));
        arrayList.add(new com.google.android.exoplayer2.metadata.e(this.m, handler.getLooper()));
        arrb = this.l = arrayList.toArray(new c.b[arrayList.size()]);
        int n2 = arrb.length;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        do {
            if (n3 >= n2) {
                this.o = n5;
                this.p = n4;
                this.v = 1.0f;
                this.j = 0;
                this.u = 3;
                this.r = 1;
                this.k = new d(this.l, h2, h3);
                return;
            }
            switch (arrb[n3].a()) {
                case 2: {
                    ++n5;
                }
                default: {
                    break;
                }
                case 1: {
                    ++n4;
                }
            }
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void k() {
        if (this.t != null) {
            if (this.t.getSurfaceTextureListener() != this.m) {
                Log.w((String)"SimpleExoPlayer", (String)"SurfaceTextureListener already unset or replaced.");
            } else {
                this.t.setSurfaceTextureListener(null);
            }
            this.t = null;
        }
        if (this.s != null) {
            this.s.removeCallback((SurfaceHolder.Callback)this.m);
            this.s = null;
        }
    }

    @Override
    public final int a() {
        return this.k.a();
    }

    public final void a(float f2) {
        this.v = f2;
        c.c[] arrc = new c.c[this.p];
        c.b[] arrb = this.l;
        int n2 = arrb.length;
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            c.b b2 = arrb[i2];
            if (b2.a() != 1) continue;
            int n4 = n3 + 1;
            arrc[n3] = new c.c(b2, 2, Float.valueOf(f2));
            n3 = n4;
        }
        this.k.a(arrc);
    }

    @Override
    public final void a(int n2) {
        this.k.a(n2);
    }

    @Override
    public final void a(int n2, long l2) {
        this.k.a(n2, l2);
    }

    @Override
    public final void a(long l2) {
        this.k.a(l2);
    }

    /*
     * Enabled aggressive block sorting
     */
    final void a(Surface surface, boolean bl2) {
        c.c[] arrc = new c.c[this.o];
        c.b[] arrb = this.l;
        int n2 = arrb.length;
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            c.b b2 = arrb[i2];
            if (b2.a() != 2) continue;
            int n4 = n3 + 1;
            arrc[n3] = new c.c(b2, 1, (Object)surface);
            n3 = n4;
        }
        if (this.c != null && this.c != surface) {
            if (this.q) {
                this.c.release();
            }
            this.k.b(arrc);
        } else {
            this.k.a(arrc);
        }
        this.c = surface;
        this.q = bl2;
    }

    public final void a(SurfaceView surfaceView) {
        surfaceView = surfaceView.getHolder();
        this.k();
        this.s = surfaceView;
        if (surfaceView == null) {
            this.a(null, false);
            return;
        }
        this.a(surfaceView.getSurface(), false);
        surfaceView.addCallback((SurfaceHolder.Callback)this.m);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(TextureView textureView) {
        SurfaceTexture surfaceTexture;
        Surface surface = null;
        this.k();
        this.t = textureView;
        if (textureView == null) {
            this.a(null, true);
            return;
        }
        if (textureView.getSurfaceTextureListener() != null) {
            Log.w((String)"SimpleExoPlayer", (String)"Replacing existing SurfaceTextureListener.");
        }
        if ((surfaceTexture = textureView.getSurfaceTexture()) != null) {
            surface = new Surface(surfaceTexture);
        }
        this.a(surface, true);
        textureView.setSurfaceTextureListener((TextureView.SurfaceTextureListener)this.m);
    }

    @Override
    public final void a(c.a a2) {
        this.k.a(a2);
    }

    @Override
    public final void a(com.google.android.exoplayer2.e.b b2, boolean bl2, boolean bl3) {
        this.k.a(b2, bl2, bl3);
    }

    public final void a(k.a a2) {
        this.d = a2;
    }

    public final void a(b b2) {
        this.e = b2;
    }

    @Override
    public final void a(boolean bl2) {
        this.k.a(bl2);
    }

    @Override
    public final /* varargs */ void a(c.c ... arrc) {
        this.k.a(arrc);
    }

    @Override
    public final void b(c.a a2) {
        this.k.b(a2);
    }

    @Override
    public final /* varargs */ void b(c.c ... arrc) {
        this.k.b(arrc);
    }

    @Override
    public final boolean b() {
        return this.k.b();
    }

    @Override
    public final void c() {
        this.k.c();
    }

    @Override
    public final void d() {
        this.k.d();
        this.k();
        if (this.c != null) {
            if (this.q) {
                this.c.release();
            }
            this.c = null;
        }
    }

    @Override
    public final n e() {
        return this.k.e();
    }

    @Override
    public final int f() {
        return this.k.f();
    }

    @Override
    public final long g() {
        return this.k.g();
    }

    @Override
    public final long h() {
        return this.k.h();
    }

    @Override
    public final long i() {
        return this.k.i();
    }

    public final void j() {
        this.k();
        this.a(null, false);
    }

    final class a
    implements f.a,
    SurfaceHolder.Callback,
    TextureView.SurfaceTextureListener,
    com.google.android.exoplayer2.a.c,
    k.a,
    e {
        private a() {
        }

        /* synthetic */ a(byte by2) {
            this();
        }

        @Override
        public final void a(int n2) {
            m.this.j = n2;
            if (m.this.f != null) {
                m.this.f.a(n2);
            }
        }

        @Override
        public final void a(int n2, int n3, int n4, float f2) {
            if (m.this.e != null) {
                m.this.e.a(n2, n3, n4, f2);
            }
            if (m.this.g != null) {
                m.this.g.a(n2, n3, n4, f2);
            }
        }

        @Override
        public final void a(Surface surface) {
            if (m.this.e != null && m.this.c == surface) {
                m.this.e.d();
            }
            if (m.this.g != null) {
                m.this.g.a(surface);
            }
        }

        @Override
        public final void a(Format format) {
            m.this.a = format;
            if (m.this.g != null) {
                m.this.g.a(format);
            }
        }

        @Override
        public final void a(com.google.android.exoplayer2.b.d d2) {
            m.this.h = d2;
            if (m.this.g != null) {
                m.this.g.a(d2);
            }
        }

        @Override
        public final void a(List<com.google.android.exoplayer2.f.b> list) {
            if (m.this.d != null) {
                m.this.d.a(list);
            }
        }

        @Override
        public final void b(Format format) {
            m.this.b = format;
            if (m.this.f != null) {
                m.this.f.b(format);
            }
        }

        @Override
        public final void b(com.google.android.exoplayer2.b.d d2) {
            if (m.this.g != null) {
                m.this.g.b(d2);
            }
            m.this.a = null;
            m.this.h = null;
        }

        @Override
        public final void c(com.google.android.exoplayer2.b.d d2) {
            m.this.i = d2;
            if (m.this.f != null) {
                m.this.f.c(d2);
            }
        }

        @Override
        public final void d(com.google.android.exoplayer2.b.d d2) {
            if (m.this.f != null) {
                m.this.f.d(d2);
            }
            m.this.b = null;
            m.this.i = null;
            m.this.j = 0;
        }

        public final void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int n2, int n3) {
            m.this.a(new Surface(surfaceTexture), true);
        }

        public final boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            m.this.a(null, true);
            return true;
        }

        public final void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int n2, int n3) {
        }

        public final void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        }

        public final void surfaceChanged(SurfaceHolder surfaceHolder, int n2, int n3, int n4) {
        }

        public final void surfaceCreated(SurfaceHolder surfaceHolder) {
            m.this.a(surfaceHolder.getSurface(), false);
        }

        public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            m.this.a(null, false);
        }
    }

    public static interface b {
        public void a(int var1, int var2, int var3, float var4);

        public void d();
    }

}

