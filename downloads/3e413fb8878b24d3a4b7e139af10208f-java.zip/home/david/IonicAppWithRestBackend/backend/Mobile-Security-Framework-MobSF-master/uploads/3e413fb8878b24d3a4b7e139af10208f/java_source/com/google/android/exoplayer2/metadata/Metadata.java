/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;
import java.util.List;

public final class Metadata
implements Parcelable {
    public static final Parcelable.Creator<Metadata> CREATOR = new Parcelable.Creator<Metadata>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new Metadata(parcel);
        }
    };
    public final Entry[] a;

    Metadata(Parcel parcel) {
        this.a = new Entry[parcel.readInt()];
        for (int i2 = 0; i2 < this.a.length; ++i2) {
            this.a[i2] = (Entry)parcel.readParcelable(Entry.class.getClassLoader());
        }
    }

    public Metadata(List<? extends Entry> list) {
        this.a = new Entry[list.size()];
        list.toArray(this.a);
    }

    public /* varargs */ Metadata(Entry ... arrentry) {
        this.a = arrentry;
    }

    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        object = (Metadata)object;
        return Arrays.equals(this.a, object.a);
    }

    public final int hashCode() {
        return Arrays.hashCode(this.a);
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeInt(this.a.length);
        Entry[] arrentry = this.a;
        int n3 = arrentry.length;
        for (n2 = 0; n2 < n3; ++n2) {
            parcel.writeParcelable((Parcelable)arrentry[n2], 0);
        }
    }

    public static interface Entry
    extends Parcelable {
    }

}

