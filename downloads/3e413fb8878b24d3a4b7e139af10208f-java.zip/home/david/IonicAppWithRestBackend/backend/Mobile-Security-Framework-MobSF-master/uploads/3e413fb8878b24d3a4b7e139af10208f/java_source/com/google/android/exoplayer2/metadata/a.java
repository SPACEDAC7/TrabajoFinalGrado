/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.metadata;

import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.d;

public interface a {
    public Metadata a(d var1);
}

