/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.metadata;

import com.google.android.exoplayer2.b.e;

public final class d
extends e {
    public long e;

    public d() {
        super(1);
    }
}

