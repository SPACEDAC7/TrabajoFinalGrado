/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.Looper
 *  android.os.Message
 */
package com.google.android.exoplayer2.metadata;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.design.widget.f;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.b;
import com.google.android.exoplayer2.f;
import com.google.android.exoplayer2.k;
import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.a;
import com.google.android.exoplayer2.metadata.c;
import com.google.android.exoplayer2.metadata.d;

public final class e
extends k
implements Handler.Callback {
    private final c i;
    private final f.a j;
    private final Handler k;
    private final f l;
    private final d m;
    private a n;
    private boolean o;
    private long p;
    private Metadata q;

    public e(f.a a2, Looper looper) {
        this(a2, looper, c.a);
    }

    /*
     * Enabled aggressive block sorting
     */
    private e(f.a a2, Looper looper, c c2) {
        super(4);
        this.j = a.a.a.a.d.b(a2);
        a2 = looper == null ? null : new Handler(looper, (Handler.Callback)this);
        this.k = a2;
        this.i = a.a.a.a.d.b(c2);
        this.l = new f();
        this.m = new d();
    }

    @Override
    public final int a(Format format) {
        if (this.i.a(format)) {
            return 3;
        }
        return 0;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final void a(long l2, long l3) {
        if (!this.o && this.q == null) {
            this.m.a();
            if (this.a(this.l, this.m) == -4) {
                if (this.m.c()) {
                    this.o = true;
                } else if (!this.m.c_()) {
                    this.p = this.m.d;
                    this.m.e = this.l.a.v;
                    this.m.f();
                    this.q = this.n.a(this.m);
                }
            }
        }
        if (this.q == null) return;
        if (this.p > l2) return;
        Metadata metadata = this.q;
        if (this.k != null) {
            this.k.obtainMessage(0, (Object)metadata).sendToTarget();
        }
        this.q = null;
        return;
        catch (com.google.android.exoplayer2.metadata.b b2) {
            throw b.a(b2, this.c);
        }
    }

    @Override
    protected final void a(long l2, boolean bl2) {
        this.q = null;
        this.o = false;
    }

    @Override
    protected final void a(Format[] arrformat) {
        this.n = this.i.b(arrformat[0]);
    }

    public final boolean handleMessage(Message object) {
        switch (object.what) {
            default: {
                return false;
            }
            case 0: 
        }
        object = object.obj;
        return true;
    }

    @Override
    public final boolean k() {
        return true;
    }

    @Override
    public final boolean l() {
        return this.o;
    }

    @Override
    protected final void r() {
        this.q = null;
        this.n = null;
        super.r();
    }
}

