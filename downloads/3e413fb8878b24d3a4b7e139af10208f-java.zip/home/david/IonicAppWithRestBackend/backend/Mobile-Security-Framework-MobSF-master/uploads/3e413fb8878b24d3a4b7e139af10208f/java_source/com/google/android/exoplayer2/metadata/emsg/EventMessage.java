/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.emsg;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.Metadata;
import java.util.Arrays;

public final class EventMessage
implements Metadata.Entry {
    public static final Parcelable.Creator<EventMessage> CREATOR = new Parcelable.Creator<EventMessage>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new EventMessage(parcel);
        }
    };
    public final String a;
    public final String b;
    public final long c;
    public final long d;
    public final byte[] e;
    private int f;

    EventMessage(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readLong();
        this.d = parcel.readLong();
        this.e = parcel.createByteArray();
    }

    public EventMessage(String string, String string2, long l2, long l3, byte[] arrby) {
        this.a = string;
        this.b = string2;
        this.c = l2;
        this.d = l3;
        this.e = arrby;
    }

    public final int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (EventMessage)object;
        if (this.c != object.c) return false;
        if (this.d != object.d) return false;
        if (!o.a(this.a, object.a)) return false;
        if (!o.a(this.b, object.b)) return false;
        if (Arrays.equals(this.e, object.e)) return true;
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int hashCode() {
        int n2 = 0;
        if (this.f != 0) return this.f;
        int n3 = this.a != null ? this.a.hashCode() : 0;
        if (this.b != null) {
            n2 = this.b.hashCode();
        }
        this.f = ((((n3 + 527) * 31 + n2) * 31 + (int)(this.c ^ this.c >>> 32)) * 31 + (int)(this.d ^ this.d >>> 32)) * 31 + Arrays.hashCode(this.e);
        return this.f;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeLong(this.c);
        parcel.writeLong(this.d);
        parcel.writeByteArray(this.e);
    }

}

