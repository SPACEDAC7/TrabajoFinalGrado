/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.metadata.emsg;

import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.d;
import com.google.android.exoplayer2.metadata.emsg.EventMessage;
import java.nio.ByteBuffer;
import java.util.Arrays;

public final class a
implements com.google.android.exoplayer2.metadata.a {
    @Override
    public final Metadata a(d arrby) {
        Object object = arrby.c;
        arrby = object.array();
        int n2 = object.limit();
        object = new i(arrby, n2);
        String string = object.r();
        String string2 = object.r();
        long l2 = object.i();
        object.d(4);
        return new Metadata(new EventMessage(string, string2, object.i() * 1000 / l2, object.i(), Arrays.copyOfRange(arrby, object.b, n2)));
    }
}

