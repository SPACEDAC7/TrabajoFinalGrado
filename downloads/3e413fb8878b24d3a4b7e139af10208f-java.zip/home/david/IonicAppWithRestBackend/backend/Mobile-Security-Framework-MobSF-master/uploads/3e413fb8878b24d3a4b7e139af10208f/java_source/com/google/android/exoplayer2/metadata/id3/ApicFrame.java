/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.id3;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.id3.Id3Frame;
import java.util.Arrays;

public final class ApicFrame
extends Id3Frame {
    public static final Parcelable.Creator<ApicFrame> CREATOR = new Parcelable.Creator<ApicFrame>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ApicFrame(parcel);
        }
    };
    public final String a;
    public final String b;
    public final int c;
    public final byte[] d;

    ApicFrame(Parcel parcel) {
        super("APIC");
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readInt();
        this.d = parcel.createByteArray();
    }

    public ApicFrame(String string, String string2, int n2, byte[] arrby) {
        super("APIC");
        this.a = string;
        this.b = string2;
        this.c = n2;
        this.d = arrby;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (ApicFrame)object;
        if (this.c != object.c) return false;
        if (!o.a(this.a, object.a)) return false;
        if (!o.a(this.b, object.b)) return false;
        if (Arrays.equals(this.d, object.d)) return true;
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int hashCode() {
        int n2 = 0;
        int n3 = this.c;
        int n4 = this.a != null ? this.a.hashCode() : 0;
        if (this.b != null) {
            n2 = this.b.hashCode();
        }
        return ((n4 + (n3 + 527) * 31) * 31 + n2) * 31 + Arrays.hashCode(this.d);
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeInt(this.c);
        parcel.writeByteArray(this.d);
    }

}

