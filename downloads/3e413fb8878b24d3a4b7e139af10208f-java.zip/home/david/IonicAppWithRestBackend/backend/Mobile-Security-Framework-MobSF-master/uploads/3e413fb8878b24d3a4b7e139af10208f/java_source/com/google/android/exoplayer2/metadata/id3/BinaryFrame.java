/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.id3;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.metadata.id3.Id3Frame;
import java.util.Arrays;

public final class BinaryFrame
extends Id3Frame {
    public static final Parcelable.Creator<BinaryFrame> CREATOR = new Parcelable.Creator<BinaryFrame>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new BinaryFrame(parcel);
        }
    };
    public final byte[] a;

    BinaryFrame(Parcel parcel) {
        super(parcel.readString());
        this.a = parcel.createByteArray();
    }

    public BinaryFrame(String string, byte[] arrby) {
        super(string);
        this.a = arrby;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (BinaryFrame)object;
        if (!this.f.equals(object.f)) return false;
        if (Arrays.equals(this.a, object.a)) return true;
        return false;
    }

    public final int hashCode() {
        return (this.f.hashCode() + 527) * 31 + Arrays.hashCode(this.a);
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.f);
        parcel.writeByteArray(this.a);
    }

}

