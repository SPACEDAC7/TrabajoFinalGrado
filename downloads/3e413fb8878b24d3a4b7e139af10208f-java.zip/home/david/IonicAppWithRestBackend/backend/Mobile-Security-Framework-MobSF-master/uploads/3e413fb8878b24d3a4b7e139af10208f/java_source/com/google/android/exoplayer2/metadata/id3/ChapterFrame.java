/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.id3;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.id3.Id3Frame;
import java.util.Arrays;

public final class ChapterFrame
extends Id3Frame {
    public static final Parcelable.Creator<ChapterFrame> CREATOR = new Parcelable.Creator<ChapterFrame>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ChapterFrame(parcel);
        }
    };
    public final String a;
    public final int b;
    public final int c;
    public final long d;
    public final long e;
    private final Id3Frame[] g;

    ChapterFrame(Parcel parcel) {
        super("CHAP");
        this.a = parcel.readString();
        this.b = parcel.readInt();
        this.c = parcel.readInt();
        this.d = parcel.readLong();
        this.e = parcel.readLong();
        int n2 = parcel.readInt();
        this.g = new Id3Frame[n2];
        for (int i2 = 0; i2 < n2; ++i2) {
            this.g[i2] = (Id3Frame)parcel.readParcelable(Id3Frame.class.getClassLoader());
        }
    }

    public ChapterFrame(String string, int n2, int n3, long l2, long l3, Id3Frame[] arrid3Frame) {
        super("CHAP");
        this.a = string;
        this.b = n2;
        this.c = n3;
        this.d = l2;
        this.e = l3;
        this.g = arrid3Frame;
    }

    @Override
    public final int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (ChapterFrame)object;
        if (this.b != object.b) return false;
        if (this.c != object.c) return false;
        if (this.d != object.d) return false;
        if (this.e != object.e) return false;
        if (!o.a(this.a, object.a)) return false;
        if (Arrays.equals(this.g, object.g)) return true;
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final int hashCode() {
        int n2;
        int n3 = this.b;
        int n4 = this.c;
        int n5 = (int)this.d;
        int n6 = (int)this.e;
        if (this.a != null) {
            n2 = this.a.hashCode();
            do {
                return n2 + ((((n3 + 527) * 31 + n4) * 31 + n5) * 31 + n6) * 31;
                break;
            } while (true);
        }
        n2 = 0;
        return n2 + ((((n3 + 527) * 31 + n4) * 31 + n5) * 31 + n6) * 31;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.a);
        parcel.writeInt(this.b);
        parcel.writeInt(this.c);
        parcel.writeLong(this.d);
        parcel.writeLong(this.e);
        parcel.writeInt(this.g.length);
        Id3Frame[] arrid3Frame = this.g;
        int n3 = arrid3Frame.length;
        for (n2 = 0; n2 < n3; ++n2) {
            parcel.writeParcelable((Parcelable)arrid3Frame[n2], 0);
        }
    }

}

