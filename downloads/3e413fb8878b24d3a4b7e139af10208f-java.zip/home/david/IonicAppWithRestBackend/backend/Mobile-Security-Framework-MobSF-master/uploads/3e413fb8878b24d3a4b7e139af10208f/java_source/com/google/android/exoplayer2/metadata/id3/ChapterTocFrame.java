/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.id3;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.id3.Id3Frame;
import java.util.Arrays;

public final class ChapterTocFrame
extends Id3Frame {
    public static final Parcelable.Creator<ChapterTocFrame> CREATOR = new Parcelable.Creator<ChapterTocFrame>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ChapterTocFrame(parcel);
        }
    };
    public final String a;
    public final boolean b;
    public final boolean c;
    public final String[] d;
    private final Id3Frame[] e;

    /*
     * Enabled aggressive block sorting
     */
    ChapterTocFrame(Parcel parcel) {
        boolean bl2 = true;
        int n2 = 0;
        super("CTOC");
        this.a = parcel.readString();
        boolean bl3 = parcel.readByte() != 0;
        this.b = bl3;
        bl3 = parcel.readByte() != 0 ? bl2 : false;
        this.c = bl3;
        this.d = parcel.createStringArray();
        int n3 = parcel.readInt();
        this.e = new Id3Frame[n3];
        while (n2 < n3) {
            this.e[n2] = (Id3Frame)parcel.readParcelable(Id3Frame.class.getClassLoader());
            ++n2;
        }
        return;
    }

    public ChapterTocFrame(String string, boolean bl2, boolean bl3, String[] arrstring, Id3Frame[] arrid3Frame) {
        super("CTOC");
        this.a = string;
        this.b = bl2;
        this.c = bl3;
        this.d = arrstring;
        this.e = arrid3Frame;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (ChapterTocFrame)object;
        if (this.b != object.b) return false;
        if (this.c != object.c) return false;
        if (!o.a(this.a, object.a)) return false;
        if (!Arrays.equals(this.d, object.d)) return false;
        if (Arrays.equals(this.e, object.e)) return true;
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int hashCode() {
        int n2 = 1;
        int n3 = 0;
        int n4 = this.b ? 1 : 0;
        if (!this.c) {
            n2 = 0;
        }
        if (this.a != null) {
            n3 = this.a.hashCode();
        }
        return ((n4 + 527) * 31 + n2) * 31 + n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void writeToParcel(Parcel parcel, int n2) {
        int n3 = 1;
        parcel.writeString(this.a);
        n2 = this.b ? 1 : 0;
        parcel.writeByte((byte)n2);
        n2 = this.c ? n3 : 0;
        parcel.writeByte((byte)n2);
        parcel.writeStringArray(this.d);
        parcel.writeInt(this.e.length);
        n2 = 0;
        while (n2 < this.e.length) {
            parcel.writeParcelable((Parcelable)this.e[n2], 0);
            ++n2;
        }
    }

}

