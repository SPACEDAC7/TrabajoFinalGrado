/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.metadata.id3;

import a.a.a.a.d;
import com.google.android.exoplayer2.metadata.Metadata;

public abstract class Id3Frame
implements Metadata.Entry {
    public final String f;

    public Id3Frame(String string) {
        this.f = d.b(string);
    }

    public int describeContents() {
        return 0;
    }
}

