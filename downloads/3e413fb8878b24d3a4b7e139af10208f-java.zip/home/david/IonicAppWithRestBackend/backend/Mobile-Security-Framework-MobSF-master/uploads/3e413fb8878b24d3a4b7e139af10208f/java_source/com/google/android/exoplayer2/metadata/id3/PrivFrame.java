/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.id3;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.id3.Id3Frame;
import java.util.Arrays;

public final class PrivFrame
extends Id3Frame {
    public static final Parcelable.Creator<PrivFrame> CREATOR = new Parcelable.Creator<PrivFrame>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new PrivFrame(parcel);
        }
    };
    public final String a;
    public final byte[] b;

    PrivFrame(Parcel parcel) {
        super("PRIV");
        this.a = parcel.readString();
        this.b = parcel.createByteArray();
    }

    public PrivFrame(String string, byte[] arrby) {
        super("PRIV");
        this.a = string;
        this.b = arrby;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (PrivFrame)object;
        if (!o.a(this.a, object.a)) return false;
        if (Arrays.equals(this.b, object.b)) return true;
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final int hashCode() {
        int n2;
        if (this.a != null) {
            n2 = this.a.hashCode();
            do {
                return (n2 + 527) * 31 + Arrays.hashCode(this.b);
                break;
            } while (true);
        }
        n2 = 0;
        return (n2 + 527) * 31 + Arrays.hashCode(this.b);
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.a);
        parcel.writeByteArray(this.b);
    }

}

