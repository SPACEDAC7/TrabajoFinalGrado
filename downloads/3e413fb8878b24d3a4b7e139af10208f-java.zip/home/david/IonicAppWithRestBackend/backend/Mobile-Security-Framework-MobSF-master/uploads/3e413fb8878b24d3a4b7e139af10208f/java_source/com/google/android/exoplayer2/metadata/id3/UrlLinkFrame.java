/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.id3;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.id3.Id3Frame;

public final class UrlLinkFrame
extends Id3Frame {
    public static final Parcelable.Creator<UrlLinkFrame> CREATOR = new Parcelable.Creator<UrlLinkFrame>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new UrlLinkFrame(parcel);
        }
    };
    public final String a;
    public final String b;

    UrlLinkFrame(Parcel parcel) {
        super(parcel.readString());
        this.a = parcel.readString();
        this.b = parcel.readString();
    }

    public UrlLinkFrame(String string, String string2, String string3) {
        super(string);
        this.a = string2;
        this.b = string3;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (UrlLinkFrame)object;
        if (!this.f.equals(object.f)) return false;
        if (!o.a(this.a, object.a)) return false;
        if (o.a(this.b, object.b)) return true;
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int hashCode() {
        int n2 = 0;
        int n3 = this.f.hashCode();
        int n4 = this.a != null ? this.a.hashCode() : 0;
        if (this.b != null) {
            n2 = this.b.hashCode();
        }
        return (n4 + (n3 + 527) * 31) * 31 + n2;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.f);
        parcel.writeString(this.a);
        parcel.writeString(this.b);
    }

}

