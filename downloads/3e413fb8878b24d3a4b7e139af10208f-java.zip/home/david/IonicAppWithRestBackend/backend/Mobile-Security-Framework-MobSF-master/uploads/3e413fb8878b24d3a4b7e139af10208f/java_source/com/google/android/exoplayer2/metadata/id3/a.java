/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.google.android.exoplayer2.metadata.id3;

import android.util.Log;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.d;
import com.google.android.exoplayer2.metadata.id3.ApicFrame;
import com.google.android.exoplayer2.metadata.id3.BinaryFrame;
import com.google.android.exoplayer2.metadata.id3.ChapterFrame;
import com.google.android.exoplayer2.metadata.id3.ChapterTocFrame;
import com.google.android.exoplayer2.metadata.id3.CommentFrame;
import com.google.android.exoplayer2.metadata.id3.GeobFrame;
import com.google.android.exoplayer2.metadata.id3.Id3Frame;
import com.google.android.exoplayer2.metadata.id3.PrivFrame;
import com.google.android.exoplayer2.metadata.id3.TextInformationFrame;
import com.google.android.exoplayer2.metadata.id3.UrlLinkFrame;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public final class a
implements com.google.android.exoplayer2.metadata.a {
    public static final int a = o.e("ID3");

    private static int a(i i2, int n2) {
        byte[] arrby = i2.a;
        int n3 = i2.b;
        int n4 = n2;
        n2 = n3;
        while (n2 + 1 < n4) {
            n3 = n4;
            if ((arrby[n2] & 255) == 255) {
                n3 = n4;
                if (arrby[n2 + 1] == 0) {
                    System.arraycopy(arrby, n2 + 2, arrby, n2 + 1, n4 - n2 - 2);
                    n3 = n4 - 1;
                }
            }
            ++n2;
            n4 = n3;
        }
        return n4;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int a(byte[] var0, int var1_1, int var2_2) {
        var3_3 = a.b(var0, var1_1);
        if (var2_2 == 0) return var3_3;
        var1_1 = var3_3;
        if (var2_2 != 3) ** GOTO lbl7
        return var3_3;
lbl-1000: // 1 sources:
        {
            var1_1 = a.b(var0, var1_1 + 1);
lbl7: // 2 sources:
            if (var1_1 >= var0.length - 1) return var0.length;
            ** while (var1_1 % 2 != 0 || var0[var1_1 + 1] != 0)
        }
lbl9: // 1 sources:
        return var1_1;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Metadata a(byte[] object, int n2) {
        boolean bl2;
        int n3;
        boolean bl3 = false;
        ArrayList<Id3Frame> arrayList = new ArrayList<Id3Frame>();
        i i2 = new i((byte[])object, n2);
        if (i2.b() < 10) {
            Log.w((String)"Id3Decoder", (String)"Data too short to be an ID3 tag");
            return null;
        }
        n2 = i2.h();
        if (n2 != a) {
            Log.w((String)"Id3Decoder", (String)("Unexpected first three bytes of ID3 tag header: " + n2));
            return null;
        }
        int n4 = i2.e();
        i2.d(1);
        int n5 = i2.e();
        n2 = i2.n();
        if (n4 == 2) {
            n3 = (n5 & 64) != 0 ? 1 : 0;
            if (n3 != 0) {
                Log.w((String)"Id3Decoder", (String)"Skipped ID3 tag with majorVersion=2 and undefined compression scheme");
                return null;
            }
        } else if (n4 == 3) {
            bl2 = (n5 & 64) != 0;
            n3 = n2;
            if (bl2) {
                n3 = i2.k();
                i2.d(n3);
                n3 = n2 - (n3 + 4);
            }
            n2 = n3;
        } else {
            if (n4 != 4) {
                Log.w((String)"Id3Decoder", (String)("Skipped ID3 tag with unsupported majorVersion=" + n4));
                return null;
            }
            bl2 = (n5 & 64) != 0;
            n3 = n2;
            if (bl2) {
                n3 = i2.n();
                i2.d(n3 - 4);
                n3 = n2 - n3;
            }
            bl2 = (n5 & 16) != 0;
            n2 = n3;
            if (bl2) {
                n2 = n3 - 10;
            }
        }
        boolean bl4 = n4 < 4 && (n5 & 128) != 0;
        object = new a(n4, bl4, n2);
        if (object == null) {
            return null;
        }
        n3 = i2.b;
        n2 = object.c;
        if (object.b) {
            n2 = a.a(i2, object.c);
        }
        i2.b(n2 + n3);
        bl4 = bl3;
        if (object.a == 4) {
            bl4 = bl3;
            if (!a.a(i2, false)) {
                if (!a.a(i2, true)) {
                    Log.w((String)"Id3Decoder", (String)"Failed to validate V4 ID3 tag");
                    return null;
                }
                bl4 = true;
            }
        }
        n2 = object.a == 2 ? 6 : 10;
        while (i2.b() >= n2) {
            Id3Frame id3Frame = a.a(object.a, i2, bl4, n2);
            if (id3Frame == null) continue;
            arrayList.add(id3Frame);
        }
        return new Metadata(arrayList);
    }

    private static ChapterFrame a(i arrid3Frame, int n2, int n3, boolean bl2, int n4) {
        long l2;
        long l3;
        int n5 = arrid3Frame.b;
        int n6 = a.b(arrid3Frame.a, n5);
        String string = new String(arrid3Frame.a, n5, n6 - n5, "ISO-8859-1");
        arrid3Frame.c(n6 + 1);
        n6 = arrid3Frame.k();
        int n7 = arrid3Frame.k();
        long l4 = l2 = arrid3Frame.i();
        if (l2 == 0xFFFFFFFFL) {
            l4 = -1;
        }
        l2 = l3 = arrid3Frame.i();
        if (l3 == 0xFFFFFFFFL) {
            l2 = -1;
        }
        ArrayList<Id3Frame> arrayList = new ArrayList<Id3Frame>();
        while (arrid3Frame.b < n5 + n2) {
            Id3Frame id3Frame = a.a(n3, (i)arrid3Frame, bl2, n4);
            if (id3Frame == null) continue;
            arrayList.add(id3Frame);
        }
        arrid3Frame = new Id3Frame[arrayList.size()];
        arrayList.toArray(arrid3Frame);
        return new ChapterFrame(string, n6, n7, l4, l2, arrid3Frame);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Id3Frame a(int var0, i var1_1, boolean var2_2, int var3_3) {
        block32 : {
            var17_4 = var1_1.e();
            var18_5 = var1_1.e();
            var19_6 = var1_1.e();
            var14_7 = var0 >= 3 ? var1_1.e() : 0;
            if (var0 == 4) {
                var8_9 = var9_8 = var1_1.o();
                if (!var2_2) {
                    var8_9 = var9_8 & 255 | (var9_8 >> 8 & 255) << 7 | (var9_8 >> 16 & 255) << 14 | var9_8 >>> 24 << 21;
                }
            } else {
                var8_9 = var0 == 3 ? var1_1.o() : var1_1.h();
            }
            var15_10 = var0 >= 3 ? var1_1.f() : 0;
            if (var17_4 == 0 && var18_5 == 0 && var19_6 == 0 && var14_7 == 0 && var8_9 == 0 && var15_10 == 0) {
                var1_1.c(var1_1.c);
                return null;
            }
            var16_11 = var1_1.b + var8_9;
            if (var16_11 > var1_1.c) {
                Log.w((String)"Id3Decoder", (String)"Frame size exceeds remaining tag data");
                var1_1.c(var1_1.c);
                return null;
            }
            var9_8 = 0;
            var13_12 = 0;
            var10_13 = 0;
            if (var0 != 3) ** GOTO lbl33
            var9_8 = (var15_10 & 128) != 0 ? 1 : 0;
            var10_13 = (var15_10 & 64) != 0 ? 1 : 0;
            var11_14 = (var15_10 & 32) != 0 ? 1 : 0;
            var12_15 = var9_8;
            var15_10 = var11_14;
            var11_14 = var12_15;
            var12_15 = var10_13;
            var10_13 = var15_10;
            ** GOTO lbl39
lbl33: // 1 sources:
            if (var0 == 4) {
                var10_13 = (var15_10 & 64) != 0 ? 1 : 0;
                var11_14 = (var15_10 & 8) != 0 ? 1 : 0;
                var12_15 = (var15_10 & 4) != 0 ? 1 : 0;
                var13_12 = (var15_10 & 2) != 0 ? 1 : 0;
                var9_8 = (var15_10 & 1) != 0 ? 1 : 0;
lbl39: // 2 sources:
                var15_10 = var12_15;
                var12_15 = var9_8;
                var9_8 = var11_14;
                var11_14 = var13_12;
            } else {
                var15_10 = 0;
                var11_14 = 0;
                var12_15 = 0;
            }
            if (var9_8 != 0 || var15_10 != 0) {
                Log.w((String)"Id3Decoder", (String)"Skipping unsupported compressed or encrypted frame");
                var1_1.c(var16_11);
                return null;
            }
            if (var10_13 != 0) {
                --var8_9;
                var1_1.d(1);
            }
            var9_8 = var8_9;
            if (var12_15 != 0) {
                var9_8 = var8_9 - 4;
                var1_1.d(4);
            }
            var8_9 = var11_14 != 0 ? a.a(var1_1, var9_8) : var9_8;
            if (var17_4 == 84 && var18_5 == 88 && var19_6 == 88 && (var0 == 2 || var14_7 == 88)) {
                var0 = var1_1.e();
                var4_16 = a.a(var0);
                var6_19 = new byte[var8_9 - 1];
                var1_1.a(var6_19, 0, var8_9 - 1);
                var3_3 = a.a(var6_19, 0, var0);
                var5_24 = new String(var6_19, 0, var3_3, (String)var4_16);
                var4_16 = (var3_3 += a.b(var0)) < var6_19.length ? new String(var6_19, var3_3, a.a(var6_19, var3_3, var0) - var3_3, (String)var4_16) : "";
                return new TextInformationFrame("TXXX", var5_24, (String)var4_16);
            }
            if (var17_4 != 84) ** GOTO lbl88
            if (var0 != 2) ** GOTO lbl75
            var4_16 = String.format(Locale.US, "%c%c%c", new Object[]{var17_4, var18_5, var19_6});
            ** GOTO lbl76
lbl75: // 1 sources:
            var4_16 = String.format(Locale.US, "%c%c%c%c", new Object[]{var17_4, var18_5, var19_6, var14_7});
lbl76: // 2 sources:
            if (var8_9 <= 1) {
                var4_16 = new TextInformationFrame((String)var4_16, null, "");
                return var4_16;
            }
            var0 = var1_1.e();
            var5_25 = a.a(var0);
            var6_20 = new byte[var8_9 - 1];
            var1_1.a(var6_20, 0, var8_9 - 1);
            var4_16 = new TextInformationFrame((String)var4_16, null, new String(var6_20, 0, a.a(var6_20, 0, var0), var5_25));
            return var4_16;
            finally {
                var1_1.c(var16_11);
            }
lbl88: // 1 sources:
            if (var17_4 == 87 && var18_5 == 88 && var19_6 == 88 && (var0 == 2 || var14_7 == 88)) {
                var0 = var1_1.e();
                var5_26 = a.a(var0);
                var4_16 = new byte[var8_9 - 1];
                var1_1.a((byte[])var4_16, 0, var8_9 - 1);
                var3_3 = a.a((byte[])var4_16, 0, var0);
                var5_26 = new String((byte[])var4_16, 0, var3_3, var5_26);
                var0 = var3_3 + a.b(var0);
                var4_16 = var0 < var4_16.length ? new String((byte[])var4_16, var0, a.b((byte[])var4_16, var0) - var0, "ISO-8859-1") : "";
                var4_16 = new UrlLinkFrame("WXXX", var5_26, (String)var4_16);
                return var4_16;
            }
            if (var17_4 != 87) ** GOTO lbl113
            if (var0 != 2) ** GOTO lbl105
            var4_16 = String.format(Locale.US, "%c%c%c", new Object[]{var17_4, var18_5, var19_6});
            ** GOTO lbl106
lbl105: // 1 sources:
            var4_16 = String.format(Locale.US, "%c%c%c%c", new Object[]{var17_4, var18_5, var19_6, var14_7});
lbl106: // 2 sources:
            if (var8_9 == 0) {
                var4_16 = new UrlLinkFrame((String)var4_16, null, "");
                return var4_16;
            }
            var5_27 = new byte[var8_9];
            var1_1.a(var5_27, 0, var8_9);
            var4_16 = new UrlLinkFrame((String)var4_16, null, new String(var5_27, 0, a.b(var5_27, 0), "ISO-8859-1"));
            return var4_16;
lbl113: // 1 sources:
            if (var17_4 != 80 || var18_5 != 82 || var19_6 != 73 || var14_7 != 86) ** GOTO lbl120
            var4_16 = new byte[var8_9];
            var1_1.a((byte[])var4_16, 0, var8_9);
            var0 = a.b((byte[])var4_16, 0);
            var4_16 = new PrivFrame(new String((byte[])var4_16, 0, var0, "ISO-8859-1"), Arrays.copyOfRange((byte[])var4_16, var0 + 1, var4_16.length));
            return var4_16;
lbl120: // 1 sources:
            if (var17_4 != 71 || var18_5 != 69 || var19_6 != 79 || var14_7 != 66 && var0 != 2) ** GOTO lbl135
            var0 = var1_1.e();
            var4_16 = a.a(var0);
            var5_28 = new byte[var8_9 - 1];
            var1_1.a(var5_28, 0, var8_9 - 1);
            var3_3 = a.b(var5_28, 0);
            var6_21 = new String(var5_28, 0, var3_3, "ISO-8859-1");
            ++var3_3;
            var8_9 = a.a(var5_28, var3_3, var0);
            var7_33 = new String(var5_28, var3_3, var8_9 - var3_3, (String)var4_16);
            var3_3 = a.b(var0) + var8_9;
            var8_9 = a.a(var5_28, var3_3, var0);
            var4_16 = new GeobFrame(var6_21, var7_33, new String(var5_28, var3_3, var8_9 - var3_3, (String)var4_16), Arrays.copyOfRange(var5_28, a.b(var0) + var8_9, var5_28.length));
            return var4_16;
lbl135: // 1 sources:
            if (!(var0 == 2 ? var17_4 == 80 && var18_5 == 73 && var19_6 == 67 : var17_4 == 65 && var18_5 == 80 && var19_6 == 73 && var14_7 == 67)) ** GOTO lbl162
            var9_8 = var1_1.e();
            var6_22 = a.a(var9_8);
            var7_34 = new byte[var8_9 - 1];
            var1_1.a(var7_34, 0, var8_9 - 1);
            if (var0 != 2) ** GOTO lbl-1000
            var3_3 = 2;
            var5_29 = "image/" + o.d(new String(var7_34, 0, 3, "ISO-8859-1"));
            var0 = var3_3;
            var4_16 = var5_29;
            if (var5_29.equals("image/jpg")) {
                var4_16 = "image/jpeg";
                var0 = var3_3;
            }
            ** GOTO lbl156
lbl-1000: // 1 sources:
            {
                var3_3 = a.b(var7_34, 0);
                var5_31 = o.d(new String(var7_34, 0, var3_3, "ISO-8859-1"));
                var0 = var3_3;
                var4_16 = var5_31;
                if (var5_31.indexOf(47) == -1) {
                    var4_16 = "image/" + var5_31;
                    var0 = var3_3;
                }
lbl156: // 4 sources:
                var3_3 = var7_34[var0 + 1];
                var0 += 2;
                ** try [egrp 8[TRYBLOCK] [37, 38 : 1497->1753)] { 
lbl159: // 1 sources:
                var8_9 = a.a(var7_34, var0, var9_8);
                var4_16 = new ApicFrame((String)var4_16, new String(var7_34, var0, var8_9 - var0, var6_22), var3_3 & 255, Arrays.copyOfRange(var7_34, a.b(var9_8) + var8_9, var7_34.length));
                return var4_16;
lbl162: // 1 sources:
                if (var17_4 == 67 && var18_5 == 79 && var19_6 == 77 && (var14_7 == 77 || var0 == 2)) {
                    var0 = var1_1.e();
                    var4_16 = a.a(var0);
                    var5_30 = new byte[3];
                    var1_1.a((byte[])var5_30, 0, 3);
                    var5_30 = new String((byte[])var5_30, 0, 3);
                    var7_35 = new byte[var8_9 - 4];
                    var1_1.a(var7_35, 0, var8_9 - 4);
                    var3_3 = a.a(var7_35, 0, var0);
                    var6_23 = new String(var7_35, 0, var3_3, (String)var4_16);
                    var4_16 = (var3_3 += a.b(var0)) < var7_35.length ? new String(var7_35, var3_3, a.a(var7_35, var3_3, var0) - var3_3, (String)var4_16) : "";
                    var4_16 = new CommentFrame((String)var5_30, var6_23, (String)var4_16);
                    return var4_16;
                }
                if (var17_4 != 67 || var18_5 != 72 || var19_6 != 65 || var14_7 != 80) break block32;
            }
            try {
                var4_16 = a.a(var1_1, var8_9, var0, var2_2, var3_3);
                return var4_16;
            }
lbl185: // 9 sources:
            catch (UnsupportedEncodingException var4_17) {
                Log.w((String)"Id3Decoder", (String)"Unsupported character encoding");
                return null;
            }
        }
        if (var17_4 == 67 && var18_5 == 84 && var19_6 == 79 && var14_7 == 67) {
            var4_16 = a.b(var1_1, var8_9, var0, var2_2, var3_3);
            return var4_16;
        }
        var4_16 = var0 == 2 ? String.format(Locale.US, "%c%c%c", new Object[]{var17_4, var18_5, var19_6}) : String.format(Locale.US, "%c%c%c%c", new Object[]{var17_4, var18_5, var19_6, var14_7});
        var5_32 = new byte[var8_9];
        var1_1.a(var5_32, 0, var8_9);
        return new BinaryFrame((String)var4_16, var5_32);
    }

    private static String a(int n2) {
        switch (n2) {
            default: {
                return "ISO-8859-1";
            }
            case 0: {
                return "ISO-8859-1";
            }
            case 1: {
                return "UTF-16";
            }
            case 2: {
                return "UTF-16BE";
            }
            case 3: 
        }
        return "UTF-8";
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static boolean a(i i2, boolean bl2) {
        int n2;
        block9 : {
            int n4;
            int n5;
            int n3;
            n2 = i2.b;
            do {
                if (i2.b() < 10) break block9;
                n5 = i2.k();
                n3 = i2.o();
                n4 = i2.f();
                if (n5 == 0 && n3 == 0 && n4 == 0) {
                    i2.c(n2);
                    return true;
                }
                if (bl2) break block10;
                break;
            } while (true);
            catch (Throwable throwable) {
                i2.c(n2);
                throw throwable;
            }
            {
                block11 : {
                    block10 : {
                        if (((long)n3 & 0x808080) != 0) {
                            i2.c(n2);
                            return false;
                        }
                        n3 = n3 >>> 24 << 21 | (n3 & 255 | (n3 >> 8 & 255) << 7 | (n3 >> 16 & 255) << 14);
                    }
                    n5 = (n4 & 64) != 0 ? 1 : 0;
                    int n6 = n5;
                    if ((n4 & 1) != 0) {
                        n6 = n5 + 4;
                    }
                    if (n3 < n6) {
                        i2.c(n2);
                        return false;
                    }
                    n5 = i2.b();
                    if (n5 >= n3) break block11;
                    i2.c(n2);
                    return false;
                }
                i2.d(n3);
                continue;
            }
        }
        i2.c(n2);
        return true;
    }

    private static int b(int n2) {
        if (n2 == 0 || n2 == 3) {
            return 1;
        }
        return 2;
    }

    private static int b(byte[] arrby, int n2) {
        while (n2 < arrby.length) {
            if (arrby[n2] == 0) {
                return n2;
            }
            ++n2;
        }
        return arrby.length;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static ChapterTocFrame b(i arrid3Frame, int n2, int n3, boolean bl2, int n4) {
        int n5 = arrid3Frame.b;
        int n6 = a.b(arrid3Frame.a, n5);
        String string = new String(arrid3Frame.a, n5, n6 - n5, "ISO-8859-1");
        arrid3Frame.c(n6 + 1);
        n6 = arrid3Frame.e();
        boolean bl3 = (n6 & 2) != 0;
        boolean bl4 = (n6 & 1) != 0;
        int n7 = arrid3Frame.e();
        String[] arrstring = new String[n7];
        for (n6 = 0; n6 < n7; ++n6) {
            int n8 = arrid3Frame.b;
            int n9 = a.b(arrid3Frame.a, n8);
            arrstring[n6] = new String(arrid3Frame.a, n8, n9 - n8, "ISO-8859-1");
            arrid3Frame.c(n9 + 1);
        }
        ArrayList<Id3Frame> arrayList = new ArrayList<Id3Frame>();
        do {
            if (arrid3Frame.b >= n5 + n2) {
                arrid3Frame = new Id3Frame[arrayList.size()];
                arrayList.toArray(arrid3Frame);
                return new ChapterTocFrame(string, bl3, bl4, arrstring, arrid3Frame);
            }
            Id3Frame id3Frame = a.a(n3, (i)arrid3Frame, bl2, n4);
            if (id3Frame == null) continue;
            arrayList.add(id3Frame);
        } while (true);
    }

    @Override
    public final Metadata a(d object) {
        object = object.c;
        return a.a(object.array(), object.limit());
    }

    static final class a {
        final int a;
        final boolean b;
        final int c;

        public a(int n2, boolean bl2, int n3) {
            this.a = n2;
            this.b = bl2;
            this.c = n3;
        }
    }

}

