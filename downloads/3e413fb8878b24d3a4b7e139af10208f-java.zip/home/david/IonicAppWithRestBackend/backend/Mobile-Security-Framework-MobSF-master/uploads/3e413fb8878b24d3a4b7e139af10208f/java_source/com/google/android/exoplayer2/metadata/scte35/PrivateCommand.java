/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.scte35;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.metadata.scte35.SpliceCommand;

public final class PrivateCommand
extends SpliceCommand {
    public static final Parcelable.Creator<PrivateCommand> CREATOR = new Parcelable.Creator<PrivateCommand>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new PrivateCommand(parcel, 0);
        }
    };
    public final long a;
    public final long b;
    public final byte[] c;

    private PrivateCommand(long l2, byte[] arrby, long l3) {
        this.a = l3;
        this.b = l2;
        this.c = arrby;
    }

    private PrivateCommand(Parcel parcel) {
        this.a = parcel.readLong();
        this.b = parcel.readLong();
        this.c = new byte[parcel.readInt()];
        parcel.readByteArray(this.c);
    }

    /* synthetic */ PrivateCommand(Parcel parcel, byte by2) {
        this(parcel);
    }

    static PrivateCommand a(i i2, int n2, long l2) {
        long l3 = i2.i();
        byte[] arrby = new byte[n2 - 4];
        i2.a(arrby, 0, arrby.length);
        return new PrivateCommand(l3, arrby, l2);
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeLong(this.a);
        parcel.writeLong(this.b);
        parcel.writeInt(this.c.length);
        parcel.writeByteArray(this.c);
    }

}

