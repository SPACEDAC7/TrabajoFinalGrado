/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.scte35;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.n;
import com.google.android.exoplayer2.metadata.scte35.SpliceCommand;
import com.google.android.exoplayer2.metadata.scte35.TimeSignalCommand;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class SpliceInsertCommand
extends SpliceCommand {
    public static final Parcelable.Creator<SpliceInsertCommand> CREATOR = new Parcelable.Creator<SpliceInsertCommand>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new SpliceInsertCommand(parcel, 0);
        }
    };
    public final long a;
    public final boolean b;
    public final boolean c;
    public final boolean d;
    public final boolean e;
    public final long f;
    public final long g;
    public final List<a> h;
    public final boolean i;
    public final long j;
    public final int k;
    public final int l;
    public final int m;

    private SpliceInsertCommand(long l2, boolean bl2, boolean bl3, boolean bl4, boolean bl5, long l3, long l4, List<a> list, boolean bl6, long l5, int n2, int n3, int n4) {
        this.a = l2;
        this.b = bl2;
        this.c = bl3;
        this.d = bl4;
        this.e = bl5;
        this.f = l3;
        this.g = l4;
        this.h = Collections.unmodifiableList(list);
        this.i = bl6;
        this.j = l5;
        this.k = n2;
        this.l = n3;
        this.m = n4;
    }

    /*
     * Enabled aggressive block sorting
     */
    private SpliceInsertCommand(Parcel parcel) {
        boolean bl2 = true;
        this.a = parcel.readLong();
        boolean bl3 = parcel.readByte() == 1;
        this.b = bl3;
        bl3 = parcel.readByte() == 1;
        this.c = bl3;
        bl3 = parcel.readByte() == 1;
        this.d = bl3;
        bl3 = parcel.readByte() == 1;
        this.e = bl3;
        this.f = parcel.readLong();
        this.g = parcel.readLong();
        int n2 = parcel.readInt();
        ArrayList<a> arrayList = new ArrayList<a>(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add(new a(parcel.readInt(), parcel.readLong(), parcel.readLong()));
        }
        this.h = Collections.unmodifiableList(arrayList);
        bl3 = parcel.readByte() == 1 ? bl2 : false;
        this.i = bl3;
        this.j = parcel.readLong();
        this.k = parcel.readInt();
        this.l = parcel.readInt();
        this.m = parcel.readInt();
    }

    /* synthetic */ SpliceInsertCommand(Parcel parcel, byte by2) {
        this(parcel);
    }

    /*
     * Enabled aggressive block sorting
     */
    static SpliceInsertCommand a(i i2, long l2, n n2) {
        long l3;
        boolean bl2;
        boolean bl3;
        long l4;
        long l5 = i2.i();
        boolean bl4 = (i2.e() & 128) != 0;
        boolean bl5 = false;
        boolean bl6 = false;
        List<a> list = Collections.emptyList();
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        if (bl4) {
            l2 = -9223372036854775807L;
            bl3 = false;
            l3 = -9223372036854775807L;
            bl2 = false;
            return new SpliceInsertCommand(l5, bl4, bl5, bl6, bl2, l3, n2.a(l3), list, bl3, l2, n3, n4, n5);
        }
        n4 = i2.e();
        bl5 = (n4 & 128) != 0;
        bl6 = (n4 & 64) != 0;
        n3 = (n4 & 32) != 0 ? 1 : 0;
        bl2 = (n4 & 16) != 0;
        l3 = bl6 && !bl2 ? TimeSignalCommand.a(i2, l2) : -9223372036854775807L;
        if (!bl6) {
            n5 = i2.e();
            ArrayList<a> arrayList = new ArrayList<a>(n5);
            n4 = 0;
            do {
                list = arrayList;
                if (n4 >= n5) break;
                int n6 = i2.e();
                l4 = -9223372036854775807L;
                if (!bl2) {
                    l4 = TimeSignalCommand.a(i2, l2);
                }
                arrayList.add(new a(n6, l4, n2.a(l4), 0));
                ++n4;
            } while (true);
        }
        if (n3 != 0) {
            l2 = i2.e();
            bl3 = (128 & l2) != 0;
            l4 = i2.i();
            l2 = (l2 & 1) << 32 | l4;
        } else {
            l2 = -9223372036854775807L;
            bl3 = false;
        }
        n3 = i2.f();
        n4 = i2.e();
        n5 = i2.e();
        return new SpliceInsertCommand(l5, bl4, bl5, bl6, bl2, l3, n2.a(l3), list, bl3, l2, n3, n4, n5);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void writeToParcel(Parcel parcel, int n2) {
        int n3 = 1;
        parcel.writeLong(this.a);
        n2 = this.b ? 1 : 0;
        parcel.writeByte((byte)n2);
        n2 = this.c ? 1 : 0;
        parcel.writeByte((byte)n2);
        n2 = this.d ? 1 : 0;
        parcel.writeByte((byte)n2);
        n2 = this.e ? 1 : 0;
        parcel.writeByte((byte)n2);
        parcel.writeLong(this.f);
        parcel.writeLong(this.g);
        int n4 = this.h.size();
        parcel.writeInt(n4);
        for (n2 = 0; n2 < n4; ++n2) {
            a a2 = this.h.get(n2);
            parcel.writeInt(a2.a);
            parcel.writeLong(a2.b);
            parcel.writeLong(a2.c);
        }
        n2 = this.i ? n3 : 0;
        parcel.writeByte((byte)n2);
        parcel.writeLong(this.j);
        parcel.writeInt(this.k);
        parcel.writeInt(this.l);
        parcel.writeInt(this.m);
    }

    public static final class a {
        public final int a;
        public final long b;
        public final long c;

        a(int n2, long l2, long l3) {
            this.a = n2;
            this.b = l2;
            this.c = l3;
        }

        /* synthetic */ a(int n2, long l2, long l3, byte by2) {
            this(n2, l2, l3);
        }
    }

}

