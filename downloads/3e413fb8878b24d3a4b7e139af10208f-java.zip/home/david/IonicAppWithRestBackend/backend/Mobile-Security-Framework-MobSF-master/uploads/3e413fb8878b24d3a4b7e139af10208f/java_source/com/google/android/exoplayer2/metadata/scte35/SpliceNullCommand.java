/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.scte35;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.metadata.scte35.SpliceCommand;

public final class SpliceNullCommand
extends SpliceCommand {
    public static final Parcelable.Creator<SpliceNullCommand> CREATOR = new Parcelable.Creator<SpliceNullCommand>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new SpliceNullCommand();
        }
    };

    public final void writeToParcel(Parcel parcel, int n2) {
    }

}

