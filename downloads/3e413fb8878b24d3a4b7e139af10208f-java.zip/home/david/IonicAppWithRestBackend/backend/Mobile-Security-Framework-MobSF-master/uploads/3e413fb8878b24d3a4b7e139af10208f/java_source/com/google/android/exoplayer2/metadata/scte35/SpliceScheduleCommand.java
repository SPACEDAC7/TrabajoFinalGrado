/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.scte35;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.metadata.scte35.SpliceCommand;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class SpliceScheduleCommand
extends SpliceCommand {
    public static final Parcelable.Creator<SpliceScheduleCommand> CREATOR = new Parcelable.Creator<SpliceScheduleCommand>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new SpliceScheduleCommand(parcel, 0);
        }
    };
    public final List<b> a;

    private SpliceScheduleCommand(Parcel parcel) {
        int n2 = parcel.readInt();
        ArrayList<b> arrayList = new ArrayList<b>(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add(new b(parcel));
        }
        this.a = Collections.unmodifiableList(arrayList);
    }

    /* synthetic */ SpliceScheduleCommand(Parcel parcel, byte by2) {
        this(parcel);
    }

    private SpliceScheduleCommand(List<b> list) {
        this.a = Collections.unmodifiableList(list);
    }

    static SpliceScheduleCommand a(i i2) {
        int n2 = i2.e();
        ArrayList<b> arrayList = new ArrayList<b>(n2);
        for (int i3 = 0; i3 < n2; ++i3) {
            arrayList.add(b.a(i2));
        }
        return new SpliceScheduleCommand(arrayList);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void writeToParcel(Parcel parcel, int n2) {
        int n3 = this.a.size();
        parcel.writeInt(n3);
        n2 = 0;
        while (n2 < n3) {
            b b2 = this.a.get(n2);
            parcel.writeLong(b2.a);
            int n4 = b2.b ? 1 : 0;
            parcel.writeByte((byte)n4);
            n4 = b2.c ? 1 : 0;
            parcel.writeByte((byte)n4);
            n4 = b2.d ? 1 : 0;
            parcel.writeByte((byte)n4);
            int n5 = b2.f.size();
            parcel.writeInt(n5);
            for (n4 = 0; n4 < n5; ++n4) {
                a a2 = b2.f.get(n4);
                parcel.writeInt(a2.a);
                parcel.writeLong(a2.b);
            }
            parcel.writeLong(b2.e);
            n4 = b2.g ? 1 : 0;
            parcel.writeByte((byte)n4);
            parcel.writeLong(b2.h);
            parcel.writeInt(b2.i);
            parcel.writeInt(b2.j);
            parcel.writeInt(b2.k);
            ++n2;
        }
    }

    public static final class a {
        public final int a;
        public final long b;

        a(int n2, long l2) {
            this.a = n2;
            this.b = l2;
        }

        /* synthetic */ a(int n2, long l2, byte by2) {
            this(n2, l2);
        }
    }

    public static final class b {
        public final long a;
        public final boolean b;
        public final boolean c;
        public final boolean d;
        public final long e;
        public final List<a> f;
        public final boolean g;
        public final long h;
        public final int i;
        public final int j;
        public final int k;

        private b(long l2, boolean bl2, boolean bl3, boolean bl4, List<a> list, long l3, boolean bl5, long l4, int n2, int n3, int n4) {
            this.a = l2;
            this.b = bl2;
            this.c = bl3;
            this.d = bl4;
            this.f = Collections.unmodifiableList(list);
            this.e = l3;
            this.g = bl5;
            this.h = l4;
            this.i = n2;
            this.j = n3;
            this.k = n4;
        }

        /*
         * Enabled aggressive block sorting
         */
        b(Parcel parcel) {
            boolean bl2 = true;
            this.a = parcel.readLong();
            boolean bl3 = parcel.readByte() == 1;
            this.b = bl3;
            bl3 = parcel.readByte() == 1;
            this.c = bl3;
            bl3 = parcel.readByte() == 1;
            this.d = bl3;
            int n2 = parcel.readInt();
            ArrayList<a> arrayList = new ArrayList<a>(n2);
            for (int i2 = 0; i2 < n2; ++i2) {
                arrayList.add(new a(parcel.readInt(), parcel.readLong()));
            }
            this.f = Collections.unmodifiableList(arrayList);
            this.e = parcel.readLong();
            bl3 = parcel.readByte() == 1 ? bl2 : false;
            this.g = bl3;
            this.h = parcel.readLong();
            this.i = parcel.readInt();
            this.j = parcel.readInt();
            this.k = parcel.readInt();
        }

        /*
         * Enabled aggressive block sorting
         */
        static b a(i i2) {
            boolean bl2;
            void var1_6;
            long l2 = i2.i();
            boolean bl3 = (i2.e() & 128) != 0;
            boolean bl4 = false;
            long l3 = -9223372036854775807L;
            ArrayList arrayList = new ArrayList();
            int n2 = 0;
            int n3 = 0;
            int n4 = 0;
            boolean bl5 = false;
            long l4 = -9223372036854775807L;
            if (bl3) {
                l4 = -9223372036854775807L;
                bl2 = false;
                bl5 = false;
                return new b(l2, bl3, bl2, bl4, (List<a>)var1_6, l3, bl5, l4, n2, n3, n4);
            }
            n2 = i2.e();
            bl2 = (n2 & 128) != 0;
            bl4 = (n2 & 64) != 0;
            n2 = (n2 & 32) != 0 ? 1 : 0;
            l3 = bl4 ? i2.i() : -9223372036854775807L;
            if (!bl4) {
                n4 = i2.e();
                ArrayList<a> arrayList2 = new ArrayList<a>(n4);
                n3 = 0;
                do {
                    ArrayList<a> arrayList3 = arrayList2;
                    if (n3 >= n4) break;
                    arrayList2.add(new a(i2.e(), i2.i(), 0));
                    ++n3;
                } while (true);
            }
            if (n2 != 0) {
                l4 = i2.e();
                bl5 = (128 & l4) != 0;
                long l5 = i2.i();
                l4 = (l4 & 1) << 32 | l5;
            }
            n2 = i2.f();
            n3 = i2.e();
            n4 = i2.e();
            return new b(l2, bl3, bl2, bl4, (List<a>)var1_6, l3, bl5, l4, n2, n3, n4);
        }
    }

}

