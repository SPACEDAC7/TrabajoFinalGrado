/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.exoplayer2.metadata.scte35;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.n;
import com.google.android.exoplayer2.metadata.scte35.SpliceCommand;

public final class TimeSignalCommand
extends SpliceCommand {
    public static final Parcelable.Creator<TimeSignalCommand> CREATOR = new Parcelable.Creator<TimeSignalCommand>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new TimeSignalCommand(parcel.readLong(), parcel.readLong(), 0);
        }
    };
    public final long a;
    public final long b;

    private TimeSignalCommand(long l2, long l3) {
        this.a = l2;
        this.b = l3;
    }

    /* synthetic */ TimeSignalCommand(long l2, long l3, byte by2) {
        this(l2, l3);
    }

    static long a(i i2, long l2) {
        long l3 = i2.e();
        long l4 = -9223372036854775807L;
        if ((128 & l3) != 0) {
            l4 = ((1 & l3) << 32 | i2.i()) + l2 & 0x1FFFFFFFFL;
        }
        return l4;
    }

    static TimeSignalCommand a(i i2, long l2, n n2) {
        l2 = TimeSignalCommand.a(i2, l2);
        return new TimeSignalCommand(l2, n2.a(l2));
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeLong(this.a);
        parcel.writeLong(this.b);
    }

}

