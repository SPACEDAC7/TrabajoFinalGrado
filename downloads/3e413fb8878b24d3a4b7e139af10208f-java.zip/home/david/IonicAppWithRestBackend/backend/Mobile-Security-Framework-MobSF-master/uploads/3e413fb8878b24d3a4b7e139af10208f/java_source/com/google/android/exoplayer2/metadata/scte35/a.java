/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2.metadata.scte35;

import com.google.android.exoplayer2.i.h;
import com.google.android.exoplayer2.i.i;
import com.google.android.exoplayer2.i.n;
import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.d;
import com.google.android.exoplayer2.metadata.scte35.PrivateCommand;
import com.google.android.exoplayer2.metadata.scte35.SpliceInsertCommand;
import com.google.android.exoplayer2.metadata.scte35.SpliceNullCommand;
import com.google.android.exoplayer2.metadata.scte35.SpliceScheduleCommand;
import com.google.android.exoplayer2.metadata.scte35.TimeSignalCommand;
import java.nio.ByteBuffer;

public final class a
implements com.google.android.exoplayer2.metadata.a {
    private final i a = new i();
    private final h b = new h();
    private n c;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final Metadata a(d object) {
        if (this.c == null || object.e != this.c.a()) {
            this.c = new n(object.d);
            this.c.b(object.d - object.e);
        }
        object = object.c;
        byte[] arrby = object.array();
        int n2 = object.limit();
        this.a.a(arrby, n2);
        this.b.a(arrby, n2);
        this.b.b(39);
        long l2 = this.b.c(1);
        l2 = (long)this.b.c(32) | l2 << 32;
        this.b.b(20);
        n2 = this.b.c(12);
        int n3 = this.b.c(8);
        this.a.d(14);
        switch (n3) {
            default: {
                return new Metadata(new Metadata.Entry[0]);
            }
            case 0: {
                object = new SpliceNullCommand();
                break;
            }
            case 4: {
                object = SpliceScheduleCommand.a(this.a);
                break;
            }
            case 5: {
                object = SpliceInsertCommand.a(this.a, l2, this.c);
                break;
            }
            case 6: {
                object = TimeSignalCommand.a(this.a, l2, this.c);
                break;
            }
            case 255: {
                object = PrivateCommand.a(this.a, n2, l2);
            }
        }
        if (object == null) {
            return new Metadata(new Metadata.Entry[0]);
        }
        return new Metadata(new Metadata.Entry[]{object});
    }
}

