/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.exoplayer2;

public abstract class n {
    public static final n a = new n(){

        @Override
        public final int a(Object object) {
            return -1;
        }

        @Override
        public final a a(int n2, a a2, boolean bl2) {
            throw new IndexOutOfBoundsException();
        }

        @Override
        public final b a(int n2, b b2, long l2) {
            throw new IndexOutOfBoundsException();
        }

        @Override
        public final int b() {
            return 0;
        }

        @Override
        public final int c() {
            return 0;
        }
    };

    public abstract int a(Object var1);

    public abstract a a(int var1, a var2, boolean var3);

    public final b a(int n2, b b2) {
        return this.a(n2, b2, 0);
    }

    public abstract b a(int var1, b var2, long var3);

    public final boolean a() {
        if (this.b() == 0) {
            return true;
        }
        return false;
    }

    public abstract int b();

    public final b b(int n2, b b2) {
        return this.a(n2, b2, 0);
    }

    public abstract int c();

    public static final class a {
        public Object a;
        public Object b;
        public int c;
        public long d;
        public long e;
    }

    public static final class b {
        public Object a;
        public long b;
        public long c;
        public boolean d;
        public boolean e;
        public int f;
        public int g;
        public long h;
        public long i;
        public long j;
    }

}

