/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.widget.FrameLayout
 */
package com.google.android.exoplayer2.ui;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import com.google.android.exoplayer2.j;

public final class AspectRatioFrameLayout
extends FrameLayout {
    private float a;
    private int b = 0;

    public AspectRatioFrameLayout(Context context) {
        this(context, null);
    }

    public AspectRatioFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        if (attributeSet != null) {
            context = context.getTheme().obtainStyledAttributes(attributeSet, j.AspectRatioFrameLayout, 0, 0);
            this.b = context.getInt(j.AspectRatioFrameLayout_resize_mode, 0);
        }
        return;
        finally {
            context.recycle();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final void onMeasure(int var1_1, int var2_2) {
        super.onMeasure(var1_1, var2_2);
        if (this.b == 3) return;
        if (this.a <= 0.0f) {
            return;
        }
        var2_2 = this.getMeasuredWidth();
        var1_1 = this.getMeasuredHeight();
        var3_3 = (float)var2_2 / (float)var1_1;
        if (Math.abs(var3_3 = this.a / var3_3 - 1.0f) <= 0.01f) return;
        switch (this.b) {
            default: {
                if (var3_3 <= 0.0f) break;
                var1_1 = (int)((float)var2_2 / this.a);
                ** GOTO lbl21
            }
            case 1: {
                var1_1 = (int)((float)var2_2 / this.a);
                ** GOTO lbl21
            }
            case 2: {
                var2_2 = (int)((float)var1_1 * this.a);
                ** GOTO lbl21
            }
        }
        var2_2 = (int)((float)var1_1 * this.a);
lbl21: // 4 sources:
        super.onMeasure(View.MeasureSpec.makeMeasureSpec((int)var2_2, (int)1073741824), View.MeasureSpec.makeMeasureSpec((int)var1_1, (int)1073741824));
    }

    public final void setAspectRatio(float f2) {
        if (this.a != f2) {
            this.a = f2;
            this.requestLayout();
        }
    }

    public final void setResizeMode(int n2) {
        if (this.b != n2) {
            this.b = n2;
            this.requestLayout();
        }
    }
}

