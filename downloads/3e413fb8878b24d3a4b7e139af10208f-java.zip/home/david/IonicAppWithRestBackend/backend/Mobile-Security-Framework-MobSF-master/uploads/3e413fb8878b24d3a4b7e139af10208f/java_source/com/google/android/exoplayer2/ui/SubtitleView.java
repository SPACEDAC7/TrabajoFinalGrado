/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Typeface
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.StaticLayout
 *  android.text.TextPaint
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.View
 *  android.view.accessibility.CaptioningManager
 *  android.view.accessibility.CaptioningManager$CaptionStyle
 */
package com.google.android.exoplayer2.ui;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.CaptioningManager;
import com.google.android.exoplayer2.f.b;
import com.google.android.exoplayer2.f.k;
import com.google.android.exoplayer2.i.o;
import com.google.android.exoplayer2.ui.a;
import java.util.ArrayList;
import java.util.List;

public final class SubtitleView
extends View
implements k.a {
    private final List<a> a = new ArrayList<a>();
    private List<b> b;
    private int c = 0;
    private float d = 0.0533f;
    private boolean e = true;
    private com.google.android.exoplayer2.f.a f = com.google.android.exoplayer2.f.a.a;
    private float g = 0.08f;

    public SubtitleView(Context context) {
        this(context, null);
    }

    public SubtitleView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @TargetApi(value=19)
    private float getUserCaptionFontScaleV19() {
        return ((CaptioningManager)this.getContext().getSystemService("captioning")).getFontScale();
    }

    @TargetApi(value=19)
    private com.google.android.exoplayer2.f.a getUserCaptionStyleV19() {
        return com.google.android.exoplayer2.f.a.a(((CaptioningManager)this.getContext().getSystemService("captioning")).getUserStyle());
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a() {
        float f2 = o.a >= 19 && !this.isInEditMode() ? this.getUserCaptionFontScaleV19() : 1.0f;
        this.setFractionalTextSize(f2 * 0.0533f);
    }

    @Override
    public final void a(List<b> list) {
        this.setCues(list);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void b() {
        com.google.android.exoplayer2.f.a a2 = o.a >= 19 && !this.isInEditMode() ? this.getUserCaptionStyleV19() : com.google.android.exoplayer2.f.a.a;
        this.setStyle(a2);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void dispatchDraw(Canvas canvas) {
        float f2;
        int n2 = this.b == null ? 0 : this.b.size();
        int n3 = this.getTop();
        int n4 = this.getBottom();
        int n5 = this.getLeft() + this.getPaddingLeft();
        int n6 = n3 + this.getPaddingTop();
        int n7 = this.getRight() + this.getPaddingRight();
        int n8 = n4 - this.getPaddingBottom();
        if (n8 <= n6) return;
        if (n7 <= n5) {
            return;
        }
        if (this.c == 2) {
            f2 = this.d;
        } else {
            f2 = this.d;
            n3 = this.c == 0 ? n8 - n6 : n4 - n3;
            f2 = (float)n3 * f2;
        }
        if (f2 <= 0.0f) return;
        int n9 = 0;
        while (n9 < n2) {
            a a2 = this.a.get(n9);
            b b2 = this.b.get(n9);
            boolean bl2 = this.e;
            com.google.android.exoplayer2.f.a a3 = this.f;
            float f3 = this.g;
            CharSequence charSequence = b2.a;
            if (!TextUtils.isEmpty((CharSequence)charSequence)) {
                CharSequence charSequence2;
                n3 = b2.i ? b2.j : a3.d;
                if (!bl2) {
                    charSequence = charSequence.toString();
                    n3 = a3.d;
                }
                n4 = (charSequence2 = a2.d) == charSequence || charSequence2 != null && charSequence2.equals(charSequence) ? 1 : 0;
                if (n4 != 0 && o.a((Object)a2.e, (Object)b2.b) && a2.f == b2.c && a2.g == b2.d && o.a((Object)a2.h, (Object)b2.e) && a2.i == b2.f && o.a((Object)a2.j, (Object)b2.g) && a2.k == b2.h && a2.l == bl2 && a2.m == a3.b && a2.n == a3.c && a2.o == n3 && a2.q == a3.e && a2.p == a3.f && o.a((Object)a2.c.getTypeface(), (Object)a3.g) && a2.r == f2 && a2.s == f3 && a2.t == n5 && a2.u == n6 && a2.v == n7 && a2.w == n8) {
                    a2.a(canvas);
                } else {
                    a2.d = charSequence;
                    a2.e = b2.b;
                    a2.f = b2.c;
                    a2.g = b2.d;
                    a2.h = b2.e;
                    a2.i = b2.f;
                    a2.j = b2.g;
                    a2.k = b2.h;
                    a2.l = bl2;
                    a2.m = a3.b;
                    a2.n = a3.c;
                    a2.o = n3;
                    a2.q = a3.e;
                    a2.p = a3.f;
                    a2.c.setTypeface(a3.g);
                    a2.r = f2;
                    a2.s = f3;
                    a2.t = n5;
                    a2.u = n6;
                    a2.v = n7;
                    a2.w = n8;
                    int n10 = a2.v - a2.t;
                    int n11 = a2.w - a2.u;
                    a2.c.setTextSize(f2);
                    int n12 = (int)(0.125f * f2 + 0.5f);
                    n3 = n4 = n10 - (n12 << 1);
                    if (a2.k != Float.MIN_VALUE) {
                        n3 = (int)((float)n4 * a2.k);
                    }
                    if (n3 <= 0) {
                        Log.w((String)"SubtitlePainter", (String)"Skipped drawing subtitle cue (insufficient space)");
                    } else {
                        int n13;
                        b2 = a2.e == null ? Layout.Alignment.ALIGN_CENTER : a2.e;
                        a2.x = new StaticLayout(charSequence, a2.c, n3, (Layout.Alignment)b2, a2.a, a2.b, true);
                        int n14 = a2.x.getHeight();
                        int n15 = a2.x.getLineCount();
                        n4 = 0;
                        for (n13 = 0; n13 < n15; ++n13) {
                            n4 = Math.max((int)Math.ceil(a2.x.getLineWidth(n13)), n4);
                        }
                        if (a2.k == Float.MIN_VALUE || n4 >= n3) {
                            n3 = n4;
                        }
                        n13 = n3 + (n12 << 1);
                        if (a2.i != Float.MIN_VALUE) {
                            n4 = Math.round((float)n10 * a2.i) + a2.t;
                            if (a2.j == 2) {
                                n3 = n4 - n13;
                            } else {
                                n3 = n4;
                                if (a2.j == 1) {
                                    n3 = ((n4 << 1) - n13) / 2;
                                }
                            }
                            n10 = Math.max(n3, a2.t);
                            n13 = Math.min(n13 + n10, a2.v);
                        } else {
                            n10 = n3 = (n10 - n13) / 2;
                            n13 += n3;
                        }
                        if (a2.f != Float.MIN_VALUE) {
                            if (a2.g == 0) {
                                n4 = Math.round((float)n11 * a2.f) + a2.u;
                            } else {
                                n3 = a2.x.getLineBottom(0) - a2.x.getLineTop(0);
                                if (a2.f >= 0.0f) {
                                    f3 = a2.f;
                                    n4 = Math.round((float)n3 * f3) + a2.u;
                                } else {
                                    f3 = a2.f;
                                    n4 = Math.round((float)n3 * (f3 + 1.0f)) + a2.w;
                                }
                            }
                            if (a2.h == 2) {
                                n3 = n4 - n14;
                            } else {
                                n3 = n4;
                                if (a2.h == 1) {
                                    n3 = ((n4 << 1) - n14) / 2;
                                }
                            }
                            if (n3 + n14 > a2.w) {
                                n3 = a2.w - n14;
                            } else {
                                n4 = n3;
                                if (n3 < a2.u) {
                                    n4 = a2.u;
                                }
                                n3 = n4;
                            }
                        } else {
                            n3 = a2.w - n14 - (int)((float)n11 * f3);
                        }
                        a2.x = new StaticLayout(charSequence, a2.c, n13 - n10, (Layout.Alignment)b2, a2.a, a2.b, true);
                        a2.y = n10;
                        a2.z = n3;
                        a2.A = n12;
                        a2.a(canvas);
                    }
                }
            }
            ++n9;
        }
    }

    public final void setApplyEmbeddedStyles(boolean bl2) {
        if (this.e == bl2) {
            return;
        }
        this.e = bl2;
        this.invalidate();
    }

    public final void setBottomPaddingFraction(float f2) {
        if (this.g == f2) {
            return;
        }
        this.g = f2;
        this.invalidate();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void setCues(List<b> list) {
        if (this.b == list) {
            return;
        }
        this.b = list;
        int n2 = list == null ? 0 : list.size();
        do {
            if (this.a.size() >= n2) {
                this.invalidate();
                return;
            }
            this.a.add(new a(this.getContext()));
        } while (true);
    }

    public final void setFractionalTextSize(float f2) {
        if (this.c != 0 || this.d != f2) {
            this.c = 0;
            this.d = f2;
            this.invalidate();
        }
    }

    public final void setStyle(com.google.android.exoplayer2.f.a a2) {
        if (this.f == a2) {
            return;
        }
        this.f = a2;
        this.invalidate();
    }
}

