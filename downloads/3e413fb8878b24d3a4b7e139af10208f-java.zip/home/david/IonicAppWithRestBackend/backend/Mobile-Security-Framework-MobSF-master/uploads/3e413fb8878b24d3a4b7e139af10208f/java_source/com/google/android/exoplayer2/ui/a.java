/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.Paint$Join
 *  android.graphics.Paint$Style
 *  android.graphics.RectF
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.StaticLayout
 *  android.text.TextPaint
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 */
package com.google.android.exoplayer2.ui;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.DisplayMetrics;

final class a {
    int A;
    private final RectF B = new RectF();
    private final float C;
    private final float D;
    private final float E;
    private final float F;
    private final Paint G;
    final float a;
    final float b;
    final TextPaint c;
    CharSequence d;
    Layout.Alignment e;
    float f;
    int g;
    int h;
    float i;
    int j;
    float k;
    boolean l;
    int m;
    int n;
    int o;
    int p;
    int q;
    float r;
    float s;
    int t;
    int u;
    int v;
    int w;
    StaticLayout x;
    int y;
    int z;

    public a(Context context) {
        TypedArray typedArray = context.obtainStyledAttributes(null, new int[]{16843287, 16843288}, 0, 0);
        this.b = typedArray.getDimensionPixelSize(0, 0);
        this.a = typedArray.getFloat(1, 1.0f);
        typedArray.recycle();
        int n2 = Math.round((float)context.getResources().getDisplayMetrics().densityDpi * 2.0f / 160.0f);
        this.C = n2;
        this.D = n2;
        this.E = n2;
        this.F = n2;
        this.c = new TextPaint();
        this.c.setAntiAlias(true);
        this.c.setSubpixelText(true);
        this.G = new Paint();
        this.G.setAntiAlias(true);
        this.G.setStyle(Paint.Style.FILL);
    }

    /*
     * Enabled aggressive block sorting
     */
    final void a(Canvas canvas) {
        float f2;
        int n2;
        int n3;
        StaticLayout staticLayout = this.x;
        if (staticLayout == null) {
            return;
        }
        int n4 = canvas.save();
        canvas.translate((float)this.y, (float)this.z);
        if (Color.alpha((int)this.o) > 0) {
            this.G.setColor(this.o);
            canvas.drawRect((float)(- this.A), 0.0f, (float)(staticLayout.getWidth() + this.A), (float)staticLayout.getHeight(), this.G);
        }
        if (Color.alpha((int)this.n) > 0) {
            this.G.setColor(this.n);
            f2 = staticLayout.getLineTop(0);
            n3 = staticLayout.getLineCount();
            for (n2 = 0; n2 < n3; ++n2) {
                this.B.left = staticLayout.getLineLeft(n2) - (float)this.A;
                this.B.right = staticLayout.getLineRight(n2) + (float)this.A;
                this.B.top = f2;
                f2 = this.B.bottom = (float)staticLayout.getLineBottom(n2);
                canvas.drawRoundRect(this.B, this.C, this.C, this.G);
            }
        }
        if (this.q == 1) {
            this.c.setStrokeJoin(Paint.Join.ROUND);
            this.c.setStrokeWidth(this.D);
            this.c.setColor(this.p);
            this.c.setStyle(Paint.Style.FILL_AND_STROKE);
            staticLayout.draw(canvas);
        } else if (this.q == 2) {
            this.c.setShadowLayer(this.E, this.F, this.F, this.p);
        } else if (this.q == 3 || this.q == 4) {
            n3 = this.q == 3 ? 1 : 0;
            n2 = n3 != 0 ? -1 : this.p;
            n3 = n3 != 0 ? this.p : -1;
            f2 = this.E / 2.0f;
            this.c.setColor(this.m);
            this.c.setStyle(Paint.Style.FILL);
            this.c.setShadowLayer(this.E, - f2, - f2, n2);
            staticLayout.draw(canvas);
            this.c.setShadowLayer(this.E, f2, f2, n3);
        }
        this.c.setColor(this.m);
        this.c.setStyle(Paint.Style.FILL);
        staticLayout.draw(canvas);
        this.c.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
        canvas.restoreToCount(n4);
    }
}

