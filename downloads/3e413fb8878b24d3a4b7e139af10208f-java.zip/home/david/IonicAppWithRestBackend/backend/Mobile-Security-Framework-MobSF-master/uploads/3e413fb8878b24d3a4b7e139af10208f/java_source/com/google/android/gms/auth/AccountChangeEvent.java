/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.e;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.Arrays;

public class AccountChangeEvent
implements SafeParcelable {
    public static final Parcelable.Creator<AccountChangeEvent> CREATOR = new e();
    final int a;
    final long b;
    final String c;
    final int d;
    final int e;
    final String f;

    AccountChangeEvent(int n2, long l2, String string, int n3, int n4, String string2) {
        this.a = n2;
        this.b = l2;
        this.c = d.d(string);
        this.d = n3;
        this.e = n4;
        this.f = string2;
    }

    public int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof AccountChangeEvent)) return false;
        object = (AccountChangeEvent)object;
        if (this.a != object.a) return false;
        if (this.b != object.b) return false;
        if (!d.a((Object)this.c, (Object)object.c)) return false;
        if (this.d != object.d) return false;
        if (this.e != object.e) return false;
        if (d.a((Object)this.f, (Object)object.f)) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b, this.c, this.d, this.e, this.f});
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public String toString() {
        var1_1 = "UNKNOWN";
        switch (this.d) {
            case 1: {
                var1_1 = "ADDED";
                ** break;
            }
            case 2: {
                var1_1 = "REMOVED";
                ** break;
            }
            case 4: {
                var1_1 = "RENAMED_TO";
            }
lbl11: // 4 sources:
            default: {
                return "AccountChangeEvent {accountName = " + this.c + ", changeType = " + var1_1 + ", changeData = " + this.f + ", eventIndex = " + this.e + "}";
            }
            case 3: 
        }
        var1_1 = "RENAMED_FROM";
        return "AccountChangeEvent {accountName = " + this.c + ", changeType = " + var1_1 + ", changeData = " + this.f + ", eventIndex = " + this.e + "}";
    }

    public void writeToParcel(Parcel parcel, int n2) {
        e.a(this, parcel);
    }
}

