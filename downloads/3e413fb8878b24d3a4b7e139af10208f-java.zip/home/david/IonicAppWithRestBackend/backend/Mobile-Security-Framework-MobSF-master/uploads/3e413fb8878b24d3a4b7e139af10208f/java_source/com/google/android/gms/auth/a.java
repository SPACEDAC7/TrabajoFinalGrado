/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.auth;

public class a
extends Exception {
    public a() {
    }

    public a(String string) {
        super(string);
    }
}

