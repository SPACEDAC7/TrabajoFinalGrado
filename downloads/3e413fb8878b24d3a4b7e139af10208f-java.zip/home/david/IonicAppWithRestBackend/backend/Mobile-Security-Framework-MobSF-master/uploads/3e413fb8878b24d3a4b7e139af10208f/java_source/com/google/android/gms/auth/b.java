/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.content.pm.ApplicationInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  android.os.RemoteException
 *  android.text.TextUtils
 *  android.util.Log
 */
package com.google.android.gms.auth;

import android.accounts.Account;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.auth.a;
import com.google.android.gms.auth.c;
import com.google.android.gms.auth.d;
import com.google.android.gms.c.a;
import com.google.android.gms.common.e;
import com.google.android.gms.common.g;
import com.google.android.gms.common.internal.k;
import java.io.IOException;

public final class b {
    public static final String a;
    public static final String b;
    private static final ComponentName c;
    private static final ComponentName d;

    static {
        int n2 = Build.VERSION.SDK_INT;
        a = "callerUid";
        n2 = Build.VERSION.SDK_INT;
        b = "androidPackageName";
        c = new ComponentName("com.google.android.gms", "com.google.android.gms.auth.GetToken");
        d = new ComponentName("com.google.android.gms", "com.google.android.gms.recovery.RecoveryService");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Bundle a(Context var0, Account var1_1, String var2_5) {
        block13 : {
            var3_6 = var0.getApplicationContext();
            a.a.a.a.d.i("Calling this from your main thread can lead to deadlock");
            b.a((Context)var3_6);
            var4_7 = new Bundle();
            var0 = var0.getApplicationInfo().packageName;
            var4_7.putString("clientPackageName", (String)var0);
            if (TextUtils.isEmpty((CharSequence)var4_7.getString(b.b))) {
                var4_7.putString(b.b, (String)var0);
            }
            var0 = new g();
            if ((var3_6 = k.a((Context)var3_6)).a(b.c, (ServiceConnection)var0, "GoogleAuthUtil") == false) throw new IOException("Could not bind to service with the given context.");
            try {
                block12 : {
                    block11 : {
                        var2_5 = a.a.a(var0.a()).a((Account)var1_1, var2_5, var4_7);
                        if (var2_5 == null) {
                            Log.w((String)"GoogleAuthUtil", (String)"Binder call returned null.");
                            throw new a("ServiceUnavailable");
                        }
                        var6_8 = TextUtils.isEmpty((CharSequence)var2_5.getString("authtoken"));
                        if (var6_8) break block11;
                        var3_6.a(b.c, (ServiceConnection)var0);
                        return var2_5;
                    }
                    var1_1 = var2_5.getString("Error");
                    var2_5 = (Intent)var2_5.getParcelable("userRecoveryIntent");
                    var5_9 = "BadAuthentication".equals(var1_1) || "CaptchaRequired".equals(var1_1) || "DeviceManagementRequiredOrSyncDisabled".equals(var1_1) || "NeedPermission".equals(var1_1) || "NeedsBrowser".equals(var1_1) || "UserCancel".equals(var1_1) || "AppDownloadRequired".equals(var1_1) || com.google.android.gms.c.b.u.W.equals(var1_1) || com.google.android.gms.c.b.v.W.equals(var1_1) || com.google.android.gms.c.b.w.W.equals(var1_1) || com.google.android.gms.c.b.x.W.equals(var1_1) || com.google.android.gms.c.b.y.W.equals(var1_1) || com.google.android.gms.c.b.z.W.equals(var1_1) || com.google.android.gms.c.b.s.W.equals(var1_1);
                    if (!var5_9) break block12;
                    throw new d((String)var1_1, (Intent)var2_5);
                }
                try {
                    if (!"NetworkError".equals(var1_1) && !"ServiceUnavailable".equals(var1_1) && !"Timeout".equals(var1_1)) break block13;
                }
                catch (RemoteException var1_2) {
                    Log.i((String)"GoogleAuthUtil", (String)"GMS remote exception ", (Throwable)var1_2);
                    throw new IOException("remote exception");
                }
            }
            catch (Throwable var1_3) {
                var3_6.a(b.c, (ServiceConnection)var0);
                throw var1_3;
            }
            catch (InterruptedException var1_4) {
                throw new a("Interrupted");
            }
            var5_9 = true;
            ** GOTO lbl45
        }
        var5_9 = false;
lbl45: // 2 sources:
        if (var5_9 == false) throw new a((String)var1_1);
        throw new IOException((String)var1_1);
    }

    @Deprecated
    public static String a(Context context, String string, String string2) {
        return b.a(context, new Account(string, "com.google"), string2).getString("authtoken");
    }

    private static void a(Context context) {
        try {
            e.b(context);
            return;
        }
        catch (com.google.android.gms.common.d var0_1) {
            throw new c(var0_1.b, var0_1.getMessage(), new Intent(var0_1.a));
        }
        catch (com.google.android.gms.common.c var0_2) {
            throw new a(var0_2.getMessage());
        }
    }

    /*
     * Exception decompiling
     */
    public static void a(Context var0, String var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 5[CATCHBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }
}

