/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 */
package com.google.android.gms.auth;

import android.content.Intent;
import com.google.android.gms.auth.d;

public final class c
extends d {
    private final int a;

    c(int n2, String string, Intent intent) {
        super(string, intent);
        this.a = n2;
    }
}

