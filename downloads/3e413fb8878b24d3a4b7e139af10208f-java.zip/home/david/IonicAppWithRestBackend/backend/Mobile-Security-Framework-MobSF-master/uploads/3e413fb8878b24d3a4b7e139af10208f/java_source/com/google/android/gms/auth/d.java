/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 */
package com.google.android.gms.auth;

import android.content.Intent;
import com.google.android.gms.auth.a;

public class d
extends a {
    private final Intent a;

    public d(String string, Intent intent) {
        super(string);
        this.a = intent;
    }

    public final Intent a() {
        if (this.a == null) {
            return null;
        }
        return new Intent(this.a);
    }
}

