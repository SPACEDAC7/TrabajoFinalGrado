/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.auth.AccountChangeEvent;

public final class e
implements Parcelable.Creator<AccountChangeEvent> {
    static void a(AccountChangeEvent accountChangeEvent, Parcel parcel) {
        int n2 = d.m(parcel, 20293);
        d.c(parcel, 1, accountChangeEvent.a);
        d.a(parcel, 2, accountChangeEvent.b);
        d.a(parcel, 3, accountChangeEvent.c);
        d.c(parcel, 4, accountChangeEvent.d);
        d.c(parcel, 5, accountChangeEvent.e);
        d.a(parcel, 6, accountChangeEvent.f);
        d.n(parcel, n2);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        String string = null;
        int n2 = 0;
        int n3 = d.a(parcel);
        long l2 = 0;
        int n4 = 0;
        String string2 = null;
        int n5 = 0;
        block8 : while (parcel.dataPosition() < n3) {
            int n6 = parcel.readInt();
            switch (65535 & n6) {
                default: {
                    d.b(parcel, n6);
                    continue block8;
                }
                case 1: {
                    n5 = d.e(parcel, n6);
                    continue block8;
                }
                case 2: {
                    l2 = d.f(parcel, n6);
                    continue block8;
                }
                case 3: {
                    string2 = d.i(parcel, n6);
                    continue block8;
                }
                case 4: {
                    n4 = d.e(parcel, n6);
                    continue block8;
                }
                case 5: {
                    n2 = d.e(parcel, n6);
                    continue block8;
                }
                case 6: 
            }
            string = d.i(parcel, n6);
        }
        if (parcel.dataPosition() != n3) {
            throw new Fragment.a("Overread allowed size end=" + n3, parcel);
        }
        return new AccountChangeEvent(n5, l2, string2, n4, n2, string);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new AccountChangeEvent[n2];
    }
}

