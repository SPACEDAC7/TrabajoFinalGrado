/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth;

import a.a.a.a.d;
import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.auth.AccountChangeEventsRequest;

public final class f
implements Parcelable.Creator<AccountChangeEventsRequest> {
    static void a(AccountChangeEventsRequest accountChangeEventsRequest, Parcel parcel, int n2) {
        int n3 = d.m(parcel, 20293);
        d.c(parcel, 1, accountChangeEventsRequest.a);
        d.c(parcel, 2, accountChangeEventsRequest.b);
        d.a(parcel, 3, accountChangeEventsRequest.c);
        d.a(parcel, 4, (Parcelable)accountChangeEventsRequest.d, n2);
        d.n(parcel, n3);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        Account account = null;
        int n2 = d.a(parcel);
        int n3 = 0;
        int n4 = 0;
        String string = null;
        block6 : while (parcel.dataPosition() < n2) {
            int n5 = parcel.readInt();
            switch (65535 & n5) {
                default: {
                    d.b(parcel, n5);
                    continue block6;
                }
                case 1: {
                    n4 = d.e(parcel, n5);
                    continue block6;
                }
                case 2: {
                    n3 = d.e(parcel, n5);
                    continue block6;
                }
                case 3: {
                    string = d.i(parcel, n5);
                    continue block6;
                }
                case 4: 
            }
            account = (Account)d.a(parcel, n5, Account.CREATOR);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new AccountChangeEventsRequest(n4, n3, string, account);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new AccountChangeEventsRequest[n2];
    }
}

