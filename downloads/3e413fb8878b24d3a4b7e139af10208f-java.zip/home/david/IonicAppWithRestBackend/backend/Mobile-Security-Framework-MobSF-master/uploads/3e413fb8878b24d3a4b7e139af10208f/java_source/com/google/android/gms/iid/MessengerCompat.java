/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Message
 *  android.os.Messenger
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.iid;

import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.iid.c;

public class MessengerCompat
implements Parcelable {
    public static final Parcelable.Creator<MessengerCompat> CREATOR = new Parcelable.Creator<MessengerCompat>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            if ((parcel = parcel.readStrongBinder()) != null) {
                return new MessengerCompat((IBinder)parcel);
            }
            return null;
        }

        public final /* synthetic */ Object[] newArray(int n2) {
            return new MessengerCompat[n2];
        }
    };
    Messenger a;
    c b;

    public MessengerCompat(Handler handler) {
        if (Build.VERSION.SDK_INT >= 21) {
            this.a = new Messenger(handler);
            return;
        }
        this.b = new a(handler);
    }

    public MessengerCompat(IBinder iBinder) {
        if (Build.VERSION.SDK_INT >= 21) {
            this.a = new Messenger(iBinder);
            return;
        }
        this.b = c.a.a(iBinder);
    }

    public static int a(Message message) {
        if (Build.VERSION.SDK_INT >= 21) {
            return message.sendingUid;
        }
        return message.arg2;
    }

    public final IBinder a() {
        if (this.a != null) {
            return this.a.getBinder();
        }
        return this.b.asBinder();
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        try {
            boolean bl2 = this.a().equals((Object)((MessengerCompat)object).a());
            return bl2;
        }
        catch (ClassCastException var1_2) {
            return false;
        }
    }

    public int hashCode() {
        return this.a().hashCode();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        if (this.a != null) {
            parcel.writeStrongBinder(this.a.getBinder());
            return;
        }
        parcel.writeStrongBinder(this.b.asBinder());
    }

    final class a
    extends c.a {
        Handler a;

        a(Handler handler) {
            this.a = handler;
        }

        @Override
        public final void a(Message message) {
            message.arg2 = Binder.getCallingUid();
            this.a.dispatchMessage(message);
        }
    }

}

