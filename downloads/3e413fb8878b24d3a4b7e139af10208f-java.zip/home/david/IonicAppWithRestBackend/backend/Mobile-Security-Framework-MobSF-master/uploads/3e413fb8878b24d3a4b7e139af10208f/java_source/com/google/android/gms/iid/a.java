/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  android.os.Looper
 *  android.util.Base64
 *  android.util.Log
 */
package com.google.android.gms.iid;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.iid.d;
import com.google.android.gms.iid.e;
import java.io.IOException;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;

public final class a {
    static Map<String, a> a = new HashMap<String, a>();
    static e c;
    static String g;
    private static d h;
    Context b;
    KeyPair d;
    String e = "";
    long f;

    private a(Context context, String string) {
        this.b = context.getApplicationContext();
        this.e = string;
    }

    static int a(Context context) {
        try {
            int n2 = context.getPackageManager().getPackageInfo((String)context.getPackageName(), (int)0).versionCode;
            return n2;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            Log.w((String)"InstanceID", (String)("Never happens: can't find own package " + (Object)var0_1));
            return 0;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static a a(Context object, Bundle object2) {
        synchronized (a.class) {
            a a2;
            String string;
            string = string == null ? "" : string.getString("subtype");
            if (string == null) {
                string = "";
            }
            Context context = object.getApplicationContext();
            if (c == null) {
                c = new e(context);
                h = new d(context);
            }
            g = Integer.toString(a.a(context));
            object = a2 = a.get(string);
            if (a2 == null) {
                object = new a(context, string);
                a.put(string, (a)object);
            }
            return object;
        }
    }

    static e a() {
        return c;
    }

    static String a(KeyPair object) {
        object = object.getPublic().getEncoded();
        try {
            object = MessageDigest.getInstance("SHA1").digest((byte[])object);
        }
        catch (NoSuchAlgorithmException var0_1) {
            Log.w((String)"InstanceID", (String)"Unexpected error, device missing required alghorithms");
            return null;
        }
        object[0] = (byte)((object[0] & 15) + 112);
        object = Base64.encodeToString((byte[])object, (int)0, (int)8, (int)11);
        return object;
    }

    static String a(byte[] arrby) {
        return Base64.encodeToString((byte[])arrby, (int)11);
    }

    public static a b(Context context) {
        return a.a(context, null);
    }

    static d b() {
        return h;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String a(String string, String string2) {
        boolean bl2;
        boolean bl3 = false;
        boolean bl4 = true;
        if (Looper.getMainLooper() == Looper.myLooper()) {
            throw new IOException("MAIN_THREAD");
        }
        String string3 = c.a("appVersion");
        if (string3 == null || !string3.equals(g)) {
            bl2 = true;
        } else {
            string3 = c.a("lastToken");
            if (string3 == null) {
                bl2 = true;
            } else {
                long l2 = Long.parseLong(string3);
                bl2 = System.currentTimeMillis() / 1000 - Long.valueOf(l2) > 604800;
            }
        }
        string3 = bl2 ? null : c.a(this.e, string, string2);
        String string4 = string3;
        if (string3 != null) return string4;
        string3 = new Bundle();
        bl2 = bl4;
        if (string3.getString("ttl") != null) {
            bl2 = false;
        }
        if ("jwt".equals(string3.getString("type"))) {
            bl2 = bl3;
        }
        string3 = this.a(string, string2, (Bundle)string3);
        Log.w((String)"InstanceID", (String)("token: " + string3));
        string4 = string3;
        if (string3 == null) return string4;
        string4 = string3;
        if (!bl2) return string4;
        c.a(this.e, string, string2, string3, g);
        return string3;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String a(String string, String string2, Bundle bundle) {
        if (string2 != null) {
            bundle.putString("scope", string2);
        }
        bundle.putString("sender", string);
        string2 = "".equals(this.e) ? string : this.e;
        if (!bundle.containsKey("legacy.register")) {
            bundle.putString("subscription", string);
            bundle.putString("subtype", string2);
            bundle.putString("X-subscription", string);
            bundle.putString("X-subtype", string2);
        }
        d d2 = h;
        if (this.d == null) {
            this.d = c.d(this.e);
        }
        if (this.d == null) {
            this.f = System.currentTimeMillis();
            this.d = c.a(this.e, this.f);
        }
        KeyPair keyPair = this.d;
        string = string2 = d2.a(bundle, keyPair);
        if (string2 != null) {
            string = string2;
            if (string2.hasExtra("google.messenger")) {
                string = d2.a(bundle, keyPair);
            }
        }
        return d.a((Intent)string);
    }
}

