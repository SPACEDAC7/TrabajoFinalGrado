/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.pm.PackageManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.Message
 *  android.os.Parcelable
 *  android.util.Log
 */
package com.google.android.gms.iid;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.b.c;
import com.google.android.gms.iid.MessengerCompat;
import com.google.android.gms.iid.a;
import com.google.android.gms.iid.d;
import com.google.android.gms.iid.e;
import java.io.IOException;
import java.security.KeyPair;

public class b
extends Service {
    static String a = "action";
    private static String f = "google.com/iid";
    private static String g = "CMD";
    private static String h = "gcm.googleapis.com/refresh";
    MessengerCompat b;
    BroadcastReceiver c;
    int d;
    int e;

    public b() {
        this.b = new MessengerCompat(new Handler(Looper.getMainLooper()){

            public final void handleMessage(Message message) {
                b.a(b.this, message, MessengerCompat.a(message));
            }
        });
        this.c = new BroadcastReceiver(){

            public final void onReceive(Context context, Intent intent) {
                if (Log.isLoggable((String)"InstanceID", (int)3)) {
                    intent.getStringExtra("registration_id");
                    Log.d((String)"InstanceID", (String)("Received GSF callback using dynamic receiver: " + (Object)intent.getExtras()));
                }
                b.this.a(intent);
                b.this.a();
            }
        };
    }

    static void a(Context context) {
        Intent intent = new Intent("com.google.android.gms.iid.InstanceID");
        intent.setPackage(context.getPackageName());
        intent.putExtra(g, "SYNC");
        context.startService(intent);
    }

    static void a(Context context, e e2) {
        e2.b();
        e2 = new Intent("com.google.android.gms.iid.InstanceID");
        e2.putExtra(g, "RST");
        e2.setPackage(context.getPackageName());
        context.startService((Intent)e2);
    }

    static /* synthetic */ void a(b b2, Message message, int n2) {
        d.a((Context)b2);
        b2.getPackageManager();
        if (n2 != d.c && n2 != d.b) {
            Log.w((String)"InstanceID", (String)("Message from unexpected caller " + n2 + " mine=" + d.b + " appid=" + d.c));
            return;
        }
        b2.a((Intent)message.obj);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    final void a() {
        synchronized (this) {
            --this.d;
            if (this.d == 0) {
                this.stopSelf(this.e);
            }
            if (Log.isLoggable((String)"InstanceID", (int)3)) {
                Log.d((String)"InstanceID", (String)("Stop " + this.d + " " + this.e));
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(Intent object) {
        Object object2;
        String string = object.getStringExtra("subtype");
        if (string == null) {
            object2 = a.b((Context)this);
        } else {
            object2 = new Bundle();
            object2.putString("subtype", string);
            object2 = a.a((Context)this, (Bundle)object2);
        }
        Object object3 = object.getStringExtra(g);
        if (object.getStringExtra("error") != null || object.getStringExtra("registration_id") != null) {
            if (Log.isLoggable((String)"InstanceID", (int)3)) {
                Log.d((String)"InstanceID", (String)("Register result in service " + string));
            }
            a.b().b((Intent)object);
            return;
        }
        if (Log.isLoggable((String)"InstanceID", (int)3)) {
            Log.d((String)"InstanceID", (String)("Service command " + string + " " + (String)object3 + " " + (Object)object.getExtras()));
        }
        if (object.getStringExtra("unregistered") != null) {
            object3 = a.a();
            object2 = string == null ? "" : string;
            object3.c((String)object2);
            a.b().b((Intent)object);
            return;
        }
        if (h.equals(object.getStringExtra("from"))) {
            a.a().c(string);
            this.b();
            return;
        }
        if ("RST".equals(object3)) {
            object2.f = 0;
            object = a.c;
            string = object2.e;
            object.b(string + "|");
            object2.d = null;
            this.b();
            return;
        }
        if ("RST_FULL".equals(object3)) {
            if (a.a().a()) return;
            {
                a.a().b();
                this.b();
                return;
            }
        }
        if ("SYNC".equals(object3)) {
            a.a().c(string);
            this.b();
            return;
        }
        if (!"PING".equals(object3)) return;
        try {
            c.a((Context)this).a(f, d.a(), object.getExtras());
            return;
        }
        catch (IOException var1_2) {
            Log.w((String)"InstanceID", (String)"Failed to send ping response");
            return;
        }
    }

    public void b() {
    }

    public IBinder onBind(Intent intent) {
        if (intent != null && "com.google.android.gms.iid.InstanceID".equals(intent.getAction())) {
            return this.b.a();
        }
        return null;
    }

    public void onCreate() {
        IntentFilter intentFilter = new IntentFilter("com.google.android.c2dm.intent.REGISTRATION");
        intentFilter.addCategory(this.getPackageName());
        this.registerReceiver(this.c, intentFilter, "com.google.android.c2dm.permission.RECEIVE", null);
    }

    public void onDestroy() {
        this.unregisterReceiver(this.c);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public int onStartCommand(Intent intent, int n2, int n3) {
        // MONITORENTER : this
        ++this.d;
        if (n3 > this.e) {
            this.e = n3;
        }
        // MONITOREXIT : this
        if (intent == null) {
            this.a();
            return 2;
        }
        if ("com.google.android.gms.iid.InstanceID".equals(intent.getAction())) {
            Intent intent2;
            if (Build.VERSION.SDK_INT <= 18 && (intent2 = (Intent)intent.getParcelableExtra("GSF")) != null) {
                this.startService(intent2);
                return 1;
            }
            this.a(intent);
        }
        if (intent.getStringExtra("from") == null) return 2;
        com.google.android.gms.b.b.a(intent);
        return 2;
        finally {
            this.a();
        }
    }

}

