/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.ConditionVariable
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  android.os.Messenger
 *  android.os.Parcelable
 *  android.os.Process
 *  android.os.RemoteException
 *  android.os.SystemClock
 *  android.text.TextUtils
 *  android.util.Log
 */
package com.google.android.gms.iid;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcelable;
import android.os.Process;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.iid.MessengerCompat;
import com.google.android.gms.iid.a;
import com.google.android.gms.iid.b;
import com.google.android.gms.iid.c;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.RSAPrivateKey;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public final class d {
    static String a = null;
    static int b = 0;
    static int c = 0;
    static int d = 0;
    Context e;
    Map<String, Object> f = new HashMap<String, Object>();
    Messenger g;
    Messenger h;
    MessengerCompat i;
    PendingIntent j;
    long k;
    long l;
    int m;
    int n;
    long o;

    public d(Context context) {
        this.e = context;
    }

    public static String a() {
        synchronized (d.class) {
            int n2 = d;
            d = n2 + 1;
            String string = Integer.toString(n2);
            return string;
        }
    }

    public static String a(Context object) {
        if (a != null) {
            return a;
        }
        b = Process.myUid();
        object = object.getPackageManager();
        for (Object object2 : object.queryIntentServices(new Intent("com.google.android.c2dm.intent.REGISTER"), 0)) {
            if (object.checkPermission("com.google.android.c2dm.permission.RECEIVE", object2.serviceInfo.packageName) == 0) {
                try {
                    ApplicationInfo applicationInfo = object.getApplicationInfo(object2.serviceInfo.packageName, 0);
                    Log.w((String)"InstanceID/Rpc", (String)("Found " + applicationInfo.uid));
                    c = applicationInfo.uid;
                    a = object2 = object2.serviceInfo.packageName;
                    return object2;
                }
                catch (PackageManager.NameNotFoundException var2_5) {
                    continue;
                }
            }
            Log.w((String)"InstanceID/Rpc", (String)("Possible malicious package " + object2.serviceInfo.packageName + " declares com.google.android.c2dm.intent.REGISTER without permission"));
        }
        Log.w((String)"InstanceID/Rpc", (String)"Failed to resolve REGISTER intent, falling back");
        try {
            Object object3 = object.getApplicationInfo("com.google.android.gms", 0);
            a = object3.packageName;
            c = object3.uid;
            object3 = a;
            return object3;
        }
        catch (PackageManager.NameNotFoundException var1_3) {
            try {
                object = object.getApplicationInfo("com.google.android.gsf", 0);
                a = object.packageName;
                c = object.uid;
                object = a;
                return object;
            }
            catch (PackageManager.NameNotFoundException var0_1) {
                Log.w((String)"InstanceID/Rpc", (String)"Both Google Play Services and legacy GSF package are missing");
                return null;
            }
        }
    }

    static String a(Intent intent) {
        String string;
        if (intent == null) {
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
        String string2 = string = intent.getStringExtra("registration_id");
        if (string == null) {
            string2 = intent.getStringExtra("unregistered");
        }
        intent.getLongExtra("Retry-After", 0);
        if (string2 == null) {
            string2 = intent.getStringExtra("error");
            if (string2 != null) {
                throw new IOException(string2);
            }
            Log.w((String)"InstanceID/Rpc", (String)("Unexpected response from GCM " + (Object)intent.getExtras()), (Throwable)new Throwable());
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
        return string2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static /* varargs */ String a(KeyPair object, String ... arrstring) {
        try {
            arrstring = TextUtils.join((CharSequence)"\n", (Object[])arrstring).getBytes("UTF-8");
        }
        catch (UnsupportedEncodingException var0_1) {
            Log.e((String)"InstanceID/Rpc", (String)"Unable to encode string", (Throwable)var0_1);
            return null;
        }
        try {
            PrivateKey privateKey = object.getPrivate();
            object = privateKey instanceof RSAPrivateKey ? "SHA256withRSA" : "SHA256withECDSA";
            object = Signature.getInstance((String)object);
            object.initSign(privateKey);
            object.update((byte[])arrstring);
            return a.a(object.sign());
        }
        catch (GeneralSecurityException var0_2) {
            Log.e((String)"InstanceID/Rpc", (String)"Unable to sign registration request", (Throwable)var0_2);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void a(Object object) {
        Class class_ = this.getClass();
        synchronized (class_) {
            Iterator<String> iterator = this.f.keySet().iterator();
            while (iterator.hasNext()) {
                String string = iterator.next();
                Object object2 = this.f.get(string);
                this.f.put(string, object);
                d.a(object2, object);
            }
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void a(Object object, Object object2) {
        if (object instanceof ConditionVariable) {
            ((ConditionVariable)object).open();
        }
        if (!(object instanceof Messenger)) return;
        object = (Messenger)object;
        Message message = Message.obtain();
        message.obj = object2;
        try {
            object.send(message);
            return;
        }
        catch (RemoteException var0_1) {
            Log.w((String)"InstanceID/Rpc", (String)("Failed to send response " + (Object)var0_1));
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void a(String string, Object object) {
        Class class_ = this.getClass();
        synchronized (class_) {
            Object object2 = this.f.get(string);
            this.f.put(string, object);
            d.a(object2, object);
            return;
        }
    }

    private void c(Intent intent) {
        synchronized (this) {
            if (this.j == null) {
                Intent intent2 = new Intent();
                intent2.setPackage("com.google.example.invalidpackage");
                this.j = PendingIntent.getBroadcast((Context)this.e, (int)0, (Intent)intent2, (int)0);
            }
            intent.putExtra("app", (Parcelable)this.j);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    final Intent a(Bundle class_, KeyPair object) {
        ConditionVariable conditionVariable;
        String string;
        block25 : {
            boolean bl2;
            Intent intent;
            block26 : {
                conditionVariable = new ConditionVariable();
                string = d.a();
                intent = this.getClass();
                synchronized (intent) {
                    this.f.put(string, (Object)conditionVariable);
                }
                long l2 = SystemClock.elapsedRealtime();
                if (this.o != 0 && l2 <= this.o) {
                    Log.w((String)"InstanceID/Rpc", (String)("Backoff mode, next request attempt: " + (this.o - l2) + " interval: " + this.n));
                    throw new IOException("RETRY_LATER");
                }
                if (this.g == null) {
                    d.a(this.e);
                    this.g = new Messenger(new Handler(Looper.getMainLooper()){

                        /*
                         * Enabled force condition propagation
                         * Lifted jumps to return sites
                         */
                        public final void handleMessage(Message message) {
                            d d2 = d.this;
                            if (message == null) return;
                            if (message.obj instanceof Intent) {
                                Intent intent = (Intent)message.obj;
                                intent.setExtrasClassLoader(MessengerCompat.class.getClassLoader());
                                if (intent.hasExtra("google.messenger")) {
                                    if ((intent = intent.getParcelableExtra("google.messenger")) instanceof MessengerCompat) {
                                        d2.i = (MessengerCompat)intent;
                                    }
                                    if (intent instanceof Messenger) {
                                        d2.h = (Messenger)intent;
                                    }
                                }
                                d2.b((Intent)message.obj);
                                return;
                            }
                            Log.w((String)"InstanceID/Rpc", (String)"Dropping invalid message");
                        }
                    });
                }
                if (a == null) {
                    throw new IOException("MISSING_INSTANCEID_SERVICE");
                }
                this.k = SystemClock.elapsedRealtime();
                intent = new Intent("com.google.android.c2dm.intent.REGISTER");
                intent.setPackage(a);
                class_.putString("gmsv", Integer.toString(com.google.android.gms.b.c.b(this.e)));
                class_.putString("osv", Integer.toString(Build.VERSION.SDK_INT));
                class_.putString("app_ver", Integer.toString(a.a(this.e)));
                class_.putString("cliv", "1");
                class_.putString("appid", a.a((KeyPair)object));
                String string2 = a.a(object.getPublic().getEncoded());
                class_.putString("pub2", string2);
                class_.putString("sig", d.a((KeyPair)object, this.e.getPackageName(), string2));
                intent.putExtras((Bundle)class_);
                this.c(intent);
                this.k = SystemClock.elapsedRealtime();
                intent.putExtra("kid", "|ID|" + string + "|");
                intent.putExtra("X-kid", "|ID|" + string + "|");
                bl2 = "com.google.android.gsf".equals(a);
                class_ = intent.getStringExtra("useGsf");
                if (class_ != null) {
                    bl2 = "1".equals(class_);
                }
                if (Log.isLoggable((String)"InstanceID/Rpc", (int)3)) {
                    Log.d((String)"InstanceID/Rpc", (String)("Sending " + (Object)intent.getExtras()));
                }
                if (this.h != null) {
                    intent.putExtra("google.messenger", (Parcelable)this.g);
                    class_ = Message.obtain();
                    class_.obj = intent;
                    try {
                        this.h.send((Message)class_);
                        break block25;
                    }
                    catch (RemoteException var1_2) {
                        if (!Log.isLoggable((String)"InstanceID/Rpc", (int)3)) break block26;
                        Log.d((String)"InstanceID/Rpc", (String)"Messenger failed, fallback to startService");
                    }
                }
            }
            if (bl2) {
                class_ = new Intent("com.google.android.gms.iid.InstanceID");
                class_.setPackage(this.e.getPackageName());
                class_.putExtra("GSF", (Parcelable)intent);
                this.e.startService((Intent)class_);
            } else {
                block27 : {
                    intent.putExtra("google.messenger", (Parcelable)this.g);
                    intent.putExtra("messenger2", "1");
                    if (this.i != null) {
                        class_ = Message.obtain();
                        class_.obj = intent;
                        try {
                            object = this.i;
                            if (object.a != null) {
                                object.a.send(class_);
                            } else {
                                object.b.a((Message)class_);
                            }
                            break block25;
                        }
                        catch (RemoteException var1_3) {
                            if (!Log.isLoggable((String)"InstanceID/Rpc", (int)3)) break block27;
                            Log.d((String)"InstanceID/Rpc", (String)"Messenger failed, fallback to startService");
                        }
                    }
                }
                this.e.startService(intent);
            }
        }
        conditionVariable.block(30000);
        class_ = this.getClass();
        synchronized (class_) {
            object = this.f.remove(string);
            if (object instanceof Intent) {
                return (Intent)object;
            }
            if (object instanceof String) {
                throw new IOException((String)object);
            }
            Log.w((String)"InstanceID/Rpc", (String)("No response " + object));
            throw new IOException("TIMEOUT");
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    final void b(Intent intent) {
        if (intent == null) {
            if (!Log.isLoggable((String)"InstanceID/Rpc", (int)3)) return;
            {
                Log.d((String)"InstanceID/Rpc", (String)"Unexpected response: null");
                return;
            }
        }
        String[] arrstring = intent.getAction();
        if (!"com.google.android.c2dm.intent.REGISTRATION".equals(arrstring) && !"com.google.android.gms.iid.InstanceID".equals(arrstring)) {
            if (!Log.isLoggable((String)"InstanceID/Rpc", (int)3)) return;
            {
                Log.d((String)"InstanceID/Rpc", (String)("Unexpected response " + intent.getAction()));
                return;
            }
        }
        arrstring = intent.getStringExtra("registration_id");
        if (arrstring == null) {
            arrstring = intent.getStringExtra("unregistered");
        }
        if (arrstring == null) {
            long l2;
            Object object = intent.getStringExtra("error");
            if (object == null) {
                Log.w((String)"InstanceID/Rpc", (String)("Unexpected response, no error or registration id " + (Object)intent.getExtras()));
                return;
            }
            if (Log.isLoggable((String)"InstanceID/Rpc", (int)3)) {
                Log.d((String)"InstanceID/Rpc", (String)("Received InstanceID error " + (String)object));
            }
            String string = null;
            String string2 = null;
            arrstring = object;
            if (object.startsWith("|")) {
                arrstring = object.split("\\|");
                if (!"ID".equals(arrstring[1])) {
                    Log.w((String)"InstanceID/Rpc", (String)("Unexpected structured response " + (String)object));
                }
                if (arrstring.length > 2) {
                    string2 = arrstring[2];
                    object = arrstring[3];
                    string = string2;
                    arrstring = object;
                    if (object.startsWith(":")) {
                        arrstring = object.substring(1);
                        string = string2;
                    }
                } else {
                    arrstring = "UNKNOWN";
                    string = string2;
                }
                intent.putExtra("error", (String)arrstring);
            }
            if (string == null) {
                this.a(arrstring);
            } else {
                this.a(string, arrstring);
            }
            if ((l2 = intent.getLongExtra("Retry-After", 0)) > 0) {
                this.l = SystemClock.elapsedRealtime();
                this.n = (int)l2 * 1000;
                this.o = SystemClock.elapsedRealtime() + (long)this.n;
                Log.w((String)"InstanceID/Rpc", (String)("Explicit request from server to backoff: " + this.n));
                return;
            }
            if (!"SERVICE_NOT_AVAILABLE".equals(arrstring) && !"AUTHENTICATION_FAILED".equals(arrstring) || !"com.google.android.gsf".equals(a)) return;
            {
                ++this.m;
                if (this.m < 3) return;
                {
                    if (this.m == 3) {
                        this.n = new Random().nextInt(1000) + 1000;
                    }
                    this.n <<= 1;
                    this.o = SystemClock.elapsedRealtime() + (long)this.n;
                    Log.w((String)"InstanceID/Rpc", (String)("Backoff due to " + (String)arrstring + " for " + this.n));
                    return;
                }
            }
        }
        this.k = SystemClock.elapsedRealtime();
        this.o = 0;
        this.m = 0;
        this.n = 0;
        if (Log.isLoggable((String)"InstanceID/Rpc", (int)3)) {
            Log.d((String)"InstanceID/Rpc", (String)("AppIDResponse: " + (String)arrstring + " " + (Object)intent.getExtras()));
        }
        String string = null;
        if (arrstring.startsWith("|")) {
            String[] arrstring2 = arrstring.split("\\|");
            if (!"ID".equals(arrstring2[1])) {
                Log.w((String)"InstanceID/Rpc", (String)("Unexpected structured response " + (String)arrstring));
            }
            string = arrstring2[2];
            if (arrstring2.length > 4) {
                if ("SYNC".equals(arrstring2[3])) {
                    b.a(this.e);
                } else if ("RST".equals(arrstring2[3])) {
                    arrstring = this.e;
                    a.b(this.e);
                    b.a((Context)arrstring, a.a());
                    intent.removeExtra("registration_id");
                    this.a(string, (Object)intent);
                    return;
                }
            }
            arrstring = arrstring2 = arrstring2[arrstring2.length - 1];
            if (arrstring2.startsWith(":")) {
                arrstring = arrstring2.substring(1);
            }
            intent.putExtra("registration_id", (String)arrstring);
            if (string != null) {
                this.a(string, (Object)intent);
                return;
            }
        }
        this.a((Object)intent);
    }

}

