/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.ApplicationInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Base64
 *  android.util.Log
 */
package com.google.android.gms.iid;

import a.a.a.a.d;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.iid.a;
import com.google.android.gms.iid.b;
import java.io.File;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class e {
    SharedPreferences a;
    Context b;

    public e(Context context) {
        this(context, "com.google.android.gms.appid");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private e(Context object, String string) {
        this.b = object;
        this.a = object.getSharedPreferences(string, 4);
        string = string + "-no-backup";
        new android.support.v4.content.b();
        object = this.b;
        object = Build.VERSION.SDK_INT >= 21 ? object.getNoBackupFilesDir() : android.support.v4.content.b.a(new File(object.getApplicationInfo().dataDir, "no_backup"));
        if ((object = new File((File)object, string)).exists()) return;
        try {
            if (!object.createNewFile() || this.a()) return;
            {
                Log.i((String)"InstanceID/Store", (String)"App restored, clearing state");
                b.a(this.b, this);
                return;
            }
        }
        catch (IOException var1_2) {
            if (!Log.isLoggable((String)"InstanceID/Store", (int)3)) return;
            Log.d((String)"InstanceID/Store", (String)("Error creating file in no backup dir: " + var1_2.getMessage()));
            return;
        }
    }

    private String a(String string, String string2) {
        synchronized (this) {
            string = this.a.getString(string + "|S|" + string2, null);
            return string;
        }
    }

    private void a(SharedPreferences.Editor editor, String string, String string2, String string3) {
        synchronized (this) {
            editor.putString(string + "|S|" + string2, string3);
            return;
        }
    }

    private static String b(String string, String string2, String string3) {
        return string + "|T|" + string2 + "|" + string3;
    }

    final String a(String string) {
        synchronized (this) {
            string = this.a.getString(string, null);
            return string;
        }
    }

    public final String a(String string, String string2, String string3) {
        synchronized (this) {
            string = e.b(string, string2, string3);
            string = this.a.getString(string, null);
            return string;
        }
    }

    final KeyPair a(String string, long l2) {
        synchronized (this) {
            KeyPair keyPair = d.b();
            SharedPreferences.Editor editor = this.a.edit();
            this.a(editor, string, "|P|", a.a(keyPair.getPublic().getEncoded()));
            this.a(editor, string, "|K|", a.a(keyPair.getPrivate().getEncoded()));
            this.a(editor, string, "cre", Long.toString(l2));
            editor.commit();
            return keyPair;
        }
    }

    public final void a(String string, String string2, String string3, String string4, String string5) {
        synchronized (this) {
            string = e.b(string, string2, string3);
            string2 = this.a.edit();
            string2.putString(string, string4);
            string2.putString("appVersion", string5);
            string2.putString("lastToken", Long.toString(System.currentTimeMillis() / 1000));
            string2.commit();
            return;
        }
    }

    final boolean a() {
        return this.a.getAll().isEmpty();
    }

    public final void b() {
        synchronized (this) {
            this.a.edit().clear().commit();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void b(String string) {
        synchronized (this) {
            SharedPreferences.Editor editor = this.a.edit();
            Iterator iterator = this.a.getAll().keySet().iterator();
            do {
                if (!iterator.hasNext()) {
                    editor.commit();
                    return;
                }
                String string2 = (String)iterator.next();
                if (!string2.startsWith(string)) continue;
                editor.remove(string2);
            } while (true);
        }
    }

    public final void c(String string) {
        this.b(string + "|T|");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    final KeyPair d(String var1_1) {
        var2_5 = this.a((String)var1_1, "|P|");
        var3_6 = this.a((String)var1_1, "|K|");
        if (var3_6 == null) {
            return null;
        }
        try {
            var1_1 = Base64.decode((String)var2_5, (int)8);
            var2_5 = Base64.decode((String)var3_6, (int)8);
            var3_6 = KeyFactory.getInstance("RSA");
            return new KeyPair(var3_6.generatePublic(new X509EncodedKeySpec((byte[])var1_1)), var3_6.generatePrivate(new PKCS8EncodedKeySpec(var2_5)));
        }
        catch (InvalidKeySpecException var1_2) {}
        ** GOTO lbl-1000
        catch (NoSuchAlgorithmException var1_4) {}
lbl-1000: // 2 sources:
        {
            Log.w((String)"InstanceID/Store", (String)("Invalid key stored " + var1_3));
            b.a(this.b, this);
            return null;
        }
    }
}

