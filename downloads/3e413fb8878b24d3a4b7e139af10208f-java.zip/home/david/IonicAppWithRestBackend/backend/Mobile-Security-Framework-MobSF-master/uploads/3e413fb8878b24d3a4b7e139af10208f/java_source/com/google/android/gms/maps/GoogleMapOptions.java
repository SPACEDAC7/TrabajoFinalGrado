/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps;

import a.a.a.a.d;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.h;
import com.google.android.gms.maps.model.CameraPosition;

public final class GoogleMapOptions
implements SafeParcelable {
    public static final h CREATOR = new h();
    final int a;
    Boolean b;
    Boolean c;
    int d = -1;
    CameraPosition e;
    Boolean f;
    Boolean g;
    Boolean h;
    Boolean i;
    Boolean j;
    Boolean k;
    Boolean l;
    Boolean m;

    public GoogleMapOptions() {
        this.a = 1;
    }

    GoogleMapOptions(int n2, byte by2, byte by3, int n3, CameraPosition cameraPosition, byte by4, byte by5, byte by6, byte by7, byte by8, byte by9, byte by10, byte by11) {
        this.a = n2;
        this.b = d.a(by2);
        this.c = d.a(by3);
        this.d = n3;
        this.e = cameraPosition;
        this.f = d.a(by4);
        this.g = d.a(by5);
        this.h = d.a(by6);
        this.i = d.a(by7);
        this.j = d.a(by8);
        this.k = d.a(by9);
        this.l = d.a(by10);
        this.m = d.a(by11);
    }

    public final GoogleMapOptions a() {
        this.d = 1;
        return this;
    }

    public final GoogleMapOptions a(CameraPosition cameraPosition) {
        this.e = cameraPosition;
        return this;
    }

    public final GoogleMapOptions a(boolean bl2) {
        this.g = bl2;
        return this;
    }

    public final GoogleMapOptions b() {
        this.f = false;
        return this;
    }

    public final GoogleMapOptions b(boolean bl2) {
        this.i = bl2;
        return this;
    }

    public final GoogleMapOptions c() {
        this.h = false;
        return this;
    }

    public final GoogleMapOptions c(boolean bl2) {
        this.j = bl2;
        return this;
    }

    public final GoogleMapOptions d() {
        this.l = true;
        return this;
    }

    public final GoogleMapOptions d(boolean bl2) {
        this.k = bl2;
        return this;
    }

    public final int describeContents() {
        return 0;
    }

    public final GoogleMapOptions e() {
        this.m = false;
        return this;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        h.a(this, parcel, n2);
    }
}

