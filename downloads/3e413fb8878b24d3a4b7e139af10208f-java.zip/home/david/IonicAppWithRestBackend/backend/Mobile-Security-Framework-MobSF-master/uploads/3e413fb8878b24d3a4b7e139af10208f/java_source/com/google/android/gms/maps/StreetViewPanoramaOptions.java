/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps;

import a.a.a.a.d;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.i;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.StreetViewPanoramaCamera;

public final class StreetViewPanoramaOptions
implements SafeParcelable {
    public static final i CREATOR = new i();
    final int a;
    StreetViewPanoramaCamera b;
    String c;
    LatLng d;
    Integer e;
    Boolean f = true;
    Boolean g = true;
    Boolean h = true;
    Boolean i = true;
    Boolean j;

    public StreetViewPanoramaOptions() {
        this.a = 1;
    }

    StreetViewPanoramaOptions(int n2, StreetViewPanoramaCamera streetViewPanoramaCamera, String string, LatLng latLng, Integer n3, byte by2, byte by3, byte by4, byte by5, byte by6) {
        this.a = n2;
        this.b = streetViewPanoramaCamera;
        this.d = latLng;
        this.e = n3;
        this.c = string;
        this.f = d.a(by2);
        this.g = d.a(by3);
        this.h = d.a(by4);
        this.i = d.a(by5);
        this.j = d.a(by6);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        i.a(this, parcel, n2);
    }
}

