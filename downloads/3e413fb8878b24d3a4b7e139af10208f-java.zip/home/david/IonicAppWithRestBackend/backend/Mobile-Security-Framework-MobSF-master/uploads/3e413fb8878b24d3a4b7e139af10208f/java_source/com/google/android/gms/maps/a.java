/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.maps;

import a.a.a.a.d;
import com.google.android.gms.a.c;

public final class a {
    final c a;

    public a(c c2) {
        this.a = d.d(c2);
    }
}

