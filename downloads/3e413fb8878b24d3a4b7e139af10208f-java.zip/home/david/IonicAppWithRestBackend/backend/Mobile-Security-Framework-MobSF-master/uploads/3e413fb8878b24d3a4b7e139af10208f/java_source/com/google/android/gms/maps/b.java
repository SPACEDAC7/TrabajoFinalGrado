/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  android.location.Location
 *  android.os.RemoteException
 */
package com.google.android.gms.maps;

import android.app.Activity;
import android.content.Intent;
import android.location.Location;
import android.os.RemoteException;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.a.j;
import com.google.android.gms.maps.a.k;
import com.google.android.gms.maps.a.n;
import com.google.android.gms.maps.a.p;
import com.google.android.gms.maps.a.r;
import com.google.android.gms.maps.a.v;
import com.google.android.gms.maps.g;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.whatsapp.PlaceInfo;
import com.whatsapp.ait;
import com.whatsapp.data.h;
import com.whatsapp.location.aw;
import com.whatsapp.yt;
import java.io.Serializable;
import java.util.ArrayList;

public final class b {
    private final com.google.android.gms.maps.a.b a;
    private g b;

    protected b(com.google.android.gms.maps.a.b b2) {
        this.a = a.a.a.a.d.d(b2);
    }

    public final CameraPosition a() {
        try {
            CameraPosition cameraPosition = this.a.a();
            return cameraPosition;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final com.google.android.gms.maps.model.b a(MarkerOptions object) {
        block3 : {
            try {
                object = this.a.a((MarkerOptions)object);
                if (object == null) break block3;
            }
            catch (RemoteException var1_2) {
                throw new Fragment.a(var1_2);
            }
            object = new com.google.android.gms.maps.model.b((com.google.android.gms.maps.model.a.f)object);
            return object;
        }
        return null;
    }

    public final void a(int n2) {
        try {
            this.a.a(n2);
            return;
        }
        catch (RemoteException var2_2) {
            throw new Fragment.a(var2_2);
        }
    }

    public final void a(int n2, int n3, int n4, int n5) {
        try {
            this.a.a(n2, n3, n4, n5);
            return;
        }
        catch (RemoteException var5_5) {
            throw new Fragment.a(var5_5);
        }
    }

    public final void a(com.google.android.gms.maps.a a2) {
        try {
            this.a.a(a2.a);
            return;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void a(com.google.android.gms.maps.a a2, a a3) {
        try {
            this.a.a(a2.a, new f(a3));
            return;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void a(final b b2) {
        try {
            this.a.a(new n.a(){

                @Override
                public final void a(CameraPosition cameraPosition) {
                    b2.a(cameraPosition);
                }
            });
            return;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void a(final c c2) {
        try {
            this.a.a(new p.a(){

                /*
                 * Enabled aggressive block sorting
                 */
                @Override
                public final void a(com.google.android.gms.maps.model.a.f object) {
                    Object object2 = c2;
                    Object object3 = new com.google.android.gms.maps.model.b((com.google.android.gms.maps.model.a.f)object);
                    object2 = object2.a;
                    if (object3.a() != null) {
                        void var1_4;
                        block4 : {
                            for (PlaceInfo placeInfo : object2.j.c) {
                                if (!object3.equals(placeInfo.tag)) continue;
                                break block4;
                            }
                            Object var1_5 = null;
                        }
                        if (var1_4 == null) return;
                        if (object2.l != null) {
                            long l2 = object2.b.getIntent().getLongExtra("quoted_message_row_id", 0);
                            object3 = l2 != 0 ? object2.n.a(l2) : null;
                            object2.m.a(object2.l, (PlaceInfo)var1_4, (com.whatsapp.protocol.j)object3, object2.b.getIntent().getBooleanExtra("has_number_from_url", false));
                        } else {
                            object3 = new Intent();
                            object3.putExtra("place", (Serializable)var1_4);
                            object2.b.setResult(-1, (Intent)object3);
                        }
                        object2.a(4);
                        object2.b.finish();
                    }
                }
            });
            return;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void a(final d d2) {
        try {
            this.a.a(new r.a(){

                @Override
                public final void a(LatLng latLng) {
                    d2.a();
                }
            });
            return;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void a(final e e2) {
        try {
            this.a.a(new v.a(){

                @Override
                public final boolean a(com.google.android.gms.maps.model.a.f f2) {
                    return e2.a(new com.google.android.gms.maps.model.b(f2));
                }
            });
            return;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void a(boolean bl2) {
        try {
            this.a.a(bl2);
            return;
        }
        catch (RemoteException var2_2) {
            throw new Fragment.a(var2_2);
        }
    }

    public final void b() {
        try {
            this.a.d();
            return;
        }
        catch (RemoteException var1_1) {
            throw new Fragment.a(var1_1);
        }
    }

    public final void b(com.google.android.gms.maps.a a2) {
        try {
            this.a.b(a2.a);
            return;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void c() {
        try {
            this.a.e();
            return;
        }
        catch (RemoteException var1_1) {
            throw new Fragment.a(var1_1);
        }
    }

    public final boolean d() {
        try {
            boolean bl2 = this.a.g();
            return bl2;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final boolean e() {
        try {
            boolean bl2 = this.a.b(true);
            return bl2;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final boolean f() {
        try {
            boolean bl2 = this.a.i();
            return bl2;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void g() {
        try {
            this.a.c(true);
            return;
        }
        catch (RemoteException var1_1) {
            throw new Fragment.a(var1_1);
        }
    }

    @Deprecated
    public final Location h() {
        try {
            Location location = this.a.j();
            return location;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final g i() {
        try {
            if (this.b == null) {
                this.b = new g(this.a.k());
            }
            g g2 = this.b;
            return g2;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final com.google.android.gms.maps.f j() {
        try {
            com.google.android.gms.maps.f f2 = new com.google.android.gms.maps.f(this.a.l());
            return f2;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public static interface a {
        public void a();

        public void b();
    }

    public static interface b {
        public void a(CameraPosition var1);
    }

    public static final class c {
        public final aw a;

        public c(aw aw2) {
            this.a = aw2;
        }
    }

    public static interface d {
        public void a();
    }

    public static interface e {
        public boolean a(com.google.android.gms.maps.model.b var1);
    }

    static final class f
    extends k.a {
        private final a a;

        f(a a2) {
            this.a = a2;
        }

        @Override
        public final void a() {
            this.a.a();
        }

        @Override
        public final void b() {
            this.a.b();
        }
    }

}

