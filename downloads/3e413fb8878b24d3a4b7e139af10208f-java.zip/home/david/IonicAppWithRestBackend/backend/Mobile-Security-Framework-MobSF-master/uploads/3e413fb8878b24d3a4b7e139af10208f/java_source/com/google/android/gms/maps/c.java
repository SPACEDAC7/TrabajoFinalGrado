/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.RemoteException
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.Button
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.TextView
 */
package com.google.android.gms.maps;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.a.b;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.a.ag;
import com.google.android.gms.maps.a.u;
import com.google.android.gms.maps.d;
import com.google.android.gms.maps.e;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.whatsapp.aiq;
import com.whatsapp.js;
import com.whatsapp.protocol.j;
import java.util.ArrayList;
import java.util.List;

public class c
extends FrameLayout {
    private final b a;
    private com.google.android.gms.maps.b b;

    public c(Context context, GoogleMapOptions googleMapOptions) {
        super(context);
        this.a = new b((ViewGroup)this, context, googleMapOptions);
        this.setClickable(true);
    }

    public final void a() {
        b b2 = this.a;
        b2.a(null, new b.a((com.google.android.gms.a.b)b2){

            @Override
            public final int a() {
                return 5;
            }

            @Override
            public final void b() {
                b.this.a.a();
            }
        });
    }

    public final void a(Bundle bundle) {
        Object object = this.a;
        object.a(bundle, new b.a(bundle){
            final /* synthetic */ Bundle a;

            @Override
            public final int a() {
                return 1;
            }

            @Override
            public final void b() {
                b.this.a.a(this.a);
            }
        });
        if (this.a.a == null) {
            bundle = this.getContext();
            int n2 = com.google.android.gms.common.e.a((Context)bundle);
            String string = a.a.a.a.d.a((Context)bundle, n2, com.google.android.gms.common.e.e((Context)bundle));
            object = a.a.a.a.d.a((Context)bundle, n2);
            LinearLayout linearLayout = new LinearLayout(this.getContext());
            linearLayout.setOrientation(1);
            linearLayout.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -2));
            this.addView((View)linearLayout);
            TextView textView = new TextView(this.getContext());
            textView.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -2));
            textView.setText((CharSequence)string);
            linearLayout.addView((View)textView);
            if (object != null) {
                string = new Button((Context)bundle);
                string.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -2));
                string.setText((CharSequence)object);
                linearLayout.addView((View)string);
                string.setOnClickListener(new View.OnClickListener((Context)bundle, n2){
                    final /* synthetic */ Context a;
                    final /* synthetic */ int b;

                    public final void onClick(View view) {
                        this.a.startActivity(com.google.android.gms.common.e.a(this.b));
                    }
                });
            }
        }
    }

    public final void a(e e2) {
        a.a.a.a.d.h("getMapAsync() must be called on the main thread");
        b b2 = this.a;
        if (b2.a != null) {
            ((a)b2.a).a(e2);
            return;
        }
        b2.e.add(e2);
    }

    public final void b() {
        b b2 = this.a;
        if (b2.a != null) {
            b2.a.b();
            return;
        }
        b2.a(5);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void b(Bundle bundle) {
        b b2 = this.a;
        if (b2.a != null) {
            b2.a.b(bundle);
            return;
        } else {
            if (b2.b == null) return;
            {
                bundle.putAll(b2.b);
                return;
            }
        }
    }

    public final void c() {
        b b2 = this.a;
        if (b2.a != null) {
            b2.a.c();
            return;
        }
        b2.a(1);
    }

    public final void d() {
        b b2 = this.a;
        if (b2.a != null) {
            b2.a.d();
        }
    }

    @Deprecated
    public final com.google.android.gms.maps.b getMap() {
        if (this.b != null) {
            return this.b;
        }
        this.a.a();
        if (this.a.a == null) {
            return null;
        }
        try {
            this.b = new com.google.android.gms.maps.b(((a)this.a.a).a.a());
            return this.b;
        }
        catch (RemoteException var1_1) {
            throw new Fragment.a(var1_1);
        }
    }

    static final class a
    implements com.google.android.gms.a.a {
        final com.google.android.gms.maps.a.e a;
        private final ViewGroup b;
        private View c;

        public a(ViewGroup viewGroup, com.google.android.gms.maps.a.e e2) {
            this.a = a.a.a.a.d.d(e2);
            this.b = a.a.a.a.d.d(viewGroup);
        }

        @Override
        public final void a() {
            try {
                this.a.b();
                return;
            }
            catch (RemoteException var1_1) {
                throw new Fragment.a(var1_1);
            }
        }

        @Override
        public final void a(Bundle bundle) {
            try {
                this.a.a(bundle);
                this.c = (View)com.google.android.gms.a.d.a(this.a.f());
                this.b.removeAllViews();
                this.b.addView(this.c);
                return;
            }
            catch (RemoteException var1_2) {
                throw new Fragment.a(var1_2);
            }
        }

        public final void a(final e e2) {
            try {
                this.a.a(new u.a(){

                    @Override
                    public final void a(com.google.android.gms.maps.a.b object) {
                        Object object2 = e2;
                        object = new com.google.android.gms.maps.b((com.google.android.gms.maps.a.b)object);
                        object2 = object2.a;
                        object2 = new LatLng(object2.a.A, object2.a.B);
                        if (js.A == null) {
                            js.A = a.a.a.a.d.d();
                        }
                        Object object3 = new MarkerOptions();
                        object3.b = object2;
                        object3.e = js.A;
                        object.c();
                        object.a((MarkerOptions)object3);
                        int n2 = (int)(aiq.a().a * 2.0f);
                        object.a(0, n2 * 2, n2, n2);
                        object3 = new CameraPosition.a();
                        object3.a = object2;
                        object3.b = 15.0f;
                        object.a(a.a.a.a.d.a(object3.a()));
                    }
                });
                return;
            }
            catch (RemoteException var1_2) {
                throw new Fragment.a(var1_2);
            }
        }

        @Override
        public final void b() {
            try {
                this.a.c();
                return;
            }
            catch (RemoteException var1_1) {
                throw new Fragment.a(var1_1);
            }
        }

        @Override
        public final void b(Bundle bundle) {
            try {
                this.a.b(bundle);
                return;
            }
            catch (RemoteException var1_2) {
                throw new Fragment.a(var1_2);
            }
        }

        @Override
        public final void c() {
            try {
                this.a.d();
                return;
            }
            catch (RemoteException var1_1) {
                throw new Fragment.a(var1_1);
            }
        }

        @Override
        public final void d() {
            try {
                this.a.e();
                return;
            }
            catch (RemoteException var1_1) {
                throw new Fragment.a(var1_1);
            }
        }

    }

    static final class b
    extends com.google.android.gms.a.b<a> {
        protected com.google.android.gms.a.e<a> d;
        final List<e> e = new ArrayList<e>();
        private final ViewGroup f;
        private final Context g;
        private final GoogleMapOptions h;

        b(ViewGroup viewGroup, Context context, GoogleMapOptions googleMapOptions) {
            this.f = viewGroup;
            this.g = context;
            this.h = googleMapOptions;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public final void a() {
            if (this.d != null && this.a == null) {
                try {
                    d.a(this.g);
                    com.google.android.gms.maps.a.e e2 = ag.a(this.g).a(com.google.android.gms.a.d.a(this.g), this.h);
                    if (e2 == null) {
                        return;
                    }
                    this.d.a(new a(this.f, e2));
                    for (e e3 : this.e) {
                        ((a)this.a).a(e3);
                    }
                    this.e.clear();
                    return;
                }
                catch (RemoteException var1_2) {
                    throw new Fragment.a(var1_2);
                }
                catch (com.google.android.gms.common.c var1_3) {
                    // empty catch block
                }
            }
        }

        @Override
        protected final void a(com.google.android.gms.a.e<a> e2) {
            this.d = e2;
            this.a();
        }
    }

}

