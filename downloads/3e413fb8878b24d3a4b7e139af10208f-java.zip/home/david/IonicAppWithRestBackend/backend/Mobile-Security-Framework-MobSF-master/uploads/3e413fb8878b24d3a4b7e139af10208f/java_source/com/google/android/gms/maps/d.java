/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.RemoteException
 */
package com.google.android.gms.maps;

import android.content.Context;
import android.os.RemoteException;
import android.support.v4.app.Fragment;
import com.google.android.gms.common.c;
import com.google.android.gms.maps.a.a;
import com.google.android.gms.maps.a.ag;
import com.google.android.gms.maps.model.a.b;

public final class d {
    private static boolean a = false;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static int a(Context object) {
        synchronized (d.class) {
            block8 : {
                a.a.a.a.d.b(object, (Object)"Context is null");
                boolean bl2 = a;
                if (bl2) {
                    return 0;
                }
                try {
                    object = ag.a((Context)object);
                }
                catch (c var0_1) {
                    return var0_1.a;
                }
                try {
                    a.a.a.a.d.bf = a.a.a.a.d.d(object.a());
                    object = object.b();
                    if (a.a.a.a.d.bg != null) break block8;
                    a.a.a.a.d.bg = (b)a.a.a.a.d.d(object);
                }
                catch (RemoteException var0_2) {
                    throw new Fragment.a(var0_2);
                }
            }
            a = true;
            return 0;
        }
    }
}

