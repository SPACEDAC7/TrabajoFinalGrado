/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.maps;

import com.whatsapp.js;

public final class e {
    public final js a;

    public e(js js2) {
        this.a = js2;
    }
}

