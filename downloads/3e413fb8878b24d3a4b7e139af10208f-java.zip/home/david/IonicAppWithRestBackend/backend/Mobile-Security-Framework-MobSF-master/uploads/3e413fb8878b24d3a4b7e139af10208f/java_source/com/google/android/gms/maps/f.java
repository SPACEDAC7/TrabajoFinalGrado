/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  android.os.RemoteException
 */
package com.google.android.gms.maps;

import android.graphics.Point;
import android.os.RemoteException;
import android.support.v4.app.Fragment;
import com.google.android.gms.a.c;
import com.google.android.gms.a.d;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.VisibleRegion;

public final class f {
    private final com.google.android.gms.maps.a.f a;

    f(com.google.android.gms.maps.a.f f2) {
        this.a = f2;
    }

    public final Point a(LatLng latLng) {
        try {
            latLng = (Point)d.a(this.a.a(latLng));
            return latLng;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final VisibleRegion a() {
        try {
            VisibleRegion visibleRegion = this.a.a();
            return visibleRegion;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }
}

