/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.RemoteException
 */
package com.google.android.gms.maps;

import android.os.RemoteException;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.a.j;

public final class g {
    private final j a;

    g(j j2) {
        this.a = j2;
    }

    public final void a() {
        try {
            this.a.a(false);
            return;
        }
        catch (RemoteException var1_1) {
            throw new Fragment.a(var1_1);
        }
    }

    public final void b() {
        try {
            this.a.b(true);
            return;
        }
        catch (RemoteException var1_1) {
            throw new Fragment.a(var1_1);
        }
    }

    public final void c() {
        try {
            this.a.c(false);
            return;
        }
        catch (RemoteException var1_1) {
            throw new Fragment.a(var1_1);
        }
    }
}

