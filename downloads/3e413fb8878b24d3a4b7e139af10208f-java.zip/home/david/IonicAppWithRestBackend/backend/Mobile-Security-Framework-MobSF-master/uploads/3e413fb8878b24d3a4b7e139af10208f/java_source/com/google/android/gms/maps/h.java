/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.d;

public final class h
implements Parcelable.Creator<GoogleMapOptions> {
    public static GoogleMapOptions a(Parcel parcel) {
        int n2 = a.a.a.a.d.a(parcel);
        int n3 = 0;
        byte by2 = -1;
        byte by3 = -1;
        int n4 = 0;
        CameraPosition cameraPosition = null;
        byte by4 = -1;
        byte by5 = -1;
        byte by6 = -1;
        byte by7 = -1;
        byte by8 = -1;
        byte by9 = -1;
        byte by10 = -1;
        byte by11 = -1;
        block15 : while (parcel.dataPosition() < n2) {
            int n5 = parcel.readInt();
            switch (65535 & n5) {
                default: {
                    a.a.a.a.d.b(parcel, n5);
                    continue block15;
                }
                case 1: {
                    n3 = a.a.a.a.d.e(parcel, n5);
                    continue block15;
                }
                case 2: {
                    by2 = a.a.a.a.d.d(parcel, n5);
                    continue block15;
                }
                case 3: {
                    by3 = a.a.a.a.d.d(parcel, n5);
                    continue block15;
                }
                case 4: {
                    n4 = a.a.a.a.d.e(parcel, n5);
                    continue block15;
                }
                case 5: {
                    cameraPosition = (CameraPosition)a.a.a.a.d.a(parcel, n5, CameraPosition.CREATOR);
                    continue block15;
                }
                case 6: {
                    by4 = a.a.a.a.d.d(parcel, n5);
                    continue block15;
                }
                case 7: {
                    by5 = a.a.a.a.d.d(parcel, n5);
                    continue block15;
                }
                case 8: {
                    by6 = a.a.a.a.d.d(parcel, n5);
                    continue block15;
                }
                case 9: {
                    by7 = a.a.a.a.d.d(parcel, n5);
                    continue block15;
                }
                case 10: {
                    by8 = a.a.a.a.d.d(parcel, n5);
                    continue block15;
                }
                case 11: {
                    by9 = a.a.a.a.d.d(parcel, n5);
                    continue block15;
                }
                case 12: {
                    by10 = a.a.a.a.d.d(parcel, n5);
                    continue block15;
                }
                case 14: 
            }
            by11 = a.a.a.a.d.d(parcel, n5);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new GoogleMapOptions(n3, by2, by3, n4, cameraPosition, by4, by5, by6, by7, by8, by9, by10, by11);
    }

    static void a(GoogleMapOptions googleMapOptions, Parcel parcel, int n2) {
        int n3 = a.a.a.a.d.m(parcel, 20293);
        a.a.a.a.d.c(parcel, 1, googleMapOptions.a);
        a.a.a.a.d.a(parcel, 2, a.a.a.a.d.a(googleMapOptions.b));
        a.a.a.a.d.a(parcel, 3, a.a.a.a.d.a(googleMapOptions.c));
        a.a.a.a.d.c(parcel, 4, googleMapOptions.d);
        a.a.a.a.d.a(parcel, 5, googleMapOptions.e, n2);
        a.a.a.a.d.a(parcel, 6, a.a.a.a.d.a(googleMapOptions.f));
        a.a.a.a.d.a(parcel, 7, a.a.a.a.d.a(googleMapOptions.g));
        a.a.a.a.d.a(parcel, 8, a.a.a.a.d.a(googleMapOptions.h));
        a.a.a.a.d.a(parcel, 9, a.a.a.a.d.a(googleMapOptions.i));
        a.a.a.a.d.a(parcel, 10, a.a.a.a.d.a(googleMapOptions.j));
        a.a.a.a.d.a(parcel, 11, a.a.a.a.d.a(googleMapOptions.k));
        a.a.a.a.d.a(parcel, 12, a.a.a.a.d.a(googleMapOptions.l));
        a.a.a.a.d.a(parcel, 14, a.a.a.a.d.a(googleMapOptions.m));
        a.a.a.a.d.n(parcel, n3);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return h.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new GoogleMapOptions[n2];
    }
}

