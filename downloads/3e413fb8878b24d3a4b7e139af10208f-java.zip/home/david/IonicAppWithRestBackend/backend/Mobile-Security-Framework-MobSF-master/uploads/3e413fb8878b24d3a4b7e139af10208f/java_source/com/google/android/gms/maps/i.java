/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.StreetViewPanoramaOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.StreetViewPanoramaCamera;
import com.google.android.gms.maps.model.h;
import com.google.android.gms.maps.model.m;

public final class i
implements Parcelable.Creator<StreetViewPanoramaOptions> {
    public static StreetViewPanoramaOptions a(Parcel parcel) {
        byte by2 = 0;
        int n2 = d.a(parcel);
        byte by3 = 0;
        byte by4 = 0;
        byte by5 = 0;
        byte by6 = 0;
        Integer n3 = null;
        LatLng latLng = null;
        String string = null;
        StreetViewPanoramaCamera streetViewPanoramaCamera = null;
        int n4 = 0;
        block12 : while (parcel.dataPosition() < n2) {
            int n5 = parcel.readInt();
            switch (65535 & n5) {
                default: {
                    d.b(parcel, n5);
                    continue block12;
                }
                case 1: {
                    n4 = d.e(parcel, n5);
                    continue block12;
                }
                case 2: {
                    streetViewPanoramaCamera = (StreetViewPanoramaCamera)d.a(parcel, n5, StreetViewPanoramaCamera.CREATOR);
                    continue block12;
                }
                case 3: {
                    string = d.i(parcel, n5);
                    continue block12;
                }
                case 4: {
                    latLng = (LatLng)d.a(parcel, n5, LatLng.CREATOR);
                    continue block12;
                }
                case 5: {
                    n5 = d.a(parcel, n5);
                    if (n5 == 0) {
                        n3 = null;
                        continue block12;
                    }
                    if (n5 != 4) {
                        throw new Fragment.a("Expected size 4 got " + n5 + " (0x" + Integer.toHexString(n5) + ")", parcel);
                    }
                    n3 = parcel.readInt();
                    continue block12;
                }
                case 6: {
                    by6 = d.d(parcel, n5);
                    continue block12;
                }
                case 7: {
                    by5 = d.d(parcel, n5);
                    continue block12;
                }
                case 8: {
                    by4 = d.d(parcel, n5);
                    continue block12;
                }
                case 9: {
                    by3 = d.d(parcel, n5);
                    continue block12;
                }
                case 10: 
            }
            by2 = d.d(parcel, n5);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new StreetViewPanoramaOptions(n4, streetViewPanoramaCamera, string, latLng, n3, by6, by5, by4, by3, by2);
    }

    static void a(StreetViewPanoramaOptions streetViewPanoramaOptions, Parcel parcel, int n2) {
        int n3 = d.m(parcel, 20293);
        d.c(parcel, 1, streetViewPanoramaOptions.a);
        d.a(parcel, 2, streetViewPanoramaOptions.b, n2);
        d.a(parcel, 3, streetViewPanoramaOptions.c);
        d.a(parcel, 4, streetViewPanoramaOptions.d, n2);
        Integer n4 = streetViewPanoramaOptions.e;
        if (n4 != null) {
            d.b(parcel, 5, 4);
            parcel.writeInt(n4.intValue());
        }
        d.a(parcel, 6, d.a(streetViewPanoramaOptions.f));
        d.a(parcel, 7, d.a(streetViewPanoramaOptions.g));
        d.a(parcel, 8, d.a(streetViewPanoramaOptions.h));
        d.a(parcel, 9, d.a(streetViewPanoramaOptions.i));
        d.a(parcel, 10, d.a(streetViewPanoramaOptions.j));
        d.n(parcel, n3);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return i.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new StreetViewPanoramaOptions[n2];
    }
}

