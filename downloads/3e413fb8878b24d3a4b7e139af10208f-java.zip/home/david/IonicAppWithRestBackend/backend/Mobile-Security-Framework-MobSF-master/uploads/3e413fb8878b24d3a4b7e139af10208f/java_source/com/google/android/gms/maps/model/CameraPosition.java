/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import android.os.Parcel;
import com.google.android.gms.common.internal.s;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.d;
import java.util.Arrays;

public final class CameraPosition
implements SafeParcelable {
    public static final d CREATOR = new d();
    final int a;
    public final LatLng b;
    public final float c;
    public final float d;
    public final float e;

    /*
     * Enabled aggressive block sorting
     */
    CameraPosition(int n2, LatLng latLng, float f2, float f3, float f4) {
        a.a.a.a.d.b(latLng, (Object)"null camera target");
        boolean bl2 = 0.0f <= f3 && f3 <= 90.0f;
        a.a.a.a.d.a(bl2, "Tilt needs to be between 0 and 90 inclusive: %s", Float.valueOf(f3));
        this.a = n2;
        this.b = latLng;
        this.c = f2;
        this.d = f3 + 0.0f;
        f2 = f4;
        if ((double)f4 <= 0.0) {
            f2 = f4 % 360.0f + 360.0f;
        }
        this.e = f2 % 360.0f;
    }

    public CameraPosition(LatLng latLng, float f2, float f3, float f4) {
        this(1, latLng, f2, f3, f4);
    }

    public static a a() {
        return new a();
    }

    public final int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof CameraPosition)) {
            return false;
        }
        object = (CameraPosition)object;
        if (!this.b.equals(object.b)) return false;
        if (Float.floatToIntBits(this.c) != Float.floatToIntBits(object.c)) return false;
        if (Float.floatToIntBits(this.d) != Float.floatToIntBits(object.d)) return false;
        if (Float.floatToIntBits(this.e) == Float.floatToIntBits(object.e)) return true;
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.b, Float.valueOf(this.c), Float.valueOf(this.d), Float.valueOf(this.e)});
    }

    public final String toString() {
        return a.a.a.a.d.c(this).a("target", this.b).a("zoom", Float.valueOf(this.c)).a("tilt", Float.valueOf(this.d)).a("bearing", Float.valueOf(this.e)).toString();
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        d.a(this, parcel, n2);
    }

    public static final class a {
        public LatLng a;
        public float b;
        private float c;
        private float d;

        public final a a(float f2) {
            this.b = f2;
            return this;
        }

        public final a a(LatLng latLng) {
            this.a = latLng;
            return this;
        }

        public final CameraPosition a() {
            return new CameraPosition(this.a, this.b, this.c, this.d);
        }

        public final a b(float f2) {
            this.c = f2;
            return this;
        }

        public final a c(float f2) {
            this.d = f2;
            return this;
        }
    }

}

