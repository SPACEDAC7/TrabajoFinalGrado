/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.e;

public final class CircleOptions
implements SafeParcelable {
    public static final e CREATOR = new e();
    final int a;
    LatLng b = null;
    double c = 0.0;
    float d = 10.0f;
    int e = -16777216;
    int f = 0;
    float g = 0.0f;
    boolean h = true;

    public CircleOptions() {
        this.a = 1;
    }

    CircleOptions(int n2, LatLng latLng, double d2, float f2, int n3, int n4, float f3, boolean bl2) {
        this.a = n2;
        this.b = latLng;
        this.c = d2;
        this.d = f2;
        this.e = n3;
        this.f = n4;
        this.g = f3;
        this.h = bl2;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        e.a(this, parcel, n2);
    }
}

