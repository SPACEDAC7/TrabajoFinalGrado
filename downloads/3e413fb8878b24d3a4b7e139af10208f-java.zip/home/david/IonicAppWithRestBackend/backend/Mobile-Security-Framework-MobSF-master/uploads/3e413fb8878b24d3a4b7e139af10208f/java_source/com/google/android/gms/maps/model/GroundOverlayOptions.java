/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.a.c;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.a;
import com.google.android.gms.maps.model.f;

public final class GroundOverlayOptions
implements SafeParcelable {
    public static final f CREATOR = new f();
    final int a;
    a b;
    LatLng c;
    float d;
    float e;
    LatLngBounds f;
    float g;
    float h;
    boolean i = true;
    float j = 0.0f;
    float k = 0.5f;
    float l = 0.5f;

    public GroundOverlayOptions() {
        this.a = 1;
    }

    GroundOverlayOptions(int n2, IBinder iBinder, LatLng latLng, float f2, float f3, LatLngBounds latLngBounds, float f4, float f5, boolean bl2, float f6, float f7, float f8) {
        this.a = n2;
        this.b = new a(c.a.a(iBinder));
        this.c = latLng;
        this.d = f2;
        this.e = f3;
        this.f = latLngBounds;
        this.g = f4;
        this.h = f5;
        this.i = bl2;
        this.j = f6;
        this.k = f7;
        this.l = f8;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        f.a(this, parcel, n2);
    }
}

