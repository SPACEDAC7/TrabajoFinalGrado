/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.h;

public final class LatLng
implements SafeParcelable {
    public static final h CREATOR = new h();
    final int a;
    public final double b;
    public final double c;

    public LatLng(double d2, double d3) {
        this(1, d2, d3);
    }

    /*
     * Enabled aggressive block sorting
     */
    LatLng(int n2, double d2, double d3) {
        this.a = n2;
        this.c = -180.0 <= d3 && d3 < 180.0 ? d3 : ((d3 - 180.0) % 360.0 + 360.0) % 360.0 - 180.0;
        this.b = Math.max(-90.0, Math.min(90.0, d2));
    }

    public final int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof LatLng)) {
            return false;
        }
        object = (LatLng)object;
        if (Double.doubleToLongBits(this.b) != Double.doubleToLongBits(object.b)) return false;
        if (Double.doubleToLongBits(this.c) == Double.doubleToLongBits(object.c)) return true;
        return false;
    }

    public final int hashCode() {
        long l2 = Double.doubleToLongBits(this.b);
        int n2 = (int)(l2 ^ l2 >>> 32);
        l2 = Double.doubleToLongBits(this.c);
        return (n2 + 31) * 31 + (int)(l2 ^ l2 >>> 32);
    }

    public final String toString() {
        return "lat/lng: (" + this.b + "," + this.c + ")";
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        h.a(this, parcel);
    }
}

