/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import com.google.android.gms.common.internal.s;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.g;
import java.util.Arrays;

public final class LatLngBounds
implements SafeParcelable {
    public static final g CREATOR = new g();
    final int a;
    public final LatLng b;
    public final LatLng c;

    /*
     * Enabled aggressive block sorting
     */
    LatLngBounds(int n2, LatLng latLng, LatLng latLng2) {
        d.b(latLng, (Object)"null southwest");
        d.b(latLng2, (Object)"null northeast");
        boolean bl2 = latLng2.b >= latLng.b;
        d.a(bl2, "southern latitude exceeds northern latitude (%s > %s)", latLng.b, latLng2.b);
        this.a = n2;
        this.b = latLng;
        this.c = latLng2;
    }

    public LatLngBounds(LatLng latLng, LatLng latLng2) {
        this(1, latLng, latLng2);
    }

    public final int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof LatLngBounds)) {
            return false;
        }
        object = (LatLngBounds)object;
        if (!this.b.equals(object.b)) return false;
        if (this.c.equals(object.c)) return true;
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.b, this.c});
    }

    public final String toString() {
        return d.c(this).a("southwest", this.b).a("northeast", this.c).toString();
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        g.a(this, parcel, n2);
    }
}

