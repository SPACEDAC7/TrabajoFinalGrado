/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.a.c;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.a;
import com.google.android.gms.maps.model.i;

public final class MarkerOptions
implements SafeParcelable {
    public static final i CREATOR = new i();
    final int a;
    public LatLng b;
    String c;
    String d;
    public a e;
    float f = 0.5f;
    float g = 1.0f;
    boolean h;
    boolean i = true;
    boolean j = false;
    float k = 0.0f;
    float l = 0.5f;
    float m = 0.0f;
    float n = 1.0f;

    public MarkerOptions() {
        this.a = 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    MarkerOptions(int n2, LatLng object, String string, String string2, IBinder iBinder, float f2, float f3, boolean bl2, boolean bl3, boolean bl4, float f4, float f5, float f6, float f7) {
        this.a = n2;
        this.b = object;
        this.c = string;
        this.d = string2;
        object = iBinder == null ? null : new a(c.a.a(iBinder));
        this.e = object;
        this.f = f2;
        this.g = f3;
        this.h = bl2;
        this.i = bl3;
        this.j = bl4;
        this.k = f4;
        this.l = f5;
        this.m = f6;
        this.n = f7;
    }

    public final MarkerOptions a(float f2) {
        this.f = 0.5f;
        this.g = f2;
        return this;
    }

    public final MarkerOptions a(LatLng latLng) {
        this.b = latLng;
        return this;
    }

    public final MarkerOptions a(a a2) {
        this.e = a2;
        return this;
    }

    public final MarkerOptions a(String string) {
        this.c = string;
        return this;
    }

    public final MarkerOptions b(String string) {
        this.d = string;
        return this;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        i.a(this, parcel, n2);
    }
}

