/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.j;

public final class PointOfInterest
implements SafeParcelable {
    public static final j CREATOR = new j();
    final int a;
    public final LatLng b;
    public final String c;
    public final String d;

    PointOfInterest(int n2, LatLng latLng, String string, String string2) {
        this.a = n2;
        this.b = latLng;
        this.c = string;
        this.d = string2;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        j.a(this, parcel, n2);
    }
}

