/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.k;
import java.util.ArrayList;
import java.util.List;

public final class PolygonOptions
implements SafeParcelable {
    public static final k CREATOR = new k();
    final int a;
    final List<LatLng> b;
    final List<List<LatLng>> c;
    float d = 10.0f;
    int e = -16777216;
    int f = 0;
    float g = 0.0f;
    boolean h = true;
    boolean i = false;

    public PolygonOptions() {
        this.a = 1;
        this.b = new ArrayList<LatLng>();
        this.c = new ArrayList<List<LatLng>>();
    }

    PolygonOptions(int n2, List<LatLng> list, List list2, float f2, int n3, int n4, float f3, boolean bl2, boolean bl3) {
        this.a = n2;
        this.b = list;
        this.c = list2;
        this.d = f2;
        this.e = n3;
        this.f = n4;
        this.g = f3;
        this.h = bl2;
        this.i = bl3;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        k.a(this, parcel);
    }
}

