/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.l;
import java.util.ArrayList;
import java.util.List;

public final class PolylineOptions
implements SafeParcelable {
    public static final l CREATOR = new l();
    final int a;
    final List<LatLng> b;
    float c = 10.0f;
    int d = -16777216;
    float e = 0.0f;
    boolean f = true;
    boolean g = false;

    public PolylineOptions() {
        this.a = 1;
        this.b = new ArrayList<LatLng>();
    }

    PolylineOptions(int n2, List list, float f2, int n3, float f3, boolean bl2, boolean bl3) {
        this.a = n2;
        this.b = list;
        this.c = f2;
        this.d = n3;
        this.e = f3;
        this.f = bl2;
        this.g = bl3;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        l.a(this, parcel);
    }
}

