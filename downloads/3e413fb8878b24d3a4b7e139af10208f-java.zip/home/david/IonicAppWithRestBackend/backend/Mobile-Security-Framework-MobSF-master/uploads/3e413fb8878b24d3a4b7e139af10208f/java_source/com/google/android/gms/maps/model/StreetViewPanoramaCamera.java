/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import com.google.android.gms.common.internal.s;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.StreetViewPanoramaOrientation;
import com.google.android.gms.maps.model.m;
import java.util.Arrays;

public class StreetViewPanoramaCamera
implements SafeParcelable {
    public static final m CREATOR = new m();
    final int a;
    public final float b;
    public final float c;
    public final float d;
    private StreetViewPanoramaOrientation e;

    /*
     * Enabled aggressive block sorting
     */
    StreetViewPanoramaCamera(int n2, float f2, float f3, float f4) {
        boolean bl2 = -90.0f <= f3 && f3 <= 90.0f;
        d.d(bl2, (Object)"Tilt needs to be between -90 and 90 inclusive");
        this.a = n2;
        float f5 = f2;
        if ((double)f2 <= 0.0) {
            f5 = 0.0f;
        }
        this.b = f5;
        this.c = f3 + 0.0f;
        f2 = (double)f4 <= 0.0 ? f4 % 360.0f + 360.0f : f4;
        this.d = f2 % 360.0f;
        StreetViewPanoramaOrientation.a a2 = new StreetViewPanoramaOrientation.a();
        a2.b = f3;
        a2.a = f4;
        this.e = new StreetViewPanoramaOrientation(a2.b, a2.a);
    }

    public int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof StreetViewPanoramaCamera)) {
            return false;
        }
        object = (StreetViewPanoramaCamera)object;
        if (Float.floatToIntBits(this.b) != Float.floatToIntBits(object.b)) return false;
        if (Float.floatToIntBits(this.c) != Float.floatToIntBits(object.c)) return false;
        if (Float.floatToIntBits(this.d) == Float.floatToIntBits(object.d)) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.b), Float.valueOf(this.c), Float.valueOf(this.d)});
    }

    public String toString() {
        return d.c(this).a("zoom", Float.valueOf(this.b)).a("tilt", Float.valueOf(this.c)).a("bearing", Float.valueOf(this.d)).toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        m.a(this, parcel);
    }
}

