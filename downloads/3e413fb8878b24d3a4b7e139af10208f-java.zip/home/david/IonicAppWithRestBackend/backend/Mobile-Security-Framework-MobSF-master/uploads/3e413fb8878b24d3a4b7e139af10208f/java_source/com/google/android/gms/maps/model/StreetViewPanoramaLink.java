/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import com.google.android.gms.common.internal.s;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.n;
import java.util.Arrays;

public class StreetViewPanoramaLink
implements SafeParcelable {
    public static final n CREATOR = new n();
    final int a;
    public final String b;
    public final float c;

    StreetViewPanoramaLink(int n2, String string, float f2) {
        this.a = n2;
        this.b = string;
        float f3 = f2;
        if ((double)f2 <= 0.0) {
            f3 = f2 % 360.0f + 360.0f;
        }
        this.c = f3 % 360.0f;
    }

    public int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof StreetViewPanoramaLink)) {
            return false;
        }
        object = (StreetViewPanoramaLink)object;
        if (!this.b.equals(object.b)) return false;
        if (Float.floatToIntBits(this.c) == Float.floatToIntBits(object.c)) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.b, Float.valueOf(this.c)});
    }

    public String toString() {
        return d.c(this).a("panoId", this.b).a("bearing", Float.valueOf(this.c)).toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        n.a(this, parcel);
    }
}

