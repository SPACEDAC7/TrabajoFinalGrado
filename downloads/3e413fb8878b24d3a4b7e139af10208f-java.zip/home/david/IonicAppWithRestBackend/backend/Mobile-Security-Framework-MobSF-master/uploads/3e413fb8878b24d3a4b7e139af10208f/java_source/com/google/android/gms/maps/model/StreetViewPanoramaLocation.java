/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import com.google.android.gms.common.internal.s;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.StreetViewPanoramaLink;
import com.google.android.gms.maps.model.o;
import java.util.Arrays;

public class StreetViewPanoramaLocation
implements SafeParcelable {
    public static final o CREATOR = new o();
    final int a;
    public final StreetViewPanoramaLink[] b;
    public final LatLng c;
    public final String d;

    StreetViewPanoramaLocation(int n2, StreetViewPanoramaLink[] arrstreetViewPanoramaLink, LatLng latLng, String string) {
        this.a = n2;
        this.b = arrstreetViewPanoramaLink;
        this.c = latLng;
        this.d = string;
    }

    public int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof StreetViewPanoramaLocation)) {
            return false;
        }
        object = (StreetViewPanoramaLocation)object;
        if (!this.d.equals(object.d)) return false;
        if (this.c.equals(object.c)) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.c, this.d});
    }

    public String toString() {
        return d.c(this).a("panoId", this.d).a("position", this.c.toString()).toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        o.a(this, parcel, n2);
    }
}

