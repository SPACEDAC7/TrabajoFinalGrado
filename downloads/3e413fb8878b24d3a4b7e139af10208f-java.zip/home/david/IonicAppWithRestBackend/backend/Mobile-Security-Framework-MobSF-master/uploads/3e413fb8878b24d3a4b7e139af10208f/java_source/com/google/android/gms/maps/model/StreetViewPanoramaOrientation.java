/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import com.google.android.gms.common.internal.s;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.p;
import java.util.Arrays;

public class StreetViewPanoramaOrientation
implements SafeParcelable {
    public static final p CREATOR = new p();
    final int a;
    public final float b;
    public final float c;

    public StreetViewPanoramaOrientation(float f2, float f3) {
        this(1, f2, f3);
    }

    /*
     * Enabled aggressive block sorting
     */
    StreetViewPanoramaOrientation(int n2, float f2, float f3) {
        boolean bl2 = -90.0f <= f2 && f2 <= 90.0f;
        d.d(bl2, (Object)"Tilt needs to be between -90 and 90 inclusive");
        this.a = n2;
        this.b = 0.0f + f2;
        f2 = f3;
        if ((double)f3 <= 0.0) {
            f2 = f3 % 360.0f + 360.0f;
        }
        this.c = f2 % 360.0f;
    }

    public int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof StreetViewPanoramaOrientation)) {
            return false;
        }
        object = (StreetViewPanoramaOrientation)object;
        if (Float.floatToIntBits(this.b) != Float.floatToIntBits(object.b)) return false;
        if (Float.floatToIntBits(this.c) == Float.floatToIntBits(object.c)) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.b), Float.valueOf(this.c)});
    }

    public String toString() {
        return d.c(this).a("tilt", Float.valueOf(this.b)).a("bearing", Float.valueOf(this.c)).toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        p.a(this, parcel);
    }

    public static final class a {
        public float a;
        public float b;
    }

}

