/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.q;

public final class Tile
implements SafeParcelable {
    public static final q CREATOR = new q();
    final int a;
    public final int b;
    public final int c;
    public final byte[] d;

    public Tile() {
        this(1, -1, -1, null);
    }

    Tile(int n2, int n3, int n4, byte[] arrby) {
        this.a = n2;
        this.b = n3;
        this.c = n4;
        this.d = arrby;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        q.a(this, parcel);
    }
}

