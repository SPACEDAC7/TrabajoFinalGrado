/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.a.i;
import com.google.android.gms.maps.model.c;
import com.google.android.gms.maps.model.r;

public final class TileOverlayOptions
implements SafeParcelable {
    public static final r CREATOR = new r();
    final int a;
    i b;
    boolean c = true;
    float d;
    boolean e = true;
    private c f;

    public TileOverlayOptions() {
        this.a = 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    TileOverlayOptions(int n2, IBinder object, boolean bl2, float f2, boolean bl3) {
        this.a = n2;
        this.b = i.a.a((IBinder)object);
        object = this.b == null ? null : new c(){
            private final i c;
        };
        this.f = object;
        this.c = bl2;
        this.d = f2;
        this.e = bl3;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        r.a(this, parcel);
    }

}

