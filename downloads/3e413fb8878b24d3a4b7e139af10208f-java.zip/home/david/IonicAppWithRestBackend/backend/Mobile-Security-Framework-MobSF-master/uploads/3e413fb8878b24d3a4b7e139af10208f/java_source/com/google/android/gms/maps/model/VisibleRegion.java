/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.s;
import java.util.Arrays;

public final class VisibleRegion
implements SafeParcelable {
    public static final s CREATOR = new s();
    final int a;
    public final LatLng b;
    public final LatLng c;
    public final LatLng d;
    public final LatLng e;
    public final LatLngBounds f;

    VisibleRegion(int n2, LatLng latLng, LatLng latLng2, LatLng latLng3, LatLng latLng4, LatLngBounds latLngBounds) {
        this.a = n2;
        this.b = latLng;
        this.c = latLng2;
        this.d = latLng3;
        this.e = latLng4;
        this.f = latLngBounds;
    }

    public final int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof VisibleRegion)) {
            return false;
        }
        object = (VisibleRegion)object;
        if (!this.b.equals(object.b)) return false;
        if (!this.c.equals(object.c)) return false;
        if (!this.d.equals(object.d)) return false;
        if (!this.e.equals(object.e)) return false;
        if (this.f.equals(object.f)) return true;
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.b, this.c, this.d, this.e, this.f});
    }

    public final String toString() {
        return d.c(this).a("nearLeft", this.b).a("nearRight", this.c).a("farLeft", this.d).a("farRight", this.e).a("latLngBounds", this.f).toString();
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        s.a(this, parcel, n2);
    }
}

