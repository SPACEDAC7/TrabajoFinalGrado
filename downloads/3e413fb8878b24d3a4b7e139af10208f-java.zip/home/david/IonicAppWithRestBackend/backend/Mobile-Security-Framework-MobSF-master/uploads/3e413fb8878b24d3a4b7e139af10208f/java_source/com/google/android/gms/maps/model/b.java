/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.RemoteException
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.RemoteException;
import android.support.v4.app.Fragment;
import com.google.android.gms.a.c;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.a;
import com.google.android.gms.maps.model.a.f;

public final class b {
    private final f a;

    public b(f f2) {
        this.a = d.d(f2);
    }

    public final String a() {
        try {
            String string = this.a.b();
            return string;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void a(LatLng latLng) {
        try {
            this.a.a(latLng);
            return;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void a(a a2) {
        try {
            this.a.a(a2.a);
            return;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void a(boolean bl2) {
        try {
            this.a.b(bl2);
            return;
        }
        catch (RemoteException var2_2) {
            throw new Fragment.a(var2_2);
        }
    }

    public final LatLng b() {
        try {
            LatLng latLng = this.a.c();
            return latLng;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final void c() {
        try {
            this.a.g();
            return;
        }
        catch (RemoteException var1_1) {
            throw new Fragment.a(var1_1);
        }
    }

    public final void d() {
        try {
            this.a.h();
            return;
        }
        catch (RemoteException var1_1) {
            throw new Fragment.a(var1_1);
        }
    }

    public final boolean e() {
        try {
            boolean bl2 = this.a.j();
            return bl2;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final boolean equals(Object object) {
        if (!(object instanceof b)) {
            return false;
        }
        try {
            boolean bl2 = this.a.a(((b)object).a);
            return bl2;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }

    public final int hashCode() {
        try {
            int n2 = this.a.k();
            return n2;
        }
        catch (RemoteException var1_2) {
            throw new Fragment.a(var1_2);
        }
    }
}

