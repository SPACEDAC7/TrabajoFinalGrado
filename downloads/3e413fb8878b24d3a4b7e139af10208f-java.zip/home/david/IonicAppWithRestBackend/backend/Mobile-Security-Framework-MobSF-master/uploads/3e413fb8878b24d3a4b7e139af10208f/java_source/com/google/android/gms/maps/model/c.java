/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.maps.model;

import com.google.android.gms.maps.model.Tile;

public interface c {
    public static final Tile b = new Tile();
}

