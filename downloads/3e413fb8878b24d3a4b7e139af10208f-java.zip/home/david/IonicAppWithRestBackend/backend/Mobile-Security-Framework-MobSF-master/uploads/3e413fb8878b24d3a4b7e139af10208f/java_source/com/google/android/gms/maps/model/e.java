/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.h;

public final class e
implements Parcelable.Creator<CircleOptions> {
    public static CircleOptions a(Parcel parcel) {
        float f2 = 0.0f;
        boolean bl2 = false;
        int n2 = d.a(parcel);
        LatLng latLng = null;
        double d2 = 0.0;
        int n3 = 0;
        int n4 = 0;
        float f3 = 0.0f;
        int n5 = 0;
        block10 : while (parcel.dataPosition() < n2) {
            int n6 = parcel.readInt();
            switch (65535 & n6) {
                default: {
                    d.b(parcel, n6);
                    continue block10;
                }
                case 1: {
                    n5 = d.e(parcel, n6);
                    continue block10;
                }
                case 2: {
                    latLng = (LatLng)d.a(parcel, n6, LatLng.CREATOR);
                    continue block10;
                }
                case 3: {
                    d2 = d.h(parcel, n6);
                    continue block10;
                }
                case 4: {
                    f3 = d.g(parcel, n6);
                    continue block10;
                }
                case 5: {
                    n4 = d.e(parcel, n6);
                    continue block10;
                }
                case 6: {
                    n3 = d.e(parcel, n6);
                    continue block10;
                }
                case 7: {
                    f2 = d.g(parcel, n6);
                    continue block10;
                }
                case 8: 
            }
            bl2 = d.c(parcel, n6);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new CircleOptions(n5, latLng, d2, f3, n4, n3, f2, bl2);
    }

    static void a(CircleOptions circleOptions, Parcel parcel, int n2) {
        int n3 = d.m(parcel, 20293);
        d.c(parcel, 1, circleOptions.a);
        d.a(parcel, 2, circleOptions.b, n2);
        d.a(parcel, 3, circleOptions.c);
        d.a(parcel, 4, circleOptions.d);
        d.c(parcel, 5, circleOptions.e);
        d.c(parcel, 6, circleOptions.f);
        d.a(parcel, 7, circleOptions.g);
        d.a(parcel, 8, circleOptions.h);
        d.n(parcel, n3);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return e.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new CircleOptions[n2];
    }
}

