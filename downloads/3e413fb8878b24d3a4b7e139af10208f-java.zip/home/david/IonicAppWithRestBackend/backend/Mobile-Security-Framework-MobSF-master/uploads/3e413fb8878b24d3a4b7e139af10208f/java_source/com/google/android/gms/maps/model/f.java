/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.a.c;
import com.google.android.gms.maps.model.GroundOverlayOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.a;
import com.google.android.gms.maps.model.g;
import com.google.android.gms.maps.model.h;

public final class f
implements Parcelable.Creator<GroundOverlayOptions> {
    public static GroundOverlayOptions a(Parcel parcel) {
        boolean bl2 = false;
        LatLngBounds latLngBounds = null;
        float f2 = 0.0f;
        int n2 = d.a(parcel);
        float f3 = 0.0f;
        float f4 = 0.0f;
        float f5 = 0.0f;
        float f6 = 0.0f;
        float f7 = 0.0f;
        float f8 = 0.0f;
        LatLng latLng = null;
        IBinder iBinder = null;
        int n3 = 0;
        block14 : while (parcel.dataPosition() < n2) {
            int n4 = parcel.readInt();
            switch (65535 & n4) {
                default: {
                    d.b(parcel, n4);
                    continue block14;
                }
                case 1: {
                    n3 = d.e(parcel, n4);
                    continue block14;
                }
                case 2: {
                    iBinder = d.j(parcel, n4);
                    continue block14;
                }
                case 3: {
                    latLng = (LatLng)d.a(parcel, n4, LatLng.CREATOR);
                    continue block14;
                }
                case 4: {
                    f8 = d.g(parcel, n4);
                    continue block14;
                }
                case 5: {
                    f7 = d.g(parcel, n4);
                    continue block14;
                }
                case 6: {
                    latLngBounds = (LatLngBounds)d.a(parcel, n4, LatLngBounds.CREATOR);
                    continue block14;
                }
                case 7: {
                    f6 = d.g(parcel, n4);
                    continue block14;
                }
                case 8: {
                    f5 = d.g(parcel, n4);
                    continue block14;
                }
                case 9: {
                    bl2 = d.c(parcel, n4);
                    continue block14;
                }
                case 10: {
                    f4 = d.g(parcel, n4);
                    continue block14;
                }
                case 11: {
                    f3 = d.g(parcel, n4);
                    continue block14;
                }
                case 12: 
            }
            f2 = d.g(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new GroundOverlayOptions(n3, iBinder, latLng, f8, f7, latLngBounds, f6, f5, bl2, f4, f3, f2);
    }

    static void a(GroundOverlayOptions groundOverlayOptions, Parcel parcel, int n2) {
        int n3 = d.m(parcel, 20293);
        d.c(parcel, 1, groundOverlayOptions.a);
        d.a(parcel, 2, groundOverlayOptions.b.a.asBinder());
        d.a(parcel, 3, groundOverlayOptions.c, n2);
        d.a(parcel, 4, groundOverlayOptions.d);
        d.a(parcel, 5, groundOverlayOptions.e);
        d.a(parcel, 6, groundOverlayOptions.f, n2);
        d.a(parcel, 7, groundOverlayOptions.g);
        d.a(parcel, 8, groundOverlayOptions.h);
        d.a(parcel, 9, groundOverlayOptions.i);
        d.a(parcel, 10, groundOverlayOptions.j);
        d.a(parcel, 11, groundOverlayOptions.k);
        d.a(parcel, 12, groundOverlayOptions.l);
        d.n(parcel, n3);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return f.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new GroundOverlayOptions[n2];
    }
}

