/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.model.LatLng;

public final class h
implements Parcelable.Creator<LatLng> {
    public static LatLng a(Parcel parcel) {
        double d2 = 0.0;
        int n2 = d.a(parcel);
        int n3 = 0;
        double d3 = 0.0;
        block5 : while (parcel.dataPosition() < n2) {
            int n4 = parcel.readInt();
            switch (65535 & n4) {
                default: {
                    d.b(parcel, n4);
                    continue block5;
                }
                case 1: {
                    n3 = d.e(parcel, n4);
                    continue block5;
                }
                case 2: {
                    d3 = d.h(parcel, n4);
                    continue block5;
                }
                case 3: 
            }
            d2 = d.h(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new LatLng(n3, d3, d2);
    }

    static void a(LatLng latLng, Parcel parcel) {
        int n2 = d.m(parcel, 20293);
        d.c(parcel, 1, latLng.a);
        d.a(parcel, 2, latLng.b);
        d.a(parcel, 3, latLng.c);
        d.n(parcel, n2);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return h.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new LatLng[n2];
    }
}

