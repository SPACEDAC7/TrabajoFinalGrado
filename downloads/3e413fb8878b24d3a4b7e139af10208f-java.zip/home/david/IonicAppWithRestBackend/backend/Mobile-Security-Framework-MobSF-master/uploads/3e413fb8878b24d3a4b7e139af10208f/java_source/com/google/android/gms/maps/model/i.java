/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.a.c;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.a;
import com.google.android.gms.maps.model.h;

public final class i
implements Parcelable.Creator<MarkerOptions> {
    public static MarkerOptions a(Parcel parcel) {
        int n2 = d.a(parcel);
        int n3 = 0;
        LatLng latLng = null;
        String string = null;
        String string2 = null;
        IBinder iBinder = null;
        float f2 = 0.0f;
        float f3 = 0.0f;
        boolean bl2 = false;
        boolean bl3 = false;
        boolean bl4 = false;
        float f4 = 0.0f;
        float f5 = 0.5f;
        float f6 = 0.0f;
        float f7 = 1.0f;
        block16 : while (parcel.dataPosition() < n2) {
            int n4 = parcel.readInt();
            switch (65535 & n4) {
                default: {
                    d.b(parcel, n4);
                    continue block16;
                }
                case 1: {
                    n3 = d.e(parcel, n4);
                    continue block16;
                }
                case 2: {
                    latLng = (LatLng)d.a(parcel, n4, LatLng.CREATOR);
                    continue block16;
                }
                case 3: {
                    string = d.i(parcel, n4);
                    continue block16;
                }
                case 4: {
                    string2 = d.i(parcel, n4);
                    continue block16;
                }
                case 5: {
                    iBinder = d.j(parcel, n4);
                    continue block16;
                }
                case 6: {
                    f2 = d.g(parcel, n4);
                    continue block16;
                }
                case 7: {
                    f3 = d.g(parcel, n4);
                    continue block16;
                }
                case 8: {
                    bl2 = d.c(parcel, n4);
                    continue block16;
                }
                case 9: {
                    bl3 = d.c(parcel, n4);
                    continue block16;
                }
                case 10: {
                    bl4 = d.c(parcel, n4);
                    continue block16;
                }
                case 11: {
                    f4 = d.g(parcel, n4);
                    continue block16;
                }
                case 12: {
                    f5 = d.g(parcel, n4);
                    continue block16;
                }
                case 13: {
                    f6 = d.g(parcel, n4);
                    continue block16;
                }
                case 14: 
            }
            f7 = d.g(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new MarkerOptions(n3, latLng, string, string2, iBinder, f2, f3, bl2, bl3, bl4, f4, f5, f6, f7);
    }

    /*
     * Enabled aggressive block sorting
     */
    static void a(MarkerOptions markerOptions, Parcel parcel, int n2) {
        int n3 = d.m(parcel, 20293);
        d.c(parcel, 1, markerOptions.a);
        d.a(parcel, 2, markerOptions.b, n2);
        d.a(parcel, 3, markerOptions.c);
        d.a(parcel, 4, markerOptions.d);
        IBinder iBinder = markerOptions.e == null ? null : markerOptions.e.a.asBinder();
        d.a(parcel, 5, iBinder);
        d.a(parcel, 6, markerOptions.f);
        d.a(parcel, 7, markerOptions.g);
        d.a(parcel, 8, markerOptions.h);
        d.a(parcel, 9, markerOptions.i);
        d.a(parcel, 10, markerOptions.j);
        d.a(parcel, 11, markerOptions.k);
        d.a(parcel, 12, markerOptions.l);
        d.a(parcel, 13, markerOptions.m);
        d.a(parcel, 14, markerOptions.n);
        d.n(parcel, n3);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return i.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new MarkerOptions[n2];
    }
}

