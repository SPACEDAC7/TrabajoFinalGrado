/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.h;
import java.util.ArrayList;
import java.util.List;

public final class k
implements Parcelable.Creator<PolygonOptions> {
    static void a(PolygonOptions polygonOptions, Parcel parcel) {
        int n2 = d.m(parcel, 20293);
        d.c(parcel, 1, polygonOptions.a);
        d.a(parcel, 2, polygonOptions.b);
        List<List<LatLng>> list = polygonOptions.c;
        if (list != null) {
            int n3 = d.m(parcel, 3);
            parcel.writeList(list);
            d.n(parcel, n3);
        }
        d.a(parcel, 4, polygonOptions.d);
        d.c(parcel, 5, polygonOptions.e);
        d.c(parcel, 6, polygonOptions.f);
        d.a(parcel, 7, polygonOptions.g);
        d.a(parcel, 8, polygonOptions.h);
        d.a(parcel, 9, polygonOptions.i);
        d.n(parcel, n2);
    }

    public final PolygonOptions a(Parcel parcel) {
        float f2 = 0.0f;
        boolean bl2 = false;
        int n2 = d.a(parcel);
        ArrayList<LatLng> arrayList = null;
        ArrayList arrayList2 = new ArrayList();
        boolean bl3 = false;
        int n3 = 0;
        int n4 = 0;
        float f3 = 0.0f;
        int n5 = 0;
        block11 : while (parcel.dataPosition() < n2) {
            int n6 = parcel.readInt();
            switch (65535 & n6) {
                default: {
                    d.b(parcel, n6);
                    continue block11;
                }
                case 1: {
                    n5 = d.e(parcel, n6);
                    continue block11;
                }
                case 2: {
                    arrayList = d.c(parcel, n6, LatLng.CREATOR);
                    continue block11;
                }
                case 3: {
                    ClassLoader classLoader = this.getClass().getClassLoader();
                    n6 = d.a(parcel, n6);
                    int n7 = parcel.dataPosition();
                    if (n6 == 0) continue block11;
                    parcel.readList(arrayList2, classLoader);
                    parcel.setDataPosition(n6 + n7);
                    continue block11;
                }
                case 4: {
                    f3 = d.g(parcel, n6);
                    continue block11;
                }
                case 5: {
                    n4 = d.e(parcel, n6);
                    continue block11;
                }
                case 6: {
                    n3 = d.e(parcel, n6);
                    continue block11;
                }
                case 7: {
                    f2 = d.g(parcel, n6);
                    continue block11;
                }
                case 8: {
                    bl3 = d.c(parcel, n6);
                    continue block11;
                }
                case 9: 
            }
            bl2 = d.c(parcel, n6);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new PolygonOptions(n5, arrayList, arrayList2, f3, n4, n3, f2, bl3, bl2);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new PolygonOptions[n2];
    }
}

