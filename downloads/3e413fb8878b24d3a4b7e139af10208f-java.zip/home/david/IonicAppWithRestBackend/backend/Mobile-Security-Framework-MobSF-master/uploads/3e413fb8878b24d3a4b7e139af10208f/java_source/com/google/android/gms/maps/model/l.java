/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.h;
import java.util.ArrayList;
import java.util.List;

public final class l
implements Parcelable.Creator<PolylineOptions> {
    public static PolylineOptions a(Parcel parcel) {
        float f2 = 0.0f;
        boolean bl2 = false;
        int n2 = d.a(parcel);
        ArrayList arrayList = null;
        boolean bl3 = false;
        int n3 = 0;
        float f3 = 0.0f;
        int n4 = 0;
        block9 : while (parcel.dataPosition() < n2) {
            int n5 = parcel.readInt();
            switch (65535 & n5) {
                default: {
                    d.b(parcel, n5);
                    continue block9;
                }
                case 1: {
                    n4 = d.e(parcel, n5);
                    continue block9;
                }
                case 2: {
                    arrayList = d.c(parcel, n5, LatLng.CREATOR);
                    continue block9;
                }
                case 3: {
                    f3 = d.g(parcel, n5);
                    continue block9;
                }
                case 4: {
                    n3 = d.e(parcel, n5);
                    continue block9;
                }
                case 5: {
                    f2 = d.g(parcel, n5);
                    continue block9;
                }
                case 6: {
                    bl3 = d.c(parcel, n5);
                    continue block9;
                }
                case 7: 
            }
            bl2 = d.c(parcel, n5);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new PolylineOptions(n4, arrayList, f3, n3, f2, bl3, bl2);
    }

    static void a(PolylineOptions polylineOptions, Parcel parcel) {
        int n2 = d.m(parcel, 20293);
        d.c(parcel, 1, polylineOptions.a);
        d.a(parcel, 2, polylineOptions.b);
        d.a(parcel, 3, polylineOptions.c);
        d.c(parcel, 4, polylineOptions.d);
        d.a(parcel, 5, polylineOptions.e);
        d.a(parcel, 6, polylineOptions.f);
        d.a(parcel, 7, polylineOptions.g);
        d.n(parcel, n2);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return l.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new PolylineOptions[n2];
    }
}

