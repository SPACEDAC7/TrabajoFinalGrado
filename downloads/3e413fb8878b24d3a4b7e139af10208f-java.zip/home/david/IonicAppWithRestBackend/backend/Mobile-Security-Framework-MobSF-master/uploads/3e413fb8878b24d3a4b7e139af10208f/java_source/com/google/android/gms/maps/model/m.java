/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.model.StreetViewPanoramaCamera;

public final class m
implements Parcelable.Creator<StreetViewPanoramaCamera> {
    public static StreetViewPanoramaCamera a(Parcel parcel) {
        float f2 = 0.0f;
        int n2 = d.a(parcel);
        float f3 = 0.0f;
        int n3 = 0;
        float f4 = 0.0f;
        block6 : while (parcel.dataPosition() < n2) {
            int n4 = parcel.readInt();
            switch (65535 & n4) {
                default: {
                    d.b(parcel, n4);
                    continue block6;
                }
                case 1: {
                    n3 = d.e(parcel, n4);
                    continue block6;
                }
                case 2: {
                    f3 = d.g(parcel, n4);
                    continue block6;
                }
                case 3: {
                    f4 = d.g(parcel, n4);
                    continue block6;
                }
                case 4: 
            }
            f2 = d.g(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new StreetViewPanoramaCamera(n3, f3, f4, f2);
    }

    static void a(StreetViewPanoramaCamera streetViewPanoramaCamera, Parcel parcel) {
        int n2 = d.m(parcel, 20293);
        d.c(parcel, 1, streetViewPanoramaCamera.a);
        d.a(parcel, 2, streetViewPanoramaCamera.b);
        d.a(parcel, 3, streetViewPanoramaCamera.c);
        d.a(parcel, 4, streetViewPanoramaCamera.d);
        d.n(parcel, n2);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new StreetViewPanoramaCamera[n2];
    }
}

