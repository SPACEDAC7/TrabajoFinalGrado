/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.StreetViewPanoramaLink;
import com.google.android.gms.maps.model.StreetViewPanoramaLocation;
import com.google.android.gms.maps.model.h;
import com.google.android.gms.maps.model.n;

public final class o
implements Parcelable.Creator<StreetViewPanoramaLocation> {
    public static StreetViewPanoramaLocation a(Parcel parcel) {
        int n2 = d.a(parcel);
        LatLng latLng = null;
        StreetViewPanoramaLink[] arrstreetViewPanoramaLink = null;
        int n3 = 0;
        String string = null;
        block6 : while (parcel.dataPosition() < n2) {
            int n4 = parcel.readInt();
            switch (65535 & n4) {
                default: {
                    d.b(parcel, n4);
                    continue block6;
                }
                case 1: {
                    n3 = d.e(parcel, n4);
                    continue block6;
                }
                case 2: {
                    arrstreetViewPanoramaLink = (StreetViewPanoramaLink[])d.b(parcel, n4, StreetViewPanoramaLink.CREATOR);
                    continue block6;
                }
                case 3: {
                    latLng = (LatLng)d.a(parcel, n4, LatLng.CREATOR);
                    continue block6;
                }
                case 4: 
            }
            string = d.i(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new StreetViewPanoramaLocation(n3, arrstreetViewPanoramaLink, latLng, string);
    }

    static void a(StreetViewPanoramaLocation streetViewPanoramaLocation, Parcel parcel, int n2) {
        int n3 = d.m(parcel, 20293);
        d.c(parcel, 1, streetViewPanoramaLocation.a);
        d.a((Parcel)parcel, (int)2, (Parcelable[])streetViewPanoramaLocation.b, (int)n2);
        d.a(parcel, 3, streetViewPanoramaLocation.c, n2);
        d.a(parcel, 4, streetViewPanoramaLocation.d);
        d.n(parcel, n3);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return o.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new StreetViewPanoramaLocation[n2];
    }
}

