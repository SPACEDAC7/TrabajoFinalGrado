/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.model.StreetViewPanoramaOrientation;

public final class p
implements Parcelable.Creator<StreetViewPanoramaOrientation> {
    public static StreetViewPanoramaOrientation a(Parcel parcel) {
        float f2 = 0.0f;
        int n2 = d.a(parcel);
        int n3 = 0;
        float f3 = 0.0f;
        block5 : while (parcel.dataPosition() < n2) {
            int n4 = parcel.readInt();
            switch (65535 & n4) {
                default: {
                    d.b(parcel, n4);
                    continue block5;
                }
                case 1: {
                    n3 = d.e(parcel, n4);
                    continue block5;
                }
                case 2: {
                    f3 = d.g(parcel, n4);
                    continue block5;
                }
                case 3: 
            }
            f2 = d.g(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new StreetViewPanoramaOrientation(n3, f3, f2);
    }

    static void a(StreetViewPanoramaOrientation streetViewPanoramaOrientation, Parcel parcel) {
        int n2 = d.m(parcel, 20293);
        d.c(parcel, 1, streetViewPanoramaOrientation.a);
        d.a(parcel, 2, streetViewPanoramaOrientation.b);
        d.a(parcel, 3, streetViewPanoramaOrientation.c);
        d.n(parcel, n2);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return p.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new StreetViewPanoramaOrientation[n2];
    }
}

