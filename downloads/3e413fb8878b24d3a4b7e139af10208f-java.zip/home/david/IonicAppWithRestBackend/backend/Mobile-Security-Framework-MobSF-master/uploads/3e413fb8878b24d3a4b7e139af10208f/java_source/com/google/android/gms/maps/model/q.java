/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.model.Tile;

public final class q
implements Parcelable.Creator<Tile> {
    public static Tile a(Parcel parcel) {
        int n2 = 0;
        int n3 = d.a(parcel);
        byte[] arrby = null;
        int n4 = 0;
        int n5 = 0;
        block6 : while (parcel.dataPosition() < n3) {
            int n6 = parcel.readInt();
            switch (65535 & n6) {
                default: {
                    d.b(parcel, n6);
                    continue block6;
                }
                case 1: {
                    n5 = d.e(parcel, n6);
                    continue block6;
                }
                case 2: {
                    n4 = d.e(parcel, n6);
                    continue block6;
                }
                case 3: {
                    n2 = d.e(parcel, n6);
                    continue block6;
                }
                case 4: 
            }
            arrby = d.l(parcel, n6);
        }
        if (parcel.dataPosition() != n3) {
            throw new Fragment.a("Overread allowed size end=" + n3, parcel);
        }
        return new Tile(n5, n4, n2, arrby);
    }

    static void a(Tile tile, Parcel parcel) {
        int n2 = d.m(parcel, 20293);
        d.c(parcel, 1, tile.a);
        d.c(parcel, 2, tile.b);
        d.c(parcel, 3, tile.c);
        d.a(parcel, 4, tile.d);
        d.n(parcel, n2);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return q.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new Tile[n2];
    }
}

