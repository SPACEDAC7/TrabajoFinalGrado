/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.model.TileOverlayOptions;
import com.google.android.gms.maps.model.a.i;

public final class r
implements Parcelable.Creator<TileOverlayOptions> {
    public static TileOverlayOptions a(Parcel parcel) {
        boolean bl2 = false;
        int n2 = d.a(parcel);
        IBinder iBinder = null;
        float f2 = 0.0f;
        boolean bl3 = true;
        int n3 = 0;
        block7 : while (parcel.dataPosition() < n2) {
            int n4 = parcel.readInt();
            switch (65535 & n4) {
                default: {
                    d.b(parcel, n4);
                    continue block7;
                }
                case 1: {
                    n3 = d.e(parcel, n4);
                    continue block7;
                }
                case 2: {
                    iBinder = d.j(parcel, n4);
                    continue block7;
                }
                case 3: {
                    bl2 = d.c(parcel, n4);
                    continue block7;
                }
                case 4: {
                    f2 = d.g(parcel, n4);
                    continue block7;
                }
                case 5: 
            }
            bl3 = d.c(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new TileOverlayOptions(n3, iBinder, bl2, f2, bl3);
    }

    static void a(TileOverlayOptions tileOverlayOptions, Parcel parcel) {
        int n2 = d.m(parcel, 20293);
        d.c(parcel, 1, tileOverlayOptions.a);
        d.a(parcel, 2, tileOverlayOptions.b.asBinder());
        d.a(parcel, 3, tileOverlayOptions.c);
        d.a(parcel, 4, tileOverlayOptions.d);
        d.a(parcel, 5, tileOverlayOptions.e);
        d.n(parcel, n2);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return r.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new TileOverlayOptions[n2];
    }
}

