/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.maps.model;

import a.a.a.a.d;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.VisibleRegion;
import com.google.android.gms.maps.model.g;
import com.google.android.gms.maps.model.h;

public final class s
implements Parcelable.Creator<VisibleRegion> {
    public static VisibleRegion a(Parcel parcel) {
        LatLngBounds latLngBounds = null;
        int n2 = d.a(parcel);
        int n3 = 0;
        LatLng latLng = null;
        LatLng latLng2 = null;
        LatLng latLng3 = null;
        LatLng latLng4 = null;
        block8 : while (parcel.dataPosition() < n2) {
            int n4 = parcel.readInt();
            switch (65535 & n4) {
                default: {
                    d.b(parcel, n4);
                    continue block8;
                }
                case 1: {
                    n3 = d.e(parcel, n4);
                    continue block8;
                }
                case 2: {
                    latLng4 = (LatLng)d.a(parcel, n4, LatLng.CREATOR);
                    continue block8;
                }
                case 3: {
                    latLng3 = (LatLng)d.a(parcel, n4, LatLng.CREATOR);
                    continue block8;
                }
                case 4: {
                    latLng2 = (LatLng)d.a(parcel, n4, LatLng.CREATOR);
                    continue block8;
                }
                case 5: {
                    latLng = (LatLng)d.a(parcel, n4, LatLng.CREATOR);
                    continue block8;
                }
                case 6: 
            }
            latLngBounds = (LatLngBounds)d.a(parcel, n4, LatLngBounds.CREATOR);
        }
        if (parcel.dataPosition() != n2) {
            throw new Fragment.a("Overread allowed size end=" + n2, parcel);
        }
        return new VisibleRegion(n3, latLng4, latLng3, latLng2, latLng, latLngBounds);
    }

    static void a(VisibleRegion visibleRegion, Parcel parcel, int n2) {
        int n3 = d.m(parcel, 20293);
        d.c(parcel, 1, visibleRegion.a);
        d.a(parcel, 2, visibleRegion.b, n2);
        d.a(parcel, 3, visibleRegion.c, n2);
        d.a(parcel, 4, visibleRegion.d, n2);
        d.a(parcel, 5, visibleRegion.e, n2);
        d.a(parcel, 6, visibleRegion.f, n2);
        d.n(parcel, n3);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return s.a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int n2) {
        return new VisibleRegion[n2];
    }
}

