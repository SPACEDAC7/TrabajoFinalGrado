/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Binder
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.search.verification.api;

import android.content.Intent;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

public interface ISearchActionVerificationService
extends IInterface {
    public int getVersion();

    public boolean isSearchAction(Intent var1, Bundle var2);

    public static abstract class Stub
    extends Binder
    implements ISearchActionVerificationService {
        private static final String DESCRIPTOR = "com.google.android.search.verification.api.ISearchActionVerificationService";
        static final int TRANSACTION_getVersion = 2;
        static final int TRANSACTION_isSearchAction = 1;

        public Stub() {
            this.attachInterface((IInterface)this, "com.google.android.search.verification.api.ISearchActionVerificationService");
        }

        public static ISearchActionVerificationService asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.search.verification.api.ISearchActionVerificationService");
            if (iInterface != null && iInterface instanceof ISearchActionVerificationService) {
                return (ISearchActionVerificationService)iInterface;
            }
            return new Proxy(iBinder);
        }

        public IBinder asBinder() {
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean onTransact(int n2, Parcel parcel, Parcel parcel2, int n3) {
            switch (n2) {
                default: {
                    return super.onTransact(n2, parcel, parcel2, n3);
                }
                case 1598968902: {
                    parcel2.writeString("com.google.android.search.verification.api.ISearchActionVerificationService");
                    return true;
                }
                case 1: {
                    parcel.enforceInterface("com.google.android.search.verification.api.ISearchActionVerificationService");
                    Intent intent = parcel.readInt() != 0 ? (Intent)Intent.CREATOR.createFromParcel(parcel) : null;
                    parcel = parcel.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(parcel) : null;
                    boolean bl2 = this.isSearchAction(intent, (Bundle)parcel);
                    parcel2.writeNoException();
                    n2 = bl2 ? 1 : 0;
                    parcel2.writeInt(n2);
                    return true;
                }
                case 2: 
            }
            parcel.enforceInterface("com.google.android.search.verification.api.ISearchActionVerificationService");
            n2 = this.getVersion();
            parcel2.writeNoException();
            parcel2.writeInt(n2);
            return true;
        }

        static class Proxy
        implements ISearchActionVerificationService {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return "com.google.android.search.verification.api.ISearchActionVerificationService";
            }

            @Override
            public int getVersion() {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.search.verification.api.ISearchActionVerificationService");
                    this.mRemote.transact(2, parcel, parcel2, 0);
                    parcel2.readException();
                    int n2 = parcel2.readInt();
                    return n2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public boolean isSearchAction(Intent intent, Bundle bundle) {
                Parcel parcel;
                boolean bl2;
                Parcel parcel2;
                block9 : {
                    block8 : {
                        bl2 = true;
                        parcel = Parcel.obtain();
                        parcel2 = Parcel.obtain();
                        try {
                            parcel.writeInterfaceToken("com.google.android.search.verification.api.ISearchActionVerificationService");
                            if (intent != null) {
                                parcel.writeInt(1);
                                intent.writeToParcel(parcel, 0);
                            } else {
                                parcel.writeInt(0);
                            }
                            if (bundle != null) {
                                parcel.writeInt(1);
                                bundle.writeToParcel(parcel, 0);
                            } else {
                                parcel.writeInt(0);
                            }
                            this.mRemote.transact(1, parcel, parcel2, 0);
                            parcel2.readException();
                            int n2 = parcel2.readInt();
                            if (n2 == 0) break block8;
                            break block9;
                        }
                        catch (Throwable var1_2) {
                            parcel2.recycle();
                            parcel.recycle();
                            throw var1_2;
                        }
                    }
                    bl2 = false;
                }
                parcel2.recycle();
                parcel.recycle();
                return bl2;
            }
        }

    }

}

