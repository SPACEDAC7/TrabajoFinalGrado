/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Parcelable
 */
package com.google.android.search.verification.client;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import com.google.android.search.verification.client.SearchActionVerificationClientService;

public abstract class SearchActionVerificationClientActivity
extends Activity {
    public abstract Class<? extends SearchActionVerificationClientService> getServiceClass();

    protected final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        bundle = new Intent((Context)this, this.getServiceClass());
        bundle.putExtra("SearchActionVerificationClientExtraIntent", (Parcelable)this.getIntent());
        this.startService((Intent)bundle);
        this.finish();
    }
}

