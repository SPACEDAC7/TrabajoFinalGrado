/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.IntentService
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.os.Build
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  android.os.RemoteException
 *  android.util.Log
 */
package com.google.android.search.verification.client;

import android.app.IntentService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.search.verification.api.ISearchActionVerificationService;
import com.google.android.search.verification.client.SearchActionVerificationClientUtil;

public abstract class SearchActionVerificationClientService
extends IntentService {
    private static final int CONNECTION_TIMEOUT_IN_MS = 1000;
    public static final String EXTRA_INTENT = "SearchActionVerificationClientExtraIntent";
    private static final long MS_TO_NS = 1000000;
    private static final String REMOTE_SERVICE_ACTION = "com.google.android.googlequicksearchbox.SEARCH_ACTION_VERIFICATION_SERVICE";
    private static final String TAG = "SAVerificationClientS";
    private static final int TIME_TO_SLEEP_IN_MS = 50;
    private final long mConnectionTimeout;
    private final boolean mDbg;
    private ISearchActionVerificationService mIRemoteService = null;
    private SearchActionVerificationServiceConnection mSearchActionVerificationServiceConnection;
    private final Intent mServiceIntent = new Intent("com.google.android.googlequicksearchbox.SEARCH_ACTION_VERIFICATION_SERVICE").setPackage("com.google.android.googlequicksearchbox");

    public SearchActionVerificationClientService() {
        super("SearchActionVerificationClientService");
        this.mDbg = this.isDebugMode();
        if (this.isTestingMode()) {
            this.mServiceIntent.setPackage("com.google.verificationdemo.fakeverification");
        }
        this.mConnectionTimeout = this.getConnectionTimeout();
    }

    private boolean isConnected() {
        if (this.mIRemoteService != null) {
            return true;
        }
        return false;
    }

    private boolean isDebugMode() {
        if (this.isTestingMode() || !"user".equals(Build.TYPE)) {
            return true;
        }
        return false;
    }

    public long getConnectionTimeout() {
        return 1000;
    }

    public boolean isTestingMode() {
        return false;
    }

    public final void onCreate() {
        if (this.mDbg) {
            Log.d((String)"SAVerificationClientS", (String)"onCreate");
        }
        super.onCreate();
        this.mSearchActionVerificationServiceConnection = new SearchActionVerificationServiceConnection();
        this.bindService(this.mServiceIntent, (ServiceConnection)this.mSearchActionVerificationServiceConnection, 1);
    }

    public final void onDestroy() {
        if (this.mDbg) {
            Log.d((String)"SAVerificationClientS", (String)"onDestroy");
        }
        super.onDestroy();
        this.unbindService((ServiceConnection)this.mSearchActionVerificationServiceConnection);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected final void onHandleIntent(Intent var1_1) {
        var7_4 = true;
        if (var1_1 == null) {
            if (this.mDbg == false) return;
            Log.d((String)"SAVerificationClientS", (String)"Unable to verify null intent");
            return;
        }
        var3_5 = this.isDebugMode() != false || SearchActionVerificationClientUtil.isPackageGoogleSigned((Context)this, "com.google.android.googlequicksearchbox") != false;
        var5_6 = System.nanoTime();
        while (!this.isConnected() && System.nanoTime() - var5_6 < this.mConnectionTimeout * 1000000) {
            try {
                Thread.sleep(50);
            }
            catch (InterruptedException var2_8) {
                if (!this.mDbg) continue;
                var2_7 = String.valueOf(var2_8);
                Log.d((String)"SAVerificationClientS", (String)new StringBuilder(String.valueOf(var2_7).length() + 33).append("Unexpected InterruptedException: ").append(var2_7).toString());
            }
        }
        if (!this.isConnected()) {
            var1_1 = String.valueOf(var1_1);
            Log.e((String)"SAVerificationClientS", (String)new StringBuilder(String.valueOf(var1_1).length() + 62).append("VerificationService is not connected, unable to check intent: ").append((String)var1_1).toString());
            return;
        }
        if (!var1_1.hasExtra("SearchActionVerificationClientExtraIntent")) {
            if (this.mDbg == false) return;
            var1_1 = String.valueOf(var1_1);
            Log.d((String)"SAVerificationClientS", (String)new StringBuilder(String.valueOf(var1_1).length() + 28).append("No extra, nothing to check: ").append((String)var1_1).toString());
            return;
        }
        var1_1 = (Intent)var1_1.getParcelableExtra("SearchActionVerificationClientExtraIntent");
        if (this.mDbg) {
            SearchActionVerificationClientUtil.logIntentWithExtras((Intent)var1_1);
        }
        try {
            var4_9 = this.mIRemoteService.getVersion();
            Log.i((String)"SAVerificationClientS", (String)new StringBuilder(24).append("API version: ").append(var4_9).toString());
            var2_7 = new Bundle();
            if (!var3_5 || !this.mIRemoteService.isSearchAction((Intent)var1_1, (Bundle)var2_7)) ** GOTO lbl38
            ** GOTO lbl39
        }
        catch (RemoteException var1_2) {
            var1_3 = String.valueOf(var1_2.getMessage());
            var1_3 = var1_3.length() != 0 ? "Remote exception: ".concat(var1_3) : new String("Remote exception: ");
lbl38: // 1 sources:
            var7_4 = false;
lbl39: // 2 sources:
            this.performAction((Intent)var1_1, var7_4, (Bundle)var2_7);
            return;
            Log.e((String)"SAVerificationClientS", (String)var1_3);
            return;
        }
    }

    public abstract boolean performAction(Intent var1, boolean var2, Bundle var3);

    class SearchActionVerificationServiceConnection
    implements ServiceConnection {
        SearchActionVerificationServiceConnection() {
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            if (SearchActionVerificationClientService.this.mDbg) {
                Log.d((String)"SAVerificationClientS", (String)"onServiceConnected");
            }
            SearchActionVerificationClientService.this.mIRemoteService = ISearchActionVerificationService.Stub.asInterface(iBinder);
        }

        public void onServiceDisconnected(ComponentName componentName) {
            SearchActionVerificationClientService.this.mIRemoteService = null;
            if (SearchActionVerificationClientService.this.mDbg) {
                Log.d((String)"SAVerificationClientS", (String)"onServiceDisconnected");
            }
        }
    }

}

