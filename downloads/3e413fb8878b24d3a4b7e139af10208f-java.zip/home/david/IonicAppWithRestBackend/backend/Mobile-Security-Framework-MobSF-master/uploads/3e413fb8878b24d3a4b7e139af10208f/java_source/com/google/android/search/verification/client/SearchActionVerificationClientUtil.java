/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.Signature
 *  android.net.Uri
 *  android.os.Binder
 *  android.os.Build
 *  android.os.Bundle
 *  android.util.Base64
 *  android.util.Log
 */
package com.google.android.search.verification.client;

import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ah;
import android.support.v4.app.aq;
import android.util.Base64;
import android.util.Log;
import java.util.Set;

public abstract class SearchActionVerificationClientUtil {
    public static final String ANDROID_AUTO_PACKAGE = "com.google.android.gearhead";
    public static final String ANDROID_WEAR_PACKAGE = "com.google.android.wearable.app";
    private static final String AUDIO_CONTENT_URI_KEY = "android.preview.support.NotificationExtras.AUDIO_CONTENT_URI_KEY";
    private static final String CONTENT_ID_KEY = "android.preview.support.NotificationExtras.CONTENT_ID_KEY";
    private static final String INPUT_ALLOWS_AUDIO_INPUT_KEY = "android.preview.support.RemoteInputExtras.ALLOWS_AUDIO_INPUT_KEY";
    private static final String INPUT_AUDIO_KEY = "android.preview.support.RemoteInputExtras.INPUT_AUDIO_KEY";
    public static final String SEARCH_APP_PACKAGE = "com.google.android.googlequicksearchbox";
    private static final String TAG = "SAVerificationClientU";
    public static final String TESTING_APP_PACKAGE = "com.google.verificationdemo.fakeverification";
    private static final String VALID_PUBLIC_SIGNATURES_B64 = "MIIEQzCCAyugAwIBAgIJAMLgh0ZkSjCNMA0GCSqGSIb3DQEBBAUAMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtHb29nbGUgSW5jLjEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDAeFw0wODA4MjEyMzEzMzRaFw0zNjAxMDcyMzEzMzRaMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtHb29nbGUgSW5jLjEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDCCASAwDQYJKoZIhvcNAQEBBQADggENADCCAQgCggEBAKtWLgDYO6IIrgqWbxJOKdoR8qtW0I9Y4sypEwPpt1TTcvZApxsdyxMJZ2JORland2qSGT2y5b+3JKkedxiLDmpHpDsz2WCbdxgxRczfey5YZnTJ4VZbH0xqWVW/8lGmPav5xVwnIiJS6HXk+BVKZF+JcWjAsb/GEuq/eFdpuzSqeYTcfi6idkyugwfYwXFU1+5fZKUaRKYCwkkFQVfcAs1fXA5V+++FGfvjJ/CxURaSxaBvGdGDhfXE28LWuT9ozCl5xw4Yq5OGazvV24mZVSoOO0yZ31j7kYvtwYK6NeADwbSxDdJEqO4k//0zOHKrUiGYXtqw/A0LFFtqoZKFjnkCAQOjgdkwgdYwHQYDVR0OBBYEFMd9jMIhF1Ylmn/Tgt9r45jk14alMIGmBgNVHSMEgZ4wgZuAFMd9jMIhF1Ylmn/Tgt9r45jk14aloXikdjB0MQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLR29vZ2xlIEluYy4xEDAOBgNVBAsTB0FuZHJvaWQxEDAOBgNVBAMTB0FuZHJvaWSCCQDC4IdGZEowjTAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBAUAA4IBAQBt0lLO74UwLDYKqs6Tm8/yzKkEu116FmH4rkaymUIE0P9KaMftGlMexFlaYjzmB2OxZyl6euNXEsQH8gjwyxCUKRJNexBiGcCEyj6z+a1fuHHvkiaai+KL8W1EyNmgjmyy8AW7P+LLlkR+ho5zEHatRbM/YAnqGcFh5iZBqpknHf1SKMXFh4dd239FJ1jWYfbMDMy3NS5CTMQ2XFI1MvcyUTdZPErjQfTbQe3aDQsQcafEQPD+nqActifKZ0Np0IS9L9kR/wbNvyz6ENwPiTrjV2KRkEjH78ZMcUQXg0L3BYHJ3lc69Vs5Ddf9uUGGMYldX3WfMBEmh/9iFBDAaTCK";

    public static boolean getAllowsAudioInput(aq aq2) {
        return SearchActionVerificationClientUtil.getAllowsAudioInputFromBundle(aq2.a);
    }

    private static boolean getAllowsAudioInputFromBundle(Bundle bundle) {
        return bundle.getBoolean("android.preview.support.RemoteInputExtras.ALLOWS_AUDIO_INPUT_KEY");
    }

    public static Uri getAudioContentUri(Notification notification) {
        return SearchActionVerificationClientUtil.getAudioContentUriFromBundle(ah.a(notification));
    }

    private static Uri getAudioContentUriFromBundle(Bundle object) {
        if ((object = object.getString("android.preview.support.NotificationExtras.AUDIO_CONTENT_URI_KEY")) == null) {
            return null;
        }
        return Uri.parse((String)object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Uri getAudioResult(String string, Intent intent) {
        try {
            intent = aq.a(intent);
            string = String.valueOf(string);
            String string2 = String.valueOf("android.preview.support.RemoteInputExtras.INPUT_AUDIO_KEY");
            if (string2.length() != 0) {
                string = string.concat(string2);
                do {
                    return Uri.parse((String)intent.getCharSequence(string).toString());
                    break;
                } while (true);
            }
            string = new String(string);
            return Uri.parse((String)intent.getCharSequence(string).toString());
        }
        catch (Exception var0_1) {
            return null;
        }
    }

    public static Integer getContentId(Notification notification) {
        return SearchActionVerificationClientUtil.getContentIdFromBundle(ah.a(notification));
    }

    private static Integer getContentIdFromBundle(Bundle bundle) {
        if (bundle.containsKey("android.preview.support.NotificationExtras.CONTENT_ID_KEY")) {
            return bundle.getInt("android.preview.support.NotificationExtras.CONTENT_ID_KEY");
        }
        return null;
    }

    public static boolean isPackageGoogleSigned(Context context, String string) {
        block3 : {
            try {
                context = context.getPackageManager().getPackageInfo(string, 64);
                if (context.signatures != null && context.signatures.length == 1) break block3;
                Log.d((String)"SAVerificationClientU", (String)"Wrong number of signatures returned");
                return false;
            }
            catch (PackageManager.NameNotFoundException var0_1) {
                String string2 = String.valueOf((Object)var0_1);
                Log.d((String)"SAVerificationClientU", (String)new StringBuilder(String.valueOf(string2).length() + 34).append("Unexpected NameNotFoundException: ").append(string2).toString());
                return false;
            }
        }
        boolean bl2 = Base64.encodeToString((byte[])context.signatures[0].toByteArray(), (int)2).equals("MIIEQzCCAyugAwIBAgIJAMLgh0ZkSjCNMA0GCSqGSIb3DQEBBAUAMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtHb29nbGUgSW5jLjEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDAeFw0wODA4MjEyMzEzMzRaFw0zNjAxMDcyMzEzMzRaMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtHb29nbGUgSW5jLjEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDCCASAwDQYJKoZIhvcNAQEBBQADggENADCCAQgCggEBAKtWLgDYO6IIrgqWbxJOKdoR8qtW0I9Y4sypEwPpt1TTcvZApxsdyxMJZ2JORland2qSGT2y5b+3JKkedxiLDmpHpDsz2WCbdxgxRczfey5YZnTJ4VZbH0xqWVW/8lGmPav5xVwnIiJS6HXk+BVKZF+JcWjAsb/GEuq/eFdpuzSqeYTcfi6idkyugwfYwXFU1+5fZKUaRKYCwkkFQVfcAs1fXA5V+++FGfvjJ/CxURaSxaBvGdGDhfXE28LWuT9ozCl5xw4Yq5OGazvV24mZVSoOO0yZ31j7kYvtwYK6NeADwbSxDdJEqO4k//0zOHKrUiGYXtqw/A0LFFtqoZKFjnkCAQOjgdkwgdYwHQYDVR0OBBYEFMd9jMIhF1Ylmn/Tgt9r45jk14alMIGmBgNVHSMEgZ4wgZuAFMd9jMIhF1Ylmn/Tgt9r45jk14aloXikdjB0MQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLR29vZ2xlIEluYy4xEDAOBgNVBAsTB0FuZHJvaWQxEDAOBgNVBAMTB0FuZHJvaWSCCQDC4IdGZEowjTAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBAUAA4IBAQBt0lLO74UwLDYKqs6Tm8/yzKkEu116FmH4rkaymUIE0P9KaMftGlMexFlaYjzmB2OxZyl6euNXEsQH8gjwyxCUKRJNexBiGcCEyj6z+a1fuHHvkiaai+KL8W1EyNmgjmyy8AW7P+LLlkR+ho5zEHatRbM/YAnqGcFh5iZBqpknHf1SKMXFh4dd239FJ1jWYfbMDMy3NS5CTMQ2XFI1MvcyUTdZPErjQfTbQe3aDQsQcafEQPD+nqActifKZ0Np0IS9L9kR/wbNvyz6ENwPiTrjV2KRkEjH78ZMcUQXg0L3BYHJ3lc69Vs5Ddf9uUGGMYldX3WfMBEmh/9iFBDAaTCK");
        return bl2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean isPackageWhitelisted(Context object, boolean bl2) {
        String string = object.getPackageManager().getNameForUid(Binder.getCallingUid());
        if (bl2 && "user".equals(Build.TYPE) && !SearchActionVerificationClientUtil.isPackageGoogleSigned((Context)object, string)) {
            Log.d((String)"SAVerificationClientU", (String)"Package is not Google signed!");
            return false;
        }
        if ("com.google.android.googlequicksearchbox".equals(string) || "com.google.android.wearable.app".equals(string) || "com.google.android.gearhead".equals(string)) {
            return true;
        }
        object = String.valueOf(string);
        object = object.length() != 0 ? "Access is not allowed for package: ".concat((String)object) : new String("Access is not allowed for package: ");
        Log.d((String)"SAVerificationClientU", (String)object);
        return false;
    }

    public static void logIntentWithExtras(Intent intent) {
        Log.d((String)"SAVerificationClientU", (String)"Intent:");
        String string = String.valueOf((Object)intent);
        Log.d((String)"SAVerificationClientU", (String)new StringBuilder(String.valueOf(string).length() + 1).append("\t").append(string).toString());
        intent = intent.getExtras();
        if (intent != null) {
            Log.d((String)"SAVerificationClientU", (String)"Extras:");
            for (String string2 : intent.keySet()) {
                Log.d((String)"SAVerificationClientU", (String)String.format("\t%s: %s", string2, intent.get(string2)));
            }
        }
    }

    public static aq.a setAllowsAudioInput(aq.a a2, boolean bl2) {
        a2.a.putBoolean("android.preview.support.RemoteInputExtras.ALLOWS_AUDIO_INPUT_KEY", bl2);
        return a2;
    }

    public static ah.d setAudioContentUri(ah.d d2, Uri uri) {
        if (uri == null) {
            d2.b().remove("android.preview.support.NotificationExtras.AUDIO_CONTENT_URI_KEY");
            return d2;
        }
        d2.b().putString("android.preview.support.NotificationExtras.AUDIO_CONTENT_URI_KEY", uri.toString());
        return d2;
    }

    public static ah.d setContentId(ah.d d2, Integer n2) {
        if (n2 == null) {
            d2.b().remove("android.preview.support.NotificationExtras.CONTENT_ID_KEY");
            return d2;
        }
        d2.b().putInt("android.preview.support.NotificationExtras.CONTENT_ID_KEY", n2.intValue());
        return d2;
    }
}

