/*
 * Decompiled with CFR 0_115.
 */
package com.google.b.a;

import com.google.b.a.c;
import com.google.b.a.d;
import com.google.b.a.e;
import com.google.b.a.h;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class a {
    private static final e n = new e().b("NA");
    private static final Pattern q = Pattern.compile("\\[([^\\[\\]])*\\]");
    private static final Pattern r = Pattern.compile("\\d(?=[^,}][^,}])");
    private static final Pattern s = Pattern.compile("[-x\u2010-\u2015\u2212\u30fc\uff0d-\uff0f \u00a0\u00ad\u200b\u2060\u3000()\uff08\uff09\uff3b\uff3d.\\[\\]/~\u2053\u223c\uff5e]*(\\$\\d[-x\u2010-\u2015\u2212\u30fc\uff0d-\uff0f \u00a0\u00ad\u200b\u2060\u3000()\uff08\uff09\uff3b\uff3d.\\[\\]/~\u2053\u223c\uff5e]*)+");
    private static final Pattern t = Pattern.compile("[- ]");
    private static final Pattern u = Pattern.compile("\u2008");
    private List<d> A = new ArrayList<d>();
    private h B = new h(64);
    public String a = "";
    public StringBuilder b = new StringBuilder();
    public boolean c = true;
    public int d = 0;
    public int e = 0;
    private StringBuilder f = new StringBuilder();
    private String g = "";
    private StringBuilder h = new StringBuilder();
    private boolean i = false;
    private boolean j = false;
    private boolean k = false;
    private final c l = c.a();
    private String m;
    private e o;
    private e p;
    private int v = 0;
    private StringBuilder w = new StringBuilder();
    private boolean x = false;
    private String y = "";
    private StringBuilder z = new StringBuilder();

    a(String string) {
        this.m = string;
        this.o = this.p = this.a(this.m);
    }

    /*
     * Enabled aggressive block sorting
     */
    private e a(String object) {
        int n2;
        Object object2 = this.l;
        if (!object2.b((String)object)) {
            Logger logger = c.a;
            Level level = Level.WARNING;
            StringBuilder stringBuilder = new StringBuilder("Invalid or missing region code (");
            object2 = object;
            if (object == null) {
                object2 = "null";
            }
            logger.log(level, stringBuilder.append((String)object2).append(") provided.").toString());
            n2 = 0;
        } else {
            if ((object2 = object2.c((String)object)) == null) {
                throw new IllegalArgumentException("Invalid region code: " + (String)object);
            }
            n2 = object2.b;
        }
        object = this.l.b(n2);
        if ((object = this.l.c((String)object)) != null) {
            return object;
        }
        return n;
    }

    private String a(char c2) {
        Matcher matcher = u.matcher(this.f);
        if (matcher.find(this.v)) {
            String string = matcher.replaceFirst(Character.toString(c2));
            this.f.replace(0, string.length(), string);
            this.v = matcher.start();
            return this.f.substring(0, this.v + 1);
        }
        if (this.A.size() == 1) {
            this.c = false;
        }
        this.g = "";
        return this.h.toString();
    }

    private void b(String string) {
        int n2 = string.length() - 3;
        Iterator<d> iterator = this.A.iterator();
        while (iterator.hasNext()) {
            d d2 = iterator.next();
            if (d2.a() <= n2 || this.B.a(d2.a(n2)).matcher(string).lookingAt()) continue;
            iterator.remove();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private boolean b() {
        var2_1 = this.A.iterator();
        do {
            if (!var2_1.hasNext()) {
                this.c = false;
                return false;
            }
            var3_3 = var2_1.next();
            var4_4 = var3_3.a;
            if (this.g.equals(var4_4)) {
                return false;
            }
            var1_2 = var3_3.a;
            if (var1_2.indexOf(124) != -1) ** GOTO lbl-1000
            var1_2 = a.q.matcher(var1_2).replaceAll("\\\\d");
            var1_2 = a.r.matcher(var1_2).replaceAll("\\\\d");
            this.f.setLength(0);
            var5_5 = var3_3.b;
            var6_6 = this.B.a(var1_2).matcher("999999999999999");
            var6_6.find();
            var6_6 = var6_6.group();
            var1_2 = var6_6.length() < this.z.length() ? "" : var6_6.replaceAll(var1_2, var5_5).replaceAll("9", "\u2008");
            if (var1_2.length() > 0) {
                this.f.append(var1_2);
                var7_7 = true;
            } else lbl-1000: // 2 sources:
            {
                var7_7 = false;
            }
            if (var7_7) {
                this.g = var4_4;
                this.x = a.t.matcher(var3_3.d).find();
                this.v = 0;
                return true;
            }
            var2_1.remove();
        } while (true);
    }

    private String c() {
        this.c = true;
        this.k = false;
        this.A.clear();
        return this.e();
    }

    private String c(String string) {
        int n2 = this.w.length();
        if (this.x && n2 > 0 && this.w.charAt(n2 - 1) != ' ') {
            return new String(this.w) + ' ' + string;
        }
        return this.w + string;
    }

    private String d() {
        for (d d2 : this.A) {
            Matcher matcher = this.B.a(d2.a).matcher(this.z);
            if (!matcher.matches()) continue;
            this.x = t.matcher(d2.d).find();
            return this.c(matcher.replaceAll(d2.b));
        }
        return "";
    }

    /*
     * Enabled aggressive block sorting
     */
    private String e() {
        if (this.z.length() < 3) {
            return this.c(this.z.toString());
        }
        String string = this.z.substring(0, 3);
        List<d> list = this.j && this.p.a() > 0 ? this.p.k : this.p.j;
        boolean bl2 = this.p.d;
        for (d d2 : list) {
            String string2;
            if (bl2 && !this.j && !d2.e && !c.a(d2.d) || !s.matcher(string2 = d2.b).matches()) continue;
            this.A.add(d2);
        }
        this.b(string);
        if (this.b()) {
            return this.f();
        }
        return this.h.toString();
    }

    private String f() {
        int n2 = this.z.length();
        if (n2 > 0) {
            String string = "";
            for (int i2 = 0; i2 < n2; ++i2) {
                string = this.a(this.z.charAt(i2));
            }
            if (this.c) {
                return this.c(string);
            }
            return this.h.toString();
        }
        return this.w.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    private String g() {
        Object object;
        int n2 = 1;
        int n3 = this.p.b == 1 && this.z.charAt(0) == '1' && this.z.charAt(1) != '0' && this.z.charAt(1) != '1' ? 1 : 0;
        if (n3 != 0) {
            this.w.append('1').append(' ');
            this.j = true;
            n3 = n2;
        } else if (this.p.g && (object = this.B.a(this.p.h).matcher(this.z)).lookingAt()) {
            this.j = true;
            n3 = object.end();
            this.w.append(this.z.substring(0, n3));
        } else {
            n3 = 0;
        }
        object = this.z.substring(0, n3);
        this.z.delete(0, n3);
        return object;
    }

    private boolean h() {
        Matcher matcher = this.B.a("\\+|" + this.p.c).matcher(this.b);
        if (matcher.lookingAt()) {
            this.j = true;
            int n2 = matcher.end();
            this.z.setLength(0);
            this.z.append(this.b.substring(n2));
            this.w.setLength(0);
            this.w.append(this.b.substring(0, n2));
            if (this.b.charAt(0) != '+') {
                this.w.append(' ');
            }
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean i() {
        int n2;
        StringBuilder stringBuilder;
        if (this.z.length() == 0 || (n2 = this.l.a(this.z, stringBuilder = new StringBuilder())) == 0) {
            return false;
        }
        this.z.setLength(0);
        this.z.append((CharSequence)stringBuilder);
        String string = this.l.b(n2);
        if ("001".equals(string)) {
            this.p = this.l.a(n2);
        } else if (!string.equals(this.m)) {
            this.p = this.a(string);
        }
        String string2 = Integer.toString(n2);
        this.w.append(string2).append(' ');
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String a(char c2, boolean bl2) {
        String string;
        char c3;
        int n2 = 1;
        this.h.append(c2);
        if (bl2) {
            this.d = this.h.length();
        }
        int n3 = Character.isDigit(c2) || this.h.length() == 1 && c.b.matcher(Character.toString(c2)).matches() ? 1 : 0;
        if (n3 == 0) {
            this.c = false;
            this.i = true;
            c3 = c2;
        } else {
            if (c2 == '+') {
                this.b.append(c2);
            } else {
                c2 = Character.forDigit(Character.digit(c2, 10), 10);
                this.b.append(c2);
                this.z.append(c2);
            }
            c3 = c2;
            if (bl2) {
                this.e = this.b.length();
                c3 = c2;
            }
        }
        if (!this.c) {
            if (this.i) {
                return this.h.toString();
            }
            if (this.h()) {
                if (!this.i()) return this.h.toString();
                return this.c();
            }
            if (this.y.length() > 0) {
                this.z.insert(0, this.y);
                n3 = this.w.lastIndexOf(this.y);
                this.w.setLength(n3);
            }
            if (this.y.equals(this.g())) {
                return this.h.toString();
            }
            n3 = n2;
            if (n3 == 0) return this.h.toString();
            this.w.append(' ');
            return this.c();
        }
        switch (this.b.length()) {
            case 0: 
            case 1: 
            case 2: {
                return this.h.toString();
            }
            case 3: {
                if (!this.h()) {
                    this.y = this.g();
                    return this.e();
                }
                this.k = true;
            }
        }
        if (this.k) {
            if (!this.i()) return this.w + this.z.toString();
            this.k = false;
            return this.w + this.z.toString();
        }
        if (this.A.size() <= 0) {
            return this.e();
        }
        String string2 = this.a(c3);
        String string3 = string = this.d();
        if (string.length() > 0) return string3;
        this.b(this.z.toString());
        if (this.b()) {
            return this.f();
        }
        if (!this.c) return this.h.toString();
        return this.c(string2);
    }

    public final void a() {
        this.a = "";
        this.h.setLength(0);
        this.b.setLength(0);
        this.f.setLength(0);
        this.v = 0;
        this.g = "";
        this.w.setLength(0);
        this.y = "";
        this.z.setLength(0);
        this.c = true;
        this.i = false;
        this.e = 0;
        this.d = 0;
        this.j = false;
        this.k = false;
        this.A.clear();
        this.x = false;
        if (!this.p.equals(this.o)) {
            this.p = this.a(this.m);
        }
    }
}

