/*
 * Decompiled with CFR 0_115.
 */
package com.google.b.a;

public final class b
extends Exception {
    a a;
    private String b;

    public b(a a2, String string) {
        super(string);
        this.b = string;
        this.a = a2;
    }

    @Override
    public final String toString() {
        return "Error type: " + (Object)((Object)this.a) + ". " + this.b;
    }

    public static enum a {
        a,
        b,
        c,
        d,
        e;
        

        private a() {
        }
    }

}

