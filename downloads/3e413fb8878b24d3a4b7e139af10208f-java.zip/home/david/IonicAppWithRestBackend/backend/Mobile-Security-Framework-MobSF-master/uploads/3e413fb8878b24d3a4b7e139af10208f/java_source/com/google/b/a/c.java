/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 */
package com.google.b.a;

import android.text.TextUtils;
import com.google.b.a.b;
import com.google.b.a.d;
import com.google.b.a.e;
import com.google.b.a.f;
import com.google.b.a.g;
import com.google.b.a.h;
import com.whatsapp.mc;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class c {
    private static final Pattern A;
    private static final Pattern B;
    private static final Pattern C;
    private static c D;
    static final Logger a;
    static final Pattern b;
    static final Pattern c;
    static final Pattern d;
    static final String e;
    static final Pattern f;
    private static final Map<Character, Character> k;
    private static final Map<Character, Character> l;
    private static final Map<Character, Character> m;
    private static final Map<Character, Character> n;
    private static final Pattern o;
    private static final String p;
    private static final Pattern q;
    private static final Pattern r;
    private static final Pattern s;
    private static final Pattern t;
    private static final String u;
    private static final String v;
    private static final Pattern w;
    private static final Pattern x;
    private static final Pattern y;
    private static final Pattern z;
    private final Map<String, e> E = Collections.synchronizedMap(new HashMap());
    private final Map<Integer, e> F = Collections.synchronizedMap(new HashMap());
    private final Set<Integer> G = new HashSet<Integer>();
    private h H = new h(100);
    private String g = "/com/google/i18n/phonenumbers/data/PhoneNumberMetadataProto";
    private Map<Integer, List<String>> h = null;
    private final Set<String> i = new HashSet<String>(320);
    private final Set<String> j = new HashSet<String>(35);

    static {
        a = Logger.getLogger(c.class.getName());
        HashMap<Character, Character> hashMap = new HashMap<Character, Character>();
        hashMap.put(Character.valueOf('0'), Character.valueOf('0'));
        hashMap.put(Character.valueOf('1'), Character.valueOf('1'));
        hashMap.put(Character.valueOf('2'), Character.valueOf('2'));
        hashMap.put(Character.valueOf('3'), Character.valueOf('3'));
        hashMap.put(Character.valueOf('4'), Character.valueOf('4'));
        hashMap.put(Character.valueOf('5'), Character.valueOf('5'));
        hashMap.put(Character.valueOf('6'), Character.valueOf('6'));
        hashMap.put(Character.valueOf('7'), Character.valueOf('7'));
        hashMap.put(Character.valueOf('8'), Character.valueOf('8'));
        hashMap.put(Character.valueOf('9'), Character.valueOf('9'));
        HashMap<Character, Character> hashMap2 = new HashMap<Character, Character>(40);
        hashMap2.put(Character.valueOf('A'), Character.valueOf('2'));
        hashMap2.put(Character.valueOf('B'), Character.valueOf('2'));
        hashMap2.put(Character.valueOf('C'), Character.valueOf('2'));
        hashMap2.put(Character.valueOf('D'), Character.valueOf('3'));
        hashMap2.put(Character.valueOf('E'), Character.valueOf('3'));
        hashMap2.put(Character.valueOf('F'), Character.valueOf('3'));
        hashMap2.put(Character.valueOf('G'), Character.valueOf('4'));
        hashMap2.put(Character.valueOf('H'), Character.valueOf('4'));
        hashMap2.put(Character.valueOf('I'), Character.valueOf('4'));
        hashMap2.put(Character.valueOf('J'), Character.valueOf('5'));
        hashMap2.put(Character.valueOf('K'), Character.valueOf('5'));
        hashMap2.put(Character.valueOf('L'), Character.valueOf('5'));
        hashMap2.put(Character.valueOf('M'), Character.valueOf('6'));
        hashMap2.put(Character.valueOf('N'), Character.valueOf('6'));
        hashMap2.put(Character.valueOf('O'), Character.valueOf('6'));
        hashMap2.put(Character.valueOf('P'), Character.valueOf('7'));
        hashMap2.put(Character.valueOf('Q'), Character.valueOf('7'));
        hashMap2.put(Character.valueOf('R'), Character.valueOf('7'));
        hashMap2.put(Character.valueOf('S'), Character.valueOf('7'));
        hashMap2.put(Character.valueOf('T'), Character.valueOf('8'));
        hashMap2.put(Character.valueOf('U'), Character.valueOf('8'));
        hashMap2.put(Character.valueOf('V'), Character.valueOf('8'));
        hashMap2.put(Character.valueOf('W'), Character.valueOf('9'));
        hashMap2.put(Character.valueOf('X'), Character.valueOf('9'));
        hashMap2.put(Character.valueOf('Y'), Character.valueOf('9'));
        hashMap2.put(Character.valueOf('Z'), Character.valueOf('9'));
        l = Collections.unmodifiableMap(hashMap2);
        hashMap2 = new HashMap(100);
        hashMap2.putAll(l);
        hashMap2.putAll(hashMap);
        m = Collections.unmodifiableMap(hashMap2);
        hashMap2 = new HashMap();
        hashMap2.putAll(hashMap);
        hashMap2.put(Character.valueOf('+'), Character.valueOf('+'));
        hashMap2.put(Character.valueOf('*'), Character.valueOf('*'));
        k = Collections.unmodifiableMap(hashMap2);
        hashMap2 = new HashMap();
        Iterator<Character> iterator = l.keySet().iterator();
        while (iterator.hasNext()) {
            char c2 = iterator.next().charValue();
            hashMap2.put(Character.valueOf(Character.toLowerCase(c2)), Character.valueOf(c2));
            hashMap2.put(Character.valueOf(c2), Character.valueOf(c2));
        }
        hashMap2.putAll(hashMap);
        hashMap2.put(Character.valueOf('-'), Character.valueOf('-'));
        hashMap2.put(Character.valueOf('\uff0d'), Character.valueOf('-'));
        hashMap2.put(Character.valueOf('\u2010'), Character.valueOf('-'));
        hashMap2.put(Character.valueOf('\u2011'), Character.valueOf('-'));
        hashMap2.put(Character.valueOf('\u2012'), Character.valueOf('-'));
        hashMap2.put(Character.valueOf('\u2013'), Character.valueOf('-'));
        hashMap2.put(Character.valueOf('\u2014'), Character.valueOf('-'));
        hashMap2.put(Character.valueOf('\u2015'), Character.valueOf('-'));
        hashMap2.put(Character.valueOf('\u2212'), Character.valueOf('-'));
        hashMap2.put(Character.valueOf('/'), Character.valueOf('/'));
        hashMap2.put(Character.valueOf('\uff0f'), Character.valueOf('/'));
        hashMap2.put(Character.valueOf(' '), Character.valueOf(' '));
        hashMap2.put(Character.valueOf('\u3000'), Character.valueOf(' '));
        hashMap2.put(Character.valueOf('\u2060'), Character.valueOf(' '));
        hashMap2.put(Character.valueOf('.'), Character.valueOf('.'));
        hashMap2.put(Character.valueOf('\uff0e'), Character.valueOf('.'));
        n = Collections.unmodifiableMap(hashMap2);
        o = Pattern.compile("[\\d]+(?:[~\u2053\u223c\uff5e][\\d]+)?");
        p = Arrays.toString(l.keySet().toArray()).replaceAll("[, \\[\\]]", "") + Arrays.toString(l.keySet().toArray()).toLowerCase().replaceAll("[, \\[\\]]", "");
        b = Pattern.compile("[+\uff0b]+");
        q = Pattern.compile("[-x\u2010-\u2015\u2212\u30fc\uff0d-\uff0f \u00a0\u00ad\u200b\u2060\u3000()\uff08\uff09\uff3b\uff3d.\\[\\]/~\u2053\u223c\uff5e]+");
        r = Pattern.compile("(\\p{Nd})");
        s = Pattern.compile("[+\uff0b\\p{Nd}]");
        c = Pattern.compile("[\\\\/] *x");
        d = Pattern.compile("[[\\P{N}&&\\P{L}]&&[^#]]+$");
        t = Pattern.compile("(?:.*?[A-Za-z]){3}.*");
        u = "\\p{Nd}{2}|[+\uff0b]*+(?:[-x\u2010-\u2015\u2212\u30fc\uff0d-\uff0f \u00a0\u00ad\u200b\u2060\u3000()\uff08\uff09\uff3b\uff3d.\\[\\]/~\u2053\u223c\uff5e*]*\\p{Nd}){3,}[-x\u2010-\u2015\u2212\u30fc\uff0d-\uff0f \u00a0\u00ad\u200b\u2060\u3000()\uff08\uff09\uff3b\uff3d.\\[\\]/~\u2053\u223c\uff5e*" + p + "\\p{Nd}]*";
        v = c.e("," + "x\uff58#\uff03~\uff5e");
        e = c.e("x\uff58#\uff03~\uff5e");
        w = Pattern.compile("(?:" + v + ")$", 66);
        x = Pattern.compile(u + "(?:" + v + ")?", 66);
        f = Pattern.compile("(\\D+)");
        y = Pattern.compile("(\\$\\d)");
        z = Pattern.compile("\\$NP");
        A = Pattern.compile("\\$FG");
        B = Pattern.compile("\\$CC");
        C = Pattern.compile("\\(?\\$1\\)?");
        D = null;
    }

    private c() {
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private int a(String var1_1, e var2_2, StringBuilder var3_3, g var4_4) {
        if (var1_1.length() == 0) {
            return 0;
        }
        var5_5 = new StringBuilder((String)var1_1);
        var1_1 = "NonMatch";
        if (var2_2 != null) {
            var1_1 = var2_2.c;
        }
        if (var5_5.length() == 0) ** GOTO lbl-1000
        var6_6 = c.b.matcher(var5_5);
        if (!var6_6.lookingAt()) ** GOTO lbl14
        var5_5.delete(0, var6_6.end());
        c.a(var5_5);
        var1_1 = g.a.a;
        ** GOTO lbl29
lbl14: // 1 sources:
        var1_1 = this.H.a((String)var1_1);
        c.a(var5_5);
        var1_1 = var1_1.matcher(var5_5);
        if (!var1_1.lookingAt()) ** GOTO lbl-1000
        var8_7 = var1_1.end();
        var1_1 = c.r.matcher(var5_5.substring(var8_7));
        if (!var1_1.find() || !c.g(var1_1.group(1)).equals("0")) {
            var5_5.delete(0, var8_7);
            var8_7 = 1;
        } else lbl-1000: // 2 sources:
        {
            var8_7 = 0;
        }
        if (var8_7 != 0) {
            var1_1 = g.a.b;
        } else lbl-1000: // 2 sources:
        {
            var1_1 = g.a.d;
        }
lbl29: // 3 sources:
        if (var1_1 != g.a.d) {
            if (var5_5.length() <= 2) {
                throw new com.google.b.a.b(b.a.c, "Phone number had an IDD, but after this was not long enough to be a viable phone number.");
            }
            var8_7 = this.a(var5_5, var3_3);
            if (var8_7 == 0) throw new com.google.b.a.b(b.a.a, "Country calling code supplied was not recognised.");
            var4_4.a(var8_7);
            return var8_7;
        }
        if (var2_2 == null) ** GOTO lbl52
        var9_8 = var2_2.b;
        var1_1 = String.valueOf(var9_8);
        var6_6 = var5_5.toString();
        if (!var6_6.startsWith((String)var1_1)) ** GOTO lbl52
        var1_1 = new StringBuilder(var6_6.substring(var1_1.length()));
        var7_9 = var2_2.a;
        var6_6 = this.H.a(var7_9.a);
        this.a((StringBuilder)var1_1, (e)var2_2, null);
        var2_2 = this.H.a(var7_9.b);
        if (!var6_6.matcher(var5_5).matches() && var6_6.matcher((CharSequence)var1_1).matches()) ** GOTO lbl-1000
        var8_7 = (var2_2 = var2_2.matcher(var5_5.toString())).matches() != false ? c.a : (var2_2.lookingAt() != false ? c.d : c.c);
        if (var8_7 == c.d) lbl-1000: // 2 sources:
        {
            var3_3.append((CharSequence)var1_1);
            var4_4.a(var9_8);
            return var9_8;
        }
lbl52: // 4 sources:
        var4_4.a(0);
        return 0;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static c a() {
        synchronized (c.class) {
            Object object;
            if (D == null) {
                object = new HashMap(286);
                ArrayList<String> arrayList = new ArrayList<String>(25);
                arrayList.add("US");
                arrayList.add("AG");
                arrayList.add("AI");
                arrayList.add("AS");
                arrayList.add("BB");
                arrayList.add("BM");
                arrayList.add("BS");
                arrayList.add("CA");
                arrayList.add("DM");
                arrayList.add("DO");
                arrayList.add("GD");
                arrayList.add("GU");
                arrayList.add("JM");
                arrayList.add("KN");
                arrayList.add("KY");
                arrayList.add("LC");
                arrayList.add("MP");
                arrayList.add("MS");
                arrayList.add("PR");
                arrayList.add("SX");
                arrayList.add("TC");
                arrayList.add("TT");
                arrayList.add("VC");
                arrayList.add("VG");
                arrayList.add("VI");
                object.put(1, arrayList);
                arrayList = new ArrayList(2);
                arrayList.add("RU");
                arrayList.add("KZ");
                object.put(7, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("EG");
                object.put(20, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("ZA");
                object.put(27, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GR");
                object.put(30, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NL");
                object.put(31, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BE");
                object.put(32, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("FR");
                object.put(33, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("ES");
                object.put(34, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("HU");
                object.put(36, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("IT");
                object.put(39, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("RO");
                object.put(40, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CH");
                object.put(41, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AT");
                object.put(43, arrayList);
                arrayList = new ArrayList(4);
                arrayList.add("GB");
                arrayList.add("GG");
                arrayList.add("IM");
                arrayList.add("JE");
                object.put(44, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("DK");
                object.put(45, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SE");
                object.put(46, arrayList);
                arrayList = new ArrayList(2);
                arrayList.add("NO");
                arrayList.add("SJ");
                object.put(47, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PL");
                object.put(48, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("DE");
                object.put(49, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PE");
                object.put(51, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MX");
                object.put(52, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CU");
                object.put(53, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AR");
                object.put(54, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BR");
                object.put(55, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CL");
                object.put(56, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CO");
                object.put(57, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("VE");
                object.put(58, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MY");
                object.put(60, arrayList);
                arrayList = new ArrayList(3);
                arrayList.add("AU");
                arrayList.add("CC");
                arrayList.add("CX");
                object.put(61, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("ID");
                object.put(62, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PH");
                object.put(63, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NZ");
                object.put(64, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SG");
                object.put(65, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TH");
                object.put(66, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("JP");
                object.put(81, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("KR");
                object.put(82, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("VN");
                object.put(84, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CN");
                object.put(86, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TR");
                object.put(90, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("IN");
                object.put(91, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PK");
                object.put(92, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AF");
                object.put(93, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("LK");
                object.put(94, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MM");
                object.put(95, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("IR");
                object.put(98, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SS");
                object.put(211, arrayList);
                arrayList = new ArrayList(2);
                arrayList.add("MA");
                arrayList.add("EH");
                object.put(212, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("DZ");
                object.put(213, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TN");
                object.put(216, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("LY");
                object.put(218, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GM");
                object.put(220, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SN");
                object.put(221, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MR");
                object.put(222, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("ML");
                object.put(223, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GN");
                object.put(224, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CI");
                object.put(225, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BF");
                object.put(226, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NE");
                object.put(227, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TG");
                object.put(228, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BJ");
                object.put(229, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MU");
                object.put(230, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("LR");
                object.put(231, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SL");
                object.put(232, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GH");
                object.put(233, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NG");
                object.put(234, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TD");
                object.put(235, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CF");
                object.put(236, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CM");
                object.put(237, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CV");
                object.put(238, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("ST");
                object.put(239, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GQ");
                object.put(240, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GA");
                object.put(241, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CG");
                object.put(242, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CD");
                object.put(243, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AO");
                object.put(244, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GW");
                object.put(245, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("IO");
                object.put(246, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AC");
                object.put(247, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SC");
                object.put(248, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SD");
                object.put(249, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("RW");
                object.put(250, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("ET");
                object.put(251, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SO");
                object.put(252, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("DJ");
                object.put(253, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("KE");
                object.put(254, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TZ");
                object.put(255, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("UG");
                object.put(256, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BI");
                object.put(257, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MZ");
                object.put(258, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("ZM");
                object.put(260, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MG");
                object.put(261, arrayList);
                arrayList = new ArrayList(2);
                arrayList.add("RE");
                arrayList.add("YT");
                object.put(262, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("ZW");
                object.put(263, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NA");
                object.put(264, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MW");
                object.put(265, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("LS");
                object.put(266, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BW");
                object.put(267, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SZ");
                object.put(268, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("KM");
                object.put(269, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SH");
                object.put(290, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("ER");
                object.put(291, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AW");
                object.put(297, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("FO");
                object.put(298, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GL");
                object.put(299, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GI");
                object.put(350, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PT");
                object.put(351, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("LU");
                object.put(352, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("IE");
                object.put(353, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("IS");
                object.put(354, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AL");
                object.put(355, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MT");
                object.put(356, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CY");
                object.put(357, arrayList);
                arrayList = new ArrayList(2);
                arrayList.add("FI");
                arrayList.add("AX");
                object.put(358, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BG");
                object.put(359, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("LT");
                object.put(370, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("LV");
                object.put(371, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("EE");
                object.put(372, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MD");
                object.put(373, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AM");
                object.put(374, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BY");
                object.put(375, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AD");
                object.put(376, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MC");
                object.put(377, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SM");
                object.put(378, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("VA");
                object.put(379, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("UA");
                object.put(380, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("RS");
                object.put(381, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("ME");
                object.put(382, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("HR");
                object.put(385, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SI");
                object.put(386, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BA");
                object.put(387, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MK");
                object.put(389, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CZ");
                object.put(420, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SK");
                object.put(421, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("LI");
                object.put(423, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("FK");
                object.put(500, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BZ");
                object.put(501, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GT");
                object.put(502, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SV");
                object.put(503, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("HN");
                object.put(504, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NI");
                object.put(505, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CR");
                object.put(506, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PA");
                object.put(507, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PM");
                object.put(508, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("HT");
                object.put(509, arrayList);
                arrayList = new ArrayList(3);
                arrayList.add("GP");
                arrayList.add("BL");
                arrayList.add("MF");
                object.put(590, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BO");
                object.put(591, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GY");
                object.put(592, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("EC");
                object.put(593, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GF");
                object.put(594, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PY");
                object.put(595, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MQ");
                object.put(596, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SR");
                object.put(597, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("UY");
                object.put(598, arrayList);
                arrayList = new ArrayList(2);
                arrayList.add("CW");
                arrayList.add("BQ");
                object.put(599, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TL");
                object.put(670, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NF");
                object.put(672, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BN");
                object.put(673, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NR");
                object.put(674, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PG");
                object.put(675, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TO");
                object.put(676, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SB");
                object.put(677, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("VU");
                object.put(678, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("FJ");
                object.put(679, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PW");
                object.put(680, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("WF");
                object.put(681, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("CK");
                object.put(682, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NU");
                object.put(683, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("WS");
                object.put(685, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("KI");
                object.put(686, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NC");
                object.put(687, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TV");
                object.put(688, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PF");
                object.put(689, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TK");
                object.put(690, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("FM");
                object.put(691, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MH");
                object.put(692, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("001");
                object.put(800, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("001");
                object.put(808, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("KP");
                object.put(850, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("HK");
                object.put(852, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MO");
                object.put(853, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("KH");
                object.put(855, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("LA");
                object.put(856, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("001");
                object.put(870, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("001");
                object.put(878, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BD");
                object.put(880, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("001");
                object.put(881, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("001");
                object.put(882, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("001");
                object.put(883, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TW");
                object.put(886, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("001");
                object.put(888, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MV");
                object.put(960, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("LB");
                object.put(961, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("JO");
                object.put(962, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SY");
                object.put(963, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("IQ");
                object.put(964, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("KW");
                object.put(965, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("SA");
                object.put(966, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("YE");
                object.put(967, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("OM");
                object.put(968, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("PS");
                object.put(970, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AE");
                object.put(971, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("IL");
                object.put(972, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BH");
                object.put(973, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("QA");
                object.put(974, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("BT");
                object.put(975, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("MN");
                object.put(976, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("NP");
                object.put(977, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("001");
                object.put(979, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TJ");
                object.put(992, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("TM");
                object.put(993, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("AZ");
                object.put(994, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("GE");
                object.put(995, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("KG");
                object.put(996, arrayList);
                arrayList = new ArrayList(1);
                arrayList.add("UZ");
                object.put(998, arrayList);
                object = c.a("/com/google/i18n/phonenumbers/data/PhoneNumberMetadataProto", object);
                do {
                    return object;
                    break;
                } while (true);
            }
            object = D;
            return object;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static c a(String iterator, Map<Integer, List<String>> object) {
        synchronized (c.class) {
            Map.Entry<Integer, List<String>> entry2;
            if (D != null) return D;
            D = entry2 = new c();
            entry2.h = object;
            object = D;
            object.g = iterator;
            for (Map.Entry<Integer, List<String>> entry2 : object.h.entrySet()) {
                List list = (List)entry2.getValue();
                if (list.size() == 1 && "001".equals(list.get(0))) {
                    object.G.add((Integer)entry2.getKey());
                    continue;
                }
                object.i.addAll(list);
            }
            if (object.i.remove("001")) {
                a.log(Level.WARNING, "invalid metadata (country calling code was mapped to the non-geo entity as well as specific region(s))");
            }
            object.j.addAll((Collection)object.h.get(1));
            return D;
        }
    }

    private d a(List<d> object, String string) {
        object = object.iterator();
        while (object.hasNext()) {
            d d2 = (d)object.next();
            int n2 = d2.a();
            if (n2 != 0 && !this.H.a(d2.a(n2 - 1)).matcher(string).lookingAt() || !this.H.a(d2.a).matcher(string).matches()) continue;
            return d2;
        }
        return null;
    }

    private e a(int n2, String string) {
        if ("001".equals(string)) {
            return this.a(n2);
        }
        return this.c(string);
    }

    private static void a(int n2, int n3, StringBuilder stringBuilder) {
        switch (.b[n3 - 1]) {
            default: {
                return;
            }
            case 1: {
                stringBuilder.insert(0, n2).insert(0, '+');
                return;
            }
            case 2: {
                stringBuilder.insert(0, " ").insert(0, n2).insert(0, '+');
                return;
            }
            case 3: 
        }
        stringBuilder.insert(0, "-").insert(0, n2).insert(0, '+').insert(0, "tel:");
    }

    private void a(String string, int n2) {
        boolean bl2 = "001".equals(string);
        try {
            mc.a a2 = mc.b(string);
            if (a2 == null) {
                throw new RuntimeException("empty metadata: " + string);
            }
        }
        catch (IOException var3_5) {
            throw new RuntimeException("empty metadata: " + string);
        }
        e e2 = new e();
        e2.a(a2.b);
        e2.a(a2.c);
        e2.b(a2.k);
        if (a2.g != null) {
            for (int i2 = 0; i2 < a2.g.length; ++i2) {
                d d2 = new d();
                d2.a(a2.g[i2]);
                d2.b(a2.h[i2]);
                if (a2.i != null && i2 < a2.i.length && a2.i[i2] != null && !a2.i[i2].equals("N/A")) {
                    for (String string2 : TextUtils.split((String)a2.i[i2], (String)"#")) {
                        if (string2 == null) {
                            throw new NullPointerException();
                        }
                        d2.c.add(string2);
                    }
                }
                e2.k.add(d2);
                e2.j.add(d2);
            }
        }
        if (bl2) {
            this.F.put(n2, e2);
            return;
        }
        this.E.put(string, e2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(StringBuilder stringBuilder) {
        String string = stringBuilder.toString();
        if (t.matcher(string).matches()) {
            Map<Character, Character> map = m;
            StringBuilder stringBuilder2 = new StringBuilder(string.length());
            for (int i2 = 0; i2 < string.length(); ++i2) {
                Character c2 = map.get(Character.valueOf(Character.toUpperCase(string.charAt(i2))));
                if (c2 == null) continue;
                stringBuilder2.append(c2);
            }
            string = stringBuilder2.toString();
        } else {
            string = c.g(string);
        }
        stringBuilder.replace(0, stringBuilder.length(), string);
    }

    static boolean a(String string) {
        return C.matcher(string).matches();
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean a(StringBuilder stringBuilder, e object, StringBuilder stringBuilder2) {
        int n2 = stringBuilder.length();
        Object object2 = object.h;
        if (n2 == 0 || object2.length() == 0 || !(object2 = this.H.a((String)object2).matcher(stringBuilder)).lookingAt()) return false;
        Pattern pattern = this.H.a(object.a.a);
        boolean bl2 = pattern.matcher(stringBuilder).matches();
        int n3 = object2.groupCount();
        object = object.i;
        if (object == null || object.length() == 0 || object2.group(n3) == null) {
            if (bl2 && !pattern.matcher(stringBuilder.substring(object2.end())).matches()) return false;
            {
                if (stringBuilder2 != null && n3 > 0 && object2.group(n3) != null) {
                    stringBuilder2.append(object2.group(1));
                }
                stringBuilder.delete(0, object2.end());
                return true;
            }
        }
        StringBuilder stringBuilder3 = new StringBuilder(stringBuilder);
        stringBuilder3.replace(0, n2, object2.replaceFirst((String)object));
        if (bl2 && !pattern.matcher(stringBuilder3.toString()).matches()) {
            return false;
        }
        if (stringBuilder2 != null && n3 > 1) {
            stringBuilder2.append(object2.group(1));
        }
        stringBuilder.replace(0, stringBuilder.length(), stringBuilder3.toString());
        return true;
    }

    private static String b(StringBuilder stringBuilder) {
        Matcher matcher = w.matcher(stringBuilder);
        if (matcher.find() && c.f(stringBuilder.substring(0, matcher.start()))) {
            int n2 = matcher.groupCount();
            for (int i2 = 1; i2 <= n2; ++i2) {
                if (matcher.group(i2) == null) continue;
                String string = matcher.group(i2);
                stringBuilder.delete(matcher.start(), stringBuilder.length());
                return string;
            }
        }
        return "";
    }

    public static com.google.b.a.a d(String string) {
        return new com.google.b.a.a(string);
    }

    private static String e(String string) {
        return ";ext=(\\p{Nd}{1,7})|[ \u00a0\\t,]*(?:e?xt(?:ensi(?:o\u0301?|\u00f3))?n?|\uff45?\uff58\uff54\uff4e?|[" + string + "]|int|anexo|\uff49\uff4e\uff54)[:\\.\uff0e]?[ \u00a0\\t,-]*(\\p{Nd}{1,7})#?|[- ]+(\\p{Nd}{1,5})#";
    }

    private static boolean f(String string) {
        if (string.length() < 2) {
            return false;
        }
        return x.matcher(string).matches();
    }

    private static String g(String arrc) {
        StringBuilder stringBuilder = new StringBuilder(arrc.length());
        arrc = arrc.toCharArray();
        int n2 = arrc.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            int n3 = Character.digit(arrc[i2], 10);
            if (n3 == -1) continue;
            stringBuilder.append(n3);
        }
        return stringBuilder.toString();
    }

    final int a(StringBuilder stringBuilder, StringBuilder stringBuilder2) {
        if (stringBuilder.length() == 0 || stringBuilder.charAt(0) == '0') {
            return 0;
        }
        int n2 = stringBuilder.length();
        for (int i2 = 1; i2 <= 3 && i2 <= n2; ++i2) {
            int n3 = Integer.parseInt(stringBuilder.substring(0, i2));
            if (!this.h.containsKey(n3)) continue;
            stringBuilder2.append(stringBuilder.substring(i2));
            return n3;
        }
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    final e a(int n2) {
        Map<Integer, e> map = this.F;
        synchronized (map) {
            if (!this.h.containsKey(n2)) {
                return null;
            }
            if (!this.F.containsKey(n2)) {
                this.a("001", n2);
            }
            return this.F.get(n2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final g a(String object, String string) {
        int n2;
        g g2;
        Object object2;
        block27 : {
            StringBuilder stringBuilder;
            block26 : {
                int n3;
                g2 = new g();
                if (object == null) {
                    throw new com.google.b.a.b(b.a.b, "The phone number supplied was null.");
                }
                if (object.length() > 250) {
                    throw new com.google.b.a.b(b.a.e, "The string supplied was too long to parse.");
                }
                stringBuilder = new StringBuilder();
                n2 = object.indexOf(";phone-context=");
                if (n2 > 0) {
                    n3 = n2 + 15;
                    if (object.charAt(n3) == '+') {
                        int n4 = object.indexOf(59, n3);
                        if (n4 > 0) {
                            stringBuilder.append(object.substring(n3, n4));
                        } else {
                            stringBuilder.append(object.substring(n3));
                        }
                    }
                    stringBuilder.append(object.substring(object.indexOf("tel:") + 4, n2));
                } else {
                    object2 = s.matcher((CharSequence)object);
                    if (object2.find()) {
                        object2 = object.substring(object2.start());
                        Matcher matcher = d.matcher((CharSequence)object2);
                        object = object2;
                        if (matcher.find()) {
                            object = object2.substring(0, matcher.start());
                            a.log(Level.FINER, "Stripped trailing characters: " + (String)object);
                        }
                        matcher = c.matcher((CharSequence)object);
                        object2 = object;
                        if (matcher.find()) {
                            object2 = object.substring(0, matcher.start());
                        }
                    } else {
                        object2 = "";
                    }
                    stringBuilder.append((String)object2);
                }
                if ((n2 = stringBuilder.indexOf(";isub=")) > 0) {
                    stringBuilder.delete(n2, stringBuilder.length());
                }
                if (!c.f(stringBuilder.toString())) {
                    throw new com.google.b.a.b(b.a.b, "The string supplied did not seem to be a phone number.");
                }
                object = stringBuilder.toString();
                n2 = !this.b(string) && (object == null || object.length() == 0 || !b.matcher((CharSequence)object).lookingAt()) ? 0 : 1;
                if (n2 == 0) {
                    throw new com.google.b.a.b(b.a.a, "Missing or invalid default region.");
                }
                object = c.b(stringBuilder);
                if (object.length() > 0) {
                    if (object == null) {
                        throw new NullPointerException();
                    }
                    g2.d = true;
                    g2.e = object;
                }
                object = this.c(string);
                object2 = new StringBuilder();
                try {
                    n2 = this.a(stringBuilder.toString(), (e)object, (StringBuilder)object2, g2);
                }
                catch (com.google.b.a.b var6_11) {
                    Matcher matcher = b.matcher(stringBuilder.toString());
                    if (var6_11.a != b.a.a || !matcher.lookingAt()) throw new com.google.b.a.b(var6_11.a, var6_11.getMessage());
                    {
                        n2 = n3 = this.a(stringBuilder.substring(matcher.end()), (e)object, (StringBuilder)object2, g2);
                        if (n3 == 0) {
                            throw new com.google.b.a.b(b.a.a, "Could not interpret numbers after plus-sign.");
                        }
                    }
                }
                if (n2 == 0) break block26;
                String string2 = this.b(n2);
                if (!string2.equals(string)) {
                    object = this.a(n2, string2);
                }
                break block27;
            }
            c.a(stringBuilder);
            object2.append((CharSequence)stringBuilder);
            g2.a(object.b);
        }
        if (object2.length() < 2) {
            throw new com.google.b.a.b(b.a.d, "The string supplied is too short to be a phone number.");
        }
        if (object != null) {
            this.a((StringBuilder)object2, (e)object, new StringBuilder());
        }
        if ((n2 = object2.length()) < 2) {
            throw new com.google.b.a.b(b.a.d, "The string supplied is too short to be a phone number.");
        }
        if (n2 > 16) {
            throw new com.google.b.a.b(b.a.e, "The string supplied is too long to be a phone number.");
        }
        if (object2.charAt(0) == '0') {
            g2.f = true;
            g2.g = true;
        }
        long l2 = Long.parseLong(object2.toString());
        g2.b = true;
        g2.c = l2;
        return g2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String a(g g2, int n2) {
        Object object;
        if (g2.c == 0 && g2.h && (object = g2.i).length() > 0) {
            return object;
        }
        StringBuilder stringBuilder = new StringBuilder(20);
        stringBuilder.setLength(0);
        int n3 = g2.a;
        object = g2.g ? "0" : "";
        object = new StringBuilder((String)object);
        object.append(g2.c);
        Object object2 = object.toString();
        if (n2 == a.a) {
            stringBuilder.append((String)object2);
            c.a(n3, a.a, stringBuilder);
            return stringBuilder.toString();
        }
        if (!this.h.containsKey(n3)) {
            stringBuilder.append((String)object2);
            return stringBuilder.toString();
        }
        e e2 = this.a(n3, this.b(n3));
        object = e2.k.size() == 0 || n2 == a.c ? e2.j : e2.k;
        Object object3 = this.a((List<d>)object, (String)object2);
        if (object3 != null) {
            object = object3.b;
            object2 = this.H.a(object3.a).matcher((CharSequence)object2);
            int n4 = a.c;
            object3 = object3.d;
            object = n2 == a.c && object3 != null && object3.length() > 0 ? object2.replaceAll(y.matcher((CharSequence)object).replaceFirst((String)object3)) : object2.replaceAll((String)object);
            object2 = object;
            if (n2 == a.d) {
                object2 = q.matcher((CharSequence)object);
                if (object2.lookingAt()) {
                    object = object2.replaceFirst("");
                }
                object2 = object2.reset((CharSequence)object).replaceAll("-");
            }
        }
        stringBuilder.append((String)object2);
        if (g2.d && g2.e.length() > 0) {
            if (n2 == a.d) {
                stringBuilder.append(";ext=").append(g2.e);
            } else if (e2.e) {
                stringBuilder.append(e2.f).append(g2.e);
            } else {
                stringBuilder.append(" ext. ").append(g2.e);
            }
        }
        c.a(n3, n2, stringBuilder);
        return stringBuilder.toString();
    }

    public final String b(int n2) {
        List<String> list = this.h.get(n2);
        if (list == null) {
            return "ZZ";
        }
        return list.get(0);
    }

    final boolean b(String string) {
        if (string != null && this.i.contains(string)) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    final e c(String string) {
        if (!this.b(string)) {
            return null;
        }
        Map<String, e> map = this.E;
        synchronized (map) {
            if (!this.E.containsKey(string)) {
                this.a(string, 0);
            }
            return this.E.get(string);
        }
    }

    public static final class a
    extends Enum<a> {
        public static final /* enum */ int a = 1;
        public static final /* enum */ int b = 2;
        public static final /* enum */ int c = 3;
        public static final /* enum */ int d = 4;
        private static final /* synthetic */ int[] e;

        static {
            e = new int[]{a, b, c, d};
        }

        public static int[] a() {
            return (int[])e.clone();
        }
    }

    public static final class b
    extends Enum<b> {
        public static final /* enum */ int a = 1;
        public static final /* enum */ int b = 2;
        public static final /* enum */ int c = 3;
        public static final /* enum */ int d = 4;
        public static final /* enum */ int e = 5;
        public static final /* enum */ int f = 6;
        public static final /* enum */ int g = 7;
        public static final /* enum */ int h = 8;
        public static final /* enum */ int i = 9;
        public static final /* enum */ int j = 10;
        public static final /* enum */ int k = 11;
        public static final /* enum */ int l = 12;
        private static final /* synthetic */ int[] m;

        static {
            m = new int[]{a, b, c, d, e, f, g, h, i, j, k, l};
        }

        public static int[] a() {
            return (int[])m.clone();
        }
    }

    public static final class c
    extends Enum<c> {
        public static final /* enum */ int a = 1;
        public static final /* enum */ int b = 2;
        public static final /* enum */ int c = 3;
        public static final /* enum */ int d = 4;
        private static final /* synthetic */ int[] e;

        static {
            e = new int[]{a, b, c, d};
        }
    }

}

