/*
 * Decompiled with CFR 0_115.
 */
package com.google.b.a;

import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.List;

public final class d
implements Externalizable {
    String a = "";
    String b = "";
    List<String> c = new ArrayList<String>();
    String d = "";
    boolean e = false;
    String f = "";
    private boolean g;
    private boolean h;
    private boolean i;
    private boolean j;
    private boolean k;

    public final int a() {
        return this.c.size();
    }

    public final d a(String string) {
        this.g = true;
        this.a = string;
        return this;
    }

    public final String a(int n2) {
        return this.c.get(n2);
    }

    public final d b(String string) {
        this.h = true;
        this.b = string;
        return this;
    }

    @Override
    public final void readExternal(ObjectInput objectInput) {
        String string;
        this.a(objectInput.readUTF());
        this.b(objectInput.readUTF());
        int n2 = objectInput.readInt();
        for (int i2 = 0; i2 < n2; ++i2) {
            this.c.add(objectInput.readUTF());
        }
        if (objectInput.readBoolean()) {
            string = objectInput.readUTF();
            this.i = true;
            this.d = string;
        }
        if (objectInput.readBoolean()) {
            string = objectInput.readUTF();
            this.k = true;
            this.f = string;
        }
        boolean bl2 = objectInput.readBoolean();
        this.j = true;
        this.e = bl2;
    }

    @Override
    public final void writeExternal(ObjectOutput objectOutput) {
        objectOutput.writeUTF(this.a);
        objectOutput.writeUTF(this.b);
        int n2 = this.a();
        objectOutput.writeInt(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            objectOutput.writeUTF(this.c.get(i2));
        }
        objectOutput.writeBoolean(this.i);
        if (this.i) {
            objectOutput.writeUTF(this.d);
        }
        objectOutput.writeBoolean(this.k);
        if (this.k) {
            objectOutput.writeUTF(this.f);
        }
        objectOutput.writeBoolean(this.e);
    }
}

