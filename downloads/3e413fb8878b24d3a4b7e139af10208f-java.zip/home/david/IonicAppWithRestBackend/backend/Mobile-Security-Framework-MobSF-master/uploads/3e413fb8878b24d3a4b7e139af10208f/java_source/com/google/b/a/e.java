/*
 * Decompiled with CFR 0_115.
 */
package com.google.b.a;

import com.google.b.a.d;
import com.google.b.a.f;
import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.List;

public final class e
implements Externalizable {
    private boolean A;
    private f B = null;
    private boolean C;
    private f D = null;
    private boolean E;
    private f F = null;
    private boolean G;
    private f H = null;
    private boolean I;
    private f J = null;
    private boolean K;
    private String L = "";
    private boolean M;
    private boolean N;
    private boolean O;
    private String P = "";
    private String Q = "";
    private boolean R;
    private boolean S;
    private boolean T = false;
    private boolean U;
    private boolean V = false;
    private boolean W;
    private String X = "";
    private boolean Y;
    private boolean Z = false;
    f a = null;
    int b = 0;
    String c = "";
    boolean d;
    boolean e;
    String f = "";
    boolean g;
    String h = "";
    String i = "";
    List<d> j = new ArrayList<d>();
    List<d> k = new ArrayList<d>();
    private boolean l;
    private boolean m;
    private f n = null;
    private boolean o;
    private f p = null;
    private boolean q;
    private f r = null;
    private boolean s;
    private f t = null;
    private boolean u;
    private f v = null;
    private boolean w;
    private f x = null;
    private boolean y;
    private f z = null;

    public final int a() {
        return this.k.size();
    }

    public final e a(int n2) {
        this.M = true;
        this.b = n2;
        return this;
    }

    public final e a(String string) {
        this.K = true;
        this.L = string;
        return this;
    }

    public final e b(String string) {
        this.N = true;
        this.c = string;
        return this;
    }

    @Override
    public final void readExternal(ObjectInput objectInput) {
        Object object;
        int n2;
        int n3 = 0;
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.l = true;
            this.a = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.m = true;
            this.n = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.o = true;
            this.p = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.q = true;
            this.r = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.s = true;
            this.t = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.u = true;
            this.v = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.w = true;
            this.x = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.y = true;
            this.z = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.A = true;
            this.B = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.C = true;
            this.D = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.E = true;
            this.F = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.G = true;
            this.H = object;
        }
        if (objectInput.readBoolean()) {
            object = new f();
            object.readExternal(objectInput);
            this.I = true;
            this.J = object;
        }
        this.a(objectInput.readUTF());
        this.a(objectInput.readInt());
        this.b(objectInput.readUTF());
        if (objectInput.readBoolean()) {
            object = objectInput.readUTF();
            this.O = true;
            this.P = object;
        }
        if (objectInput.readBoolean()) {
            object = objectInput.readUTF();
            this.d = true;
            this.Q = object;
        }
        if (objectInput.readBoolean()) {
            object = objectInput.readUTF();
            this.e = true;
            this.f = object;
        }
        if (objectInput.readBoolean()) {
            object = objectInput.readUTF();
            this.g = true;
            this.h = object;
        }
        if (objectInput.readBoolean()) {
            object = objectInput.readUTF();
            this.R = true;
            this.i = object;
        }
        boolean bl2 = objectInput.readBoolean();
        this.S = true;
        this.T = bl2;
        int n4 = objectInput.readInt();
        for (n2 = 0; n2 < n4; ++n2) {
            object = new d();
            object.readExternal(objectInput);
            this.j.add((d)object);
        }
        n4 = objectInput.readInt();
        for (n2 = n3; n2 < n4; ++n2) {
            object = new d();
            object.readExternal(objectInput);
            this.k.add((d)object);
        }
        bl2 = objectInput.readBoolean();
        this.U = true;
        this.V = bl2;
        if (objectInput.readBoolean()) {
            object = objectInput.readUTF();
            this.W = true;
            this.X = object;
        }
        bl2 = objectInput.readBoolean();
        this.Y = true;
        this.Z = bl2;
    }

    @Override
    public final void writeExternal(ObjectOutput objectOutput) {
        int n2;
        int n3 = 0;
        objectOutput.writeBoolean(this.l);
        if (this.l) {
            this.a.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.m);
        if (this.m) {
            this.n.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.o);
        if (this.o) {
            this.p.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.q);
        if (this.q) {
            this.r.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.s);
        if (this.s) {
            this.t.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.u);
        if (this.u) {
            this.v.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.w);
        if (this.w) {
            this.x.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.y);
        if (this.y) {
            this.z.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.A);
        if (this.A) {
            this.B.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.C);
        if (this.C) {
            this.D.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.E);
        if (this.E) {
            this.F.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.G);
        if (this.G) {
            this.H.writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.I);
        if (this.I) {
            this.J.writeExternal(objectOutput);
        }
        objectOutput.writeUTF(this.L);
        objectOutput.writeInt(this.b);
        objectOutput.writeUTF(this.c);
        objectOutput.writeBoolean(this.O);
        if (this.O) {
            objectOutput.writeUTF(this.P);
        }
        objectOutput.writeBoolean(this.d);
        if (this.d) {
            objectOutput.writeUTF(this.Q);
        }
        objectOutput.writeBoolean(this.e);
        if (this.e) {
            objectOutput.writeUTF(this.f);
        }
        objectOutput.writeBoolean(this.g);
        if (this.g) {
            objectOutput.writeUTF(this.h);
        }
        objectOutput.writeBoolean(this.R);
        if (this.R) {
            objectOutput.writeUTF(this.i);
        }
        objectOutput.writeBoolean(this.T);
        int n4 = this.j.size();
        objectOutput.writeInt(n4);
        for (n2 = 0; n2 < n4; ++n2) {
            this.j.get(n2).writeExternal(objectOutput);
        }
        n4 = this.a();
        objectOutput.writeInt(n4);
        for (n2 = n3; n2 < n4; ++n2) {
            this.k.get(n2).writeExternal(objectOutput);
        }
        objectOutput.writeBoolean(this.V);
        objectOutput.writeBoolean(this.W);
        if (this.W) {
            objectOutput.writeUTF(this.X);
        }
        objectOutput.writeBoolean(this.Z);
    }
}

