/*
 * Decompiled with CFR 0_115.
 */
package com.google.b.a;

import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public final class f
implements Externalizable {
    String a = "";
    String b = "";
    private boolean c;
    private boolean d;
    private boolean e;
    private String f = "";

    @Override
    public final void readExternal(ObjectInput object) {
        String string;
        if (object.readBoolean()) {
            string = object.readUTF();
            this.c = true;
            this.a = string;
        }
        if (object.readBoolean()) {
            string = object.readUTF();
            this.d = true;
            this.b = string;
        }
        if (object.readBoolean()) {
            object = object.readUTF();
            this.e = true;
            this.f = object;
        }
    }

    @Override
    public final void writeExternal(ObjectOutput objectOutput) {
        objectOutput.writeBoolean(this.c);
        if (this.c) {
            objectOutput.writeUTF(this.a);
        }
        objectOutput.writeBoolean(this.d);
        if (this.d) {
            objectOutput.writeUTF(this.b);
        }
        objectOutput.writeBoolean(this.e);
        if (this.e) {
            objectOutput.writeUTF(this.f);
        }
    }
}

