/*
 * Decompiled with CFR 0_115.
 */
package com.google.b.a;

import java.io.Serializable;

public final class g
implements Serializable {
    int a = 0;
    boolean b;
    long c = 0;
    boolean d;
    String e = "";
    boolean f;
    boolean g = false;
    boolean h;
    String i = "";
    private boolean j;
    private boolean k;
    private a l = a.a;
    private boolean m;
    private String n = "";

    public final g a(int n2) {
        this.j = true;
        this.a = n2;
        return this;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (!(object instanceof g)) return false;
        if ((object = (g)object) == null) return false;
        if (this == object) {
            return true;
        }
        if (this.a != object.a || this.c != object.c || !this.e.equals(object.e) || this.g != object.g || !this.i.equals(object.i) || this.l != object.l || !this.n.equals(object.n) || this.m != object.m) return false;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int hashCode() {
        int n2 = 1231;
        int n3 = this.a;
        int n4 = Long.valueOf(this.c).hashCode();
        int n5 = this.e.hashCode();
        int n6 = this.g ? 1231 : 1237;
        int n7 = this.i.hashCode();
        int n8 = this.l.hashCode();
        int n9 = this.n.hashCode();
        if (this.m) {
            return ((((n6 + (((n3 + 2173) * 53 + n4) * 53 + n5) * 53) * 53 + n7) * 53 + n8) * 53 + n9) * 53 + n2;
        }
        n2 = 1237;
        return ((((n6 + (((n3 + 2173) * 53 + n4) * 53 + n5) * 53) * 53 + n7) * 53 + n8) * 53 + n9) * 53 + n2;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Country Code: ").append(this.a);
        stringBuilder.append(" National Number: ").append(this.c);
        if (this.f && this.g) {
            stringBuilder.append(" Leading Zero: true");
        }
        if (this.d) {
            stringBuilder.append(" Extension: ").append(this.e);
        }
        if (this.k) {
            stringBuilder.append(" Country Code Source: ").append((Object)this.l);
        }
        if (this.m) {
            stringBuilder.append(" Preferred Domestic Carrier Code: ").append(this.n);
        }
        return stringBuilder.toString();
    }

    public static enum a {
        a,
        b,
        c,
        d;
        

        private a() {
        }
    }

}

