/*
 * Decompiled with CFR 0_115.
 */
package com.google.b.a;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

public final class h {
    private a<String, Pattern> a;

    public h(int n2) {
        this.a = new a(n2);
    }

    public final Pattern a(String string) {
        Pattern pattern;
        Pattern pattern2 = pattern = this.a.a(string);
        if (pattern == null) {
            pattern2 = Pattern.compile(string);
            this.a.a(string, pattern2);
        }
        return pattern2;
    }

    static final class a<K, V> {
        int a;
        private LinkedHashMap<K, V> b;

        public a(int n2) {
            this.a = n2;
            this.b = new LinkedHashMap<K, V>((n2 << 2) / 3 + 1){

                @Override
                protected final boolean removeEldestEntry(Map.Entry<K, V> entry) {
                    if (this.size() > a.this.a) {
                        return true;
                    }
                    return false;
                }
            };
        }

        public final V a(K object) {
            synchronized (this) {
                object = this.b.get(object);
                return (V)object;
            }
        }

        public final void a(K k2, V v2) {
            synchronized (this) {
                this.b.put(k2, v2);
                return;
            }
        }

    }

}

