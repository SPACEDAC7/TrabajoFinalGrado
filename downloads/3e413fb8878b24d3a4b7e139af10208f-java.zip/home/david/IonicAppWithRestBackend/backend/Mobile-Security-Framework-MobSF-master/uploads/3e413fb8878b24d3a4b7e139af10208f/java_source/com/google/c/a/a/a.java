/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.a.a;

import com.google.c.b.b;
import com.google.c.b.b.c;
import com.google.c.b.b.e;
import com.google.c.g;
import java.util.Arrays;
import java.util.List;

public final class a {
    private static final String[] a = new String[]{"CTRL_PS", " ", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "CTRL_LL", "CTRL_ML", "CTRL_DL", "CTRL_BS"};
    private static final String[] b = new String[]{"CTRL_PS", " ", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "CTRL_US", "CTRL_ML", "CTRL_DL", "CTRL_BS"};
    private static final String[] c = new String[]{"CTRL_PS", " ", "\u0001", "\u0002", "\u0003", "\u0004", "\u0005", "\u0006", "\u0007", "\b", "\t", "\n", "\u000b", "\f", "\r", "\u001b", "\u001c", "\u001d", "\u001e", "\u001f", "@", "\\", "^", "_", "`", "|", "~", "", "CTRL_LL", "CTRL_UL", "CTRL_PL", "CTRL_BS"};
    private static final String[] d = new String[]{"", "\r", "\r\n", ". ", ", ", ": ", "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "[", "]", "{", "}", "CTRL_UL"};
    private static final String[] e = new String[]{"CTRL_PS", " ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ",", ".", "CTRL_UL", "CTRL_US"};
    private com.google.c.a.a f;

    private static int a(boolean[] arrbl, int n2, int n3) {
        int n4 = 0;
        for (int i2 = n2; i2 < n2 + n3; ++i2) {
            int n5;
            n4 = n5 = n4 << 1;
            if (!arrbl[i2]) continue;
            n4 = n5 | 1;
        }
        return n4;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private boolean[] a(boolean[] var1_1) {
        var4_3 = 8;
        if (this.f.c <= 2) {
            var4_3 = 6;
            var2_4 = com.google.c.b.b.a.c;
        } else if (this.f.c <= 8) {
            var2_4 = com.google.c.b.b.a.g;
        } else if (this.f.c <= 22) {
            var4_3 = 10;
            var2_4 = com.google.c.b.b.a.b;
        } else {
            var4_3 = 12;
            var2_4 = com.google.c.b.b.a.a;
        }
        if ((var7_6 = var1_1.length / var4_3) < (var8_5 = this.f.b)) {
            throw g.a();
        }
        var5_7 = var1_1.length;
        var3_8 = new int[var7_6];
        var5_7 %= var4_3;
        for (var6_9 = 0; var6_9 < var7_6; ++var6_9, var5_7 += var4_3) {
            var3_8[var6_9] = a.a(var1_1, var5_7, var4_3);
        }
        try {
            new c(var2_4).a(var3_8, var7_6 - var8_5);
            var9_10 = (1 << var4_3) - 1;
            var6_9 = 0;
        }
        catch (e var1_2) {
            throw g.a();
        }
        for (var5_7 = 0; var5_7 < var8_5; ++var5_7) {
            block17 : {
                var10_11 = var3_8[var5_7];
                if (var10_11 == 0) throw g.a();
                if (var10_11 == var9_10) {
                    throw g.a();
                }
                if (var10_11 != 1) {
                    var7_6 = var6_9;
                    if (var10_11 != var9_10 - 1) break block17;
                }
                var7_6 = var6_9 + 1;
            }
            var6_9 = var7_6;
        }
        var1_1 = new boolean[var8_5 * var4_3 - var6_9];
        var5_7 = 0;
        var6_9 = 0;
        block4 : do {
            if (var6_9 >= var8_5) return var1_1;
            var10_11 = var3_8[var6_9];
            if (var10_11 != 1 && var10_11 != var9_10 - 1) ** GOTO lbl53
            var11_12 = var10_11 > 1;
            Arrays.fill(var1_1, var5_7, var5_7 + var4_3 - 1, var11_12);
            var5_7 = var4_3 - 1 + var5_7;
            ** GOTO lbl-1000
lbl53: // 1 sources:
            var7_6 = var4_3 - 1;
            do {
                if (var7_6 < 0) lbl-1000: // 2 sources:
                {
                    ++var6_9;
                    continue block4;
                }
                var11_12 = (1 << var7_6 & var10_11) != 0;
                var1_1[var5_7] = var11_12;
                --var7_6;
                ++var5_7;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final com.google.c.b.e a(com.google.c.a.a var1_1) {
        this.f = var1_1;
        var1_1 = var1_1.d;
        var14_2 = this.f.a;
        var10_3 = this.f.c;
        var4_4 = var14_2 != false ? (var10_3 << 2) + 11 : (var10_3 << 2) + 14;
        var2_5 = new int[var4_4];
        var5_6 = var14_2 != false ? 88 : 112;
        var3_7 = new boolean[(var5_6 + (var10_3 << 4)) * var10_3];
        if (var14_2) {
            var5_6 = 0;
            while (var5_6 < var2_5.length) {
                var2_5[var5_6] = var5_6++;
            }
        } else {
            var5_6 = (var4_4 / 2 - 1) / 15;
            var6_8 = var4_4 / 2;
            var7_9 = (var4_4 + 1 + var5_6 * 2) / 2;
            for (var5_6 = 0; var5_6 < var6_8; ++var5_6) {
                var8_10 = var5_6 / 15 + var5_6;
                var2_5[var6_8 - var5_6 - 1] = var7_9 - var8_10 - 1;
                var2_5[var6_8 + var5_6] = var8_10 + var7_9 + 1;
            }
        }
        var6_8 = 0;
        var5_6 = 0;
        do {
            if (var5_6 >= var10_3) break;
            var7_9 = var14_2 != false ? (var10_3 - var5_6 << 2) + 9 : (var10_3 - var5_6 << 2) + 12;
            var11_12 = var5_6 << 1;
            var12_13 = var4_4 - 1 - var11_12;
            for (var8_10 = 0; var8_10 < var7_9; ++var8_10) {
                var13_14 = var8_10 << 1;
                for (var9_11 = 0; var9_11 < 2; ++var9_11) {
                    var3_7[var6_8 + var13_14 + var9_11] = var1_1.a(var2_5[var11_12 + var9_11], var2_5[var11_12 + var8_10]);
                    var3_7[var7_9 * 2 + var6_8 + var13_14 + var9_11] = var1_1.a(var2_5[var11_12 + var8_10], var2_5[var12_13 - var9_11]);
                    var3_7[var7_9 * 4 + var6_8 + var13_14 + var9_11] = var1_1.a(var2_5[var12_13 - var9_11], var2_5[var12_13 - var8_10]);
                    var3_7[var7_9 * 6 + var6_8 + var13_14 + var9_11] = var1_1.a(var2_5[var12_13 - var8_10], var2_5[var11_12 + var9_11]);
                }
            }
            var6_8 = (var7_9 << 3) + var6_8;
            ++var5_6;
        } while (true);
        var2_5 = this.a((boolean[])var3_7);
        var8_10 = var2_5.length;
        var5_6 = a.a;
        var6_8 = a.a;
        var3_7 = new StringBuilder(20);
        var4_4 = 0;
        block19 : do {
            if (var4_4 >= var8_10) return new com.google.c.b.e(null, var3_7.toString(), null, null);
            if (var6_8 == a.f) {
                if (var8_10 - var4_4 < 5) return new com.google.c.b.e(null, var3_7.toString(), null, null);
                var7_9 = a.a((boolean[])var2_5, var4_4, 5);
                var9_11 = var4_4 + 5;
                var6_8 = var7_9;
                var4_4 = var9_11;
                if (var7_9 == 0) {
                    if (var8_10 - var9_11 < 11) return new com.google.c.b.e(null, var3_7.toString(), null, null);
                    var6_8 = a.a((boolean[])var2_5, var9_11, 11) + 31;
                    var4_4 = var9_11 + 11;
                }
            } else {
                var7_9 = var6_8 == a.d ? 4 : 5;
                if (var8_10 - var4_4 < var7_9) return new com.google.c.b.e(null, var3_7.toString(), null, null);
                var9_11 = a.a((boolean[])var2_5, var4_4, var7_9);
                var7_9 = var4_4 + var7_9;
                switch (.a[var6_8 - 1]) {
                    default: {
                        throw new IllegalStateException("Bad table");
                    }
                    case 1: {
                        var1_1 = a.a[var9_11];
                        break;
                    }
                    case 2: {
                        var1_1 = a.b[var9_11];
                        break;
                    }
                    case 3: {
                        var1_1 = a.c[var9_11];
                        break;
                    }
                    case 4: {
                        var1_1 = a.d[var9_11];
                        break;
                    }
                    case 5: {
                        var1_1 = a.e[var9_11];
                        break;
                    }
                }
                if (var1_1.startsWith("CTRL_")) {
                    switch (var1_1.charAt(5)) {
                        default: {
                            var4_4 = a.a;
                            break;
                        }
                        case 'L': {
                            var4_4 = a.b;
                            break;
                        }
                        case 'P': {
                            var4_4 = a.e;
                            break;
                        }
                        case 'M': {
                            var4_4 = a.c;
                            break;
                        }
                        case 'D': {
                            var4_4 = a.d;
                            break;
                        }
                        case 'B': {
                            var4_4 = a.f;
                            break;
                        }
                    }
                    var6_8 = var4_4;
                    if (var1_1.charAt(6) == 'L') {
                        var6_8 = var4_4;
                        var5_6 = var4_4;
                        var4_4 = var7_9;
                        continue;
                    }
                } else {
                    var3_7.append((String)var1_1);
                    var6_8 = var5_6;
                }
                var4_4 = var7_9;
                continue;
            }
            var7_9 = 0;
            do {
                if (var7_9 >= var6_8) ** GOTO lbl119
                if (var8_10 - var4_4 < 8) {
                    var4_4 = var8_10;
lbl119: // 2 sources:
                    var6_8 = var5_6;
                    continue block19;
                }
                var3_7.append((char)a.a((boolean[])var2_5, var4_4, 8));
                ++var7_9;
                var4_4 += 8;
            } while (true);
            break;
        } while (true);
    }

    static final class a
    extends Enum<a> {
        public static final /* enum */ int a = 1;
        public static final /* enum */ int b = 2;
        public static final /* enum */ int c = 3;
        public static final /* enum */ int d = 4;
        public static final /* enum */ int e = 5;
        public static final /* enum */ int f = 6;
        private static final /* synthetic */ int[] g;

        static {
            g = new int[]{a, b, c, d, e, f};
        }

        public static int[] a() {
            return (int[])g.clone();
        }
    }

}

