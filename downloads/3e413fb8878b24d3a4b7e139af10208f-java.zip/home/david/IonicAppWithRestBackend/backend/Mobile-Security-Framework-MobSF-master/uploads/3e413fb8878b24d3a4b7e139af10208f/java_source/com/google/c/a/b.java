/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.a;

import com.google.c.a.b.a;
import com.google.c.c;
import com.google.c.e;
import com.google.c.g;
import com.google.c.j;
import com.google.c.l;
import com.google.c.n;
import com.google.c.o;
import com.google.c.p;
import java.util.List;
import java.util.Map;

public final class b
implements l {
    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    @Override
    public final n a(c var1_1, Map<e, ?> var2_9) {
        var5_10 = null;
        var7_11 = new a(var1_1.a());
        var1_1 = var7_11.a(false);
        var3_12 = var1_1.e;
        try {
            var1_1 = new com.google.c.a.a.a().a((com.google.c.a.a)var1_1);
            var4_13 = null;
        }
        catch (g var1_7) {
            ** continue;
        }
        catch (j var1_8) {
            ** continue;
        }
lbl9: // 3 sources:
        do {
            var6_14 = var1_1;
            if (var1_1 == null) {
                var1_1 = var7_11.a(true);
                var3_12 = var1_1.e;
                var6_14 = new com.google.c.a.a.a().a((com.google.c.a.a)var1_1);
            }
            if (var2_9 != null) {
                var2_9.get((Object)e.j);
            }
            var1_1 = new n(var6_14.b, var6_14.a, var3_12, com.google.c.a.a);
            var2_9 = var6_14.c;
            if (var2_9 != null) {
                var1_1.a(o.c, var2_9);
            }
            if ((var2_9 = var6_14.d) != null) {
                var1_1.a(o.d, var2_9);
            }
            return var1_1;
            break;
        } while (true);
        catch (j var1_2) {
            var3_12 = null;
lbl27: // 2 sources:
            do {
                var4_13 = var1_1;
                var1_1 = null;
                break;
            } while (true);
        }
        catch (g var1_3) {
            var3_12 = null;
lbl33: // 2 sources:
            do {
                var4_13 = null;
                var6_14 = null;
                var5_10 = var1_1;
                var1_1 = var6_14;
                ** continue;
                break;
            } while (true);
        }
lbl39: // 1 sources:
        ** GOTO lbl9
        catch (g var1_4) lbl-1000: // 2 sources:
        {
            do {
                if (var4_13 != null) {
                    throw var4_13;
                }
                if (var5_10 != null) {
                    throw var5_10;
                }
                throw var1_5;
                break;
            } while (true);
        }
        catch (j var1_6) {
            ** continue;
        }
    }

    @Override
    public final void a() {
    }
}

