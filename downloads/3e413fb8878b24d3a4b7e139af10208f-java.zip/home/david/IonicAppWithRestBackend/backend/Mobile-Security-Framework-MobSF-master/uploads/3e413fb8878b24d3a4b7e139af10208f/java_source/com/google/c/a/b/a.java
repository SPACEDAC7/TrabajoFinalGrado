/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.a.b;

import a.a.a.a.d;
import com.google.c.b.b;
import com.google.c.b.b.c;
import com.google.c.b.b.e;
import com.google.c.b.i;
import com.google.c.j;
import com.google.c.p;

public final class a {
    private static final int[] g = new int[]{3808, 476, 2107, 1799};
    private final b a;
    private boolean b;
    private int c;
    private int d;
    private int e;
    private int f;

    public a(b b2) {
        this.a = b2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static int a(long l2, boolean bl2) {
        int n2;
        int n3;
        int n4;
        int n5 = 0;
        if (bl2) {
            n3 = 7;
            n2 = 2;
        } else {
            n3 = 10;
            n2 = 4;
        }
        int[] arrn = new int[n3];
        for (n4 = n3 - 1; n4 >= 0; l2 >>= 4, --n4) {
            arrn[n4] = (int)l2 & 15;
        }
        try {
            new c(com.google.c.b.b.a.d).a(arrn, n3 - n2);
            n4 = 0;
            n3 = n5;
        }
        catch (e var3_6) {
            throw j.a();
        }
        do {
            if (n3 >= n2) {
                return n4;
            }
            n4 = (n4 << 4) + arrn[n3];
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private int a(a a2, a a3) {
        float f2 = a.b(a2, a3);
        float f3 = (float)(a3.a - a2.a) / f2;
        float f4 = (float)(a3.b - a2.b) / f2;
        float f5 = a2.a;
        float f6 = a2.b;
        boolean bl2 = this.a.a(a2.a, a2.b);
        int n2 = 0;
        int n3 = 0;
        while ((float)n3 < f2) {
            int n4 = n2;
            if (this.a.a(d.b(f5 += f3), d.b(f6 += f4)) != bl2) {
                n4 = n2 + 1;
            }
            ++n3;
            n2 = n4;
        }
        f5 = (float)n2 / f2;
        if (f5 > 0.1f && f5 < 0.9f) {
            return 0;
        }
        boolean bl3 = f5 <= 0.1f;
        if (bl3 != bl2) return -1;
        return 1;
    }

    private int a(p p2, p p3, int n2) {
        int n3 = 0;
        float f2 = d.a(p2.a, p2.b, p3.a, p3.b);
        float f3 = f2 / (float)n2;
        float f4 = p2.a;
        float f5 = p2.b;
        float f6 = (p3.a - p2.a) * f3 / f2;
        f2 = f3 * (p3.b - p2.b) / f2;
        for (int i2 = 0; i2 < n2; ++i2) {
            int n4 = n3;
            if (this.a.a(d.b((float)i2 * f6 + f4), d.b((float)i2 * f2 + f5))) {
                n4 = n3 | 1 << n2 - i2 - 1;
            }
            n3 = n4;
        }
        return n3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private a a() {
        p p2;
        p p3;
        p p4;
        Object object;
        int n2;
        int n3;
        try {
            object = new com.google.c.b.a.a(this.a).a();
        }
        catch (j var2_2) {
            n3 = this.a.a / 2;
            n2 = this.a.b / 2;
            p2 = this.a(new a(n3 + 7, n2 - 7), false, 1, -1).a();
            p3 = this.a(new a(n3 + 7, n2 + 7), false, 1, 1).a();
            p4 = this.a(new a(n3 - 7, n2 + 7), false, -1, 1).a();
            object = this.a(new a(n3 - 7, n2 - 7), false, -1, -1).a();
        }
        p2 = object[0];
        p3 = object[1];
        p4 = object[2];
        object = object[3];
        n3 = d.b((p2.a + object.a + p3.a + p4.a) / 4.0f);
        float f2 = p2.b;
        n2 = d.b((object.b + f2 + p3.b + p4.b) / 4.0f);
        try {
            object = new com.google.c.b.a.a(this.a, 15, n3, n2).a();
        }
        catch (j var2_3) {
            p2 = this.a(new a(n3 + 7, n2 - 7), false, 1, -1).a();
            p3 = this.a(new a(n3 + 7, n2 + 7), false, 1, 1).a();
            p4 = this.a(new a(n3 - 7, n2 + 7), false, -1, 1).a();
            object = this.a(new a(n3 - 7, n2 - 7), false, -1, -1).a();
        }
        p2 = object[0];
        p3 = object[1];
        p4 = object[2];
        object = object[3];
        n3 = d.b((p2.a + object.a + p3.a + p4.a) / 4.0f);
        f2 = p2.b;
        return new a(n3, d.b((object.b + f2 + p3.b + p4.b) / 4.0f));
    }

    private a a(a a2, boolean bl2, int n2, int n3) {
        int n4 = a2.a + n2;
        int n5 = a2.b + n3;
        while (this.a(n4, n5) && this.a.a(n4, n5) == bl2) {
            n4 += n2;
            n5 += n3;
        }
        int n6 = n4 - n2;
        n4 = n5 - n3;
        n5 = n6;
        while (this.a(n5, n4) && this.a.a(n5, n4) == bl2) {
            n5 += n2;
        }
        n2 = n4;
        while (this.a(n5 -= n2, n2) && this.a.a(n5, n2) == bl2) {
            n2 += n3;
        }
        return new a(n5, n2 - n3);
    }

    private boolean a(int n2, int n3) {
        if (n2 >= 0 && n2 < this.a.a && n3 > 0 && n3 < this.a.b) {
            return true;
        }
        return false;
    }

    private boolean a(p p2) {
        return this.a(d.b(p2.a), d.b(p2.b));
    }

    private static p[] a(p[] arrp, float f2, float f3) {
        f2 = f3 / (2.0f * f2);
        f3 = arrp[0].a - arrp[2].a;
        float f4 = arrp[0].b - arrp[2].b;
        float f5 = (arrp[0].a + arrp[2].a) / 2.0f;
        float f6 = (arrp[0].b + arrp[2].b) / 2.0f;
        p p2 = new p(f2 * f3 + f5, f2 * f4 + f6);
        p p3 = new p(f5 - f3 * f2, f6 - f4 * f2);
        f3 = arrp[1].a - arrp[3].a;
        f4 = arrp[1].b - arrp[3].b;
        f5 = (arrp[1].a + arrp[3].a) / 2.0f;
        f6 = (arrp[1].b + arrp[3].b) / 2.0f;
        return new p[]{p2, new p(f2 * f3 + f5, f2 * f4 + f6), p3, new p(f5 - f3 * f2, f6 - f2 * f4)};
    }

    private static float b(a a2, a a3) {
        return d.a(a2.a, a2.b, a3.a, a3.b);
    }

    private int b() {
        if (this.b) {
            return this.c * 4 + 11;
        }
        if (this.c <= 4) {
            return this.c * 4 + 15;
        }
        return this.c * 4 + ((this.c - 4) / 8 + 1) * 2 + 15;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final com.google.c.a.a a(boolean bl2) {
        int n2;
        Object object;
        float f2;
        Object object2;
        Object object3;
        int n3;
        long l2;
        p[] arrp = this.a();
        this.e = 1;
        Object object4 = arrp;
        boolean bl3 = true;
        Object object5 = arrp;
        Object object6 = arrp;
        while (this.e < 9) {
            object = this.a((a)object6, bl3, 1, -1);
            object2 = this.a((a)object5, bl3, 1, 1);
            a a2 = this.a((a)object4, bl3, -1, 1);
            object3 = this.a((a)arrp, bl3, -1, -1);
            if (this.e > 2) {
                f2 = a.b((a)object3, (a)object) * (float)this.e / (a.b((a)arrp, (a)object6) * (float)(this.e + 2));
                if ((double)f2 < 0.75 || (double)f2 > 1.25) break;
                a a3 = new a(object.a - 3, object.b + 3);
                a a4 = new a(object2.a - 3, object2.b - 3);
                a a5 = new a(a2.a + 3, a2.b - 3);
                a a6 = new a(object3.a + 3, object3.b + 3);
                n2 = this.a(a6, a3);
                n2 = n2 != 0 && this.a(a3, a4) == n2 && this.a(a4, a5) == n2 && this.a(a5, a6) == n2 ? 1 : 0;
                if (n2 == 0) break;
            }
            bl3 = !bl3;
            ++this.e;
            object4 = a2;
            object5 = object2;
            object6 = object;
            arrp = object3;
        }
        if (this.e != 5 && this.e != 7) {
            throw j.a();
        }
        bl3 = this.e == 5;
        this.b = bl3;
        object6 = new p((float)object6.a + 0.5f, (float)object6.b - 0.5f);
        object5 = new p((float)object5.a + 0.5f, (float)object5.b + 0.5f);
        object4 = new p((float)object4.a - 0.5f, (float)object4.b + 0.5f);
        arrp = new p((float)arrp.a - 0.5f, (float)arrp.b - 0.5f);
        f2 = this.e * 2 - 3;
        float f3 = this.e * 2;
        arrp = a.a(new p[]{object6, object5, object4, arrp}, f2, f3);
        if (bl2) {
            object4 = arrp[0];
            arrp[0] = arrp[2];
            arrp[2] = object4;
        }
        if (!(this.a(arrp[0]) && this.a(arrp[1]) && this.a(arrp[2]) && this.a(arrp[3]))) {
            throw j.a();
        }
        int n4 = this.e * 2;
        object4 = new int[]{this.a(arrp[0], arrp[1], n4), this.a(arrp[1], arrp[2], n4), this.a(arrp[2], arrp[3], n4), this.a(arrp[3], arrp[0], n4)};
        n2 = 0;
        for (n3 = 0; n3 < 4; ++n3) {
            int n5 = object4[n3];
            n2 = (n2 << 3) + ((n5 & 1) + (n5 >> n4 - 2 << 1));
        }
        n3 = 0;
        do {
            if (n3 >= 4) {
                throw j.a();
            }
            if (Integer.bitCount(g[n3] ^ (n2 >> 1) + ((n2 & 1) << 11)) <= 2) {
                this.f = n3;
                l2 = 0;
                break;
            }
            ++n3;
        } while (true);
        for (n2 = 0; n2 < 4; ++n2) {
            n3 = object4[(this.f + n2) % 4];
            l2 = this.b ? (l2 << 7) + (long)(n3 >> 1 & 127) : (l2 << 10) + (long)((n3 >> 1 & 31) + (n3 >> 2 & 992));
        }
        n2 = a.a(l2, this.b);
        if (this.b) {
            this.c = (n2 >> 6) + 1;
            this.d = (n2 & 63) + 1;
        } else {
            this.c = (n2 >> 11) + 1;
            this.d = (n2 & 2047) + 1;
        }
        object4 = this.a;
        object5 = arrp[this.f % 4];
        object6 = arrp[(this.f + 1) % 4];
        object3 = arrp[(this.f + 2) % 4];
        object = arrp[(this.f + 3) % 4];
        object2 = i.a();
        n2 = this.b();
        f2 = (float)n2 / 2.0f - (float)this.e;
        f3 = (float)n2 / 2.0f + (float)this.e;
        return new com.google.c.a.a(object2.a((b)object4, n2, n2, f2, f2, f3, f2, f3, f3, f2, f3, object5.a, object5.b, object6.a, object6.b, object3.a, object3.b, object.a, object.b), a.a(arrp, this.e * 2, this.b()), this.b, this.d, this.c);
    }

    static final class a {
        final int a;
        final int b;

        a(int n2, int n3) {
            this.a = n2;
            this.b = n3;
        }

        final p a() {
            return new p(this.a, this.b);
        }

        public final String toString() {
            return "<" + this.a + ' ' + this.b + '>';
        }
    }

}

