/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import com.google.c.b.a;
import com.google.c.h;

public abstract class b {
    public final h a;

    public b(h h2) {
        this.a = h2;
    }

    public abstract a a(int var1, a var2);

    public abstract com.google.c.b.b a();
}

