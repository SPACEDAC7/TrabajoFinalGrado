/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

import java.util.Arrays;

public final class a
implements Cloneable {
    public int[] a;
    public int b;

    public a() {
        this.b = 0;
        this.a = new int[1];
    }

    public a(int n2) {
        this.b = n2;
        this.a = a.f(n2);
    }

    private a(int[] arrn, int n2) {
        this.a = arrn;
        this.b = n2;
    }

    private void e(int n2) {
        if (n2 > this.a.length << 5) {
            int[] arrn = a.f(n2);
            System.arraycopy(this.a, 0, arrn, 0, this.a.length);
            this.a = arrn;
        }
    }

    private static int[] f(int n2) {
        return new int[(n2 + 31) / 32];
    }

    public final int a() {
        return (this.b + 7) / 8;
    }

    public final void a(int n2, byte[] arrby, int n3) {
        for (int i2 = 0; i2 < n3; ++i2) {
            int n4 = 0;
            for (int i3 = 0; i3 < 8; ++i3) {
                int n5 = n4;
                if (this.a(n2)) {
                    n5 = n4 | 1 << 7 - i3;
                }
                ++n2;
                n4 = n5;
            }
            arrby[i2] = n4;
        }
    }

    public final void a(a a2) {
        int n2 = a2.b;
        this.e(this.b + n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            this.a(a2.a(i2));
        }
    }

    public final void a(boolean bl2) {
        this.e(this.b + 1);
        if (bl2) {
            int[] arrn = this.a;
            int n2 = this.b / 32;
            arrn[n2] = arrn[n2] | 1 << (this.b & 31);
        }
        ++this.b;
    }

    public final boolean a(int n2) {
        if ((this.a[n2 / 32] & 1 << (n2 & 31)) != 0) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean a(int n2, int n3) {
        if (n3 < n2) {
            throw new IllegalArgumentException();
        }
        if (n3 == n2) {
            return true;
        }
        int n4 = n3 - 1;
        int n5 = n2 / 32;
        int n6 = n4 / 32;
        int n7 = n5;
        while (n7 <= n6) {
            int n8;
            n3 = n7 > n5 ? 0 : n2 & 31;
            int n9 = n7 < n6 ? 31 : n4 & 31;
            if (n3 == 0 && n9 == 31) {
                n8 = -1;
            } else {
                n8 = 0;
                int n10 = n3;
                n3 = n8;
                do {
                    n8 = n3;
                    if (n10 > n9) break;
                    n3 |= 1 << n10;
                    ++n10;
                } while (true);
            }
            if ((n8 & this.a[n7]) != 0) {
                return false;
            }
            ++n7;
        }
        return true;
    }

    public final void b() {
        int n2 = this.a.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            this.a[i2] = 0;
        }
    }

    public final void b(int n2) {
        int[] arrn = this.a;
        int n3 = n2 / 32;
        arrn[n3] = arrn[n3] | 1 << (n2 & 31);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void b(int n2, int n3) {
        if (n3 < 0 || n3 > 32) {
            throw new IllegalArgumentException("Num bits must be between 0 and 32");
        }
        this.e(this.b + n3);
        while (n3 > 0) {
            boolean bl2 = (n2 >> n3 - 1 & 1) == 1;
            this.a(bl2);
            --n3;
        }
        return;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final int c(int n2) {
        if (n2 >= this.b) {
            return this.b;
        }
        int n3 = n2 / 32;
        int n4 = this.a[n3] & ~ ((1 << (n2 & 31)) - 1);
        n2 = n3;
        while (n4 == 0) {
            if (++n2 == this.a.length) {
                return this.b;
            }
            n4 = this.a[n2];
        }
        n2 = n4 = (n2 << 5) + Integer.numberOfTrailingZeros(n4);
        if (n4 <= this.b) return n2;
        return this.b;
    }

    public final void c() {
        int n2;
        int n3 = 1;
        int[] arrn = new int[this.a.length];
        int n4 = (this.b - 1) / 32;
        int n5 = n4 + 1;
        for (n2 = 0; n2 < n5; ++n2) {
            long l2 = this.a[n2];
            l2 = (l2 & 0x55555555) << 1 | l2 >> 1 & 0x55555555;
            l2 = (l2 & 0x33333333) << 2 | l2 >> 2 & 0x33333333;
            l2 = (l2 & 0xF0F0F0F) << 4 | l2 >> 4 & 0xF0F0F0F;
            l2 = (l2 & 0xFF00FF) << 8 | l2 >> 8 & 0xFF00FF;
            arrn[n4 - n2] = (int)((l2 & 65535) << 16 | l2 >> 16 & 65535);
        }
        if (this.b != n5 << 5) {
            int n6 = (n5 << 5) - this.b;
            n2 = 1;
            for (n4 = 0; n4 < 31 - n6; ++n4) {
                n2 = n2 << 1 | 1;
            }
            int n7 = arrn[0] >> n6 & n2;
            n4 = n3;
            n3 = n7;
            while (n4 < n5) {
                n7 = arrn[n4];
                arrn[n4 - 1] = n3 | n7 << 32 - n6;
                n3 = n7 >> n6 & n2;
                ++n4;
            }
            arrn[n5 - 1] = n3;
        }
        this.a = arrn;
    }

    public final /* synthetic */ Object clone() {
        return new a((int[])this.a.clone(), this.b);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final int d(int n2) {
        if (n2 >= this.b) {
            return this.b;
        }
        int n3 = n2 / 32;
        int n4 = ~ this.a[n3] & ~ ((1 << (n2 & 31)) - 1);
        n2 = n3;
        while (n4 == 0) {
            if (++n2 == this.a.length) {
                return this.b;
            }
            n4 = ~ this.a[n2];
        }
        n2 = n4 = (n2 << 5) + Integer.numberOfTrailingZeros(n4);
        if (n4 <= this.b) return n2;
        return this.b;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (!(object instanceof a)) {
            return false;
        }
        object = (a)object;
        if (this.b != object.b) return false;
        if (!Arrays.equals(this.a, object.a)) return false;
        return true;
    }

    public final int hashCode() {
        return this.b * 31 + Arrays.hashCode(this.a);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(this.b);
        int n2 = 0;
        while (n2 < this.b) {
            if ((n2 & 7) == 0) {
                stringBuilder.append(' ');
            }
            char c2 = this.a(n2) ? 'X' : '.';
            stringBuilder.append(c2);
            ++n2;
        }
        return stringBuilder.toString();
    }
}

