/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b.a;

import a.a.a.a.d;
import com.google.c.b.b;
import com.google.c.j;
import com.google.c.p;

public final class a {
    private final b a;
    private final int b;
    private final int c;
    private final int d;
    private final int e;
    private final int f;
    private final int g;

    public a(b b2) {
        this(b2, 10, b2.a / 2, b2.b / 2);
    }

    public a(b b2, int n2, int n3, int n4) {
        this.a = b2;
        this.b = b2.b;
        this.c = b2.a;
        this.d = n3 - (n2 /= 2);
        this.e = n3 + n2;
        this.g = n4 - n2;
        this.f = n2 + n4;
        if (this.g < 0 || this.d < 0 || this.f >= this.b || this.e >= this.c) {
            throw j.a();
        }
    }

    private p a(float f2, float f3, float f4, float f5) {
        int n2 = d.b(d.a(f2, f3, f4, f5));
        f4 = (f4 - f2) / (float)n2;
        f5 = (f5 - f3) / (float)n2;
        for (int i2 = 0; i2 < n2; ++i2) {
            int n3;
            int n4 = d.b((float)i2 * f4 + f2);
            if (!this.a.a(n4, n3 = d.b((float)i2 * f5 + f3))) continue;
            return new p(n4, n3);
        }
        return null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private boolean a(int var1_1, int var2_2, int var3_3, boolean var4_4) {
        var5_5 = var1_1;
        if (!var4_4) ** GOTO lbl10
        while (var1_1 <= var2_2) {
            if (this.a.a(var1_1, var3_3)) {
                return true;
            }
            ++var1_1;
        }
        return false;
lbl-1000: // 1 sources:
        {
            ++var5_5;
lbl10: // 2 sources:
            if (var5_5 > var2_2) return false;
            ** while (!this.a.a((int)var3_3, (int)var5_5))
        }
lbl12: // 1 sources:
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final p[] a() {
        var17_1 = this.d;
        var14_2 = this.e;
        var15_3 = this.g;
        var16_4 = this.f;
        var24_5 = 0;
        var22_6 = false;
        var18_7 = 0;
        var20_8 = 0;
        var19_9 = 0;
        var23_10 = false;
        var21_11 = true;
        do {
            if (var21_11) ** GOTO lbl22
            var19_9 = var14_2;
            var20_8 = var16_4;
            var14_2 = var15_3;
            var18_7 = var24_5;
            var16_4 = var17_1;
            var15_3 = var20_8;
            var17_1 = var19_9;
            ** GOTO lbl49
lbl22: // 1 sources:
            var25_12 = true;
            var21_11 = false;
            while ((var25_12 || var18_7 == 0) && var14_2 < this.c) {
                var26_13 = this.a(var15_3, var16_4, var14_2, false);
                if (var26_13) {
                    var21_11 = true;
                    ++var14_2;
                    var18_7 = 1;
                    var25_12 = var26_13;
                    continue;
                }
                var25_12 = var26_13;
                if (var18_7 != 0) continue;
                ++var14_2;
                var25_12 = var26_13;
            }
            if (var14_2 < this.c) {
                var25_12 = true;
            } else {
                var20_8 = 1;
                var18_7 = var14_2;
                var14_2 = var17_1;
                var19_9 = var15_3;
                var17_1 = var18_7;
                var15_3 = var16_4;
                var16_4 = var14_2;
                var14_2 = var19_9;
                var18_7 = var20_8;
lbl49: // 5 sources:
                do {
                    if (var18_7 != 0) throw j.a();
                    if (var22_6 == false) throw j.a();
                    var19_9 = var17_1 - var16_4;
                    var9_14 = null;
                    var18_7 = 1;
                    do {
                        var10_15 = var9_14;
                        if (var18_7 >= var19_9) break;
                        var10_15 = var9_14 = this.a((float)var16_4, (float)(var15_3 - var18_7), (float)(var16_4 + var18_7), var15_3);
                        if (var9_14 != null) break;
                        ++var18_7;
                    } while (true);
                    if (var10_15 == null) {
                        throw j.a();
                    }
                    var9_14 = null;
                    var18_7 = 1;
                    do {
                        var11_16 = var9_14;
                        if (var18_7 >= var19_9) break;
                        var11_16 = var9_14 = this.a((float)var16_4, (float)(var14_2 + var18_7), (float)(var16_4 + var18_7), var14_2);
                        if (var9_14 != null) break;
                        ++var18_7;
                    } while (true);
                    if (var11_16 == null) {
                        throw j.a();
                    }
                    var9_14 = null;
                    var16_4 = 1;
                    do {
                        var12_17 = var9_14;
                        if (var16_4 >= var19_9) break;
                        var12_17 = var9_14 = this.a((float)var17_1, (float)(var14_2 + var16_4), (float)(var17_1 - var16_4), var14_2);
                        if (var9_14 != null) break;
                        ++var16_4;
                    } while (true);
                    if (var12_17 == null) {
                        throw j.a();
                    }
                    var9_14 = null;
                    var14_2 = 1;
                    do {
                        var13_18 = var9_14;
                        if (var14_2 >= var19_9) break;
                        var13_18 = var9_14 = this.a((float)var17_1, (float)(var15_3 - var14_2), (float)(var17_1 - var14_2), var15_3);
                        if (var9_14 != null) break;
                        ++var14_2;
                    } while (true);
                    if (var13_18 == null) {
                        throw j.a();
                    }
                    var1_19 = var13_18.a;
                    var2_20 = var13_18.b;
                    var3_21 = var10_15.a;
                    var4_22 = var10_15.b;
                    var5_23 = var12_17.a;
                    var6_24 = var12_17.b;
                    var7_25 = var11_16.a;
                    var8_26 = var11_16.b;
                    if (var1_19 >= (float)this.c / 2.0f) return new p[]{new p(var7_25 + 1.0f, var8_26 + 1.0f), new p(var3_21 + 1.0f, var4_22 - 1.0f), new p(var5_23 - 1.0f, var6_24 + 1.0f), new p(var1_19 - 1.0f, var2_20 - 1.0f)};
                    return new p[]{new p(var7_25 - 1.0f, var8_26 + 1.0f), new p(var3_21 + 1.0f, var4_22 + 1.0f), new p(var5_23 - 1.0f, var6_24 - 1.0f), new p(var1_19 + 1.0f, var2_20 - 1.0f)};
                    break;
                } while (true);
            }
            while ((var25_12 || var20_8 == 0) && var16_4 < this.b) {
                var26_13 = this.a(var17_1, var14_2, var16_4, true);
                if (var26_13) {
                    var21_11 = true;
                    ++var16_4;
                    var20_8 = 1;
                    var25_12 = var26_13;
                    continue;
                }
                var25_12 = var26_13;
                if (var20_8 != 0) continue;
                ++var16_4;
                var25_12 = var26_13;
            }
            if (var16_4 < this.b) ** GOTO lbl129
            var18_7 = 1;
            var19_9 = var14_2;
            var20_8 = var16_4;
            var14_2 = var15_3;
            var16_4 = var17_1;
            var15_3 = var20_8;
            var17_1 = var19_9;
            ** GOTO lbl49
lbl129: // 1 sources:
            var25_12 = true;
            while ((var25_12 || var19_9 == 0) && var17_1 >= 0) {
                var26_13 = this.a(var15_3, var16_4, var17_1, false);
                if (var26_13) {
                    var21_11 = true;
                    --var17_1;
                    var19_9 = 1;
                    var25_12 = var26_13;
                    continue;
                }
                var25_12 = var26_13;
                if (var19_9 != 0) continue;
                --var17_1;
                var25_12 = var26_13;
            }
            if (var17_1 >= 0) ** GOTO lbl152
            var18_7 = 1;
            var19_9 = var14_2;
            var20_8 = var16_4;
            var14_2 = var15_3;
            var16_4 = var17_1;
            var15_3 = var20_8;
            var17_1 = var19_9;
            ** GOTO lbl49
lbl152: // 1 sources:
            var25_12 = true;
            while ((var25_12 || !var23_10) && var15_3 >= 0) {
                var26_13 = this.a(var17_1, var14_2, var15_3, true);
                if (var26_13) {
                    --var15_3;
                    var21_11 = true;
                    var23_10 = true;
                    var25_12 = var26_13;
                    continue;
                }
                var25_12 = var26_13;
                if (var23_10) continue;
                --var15_3;
                var25_12 = var26_13;
            }
            if (var15_3 < 0) {
                var18_7 = 1;
                var19_9 = var14_2;
                var20_8 = var16_4;
                var14_2 = var15_3;
                var16_4 = var17_1;
                var15_3 = var20_8;
                var17_1 = var19_9;
                ** continue;
            }
            if (!var21_11) continue;
            var22_6 = true;
        } while (true);
    }
}

