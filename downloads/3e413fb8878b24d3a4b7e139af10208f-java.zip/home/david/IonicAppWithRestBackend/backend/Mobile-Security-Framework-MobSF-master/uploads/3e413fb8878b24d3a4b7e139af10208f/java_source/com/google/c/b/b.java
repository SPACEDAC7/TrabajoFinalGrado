/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

import com.google.c.b.a;
import java.util.Arrays;

public final class b
implements Cloneable {
    public final int a;
    public final int b;
    public final int c;
    public final int[] d;

    public b(int n2) {
        this(n2, n2);
    }

    public b(int n2, int n3) {
        if (n2 <= 0 || n3 <= 0) {
            throw new IllegalArgumentException("Both dimensions must be greater than 0");
        }
        this.a = n2;
        this.b = n3;
        this.c = (n2 + 31) / 32;
        this.d = new int[this.c * n3];
    }

    private b(int n2, int n3, int n4, int[] arrn) {
        this.a = n2;
        this.b = n3;
        this.c = n4;
        this.d = arrn;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final a a(int n2, a a2) {
        if (a2 == null || a2.b < this.a) {
            a2 = new a(this.a);
        } else {
            a2.b();
        }
        int n3 = this.c;
        int n4 = 0;
        while (n4 < this.c) {
            int n5;
            a2.a[(n4 << 5) / 32] = n5 = this.d[n2 * n3 + n4];
            ++n4;
        }
        return a2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(int var1_1, int var2_2, int var3_3, int var4_4) {
        if (var2_2 < 0) throw new IllegalArgumentException("Left and top must be nonnegative");
        if (var1_1 < 0) {
            throw new IllegalArgumentException("Left and top must be nonnegative");
        }
        if (var4_4 <= 0) throw new IllegalArgumentException("Height and width must be at least 1");
        if (var3_3 <= 0) {
            throw new IllegalArgumentException("Height and width must be at least 1");
        }
        var6_5 = var1_1 + var3_3;
        if ((var4_4 = var2_2 + var4_4) > this.b) throw new IllegalArgumentException("The region must fit inside the matrix");
        if (var6_5 <= this.a) ** GOTO lbl12
        throw new IllegalArgumentException("The region must fit inside the matrix");
        {
            ++var2_2;
lbl12: // 2 sources:
            if (var2_2 >= var4_4) return;
            var7_7 = this.c;
            var3_3 = var1_1;
            do {
                if (var3_3 >= var6_5) continue block0;
                var5_6 = this.d;
                var8_8 = var3_3 / 32 + var2_2 * var7_7;
                var5_6[var8_8] = var5_6[var8_8] | 1 << (var3_3 & 31);
                ++var3_3;
            } while (true);
        }
    }

    public final boolean a(int n2, int n3) {
        int n4 = this.c;
        int n5 = n2 / 32;
        if ((this.d[n4 * n3 + n5] >>> (n2 & 31) & 1) != 0) {
            return true;
        }
        return false;
    }

    public final int[] a() {
        int n2;
        for (n2 = 0; n2 < this.d.length && this.d[n2] == 0; ++n2) {
        }
        if (n2 == this.d.length) {
            return null;
        }
        int n3 = n2 / this.c;
        int n4 = this.c;
        int n5 = this.d[n2];
        int n6 = 0;
        while (n5 << 31 - n6 == 0) {
            ++n6;
        }
        return new int[]{(n2 % n4 << 5) + n6, n3};
    }

    public final void b(int n2, int n3) {
        n3 = this.c * n3 + n2 / 32;
        int[] arrn = this.d;
        arrn[n3] = arrn[n3] | 1 << (n2 & 31);
    }

    public final void b(int n2, a a2) {
        System.arraycopy(a2.a, 0, this.d, this.c * n2, this.c);
    }

    public final int[] b() {
        int n2;
        for (n2 = this.d.length - 1; n2 >= 0 && this.d[n2] == 0; --n2) {
        }
        if (n2 < 0) {
            return null;
        }
        int n3 = n2 / this.c;
        int n4 = this.c;
        int n5 = this.d[n2];
        int n6 = 31;
        while (n5 >>> n6 == 0) {
            --n6;
        }
        return new int[]{(n2 % n4 << 5) + n6, n3};
    }

    public final b c() {
        return new b(this.a, this.b, this.c, (int[])this.d.clone());
    }

    public final void c(int n2, int n3) {
        n3 = this.c * n3 + n2 / 32;
        int[] arrn = this.d;
        arrn[n3] = arrn[n3] ^ 1 << (n2 & 31);
    }

    public final /* synthetic */ Object clone() {
        return this.c();
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (!(object instanceof b)) {
            return false;
        }
        object = (b)object;
        if (this.a != object.a) return false;
        if (this.b != object.b) return false;
        if (this.c != object.c) return false;
        if (!Arrays.equals(this.d, object.d)) return false;
        return true;
    }

    public final int hashCode() {
        return (((this.a * 31 + this.a) * 31 + this.b) * 31 + this.c) * 31 + Arrays.hashCode(this.d);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(this.b * (this.a + 1));
        int n2 = 0;
        while (n2 < this.b) {
            for (int i2 = 0; i2 < this.a; ++i2) {
                String string = this.a(i2, n2) ? "X " : "  ";
                stringBuilder.append(string);
            }
            stringBuilder.append('\n');
            ++n2;
        }
        return stringBuilder.toString();
    }
}

