/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b.b;

import com.google.c.b.b.b;

public final class a {
    public static final a a;
    public static final a b;
    public static final a c;
    public static final a d;
    public static final a e;
    public static final a f;
    public static final a g;
    public static final a h;
    final int[] i;
    final b j;
    final b k;
    final int l;
    final int m;
    private final int[] n;
    private final int o;

    static {
        a a2;
        a = new a(4201, 4096, 1);
        b = new a(1033, 1024, 1);
        c = new a(67, 64, 1);
        d = new a(19, 16, 1);
        e = new a(285, 256, 0);
        f = a2 = new a(301, 256, 1);
        g = a2;
        h = c;
    }

    private a(int n2, int n3, int n4) {
        this.o = n2;
        this.l = n3;
        this.m = n4;
        this.i = new int[n3];
        this.n = new int[n3];
        n4 = 1;
        for (int i2 = 0; i2 < n3; ++i2) {
            int n5;
            this.i[i2] = n4;
            n4 = n5 = n4 << 1;
            if (n5 < n3) continue;
            n4 = (n5 ^ n2) & n3 - 1;
        }
        n2 = 0;
        while (n2 < n3 - 1) {
            this.n[this.i[n2]] = n2++;
        }
        this.j = new b(this, new int[]{0});
        this.k = new b(this, new int[]{1});
    }

    static int b(int n2, int n3) {
        return n2 ^ n3;
    }

    final int a(int n2) {
        if (n2 == 0) {
            throw new IllegalArgumentException();
        }
        return this.n[n2];
    }

    final b a(int n2, int n3) {
        if (n2 < 0) {
            throw new IllegalArgumentException();
        }
        if (n3 == 0) {
            return this.j;
        }
        int[] arrn = new int[n2 + 1];
        arrn[0] = n3;
        return new b(this, arrn);
    }

    final int b(int n2) {
        if (n2 == 0) {
            throw new ArithmeticException();
        }
        return this.i[this.l - this.n[n2] - 1];
    }

    final int c(int n2, int n3) {
        if (n2 == 0 || n3 == 0) {
            return 0;
        }
        return this.i[(this.n[n2] + this.n[n3]) % (this.l - 1)];
    }

    public final String toString() {
        return "GF(0x" + Integer.toHexString(this.o) + ',' + this.l + ')';
    }
}

