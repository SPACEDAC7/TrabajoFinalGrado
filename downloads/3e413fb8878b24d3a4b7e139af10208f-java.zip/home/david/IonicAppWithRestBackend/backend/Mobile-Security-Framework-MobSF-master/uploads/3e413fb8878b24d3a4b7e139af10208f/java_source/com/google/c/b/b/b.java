/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b.b;

import com.google.c.b.b.a;

public final class b {
    public final int[] a;
    private final a b;

    public b(a a2, int[] arrn) {
        if (arrn.length == 0) {
            throw new IllegalArgumentException();
        }
        this.b = a2;
        int n2 = arrn.length;
        if (n2 > 1 && arrn[0] == 0) {
            int n3;
            for (n3 = 1; n3 < n2 && arrn[n3] == 0; ++n3) {
            }
            if (n3 == n2) {
                this.a = new int[]{0};
                return;
            }
            this.a = new int[n2 - n3];
            System.arraycopy(arrn, n3, this.a, 0, this.a.length);
            return;
        }
        this.a = arrn;
    }

    final int a(int n2) {
        return this.a[this.a.length - 1 - n2];
    }

    public final b a(int n2, int n3) {
        if (n2 < 0) {
            throw new IllegalArgumentException();
        }
        if (n3 == 0) {
            return this.b.j;
        }
        int n4 = this.a.length;
        int[] arrn = new int[n4 + n2];
        for (n2 = 0; n2 < n4; ++n2) {
            arrn[n2] = this.b.c(this.a[n2], n3);
        }
        return new b(this.b, arrn);
    }

    /*
     * Enabled aggressive block sorting
     */
    final b a(b arrn) {
        int[] arrn2;
        if (!this.b.equals(arrn.b)) {
            throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
        }
        if (this.a()) {
            return arrn;
        }
        if (arrn.a()) {
            return this;
        }
        int[] arrn3 = this.a;
        arrn = arrn.a;
        if (arrn3.length <= arrn.length) {
            arrn2 = arrn;
            arrn = arrn3;
            arrn3 = arrn2;
        }
        arrn2 = new int[arrn3.length];
        int n2 = arrn3.length - arrn.length;
        System.arraycopy(arrn3, 0, arrn2, 0, n2);
        int n3 = n2;
        while (n3 < arrn3.length) {
            arrn2[n3] = a.b(arrn[n3 - n2], arrn3[n3]);
            ++n3;
        }
        return new b(this.b, arrn2);
    }

    final boolean a() {
        boolean bl2 = false;
        if (this.a[0] == 0) {
            bl2 = true;
        }
        return bl2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    final int b(int n2) {
        int n3;
        int n4 = 0;
        if (n2 == 0) {
            return this.a(0);
        }
        int n5 = this.a.length;
        if (n2 == 1) {
            int[] arrn = this.a;
            int n6 = arrn.length;
            n2 = 0;
            do {
                n3 = n2;
                if (n4 >= n6) return n3;
                n2 = a.b(n2, arrn[n4]);
                ++n4;
            } while (true);
        }
        n4 = this.a[0];
        int n7 = 1;
        do {
            n3 = n4;
            if (n7 >= n5) return n3;
            n4 = a.b(this.b.c(n2, n4), this.a[n7]);
            ++n7;
        } while (true);
    }

    final b b(b arrn) {
        if (!this.b.equals(arrn.b)) {
            throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
        }
        if (this.a() || arrn.a()) {
            return this.b.j;
        }
        int[] arrn2 = this.a;
        int n2 = arrn2.length;
        arrn = arrn.a;
        int n3 = arrn.length;
        int[] arrn3 = new int[n2 + n3 - 1];
        for (int i2 = 0; i2 < n2; ++i2) {
            int n4 = arrn2[i2];
            for (int i3 = 0; i3 < n3; ++i3) {
                arrn3[i2 + i3] = a.b(arrn3[i2 + i3], this.b.c(n4, arrn[i3]));
            }
        }
        return new b(this.b, arrn3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    final b c(int n2) {
        if (n2 == 0) {
            return this.b.j;
        }
        int[] arrn = this;
        if (n2 == 1) return arrn;
        int n3 = this.a.length;
        arrn = new int[n3];
        int n4 = 0;
        while (n4 < n3) {
            arrn[n4] = this.b.c(this.a[n4], n2);
            ++n4;
        }
        return new b(this.b, arrn);
    }

    public final b[] c(b b2) {
        if (!this.b.equals(b2.b)) {
            throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
        }
        if (b2.a()) {
            throw new IllegalArgumentException("Divide by 0");
        }
        b b3 = this.b.j;
        int n2 = b2.a(b2.a.length - 1);
        n2 = this.b.b(n2);
        b b4 = this;
        while (b4.a.length - 1 >= b2.a.length - 1 && !b4.a()) {
            int n3 = b4.a.length - 1 - (b2.a.length - 1);
            int n4 = this.b.c(b4.a(b4.a.length - 1), n2);
            b b5 = b2.a(n3, n4);
            b3 = b3.a(this.b.a(n3, n4));
            b4 = b4.a(b5);
        }
        return new b[]{b3, b4};
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder((this.a.length - 1) * 8);
        int n2 = this.a.length - 1;
        while (n2 >= 0) {
            int n3 = this.a(n2);
            if (n3 != 0) {
                int n4;
                if (n3 < 0) {
                    stringBuilder.append(" - ");
                    n4 = - n3;
                } else {
                    n4 = n3;
                    if (stringBuilder.length() > 0) {
                        stringBuilder.append(" + ");
                        n4 = n3;
                    }
                }
                if (n2 == 0 || n4 != 1) {
                    if ((n4 = this.b.a(n4)) == 0) {
                        stringBuilder.append('1');
                    } else if (n4 == 1) {
                        stringBuilder.append('a');
                    } else {
                        stringBuilder.append("a^");
                        stringBuilder.append(n4);
                    }
                }
                if (n2 != 0) {
                    if (n2 == 1) {
                        stringBuilder.append('x');
                    } else {
                        stringBuilder.append("x^");
                        stringBuilder.append(n2);
                    }
                }
            }
            --n2;
        }
        return stringBuilder.toString();
    }
}

