/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b.b;

import com.google.c.b.b.a;
import com.google.c.b.b.b;
import com.google.c.b.b.e;

public final class c {
    private final a a;

    public c(a a2) {
        this.a = a2;
    }

    private int[] a(b b2) {
        int n2 = 0;
        int n3 = b2.a.length - 1;
        if (n3 == 1) {
            return new int[]{b2.a(1)};
        }
        int[] arrn = new int[n3];
        for (int i2 = 1; i2 < this.a.l && n2 < n3; ++i2) {
            int n4 = n2;
            if (b2.b(i2) == 0) {
                arrn[n2] = this.a.b(i2);
                n4 = n2 + 1;
            }
            n2 = n4;
        }
        if (n2 != n3) {
            throw new e("Error locator degree does not match number of roots");
        }
        return arrn;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int[] a(b b2, int[] arrn) {
        int n2 = arrn.length;
        int[] arrn2 = new int[n2];
        int n3 = 0;
        while (n3 < n2) {
            int n4 = this.a.b(arrn[n3]);
            int n5 = 1;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (n3 == i2) continue;
                int n6 = this.a.c(arrn[i2], n4);
                n6 = (n6 & 1) == 0 ? (n6 |= 1) : (n6 &= -2);
                n5 = this.a.c(n5, n6);
            }
            arrn2[n3] = this.a.c(b2.b(n4), this.a.b(n5));
            if (this.a.m != 0) {
                arrn2[n3] = this.a.c(arrn2[n3], n4);
            }
            ++n3;
        }
        return arrn2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void a(int[] arrn, int n2) {
        int n3 = 0;
        b b2 = new b(this.a, arrn);
        int[] arrn2 = new int[n2];
        int n4 = 0;
        int n5 = 1;
        while (n4 < n2) {
            a a2 = this.a;
            int n6 = this.a.m;
            arrn2[arrn2.length - 1 - n4] = n6 = b2.b(a2.i[n6 + n4]);
            if (n6 != 0) {
                n5 = 0;
            }
            ++n4;
        }
    }
}

