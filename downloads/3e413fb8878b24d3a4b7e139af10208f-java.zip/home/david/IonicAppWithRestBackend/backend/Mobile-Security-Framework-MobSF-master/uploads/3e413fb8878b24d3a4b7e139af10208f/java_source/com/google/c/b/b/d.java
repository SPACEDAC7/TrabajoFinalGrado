/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b.b;

import com.google.c.b.b.a;
import com.google.c.b.b.b;
import java.util.ArrayList;
import java.util.List;

public final class d {
    public final a a;
    private final List<b> b;

    public d(a a2) {
        this.a = a2;
        this.b = new ArrayList<b>();
        this.b.add(new b(a2, new int[]{1}));
    }

    public final b a(int n2) {
        if (n2 >= this.b.size()) {
            b b2 = this.b.get(this.b.size() - 1);
            for (int i2 = this.b.size(); i2 <= n2; ++i2) {
                a a2 = this.a;
                a a3 = this.a;
                int n3 = this.a.m;
                b2 = b2.b(new b(a2, new int[]{1, a3.i[i2 - 1 + n3]}));
                this.b.add(b2);
            }
        }
        return this.b.get(n2);
    }
}

