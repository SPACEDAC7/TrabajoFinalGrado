/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b.b;

public final class e
extends Exception {
    public e(String string) {
        super(string);
    }
}

