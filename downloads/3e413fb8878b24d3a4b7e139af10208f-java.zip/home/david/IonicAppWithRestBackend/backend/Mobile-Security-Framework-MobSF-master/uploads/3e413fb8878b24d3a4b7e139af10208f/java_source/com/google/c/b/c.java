/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

public final class c {
    public int a;
    public int b;
    private final byte[] c;

    public c(byte[] arrby) {
        this.c = arrby;
    }

    public final int a() {
        return (this.c.length - this.a) * 8 - this.b;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int a(int n2) {
        int n3;
        int n4;
        if (n2 <= 0 || n2 > 32 || n2 > this.a()) {
            throw new IllegalArgumentException(String.valueOf(n2));
        }
        if (this.b > 0) {
            n3 = 8 - this.b;
            n4 = n2 < n3 ? n2 : n3;
            n3 -= n4;
            int n5 = this.c[this.a];
            this.b = n4 + this.b;
            if (this.b == 8) {
                this.b = 0;
                ++this.a;
            }
            n5 = (255 >> 8 - n4 << n3 & n5) >> n3;
            n3 = n2 - n4;
            n2 = n5;
        } else {
            n4 = 0;
            n3 = n2;
            n2 = n4;
        }
        n4 = n2;
        if (n3 > 0) {
            while (n3 >= 8) {
                n2 = n2 << 8 | this.c[this.a] & 255;
                ++this.a;
                n3 -= 8;
            }
            n4 = n2;
            if (n3 > 0) {
                n4 = 8 - n3;
                n4 = n2 << n3 | (255 >> n4 << n4 & this.c[this.a]) >> n4;
                this.b = n3 + this.b;
            }
        }
        return n4;
    }
}

