/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

import com.google.c.g;
import java.util.HashMap;
import java.util.Map;

public enum d {
    a(new int[]{0, 2}, new String[0]),
    b(new int[]{1, 3}, "ISO-8859-1"),
    c(4, "ISO-8859-2"),
    d(5, "ISO-8859-3"),
    e(6, "ISO-8859-4"),
    f(7, "ISO-8859-5"),
    g(8, "ISO-8859-6"),
    h(9, "ISO-8859-7"),
    i(10, "ISO-8859-8"),
    j(11, "ISO-8859-9"),
    k(12, "ISO-8859-10"),
    l(13, "ISO-8859-11"),
    m(15, "ISO-8859-13"),
    n(16, "ISO-8859-14"),
    o(17, "ISO-8859-15"),
    p(18, "ISO-8859-16"),
    q(20, "Shift_JIS"),
    r(21, "windows-1250"),
    s(22, "windows-1251"),
    t(23, "windows-1252"),
    u(24, "windows-1256"),
    v(25, "UTF-16BE", "UnicodeBig"),
    w(26, "UTF-8"),
    x(new int[]{27, 170}, "US-ASCII"),
    y,
    z(29, "GB2312", "EUC_CN", "GBK"),
    A(30, "EUC-KR");
    
    private static final Map<Integer, d> C;
    private static final Map<String, d> D;
    public final int[] B;
    private final String[] E;

    static {
        C = new HashMap<Integer, d>();
        D = new HashMap<String, d>();
        for (d d2 : d.values()) {
            for (int n2 : d2.B) {
                C.put(n2, d2);
            }
            D.put(d2.name(), d2);
            for (int n3 : d2.E) {
                D.put((String)((int)n3), d2);
            }
        }
    }

    private d(int n3) {
        this(new int[]{28}, new String[0]);
    }

    private /* varargs */ d(int n3, String ... arrstring) {
        this.B = new int[]{n3};
        this.E = arrstring;
    }

    private /* varargs */ d(int[] arrn, String ... arrstring) {
        this.B = arrn;
        this.E = arrstring;
    }

    public static d a(int n2) {
        if (n2 < 0 || n2 >= 900) {
            throw g.a();
        }
        return C.get(n2);
    }

    public static d a(String string) {
        return D.get(string);
    }
}

