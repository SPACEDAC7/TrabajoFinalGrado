/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

import java.util.List;

public final class e {
    public final byte[] a;
    public final String b;
    public final List<byte[]> c;
    public final String d;
    public Integer e;
    public Integer f;
    public Object g;
    public final int h;
    public final int i;

    public e(byte[] arrby, String string, List<byte[]> list, String string2) {
        this(arrby, string, list, string2, -1, -1);
    }

    public e(byte[] arrby, String string, List<byte[]> list, String string2, int n2, int n3) {
        this.a = arrby;
        this.b = string;
        this.c = list;
        this.d = string2;
        this.h = n3;
        this.i = n2;
    }
}

