/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

import com.google.c.b.b;
import com.google.c.b.i;
import com.google.c.b.k;
import com.google.c.j;

public final class f
extends i {
    @Override
    public final b a(b b2, int n2, int n3, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float f11, float f12, float f13, float f14, float f15, float f16, float f17) {
        return this.a(b2, n2, n3, k.a(f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final b a(b b2, int n2, int n3, k k2) {
        if (n2 <= 0 || n3 <= 0) {
            throw j.a();
        }
        b b3 = new b(n2, n3);
        float[] arrf = new float[n2 * 2];
        int n4 = 0;
        while (n4 < n3) {
            int n5;
            int n6;
            int n7 = arrf.length;
            float f2 = n4;
            for (n2 = 0; n2 < n7; n2 += 2) {
                arrf[n2] = (float)(n2 / 2) + 0.5f;
                arrf[n2 + 1] = 0.5f + f2;
            }
            int n8 = arrf.length;
            f2 = k2.a;
            float f3 = k2.b;
            float f4 = k2.c;
            float f5 = k2.d;
            float f6 = k2.e;
            float f7 = k2.f;
            float f8 = k2.g;
            float f9 = k2.h;
            float f10 = k2.i;
            for (n2 = 0; n2 < n8; n2 += 2) {
                float f11 = arrf[n2];
                float f12 = arrf[n2 + 1];
                float f13 = f4 * f11 + f7 * f12 + f10;
                arrf[n2] = (f2 * f11 + f5 * f12 + f8) / f13;
                arrf[n2 + 1] = (f11 * f3 + f12 * f6 + f9) / f13;
            }
            int n9 = b2.a;
            int n10 = b2.b;
            n2 = 1;
            for (n8 = 0; n8 < arrf.length && n2 != 0; n8 += 2) {
                n5 = (int)arrf[n8];
                n6 = (int)arrf[n8 + 1];
                if (n5 < -1 || n5 > n9 || n6 < -1 || n6 > n10) {
                    throw j.a();
                }
                n2 = 0;
                if (n5 == -1) {
                    arrf[n8] = 0.0f;
                    n2 = 1;
                } else if (n5 == n9) {
                    arrf[n8] = n9 - 1;
                    n2 = 1;
                }
                if (n6 == -1) {
                    arrf[n8 + 1] = 0.0f;
                    n2 = 1;
                    continue;
                }
                if (n6 != n10) continue;
                arrf[n8 + 1] = n10 - 1;
                n2 = 1;
            }
            n8 = arrf.length;
            n2 = 1;
            n8 -= 2;
            while (n8 >= 0 && n2 != 0) {
                n5 = (int)arrf[n8];
                n6 = (int)arrf[n8 + 1];
                if (n5 < -1 || n5 > n9 || n6 < -1 || n6 > n10) {
                    throw j.a();
                }
                n2 = 0;
                if (n5 == -1) {
                    arrf[n8] = 0.0f;
                    n2 = 1;
                } else if (n5 == n9) {
                    arrf[n8] = n9 - 1;
                    n2 = 1;
                }
                if (n6 == -1) {
                    arrf[n8 + 1] = 0.0f;
                    n2 = 1;
                } else if (n6 == n10) {
                    arrf[n8 + 1] = n10 - 1;
                    n2 = 1;
                }
                n8 -= 2;
            }
            for (n2 = 0; n2 < n7; n2 += 2) {
                try {
                    if (!b2.a((int)arrf[n2], (int)arrf[n2 + 1])) continue;
                    b3.b(n2 / 2, n4);
                    continue;
                }
                catch (ArrayIndexOutOfBoundsException var1_2) {
                    throw j.a();
                }
            }
            ++n4;
        }
        return b3;
    }
}

