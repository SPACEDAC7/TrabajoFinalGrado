/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

import com.google.c.b.b;
import com.google.c.p;

public class g {
    public final b d;
    public final p[] e;

    public g(b b2, p[] arrp) {
        this.d = b2;
        this.e = arrp;
    }
}

