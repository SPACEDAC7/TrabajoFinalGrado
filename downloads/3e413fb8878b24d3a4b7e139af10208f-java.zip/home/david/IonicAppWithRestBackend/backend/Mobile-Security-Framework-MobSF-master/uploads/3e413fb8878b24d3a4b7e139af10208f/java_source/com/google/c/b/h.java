/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

import com.google.c.b.a;
import com.google.c.b.b;
import com.google.c.j;

public class h
extends com.google.c.b {
    private static final byte[] b = new byte[0];
    private byte[] c = b;
    private final int[] d = new int[32];

    public h(com.google.c.h h2) {
        super(h2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int a(int[] arrn) {
        int n2;
        int n3;
        int n4;
        int n5 = arrn.length;
        int n6 = 0;
        int n7 = 0;
        int n8 = 0;
        for (n2 = 0; n2 < n5; ++n2) {
            n3 = n6;
            if (arrn[n2] > n6) {
                n3 = arrn[n2];
                n7 = n2;
            }
            n4 = n8;
            if (arrn[n2] > n8) {
                n4 = arrn[n2];
            }
            n6 = n3;
            n8 = n4;
        }
        n2 = 0;
        n6 = 0;
        for (n3 = 0; n3 < n5; ++n3) {
            n4 = n3 - n7;
            if ((n4 *= arrn[n3] * n4) > n6) {
                n6 = n3;
                n2 = n4;
            } else {
                n4 = n6;
                n6 = n2;
                n2 = n4;
            }
            n4 = n2;
            n2 = n6;
            n6 = n4;
        }
        if (n7 > n2) {
            n4 = n7;
            n6 = n2;
        } else {
            n6 = n7;
            n4 = n2;
        }
        if (n4 - n6 <= n5 / 16) {
            throw j.a();
        }
        n2 = n4 - 1;
        n3 = -1;
        n7 = n4 - 1;
        while (n7 > n6) {
            n5 = n7 - n6;
            if ((n5 = n5 * n5 * (n4 - n7) * (n8 - arrn[n7])) > n3) {
                n3 = n7;
                n2 = n5;
            } else {
                n5 = n2;
                n2 = n3;
                n3 = n5;
            }
            --n7;
            n5 = n3;
            n3 = n2;
            n2 = n5;
        }
        return n2 << 3;
    }

    private void a(int n2) {
        if (this.c.length < n2) {
            this.c = new byte[n2];
        }
        for (n2 = 0; n2 < 32; ++n2) {
            this.d[n2] = 0;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final a a(int n2, a a2) {
        int n3;
        int n4 = 1;
        byte[] arrby = this.a;
        int n5 = arrby.a;
        if (a2 == null || a2.b < n5) {
            a2 = new a(n5);
        } else {
            a2.b();
        }
        this.a(n5);
        arrby = arrby.a(n2, this.c);
        int[] arrn = this.d;
        for (n2 = 0; n2 < n5; ++n2) {
            n3 = (arrby[n2] & 255) >> 3;
            arrn[n3] = arrn[n3] + 1;
        }
        int n6 = h.a(arrn);
        n3 = arrby[0] & 255;
        n2 = arrby[1] & 255;
        while (n4 < n5 - 1) {
            int n7 = arrby[n4 + 1] & 255;
            if (((n2 << 2) - n3 - n7) / 2 < n6) {
                a2.b(n4);
            }
            ++n4;
            n3 = n2;
            n2 = n7;
        }
        return a2;
    }

    @Override
    public b a() {
        int n2;
        int n3;
        int n4;
        byte[] arrby = this.a;
        int n5 = arrby.a;
        int n6 = arrby.b;
        b b2 = new b(n5, n6);
        this.a(n5);
        int[] arrn = this.d;
        for (n2 = 1; n2 < 5; ++n2) {
            byte[] arrby2 = arrby.a(n6 * n2 / 5, this.c);
            n3 = (n5 << 2) / 5;
            for (n4 = n5 / 5; n4 < n3; ++n4) {
                int n7 = (arrby2[n4] & 255) >> 3;
                arrn[n7] = arrn[n7] + 1;
            }
        }
        n3 = h.a(arrn);
        arrby = arrby.a();
        for (n2 = 0; n2 < n6; ++n2) {
            for (n4 = 0; n4 < n5; ++n4) {
                if ((arrby[n2 * n5 + n4] & 255) >= n3) continue;
                b2.b(n4, n2);
            }
        }
        return b2;
    }
}

