/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

import com.google.c.b.b;
import com.google.c.b.f;
import com.google.c.b.k;

public abstract class i {
    private static i a = new f();

    public static i a() {
        return a;
    }

    public abstract b a(b var1, int var2, int var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float var11, float var12, float var13, float var14, float var15, float var16, float var17, float var18, float var19);

    public abstract b a(b var1, int var2, int var3, k var4);
}

