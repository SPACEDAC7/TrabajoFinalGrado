/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

import com.google.c.b.b;
import com.google.c.b.h;
import java.lang.reflect.Array;

public final class j
extends h {
    private b b;

    public j(com.google.c.h h2) {
        super(h2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static int a(int n2, int n3) {
        if (n2 < 2) {
            return 2;
        }
        int n4 = n3;
        if (n2 > n3) return n4;
        return n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final b a() {
        if (this.b != null) {
            return this.b;
        }
        byte[] arrby = this.a;
        int n2 = arrby.a;
        int n3 = arrby.b;
        if (n2 >= 40 && n3 >= 40) {
            int n4;
            int n5;
            int n6;
            int n7;
            int n8;
            int n9;
            int n10;
            int n11;
            int n12;
            int n13;
            int n14;
            arrby = arrby.a();
            int n15 = n2 >> 3;
            if ((n2 & 7) != 0) {
                ++n15;
            }
            int n16 = n3 >> 3;
            if ((n3 & 7) != 0) {
                ++n16;
            }
            int[][] arrn = (int[][])Array.newInstance(Integer.TYPE, n16, n15);
            for (n6 = 0; n6 < n16; ++n6) {
                n8 = n6 << 3;
                n12 = n3 - 8;
                if (n8 > n12) {
                    n8 = n12;
                }
                for (n11 = 0; n11 < n15; ++n11) {
                    n12 = n11 << 3;
                    n5 = n2 - 8;
                    if (n12 > n5) {
                        n12 = n5;
                    }
                    n13 = 0;
                    n14 = 255;
                    n5 = 0;
                    n9 = 0;
                    n4 = n8 * n2 + n12;
                    n12 = n13;
                    while (n9 < 8) {
                        n13 = 0;
                        while (n13 < 8) {
                            n7 = arrby[n4 + n13] & 255;
                            if (n7 < n14) {
                                n14 = n7;
                            }
                            if (n7 > n5) {
                                n5 = n7;
                            }
                            ++n13;
                            n12 += n7;
                        }
                        if (n5 - n14 > 24) {
                            n13 = n4 + n2;
                            n4 = n9 + 1;
                            n9 = n13;
                            do {
                                n10 = n9;
                                n7 = n4;
                                n13 = n12;
                                if (n4 < 8) {
                                    for (n13 = 0; n13 < 8; ++n13) {
                                        n12 += arrby[n9 + n13] & 255;
                                    }
                                    ++n4;
                                    n9 += n2;
                                    continue;
                                }
                                break;
                                break;
                            } while (true);
                        } else {
                            n13 = n12;
                            n7 = n9;
                            n10 = n4;
                        }
                        n4 = n10 + n2;
                        n12 = n13;
                        n9 = n7 + 1;
                    }
                    n12 >>= 6;
                    if (n5 - n14 <= 24) {
                        n12 = n14 / 2;
                        if (n6 > 0 && n11 > 0 && n14 < (n5 = (arrn[n6 - 1][n11] + arrn[n6][n11 - 1] * 2 + arrn[n6 - 1][n11 - 1]) / 4)) {
                            n12 = n5;
                        }
                    }
                    arrn[n6][n11] = n12;
                }
            }
            b b2 = new b(n2, n3);
            for (n12 = 0; n12 < n16; ++n12) {
                n5 = n12 << 3;
                n14 = n3 - 8;
                if (n5 > n14) {
                    n5 = n14;
                }
                for (n14 = 0; n14 < n15; ++n14) {
                    n9 = n14 << 3;
                    n4 = n2 - 8;
                    if (n9 > n4) {
                        n9 = n4;
                    }
                    n6 = j.a(n14, n15 - 3);
                    n8 = j.a(n12, n16 - 3);
                    n13 = 0;
                    for (n4 = -2; n4 <= 2; ++n4) {
                        int[] arrn2 = arrn[n8 + n4];
                        n11 = arrn2[n6 - 2];
                        n7 = arrn2[n6 - 1];
                        n10 = arrn2[n6];
                        int n17 = arrn2[n6 + 1];
                        n13 += arrn2[n6 + 2] + (n11 + n7 + n10 + n17);
                    }
                    n8 = n13 / 25;
                    n13 = 0;
                    n4 = n5 * n2 + n9;
                    while (n13 < 8) {
                        for (n6 = 0; n6 < 8; ++n6) {
                            if ((arrby[n4 + n6] & 255) > n8) continue;
                            b2.b(n9 + n6, n5 + n13);
                        }
                        ++n13;
                        n4 += n2;
                    }
                }
            }
            this.b = b2;
            do {
                return this.b;
                break;
            } while (true);
        }
        this.b = super.a();
        return this.b;
    }
}

