/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

public final class k {
    final float a;
    final float b;
    final float c;
    final float d;
    final float e;
    final float f;
    final float g;
    final float h;
    final float i;

    private k(float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10) {
        this.a = f2;
        this.b = f5;
        this.c = f8;
        this.d = f3;
        this.e = f6;
        this.f = f9;
        this.g = f4;
        this.h = f7;
        this.i = f10;
    }

    private static k a(float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9) {
        float f10 = f2 - f4 + f6 - f8;
        float f11 = f3 - f5 + f7 - f9;
        if (f10 == 0.0f && f11 == 0.0f) {
            return new k(f4 - f2, f6 - f4, f2, f5 - f3, f7 - f5, f3, 0.0f, 0.0f, 1.0f);
        }
        float f12 = f4 - f6;
        float f13 = f8 - f6;
        f6 = f5 - f7;
        float f14 = f9 - f7;
        f7 = f12 * f14 - f13 * f6;
        f13 = (f14 * f10 - f13 * f11) / f7;
        f6 = (f11 * f12 - f10 * f6) / f7;
        return new k(f4 - f2 + f13 * f4, f8 - f2 + f6 * f8, f2, f13 * f5 + (f5 - f3), f6 * f9 + (f9 - f3), f3, f13, f6, 1.0f);
    }

    public static k a(float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float f11, float f12, float f13, float f14, float f15, float f16, float f17) {
        k k2 = k.a(f2, f3, f4, f5, f6, f7, f8, f9);
        f2 = k2.e;
        f3 = k2.i;
        f4 = k2.f;
        f5 = k2.h;
        f6 = k2.f;
        f7 = k2.g;
        f8 = k2.d;
        f9 = k2.i;
        float f18 = k2.d;
        float f19 = k2.h;
        float f20 = k2.e;
        float f21 = k2.g;
        float f22 = k2.c;
        float f23 = k2.h;
        float f24 = k2.b;
        float f25 = k2.i;
        float f26 = k2.a;
        float f27 = k2.i;
        float f28 = k2.c;
        float f29 = k2.g;
        float f30 = k2.b;
        float f31 = k2.g;
        float f32 = k2.a;
        float f33 = k2.h;
        float f34 = k2.b;
        float f35 = k2.f;
        float f36 = k2.c;
        float f37 = k2.e;
        float f38 = k2.c;
        float f39 = k2.d;
        float f40 = k2.a;
        float f41 = k2.f;
        float f42 = k2.a;
        float f43 = k2.e;
        float f44 = k2.b;
        k2 = new k(f2 * f3 - f4 * f5, f6 * f7 - f8 * f9, f18 * f19 - f20 * f21, f22 * f23 - f24 * f25, f26 * f27 - f28 * f29, f30 * f31 - f32 * f33, f34 * f35 - f36 * f37, f38 * f39 - f40 * f41, f42 * f43 - k2.d * f44);
        k k3 = k.a(f10, f11, f12, f13, f14, f15, f16, f17);
        f2 = k3.a;
        f3 = k2.a;
        f4 = k3.d;
        f5 = k2.b;
        f6 = k3.g;
        f7 = k2.c;
        f8 = k3.a;
        f9 = k2.d;
        f10 = k3.d;
        f11 = k2.e;
        f12 = k3.g;
        f13 = k2.f;
        f14 = k3.a;
        f15 = k2.g;
        f16 = k3.d;
        f17 = k2.h;
        f18 = k3.g;
        f19 = k2.i;
        f20 = k3.b;
        f21 = k2.a;
        f22 = k3.e;
        f23 = k2.b;
        f24 = k3.h;
        f25 = k2.c;
        f26 = k3.b;
        f27 = k2.d;
        f28 = k3.e;
        f29 = k2.e;
        f30 = k3.h;
        f31 = k2.f;
        f32 = k3.b;
        f33 = k2.g;
        f34 = k3.e;
        f35 = k2.h;
        f36 = k3.h;
        f37 = k2.i;
        f38 = k3.c;
        f39 = k2.a;
        f40 = k3.f;
        f41 = k2.b;
        f42 = k3.i;
        f43 = k2.c;
        f44 = k3.c;
        float f45 = k2.d;
        float f46 = k3.f;
        float f47 = k2.e;
        float f48 = k3.i;
        float f49 = k2.f;
        float f50 = k3.c;
        float f51 = k2.g;
        float f52 = k3.f;
        float f53 = k2.h;
        float f54 = k3.i;
        return new k(f2 * f3 + f4 * f5 + f6 * f7, f8 * f9 + f10 * f11 + f12 * f13, f14 * f15 + f16 * f17 + f18 * f19, f20 * f21 + f22 * f23 + f24 * f25, f26 * f27 + f28 * f29 + f30 * f31, f32 * f33 + f34 * f35 + f36 * f37, f38 * f39 + f40 * f41 + f42 * f43, f44 * f45 + f46 * f47 + f48 * f49, f50 * f51 + f52 * f53 + k2.i * f54);
    }
}

