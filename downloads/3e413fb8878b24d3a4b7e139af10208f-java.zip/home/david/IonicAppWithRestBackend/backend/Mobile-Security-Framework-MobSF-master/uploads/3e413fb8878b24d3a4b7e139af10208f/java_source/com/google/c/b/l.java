/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.b;

import com.google.c.e;
import java.nio.charset.Charset;
import java.util.Map;

public final class l {
    private static final String a = Charset.defaultCharset().name();
    private static final boolean b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl2 = "SJIS".equalsIgnoreCase(a) || "EUC_JP".equalsIgnoreCase(a);
        b = bl2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static String a(byte[] var0, Map<e, ?> var1_1) {
        if (var1_1 != null && (var1_1 = (String)var1_1.get((Object)e.e)) != null) {
            return var1_1;
        }
        var21_2 = var0.length;
        var12_3 = 1;
        var3_4 = 1;
        var7_5 = 1;
        var18_6 = 0;
        var17_7 = 0;
        var16_8 = 0;
        var6_9 = 0;
        var5_10 = 0;
        var8_11 = 0;
        var11_12 = 0;
        var4_13 = 0;
        var2_14 = 0;
        var13_15 = 0;
        var14_16 = var0.length > 3 && var0[0] == -17 && var0[1] == -69 && var0[2] == -65;
        var15_17 = 0;
        var9_18 = 0;
        do {
            if (var15_17 >= var21_2 || var12_3 == 0 && var3_4 == 0 && var7_5 == 0) ** GOTO lbl49
            var19_20 = var0[var15_17] & 255;
            if (var7_5 == 0) ** GOTO lbl76
            if (var9_18 <= 0) ** GOTO lbl29
            var10_19 = var9_18--;
            if ((var19_20 & 128) == 0) ** GOTO lbl-1000
            var10_19 = var7_5;
            ** GOTO lbl77
lbl29: // 1 sources:
            if ((var19_20 & 128) == 0) ** GOTO lbl76
            var10_19 = var9_18++;
            if ((var19_20 & 64) == 0) ** GOTO lbl-1000
            if ((var19_20 & 32) == 0) {
                ++var18_6;
                var10_19 = var7_5;
            } else {
                ++var9_18;
                if ((var19_20 & 16) == 0) {
                    ++var17_7;
                    var10_19 = var7_5;
                } else {
                    var10_19 = ++var9_18;
                    if ((var19_20 & 8) == 0) {
                        ++var16_8;
                        var10_19 = var7_5;
                    } else lbl-1000: // 3 sources:
                    {
                        var9_18 = var10_19;
                        var10_19 = 0;
                    }
                }
            }
            ** GOTO lbl77
lbl49: // 1 sources:
            if (var7_5 != 0 && var9_18 > 0) {
                var7_5 = 0;
            }
            var8_11 = var3_4;
            if (var3_4 != 0) {
                var8_11 = var3_4;
                if (var6_9 > 0) {
                    var8_11 = 0;
                }
            }
            if (var7_5 != 0) {
                if (var14_16 != false) return "UTF8";
                if (var18_6 + var17_7 + var16_8 > 0) {
                    return "UTF8";
                }
                if (var8_11 != 0) {
                    if (l.b != false) return "SJIS";
                    if (var4_13 >= 3) return "SJIS";
                    if (var2_14 >= 3) {
                        return "SJIS";
                    }
                }
            }
            if (var12_3 != 0 && var8_11 != 0) {
                if (var4_13 == 2) {
                    if (var5_10 == 2) return "SJIS";
                }
                if (var13_15 * 10 < var21_2) return "ISO8859_1";
                return "SJIS";
            }
            if (var12_3 != 0) {
                return "ISO8859_1";
            }
            if (var8_11 != 0) {
                return "SJIS";
            }
            if (var7_5 == 0) return l.a;
            return "UTF8";
lbl76: // 2 sources:
            var10_19 = var7_5;
lbl77: // 6 sources:
            if (var12_3 == 0) ** GOTO lbl-1000
            if (var19_20 > 127 && var19_20 < 160) {
                var12_3 = var13_15;
                var13_15 = 0;
            } else if (var19_20 > 159 && (var19_20 < 192 || var19_20 == 215 || var19_20 == 247)) {
                var7_5 = var13_15 + 1;
                var13_15 = var12_3;
                var12_3 = var7_5;
            } else lbl-1000: // 2 sources:
            {
                var7_5 = var12_3;
                var12_3 = var13_15;
                var13_15 = var7_5;
            }
            if (var3_4 == 0) ** GOTO lbl181
            if (var6_9 <= 0) ** GOTO lbl111
            if (var19_20 < 64 || var19_20 == 127 || var19_20 > 252) {
                var3_4 = var4_13;
                var4_13 = var11_12;
                var11_12 = var8_11;
                var8_11 = 0;
                var7_5 = var6_9;
                var6_9 = var5_10;
                var5_10 = var11_12;
            } else {
                var19_20 = var3_4;
                var7_5 = var5_10;
                var20_21 = var6_9 - 1;
                var3_4 = var4_13;
                var4_13 = var11_12;
                var5_10 = var8_11;
                var6_9 = var7_5;
                var7_5 = var20_21;
                var8_11 = var19_20;
            }
            ** GOTO lbl190
lbl111: // 1 sources:
            if (var19_20 != 128 && var19_20 != 160 && var19_20 <= 239) ** GOTO lbl122
            var3_4 = var4_13;
            var4_13 = var11_12;
            var7_5 = var5_10;
            var11_12 = var6_9;
            var19_20 = 0;
            var5_10 = var8_11;
            var6_9 = var7_5;
            var7_5 = var11_12;
            var8_11 = var19_20;
            ** GOTO lbl190
lbl122: // 1 sources:
            if (var19_20 <= 160 || var19_20 >= 224) ** GOTO lbl136
            var7_5 = var5_10 + 1;
            var5_10 = var8_11 + 1;
            if (var5_10 <= var4_13) ** GOTO lbl173
            var4_13 = 0;
            var19_20 = var5_10;
            var8_11 = var6_9;
            var11_12 = var3_4;
            var3_4 = var5_10;
            var5_10 = var19_20;
            var6_9 = var7_5;
            var7_5 = var8_11;
            var8_11 = var11_12;
            ** GOTO lbl190
lbl136: // 1 sources:
            if (var19_20 <= 127) ** GOTO lbl152
            var8_11 = var6_9 + 1;
            var6_9 = var11_12 + 1;
            if (var6_9 <= var2_14) ** GOTO lbl163
            var19_20 = var4_13;
            var20_21 = 0;
            var4_13 = var6_9;
            var7_5 = var5_10;
            var11_12 = var3_4;
            var2_14 = var6_9;
            var3_4 = var19_20;
            var5_10 = var20_21;
            var6_9 = var7_5;
            var7_5 = var8_11;
            var8_11 = var11_12;
            ** GOTO lbl190
lbl152: // 1 sources:
            var19_20 = 0;
            var7_5 = var5_10;
            var8_11 = var6_9;
            var11_12 = var3_4;
            var3_4 = var4_13;
            var4_13 = 0;
            var5_10 = var19_20;
            var6_9 = var7_5;
            var7_5 = var8_11;
            var8_11 = var11_12;
            ** GOTO lbl190
lbl163: // 1 sources:
            var19_20 = 0;
            var7_5 = var5_10;
            var11_12 = var3_4;
            var3_4 = var4_13;
            var4_13 = var6_9;
            var5_10 = var19_20;
            var6_9 = var7_5;
            var7_5 = var8_11;
            var8_11 = var11_12;
            ** GOTO lbl190
lbl173: // 1 sources:
            var8_11 = var6_9;
            var11_12 = var3_4;
            var3_4 = var4_13;
            var4_13 = 0;
            var6_9 = var7_5;
            var7_5 = var8_11;
            var8_11 = var11_12;
            ** GOTO lbl190
lbl181: // 1 sources:
            var7_5 = var5_10;
            var19_20 = var6_9;
            var20_21 = var3_4;
            var3_4 = var4_13;
            var4_13 = var11_12;
            var5_10 = var8_11;
            var6_9 = var7_5;
            var7_5 = var19_20;
            var8_11 = var20_21;
lbl190: // 9 sources:
            var20_21 = var15_17 + 1;
            var15_17 = var13_15;
            var13_15 = var8_11;
            var19_20 = var7_5;
            var7_5 = var10_19;
            var11_12 = var4_13;
            var4_13 = var3_4;
            var8_11 = var5_10;
            var5_10 = var6_9;
            var6_9 = var19_20;
            var3_4 = var13_15;
            var13_15 = var12_3;
            var12_3 = var15_17;
            var15_17 = var20_21;
        } while (true);
    }
}

