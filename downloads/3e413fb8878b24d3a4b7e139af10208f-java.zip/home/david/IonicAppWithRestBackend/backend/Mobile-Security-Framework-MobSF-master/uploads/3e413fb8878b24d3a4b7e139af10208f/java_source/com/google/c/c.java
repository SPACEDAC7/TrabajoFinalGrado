/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import com.google.c.b.b;
import com.google.c.j;

public final class c {
    public final com.google.c.b a;
    private b b;

    public c(com.google.c.b b2) {
        this.a = b2;
    }

    public final b a() {
        if (this.b == null) {
            this.b = this.a.a();
        }
        return this.b;
    }

    public final String toString() {
        try {
            String string = this.a().toString();
            return string;
        }
        catch (j var1_2) {
            return "";
        }
    }
}

