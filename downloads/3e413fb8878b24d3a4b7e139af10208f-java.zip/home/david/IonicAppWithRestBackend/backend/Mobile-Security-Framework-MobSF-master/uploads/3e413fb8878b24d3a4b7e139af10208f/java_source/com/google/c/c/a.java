/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.c;

import com.google.c.b.b;
import com.google.c.b.g;
import com.google.c.c;
import com.google.c.c.a.d;
import com.google.c.c.b.a;
import com.google.c.e;
import com.google.c.j;
import com.google.c.l;
import com.google.c.n;
import com.google.c.o;
import com.google.c.p;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class a
implements l {
    private static final p[] a = new p[0];
    private final d b = new d();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final n a(c var1_1, Map<e, ?> var2_2) {
        if (var2_2 == null || !var2_2.containsKey((Object)e.b)) {
            var12_15 = new com.google.c.c.b.a(var1_1.a());
            var1_1 = var12_15.b.a();
            var8_16 = var1_1[0];
            var9_17 = var1_1[1];
            var10_18 = var1_1[2];
            var11_19 = var1_1[3];
            var2_2 = new ArrayList<E>(4);
            var2_2.add(var12_15.b(var8_16, var9_17));
            var2_2.add(var12_15.b(var8_16, var10_18));
            var2_2.add(var12_15.b(var9_17, var11_19));
            var2_2.add(var12_15.b(var10_18, var11_19));
            Collections.sort(var2_2, new a.b(0));
            var1_1 = (a.a)var2_2.get(0);
            var2_2 = (a.a)var2_2.get(1);
            var16_20 = new HashMap<p, Integer>();
            com.google.c.c.b.a.a(var16_20, var1_1.a);
            com.google.c.c.b.a.a(var16_20, var1_1.b);
            com.google.c.c.b.a.a(var16_20, var2_2.a);
            com.google.c.c.b.a.a(var16_20, var2_2.b);
            var13_21 = var16_20.entrySet().iterator();
            var6_3 = null;
            var2_2 = null;
            var7_22 = null;
        } else {
            var1_1 = var1_1.a();
            var2_2 = var1_1.a();
            var6_3 = var1_1.b();
            if (var2_2 == null) throw j.a();
            if (var6_3 == null) {
                throw j.a();
            }
            var18_4 = var1_1.a;
            var19_8 = var2_2[1];
            for (var17_6 = var2_2[0]; var17_6 < var18_4 && var1_1.a((int)var17_6, (int)var19_8); ++var17_6) {
            }
            if (var17_6 == var18_4) {
                throw j.a();
            }
            var19_8 = var17_6 - var2_2[0];
            if (var19_8 == false) {
                throw j.a();
            }
            var20_10 = var2_2[1];
            var17_6 = (reference)var6_3[1];
            var21_11 = var2_2[0];
            var22_12 = (var6_3[0] - var21_11 + 1) / var19_8;
            var23_13 = (var17_6 - var20_10 + true) / var19_8;
            if (var22_12 <= 0) throw j.a();
            if (var23_13 <= 0) {
                throw j.a();
            }
            var24_14 = var19_8 / 2;
            var2_2 = new b(var22_12, (int)var23_13);
            for (var17_6 = (reference)false ? 1 : 0; var17_6 < var23_13; ++var17_6) {
                for (var18_4 = 0; var18_4 < var22_12; ++var18_4) {
                    if (!var1_1.a(var18_4 * var19_8 + (var24_14 + var21_11), (int)(var20_10 + var24_14 + var17_6 * var19_8))) continue;
                    var2_2.b(var18_4, (int)var17_6);
                }
            }
            var1_1 = this.b.a((b)var2_2);
            var2_2 = a.a;
lbl59: // 2 sources:
            do {
                var2_2 = new n(var1_1.b, var1_1.a, var2_2, com.google.c.a.f);
                var6_3 = var1_1.c;
                if (var6_3 != null) {
                    var2_2.a(o.c, var6_3);
                }
                if ((var1_1 = var1_1.d) == null) return var2_2;
                var2_2.a(o.d, var1_1);
                return var2_2;
                break;
            } while (true);
        }
        while (var13_21.hasNext()) {
            var14_23 = var13_21.next();
            var1_1 = var14_23.getKey();
            if (var14_23.getValue() == 2) {
                var6_3 = var1_1;
                continue;
            }
            if (var2_2 == null) {
                var2_2 = var1_1;
                continue;
            }
            var7_22 = var1_1;
        }
        if (var2_2 == null) throw j.a();
        if (var6_3 == null) throw j.a();
        if (var7_22 == null) {
            throw j.a();
        }
        var1_1 = new p[]{var2_2, var6_3, var7_22};
        p.a((p[])var1_1);
        var13_21 = var1_1[0];
        var14_23 = var1_1[1];
        var15_24 = var1_1[2];
        var1_1 = var16_20.containsKey(var8_16) == false ? var8_16 : (var16_20.containsKey(var9_17) == false ? var9_17 : (var16_20.containsKey(var10_18) == false ? var10_18 : var11_19));
        var19_9 = var12_15.b((p)var15_24, (p)var1_1).c;
        var18_5 = var12_15.b((p)var13_21, (p)var1_1).c;
        var17_7 = var19_9;
        if ((var19_9 & 1) == 1) {
            var17_7 = var19_9 + 1;
        }
        var19_9 = var17_7 + 2;
        var17_7 = var18_5;
        if ((var18_5 & 1) == 1) {
            var17_7 = var18_5 + 1;
        }
        if (var19_9 * 4 < (var17_7 += 2) * 7 && var17_7 * 4 < var19_9 * 7) ** GOTO lbl131
        var3_25 = (float)com.google.c.c.b.a.a((p)var14_23, (p)var13_21) / (float)var19_9;
        var18_5 = com.google.c.c.b.a.a(var15_24, (p)var1_1);
        var4_27 = (var1_1.a - var15_24.a) / (float)var18_5;
        var5_29 = (var1_1.b - var15_24.b) / (float)var18_5;
        var6_3 = new p(var4_27 * var3_25 + var1_1.a, var3_25 * var5_29 + var1_1.b);
        var3_25 = (float)com.google.c.c.b.a.a((p)var14_23, var15_24) / (float)var17_7;
        var18_5 = com.google.c.c.b.a.a((p)var13_21, (p)var1_1);
        var4_27 = (var1_1.a - var13_21.a) / (float)var18_5;
        var5_29 = (var1_1.b - var13_21.b) / (float)var18_5;
        var7_22 = new p(var4_27 * var3_25 + var1_1.a, var3_25 * var5_29 + var1_1.b);
        if (var12_15.a((p)var6_3)) ** GOTO lbl112
        if (var12_15.a((p)var7_22)) ** GOTO lbl-1000
        var2_2 = null;
        ** GOTO lbl118
lbl112: // 1 sources:
        var2_2 = var6_3;
        if (var12_15.a((p)var7_22)) {
            var2_2 = var6_3;
            ** if (Math.abs((int)(var19_9 - var12_15.b((p)var15_24, (p)var6_3).c)) + Math.abs((int)(var17_7 - var12_15.b((p)var13_21, (p)var6_3).c)) <= Math.abs((int)(var19_9 - var12_15.b((p)var15_24, (p)var7_22).c)) + Math.abs((int)(var17_7 - var12_15.b((p)var13_21, (p)var7_22).c))) goto lbl118
        }
        ** GOTO lbl118
lbl-1000: // 2 sources:
        {
            var2_2 = var7_22;
        }
lbl118: // 4 sources:
        var6_3 = var2_2;
        if (var2_2 == null) {
            var6_3 = var1_1;
        }
        var18_5 = var12_15.b((p)var15_24, (p)var6_3).c;
        var19_9 = var12_15.b((p)var13_21, (p)var6_3).c;
        var17_7 = var18_5;
        if ((var18_5 & 1) == 1) {
            var17_7 = var18_5 + 1;
        }
        var18_5 = var19_9;
        if ((var19_9 & 1) == 1) {
            var18_5 = var19_9 + 1;
        }
        var1_1 = com.google.c.c.b.a.a(var12_15.a, var15_24, (p)var14_23, (p)var13_21, (p)var6_3, var17_7, var18_5);
        ** GOTO lbl159
lbl131: // 1 sources:
        var17_7 = Math.min(var17_7, var19_9);
        var3_26 = (float)com.google.c.c.b.a.a((p)var14_23, (p)var13_21) / (float)var17_7;
        var18_5 = com.google.c.c.b.a.a(var15_24, (p)var1_1);
        var4_28 = (var1_1.a - var15_24.a) / (float)var18_5;
        var5_30 = (var1_1.b - var15_24.b) / (float)var18_5;
        var6_3 = new p(var4_28 * var3_26 + var1_1.a, var3_26 * var5_30 + var1_1.b);
        var3_26 = (float)com.google.c.c.b.a.a((p)var14_23, var15_24) / (float)var17_7;
        var17_7 = com.google.c.c.b.a.a((p)var13_21, (p)var1_1);
        var4_28 = (var1_1.a - var13_21.a) / (float)var17_7;
        var5_30 = (var1_1.b - var13_21.b) / (float)var17_7;
        var7_22 = new p(var4_28 * var3_26 + var1_1.a, var3_26 * var5_30 + var1_1.b);
        if (var12_15.a((p)var6_3)) ** GOTO lbl146
        if (var12_15.a((p)var7_22)) ** GOTO lbl-1000
        var2_2 = null;
        ** GOTO lbl152
lbl146: // 1 sources:
        var2_2 = var6_3;
        if (var12_15.a((p)var7_22)) {
            var2_2 = var6_3;
            ** if (Math.abs((int)(var12_15.b((p)var15_24, (p)var6_3).c - var12_15.b((p)var13_21, (p)var6_3).c)) <= Math.abs((int)(var12_15.b((p)var15_24, (p)var7_22).c - var12_15.b((p)var13_21, (p)var7_22).c))) goto lbl152
        }
        ** GOTO lbl152
lbl-1000: // 2 sources:
        {
            var2_2 = var7_22;
        }
lbl152: // 4 sources:
        var6_3 = var2_2;
        if (var2_2 == null) {
            var6_3 = var1_1;
        }
        var17_7 = var18_5 = Math.max(var12_15.b((p)var15_24, (p)var6_3).c, var12_15.b((p)var13_21, (p)var6_3).c) + 1;
        if ((var18_5 & 1) == 1) {
            var17_7 = var18_5 + 1;
        }
        var1_1 = com.google.c.c.b.a.a(var12_15.a, var15_24, (p)var14_23, (p)var13_21, (p)var6_3, var17_7, var17_7);
lbl159: // 2 sources:
        var2_2 = new g((b)var1_1, new p[]{var15_24, var14_23, var13_21, var6_3});
        var1_1 = this.b.a(var2_2.d);
        var2_2 = var2_2.e;
        ** while (true)
    }

    @Override
    public final void a() {
    }
}

