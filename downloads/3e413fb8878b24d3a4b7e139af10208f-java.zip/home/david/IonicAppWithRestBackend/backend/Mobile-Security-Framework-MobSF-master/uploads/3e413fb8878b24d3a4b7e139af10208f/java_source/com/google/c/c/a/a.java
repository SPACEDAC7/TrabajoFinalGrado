/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.c.a;

import com.google.c.b.b;
import com.google.c.c.a.e;
import com.google.c.g;

final class a {
    final b a;
    final b b;
    final e c;

    a(b b2) {
        int n2 = b2.b;
        if (n2 < 8 || n2 > 144 || (n2 & 1) != 0) {
            throw g.a();
        }
        this.c = e.a(b2.b, b2.a);
        this.a = this.a(b2);
        this.b = new b(this.a.a, this.a.b);
    }

    private b a(b b2) {
        int n2 = this.c.b;
        int n3 = this.c.c;
        if (b2.b != n2) {
            throw new IllegalArgumentException("Dimension of bitMarix must match the version size");
        }
        int n4 = this.c.d;
        int n5 = this.c.e;
        int n6 = n2 / n4;
        int n7 = n3 / n5;
        b b3 = new b(n7 * n5, n6 * n4);
        for (n3 = 0; n3 < n6; ++n3) {
            for (n2 = 0; n2 < n7; ++n2) {
                for (int i2 = 0; i2 < n4; ++i2) {
                    for (int i3 = 0; i3 < n5; ++i3) {
                        if (!b2.a((n5 + 2) * n2 + 1 + i3, (n4 + 2) * n3 + 1 + i2)) continue;
                        b3.b(n2 * n5 + i3, n3 * n4 + i2);
                    }
                }
            }
        }
        return b3;
    }

    final boolean a(int n2, int n3, int n4, int n5) {
        if (n2 < 0) {
            n2 += n4;
            n3 = 4 - (n4 + 4 & 7) + n3;
        }
        int n6 = n3;
        n4 = n2;
        if (n3 < 0) {
            n6 = n3 + n5;
            n4 = n2 + (4 - (n5 + 4 & 7));
        }
        this.b.b(n6, n4);
        return this.a.a(n6, n4);
    }

    final int b(int n2, int n3, int n4, int n5) {
        int n6;
        int n7 = 0;
        if (this.a(n2 - 2, n3 - 2, n4, n5)) {
            n7 = 1;
        }
        n7 = n6 = n7 << 1;
        if (this.a(n2 - 2, n3 - 1, n4, n5)) {
            n7 = n6 | 1;
        }
        n7 = n6 = n7 << 1;
        if (this.a(n2 - 1, n3 - 2, n4, n5)) {
            n7 = n6 | 1;
        }
        n7 = n6 = n7 << 1;
        if (this.a(n2 - 1, n3 - 1, n4, n5)) {
            n7 = n6 | 1;
        }
        n7 = n6 = n7 << 1;
        if (this.a(n2 - 1, n3, n4, n5)) {
            n7 = n6 | 1;
        }
        n7 = n6 = n7 << 1;
        if (this.a(n2, n3 - 2, n4, n5)) {
            n7 = n6 | 1;
        }
        n7 = n6 = n7 << 1;
        if (this.a(n2, n3 - 1, n4, n5)) {
            n7 = n6 | 1;
        }
        n7 = n6 = n7 << 1;
        if (this.a(n2, n3, n4, n5)) {
            n7 = n6 | 1;
        }
        return n7;
    }
}

