/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.c.a;

import com.google.c.b.e;
import com.google.c.g;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

final class c {
    private static final char[] a = new char[]{'*', '*', '*', ' ', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    private static final char[] b = new char[]{'!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_'};
    private static final char[] c = new char[]{'*', '*', '*', ' ', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
    private static final char[] d = new char[]{'`', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '{', '|', '}', '~', ''};

    private static int a(int n2, int n3) {
        if ((n2 -= n3 * 149 % 255 + 1) >= 0) {
            return n2;
        }
        return n2 + 256;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int a(com.google.c.b.c c2, StringBuilder stringBuilder, StringBuilder stringBuilder2) {
        int n2 = 0;
        do {
            int n3;
            int n4;
            if ((n4 = c2.a(8)) == 0) {
                throw g.a();
            }
            if (n4 <= 128) {
                n2 = n2 != 0 ? n4 + 128 : n4;
                stringBuilder.append((char)(n2 - 1));
                return a.b;
            }
            if (n4 == 129) {
                return a.a;
            }
            if (n4 <= 229) {
                n3 = n4 - 130;
                if (n3 < 10) {
                    stringBuilder.append('0');
                }
                stringBuilder.append(n3);
                n3 = n2;
            } else {
                if (n4 == 230) {
                    return a.c;
                }
                if (n4 == 231) {
                    return a.g;
                }
                if (n4 == 232) {
                    stringBuilder.append('\u001d');
                    n3 = n2;
                } else {
                    n3 = n2;
                    if (n4 != 233) {
                        n3 = n2;
                        if (n4 != 234) {
                            if (n4 == 235) {
                                n3 = 1;
                            } else if (n4 == 236) {
                                stringBuilder.append("[)>\u001e05\u001d");
                                stringBuilder2.insert(0, "\u001e\u0004");
                                n3 = n2;
                            } else if (n4 == 237) {
                                stringBuilder.append("[)>\u001e06\u001d");
                                stringBuilder2.insert(0, "\u001e\u0004");
                                n3 = n2;
                            } else {
                                if (n4 == 238) {
                                    return a.e;
                                }
                                if (n4 == 239) {
                                    return a.d;
                                }
                                if (n4 == 240) {
                                    return a.f;
                                }
                                n3 = n2;
                                if (n4 != 241) {
                                    n3 = n2;
                                    if (n4 >= 242) {
                                        if (n4 != 254) throw g.a();
                                        n3 = n2;
                                        if (c2.a() != 0) {
                                            throw g.a();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            n2 = n3;
        } while (c2.a() > 0);
        return a.b;
    }

    /*
     * Enabled aggressive block sorting
     */
    static e a(byte[] arrby) {
        Object object = new com.google.c.b.c(arrby);
        StringBuilder stringBuilder = new StringBuilder(100);
        StringBuilder stringBuilder2 = new StringBuilder(0);
        ArrayList<byte[]> arrayList = new ArrayList<byte[]>(1);
        int n2 = a.b;
        do {
            if (n2 == a.b) {
                n2 = c.a((com.google.c.b.c)object, stringBuilder, stringBuilder2);
                continue;
            }
            switch (.a[n2 - 1]) {
                default: {
                    throw g.a();
                }
                case 1: {
                    c.a((com.google.c.b.c)object, stringBuilder);
                    break;
                }
                case 2: {
                    c.b((com.google.c.b.c)object, stringBuilder);
                    break;
                }
                case 3: {
                    c.c((com.google.c.b.c)object, stringBuilder);
                    break;
                }
                case 4: {
                    c.d((com.google.c.b.c)object, stringBuilder);
                    break;
                }
                case 5: {
                    c.a((com.google.c.b.c)object, stringBuilder, arrayList);
                }
            }
            n2 = a.b;
        } while (n2 != a.a && object.a() > 0);
        if (stringBuilder2.length() > 0) {
            stringBuilder.append((CharSequence)stringBuilder2);
        }
        object = stringBuilder.toString();
        if (arrayList.isEmpty()) {
            arrayList = null;
        }
        return new e(arrby, (String)object, arrayList, null);
    }

    private static void a(int n2, int n3, int[] arrn) {
        n2 = (n2 << 8) + n3 - 1;
        arrn[0] = n3 = n2 / 1600;
        arrn[1] = n3 = (n2 -= n3 * 1600) / 40;
        arrn[2] = n2 - n3 * 40;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(com.google.c.b.c c2, StringBuilder stringBuilder) {
        int[] arrn = new int[3];
        int n2 = 0;
        boolean bl2 = false;
        do {
            int n3;
            if (c2.a() == 8 || (n3 = c2.a(8)) == 254) {
                return;
            }
            c.a(n3, c2.a(8), arrn);
            block7 : for (n3 = 0; n3 < 3; ++n3) {
                int n4 = arrn[n3];
                switch (n2) {
                    char c3;
                    default: {
                        throw g.a();
                    }
                    case 0: {
                        if (n4 < 3) {
                            n2 = n4 + 1;
                            continue block7;
                        }
                        if (n4 >= a.length) {
                            throw g.a();
                        }
                        c3 = a[n4];
                        if (bl2) {
                            stringBuilder.append((char)(c3 + 128));
                            bl2 = false;
                            continue block7;
                        }
                        stringBuilder.append(c3);
                        continue block7;
                    }
                    case 1: {
                        if (bl2) {
                            stringBuilder.append((char)(n4 + 128));
                            bl2 = false;
                        } else {
                            stringBuilder.append((char)n4);
                        }
                        n2 = 0;
                        continue block7;
                    }
                    case 2: {
                        if (n4 < b.length) {
                            c3 = b[n4];
                            if (bl2) {
                                stringBuilder.append((char)(c3 + 128));
                                bl2 = false;
                            } else {
                                stringBuilder.append(c3);
                            }
                        } else if (n4 == 27) {
                            stringBuilder.append('\u001d');
                        } else {
                            if (n4 != 30) {
                                throw g.a();
                            }
                            bl2 = true;
                        }
                        n2 = 0;
                        continue block7;
                    }
                    case 3: {
                        if (bl2) {
                            stringBuilder.append((char)(n4 + 224));
                            bl2 = false;
                        } else {
                            stringBuilder.append((char)(n4 + 96));
                        }
                        n2 = 0;
                    }
                }
            }
        } while (c2.a() > 0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void a(com.google.c.b.c c2, StringBuilder stringBuilder, Collection<byte[]> collection) {
        int n2 = c2.a + 1;
        int n3 = c2.a(8);
        int n4 = n2 + 1;
        if ((n2 = c.a(n3, n2)) == 0) {
            n2 = c2.a() / 8;
        } else if (n2 >= 250) {
            n2 = (n2 - 249) * 250 + c.a(c2.a(8), n4);
            ++n4;
        }
        if (n2 < 0) {
            throw g.a();
        }
        byte[] arrby = new byte[n2];
        for (n3 = 0; n3 < n2; ++n3, ++n4) {
            if (c2.a() < 8) {
                throw g.a();
            }
            arrby[n3] = (byte)c.a(c2.a(8), n4);
        }
        collection.add(arrby);
        try {
            stringBuilder.append(new String(arrby, "ISO8859_1"));
            return;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw new IllegalStateException("Platform does not support required encoding: " + var0_1);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void b(com.google.c.b.c c2, StringBuilder stringBuilder) {
        int[] arrn = new int[3];
        int n2 = 0;
        boolean bl2 = false;
        do {
            int n3;
            if (c2.a() == 8 || (n3 = c2.a(8)) == 254) {
                return;
            }
            c.a(n3, c2.a(8), arrn);
            block7 : for (n3 = 0; n3 < 3; ++n3) {
                int n4 = arrn[n3];
                switch (n2) {
                    char c3;
                    default: {
                        throw g.a();
                    }
                    case 0: {
                        if (n4 < 3) {
                            n2 = n4 + 1;
                            continue block7;
                        }
                        if (n4 >= c.length) {
                            throw g.a();
                        }
                        c3 = c[n4];
                        if (bl2) {
                            stringBuilder.append((char)(c3 + 128));
                            bl2 = false;
                            continue block7;
                        }
                        stringBuilder.append(c3);
                        continue block7;
                    }
                    case 1: {
                        if (bl2) {
                            stringBuilder.append((char)(n4 + 128));
                            bl2 = false;
                        } else {
                            stringBuilder.append((char)n4);
                        }
                        n2 = 0;
                        continue block7;
                    }
                    case 2: {
                        if (n4 < b.length) {
                            c3 = b[n4];
                            if (bl2) {
                                stringBuilder.append((char)(c3 + 128));
                                bl2 = false;
                            } else {
                                stringBuilder.append(c3);
                            }
                        } else if (n4 == 27) {
                            stringBuilder.append('\u001d');
                        } else {
                            if (n4 != 30) {
                                throw g.a();
                            }
                            bl2 = true;
                        }
                        n2 = 0;
                        continue block7;
                    }
                    case 3: {
                        if (n4 >= d.length) {
                            throw g.a();
                        }
                        c3 = d[n4];
                        if (bl2) {
                            stringBuilder.append((char)(c3 + 128));
                            bl2 = false;
                        } else {
                            stringBuilder.append(c3);
                        }
                        n2 = 0;
                    }
                }
            }
        } while (c2.a() > 0);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void c(com.google.c.b.c c2, StringBuilder stringBuilder) {
        int[] arrn = new int[3];
        do {
            int n2;
            if (c2.a() == 8 || (n2 = c2.a(8)) == 254) {
                return;
            }
            c.a(n2, c2.a(8), arrn);
            for (n2 = 0; n2 < 3; ++n2) {
                int n3 = arrn[n2];
                if (n3 == 0) {
                    stringBuilder.append('\r');
                    continue;
                }
                if (n3 == 1) {
                    stringBuilder.append('*');
                    continue;
                }
                if (n3 == 2) {
                    stringBuilder.append('>');
                    continue;
                }
                if (n3 == 3) {
                    stringBuilder.append(' ');
                    continue;
                }
                if (n3 < 14) {
                    stringBuilder.append((char)(n3 + 44));
                    continue;
                }
                if (n3 >= 40) {
                    throw g.a();
                }
                stringBuilder.append((char)(n3 + 51));
            }
        } while (c2.a() > 0);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void d(com.google.c.b.c c2, StringBuilder stringBuilder) {
        int n2;
        block4 : {
            block0 : while (c2.a() > 16) {
                for (n2 = 0; n2 < 4; ++n2) {
                    int n3 = c2.a(6);
                    if (n3 == 31) {
                        n2 = 8 - c2.b;
                        if (n2 == 8) break block0;
                        break block4;
                    }
                    int n4 = n3;
                    if ((n3 & 32) == 0) {
                        n4 = n3 | 64;
                    }
                    stringBuilder.append((char)n4);
                }
                if (c2.a() > 0) continue;
                return;
            }
            return;
        }
        c2.a(n2);
    }

    static final class a
    extends Enum<a> {
        public static final /* enum */ int a = 1;
        public static final /* enum */ int b = 2;
        public static final /* enum */ int c = 3;
        public static final /* enum */ int d = 4;
        public static final /* enum */ int e = 5;
        public static final /* enum */ int f = 6;
        public static final /* enum */ int g = 7;
        private static final /* synthetic */ int[] h;

        static {
            h = new int[]{a, b, c, d, e, f, g};
        }

        public static int[] a() {
            return (int[])h.clone();
        }
    }

}

