/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.c.a;

import com.google.c.c.a.a;
import com.google.c.c.a.b;
import com.google.c.c.a.c;
import com.google.c.c.a.e;
import com.google.c.g;

public final class d {
    private final com.google.c.b.b.c a = new com.google.c.b.b.c(com.google.c.b.b.a.f);

    private void a(byte[] arrby, int n2) {
        int n3;
        int n4 = 0;
        int n5 = arrby.length;
        int[] arrn = new int[n5];
        for (n3 = 0; n3 < n5; ++n3) {
            arrn[n3] = arrby[n3] & 255;
        }
        n3 = arrby.length;
        try {
            this.a.a(arrn, n3 - n2);
        }
        catch (com.google.c.b.b.e var1_2) {
            throw com.google.c.d.a();
        }
        for (n3 = n4; n3 < n2; ++n3) {
            arrby[n3] = (byte)arrn[n3];
        }
    }

    /*
     * Unable to fully structure code
     */
    public final com.google.c.b.e a(com.google.c.b.b var1_1) {
        block59 : {
            block61 : {
                block60 : {
                    var1_1 = new a((com.google.c.b.b)var1_1);
                    var2_2 = var1_1.c;
                    var3_3 = new byte[var1_1.c.g];
                    var12_4 = 4;
                    var16_5 = var1_1.a.b;
                    var17_6 = var1_1.a.a;
                    var11_7 = 0;
                    var13_8 = 0;
                    var8_9 = 0;
                    var9_10 = 0;
                    var10_11 = 0;
                    var7_12 = 0;
lbl13: // 2 sources:
                    if (var12_4 == var16_5 && var11_7 == 0 && var8_9 == 0) {
                        var14_13 = var13_8 + 1;
                        var8_9 = 0;
                        if (var1_1.a(var16_5 - 1, 0, var16_5, var17_6)) {
                            var8_9 = 1;
                        }
                        var8_9 = var15_14 = var8_9 << 1;
                        if (var1_1.a(var16_5 - 1, 1, var16_5, var17_6)) {
                            var8_9 = var15_14 | 1;
                        }
                        var8_9 = var15_14 = var8_9 << 1;
                        if (var1_1.a(var16_5 - 1, 2, var16_5, var17_6)) {
                            var8_9 = var15_14 | 1;
                        }
                        var8_9 = var15_14 = var8_9 << 1;
                        if (var1_1.a(0, var17_6 - 2, var16_5, var17_6)) {
                            var8_9 = var15_14 | 1;
                        }
                        var8_9 = var15_14 = var8_9 << 1;
                        if (var1_1.a(0, var17_6 - 1, var16_5, var17_6)) {
                            var8_9 = var15_14 | 1;
                        }
                        var8_9 = var15_14 = var8_9 << 1;
                        if (var1_1.a(1, var17_6 - 1, var16_5, var17_6)) {
                            var8_9 = var15_14 | 1;
                        }
                        var8_9 = var15_14 = var8_9 << 1;
                        if (var1_1.a(2, var17_6 - 1, var16_5, var17_6)) {
                            var8_9 = var15_14 | 1;
                        }
                        var8_9 = var15_14 = var8_9 << 1;
                        if (var1_1.a(3, var17_6 - 1, var16_5, var17_6)) {
                            var8_9 = var15_14 | 1;
                        }
                        var3_3[var13_8] = (byte)var8_9;
                        var15_14 = var11_7 + 2;
                        var8_9 = var10_11;
                        var10_11 = 1;
                        var13_8 = var14_13;
                        var11_7 = var12_4 -= 2;
                        var12_4 = var15_14;
lbl46: // 5 sources:
                        do {
                            if (var11_7 < var16_5 || var12_4 < var17_6) break block59;
                            if (var13_8 != var1_1.c.g) {
                                throw g.a();
                            }
                            break block60;
                            break;
                        } while (true);
                    }
                    if (var12_4 != var16_5 - 2 || var11_7 != 0 || (var17_6 & 3) == 0 || var9_10 != 0) ** GOTO lbl87
                    var14_13 = var13_8 + 1;
                    var9_10 = 0;
                    if (var1_1.a(var16_5 - 3, 0, var16_5, var17_6)) {
                        var9_10 = 1;
                    }
                    var9_10 = var15_14 = var9_10 << 1;
                    if (var1_1.a(var16_5 - 2, 0, var16_5, var17_6)) {
                        var9_10 = var15_14 | 1;
                    }
                    var9_10 = var15_14 = var9_10 << 1;
                    if (var1_1.a(var16_5 - 1, 0, var16_5, var17_6)) {
                        var9_10 = var15_14 | 1;
                    }
                    var9_10 = var15_14 = var9_10 << 1;
                    if (var1_1.a(0, var17_6 - 4, var16_5, var17_6)) {
                        var9_10 = var15_14 | 1;
                    }
                    var9_10 = var15_14 = var9_10 << 1;
                    if (var1_1.a(0, var17_6 - 3, var16_5, var17_6)) {
                        var9_10 = var15_14 | 1;
                    }
                    var9_10 = var15_14 = var9_10 << 1;
                    if (var1_1.a(0, var17_6 - 2, var16_5, var17_6)) {
                        var9_10 = var15_14 | 1;
                    }
                    var9_10 = var15_14 = var9_10 << 1;
                    if (var1_1.a(0, var17_6 - 1, var16_5, var17_6)) {
                        var9_10 = var15_14 | 1;
                    }
                    var9_10 = var15_14 = var9_10 << 1;
                    if (var1_1.a(1, var17_6 - 1, var16_5, var17_6)) {
                        var9_10 = var15_14 | 1;
                    }
                    var3_3[var13_8] = (byte)var9_10;
                    var13_8 = var12_4 - 2;
                    var9_10 = 1;
                    var12_4 = var11_7 + 2;
                    var11_7 = var8_9;
                    var8_9 = var10_11;
                    var10_11 = var11_7;
                    var11_7 = var13_8;
                    var13_8 = var14_13;
                    ** GOTO lbl46
lbl87: // 1 sources:
                    if (var12_4 != var16_5 + 4 || var11_7 != 2 || (var17_6 & 7) != 0 || var10_11 != 0) ** GOTO lbl122
                    var14_13 = var13_8 + 1;
                    var10_11 = 0;
                    if (var1_1.a(var16_5 - 1, 0, var16_5, var17_6)) {
                        var10_11 = 1;
                    }
                    var10_11 = var15_14 = var10_11 << 1;
                    if (var1_1.a(var16_5 - 1, var17_6 - 1, var16_5, var17_6)) {
                        var10_11 = var15_14 | 1;
                    }
                    var10_11 = var15_14 = var10_11 << 1;
                    if (var1_1.a(0, var17_6 - 3, var16_5, var17_6)) {
                        var10_11 = var15_14 | 1;
                    }
                    var10_11 = var15_14 = var10_11 << 1;
                    if (var1_1.a(0, var17_6 - 2, var16_5, var17_6)) {
                        var10_11 = var15_14 | 1;
                    }
                    var10_11 = var15_14 = var10_11 << 1;
                    if (var1_1.a(0, var17_6 - 1, var16_5, var17_6)) {
                        var10_11 = var15_14 | 1;
                    }
                    var10_11 = var15_14 = var10_11 << 1;
                    if (var1_1.a(1, var17_6 - 3, var16_5, var17_6)) {
                        var10_11 = var15_14 | 1;
                    }
                    var10_11 = var15_14 = var10_11 << 1;
                    if (var1_1.a(1, var17_6 - 2, var16_5, var17_6)) {
                        var10_11 = var15_14 | 1;
                    }
                    var10_11 = var15_14 = var10_11 << 1;
                    if (var1_1.a(1, var17_6 - 1, var16_5, var17_6)) {
                        var10_11 = var15_14 | 1;
                    }
                    var3_3[var13_8] = (byte)var10_11;
                    var13_8 = var12_4 - 2;
                    var12_4 = 1;
                    var10_11 = var8_9;
                    var8_9 = var12_4;
                    var12_4 = var11_7 += 2;
                    var11_7 = var13_8;
                    var13_8 = var14_13;
                    ** GOTO lbl46
lbl122: // 1 sources:
                    if (var12_4 != var16_5 - 2 || var11_7 != 0 || (var17_6 & 7) != 4 || var7_12 != 0) ** GOTO lbl267
                    var14_13 = var13_8 + 1;
                    var7_12 = 0;
                    if (var1_1.a(var16_5 - 3, 0, var16_5, var17_6)) {
                        var7_12 = 1;
                    }
                    var7_12 = var15_14 = var7_12 << 1;
                    if (var1_1.a(var16_5 - 2, 0, var16_5, var17_6)) {
                        var7_12 = var15_14 | 1;
                    }
                    var7_12 = var15_14 = var7_12 << 1;
                    if (var1_1.a(var16_5 - 1, 0, var16_5, var17_6)) {
                        var7_12 = var15_14 | 1;
                    }
                    var7_12 = var15_14 = var7_12 << 1;
                    if (var1_1.a(0, var17_6 - 2, var16_5, var17_6)) {
                        var7_12 = var15_14 | 1;
                    }
                    var7_12 = var15_14 = var7_12 << 1;
                    if (var1_1.a(0, var17_6 - 1, var16_5, var17_6)) {
                        var7_12 = var15_14 | 1;
                    }
                    var7_12 = var15_14 = var7_12 << 1;
                    if (var1_1.a(1, var17_6 - 1, var16_5, var17_6)) {
                        var7_12 = var15_14 | 1;
                    }
                    var7_12 = var15_14 = var7_12 << 1;
                    if (var1_1.a(2, var17_6 - 1, var16_5, var17_6)) {
                        var7_12 = var15_14 | 1;
                    }
                    var7_12 = var15_14 = var7_12 << 1;
                    if (var1_1.a(3, var17_6 - 1, var16_5, var17_6)) {
                        var7_12 = var15_14 | 1;
                    }
                    var3_3[var13_8] = (byte)var7_12;
                    var13_8 = var12_4 - 2;
                    var7_12 = 1;
                    var12_4 = var8_9;
                    var8_9 = var10_11;
                    var10_11 = var12_4;
                    var12_4 = var11_7 += 2;
                    var11_7 = var13_8;
                    var13_8 = var14_13;
                    ** GOTO lbl46
lbl158: // 2 sources:
                    if (var13_8 < var16_5 && var12_4 >= 0 && !var1_1.b.a(var12_4, var13_8)) {
                        var14_13 = var11_7 + 1;
                        var3_3[var11_7] = (byte)var1_1.b(var13_8, var12_4, var16_5, var17_6);
                        var11_7 = var14_13;
                    }
                    if ((var13_8 -= 2) >= 0 && (var12_4 += 2) < var17_6) ** GOTO lbl158
                    var14_13 = var13_8 + 1;
                    var12_4 += 3;
lbl165: // 2 sources:
                    if (var14_13 < 0 || var12_4 >= var17_6 || var1_1.b.a(var12_4, var14_13)) ** GOTO lbl265
                    var13_8 = var11_7 + 1;
                    var3_3[var11_7] = (byte)var1_1.b(var14_13, var12_4, var16_5, var17_6);
lbl168: // 2 sources:
                    if ((var14_13 += 2) >= var16_5 || (var12_4 -= 2) < 0) {
                        var11_7 = var8_9;
                        ++var12_4;
                        var8_9 = var10_11;
                        var10_11 = var11_7;
                        var11_7 = var14_13 += 3;
                        ** continue;
                    }
                    ** GOTO lbl263
                }
                var4_15 = var2_2.f;
                var8_9 = 0;
                var5_16 = var4_15.b;
                var9_10 = var5_16.length;
                for (var7_12 = 0; var7_12 < var9_10; ++var7_12) {
                    var8_9 += var5_16[var7_12].a;
                }
                var1_1 = new b[var8_9];
                var7_12 = 0;
                for (e.a var6_17 : var5_16) {
                    var9_10 = 0;
                    while (var9_10 < var6_17.a) {
                        var11_7 = var6_17.b;
                        var1_1[var7_12] = new b(var11_7, new byte[var4_15.a + var11_7]);
                        ++var9_10;
                        ++var7_12;
                    }
                }
                var12_4 = var1_1[0].b.length - var4_15.a;
                var8_9 = 0;
                for (var9_10 = 0; var9_10 < var12_4 - 1; ++var9_10) {
                    var10_11 = 0;
                    while (var10_11 < var7_12) {
                        var1_1[var10_11].b[var9_10] = var3_3[var8_9];
                        ++var10_11;
                        ++var8_9;
                    }
                }
                if (var2_2.a != 24) ** GOTO lbl218
                var10_11 = 1;
lbl207: // 2 sources:
                while (var10_11 != 0) {
                    var9_10 = 8;
lbl209: // 2 sources:
                    do {
                        var11_7 = 0;
                        while (var11_7 < var9_10) {
                            var1_1[var11_7].b[var12_4 - 1] = var3_3[var8_9];
                            ++var11_7;
                            ++var8_9;
                        }
                        break block61;
                        break;
                    } while (true);
                }
                ** GOTO lbl220
lbl218: // 1 sources:
                var10_11 = 0;
                ** GOTO lbl207
lbl220: // 1 sources:
                var9_10 = var7_12;
                ** while (true)
            }
            var13_8 = var1_1[0].b.length;
            var9_10 = var8_9;
            for (var8_9 = var12_4; var8_9 < var13_8; ++var8_9) {
                block16 : for (var11_7 = 0; var11_7 < var7_12; ++var11_7) {
                    if (var10_11 != 0 && var11_7 > 7) {
                        var12_4 = var8_9 - 1;
lbl229: // 2 sources:
                        do {
                            var1_1[var11_7].b[var12_4] = var3_3[var9_10];
                            ++var9_10;
                            continue block16;
                            break;
                        } while (true);
                    }
                    var12_4 = var8_9;
                    ** continue;
                }
            }
            if (var9_10 != var3_3.length) {
                throw new IllegalArgumentException();
            }
            var9_10 = var1_1.length;
            var8_9 = 0;
            var10_11 = var1_1.length;
            for (var7_12 = 0; var7_12 < var10_11; ++var7_12) {
                var8_9 += var1_1[var7_12].a;
            }
            var2_2 = new byte[var8_9];
            for (var7_12 = 0; var7_12 < var9_10; ++var7_12) {
                var3_3 = var1_1[var7_12];
                var4_15 = var3_3.b;
                var10_11 = var3_3.a;
                this.a(var4_15, var10_11);
                for (var8_9 = 0; var8_9 < var10_11; ++var8_9) {
                    var2_2[var8_9 * var9_10 + var7_12] = var4_15[var8_9];
                }
            }
            return c.a(var2_2);
        }
        var14_13 = var12_4;
        var12_4 = var10_11;
        var10_11 = var8_9;
        var8_9 = var12_4;
        var12_4 = var11_7;
        var11_7 = var14_13;
        ** GOTO lbl13
lbl263: // 1 sources:
        var11_7 = var13_8;
        ** GOTO lbl165
lbl265: // 1 sources:
        var13_8 = var11_7;
        ** GOTO lbl168
lbl267: // 1 sources:
        var14_13 = var11_7;
        var15_14 = var12_4;
        var11_7 = var13_8;
        var12_4 = var14_13;
        var13_8 = var15_14;
        ** GOTO lbl158
    }
}

