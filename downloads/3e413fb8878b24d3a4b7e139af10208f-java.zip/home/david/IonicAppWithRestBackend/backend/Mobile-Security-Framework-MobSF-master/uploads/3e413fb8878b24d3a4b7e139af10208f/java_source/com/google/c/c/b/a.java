/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.c.b;

import a.a.a.a.d;
import com.google.c.b.i;
import com.google.c.p;
import java.io.Serializable;
import java.util.Comparator;
import java.util.Map;

public final class a {
    public final com.google.c.b.b a;
    public final com.google.c.b.a.a b;

    public a(com.google.c.b.b b2) {
        this.a = b2;
        this.b = new com.google.c.b.a.a(b2);
    }

    public static int a(p p2, p p3) {
        return d.b(p.a(p2, p3));
    }

    public static com.google.c.b.b a(com.google.c.b.b b2, p p2, p p3, p p4, p p5, int n2, int n3) {
        return i.a().a(b2, n2, n3, 0.5f, 0.5f, (float)n2 - 0.5f, 0.5f, (float)n2 - 0.5f, (float)n3 - 0.5f, 0.5f, (float)n3 - 0.5f, p2.a, p2.b, p5.a, p5.b, p4.a, p4.b, p3.a, p3.b);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(Map<p, Integer> map, p p2) {
        Integer n2 = map.get(p2);
        int n3 = n2 == null ? 1 : n2 + 1;
        map.put(p2, n3);
    }

    public final boolean a(p p2) {
        if (p2.a >= 0.0f && p2.a < (float)this.a.a && p2.b > 0.0f && p2.b < (float)this.a.b) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final a b(p p2, p p3) {
        int n2;
        int n3;
        int n4 = (int)p2.a;
        int n5 = (int)p2.b;
        int n6 = (int)p3.a;
        int n7 = (int)p3.b;
        boolean bl2 = Math.abs(n7 - n5) > Math.abs(n6 - n4);
        if (!bl2) {
            n3 = n6;
            n6 = n7;
            n2 = n4;
            n7 = n3;
            n4 = n5;
            n5 = n2;
        }
        int n8 = Math.abs(n7 - n5);
        int n9 = Math.abs(n6 - n4);
        int n10 = (- n8) / 2;
        int n11 = n4 < n6 ? 1 : -1;
        int n12 = n5 < n7 ? 1 : -1;
        int n13 = 0;
        com.google.c.b.b b2 = this.a;
        n3 = bl2 ? n4 : n5;
        n2 = bl2 ? n5 : n4;
        boolean bl3 = b2.a(n3, n2);
        n3 = n13;
        do {
            int n14;
            n13 = n3;
            if (n5 == n7) break;
            b2 = this.a;
            n2 = bl2 ? n4 : n5;
            n13 = bl2 ? n5 : n4;
            boolean bl4 = b2.a(n2, n13);
            n2 = n3;
            boolean bl5 = bl3;
            if (bl4 != bl3) {
                n2 = n3 + 1;
                bl5 = bl4;
            }
            n3 = n14 = n10 + n9;
            n10 = n4;
            if (n14 > 0) {
                n13 = n2;
                if (n4 == n6) break;
                n10 = n4 + n11;
                n3 = n14 - n8;
            }
            n5 += n12;
            n13 = n3;
            n4 = n10;
            n3 = n2;
            bl3 = bl5;
            n10 = n13;
        } while (true);
        return new a(p2, p3, n13, 0);
    }

    public static final class a {
        public final p a;
        public final p b;
        public final int c;

        private a(p p2, p p3, int n2) {
            this.a = p2;
            this.b = p3;
            this.c = n2;
        }

        /* synthetic */ a(p p2, p p3, int n2, byte by2) {
            this(p2, p3, n2);
        }

        public final String toString() {
            return this.a + "/" + this.b + '/' + this.c;
        }
    }

    public static final class b
    implements Serializable,
    Comparator<a> {
        private b() {
        }

        public /* synthetic */ b(byte by2) {
            this();
        }
    }

}

