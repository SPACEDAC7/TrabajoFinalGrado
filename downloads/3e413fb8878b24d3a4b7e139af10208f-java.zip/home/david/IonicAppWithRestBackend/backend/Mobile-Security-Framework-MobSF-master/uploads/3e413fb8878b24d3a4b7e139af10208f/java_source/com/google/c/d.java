/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import com.google.c.m;

public final class d
extends m {
    private static final d a = new d();

    private d() {
    }

    public static d a() {
        return a;
    }
}

