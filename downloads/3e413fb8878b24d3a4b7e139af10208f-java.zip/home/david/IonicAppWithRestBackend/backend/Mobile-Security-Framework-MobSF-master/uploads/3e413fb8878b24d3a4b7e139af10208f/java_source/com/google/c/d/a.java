/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.d;

import com.google.c.c;
import com.google.c.d.a.b;
import com.google.c.e;
import com.google.c.g;
import com.google.c.j;
import com.google.c.l;
import com.google.c.n;
import com.google.c.o;
import com.google.c.p;
import java.util.Map;

public final class a
implements l {
    private static final p[] a = new p[0];
    private final com.google.c.d.a.c b = new com.google.c.d.a.c();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final n a(c var1_1, Map<e, ?> var2_2) {
        if (var2_2 == null) throw j.a();
        if (var2_2.containsKey((Object)e.b) == false) throw j.a();
        var2_2 = var1_1.a();
        var8_3 = var2_2.a;
        var7_4 = var2_2.b;
        var6_5 = -1;
        var10_6 = -1;
        var5_7 = 0;
        block4 : do {
            if (var5_7 >= var2_2.b) {
                var5_7 = var6_5 - var8_3;
                var6_5 = var10_6 - var7_4;
                var1_1 = var5_7 < 0 || var6_5 < 0 ? null : new int[]{var8_3, var7_4, var5_7, var6_5};
                if (var1_1 == null) {
                    throw j.a();
                }
                var7_4 = var1_1[0];
                var8_3 = var1_1[1];
                var9_8 = var1_1[2];
                var10_6 = var1_1[3];
                var3_11 = new com.google.c.b.b(30, 33);
                break;
            }
            var11_9 = 0;
            do {
                if (var11_9 >= var2_2.c) ** GOTO lbl41
                var12_10 = var2_2.d[var2_2.c * var5_7 + var11_9];
                if (var12_10 == 0) ** GOTO lbl60
                var9_8 = var7_4;
                if (var5_7 < var7_4) {
                    var9_8 = var5_7;
                }
                var7_4 = var10_6;
                if (var5_7 > var10_6) {
                    var7_4 = var5_7;
                }
                if (var11_9 << 5 >= var8_3) ** GOTO lbl43
                var10_6 = 0;
                while (var12_10 << 31 - var10_6 == 0) {
                    ++var10_6;
                }
                if ((var11_9 << 5) + var10_6 >= var8_3) ** GOTO lbl43
                var10_6 = (var11_9 << 5) + var10_6;
                ** GOTO lbl44
lbl41: // 1 sources:
                ++var5_7;
                continue block4;
lbl43: // 2 sources:
                var10_6 = var8_3;
lbl44: // 2 sources:
                if ((var11_9 << 5) + 31 <= var6_5) ** GOTO lbl-1000
                var8_3 = 31;
                while (var12_10 >>> var8_3 == 0) {
                    --var8_3;
                }
                if ((var11_9 << 5) + var8_3 > var6_5) {
                    var12_10 = (var11_9 << 5) + var8_3;
                    var6_5 = var7_4;
                    var8_3 = var9_8;
                    var7_4 = var12_10;
                } else lbl-1000: // 2 sources:
                {
                    var8_3 = var9_8;
                    var9_8 = var6_5;
                    var6_5 = var7_4;
                    var7_4 = var9_8;
                }
                ** GOTO lbl65
lbl60: // 1 sources:
                var9_8 = var8_3;
                var8_3 = var7_4;
                var7_4 = var6_5;
                var6_5 = var10_6;
                var10_6 = var9_8;
lbl65: // 3 sources:
                ++var11_9;
                var9_8 = var10_6;
                var10_6 = var6_5;
                var6_5 = var7_4;
                var7_4 = var8_3;
                var8_3 = var9_8;
            } while (true);
            break;
        } while (true);
        for (var5_7 = 0; var5_7 < 33; ++var5_7) {
            var11_9 = (var5_7 * var10_6 + var10_6 / 2) / 33;
            for (var6_5 = 0; var6_5 < 30; ++var6_5) {
                if (!var2_2.a((var6_5 * var9_8 + var9_8 / 2 + (var5_7 & 1) * var9_8 / 2) / 30 + var7_4, var8_3 + var11_9)) continue;
                var3_11.b(var6_5, var5_7);
            }
        }
        var1_1 = this.b;
        var3_11 = new com.google.c.d.a.a((com.google.c.b.b)var3_11);
        var2_2 = new byte[144];
        var7_4 = var3_11.b.b;
        var8_3 = var3_11.b.a;
        for (var5_7 = 0; var5_7 < var7_4; ++var5_7) {
            var4_12 = com.google.c.d.a.a.a[var5_7];
            for (var6_5 = 0; var6_5 < var8_3; ++var6_5) {
                var9_8 = var4_12[var6_5];
                if (var9_8 < 0 || !var3_11.b.a(var6_5, var5_7)) continue;
                var10_6 = var9_8 / 6;
                var11_9 = var2_2[var10_6];
                var2_2[var10_6] = (byte)((byte)(1 << 5 - var9_8 % 6) | var11_9);
            }
        }
        var1_1.a((byte[])var2_2, 0, 10, 10, 0);
        var5_7 = var2_2[0] & 15;
        switch (var5_7) {
            default: {
                throw g.a();
            }
            case 2: 
            case 3: 
            case 4: {
                var1_1.a((byte[])var2_2, 20, 84, 40, 1);
                var1_1.a((byte[])var2_2, 20, 84, 40, 2);
                var1_1 = new byte[94];
                break;
            }
            case 5: {
                var1_1.a((byte[])var2_2, 20, 68, 56, 1);
                var1_1.a((byte[])var2_2, 20, 68, 56, 2);
                var1_1 = new byte[78];
            }
        }
        System.arraycopy(var2_2, 0, var1_1, 0, 10);
        System.arraycopy(var2_2, 20, var1_1, 10, var1_1.length - 10);
        var1_1 = b.a((byte[])var1_1, var5_7);
        var2_2 = a.a;
        var2_2 = new n(var1_1.b, var1_1.a, (p[])var2_2, com.google.c.a.j);
        var1_1 = var1_1.d;
        if (var1_1 == null) return var2_2;
        var2_2.a(o.d, var1_1);
        return var2_2;
    }

    @Override
    public final void a() {
    }
}

