/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.d.a;

import com.google.c.b.e;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;

public final class b {
    private static final NumberFormat a = new DecimalFormat("000000000");
    private static final NumberFormat b = new DecimalFormat("000");
    private static final String[] c = new String[]{"\nABCDEFGHIJKLMNOPQRSTUVWXYZ\ufffa\u001c\u001d\u001e\ufffb \ufffc\"#$%&'()*+,-./0123456789:\ufff1\ufff2\ufff3\ufff4\ufff8", "`abcdefghijklmnopqrstuvwxyz\ufffa\u001c\u001d\u001e\ufffb{\ufffc}~;<=>?[\\]^_ ,./:@!|\ufffc\ufff5\ufff6\ufffc\ufff0\ufff2\ufff3\ufff4\ufff7", "\u00c0\u00c1\u00c2\u00c3\u00c4\u00c5\u00c6\u00c7\u00c8\u00c9\u00ca\u00cb\u00cc\u00cd\u00ce\u00cf\u00d0\u00d1\u00d2\u00d3\u00d4\u00d5\u00d6\u00d7\u00d8\u00d9\u00da\ufffa\u001c\u001d\u001e\u00db\u00dc\u00dd\u00de\u00df\u00aa\u00ac\u00b1\u00b2\u00b3\u00b5\u00b9\u00ba\u00bc\u00bd\u00be\u0081\u0082\u0083\u0084\u0085\u0086\u0087\u0088\u0089\ufff7 \ufff9\ufff3\ufff4\ufff8", "\u00e0\u00e1\u00e2\u00e3\u00e4\u00e5\u00e6\u00e7\u00e8\u00e9\u00ea\u00eb\u00ec\u00ed\u00ee\u00ef\u00f0\u00f1\u00f2\u00f3\u00f4\u00f5\u00f6\u00f7\u00f8\u00f9\u00fa\ufffa\u001c\u001d\u001e\ufffb\u00fb\u00fc\u00fd\u00fe\u00ff\u00a1\u00a8\u00ab\u00af\u00b0\u00b4\u00b7\u00b8\u00bb\u00bf\u008a\u008b\u008c\u008d\u008e\u008f\u0090\u0091\u0092\u0093\u0094\ufff7 \ufff2\ufff9\ufff4\ufff8", "\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\b\t\n\u000b\f\r\u000e\u000f\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001a\ufffa\ufffc\ufffc\u001b\ufffb\u001c\u001d\u001e\u001f\u009f\u00a0\u00a2\u00a3\u00a4\u00a5\u00a6\u00a7\u00a9\u00ad\u00ae\u00b6\u0095\u0096\u0097\u0098\u0099\u009a\u009b\u009c\u009d\u009e\ufff7 \ufff2\ufff3\ufff9\ufff8", "\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\b\t\n\u000b\f\r\u000e\u000f\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001a\u001b\u001c\u001d\u001e\u001f !\"#$%&'()*+,-./0123456789:;<=>?"};

    /*
     * Enabled aggressive block sorting
     */
    private static int a(byte[] arrby, byte[] arrby2) {
        if (arrby2.length == 0) {
            throw new IllegalArgumentException();
        }
        int n2 = 0;
        int n3 = 0;
        while (n2 < arrby2.length) {
            int n4 = arrby2[n2] - 1;
            n4 = (1 << 5 - n4 % 6 & arrby[n4 / 6]) == 0 ? 0 : 1;
            n3 += n4 << arrby2.length - n2 - 1;
            ++n2;
        }
        return n3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static e a(byte[] var0, int var1_1) {
        var3_2 = new StringBuilder(144);
        switch (var1_1) {
            case 2: 
            case 3: {
                if (var1_1 == 2) {
                    var6_3 = b.a(var0, new byte[]{33, 34, 35, 36, 25, 26, 27, 28, 29, 30, 19, 20, 21, 22, 23, 24, 13, 14, 15, 16, 17, 18, 7, 8, 9, 10, 11, 12, 1, 2});
                    var2_4 = new DecimalFormat("0000000000".substring(0, b.a(var0, new byte[]{39, 40, 41, 42, 31, 32}))).format(var6_3);
                } else {
                    var2_4 = String.valueOf(new char[]{b.c[0].charAt(b.a(var0, new byte[]{39, 40, 41, 42, 31, 32})), b.c[0].charAt(b.a(var0, new byte[]{33, 34, 35, 36, 25, 26})), b.c[0].charAt(b.a(var0, new byte[]{27, 28, 29, 30, 19, 20})), b.c[0].charAt(b.a(var0, new byte[]{21, 22, 23, 24, 13, 14})), b.c[0].charAt(b.a(var0, new byte[]{15, 16, 17, 18, 7, 8})), b.c[0].charAt(b.a(var0, new byte[]{9, 10, 11, 12, 1, 2}))});
                }
                var4_5 = b.b.format(b.a(var0, new byte[]{53, 54, 43, 44, 45, 46, 47, 48, 37, 38}));
                var5_6 = b.b.format(b.a(var0, new byte[]{55, 56, 57, 58, 59, 60, 49, 50, 51, 52}));
                var3_2.append(b.a(var0, 10, 84));
                if (var3_2.toString().startsWith("[)>\u001e01\u001d")) {
                    var3_2.insert(9, var2_4 + '\u001d' + var4_5 + '\u001d' + var5_6 + '\u001d');
                    ** break;
                }
                var3_2.insert(0, var2_4 + '\u001d' + var4_5 + '\u001d' + var5_6 + '\u001d');
                ** break;
            }
            case 4: {
                var3_2.append(b.a(var0, 1, 93));
            }
lbl19: // 4 sources:
            default: {
                return new e(var0, var3_2.toString(), null, String.valueOf(var1_1));
            }
            case 5: 
        }
        var3_2.append(b.a(var0, 1, 77));
        return new e(var0, var3_2.toString(), null, String.valueOf(var1_1));
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String a(byte[] arrby, int n2, int n3) {
        StringBuilder stringBuilder = new StringBuilder();
        int n4 = n2;
        int n5 = 0;
        int n6 = 0;
        int n7 = -1;
        while (n4 < n2 + n3) {
            int n8;
            char c2 = c[n6].charAt(arrby[n4]);
            switch (c2) {
                default: {
                    stringBuilder.append(c2);
                    n8 = n6;
                    n6 = n4;
                    n4 = n8;
                    break;
                }
                case '\ufff7': {
                    n6 = n4;
                    n7 = -1;
                    n4 = 0;
                    break;
                }
                case '\ufff8': {
                    n6 = n4;
                    n7 = -1;
                    n4 = 1;
                    break;
                }
                case '\ufff0': 
                case '\ufff1': 
                case '\ufff2': 
                case '\ufff3': 
                case '\ufff4': {
                    n8 = 1;
                    n7 = n4;
                    n4 = c2 - 65520;
                    n5 = n6;
                    n6 = n7;
                    n7 = n8;
                    break;
                }
                case '\ufff5': {
                    n8 = 2;
                    n7 = n4;
                    n4 = 0;
                    n5 = n6;
                    n6 = n7;
                    n7 = n8;
                    break;
                }
                case '\ufff6': {
                    n8 = 3;
                    n7 = n4;
                    n4 = 0;
                    n5 = n6;
                    n6 = n7;
                    n7 = n8;
                    break;
                }
                case '\ufffb': {
                    n8 = n4 + 1;
                    n4 = arrby[n8];
                    byte by2 = arrby[++n8];
                    byte by3 = arrby[++n8];
                    byte by4 = arrby[++n8];
                    byte by5 = arrby[++n8];
                    stringBuilder.append(a.format((n4 << 24) + (by2 << 18) + (by3 << 12) + (by4 << 6) + by5));
                    n4 = n6;
                    n6 = n8;
                    break;
                }
                case '\ufff9': {
                    n8 = -1;
                    n7 = n4;
                    n4 = n6;
                    n6 = n7;
                    n7 = n8;
                }
            }
            if (n7 == 0) {
                n4 = n5;
            }
            --n7;
            n8 = n6 + 1;
            n6 = n4;
            n4 = n8;
        }
        while (stringBuilder.length() > 0 && stringBuilder.charAt(stringBuilder.length() - 1) == '\ufffc') {
            stringBuilder.setLength(stringBuilder.length() - 1);
        }
        return stringBuilder.toString();
    }
}

