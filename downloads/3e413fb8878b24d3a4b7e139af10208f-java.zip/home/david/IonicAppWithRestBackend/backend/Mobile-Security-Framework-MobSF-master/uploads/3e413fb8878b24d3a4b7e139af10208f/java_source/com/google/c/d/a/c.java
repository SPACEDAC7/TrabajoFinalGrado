/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.d.a;

import com.google.c.b.b.a;
import com.google.c.b.b.e;
import com.google.c.d;

public final class c {
    private final com.google.c.b.b.c a = new com.google.c.b.b.c(a.h);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(byte[] arrby, int n2, int n3, int n4, int n5) {
        int n6 = 0;
        int n7 = n3 + n4;
        int n8 = n5 == 0 ? 1 : 2;
        int[] arrn = new int[n7 / n8];
        for (int i2 = 0; i2 < n7; ++i2) {
            if (n5 != 0 && i2 % 2 != n5 - 1) continue;
            arrn[i2 / n8] = arrby[i2 + n2] & 255;
        }
        try {
            this.a.a(arrn, n4 / n8);
            n4 = n6;
        }
        catch (e var1_2) {
            throw d.a();
        }
        do {
            if (n4 >= n3) {
                return;
            }
            if (n5 == 0 || n4 % 2 == n5 - 1) {
                arrby[n4 + n2] = (byte)arrn[n4 / n8];
            }
            ++n4;
        } while (true);
    }
}

