/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import android.support.design.widget.AppBarLayout;
import java.util.List;

public enum e {
    a(Object.class),
    b(Void.class),
    c(List.class),
    d(Void.class),
    e(String.class),
    f(int[].class),
    g(Void.class),
    h(Void.class),
    i(Void.class),
    j(AppBarLayout.b.class),
    k(int[].class);
    
    private final Class<?> l;

    private e(Class<?> class_) {
        this.l = class_;
    }
}

