/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.e;
import com.google.c.e.k;
import com.google.c.j;
import com.google.c.n;
import com.google.c.p;
import java.util.Arrays;
import java.util.Map;

public final class a
extends k {
    static final char[] a = "0123456789-$:/.+ABCD".toCharArray();
    static final int[] b = new int[]{3, 6, 9, 96, 18, 66, 33, 36, 48, 72, 12, 24, 69, 81, 84, 21, 26, 41, 11, 14};
    private static final char[] c = new char[]{'A', 'B', 'C', 'D'};
    private final StringBuilder d = new StringBuilder(20);
    private int[] e = new int[80];
    private int f = 0;

    private void a(int n2) {
        this.e[this.f] = n2;
        ++this.f;
        if (this.f >= this.e.length) {
            int[] arrn = new int[this.f << 1];
            System.arraycopy(this.e, 0, arrn, 0, this.f);
            this.e = arrn;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean a(char[] arrc, char c2) {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (arrc == null) return bl3;
        int n2 = arrc.length;
        int n3 = 0;
        do {
            bl3 = bl2;
            if (n3 >= n2) return bl3;
            if (arrc[n3] == c2) {
                return true;
            }
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private int b(int n2) {
        int n3;
        int n4;
        int n5;
        int n6 = Integer.MAX_VALUE;
        int n7 = n2 + 7;
        if (n7 >= this.f) {
            return -1;
        }
        int[] arrn = this.e;
        int n8 = Integer.MAX_VALUE;
        int n9 = 0;
        for (n3 = n2; n3 < n7; n3 += 2) {
            n5 = arrn[n3];
            n4 = n8;
            if (n5 < n8) {
                n4 = n5;
            }
            if (n5 > n9) {
                n9 = n5;
            }
            n8 = n4;
        }
        int n10 = (n8 + n9) / 2;
        n9 = 0;
        n8 = n6;
        for (n3 = n2 + 1; n3 < n7; n3 += 2) {
            n5 = arrn[n3];
            n4 = n8;
            if (n5 < n8) {
                n4 = n5;
            }
            if (n5 > n9) {
                n9 = n5;
            }
            n8 = n4;
        }
        n5 = (n8 + n9) / 2;
        n4 = 128;
        n9 = 0;
        for (n3 = 0; n3 < 7; ++n3) {
            n8 = (n3 & 1) == 0 ? n10 : n5;
            n4 >>= 1;
            if (arrn[n2 + n3] <= n8) continue;
            n9 |= n4;
        }
        n2 = 0;
        while (n2 < b.length) {
            n3 = n2;
            if (b[n2] == n9) return n3;
            ++n2;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final n a(int n2, com.google.c.b.a object, Map<e, ?> object2) {
        int n3;
        Object object3;
        int n4;
        int n5;
        Arrays.fill(this.e, 0);
        this.f = 0;
        int n6 = object.d(0);
        int n7 = object.b;
        if (n6 >= n7) {
            throw j.a();
        }
        int n8 = 1;
        int n9 = 0;
        while (n6 < n7) {
            if (object.a(n6) ^ n8) {
                n4 = n9 + 1;
                n9 = n8;
                n8 = n4;
            } else {
                this.a(n9);
                n8 = n8 == 0 ? 1 : 0;
                n9 = n8;
                n8 = 1;
            }
            n4 = n6 + 1;
            n6 = n9;
            n9 = n8;
            n8 = n6;
            n6 = n4;
        }
        this.a(n9);
        n8 = 1;
        do {
            if (n8 >= this.f) {
                throw j.a();
            }
            n9 = this.b(n8);
            if (n9 != -1 && a.a(c, a[n9])) {
                n6 = 0;
                for (n9 = n8; n9 < n8 + 7; n6 += this.e[n9], ++n9) {
                }
                if (n8 == 1 || this.e[n8 - 1] >= n6 / 2) break;
            }
            n8 += 2;
        } while (true);
        this.d.setLength(0);
        n9 = n8;
        do {
            if ((n6 = this.b(n9)) == -1) {
                throw j.a();
            }
            this.d.append((char)n6);
            n3 = n9 + 8;
            if (this.d.length() > 1 && a.a(c, a[n6])) break;
            n9 = n3;
        } while (n3 < this.f);
        n4 = this.e[n3 - 1];
        n6 = 0;
        for (n9 = -8; n9 < -1; n6 += this.e[n3 + n9], ++n9) {
        }
        if (n3 < this.f && n4 < n6 / 2) {
            throw j.a();
        }
        Object object4 = object = new int[4];
        object4[0] = 0;
        object4[1] = 0;
        object4[2] = 0;
        object4[3] = 0;
        Object object5 = object3 = new int[4];
        object5[0] = 0;
        object5[1] = 0;
        object5[2] = 0;
        object5[3] = 0;
        int n10 = this.d.length() - 1;
        n9 = 0;
        n6 = n8;
        do {
            n7 = b[this.d.charAt(n9)];
            for (n4 = 6; n4 >= 0; n7 >>= 1, --n4) {
                n5 = (n4 & 1) + ((n7 & 1) << 1);
                object[n5] = object[n5] + this.e[n6 + n4];
                object3[n5] = object3[n5] + 1;
            }
            if (n9 >= n10) break;
            n6 += 8;
            ++n9;
        } while (true);
        Object object6 = new float[4];
        float[] arrf = new float[4];
        for (n9 = 0; n9 < 2; ++n9) {
            arrf[n9] = 0.0f;
            arrf[n9 + 2] = ((float)object[n9] / (float)object3[n9] + (float)object[n9 + 2] / (float)object3[n9 + 2]) / 2.0f;
            object6[n9] = arrf[n9 + 2];
            object6[n9 + 2] = ((float)object[n9 + 2] * 2.0f + 1.5f) / (float)object3[n9 + 2];
        }
        n9 = 0;
        n6 = n8;
        do {
            n7 = b[this.d.charAt(n9)];
            for (n4 = 6; n4 >= 0; n7 >>= 1, --n4) {
                int n11 = this.e[n6 + n4];
                n5 = (n4 & 1) + ((n7 & 1) << 1);
                if ((float)n11 >= arrf[n5] && (float)n11 <= object6[n5]) continue;
                throw j.a();
            }
            if (n9 >= n10) break;
            n6 += 8;
            ++n9;
        } while (true);
        for (n9 = 0; n9 < this.d.length(); ++n9) {
            this.d.setCharAt(n9, a[this.d.charAt(n9)]);
        }
        char c2 = this.d.charAt(0);
        if (!a.a(c, c2)) {
            throw j.a();
        }
        c2 = this.d.charAt(this.d.length() - 1);
        if (!a.a(c, c2)) {
            throw j.a();
        }
        if (this.d.length() <= 3) {
            throw j.a();
        }
        if (object2 == null || !object2.containsKey((Object)e.i)) {
            this.d.deleteCharAt(this.d.length() - 1);
            this.d.deleteCharAt(0);
        }
        n9 = 0;
        for (n6 = 0; n6 < n8; ++n6) {
            n4 = this.e[n6];
            n9 = n4 + n9;
        }
        float f2 = n9;
        do {
            if (n8 >= n3 - 1) {
                float f3 = n9;
                object = this.d.toString();
                object2 = new p(f2, n2);
                object3 = new p(f3, n2);
                object6 = com.google.c.a.b;
                return new n((String)object, null, new p[]{object2, object3}, (com.google.c.a)((Object)object6));
            }
            n9 += this.e[n8];
            ++n8;
        } while (true);
    }
}

