/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a;

import com.google.c.e.k;
import com.google.c.j;

public abstract class a
extends k {
    public final int[] a = new int[4];
    public final int[] b = new int[8];
    public final float[] c = new float[4];
    public final float[] d = new float[4];
    public final int[] e = new int[this.b.length / 2];
    public final int[] f = new int[this.b.length / 2];

    public static int a(int[] arrn) {
        int n2 = arrn.length;
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            n3 += arrn[i2];
        }
        return n3;
    }

    public static int a(int[] arrn, int[][] arrn2) {
        for (int i2 = 0; i2 < arrn2.length; ++i2) {
            if (a.a(arrn, arrn2[i2], 0.45f) >= 0.2f) continue;
            return i2;
        }
        throw j.a();
    }

    public static void a(int[] arrn, float[] arrf) {
        int n2 = 0;
        float f2 = arrf[0];
        for (int i2 = 1; i2 < arrn.length; ++i2) {
            float f3 = f2;
            if (arrf[i2] > f2) {
                f3 = arrf[i2];
                n2 = i2;
            }
            f2 = f3;
        }
        arrn[n2] = arrn[n2] + 1;
    }

    public static void b(int[] arrn, float[] arrf) {
        int n2 = 0;
        float f2 = arrf[0];
        for (int i2 = 1; i2 < arrn.length; ++i2) {
            float f3 = f2;
            if (arrf[i2] < f2) {
                f3 = arrf[i2];
                n2 = i2;
            }
            f2 = f3;
        }
        arrn[n2] = arrn[n2] - 1;
    }

    public static boolean b(int[] arrn) {
        int n2 = arrn[0] + arrn[1];
        int n3 = arrn[2];
        int n4 = arrn[3];
        float f2 = (float)n2 / (float)(n3 + n2 + n4);
        if (f2 >= 0.7916667f && f2 <= 0.89285713f) {
            n2 = Integer.MAX_VALUE;
            int n5 = Integer.MIN_VALUE;
            for (int n6 : arrn) {
                n4 = n5;
                if (n6 > n5) {
                    n4 = n6;
                }
                if (n6 < n2) {
                    n2 = n6;
                }
                n5 = n4;
            }
            if (n5 < n2 * 10) {
                return true;
            }
            return false;
        }
        return false;
    }
}

