/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a;

import com.google.c.e.a.b;
import com.google.c.e.a.c;

public final class a {
    final b a;
    final b b;
    final c c;
    private final boolean d;

    a(b b2, b b3, c c2) {
        this.a = b2;
        this.b = b3;
        this.c = c2;
        this.d = true;
    }

    private static int a(Object object) {
        if (object == null) {
            return 0;
        }
        return object.hashCode();
    }

    private static boolean a(Object object, Object object2) {
        if (object == null) {
            if (object2 == null) {
                return true;
            }
            return false;
        }
        return object.equals(object2);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (!(object instanceof a)) {
            return false;
        }
        object = (a)object;
        if (!a.a(this.a, object.a)) return false;
        if (!a.a(this.b, object.b)) return false;
        if (!a.a(this.c, object.c)) return false;
        return true;
    }

    public final int hashCode() {
        return a.a(this.a) ^ a.a(this.b) ^ a.a(this.c);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final String toString() {
        Object object;
        StringBuilder stringBuilder = new StringBuilder("[ ").append(this.a).append(" , ").append(this.b).append(" : ");
        if (this.c == null) {
            object = "null";
            do {
                return stringBuilder.append(object).append(" ]").toString();
                break;
            } while (true);
        }
        object = this.c.a;
        return stringBuilder.append(object).append(" ]").toString();
    }
}

