/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.e.a.a.a.f;

public final class a
extends f {
    public a(com.google.c.b.a a2) {
        super(a2);
    }

    @Override
    protected final int a(int n2) {
        return n2;
    }

    @Override
    protected final void a(StringBuilder stringBuilder, int n2) {
        stringBuilder.append("(3103)");
    }
}

