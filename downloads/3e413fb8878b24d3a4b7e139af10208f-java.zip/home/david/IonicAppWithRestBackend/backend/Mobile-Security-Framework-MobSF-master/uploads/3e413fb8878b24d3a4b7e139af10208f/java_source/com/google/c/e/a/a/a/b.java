/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.b.a;
import com.google.c.e.a.a.a.f;

public final class b
extends f {
    public b(a a2) {
        super(a2);
    }

    @Override
    protected final int a(int n2) {
        if (n2 < 10000) {
            return n2;
        }
        return n2 - 10000;
    }

    @Override
    protected final void a(StringBuilder stringBuilder, int n2) {
        if (n2 < 10000) {
            stringBuilder.append("(3202)");
            return;
        }
        stringBuilder.append("(3203)");
    }
}

