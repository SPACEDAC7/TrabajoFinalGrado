/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.b.a;
import com.google.c.e.a.a.a.h;
import com.google.c.e.a.a.a.j;
import com.google.c.e.a.a.a.o;
import com.google.c.e.a.a.a.s;

public final class c
extends h {
    public c(a a2) {
        super(a2);
    }

    @Override
    public final String a() {
        if (this.a.b < 48) {
            throw com.google.c.j.a();
        }
        StringBuilder stringBuilder = new StringBuilder();
        this.b(stringBuilder, 8);
        int n2 = this.b.a(48, 2);
        stringBuilder.append("(392");
        stringBuilder.append(n2);
        stringBuilder.append(')');
        stringBuilder.append(this.b.a((int)50, (String)null).a);
        return stringBuilder.toString();
    }
}

