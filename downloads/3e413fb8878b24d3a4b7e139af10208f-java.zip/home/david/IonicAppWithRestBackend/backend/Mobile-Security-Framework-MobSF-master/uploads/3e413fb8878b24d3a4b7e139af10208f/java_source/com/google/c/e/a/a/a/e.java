/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.b.a;
import com.google.c.e.a.a.a.i;
import com.google.c.e.a.a.a.j;
import com.google.c.e.a.a.a.s;

public final class e
extends i {
    private final String c;
    private final String d;

    public e(a a2, String string, String string2) {
        super(a2);
        this.c = string2;
        this.d = string;
    }

    @Override
    protected final int a(int n2) {
        return n2 % 100000;
    }

    @Override
    public final String a() {
        if (this.a.b != 84) {
            throw com.google.c.j.a();
        }
        StringBuilder stringBuilder = new StringBuilder();
        this.b(stringBuilder, 8);
        this.b(stringBuilder, 48, 20);
        int n2 = this.b.a(68, 16);
        if (n2 != 38400) {
            stringBuilder.append('(');
            stringBuilder.append(this.c);
            stringBuilder.append(')');
            int n3 = n2 % 32;
            int n4 = n2 / 32;
            n2 = n4 % 12 + 1;
            if ((n4 /= 12) / 10 == 0) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n4);
            if (n2 / 10 == 0) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n2);
            if (n3 / 10 == 0) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n3);
        }
        return stringBuilder.toString();
    }

    @Override
    protected final void a(StringBuilder stringBuilder, int n2) {
        stringBuilder.append('(');
        stringBuilder.append(this.d);
        stringBuilder.append(n2 /= 100000);
        stringBuilder.append(')');
    }
}

