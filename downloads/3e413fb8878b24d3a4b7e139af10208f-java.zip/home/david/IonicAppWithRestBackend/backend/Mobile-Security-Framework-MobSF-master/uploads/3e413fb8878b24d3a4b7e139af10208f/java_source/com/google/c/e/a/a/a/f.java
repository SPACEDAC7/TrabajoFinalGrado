/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.b.a;
import com.google.c.e.a.a.a.i;
import com.google.c.e.a.a.a.j;

abstract class f
extends i {
    f(a a2) {
        super(a2);
    }

    @Override
    public final String a() {
        if (this.a.b != 60) {
            throw com.google.c.j.a();
        }
        StringBuilder stringBuilder = new StringBuilder();
        this.b(stringBuilder, 5);
        this.b(stringBuilder, 45, 15);
        return stringBuilder.toString();
    }
}

