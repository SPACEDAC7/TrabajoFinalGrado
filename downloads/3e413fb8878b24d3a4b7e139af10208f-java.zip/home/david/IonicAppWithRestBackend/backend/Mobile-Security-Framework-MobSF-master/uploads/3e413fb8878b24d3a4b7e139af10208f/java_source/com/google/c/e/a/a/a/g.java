/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.b.a;
import com.google.c.e.a.a.a.h;
import com.google.c.e.a.a.a.j;
import com.google.c.e.a.a.a.s;

public final class g
extends h {
    public g(a a2) {
        super(a2);
    }

    @Override
    public final String a() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("(01)");
        int n2 = stringBuilder.length();
        stringBuilder.append(this.b.a(4, 4));
        this.a(stringBuilder, 8, n2);
        return this.b.a(stringBuilder, 48);
    }
}

