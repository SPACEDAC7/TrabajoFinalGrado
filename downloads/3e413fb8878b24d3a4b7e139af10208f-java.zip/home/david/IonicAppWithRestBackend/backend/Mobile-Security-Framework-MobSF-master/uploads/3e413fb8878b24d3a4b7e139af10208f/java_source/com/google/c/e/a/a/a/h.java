/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.b.a;
import com.google.c.e.a.a.a.j;
import com.google.c.e.a.a.a.s;

abstract class h
extends j {
    h(a a2) {
        super(a2);
    }

    protected final void a(StringBuilder stringBuilder, int n2, int n3) {
        int n4;
        int n5;
        for (n4 = 0; n4 < 4; ++n4) {
            n5 = this.b.a(n4 * 10 + n2, 10);
            if (n5 / 100 == 0) {
                stringBuilder.append('0');
            }
            if (n5 / 10 == 0) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n5);
        }
        n4 = 0;
        for (n2 = 0; n2 < 13; ++n2) {
            int n6;
            n5 = n6 = stringBuilder.charAt(n2 + n3) - 48;
            if ((n2 & 1) == 0) {
                n5 = n6 * 3;
            }
            n4 += n5;
        }
        n2 = n3 = 10 - n4 % 10;
        if (n3 == 10) {
            n2 = 0;
        }
        stringBuilder.append(n2);
    }

    protected final void b(StringBuilder stringBuilder, int n2) {
        stringBuilder.append("(01)");
        int n3 = stringBuilder.length();
        stringBuilder.append('9');
        this.a(stringBuilder, n2, n3);
    }
}

