/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.b.a;
import com.google.c.e.a.a.a.h;
import com.google.c.e.a.a.a.j;
import com.google.c.e.a.a.a.s;

abstract class i
extends h {
    i(a a2) {
        super(a2);
    }

    protected abstract int a(int var1);

    protected abstract void a(StringBuilder var1, int var2);

    protected final void b(StringBuilder stringBuilder, int n2, int n3) {
        n2 = this.b.a(n2, n3);
        this.a(stringBuilder, n2);
        int n4 = this.a(n2);
        n3 = 100000;
        for (n2 = 0; n2 < 5; ++n2) {
            if (n4 / n3 == 0) {
                stringBuilder.append('0');
            }
            n3 /= 10;
        }
        stringBuilder.append(n4);
    }
}

