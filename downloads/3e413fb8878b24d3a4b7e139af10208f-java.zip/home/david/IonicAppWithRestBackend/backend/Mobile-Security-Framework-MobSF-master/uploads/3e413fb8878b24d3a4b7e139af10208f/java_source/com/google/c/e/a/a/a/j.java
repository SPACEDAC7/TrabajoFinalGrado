/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.b.a;
import com.google.c.e.a.a.a.s;

public abstract class j {
    final a a;
    final s b;

    j(a a2) {
        this.a = a2;
        this.b = new s(a2);
    }

    public abstract String a();
}

