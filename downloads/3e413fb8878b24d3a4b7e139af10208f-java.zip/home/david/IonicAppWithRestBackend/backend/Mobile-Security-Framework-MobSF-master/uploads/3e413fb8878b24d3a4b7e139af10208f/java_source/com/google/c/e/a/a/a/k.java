/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.b.a;
import com.google.c.e.a.a.a.j;
import com.google.c.e.a.a.a.s;

public final class k
extends j {
    public k(a a2) {
        super(a2);
    }

    @Override
    public final String a() {
        StringBuilder stringBuilder = new StringBuilder();
        return this.b.a(stringBuilder, 5);
    }
}

