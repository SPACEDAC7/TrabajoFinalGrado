/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.e.a.a.a.o;

final class l {
    final o a;
    final boolean b;

    l() {
        this(null, false);
    }

    l(o o2, boolean bl2) {
        this.b = bl2;
        this.a = o2;
    }
}

