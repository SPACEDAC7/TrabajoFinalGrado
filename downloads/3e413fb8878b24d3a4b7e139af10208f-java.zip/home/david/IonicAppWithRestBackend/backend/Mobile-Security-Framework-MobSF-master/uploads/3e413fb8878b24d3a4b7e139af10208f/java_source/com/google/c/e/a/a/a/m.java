/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

final class m {
    int a = 0;
    int b = a.a;

    m() {
    }

    final void a(int n2) {
        this.a += n2;
    }

    static final class a
    extends Enum<a> {
        public static final /* enum */ int a = 1;
        public static final /* enum */ int b = 2;
        public static final /* enum */ int c = 3;
        private static final /* synthetic */ int[] d;

        static {
            d = new int[]{a, b, c};
        }
    }

}

