/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.e.a.a.a.q;

final class n
extends q {
    final char a;

    n(int n2, char c2) {
        super(n2);
        this.a = c2;
    }

    final boolean a() {
        if (this.a == '$') {
            return true;
        }
        return false;
    }
}

