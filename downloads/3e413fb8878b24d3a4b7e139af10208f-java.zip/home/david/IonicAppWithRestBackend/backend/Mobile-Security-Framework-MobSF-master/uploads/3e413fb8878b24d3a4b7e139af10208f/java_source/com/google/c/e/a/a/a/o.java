/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.e.a.a.a.q;

final class o
extends q {
    final String a;
    final int b;
    final boolean c;

    o(int n2, String string) {
        super(n2);
        this.a = string;
        this.c = false;
        this.b = 0;
    }

    o(int n2, String string, int n3) {
        super(n2);
        this.c = true;
        this.b = n3;
        this.a = string;
    }
}

