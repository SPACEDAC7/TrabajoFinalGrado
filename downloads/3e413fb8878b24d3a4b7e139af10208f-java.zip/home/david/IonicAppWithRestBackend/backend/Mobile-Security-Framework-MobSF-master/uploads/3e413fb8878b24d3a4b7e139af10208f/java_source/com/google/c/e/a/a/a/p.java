/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.e.a.a.a.q;
import com.google.c.g;

final class p
extends q {
    final int a;
    final int b;

    p(int n2, int n3, int n4) {
        super(n2);
        if (n3 < 0 || n3 > 10 || n4 < 0 || n4 > 10) {
            throw g.a();
        }
        this.a = n3;
        this.b = n4;
    }

    final boolean a() {
        if (this.b == 10) {
            return true;
        }
        return false;
    }
}

