/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

abstract class q {
    final int d;

    q(int n2) {
        this.d = n2;
    }
}

