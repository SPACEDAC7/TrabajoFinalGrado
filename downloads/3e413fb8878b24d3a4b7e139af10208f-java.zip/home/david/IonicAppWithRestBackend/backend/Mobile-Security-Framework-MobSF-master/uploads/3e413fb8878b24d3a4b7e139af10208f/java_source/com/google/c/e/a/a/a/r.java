/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.j;

final class r {
    private static final Object a = new Object();
    private static final Object[][] b;
    private static final Object[][] c;
    private static final Object[][] d;
    private static final Object[][] e;

    static {
        Object object = new Object[]{"00", 18};
        Object object2 = new Object[]{"01", 14};
        Object object3 = new Object[]{"02", 14};
        Object object4 = a;
        Object object5 = new Object[]{"11", 6};
        Object object6 = new Object[]{"12", 6};
        Object object7 = new Object[]{"13", 6};
        Object[] arrobject = new Object[]{"15", 6};
        Object[] arrobject2 = new Object[]{"17", 6};
        Object[] arrobject3 = new Object[]{"20", 2};
        Object[] arrobject4 = new Object[]{"21", a, 20};
        Object[] arrobject5 = new Object[]{"22", a, 29};
        Object[] arrobject6 = new Object[]{"30", a, 8};
        Object[] arrobject7 = new Object[]{"37", a, 8};
        Object[] arrobject8 = new Object[]{"90", a, 30};
        Object[] arrobject9 = new Object[]{"91", a, 30};
        Object[] arrobject10 = new Object[]{"92", a, 30};
        Object[] arrobject11 = new Object[]{"93", a, 30};
        Object[] arrobject12 = new Object[]{"94", a, 30};
        Object[] arrobject13 = new Object[]{"95", a, 30};
        Object[] arrobject14 = new Object[]{"96", a, 30};
        Object[] arrobject15 = new Object[]{"97", a, 30};
        Object[] arrobject16 = new Object[]{"98", a, 30};
        Object[] arrobject17 = new Object[]{"99", a, 30};
        b = new Object[][]{object, object2, object3, {"10", object4, 20}, object5, object6, object7, arrobject, arrobject2, arrobject3, arrobject4, arrobject5, arrobject6, arrobject7, arrobject8, arrobject9, arrobject10, arrobject11, arrobject12, arrobject13, arrobject14, arrobject15, arrobject16, arrobject17};
        object4 = a;
        object6 = new Object[]{"241", a, 30};
        object7 = new Object[]{"242", a, 6};
        object = a;
        arrobject = new Object[]{"251", a, 30};
        arrobject2 = new Object[]{"253", a, 17};
        object2 = a;
        arrobject3 = new Object[]{"400", a, 30};
        object3 = a;
        arrobject4 = new Object[]{"402", 17};
        arrobject5 = new Object[]{"403", a, 30};
        arrobject6 = new Object[]{"413", 13};
        arrobject7 = new Object[]{"414", 13};
        arrobject8 = new Object[]{"420", a, 20};
        arrobject9 = new Object[]{"421", a, 15};
        arrobject10 = new Object[]{"422", 3};
        object5 = a;
        arrobject11 = new Object[]{"424", 3};
        c = new Object[][]{{"240", object4, 30}, object6, object7, {"250", object, 30}, arrobject, arrobject2, {"254", object2, 20}, arrobject3, {"401", object3, 30}, arrobject4, arrobject5, {"410", 13}, {"411", 13}, {"412", 13}, arrobject6, arrobject7, arrobject8, arrobject9, arrobject10, {"423", object5, 15}, arrobject11, {"425", 3}, {"426", 3}};
        object2 = new Object[]{"313", 6};
        object3 = new Object[]{"314", 6};
        object5 = new Object[]{"316", 6};
        object6 = new Object[]{"320", 6};
        object7 = new Object[]{"321", 6};
        arrobject = new Object[]{"322", 6};
        arrobject2 = new Object[]{"323", 6};
        arrobject3 = new Object[]{"326", 6};
        arrobject4 = new Object[]{"328", 6};
        arrobject5 = new Object[]{"330", 6};
        arrobject6 = new Object[]{"331", 6};
        arrobject7 = new Object[]{"332", 6};
        arrobject8 = new Object[]{"334", 6};
        arrobject9 = new Object[]{"335", 6};
        arrobject10 = new Object[]{"341", 6};
        arrobject11 = new Object[]{"343", 6};
        arrobject12 = new Object[]{"345", 6};
        arrobject13 = new Object[]{"346", 6};
        arrobject14 = new Object[]{"348", 6};
        arrobject15 = new Object[]{"351", 6};
        arrobject16 = new Object[]{"352", 6};
        arrobject17 = new Object[]{"353", 6};
        Object[] arrobject18 = new Object[]{"355", 6};
        Object[] arrobject19 = new Object[]{"356", 6};
        Object[] arrobject20 = new Object[]{"365", 6};
        Object[] arrobject21 = new Object[]{"368", 6};
        Object[] arrobject22 = new Object[]{"369", 6};
        Object[] arrobject23 = new Object[]{"390", a, 15};
        Object[] arrobject24 = new Object[]{"391", a, 18};
        Object[] arrobject25 = new Object[]{"392", a, 15};
        object4 = a;
        object = a;
        d = new Object[][]{{"310", 6}, {"311", 6}, {"312", 6}, object2, object3, {"315", 6}, object5, object6, object7, arrobject, arrobject2, {"324", 6}, {"325", 6}, arrobject3, {"327", 6}, arrobject4, {"329", 6}, arrobject5, arrobject6, arrobject7, {"333", 6}, arrobject8, arrobject9, {"336", 6}, {"340", 6}, arrobject10, {"342", 6}, arrobject11, {"344", 6}, arrobject12, arrobject13, {"347", 6}, arrobject14, {"349", 6}, {"350", 6}, arrobject15, arrobject16, arrobject17, {"354", 6}, arrobject18, arrobject19, {"357", 6}, {"360", 6}, {"361", 6}, {"362", 6}, {"363", 6}, {"364", 6}, arrobject20, {"366", 6}, {"367", 6}, arrobject21, arrobject22, arrobject23, arrobject24, arrobject25, {"393", object4, 18}, {"703", object, 30}};
        object4 = a;
        object = a;
        object2 = a;
        object3 = a;
        arrobject = new Object[]{"8007", a, 30};
        object5 = a;
        arrobject2 = new Object[]{"8018", 18};
        arrobject3 = new Object[]{"8020", a, 25};
        object6 = a;
        object7 = a;
        e = new Object[][]{{"7001", 13}, {"7002", object4, 30}, {"7003", 10}, {"8001", 14}, {"8002", object, 20}, {"8003", object2, 30}, {"8004", object3, 30}, {"8005", 6}, {"8006", 18}, arrobject, {"8008", object5, 12}, arrobject2, arrobject3, {"8100", 6}, {"8101", 10}, {"8102", 2}, {"8110", object6, 70}, {"8200", object7, 70}};
    }

    private static String a(int n2, int n3, String string) {
        if (string.length() < n2) {
            throw j.a();
        }
        String string2 = string.substring(0, n2);
        if (string.length() < n2 + n3) {
            throw j.a();
        }
        String string3 = string.substring(n2, n2 + n3);
        string = string.substring(n2 + n3);
        string2 = "(" + string2 + ')' + string3;
        if ((string = r.a(string)) == null) {
            return string2;
        }
        return string2 + string;
    }

    static String a(String string) {
        if (string.isEmpty()) {
            return null;
        }
        if (string.length() < 2) {
            throw j.a();
        }
        String string2 = string.substring(0, 2);
        for (Object[] arrobject222 : b) {
            if (!arrobject222[0].equals(string2)) continue;
            if (arrobject222[1] == a) {
                return r.b(2, (Integer)arrobject222[2], string);
            }
            return r.a(2, (Integer)arrobject222[1], string);
        }
        if (string.length() < 3) {
            throw j.a();
        }
        string2 = string.substring(0, 3);
        for (Object[] arrobject222 : c) {
            if (!arrobject222[0].equals(string2)) continue;
            if (arrobject222[1] == a) {
                return r.b(3, (Integer)arrobject222[2], string);
            }
            return r.a(3, (Integer)arrobject222[1], string);
        }
        for (Object[] arrobject222 : d) {
            if (!arrobject222[0].equals(string2)) continue;
            if (arrobject222[1] == a) {
                return r.b(4, (Integer)arrobject222[2], string);
            }
            return r.a(4, (Integer)arrobject222[1], string);
        }
        if (string.length() < 4) {
            throw j.a();
        }
        string2 = string.substring(0, 4);
        for (Object[] arrobject222 : e) {
            if (!arrobject222[0].equals(string2)) continue;
            if (arrobject222[1] == a) {
                return r.b(4, (Integer)arrobject222[2], string);
            }
            return r.a(4, (Integer)arrobject222[1], string);
        }
        throw j.a();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String b(int n2, int n3, String string) {
        String string2 = string.substring(0, n2);
        n3 = string.length() < n2 + n3 ? string.length() : n2 + n3;
        String string3 = string.substring(n2, n3);
        string = string.substring(n3);
        string2 = "(" + string2 + ')' + string3;
        if ((string = r.a(string)) == null) {
            return string2;
        }
        return string2 + string;
    }
}

