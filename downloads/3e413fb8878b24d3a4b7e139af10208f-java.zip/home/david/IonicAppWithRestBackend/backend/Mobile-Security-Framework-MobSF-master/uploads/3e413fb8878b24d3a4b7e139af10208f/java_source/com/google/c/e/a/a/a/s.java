/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a.a;

import com.google.c.b.a;
import com.google.c.e.a.a.a.l;
import com.google.c.e.a.a.a.m;
import com.google.c.e.a.a.a.n;
import com.google.c.e.a.a.a.o;
import com.google.c.e.a.a.a.p;
import com.google.c.e.a.a.a.q;
import com.google.c.e.a.a.a.r;
import com.google.c.g;

public final class s {
    private final a a;
    private final m b = new m();
    private final StringBuilder c = new StringBuilder();

    s(a a2) {
        this.a = a2;
    }

    public static int a(a a2, int n2, int n3) {
        int n4 = 0;
        for (int i2 = 0; i2 < n3; ++i2) {
            int n5 = n4;
            if (a2.a(n2 + i2)) {
                n5 = n4 | 1 << n3 - i2 - 1;
            }
            n4 = n5;
        }
        return n4;
    }

    /*
     * Unable to fully structure code
     */
    private l a() {
        block0 : do {
            block18 : {
                block19 : {
                    block17 : {
                        block15 : {
                            block16 : {
                                if ((var3_9 = this.b.a) + 7 <= this.a.b) ** GOTO lbl24
                                if (var3_9 + 4 <= this.a.b) {
                                    var4_10 = true;
lbl5: // 4 sources:
                                    do {
                                        if (!var4_10) break block0;
                                        var2_8 = this.b.a;
                                        if (var2_8 + 7 <= this.a.b) break block15;
                                        if ((var2_8 = this.a(var2_8, 4)) != 0) break block16;
                                        var1_2 = new p(this.a.b, 10, 10);
lbl11: // 3 sources:
                                        do {
                                            this.b.a = var1_1.d;
                                            if (var1_1.a != 10) break block17;
                                            var2_8 = 1;
lbl15: // 2 sources:
                                            do {
                                                if (var2_8 == 0) break block18;
                                                if (var1_1.a()) {
                                                    var1_3 = new o(this.b.a, this.c.toString());
lbl19: // 2 sources:
                                                    do {
                                                        return new l((o)var1_4, true);
                                                        break;
                                                    } while (true);
                                                }
                                                break block19;
                                                break;
                                            } while (true);
                                            break;
                                        } while (true);
                                        break;
                                    } while (true);
                                }
                                var4_10 = false;
                                ** GOTO lbl5
lbl24: // 2 sources:
                                for (var2_8 = var3_9; var2_8 < var3_9 + 3; ++var2_8) {
                                    if (!this.a.a(var2_8)) continue;
                                    var4_10 = true;
                                    ** GOTO lbl5
                                }
                                var4_10 = this.a.a(var3_9 + 3);
                                ** continue;
                            }
                            var1_5 = new p(this.a.b, var2_8 - 1, 10);
                            ** GOTO lbl11
                        }
                        var3_9 = this.a(var2_8, 7);
                        var1_6 = new p(var2_8 + 7, (var3_9 - 8) / 11, (var3_9 - 8) % 11);
                        ** continue;
                    }
                    var2_8 = 0;
                    ** continue;
                }
                var1_7 = new o(this.b.a, this.c.toString(), var1_1.b);
                ** continue;
            }
            this.c.append(var1_1.a);
            if (var1_1.a()) {
                return new l(new o(this.b.a, this.c.toString()), true);
            }
            this.c.append(var1_1.b);
        } while (true);
        var3_9 = this.b.a;
        if (var3_9 + 1 > this.a.b) {
            var2_8 = 0;
lbl52: // 3 sources:
            do {
                if (var2_8 != 0) {
                    this.b.b = m.a.b;
                    this.b.a(4);
                }
                return new l();
                break;
            } while (true);
        }
        for (var2_8 = 0; var2_8 < 4 && var2_8 + var3_9 < this.a.b; ++var2_8) {
            if (!this.a.a(var3_9 + var2_8)) continue;
            var2_8 = 0;
            ** GOTO lbl52
        }
        var2_8 = 1;
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private boolean a(int n2) {
        if (n2 + 1 > this.a.b) {
            return false;
        }
        int n3 = 0;
        while (n3 < 5) {
            if (n3 + n2 >= this.a.b) return true;
            if (n3 == 2) {
                if (!this.a.a(n2 + 2)) return false;
            } else if (this.a.a(n2 + n3)) {
                return false;
            }
            ++n3;
        }
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private l b() {
        block23 : while ((var3_3 = this.b.a) + 5 <= this.a.b) {
            var4_4 = this.a(var3_3, 5);
            if (var4_4 >= 5 && var4_4 < 16) {
                var3_3 = 1;
            } else {
                if (var3_3 + 7 > this.a.b) break;
                var4_4 = this.a(var3_3, 7);
                if (var4_4 >= 64 && var4_4 < 116) {
                    var3_3 = 1;
                } else {
                    if (var3_3 + 8 > this.a.b || (var3_3 = this.a(var3_3, 8)) < 232 || var3_3 >= 253) break;
                    var3_3 = 1;
                }
            }
lbl13: // 4 sources:
            do {
                if (var3_3 != 0) {
                    var3_3 = this.b.a;
                    var4_4 = this.a(var3_3, 5);
                    if (var4_4 == 15) {
                        var2_2 = new n(var3_3 + 5, '$');
                    } else if (var4_4 >= 5 && var4_4 < 15) {
                        var2_2 = new n(var3_3 + 5, (char)(var4_4 + 48 - 5));
                    } else {
                        var4_4 = this.a(var3_3, 7);
                        if (var4_4 >= 64 && var4_4 < 90) {
                            var2_2 = new n(var3_3 + 7, (char)(var4_4 + 1));
                        } else if (var4_4 >= 90 && var4_4 < 116) {
                            var2_2 = new n(var3_3 + 7, (char)(var4_4 + 7));
                        } else {
                            switch (this.a(var3_3, 8)) {
                                default: {
                                    throw g.a();
                                }
                                case 232: {
                                    var1_1 = '!';
                                    break;
                                }
                                case 233: {
                                    var1_1 = '\"';
                                    break;
                                }
                                case 234: {
                                    var1_1 = '%';
                                    break;
                                }
                                case 235: {
                                    var1_1 = '&';
                                    break;
                                }
                                case 236: {
                                    var1_1 = '\'';
                                    break;
                                }
                                case 237: {
                                    var1_1 = '(';
                                    break;
                                }
                                case 238: {
                                    var1_1 = ')';
                                    break;
                                }
                                case 239: {
                                    var1_1 = '*';
                                    break;
                                }
                                case 240: {
                                    var1_1 = '+';
                                    break;
                                }
                                case 241: {
                                    var1_1 = ',';
                                    break;
                                }
                                case 242: {
                                    var1_1 = '-';
                                    break;
                                }
                                case 243: {
                                    var1_1 = '.';
                                    break;
                                }
                                case 244: {
                                    var1_1 = '/';
                                    break;
                                }
                                case 245: {
                                    var1_1 = ':';
                                    break;
                                }
                                case 246: {
                                    var1_1 = ';';
                                    break;
                                }
                                case 247: {
                                    var1_1 = '<';
                                    break;
                                }
                                case 248: {
                                    var1_1 = '=';
                                    break;
                                }
                                case 249: {
                                    var1_1 = '>';
                                    break;
                                }
                                case 250: {
                                    var1_1 = '?';
                                    break;
                                }
                                case 251: {
                                    var1_1 = '_';
                                    break;
                                }
                                case 252: {
                                    var1_1 = ' ';
                                }
                            }
                            var2_2 = new n(var3_3 + 8, var1_1);
                        }
                    }
                    this.b.a = var2_2.d;
                    if (var2_2.a()) {
                        return new l(new o(this.b.a, this.c.toString()), true);
                    }
                    this.c.append(var2_2.a);
                    continue block23;
                }
                if (this.b(this.b.a)) {
                    this.b.a(3);
                    this.b.b = m.a.a;
                    return new l();
                }
                if (this.a(this.b.a) == false) return new l();
                if (this.b.a + 5 < this.a.b) {
                    this.b.a(5);
                } else {
                    this.b.a = this.a.b;
                }
                this.b.b = m.a.b;
                return new l();
                break;
            } while (true);
        }
        var3_3 = 0;
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean b(int n2) {
        if (n2 + 3 <= this.a.b) {
            int n3 = n2;
            do {
                if (n3 >= n2 + 3) {
                    return true;
                }
                if (this.a.a(n3)) break;
                ++n3;
            } while (true);
        }
        return false;
    }

    final int a(int n2, int n3) {
        return s.a(this.a, n2, n3);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     */
    final o a(int var1_1, String var2_2) {
        this.c.setLength(0);
        if (var2_2 != null) {
            this.c.append((String)var2_2);
        }
        this.b.a = var1_1;
        do {
            block29 : {
                var4_4 = this.b.a;
                var1_1 = this.b.b == m.a.b ? 1 : 0;
                if (var1_1 != 0) ** GOTO lbl17
                var1_1 = this.b.b == m.a.c ? 1 : 0;
                if (var1_1 != 0) {
                    var2_2 = this.b();
                    var6_6 = var2_2.b;
                } else {
                    var2_2 = this.a();
                    var6_6 = var2_2.b;
                }
                ** GOTO lbl77
lbl17: // 1 sources:
                do {
                    if ((var1_1 = this.b.a) + 5 > this.a.b) ** GOTO lbl-1000
                    var5_5 = this.a(var1_1, 5);
                    if (var5_5 >= 5 && var5_5 < 16) {
                        var1_1 = 1;
                    } else if (var1_1 + 6 <= this.a.b && (var1_1 = this.a(var1_1, 6)) >= 16 && var1_1 < 63) {
                        var1_1 = 1;
                    } else lbl-1000: // 2 sources:
                    {
                        var1_1 = 0;
                    }
                    if (var1_1 == 0) break;
                    var1_1 = this.b.a;
                    var5_5 = this.a(var1_1, 5);
                    if (var5_5 == 15) {
                        var2_2 = new n(var1_1 + 5, '$');
                    } else if (var5_5 >= 5 && var5_5 < 15) {
                        var2_2 = new n(var1_1 + 5, (char)(var5_5 + 48 - 5));
                    } else {
                        var5_5 = this.a(var1_1, 6);
                        if (var5_5 >= 32 && var5_5 < 58) {
                            var2_2 = new n(var1_1 + 6, (char)(var5_5 + 33));
                        } else {
                            switch (var5_5) {
                                default: {
                                    throw new IllegalStateException("Decoding invalid alphanumeric value: " + var5_5);
                                }
                                case 58: {
                                    var3_3 = '*';
                                    break;
                                }
                                case 59: {
                                    var3_3 = ',';
                                    break;
                                }
                                case 60: {
                                    var3_3 = '-';
                                    break;
                                }
                                case 61: {
                                    var3_3 = '.';
                                    break;
                                }
                                case 62: {
                                    var3_3 = '/';
                                }
                            }
                            var2_2 = new n(var1_1 + 6, var3_3);
                        }
                    }
                    this.b.a = var2_2.d;
                    if (var2_2.a()) {
                        var2_2 = new l(new o(this.b.a, this.c.toString()), true);
                        break block29;
                    }
                    this.c.append(var2_2.a);
                } while (true);
                if (this.b(this.b.a)) {
                    this.b.a(3);
                    this.b.b = m.a.a;
                } else if (this.a(this.b.a)) {
                    if (this.b.a + 5 < this.a.b) {
                        this.b.a(5);
                    } else {
                        this.b.a = this.a.b;
                    }
                    this.b.b = m.a.c;
                }
                var2_2 = new l();
            }
            var6_6 = var2_2.b;
lbl77: // 3 sources:
            var1_1 = var4_4 != this.b.a ? 1 : 0;
        } while ((var1_1 != 0 || var6_6) && !var6_6);
        var2_2 = var2_2.a;
        if (var2_2 != null && var2_2.c) {
            return new o(this.b.a, this.c.toString(), var2_2.b);
        }
        return new o(this.b.a, this.c.toString());
    }

    /*
     * Enabled aggressive block sorting
     */
    final String a(StringBuilder stringBuilder, int n2) {
        String string = null;
        do {
            o o2 = this.a(n2, string);
            string = r.a(o2.a);
            if (string != null) {
                stringBuilder.append(string);
            }
            string = o2.c ? String.valueOf(o2.b) : null;
            if (n2 == o2.d) return stringBuilder.toString();
            n2 = o2.d;
        } while (true);
    }
}

