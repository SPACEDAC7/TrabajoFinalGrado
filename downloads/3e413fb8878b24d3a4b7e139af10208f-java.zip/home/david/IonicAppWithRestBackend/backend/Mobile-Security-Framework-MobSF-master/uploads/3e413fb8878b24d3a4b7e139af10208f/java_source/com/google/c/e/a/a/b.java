/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a;

import com.google.c.e.a.a.a;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

final class b {
    final List<a> a;
    final int b;
    private final boolean c;

    b(List<a> list, int n2) {
        this.a = new ArrayList<a>(list);
        this.b = n2;
        this.c = false;
    }

    final boolean a(List<a> list) {
        return this.a.equals(list);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (!(object instanceof b)) {
            return false;
        }
        object = (b)object;
        if (!this.a.equals(object.a)) return false;
        if (this.c != object.c) return false;
        return true;
    }

    public final int hashCode() {
        return this.a.hashCode() ^ Boolean.valueOf(this.c).hashCode();
    }

    public final String toString() {
        return "{ " + this.a + " }";
    }
}

