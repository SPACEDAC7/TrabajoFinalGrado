/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a.a;

import a.a.a.a.d;
import com.google.c.e;
import com.google.c.e.a.a.a;
import com.google.c.e.a.a.b;
import com.google.c.j;
import com.google.c.n;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class c
extends com.google.c.e.a.a {
    private static final int[] g = new int[]{7, 5, 4, 3, 1};
    private static final int[] h = new int[]{4, 20, 52, 104, 204};
    private static final int[] i = new int[]{0, 348, 1388, 2948, 3988};
    private static final int[][] j = new int[][]{{1, 8, 4, 1}, {3, 6, 4, 1}, {3, 4, 6, 1}, {3, 2, 8, 1}, {2, 6, 5, 1}, {2, 2, 9, 1}};
    private static final int[][] k = new int[][]{{1, 3, 9, 27, 81, 32, 96, 77}, {20, 60, 180, 118, 143, 7, 21, 63}, {189, 145, 13, 39, 117, 140, 209, 205}, {193, 157, 49, 147, 19, 57, 171, 91}, {62, 186, 136, 197, 169, 85, 44, 132}, {185, 133, 188, 142, 4, 12, 36, 108}, {113, 128, 173, 97, 80, 29, 87, 50}, {150, 28, 84, 41, 123, 158, 52, 156}, {46, 138, 203, 187, 139, 206, 196, 166}, {76, 17, 51, 153, 37, 111, 122, 155}, {43, 129, 176, 106, 107, 110, 119, 146}, {16, 48, 144, 10, 30, 90, 59, 177}, {109, 116, 137, 200, 178, 112, 125, 164}, {70, 210, 208, 202, 184, 130, 179, 115}, {134, 191, 151, 31, 93, 68, 204, 190}, {148, 22, 66, 198, 172, 94, 71, 2}, {6, 18, 54, 162, 64, 192, 154, 40}, {120, 149, 25, 75, 14, 42, 126, 167}, {79, 26, 78, 23, 69, 207, 199, 175}, {103, 98, 83, 38, 114, 131, 182, 124}, {161, 61, 183, 127, 170, 88, 53, 159}, {55, 165, 73, 8, 24, 72, 5, 15}, {45, 135, 194, 160, 58, 174, 100, 89}};
    private static final int[][] l;
    private final List<a> m = new ArrayList<a>(11);
    private final List<b> n = new ArrayList<b>();
    private final int[] o = new int[2];
    private boolean p = false;

    static {
        int[] arrn = new int[]{0, 1, 1};
        int[] arrn2 = new int[]{0, 2, 1, 3};
        int[] arrn3 = new int[]{0, 4, 1, 3, 2};
        int[] arrn4 = new int[]{0, 4, 1, 3, 3, 5};
        int[] arrn5 = new int[]{0, 4, 1, 3, 4, 5, 5};
        int[] arrn6 = new int[]{0, 0, 1, 1, 2, 2, 3, 3};
        int[] arrn7 = new int[]{0, 0, 1, 1, 2, 2, 3, 4, 4};
        int[] arrn8 = new int[]{0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5};
        l = new int[][]{{0, 0}, arrn, arrn2, arrn3, arrn4, arrn5, arrn6, arrn7, {0, 0, 1, 1, 2, 2, 3, 4, 5, 5}, arrn8};
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private a a(com.google.c.b.a object, List<a> list, int n2) {
        boolean bl2 = list.size() % 2 == 0;
        if (this.p) {
            bl2 = !bl2;
        }
        int n3 = 1;
        int n4 = -1;
        do {
            int n5;
            Object object2;
            block20 : {
                block19 : {
                    int n6;
                    object2 = this.a;
                    object2[0] = 0;
                    object2[1] = 0;
                    object2[2] = 0;
                    object2[3] = 0;
                    int n7 = object.b;
                    n5 = n4 < 0 ? (list.isEmpty() ? 0 : list.get((int)(list.size() - 1)).c.b[1]) : n4;
                    int n8 = list.size() % 2 != 0 ? 1 : 0;
                    int n9 = n8;
                    if (this.p) {
                        n9 = n8 == 0 ? 1 : 0;
                    }
                    n8 = 0;
                    do {
                        n6 = n8;
                        if (n5 >= n7) break;
                        n8 = !object.a(n5) ? 1 : 0;
                        n6 = n8;
                        if (n8 == 0) break;
                        ++n5;
                    } while (true);
                    n8 = n5;
                    int n10 = n6;
                    int n11 = 0;
                    n6 = n8;
                    while (n6 < n7) {
                        if ((object.a(n6) ^ n10) != 0) {
                            object2[n11] = object2[n11] + 1;
                            n8 = n10;
                            n10 = n5;
                        } else {
                            int n12;
                            if (n11 == 3) {
                                if (n9 != 0) {
                                    c.c((int[])object2);
                                }
                                if (c.b((int[])object2)) {
                                    this.o[0] = n5;
                                    this.o[1] = n6;
                                    object2 = this.a((com.google.c.b.a)object, n2, bl2);
                                    if (object2 != null) break block19;
                                    n4 = this.o[0];
                                    n4 = object.a(n4) ? object.c(object.d(n4)) : object.d(object.c(n4));
                                    n5 = n3;
                                    break block20;
                                }
                                if (n9 != 0) {
                                    c.c((int[])object2);
                                }
                                n8 = n5 + (object2[0] + object2[1]);
                                object2[0] = object2[2];
                                object2[1] = object2[3];
                                object2[2] = false;
                                object2[3] = false;
                                n5 = n11 - 1;
                            } else {
                                n8 = n5;
                                n5 = ++n11;
                            }
                            object2[n5] = 1;
                            if (n10 == 0) {
                                n12 = 1;
                                n10 = n8;
                                n11 = n5;
                                n8 = n12;
                            } else {
                                n12 = 0;
                                n10 = n8;
                                n11 = n5;
                                n8 = n12;
                            }
                        }
                        ++n6;
                        n5 = n10;
                        n10 = n8;
                    }
                    throw j.a();
                }
                n5 = 0;
            }
            if (n5 == 0) {
                com.google.c.e.a.b b2 = this.a((com.google.c.b.a)object, (com.google.c.e.a.c)object2, bl2, true);
                if (!list.isEmpty()) {
                    n2 = list.get((int)(list.size() - 1)).b == null ? 1 : 0;
                    if (n2 != 0) {
                        throw j.a();
                    }
                }
                try {
                    object = this.a((com.google.c.b.a)object, (com.google.c.e.a.c)object2, bl2, false);
                    return new a(b2, (com.google.c.e.a.b)object, (com.google.c.e.a.c)object2);
                }
                catch (j var1_2) {
                    object = null;
                    return new a(b2, (com.google.c.e.a.b)object, (com.google.c.e.a.c)object2);
                }
            }
            n3 = n5;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private com.google.c.e.a.b a(com.google.c.b.a arrn, com.google.c.e.a.c c2, boolean bl2, boolean bl3) {
        int n2;
        int n3;
        int[] arrn2;
        int n4;
        int n5;
        int n6;
        int n7;
        block47 : {
            float f2;
            float f3;
            int[] arrn3 = this.b;
            arrn3[0] = 0;
            arrn3[1] = 0;
            arrn3[2] = 0;
            arrn3[3] = 0;
            arrn3[4] = 0;
            arrn3[5] = 0;
            arrn3[6] = 0;
            arrn3[7] = 0;
            if (bl3) {
                c.b((com.google.c.b.a)arrn, c2.b[0], arrn3);
            } else {
                c.a((com.google.c.b.a)arrn, c2.b[1], arrn3);
                n4 = 0;
                for (n5 = arrn3.length - 1; n4 < n5; ++n4, --n5) {
                    n7 = arrn3[n4];
                    arrn3[n4] = arrn3[n5];
                    arrn3[n5] = n7;
                }
            }
            if (Math.abs((f2 = (float)c.a(arrn3) / 17.0f) - (f3 = (float)(c2.b[1] - c2.b[0]) / 15.0f)) / f3 > 0.3f) {
                throw j.a();
            }
            arrn = this.e;
            arrn2 = this.f;
            float[] arrf = this.c;
            float[] arrf2 = this.d;
            for (n4 = 0; n4 < arrn3.length; ++n4) {
                f3 = 1.0f * (float)arrn3[n4] / f2;
                n7 = (int)(0.5f + f3);
                if (n7 <= 0) {
                    if (f3 < 0.3f) {
                        throw j.a();
                    }
                    n5 = 1;
                } else {
                    n5 = n7;
                    if (n7 > 8) {
                        if (f3 > 8.7f) {
                            throw j.a();
                        }
                        n5 = 8;
                    }
                }
                n7 = n4 / 2;
                if ((n4 & 1) == 0) {
                    arrn[n7] = n5;
                    arrf[n7] = f3 - (float)n5;
                    continue;
                }
                arrn2[n7] = n5;
                arrf2[n7] = f3 - (float)n5;
            }
            int n8 = c.a(this.e);
            int n9 = c.a(this.f);
            int n10 = n8 + n9 - 17;
            n3 = (n8 & 1) == 1 ? 1 : 0;
            n2 = (n9 & 1) == 0 ? 1 : 0;
            n4 = 0;
            n7 = 0;
            if (n8 > 13) {
                n5 = 1;
            } else {
                n5 = n7;
                if (n8 < 4) {
                    n4 = 1;
                    n5 = n7;
                }
            }
            n6 = 0;
            int n11 = 0;
            if (n9 > 13) {
                n7 = 1;
            } else {
                n7 = n11;
                if (n9 < 4) {
                    n6 = 1;
                    n7 = n11;
                }
            }
            if (n10 == 1) {
                if (n3 != 0) {
                    if (n2 != 0) {
                        throw j.a();
                    }
                    n5 = 1;
                } else {
                    if (n2 == 0) {
                        throw j.a();
                    }
                    n7 = 1;
                }
            } else if (n10 == -1) {
                if (n3 != 0) {
                    if (n2 != 0) {
                        throw j.a();
                    }
                    n4 = 1;
                } else {
                    if (n2 == 0) {
                        throw j.a();
                    }
                    n6 = 1;
                }
            } else {
                if (n10 != 0) {
                    throw j.a();
                }
                if (n3 != 0) {
                    if (n2 == 0) {
                        throw j.a();
                    }
                    if (n8 < n9) {
                        n4 = 1;
                        n7 = 1;
                    } else {
                        n5 = 1;
                        n6 = 1;
                    }
                } else if (n2 != 0) {
                    throw j.a();
                }
            }
            if (n4 != 0) {
                if (n5 != 0) {
                    throw j.a();
                }
                c.a(this.e, this.c);
                if (n5 == 0) break block47;
            }
            c.b(this.e, this.c);
        }
        if (n6 != 0) {
            if (n7 != 0) {
                throw j.a();
            }
            c.a(this.f, this.c);
        }
        if (n7 != 0) {
            c.b(this.f, this.d);
        }
        n7 = c2.a;
        n5 = bl2 ? 0 : 2;
        n4 = bl3 ? 0 : 1;
        n3 = n4 + (n7 * 4 + n5) - 1;
        n5 = arrn.length;
        n4 = 0;
        n7 = n5 - 1;
        n5 = 0;
        while (n7 >= 0) {
            n6 = n5;
            if (c.a(c2, bl2, bl3)) {
                n6 = n5 + k[n3][n7 * 2] * arrn[n7];
            }
            n5 = arrn[n7];
            --n7;
            n4 = n5 + n4;
            n5 = n6;
        }
        n7 = 0;
        for (n6 = arrn2.length - 1; n6 >= 0; --n6) {
            n2 = n7;
            if (c.a(c2, bl2, bl3)) {
                n2 = n7 + k[n3][n6 * 2 + 1] * arrn2[n6];
            }
            n7 = n2;
        }
        if ((n4 & 1) == 0 && n4 <= 13 && n4 >= 4) {
            n4 = (13 - n4) / 2;
            n2 = g[n4];
            n6 = d.a(arrn, n2, true);
            n2 = d.a(arrn2, 9 - n2, false);
            n3 = h[n4];
            return new com.google.c.e.a.b(i[n4] + (n6 * n3 + n2), n5 + n7);
        }
        throw j.a();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private com.google.c.e.a.c a(com.google.c.b.a arrn, int n2, boolean bl2) {
        int n3;
        int n4;
        int n5;
        if (bl2) {
            for (n4 = this.o[0] - 1; n4 >= 0 && !arrn.a(n4); --n4) {
            }
            n3 = this.o[0] - ++n4;
            n5 = this.o[1];
        } else {
            n4 = this.o[0];
            n5 = arrn.d(this.o[1] + 1);
            n3 = n5 - this.o[1];
        }
        arrn = this.a;
        System.arraycopy(arrn, 0, arrn, 1, arrn.length - 1);
        arrn[0] = n3;
        try {
            n3 = c.a(arrn, j);
        }
        catch (j var1_2) {
            return null;
        }
        return new com.google.c.e.a.c(n3, new int[]{n4, n5}, n4, n5, n2);
    }

    /*
     * Exception decompiling
     */
    private static n a(List<a> var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private List<a> a(int var1_1, com.google.c.b.a var2_2) {
        try {
            do {
                var3_5 = this.a(var2_2, this.m, var1_1);
                this.m.add(var3_5);
            } while (true);
        }
        catch (j var2_3) {
            block17 : {
                block16 : {
                    if (this.m.isEmpty()) {
                        throw var2_3;
                    }
                    if (this.b()) {
                        return this.m;
                    }
                    var8_7 = this.n.isEmpty() == false;
                    var11_8 = false;
                    for (var9_9 = 0; var9_9 < this.n.size(); ++var9_9) {
                        var2_4 = this.n.get(var9_9);
                        if (var2_4.b > var1_1) {
                            var12_10 = var2_4.a(this.m);
                            break block16;
                        }
                        var11_8 = var2_4.a(this.m);
                    }
                    var12_10 = false;
                }
                if (var12_10 || var11_8) ** GOTO lbl-1000
                var2_4 = this.m;
                var3_6 = this.n.iterator();
                block4 : do {
                    if (!var3_6.hasNext()) {
                        var10_15 = false;
                        break block17;
                    }
                    var4_11 = (b)var3_6.next();
                    var5_12 = var2_4.iterator();
                    while (var5_12.hasNext()) {
                        block18 : {
                            var6_13 = var5_12.next();
                            var7_14 = var4_11.a.iterator();
                            while (var7_14.hasNext()) {
                                if (!var6_13.equals(var7_14.next())) continue;
                                var10_15 = true;
                                break block18;
                            }
                            var10_15 = false;
                        }
                        if (var10_15) continue;
                        var10_15 = false;
                        continue block4;
                    }
                    var10_15 = true;
                } while (!var10_15);
                var10_15 = true;
            }
            if (var10_15) ** GOTO lbl-1000
            this.n.add(var9_9, new b(this.m, var1_1));
            var2_4 = this.m;
            var3_6 = this.n.iterator();
            do {
                block20 : {
                    if (var3_6.hasNext()) {
                        var4_11 = (b)var3_6.next();
                        if (var4_11.a.size() == var2_4.size()) continue;
                        var4_11 = var4_11.a.iterator();
                    } else lbl-1000: // 3 sources:
                    {
                        if (var8_7 == false) throw j.a();
                        var2_4 = var3_6 = this.a(false);
                        if (var3_6 != null) return var2_4;
                        var2_4 = var3_6 = this.a(true);
                        if (var3_6 != null) return var2_4;
                        throw j.a();
                    }
                    while (var4_11.hasNext()) {
                        block19 : {
                            var5_12 = (a)var4_11.next();
                            var6_13 = var2_4.iterator();
                            while (var6_13.hasNext()) {
                                if (!var5_12.equals((a)var6_13.next())) continue;
                                var1_1 = 1;
                                break block19;
                            }
                            var1_1 = 0;
                        }
                        if (var1_1 != 0) continue;
                        var1_1 = 0;
                        break block20;
                    }
                    var1_1 = 1;
                }
                if (var1_1 == 0) continue;
                var3_6.remove();
            } while (true);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private List<a> a(List<b> var1_1, int var2_2) {
        while (var2_2 < this.n.size()) {
            block9 : {
                var3_3 = this.n.get(var2_2);
                this.m.clear();
                var8_9 = var1_1.size();
                for (var7_8 = 0; var7_8 < var8_9; ++var7_8) {
                    this.m.addAll(var1_1.get((int)var7_8).a);
                }
                this.m.addAll(var3_3.a);
                var4_5 = this.m;
                var5_6 = c.l;
                var9_10 = var5_6.length;
                var7_8 = 0;
                do {
                    block8 : {
                        if (var7_8 >= var9_10) ** GOTO lbl18
                        var6_7 = var5_6[var7_8];
                        if (var4_5.size() > var6_7.length) ** GOTO lbl32
                        ** GOTO lbl20
lbl18: // 1 sources:
                        var7_8 = 0;
                        ** GOTO lbl28
lbl20: // 2 sources:
                        for (var8_9 = 0; var8_9 < var4_5.size(); ++var8_9) {
                            if (var4_5.get((int)var8_9).c.a == var6_7[var8_9]) continue;
                            var8_9 = 0;
                            break block8;
                        }
                        var8_9 = 1;
                    }
                    if (var8_9 != 0) {
                        var7_8 = 1;
lbl28: // 2 sources:
                        if (var7_8 != 0) {
                            if (!this.b()) break;
                            return this.m;
                        }
                        break block9;
                    }
lbl32: // 3 sources:
                    ++var7_8;
                } while (true);
                var4_5 = new ArrayList<a>();
                var4_5.addAll(var1_1);
                var4_5.add((a)var3_3);
                try {
                    return this.a(var4_5, var2_2 + 1);
                }
                catch (j var3_4) {
                    // empty catch block
                }
            }
            ++var2_2;
        }
        throw j.a();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private List<a> a(boolean bl2) {
        List<a> list;
        List<a> list2;
        list2 = null;
        list = null;
        if (this.n.size() > 25) {
            this.n.clear();
            return list;
        }
        this.m.clear();
        if (bl2) {
            Collections.reverse(this.n);
        }
        try {
            list2 = list = this.a(new ArrayList<b>(), 0);
        }
        catch (j var3_4) {}
        list = list2;
        if (!bl2) {
            return list;
        }
        Collections.reverse(this.n);
        return list2;
    }

    private static boolean a(com.google.c.e.a.c c2, boolean bl2, boolean bl3) {
        if (c2.a != 0 || !bl2 || !bl3) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean b() {
        boolean bl2 = true;
        Object object = this.m.get(0);
        com.google.c.e.a.b b2 = object.a;
        object = object.b;
        if (object == null) {
            return false;
        }
        int n2 = object.b;
        int n3 = 2;
        for (int i2 = 1; i2 < this.m.size(); ++i2) {
            object = this.m.get(i2);
            int n4 = n2 + object.a.b;
            int n5 = n3 + 1;
            object = object.b;
            n3 = n5;
            n2 = n4;
            if (object == null) continue;
            n2 = n4 + object.b;
            n3 = n5 + 1;
        }
        if (n2 % 211 + (n3 - 4) * 211 == b2.a) return bl2;
        return false;
    }

    private static void c(int[] arrn) {
        int n2 = arrn.length;
        for (int i2 = 0; i2 < n2 / 2; ++i2) {
            int n3 = arrn[i2];
            arrn[i2] = arrn[n2 - i2 - 1];
            arrn[n2 - i2 - 1] = n3;
        }
    }

    @Override
    public final n a(int n2, com.google.c.b.a a2, Map<e, ?> object) {
        this.m.clear();
        this.p = false;
        try {
            object = c.a(this.a(n2, a2));
            return object;
        }
        catch (j var3_4) {
            this.m.clear();
            this.p = true;
            return c.a(this.a(n2, a2));
        }
    }

    @Override
    public final void a() {
        this.m.clear();
        this.n.clear();
    }
}

