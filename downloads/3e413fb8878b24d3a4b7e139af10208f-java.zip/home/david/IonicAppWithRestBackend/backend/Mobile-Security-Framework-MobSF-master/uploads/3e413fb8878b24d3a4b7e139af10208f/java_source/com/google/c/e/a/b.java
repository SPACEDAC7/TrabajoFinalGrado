/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a;

public class b {
    public final int a;
    public final int b;

    public b(int n2, int n3) {
        this.a = n2;
        this.b = n3;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (!(object instanceof b)) {
            return false;
        }
        object = (b)object;
        if (this.a != object.a) return false;
        if (this.b != object.b) return false;
        return true;
    }

    public final int hashCode() {
        return this.a ^ this.b;
    }

    public final String toString() {
        return "" + this.a + "(" + this.b + ')';
    }
}

