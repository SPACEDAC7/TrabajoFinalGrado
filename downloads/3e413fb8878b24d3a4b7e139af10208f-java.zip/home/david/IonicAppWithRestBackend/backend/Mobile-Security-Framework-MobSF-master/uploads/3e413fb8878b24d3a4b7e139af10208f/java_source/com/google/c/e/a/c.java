/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a;

import com.google.c.p;

public final class c {
    public final int a;
    public final int[] b;
    public final p[] c;

    public c(int n2, int[] arrn, int n3, int n4, int n5) {
        this.a = n2;
        this.b = arrn;
        this.c = new p[]{new p(n3, n5), new p(n4, n5)};
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (!(object instanceof c)) {
            return false;
        }
        object = (c)object;
        if (this.a != object.a) return false;
        return true;
    }

    public final int hashCode() {
        return this.a;
    }
}

