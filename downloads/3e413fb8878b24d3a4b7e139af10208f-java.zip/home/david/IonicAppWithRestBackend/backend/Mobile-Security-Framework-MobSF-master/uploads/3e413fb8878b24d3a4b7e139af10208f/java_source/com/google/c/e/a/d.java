/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a;

import com.google.c.e.a.b;
import com.google.c.e.a.c;

final class d
extends b {
    final c c;
    int d;

    d(int n2, int n3, c c2) {
        super(n2, n3);
        this.c = c2;
    }
}

