/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e.a;

import android.support.design.widget.AppBarLayout;
import com.google.c.e.a.a;
import com.google.c.e.a.b;
import com.google.c.e.a.c;
import com.google.c.e.a.d;
import com.google.c.j;
import com.google.c.n;
import com.google.c.p;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class e
extends a {
    private static final int[] g = new int[]{1, 10, 34, 70, 126};
    private static final int[] h = new int[]{4, 20, 48, 81};
    private static final int[] i = new int[]{0, 161, 961, 2015, 2715};
    private static final int[] j = new int[]{0, 336, 1036, 1516};
    private static final int[] k = new int[]{8, 6, 4, 3, 1};
    private static final int[] l = new int[]{2, 4, 6, 8};
    private static final int[][] m;
    private final List<d> n = new ArrayList<d>();
    private final List<d> o = new ArrayList<d>();

    static {
        int[] arrn = new int[]{3, 8, 2, 1};
        int[] arrn2 = new int[]{3, 3, 7, 1};
        int[] arrn3 = new int[]{2, 5, 6, 1};
        int[] arrn4 = new int[]{2, 3, 8, 1};
        int[] arrn5 = new int[]{1, 5, 7, 1};
        int[] arrn6 = new int[]{1, 3, 9, 1};
        m = new int[][]{arrn, {3, 5, 5, 1}, arrn2, {3, 1, 9, 1}, {2, 7, 4, 1}, arrn3, arrn4, arrn5, arrn6};
    }

    /*
     * Enabled aggressive block sorting
     */
    private b a(com.google.c.b.a arrn, c arrn2, boolean bl2) {
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        block52 : {
            int[] arrn3 = this.b;
            arrn3[0] = 0;
            arrn3[1] = 0;
            arrn3[2] = 0;
            arrn3[3] = 0;
            arrn3[4] = 0;
            arrn3[5] = 0;
            arrn3[6] = 0;
            arrn3[7] = 0;
            if (bl2) {
                e.b((com.google.c.b.a)arrn, arrn2.b[0], arrn3);
            } else {
                e.a((com.google.c.b.a)arrn, arrn2.b[1] + 1, arrn3);
                n2 = 0;
                for (n5 = arrn3.length - 1; n2 < n5; ++n2, --n5) {
                    n3 = arrn3[n2];
                    arrn3[n2] = arrn3[n5];
                    arrn3[n5] = n3;
                }
            }
            n2 = bl2 ? 16 : 15;
            float f2 = (float)e.a(arrn3) / (float)n2;
            arrn = this.e;
            arrn2 = this.f;
            float[] arrf = this.c;
            float[] arrf2 = this.d;
            for (n3 = 0; n3 < arrn3.length; ++n3) {
                float f3 = (float)arrn3[n3] / f2;
                n4 = (int)(0.5f + f3);
                if (n4 <= 0) {
                    n5 = 1;
                } else {
                    n5 = n4;
                    if (n4 > 8) {
                        n5 = 8;
                    }
                }
                n4 = n3 / 2;
                if ((n3 & 1) == 0) {
                    arrn[n4] = n5;
                    arrf[n4] = f3 - (float)n5;
                    continue;
                }
                arrn2[n4] = n5;
                arrf2[n4] = f3 - (float)n5;
            }
            int n7 = e.a(this.e);
            int n8 = e.a(this.f);
            int n9 = n7 + n8 - n2;
            n5 = bl2 ? 1 : 0;
            boolean bl3 = (n7 & 1) == n5;
            boolean bl4 = (n8 & 1) == 1;
            n4 = 0;
            int n10 = 0;
            n3 = 0;
            n5 = 0;
            n2 = 0;
            int n11 = 0;
            if (bl2) {
                if (n7 > 12) {
                    n6 = 1;
                } else {
                    n6 = n5;
                    if (n7 < 4) {
                        n10 = 1;
                        n6 = n5;
                    }
                }
                if (n8 > 12) {
                    n5 = 1;
                    n3 = n10;
                    n4 = n6;
                } else {
                    n5 = n11;
                    n4 = n6;
                    n3 = n10;
                    if (n8 < 4) {
                        n2 = 1;
                        n5 = n11;
                        n4 = n6;
                        n3 = n10;
                    }
                }
            } else {
                if (n7 > 11) {
                    n6 = 1;
                    n10 = n4;
                } else {
                    n6 = n3;
                    n10 = n4;
                    if (n7 < 5) {
                        n10 = 1;
                        n6 = n3;
                    }
                }
                if (n8 > 10) {
                    n5 = 1;
                    n4 = n6;
                    n3 = n10;
                } else {
                    n5 = n11;
                    n4 = n6;
                    n3 = n10;
                    if (n8 < 4) {
                        n2 = 1;
                        n5 = n11;
                        n4 = n6;
                        n3 = n10;
                    }
                }
            }
            if (n9 == 1) {
                if (bl3) {
                    if (bl4) {
                        throw j.a();
                    }
                    n4 = 1;
                } else {
                    if (!bl4) {
                        throw j.a();
                    }
                    n5 = 1;
                }
            } else if (n9 == -1) {
                if (bl3) {
                    if (bl4) {
                        throw j.a();
                    }
                    n3 = 1;
                } else {
                    if (!bl4) {
                        throw j.a();
                    }
                    n2 = 1;
                }
            } else {
                if (n9 != 0) {
                    throw j.a();
                }
                if (bl3) {
                    if (!bl4) {
                        throw j.a();
                    }
                    if (n7 < n8) {
                        n3 = 1;
                        n5 = 1;
                    } else {
                        n4 = 1;
                        n2 = 1;
                    }
                } else if (bl4) {
                    throw j.a();
                }
            }
            if (n3 != 0) {
                if (n4 != 0) {
                    throw j.a();
                }
                e.a(this.e, this.c);
                if (n4 == 0) break block52;
            }
            e.b(this.e, this.c);
        }
        if (n2 != 0) {
            if (n5 != 0) {
                throw j.a();
            }
            e.a(this.f, this.c);
        }
        if (n5 != 0) {
            e.b(this.f, this.d);
        }
        n2 = 0;
        n5 = 0;
        for (n3 = arrn.length - 1; n3 >= 0; --n3) {
            n6 = arrn[n3];
            n4 = arrn[n3];
            n2 = n2 * 9 + n6;
            n5 = n4 + n5;
        }
        n6 = 0;
        n4 = 0;
        for (n3 = arrn2.length - 1; n3 >= 0; n4 += arrn2[n3], --n3) {
            n6 = n6 * 9 + arrn2[n3];
        }
        n2 = n6 * 3 + n2;
        if (bl2) {
            if ((n5 & 1) == 0 && n5 <= 12 && n5 >= 4) {
                n5 = (12 - n5) / 2;
                n4 = k[n5];
                n3 = a.a.a.a.d.a(arrn, n4, false);
                n4 = a.a.a.a.d.a(arrn2, 9 - n4, true);
                return new b(n3 * g[n5] + n4 + i[n5], n2);
            }
            throw j.a();
        }
        if ((n4 & 1) == 0 && n4 <= 10 && n4 >= 4) {
            n5 = (10 - n4) / 2;
            n3 = l[n5];
            return new b(a.a.a.a.d.a(arrn, n3, true) + a.a.a.a.d.a(arrn2, 9 - n3, false) * h[n5] + j[n5], n2);
        }
        throw j.a();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    private d a(com.google.c.b.a var1_1, boolean var2_3, int var3_4, Map<com.google.c.e, ?> var4_5) {
        block32 : {
            block30 : {
                block25 : {
                    block26 : {
                        block27 : {
                            block31 : {
                                block28 : {
                                    block29 : {
                                        var9_6 = 0;
                                        var7_7 = this.a;
                                        var7_7[0] = 0;
                                        var7_7[1] = 0;
                                        var7_7[2] = 0;
                                        var7_7[3] = 0;
                                        var13_8 = var1_1.b;
                                        var14_9 = false;
lbl11: // 2 sources:
                                        var15_10 = var14_9;
                                        if (var9_6 >= var13_8) break block25;
                                        if (var1_1.a(var9_6)) break block26;
                                        var14_9 = true;
                                        break block27;
lbl16: // 2 sources:
                                        if (var11_12 >= var13_8) break block28;
                                        if (!(var1_1.a(var11_12) ^ var14_9)) break block29;
                                        var7_7[var10_11] = var7_7[var10_11] + 1;
                                        ** GOTO lbl81
                                    }
                                    if (var10_11 != 3) ** GOTO lbl103
                                    if (!e.b((int[])var7_7)) break block30;
                                    var8_14 = new int[]{var9_6, var11_12};
                                    var14_9 = var1_1.a(var8_14[0]);
                                    for (var9_6 = var8_14[0] - 1; var9_6 >= 0; --var9_6) {
                                        if (var1_1.a(var9_6) ^ var14_9) {
                                            continue;
                                        }
                                        break block31;
                                    }
                                    ** GOTO lbl36
                                }
                                throw j.a();
                            }
                            var11_12 = var9_6 + 1;
                            var9_6 = var8_14[0];
                            var7_7 = this.a;
                            System.arraycopy(var7_7, 0, var7_7, 1, var7_7.length - 1);
                            var7_7[0] = var9_6 - var11_12;
                            try {
                                var12_13 = e.a((int[])var7_7, e.m);
                            }
                            catch (j var1_2) {
                                return null;
                            }
                            var10_11 = var8_14[1];
                            if (var2_3) {
                                var9_6 = var1_1.b - 1 - var11_12;
                                var10_11 = var1_1.b - 1 - var10_11;
lbl50: // 2 sources:
                                do {
                                    var7_7 = new c(var12_13, new int[]{var11_12, var8_14[1]}, var9_6, var10_11, var3_4);
                                    if (var4_5 == null) {
                                        var4_5 = null;
lbl54: // 2 sources:
                                        do {
                                            if (var4_5 != null) {
                                                var5_16 = var6_15 = (float)(var8_14[0] + var8_14[1]) / 2.0f;
                                                if (var2_3) {
                                                    var5_16 = (float)(var1_1.b - 1) - var6_15;
                                                }
                                                new p(var5_16, var3_4);
                                            }
                                            var4_5 = this.a((com.google.c.b.a)var1_1, (c)var7_7, true);
                                            var1_1 = this.a((com.google.c.b.a)var1_1, (c)var7_7, false);
                                            return new d(var4_5.a * 1597 + var1_1.a, var4_5.b + var1_1.b * 4, (c)var7_7);
                                            break;
                                        } while (true);
                                    }
                                    var4_5 = (AppBarLayout.b)var4_5.get((Object)com.google.c.e.j);
                                    ** continue;
                                    break;
                                } while (true);
                            }
                            var9_6 = var11_12;
                            ** while (true)
                        }
lbl68: // 2 sources:
                        do {
                            var15_10 = var14_9;
                            if (var2_3 == var14_9) break block25;
                            ++var9_6;
                            ** GOTO lbl11
                            break;
                        } while (true);
                    }
                    var14_9 = false;
                    ** while (true)
                }
                var11_12 = var9_6;
                var14_9 = var15_10;
                var10_11 = 0;
                ** GOTO lbl16
lbl81: // 2 sources:
                do {
                    ++var11_12;
                    ** GOTO lbl16
                    break;
                } while (true);
            }
            var9_6 = var7_7[0] + var7_7[1] + var9_6;
            var7_7[0] = var7_7[2];
            var7_7[1] = var7_7[3];
            var7_7[2] = 0;
            var7_7[3] = 0;
            var12_13 = var10_11 - 1;
            var10_11 = var9_6;
            var9_6 = var12_13;
lbl93: // 2 sources:
            do {
                var7_7[var9_6] = 1;
                if (!var14_9) {
                    var14_9 = true;
lbl97: // 2 sources:
                    do {
                        var12_13 = var10_11;
                        var10_11 = var9_6;
                        var9_6 = var12_13;
                        ** continue;
                        break;
                    } while (true);
                }
                break block32;
                break;
            } while (true);
lbl103: // 1 sources:
            var12_13 = var9_6;
            var9_6 = var10_11 + 1;
            var10_11 = var12_13;
            ** while (true)
        }
        var14_9 = false;
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void a(Collection<d> collection, d d2) {
        if (d2 == null) {
            return;
        }
        Iterator<d> iterator = collection.iterator();
        do {
            if (!iterator.hasNext()) {
                boolean bl2 = false;
                if (bl2) return;
                collection.add(d2);
                return;
            }
            d d3 = iterator.next();
        } while (d3.a != d2.a);
        ++d3.d;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final n a(int n2, com.google.c.b.a object, Map<com.google.c.e, ?> object2) {
        Object object3 = this.a((com.google.c.b.a)object, false, n2, object2);
        e.a(this.n, (d)object3);
        object.c();
        object2 = this.a((com.google.c.b.a)object, true, n2, object2);
        e.a(this.o, (d)object2);
        object.c();
        int n3 = this.n.size();
        int n4 = 0;
        do {
            if (n4 >= n3) {
                throw j.a();
            }
            object3 = this.n.get(n4);
            if (object3.d > 1) {
                int n5 = this.o.size();
                for (int i2 = 0; i2 < n5; ++i2) {
                    int n6;
                    object2 = this.o.get(i2);
                    if (object2.d <= 1) continue;
                    int n7 = object3.b;
                    int n8 = object2.b;
                    n2 = n6 = object3.c.a * 9 + object2.c.a;
                    if (n6 > 72) {
                        n2 = n6 - 1;
                    }
                    n6 = n2;
                    if (n2 > 8) {
                        n6 = n2 - 1;
                    }
                    n2 = (n7 + n8 * 16) % 79 == n6 ? 1 : 0;
                    if (n2 == 0) continue;
                    Object object4 = String.valueOf(4537077 * (long)object3.a + (long)object2.a);
                    object = new StringBuilder(14);
                    for (n2 = 13 - object4.length(); n2 > 0; --n2) {
                        object.append('0');
                    }
                    object.append((String)object4);
                    n2 = 0;
                    for (n4 = 0; n4 < 13; ++n4) {
                        i2 = n6 = object.charAt(n4) - 48;
                        if ((n4 & 1) == 0) {
                            i2 = n6 * 3;
                        }
                        n2 = i2 + n2;
                    }
                    n2 = n4 = 10 - n2 % 10;
                    if (n4 == 10) {
                        n2 = 0;
                    }
                    object.append(n2);
                    object4 = object3.c.c;
                    object3 = object2.c.c;
                    object = String.valueOf(object.toString());
                    object2 = object4[0];
                    object4 = object4[1];
                    p p2 = object3[0];
                    object3 = object3[1];
                    com.google.c.a a2 = com.google.c.a.m;
                    return new n((String)object, null, new p[]{object2, object4, p2, object3}, a2);
                }
            }
            ++n4;
        } while (true);
    }

    @Override
    public final void a() {
        this.n.clear();
        this.o.clear();
    }
}

