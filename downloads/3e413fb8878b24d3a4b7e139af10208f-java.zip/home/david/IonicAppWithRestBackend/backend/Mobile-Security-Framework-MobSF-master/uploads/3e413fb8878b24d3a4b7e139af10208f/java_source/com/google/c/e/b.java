/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.b.a;
import com.google.c.e;
import com.google.c.e.k;
import com.google.c.j;
import com.google.c.n;
import java.util.Map;

public final class b
extends k {
    static final int[][] a;

    static {
        int[] arrn = new int[]{1, 2, 1, 2, 2, 3};
        int[] arrn2 = new int[]{2, 3, 1, 2, 1, 2};
        int[] arrn3 = new int[]{1, 2, 3, 1, 2, 2};
        int[] arrn4 = new int[]{3, 1, 2, 2, 1, 2};
        int[] arrn5 = new int[]{3, 2, 2, 1, 1, 2};
        int[] arrn6 = new int[]{3, 2, 2, 2, 1, 1};
        int[] arrn7 = new int[]{1, 1, 1, 3, 2, 3};
        int[] arrn8 = new int[]{1, 3, 1, 3, 2, 1};
        int[] arrn9 = new int[]{2, 1, 1, 3, 1, 3};
        int[] arrn10 = new int[]{2, 3, 1, 1, 1, 3};
        int[] arrn11 = new int[]{2, 1, 3, 3, 1, 1};
        int[] arrn12 = new int[]{3, 1, 1, 3, 2, 1};
        int[] arrn13 = new int[]{1, 1, 1, 2, 2, 4};
        int[] arrn14 = new int[]{1, 2, 2, 1, 1, 4};
        int[] arrn15 = new int[]{2, 4, 1, 2, 1, 1};
        int[] arrn16 = new int[]{4, 1, 3, 1, 1, 1};
        int[] arrn17 = new int[]{2, 1, 4, 1, 2, 1};
        int[] arrn18 = new int[]{4, 1, 1, 1, 1, 3};
        int[] arrn19 = new int[]{3, 1, 1, 1, 4, 1};
        int[] arrn20 = new int[]{2, 1, 1, 2, 1, 4};
        a = new int[][]{{2, 1, 2, 2, 2, 2}, {2, 2, 2, 1, 2, 2}, {2, 2, 2, 2, 2, 1}, arrn, {1, 2, 1, 3, 2, 2}, {1, 3, 1, 2, 2, 2}, {1, 2, 2, 2, 1, 3}, {1, 2, 2, 3, 1, 2}, {1, 3, 2, 2, 1, 2}, {2, 2, 1, 2, 1, 3}, {2, 2, 1, 3, 1, 2}, arrn2, {1, 1, 2, 2, 3, 2}, {1, 2, 2, 1, 3, 2}, {1, 2, 2, 2, 3, 1}, {1, 1, 3, 2, 2, 2}, arrn3, {1, 2, 3, 2, 2, 1}, {2, 2, 3, 2, 1, 1}, {2, 2, 1, 1, 3, 2}, {2, 2, 1, 2, 3, 1}, {2, 1, 3, 2, 1, 2}, {2, 2, 3, 1, 1, 2}, {3, 1, 2, 1, 3, 1}, {3, 1, 1, 2, 2, 2}, {3, 2, 1, 1, 2, 2}, {3, 2, 1, 2, 2, 1}, arrn4, arrn5, arrn6, {2, 1, 2, 1, 2, 3}, {2, 1, 2, 3, 2, 1}, {2, 3, 2, 1, 2, 1}, arrn7, {1, 3, 1, 1, 2, 3}, arrn8, {1, 1, 2, 3, 1, 3}, {1, 3, 2, 1, 1, 3}, {1, 3, 2, 3, 1, 1}, arrn9, arrn10, {2, 3, 1, 3, 1, 1}, {1, 1, 2, 1, 3, 3}, {1, 1, 2, 3, 3, 1}, {1, 3, 2, 1, 3, 1}, {1, 1, 3, 1, 2, 3}, {1, 1, 3, 3, 2, 1}, {1, 3, 3, 1, 2, 1}, {3, 1, 3, 1, 2, 1}, {2, 1, 1, 3, 3, 1}, {2, 3, 1, 1, 3, 1}, {2, 1, 3, 1, 1, 3}, arrn11, {2, 1, 3, 1, 3, 1}, {3, 1, 1, 1, 2, 3}, arrn12, {3, 3, 1, 1, 2, 1}, {3, 1, 2, 1, 1, 3}, {3, 1, 2, 3, 1, 1}, {3, 3, 2, 1, 1, 1}, {3, 1, 4, 1, 1, 1}, {2, 2, 1, 4, 1, 1}, {4, 3, 1, 1, 1, 1}, arrn13, {1, 1, 1, 4, 2, 2}, {1, 2, 1, 1, 2, 4}, {1, 2, 1, 4, 2, 1}, {1, 4, 1, 1, 2, 2}, {1, 4, 1, 2, 2, 1}, {1, 1, 2, 2, 1, 4}, {1, 1, 2, 4, 1, 2}, arrn14, {1, 2, 2, 4, 1, 1}, {1, 4, 2, 1, 1, 2}, {1, 4, 2, 2, 1, 1}, arrn15, {2, 2, 1, 1, 1, 4}, arrn16, {2, 4, 1, 1, 1, 2}, {1, 3, 4, 1, 1, 1}, {1, 1, 1, 2, 4, 2}, {1, 2, 1, 1, 4, 2}, {1, 2, 1, 2, 4, 1}, {1, 1, 4, 2, 1, 2}, {1, 2, 4, 1, 1, 2}, {1, 2, 4, 2, 1, 1}, {4, 1, 1, 2, 1, 2}, {4, 2, 1, 1, 1, 2}, {4, 2, 1, 2, 1, 1}, {2, 1, 2, 1, 4, 1}, arrn17, {4, 1, 2, 1, 2, 1}, {1, 1, 1, 1, 4, 3}, {1, 1, 1, 3, 4, 1}, {1, 3, 1, 1, 4, 1}, {1, 1, 4, 1, 1, 3}, {1, 1, 4, 3, 1, 1}, arrn18, {4, 1, 1, 3, 1, 1}, {1, 1, 3, 1, 4, 1}, {1, 1, 4, 1, 3, 1}, arrn19, {4, 1, 1, 1, 3, 1}, {2, 1, 1, 4, 1, 2}, arrn20, {2, 1, 1, 2, 3, 2}, {2, 3, 3, 1, 1, 1, 2}};
    }

    private static int a(a a2, int[] arrn, int n2) {
        b.a(a2, n2, arrn);
        float f2 = 0.25f;
        int n3 = -1;
        for (n2 = 0; n2 < a.length; ++n2) {
            float f3 = b.a(arrn, a[n2], 0.7f);
            float f4 = f2;
            if (f3 < f2) {
                n3 = n2;
                f4 = f3;
            }
            f2 = f4;
        }
        if (n3 >= 0) {
            return n3;
        }
        throw j.a();
    }

    /*
     * Exception decompiling
     */
    @Override
    public final n a(int var1_1, a var2_2, Map<e, ?> var3_3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.rebuildSwitches(SwitchReplacer.java:334)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:539)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }
}

