/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.a;
import com.google.c.d;
import com.google.c.e;
import com.google.c.e.k;
import com.google.c.g;
import com.google.c.j;
import com.google.c.n;
import com.google.c.p;
import java.util.Arrays;
import java.util.Map;

public final class c
extends k {
    static final int[] a;
    private static final char[] b;
    private static final int c;
    private final boolean d;
    private final boolean e;
    private final StringBuilder f;
    private final int[] g;

    static {
        int[] arrn;
        b = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%".toCharArray();
        int[] arrn2 = arrn = new int[44];
        arrn2[0] = 52;
        arrn2[1] = 289;
        arrn2[2] = 97;
        arrn2[3] = 352;
        arrn2[4] = 49;
        arrn2[5] = 304;
        arrn2[6] = 112;
        arrn2[7] = 37;
        arrn2[8] = 292;
        arrn2[9] = 100;
        arrn2[10] = 265;
        arrn2[11] = 73;
        arrn2[12] = 328;
        arrn2[13] = 25;
        arrn2[14] = 280;
        arrn2[15] = 88;
        arrn2[16] = 13;
        arrn2[17] = 268;
        arrn2[18] = 76;
        arrn2[19] = 28;
        arrn2[20] = 259;
        arrn2[21] = 67;
        arrn2[22] = 322;
        arrn2[23] = 19;
        arrn2[24] = 274;
        arrn2[25] = 82;
        arrn2[26] = 7;
        arrn2[27] = 262;
        arrn2[28] = 70;
        arrn2[29] = 22;
        arrn2[30] = 385;
        arrn2[31] = 193;
        arrn2[32] = 448;
        arrn2[33] = 145;
        arrn2[34] = 400;
        arrn2[35] = 208;
        arrn2[36] = 133;
        arrn2[37] = 388;
        arrn2[38] = 196;
        arrn2[39] = 148;
        arrn2[40] = 168;
        arrn2[41] = 162;
        arrn2[42] = 138;
        arrn2[43] = 42;
        a = arrn;
        c = arrn[39];
    }

    public c() {
        this(false);
    }

    public c(boolean bl2) {
        this(bl2, 0);
    }

    private c(boolean bl2, byte by2) {
        this.d = bl2;
        this.e = false;
        this.f = new StringBuilder(20);
        this.g = new int[9];
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static int a(int[] arrn) {
        int n2 = arrn.length;
        int n3 = 0;
        do {
            int n4;
            int n5 = Integer.MAX_VALUE;
            for (int n62 : arrn) {
                n4 = n5;
                if (n62 < n5) {
                    n4 = n5;
                    if (n62 > n3) {
                        n4 = n62;
                    }
                }
                n5 = n4;
            }
            n3 = 0;
            n4 = 0;
            int n7 = 0;
            for (int n62 = 0; n62 < n2; ++n62) {
                int n8 = arrn[n62];
                int n9 = n3;
                int n10 = n4;
                int n11 = n7;
                if (n8 > n5) {
                    n9 = n3 | 1 << n2 - 1 - n62;
                    n11 = n7 + 1;
                    n10 = n4 + n8;
                }
                n3 = n9;
                n4 = n10;
                n7 = n11;
            }
            if (n7 <= 3) {
                return -1;
            }
            n3 = n5;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final n a(int var1_1, com.google.c.b.a var2_2, Map<e, ?> var3_3) {
        block32 : {
            block30 : {
                var10_4 = this.g;
                Arrays.fill((int[])var10_4, 0);
                var9_5 = this.f;
                var9_5.setLength(0);
                var17_6 = var2_2.b;
                var11_7 = var2_2.c(0);
                var15_8 = 0;
                var14_9 = 0;
                var18_10 = var10_4.length;
                var13_11 = var11_7;
                while (var13_11 < var17_6) {
                    if (var2_2.a(var13_11) ^ var14_9) {
                        var10_4[var15_8] = var10_4[var15_8] + 1;
                        var12_12 = var14_9;
                        var14_9 = var11_7;
                    } else {
                        if (var15_8 == var18_10 - 1) {
                            if (c.a((int[])var10_4) == c.c && var2_2.a(Math.max(0, var11_7 - (var13_11 - var11_7) / 2), var11_7)) break block30;
                            var12_12 = var11_7 + (var10_4[0] + var10_4[1]);
                            System.arraycopy(var10_4, 2, var10_4, 0, var18_10 - 2);
                            var10_4[var18_10 - 2] = 0;
                            var10_4[var18_10 - 1] = 0;
                            var11_7 = var15_8 - 1;
                        } else {
                            var12_12 = var11_7;
                            var11_7 = ++var15_8;
                        }
                        var10_4[var11_7] = 1;
                        if (var14_9 == 0) {
                            var16_13 = 1;
                            var14_9 = var12_12;
                            var15_8 = var11_7;
                            var12_12 = var16_13;
                        } else {
                            var16_13 = 0;
                            var14_9 = var12_12;
                            var15_8 = var11_7;
                            var12_12 = var16_13;
                        }
                    }
                    ++var13_11;
                    var11_7 = var14_9;
                    var14_9 = var12_12;
                }
                throw j.a();
            }
            var3_3 = new int[]{var11_7, var13_11};
            var11_7 = var2_2.c(var3_3[1]);
            var15_8 = var2_2.b;
            do {
                block31 : {
                    c.a((com.google.c.b.a)var2_2, var11_7, (int[])var10_4);
                    var13_11 = c.a((int[])var10_4);
                    if (var13_11 < 0) {
                        throw j.a();
                    }
                    var12_12 = 0;
                    while (var12_12 < c.a.length) {
                        if (c.a[var12_12] == var13_11) {
                            var7_14 = c.b[var12_12];
                            var9_5.append((char)var7_14);
                            var14_9 = var10_4.length;
                            var13_11 = var11_7;
                            for (var12_12 = 0; var12_12 < var14_9; var13_11 += var10_4[var12_12], ++var12_12) {
                            }
                            break block31;
                        }
                        ++var12_12;
                    }
                    throw j.a();
                }
                var14_9 = var2_2.c(var13_11);
                if (var7_14 == 42) {
                    var9_5.setLength(var9_5.length() - 1);
                    var13_11 = 0;
                    var16_13 = var10_4.length;
                    for (var12_12 = 0; var12_12 < var16_13; var13_11 += var10_4[var12_12], ++var12_12) {
                    }
                    if (var14_9 != var15_8 && var14_9 - var11_7 - var13_11 << 1 < var13_11) {
                        throw j.a();
                    }
                    if (this.d) {
                        var15_8 = var9_5.length() - 1;
                        var14_9 = 0;
                        for (var12_12 = 0; var12_12 < var15_8; var14_9 += "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%".indexOf((int)this.f.charAt((int)var12_12)), ++var12_12) {
                        }
                        if (var9_5.charAt(var15_8) != c.b[var14_9 % 43]) {
                            throw d.a();
                        }
                        var9_5.setLength(var15_8);
                    }
                    if (var9_5.length() == 0) {
                        throw j.a();
                    }
                    if (this.e) {
                        var14_9 = var9_5.length();
                        var2_2 = new StringBuilder(var14_9);
                        break;
                    }
                    var2_2 = var9_5.toString();
                    break block32;
                }
                var11_7 = var14_9;
            } while (true);
            for (var12_12 = 0; var12_12 < var14_9; ++var12_12) {
                var8_15 = var9_5.charAt(var12_12);
                if (var8_15 != '+' && var8_15 != '$' && var8_15 != '%' && var8_15 != '/') ** GOTO lbl127
                var15_8 = var9_5.charAt(var12_12 + 1);
                var7_14 = 0;
                switch (var8_15) {
                    case '+': {
                        if (var15_8 < 65) throw g.a();
                        if (var15_8 > 90) throw g.a();
                        var7_14 = (char)(var15_8 + 32);
                        ** break;
                    }
                    case '$': {
                        if (var15_8 < 65) throw g.a();
                        if (var15_8 > 90) throw g.a();
                        var7_14 = (char)(var15_8 - 64);
                        ** break;
                    }
                    case '%': {
                        if (var15_8 >= 65 && var15_8 <= 69) {
                            var7_14 = (char)(var15_8 - 38);
                            ** break;
                        }
                        if (var15_8 < 70) throw g.a();
                        if (var15_8 > 87) throw g.a();
                        var7_14 = (char)(var15_8 - 11);
                    }
lbl116: // 5 sources:
                    default: {
                        ** GOTO lbl124
                    }
                    case '/': 
                }
                if (var15_8 >= 65 && var15_8 <= 79) {
                    var7_14 = (char)(var15_8 - 32);
                } else {
                    if (var15_8 != 90) throw g.a();
                    var7_14 = 58;
                }
lbl124: // 3 sources:
                var2_2.append((char)var7_14);
                ++var12_12;
                continue;
lbl127: // 1 sources:
                var2_2.append(var8_15);
            }
            var2_2 = var2_2.toString();
        }
        var4_16 = (float)(var3_3[1] + var3_3[0]) / 2.0f;
        var5_17 = var11_7;
        var6_18 = (float)var13_11 / 2.0f;
        var3_3 = new p(var4_16, var1_1);
        var9_5 = new p(var5_17 + var6_18, var1_1);
        var10_4 = a.c;
        return new n((String)var2_2, null, new p[]{var3_3, var9_5}, (a)var10_4);
    }
}

