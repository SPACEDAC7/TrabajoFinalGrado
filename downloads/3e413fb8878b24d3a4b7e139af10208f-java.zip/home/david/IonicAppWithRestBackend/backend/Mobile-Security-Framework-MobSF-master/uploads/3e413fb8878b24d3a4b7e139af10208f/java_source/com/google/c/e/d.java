/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.a;
import com.google.c.e;
import com.google.c.e.k;
import com.google.c.g;
import com.google.c.j;
import com.google.c.n;
import com.google.c.p;
import java.util.Arrays;
import java.util.Map;

public final class d
extends k {
    private static final char[] a;
    private static final int[] b;
    private static final int c;
    private final StringBuilder d = new StringBuilder(20);
    private final int[] e = new int[6];

    static {
        int[] arrn;
        a = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".toCharArray();
        int[] arrn2 = arrn = new int[48];
        arrn2[0] = 276;
        arrn2[1] = 328;
        arrn2[2] = 324;
        arrn2[3] = 322;
        arrn2[4] = 296;
        arrn2[5] = 292;
        arrn2[6] = 290;
        arrn2[7] = 336;
        arrn2[8] = 274;
        arrn2[9] = 266;
        arrn2[10] = 424;
        arrn2[11] = 420;
        arrn2[12] = 418;
        arrn2[13] = 404;
        arrn2[14] = 402;
        arrn2[15] = 394;
        arrn2[16] = 360;
        arrn2[17] = 356;
        arrn2[18] = 354;
        arrn2[19] = 308;
        arrn2[20] = 282;
        arrn2[21] = 344;
        arrn2[22] = 332;
        arrn2[23] = 326;
        arrn2[24] = 300;
        arrn2[25] = 278;
        arrn2[26] = 436;
        arrn2[27] = 434;
        arrn2[28] = 428;
        arrn2[29] = 422;
        arrn2[30] = 406;
        arrn2[31] = 410;
        arrn2[32] = 364;
        arrn2[33] = 358;
        arrn2[34] = 310;
        arrn2[35] = 314;
        arrn2[36] = 302;
        arrn2[37] = 468;
        arrn2[38] = 466;
        arrn2[39] = 458;
        arrn2[40] = 366;
        arrn2[41] = 374;
        arrn2[42] = 430;
        arrn2[43] = 294;
        arrn2[44] = 474;
        arrn2[45] = 470;
        arrn2[46] = 306;
        arrn2[47] = 350;
        b = arrn;
        c = arrn[47];
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static int a(int[] arrn) {
        int n2;
        int n3;
        int n4 = arrn.length;
        int n5 = arrn.length;
        int n6 = 0;
        for (n2 = 0; n2 < n5; ++n2) {
            n3 = arrn[n2];
            n6 = n3 + n6;
        }
        n3 = 0;
        n2 = 0;
        do {
            n5 = n2;
            if (n3 >= n4) return n5;
            int n7 = Math.round((float)arrn[n3] * 9.0f / (float)n6);
            if (n7 <= 0) return -1;
            if (n7 > 4) {
                return -1;
            }
            if ((n3 & 1) == 0) {
                int n8 = 0;
                do {
                    n5 = n2;
                    if (n8 < n7) {
                        ++n8;
                        n2 = n2 << 1 | 1;
                        continue;
                    }
                    break;
                    break;
                } while (true);
            } else {
                n5 = n2 << n7;
            }
            ++n3;
            n2 = n5;
        } while (true);
    }

    private static void a(CharSequence charSequence, int n2, int n3) {
        int n4 = 1;
        int n5 = n2 - 1;
        int n6 = 0;
        do {
            int n7;
            int n8 = n4;
            if (n5 < 0) break;
            int n9 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".indexOf(charSequence.charAt(n5));
            n4 = n7 = n8 + 1;
            if (n7 > n3) {
                n4 = 1;
            }
            --n5;
            n6 = n9 * n8 + n6;
        } while (true);
        if (charSequence.charAt(n2) != a[n6 % 47]) {
            throw com.google.c.d.a();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final n a(int var1_1, com.google.c.b.a var2_2, Map<e, ?> var3_3) {
        block27 : {
            var16_4 = var2_2.b;
            var11_5 = var2_2.c(0);
            Arrays.fill(this.e, 0);
            var3_3 = this.e;
            var14_6 = 0;
            var17_7 = var3_3.length;
            var15_8 = 0;
            var13_9 = var11_5;
            while (var13_9 < var16_4) {
                if (var2_2.a(var13_9) ^ var14_6) {
                    var3_3[var15_8] = var3_3[var15_8] + 1;
                    var12_10 = var14_6;
                } else {
                    if (var15_8 == var17_7 - 1) {
                        if (d.a((int[])var3_3) == d.c) break block27;
                        var11_5 += var3_3[0] + var3_3[1];
                        System.arraycopy(var3_3, 2, var3_3, 0, var17_7 - 2);
                        var3_3[var17_7 - 2] = 0;
                        var3_3[var17_7 - 1] = 0;
                        var12_10 = var15_8 - 1;
                    } else {
                        var12_10 = var15_8 + 1;
                    }
                    var3_3[var12_10] = 1;
                    if (var14_6 == 0) {
                        var14_6 = 1;
                        var15_8 = var12_10;
                        var12_10 = var14_6;
                    } else {
                        var14_6 = 0;
                        var15_8 = var12_10;
                        var12_10 = var14_6;
                    }
                }
                ++var13_9;
                var14_6 = var12_10;
            }
            throw j.a();
        }
        var3_3 = new int[]{var11_5, var13_9};
        var11_5 = var2_2.c(var3_3[1]);
        var15_8 = var2_2.b;
        var10_11 = this.e;
        Arrays.fill((int[])var10_11, 0);
        var9_12 = this.d;
        var9_12.setLength(0);
        do {
            block28 : {
                var12_10 = var11_5;
                d.a((com.google.c.b.a)var2_2, var12_10, (int[])var10_11);
                var13_9 = d.a((int[])var10_11);
                if (var13_9 < 0) {
                    throw j.a();
                }
                var11_5 = 0;
                while (var11_5 < d.b.length) {
                    if (d.b[var11_5] == var13_9) {
                        var7_13 = d.a[var11_5];
                        var9_12.append((char)var7_13);
                        var14_6 = var10_11.length;
                        var13_9 = var12_10;
                        for (var11_5 = 0; var11_5 < var14_6; var13_9 += var10_11[var11_5], ++var11_5) {
                        }
                        break block28;
                    }
                    ++var11_5;
                }
                throw j.a();
            }
            var11_5 = var14_6 = var2_2.c(var13_9);
        } while (var7_13 != 42);
        var9_12.deleteCharAt(var9_12.length() - 1);
        var13_9 = 0;
        var16_4 = var10_11.length;
        for (var11_5 = 0; var11_5 < var16_4; var13_9 += var10_11[var11_5], ++var11_5) {
        }
        if (var14_6 == var15_8) throw j.a();
        if (!var2_2.a(var14_6)) {
            throw j.a();
        }
        if (var9_12.length() < 2) {
            throw j.a();
        }
        var11_5 = var9_12.length();
        d.a((CharSequence)var9_12, var11_5 - 2, 20);
        d.a((CharSequence)var9_12, var11_5 - 1, 15);
        var9_12.setLength(var9_12.length() - 2);
        var14_6 = var9_12.length();
        var2_2 = new StringBuilder(var14_6);
        var11_5 = 0;
        do {
            if (var11_5 >= var14_6) {
                var2_2 = var2_2.toString();
                var4_15 = (float)(var3_3[1] + var3_3[0]) / 2.0f;
                var5_16 = var12_10;
                var6_17 = (float)var13_9 / 2.0f;
                var3_3 = new p(var4_15, var1_1);
                var9_12 = new p(var5_16 + var6_17, var1_1);
                var10_11 = a.d;
                return new n((String)var2_2, null, new p[]{var3_3, var9_12}, (a)var10_11);
            }
            var8_14 = var9_12.charAt(var11_5);
            if (var8_14 < 'a' || var8_14 > 'd') ** GOTO lbl128
            if (var11_5 >= var14_6 - 1) {
                throw g.a();
            }
            var15_8 = var9_12.charAt(var11_5 + 1);
            var7_13 = 0;
            switch (var8_14) {
                case 'd': {
                    if (var15_8 < 65) throw g.a();
                    if (var15_8 > 90) throw g.a();
                    var7_13 = (char)(var15_8 + 32);
                    ** break;
                }
                case 'a': {
                    if (var15_8 < 65) throw g.a();
                    if (var15_8 > 90) throw g.a();
                    var7_13 = (char)(var15_8 - 64);
                    ** break;
                }
                case 'b': {
                    if (var15_8 >= 65 && var15_8 <= 69) {
                        var7_13 = (char)(var15_8 - 38);
                        ** break;
                    }
                    if (var15_8 < 70) throw g.a();
                    if (var15_8 > 87) throw g.a();
                    var7_13 = (char)(var15_8 - 11);
                }
lbl117: // 5 sources:
                default: {
                    ** GOTO lbl125
                }
                case 'c': 
            }
            if (var15_8 >= 65 && var15_8 <= 79) {
                var7_13 = (char)(var15_8 - 32);
            } else {
                if (var15_8 != 90) throw g.a();
                var7_13 = 58;
            }
lbl125: // 3 sources:
            var2_2.append((char)var7_13);
            ++var11_5;
            ** GOTO lbl129
lbl128: // 1 sources:
            var2_2.append(var8_14);
lbl129: // 2 sources:
            ++var11_5;
        } while (true);
    }
}

