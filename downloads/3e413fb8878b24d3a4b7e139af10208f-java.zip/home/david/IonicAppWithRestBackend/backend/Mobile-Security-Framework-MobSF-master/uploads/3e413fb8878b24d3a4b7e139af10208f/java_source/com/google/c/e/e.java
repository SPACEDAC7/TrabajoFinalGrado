/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.a;
import com.google.c.e.p;
import com.google.c.j;

public final class e
extends p {
    static final int[] a = new int[]{0, 11, 13, 14, 19, 25, 28, 21, 22, 26};
    private final int[] f = new int[4];

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final int a(com.google.c.b.a a2, int[] arrn, StringBuilder stringBuilder) {
        int n2;
        int n3;
        int n4;
        int[] arrn2 = this.f;
        arrn2[0] = 0;
        arrn2[1] = 0;
        arrn2[2] = 0;
        arrn2[3] = 0;
        int n5 = a2.b;
        int n6 = arrn[1];
        int n7 = 0;
        for (n4 = 0; n4 < 6 && n6 < n5; ++n4) {
            n3 = e.a(a2, arrn2, n6, e);
            stringBuilder.append((char)(n3 % 10 + 48));
            int n8 = arrn2.length;
            for (n2 = 0; n2 < n8; n6 += arrn2[n2], ++n2) {
            }
            n2 = n7;
            if (n3 >= 10) {
                n2 = n7 | 1 << 5 - n4;
            }
            n7 = n2;
        }
        n4 = 0;
        do {
            if (n4 >= 10) {
                throw j.a();
            }
            if (n7 == a[n4]) break;
            ++n4;
        } while (true);
        stringBuilder.insert(0, (char)(n4 + 48));
        n4 = e.a(a2, n6, true, c)[1];
        n7 = 0;
        while (n7 < 6) {
            if (n4 >= n5) {
                return n4;
            }
            stringBuilder.append((char)(e.a(a2, arrn2, n4, d) + 48));
            n2 = arrn2.length;
            for (n6 = 0; n6 < n2; ++n6) {
                n3 = arrn2[n6];
                n4 = n3 + n4;
            }
            ++n7;
        }
        return n4;
    }

    @Override
    final a b() {
        return a.h;
    }
}

