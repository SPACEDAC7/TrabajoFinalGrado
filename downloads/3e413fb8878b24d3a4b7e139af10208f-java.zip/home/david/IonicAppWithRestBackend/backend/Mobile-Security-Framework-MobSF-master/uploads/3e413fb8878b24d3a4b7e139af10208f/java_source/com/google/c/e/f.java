/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.a;
import com.google.c.e.p;

public final class f
extends p {
    private final int[] a = new int[4];

    @Override
    protected final int a(com.google.c.b.a a2, int[] arrn, StringBuilder stringBuilder) {
        int n2;
        int n3;
        int n4;
        int[] arrn2 = this.a;
        arrn2[0] = 0;
        arrn2[1] = 0;
        arrn2[2] = 0;
        arrn2[3] = 0;
        int n5 = a2.b;
        int n6 = arrn[1];
        for (n4 = 0; n4 < 4 && n6 < n5; ++n4) {
            stringBuilder.append((char)(f.a(a2, arrn2, n6, d) + 48));
            n2 = arrn2.length;
            for (n3 = 0; n3 < n2; ++n3) {
                n6 += arrn2[n3];
            }
        }
        n6 = f.a(a2, n6, true, c)[1];
        for (n4 = 0; n4 < 4 && n6 < n5; ++n4) {
            stringBuilder.append((char)(f.a(a2, arrn2, n6, d) + 48));
            n2 = arrn2.length;
            for (n3 = 0; n3 < n2; ++n3) {
                n6 += arrn2[n3];
            }
        }
        return n6;
    }

    @Override
    final a b() {
        return a.g;
    }
}

