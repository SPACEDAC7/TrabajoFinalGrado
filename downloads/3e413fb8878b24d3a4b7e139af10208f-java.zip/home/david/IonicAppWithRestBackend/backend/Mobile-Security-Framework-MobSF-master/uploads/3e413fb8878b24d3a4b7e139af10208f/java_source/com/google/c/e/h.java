/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.a;
import com.google.c.e;
import com.google.c.e.k;
import com.google.c.g;
import com.google.c.j;
import com.google.c.n;
import com.google.c.p;
import java.util.Map;

public final class h
extends k {
    static final int[][] a;
    private static final int[] b;
    private static final int[] d;
    private static final int[] e;
    private int c = -1;

    static {
        b = new int[]{6, 8, 10, 12, 14};
        d = new int[]{1, 1, 1, 1};
        e = new int[]{1, 1, 3};
        a = new int[][]{{1, 1, 3, 3, 1}, {3, 1, 1, 1, 3}, {1, 3, 1, 1, 3}, {3, 3, 1, 1, 1}, {1, 1, 3, 1, 3}, {3, 1, 3, 1, 1}, {1, 3, 3, 1, 1}, {1, 1, 1, 3, 3}, {3, 1, 1, 3, 1}, {1, 3, 1, 3, 1}};
    }

    private static int a(com.google.c.b.a a2) {
        int n2 = a2.b;
        int n3 = a2.c(0);
        if (n3 == n2) {
            throw j.a();
        }
        return n3;
    }

    private static int a(int[] arrn) {
        float f2 = 0.38f;
        int n2 = -1;
        int n3 = a.length;
        for (int i2 = 0; i2 < n3; ++i2) {
            float f3 = h.a(arrn, a[i2], 0.78f);
            if (f3 >= f2) continue;
            n2 = i2;
            f2 = f3;
        }
        if (n2 >= 0) {
            return n2;
        }
        throw j.a();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(com.google.c.b.a a2, int n2) {
        int n3 = this.c * 10;
        if (n3 >= n2) {
            n3 = n2;
        }
        --n2;
        while (n3 > 0 && n2 >= 0 && !a2.a(n2)) {
            --n3;
            --n2;
        }
        if (n3 != 0) {
            throw j.a();
        }
    }

    private static void a(com.google.c.b.a a2, int n2, int n3, StringBuilder stringBuilder) {
        int[] arrn = new int[10];
        int[] arrn2 = new int[5];
        int[] arrn3 = new int[5];
        while (n2 < n3) {
            int n4;
            h.a(a2, n2, arrn);
            for (n4 = 0; n4 < 5; ++n4) {
                int n5 = n4 * 2;
                arrn2[n4] = arrn[n5];
                arrn3[n4] = arrn[n5 + 1];
            }
            stringBuilder.append((char)(h.a(arrn2) + 48));
            stringBuilder.append((char)(h.a(arrn3) + 48));
            for (n4 = 0; n4 < 10; ++n4) {
                n2 += arrn[n4];
            }
        }
    }

    private int[] b(com.google.c.b.a a2) {
        a2.c();
        int[] arrn = h.c(a2, h.a(a2), e);
        this.a(a2, arrn[0]);
        int n2 = arrn[0];
        try {
            arrn[0] = a2.b - arrn[1];
            arrn[1] = a2.b - n2;
            return arrn;
        }
        finally {
            a2.c();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int[] c(com.google.c.b.a a2, int n2, int[] arrn) {
        int n3 = arrn.length;
        int[] arrn2 = new int[n3];
        int n4 = a2.b;
        int n5 = n2;
        int n6 = 0;
        int n7 = 0;
        int n8 = n2;
        n2 = n5;
        do {
            if (n8 >= n4) {
                throw j.a();
            }
            if (a2.a(n8) ^ n7) {
                arrn2[n6] = arrn2[n6] + 1;
                n5 = n7;
                n7 = n2;
            } else {
                int n9;
                if (n6 == n3 - 1) {
                    if (h.a(arrn2, arrn, 0.78f) < 0.38f) {
                        return new int[]{n2, n8};
                    }
                    n5 = n2 + (arrn2[0] + arrn2[1]);
                    System.arraycopy(arrn2, 2, arrn2, 0, n3 - 2);
                    arrn2[n3 - 2] = 0;
                    arrn2[n3 - 1] = 0;
                    n2 = n6 - 1;
                } else {
                    n5 = n2;
                    n2 = ++n6;
                }
                arrn2[n2] = 1;
                if (n7 == 0) {
                    n9 = 1;
                    n7 = n5;
                    n6 = n2;
                    n5 = n9;
                } else {
                    n9 = 0;
                    n7 = n5;
                    n6 = n2;
                    n5 = n9;
                }
            }
            ++n8;
            n2 = n7;
            n7 = n5;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final n a(int n2, com.google.c.b.a arrn, Map<e, ?> object) {
        int n3;
        int n4;
        int n5;
        Object object2;
        int n6;
        String string;
        int[] arrn2;
        block6 : {
            arrn2 = h.c((com.google.c.b.a)arrn, h.a((com.google.c.b.a)arrn), d);
            this.c = (arrn2[1] - arrn2[0]) / 4;
            this.a((com.google.c.b.a)arrn, arrn2[0]);
            object2 = this.b((com.google.c.b.a)arrn);
            StringBuilder stringBuilder = new StringBuilder(20);
            h.a((com.google.c.b.a)arrn, arrn2[1], object2[0], stringBuilder);
            string = stringBuilder.toString();
            arrn = object != null ? (int[])object.get((Object)e.f) : null;
            object = arrn;
            if (arrn == null) {
                object = b;
            }
            n6 = string.length();
            int n7 = object.length;
            n3 = 0;
            for (n5 = 0; n5 < n7; ++n5) {
                n4 = object[n5];
                if (n6 == n4) {
                    n5 = 1;
                    break block6;
                }
                if (n4 <= n3) continue;
                n3 = n4;
            }
            n5 = 0;
        }
        n4 = n5;
        if (n5 == 0) {
            n4 = n5;
            if (n6 > n3) {
                n4 = 1;
            }
        }
        if (n4 == 0) {
            throw g.a();
        }
        arrn = new p(arrn2[1], n2);
        object = new p(object2[0], n2);
        object2 = a.i;
        return new n(string, null, new p[]{arrn, object}, (a)((Object)object2));
    }
}

