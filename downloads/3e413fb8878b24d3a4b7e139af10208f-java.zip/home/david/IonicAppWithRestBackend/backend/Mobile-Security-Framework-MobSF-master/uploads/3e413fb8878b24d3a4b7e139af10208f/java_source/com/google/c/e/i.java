/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.e.a;
import com.google.c.e.a.e;
import com.google.c.e.b;
import com.google.c.e.c;
import com.google.c.e.d;
import com.google.c.e.h;
import com.google.c.e.j;
import com.google.c.e.k;
import com.google.c.m;
import com.google.c.n;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public final class i
extends k {
    private final k[] a;

    /*
     * Enabled aggressive block sorting
     */
    public i(Map<com.google.c.e, ?> map) {
        Collection collection = map == null ? null : (Collection)map.get((Object)com.google.c.e.c);
        boolean bl2 = map != null && map.get((Object)com.google.c.e.g) != null;
        ArrayList<k> arrayList = new ArrayList<k>();
        if (collection != null) {
            if (collection.contains((Object)com.google.c.a.h) || collection.contains((Object)com.google.c.a.o) || collection.contains((Object)com.google.c.a.g) || collection.contains((Object)com.google.c.a.p)) {
                arrayList.add(new j(map));
            }
            if (collection.contains((Object)com.google.c.a.c)) {
                arrayList.add(new c(bl2));
            }
            if (collection.contains((Object)com.google.c.a.d)) {
                arrayList.add(new d());
            }
            if (collection.contains((Object)com.google.c.a.e)) {
                arrayList.add(new b());
            }
            if (collection.contains((Object)com.google.c.a.i)) {
                arrayList.add(new h());
            }
            if (collection.contains((Object)com.google.c.a.b)) {
                arrayList.add(new a());
            }
            if (collection.contains((Object)com.google.c.a.m)) {
                arrayList.add(new e());
            }
            if (collection.contains((Object)com.google.c.a.n)) {
                arrayList.add(new com.google.c.e.a.a.c());
            }
        }
        if (arrayList.isEmpty()) {
            arrayList.add(new j(map));
            arrayList.add(new c());
            arrayList.add(new a());
            arrayList.add(new d());
            arrayList.add(new b());
            arrayList.add(new h());
            arrayList.add(new e());
            arrayList.add(new com.google.c.e.a.a.c());
        }
        this.a = arrayList.toArray(new k[arrayList.size()]);
    }

    @Override
    public final n a(int n2, com.google.c.b.a a2, Map<com.google.c.e, ?> map) {
        for (k object : this.a) {
            try {
                n n3 = object.a(n2, a2, map);
                return n3;
            }
            catch (m var5_7) {
                continue;
            }
        }
        throw com.google.c.j.a();
    }

    @Override
    public final void a() {
        k[] arrk = this.a;
        int n2 = arrk.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrk[i2].a();
        }
    }
}

