/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.a;
import com.google.c.e;
import com.google.c.e.f;
import com.google.c.e.k;
import com.google.c.e.l;
import com.google.c.e.q;
import com.google.c.m;
import com.google.c.n;
import com.google.c.o;
import com.google.c.p;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public final class j
extends k {
    private final com.google.c.e.p[] a;

    /*
     * Enabled aggressive block sorting
     */
    public j(Map<e, ?> object) {
        object = object == null ? null : (Collection)object.get((Object)e.c);
        ArrayList<com.google.c.e.p> arrayList = new ArrayList<com.google.c.e.p>();
        if (object != null) {
            if (object.contains((Object)a.h)) {
                arrayList.add(new com.google.c.e.e());
            } else if (object.contains((Object)a.o)) {
                arrayList.add(new l());
            }
            if (object.contains((Object)a.g)) {
                arrayList.add(new f());
            }
            if (object.contains((Object)a.p)) {
                arrayList.add(new q());
            }
        }
        if (arrayList.isEmpty()) {
            arrayList.add(new com.google.c.e.e());
            arrayList.add(new f());
            arrayList.add(new q());
        }
        this.a = arrayList.toArray(new com.google.c.e.p[arrayList.size()]);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final n a(int n2, com.google.c.b.a object, Map<e, ?> map) {
        int[] arrn = com.google.c.e.p.a((com.google.c.b.a)object);
        com.google.c.e.p[] arrp = this.a;
        int n3 = arrp.length;
        int n4 = 0;
        do {
            if (n4 >= n3) {
                throw com.google.c.j.a();
            }
            Object object2 = arrp[n4];
            try {
                object2 = object2.a(n2, (com.google.c.b.a)object, arrn, map);
                n2 = object2.d == a.h && object2.a.charAt(0) == '0' ? 1 : 0;
            }
            catch (m var4_8) {
                ++n4;
                continue;
            }
            object = map == null ? null : (Collection)map.get((Object)e.c);
            n4 = object == null || object.contains((Object)a.o) ? 1 : 0;
            if (n2 == 0) return object2;
            if (n4 != 0) {
                object = new n(object2.a.substring(1), object2.b, object2.c, a.o);
                object.a(object2.e);
                return object;
            }
            return object2;
            break;
        } while (true);
    }

    @Override
    public final void a() {
        com.google.c.e.p[] arrp = this.a;
        int n2 = arrp.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrp[i2].a();
        }
    }
}

