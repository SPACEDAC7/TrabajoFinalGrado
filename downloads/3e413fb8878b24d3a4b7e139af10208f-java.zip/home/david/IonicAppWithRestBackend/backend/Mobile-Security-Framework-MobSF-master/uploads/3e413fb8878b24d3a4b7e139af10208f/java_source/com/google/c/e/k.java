/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.b;
import com.google.c.b.a;
import com.google.c.c;
import com.google.c.e;
import com.google.c.h;
import com.google.c.j;
import com.google.c.l;
import com.google.c.m;
import com.google.c.n;
import com.google.c.o;
import com.google.c.p;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;

public abstract class k
implements l {
    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static float a(int[] arrn, int[] arrn2, float f2) {
        int n2;
        int n3 = arrn.length;
        int n4 = 0;
        int n5 = 0;
        for (n2 = 0; n2 < n3; n5 += arrn[n2], n4 += arrn2[n2], ++n2) {
        }
        if (n5 < n4) {
            return Float.POSITIVE_INFINITY;
        }
        float f3 = (float)n5 / (float)n4;
        float f4 = 0.0f;
        n2 = 0;
        while (n2 < n3) {
            n4 = arrn[n2];
            float f5 = (float)arrn2[n2] * f3;
            f5 = (float)n4 > f5 ? (float)n4 - f5 : (f5 -= (float)n4);
            if (f5 > f2 * f3) return Float.POSITIVE_INFINITY;
            f4 += f5;
            ++n2;
        }
        return f4 / (float)n5;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(a a2, int n2, int[] arrn) {
        int n3 = arrn.length;
        Arrays.fill(arrn, 0, n3, 0);
        int n4 = a2.b;
        if (n2 >= n4) {
            throw j.a();
        }
        int n5 = !a2.a(n2) ? 1 : 0;
        int n6 = 0;
        int n7 = n2;
        n2 = n6;
        while (n7 < n4) {
            if (a2.a(n7) ^ n5) {
                arrn[n2] = arrn[n2] + 1;
            } else {
                n2 = n6 = n2 + 1;
                if (n6 == n3) break;
                arrn[n6] = 1;
                n2 = n5 == 0 ? 1 : 0;
                n5 = n2;
                n2 = n6;
            }
            ++n7;
        }
        if (n2 != n3 && (n2 != n3 - 1 || n7 != n4)) {
            throw j.a();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private n b(c c2, Map<e, ?> map) {
        int n2 = c2.a.a.a;
        int n3 = c2.a.a.b;
        Map map2 = new a(n2);
        int n4 = map != null && map.containsKey((Object)e.d) ? 1 : 0;
        int n5 = n4 != 0 ? 8 : 5;
        int n6 = Math.max(1, n3 >> n5);
        n4 = n4 != 0 ? n3 : 15;
        for (n5 = 0; n5 < n4; ++n5) {
            Map map3;
            p[] arrp;
            block11 : {
                int n7 = (n5 + 1) / 2;
                int n8 = (n5 & 1) == 0 ? 1 : 0;
                n8 = n8 != 0 ? n7 : - n7;
                n7 = (n3 >> 1) + n8 * n6;
                if (n7 < 0 || n7 >= n3) break;
                try {
                    map2 = map3 = c2.a.a(n7, (a)((Object)map2));
                    n8 = 0;
                }
                catch (j var4_11) {
                    map3 = map;
                    arrp = map2;
                    break block11;
                }
                do {
                    arrp = map2;
                    map3 = map;
                    if (n8 >= 2) break;
                    map3 = map;
                    if (n8 == 1) {
                        map2.c();
                        map3 = map;
                        if (map != null) {
                            map3 = map;
                            if (map.containsKey((Object)e.j)) {
                                map3 = new EnumMap(e.class);
                                map3.putAll(map);
                                map3.remove((Object)e.j);
                            }
                        }
                    }
                    try {
                        map = this.a(n7, (a)((Object)map2), map3);
                        if (n8 == 1) {
                            map.a(o.b, 180);
                            arrp = map.c;
                            if (arrp != null) {
                                arrp[0] = new p((float)n2 - arrp[0].a - 1.0f, arrp[0].b);
                                arrp[1] = new p((float)n2 - arrp[1].a - 1.0f, arrp[1].b);
                            }
                        }
                        return map;
                    }
                    catch (m var2_3) {
                        ++n8;
                        map = map3;
                        continue;
                    }
                    break;
                } while (true);
            }
            map2 = arrp;
            map = map3;
        }
        throw j.a();
    }

    public static void b(a a2, int n2, int[] arrn) {
        int n3 = arrn.length;
        boolean bl2 = a2.a(n2);
        while (n2 > 0 && n3 >= 0) {
            int n4;
            n2 = n4 = n2 - 1;
            if (a2.a(n4) == bl2) continue;
            --n3;
            if (!bl2) {
                bl2 = true;
                n2 = n4;
                continue;
            }
            bl2 = false;
            n2 = n4;
        }
        if (n3 >= 0) {
            throw j.a();
        }
        k.a(a2, n2 + 1, arrn);
    }

    public abstract n a(int var1, a var2, Map<e, ?> var3);

    @Override
    public n a(c object, Map<e, ?> map) {
        try {
            object = this.b((c)object, map);
            return object;
        }
        catch (j var1_2) {
            if (map != null) {
                map.containsKey((Object)((Object)e.d));
            }
            throw var1_2;
        }
    }

    @Override
    public void a() {
    }
}

