/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.a;
import com.google.c.c;
import com.google.c.e;
import com.google.c.g;
import com.google.c.n;
import com.google.c.p;
import java.util.Map;

public final class l
extends com.google.c.e.p {
    private final com.google.c.e.p a = new com.google.c.e.e();

    private static n a(n n2) {
        String string = n2.a;
        if (string.charAt(0) == '0') {
            return new n(string.substring(1), null, n2.c, a.o);
        }
        throw g.a();
    }

    @Override
    protected final int a(com.google.c.b.a a2, int[] arrn, StringBuilder stringBuilder) {
        return this.a.a(a2, arrn, stringBuilder);
    }

    @Override
    public final n a(int n2, com.google.c.b.a a2, Map<e, ?> map) {
        return l.a(this.a.a(n2, a2, map));
    }

    @Override
    public final n a(int n2, com.google.c.b.a a2, int[] arrn, Map<e, ?> map) {
        return l.a(this.a.a(n2, a2, arrn, map));
    }

    @Override
    public final n a(c c2, Map<e, ?> map) {
        return l.a(this.a.a(c2, map));
    }

    @Override
    final a b() {
        return a.o;
    }
}

