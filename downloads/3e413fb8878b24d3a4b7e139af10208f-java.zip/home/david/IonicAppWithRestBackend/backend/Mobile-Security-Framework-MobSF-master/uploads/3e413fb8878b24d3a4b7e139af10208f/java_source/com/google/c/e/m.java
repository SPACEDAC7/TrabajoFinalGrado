/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.a;
import com.google.c.j;
import com.google.c.n;
import com.google.c.o;
import com.google.c.p;
import java.util.EnumMap;
import java.util.Map;

final class m {
    private final int[] a = new int[4];
    private final StringBuilder b = new StringBuilder();

    m() {
    }

    /*
     * Enabled aggressive block sorting
     */
    final n a(int n2, com.google.c.b.a a2, int[] object) {
        StringBuilder stringBuilder = this.b;
        stringBuilder.setLength(0);
        Object object2 = this.a;
        object2[0] = 0;
        object2[1] = 0;
        object2[2] = 0;
        object2[3] = 0;
        int n3 = a2.b;
        Object object3 = object[1];
        Object object4 = 0;
        for (int i2 = 0; i2 < 2 && object3 < n3; ++i2) {
            int n4 = com.google.c.e.p.a(a2, (int[])object2, (int)object3, com.google.c.e.p.e);
            stringBuilder.append((char)(n4 % 10 + 48));
            for (int n5 : object2) {
                object3 = n5 + object3;
            }
            int n6 = object4;
            if (n4 >= 10) {
                n6 = object4 | 1 << 1 - i2;
            }
            object4 = object3;
            if (i2 != 1) {
                object4 = a2.d(a2.c((int)object3));
            }
            object3 = object4;
            object4 = n6;
        }
        if (stringBuilder.length() != 2) {
            throw j.a();
        }
        if (Integer.parseInt(stringBuilder.toString()) % 4 != object4) {
            throw j.a();
        }
        String string = stringBuilder.toString();
        if (string.length() != 2) {
            a2 = null;
        } else {
            a2 = new EnumMap(o.class);
            a2.put(o.e, Integer.valueOf(string));
        }
        object = new p((float)((Object)(object[0] + object[1]) / 2.0f), n2);
        object2 = new p((float)object3, n2);
        a a3 = a.q;
        object = new n(string, null, new p[]{object, object2}, a3);
        if (a2 != null) {
            object.a((Map<o, Object>)((Object)a2));
        }
        return object;
    }
}

