/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

final class n {
    static final int[] a = new int[]{24, 20, 18, 17, 12, 6, 3, 10, 9, 5};
    final int[] b = new int[4];
    final StringBuilder c = new StringBuilder();

    n() {
    }
}

