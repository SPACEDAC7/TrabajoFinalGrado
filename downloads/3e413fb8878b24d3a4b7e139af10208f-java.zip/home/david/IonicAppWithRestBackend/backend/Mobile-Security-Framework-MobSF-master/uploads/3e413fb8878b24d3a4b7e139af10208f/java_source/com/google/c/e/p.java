/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import android.support.design.widget.AppBarLayout;
import com.google.c.a;
import com.google.c.d;
import com.google.c.e;
import com.google.c.e.k;
import com.google.c.g;
import com.google.c.j;
import com.google.c.m;
import com.google.c.n;
import com.google.c.o;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public abstract class p
extends k {
    static final int[] b = new int[]{1, 1, 1};
    static final int[] c = new int[]{1, 1, 1, 1, 1};
    static final int[][] d;
    static final int[][] e;
    private final StringBuilder a = new StringBuilder(20);
    private final com.google.c.e.o f = new com.google.c.e.o();
    private final com.google.c.e.g g = new com.google.c.e.g();

    static {
        int[] arrn = new int[]{1, 4, 1, 1};
        int[] arrn2 = new int[]{1, 2, 3, 1};
        d = new int[][]{{3, 2, 1, 1}, {2, 2, 2, 1}, {2, 1, 2, 2}, arrn, {1, 1, 3, 2}, arrn2, {1, 1, 1, 4}, {1, 3, 1, 2}, {1, 2, 1, 3}, {3, 1, 1, 2}};
        e = new int[20][];
        System.arraycopy(d, 0, e, 0, 10);
        for (int i2 = 10; i2 < 20; ++i2) {
            arrn = d[i2 - 10];
            arrn2 = new int[arrn.length];
            for (int i3 = 0; i3 < arrn.length; ++i3) {
                arrn2[i3] = arrn[arrn.length - i3 - 1];
            }
            p.e[i2] = arrn2;
        }
    }

    protected p() {
    }

    static int a(com.google.c.b.a a2, int[] arrn, int n2, int[][] arrn2) {
        p.a(a2, n2, arrn);
        float f2 = 0.48f;
        int n3 = -1;
        int n4 = arrn2.length;
        for (n2 = 0; n2 < n4; ++n2) {
            float f3 = p.a(arrn, arrn2[n2], 0.7f);
            if (f3 >= f2) continue;
            n3 = n2;
            f2 = f3;
        }
        if (n3 >= 0) {
            return n3;
        }
        throw j.a();
    }

    static int[] a(com.google.c.b.a a2) {
        int[] arrn = new int[b.length];
        int n2 = 0;
        int[] arrn2 = null;
        boolean bl2 = false;
        while (!bl2) {
            Arrays.fill(arrn, 0, b.length, 0);
            int[] arrn3 = p.a(a2, n2, false, b, arrn);
            int n3 = arrn3[0];
            int n4 = arrn3[1];
            int n5 = n3 - (n4 - n3);
            n2 = n4;
            arrn2 = arrn3;
            if (n5 < 0) continue;
            bl2 = a2.a(n5, n3);
            n2 = n4;
            arrn2 = arrn3;
        }
        return arrn2;
    }

    static int[] a(com.google.c.b.a a2, int n2, boolean bl2, int[] arrn) {
        return p.a(a2, n2, bl2, arrn, new int[arrn.length]);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int[] a(com.google.c.b.a a2, int n2, boolean bl2, int[] arrn, int[] arrn2) {
        int n3 = arrn.length;
        int n4 = a2.b;
        n2 = bl2 ? a2.d(n2) : a2.c(n2);
        int n5 = 0;
        int n6 = n2;
        do {
            int n7;
            if (n6 >= n4) {
                throw j.a();
            }
            if (a2.a(n6) ^ bl2) {
                arrn2[n5] = arrn2[n5] + 1;
                n7 = n5;
                n5 = n2;
            } else {
                if (n5 == n3 - 1) {
                    if (p.a(arrn2, arrn, 0.7f) < 0.48f) {
                        return new int[]{n2, n6};
                    }
                    n7 = n2 + (arrn2[0] + arrn2[1]);
                    System.arraycopy(arrn2, 2, arrn2, 0, n3 - 2);
                    arrn2[n3 - 2] = 0;
                    arrn2[n3 - 1] = 0;
                    n2 = n5 - 1;
                    n5 = n7;
                } else {
                    n7 = n5 + 1;
                    n5 = n2;
                    n2 = n7;
                }
                arrn2[n2] = 1;
                if (!bl2) {
                    bl2 = true;
                    n7 = n2;
                } else {
                    bl2 = false;
                    n7 = n2;
                }
            }
            ++n6;
            n2 = n5;
            n5 = n7;
        } while (true);
    }

    protected abstract int a(com.google.c.b.a var1, int[] var2, StringBuilder var3);

    @Override
    public n a(int n2, com.google.c.b.a a2, Map<e, ?> map) {
        return this.a(n2, a2, p.a(a2), map);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public n a(int var1_1, com.google.c.b.a var2_2, int[] var3_4, Map<e, ?> var4_5) {
        var7_6 = var4_5 == null ? null : (AppBarLayout.b)var4_5.get((Object)e.j);
        if (var7_6 != null) {
            new com.google.c.p((float)((Object)(var3_4[0] + var3_4[1]) / 2.0f), var1_1);
        }
        var8_7 = this.a;
        var8_7.setLength(0);
        var12_8 = this.a((com.google.c.b.a)var2_2, (int[])var3_4, (StringBuilder)var8_7);
        if (var7_6 != null) {
            new com.google.c.p(var12_8, var1_1);
        }
        var9_9 = this.a((com.google.c.b.a)var2_2, var12_8);
        if (var7_6 != null) {
            new com.google.c.p((float)(var9_9[0] + var9_9[1]) / 2.0f, var1_1);
        }
        if ((var13_10 = (var12_8 = var9_9[1]) - var9_9[0] + var12_8) >= var2_2.b) throw j.a();
        if (!var2_2.a(var12_8, var13_10)) {
            throw j.a();
        }
        var7_6 = var8_7.toString();
        if (var7_6.length() < 8) {
            throw g.a();
        }
        if (!this.a((String)var7_6)) {
            throw d.a();
        }
        var5_11 = (Object)(var3_4[1] + var3_4[0]) / 2.0f;
        var6_12 = (float)(var9_9[1] + var9_9[0]) / 2.0f;
        var8_7 = this.b();
        var3_4 = new n((String)var7_6, null, new com.google.c.p[]{new com.google.c.p((float)var5_11, var1_1), new com.google.c.p(var6_12, var1_1)}, (a)var8_7);
        try {
            block18 : {
                var2_2 = this.f.a(var1_1, (com.google.c.b.a)var2_2, var9_9[1]);
                var3_4.a(o.h, var2_2.a);
                var3_4.a(var2_2.e);
                var9_9 = var2_2.c;
                var10_13 = var3_4.c;
                if (var10_13 == null) {
                    var3_4.c = var9_9;
                } else if (var9_9 != null) {
                    if (var9_9.length <= 0) break block18;
                    var11_14 = new com.google.c.p[var10_13.length + var9_9.length];
                    System.arraycopy(var10_13, 0, var11_14, 0, var10_13.length);
                    System.arraycopy(var9_9, 0, var11_14, var10_13.length, var9_9.length);
                    var3_4.c = var11_14;
                }
            }
            var1_1 = var2_2.a.length();
        }
        catch (m var2_3) {
            var1_1 = 0;
        }
        var2_2 = var4_5 == null ? null : (int[])var4_5.get((Object)e.k);
        if (var2_2 == null) ** GOTO lbl59
        var14_15 = 0;
        var15_16 = var2_2.length;
        var12_8 = 0;
        do {
            var13_10 = var14_15;
            if (var12_8 >= var15_16) ** GOTO lbl55
            if (var1_1 == var2_2[var12_8]) {
                var13_10 = 1;
lbl55: // 2 sources:
                if (var13_10 != 0) break;
                throw j.a();
            }
            ++var12_8;
        } while (true);
lbl59: // 2 sources:
        if (var8_7 != a.h) {
            if (var8_7 != a.o) return var3_4;
        }
        var2_2 = this.g;
        var2_2.a();
        var13_10 = Integer.parseInt(var7_6.substring(0, 3));
        var14_15 = var2_2.a.size();
        var1_1 = 0;
        while (var1_1 < var14_15) {
            var4_5 = var2_2.a.get(var1_1);
            var12_8 = var4_5[0];
            if (var13_10 < var12_8) return var3_4;
            if (var4_5.length != 1) {
                var12_8 = var4_5[1];
            }
            if (var13_10 <= var12_8) {
                var2_2 = var2_2.b.get(var1_1);
                if (var2_2 == null) return var3_4;
                var3_4.a(o.g, var2_2);
                return var3_4;
            }
            ++var1_1;
        }
        return var3_4;
    }

    boolean a(String string) {
        boolean bl2 = false;
        int n2 = string.length();
        boolean bl3 = bl2;
        if (n2 != 0) {
            int n3;
            int n4 = 0;
            for (n3 = n2 - 2; n3 >= 0; n3 -= 2) {
                int n5 = string.charAt(n3) - 48;
                if (n5 < 0 || n5 > 9) {
                    throw g.a();
                }
                n4 += n5;
            }
            n4 *= 3;
            for (n3 = n2 - 1; n3 >= 0; n3 -= 2) {
                n2 = string.charAt(n3) - 48;
                if (n2 < 0 || n2 > 9) {
                    throw g.a();
                }
                n4 += n2;
            }
            bl3 = bl2;
            if (n4 % 10 == 0) {
                bl3 = true;
            }
        }
        return bl3;
    }

    int[] a(com.google.c.b.a a2, int n2) {
        return p.a(a2, n2, false, b);
    }

    abstract a b();
}

