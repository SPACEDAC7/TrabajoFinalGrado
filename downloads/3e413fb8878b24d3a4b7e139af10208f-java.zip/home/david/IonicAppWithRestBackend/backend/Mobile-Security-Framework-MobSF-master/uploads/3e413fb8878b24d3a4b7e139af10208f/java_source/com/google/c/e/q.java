/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.e;

import com.google.c.a;
import com.google.c.e.p;
import com.google.c.j;

public final class q
extends p {
    private static final int[] a = new int[]{1, 1, 1, 1, 1, 1};
    private static final int[][] f = new int[][]{{56, 52, 50, 49, 44, 38, 35, 42, 41, 37}, {7, 11, 13, 14, 19, 25, 28, 21, 22, 26}};
    private final int[] g = new int[4];

    @Override
    protected final int a(com.google.c.b.a a2, int[] arrn, StringBuilder stringBuilder) {
        int n2;
        int n3;
        int[] arrn2 = this.g;
        arrn2[0] = 0;
        arrn2[1] = 0;
        arrn2[2] = 0;
        arrn2[3] = 0;
        int n4 = a2.b;
        int n5 = arrn[1];
        int n6 = 0;
        for (n3 = 0; n3 < 6 && n5 < n4; ++n3) {
            int n7 = q.a(a2, arrn2, n5, e);
            stringBuilder.append((char)(n7 % 10 + 48));
            int n8 = arrn2.length;
            for (n2 = 0; n2 < n8; ++n2) {
                n5 += arrn2[n2];
            }
            n2 = n6;
            if (n7 >= 10) {
                n2 = n6 | 1 << 5 - n3;
            }
            n6 = n2;
        }
        for (n3 = 0; n3 <= 1; ++n3) {
            for (n2 = 0; n2 < 10; ++n2) {
                if (n6 != f[n3][n2]) continue;
                stringBuilder.insert(0, (char)(n3 + 48));
                stringBuilder.append((char)(n2 + 48));
                return n5;
            }
        }
        throw j.a();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final boolean a(String string) {
        char[] arrc = new char[6];
        string.getChars(1, 7, arrc, 0);
        StringBuilder stringBuilder = new StringBuilder(12);
        stringBuilder.append(string.charAt(0));
        char c2 = arrc[5];
        switch (c2) {
            default: {
                stringBuilder.append(arrc, 0, 5);
                stringBuilder.append("0000");
                stringBuilder.append(c2);
                break;
            }
            case '0': 
            case '1': 
            case '2': {
                stringBuilder.append(arrc, 0, 2);
                stringBuilder.append(c2);
                stringBuilder.append("0000");
                stringBuilder.append(arrc, 2, 3);
                break;
            }
            case '3': {
                stringBuilder.append(arrc, 0, 3);
                stringBuilder.append("00000");
                stringBuilder.append(arrc, 3, 2);
                break;
            }
            case '4': {
                stringBuilder.append(arrc, 0, 4);
                stringBuilder.append("00000");
                stringBuilder.append(arrc[4]);
            }
        }
        stringBuilder.append(string.charAt(7));
        return super.a(stringBuilder.toString());
    }

    @Override
    protected final int[] a(com.google.c.b.a a2, int n2) {
        return q.a(a2, n2, true, a);
    }

    @Override
    final a b() {
        return a.p;
    }
}

