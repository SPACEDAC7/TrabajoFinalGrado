/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a;

final class a {
    final int a;
    final int b;
    final int c;
    final int d;
    final int e;

    a(int n2, int n3, int n4, int n5) {
        this.a = n2;
        this.b = n5;
        this.c = n3;
        this.d = n4;
        this.e = n3 + n4;
    }
}

