/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a.a;

import com.google.c.d;
import com.google.c.f.a.a.b;
import com.google.c.f.a.a.c;

public final class a {
    public final b a = b.a;

    public final int[] a(c c2) {
        int n2 = c2.b.length - 1;
        int[] arrn = new int[n2];
        int n3 = 0;
        for (int i2 = 1; i2 < this.a.f && n3 < n2; ++i2) {
            int n4 = n3;
            if (c2.b(i2) == 0) {
                arrn[n3] = this.a.a(i2);
                n4 = n3 + 1;
            }
            n3 = n4;
        }
        if (n3 != n2) {
            throw d.a();
        }
        return arrn;
    }

    public final int[] a(c c2, c c3, int[] arrn) {
        int n2;
        int n3 = c3.b.length - 1;
        int[] arrn2 = new int[n3];
        for (n2 = 1; n2 <= n3; ++n2) {
            arrn2[n3 - n2] = this.a.d(n2, c3.a(n2));
        }
        c3 = new c(this.a, arrn2);
        n3 = arrn.length;
        arrn2 = new int[n3];
        for (n2 = 0; n2 < n3; ++n2) {
            int n4 = this.a.a(arrn[n2]);
            int n5 = this.a.c(0, c2.b(n4));
            n4 = this.a.a(c3.b(n4));
            arrn2[n2] = this.a.d(n5, n4);
        }
        return arrn2;
    }
}

