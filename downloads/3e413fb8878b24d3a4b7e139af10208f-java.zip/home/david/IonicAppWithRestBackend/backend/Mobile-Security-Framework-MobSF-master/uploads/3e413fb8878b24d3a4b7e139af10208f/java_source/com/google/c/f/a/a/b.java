/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a.a;

import com.google.c.f.a.a.c;

public final class b {
    public static final b a = new b();
    public final int[] b = new int[929];
    public final int[] c = new int[929];
    public final c d;
    public final c e;
    final int f = 929;

    private b() {
        int n2;
        int n3 = 1;
        for (n2 = 0; n2 < 929; ++n2) {
            this.b[n2] = n3;
            n3 = n3 * 3 % 929;
        }
        n2 = 0;
        while (n2 < 928) {
            this.c[this.b[n2]] = n2++;
        }
        this.d = new c(this, new int[]{0});
        this.e = new c(this, new int[]{1});
    }

    public final int a(int n2) {
        if (n2 == 0) {
            throw new ArithmeticException();
        }
        return this.b[this.f - this.c[n2] - 1];
    }

    public final c a(int n2, int n3) {
        if (n2 < 0) {
            throw new IllegalArgumentException();
        }
        if (n3 == 0) {
            return this.d;
        }
        int[] arrn = new int[n2 + 1];
        arrn[0] = n3;
        return new c(this, arrn);
    }

    final int b(int n2, int n3) {
        return (n2 + n3) % this.f;
    }

    public final int c(int n2, int n3) {
        return (this.f + n2 - n3) % this.f;
    }

    public final int d(int n2, int n3) {
        if (n2 == 0 || n3 == 0) {
            return 0;
        }
        return this.b[(this.c[n2] + this.c[n3]) % (this.f - 1)];
    }
}

