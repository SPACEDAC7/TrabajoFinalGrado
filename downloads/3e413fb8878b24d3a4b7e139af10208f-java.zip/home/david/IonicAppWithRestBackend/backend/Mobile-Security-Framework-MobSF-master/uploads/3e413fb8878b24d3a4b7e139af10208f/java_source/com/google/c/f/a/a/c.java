/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a.a;

import com.google.c.f.a.a.b;

public final class c {
    public final b a;
    public final int[] b;

    public c(b b2, int[] arrn) {
        if (arrn.length == 0) {
            throw new IllegalArgumentException();
        }
        this.a = b2;
        int n2 = arrn.length;
        if (n2 > 1 && arrn[0] == 0) {
            int n3;
            for (n3 = 1; n3 < n2 && arrn[n3] == 0; ++n3) {
            }
            if (n3 == n2) {
                this.b = new int[]{0};
                return;
            }
            this.b = new int[n2 - n3];
            System.arraycopy(arrn, n3, this.b, 0, this.b.length);
            return;
        }
        this.b = arrn;
    }

    public final int a(int n2) {
        return this.b[this.b.length - 1 - n2];
    }

    /*
     * Enabled aggressive block sorting
     */
    public final c a(c arrn) {
        int[] arrn2;
        if (!this.a.equals(arrn.a)) {
            throw new IllegalArgumentException("ModulusPolys do not have same ModulusGF field");
        }
        if (this.a()) {
            return arrn;
        }
        if (arrn.a()) {
            return this;
        }
        int[] arrn3 = this.b;
        arrn = arrn.b;
        if (arrn3.length <= arrn.length) {
            arrn2 = arrn;
            arrn = arrn3;
            arrn3 = arrn2;
        }
        arrn2 = new int[arrn3.length];
        int n2 = arrn3.length - arrn.length;
        System.arraycopy(arrn3, 0, arrn2, 0, n2);
        int n3 = n2;
        while (n3 < arrn3.length) {
            arrn2[n3] = this.a.b(arrn[n3 - n2], arrn3[n3]);
            ++n3;
        }
        return new c(this.a, arrn2);
    }

    public final boolean a() {
        boolean bl2 = false;
        if (this.b[0] == 0) {
            bl2 = true;
        }
        return bl2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final int b(int n2) {
        int n3;
        int n4 = 0;
        if (n2 == 0) {
            return this.a(0);
        }
        int n5 = this.b.length;
        if (n2 == 1) {
            int[] arrn = this.b;
            int n6 = arrn.length;
            n2 = 0;
            do {
                n3 = n2;
                if (n4 >= n6) return n3;
                n3 = arrn[n4];
                n2 = this.a.b(n2, n3);
                ++n4;
            } while (true);
        }
        n4 = this.b[0];
        int n7 = 1;
        do {
            n3 = n4;
            if (n7 >= n5) return n3;
            n4 = this.a.b(this.a.d(n2, n4), this.b[n7]);
            ++n7;
        } while (true);
    }

    public final c b() {
        int n2 = this.b.length;
        int[] arrn = new int[n2];
        for (int i2 = 0; i2 < n2; ++i2) {
            arrn[i2] = this.a.c(0, this.b[i2]);
        }
        return new c(this.a, arrn);
    }

    public final c b(c c2) {
        if (!this.a.equals(c2.a)) {
            throw new IllegalArgumentException("ModulusPolys do not have same ModulusGF field");
        }
        if (c2.a()) {
            return this;
        }
        return this.a(c2.b());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final c c(int n2) {
        if (n2 == 0) {
            return this.a.d;
        }
        int[] arrn = this;
        if (n2 == 1) return arrn;
        int n3 = this.b.length;
        arrn = new int[n3];
        int n4 = 0;
        while (n4 < n3) {
            arrn[n4] = this.a.d(this.b[n4], n2);
            ++n4;
        }
        return new c(this.a, arrn);
    }

    public final c c(c arrn) {
        if (!this.a.equals(arrn.a)) {
            throw new IllegalArgumentException("ModulusPolys do not have same ModulusGF field");
        }
        if (this.a() || arrn.a()) {
            return this.a.d;
        }
        int[] arrn2 = this.b;
        int n2 = arrn2.length;
        arrn = arrn.b;
        int n3 = arrn.length;
        int[] arrn3 = new int[n2 + n3 - 1];
        for (int i2 = 0; i2 < n2; ++i2) {
            int n4 = arrn2[i2];
            for (int i3 = 0; i3 < n3; ++i3) {
                arrn3[i2 + i3] = this.a.b(arrn3[i2 + i3], this.a.d(n4, arrn[i3]));
            }
        }
        return new c(this.a, arrn3);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder((this.b.length - 1) * 8);
        int n2 = this.b.length - 1;
        while (n2 >= 0) {
            int n3 = this.a(n2);
            if (n3 != 0) {
                int n4;
                if (n3 < 0) {
                    stringBuilder.append(" - ");
                    n4 = - n3;
                } else {
                    n4 = n3;
                    if (stringBuilder.length() > 0) {
                        stringBuilder.append(" + ");
                        n4 = n3;
                    }
                }
                if (n2 == 0 || n4 != 1) {
                    stringBuilder.append(n4);
                }
                if (n2 != 0) {
                    if (n2 == 1) {
                        stringBuilder.append('x');
                    } else {
                        stringBuilder.append("x^");
                        stringBuilder.append(n2);
                    }
                }
            }
            --n2;
        }
        return stringBuilder.toString();
    }
}

