/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a;

import com.google.c.f.a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

final class b {
    private final Map<Integer, Integer> a = new HashMap<Integer, Integer>();

    b() {
    }

    final void a(int n2) {
        Integer n3;
        Integer n4 = n3 = this.a.get(n2);
        if (n3 == null) {
            n4 = 0;
        }
        int n5 = n4;
        this.a.put(n2, n5 + 1);
    }

    final int[] a() {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        Iterator<Map.Entry<Integer, Integer>> iterator = this.a.entrySet().iterator();
        int n2 = -1;
        while (iterator.hasNext()) {
            Map.Entry<Integer, Integer> entry = iterator.next();
            if (entry.getValue() > n2) {
                n2 = entry.getValue();
                arrayList.clear();
                arrayList.add(entry.getKey());
                continue;
            }
            if (entry.getValue() != n2) continue;
            arrayList.add(entry.getKey());
        }
        return a.a(arrayList);
    }
}

