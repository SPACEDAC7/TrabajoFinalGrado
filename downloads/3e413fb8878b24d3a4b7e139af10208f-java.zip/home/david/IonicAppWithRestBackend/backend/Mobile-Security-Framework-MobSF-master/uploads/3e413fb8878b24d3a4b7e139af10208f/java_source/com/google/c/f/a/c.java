/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a;

import com.google.c.b.b;
import com.google.c.j;
import com.google.c.p;

final class c {
    b a;
    p b;
    p c;
    p d;
    p e;
    int f;
    int g;
    int h;
    int i;

    c(b b2, p p2, p p3, p p4, p p5) {
        if (p2 == null && p4 == null || p3 == null && p5 == null || p2 != null && p3 == null || p4 != null && p5 == null) {
            throw j.a();
        }
        this.a(b2, p2, p3, p4, p5);
    }

    c(c c2) {
        this.a(c2.a, c2.b, c2.c, c2.d, c2.e);
    }

    private void a(b b2, p p2, p p3, p p4, p p5) {
        this.a = b2;
        this.b = p2;
        this.c = p3;
        this.d = p4;
        this.e = p5;
        this.a();
    }

    /*
     * Enabled aggressive block sorting
     */
    final void a() {
        if (this.b == null) {
            this.b = new p(0.0f, this.d.b);
            this.c = new p(0.0f, this.e.b);
        } else if (this.d == null) {
            this.d = new p(this.a.a - 1, this.b.b);
            this.e = new p(this.a.a - 1, this.c.b);
        }
        this.f = (int)Math.min(this.b.a, this.c.a);
        this.g = (int)Math.max(this.d.a, this.e.a);
        this.h = (int)Math.min(this.b.b, this.d.b);
        this.i = (int)Math.max(this.c.b, this.e.b);
    }
}

