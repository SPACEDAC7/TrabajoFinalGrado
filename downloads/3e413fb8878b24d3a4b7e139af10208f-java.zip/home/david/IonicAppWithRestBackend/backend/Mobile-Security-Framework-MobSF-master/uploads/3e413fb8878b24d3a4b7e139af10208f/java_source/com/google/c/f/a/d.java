/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a;

final class d {
    final int a;
    final int b;
    final int c;
    final int d;
    int e = -1;

    d(int n2, int n3, int n4, int n5) {
        this.a = n2;
        this.b = n3;
        this.c = n4;
        this.d = n5;
    }

    final boolean a() {
        return this.a(this.e);
    }

    final boolean a(int n2) {
        if (n2 != -1 && this.c == n2 % 3 * 3) {
            return true;
        }
        return false;
    }

    final void b() {
        this.e = this.d / 30 * 3 + this.c / 3;
    }

    final int c() {
        return this.b - this.a;
    }

    public final String toString() {
        return "" + this.e + "|" + this.d;
    }
}

