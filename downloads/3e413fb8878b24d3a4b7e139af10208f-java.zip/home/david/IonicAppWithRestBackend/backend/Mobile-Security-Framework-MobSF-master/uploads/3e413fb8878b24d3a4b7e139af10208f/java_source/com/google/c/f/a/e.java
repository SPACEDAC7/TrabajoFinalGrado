/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a;

import com.google.c.f.c;
import com.google.c.g;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;

final class e {
    private static final char[] a;
    private static final char[] b;
    private static final BigInteger[] c;

    static {
        Object object;
        a = new char[]{';', '<', '>', '@', '[', '\\', ']', '_', '`', '~', '!', '\r', '\t', ',', ':', '\n', '-', '.', '$', '/', '\"', '|', '*', '(', ')', '?', '{', '}', '\''};
        b = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '&', '\r', '\t', ',', ':', '#', '-', '.', '$', '/', '+', '%', '*', '=', '^'};
        c = object = new BigInteger[16];
        object[0] = BigInteger.ONE;
        e.c[1] = object = BigInteger.valueOf(900);
        for (int i2 = 2; i2 < c.length; ++i2) {
            e.c[i2] = c[i2 - 1].multiply((BigInteger)object);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int a(int n2, int[] arrn, int n3, StringBuilder stringBuilder) {
        int n4;
        if (n2 == 901) {
            int n5 = 0;
            long l2 = 0;
            char[] arrc = new char[6];
            int[] arrn2 = new int[6];
            int n6 = 0;
            n2 = n3 + 1;
            n4 = arrn[n3];
            n3 = n5;
            do {
                if (n2 < arrn[0] && n6 == 0) {
                    n5 = n3 + 1;
                    arrn2[n3] = n4;
                    l2 = l2 * 900 + (long)n4;
                    n3 = n2 + 1;
                    n4 = arrn[n2];
                    if (n4 == 900 || n4 == 901 || n4 == 902 || n4 == 924 || n4 == 928 || n4 == 923 || n4 == 922) {
                        n2 = n3 - 1;
                        n6 = 1;
                        n3 = n5;
                        continue;
                    }
                    if (n5 % 5 == 0 && n5 > 0) {
                        for (n2 = 0; n2 < 6; ++n2, l2 >>= 8) {
                            arrc[5 - n2] = (char)(l2 % 256);
                        }
                        stringBuilder.append(arrc);
                        n5 = 0;
                        n2 = n3;
                        n3 = n5;
                        continue;
                    }
                } else {
                    n6 = n3;
                    if (n2 == arrn[0]) {
                        n6 = n3;
                        if (n4 < 900) {
                            arrn2[n3] = n4;
                            n6 = n3 + 1;
                        }
                    }
                    n3 = 0;
                    while (n3 < n6) {
                        stringBuilder.append((char)arrn2[n3]);
                        ++n3;
                    }
                    return n2;
                }
                n2 = n3;
                n3 = n5;
            } while (true);
        }
        n4 = n3;
        if (n2 != 924) return n4;
        n2 = 0;
        long l3 = 0;
        int n7 = 0;
        int n8 = n3;
        n3 = n2;
        do {
            int n9;
            long l4;
            n4 = n8;
            if (n8 >= arrn[0]) return n4;
            n4 = n8;
            if (n7 != 0) return n4;
            n2 = n8 + 1;
            if ((n8 = arrn[n8]) < 900) {
                n9 = n3 + 1;
                l4 = l3 * 900 + (long)n8;
                n4 = n7;
            } else if (n8 == 900 || n8 == 901 || n8 == 902 || n8 == 924 || n8 == 928 || n8 == 923 || n8 == 922) {
                --n2;
                n4 = 1;
                l4 = l3;
                n9 = n3;
            } else {
                l4 = l3;
                n4 = n7;
                n9 = n3;
            }
            l3 = l4;
            n7 = n4;
            n3 = n9;
            n8 = n2;
            if (n9 % 5 != 0) continue;
            l3 = l4;
            n7 = n4;
            n3 = n9;
            n8 = n2;
            if (n9 <= 0) continue;
            char[] arrc = new char[6];
            l3 = l4;
            for (n3 = 0; n3 < 6; ++n3, l3 >>= 8) {
                arrc[5 - n3] = (char)(255 & l3);
            }
            stringBuilder.append(arrc);
            n3 = 0;
            n7 = n4;
            n8 = n2;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int a(int[] arrn, int n2, c c2) {
        int n3;
        if (n2 + 2 > arrn[0]) {
            throw g.a();
        }
        int[] arrn2 = new int[2];
        for (n3 = 0; n3 < 2; ++n3, ++n2) {
            arrn2[n3] = arrn[n2];
        }
        c2.a = Integer.parseInt(e.a(arrn2, 2));
        arrn2 = new StringBuilder();
        n3 = e.a(arrn, n2, (StringBuilder)arrn2);
        c2.b = arrn2.toString();
        if (arrn[n3] != 923) {
            n2 = n3;
            if (arrn[n3] != 922) return n2;
            {
                c2.d = true;
                return n3 + 1;
            }
        } else {
            n2 = n3 + 1;
            arrn2 = new int[arrn[0] - n2];
            n3 = 0;
            boolean bl2 = false;
            while (n2 < arrn[0] && !bl2) {
                int n4 = n2 + 1;
                if ((n2 = arrn[n2]) < 900) {
                    arrn2[n3] = n2;
                    ++n3;
                    n2 = n4;
                    continue;
                }
                switch (n2) {
                    default: {
                        throw g.a();
                    }
                    case 922: 
                }
                c2.d = true;
                n2 = n4 + 1;
                bl2 = true;
            }
            c2.c = Arrays.copyOf(arrn2, n3);
        }
        return n2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int a(int[] var0, int var1_1, StringBuilder var2_2) {
        var5_3 = new int[var0[0] - var1_1 << 1];
        var6_4 = new int[var0[0] - var1_1 << 1];
        var10_5 = 0;
        var7_6 = 0;
        var8_7 = var1_1;
        block13 : while (var8_7 < var0[0] && var7_6 == 0) {
            var1_1 = var8_7 + 1;
            if ((var8_7 = var0[var8_7]) < 900) {
                var5_3[var10_5] = var8_7 / 30;
                var5_3[var10_5 + 1] = var8_7 % 30;
                var10_5 += 2;
                var8_7 = var1_1;
                continue;
            }
            switch (var8_7) {
                default: {
                    var8_7 = var1_1;
                    continue block13;
                }
                case 900: {
                    var5_3[var10_5] = 900;
                    ++var10_5;
                    var8_7 = var1_1;
                    continue block13;
                }
                case 901: 
                case 902: 
                case 922: 
                case 923: 
                case 924: 
                case 928: {
                    var8_7 = var1_1 - 1;
                    var7_6 = 1;
                    continue block13;
                }
                case 913: 
            }
            var5_3[var10_5] = 913;
            var8_7 = var1_1 + 1;
            var6_4[var10_5] = var0[var1_1];
            ++var10_5;
        }
        var1_1 = a.a;
        var7_6 = a.a;
        var11_8 = 0;
        while (var11_8 < var10_5) {
            var12_12 = var5_3[var11_8];
            var4_10 = 0;
            switch (.a[var1_1 - 1]) {
                default: {
                    var9_11 = var7_6;
                    var3_9 = var4_10;
                    ** GOTO lbl229
                }
                case 1: {
                    if (var12_12 < 26) {
                        var3_9 = (char)(var12_12 + 65);
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 26) {
                        var3_9 = 32;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 27) {
                        var1_1 = a.b;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 28) {
                        var1_1 = a.c;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 29) {
                        var7_6 = a.f;
                        var3_9 = var4_10;
                        var9_11 = var1_1;
                        var1_1 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 913) {
                        var2_2.append((char)var6_4[var11_8]);
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    var3_9 = var4_10;
                    var9_11 = var7_6;
                    if (var12_12 == 900) {
                        var1_1 = a.a;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    ** GOTO lbl229
                }
                case 2: {
                    if (var12_12 < 26) {
                        var3_9 = (char)(var12_12 + 97);
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 26) {
                        var3_9 = 32;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 27) {
                        var7_6 = a.e;
                        var3_9 = var4_10;
                        var9_11 = var1_1;
                        var1_1 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 28) {
                        var1_1 = a.c;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 29) {
                        var7_6 = a.f;
                        var3_9 = var4_10;
                        var9_11 = var1_1;
                        var1_1 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 913) {
                        var2_2.append((char)var6_4[var11_8]);
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    var3_9 = var4_10;
                    var9_11 = var7_6;
                    if (var12_12 == 900) {
                        var1_1 = a.a;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    ** GOTO lbl229
                }
                case 3: {
                    if (var12_12 < 25) {
                        var3_9 = e.b[var12_12];
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 25) {
                        var1_1 = a.d;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 26) {
                        var3_9 = 32;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 27) {
                        var1_1 = a.b;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 28) {
                        var1_1 = a.a;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 29) {
                        var7_6 = a.f;
                        var3_9 = var4_10;
                        var9_11 = var1_1;
                        var1_1 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 913) {
                        var2_2.append((char)var6_4[var11_8]);
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    var3_9 = var4_10;
                    var9_11 = var7_6;
                    if (var12_12 == 900) {
                        var1_1 = a.a;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    ** GOTO lbl229
                }
                case 4: {
                    if (var12_12 < 29) {
                        var3_9 = e.a[var12_12];
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 29) {
                        var1_1 = a.a;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 913) {
                        var2_2.append((char)var6_4[var11_8]);
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    var3_9 = var4_10;
                    var9_11 = var7_6;
                    if (var12_12 == 900) {
                        var1_1 = a.a;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    ** GOTO lbl229
                }
                case 5: {
                    if (var12_12 < 26) {
                        var3_9 = (char)(var12_12 + 65);
                        var1_1 = var7_6;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 26) {
                        var3_9 = 32;
                        var1_1 = var7_6;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 != 900) break;
                    var1_1 = a.a;
                    var3_9 = var4_10;
                    var9_11 = var7_6;
                    ** break;
                }
                case 6: {
                    if (var12_12 < 29) {
                        var3_9 = e.a[var12_12];
                        var1_1 = var7_6;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 29) {
                        var1_1 = a.a;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 == 913) {
                        var2_2.append((char)var6_4[var11_8]);
                        var1_1 = var7_6;
                        var3_9 = var4_10;
                        var9_11 = var7_6;
                        ** break;
                    }
                    if (var12_12 != 900) break;
                    var1_1 = a.a;
                    var3_9 = var4_10;
                    var9_11 = var7_6;
                    ** break;
lbl225: // 33 sources:
                    ** GOTO lbl229
                }
            }
            var1_1 = var7_6;
            var3_9 = var4_10;
            var9_11 = var7_6;
lbl229: // 7 sources:
            if (var3_9 != 0) {
                var2_2.append((char)var3_9);
            }
            ++var11_8;
            var7_6 = var9_11;
        }
        return var8_7;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static com.google.c.b.e a(int[] var0, String var1_1) {
        var3_2 = new StringBuilder(var0.length << 1);
        var5_3 = 2;
        var4_4 = var0[1];
        var2_5 = new c();
        block7 : while (var5_3 < var0[0]) {
            switch (var4_4) {
                default: {
                    var4_4 = e.a((int[])var0, var5_3 - 1, var3_2);
                    ** GOTO lbl21
                }
                case 900: {
                    var4_4 = e.a((int[])var0, (int)var5_3, var3_2);
                    ** GOTO lbl21
                }
                case 901: 
                case 913: 
                case 924: {
                    var4_4 = e.a((int)var4_4, (int[])var0, (int)var5_3, var3_2);
                    ** GOTO lbl21
                }
                case 902: {
                    var4_4 = e.b((int[])var0, (int)var5_3, var3_2);
                    ** GOTO lbl21
                }
                case 928: {
                    var4_4 = e.a((int[])var0, (int)var5_3, var2_5);
lbl21: // 5 sources:
                    if (var4_4 >= var0.length) throw g.a();
                    var5_3 = var4_4 + true;
                    var4_4 = var0[var4_4];
                    continue block7;
                }
                case 922: 
                case 923: 
            }
            throw g.a();
        }
        if (var3_2.length() == 0) {
            throw g.a();
        }
        var0 = new com.google.c.b.e(null, var3_2.toString(), null, var1_1);
        var0.g = var2_5;
        return var0;
    }

    private static String a(int[] object, int n2) {
        BigInteger bigInteger = BigInteger.ZERO;
        for (int i2 = 0; i2 < n2; ++i2) {
            bigInteger = bigInteger.add(c[n2 - i2 - 1].multiply(BigInteger.valueOf((long)object[i2])));
        }
        object = bigInteger.toString();
        if (object.charAt(0) != '1') {
            throw g.a();
        }
        return object.substring(1);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int b(int[] arrn, int n2, StringBuilder stringBuilder) {
        int[] arrn2 = new int[15];
        boolean bl2 = false;
        int n3 = 0;
        int n4 = n2;
        while (n4 < arrn[0] && !bl2) {
            int n5;
            n2 = n4 + 1;
            n4 = arrn[n4];
            boolean bl3 = bl2;
            if (n2 == arrn[0]) {
                bl3 = true;
            }
            if (n4 < 900) {
                arrn2[n3] = n4;
                n5 = n3 + 1;
            } else if (n4 == 900 || n4 == 901 || n4 == 924 || n4 == 928 || n4 == 923 || n4 == 922) {
                --n2;
                bl3 = true;
                n5 = n3;
            } else {
                n5 = n3;
            }
            if (n5 % 15 != 0 && n4 != 902) {
                bl2 = bl3;
                n3 = n5;
                n4 = n2;
                if (!bl3) continue;
            }
            stringBuilder.append(e.a(arrn2, n5));
            n3 = 0;
            bl2 = bl3;
            n4 = n2;
        }
        return n4;
    }

    static final class a
    extends Enum<a> {
        public static final /* enum */ int a = 1;
        public static final /* enum */ int b = 2;
        public static final /* enum */ int c = 3;
        public static final /* enum */ int d = 4;
        public static final /* enum */ int e = 5;
        public static final /* enum */ int f = 6;
        private static final /* synthetic */ int[] g;

        static {
            g = new int[]{a, b, c, d, e, f};
        }

        public static int[] a() {
            return (int[])g.clone();
        }
    }

}

