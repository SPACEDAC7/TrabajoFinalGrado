/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a;

import com.google.c.f.a.a;
import com.google.c.f.a.c;
import com.google.c.f.a.d;
import com.google.c.f.a.g;
import com.google.c.f.a.h;
import com.google.c.p;
import java.util.Formatter;

final class f {
    final a a;
    final g[] b;
    c c;
    final int d;

    f(a a2, c c2) {
        this.a = a2;
        this.d = a2.a;
        this.c = c2;
        this.b = new g[this.d + 2];
    }

    /*
     * Enabled aggressive block sorting
     */
    static int a(int n2, int n3, d d2) {
        if (d2 == null || d2.a()) {
            return n3;
        }
        if (d2.a(n2)) {
            d2.e = n2;
            return 0;
        }
        return n3 + 1;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final void a(g var1_1) {
        block15 : {
            block14 : {
                if (var1_1 == null) return;
                var5_2 = (h)var1_1;
                var3_3 = this.a;
                var4_4 = var5_2.b;
                for (d var2_7 : var5_2.b) {
                    if (var2_7 == null) continue;
                    var2_7.b();
                }
                var5_2.a(var4_4, var3_3);
                var2_8 = var5_2.a;
                var1_1 = var5_2.c != false ? var2_8.b : var2_8.d;
                if (var5_2.c) {
                    var2_9 = var2_8.c;
                } else {
                    var2_11 = var2_8.e;
                }
                var10_12 = var5_2.b((int)var1_1.b);
                var13_13 = var5_2.b((int)var2_10.b);
                var7_5 = -1;
                var6_6 = 1;
                var8_14 = 0;
                block1 : while (var10_12 < var13_13) {
                    if (var4_4[var10_12] != null) {
                        var1_1 = var4_4[var10_12];
                        var11_16 = var1_1.e - var7_5;
                        if (var11_16 == 0) {
                            ++var8_14;
                        } else if (var11_16 == 1) {
                            var6_6 = Math.max(var6_6, var8_14);
                            var8_14 = 1;
                            var7_5 = var1_1.e;
                        } else {
                            if (var11_16 >= 0 && var1_1.e < var3_3.e && var11_16 <= var10_12) {
                                if (var6_6 > 2) {
                                    var11_16 *= var6_6 - 2;
                                }
                                var9_15 = var11_16 >= var10_12;
                                break block14;
                            }
                            var4_4[var10_12] = null;
                        }
                    }
lbl39: // 7 sources:
                    do {
                        ++var10_12;
                        continue block1;
                        break;
                    } while (true);
                }
                return;
            }
            for (var12_17 = 1; var12_17 <= var11_16; ++var12_17) {
                if (!var9_15) {
                    var9_15 = var4_4[var10_12 - var12_17] != null;
                    continue;
                }
                if (!var9_15) break block15;
            }
            var4_4[var10_12] = null;
            ** GOTO lbl39
        }
        var7_5 = var1_1.e;
        var8_14 = 1;
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String toString() {
        Object object;
        Object object2 = object = this.b[0];
        if (object == null) {
            object2 = this.b[this.d + 1];
        }
        object = new Formatter();
        int n2 = 0;
        do {
            if (n2 >= object2.b.length) {
                object2 = object.toString();
                object.close();
                return object2;
            }
            object.format("CW %3d:", n2);
            for (int i2 = 0; i2 < this.d + 2; ++i2) {
                if (this.b[i2] == null) {
                    object.format("    |   ", new Object[0]);
                    continue;
                }
                d d2 = this.b[i2].b[n2];
                if (d2 == null) {
                    object.format("    |   ", new Object[0]);
                    continue;
                }
                object.format(" %3d|%3d", d2.e, d2.d);
            }
            object.format("%n", new Object[0]);
            ++n2;
        } while (true);
    }
}

