/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a;

import com.google.c.f.a.c;
import com.google.c.f.a.d;
import java.util.Formatter;

class g {
    final c a;
    final d[] b;

    g(c c2) {
        this.a = new c(c2);
        this.b = new d[c2.i - c2.h + 1];
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final d a(int n2) {
        d d2 = this.c(n2);
        if (d2 != null) {
            return d2;
        }
        int n3 = 1;
        while (n3 < 5) {
            d d3;
            int n4 = this.b(n2) - n3;
            if (n4 >= 0) {
                d2 = d3 = this.b[n4];
                if (d3 != null) return d2;
            }
            if ((n4 = this.b(n2) + n3) < this.b.length) {
                d2 = d3 = this.b[n4];
                if (d3 != null) return d2;
            }
            ++n3;
        }
        return null;
    }

    final void a(int n2, d d2) {
        this.b[this.b((int)n2)] = d2;
    }

    final int b(int n2) {
        return n2 - this.a.h;
    }

    final d c(int n2) {
        return this.b[this.b(n2)];
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        Formatter formatter = new Formatter();
        Object object = this.b;
        int n2 = object.length;
        int n3 = 0;
        int n4 = 0;
        do {
            int n5;
            if (n3 >= n2) {
                object = formatter.toString();
                formatter.close();
                return object;
            }
            d d2 = object[n3];
            if (d2 == null) {
                n5 = n4 + 1;
                formatter.format("%3d:    |   %n", n4);
                n4 = n5;
            } else {
                n5 = n4 + 1;
                formatter.format("%3d: %3d|%3d%n", n4, d2.e, d2.d);
                n4 = n5;
            }
            ++n3;
        } while (true);
    }
}

