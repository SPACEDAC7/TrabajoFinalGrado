/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a;

import com.google.c.f.a.a;
import com.google.c.f.a.b;
import com.google.c.f.a.c;
import com.google.c.f.a.d;
import com.google.c.f.a.g;

final class h
extends g {
    final boolean c;

    h(c c2, boolean bl2) {
        super(c2);
        this.c = bl2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final a a() {
        var1_1 = this.b;
        var2_2 = new b();
        var3_3 = new b();
        var4_4 = new b();
        var5_5 = new b();
        var10_6 = var1_1.length;
        block5 : for (var7_7 = 0; var7_7 < var10_6; ++var7_7) {
            var6_8 = var1_1[var7_7];
            if (var6_8 == null) continue;
            var6_8.b();
            var11_11 = var6_8.d % 30;
            var8_9 = var9_10 = var6_8.e;
            if (!this.c) {
                var8_9 = var9_10 + 2;
            }
            switch (var8_9 % 3) {
                case 0: {
                    var3_3.a(var11_11 * 3 + 1);
                    ** break;
                }
                case 1: {
                    var5_5.a(var11_11 / 3);
                    var4_4.a(var11_11 % 3);
                }
lbl22: // 3 sources:
                default: {
                    continue block5;
                }
                case 2: 
            }
            var2_2.a(var11_11 + 1);
        }
        if (var2_2.a().length == 0) return null;
        if (var3_3.a().length == 0) return null;
        if (var4_4.a().length == 0) return null;
        if (var5_5.a().length == 0) return null;
        if (var2_2.a()[0] <= 0) return null;
        if (var3_3.a()[0] + var4_4.a()[0] < 3) return null;
        if (var3_3.a()[0] + var4_4.a()[0] > 90) {
            return null;
        }
        var2_2 = new a(var2_2.a()[0], var3_3.a()[0], var4_4.a()[0], var5_5.a()[0]);
        this.a(var1_1, (a)var2_2);
        return var2_2;
    }

    /*
     * Enabled aggressive block sorting
     */
    final void a(d[] arrd, a a2) {
        int n2 = 0;
        while (n2 < arrd.length) {
            d d2 = arrd[n2];
            if (arrd[n2] != null) {
                int n3 = d2.d % 30;
                int n4 = d2.e;
                if (n4 > a2.e) {
                    arrd[n2] = null;
                } else {
                    int n5 = n4;
                    if (!this.c) {
                        n5 = n4 + 2;
                    }
                    switch (n5 % 3) {
                        default: {
                            break;
                        }
                        case 0: {
                            if (n3 * 3 + 1 == a2.c) break;
                            arrd[n2] = null;
                            break;
                        }
                        case 1: {
                            if (n3 / 3 == a2.b && n3 % 3 == a2.d) break;
                            arrd[n2] = null;
                            break;
                        }
                        case 2: {
                            if (n3 + 1 == a2.a) break;
                            arrd[n2] = null;
                        }
                    }
                }
            }
            ++n2;
        }
    }

    @Override
    public final String toString() {
        return "IsLeft: " + this.c + '\n' + super.toString();
    }
}

