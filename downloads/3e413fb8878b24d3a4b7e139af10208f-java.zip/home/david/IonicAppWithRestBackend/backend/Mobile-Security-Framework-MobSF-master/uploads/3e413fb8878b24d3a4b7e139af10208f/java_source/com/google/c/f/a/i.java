/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a;

import com.google.c.f.a;
import java.lang.reflect.Array;

final class i {
    private static final float[][] a;

    static {
        int n2 = a.a.length;
        a = (float[][])Array.newInstance(Float.TYPE, n2, 8);
        for (n2 = 0; n2 < a.a.length; ++n2) {
            int n3 = a.a[n2];
            int n4 = n3 & 1;
            for (int i2 = 0; i2 < 8; ++i2) {
                float f2 = 0.0f;
                while ((n3 & 1) == n4) {
                    f2 += 1.0f;
                    n3 >>= 1;
                }
                n4 = n3 & 1;
                i.a[n2][8 - i2 - 1] = f2 / 17.0f;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static int a(int[] arrn) {
        float f2;
        int n2;
        int n3;
        float f3;
        float f4 = a.a(arrn);
        int[] arrn2 = new int[8];
        int n4 = 0;
        int n5 = 0;
        for (n2 = 0; n2 < 17; ++n2) {
            f3 = f4 / 34.0f;
            f2 = (float)n2 * f4 / 17.0f;
            int n6 = n4;
            n3 = n5;
            if ((float)(arrn[n5] + n4) <= f3 + f2) {
                n6 = n4 + arrn[n5];
                n3 = n5 + 1;
            }
            arrn2[n3] = arrn2[n3] + 1;
            n4 = n6;
            n5 = n3;
        }
        long l2 = 0;
        n2 = 0;
        do {
            if (n2 < 8) {
            } else {
                n2 = n5 = (int)l2;
                if (a.a(n5) == -1) {
                    n2 = -1;
                }
                if (n2 != -1) {
                    return n2;
                }
                n5 = a.a(arrn);
                arrn2 = new float[8];
                for (n2 = 0; n2 < 8; ++n2) {
                    arrn2[n2] = (int)((float)arrn[n2] / (float)n5);
                }
                break;
            }
            for (n5 = 0; n5 < arrn2[n2]; ++n5) {
                n3 = n2 % 2 == 0 ? 1 : 0;
                l2 = l2 << 1 | (long)n3;
            }
            ++n2;
        } while (true);
        f4 = Float.MAX_VALUE;
        n2 = -1;
        n5 = 0;
        do {
            n3 = n2;
            if (n5 >= a.length) return n3;
            f3 = 0.0f;
            arrn = a[n5];
            n3 = 0;
            do {
                f2 = f3;
                if (n3 >= 8) break;
                f2 = arrn[n3] - arrn2[n3];
                f2 = f3 += f2 * f2;
                if (f3 >= f4) break;
                ++n3;
            } while (true);
            if (f2 < f4) {
                n2 = a.a[n5];
            } else {
                f2 = f4;
            }
            ++n5;
            f4 = f2;
        } while (true);
    }
}

