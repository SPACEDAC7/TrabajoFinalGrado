/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.a;

import com.google.c.b.e;
import com.google.c.f.a;
import com.google.c.f.a.b;
import com.google.c.f.a.c;
import com.google.c.f.a.d;
import com.google.c.f.a.f;
import com.google.c.f.a.h;
import com.google.c.f.a.i;
import com.google.c.g;
import com.google.c.p;
import java.lang.reflect.Array;
import java.util.ArrayList;

public final class j {
    private static final com.google.c.f.a.a.a a = new com.google.c.f.a.a.a();

    /*
     * Exception decompiling
     */
    private static e a(int var0, int[] var1_1, int[] var2_2, int[] var3_3, int[][] var4_4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 14[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static e a(com.google.c.b.b var0, p var1_1, p var2_2, p var3_3, p var4_4, int var5_5, int var6_6) {
        block77 : {
            block76 : {
                block75 : {
                    block74 : {
                        block73 : {
                            var9_7 = new c((com.google.c.b.b)var0, (p)var1_1, (p)var2_2, (p)var3_3, (p)var4_4);
                            var2_2 = null;
                            var7_9 = null;
                            var4_4 = null;
                            for (var11_8 = 0; var11_8 < 2; ++var11_8) {
                                if (var1_1 != null) {
                                    var4_4 = j.a((com.google.c.b.b)var0, var9_7, (p)var1_1, true, var5_5, var6_6);
                                }
                                var7_9 = var3_3 != null ? j.a((com.google.c.b.b)var0, var9_7, (p)var3_3, false, var5_5, var6_6) : var2_2;
                                if (var4_4 == null && var7_9 == null) {
                                    var2_2 = null;
                                } else {
                                    if (var4_4 == null || (var2_2 = var4_4.a()) == null) {
                                        var2_2 = var7_9 == null ? null : var7_9.a();
                                    } else if (var7_9 != null && (var8_10 = var7_9.a()) != null && var2_2.a != var8_10.a && var2_2.b != var8_10.b && var2_2.e != var8_10.e) {
                                        var2_2 = null;
                                    }
                                    if (var2_2 == null) {
                                        var2_2 = null;
                                    } else {
                                        var8_10 = j.a((h)var4_4);
                                        var10_11 = j.a((h)var7_9);
                                        if (var8_10 == null) {
                                            var8_10 = var10_11;
                                        } else if (var10_11 != null) {
                                            var8_10 = new c(var8_10.a, var8_10.b, var8_10.c, var10_11.d, var10_11.e);
                                        }
                                        var2_2 = new f((com.google.c.f.a.a)var2_2, (c)var8_10);
                                    }
                                }
                                if (var2_2 == null) {
                                    throw com.google.c.j.a();
                                }
                                if (var11_8 == 0 && var2_2.c != null && (var2_2.c.h < var9_7.h || var2_2.c.i > var9_7.i)) {
                                    var9_7 = var2_2.c;
                                    var8_10 = var7_9;
                                    var7_9 = var2_2;
                                    var2_2 = var8_10;
                                    continue;
                                }
                                var2_2.c = var9_7;
                                var1_1 = var2_2;
                                break block73;
                            }
                            var1_1 = var7_9;
                            var7_9 = var2_2;
                        }
                        var19_12 = var1_1.d + 1;
                        var1_1.b[0] = var4_4;
                        var1_1.b[var19_12] = var7_9;
                        var21_13 = var4_4 != null;
                        var11_8 = 1;
                        var12_14 = var6_6;
                        var6_6 = var11_8;
                        var14_15 = var5_5;
                        block1 : do {
                            if (var6_6 > var19_12) ** GOTO lbl62
                            var11_8 = var21_13 != false ? var6_6 : var19_12 - var6_6;
                            var5_5 = var14_15;
                            var15_17 = var12_14;
                            if (var1_1.b[var11_8] != null) ** GOTO lbl-1000
                            if (var11_8 == 0 || var11_8 == var19_12) {
                                var22_22 = var11_8 == 0;
                                var2_2 = new h(var9_7, var22_22);
                            } else {
                                var2_2 = new com.google.c.f.a.g(var9_7);
                            }
                            ** GOTO lbl64
lbl62: // 1 sources:
                            var3_3 = (b[][])Array.newInstance(b.class, new int[]{var1_1.a.e, var1_1.d + 2});
                            break block74;
lbl64: // 2 sources:
                            var1_1.b[var11_8] = var2_2;
                            var13_16 = -1;
                            var16_19 = var9_7.h;
                            block2 : do {
                                var5_5 = var14_15;
                                var15_17 = var12_14;
                                if (var16_19 <= var9_7.i) {
                                    var5_5 = var21_13 != false ? 1 : -1;
                                    var3_3 = null;
                                    if (j.a((f)var1_1, var11_8 - var5_5) && (var3_3 = var1_1.b[var11_8 - var5_5].c(var16_19)) != null) {
                                        var5_5 = var21_13 ? var3_3.b : var3_3.a;
                                    } else {
                                        var3_3 = var1_1.b[var11_8].a(var16_19);
                                        if (var3_3 != null) {
                                            var5_5 = var21_13 ? var3_3.a : var3_3.b;
                                        } else {
                                            if (j.a((f)var1_1, var11_8 - var5_5)) {
                                                var3_3 = var1_1.b[var11_8 - var5_5].a(var16_19);
                                            }
                                            if (var3_3 == null) break block1;
                                            var5_5 = var21_13 ? var3_3.b : var3_3.a;
                                        }
                                    }
                                } else lbl-1000: // 2 sources:
                                {
                                    ++var6_6;
                                    var14_15 = var5_5;
                                    var12_14 = var15_17;
                                    continue block1;
                                }
lbl89: // 6 sources:
                                do {
                                    if (var5_5 < 0) ** GOTO lbl93
                                    var15_17 = var5_5;
                                    if (var5_5 <= var9_7.g) ** GOTO lbl98
lbl93: // 2 sources:
                                    var18_20 = var14_15;
                                    var17_18 = var12_14;
                                    var5_5 = var13_16;
                                    if (var13_16 != -1) {
                                        var15_17 = var13_16;
lbl98: // 2 sources:
                                        var3_3 = j.a((com.google.c.b.b)var0, var9_7.f, var9_7.g, var21_13, var15_17, var16_19, var14_15, var12_14);
                                        var18_20 = var14_15;
                                        var17_18 = var12_14;
                                        var5_5 = var13_16;
                                        if (var3_3 != null) {
                                            var2_2.a(var16_19, (d)var3_3);
                                            var18_20 = Math.min(var14_15, var3_3.c());
                                            var17_18 = Math.max(var12_14, var3_3.c());
                                            var5_5 = var15_17;
                                        }
                                    }
                                    ++var16_19;
                                    var14_15 = var18_20;
                                    var12_14 = var17_18;
                                    var13_16 = var5_5;
                                    continue block2;
                                    break;
                                } while (true);
                                break;
                            } while (true);
                            break;
                        } while (true);
                        var15_17 = 0;
                        var17_18 = var11_8;
                        do {
                            if (!j.a((f)var1_1, var17_18 - var5_5)) ** GOTO lbl120
                            var18_20 = var17_18 - var5_5;
                            var3_3 = var1_1.b[var18_20].b;
                            var20_21 = var3_3.length;
                            ** GOTO lbl125
lbl120: // 1 sources:
                            if (!var21_13) ** GOTO lbl123
                            var5_5 = var1_1.c.f;
                            ** GOTO lbl89
lbl123: // 1 sources:
                            var5_5 = var1_1.c.g;
                            ** GOTO lbl89
lbl125: // 2 sources:
                            for (var17_18 = 0; var17_18 < var20_21; ++var17_18) {
                                var4_4 = var3_3[var17_18];
                                if (var4_4 == null) continue;
                                var17_18 = var21_13 != false ? var4_4.b : var4_4.a;
                                var5_5 = var17_18 + var15_17 * var5_5 * (var4_4.b - var4_4.a);
                                ** continue;
                            }
                            ++var15_17;
                            var17_18 = var18_20;
                        } while (true);
                    }
                    for (var5_5 = 0; var5_5 < var3_3.length; ++var5_5) {
                        for (var6_6 = 0; var6_6 < var3_3[var5_5].length; ++var6_6) {
                            var3_3[var5_5][var6_6] = new b();
                        }
                    }
                    var1_1.a(var1_1.b[0]);
                    var1_1.a(var1_1.b[var1_1.d + 1]);
                    var6_6 = 928;
                    block8 : do {
                        if (var1_1.b[0] == null || var1_1.b[var1_1.d + 1] == null) ** GOTO lbl150
                        var0 = var1_1.b[0].b;
                        var2_2 = var1_1.b[var1_1.d + 1].b;
                        var5_5 = 0;
                        do {
                            if (var5_5 < var0.length) ** GOTO lbl195
lbl150: // 2 sources:
                            if (var1_1.b[0] != null) break block8;
                            var11_8 = 0;
                            do {
                                if (var1_1.b[var1_1.d + 1] != null) break block75;
                                var13_16 = 0;
                                do {
                                    var14_15 = var11_8 + var13_16;
                                    if (var14_15 != 0) break block76;
                                    var5_5 = 0;
lbl159: // 2 sources:
                                    do {
                                        if (var5_5 > 0 && var5_5 < var6_6) {
                                            var6_6 = var5_5;
                                            continue block8;
                                        }
                                        var0 = var1_1.b;
                                        var12_14 = var0.length;
                                        var5_5 = 0;
                                        var6_6 = 0;
                                        do {
                                            if (var5_5 >= var12_14) ** GOTO lbl174
                                            var2_2 = var0[var5_5];
                                            if (var2_2 == null) ** GOTO lbl192
                                            var2_2 = var2_2.b;
                                            var13_16 = var2_2.length;
                                            ** GOTO lbl185
lbl174: // 1 sources:
                                            var0 = var3_3[0][1].a();
                                            var5_5 = var1_1.d * var1_1.a.e - (2 << var1_1.a.b);
                                            if (var0.length == 0) {
                                                if (var5_5 <= 0) throw com.google.c.j.a();
                                                if (var5_5 > 928) {
                                                    throw com.google.c.j.a();
                                                }
                                                var3_3[0][1].a(var5_5);
                                            } else if (var0[0] != var5_5) {
                                                var3_3[0][1].a(var5_5);
                                            }
                                            break block77;
lbl185: // 3 sources:
                                            for (var11_8 = 0; var11_8 < var13_16; ++var11_8) {
                                                var4_4 = var2_2[var11_8];
                                                if (var4_4 == null || (var14_15 = var4_4.e) < 0) continue;
                                                if (var14_15 >= var3_3.length) {
                                                    throw g.a();
                                                }
                                                var3_3[var14_15][var6_6].a(var4_4.d);
                                            }
lbl192: // 2 sources:
                                            ++var6_6;
                                            ++var5_5;
                                        } while (true);
                                        break;
                                    } while (true);
                                    break;
                                } while (true);
                                break;
                            } while (true);
lbl195: // 1 sources:
                            if (var0[var5_5] != null && var2_2[var5_5] != null && var0[var5_5].e == var2_2[var5_5].e) {
                                for (var11_8 = 1; var11_8 <= var1_1.d; ++var11_8) {
                                    var4_4 = var1_1.b[var11_8].b[var5_5];
                                    if (var4_4 == null) continue;
                                    var4_4.e = var0[var5_5].e;
                                    if (var4_4.a()) continue;
                                    var1_1.b[var11_8].b[var5_5] = null;
                                }
                            }
                            ++var5_5;
                        } while (true);
                        break;
                    } while (true);
                    var5_5 = 0;
                    var0 = var1_1.b[0].b;
                    var12_14 = 0;
                    do {
                        var11_8 = var5_5;
                        if (var12_14 >= var0.length) ** continue;
                        var11_8 = var5_5;
                        if (var0[var12_14] != null) {
                            var16_19 = var0[var12_14].e;
                            var14_15 = 0;
                            for (var13_16 = 1; var13_16 < var1_1.d + 1 && var14_15 < 2; ++var13_16) {
                                var2_2 = var1_1.b[var13_16].b[var12_14];
                                var15_17 = var5_5;
                                var11_8 = var14_15;
                                if (var2_2 != null) {
                                    var14_15 = f.a(var16_19, var14_15, (d)var2_2);
                                    var15_17 = var5_5;
                                    var11_8 = var14_15;
                                    if (!var2_2.a()) {
                                        var15_17 = var5_5 + 1;
                                        var11_8 = var14_15;
                                    }
                                }
                                var5_5 = var15_17;
                                var14_15 = var11_8;
                            }
                            var11_8 = var5_5;
                        }
                        ++var12_14;
                        var5_5 = var11_8;
                    } while (true);
                }
                var5_5 = 0;
                var0 = var1_1.b[var1_1.d + 1].b;
                var12_14 = 0;
                do {
                    var13_16 = var5_5;
                    if (var12_14 >= var0.length) ** continue;
                    var15_17 = var5_5;
                    if (var0[var12_14] != null) {
                        var17_18 = var0[var12_14].e;
                        var13_16 = var1_1.d;
                        var14_15 = 0;
                        ++var13_16;
                        do {
                            var15_17 = var5_5;
                            if (var13_16 <= 0) break;
                            var15_17 = var5_5;
                            if (var14_15 >= 2) break;
                            var2_2 = var1_1.b[var13_16].b[var12_14];
                            var16_19 = var5_5;
                            var15_17 = var14_15;
                            if (var2_2 != null) {
                                var14_15 = f.a(var17_18, var14_15, (d)var2_2);
                                var16_19 = var5_5;
                                var15_17 = var14_15;
                                if (!var2_2.a()) {
                                    var16_19 = var5_5 + 1;
                                    var15_17 = var14_15;
                                }
                            }
                            --var13_16;
                            var5_5 = var16_19;
                            var14_15 = var15_17;
                        } while (true);
                    }
                    ++var12_14;
                    var5_5 = var15_17;
                } while (true);
            }
            var5_5 = 1;
            block20 : do {
                if (var5_5 >= var1_1.d + 1) {
                    var5_5 = var14_15;
                    ** continue;
                }
                var4_4 = var1_1.b[var5_5].b;
                var11_8 = 0;
                do {
                    if (var11_8 >= var4_4.length) ** GOTO lbl302
                    if (var4_4[var11_8] == null || var4_4[var11_8].a()) ** GOTO lbl313
                    var7_9 = var4_4[var11_8];
                    var2_2 = var1_1.b[var5_5 - 1].b;
                    var0 = var1_1.b[var5_5 + 1] != null ? var1_1.b[var5_5 + 1].b : var2_2;
                    var8_10 = new d[14];
                    var8_10[2] = (d)var2_2[var11_8];
                    var8_10[3] = var0[var11_8];
                    if (var11_8 > 0) {
                        var8_10[0] = var4_4[var11_8 - 1];
                        var8_10[4] = (d)var2_2[var11_8 - 1];
                        var8_10[5] = var0[var11_8 - 1];
                    }
                    if (var11_8 > 1) {
                        var8_10[8] = var4_4[var11_8 - 2];
                        var8_10[10] = (d)var2_2[var11_8 - 2];
                        var8_10[11] = var0[var11_8 - 2];
                    }
                    if (var11_8 < var4_4.length - 1) {
                        var8_10[1] = var4_4[var11_8 + 1];
                        var8_10[6] = (d)var2_2[var11_8 + 1];
                        var8_10[7] = var0[var11_8 + 1];
                    }
                    if (var11_8 >= var4_4.length - 2) ** GOTO lbl304
                    var8_10[9] = var4_4[var11_8 + 2];
                    var8_10[12] = (d)var2_2[var11_8 + 2];
                    var8_10[13] = var0[var11_8 + 2];
                    ** GOTO lbl304
lbl302: // 1 sources:
                    ++var5_5;
                    continue block20;
lbl304: // 3 sources:
                    for (var12_14 = 0; var12_14 < 14; ++var12_14) {
                        var0 = var8_10[var12_14];
                        if (var0 != null && var0.a() && var0.c == var7_9.c) {
                            var7_9.e = var0.e;
                            var13_16 = 1;
                        } else {
                            var13_16 = 0;
                        }
                        if (var13_16 != 0) break;
                    }
lbl313: // 3 sources:
                    ++var11_8;
                } while (true);
                break;
            } while (true);
        }
        var0 = new ArrayList<E>();
        var2_2 = new int[var1_1.a.e * var1_1.d];
        var4_4 = new ArrayList<d[]>();
        var7_9 = new ArrayList<Integer>();
        var5_5 = 0;
        do {
            if (var5_5 < var1_1.a.e) {
            } else {
                var3_3 = new int[var4_4.size()][];
                var5_5 = 0;
                while (var5_5 < var3_3.length) {
                    var3_3[var5_5] = (int[])var4_4.get(var5_5);
                    ++var5_5;
                }
                return j.a(var1_1.a.b, (int[])var2_2, a.a(var0), a.a(var7_9), (int[][])var3_3);
            }
            for (var6_6 = 0; var6_6 < var1_1.d; ++var6_6) {
                var8_10 = var3_3[var5_5][var6_6 + 1].a();
                var11_8 = var1_1.d * var5_5 + var6_6;
                if (var8_10.length == 0) {
                    var0.add(var11_8);
                    continue;
                }
                if (var8_10.length == 1) {
                    var2_2[var11_8] = var8_10[0];
                    continue;
                }
                var7_9.add(var11_8);
                var4_4.add((d[])var8_10);
            }
            ++var5_5;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static c a(h var0) {
        if (var0 == null) {
            return null;
        }
        var3_1 = var0.a();
        if (var3_1 == null) {
            return null;
        }
        var2_14 = var0.a;
        var1_13 = var0.c != false ? var2_14.b : var2_14.d;
        var2_14 = var0.c != false ? var2_14.c : var2_14.e;
        var13_22 = var0.b((int)var2_14.b);
        var1_13 = var0.b;
        var9_18 = 1;
        var10_19 = -1;
        var12_21 = 0;
        ** GOTO lbl87
        do {
            if (var1_13 == null) {
                return null;
            }
            var7_16 = var1_13.length;
            var8_17 = -1;
            for (var6_15 = 0; var6_15 < var7_16; ++var6_15) {
                var8_17 = Math.max(var8_17, (int)var1_13[var6_15]);
            }
            var10_19 = var1_13.length;
            var9_18 = 0;
            var6_15 = 0;
            do {
                var7_16 = var6_15;
                if (var9_18 >= var10_19) break;
                var11_20 = var1_13[var9_18];
                var7_16 = var6_15 += var8_17 - var11_20;
                if (var11_20 > 0) break;
                ++var9_18;
            } while (true);
            var2_14 = var0.b;
            var6_15 = 0;
            for (var9_18 = var7_16; var9_18 > 0 && var2_14[var6_15] == null; ++var6_15, --var9_18) {
            }
            var10_19 = var1_13.length - 1;
            var7_16 = 0;
            do {
                var6_15 = var7_16;
                if (var10_19 < 0) break;
                var6_15 = var7_16 += var8_17 - var1_13[var10_19];
                if (var1_13[var10_19] > 0) break;
                --var10_19;
            } while (true);
            var7_16 = var2_14.length;
            --var7_16;
            while (var6_15 > 0 && var2_14[var7_16] == null) {
                --var7_16;
                --var6_15;
            }
            var5_23 = var0.a;
            var14_24 = var0.c;
            var0 = var5_23.b;
            var2_14 = var5_23.c;
            var1_13 = var5_23.d;
            var4_25 = var5_23.e;
            if (var9_18 > 0) {
                if (var14_24) {
                    var3_4 = var5_23.b;
                } else {
                    var3_11 = var5_23.d;
                }
                var7_16 = var8_17 = (int)var3_5.b - var9_18;
                if (var8_17 < 0) {
                    var7_16 = 0;
                }
                var3_6 = new p(var3_5.a, var7_16);
                if (var14_24) {
                    var0 = var3_6;
                } else {
                    var1_13 = var3_6;
                }
            }
            if (var6_15 > 0) {
                if (var14_24) {
                    var3_8 = var5_23.c;
                } else {
                    var3_12 = var5_23.e;
                }
                var6_15 = var7_16 = (int)var3_9.b + var6_15;
                if (var7_16 >= var5_23.a.b) {
                    var6_15 = var5_23.a.b - 1;
                }
                var3_10 = new p(var3_9.a, var6_15);
                if (var14_24) {
                    var2_14 = var3_10;
                } else {
                    var4_25 = var3_10;
                }
            }
            var5_23.a();
            return new c(var5_23.a, (p)var0, (p)var2_14, (p)var1_13, var4_25);
            break;
        } while (true);
lbl87: // 2 sources:
        for (var8_17 = var0.b((int)((int)var1_13.b)); var8_17 < var13_22; ++var8_17) {
            var6_15 = var12_21;
            var11_20 = var9_18;
            var7_16 = var10_19;
            if (var1_13[var8_17] != null) {
                var2_14 = var1_13[var8_17];
                var2_14.b();
                var6_15 = var2_14.e - var10_19;
                if (var6_15 == 0) {
                    var6_15 = var12_21 + 1;
                    var7_16 = var10_19;
                    var11_20 = var9_18;
                } else if (var6_15 == 1) {
                    var11_20 = Math.max((int)var9_18, var12_21);
                    var7_16 = var2_14.e;
                    var6_15 = 1;
                } else if (var2_14.e >= var3_1.e) {
                    var1_13[var8_17] = null;
                    var6_15 = var12_21;
                    var11_20 = var9_18;
                    var7_16 = var10_19;
                } else {
                    var7_16 = var2_14.e;
                    var6_15 = 1;
                    var11_20 = var9_18;
                }
            }
            var12_21 = var6_15;
            var9_18 = var11_20;
            var10_19 = var7_16;
        }
        var1_13 = new int[var3_1.e];
        var2_14 = var0.b;
        var7_16 = var2_14.length;
        var6_15 = 0;
        do {
            if (var6_15 >= var7_16) ** continue;
            var3_3 = var2_14[var6_15];
            if (var3_3 != null) {
                var8_17 = var3_3.e;
                if (var8_17 >= var1_13.length) {
                    throw g.a();
                }
                var1_13[var8_17] = var1_13[var8_17] + true;
            }
            ++var6_15;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static d a(com.google.c.b.b var0, int var1_1, int var2_2, boolean var3_3, int var4_4, int var5_5, int var6_6, int var7_7) {
        var9_8 = var3_3 != false ? -1 : 1;
        var10_9 = 0;
        var11_10 = var9_8;
        var12_11 = var3_3;
        var9_8 = var4_4;
        block0 : do {
            if (var10_9 < 2) ** GOTO lbl10
            var4_4 = var9_8;
            ** GOTO lbl-1000
lbl10: // 2 sources:
            while ((var12_11 && var9_8 >= var1_1 || !var12_11 && var9_8 < var2_2) && var12_11 == var0.a(var9_8, var5_5)) {
                if (Math.abs(var4_4 - var9_8) > 2) lbl-1000: // 2 sources:
                {
                    var8_12 = new int[8];
                    var11_10 = 0;
                    var9_8 = var3_3 != false ? 1 : -1;
                    var10_9 = var4_4;
                    var12_11 = var3_3;
                    break block0;
                }
                var9_8 += var11_10;
            }
            var11_10 = - var11_10;
            var12_11 = var12_11 == false;
            ++var10_9;
        } while (true);
        while ((var3_3 && var10_9 < var2_2 || !var3_3 && var10_9 >= var1_1) && var11_10 < 8) {
            if (var0.a(var10_9, var5_5) == var12_11) {
                var8_12[var11_10] = var8_12[var11_10] + 1;
                var10_9 += var9_8;
                continue;
            }
            var12_11 = var12_11 == false;
            ++var11_10;
        }
        var0 = var8_12;
        if (var11_10 != 8) {
            if (!var3_3 || var10_9 != var2_2) {
                if (var3_3 != false) return null;
                if (var10_9 != var1_1) return null;
            }
            if (var11_10 != 7) return null;
            var0 = var8_12;
        }
        if (var0 == null) {
            return null;
        }
        var2_2 = a.a(var0);
        if (var3_3) {
            var1_1 = var4_4 + var2_2;
        } else {
            for (var1_1 = 0; var1_1 < var0.length / 2; ++var1_1) {
                var5_5 = var0[var1_1];
                var0[var1_1] = var0[var0.length - 1 - var1_1];
                var0[var0.length - 1 - var1_1] = var5_5;
            }
            var1_1 = var4_4;
            var4_4 -= var2_2;
        }
        if (var6_6 - 2 > var2_2) return null;
        if (var2_2 > var7_7 + 2) return null;
        var2_2 = 1;
        if (var2_2 == 0) {
            return null;
        }
        var2_2 = i.a(var0);
        var5_5 = a.a(var2_2);
        if (var5_5 == -1) {
            return null;
        }
        var0 = j.a(var2_2);
        return new d(var4_4, var1_1, (var0[0] - var0[2] + var0[4] - var0[6] + 9) % 9, var5_5);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static h a(com.google.c.b.b b2, c c2, p p2, boolean bl2, int n2, int n3) {
        h h2 = new h(c2, bl2);
        int n4 = 0;
        while (n4 < 2) {
            int n5 = n4 == 0 ? 1 : -1;
            int n6 = (int)p2.a;
            for (int i2 = (int)p2.b; i2 <= c2.i && i2 >= c2.h; i2 += n5) {
                d d2 = j.a(b2, 0, b2.a, bl2, n6, i2, n2, n3);
                if (d2 == null) continue;
                h2.a(i2, d2);
                n6 = bl2 ? d2.a : d2.b;
            }
            ++n4;
        }
        return h2;
    }

    private static boolean a(f f2, int n2) {
        if (n2 >= 0 && n2 <= f2.d + 1) {
            return true;
        }
        return false;
    }

    private static int[] a(int n2) {
        int[] arrn = new int[8];
        int n3 = 0;
        int n4 = 7;
        do {
            int n5 = n4;
            int n6 = n3;
            if ((n2 & 1) != n3) {
                n6 = n2 & 1;
                n5 = n4 - 1;
                if (n5 < 0) break;
            }
            arrn[n5] = arrn[n5] + 1;
            n2 >>= 1;
            n4 = n5;
            n3 = n6;
        } while (true);
        return arrn;
    }
}

