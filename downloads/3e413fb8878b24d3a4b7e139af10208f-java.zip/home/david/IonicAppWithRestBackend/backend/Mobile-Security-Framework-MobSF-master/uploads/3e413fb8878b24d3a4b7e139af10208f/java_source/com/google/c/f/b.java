/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f;

import com.google.c.e;
import com.google.c.f.b.a;
import com.google.c.f.c;
import com.google.c.j;
import com.google.c.l;
import com.google.c.n;
import com.google.c.o;
import com.google.c.p;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class b
implements l {
    private static int a(p p2, p p3) {
        if (p2 == null || p3 == null) {
            return 0;
        }
        return (int)Math.abs(p2.a - p3.a);
    }

    private static int b(p p2, p p3) {
        if (p2 == null || p3 == null) {
            return Integer.MAX_VALUE;
        }
        return (int)Math.abs(p2.a - p3.a);
    }

    @Override
    public final n a(com.google.c.c arrn, Map<e, ?> object) {
        object = new ArrayList();
        arrn = a.a((com.google.c.c)arrn);
        Iterator<p[]> iterator = arrn.b.iterator();
        while (iterator.hasNext()) {
            Object object2 = iterator.next();
            Object object3 = com.google.c.f.a.j.a(arrn.a, object2[4], object2[5], object2[6], object2[7], Math.min(Math.min(b.b(object2[0], object2[4]), b.b(object2[6], object2[2]) * 17 / 18), Math.min(b.b(object2[1], object2[5]), b.b(object2[7], object2[3]) * 17 / 18)), Math.max(Math.max(b.a(object2[0], object2[4]), b.a(object2[6], object2[2]) * 17 / 18), Math.max(b.a(object2[1], object2[5]), b.a(object2[7], object2[3]) * 17 / 18)));
            object2 = new n(object3.b, object3.a, (p[])object2, com.google.c.a.k);
            object2.a(o.d, object3.d);
            object3 = (c)object3.g;
            if (object3 != null) {
                object2.a(o.i, object3);
            }
            object.add(object2);
        }
        arrn = object.toArray(new n[object.size()]);
        if (arrn == null || arrn.length == 0 || arrn[0] == null) {
            throw j.a();
        }
        return arrn[0];
    }

    @Override
    public final void a() {
    }
}

