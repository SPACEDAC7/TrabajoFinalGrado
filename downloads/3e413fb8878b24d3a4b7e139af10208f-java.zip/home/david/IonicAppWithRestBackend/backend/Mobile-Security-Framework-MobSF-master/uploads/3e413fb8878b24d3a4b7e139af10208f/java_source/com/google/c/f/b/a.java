/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.b;

import com.google.c.c;
import com.google.c.f.b.b;
import com.google.c.p;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class a {
    private static final int[] a = new int[]{0, 4, 1, 5};
    private static final int[] b = new int[]{6, 2, 7, 3};
    private static final int[] c = new int[]{8, 1, 1, 1, 1, 1, 1, 3};
    private static final int[] d = new int[]{7, 1, 1, 3, 1, 1, 1, 2, 1};

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static float a(int[] arrn, int[] arrn2) {
        int n2;
        int n3 = arrn.length;
        int n4 = 0;
        int n5 = 0;
        for (n2 = 0; n2 < n3; ++n2) {
            int n6 = arrn[n2];
            int n7 = arrn2[n2];
            n5 = n7 + n5;
            n4 = n6 + n4;
        }
        if (n4 < n5) {
            return Float.POSITIVE_INFINITY;
        }
        float f2 = (float)n4 / (float)n5;
        float f3 = 0.0f;
        n5 = 0;
        while (n5 < n3) {
            n2 = arrn[n5];
            float f4 = (float)arrn2[n5] * f2;
            f4 = (float)n2 > f4 ? (float)n2 - f4 : (f4 -= (float)n2);
            if (f4 > 0.8f * f2) return Float.POSITIVE_INFINITY;
            f3 += f4;
            ++n5;
        }
        return f3 / (float)n4;
    }

    public static b a(c object) {
        List<p[]> list;
        com.google.c.b.b b2 = object.a();
        List<p[]> list2 = list = a.a(b2);
        object = b2;
        if (list.isEmpty()) {
            b2 = b2.c();
            int n2 = b2.a;
            int n3 = b2.b;
            list2 = new com.google.c.b.a(n2);
            object = new com.google.c.b.a(n2);
            for (n2 = 0; n2 < (n3 + 1) / 2; ++n2) {
                list2 = b2.a(n2, (com.google.c.b.a)((Object)list2));
                object = b2.a(n3 - 1 - n2, (com.google.c.b.a)object);
                list2.c();
                object.c();
                b2.b(n2, (com.google.c.b.a)object);
                b2.b(n3 - 1 - n2, (com.google.c.b.a)((Object)list2));
            }
            list2 = a.a(b2);
            object = b2;
        }
        return new b((com.google.c.b.b)object, list2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static List<p[]> a(com.google.c.b.b b2) {
        ArrayList<p[]> arrayList = new ArrayList<p[]>();
        if (b2.b > 0) {
            int n2;
            int n3;
            int n4 = b2.b;
            int n5 = b2.a;
            p[] arrp = new p[8];
            a.a(arrp, a.a(b2, n4, n5, 0, 0, c), a);
            if (arrp[4] != null) {
                n3 = (int)arrp[4].a;
                n2 = (int)arrp[4].b;
            } else {
                n3 = 0;
                n2 = 0;
            }
            a.a(arrp, a.a(b2, n4, n5, n2, n3, d), b);
            if (arrp[0] != null || arrp[3] != null) {
                arrayList.add(arrp);
            }
        }
        return arrayList;
    }

    private static void a(p[] arrp, p[] arrp2, int[] arrn) {
        for (int i2 = 0; i2 < arrn.length; ++i2) {
            arrp[arrn[i2]] = arrp2[i2];
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int[] a(com.google.c.b.b b2, int n2, int n3, int n4, int[] arrn, int[] arrn2) {
        int n5;
        Arrays.fill(arrn2, 0, arrn2.length, 0);
        int n6 = arrn.length;
        for (n5 = 0; b2.a(n2, n3) && n2 > 0 && n5 < 3; --n2, ++n5) {
        }
        int n7 = 0;
        int n8 = 0;
        n5 = n2;
        int n9 = n2;
        n2 = n5;
        while (n9 < n4) {
            if (b2.a(n9, n3) ^ n8) {
                arrn2[n7] = arrn2[n7] + 1;
                n5 = n8;
            } else {
                if (n7 == n6 - 1) {
                    if (a.a(arrn2, arrn) < 0.42f) {
                        return new int[]{n2, n9};
                    }
                    n2 += arrn2[0] + arrn2[1];
                    System.arraycopy(arrn2, 2, arrn2, 0, n6 - 2);
                    arrn2[n6 - 2] = 0;
                    arrn2[n6 - 1] = 0;
                    n5 = n7 - 1;
                } else {
                    n5 = n7 + 1;
                }
                arrn2[n5] = 1;
                if (n8 == 0) {
                    n8 = 1;
                    n7 = n5;
                    n5 = n8;
                } else {
                    n8 = 0;
                    n7 = n5;
                    n5 = n8;
                }
            }
            ++n9;
            n8 = n5;
        }
        if (n7 == n6 - 1 && a.a(arrn2, arrn) < 0.42f) {
            return new int[]{n2, n9 - 1};
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static p[] a(com.google.c.b.b b2, int n2, int n3, int n4, int n5, int[] arrn) {
        int[] arrn2;
        p[] arrp;
        int n6;
        int[] arrn3;
        int[] arrn4;
        block10 : {
            arrp = new p[4];
            arrn2 = new int[arrn.length];
            while (n4 < n2) {
                arrn3 = a.a(b2, n5, n4, n3, arrn, arrn2);
                if (arrn3 != null) {
                    block9 : {
                        n6 = n4;
                        do {
                            n4 = n6;
                            if (n6 <= 0) break block9;
                            if ((arrn4 = a.a(b2, n5, --n6, n3, arrn, arrn2)) == null) break;
                            arrn3 = arrn4;
                        } while (true);
                        n4 = n6 + 1;
                    }
                    arrp[0] = new p(arrn3[0], n4);
                    arrp[1] = new p(arrn3[1], n4);
                    n6 = 1;
                    n5 = n4;
                    n4 = n6;
                    break block10;
                }
                n4 += 5;
            }
            n6 = 0;
            n5 = n4;
            n4 = n6;
        }
        int n7 = n6 = n5 + 1;
        if (n4 != 0) {
            arrn3 = new int[]{(int)arrp[0].a, (int)arrp[1].a};
            n4 = 0;
            while (n6 < n2) {
                arrn4 = a.a(b2, arrn3[0], n6, n3, arrn, arrn2);
                if (arrn4 != null && Math.abs(arrn3[0] - arrn4[0]) < 5 && Math.abs(arrn3[1] - arrn4[1]) < 5) {
                    n4 = 0;
                    arrn3 = arrn4;
                } else {
                    if (n4 > 25) break;
                    ++n4;
                }
                ++n6;
            }
            n7 = n6 - (n4 + 1);
            arrp[2] = new p(arrn3[0], n7);
            arrp[3] = new p(arrn3[1], n7);
        }
        if (n7 - n5 >= 10) {
            return arrp;
        }
        n2 = 0;
        while (n2 < 4) {
            arrp[n2] = null;
            ++n2;
        }
        return arrp;
    }
}

