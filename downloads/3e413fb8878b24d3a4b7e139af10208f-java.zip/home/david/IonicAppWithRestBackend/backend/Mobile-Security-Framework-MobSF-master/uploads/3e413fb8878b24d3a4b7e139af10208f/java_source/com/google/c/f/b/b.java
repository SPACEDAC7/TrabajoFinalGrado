/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f.b;

import com.google.c.p;
import java.util.List;

public final class b {
    public final com.google.c.b.b a;
    public final List<p[]> b;

    public b(com.google.c.b.b b2, List<p[]> list) {
        this.a = b2;
        this.b = list;
    }
}

