/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.f;

public final class c {
    public int a;
    public String b;
    public int[] c;
    public boolean d;
}

