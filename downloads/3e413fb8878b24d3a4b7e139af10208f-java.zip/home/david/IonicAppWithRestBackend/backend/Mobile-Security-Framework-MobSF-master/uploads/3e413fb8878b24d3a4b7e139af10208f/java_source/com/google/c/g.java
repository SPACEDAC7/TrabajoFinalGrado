/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import com.google.c.m;

public final class g
extends m {
    private static final g a = new g();

    private g() {
    }

    public static g a() {
        return a;
    }
}

