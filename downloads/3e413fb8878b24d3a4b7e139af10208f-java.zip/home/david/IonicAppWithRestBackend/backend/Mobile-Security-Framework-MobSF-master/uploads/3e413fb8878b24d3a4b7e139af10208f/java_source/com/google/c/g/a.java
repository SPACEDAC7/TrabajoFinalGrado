/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g;

import android.support.design.widget.AppBarLayout;
import com.google.c.b.b;
import com.google.c.b.g;
import com.google.c.c;
import com.google.c.e;
import com.google.c.g.a.i;
import com.google.c.g.b.d;
import com.google.c.g.b.e;
import com.google.c.g.b.f;
import com.google.c.j;
import com.google.c.l;
import com.google.c.n;
import com.google.c.o;
import com.google.c.p;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class a
implements l {
    private static final p[] a = new p[0];
    private final com.google.c.g.a.e b = new com.google.c.g.a.e();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final n a(c var1_1, Map<e, ?> var2_2) {
        if (var2_2 == null || !var2_2.containsKey((Object)e.b)) {
            var7_5 = new com.google.c.g.b.c(var1_1.a());
            var1_1 = var2_2 == null ? null : (AppBarLayout.b)var2_2.get((Object)e.j);
            var7_5.b = var1_1;
            var8_24 = new com.google.c.g.b.e(var7_5.a, var7_5.b);
            var12_11 = var2_2 != null && var2_2.containsKey((Object)e.d) != false ? 1 : 0;
            var21_25 = var2_2 != null && var2_2.containsKey((Object)e.b) != false;
            var16_21 = var8_24.a.b;
            var17_23 = var8_24.a.a;
            var11_12 = var16_21 * 3 / 228;
            if (var11_12 < 3 || var12_11 != 0) {
                var11_12 = 3;
            }
        } else {
            var1_1 = var1_1.a();
            var6_3 = var1_1.a();
            var7_4 = var1_1.b();
            if (var6_3 == null) throw j.a();
            if (var7_4 == null) {
                throw j.a();
            }
            var14_6 = var1_1.b;
            var15_8 = var1_1.a;
            var12_10 = var6_3[0];
            var19_13 = true;
            var13_15 = 0;
            for (var11_12 = var6_3[1]; var12_10 < var15_8 && var11_12 < var14_6; ++var12_10, ++var11_12) {
                if (var19_13 == var1_1.a(var12_10, var11_12)) continue;
                if (++var13_15 == 5) break;
                var19_13 = var19_13 == false;
            }
            if (var12_10 == var15_8) throw j.a();
            if (var11_12 == var14_6) {
                throw j.a();
            }
            var3_17 = (float)(var12_10 - var6_3[0]) / 7.0f;
            var18_19 = var6_3[1];
            var14_6 = var7_4[1];
            var13_15 = var6_3[0];
            var12_10 = var7_4[0];
            if (var13_15 >= var12_10) throw j.a();
            if (var18_19 >= var14_6) {
                throw j.a();
            }
            var11_12 = var12_10;
            if (var14_6 - var18_19 != var12_10 - var13_15) {
                var11_12 = var14_6 - var18_19 + var13_15;
            }
            var15_8 = Math.round((float)(var11_12 - var13_15 + 1) / var3_17);
            var16_20 = Math.round((float)(var14_6 - var18_19 + 1) / var3_17);
            if (var15_8 <= 0) throw j.a();
            if (var16_20 <= 0) {
                throw j.a();
            }
            if (var16_20 != var15_8) {
                throw j.a();
            }
            var17_22 = (int)(var3_17 / 2.0f);
            var12_10 = var18_19 + var17_22;
            if ((var11_12 = (int)((float)(var15_8 - 1) * var3_17) + (var13_15 += var17_22) - (var11_12 - 1)) > 0) {
                if (var11_12 > var17_22) {
                    throw j.a();
                }
                var11_12 = var13_15 - var11_12;
            } else {
                var11_12 = var13_15;
            }
            if ((var13_15 = (int)((float)(var16_20 - 1) * var3_17) + var12_10 - (var14_6 - 1)) > 0) {
                if (var13_15 > var17_22) {
                    throw j.a();
                }
                var12_10 -= var13_15;
            }
            var6_3 = new b(var15_8, var16_20);
            for (var13_15 = 0; var13_15 < var16_20; ++var13_15) {
                var17_22 = (int)((float)var13_15 * var3_17);
                for (var14_6 = 0; var14_6 < var15_8; ++var14_6) {
                    if (!var1_1.a((int)((float)var14_6 * var3_17) + var11_12, var12_10 + var17_22)) continue;
                    var6_3.b(var14_6, var13_15);
                }
            }
            var1_1 = this.b.a((b)var6_3, var2_2);
            var2_2 = a.a;
lbl73: // 2 sources:
            do {
                if (var1_1.g instanceof i && ((i)var1_1.g).a && var2_2 != null && var2_2.length >= 3) {
                    var6_3 = var2_2[0];
                    var2_2[0] = var2_2[2];
                    var2_2[2] = var6_3;
                }
                var2_2 = new n(var1_1.b, var1_1.a, var2_2, com.google.c.a.l);
                var6_3 = var1_1.c;
                if (var6_3 != null) {
                    var2_2.a(o.c, var6_3);
                }
                if ((var6_3 = var1_1.d) != null) {
                    var2_2.a(o.d, var6_3);
                }
                if (var1_1.h < 0) return var2_2;
                if (var1_1.i < 0) return var2_2;
                var11_12 = 1;
                if (var11_12 == 0) return var2_2;
                var2_2.a(o.j, var1_1.i);
                var2_2.a(o.k, var1_1.h);
                return var2_2;
                break;
            } while (true);
        }
        var19_14 = false;
        var9_26 = new int[5];
        var13_16 = var11_12 - 1;
        var14_7 = var11_12;
        do {
            if (var13_16 < var16_21 && !var19_14) {
                var9_26[0] = 0;
                var9_26[1] = 0;
                var9_26[2] = 0;
                var9_26[3] = 0;
                var9_26[4] = 0;
                var11_12 = 0;
            } else {
                var11_12 = var8_24.b.size();
                if (var11_12 < 3) {
                    throw j.a();
                }
                if (var11_12 > 3) {
                    var1_1 = var8_24.b.iterator();
                    var4_29 = 0.0f;
                    var3_18 = 0.0f;
                    while (var1_1.hasNext()) {
                        var5_30 = ((d)var1_1.next()).c;
                        var4_29 += var5_30;
                        var3_18 = var5_30 * var5_30 + var3_18;
                    }
                    var3_18 = (float)Math.sqrt(var3_18 / (float)var11_12 - var4_29 * (var4_29 /= (float)var11_12));
                    Collections.sort(var8_24.b, new e.b(var4_29, 0));
                    var3_18 = Math.max(0.2f * var4_29, var3_18);
                    var11_12 = 0;
                    while (var11_12 < var8_24.b.size() && var8_24.b.size() > 3) {
                        var12_11 = var11_12;
                        if (Math.abs(var8_24.b.get((int)var11_12).c - var4_29) > var3_18) {
                            var8_24.b.remove(var11_12);
                            var12_11 = var11_12 - 1;
                        }
                        var11_12 = var12_11 + 1;
                    }
                }
                if (var8_24.b.size() > 3) {
                    var1_1 = var8_24.b.iterator();
                    var3_18 = 0.0f;
                    while (var1_1.hasNext()) {
                        var3_18 = ((d)var1_1.next()).c + var3_18;
                    }
                    Collections.sort(var8_24.b, new e.a(var3_18 /= (float)var8_24.b.size(), 0));
                    var8_24.b.subList(3, var8_24.b.size()).clear();
                }
                var1_1 = new d[]{var8_24.b.get(0), var8_24.b.get(1), var8_24.b.get(2)};
                p.a((p[])var1_1);
                var6_3 = var7_5.a(new f((d[])var1_1));
                var1_1 = this.b.a(var6_3.d, var2_2);
                var2_2 = var6_3.e;
                ** continue;
            }
            for (var12_11 = 0; var12_11 < var17_23; ++var12_11) {
                if (var8_24.a.a(var12_11, var13_16)) {
                    var15_9 = var11_12;
                    if ((var11_12 & 1) == 1) {
                        var15_9 = var11_12 + 1;
                    }
                    var9_26[var15_9] = var9_26[var15_9] + 1;
                    var11_12 = var15_9;
                    continue;
                }
                if ((var11_12 & 1) == 0) {
                    if (var11_12 == 4) {
                        if (com.google.c.g.b.e.a(var9_26)) {
                            if (var8_24.a(var9_26, var13_16, var12_11, var21_25)) {
                                if (var8_24.c) {
                                    var19_14 = var8_24.a();
                                } else {
                                    if (var8_24.b.size() > 1) {
                                        var10_28 = var8_24.b.iterator();
                                        var1_1 = null;
                                        while (var10_28.hasNext()) {
                                            var6_3 = var10_28.next();
                                            if (var6_3.d < 2) continue;
                                            if (var1_1 == null) {
                                                var1_1 = var6_3;
                                                continue;
                                            }
                                            var8_24.c = true;
                                            var11_12 = (int)(Math.abs(var1_1.a - var6_3.a) - Math.abs(var1_1.b - var6_3.b)) / 2;
                                            break;
                                        }
                                    } else {
                                        var11_12 = 0;
                                    }
                                    if (var11_12 > var9_26[2]) {
                                        var11_12 = var13_16 + (var11_12 - var9_26[2] - 2);
                                        var12_11 = var17_23 - 1;
                                    } else {
                                        var11_12 = var13_16;
                                    }
                                    var13_16 = var11_12;
                                }
                                var9_26[0] = 0;
                                var9_26[1] = 0;
                                var9_26[2] = 0;
                                var9_26[3] = 0;
                                var9_26[4] = 0;
                                var11_12 = 0;
                                var14_7 = 2;
                                continue;
                            }
                            var9_26[0] = var9_26[2];
                            var9_26[1] = var9_26[3];
                            var9_26[2] = var9_26[4];
                            var9_26[3] = 1;
                            var9_26[4] = 0;
                            var11_12 = 3;
                            continue;
                        }
                        var9_26[0] = var9_26[2];
                        var9_26[1] = var9_26[3];
                        var9_26[2] = var9_26[4];
                        var9_26[3] = 1;
                        var9_26[4] = 0;
                        var11_12 = 3;
                        continue;
                    }
                    var9_26[++var11_12] = var9_26[var11_12] + 1;
                    continue;
                }
                var9_26[var11_12] = var9_26[var11_12] + 1;
            }
            var11_12 = var14_7;
            var20_27 = var19_14;
            if (com.google.c.g.b.e.a(var9_26)) {
                var11_12 = var14_7;
                var20_27 = var19_14;
                if (var8_24.a(var9_26, var13_16, var17_23, var21_25)) {
                    var11_12 = var12_11 = var9_26[0];
                    var20_27 = var19_14;
                    if (var8_24.c) {
                        var20_27 = var8_24.a();
                        var11_12 = var12_11;
                    }
                }
            }
            var13_16 += var11_12;
            var14_7 = var11_12;
            var19_14 = var20_27;
        } while (true);
    }

    @Override
    public final void a() {
    }
}

