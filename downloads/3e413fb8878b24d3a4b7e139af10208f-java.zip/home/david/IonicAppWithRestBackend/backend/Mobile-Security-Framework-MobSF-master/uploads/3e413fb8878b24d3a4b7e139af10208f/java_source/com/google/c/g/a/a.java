/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.a;

import com.google.c.b.b;
import com.google.c.g.a.g;
import com.google.c.g.a.j;

final class a {
    final b a;
    j b;
    g c;
    boolean d;

    a(b b2) {
        int n2 = b2.b;
        if (n2 < 21 || (n2 & 3) != 1) {
            throw com.google.c.g.a();
        }
        this.a = b2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int a(int n2, int n3, int n4) {
        boolean bl2 = this.d ? this.a.a(n3, n2) : this.a.a(n2, n3);
        if (bl2) {
            return n4 << 1 | 1;
        }
        return n4 << 1;
    }

    final g a() {
        int n2;
        int n3 = 0;
        if (this.c != null) {
            return this.c;
        }
        int n4 = 0;
        for (n2 = 0; n2 < 6; ++n2) {
            n4 = this.a(n2, 8, n4);
        }
        n4 = this.a(8, 7, this.a(8, 8, this.a(7, 8, n4)));
        for (n2 = 5; n2 >= 0; --n2) {
            n4 = this.a(8, n2, n4);
        }
        int n5 = this.a.b;
        int n6 = n5 - 1;
        n2 = n3;
        for (n3 = n6; n3 >= n5 - 7; --n3) {
            n2 = this.a(8, n3, n2);
        }
        n6 = n5 - 8;
        n3 = n2;
        for (n2 = n6; n2 < n5; ++n2) {
            n3 = this.a(n2, 8, n3);
        }
        this.c = g.b(n4, n3);
        if (this.c != null) {
            return this.c;
        }
        throw com.google.c.g.a();
    }

    final j b() {
        int n2;
        if (this.b != null) {
            return this.b;
        }
        int n3 = this.a.b;
        int n4 = (n3 - 17) / 4;
        if (n4 <= 6) {
            return j.b(n4);
        }
        int n5 = n3 - 11;
        int n6 = 0;
        for (n4 = 5; n4 >= 0; --n4) {
            for (n2 = n3 - 9; n2 >= n5; --n2) {
                n6 = this.a(n2, n4, n6);
            }
        }
        j j2 = j.c(n6);
        if (j2 != null && j2.a() == n3) {
            this.b = j2;
            return j2;
        }
        n6 = 0;
        for (n4 = 5; n4 >= 0; --n4) {
            for (n2 = n3 - 9; n2 >= n5; --n2) {
                n6 = this.a(n4, n2, n6);
            }
        }
        j2 = j.c(n6);
        if (j2 != null && j2.a() == n3) {
            this.b = j2;
            return j2;
        }
        throw com.google.c.g.a();
    }
}

