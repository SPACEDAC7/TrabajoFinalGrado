/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.a;

final class b {
    final int a;
    final byte[] b;

    b(int n2, byte[] arrby) {
        this.a = n2;
        this.b = arrby;
    }
}

