/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.a;

abstract class c {
    private static final c[] a = new c[]{new a(0), new b(0), new c(0), new d(0), new e(0), new f(0), new g(0), new h(0)};

    private c() {
    }

    /* synthetic */ c(byte by2) {
        this();
    }

    static c a(int n2) {
        if (n2 < 0 || n2 > 7) {
            throw new IllegalArgumentException();
        }
        return a[n2];
    }

    final void a(com.google.c.b.b b2, int n2) {
        for (int i2 = 0; i2 < n2; ++i2) {
            for (int i3 = 0; i3 < n2; ++i3) {
                if (!this.a(i2, i3)) continue;
                b2.c(i3, i2);
            }
        }
    }

    abstract boolean a(int var1, int var2);

    static final class a
    extends c {
        private a() {
            super(0);
        }

        /* synthetic */ a(byte by2) {
            this();
        }

        @Override
        final boolean a(int n2, int n3) {
            if ((n2 + n3 & 1) == 0) {
                return true;
            }
            return false;
        }
    }

    static final class b
    extends c {
        private b() {
            super(0);
        }

        /* synthetic */ b(byte by2) {
            this();
        }

        @Override
        final boolean a(int n2, int n3) {
            if ((n2 & 1) == 0) {
                return true;
            }
            return false;
        }
    }

    static final class c
    extends c {
        private c() {
            super(0);
        }

        /* synthetic */ c(byte by2) {
            this();
        }

        @Override
        final boolean a(int n2, int n3) {
            if (n3 % 3 == 0) {
                return true;
            }
            return false;
        }
    }

    static final class d
    extends c {
        private d() {
            super(0);
        }

        /* synthetic */ d(byte by2) {
            this();
        }

        @Override
        final boolean a(int n2, int n3) {
            if ((n2 + n3) % 3 == 0) {
                return true;
            }
            return false;
        }
    }

    static final class e
    extends c {
        private e() {
            super(0);
        }

        /* synthetic */ e(byte by2) {
            this();
        }

        @Override
        final boolean a(int n2, int n3) {
            if ((n2 / 2 + n3 / 3 & 1) == 0) {
                return true;
            }
            return false;
        }
    }

    static final class f
    extends c {
        private f() {
            super(0);
        }

        /* synthetic */ f(byte by2) {
            this();
        }

        @Override
        final boolean a(int n2, int n3) {
            if ((n2 *= n3) % 3 + (n2 & 1) == 0) {
                return true;
            }
            return false;
        }
    }

    static final class g
    extends c {
        private g() {
            super(0);
        }

        /* synthetic */ g(byte by2) {
            this();
        }

        @Override
        final boolean a(int n2, int n3) {
            if (((n2 *= n3) % 3 + (n2 & 1) & 1) == 0) {
                return true;
            }
            return false;
        }
    }

    static final class h
    extends c {
        private h() {
            super(0);
        }

        /* synthetic */ h(byte by2) {
            this();
        }

        @Override
        final boolean a(int n2, int n3) {
            if (((n2 + n3 & 1) + n2 * n3 % 3 & 1) == 0) {
                return true;
            }
            return false;
        }
    }

}

