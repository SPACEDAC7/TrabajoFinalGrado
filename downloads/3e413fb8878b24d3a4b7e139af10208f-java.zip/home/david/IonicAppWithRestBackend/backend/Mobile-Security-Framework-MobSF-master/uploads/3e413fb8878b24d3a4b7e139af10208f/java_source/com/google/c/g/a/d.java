/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.a;

import com.google.c.b.c;
import com.google.c.b.l;
import com.google.c.e;
import com.google.c.g;
import com.google.c.g.a.f;
import com.google.c.g.a.h;
import com.google.c.g.a.j;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

final class d {
    private static final char[] a = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', ' ', '$', '%', '*', '+', '-', '.', '/', ':'};

    private static char a(int n2) {
        if (n2 >= a.length) {
            throw g.a();
        }
        return a[n2];
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static com.google.c.b.e a(byte[] var0, j var1_2, f var2_3, Map<e, ?> var3_4) {
        var7_5 = new c(var0);
        var8_6 = new StringBuilder(50);
        var6_7 = new ArrayList<byte[]>(1);
        var5_8 = null;
        var10_9 = -1;
        var11_10 = -1;
        var14_11 = false;
        do {
            block23 : {
                block27 : {
                    block22 : {
                        block21 : {
                            block24 : {
                                block25 : {
                                    block26 : {
                                        try {
                                            var4_12 = var7_5.a() < 4 ? h.a : h.a(var7_5.a(4));
                                            if (var4_12 == h.a) break block21;
                                            if (var4_12 == h.h || var4_12 == h.i) break block22;
                                            if (var4_12 == h.d) {
                                                if (var7_5.a() < 16) {
                                                    throw g.a();
                                                }
                                                var10_9 = var7_5.a(8);
                                                var11_10 = var7_5.a(8);
                                                break block23;
                                            }
                                            if (var4_12 != h.f) break block24;
                                            var12_14 = var7_5.a(8);
                                            if ((var12_14 & 128) == 0) {
                                                var12_14 &= 127;
                                                break block25;
                                            }
                                            if ((var12_14 & 192) != 128) break block26;
                                        }
                                        catch (IllegalArgumentException var0_1) {
                                            throw g.a();
                                        }
                                        var12_14 = (var12_14 & 63) << 8 | var7_5.a(8);
                                    }
                                    if ((var12_14 & 224) != 192) throw g.a();
                                    var12_14 = (var12_14 & 31) << 16 | var7_5.a(16);
                                }
                                var5_8 = com.google.c.b.d.a(var12_14);
                                if (var5_8 == null) {
                                    throw g.a();
                                }
                                break block27;
                            }
                            if (var4_12 != h.j) ** GOTO lbl47
                            var12_14 = var7_5.a(4);
                            var13_15 = var7_5.a(var4_12.a((j)var1_2 /* !! */ ));
                            if (var12_14 == 1) {
                                d.a(var7_5, var8_6, var13_15);
                            }
                            ** GOTO lbl88
lbl47: // 1 sources:
                            var12_14 = var7_5.a(var4_12.a((j)var1_2 /* !! */ ));
                            if (var4_12 == h.b) {
                                d.c(var7_5, var8_6, var12_14);
                                var12_14 = var10_9;
                                var10_9 = var11_10;
                                var11_10 = var12_14;
                            } else if (var4_12 == h.c) {
                                d.a(var7_5, var8_6, var12_14, var14_11);
                                var12_14 = var10_9;
                                var10_9 = var11_10;
                                var11_10 = var12_14;
                            } else if (var4_12 == h.e) {
                                d.a(var7_5, var8_6, var12_14, var5_8, var6_7, var3_4);
                                var12_14 = var10_9;
                                var10_9 = var11_10;
                                var11_10 = var12_14;
                            } else {
                                if (var4_12 != h.g) throw g.a();
                                d.b(var7_5, var8_6, var12_14);
                                var12_14 = var10_9;
                                var10_9 = var11_10;
                                var11_10 = var12_14;
                            }
                            ** GOTO lbl91
                        }
                        var12_14 = var10_9;
                        var10_9 = var11_10;
                        var11_10 = var12_14;
                        ** GOTO lbl91
                    }
                    var14_11 = true;
                    var12_14 = var10_9;
                    var10_9 = var11_10;
                    var11_10 = var12_14;
                    ** GOTO lbl91
                }
                var12_14 = var10_9;
                var10_9 = var11_10;
                var11_10 = var12_14;
                ** GOTO lbl91
lbl88: // 1 sources:
                var12_14 = var10_9;
                var10_9 = var11_10;
                var11_10 = var12_14;
            }
            if (var4_12 == (var9_13 = h.a)) {
                var3_4 = var8_6.toString();
                var1_2 /* !! */  = var6_7.isEmpty() != false ? null : var6_7;
                if (var2_3 == null) {
                    var2_3 = null;
                    return new com.google.c.b.e(var0, (String)var3_4, var1_2 /* !! */ , (String)var2_3, var10_9, var11_10);
                }
                var2_3 = var2_3.toString();
                return new com.google.c.b.e(var0, (String)var3_4, var1_2 /* !! */ , (String)var2_3, var10_9, var11_10);
            }
            var12_14 = var10_9;
            var10_9 = var11_10;
            var11_10 = var12_14;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void a(c c2, StringBuilder stringBuilder, int n2) {
        if (n2 * 13 > c2.a()) {
            throw g.a();
        }
        byte[] arrby = new byte[n2 * 2];
        int n3 = 0;
        int n4 = n2;
        n2 = n3;
        while (n4 > 0) {
            n3 = c2.a(13);
            n3 = (n3 = n3 % 96 | n3 / 96 << 8) < 959 ? (n3 += 41377) : (n3 += 42657);
            arrby[n2] = (byte)(n3 >> 8);
            arrby[n2 + 1] = (byte)n3;
            --n4;
            n2 += 2;
        }
        try {
            stringBuilder.append(new String(arrby, "GB2312"));
            return;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw g.a();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void a(c object, StringBuilder stringBuilder, int n2, com.google.c.b.d d2, Collection<byte[]> collection, Map<e, ?> map) {
        if (n2 << 3 > object.a()) {
            throw g.a();
        }
        byte[] arrby = new byte[n2];
        for (int i2 = 0; i2 < n2; ++i2) {
            arrby[i2] = (byte)object.a(8);
        }
        object = d2 == null ? l.a(arrby, map) : d2.name();
        try {
            stringBuilder.append(new String(arrby, (String)object));
            collection.add(arrby);
            return;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw g.a();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(c c2, StringBuilder stringBuilder, int n2, boolean bl2) {
        int n3 = stringBuilder.length();
        while (n2 > 1) {
            if (c2.a() < 11) {
                throw g.a();
            }
            int n4 = c2.a(11);
            stringBuilder.append(d.a(n4 / 45));
            stringBuilder.append(d.a(n4 % 45));
            n2 -= 2;
        }
        if (n2 == 1) {
            if (c2.a() < 6) {
                throw g.a();
            }
            stringBuilder.append(d.a(c2.a(6)));
        }
        if (bl2) {
            for (n2 = n3; n2 < stringBuilder.length(); ++n2) {
                if (stringBuilder.charAt(n2) != '%') continue;
                if (n2 < stringBuilder.length() - 1 && stringBuilder.charAt(n2 + 1) == '%') {
                    stringBuilder.deleteCharAt(n2 + 1);
                    continue;
                }
                stringBuilder.setCharAt(n2, '\u001d');
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void b(c c2, StringBuilder stringBuilder, int n2) {
        if (n2 * 13 > c2.a()) {
            throw g.a();
        }
        byte[] arrby = new byte[n2 * 2];
        int n3 = 0;
        int n4 = n2;
        n2 = n3;
        while (n4 > 0) {
            n3 = c2.a(13);
            n3 = (n3 = n3 % 192 | n3 / 192 << 8) < 7936 ? (n3 += 33088) : (n3 += 49472);
            arrby[n2] = (byte)(n3 >> 8);
            arrby[n2 + 1] = (byte)n3;
            --n4;
            n2 += 2;
        }
        try {
            stringBuilder.append(new String(arrby, "SJIS"));
            return;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw g.a();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void c(c c2, StringBuilder stringBuilder, int n2) {
        while (n2 >= 3) {
            if (c2.a() < 10) {
                throw g.a();
            }
            int n3 = c2.a(10);
            if (n3 >= 1000) {
                throw g.a();
            }
            stringBuilder.append(d.a(n3 / 100));
            stringBuilder.append(d.a(n3 / 10 % 10));
            stringBuilder.append(d.a(n3 % 10));
            n2 -= 3;
        }
        if (n2 == 2) {
            if (c2.a() < 7) {
                throw g.a();
            }
            n2 = c2.a(7);
            if (n2 >= 100) {
                throw g.a();
            }
            stringBuilder.append(d.a(n2 / 10));
            stringBuilder.append(d.a(n2 % 10));
            return;
        }
        if (n2 != 1) return;
        {
            if (c2.a() < 4) {
                throw g.a();
            }
        }
        n2 = c2.a(4);
        if (n2 >= 10) {
            throw g.a();
        }
        stringBuilder.append(d.a(n2));
    }
}

