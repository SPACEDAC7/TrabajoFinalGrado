/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.a;

import com.google.c.g.a.a;
import com.google.c.g.a.b;
import com.google.c.g.a.c;
import com.google.c.g.a.d;
import com.google.c.g.a.f;
import com.google.c.g.a.g;
import com.google.c.g.a.i;
import com.google.c.g.a.j;
import java.util.Map;

public final class e {
    private final com.google.c.b.b.c a = new com.google.c.b.b.c(com.google.c.b.b.a.e);

    /*
     * Enabled aggressive block sorting
     */
    private com.google.c.b.e a(a arrb, Map<com.google.c.e, ?> map) {
        int n2;
        int n3;
        int n4;
        int n5;
        j j2 = arrb.b();
        f f2 = arrb.a().a;
        byte[] arrby = arrb.a();
        j j3 = arrb.b();
        arrby = c.a(arrby.b);
        int n6 = arrb.a.b;
        arrby.a(arrb.a, n6);
        int n7 = j3.a();
        j.a[] arra = new j.a[](n7);
        arra.a(0, 0, 9, 9);
        arra.a(n7 - 8, 0, 8, 9);
        arra.a(0, n7 - 8, 9, 8);
        int n8 = j3.b.length;
        for (n4 = 0; n4 < n8; ++n4) {
            n5 = j3.b[n4];
            for (n3 = 0; n3 < n8; ++n3) {
                if (n4 == 0 && (n3 == 0 || n3 == n8 - 1) || n4 == n8 - 1 && n3 == 0) continue;
                arra.a(j3.b[n3] - 2, n5 - 2, 5, 5);
            }
        }
        arra.a(6, 9, 1, n7 - 17);
        arra.a(9, 6, n7 - 17, 1);
        if (j3.a > 6) {
            arra.a(n7 - 11, 0, 3, 6);
            arra.a(0, n7 - 11, 6, 3);
        }
        arrby = new byte[j3.c];
        n8 = 0;
        n4 = 0;
        n3 = 0;
        n7 = n6 - 1;
        int n9 = 1;
        block2 : do {
            int n10;
            if (n7 > 0) {
                n10 = n7;
                if (n7 == 6) {
                    n10 = n7 - 1;
                }
            } else {
                if (n8 != j3.c) {
                    throw com.google.c.g.a();
                }
                if (arrby.length != j2.c) {
                    throw new IllegalArgumentException();
                }
                j.b b2 = j2.a(f2);
                n3 = 0;
                arra = b2.b;
                n7 = arra.length;
                for (n4 = 0; n4 < n7; n3 += arra[n4].a, ++n4) {
                }
                arrb = new b[n3];
                n7 = 0;
                n8 = arra.length;
                break;
            }
            n7 = 0;
            do {
                int n11;
                if (n7 < n6) {
                    n11 = n9 != 0 ? n6 - 1 - n7 : n7;
                    n5 = n3;
                    n3 = n4;
                    n4 = n5;
                } else {
                    n7 = n10 - 2;
                    n9 ^= true;
                    continue block2;
                }
                for (int i2 = 0; i2 < 2; ++i2) {
                    n2 = n4;
                    n5 = n3;
                    if (!arra.a(n10 - i2, n11)) {
                        int n12 = n4 + 1;
                        n4 = n3 <<= 1;
                        if (arrb.a.a(n10 - i2, n11)) {
                            n4 = n3 | 1;
                        }
                        n2 = n12;
                        n5 = n4;
                        if (n12 == 8) {
                            n3 = n8 + 1;
                            arrby[n8] = (byte)n4;
                            n4 = 0;
                            n5 = 0;
                            n8 = n3;
                            n3 = n5;
                            continue;
                        }
                    }
                    n4 = n2;
                    n3 = n5;
                }
                ++n7;
                n5 = n3;
                n3 = n4;
                n4 = n5;
            } while (true);
            break;
        } while (true);
        for (n4 = 0; n4 < n8; ++n4) {
            j.a a2 = arra[n4];
            for (n3 = 0; n3 < a2.a; ++n3, ++n7) {
                n5 = a2.b;
                arrb[n7] = new b(n5, new byte[b2.a + n5]);
            }
        }
        n3 = arrb[0].b.length;
        for (n4 = arrb.length - 1; n4 >= 0 && arrb[n4].b.length != n3; --n4) {
        }
        n2 = n4 + 1;
        n5 = n3 - b2.a;
        n4 = 0;
        for (n3 = 0; n3 < n5; ++n3) {
            for (n8 = 0; n8 < n7; ++n8, ++n4) {
                arrb[n8].b[n3] = arrby[n4];
            }
        }
        n3 = n4;
        for (n8 = n2; n8 < n7; ++n8, ++n3) {
            arrb[n8].b[n5] = arrby[n3];
        }
        n9 = arrb[0].b.length;
        n4 = n5;
        do {
            if (n4 < n9) {
            } else {
                n3 = 0;
                n7 = arrb.length;
                for (n4 = 0; n4 < n7; n3 += arrb[n4].a, ++n4) {
                }
                break;
            }
            for (n8 = 0; n8 < n7; ++n8, ++n3) {
                n5 = n8 < n2 ? n4 : n4 + 1;
                arrb[n8].b[n5] = arrby[n3];
            }
            ++n4;
        } while (true);
        arrby = new byte[n3];
        n3 = 0;
        n8 = arrb.length;
        n4 = 0;
        while (n4 < n8) {
            b b3 = arrb[n4];
            arra = b3.b;
            n5 = b3.a;
            this.a((byte[])arra, n5);
            for (n7 = 0; n7 < n5; ++n7, ++n3) {
                arrby[n3] = arra[n7];
            }
            ++n4;
        }
        return d.a(arrby, j2, f2, map);
    }

    private void a(byte[] arrby, int n2) {
        int n3;
        int n4 = 0;
        int n5 = arrby.length;
        int[] arrn = new int[n5];
        for (n3 = 0; n3 < n5; ++n3) {
            arrn[n3] = arrby[n3] & 255;
        }
        n3 = arrby.length;
        try {
            this.a.a(arrn, n3 - n2);
        }
        catch (com.google.c.b.b.e var1_2) {
            throw com.google.c.d.a();
        }
        for (n3 = n4; n3 < n2; ++n3) {
            arrby[n3] = (byte)arrn[n3];
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final com.google.c.b.e a(com.google.c.b.b var1_1, Map<com.google.c.e, ?> var2_3) {
        block15 : {
            var4_7 = new a((com.google.c.b.b)var1_1);
            try {
                return this.a(var4_7, var2_3);
            }
            catch (com.google.c.g var3_8) {
                var1_1 = null;
                ** GOTO lbl9
                catch (com.google.c.d var1_2) {
                    var3_9 = null;
                }
lbl9: // 2 sources:
                try {
                    if (var4_7.c != null) {
                        var5_10 = c.a(var4_7.c.b);
                        var6_11 = var4_7.a.b;
                        var5_10.a(var4_7.a, var6_11);
                    }
                    var4_7.b = null;
                    var4_7.c = null;
                    var4_7.d = true;
                    var4_7.b();
                    var4_7.a();
                    var6_11 = 0;
lbl20: // 2 sources:
                    if (var6_11 < var4_7.a.a) {
                        var7_12 = var6_11 + 1;
                    } else {
                        var2_3 = this.a(var4_7, var2_3);
                        var2_3.g = new i();
                        return var2_3;
                    }
lbl26: // 2 sources:
                    if (var7_12 >= var4_7.a.b) break block15;
                    if (var4_7.a.a(var6_11, var7_12) != var4_7.a.a(var7_12, var6_11)) {
                        var4_7.a.c(var7_12, var6_11);
                        var4_7.a.c(var6_11, var7_12);
                    }
                }
                catch (com.google.c.g var2_4) {}
                ** GOTO lbl-1000
                catch (com.google.c.d var2_6) {}
lbl-1000: // 2 sources:
                {
                    if (var3_9 != null) {
                        throw var3_9;
                    }
                    if (var1_1 == null) throw var2_5;
                    throw var1_1;
                }
                ++var7_12;
                ** GOTO lbl26
            }
        }
        ++var6_11;
        ** GOTO lbl20
    }
}

