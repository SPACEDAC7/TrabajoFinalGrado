/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.a;

public enum f {
    a(1),
    b(0),
    c(3),
    d(2);
    
    private static final f[] f;
    public final int e;

    static {
        f = new f[]{b, a, d, c};
    }

    private f(int n3) {
        this.e = n3;
    }

    public static f a(int n2) {
        if (n2 < 0 || n2 >= f.length) {
            throw new IllegalArgumentException();
        }
        return f[n2];
    }
}

