/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.a;

import com.google.c.g.a.f;

final class g {
    private static final int[][] c;
    private static final int[] d;
    final f a;
    final byte b;

    static {
        int[] arrn = new int[]{25368, 13};
        int[] arrn2 = new int[]{16177, 26};
        c = new int[][]{{21522, 0}, {20773, 1}, {24188, 2}, {23371, 3}, {17913, 4}, {16590, 5}, {20375, 6}, {19104, 7}, {30660, 8}, {29427, 9}, {32170, 10}, {30877, 11}, {26159, 12}, arrn, {27713, 14}, {26998, 15}, {5769, 16}, {5054, 17}, {7399, 18}, {6608, 19}, {1890, 20}, {597, 21}, {3340, 22}, {2107, 23}, {13663, 24}, {12392, 25}, arrn2, {14854, 27}, {9396, 28}, {8579, 29}, {11994, 30}, {11245, 31}};
        d = new int[]{0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4};
    }

    private g(int n2) {
        this.a = f.a(n2 >> 3 & 3);
        this.b = (byte)(n2 & 7);
    }

    static int a(int n2, int n3) {
        n3 = d[(n2 ^= n3) & 15];
        int n4 = d[n2 >>> 4 & 15];
        int n5 = d[n2 >>> 8 & 15];
        int n6 = d[n2 >>> 12 & 15];
        int n7 = d[n2 >>> 16 & 15];
        int n8 = d[n2 >>> 20 & 15];
        int n9 = d[n2 >>> 24 & 15];
        return d[n2 >>> 28 & 15] + (n3 + n4 + n5 + n6 + n7 + n8 + n9);
    }

    static g b(int n2, int n3) {
        g g2 = g.c(n2, n3);
        if (g2 != null) {
            return g2;
        }
        return g.c(n2 ^ 21522, n3 ^ 21522);
    }

    private static g c(int n2, int n3) {
        int n4 = Integer.MAX_VALUE;
        int[][] arrn = c;
        int n5 = arrn.length;
        int n6 = 0;
        for (int i2 = 0; i2 < n5; ++i2) {
            int[] arrn2 = arrn[i2];
            int n7 = arrn2[0];
            if (n7 == n2 || n7 == n3) {
                return new g(arrn2[1]);
            }
            int n8 = g.a(n2, n7);
            if (n8 < n4) {
                n6 = arrn2[1];
                n4 = n8;
            }
            if (n2 == n3 || (n8 = g.a(n3, n7)) >= n4) continue;
            n6 = arrn2[1];
            n4 = n8;
        }
        if (n4 <= 3) {
            return new g(n6);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (!(object instanceof g)) {
            return false;
        }
        object = (g)object;
        if (this.a != object.a) return false;
        if (this.b != object.b) return false;
        return true;
    }

    public final int hashCode() {
        return this.a.ordinal() << 3 | this.b;
    }
}

