/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.a;

import com.google.c.g.a.j;

public enum h {
    a(new int[]{0, 0, 0}, 0),
    b(new int[]{10, 12, 14}, 1),
    c(new int[]{9, 11, 13}, 2),
    d(new int[]{0, 0, 0}, 3),
    e(new int[]{8, 16, 16}, 4),
    f(new int[]{0, 0, 0}, 7),
    g(new int[]{8, 10, 12}, 8),
    h(new int[]{0, 0, 0}, 5),
    i(new int[]{0, 0, 0}, 9),
    j(new int[]{8, 10, 12}, 13);
    
    public final int k;
    private final int[] l;

    private h(int[] arrn, int n3) {
        this.l = arrn;
        this.k = n3;
    }

    public static h a(int n2) {
        switch (n2) {
            default: {
                throw new IllegalArgumentException();
            }
            case 0: {
                return a;
            }
            case 1: {
                return b;
            }
            case 2: {
                return c;
            }
            case 3: {
                return d;
            }
            case 4: {
                return e;
            }
            case 5: {
                return h;
            }
            case 7: {
                return f;
            }
            case 8: {
                return g;
            }
            case 9: {
                return i;
            }
            case 13: 
        }
        return j;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final int a(j j2) {
        int n2 = j2.a;
        if (n2 <= 9) {
            n2 = 0;
            do {
                return this.l[n2];
                break;
            } while (true);
        }
        if (n2 <= 26) {
            n2 = 1;
            return this.l[n2];
        }
        n2 = 2;
        return this.l[n2];
    }
}

