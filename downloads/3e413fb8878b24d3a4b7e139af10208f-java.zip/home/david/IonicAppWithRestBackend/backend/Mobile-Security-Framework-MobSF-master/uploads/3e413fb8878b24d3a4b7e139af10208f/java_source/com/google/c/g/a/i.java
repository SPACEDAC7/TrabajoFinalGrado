/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.a;

public final class i {
    public final boolean a = true;

    i() {
    }
}

