/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.b;

import com.google.c.p;

public final class a
extends p {
    final float c;

    a(float f2, float f3, float f4) {
        super(f2, f3);
        this.c = f4;
    }
}

