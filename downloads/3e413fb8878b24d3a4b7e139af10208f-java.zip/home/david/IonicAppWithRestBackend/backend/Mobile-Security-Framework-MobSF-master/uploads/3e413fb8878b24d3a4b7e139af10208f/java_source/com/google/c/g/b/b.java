/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.b;

import android.support.design.widget.AppBarLayout;
import com.google.c.g.b.a;
import com.google.c.p;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

final class b {
    final com.google.c.b.b a;
    final List<a> b;
    final int c;
    final int d;
    final int e;
    final int f;
    private final float g;
    private final int[] h;
    private final AppBarLayout.b i;

    b(com.google.c.b.b b2, int n2, int n3, int n4, int n5, float f2, AppBarLayout.b b3) {
        this.a = b2;
        this.b = new ArrayList<a>(5);
        this.c = n2;
        this.d = n3;
        this.e = n4;
        this.f = n5;
        this.g = f2;
        this.h = new int[3];
        this.i = b3;
    }

    private static float a(int[] arrn, int n2) {
        return (float)(n2 - arrn[2]) - (float)arrn[1] / 2.0f;
    }

    /*
     * Enabled aggressive block sorting
     */
    final a a(int[] object, int n2, int n3) {
        float f2;
        reference var10_4 = object[0];
        Object object2 = object[1];
        var10_4 = object[2] + (var10_4 + object2);
        float f3 = b.a((int[])object, n3);
        object2 = (int)f3;
        reference var12_7 = object[1] * 2;
        Object object3 = this.a;
        int n4 = object3.b;
        int[] arrn = this.h;
        arrn[0] = 0;
        arrn[1] = 0;
        arrn[2] = 0;
        for (n3 = n2; n3 >= 0 && object3.a((int)object2, n3) && arrn[1] <= var12_7; --n3) {
            arrn[1] = arrn[1] + 1;
        }
        if (n3 < 0 || arrn[1] > var12_7) {
            f2 = Float.NaN;
        } else {
            while (n3 >= 0 && !object3.a((int)object2, n3) && arrn[0] <= var12_7) {
                arrn[0] = arrn[0] + 1;
                --n3;
            }
            if (arrn[0] > var12_7) {
                f2 = Float.NaN;
            } else {
                ++n2;
                while (n2 < n4 && object3.a((int)object2, n2) && arrn[1] <= var12_7) {
                    arrn[1] = arrn[1] + 1;
                    ++n2;
                }
                if (n2 == n4 || arrn[1] > var12_7) {
                    f2 = Float.NaN;
                } else {
                    while (n2 < n4 && !object3.a((int)object2, n2) && arrn[2] <= var12_7) {
                        arrn[2] = arrn[2] + 1;
                        ++n2;
                    }
                    f2 = arrn[2] > var12_7 ? Float.NaN : (Math.abs(arrn[0] + arrn[1] + arrn[2] - var10_4) * 5 >= var10_4 * 2 ? Float.NaN : (this.a(arrn) ? b.a(arrn, n2) : Float.NaN));
                }
            }
        }
        if (Float.isNaN(f2)) return null;
        reference var6_12 = (Object)(object[0] + object[1] + object[2]) / 3.0f;
        object = this.b.iterator();
        do {
            if (!object.hasNext()) {
                object = new a(f3, f2, (float)var6_12);
                this.b.add((a)object);
                return null;
            }
            object3 = object.next();
            if (Math.abs(f2 - object3.b) <= var6_12 && Math.abs(f3 - object3.a) <= var6_12) {
                float f4 = Math.abs((float)(var6_12 - object3.c));
                if (f4 <= 1.0f || f4 <= object3.c) {
                    return new a((object3.a + f3) / 2.0f, (f2 + object3.b) / 2.0f, (object3.c + var6_12) / 2.0f);
                }
                n2 = 0;
                continue;
            }
            n2 = 0;
        } while (n2 == 0);
        return new a((object3.a + f3) / 2.0f, (f2 + object3.b) / 2.0f, (object3.c + var6_12) / 2.0f);
    }

    final boolean a(int[] arrn) {
        float f2 = this.g;
        float f3 = f2 / 2.0f;
        for (int i2 = 0; i2 < 3; ++i2) {
            if (Math.abs(f2 - (float)arrn[i2]) < f3) continue;
            return false;
        }
        return true;
    }
}

