/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.b;

import a.a.a.a.d;
import android.support.design.widget.AppBarLayout;
import com.google.c.b.b;
import com.google.c.b.g;
import com.google.c.g.b.f;
import com.google.c.p;

public final class c {
    public final b a;
    public AppBarLayout.b b;

    public c(b b2) {
        this.a = b2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private float a(int n2, int n3, int n4, int n5) {
        float f2;
        int n6 = 0;
        float f3 = this.b(n2, n3, n4, n5);
        if ((n4 = n2 - (n4 - n2)) < 0) {
            f2 = (float)n2 / (float)(n2 - n4);
            n4 = 0;
        } else if (n4 >= this.a.a) {
            f2 = (float)(this.a.a - 1 - n2) / (float)(n4 - n2);
            n4 = this.a.a - 1;
        } else {
            f2 = 1.0f;
        }
        if ((n5 = (int)((float)n3 - f2 * (float)(n5 - n3))) < 0) {
            f2 = (float)n3 / (float)(n3 - n5);
            n5 = n6;
        } else if (n5 >= this.a.b) {
            f2 = (float)(this.a.b - 1 - n3) / (float)(n5 - n3);
            n5 = this.a.b - 1;
        } else {
            f2 = 1.0f;
        }
        float f4 = n2;
        return this.b(n2, n3, (int)(f2 * (float)(n4 - n2) + f4), n5) + f3 - 1.0f;
    }

    private float a(p p2, p p3) {
        float f2 = this.a((int)p2.a, (int)p2.b, (int)p3.a, (int)p3.b);
        float f3 = this.a((int)p3.a, (int)p3.b, (int)p2.a, (int)p2.b);
        if (Float.isNaN(f2)) {
            return f3 / 7.0f;
        }
        if (Float.isNaN(f3)) {
            return f2 / 7.0f;
        }
        return (f2 + f3) / 14.0f;
    }

    /*
     * Enabled aggressive block sorting
     */
    private float b(int n2, int n3, int n4, int n5) {
        int n6;
        int n7;
        int n8;
        boolean bl2 = Math.abs(n5 - n3) > Math.abs(n4 - n2);
        if (bl2) {
            n6 = n5;
            n8 = n4;
            n7 = n3;
            n5 = n2;
        } else {
            n8 = n5;
            n5 = n3;
            n7 = n2;
            n6 = n4;
        }
        int n9 = Math.abs(n6 - n7);
        int n10 = Math.abs(n8 - n5);
        int n11 = (- n9) / 2;
        int n12 = n7 < n6 ? 1 : -1;
        int n13 = n5 < n8 ? 1 : -1;
        n4 = 0;
        n2 = n5;
        for (n3 = n7; n3 != n6 + n12; n3 += n12) {
            int n14;
            int n15;
            boolean bl3 = n4 == 1;
            if (bl3 == this.a.a(n14 = bl2 ? n2 : n3, n15 = bl2 ? n3 : n2)) {
                if (n4 == 2) {
                    return d.a(n3, n2, n7, n5);
                }
                ++n4;
            }
            if ((n11 += n10) <= 0) continue;
            if (n2 == n8) break;
            n2 += n13;
            n11 -= n9;
        }
        if (n4 == 2) {
            return d.a(n6 + n12, n8, n7, n5);
        }
        return Float.NaN;
    }

    /*
     * Exception decompiling
     */
    public final g a(f var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 4 blocks at once
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:371)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:449)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }
}

