/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.b;

import com.google.c.p;

public final class d
extends p {
    public final float c;
    public final int d;

    d(float f2, float f3, float f4) {
        this(f2, f3, f4, 1);
    }

    d(float f2, float f3, float f4, int n2) {
        super(f2, f3);
        this.c = f4;
        this.d = n2;
    }
}

