/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.b;

import android.support.design.widget.AppBarLayout;
import com.google.c.g.b.d;
import com.google.c.p;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public final class e {
    public final com.google.c.b.b a;
    public final List<d> b;
    public boolean c;
    private final int[] d;
    private final AppBarLayout.b e;

    public e(com.google.c.b.b b2, AppBarLayout.b b3) {
        this.a = b2;
        this.b = new ArrayList<d>();
        this.d = new int[5];
        this.e = b3;
    }

    private static float a(int[] arrn, int n2) {
        return (float)(n2 - arrn[4] - arrn[3]) - (float)arrn[2] / 2.0f;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean a(int[] arrn) {
        int n2;
        int n3 = 0;
        for (int i2 = 0; i2 < 5; n3 += n2, ++i2) {
            n2 = arrn[i2];
            if (n2 == 0) return false;
            {
                continue;
            }
        }
        if (n3 < 7) return false;
        float f2 = (float)n3 / 7.0f;
        float f3 = f2 / 2.0f;
        if (Math.abs(f2 - (float)arrn[0]) < f3 && Math.abs(f2 - (float)arrn[1]) < f3 && Math.abs(3.0f * f2 - (float)arrn[2]) < 3.0f * f3 && Math.abs(f2 - (float)arrn[3]) < f3 && Math.abs(f2 - (float)arrn[4]) < f3) return true;
        return false;
    }

    private int[] b() {
        this.d[0] = 0;
        this.d[1] = 0;
        this.d[2] = 0;
        this.d[3] = 0;
        this.d[4] = 0;
        return this.d;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean a() {
        float f2 = 0.0f;
        int n2 = this.b.size();
        Iterator<d> iterator = this.b.iterator();
        float f3 = 0.0f;
        int n3 = 0;
        while (iterator.hasNext()) {
            d d2 = iterator.next();
            if (d2.d < 2) continue;
            f3 = d2.c + f3;
            ++n3;
        }
        if (n3 < 3) {
            return false;
        }
        float f4 = f3 / (float)n2;
        iterator = this.b.iterator();
        do {
            if (!iterator.hasNext()) {
                if (f2 > 0.05f * f3) return false;
                return true;
            }
            f2 += Math.abs(iterator.next().c - f4);
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean a(int[] object, int n2, int n3, boolean bl2) {
        int n4;
        float f2;
        reference var14_5 = object[0] + object[1] + object[2] + object[3] + object[4];
        float f3 = e.a((int[])object, n3);
        int n5 = (int)f3;
        Object object2 = object[2];
        Object object3 = this.a;
        int n6 = object3.b;
        int[] arrn = this.b();
        for (n3 = n2; n3 >= 0 && object3.a(n5, n3); --n3) {
            arrn[2] = arrn[2] + 1;
        }
        if (n3 < 0) {
            f2 = Float.NaN;
        } else {
            for (n4 = n3; n4 >= 0 && !object3.a(n5, n4) && arrn[1] <= object2; --n4) {
                arrn[1] = arrn[1] + 1;
            }
            if (n4 < 0 || arrn[1] > object2) {
                f2 = Float.NaN;
            } else {
                while (n4 >= 0 && object3.a(n5, n4) && arrn[0] <= object2) {
                    arrn[0] = arrn[0] + 1;
                    --n4;
                }
                if (arrn[0] > object2) {
                    f2 = Float.NaN;
                } else {
                    ++n2;
                    while (n2 < n6 && object3.a(n5, n2)) {
                        arrn[2] = arrn[2] + 1;
                        ++n2;
                    }
                    if (n2 == n6) {
                        f2 = Float.NaN;
                    } else {
                        for (n3 = n2; n3 < n6 && !object3.a(n5, n3) && arrn[3] < object2; ++n3) {
                            arrn[3] = arrn[3] + 1;
                        }
                        if (n3 == n6 || arrn[3] >= object2) {
                            f2 = Float.NaN;
                        } else {
                            while (n3 < n6 && object3.a(n5, n3) && arrn[4] < object2) {
                                arrn[4] = arrn[4] + 1;
                                ++n3;
                            }
                            f2 = arrn[4] >= object2 ? Float.NaN : (Math.abs(arrn[0] + arrn[1] + arrn[2] + arrn[3] + arrn[4] - var14_5) * 5 >= var14_5 * 2 ? Float.NaN : (e.a(arrn) ? e.a(arrn, n3) : Float.NaN));
                        }
                    }
                }
            }
        }
        if (Float.isNaN(f2)) return false;
        n4 = (int)f3;
        n5 = (int)f2;
        object2 = object[2];
        object3 = this.a;
        n6 = object3.a;
        arrn = this.b();
        for (n2 = n4; n2 >= 0 && object3.a(n2, n5); --n2) {
            arrn[2] = arrn[2] + 1;
        }
        if (n2 < 0) {
            f3 = Float.NaN;
        } else {
            for (n3 = n2; n3 >= 0 && !object3.a(n3, n5) && arrn[1] <= object2; --n3) {
                arrn[1] = arrn[1] + 1;
            }
            if (n3 < 0 || arrn[1] > object2) {
                f3 = Float.NaN;
            } else {
                while (n3 >= 0 && object3.a(n3, n5) && arrn[0] <= object2) {
                    arrn[0] = arrn[0] + 1;
                    --n3;
                }
                if (arrn[0] > object2) {
                    f3 = Float.NaN;
                } else {
                    for (n2 = n4 + 1; n2 < n6 && object3.a(n2, n5); ++n2) {
                        arrn[2] = arrn[2] + 1;
                    }
                    if (n2 == n6) {
                        f3 = Float.NaN;
                    } else {
                        for (n3 = n2; n3 < n6 && !object3.a(n3, n5) && arrn[3] < object2; ++n3) {
                            arrn[3] = arrn[3] + 1;
                        }
                        if (n3 == n6 || arrn[3] >= object2) {
                            f3 = Float.NaN;
                        } else {
                            while (n3 < n6 && object3.a(n3, n5) && arrn[4] < object2) {
                                arrn[4] = arrn[4] + 1;
                                ++n3;
                            }
                            f3 = arrn[4] >= object2 ? Float.NaN : (Math.abs(arrn[0] + arrn[1] + arrn[2] + arrn[3] + arrn[4] - var14_5) * 5 >= var14_5 ? Float.NaN : (e.a(arrn) ? e.a(arrn, n3) : Float.NaN));
                        }
                    }
                }
            }
        }
        if (Float.isNaN(f3)) return false;
        if (bl2) {
            n4 = (int)f2;
            n5 = (int)f3;
            object2 = object[2];
            object = this.b();
            for (n2 = 0; n4 >= n2 && n5 >= n2 && this.a.a(n5 - n2, n4 - n2); ++n2) {
                object[2] = object[2] + true;
            }
            if (n4 < n2) return false;
            if (n5 < n2) {
                return false;
            }
            for (n3 = n2; n4 >= n3 && n5 >= n3 && !this.a.a(n5 - n3, n4 - n3) && object[1] <= object2; ++n3) {
                object[1] = object[1] + true;
            }
            if (n4 < n3 || n5 < n3 || object[1] > object2) {
                return false;
            }
            while (n4 >= n3 && n5 >= n3 && this.a.a(n5 - n3, n4 - n3) && object[0] <= object2) {
                object[0] = object[0] + true;
                ++n3;
            }
            if (object[0] > object2) return false;
            n6 = this.a.b;
            int n7 = this.a.a;
            n2 = 1;
            while (n4 + n2 < n6 && n5 + n2 < n7 && this.a.a(n5 + n2, n4 + n2)) {
                object[2] = object[2] + true;
                ++n2;
            }
            if (n4 + n2 >= n6) return false;
            n3 = n2;
            if (n5 + n2 >= n7) {
                return false;
            }
            while (n4 + n3 < n6 && n5 + n3 < n7 && !this.a.a(n5 + n3, n4 + n3) && object[3] < object2) {
                object[3] = object[3] + true;
                ++n3;
            }
            if (n4 + n3 >= n6 || n5 + n3 >= n7 || object[3] >= object2) {
                return false;
            }
            while (n4 + n3 < n6 && n5 + n3 < n7 && this.a.a(n5 + n3, n4 + n3) && object[4] < object2) {
                object[4] = object[4] + true;
                ++n3;
            }
            if (object[4] >= object2 || Math.abs((int)(object[0] + object[1] + object[2] + object[3] + object[4] - var14_5)) >= var14_5 * 2 || !e.a((int[])object)) return false;
            {
                n2 = 1;
                if (n2 == 0) {
                    return false;
                }
            }
        }
        reference var7_15 = (Object)var14_5 / 7.0f;
        for (n3 = 0; n3 < this.b.size(); ++n3) {
            float f4;
            object = this.b.get(n3);
            n2 = Math.abs(f2 - object.b) <= var7_15 && Math.abs(f3 - object.a) <= var7_15 ? ((f4 = Math.abs((float)(var7_15 - object.c))) <= 1.0f || f4 <= object.c ? 1 : 0) : 0;
            if (n2 == 0) continue;
            object3 = this.b;
            n2 = object.d + 1;
            f4 = ((float)object.d * object.a + f3) / (float)n2;
            float f5 = ((float)object.d * object.b + f2) / (float)n2;
            float f6 = object.d;
            object3.set(n3, new d(f4, f5, (object.c * f6 + var7_15) / (float)n2, n2));
            return true;
        }
        n2 = 0;
        if (n2 != 0) return true;
        {
            object = new d(f3, f2, (float)var7_15);
            this.b.add((d)object);
        }
        return true;
    }

    public static final class a
    implements Serializable,
    Comparator<d> {
        private final float a;

        private a(float f2) {
            this.a = f2;
        }

        public /* synthetic */ a(float f2, byte by2) {
            this(f2);
        }

        @Override
        public final /* synthetic */ int compare(Object object, Object object2) {
            object = (d)object;
            object2 = (d)object2;
            if (object2.d == object.d) {
                float f2;
                float f3 = Math.abs(object2.c - this.a);
                if (f3 < (f2 = Math.abs(object.c - this.a))) {
                    return 1;
                }
                if (f3 == f2) {
                    return 0;
                }
                return -1;
            }
            return object2.d - object.d;
        }
    }

    public static final class b
    implements Serializable,
    Comparator<d> {
        private final float a;

        private b(float f2) {
            this.a = f2;
        }

        public /* synthetic */ b(float f2, byte by2) {
            this(f2);
        }

        @Override
        public final /* synthetic */ int compare(Object object, Object object2) {
            float f2;
            object = (d)object;
            float f3 = Math.abs(((d)object2).c - this.a);
            if (f3 < (f2 = Math.abs(object.c - this.a))) {
                return -1;
            }
            if (f3 == f2) {
                return 0;
            }
            return 1;
        }
    }

}

