/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.b;

import com.google.c.g.b.d;

public final class f {
    final d a;
    final d b;
    final d c;

    public f(d[] arrd) {
        this.a = arrd[0];
        this.b = arrd[1];
        this.c = arrd[2];
    }
}

