/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.c;

final class a {
    final byte[] a;
    final byte[] b;

    a(byte[] arrby, byte[] arrby2) {
        this.a = arrby;
        this.b = arrby2;
    }
}

