/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.c;

import java.lang.reflect.Array;

public final class b {
    final byte[][] a;
    final int b;
    final int c;

    public b(int n2, int n3) {
        this.a = (byte[][])Array.newInstance(Byte.TYPE, n3, n2);
        this.b = n2;
        this.c = n3;
    }

    public final byte a(int n2, int n3) {
        return this.a[n3][n2];
    }

    public final int a() {
        return this.c;
    }

    public final void a(int n2, int n3, int n4) {
        this.a[n3][n2] = (byte)n4;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2, int n3, boolean bl2) {
        byte[] arrby = this.a[n3];
        n3 = bl2 ? 1 : 0;
        arrby[n2] = (byte)n3;
    }

    public final int b() {
        return this.b;
    }

    public final byte[][] c() {
        return this.a;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(this.b * 2 * this.c + 2);
        int n2 = 0;
        while (n2 < this.c) {
            block5 : for (int i2 = 0; i2 < this.b; ++i2) {
                switch (this.a[n2][i2]) {
                    default: {
                        stringBuilder.append("  ");
                        continue block5;
                    }
                    case 0: {
                        stringBuilder.append(" 0");
                        continue block5;
                    }
                    case 1: {
                        stringBuilder.append(" 1");
                    }
                }
            }
            stringBuilder.append('\n');
            ++n2;
        }
        return stringBuilder.toString();
    }
}

