/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.c;

import com.google.c.f;
import com.google.c.g.a.h;
import com.google.c.g.a.j;
import com.google.c.g.c.a;
import com.google.c.g.c.b;
import com.google.c.g.c.d;
import com.google.c.g.c.e;
import com.google.c.q;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public final class c {
    private static final int[] a = new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 36, -1, -1, -1, 37, 38, -1, -1, -1, -1, 39, 40, -1, 41, 42, 43, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 44, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, -1, -1, -1, -1, -1};

    private static int a(int n2) {
        if (n2 < a.length) {
            return a[n2];
        }
        return -1;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int a(com.google.c.b.a var0, com.google.c.g.a.f var1_1, j var2_2, b var3_3) {
        var8_4 = Integer.MAX_VALUE;
        var9_5 = -1;
        var7_6 = 0;
        while (var7_6 < 8) {
            d.a(var0, var1_1, var2_2, var7_6, var3_3);
            var15_18 = a.a.a.a.d.a(var3_3, true);
            var16_8 = a.a.a.a.d.a(var3_3, false);
            var10_13 = 0;
            var4_10 = var3_3.a;
            var13_16 = var3_3.b;
            var14_17 = var3_3.c;
            for (var11_14 = 0; var11_14 < var14_17 - 1; ++var11_14) {
                var6_12 = var10_13;
                for (var10_13 = 0; var10_13 < var13_16 - 1; ++var10_13) {
                    var17_7 = var4_10[var11_14][var10_13];
                    var12_15 = var6_12;
                    if (var17_7 == var4_10[var11_14][var10_13 + 1]) {
                        var12_15 = var6_12;
                        if (var17_7 == var4_10[var11_14 + 1][var10_13]) {
                            var12_15 = var6_12;
                            if (var17_7 == var4_10[var11_14 + 1][var10_13 + 1]) {
                                var12_15 = var6_12 + 1;
                            }
                        }
                    }
                    var6_12 = var12_15;
                }
                var10_13 = var6_12;
            }
            var6_12 = 0;
            var4_10 = var3_3.a;
            var14_17 = var3_3.b;
            var17_7 = var3_3.c;
            for (var12_15 = 0; var12_15 < var17_7; ++var12_15) {
                for (var13_16 = 0; var13_16 < var14_17; ++var13_16) {
                    var5_11 = var4_10[var12_15];
                    var11_14 = var6_12;
                    if (var13_16 + 6 >= var14_17) ** GOTO lbl54
                    var11_14 = var6_12;
                    if (var5_11[var13_16] != 1) ** GOTO lbl54
                    var11_14 = var6_12;
                    if (var5_11[var13_16 + 1] != 0) ** GOTO lbl54
                    var11_14 = var6_12;
                    if (var5_11[var13_16 + 2] != 1) ** GOTO lbl54
                    var11_14 = var6_12;
                    if (var5_11[var13_16 + 3] != 1) ** GOTO lbl54
                    var11_14 = var6_12;
                    if (var5_11[var13_16 + 4] != 1) ** GOTO lbl54
                    var11_14 = var6_12;
                    if (var5_11[var13_16 + 5] != 0) ** GOTO lbl54
                    var11_14 = var6_12;
                    if (var5_11[var13_16 + 6] != 1) ** GOTO lbl54
                    if (a.a.a.a.d.a(var5_11, var13_16 - 4, var13_16)) ** GOTO lbl-1000
                    var11_14 = var6_12;
                    if (a.a.a.a.d.a(var5_11, var13_16 + 7, var13_16 + 11)) lbl-1000: // 2 sources:
                    {
                        var11_14 = var6_12 + 1;
                    }
lbl54: // 11 sources:
                    var6_12 = var11_14;
                    if (var12_15 + 6 >= var17_7) continue;
                    var6_12 = var11_14;
                    if (var4_10[var12_15][var13_16] != 1) continue;
                    var6_12 = var11_14;
                    if (var4_10[var12_15 + 1][var13_16] != 0) continue;
                    var6_12 = var11_14;
                    if (var4_10[var12_15 + 2][var13_16] != 1) continue;
                    var6_12 = var11_14;
                    if (var4_10[var12_15 + 3][var13_16] != 1) continue;
                    var6_12 = var11_14;
                    if (var4_10[var12_15 + 4][var13_16] != 1) continue;
                    var6_12 = var11_14;
                    if (var4_10[var12_15 + 5][var13_16] != 0) continue;
                    var6_12 = var11_14;
                    if (var4_10[var12_15 + 6][var13_16] != 1) continue;
                    if (!a.a.a.a.d.a(var4_10, var13_16, var12_15 - 4, var12_15)) {
                        var6_12 = var11_14;
                        if (!a.a.a.a.d.a(var4_10, var13_16, var12_15 + 7, var12_15 + 11)) continue;
                    }
                    var6_12 = var11_14 + 1;
                }
            }
            var11_14 = 0;
            var4_10 = var3_3.a;
            var17_7 = var3_3.b;
            var18_9 = var3_3.c;
            for (var12_15 = 0; var12_15 < var18_9; ++var12_15) {
                var5_11 = var4_10[var12_15];
                for (var13_16 = 0; var13_16 < var17_7; ++var13_16) {
                    var14_17 = var11_14;
                    if (var5_11[var13_16] == 1) {
                        var14_17 = var11_14 + 1;
                    }
                    var11_14 = var14_17;
                }
            }
            var12_15 = var3_3.c * var3_3.b;
            var6_12 = Math.abs((var11_14 << 1) - var12_15) * 10 / var12_15 * 10 + (var15_18 + var16_8 + var10_13 * 3 + var6_12 * 40);
            if (var6_12 < var8_4) {
                var8_4 = var6_12;
                var6_12 = var7_6;
            } else {
                var6_12 = var9_5;
            }
            ++var7_6;
            var9_5 = var6_12;
        }
        return var9_5;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static com.google.c.b.a a(com.google.c.b.a a2, int n2, int n3, int n4) {
        Iterator iterator;
        byte[] arrby;
        if (a2.a() != n3) {
            throw new q("Number of bits and data bytes does not match");
        }
        ArrayList<a> arrayList = new ArrayList<a>(n4);
        Object object = 0;
        int n5 = 0;
        int n6 = 0;
        for (int i2 = 0; i2 < n4; ++i2) {
            iterator = new int[1];
            int[] arrn = new int[1];
            if (i2 >= n4) {
                throw new q("Block ID too large");
            }
            Iterator iterator2 = n2 % n4;
            int n7 = n4 - iterator2;
            int n8 = n2 / n4;
            int n9 = n3 / n4;
            int n10 = n9 + 1;
            int n11 = n8 - n9;
            if (n11 != (n8 = n8 + 1 - n10)) {
                throw new q("EC bytes mismatch");
            }
            if (n4 != n7 + iterator2) {
                throw new q("RS blocks mismatch");
            }
            if (n2 != iterator2 * (n10 + n8) + (n9 + n11) * n7) {
                throw new q("Total bytes mismatch");
            }
            if (i2 < n7) {
                iterator[0] = (Iterator)n9;
                arrn[0] = n11;
            } else {
                iterator[0] = (Iterator)n10;
                arrn[0] = n8;
            }
            iterator2 = iterator[0];
            arrby = new byte[iterator2];
            a2.a(object << 3, arrby, (int)iterator2);
            arrn = c.a(arrby, arrn[0]);
            arrayList.add(new a(arrby, (byte[])arrn));
            n5 = Math.max(n5, (int)iterator2);
            n6 = Math.max(n6, arrn.length);
            iterator2 = iterator[0];
            object = iterator2 + object;
        }
        if (n3 != object) {
            throw new q("Data bytes does not match offset");
        }
        a2 = new com.google.c.b.a();
        for (n3 = 0; n3 < n5; ++n3) {
            iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                arrby = ((a)iterator.next()).a;
                if (n3 >= arrby.length) continue;
                a2.b(arrby[n3], 8);
            }
        }
        for (n3 = 0; n3 < n6; ++n3) {
            iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                arrby = ((a)iterator.next()).b;
                if (n3 >= arrby.length) continue;
                a2.b(arrby[n3], 8);
            }
        }
        if (n2 != a2.a()) {
            throw new q("Interleaving error: " + n2 + " and " + a2.a() + " differ.");
        }
        return a2;
    }

    private static j a(int n2, com.google.c.g.a.f f2) {
        for (int i2 = 1; i2 <= 40; ++i2) {
            j j2 = j.b(i2);
            if (j2.c - j2.a(f2).b() < (n2 + 7) / 8) continue;
            return j2;
        }
        throw new q("Data too big");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static e a(String var0, com.google.c.g.a.f var1_3, Map<f, ?> var2_4) {
        block29 : {
            block30 : {
                var11_5 = 0;
                var12_6 = 0;
                var13_7 = 0;
                var10_8 = 0;
                var3_9 = var2_4 = (String)var2_4.get((Object)f.b);
                if (var2_4 == null) {
                    var3_9 = "ISO-8859-1";
                }
                if (!"Shift_JIS".equals(var3_9)) {
                    var9_12 = 0;
                    var8_11 = 0;
                } else {
                    var2_4 = c.a((String)var0) ? h.g : h.e;
lbl13: // 3 sources:
                    do {
                        var4_14 = new com.google.c.b.a();
                        if (var2_4 == h.e && !"ISO-8859-1".equals(var3_9) && (var5_15 = com.google.c.b.d.a((String)var3_9)) != null) {
                            var4_14.b(h.f.k, 4);
                            var4_14.b(var5_15.B[0], 8);
                        }
                        var4_14.b(var2_4.k, 4);
                        var5_15 = new com.google.c.b.a();
                        switch (.a[var2_4.ordinal()]) {
                            default: {
                                throw new q("Invalid mode: " + var2_4);
                            }
                            case 1: {
                                var8_11 = var0.length();
                                var7_10 = var10_8;
                                while (var7_10 < var8_11) {
                                    var9_12 = var0.charAt(var7_10) - 48;
                                    if (var7_10 + 2 < var8_11) {
                                        var5_15.b(var9_12 * 100 + (var0.charAt(var7_10 + 1) - 48) * 10 + (var0.charAt(var7_10 + 2) - 48), 10);
                                        var7_10 += 3;
                                        continue;
                                    }
                                    if (var7_10 + 1 < var8_11) {
                                        var5_15.b(var9_12 * 10 + (var0.charAt(var7_10 + 1) - 48), 7);
                                        var7_10 += 2;
                                        continue;
                                    }
                                    var5_15.b(var9_12, 4);
                                    ++var7_10;
                                }
                                break block29;
                            }
                            case 2: {
                                var8_11 = var0.length();
                                var7_10 = var11_5;
                                while (var7_10 < var8_11) {
                                    var9_12 = c.a(var0.charAt(var7_10));
                                    if (var9_12 == -1) {
                                        throw new q();
                                    }
                                    if (var7_10 + 1 < var8_11) {
                                        var10_8 = c.a(var0.charAt(var7_10 + 1));
                                        if (var10_8 == -1) {
                                            throw new q();
                                        }
                                        var5_15.b(var9_12 * 45 + var10_8, 11);
                                        var7_10 += 2;
                                        continue;
                                    }
                                    var5_15.b(var9_12, 6);
                                    ++var7_10;
                                }
                                break block29;
                            }
                            case 3: {
                                try {
                                    var3_9 = var0.getBytes((String)var3_9);
                                }
                                catch (UnsupportedEncodingException var0_1) {
                                    throw new q(var0_1);
                                }
                                var8_11 = var3_9.length;
                                for (var7_10 = var12_6; var7_10 < var8_11; ++var7_10) {
                                    var5_15.b(var3_9[var7_10], 8);
                                }
                                break block29;
                            }
                            case 4: 
                        }
                        try {
                            var3_9 = var0.getBytes("Shift_JIS");
                        }
                        catch (UnsupportedEncodingException var0_2) {
                            throw new q(var0_2);
                        }
                        var9_12 = var3_9.length;
                        break block30;
                        break;
                    } while (true);
                }
                for (var7_10 = 0; var7_10 < var0.length(); ++var7_10) {
                    var14_13 = var0.charAt(var7_10);
                    if (var14_13 >= '0' && var14_13 <= '9') {
                        var8_11 = 1;
                        continue;
                    }
                    if (c.a(var14_13) != -1) {
                        var9_12 = 1;
                        continue;
                    }
                    var2_4 = h.e;
                    ** GOTO lbl13
                }
                var2_4 = h.e;
                ** while (true)
            }
            for (var8_11 = var13_7; var8_11 < var9_12; var8_11 += 2) {
                var7_10 = (var3_9[var8_11] & 255) << 8 | var3_9[var8_11 + 1] & 255;
                var7_10 = var7_10 >= 33088 && var7_10 <= 40956 ? (var7_10 -= 33088) : (var7_10 >= 57408 && var7_10 <= 60351 ? (var7_10 -= 49472) : -1);
                if (var7_10 == -1) {
                    throw new q("Invalid byte sequence");
                }
                var5_15.b((var7_10 & 255) + (var7_10 >> 8) * 192, 13);
            }
        }
        var3_9 = c.a(var4_14.b + var2_4.a(j.b(1)) + var5_15.b, var1_3);
        var7_10 = var4_14.b;
        var3_9 = c.a(var2_4.a((j)var3_9) + var7_10 + var5_15.b, var1_3);
        var6_16 = new com.google.c.b.a();
        var6_16.a((com.google.c.b.a)var4_14);
        var7_10 = var2_4 == h.e ? var5_15.a() : var0.length();
        var8_11 = var2_4.a((j)var3_9);
        if (var7_10 >= 1 << var8_11) {
            throw new q("" + var7_10 + " is bigger than " + ((1 << var8_11) - 1));
        }
        var6_16.b(var7_10, var8_11);
        var6_16.a((com.google.c.b.a)var5_15);
        var0 = var3_9.a(var1_3);
        var7_10 = var3_9.c - var0.b();
        c.a(var7_10, var6_16);
        var0 = c.a(var6_16, var3_9.c, var7_10, var0.a());
        var4_14 = new e();
        var4_14.b = var1_3;
        var4_14.a = var2_4;
        var4_14.c = var3_9;
        var7_10 = var3_9.a();
        var2_4 = new b(var7_10, var7_10);
        var4_14.d = var7_10 = c.a((com.google.c.b.a)var0, var1_3, (j)var3_9, (b)var2_4);
        d.a((com.google.c.b.a)var0, var1_3, (j)var3_9, var7_10, (b)var2_4);
        var4_14.e = var2_4;
        return var4_14;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(int n2, com.google.c.b.a a2) {
        int n3;
        int n4 = n2 << 3;
        if (a2.b > n4) {
            throw new q("data bits cannot fit in the QR Code" + a2.b + " > " + n4);
        }
        for (n3 = 0; n3 < 4 && a2.b < n4; ++n3) {
            a2.a(false);
        }
        n3 = a2.b & 7;
        if (n3 > 0) {
            while (n3 < 8) {
                a2.a(false);
                ++n3;
            }
        }
        int n5 = a2.a();
        for (n3 = 0; n3 < n2 - n5; ++n3) {
            int n6 = (n3 & 1) == 0 ? 236 : 17;
            a2.b(n6, 8);
        }
        if (a2.b != n4) {
            throw new q("Bits size does not equal capacity");
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static boolean a(String arrby) {
        try {
            arrby = arrby.getBytes("Shift_JIS");
        }
        catch (UnsupportedEncodingException var0_1) {
            return false;
        }
        int n2 = arrby.length;
        if (n2 % 2 != 0) {
            return false;
        }
        int n3 = 0;
        while (n3 < n2) {
            int n4 = arrby[n3] & 255;
            if (n4 < 129 || n4 > 159) {
                if (n4 < 224) return false;
                if (n4 > 235) return false;
            }
            n3 += 2;
        }
        return true;
    }

    private static byte[] a(byte[] arrn, int n2) {
        int n3;
        int n4 = 0;
        int n5 = arrn.length;
        int[] arrn2 = new int[n5 + n2];
        for (n3 = 0; n3 < n5; ++n3) {
            arrn2[n3] = arrn[n3] & 255;
        }
        arrn = new com.google.c.b.b.d(com.google.c.b.b.a.e);
        if (n2 == 0) {
            throw new IllegalArgumentException("No error correction bytes");
        }
        int n6 = arrn2.length - n2;
        if (n6 <= 0) {
            throw new IllegalArgumentException("No data bytes provided");
        }
        com.google.c.b.b.b b2 = arrn.a(n2);
        int[] arrn3 = new int[n6];
        System.arraycopy(arrn2, 0, arrn3, 0, n6);
        arrn = new com.google.c.b.b.b((com.google.c.b.b.a)arrn.a, (int[])arrn3).a((int)n2, (int)1).c((com.google.c.b.b.b)b2)[1].a;
        int n7 = n2 - arrn.length;
        for (n3 = 0; n3 < n7; ++n3) {
            arrn2[n6 + n3] = 0;
        }
        System.arraycopy(arrn, 0, arrn2, n6 + n7, arrn.length);
        arrn = new byte[n2];
        for (n3 = n4; n3 < n2; ++n3) {
            arrn[n3] = (byte)arrn2[n5 + n3];
        }
        return arrn;
    }

}

