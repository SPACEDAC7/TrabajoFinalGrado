/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.c;

import com.google.c.b.a;
import com.google.c.g.a.f;
import com.google.c.g.a.j;
import com.google.c.g.c.b;
import com.google.c.q;

final class d {
    private static final int[][] a = new int[][]{{1, 1, 1, 1, 1, 1, 1}, {1, 0, 0, 0, 0, 0, 1}, {1, 0, 1, 1, 1, 0, 1}, {1, 0, 1, 1, 1, 0, 1}, {1, 0, 1, 1, 1, 0, 1}, {1, 0, 0, 0, 0, 0, 1}, {1, 1, 1, 1, 1, 1, 1}};
    private static final int[][] b;
    private static final int[][] c;
    private static final int[][] d;

    static {
        int[] arrn = new int[]{1, 1, 1, 1, 1};
        int[] arrn2 = new int[]{1, 0, 1, 0, 1};
        b = new int[][]{arrn, {1, 0, 0, 0, 1}, arrn2, {1, 0, 0, 0, 1}, {1, 1, 1, 1, 1}};
        arrn = new int[]{6, 30, -1, -1, -1, -1, -1};
        arrn2 = new int[]{6, 26, 46, -1, -1, -1, -1};
        int[] arrn3 = new int[]{6, 30, 54, -1, -1, -1, -1};
        int[] arrn4 = new int[]{6, 32, 58, -1, -1, -1, -1};
        int[] arrn5 = new int[]{6, 34, 62, -1, -1, -1, -1};
        int[] arrn6 = new int[]{6, 26, 48, 70, -1, -1, -1};
        int[] arrn7 = new int[]{6, 30, 54, 78, -1, -1, -1};
        int[] arrn8 = new int[]{6, 28, 50, 72, 94, -1, -1};
        int[] arrn9 = new int[]{6, 26, 50, 74, 98, -1, -1};
        int[] arrn10 = new int[]{6, 28, 54, 80, 106, -1, -1};
        int[] arrn11 = new int[]{6, 30, 58, 86, 114, -1, -1};
        int[] arrn12 = new int[]{6, 30, 54, 78, 102, 126, -1};
        int[] arrn13 = new int[]{6, 34, 60, 86, 112, 138, -1};
        int[] arrn14 = new int[]{6, 30, 58, 86, 114, 142, -1};
        int[] arrn15 = new int[]{6, 30, 54, 78, 102, 126, 150};
        int[] arrn16 = new int[]{6, 24, 50, 76, 102, 128, 154};
        int[] arrn17 = new int[]{6, 32, 58, 84, 110, 136, 162};
        int[] arrn18 = new int[]{6, 30, 58, 86, 114, 142, 170};
        c = new int[][]{{-1, -1, -1, -1, -1, -1, -1}, {6, 18, -1, -1, -1, -1, -1}, {6, 22, -1, -1, -1, -1, -1}, {6, 26, -1, -1, -1, -1, -1}, arrn, {6, 34, -1, -1, -1, -1, -1}, {6, 22, 38, -1, -1, -1, -1}, {6, 24, 42, -1, -1, -1, -1}, arrn2, {6, 28, 50, -1, -1, -1, -1}, arrn3, arrn4, arrn5, {6, 26, 46, 66, -1, -1, -1}, arrn6, {6, 26, 50, 74, -1, -1, -1}, arrn7, {6, 30, 56, 82, -1, -1, -1}, {6, 30, 58, 86, -1, -1, -1}, {6, 34, 62, 90, -1, -1, -1}, arrn8, arrn9, {6, 30, 54, 78, 102, -1, -1}, arrn10, {6, 32, 58, 84, 110, -1, -1}, arrn11, {6, 34, 62, 90, 118, -1, -1}, {6, 26, 50, 74, 98, 122, -1}, arrn12, {6, 26, 52, 78, 104, 130, -1}, {6, 30, 56, 82, 108, 134, -1}, arrn13, arrn14, {6, 34, 62, 90, 118, 146, -1}, arrn15, arrn16, {6, 28, 54, 80, 106, 132, 158}, arrn17, {6, 26, 54, 82, 110, 138, 166}, arrn18};
        arrn = new int[]{8, 0};
        arrn2 = new int[]{8, 1};
        arrn3 = new int[]{8, 2};
        arrn4 = new int[]{8, 5};
        arrn5 = new int[]{8, 7};
        arrn6 = new int[]{8, 8};
        arrn7 = new int[]{7, 8};
        arrn8 = new int[]{4, 8};
        arrn9 = new int[]{3, 8};
        arrn10 = new int[]{1, 8};
        d = new int[][]{arrn, arrn2, arrn3, {8, 3}, {8, 4}, arrn4, arrn5, arrn6, arrn7, {5, 8}, arrn8, arrn9, {2, 8}, arrn10, {0, 8}};
    }

    private static int a(int n2) {
        int n3 = 0;
        int n4 = n2;
        n2 = n3;
        while (n4 != 0) {
            n4 >>>= 1;
            ++n2;
        }
        return n2;
    }

    private static int a(int n2, int n3) {
        if (n3 == 0) {
            throw new IllegalArgumentException("0 polynomial");
        }
        int n4 = d.a(n3);
        n2 <<= n4 - 1;
        while (d.a(n2) >= n4) {
            n2 ^= n3 << d.a(n2) - n4;
        }
        return n2;
    }

    private static void a(int n2, int n3, b b2) {
        for (int i2 = 0; i2 < 8; ++i2) {
            if (!d.b(b2.a(n2 + i2, n3))) {
                throw new q();
            }
            b2.a(n2 + i2, n3, 0);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(a a2, int n2, b b2) {
        int n3 = b2.b - 1;
        int n4 = b2.c - 1;
        int n5 = -1;
        int n6 = 0;
        block10 : do {
            int n7;
            if (n3 > 0) {
                n7 = n3 == 6 ? n3 - 1 : n3;
            } else {
                if (n6 != a2.b) {
                    throw new q("Not all bits consumed: " + n6 + '/' + a2.b);
                }
                return;
            }
            do {
                if (n4 >= 0 && n4 < b2.c) {
                } else {
                    n5 = n3 = - n5;
                    n4 += n3;
                    n3 = n7 - 2;
                    continue block10;
                }
                for (int i2 = 0; i2 < 2; ++i2) {
                    int n8 = n7 - i2;
                    n3 = n6;
                    if (d.b(b2.a(n8, n4))) {
                        boolean bl2;
                        if (n6 < a2.b) {
                            bl2 = a2.a(n6);
                            n3 = n6 + 1;
                        } else {
                            bl2 = false;
                            n3 = n6;
                        }
                        boolean bl3 = bl2;
                        if (n2 != -1) {
                            switch (n2) {
                                default: {
                                    throw new IllegalArgumentException("Invalid mask pattern: " + n2);
                                }
                                case 0: {
                                    n6 = n4 + n8 & 1;
                                    break;
                                }
                                case 1: {
                                    n6 = n4 & 1;
                                    break;
                                }
                                case 2: {
                                    n6 = n8 % 3;
                                    break;
                                }
                                case 3: {
                                    n6 = (n4 + n8) % 3;
                                    break;
                                }
                                case 4: {
                                    n6 = n4 / 2 + n8 / 3 & 1;
                                    break;
                                }
                                case 5: {
                                    n6 = n4 * n8;
                                    n6 = n6 % 3 + (n6 & 1);
                                    break;
                                }
                                case 6: {
                                    n6 = n4 * n8;
                                    n6 = n6 % 3 + (n6 & 1) & 1;
                                    break;
                                }
                                case 7: {
                                    n6 = n4 * n8 % 3 + (n4 + n8 & 1) & 1;
                                }
                            }
                            n6 = n6 == 0 ? 1 : 0;
                            bl3 = bl2;
                            if (n6 != 0) {
                                bl3 = !bl2;
                            }
                        }
                        b2.a(n8, n4, bl3);
                    }
                    n6 = n3;
                }
                n4 += n5;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static void a(a var0, f var1_1, j var2_2, int var3_3, b var4_4) {
        for (var7_5 = 0; var7_5 < var4_4.c; ++var7_5) {
            for (var8_6 = 0; var8_6 < var4_4.b; ++var8_6) {
                var4_4.a[var7_5][var8_6] = -1;
            }
        }
        var7_5 = d.a[0].length;
        d.c(0, 0, var4_4);
        d.c(var4_4.b - var7_5, 0, var4_4);
        d.c(0, var4_4.b - var7_5, var4_4);
        d.a(0, 7, var4_4);
        d.a(var4_4.b - 8, 7, var4_4);
        d.a(0, var4_4.b - 8, var4_4);
        d.b(7, 0, var4_4);
        d.b(var4_4.c - 7 - 1, 0, var4_4);
        d.b(7, var4_4.c - 7, var4_4);
        if (var4_4.a(8, var4_4.c - 8) == 0) {
            throw new q();
        }
        var4_4.a(8, var4_4.c - 8, 1);
        if (var2_2.a < 2) ** GOTO lbl38
        var7_5 = var2_2.a - 1;
        var5_7 = d.c[var7_5];
        var11_8 = d.c[var7_5].length;
        block2 : for (var7_5 = 0; var7_5 < var11_8; ++var7_5) {
            var8_6 = 0;
            do {
                if (var8_6 >= var11_8) continue block2;
                var12_11 = var5_7[var7_5];
                var13_12 = var5_7[var8_6];
                if (var13_12 == -1 || var12_11 == -1 || !d.b(var4_4.a((int)var13_12, (int)var12_11))) ** GOTO lbl36
                for (var9_9 = 0; var9_9 < 5; ++var9_9) {
                    for (var10_10 = 0; var10_10 < 5; ++var10_10) {
                        var4_4.a((int)(var13_12 - 2 + var10_10), (int)(var12_11 - 2 + var9_9), d.b[var9_9][var10_10]);
                    }
                }
lbl36: // 2 sources:
                ++var8_6;
            } while (true);
        }
lbl38: // 4 sources:
        for (var7_5 = 8; var7_5 < var4_4.b - 8; ++var7_5) {
            var8_6 = (var7_5 + 1) % 2;
            if (d.b(var4_4.a(var7_5, 6))) {
                var4_4.a(var7_5, 6, var8_6);
            }
            if (!d.b(var4_4.a(6, var7_5))) continue;
            var4_4.a(6, var7_5, var8_6);
        }
        var5_7 = new a();
        var7_5 = var3_3 >= 0 && var3_3 < 8 ? 1 : 0;
        if (var7_5 == 0) {
            throw new q("Invalid mask pattern");
        }
        var7_5 = var1_1.e << 3 | var3_3;
        var5_7.b(var7_5, 5);
        var5_7.b(d.a(var7_5, 1335), 10);
        var1_1 = new a();
        var1_1.b(21522, 15);
        if (var5_7.a.length != var1_1.a.length) {
            throw new IllegalArgumentException("Sizes don't match");
        }
        for (var7_5 = 0; var7_5 < var5_7.a.length; ++var7_5) {
            var6_13 = var5_7.a;
            var6_13[var7_5] = var6_13[var7_5] ^ var1_1.a[var7_5];
        }
        if (var5_7.b != 15) {
            throw new q("should not happen but we got: " + var5_7.b);
        }
        var7_5 = 0;
        do {
            if (var7_5 >= var5_7.b) {
                d.a(var2_2, var4_4);
                d.a(var0, var3_3, var4_4);
                return;
            }
            var14_14 = var5_7.a(var5_7.b - 1 - var7_5);
            var4_4.a(d.d[var7_5][0], d.d[var7_5][1], var14_14);
            if (var7_5 < 8) {
                var4_4.a(var4_4.b - var7_5 - 1, 8, var14_14);
            } else {
                var4_4.a(8, var4_4.c - 7 + (var7_5 - 8), var14_14);
            }
            ++var7_5;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void a(j j2, b b2) {
        if (j2.a < 7) {
            return;
        }
        a a2 = new a();
        a2.b(j2.a, 6);
        a2.b(d.a(j2.a, 7973), 12);
        if (a2.b != 18) {
            throw new q("should not happen but we got: " + a2.b);
        }
        int n2 = 17;
        int n3 = 0;
        while (n3 < 6) {
            for (int i2 = 0; i2 < 3; ++i2) {
                boolean bl2 = a2.a(n2);
                --n2;
                b2.a(n3, b2.c - 11 + i2, bl2);
                b2.a(b2.c - 11 + i2, n3, bl2);
            }
            ++n3;
        }
    }

    private static void b(int n2, int n3, b b2) {
        for (int i2 = 0; i2 < 7; ++i2) {
            if (!d.b(b2.a(n2, n3 + i2))) {
                throw new q();
            }
            b2.a(n2, n3 + i2, 0);
        }
    }

    private static boolean b(int n2) {
        if (n2 == -1) {
            return true;
        }
        return false;
    }

    private static void c(int n2, int n3, b b2) {
        for (int i2 = 0; i2 < 7; ++i2) {
            for (int i3 = 0; i3 < 7; ++i3) {
                b2.a(n2 + i3, n3 + i2, a[i2][i3]);
            }
        }
    }
}

