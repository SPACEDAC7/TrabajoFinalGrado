/*
 * Decompiled with CFR 0_115.
 */
package com.google.c.g.c;

import com.google.c.g.a.f;
import com.google.c.g.a.h;
import com.google.c.g.a.j;
import com.google.c.g.c.b;

public final class e {
    h a;
    f b;
    j c;
    int d = -1;
    b e;

    public final b a() {
        return this.e;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(200);
        stringBuilder.append("<<\n");
        stringBuilder.append(" mode: ");
        stringBuilder.append((Object)this.a);
        stringBuilder.append("\n ecLevel: ");
        stringBuilder.append((Object)this.b);
        stringBuilder.append("\n version: ");
        stringBuilder.append(this.c);
        stringBuilder.append("\n maskPattern: ");
        stringBuilder.append(this.d);
        if (this.e == null) {
            stringBuilder.append("\n matrix: null\n");
        } else {
            stringBuilder.append("\n matrix:\n");
            stringBuilder.append(this.e);
        }
        stringBuilder.append(">>\n");
        return stringBuilder.toString();
    }
}

