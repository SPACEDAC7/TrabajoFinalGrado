/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

public abstract class h {
    public final int a;
    public final int b;

    protected h(int n2, int n3) {
        this.a = n2;
        this.b = n3;
    }

    public abstract byte[] a();

    public abstract byte[] a(int var1, byte[] var2);

    /*
     * Enabled aggressive block sorting
     */
    public final String toString() {
        byte[] arrby = new byte[this.a];
        StringBuilder stringBuilder = new StringBuilder(this.b * (this.a + 1));
        int n2 = 0;
        while (n2 < this.b) {
            arrby = this.a(n2, arrby);
            for (int i2 = 0; i2 < this.a; ++i2) {
                int n3 = arrby[i2] & 255;
                int n4 = n3 < 64 ? 35 : (n3 < 128 ? 43 : (n3 < 192 ? 46 : 32));
                stringBuilder.append((char)n4);
            }
            stringBuilder.append('\n');
            ++n2;
        }
        return stringBuilder.toString();
    }
}

