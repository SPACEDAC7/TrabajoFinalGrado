/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import com.google.c.c;
import com.google.c.c.a;
import com.google.c.e;
import com.google.c.f.b;
import com.google.c.j;
import com.google.c.l;
import com.google.c.m;
import com.google.c.n;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public final class i
implements l {
    private Map<e, ?> a;
    private l[] b;

    private n b(c c2) {
        if (this.b != null) {
            for (l object : this.b) {
                try {
                    n n2 = object.a(c2, this.a);
                    return n2;
                }
                catch (m var3_5) {
                    continue;
                }
            }
        }
        throw j.a();
    }

    public final n a(c c2) {
        if (this.b == null) {
            this.a(null);
        }
        return this.b(c2);
    }

    @Override
    public final n a(c c2, Map<e, ?> map) {
        this.a(map);
        return this.b(c2);
    }

    @Override
    public final void a() {
        if (this.b != null) {
            l[] arrl = this.b;
            int n2 = arrl.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                arrl[i2].a();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(Map<e, ?> map) {
        boolean bl2 = false;
        this.a = map;
        boolean bl3 = map != null && map.containsKey((Object)e.d);
        Collection collection = map == null ? null : (Collection)map.get((Object)e.c);
        ArrayList<l> arrayList = new ArrayList<l>();
        if (collection != null) {
            if (collection.contains((Object)com.google.c.a.o) || collection.contains((Object)com.google.c.a.p) || collection.contains((Object)com.google.c.a.h) || collection.contains((Object)com.google.c.a.g) || collection.contains((Object)com.google.c.a.b) || collection.contains((Object)com.google.c.a.c) || collection.contains((Object)com.google.c.a.d) || collection.contains((Object)com.google.c.a.e) || collection.contains((Object)com.google.c.a.i) || collection.contains((Object)com.google.c.a.m) || collection.contains((Object)com.google.c.a.n)) {
                bl2 = true;
            }
            if (bl2 && !bl3) {
                arrayList.add(new com.google.c.e.i(map));
            }
            if (collection.contains((Object)com.google.c.a.l)) {
                arrayList.add(new com.google.c.g.a());
            }
            if (collection.contains((Object)com.google.c.a.f)) {
                arrayList.add(new a());
            }
            if (collection.contains((Object)com.google.c.a.a)) {
                arrayList.add(new com.google.c.a.b());
            }
            if (collection.contains((Object)com.google.c.a.k)) {
                arrayList.add(new b());
            }
            if (collection.contains((Object)com.google.c.a.j)) {
                arrayList.add(new com.google.c.d.a());
            }
            if (bl2 && bl3) {
                arrayList.add(new com.google.c.e.i(map));
            }
        }
        if (arrayList.isEmpty()) {
            if (!bl3) {
                arrayList.add(new com.google.c.e.i(map));
            }
            arrayList.add(new com.google.c.g.a());
            arrayList.add(new a());
            arrayList.add(new com.google.c.a.b());
            arrayList.add(new b());
            arrayList.add(new com.google.c.d.a());
            if (bl3) {
                arrayList.add(new com.google.c.e.i(map));
            }
        }
        this.b = arrayList.toArray(new l[arrayList.size()]);
    }
}

