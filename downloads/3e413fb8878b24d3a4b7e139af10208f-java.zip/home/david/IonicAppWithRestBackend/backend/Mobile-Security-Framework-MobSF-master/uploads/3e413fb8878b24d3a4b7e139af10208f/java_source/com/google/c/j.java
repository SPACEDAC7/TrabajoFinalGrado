/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import com.google.c.m;

public final class j
extends m {
    private static final j a = new j();

    private j() {
    }

    public static j a() {
        return a;
    }
}

