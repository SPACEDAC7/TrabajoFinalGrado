/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import com.google.c.h;

public final class k
extends h {
    private final byte[] c;
    private final int d;
    private final int e;
    private final int f;
    private final int g;

    public k(byte[] arrby, int n2, int n3, int n4, int n5, int n6, int n7) {
        super(n6, n7);
        if (n4 + n6 > n2 || n5 + n7 > n3) {
            throw new IllegalArgumentException("Crop rectangle does not fit within image data.");
        }
        this.c = arrby;
        this.d = n2;
        this.e = n3;
        this.f = n4;
        this.g = n5;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final byte[] a() {
        int n2 = 0;
        int n3 = this.a;
        int n4 = this.b;
        if (n3 == this.d && n4 == this.e) {
            return this.c;
        }
        int n5 = n3 * n4;
        byte[] arrby = new byte[n5];
        int n6 = this.g * this.d + this.f;
        if (n3 == this.d) {
            System.arraycopy(this.c, n6, arrby, 0, n5);
            return arrby;
        }
        byte[] arrby2 = this.c;
        do {
            byte[] arrby3 = arrby;
            if (n2 >= n4) return arrby3;
            System.arraycopy(arrby2, n6, arrby, n2 * n3, n3);
            n6 += this.d;
            ++n2;
        } while (true);
    }

    @Override
    public final byte[] a(int n2, byte[] arrby) {
        byte[] arrby2;
        int n3;
        block3 : {
            if (n2 < 0 || n2 >= this.b) {
                throw new IllegalArgumentException("Requested row is outside the image: " + n2);
            }
            n3 = this.a;
            if (arrby != null) {
                arrby2 = arrby;
                if (arrby.length >= n3) break block3;
            }
            arrby2 = new byte[n3];
        }
        int n4 = this.g;
        int n5 = this.d;
        int n6 = this.f;
        System.arraycopy(this.c, (n4 + n2) * n5 + n6, arrby2, 0, n3);
        return arrby2;
    }
}

