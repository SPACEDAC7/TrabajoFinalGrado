/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import com.google.c.c;
import com.google.c.e;
import com.google.c.n;
import java.util.Map;

public interface l {
    public n a(c var1, Map<e, ?> var2);

    public void a();
}

