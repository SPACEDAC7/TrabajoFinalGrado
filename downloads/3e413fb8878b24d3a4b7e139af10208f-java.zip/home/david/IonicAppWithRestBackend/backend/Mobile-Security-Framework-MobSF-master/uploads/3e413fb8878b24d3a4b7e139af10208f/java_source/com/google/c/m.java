/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

public abstract class m
extends Exception {
    m() {
    }

    @Override
    public final Throwable fillInStackTrace() {
        return null;
    }
}

