/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import com.google.c.a;
import com.google.c.o;
import com.google.c.p;
import java.util.EnumMap;
import java.util.Map;

public final class n {
    public final String a;
    public final byte[] b;
    public p[] c;
    public final a d;
    public Map<o, Object> e;
    private final long f;

    public n(String string, byte[] arrby, p[] arrp, a a2) {
        this(string, arrby, arrp, a2, System.currentTimeMillis());
    }

    private n(String string, byte[] arrby, p[] arrp, a a2, long l2) {
        this.a = string;
        this.b = arrby;
        this.c = arrp;
        this.d = a2;
        this.e = null;
        this.f = l2;
    }

    public final String a() {
        return this.a;
    }

    public final void a(o o2, Object object) {
        if (this.e == null) {
            this.e = new EnumMap<o, Object>(o.class);
        }
        this.e.put(o2, object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void a(Map<o, Object> map) {
        if (map == null) return;
        if (this.e == null) {
            this.e = map;
            return;
        }
        this.e.putAll(map);
    }

    public final String toString() {
        return this.a;
    }
}

