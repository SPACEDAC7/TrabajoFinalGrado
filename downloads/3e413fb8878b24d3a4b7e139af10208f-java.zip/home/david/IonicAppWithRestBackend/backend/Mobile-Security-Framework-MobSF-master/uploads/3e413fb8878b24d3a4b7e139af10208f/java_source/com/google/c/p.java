/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

import a.a.a.a.d;

public class p {
    public final float a;
    public final float b;

    public p(float f2, float f3) {
        this.a = f2;
        this.b = f3;
    }

    public static float a(p p2, p p3) {
        return d.a(p2.a, p2.b, p3.a, p3.b);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(p[] arrp) {
        float f2;
        p p2;
        p p3;
        float f3;
        p p4;
        float f4 = p.a(arrp[0], arrp[1]);
        float f5 = p.a(arrp[1], arrp[2]);
        float f6 = p.a(arrp[0], arrp[2]);
        if (f5 >= f4 && f5 >= f6) {
            p4 = arrp[0];
            p3 = arrp[1];
            p2 = arrp[2];
        } else if (f6 >= f5 && f6 >= f4) {
            p4 = arrp[1];
            p3 = arrp[0];
            p2 = arrp[2];
        } else {
            p4 = arrp[2];
            p3 = arrp[0];
            p2 = arrp[1];
        }
        if (((f6 = p2.a) - (f4 = p4.a)) * ((f2 = p3.b) - (f5 = p4.b)) - (p3.a - f4) * ((f3 = p2.b) - f5) >= 0.0f) {
            p p5 = p2;
            p2 = p3;
            p3 = p5;
        }
        arrp[0] = p2;
        arrp[1] = p4;
        arrp[2] = p3;
    }

    public final boolean equals(Object object) {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (object instanceof p) {
            object = (p)object;
            bl3 = bl2;
            if (this.a == object.a) {
                bl3 = bl2;
                if (this.b == object.b) {
                    bl3 = true;
                }
            }
        }
        return bl3;
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.a) * 31 + Float.floatToIntBits(this.b);
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(25);
        stringBuilder.append('(');
        stringBuilder.append(this.a);
        stringBuilder.append(',');
        stringBuilder.append(this.b);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}

