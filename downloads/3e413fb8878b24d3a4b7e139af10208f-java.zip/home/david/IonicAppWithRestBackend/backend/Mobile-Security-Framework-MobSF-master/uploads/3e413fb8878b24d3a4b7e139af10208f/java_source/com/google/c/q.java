/*
 * Decompiled with CFR 0_115.
 */
package com.google.c;

public final class q
extends Exception {
    public q() {
    }

    public q(String string) {
        super(string);
    }

    public q(Throwable throwable) {
        super(throwable);
    }
}

