/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.b;
import com.google.protobuf.o;
import com.google.protobuf.u;
import com.google.protobuf.v;
import com.google.protobuf.x;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public abstract class GeneratedMessageLite
extends b
implements Serializable {
    public GeneratedMessageLite() {
    }

    public GeneratedMessageLite(byte by2) {
    }

    @Override
    public x<? extends u> getParserForType() {
        throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
    }

    static final class SerializedForm
    implements Serializable {
        private static final long serialVersionUID = 0;
        private byte[] asBytes;
        private String messageClassName;

        SerializedForm(u u2) {
            this.messageClassName = u2.getClass().getName();
            this.asBytes = u2.toByteArray();
        }

        protected final Object readResolve() {
            try {
                v v2 = (u.a)Class.forName(this.messageClassName).getMethod("newBuilder", new Class[0]).invoke(null, new Object[0]);
                v2.mergeFrom(this.asBytes);
                v2 = v2.buildPartial();
                return v2;
            }
            catch (ClassNotFoundException var1_2) {
                throw new RuntimeException("Unable to find proto buffer class", var1_2);
            }
            catch (NoSuchMethodException var1_3) {
                throw new RuntimeException("Unable to find newBuilder method", var1_3);
            }
            catch (IllegalAccessException var1_4) {
                throw new RuntimeException("Unable to call newBuilder method", var1_4);
            }
            catch (InvocationTargetException var1_5) {
                throw new RuntimeException("Error calling newBuilder", var1_5.getCause());
            }
            catch (o var1_6) {
                throw new RuntimeException("Unable to understand proto buffer", var1_6);
            }
        }
    }

    public static abstract class a<MessageType extends GeneratedMessageLite, BuilderType extends a>
    extends b.a<BuilderType> {
        public BuilderType a() {
            throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
        }

        @Override
        public /* synthetic */ b.a clone() {
            return this.a();
        }

        @Override
        public /* synthetic */ u.a clone() {
            return this.a();
        }

        @Override
        public /* synthetic */ Object clone() {
            return this.a();
        }
    }

}

