/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import android.support.design.widget.FloatingActionButton;
import com.google.protobuf.ad;
import com.google.protobuf.ae;
import com.google.protobuf.af;
import com.google.protobuf.ah;
import com.google.protobuf.b;
import com.google.protobuf.d;
import com.google.protobuf.e;
import com.google.protobuf.f;
import com.google.protobuf.g;
import com.google.protobuf.h;
import com.google.protobuf.j;
import com.google.protobuf.k;
import com.google.protobuf.l;
import com.google.protobuf.m;
import com.google.protobuf.n;
import com.google.protobuf.p;
import com.google.protobuf.t;
import com.google.protobuf.u;
import com.google.protobuf.w;
import com.google.protobuf.x;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class a
extends b
implements t {
    private int memoizedSize = -1;

    private static String delimitWithCommas(List<String> object) {
        StringBuilder stringBuilder = new StringBuilder();
        object = object.iterator();
        while (object.hasNext()) {
            String string = (String)object.next();
            if (stringBuilder.length() > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(string);
        }
        return stringBuilder.toString();
    }

    protected static int hashBoolean(boolean bl2) {
        if (bl2) {
            return 1231;
        }
        return 1237;
    }

    protected static int hashEnum(n n2) {
        return n2.getNumber();
    }

    protected static int hashEnumList(List<? extends n> object) {
        object = object.iterator();
        int n2 = 1;
        while (object.hasNext()) {
            n2 = a.hashEnum((n)object.next()) + n2 * 31;
        }
        return n2;
    }

    protected static int hashLong(long l2) {
        return (int)(l2 >>> 32 ^ l2);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof t)) {
            return false;
        }
        object = (t)object;
        if (this.getDescriptorForType() != object.getDescriptorForType()) {
            return false;
        }
        if (!this.getAllFields().equals(object.getAllFields())) return false;
        if (this.getUnknownFields().equals(object.getUnknownFields())) return true;
        return false;
    }

    public List<String> findInitializationErrors() {
        return a.b(this);
    }

    public String getInitializationErrorString() {
        return a.delimitWithCommas(this.findInitializationErrors());
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int getSerializedSize() {
        int n2 = this.memoizedSize;
        if (n2 != -1) {
            return n2;
        }
        boolean bl2 = this.getDescriptorForType().a.d.c;
        Object object = this.getAllFields().entrySet().iterator();
        n2 = 0;
        while (object.hasNext()) {
            Object object2 = object.next();
            h.f f2 = object2.getKey();
            object2 = object2.getValue();
            if (bl2 && f2.b.f() && f2.e == h.f.b.k && !f2.j()) {
                n2 = f.e(f2.b.c, (t)object2) + n2;
                continue;
            }
            n2 = l.c(f2, object2) + n2;
        }
        object = this.getUnknownFields();
        n2 = bl2 ? object.c() + n2 : object.getSerializedSize() + n2;
        this.memoizedSize = n2;
        return n2;
    }

    public int hashCode() {
        return this.hashFields(this.getDescriptorForType().hashCode() + 779, this.getAllFields()) * 29 + this.getUnknownFields().hashCode();
    }

    protected int hashFields(int n2, Map<h.f, Object> object) {
        object = object.entrySet().iterator();
        while (object.hasNext()) {
            Object object2 = (Map.Entry)object.next();
            h.f f2 = (h.f)object2.getKey();
            object2 = object2.getValue();
            n2 = n2 * 37 + f2.b.c;
            if (f2.e != h.f.b.n) {
                n2 = n2 * 53 + object2.hashCode();
                continue;
            }
            if (f2.j()) {
                n2 = n2 * 53 + a.hashEnumList((List)object2);
                continue;
            }
            n2 = n2 * 53 + a.hashEnum((n)object2);
        }
        return n2;
    }

    @Override
    public boolean isInitialized() {
        for (h.f object2 : this.getDescriptorForType().d()) {
            if (!object2.g() || this.hasField(object2)) continue;
            return false;
        }
        for (Map.Entry entry : this.getAllFields().entrySet()) {
            h.f f2 = (h.f)entry.getKey();
            if (f2.e.s != h.f.a.i) continue;
            if (f2.j()) {
                Iterator iterator = ((List)entry.getValue()).iterator();
                while (iterator.hasNext()) {
                    if (((t)iterator.next()).isInitialized()) continue;
                    return false;
                }
                continue;
            }
            if (((t)entry.getValue()).isInitialized()) continue;
            return false;
        }
        return true;
    }

    @Override
    ae newUninitializedMessageException() {
        return a.newUninitializedMessageException(this);
    }

    public final String toString() {
        return ad.a(this);
    }

    @Override
    public void writeTo(f f2) {
        boolean bl2 = this.getDescriptorForType().a.d.c;
        Object object = this.getAllFields().entrySet().iterator();
        while (object.hasNext()) {
            Object object2 = object.next();
            h.f f3 = object2.getKey();
            object2 = object2.getValue();
            if (bl2 && f3.b.f() && f3.e == h.f.b.k && !f3.j()) {
                f2.c(f3.b.c, (t)object2);
                continue;
            }
            l.a(f3, object2, f2);
        }
        object = this.getUnknownFields();
        if (bl2) {
            object.a(f2);
            return;
        }
        object.writeTo(f2);
    }

    public static abstract class a<BuilderType extends a>
    extends b.a<BuilderType>
    implements t.a {
        /*
         * Enabled aggressive block sorting
         */
        private static String a(String charSequence, h.f f2, int n2) {
            void var2_3;
            StringBuilder stringBuilder = new StringBuilder((String)charSequence);
            if (var1_2.b.f()) {
                stringBuilder.append('(').append(var1_2.c).append(')');
            } else {
                stringBuilder.append(var1_2.b.b());
            }
            if (var2_3 != -1) {
                stringBuilder.append('[').append((int)var2_3).append(']');
            }
            stringBuilder.append('.');
            return stringBuilder.toString();
        }

        private static void a(t.a w2, l<h.f> l2, h.f f2, t.a a2) {
            if ((w2 = a.b(w2, l2, f2)) != null) {
                a2.mergeFrom((t)w2);
            }
        }

        private static void a(t.a a2, l<h.f> l2, h.f f2, Object object) {
            if (a2 != null) {
                a2.addRepeatedField(f2, object);
                return;
            }
            l2.b(f2, object);
        }

        private static void a(w w2, String string, List<String> list) {
            for (h.f f22 : w2.getDescriptorForType().d()) {
                if (!f22.g() || w2.hasField(f22)) continue;
                list.add(string + f22.b.b());
            }
            Iterator iterator = w2.getAllFields().entrySet().iterator();
            while (iterator.hasNext()) {
                h.f f22;
                Object object = (Map.Entry)iterator.next();
                f22 = (h.f)object.getKey();
                object = object.getValue();
                if (f22.e.s != h.f.a.i) continue;
                if (f22.j()) {
                    int n2 = 0;
                    object = ((List)object).iterator();
                    while (object.hasNext()) {
                        a.a((w)object.next(), a.a(string, f22, n2), list);
                        ++n2;
                    }
                    continue;
                }
                if (!w2.hasField(f22)) continue;
                a.a((w)object, a.a(string, f22, -1), list);
            }
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        static boolean a(e var0, af.a var1_1, k var2_2, h.a var3_3, t.a var4_4, l<h.f> var5_5, int var6_6) {
            var11_12 = false;
            var7_13 = null;
            if (!var3_3.a.d.c || var6_11 != ah.a) ** GOTO lbl8
            var7_13 = null;
            var6_11 = 0;
            var8_14 = null;
            ** GOTO lbl41
lbl8: // 1 sources:
            var10_18 = ah.a(var6_11);
            var12_20 = ah.b(var6_11);
            if (!var3_3.a(var12_20)) ** GOTO lbl21
            if (!(var2_2 instanceof j)) ** GOTO lbl19
            var8_15 = ((j)var2_2).a(var3_3, var12_20);
            if (var8_15 == null) ** GOTO lbl-1000
            var3_4 = var8_15.q;
            var7_13 = var8_15.r;
            if (var7_13 == null && var3_4.e.s == h.f.a.i) {
                throw new IllegalStateException("Message-typed extension lacked default instance: " + var3_4.c);
            }
            ** GOTO lbl25
lbl19: // 1 sources:
            var3_6 = null;
            ** GOTO lbl25
lbl21: // 1 sources:
            if (var4_9 != null) {
                var3_7 = (h.f)h.b.a(var3_3.c.c).get(new h.b.a(var3_3, var12_20));
            } else lbl-1000: // 2 sources:
            {
                var3_8 = null;
            }
lbl25: // 4 sources:
            if (var3_5 == null) return var1_1.a(var6_11, (e)var0);
            if (var10_18 == l.a(var3_5.f(), false)) {
                var10_18 = 0;
            } else {
                if (var3_5.l() == false) return var1_1.a(var6_11, (e)var0);
                if (var10_18 != l.a(var3_5.f(), true)) return var1_1.a(var6_11, (e)var0);
                var10_18 = 0;
                var11_12 = true;
            }
            if (var10_18 != 0) {
                return var1_1.a(var6_11, (e)var0);
            }
            var6_11 = var0.c(var0.k());
            if (var3_5.f() == ah.a.n) ** GOTO lbl95
            while (var0.o() > 0) {
                a.a((t.a)var4_9, var5_10, (h.f)var3_5, l.a((e)var0, var3_5.f()));
            }
            ** GOTO lbl102
lbl41: // 7 sources:
            while ((var10_17 = var0.a()) != 0) {
                if (var10_17 == ah.c) {
                    var6_11 = var10_17 = var0.k();
                    if (var10_17 == 0) continue;
                    var6_11 = var10_17;
                    if (!(var2_2 instanceof j)) continue;
                    var8_14 = ((j)var2_2).a(var3_3, var10_17);
                    var6_11 = var10_17;
                    continue;
                }
                if (var10_17 == ah.d) {
                    if (var6_11 != 0 && var8_14 != null && k.b()) {
                        var9_16 = var8_14.q;
                        if (a.a((t.a)var4_9, var5_10, var9_16)) {
                            var7_13 = a.b((t.a)var4_9, var5_10, var9_16).toBuilder();
                            var0.a((u.a)var7_13, (k)var2_2);
                            var7_13 = var7_13.buildPartial();
                        } else {
                            var7_13 = var0.a(var8_14.r.getParserForType(), (k)var2_2);
                        }
                        if (var4_9 != null) {
                            var4_9.setField(var9_16, var7_13);
                        } else {
                            var5_10.a(var9_16, var7_13);
                        }
                        var7_13 = null;
                        continue;
                    }
                    var7_13 = var0.f();
                    continue;
                }
                if (var0.b(var10_17)) continue;
            }
            var0.a(ah.b);
            if (var7_13 == null) return true;
            if (var6_11 == 0) return true;
            if (var8_14 == null) {
                if (var7_13 == null) return true;
                var1_1.a(var6_11, af.b.a().a((d)var7_13).a());
                return true;
            }
            var1_1 = var8_14.q;
            var13_19 = a.a((t.a)var4_9, var5_10, (h.f)var1_1);
            if (var13_19 || k.b()) {
                if (var13_19) {
                    var0 = a.b((t.a)var4_9, var5_10, (h.f)var1_1).toBuilder();
                    var0.mergeFrom((d)var7_13, (k)var2_2);
                    var0 = var0.buildPartial();
                } else {
                    var0 = var8_14.r.getParserForType().a((d)var7_13, (k)var2_2);
                }
                a.b((t.a)var4_9, var5_10, (h.f)var1_1, var0);
                return true;
            }
            var0 = new p(var8_14.r, (k)var2_2, (d)var7_13);
            if (var4_9 == null) {
                var5_10.a(var1_1, var0);
                return true;
            }
            if (var4_9 instanceof m.c) {
                var4_9.setField((h.f)var1_1, var0);
                return true;
            }
            var4_9.setField((h.f)var1_1, var0.a());
            return true;
lbl95: // 2 sources:
            while (var0.o() > 0) {
                var10_18 = var0.h();
                var1_1 = var3_5.o().a(var10_18);
                if (var1_1 == null) {
                    return true;
                }
                a.a((t.a)var4_9, var5_10, (h.f)var3_5, var1_1);
            }
lbl102: // 2 sources:
            var0.d(var6_11);
            return true;
        }

        private static boolean a(t.a a2, l<h.f> l2, h.f f2) {
            if (a2 != null) {
                return a2.hasField(f2);
            }
            return l2.a(f2);
        }

        private static t b(t.a a2, l<h.f> l2, h.f f2) {
            if (a2 != null) {
                return (t)a2.getField(f2);
            }
            return (t)l2.b(f2);
        }

        private static List<String> b(w w2) {
            ArrayList<String> arrayList = new ArrayList<String>();
            a.a(w2, "", arrayList);
            return arrayList;
        }

        private static void b(t.a a2, l<h.f> l2, h.f f2, Object object) {
            if (a2 != null) {
                a2.setField(f2, object);
                return;
            }
            l2.a(f2, object);
        }

        public static ae newUninitializedMessageException(t t2) {
            return new ae(a.b(t2));
        }

        public BuilderType clear() {
            Iterator<Map.Entry<h.f, Object>> iterator = this.getAllFields().entrySet().iterator();
            while (iterator.hasNext()) {
                this.clearField(iterator.next().getKey());
            }
            return (BuilderType)this;
        }

        @Override
        public abstract BuilderType clone();

        public List<String> findInitializationErrors() {
            return a.b(this);
        }

        public t.a getFieldBuilder(h.f f2) {
            throw new UnsupportedOperationException("getFieldBuilder() called on an unsupported message type.");
        }

        public String getInitializationErrorString() {
            return a.delimitWithCommas(this.findInitializationErrors());
        }

        @Override
        public boolean mergeDelimitedFrom(InputStream inputStream) {
            return super.mergeDelimitedFrom(inputStream);
        }

        @Override
        public boolean mergeDelimitedFrom(InputStream inputStream, k k2) {
            return super.mergeDelimitedFrom(inputStream, k2);
        }

        @Override
        public BuilderType mergeFrom(d d2) {
            return (BuilderType)((a)super.mergeFrom(d2));
        }

        @Override
        public BuilderType mergeFrom(d d2, k k2) {
            return (BuilderType)((a)super.mergeFrom(d2, k2));
        }

        @Override
        public BuilderType mergeFrom(e e2) {
            return (BuilderType)this.mergeFrom(e2, (k)j.a());
        }

        @Override
        public BuilderType mergeFrom(e e2, k k2) {
            int n2;
            af.a a2 = af.a(this.getUnknownFields());
            while ((n2 = e2.a()) != 0 && a.a(e2, a2, k2, this.getDescriptorForType(), this, null, n2)) {
            }
            this.setUnknownFields(a2.a());
            return (BuilderType)this;
        }

        public BuilderType mergeFrom(t t2) {
            if (t2.getDescriptorForType() != this.getDescriptorForType()) {
                throw new IllegalArgumentException("mergeFrom(Message) can only merge messages of the same type.");
            }
            Iterator<Map.Entry<h.f, Object>> iterator = t2.getAllFields().entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<h.f, Object> entry = iterator.next();
                h.f f2 = entry.getKey();
                if (f2.j()) {
                    entry = ((List)entry.getValue()).iterator();
                    while (entry.hasNext()) {
                        this.addRepeatedField(f2, entry.next());
                    }
                    continue;
                }
                if (f2.e.s == h.f.a.i) {
                    t t3 = (t)this.getField(f2);
                    if (t3 == t3.getDefaultInstanceForType()) {
                        this.setField(f2, entry.getValue());
                        continue;
                    }
                    this.setField(f2, t3.newBuilderForType().mergeFrom(t3).mergeFrom((t)entry.getValue()).build());
                    continue;
                }
                this.setField(f2, entry.getValue());
            }
            this.mergeUnknownFields(t2.getUnknownFields());
            return (BuilderType)this;
        }

        @Override
        public BuilderType mergeFrom(InputStream inputStream) {
            return (BuilderType)((a)super.mergeFrom(inputStream));
        }

        @Override
        public BuilderType mergeFrom(InputStream inputStream, k k2) {
            return (BuilderType)((a)super.mergeFrom(inputStream, k2));
        }

        @Override
        public BuilderType mergeFrom(byte[] arrby) {
            return (BuilderType)((a)super.mergeFrom(arrby));
        }

        @Override
        public BuilderType mergeFrom(byte[] arrby, int n2, int n3) {
            return (BuilderType)((a)super.mergeFrom(arrby, n2, n3));
        }

        @Override
        public BuilderType mergeFrom(byte[] arrby, int n2, int n3, k k2) {
            return (BuilderType)((a)super.mergeFrom(arrby, n2, n3, k2));
        }

        @Override
        public BuilderType mergeFrom(byte[] arrby, k k2) {
            return (BuilderType)((a)super.mergeFrom(arrby, k2));
        }

        public BuilderType mergeUnknownFields(af af2) {
            this.setUnknownFields(af.a(this.getUnknownFields()).a(af2).a());
            return (BuilderType)this;
        }
    }

}

