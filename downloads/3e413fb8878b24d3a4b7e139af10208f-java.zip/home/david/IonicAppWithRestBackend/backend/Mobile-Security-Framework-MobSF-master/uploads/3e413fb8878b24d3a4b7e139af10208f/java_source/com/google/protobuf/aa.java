/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.d;
import com.google.protobuf.e;
import com.google.protobuf.s;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Stack;

final class aa
extends d {
    private static final int[] c;
    private final int d;
    private final d e;
    private final d f;
    private final int g;
    private int h;

    static {
        int n2 = 1;
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        int n3 = 1;
        do {
            int n4 = n3;
            if (n2 <= 0) break;
            arrayList.add(n2);
            n3 = n2;
            n2 = n4 + n2;
        } while (true);
        arrayList.add(Integer.MAX_VALUE);
        c = new int[arrayList.size()];
        for (n2 = 0; n2 < c.length; ++n2) {
            aa.c[n2] = (Integer)arrayList.get(n2);
        }
    }

    @Override
    public final byte a(int n2) {
        if (n2 < 0) {
            throw new ArrayIndexOutOfBoundsException("Index < 0: " + n2);
        }
        if (n2 > this.d) {
            throw new ArrayIndexOutOfBoundsException("Index > length: " + n2 + ", " + this.d);
        }
        if (n2 < this.g) {
            return this.e.a(n2);
        }
        return this.f.a(n2 - this.g);
    }

    @Override
    protected final int a(int n2, int n3, int n4) {
        if (n3 + n4 <= this.g) {
            return this.e.a(n2, n3, n4);
        }
        if (n3 >= this.g) {
            return this.f.a(n2, n3 - this.g, n4);
        }
        int n5 = this.g - n3;
        n2 = this.e.a(n2, n3, n5);
        return this.f.a(n2, 0, n4 - n5);
    }

    @Override
    public final d.a a() {
        return new b(0);
    }

    @Override
    public final int b() {
        return this.d;
    }

    @Override
    protected final int b(int n2, int n3, int n4) {
        if (n3 + n4 <= this.g) {
            return this.e.b(n2, n3, n4);
        }
        if (n3 >= this.g) {
            return this.f.b(n2, n3 - this.g, n4);
        }
        int n5 = this.g - n3;
        n2 = this.e.b(n2, n3, n5);
        return this.f.b(n2, 0, n4 - n5);
    }

    @Override
    public final String b(String string) {
        return new String(this.c(), string);
    }

    @Override
    protected final void b(byte[] arrby, int n2, int n3, int n4) {
        if (n2 + n4 <= this.g) {
            this.e.b(arrby, n2, n3, n4);
            return;
        }
        if (n2 >= this.g) {
            this.f.b(arrby, n2 - this.g, n3, n4);
            return;
        }
        int n5 = this.g - n2;
        this.e.b(arrby, n2, n3, n5);
        this.f.b(arrby, 0, n3 + n5, n4 - n5);
    }

    @Override
    public final boolean e() {
        boolean bl2 = false;
        int n2 = this.e.a(0, 0, this.g);
        if (this.f.a(n2, 0, this.f.b()) == 0) {
            bl2 = true;
        }
        return bl2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean equals(Object object) {
        int n2;
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!(object instanceof d)) return bl3;
        object = (d)object;
        bl3 = bl2;
        if (this.d != object.b()) return bl3;
        if (this.d == 0) {
            return true;
        }
        if (this.h != 0 && (n2 = object.h()) != 0) {
            bl3 = bl2;
            if (this.h != n2) return bl3;
        }
        a a2 = new a(this, 0);
        s s2 = (s)a2.next();
        a a3 = new a((d)object, 0);
        object = (s)a3.next();
        n2 = 0;
        int n3 = 0;
        int n4 = 0;
        do {
            int n5 = s2.b() - n3;
            int n6 = object.b() - n2;
            int n7 = Math.min(n5, n6);
            boolean bl4 = n3 == 0 ? s2.a((s)object, n2, n7) : object.a(s2, n3, n7);
            bl3 = bl2;
            if (!bl4) return bl3;
            if ((n4 += n7) >= this.d) {
                if (n4 != this.d) throw new IllegalStateException();
                return true;
            }
            if (n7 == n5) {
                s2 = (s)a2.next();
                n3 = 0;
            } else {
                n3 += n7;
            }
            if (n7 == n6) {
                object = (s)a3.next();
                n2 = 0;
                continue;
            }
            n2 += n7;
        } while (true);
    }

    @Override
    public final InputStream f() {
        return new c();
    }

    @Override
    public final e g() {
        return e.a(new c());
    }

    @Override
    protected final int h() {
        return this.h;
    }

    public final int hashCode() {
        int n2;
        int n3 = n2 = this.h;
        if (n2 == 0) {
            n3 = n2 = this.b(this.d, 0, this.d);
            if (n2 == 0) {
                n3 = 1;
            }
            this.h = n3;
        }
        return n3;
    }

    @Override
    public final /* synthetic */ Iterator iterator() {
        return this.a();
    }

    static final class a
    implements Iterator<s> {
        private final Stack<aa> a = new Stack();
        private s b;

        private a(d d2) {
            this.b = this.a(d2);
        }

        /* synthetic */ a(d d2, byte by2) {
            this(d2);
        }

        private s a(d d2) {
            while (d2 instanceof aa) {
                d2 = (aa)d2;
                this.a.push((aa)d2);
                d2 = ((aa)d2).e;
            }
            return (s)d2;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        private s b() {
            boolean bl2;
            s s2;
            do {
                if (this.a.isEmpty()) {
                    return null;
                }
                s2 = this.a(this.a.pop().f);
                if (s2.b() != 0) return s2;
            } while (bl2 = true);
            return s2;
        }

        public final s a() {
            if (this.b == null) {
                throw new NoSuchElementException();
            }
            s s2 = this.b;
            this.b = this.b();
            return s2;
        }

        @Override
        public final boolean hasNext() {
            if (this.b != null) {
                return true;
            }
            return false;
        }

        @Override
        public final /* synthetic */ Object next() {
            return this.a();
        }

        @Override
        public final void remove() {
            throw new UnsupportedOperationException();
        }
    }

    final class b
    implements d.a {
        int a;
        private final a c;
        private d.a d;

        private b() {
            this.c = new a(aa.this, 0);
            this.d = this.c.a().a();
            this.a = aa.this.b();
        }

        /* synthetic */ b(byte by2) {
            this();
        }

        @Override
        public final byte a() {
            if (!this.d.hasNext()) {
                this.d = this.c.a().a();
            }
            --this.a;
            return this.d.a();
        }

        @Override
        public final boolean hasNext() {
            if (this.a > 0) {
                return true;
            }
            return false;
        }

        @Override
        public final /* synthetic */ Object next() {
            return Byte.valueOf(this.a());
        }

        @Override
        public final void remove() {
            throw new UnsupportedOperationException();
        }
    }

    final class c
    extends InputStream {
        private a b;
        private s c;
        private int d;
        private int e;
        private int f;
        private int g;

        public c() {
            this.a();
        }

        private int a(byte[] arrby, int n2, int n3) {
            int n4 = n3;
            int n5 = n2;
            n2 = n4;
            n4 = n5;
            while (n2 > 0) {
                this.b();
                if (this.c == null) {
                    if (n2 != n3) break;
                    return -1;
                }
                int n6 = Math.min(this.d - this.e, n2);
                n5 = n4;
                if (arrby != null) {
                    this.c.a(arrby, this.e, n4, n6);
                    n5 = n4 + n6;
                }
                this.e += n6;
                n2 -= n6;
                n4 = n5;
            }
            return n3 - n2;
        }

        private void a() {
            this.b = new a(aa.this, 0);
            this.c = this.b.a();
            this.d = this.c.b();
            this.e = 0;
            this.f = 0;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        private void b() {
            if (this.c == null || this.e != this.d) return;
            this.f += this.d;
            this.e = 0;
            if (this.b.hasNext()) {
                this.c = this.b.a();
                this.d = this.c.b();
                return;
            }
            this.c = null;
            this.d = 0;
        }

        @Override
        public final int available() {
            int n2 = this.f;
            int n3 = this.e;
            return aa.this.b() - (n2 + n3);
        }

        @Override
        public final void mark(int n2) {
            this.g = this.f + this.e;
        }

        @Override
        public final boolean markSupported() {
            return true;
        }

        @Override
        public final int read() {
            this.b();
            if (this.c == null) {
                return -1;
            }
            s s2 = this.c;
            int n2 = this.e;
            this.e = n2 + 1;
            return s2.a(n2) & 255;
        }

        @Override
        public final int read(byte[] arrby, int n2, int n3) {
            if (arrby == null) {
                throw new NullPointerException();
            }
            if (n2 < 0 || n3 < 0 || n3 > arrby.length - n2) {
                throw new IndexOutOfBoundsException();
            }
            return this.a(arrby, n2, n3);
        }

        @Override
        public final void reset() {
            synchronized (this) {
                this.a();
                this.a(null, 0, this.g);
                return;
            }
        }

        @Override
        public final long skip(long l2) {
            if (l2 < 0) {
                throw new IndexOutOfBoundsException();
            }
            long l3 = l2;
            if (l2 > Integer.MAX_VALUE) {
                l3 = Integer.MAX_VALUE;
            }
            return this.a(null, 0, (int)l3);
        }
    }

}

