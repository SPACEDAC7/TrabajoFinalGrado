/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.m;
import com.google.protobuf.t;
import com.google.protobuf.u;
import com.google.protobuf.w;

public final class ab<MType extends m, BType extends m.a, IType extends w>
implements m.b {
    m.b a;
    private BType b;
    private MType c;
    private boolean d;

    public ab(MType MType, m.b b2, boolean bl2) {
        if (MType == null) {
            throw new NullPointerException();
        }
        this.c = MType;
        this.a = b2;
        this.d = bl2;
    }

    private void g() {
        if (this.b != null) {
            this.c = null;
        }
        if (this.d && this.a != null) {
            this.a.a();
            this.d = false;
        }
    }

    public final ab<MType, BType, IType> a(MType MType) {
        if (MType == null) {
            throw new NullPointerException();
        }
        this.c = MType;
        if (this.b != null) {
            this.b.a = null;
            this.b = null;
        }
        this.g();
        return this;
    }

    @Override
    public final void a() {
        this.g();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final ab<MType, BType, IType> b(MType MType) {
        if (this.b == null && this.c == this.c.getDefaultInstanceForType()) {
            this.c = MType;
        } else {
            this.d().mergeFrom((t)MType);
        }
        this.g();
        return this;
    }

    public final MType b() {
        if (this.c == null) {
            this.c = (m)this.b.buildPartial();
        }
        return this.c;
    }

    public final MType c() {
        this.d = true;
        return this.b();
    }

    public final BType d() {
        if (this.b == null) {
            this.b = (m.a)this.c.newBuilderForType(this);
            this.b.mergeFrom((t)this.c);
            this.b.b = true;
        }
        return this.b;
    }

    public final IType e() {
        if (this.b != null) {
            return (IType)this.b;
        }
        return (IType)this.c;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final ab<MType, BType, IType> f() {
        t t2 = this.c != null ? this.c.getDefaultInstanceForType() : this.b.getDefaultInstanceForType();
        this.c = (m)t2;
        if (this.b != null) {
            this.b.a = null;
            this.b = null;
        }
        this.g();
        return this;
    }
}

