/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.l;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

class ac<K extends Comparable<K>, V>
extends AbstractMap<K, V> {
    boolean a;
    private final int b;
    private List<ac<K, V>> c;
    private Map<K, V> d;
    private volatile ac<K, V> e;

    private ac(int n2) {
        this.b = n2;
        this.c = Collections.emptyList();
        this.d = Collections.emptyMap();
    }

    /* synthetic */ ac(int n2, byte by2) {
        this(n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private int a(K k2) {
        int n2;
        int n3 = this.c.size() - 1;
        if (n3 >= 0) {
            n2 = k2.compareTo(((b)this.c.get((int)n3)).a);
            if (n2 > 0) {
                return - n3 + 2;
            }
            if (n2 == 0) {
                return n3;
            }
        }
        n2 = 0;
        while (n2 <= n3) {
            int n4 = (n2 + n3) / 2;
            int n5 = k2.compareTo(((b)this.c.get((int)n4)).a);
            if (n5 < 0) {
                n3 = n4 - 1;
                continue;
            }
            if (n5 <= 0) {
                return n4;
            }
            n2 = n4 + 1;
        }
        return - n2 + 1;
    }

    static <FieldDescriptorType extends l.a<FieldDescriptorType>> ac<FieldDescriptorType, Object> a(int n2) {
        return new ac<FieldDescriptorType, Object>(n2){

            @Override
            public final void a() {
                if (!this.a) {
                    for (int i2 = 0; i2 < this.b(); ++i2) {
                        Map.Entry entry = this.b(i2);
                        if (!((l.a)entry.getKey()).j()) continue;
                        entry.setValue(Collections.unmodifiableList((List)entry.getValue()));
                    }
                    for (Map.Entry entry : this.c()) {
                        if (!((l.a)entry.getKey()).j()) continue;
                        entry.setValue(Collections.unmodifiableList((List)entry.getValue()));
                    }
                }
                super.a();
            }

            @Override
            public final /* synthetic */ Object put(Object object, Object object2) {
                return super.a((l.a)object, object2);
            }
        };
    }

    private V c(int n2) {
        this.d();
        Object v2 = ((b)((Object)this.c.remove(n2))).getValue();
        if (!this.d.isEmpty()) {
            Iterator<Map.Entry<K, V>> iterator = this.e().entrySet().iterator();
            this.c.add((ac<K, V>)((Object)new b(iterator.next())));
            iterator.remove();
        }
        return v2;
    }

    private void d() {
        if (this.a) {
            throw new UnsupportedOperationException();
        }
    }

    private SortedMap<K, V> e() {
        this.d();
        if (this.d.isEmpty() && !(this.d instanceof TreeMap)) {
            this.d = new TreeMap();
        }
        return (SortedMap)this.d;
    }

    public final V a(K k2, V v2) {
        this.d();
        int n2 = this.a(k2);
        if (n2 >= 0) {
            return ((b)((Object)this.c.get(n2))).setValue(v2);
        }
        this.d();
        if (this.c.isEmpty() && !(this.c instanceof ArrayList)) {
            this.c = new ArrayList<ac<K, V>>(this.b);
        }
        if ((n2 = - n2 + 1) >= this.b) {
            return this.e().put(k2, v2);
        }
        if (this.c.size() == this.b) {
            b b2 = (b)((Object)this.c.remove(this.b - 1));
            this.e().put(b2.a, b2.getValue());
        }
        this.c.add(n2, (ac<K, V>)((Object)new b(this, k2, v2)));
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a() {
        if (!this.a) {
            Map map = this.d.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(this.d);
            this.d = map;
            this.a = true;
        }
    }

    public final int b() {
        return this.c.size();
    }

    public final Map.Entry<K, V> b(int n2) {
        return (Map.Entry)((Object)this.c.get(n2));
    }

    public final Iterable<Map.Entry<K, V>> c() {
        if (this.d.isEmpty()) {
            return a.a();
        }
        return this.d.entrySet();
    }

    @Override
    public void clear() {
        this.d();
        if (!this.c.isEmpty()) {
            this.c.clear();
        }
        if (!this.d.isEmpty()) {
            this.d.clear();
        }
    }

    @Override
    public boolean containsKey(Object object) {
        if (this.a(object = (Comparable)object) >= 0 || this.d.containsKey(object)) {
            return true;
        }
        return false;
    }

    @Override
    public Set<Map.Entry<K, V>> entrySet() {
        if (this.e == null) {
            this.e = new d(0);
        }
        return this.e;
    }

    @Override
    public V get(Object object) {
        int n2 = this.a(object = (Comparable)object);
        if (n2 >= 0) {
            return ((b)((Object)this.c.get(n2))).getValue();
        }
        return this.d.get(object);
    }

    @Override
    public /* synthetic */ Object put(Object object, Object object2) {
        return this.a((Comparable)object, object2);
    }

    @Override
    public V remove(Object object) {
        this.d();
        object = (Comparable)object;
        int n2 = this.a(object);
        if (n2 >= 0) {
            return this.c(n2);
        }
        if (this.d.isEmpty()) {
            return null;
        }
        return this.d.remove(object);
    }

    @Override
    public int size() {
        return this.c.size() + this.d.size();
    }

    static final class a {
        private static final Iterator<Object> a = new Iterator<Object>(){

            @Override
            public final boolean hasNext() {
                return false;
            }

            @Override
            public final Object next() {
                throw new NoSuchElementException();
            }

            @Override
            public final void remove() {
                throw new UnsupportedOperationException();
            }
        };
        private static final Iterable<Object> b = new Iterable<Object>(){

            @Override
            public final Iterator<Object> iterator() {
                return a;
            }
        };

        static <T> Iterable<T> a() {
            return b;
        }

    }

    final class b
    implements Comparable<ac<K, V>>,
    Map.Entry<K, V> {
        final K a;
        private V c;

        b(V k2) {
            this.a = k2;
            this.c = v2;
        }

        b(Map.Entry<K, V> entry) {
            this(ac2, (Comparable)entry.getKey(), entry.getValue());
        }

        private static boolean a(Object object, Object object2) {
            if (object == null) {
                if (object2 == null) {
                    return true;
                }
                return false;
            }
            return object.equals(object2);
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        @Override
        public final boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof Map.Entry)) {
                return false;
            }
            if (!b.a(this.a, (object = (Map.Entry)object).getKey())) return false;
            if (b.a(this.c, object.getValue())) return true;
            return false;
        }

        @Override
        public final V getValue() {
            return this.c;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int hashCode() {
            int n2 = 0;
            int n3 = this.a == null ? 0 : this.a.hashCode();
            if (this.c == null) {
                return n3 ^ n2;
            }
            n2 = this.c.hashCode();
            return n3 ^ n2;
        }

        @Override
        public final V setValue(V v2) {
            b.d();
            V v3 = this.c;
            this.c = v2;
            return v3;
        }

        public final String toString() {
            return this.a + "=" + this.c;
        }
    }

    final class c
    implements Iterator<Map.Entry<K, V>> {
        private int b;
        private boolean c;
        private Iterator<Map.Entry<K, V>> d;

        private c() {
            this.b = -1;
        }

        /* synthetic */ c(byte by2) {
            this();
        }

        private Iterator<Map.Entry<K, V>> a() {
            if (this.d == null) {
                this.d = ac.this.d.entrySet().iterator();
            }
            return this.d;
        }

        @Override
        public final boolean hasNext() {
            if (this.b + 1 < ac.this.c.size() || this.a().hasNext()) {
                return true;
            }
            return false;
        }

        @Override
        public final /* synthetic */ Object next() {
            int n2;
            this.c = true;
            this.b = n2 = this.b + 1;
            if (n2 < ac.this.c.size()) {
                return (Map.Entry)ac.this.c.get(this.b);
            }
            return this.a().next();
        }

        @Override
        public final void remove() {
            if (!this.c) {
                throw new IllegalStateException("remove() was called before next()");
            }
            this.c = false;
            ac.this.d();
            if (this.b < ac.this.c.size()) {
                ac ac2 = ac.this;
                int n2 = this.b;
                this.b = n2 - 1;
                ac2.c(n2);
                return;
            }
            this.a().remove();
        }
    }

    final class d
    extends AbstractSet<Map.Entry<K, V>> {
        private d() {
        }

        /* synthetic */ d(byte by2) {
            this();
        }

        @Override
        public final /* synthetic */ boolean add(Object object) {
            if (!this.contains(object = (Map.Entry)object)) {
                ac.this.a((Comparable)object.getKey(), object.getValue());
                return true;
            }
            return false;
        }

        @Override
        public final void clear() {
            ac.this.clear();
        }

        @Override
        public final boolean contains(Object object) {
            Map.Entry entry = (Map.Entry)object;
            object = ac.this.get(entry.getKey());
            if (object == (entry = entry.getValue()) || object != null && object.equals(entry)) {
                return true;
            }
            return false;
        }

        @Override
        public final Iterator<Map.Entry<K, V>> iterator() {
            return new c(0);
        }

        @Override
        public final boolean remove(Object object) {
            if (this.contains(object = (Map.Entry)object)) {
                ac.this.remove(object.getKey());
                return true;
            }
            return false;
        }

        @Override
        public final int size() {
            return ac.this.size();
        }
    }

}

