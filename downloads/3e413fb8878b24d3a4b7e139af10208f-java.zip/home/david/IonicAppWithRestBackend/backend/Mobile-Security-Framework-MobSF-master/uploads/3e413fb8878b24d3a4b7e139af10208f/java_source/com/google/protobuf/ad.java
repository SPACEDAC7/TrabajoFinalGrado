/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.af;
import com.google.protobuf.ah;
import com.google.protobuf.d;
import com.google.protobuf.g;
import com.google.protobuf.h;
import com.google.protobuf.t;
import com.google.protobuf.w;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class ad {
    private static final b a = new b(0);
    private static final b b;
    private static final b c;

    static {
        b b2 = new b(0);
        b2.a = true;
        b = b2;
        b2 = new b(0);
        b2.b = false;
        c = b2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static long a(String string, boolean bl2, boolean bl3) {
        int n2;
        Object object;
        boolean bl4 = true;
        int n3 = 0;
        if (string.startsWith("-", 0)) {
            if (!bl2) {
                throw new NumberFormatException("Number must be positive: " + string);
            }
            n3 = 1;
        } else {
            bl4 = false;
        }
        if (string.startsWith("0x", n3)) {
            n2 = n3 + 2;
            n3 = 16;
        } else if (string.startsWith("0", n3)) {
            n2 = n3;
            n3 = 8;
        } else {
            n2 = n3;
            n3 = 10;
        }
        if ((object = string.substring(n2)).length() < 16) {
            long l2 = Long.parseLong((String)object, n3);
            if (bl4) {
                l2 = - l2;
            }
            long l3 = l2;
            if (bl3) return l3;
            if (bl2) {
                if (l2 > Integer.MAX_VALUE) throw new NumberFormatException("Number out of range for 32-bit signed integer: " + string);
                l3 = l2;
                if (l2 >= Integer.MIN_VALUE) return l3;
                throw new NumberFormatException("Number out of range for 32-bit signed integer: " + string);
            }
            if (l2 >= 0x100000000L) throw new NumberFormatException("Number out of range for 32-bit unsigned integer: " + string);
            l3 = l2;
            if (l2 >= 0) return l3;
            throw new NumberFormatException("Number out of range for 32-bit unsigned integer: " + string);
        }
        object = new BigInteger((String)object, n3);
        if (bl4) {
            object = object.negate();
        }
        if (!bl3) {
            if (bl2) {
                if (object.bitLength() <= 31) return object.longValue();
                throw new NumberFormatException("Number out of range for 32-bit signed integer: " + string);
            }
            if (object.bitLength() <= 32) return object.longValue();
            throw new NumberFormatException("Number out of range for 32-bit unsigned integer: " + string);
        }
        if (bl2) {
            if (object.bitLength() <= 63) return object.longValue();
            throw new NumberFormatException("Number out of range for 64-bit signed integer: " + string);
        }
        if (object.bitLength() <= 64) return object.longValue();
        throw new NumberFormatException("Number out of range for 64-bit unsigned integer: " + string);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static d a(CharSequence var0) {
        var0 = d.a(var0.toString());
        var2_1 = new byte[var0.b()];
        var4_2 = 0;
        var6_3 = 0;
        while (var4_2 < var0.b()) {
            var1_4 = var0.a(var4_2);
            if (var1_4 != 92) ** GOTO lbl100
            if (var4_2 + 1 >= var0.b()) throw new a("Invalid escape sequence: '\\' at end of string.");
            var5_6 = var4_2 + 1;
            var1_4 = var0.a(var5_6);
            if (!ad.a(var1_4)) ** GOTO lbl32
            var3_5 = var7_7 = ad.c(var1_4);
            var4_2 = var5_6;
            if (var5_6 + 1 < var0.b()) {
                var3_5 = var7_7;
                var4_2 = var5_6;
                if (ad.a(var0.a(var5_6 + 1))) {
                    var4_2 = var5_6 + 1;
                    var3_5 = (var7_7 << 3) + ad.c(var0.a(var4_2));
                }
            }
            var7_7 = var3_5;
            var5_6 = var4_2;
            if (var4_2 + 1 < var0.b()) {
                var7_7 = var3_5;
                var5_6 = var4_2;
                if (ad.a(var0.a(var4_2 + 1))) {
                    var5_6 = var4_2 + 1;
                    var7_7 = (var3_5 << 3) + ad.c(var0.a(var5_6));
                }
            }
            var2_1[var6_3] = (byte)var7_7;
            var3_5 = var6_3 + 1;
            var4_2 = var5_6;
            ** GOTO lbl102
lbl32: // 1 sources:
            switch (var1_4) {
                default: {
                    throw new a("Invalid escape sequence: '\\" + (char)var1_4 + '\'');
                }
                case 97: {
                    var2_1[var6_3] = 7;
                    var3_5 = var6_3 + 1;
                    var4_2 = var5_6;
                    ** GOTO lbl102
                }
                case 98: {
                    var2_1[var6_3] = 8;
                    var3_5 = var6_3 + 1;
                    var4_2 = var5_6;
                    ** GOTO lbl102
                }
                case 102: {
                    var2_1[var6_3] = 12;
                    var3_5 = var6_3 + 1;
                    var4_2 = var5_6;
                    ** GOTO lbl102
                }
                case 110: {
                    var2_1[var6_3] = 10;
                    var3_5 = var6_3 + 1;
                    var4_2 = var5_6;
                    ** GOTO lbl102
                }
                case 114: {
                    var2_1[var6_3] = 13;
                    var3_5 = var6_3 + 1;
                    var4_2 = var5_6;
                    ** GOTO lbl102
                }
                case 116: {
                    var2_1[var6_3] = 9;
                    var3_5 = var6_3 + 1;
                    var4_2 = var5_6;
                    ** GOTO lbl102
                }
                case 118: {
                    var2_1[var6_3] = 11;
                    var3_5 = var6_3 + 1;
                    var4_2 = var5_6;
                    ** GOTO lbl102
                }
                case 92: {
                    var2_1[var6_3] = 92;
                    var3_5 = var6_3 + 1;
                    var4_2 = var5_6;
                    ** GOTO lbl102
                }
                case 39: {
                    var2_1[var6_3] = 39;
                    var3_5 = var6_3 + 1;
                    var4_2 = var5_6;
                    ** GOTO lbl102
                }
                case 34: {
                    var2_1[var6_3] = 34;
                    var3_5 = var6_3 + 1;
                    var4_2 = var5_6;
                    ** GOTO lbl102
                }
                case 120: 
            }
            if (var5_6 + 1 >= var0.b()) throw new a("Invalid escape sequence: '\\x' with no digits");
            if (ad.b(var0.a(var5_6 + 1)) == false) throw new a("Invalid escape sequence: '\\x' with no digits");
            var7_7 = var5_6 + 1;
            var3_5 = var5_6 = ad.c(var0.a(var7_7));
            var4_2 = var7_7;
            if (var7_7 + 1 < var0.b()) {
                var3_5 = var5_6;
                var4_2 = var7_7;
                if (ad.b(var0.a(var7_7 + 1))) {
                    var4_2 = var7_7 + 1;
                    var3_5 = (var5_6 << 4) + ad.c(var0.a(var4_2));
                }
            }
            var2_1[var6_3] = (byte)var3_5;
            var3_5 = var6_3 + 1;
            ** GOTO lbl102
lbl100: // 1 sources:
            var2_1[var6_3] = var1_4;
            var3_5 = var6_3 + 1;
lbl102: // 13 sources:
            ++var4_2;
            var6_3 = var3_5;
        }
        return d.a(var2_1, 0, var6_3);
    }

    static /* synthetic */ String a(int n2) {
        if (n2 >= 0) {
            return Integer.toString(n2);
        }
        return Long.toString((long)n2 & 0xFFFFFFFFL);
    }

    static /* synthetic */ String a(long l2) {
        return ad.b(l2);
    }

    public static String a(af object) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            a.a((af)object, new c(stringBuilder, 0));
            object = stringBuilder.toString();
            return object;
        }
        catch (IOException var0_1) {
            throw new IllegalStateException(var0_1);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static String a(d var0) {
        var1_1 = new StringBuilder(var0.b());
        var2_2 = 0;
        while (var2_2 < var0.b()) {
            var3_3 = var0.a(var2_2);
            switch (var3_3) {
                default: {
                    if (var3_3 < 32) break;
                    var1_1.append((char)var3_3);
                    ** GOTO lbl44
                }
                case 7: {
                    var1_1.append("\\a");
                    ** GOTO lbl44
                }
                case 8: {
                    var1_1.append("\\b");
                    ** GOTO lbl44
                }
                case 12: {
                    var1_1.append("\\f");
                    ** GOTO lbl44
                }
                case 10: {
                    var1_1.append("\\n");
                    ** GOTO lbl44
                }
                case 13: {
                    var1_1.append("\\r");
                    ** GOTO lbl44
                }
                case 9: {
                    var1_1.append("\\t");
                    ** GOTO lbl44
                }
                case 11: {
                    var1_1.append("\\v");
                    ** GOTO lbl44
                }
                case 92: {
                    var1_1.append("\\\\");
                    ** GOTO lbl44
                }
                case 39: {
                    var1_1.append("\\'");
                    ** GOTO lbl44
                }
                case 34: {
                    var1_1.append("\\\"");
                    ** GOTO lbl44
                }
            }
            var1_1.append('\\');
            var1_1.append((char)((var3_3 >>> 6 & 3) + 48));
            var1_1.append((char)((var3_3 >>> 3 & 7) + 48));
            var1_1.append((char)((var3_3 & 7) + 48));
lbl44: // 12 sources:
            ++var2_2;
        }
        return var1_1.toString();
    }

    public static String a(w object) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            ad.a((w)object, stringBuilder);
            object = stringBuilder.toString();
            return object;
        }
        catch (IOException var0_1) {
            throw new IllegalStateException(var0_1);
        }
    }

    static String a(String string) {
        return ad.a(d.a(string));
    }

    static /* synthetic */ void a(int n2, Object object, c c2) {
        switch (ah.a(n2)) {
            default: {
                throw new IllegalArgumentException("Bad tag: " + n2);
            }
            case 0: {
                c2.a(ad.b((Long)object));
                return;
            }
            case 5: {
                c2.a(String.format(null, "0x%08x", (Integer)object));
                return;
            }
            case 1: {
                c2.a(String.format(null, "0x%016x", (Long)object));
                return;
            }
            case 2: {
                c2.a("\"");
                c2.a(ad.a((d)object));
                c2.a("\"");
                return;
            }
            case 3: 
        }
        a.a((af)object, c2);
    }

    private static void a(w w2, Appendable appendable) {
        a.a(w2, new c(appendable, 0));
    }

    private static boolean a(byte by2) {
        if (48 <= by2 && by2 <= 55) {
            return true;
        }
        return false;
    }

    static int b(String string) {
        return (int)ad.a(string, true, false);
    }

    private static String b(long l2) {
        if (l2 >= 0) {
            return Long.toString(l2);
        }
        return BigInteger.valueOf(Long.MAX_VALUE & l2).setBit(63).toString();
    }

    private static boolean b(byte by2) {
        if (48 <= by2 && by2 <= 57 || 97 <= by2 && by2 <= 102 || 65 <= by2 && by2 <= 70) {
            return true;
        }
        return false;
    }

    private static int c(byte by2) {
        if (48 <= by2 && by2 <= 57) {
            return by2 - 48;
        }
        if (97 <= by2 && by2 <= 122) {
            return by2 - 97 + 10;
        }
        return by2 - 65 + 10;
    }

    static int c(String string) {
        return (int)ad.a(string, false, false);
    }

    static long d(String string) {
        return ad.a(string, true, true);
    }

    static long e(String string) {
        return ad.a(string, false, true);
    }

    static final class a
    extends IOException {
        a(String string) {
            super(string);
        }
    }

    static final class b {
        boolean a = false;
        boolean b = true;

        private b() {
        }

        /* synthetic */ b(byte by2) {
            this();
        }

        /*
         * Enabled aggressive block sorting
         */
        private void a(int n2, int n3, List<?> object, c c2) {
            Iterator iterator = object.iterator();
            while (iterator.hasNext()) {
                object = iterator.next();
                c2.a(String.valueOf(n2));
                c2.a(": ");
                ad.a(n3, object, c2);
                object = this.a ? " " : "\n";
                c2.a((CharSequence)object);
            }
            return;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        private void a(h.f var1_1, Object var2_2, c var3_3) {
            if (!var1_1.b.f()) ** GOTO lbl12
            var3_3.a("[");
            if (!var1_1.f.a.d.c || var1_1.e != h.f.b.k || !var1_1.i()) ** GOTO lbl-1000
            if (!var1_1.b.f()) {
                throw new UnsupportedOperationException("This field is not an extension.");
            }
            if (var1_1.d == var1_1.n()) {
                var3_3.a(var1_1.n().b);
            } else lbl-1000: // 2 sources:
            {
                var3_3.a(var1_1.c);
            }
            var3_3.a("]");
            ** GOTO lbl16
lbl12: // 1 sources:
            if (var1_1.e == h.f.b.j) {
                var3_3.a(var1_1.n().a.b());
            } else {
                var3_3.a(var1_1.b.b());
            }
lbl16: // 3 sources:
            if (var1_1.e.s == h.f.a.i) {
                if (this.a) {
                    var3_3.a(" { ");
                } else {
                    var3_3.a(" {\n");
                    var3_3.a();
                }
            } else {
                var3_3.a(": ");
            }
            switch (.a[var1_1.e.ordinal()]) {
                case 1: 
                case 2: 
                case 3: {
                    var3_3.a(((Integer)var2_2).toString());
                    break;
                }
                case 4: 
                case 5: 
                case 6: {
                    var3_3.a(((Long)var2_2).toString());
                    break;
                }
                case 7: {
                    var3_3.a(((Boolean)var2_2).toString());
                    break;
                }
                case 8: {
                    var3_3.a(((Float)var2_2).toString());
                    break;
                }
                case 9: {
                    var3_3.a(((Double)var2_2).toString());
                    break;
                }
                case 10: 
                case 11: {
                    var3_3.a(ad.a((Integer)var2_2));
                    break;
                }
                case 12: 
                case 13: {
                    var3_3.a(ad.a((Long)var2_2));
                    break;
                }
                case 14: {
                    var3_3.a("\"");
                    var2_2 = this.b != false ? ad.a((String)var2_2) : (String)var2_2;
                    var3_3.a((CharSequence)var2_2);
                    var3_3.a("\"");
                    break;
                }
                case 15: {
                    var3_3.a("\"");
                    var3_3.a(ad.a((d)var2_2));
                    var3_3.a("\"");
                    break;
                }
                case 16: {
                    var3_3.a(((h.e)var2_2).b.b());
                    break;
                }
                case 17: 
                case 18: {
                    this.a((t)var2_2, var3_3);
                }
            }
            if (var1_1.e.s == h.f.a.i) {
                if (this.a) {
                    var3_3.a("} ");
                    return;
                }
                var3_3.b();
                var3_3.a("}\n");
                return;
            }
            if (this.a) {
                var3_3.a(" ");
                return;
            }
            var3_3.a("\n");
        }

        /*
         * Enabled aggressive block sorting
         */
        final void a(af iterator, c c2) {
            iterator = iterator.a.entrySet().iterator();
            block0 : while (iterator.hasNext()) {
                Map.Entry<Integer, af.b> entry = iterator.next();
                int n2 = entry.getKey();
                Object object = entry.getValue();
                this.a(n2, 0, object.a, c2);
                this.a(n2, 5, object.b, c2);
                this.a(n2, 1, object.c, c2);
                this.a(n2, 2, object.d, c2);
                object = object.e.iterator();
                do {
                    if (!object.hasNext()) continue block0;
                    af af2 = (af)object.next();
                    c2.a(entry.getKey().toString());
                    if (this.a) {
                        c2.a(" { ");
                    } else {
                        c2.a(" {\n");
                        c2.a();
                    }
                    this.a(af2, c2);
                    if (this.a) {
                        c2.a("} ");
                        continue;
                    }
                    c2.b();
                    c2.a("}\n");
                } while (true);
                break;
            }
            return;
        }

        final void a(w w2, c c2) {
            Iterator<Map.Entry<h.f, Object>> iterator = w2.getAllFields().entrySet().iterator();
            while (iterator.hasNext()) {
                Iterator iterator2 = iterator.next();
                h.f f2 = iterator2.getKey();
                iterator2 = iterator2.getValue();
                if (f2.j()) {
                    iterator2 = ((List)((Object)iterator2)).iterator();
                    while (iterator2.hasNext()) {
                        this.a(f2, iterator2.next(), c2);
                    }
                    continue;
                }
                this.a(f2, iterator2, c2);
            }
            this.a(w2.getUnknownFields(), c2);
        }
    }

    static final class c {
        private final Appendable a;
        private final StringBuilder b = new StringBuilder();
        private boolean c = true;

        private c(Appendable appendable) {
            this.a = appendable;
        }

        /* synthetic */ c(Appendable appendable, byte by2) {
            this(appendable);
        }

        private void a(CharSequence charSequence, int n2) {
            if (n2 == 0) {
                return;
            }
            if (this.c) {
                this.c = false;
                this.a.append(this.b);
            }
            this.a.append(charSequence);
        }

        public final void a() {
            this.b.append("  ");
        }

        public final void a(CharSequence charSequence) {
            int n2 = 0;
            int n3 = charSequence.length();
            for (int i2 = 0; i2 < n3; ++i2) {
                int n4 = n2;
                if (charSequence.charAt(i2) == '\n') {
                    this.a(charSequence.subSequence(n2, n3), i2 - n2 + 1);
                    n4 = i2 + 1;
                    this.c = true;
                }
                n2 = n4;
            }
            this.a(charSequence.subSequence(n2, n3), n3 - n2);
        }

        public final void b() {
            int n2 = this.b.length();
            if (n2 == 0) {
                throw new IllegalArgumentException(" Outdent() without matching Indent().");
            }
            this.b.delete(n2 - 2, n2);
        }
    }

}

