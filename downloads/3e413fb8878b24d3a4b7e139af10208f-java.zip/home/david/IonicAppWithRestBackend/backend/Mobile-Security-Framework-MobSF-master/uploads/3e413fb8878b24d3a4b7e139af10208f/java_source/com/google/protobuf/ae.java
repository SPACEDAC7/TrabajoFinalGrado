/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import java.util.Iterator;
import java.util.List;

public final class ae
extends RuntimeException {
    private final List<String> a;

    public ae() {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
        this.a = null;
    }

    public ae(List<String> list) {
        super(ae.a(list));
        this.a = list;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String a(List<String> iterator) {
        StringBuilder stringBuilder = new StringBuilder("Message missing required fields: ");
        iterator = iterator.iterator();
        boolean bl2 = true;
        while (iterator.hasNext()) {
            String string = (String)iterator.next();
            if (bl2) {
                bl2 = false;
            } else {
                stringBuilder.append(", ");
            }
            stringBuilder.append(string);
        }
        return stringBuilder.toString();
    }
}

