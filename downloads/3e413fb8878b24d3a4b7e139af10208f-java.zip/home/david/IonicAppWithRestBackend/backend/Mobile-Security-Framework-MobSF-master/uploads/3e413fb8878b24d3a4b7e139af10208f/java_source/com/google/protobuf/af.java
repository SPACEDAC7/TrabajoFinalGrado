/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.ad;
import com.google.protobuf.ah;
import com.google.protobuf.d;
import com.google.protobuf.e;
import com.google.protobuf.f;
import com.google.protobuf.j;
import com.google.protobuf.k;
import com.google.protobuf.o;
import com.google.protobuf.u;
import com.google.protobuf.v;
import com.google.protobuf.x;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public final class af
implements u {
    private static final af b = new af(Collections.<Integer, b>emptyMap());
    private static final c c = new c();
    public Map<Integer, b> a;

    private af() {
    }

    private af(Map<Integer, b> map) {
        this.a = map;
    }

    /* synthetic */ af(Map map, byte by2) {
        this(map);
    }

    public static a a() {
        return a.b();
    }

    public static a a(af af2) {
        return a.b().a(af2);
    }

    public static af b() {
        return b;
    }

    public final void a(f f2) {
        Iterator<Map.Entry<Integer, b>> iterator = this.a.entrySet().iterator();
        while (iterator.hasNext()) {
            Object object = iterator.next();
            b b2 = object.getValue();
            int n2 = object.getKey();
            object = b2.d.iterator();
            while (object.hasNext()) {
                f2.b(n2, (d)object.next());
            }
        }
    }

    public final int c() {
        Iterator<Map.Entry<Integer, b>> iterator = this.a.entrySet().iterator();
        int n2 = 0;
        while (iterator.hasNext()) {
            Object object = iterator.next();
            Object object2 = object.getValue();
            int n3 = object.getKey();
            object = object2.d.iterator();
            int n4 = 0;
            while (object.hasNext()) {
                object2 = (d)object.next();
                int n5 = f.d(1);
                int n6 = f.e(2, n3);
                n4 = f.c(3, (d)object2) + ((n5 << 1) + n6) + n4;
            }
            n2 += n4;
        }
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean equals(Object object) {
        if (this == object || object instanceof af && this.a.equals(((af)object).a)) {
            return true;
        }
        return false;
    }

    @Override
    public final int getSerializedSize() {
        Iterator<Map.Entry<Integer, b>> iterator = this.a.entrySet().iterator();
        int n2 = 0;
        while (iterator.hasNext()) {
            Map.Entry<Integer, b> entry = iterator.next();
            b b2 = entry.getValue();
            int n3 = entry.getKey();
            Iterator<Long> iterator2 = b2.a.iterator();
            int n4 = 0;
            while (iterator2.hasNext()) {
                n4 = f.c(n3, iterator2.next()) + n4;
            }
            Iterator<Integer> iterator3 = b2.b.iterator();
            while (iterator3.hasNext()) {
                iterator3.next().intValue();
                n4 += f.d(n3) + 4;
            }
            Iterator<Long> iterator4 = b2.c.iterator();
            while (iterator4.hasNext()) {
                iterator4.next().longValue();
                n4 += f.d(n3) + 8;
            }
            Iterator<d> iterator5 = b2.d.iterator();
            while (iterator5.hasNext()) {
                n4 += f.c(n3, iterator5.next());
            }
            for (af af2 : b2.e) {
                int n5 = f.d(n3);
                n4 += af2.getSerializedSize() + (n5 << 1);
            }
            n2 += n4;
        }
        return n2;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    @Override
    public final boolean isInitialized() {
        return true;
    }

    @Override
    public final /* synthetic */ u.a toBuilder() {
        return a.b().a(this);
    }

    @Override
    public final byte[] toByteArray() {
        try {
            byte[] arrby = new byte[this.getSerializedSize()];
            f f2 = f.a(arrby);
            this.writeTo(f2);
            f2.c();
            return arrby;
        }
        catch (IOException var1_2) {
            throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", var1_2);
        }
    }

    @Override
    public final d toByteString() {
        try {
            Object object = d.b(this.getSerializedSize());
            this.writeTo(object.a);
            object = object.a();
            return object;
        }
        catch (IOException var1_2) {
            throw new RuntimeException("Serializing to a ByteString threw an IOException (should never happen).", var1_2);
        }
    }

    public final String toString() {
        return ad.a(this);
    }

    @Override
    public final void writeTo(f f2) {
        Iterator<Map.Entry<Integer, b>> iterator = this.a.entrySet().iterator();
        while (iterator.hasNext()) {
            Iterator iterator2 = iterator.next();
            Object object = iterator2.getValue();
            int n2 = iterator2.getKey();
            iterator2 = object.a.iterator();
            while (iterator2.hasNext()) {
                f2.a(n2, (Long)iterator2.next());
            }
            iterator2 = object.b.iterator();
            while (iterator2.hasNext()) {
                int n3 = iterator2.next();
                f2.g(n2, 5);
                f2.g(n3);
            }
            iterator2 = object.c.iterator();
            while (iterator2.hasNext()) {
                f2.b(n2, (Long)iterator2.next());
            }
            iterator2 = object.d.iterator();
            while (iterator2.hasNext()) {
                f2.a(n2, (d)iterator2.next());
            }
            object = object.e.iterator();
            while (object.hasNext()) {
                f2.a(n2, (af)object.next());
            }
        }
    }

    public static final class a
    implements u.a {
        private Map<Integer, b> a;
        private int b;
        private b.a c;

        private a() {
        }

        private a a(byte[] object) {
            try {
                object = e.a((byte[])object, 0, object.length);
                this.a((e)object);
                object.a(0);
                return this;
            }
            catch (o var1_2) {
                throw var1_2;
            }
            catch (IOException var1_3) {
                throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).", var1_3);
            }
        }

        private b.a a(int n2) {
            if (this.c != null) {
                if (n2 == this.b) {
                    return this.c;
                }
                this.b(this.b, this.c.a());
            }
            if (n2 == 0) {
                return null;
            }
            b b2 = this.a.get(n2);
            this.b = n2;
            this.c = b.a();
            if (b2 != null) {
                this.c.a(b2);
            }
            return this.c;
        }

        static /* synthetic */ a b() {
            a a2 = new a();
            a2.a = Collections.emptyMap();
            a2.b = 0;
            a2.c = null;
            return a2;
        }

        private a b(int n2, b b2) {
            if (n2 == 0) {
                throw new IllegalArgumentException("Zero is not a valid field number.");
            }
            if (this.c != null && this.b == n2) {
                this.c = null;
                this.b = 0;
            }
            if (this.a.isEmpty()) {
                this.a = new TreeMap<Integer, b>();
            }
            this.a.put(n2, b2);
            return this;
        }

        public final a a(int n2, int n3) {
            if (n2 == 0) {
                throw new IllegalArgumentException("Zero is not a valid field number.");
            }
            this.a(n2).a(n3);
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public final a a(int n2, b b2) {
            if (n2 == 0) {
                throw new IllegalArgumentException("Zero is not a valid field number.");
            }
            if (n2 == 0) {
                throw new IllegalArgumentException("Zero is not a valid field number.");
            }
            boolean bl2 = n2 == this.b || this.a.containsKey(n2);
            if (bl2) {
                this.a(n2).a(b2);
                return this;
            }
            this.b(n2, b2);
            return this;
        }

        public final a a(af object) {
            if (object != af.b()) {
                for (Map.Entry entry : ((af)((Object)object)).a.entrySet()) {
                    this.a((int)((Integer)entry.getKey()), (b)entry.getValue());
                }
            }
            return this;
        }

        public final a a(e e2) {
            int n2;
            while ((n2 = e2.a()) != 0 && this.a(n2, e2)) {
            }
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public final af a() {
            this.a(0);
            af af2 = this.a.isEmpty() ? af.b() : new af(Collections.unmodifiableMap(this.a), 0);
            this.a = null;
            return af2;
        }

        public final boolean a(int n2, e object) {
            int n3 = ah.b(n2);
            switch (ah.a(n2)) {
                default: {
                    throw o.f();
                }
                case 0: {
                    this.a(n3).a(object.l());
                    return true;
                }
                case 1: {
                    b.a a2 = this.a(n3);
                    long l2 = object.n();
                    if (a2.a.c == null) {
                        a2.a.c = new ArrayList();
                    }
                    a2.a.c.add(l2);
                    return true;
                }
                case 2: {
                    this.a(n3).a(object.f());
                    return true;
                }
                case 3: {
                    v v2 = af.a();
                    object.a(n3, (u.a)v2, j.a());
                    object = this.a(n3);
                    v2 = v2.a();
                    if (object.a.e == null) {
                        object.a.e = new ArrayList();
                    }
                    object.a.e.add(v2);
                    return true;
                }
                case 4: {
                    return false;
                }
                case 5: 
            }
            b.a a3 = this.a(n3);
            n2 = object.m();
            if (a3.a.b == null) {
                a3.a.b = new ArrayList();
            }
            a3.a.b.add(n2);
            return true;
        }

        @Override
        public final /* synthetic */ u build() {
            return this.a();
        }

        @Override
        public final /* synthetic */ u buildPartial() {
            return this.a();
        }

        public final /* synthetic */ Object clone() {
            this.a(0);
            return af.a().a(new af(this.a, 0));
        }

        @Override
        public final boolean isInitialized() {
            return true;
        }

        @Override
        public final /* synthetic */ u.a mergeFrom(e e2, k k2) {
            return this.a(e2);
        }

        @Override
        public final /* synthetic */ u.a mergeFrom(byte[] arrby) {
            return this.a(arrby);
        }
    }

    public static final class b {
        private static final b f = b.a().a();
        List<Long> a;
        List<Integer> b;
        List<Long> c;
        List<d> d;
        List<af> e;

        private b() {
        }

        private /* synthetic */ b(byte by2) {
            this();
        }

        public static a a() {
            a a2 = new a();
            a2.a = new b(0);
            return a2;
        }

        private Object[] b() {
            return new Object[]{this.a, this.b, this.c, this.d, this.e};
        }

        public final boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (!(object instanceof b)) {
                return false;
            }
            return Arrays.equals(this.b(), ((b)object).b());
        }

        public final int hashCode() {
            return Arrays.hashCode(this.b());
        }

        public static final class a {
            b a;

            a() {
            }

            public final a a(long l2) {
                if (this.a.a == null) {
                    this.a.a = new ArrayList();
                }
                this.a.a.add(l2);
                return this;
            }

            public final a a(b b2) {
                if (!b2.a.isEmpty()) {
                    if (this.a.a == null) {
                        this.a.a = new ArrayList();
                    }
                    this.a.a.addAll(b2.a);
                }
                if (!b2.b.isEmpty()) {
                    if (this.a.b == null) {
                        this.a.b = new ArrayList();
                    }
                    this.a.b.addAll(b2.b);
                }
                if (!b2.c.isEmpty()) {
                    if (this.a.c == null) {
                        this.a.c = new ArrayList();
                    }
                    this.a.c.addAll(b2.c);
                }
                if (!b2.d.isEmpty()) {
                    if (this.a.d == null) {
                        this.a.d = new ArrayList();
                    }
                    this.a.d.addAll(b2.d);
                }
                if (!b2.e.isEmpty()) {
                    if (this.a.e == null) {
                        this.a.e = new ArrayList();
                    }
                    this.a.e.addAll(b2.e);
                }
                return this;
            }

            public final a a(d d2) {
                if (this.a.d == null) {
                    this.a.d = new ArrayList();
                }
                this.a.d.add(d2);
                return this;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final b a() {
                if (this.a.a == null) {
                    this.a.a = Collections.emptyList();
                } else {
                    this.a.a = Collections.unmodifiableList(this.a.a);
                }
                if (this.a.b == null) {
                    this.a.b = Collections.emptyList();
                } else {
                    this.a.b = Collections.unmodifiableList(this.a.b);
                }
                if (this.a.c == null) {
                    this.a.c = Collections.emptyList();
                } else {
                    this.a.c = Collections.unmodifiableList(this.a.c);
                }
                if (this.a.d == null) {
                    this.a.d = Collections.emptyList();
                } else {
                    this.a.d = Collections.unmodifiableList(this.a.d);
                }
                if (this.a.e == null) {
                    this.a.e = Collections.emptyList();
                } else {
                    this.a.e = Collections.unmodifiableList(this.a.e);
                }
                b b2 = this.a;
                this.a = null;
                return b2;
            }
        }

    }

    public static final class c
    extends com.google.protobuf.c<af> {
        private static af b(e e2) {
            a a2 = af.a();
            try {
                a2.a(e2);
                return a2.a();
            }
            catch (o var0_1) {
                var0_1.a = a2.a();
                throw var0_1;
            }
            catch (IOException var0_2) {
                o o2 = new o(var0_2.getMessage());
                o2.a = a2.a();
                throw o2;
            }
        }
    }

}

