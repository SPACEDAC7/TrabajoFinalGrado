/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.d;
import com.google.protobuf.r;
import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public final class ag
extends AbstractList<String>
implements r,
RandomAccess {
    private final r a;

    public ag(r r2) {
        this.a = r2;
    }

    @Override
    public final d a(int n2) {
        return this.a.a(n2);
    }

    @Override
    public final List<?> a() {
        return this.a.a();
    }

    @Override
    public final void a(d d2) {
        throw new UnsupportedOperationException();
    }

    @Override
    public final Iterator<String> iterator() {
        return new Iterator<String>(){
            Iterator<String> a;

            @Override
            public final boolean hasNext() {
                return this.a.hasNext();
            }

            @Override
            public final void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    @Override
    public final ListIterator<String> listIterator(final int n2) {
        return new ListIterator<String>(){
            ListIterator<String> a;

            @Override
            public final /* synthetic */ void add(Object object) {
                throw new UnsupportedOperationException();
            }

            @Override
            public final boolean hasNext() {
                return this.a.hasNext();
            }

            @Override
            public final boolean hasPrevious() {
                return this.a.hasPrevious();
            }

            @Override
            public final int nextIndex() {
                return this.a.nextIndex();
            }

            @Override
            public final int previousIndex() {
                return this.a.previousIndex();
            }

            @Override
            public final void remove() {
                throw new UnsupportedOperationException();
            }

            @Override
            public final /* synthetic */ void set(Object object) {
                throw new UnsupportedOperationException();
            }
        };
    }

    @Override
    public final int size() {
        return this.a.size();
    }

}

