/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.d;

public final class ah {
    static final int a = 11;
    static final int b = 12;
    static final int c = 16;
    static final int d = 26;

    static int a(int n2) {
        return n2 & 7;
    }

    static int a(int n2, int n3) {
        return n2 << 3 | n3;
    }

    public static int b(int n2) {
        return n2 >>> 3;
    }

    public static enum a {
        a(b.d, 1),
        b(b.c, 5),
        c(b.b, 0),
        d(b.b, 0),
        e(b.a, 0),
        f(b.b, 1),
        g(b.a, 5),
        h(b.e, 0),
        i{

            @Override
            public final boolean a() {
                return false;
            }
        }
        ,
        j{

            @Override
            public final boolean a() {
                return false;
            }
        }
        ,
        k{

            @Override
            public final boolean a() {
                return false;
            }
        }
        ,
        l{

            @Override
            public final boolean a() {
                return false;
            }
        }
        ,
        m(b.a, 0),
        n(b.h, 0),
        o(b.a, 5),
        p(b.b, 1),
        q(b.a, 0),
        r(b.b, 0);
        
        final b s;
        final int t;

        private a(b b2, int n3) {
            this.s = b2;
            this.t = n3;
        }

        /* synthetic */ a(String string, int n2, b b2, int n3, byte by2) {
            this(b2, n3);
        }

        public boolean a() {
            return true;
        }

    }

    public static enum b {
        a(0),
        b(0),
        c(Float.valueOf(0.0f)),
        d(0.0),
        e(false),
        f(""),
        g(d.a),
        h(null),
        i(null);
        
        private final Object j;

        private b(Object object) {
            this.j = object;
        }
    }

}

