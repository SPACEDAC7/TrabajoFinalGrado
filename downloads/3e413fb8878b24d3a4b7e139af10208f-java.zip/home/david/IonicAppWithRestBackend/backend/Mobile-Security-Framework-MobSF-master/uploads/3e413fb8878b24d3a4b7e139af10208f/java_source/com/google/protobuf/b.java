/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.ae;
import com.google.protobuf.d;
import com.google.protobuf.e;
import com.google.protobuf.f;
import com.google.protobuf.k;
import com.google.protobuf.o;
import com.google.protobuf.r;
import com.google.protobuf.u;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public abstract class b
implements u {
    ae newUninitializedMessageException() {
        return new ae();
    }

    @Override
    public byte[] toByteArray() {
        try {
            byte[] arrby = new byte[this.getSerializedSize()];
            f f2 = f.a(arrby);
            this.writeTo(f2);
            f2.c();
            return arrby;
        }
        catch (IOException var1_2) {
            throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", var1_2);
        }
    }

    @Override
    public d toByteString() {
        try {
            Object object = d.b(this.getSerializedSize());
            this.writeTo(object.a);
            object = object.a();
            return object;
        }
        catch (IOException var1_2) {
            throw new RuntimeException("Serializing to a ByteString threw an IOException (should never happen).", var1_2);
        }
    }

    public void writeDelimitedTo(OutputStream object) {
        int n2 = this.getSerializedSize();
        object = f.a((OutputStream)object, f.a(f.f(n2) + n2));
        object.e(n2);
        this.writeTo((f)object);
        object.b();
    }

    public void writeTo(OutputStream object) {
        object = f.a((OutputStream)object, f.a(this.getSerializedSize()));
        this.writeTo((f)object);
        object.b();
    }

    public static abstract class com.google.protobuf.b$a<BuilderType extends com.google.protobuf.b$a>
    implements u.a {
        private static void a(Iterable<?> object) {
            object = object.iterator();
            while (object.hasNext()) {
                if (object.next() != null) continue;
                throw new NullPointerException();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public static <T> void addAll(Iterable<T> iterator, Collection<? super T> collection) {
            if (iterator instanceof r) {
                com.google.protobuf.b$a.a(((r)((Object)iterator)).a());
            } else {
                com.google.protobuf.b$a.a(iterator);
            }
            if (iterator instanceof Collection) {
                collection.addAll((Collection)((Object)iterator));
                return;
            } else {
                iterator = iterator.iterator();
                while (iterator.hasNext()) {
                    collection.add(iterator.next());
                }
            }
        }

        public static ae newUninitializedMessageException(u u2) {
            return new ae();
        }

        public abstract BuilderType clone();

        public boolean mergeDelimitedFrom(InputStream inputStream) {
            return this.mergeDelimitedFrom(inputStream, k.c());
        }

        public boolean mergeDelimitedFrom(InputStream inputStream, k k2) {
            int n2 = inputStream.read();
            if (n2 == -1) {
                return false;
            }
            this.mergeFrom(new a(inputStream, e.a(n2, inputStream)), k2);
            return true;
        }

        public BuilderType mergeFrom(d object) {
            try {
                object = object.g();
                this.mergeFrom((e)object);
                object.a(0);
            }
            catch (o var1_2) {
                throw var1_2;
            }
            catch (IOException var1_3) {
                throw new RuntimeException("Reading from a ByteString threw an IOException (should never happen).", var1_3);
            }
            return (BuilderType)this;
        }

        public BuilderType mergeFrom(d object, k k2) {
            try {
                object = object.g();
                this.mergeFrom((e)object, k2);
                object.a(0);
            }
            catch (o var1_2) {
                throw var1_2;
            }
            catch (IOException var1_3) {
                throw new RuntimeException("Reading from a ByteString threw an IOException (should never happen).", var1_3);
            }
            return (BuilderType)this;
        }

        public BuilderType mergeFrom(e e2) {
            return (BuilderType)this.mergeFrom(e2, k.c());
        }

        public abstract BuilderType mergeFrom(e var1, k var2);

        public BuilderType mergeFrom(InputStream object) {
            object = e.a((InputStream)object);
            this.mergeFrom((e)object);
            object.a(0);
            return (BuilderType)this;
        }

        public BuilderType mergeFrom(InputStream object, k k2) {
            object = e.a((InputStream)object);
            this.mergeFrom((e)object, k2);
            object.a(0);
            return (BuilderType)this;
        }

        public BuilderType mergeFrom(byte[] arrby) {
            return (BuilderType)this.mergeFrom(arrby, 0, arrby.length);
        }

        public BuilderType mergeFrom(byte[] object, int n2, int n3) {
            try {
                object = e.a((byte[])object, n2, n3);
                this.mergeFrom((e)object);
                object.a(0);
            }
            catch (o var1_2) {
                throw var1_2;
            }
            catch (IOException var1_3) {
                throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).", var1_3);
            }
            return (BuilderType)this;
        }

        public BuilderType mergeFrom(byte[] object, int n2, int n3, k k2) {
            try {
                object = e.a((byte[])object, n2, n3);
                this.mergeFrom((e)object, k2);
                object.a(0);
            }
            catch (o var1_2) {
                throw var1_2;
            }
            catch (IOException var1_3) {
                throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).", var1_3);
            }
            return (BuilderType)this;
        }

        public BuilderType mergeFrom(byte[] arrby, k k2) {
            return (BuilderType)this.mergeFrom(arrby, 0, arrby.length, k2);
        }

        static final class a
        extends FilterInputStream {
            private int a;

            a(InputStream inputStream, int n2) {
                super(inputStream);
                this.a = n2;
            }

            @Override
            public final int available() {
                return Math.min(super.available(), this.a);
            }

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            @Override
            public final int read() {
                int n2;
                if (this.a <= 0) {
                    return -1;
                }
                int n3 = n2 = super.read();
                if (n2 < 0) return n3;
                --this.a;
                return n2;
            }

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            @Override
            public final int read(byte[] arrby, int n2, int n3) {
                if (this.a <= 0) {
                    return -1;
                }
                n2 = n3 = super.read(arrby, n2, Math.min(n3, this.a));
                if (n3 < 0) return n2;
                this.a -= n3;
                return n3;
            }

            @Override
            public final long skip(long l2) {
                if ((l2 = super.skip(Math.min(l2, (long)this.a))) >= 0) {
                    this.a = (int)((long)this.a - l2);
                }
                return l2;
            }
        }

    }

}

