/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.ae;
import com.google.protobuf.b;
import com.google.protobuf.d;
import com.google.protobuf.e;
import com.google.protobuf.k;
import com.google.protobuf.o;
import com.google.protobuf.u;
import com.google.protobuf.x;
import java.io.IOException;
import java.io.InputStream;

public abstract class c<MessageType extends u>
implements x<MessageType> {
    private static final k a = k.c();

    /*
     * Enabled aggressive block sorting
     */
    private static MessageType a(MessageType MessageType) {
        if (MessageType != null && !MessageType.isInitialized()) {
            void var1_2;
            if (MessageType instanceof b) {
                ae ae2 = ((b)MessageType).newUninitializedMessageException();
            } else {
                ae ae3 = new ae();
            }
            o o2 = new o(var1_2.getMessage());
            o2.a = MessageType;
            throw o2;
        }
        return MessageType;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private MessageType a(byte[] object, int n2, k object2) {
        try {
            object = e.a((byte[])object, 0, n2);
            object2 = (u)this.b((e)object, (k)object2);
            {
                catch (o o2) {
                    throw o2;
                }
            }
            try {
                object.a(0);
            }
            catch (o o2) {
                o2.a = object2;
                throw o2;
            }
            return (MessageType)object2;
        }
        catch (IOException var1_4) {
            throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).", var1_4);
        }
    }

    private MessageType b(byte[] arrby, k k2) {
        return c.a(this.a(arrby, arrby.length, k2));
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private MessageType c(d object, k object2) {
        try {
            object = object.g();
            object2 = (u)this.b((e)object, (k)object2);
            {
                catch (o o2) {
                    throw o2;
                }
            }
            try {
                object.a(0);
            }
            catch (o o2) {
                o2.a = object2;
                throw o2;
            }
            return (MessageType)object2;
        }
        catch (IOException var1_4) {
            throw new RuntimeException("Reading from a ByteString threw an IOException (should never happen).", var1_4);
        }
    }

    private MessageType c(e e2, k k2) {
        return (MessageType)c.a((u)this.b(e2, k2));
    }

    private MessageType c(InputStream object, k object2) {
        object = e.a((InputStream)object);
        object2 = (u)this.b((e)object, (k)object2);
        try {
            object.a(0);
        }
        catch (o var1_2) {
            var1_2.a = object2;
            throw var1_2;
        }
        return (MessageType)object2;
    }

    private MessageType d(d d2, k k2) {
        return c.a(this.c(d2, k2));
    }

    private MessageType d(InputStream inputStream, k k2) {
        return c.a(this.c(inputStream, k2));
    }

    private MessageType e(InputStream inputStream, k k2) {
        int n2;
        block3 : {
            try {
                n2 = inputStream.read();
                if (n2 != -1) break block3;
            }
            catch (IOException var1_2) {
                throw new o(var1_2.getMessage());
            }
            return null;
        }
        n2 = e.a(n2, inputStream);
        return this.c(new b.a.a(inputStream, n2), k2);
    }

    private MessageType f(InputStream inputStream, k k2) {
        return c.a(this.e(inputStream, k2));
    }

    @Override
    public final /* synthetic */ Object a(d d2) {
        return this.d(d2, a);
    }

    @Override
    public final /* synthetic */ Object a(d d2, k k2) {
        return this.c(d2, k2);
    }

    @Override
    public final /* synthetic */ Object a(e e2) {
        return this.c(e2, a);
    }

    @Override
    public final /* synthetic */ Object a(e e2, k k2) {
        return this.c(e2, k2);
    }

    @Override
    public final /* synthetic */ Object a(InputStream inputStream) {
        return this.f(inputStream, a);
    }

    @Override
    public final /* synthetic */ Object a(InputStream inputStream, k k2) {
        return this.f(inputStream, k2);
    }

    @Override
    public final /* synthetic */ Object a(byte[] arrby) {
        return this.b(arrby, a);
    }

    @Override
    public final /* synthetic */ Object a(byte[] arrby, k k2) {
        return this.b(arrby, k2);
    }

    @Override
    public final /* synthetic */ Object b(d d2, k k2) {
        return this.d(d2, k2);
    }

    @Override
    public final /* synthetic */ Object b(InputStream inputStream) {
        return this.d(inputStream, a);
    }

    @Override
    public final /* synthetic */ Object b(InputStream inputStream, k k2) {
        return this.d(inputStream, k2);
    }
}

