/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.e;
import com.google.protobuf.f;
import com.google.protobuf.s;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;

public abstract class d
implements Iterable<Byte> {
    public static final d a;
    static final /* synthetic */ boolean b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl2 = !d.class.desiredAssertionStatus();
        b = bl2;
        a = new s(new byte[0]);
    }

    d() {
    }

    public static d a(String object) {
        try {
            object = new s(object.getBytes("UTF-8"));
            return object;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw new RuntimeException("UTF-8 not supported?", var0_1);
        }
    }

    public static d a(byte[] arrby) {
        return d.a(arrby, 0, arrby.length);
    }

    public static d a(byte[] arrby, int n2, int n3) {
        byte[] arrby2 = new byte[n3];
        System.arraycopy(arrby, n2, arrby2, 0, n3);
        return new s(arrby2);
    }

    static b b(int n2) {
        return new b(n2, 0);
    }

    public abstract byte a(int var1);

    protected abstract int a(int var1, int var2, int var3);

    public abstract a a();

    public final void a(byte[] arrby, int n2, int n3, int n4) {
        if (n2 < 0) {
            throw new IndexOutOfBoundsException("Source offset < 0: " + n2);
        }
        if (n3 < 0) {
            throw new IndexOutOfBoundsException("Target offset < 0: " + n3);
        }
        if (n4 < 0) {
            throw new IndexOutOfBoundsException("Length < 0: " + n4);
        }
        if (n2 + n4 > this.b()) {
            throw new IndexOutOfBoundsException("Source end offset < 0: " + (n2 + n4));
        }
        if (n3 + n4 > arrby.length) {
            throw new IndexOutOfBoundsException("Target end offset < 0: " + (n3 + n4));
        }
        if (n4 > 0) {
            this.b(arrby, n2, n3, n4);
        }
    }

    public abstract int b();

    protected abstract int b(int var1, int var2, int var3);

    public abstract String b(String var1);

    protected abstract void b(byte[] var1, int var2, int var3, int var4);

    public final byte[] c() {
        int n2 = this.b();
        byte[] arrby = new byte[n2];
        this.b(arrby, 0, 0, n2);
        return arrby;
    }

    public final String d() {
        try {
            String string = this.b("UTF-8");
            return string;
        }
        catch (UnsupportedEncodingException var1_2) {
            throw new RuntimeException("UTF-8 not supported?", var1_2);
        }
    }

    public abstract boolean e();

    public abstract boolean equals(Object var1);

    public abstract InputStream f();

    public abstract e g();

    protected abstract int h();

    @Override
    public /* synthetic */ Iterator iterator() {
        return this.a();
    }

    public String toString() {
        return String.format("<ByteString@%s size=%d>", Integer.toHexString(System.identityHashCode(this)), this.b());
    }

    public static interface a
    extends Iterator<Byte> {
        public byte a();
    }

    static final class b {
        final f a;
        private final byte[] b;

        private b(int n2) {
            this.b = new byte[n2];
            this.a = f.a(this.b);
        }

        /* synthetic */ b(int n2, byte by2) {
            this(n2);
        }

        public final d a() {
            this.a.c();
            return new s(this.b);
        }
    }

}

