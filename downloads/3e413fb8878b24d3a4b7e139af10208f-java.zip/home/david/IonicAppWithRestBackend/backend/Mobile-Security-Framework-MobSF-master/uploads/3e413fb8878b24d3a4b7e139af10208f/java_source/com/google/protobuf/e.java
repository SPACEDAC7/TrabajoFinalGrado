/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.ah;
import com.google.protobuf.d;
import com.google.protobuf.k;
import com.google.protobuf.o;
import com.google.protobuf.u;
import com.google.protobuf.x;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

public final class e {
    final byte[] a;
    int b;
    int c;
    private int d;
    private final InputStream e;
    private int f;
    private int g;
    private int h = Integer.MAX_VALUE;
    private int i;
    private int j = 64;
    private int k = 67108864;

    private e(InputStream inputStream) {
        this.a = new byte[4096];
        this.b = 0;
        this.c = 0;
        this.g = 0;
        this.e = inputStream;
    }

    private e(byte[] arrby, int n2, int n3) {
        this.a = arrby;
        this.b = n2 + n3;
        this.c = n2;
        this.g = - n2;
        this.e = null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static int a(int var0, InputStream var1_1) {
        if ((var0 & 128) == 0) {
            return var0;
        }
        var2_3 = var0 & 127;
        var0 = 7;
        do {
            var3_2 = var0;
            if (var0 >= 32) ** GOTO lbl16
            var4_4 = var1_1.read();
            if (var4_4 == -1) {
                throw o.a();
            }
            var3_2 = var2_3 |= (var4_4 & 127) << var0;
            if ((var4_4 & 128) == 0) return var3_2;
            var0 += 7;
        } while (true);
lbl-1000: // 1 sources:
        {
            var3_2 += 7;
lbl16: // 2 sources:
            if (var3_2 >= 64) throw o.c();
            var0 = var1_1.read();
            if (var0 != -1) continue;
            throw o.a();
            ** while ((var0 & 128) != 0)
        }
lbl21: // 1 sources:
        return var2_3;
    }

    public static e a(InputStream inputStream) {
        return new e(inputStream);
    }

    public static e a(byte[] object, int n2, int n3) {
        object = new e((byte[])object, n2, n3);
        try {
            object.c(n3);
            return object;
        }
        catch (o var0_1) {
            throw new IllegalArgumentException(var0_1);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean a(boolean bl2) {
        if (this.c < this.b) {
            throw new IllegalStateException("refillBuffer() called when buffer wasn't empty.");
        }
        if (this.g + this.b == this.h) {
            if (bl2) {
                throw o.a();
            }
            return false;
        }
        this.g += this.b;
        this.c = 0;
        int n2 = this.e == null ? -1 : this.e.read(this.a);
        this.b = n2;
        if (this.b == 0 || this.b < -1) {
            throw new IllegalStateException("InputStream#read(byte[]) returned invalid result: " + this.b + "\nThe InputStream implementation is buggy.");
        }
        if (this.b == -1) {
            this.b = 0;
            if (bl2) {
                throw o.a();
            }
            return false;
        }
        this.p();
        n2 = this.g + this.b + this.d;
        if (n2 <= this.k && n2 >= 0) {
            return true;
        }
        throw o.h();
    }

    private void f(int n2) {
        if (n2 < 0) {
            throw o.b();
        }
        if (this.g + this.c + n2 > this.h) {
            this.f(this.h - this.g - this.c);
            throw o.a();
        }
        if (n2 <= this.b - this.c) {
            this.c += n2;
            return;
        }
        int n3 = this.b - this.c;
        this.c = this.b;
        this.a(true);
        while (n2 - n3 > this.b) {
            n3 += this.b;
            this.c = this.b;
            this.a(true);
        }
        this.c = n2 - n3;
    }

    private void p() {
        this.b += this.d;
        int n2 = this.g + this.b;
        if (n2 > this.h) {
            this.d = n2 - this.h;
            this.b -= this.d;
            return;
        }
        this.d = 0;
    }

    private byte q() {
        if (this.c == this.b) {
            this.a(true);
        }
        byte[] arrby = this.a;
        int n2 = this.c;
        this.c = n2 + 1;
        return arrby[n2];
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int a() {
        boolean bl2 = this.c == this.b && !this.a(false);
        if (bl2) {
            this.f = 0;
            return 0;
        }
        this.f = this.k();
        if (ah.b(this.f) == 0) {
            throw o.d();
        }
        return this.f;
    }

    public final <T extends u> T a(x<T> object, k k2) {
        int n2 = this.k();
        if (this.i >= this.j) {
            throw o.g();
        }
        n2 = this.c(n2);
        ++this.i;
        object = (u)object.b(this, k2);
        this.a(0);
        --this.i;
        this.d(n2);
        return (T)object;
    }

    public final void a(int n2) {
        if (this.f != n2) {
            throw o.e();
        }
    }

    public final void a(int n2, u.a a2, k k2) {
        if (this.i >= this.j) {
            throw o.g();
        }
        ++this.i;
        a2.mergeFrom(this, k2);
        this.a(ah.a(n2, 4));
        --this.i;
    }

    public final void a(u.a a2, k k2) {
        int n2 = this.k();
        if (this.i >= this.j) {
            throw o.g();
        }
        n2 = this.c(n2);
        ++this.i;
        a2.mergeFrom(this, k2);
        this.a(0);
        --this.i;
        this.d(n2);
    }

    public final long b() {
        return this.l();
    }

    public final boolean b(int n2) {
        switch (ah.a(n2)) {
            default: {
                throw o.f();
            }
            case 0: {
                this.k();
                return true;
            }
            case 1: {
                this.n();
                return true;
            }
            case 2: {
                this.f(this.k());
                return true;
            }
            case 3: {
                int n3;
                while ((n3 = this.a()) != 0 && this.b(n3)) {
                }
                this.a(ah.a(ah.b(n2), 4));
                return true;
            }
            case 4: {
                return false;
            }
            case 5: 
        }
        this.m();
        return true;
    }

    public final int c(int n2) {
        if (n2 < 0) {
            throw o.b();
        }
        int n3 = this.h;
        if ((n2 = this.g + this.c + n2) > n3) {
            throw o.a();
        }
        this.h = n2;
        this.p();
        return n3;
    }

    public final long c() {
        return this.l();
    }

    public final int d() {
        return this.k();
    }

    public final void d(int n2) {
        this.h = n2;
        this.p();
    }

    public final boolean e() {
        if (this.k() != 0) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final byte[] e(int n2) {
        if (n2 < 0) {
            throw o.b();
        }
        if (this.g + this.c + n2 > this.h) {
            this.f(this.h - this.g - this.c);
            throw o.a();
        }
        if (n2 <= this.b - this.c) {
            byte[] arrby = new byte[n2];
            System.arraycopy(this.a, this.c, arrby, 0, n2);
            this.c += n2;
            return arrby;
        }
        if (n2 < 4096) {
            byte[] arrby = new byte[n2];
            int n3 = this.b - this.c;
            System.arraycopy(this.a, this.c, arrby, 0, n3);
            this.c = this.b;
            this.a(true);
            do {
                if (n2 - n3 <= this.b) {
                    System.arraycopy(this.a, 0, arrby, n3, n2 - n3);
                    this.c = n2 - n3;
                    return arrby;
                }
                System.arraycopy(this.a, 0, arrby, n3, this.b);
                n3 += this.b;
                this.c = this.b;
                this.a(true);
            } while (true);
        }
        int n4 = this.c;
        int n5 = this.b;
        this.g += this.b;
        this.c = 0;
        this.b = 0;
        Object object = new ArrayList<byte[]>();
        int n6 = n2 - (n5 - n4);
        do {
            int n7;
            byte[] arrby;
            int n8;
            if (n6 > 0) {
                arrby = new byte[Math.min(n6, 4096)];
            } else {
                arrby = new byte[n2];
                n2 = n5 - n4;
                System.arraycopy(this.a, n4, arrby, 0, n2);
                object = object.iterator();
                do {
                    if (!object.hasNext()) {
                        return arrby;
                    }
                    byte[] arrby2 = (byte[])object.next();
                    System.arraycopy(arrby2, 0, arrby, n2, arrby2.length);
                    n2 = arrby2.length + n2;
                } while (true);
            }
            for (n8 = 0; n8 < arrby.length; this.g += n7, n8 += n7) {
                n7 = this.e == null ? -1 : this.e.read(arrby, n8, arrby.length - n8);
                if (n7 != -1) continue;
                throw o.a();
            }
            n8 = arrby.length;
            object.add((byte[])arrby);
            n6 -= n8;
        } while (true);
    }

    public final d f() {
        int n2 = this.k();
        if (n2 == 0) {
            return d.a;
        }
        if (n2 <= this.b - this.c && n2 > 0) {
            d d2 = d.a(this.a, this.c, n2);
            this.c = n2 + this.c;
            return d2;
        }
        return d.a(this.e(n2));
    }

    public final int g() {
        return this.k();
    }

    public final int h() {
        return this.k();
    }

    public final int i() {
        int n2 = this.k();
        return - (n2 & 1) ^ n2 >>> 1;
    }

    public final long j() {
        long l2 = this.l();
        return - (l2 & 1) ^ l2 >>> 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int k() {
        int n2 = this.q();
        if (n2 < 0) {
            n2 &= 127;
            int n3 = this.q();
            if (n3 >= 0) {
                return n2 | n3 << 7;
            }
            n2 |= (n3 & 127) << 7;
            n3 = this.q();
            if (n3 >= 0) {
                return n2 | n3 << 14;
            }
            n2 |= (n3 & 127) << 14;
            int n4 = this.q();
            if (n4 >= 0) {
                return n2 | n4 << 21;
            }
            n3 = this.q();
            n2 = n4 = n2 | (n4 & 127) << 21 | n3 << 28;
            if (n3 < 0) {
                n3 = 0;
                do {
                    if (n3 >= 5) {
                        throw o.c();
                    }
                    n2 = n4;
                    if (this.q() >= 0) break;
                    ++n3;
                } while (true);
            }
        }
        return n2;
    }

    public final long l() {
        long l2 = 0;
        for (int i2 = 0; i2 < 64; i2 += 7) {
            byte by2 = this.q();
            l2 |= (long)(by2 & 127) << i2;
            if ((by2 & 128) != 0) continue;
            return l2;
        }
        throw o.c();
    }

    public final int m() {
        return this.q() & 255 | (this.q() & 255) << 8 | (this.q() & 255) << 16 | (this.q() & 255) << 24;
    }

    public final long n() {
        byte by2 = this.q();
        byte by3 = this.q();
        byte by4 = this.q();
        byte by5 = this.q();
        byte by6 = this.q();
        byte by7 = this.q();
        byte by8 = this.q();
        byte by9 = this.q();
        long l2 = by2;
        return ((long)by3 & 255) << 8 | l2 & 255 | ((long)by4 & 255) << 16 | ((long)by5 & 255) << 24 | ((long)by6 & 255) << 32 | ((long)by7 & 255) << 40 | ((long)by8 & 255) << 48 | ((long)by9 & 255) << 56;
    }

    public final int o() {
        if (this.h == Integer.MAX_VALUE) {
            return -1;
        }
        int n2 = this.g;
        int n3 = this.c;
        return this.h - (n2 + n3);
    }
}

