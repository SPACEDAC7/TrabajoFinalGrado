/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.c.d.a.a;
import com.google.protobuf.ah;
import com.google.protobuf.d;
import com.google.protobuf.p;
import com.google.protobuf.u;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

public final class f {
    final byte[] a;
    final int b;
    int c;
    final OutputStream d;

    private f(OutputStream outputStream, byte[] arrby) {
        this.d = outputStream;
        this.a = arrby;
        this.c = 0;
        this.b = arrby.length;
    }

    private f(byte[] arrby, int n2) {
        this.d = null;
        this.a = arrby;
        this.c = 0;
        this.b = n2;
    }

    static int a(int n2) {
        int n3 = n2;
        if (n2 > 4096) {
            n3 = 4096;
        }
        return n3;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int a(p p2) {
        int n2;
        if (p2.c) {
            n2 = p2.b.getSerializedSize();
            do {
                return n2 + f.f(n2);
                break;
            } while (true);
        }
        n2 = p2.a.b();
        return n2 + f.f(n2);
    }

    public static int a(String arrby) {
        try {
            arrby = arrby.getBytes("UTF-8");
            int n2 = f.f(arrby.length);
            int n3 = arrby.length;
            return n3 + n2;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw new RuntimeException("UTF-8 not supported.", var0_1);
        }
    }

    public static f a(OutputStream outputStream, int n2) {
        return new f(outputStream, new byte[n2]);
    }

    public static f a(byte[] arrby) {
        return new f(arrby, arrby.length);
    }

    public static int b(long l2) {
        if ((-128 & l2) == 0) {
            return 1;
        }
        if ((-16384 & l2) == 0) {
            return 2;
        }
        if ((-2097152 & l2) == 0) {
            return 3;
        }
        if ((-268435456 & l2) == 0) {
            return 4;
        }
        if ((-34359738368L & l2) == 0) {
            return 5;
        }
        if ((-4398046511104L & l2) == 0) {
            return 6;
        }
        if ((-562949953421312L & l2) == 0) {
            return 7;
        }
        if ((-72057594037927936L & l2) == 0) {
            return 8;
        }
        if ((Long.MIN_VALUE & l2) == 0) {
            return 9;
        }
        return 10;
    }

    public static int b(d d2) {
        return f.f(d2.b()) + d2.b();
    }

    public static int b(u u2) {
        int n2 = u2.getSerializedSize();
        return n2 + f.f(n2);
    }

    public static int c(int n2) {
        if (n2 >= 0) {
            return f.f(n2);
        }
        return 10;
    }

    public static int c(int n2, long l2) {
        return f.d(n2) + f.b(l2);
    }

    public static int c(int n2, d d2) {
        return f.d(n2) + f.b(d2);
    }

    public static int d(int n2) {
        return f.f(ah.a(n2, 0));
    }

    public static int d(int n2, int n3) {
        return f.d(n2) + f.c(n3);
    }

    public static int d(int n2, u u2) {
        return f.d(n2) + f.b(u2);
    }

    public static long d(long l2) {
        return l2 << 1 ^ l2 >> 63;
    }

    public static int e(int n2, int n3) {
        return f.d(n2) + f.f(n3);
    }

    public static int e(int n2, u u2) {
        return (f.d(1) << 1) + f.e(2, n2) + f.d(3, u2);
    }

    public static int f(int n2) {
        if ((n2 & -128) == 0) {
            return 1;
        }
        if ((n2 & -16384) == 0) {
            return 2;
        }
        if ((-2097152 & n2) == 0) {
            return 3;
        }
        if ((-268435456 & n2) == 0) {
            return 4;
        }
        return 5;
    }

    public static int f(int n2, int n3) {
        return f.d(n2) + f.c(n3);
    }

    public static int h(int n2) {
        return n2 << 1 ^ n2 >> 31;
    }

    private void i(int n2) {
        byte by2 = (byte)n2;
        if (this.c == this.b) {
            this.a();
        }
        byte[] arrby = this.a;
        n2 = this.c;
        this.c = n2 + 1;
        arrby[n2] = by2;
    }

    final void a() {
        if (this.d == null) {
            throw new a();
        }
        this.d.write(this.a, 0, this.c);
        this.c = 0;
    }

    public final void a(double d2) {
        this.c(Double.doubleToRawLongBits(d2));
    }

    public final void a(int n2, int n3) {
        this.g(n2, 0);
        this.b(n3);
    }

    public final void a(int n2, long l2) {
        this.g(n2, 0);
        this.a(l2);
    }

    public final void a(int n2, d d2) {
        this.g(n2, 2);
        this.a(d2);
    }

    public final void a(int n2, u u2) {
        this.g(n2, 3);
        u2.writeTo(this);
        this.g(n2, 4);
    }

    public final void a(int n2, boolean bl2) {
        this.g(n2, 0);
        this.a(bl2);
    }

    public final void a(long l2) {
        do {
            if ((-128 & l2) == 0) {
                this.i((int)l2);
                return;
            }
            this.i((int)l2 & 127 | 128);
            l2 >>>= 7;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(d var1_1) {
        this.e(var1_1.b());
        var2_2 = var1_1.b();
        if (this.b - this.c >= var2_2) {
            var1_1.a(this.a, 0, this.c, var2_2);
            this.c = var2_2 + this.c;
            return;
        }
        var3_3 = this.b - this.c;
        var1_1.a(this.a, 0, this.c, var3_3);
        this.c = this.b;
        this.a();
        if ((var2_2 -= var3_3) <= this.b) {
            var1_1.a(this.a, var3_3, 0, var2_2);
            this.c = var2_2;
            return;
        }
        if ((long)var3_3 == (var1_1 = var1_1.f()).skip(var3_3)) ** GOTO lbl19
        throw new IllegalStateException("Skip failed? Should never happen.");
lbl-1000: // 1 sources:
        {
            this.d.write(this.a, 0, var4_4);
            var2_2 -= var4_4;
lbl19: // 2 sources:
            if (var2_2 <= 0) return;
            ** while ((var4_4 = var1_1.read((byte[])this.a, (int)0, (int)(var3_3 = Math.min((int)var2_2, (int)this.b)))) == var3_3)
        }
lbl21: // 1 sources:
        throw new IllegalStateException("Read failed? Should never happen");
    }

    public final void a(u u2) {
        this.e(u2.getSerializedSize());
        u2.writeTo(this);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(boolean bl2) {
        int n2 = bl2 ? 1 : 0;
        this.i(n2);
    }

    public final void b() {
        if (this.d != null) {
            this.a();
        }
    }

    public final void b(int n2) {
        if (n2 >= 0) {
            this.e(n2);
            return;
        }
        this.a(n2);
    }

    public final void b(int n2, int n3) {
        this.g(n2, 0);
        this.e(n3);
    }

    public final void b(int n2, long l2) {
        this.g(n2, 1);
        this.c(l2);
    }

    public final void b(int n2, d d2) {
        this.g(1, 3);
        this.b(2, n2);
        this.a(3, d2);
        this.g(1, 4);
    }

    public final void b(int n2, u u2) {
        this.g(n2, 2);
        this.a(u2);
    }

    public final void c() {
        if (this.d == null) {
            if (this.b - this.c != 0) {
                throw new IllegalStateException("Did not write as much data as expected.");
            }
        } else {
            throw new UnsupportedOperationException("spaceLeft() can only be called on CodedOutputStreams that are writing to a flat array.");
        }
    }

    public final void c(int n2, int n3) {
        this.g(n2, 0);
        this.b(n3);
    }

    public final void c(int n2, u u2) {
        this.g(1, 3);
        this.b(2, n2);
        this.b(3, u2);
        this.g(1, 4);
    }

    public final void c(long l2) {
        this.i((int)l2 & 255);
        this.i((int)(l2 >> 8) & 255);
        this.i((int)(l2 >> 16) & 255);
        this.i((int)(l2 >> 24) & 255);
        this.i((int)(l2 >> 32) & 255);
        this.i((int)(l2 >> 40) & 255);
        this.i((int)(l2 >> 48) & 255);
        this.i((int)(l2 >> 56) & 255);
    }

    public final void e(int n2) {
        do {
            if ((n2 & -128) == 0) {
                this.i(n2);
                return;
            }
            this.i(n2 & 127 | 128);
            n2 >>>= 7;
        } while (true);
    }

    public final void g(int n2) {
        this.i(n2 & 255);
        this.i(n2 >> 8 & 255);
        this.i(n2 >> 16 & 255);
        this.i(n2 >>> 24);
    }

    public final void g(int n2, int n3) {
        this.e(ah.a(n2, n3));
    }
}

