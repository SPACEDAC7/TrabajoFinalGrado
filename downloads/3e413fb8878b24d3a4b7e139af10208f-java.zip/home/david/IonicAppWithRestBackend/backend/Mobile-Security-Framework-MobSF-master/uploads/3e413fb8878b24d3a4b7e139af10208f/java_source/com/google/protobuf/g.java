/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import android.support.design.widget.f;
import com.google.protobuf.a;
import com.google.protobuf.ab;
import com.google.protobuf.af;
import com.google.protobuf.ag;
import com.google.protobuf.b;
import com.google.protobuf.h;
import com.google.protobuf.m;
import com.google.protobuf.q;
import com.google.protobuf.r;
import com.google.protobuf.t;
import com.google.protobuf.u;
import com.google.protobuf.x;
import com.google.protobuf.y;
import com.google.protobuf.z;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public final class g {
    private static h.a A;
    private static m.e B;
    private static h.a C;
    private static m.e D;
    private static h.a E;
    private static m.e F;
    private static h.a G;
    private static m.e H;
    private static h.a I;
    private static m.e J;
    private static h.a K;
    private static m.e L;
    private static h.a M;
    private static m.e N;
    private static h.g O;
    private static h.a a;
    private static m.e b;
    private static h.a c;
    private static m.e d;
    private static h.a e;
    private static m.e f;
    private static h.a g;
    private static m.e h;
    private static h.a i;
    private static m.e j;
    private static h.a k;
    private static m.e l;
    private static h.a m;
    private static m.e n;
    private static h.a o;
    private static m.e p;
    private static h.a q;
    private static m.e r;
    private static h.a s;
    private static m.e t;
    private static h.a u;
    private static m.e v;
    private static h.a w;
    private static m.e x;
    private static h.a y;
    private static m.e z;

    static {
        h.g.a a2 = new h.g.a(){

            @Override
            public final com.google.protobuf.j a(h.g g2) {
                O = g2;
                a = g.a().b().get(0);
                b = new m.e(a, new String[]{"File"});
                c = g.a().b().get(1);
                d = new m.e(c, new String[]{"Name", "Package", "Dependency", "PublicDependency", "WeakDependency", "MessageType", "EnumType", "Service", "Extension", "Options", "SourceCodeInfo"});
                e = g.a().b().get(2);
                f = new m.e(e, new String[]{"Name", "Field", "Extension", "NestedType", "EnumType", "ExtensionRange", "Options"});
                g = e.e().get(0);
                h = new m.e(g, new String[]{"Start", "End"});
                i = g.a().b().get(3);
                j = new m.e(i, new String[]{"Name", "Number", "Label", "Type", "TypeName", "Extendee", "DefaultValue", "Options"});
                k = g.a().b().get(4);
                l = new m.e(k, new String[]{"Name", "Value", "Options"});
                m = g.a().b().get(5);
                n = new m.e(m, new String[]{"Name", "Number", "Options"});
                o = g.a().b().get(6);
                p = new m.e(o, new String[]{"Name", "Method", "Options"});
                q = g.a().b().get(7);
                r = new m.e(q, new String[]{"Name", "InputType", "OutputType", "Options"});
                s = g.a().b().get(8);
                t = new m.e(s, new String[]{"JavaPackage", "JavaOuterClassname", "JavaMultipleFiles", "JavaGenerateEqualsAndHash", "OptimizeFor", "GoPackage", "CcGenericServices", "JavaGenericServices", "PyGenericServices", "UninterpretedOption"});
                u = g.a().b().get(9);
                v = new m.e(u, new String[]{"MessageSetWireFormat", "NoStandardDescriptorAccessor", "UninterpretedOption"});
                w = g.a().b().get(10);
                x = new m.e(w, new String[]{"Ctype", "Packed", "Lazy", "Deprecated", "ExperimentalMapKey", "Weak", "UninterpretedOption"});
                y = g.a().b().get(11);
                z = new m.e(y, new String[]{"AllowAlias", "UninterpretedOption"});
                A = g.a().b().get(12);
                B = new m.e(A, new String[]{"UninterpretedOption"});
                C = g.a().b().get(13);
                D = new m.e(C, new String[]{"UninterpretedOption"});
                E = g.a().b().get(14);
                F = new m.e(E, new String[]{"UninterpretedOption"});
                G = g.a().b().get(15);
                H = new m.e(G, new String[]{"Name", "IdentifierValue", "PositiveIntValue", "NegativeIntValue", "DoubleValue", "StringValue", "AggregateValue"});
                I = G.e().get(0);
                J = new m.e(I, new String[]{"NamePart", "IsExtension"});
                K = g.a().b().get(16);
                L = new m.e(K, new String[]{"Location"});
                M = K.e().get(0);
                N = new m.e(M, new String[]{"Path", "Span", "LeadingComments", "TrailingComments"});
                return null;
            }
        };
        h.g.a(new String[]{"\n google/protobuf/descriptor.proto\u0012\u000fgoogle.protobuf\"G\n\u0011FileDescriptorSet\u00122\n\u0004file\u0018\u0001 \u0003(\u000b2$.google.protobuf.FileDescriptorProto\"\u00cb\u0003\n\u0013FileDescriptorProto\u0012\f\n\u0004name\u0018\u0001 \u0001(\t\u0012\u000f\n\u0007package\u0018\u0002 \u0001(\t\u0012\u0012\n\ndependency\u0018\u0003 \u0003(\t\u0012\u0019\n\u0011public_dependency\u0018\n \u0003(\u0005\u0012\u0017\n\u000fweak_dependency\u0018\u000b \u0003(\u0005\u00126\n\fmessage_type\u0018\u0004 \u0003(\u000b2 .google.protobuf.DescriptorProto\u00127\n\tenum_type\u0018\u0005 \u0003(\u000b2$.google.protobuf.EnumDescriptorProto\u00128\n\u0007service\u0018\u0006 \u0003(\u000b2'.google.protobuf.", "ServiceDescriptorProto\u00128\n\textension\u0018\u0007 \u0003(\u000b2%.google.protobuf.FieldDescriptorProto\u0012-\n\u0007options\u0018\b \u0001(\u000b2\u001c.google.protobuf.FileOptions\u00129\n\u0010source_code_info\u0018\t \u0001(\u000b2\u001f.google.protobuf.SourceCodeInfo\"\u00a9\u0003\n\u000fDescriptorProto\u0012\f\n\u0004name\u0018\u0001 \u0001(\t\u00124\n\u0005field\u0018\u0002 \u0003(\u000b2%.google.protobuf.FieldDescriptorProto\u00128\n\textension\u0018\u0006 \u0003(\u000b2%.google.protobuf.FieldDescriptorProto\u00125\n\u000bnested_type\u0018\u0003 \u0003(\u000b2 .google.protobuf.DescriptorProto\u00127\n\tenum_type", "\u0018\u0004 \u0003(\u000b2$.google.protobuf.EnumDescriptorProto\u0012H\n\u000fextension_range\u0018\u0005 \u0003(\u000b2/.google.protobuf.DescriptorProto.ExtensionRange\u00120\n\u0007options\u0018\u0007 \u0001(\u000b2\u001f.google.protobuf.MessageOptions\u001a,\n\u000eExtensionRange\u0012\r\n\u0005start\u0018\u0001 \u0001(\u0005\u0012\u000b\n\u0003end\u0018\u0002 \u0001(\u0005\"\u0094\u0005\n\u0014FieldDescriptorProto\u0012\f\n\u0004name\u0018\u0001 \u0001(\t\u0012\u000e\n\u0006number\u0018\u0003 \u0001(\u0005\u0012:\n\u0005label\u0018\u0004 \u0001(\u000e2+.google.protobuf.FieldDescriptorProto.Label\u00128\n\u0004type\u0018\u0005 \u0001(\u000e2*.google.protobuf.FieldDescriptorProto.Type\u0012\u0011\n\ttype_name", "\u0018\u0006 \u0001(\t\u0012\u0010\n\bextendee\u0018\u0002 \u0001(\t\u0012\u0015\n\rdefault_value\u0018\u0007 \u0001(\t\u0012.\n\u0007options\u0018\b \u0001(\u000b2\u001d.google.protobuf.FieldOptions\"\u00b6\u0002\n\u0004Type\u0012\u000f\n\u000bTYPE_DOUBLE\u0010\u0001\u0012\u000e\n\nTYPE_FLOAT\u0010\u0002\u0012\u000e\n\nTYPE_INT64\u0010\u0003\u0012\u000f\n\u000bTYPE_UINT64\u0010\u0004\u0012\u000e\n\nTYPE_INT32\u0010\u0005\u0012\u0010\n\fTYPE_FIXED64\u0010\u0006\u0012\u0010\n\fTYPE_FIXED32\u0010\u0007\u0012\r\n\tTYPE_BOOL\u0010\b\u0012\u000f\n\u000bTYPE_STRING\u0010\t\u0012\u000e\n\nTYPE_GROUP\u0010\n\u0012\u0010\n\fTYPE_MESSAGE\u0010\u000b\u0012\u000e\n\nTYPE_BYTES\u0010\f\u0012\u000f\n\u000bTYPE_UINT32\u0010\r\u0012\r\n\tTYPE_ENUM\u0010\u000e\u0012\u0011\n\rTYPE_SFIXED32\u0010\u000f\u0012\u0011\n\rTYPE_SFIXED64\u0010\u0010\u0012\u000f\n\u000bTYPE_SINT32\u0010\u0011\u0012\u000f\n\u000bTYPE_", "SINT64\u0010\u0012\"C\n\u0005Label\u0012\u0012\n\u000eLABEL_OPTIONAL\u0010\u0001\u0012\u0012\n\u000eLABEL_REQUIRED\u0010\u0002\u0012\u0012\n\u000eLABEL_REPEATED\u0010\u0003\"\u008c\u0001\n\u0013EnumDescriptorProto\u0012\f\n\u0004name\u0018\u0001 \u0001(\t\u00128\n\u0005value\u0018\u0002 \u0003(\u000b2).google.protobuf.EnumValueDescriptorProto\u0012-\n\u0007options\u0018\u0003 \u0001(\u000b2\u001c.google.protobuf.EnumOptions\"l\n\u0018EnumValueDescriptorProto\u0012\f\n\u0004name\u0018\u0001 \u0001(\t\u0012\u000e\n\u0006number\u0018\u0002 \u0001(\u0005\u00122\n\u0007options\u0018\u0003 \u0001(\u000b2!.google.protobuf.EnumValueOptions\"\u0090\u0001\n\u0016ServiceDescriptorProto\u0012\f\n\u0004name\u0018\u0001 \u0001(\t\u00126\n\u0006method\u0018\u0002 \u0003(\u000b2&.google.pro", "tobuf.MethodDescriptorProto\u00120\n\u0007options\u0018\u0003 \u0001(\u000b2\u001f.google.protobuf.ServiceOptions\"\n\u0015MethodDescriptorProto\u0012\f\n\u0004name\u0018\u0001 \u0001(\t\u0012\u0012\n\ninput_type\u0018\u0002 \u0001(\t\u0012\u0013\n\u000boutput_type\u0018\u0003 \u0001(\t\u0012/\n\u0007options\u0018\u0004 \u0001(\u000b2\u001e.google.protobuf.MethodOptions\"\u00e9\u0003\n\u000bFileOptions\u0012\u0014\n\fjava_package\u0018\u0001 \u0001(\t\u0012\u001c\n\u0014java_outer_classname\u0018\b \u0001(\t\u0012\"\n\u0013java_multiple_files\u0018\n \u0001(\b:\u0005false\u0012,\n\u001djava_generate_equals_and_hash\u0018\u0014 \u0001(\b:\u0005false\u0012F\n\foptimize_for\u0018\t \u0001(\u000e2).google.protobuf.Fil", "eOptions.OptimizeMode:\u0005SPEED\u0012\u0012\n\ngo_package\u0018\u000b \u0001(\t\u0012\"\n\u0013cc_generic_services\u0018\u0010 \u0001(\b:\u0005false\u0012$\n\u0015java_generic_services\u0018\u0011 \u0001(\b:\u0005false\u0012\"\n\u0013py_generic_services\u0018\u0012 \u0001(\b:\u0005false\u0012C\n\u0014uninterpreted_option\u0018\u00e7\u0007 \u0003(\u000b2$.google.protobuf.UninterpretedOption\":\n\fOptimizeMode\u0012\t\n\u0005SPEED\u0010\u0001\u0012\r\n\tCODE_SIZE\u0010\u0002\u0012\u0010\n\fLITE_RUNTIME\u0010\u0003*\t\b\u00e8\u0007\u0010\u0002\"\u00b8\u0001\n\u000eMessageOptions\u0012&\n\u0017message_set_wire_format\u0018\u0001 \u0001(\b:\u0005false\u0012.\n\u001fno_standard_descriptor_accessor\u0018\u0002 \u0001(\b:\u0005", "false\u0012C\n\u0014uninterpreted_option\u0018\u00e7\u0007 \u0003(\u000b2$.google.protobuf.UninterpretedOption*\t\b\u00e8\u0007\u0010\u0002\"\u00be\u0002\n\fFieldOptions\u0012:\n\u0005ctype\u0018\u0001 \u0001(\u000e2#.google.protobuf.FieldOptions.CType:\u0006STRING\u0012\u000e\n\u0006packed\u0018\u0002 \u0001(\b\u0012\u0013\n\u0004lazy\u0018\u0005 \u0001(\b:\u0005false\u0012\u0019\n\ndeprecated\u0018\u0003 \u0001(\b:\u0005false\u0012\u001c\n\u0014experimental_map_key\u0018\t \u0001(\t\u0012\u0013\n\u0004weak\u0018\n \u0001(\b:\u0005false\u0012C\n\u0014uninterpreted_option\u0018\u00e7\u0007 \u0003(\u000b2$.google.protobuf.UninterpretedOption\"/\n\u0005CType\u0012\n\n\u0006STRING\u0010\u0000\u0012\b\n\u0004CORD\u0010\u0001\u0012\u0010\n\fSTRING_PIECE\u0010\u0002*\t\b\u00e8\u0007", "\u0010\u0002\"x\n\u000bEnumOptions\u0012\u0019\n\u000ballow_alias\u0018\u0002 \u0001(\b:\u0004true\u0012C\n\u0014uninterpreted_option\u0018\u00e7\u0007 \u0003(\u000b2$.google.protobuf.UninterpretedOption*\t\b\u00e8\u0007\u0010\u0002\"b\n\u0010EnumValueOptions\u0012C\n\u0014uninterpreted_option\u0018\u00e7\u0007 \u0003(\u000b2$.google.protobuf.UninterpretedOption*\t\b\u00e8\u0007\u0010\u0002\"`\n\u000eServiceOptions\u0012C\n\u0014uninterpreted_option\u0018\u00e7\u0007 \u0003(\u000b2$.google.protobuf.UninterpretedOption*\t\b\u00e8\u0007\u0010\u0002\"_\n\rMethodOptions\u0012C\n\u0014uninterpreted_option\u0018\u00e7\u0007 \u0003(\u000b2$.google.protobuf.Uninter", "pretedOption*\t\b\u00e8\u0007\u0010\u0002\"\u009e\u0002\n\u0013UninterpretedOption\u0012;\n\u0004name\u0018\u0002 \u0003(\u000b2-.google.protobuf.UninterpretedOption.NamePart\u0012\u0018\n\u0010identifier_value\u0018\u0003 \u0001(\t\u0012\u001a\n\u0012positive_int_value\u0018\u0004 \u0001(\u0004\u0012\u001a\n\u0012negative_int_value\u0018\u0005 \u0001(\u0003\u0012\u0014\n\fdouble_value\u0018\u0006 \u0001(\u0001\u0012\u0014\n\fstring_value\u0018\u0007 \u0001(\f\u0012\u0017\n\u000faggregate_value\u0018\b \u0001(\t\u001a3\n\bNamePart\u0012\u0011\n\tname_part\u0018\u0001 \u0002(\t\u0012\u0014\n\fis_extension\u0018\u0002 \u0002(\b\"\u00b1\u0001\n\u000eSourceCodeInfo\u0012:\n\blocation\u0018\u0001 \u0003(\u000b2(.google.protobuf.SourceCodeInfo.Location\u001ac\n\bLocat", "ion\u0012\u0010\n\u0004path\u0018\u0001 \u0003(\u0005B\u0002\u0010\u0001\u0012\u0010\n\u0004span\u0018\u0002 \u0003(\u0005B\u0002\u0010\u0001\u0012\u0018\n\u0010leading_comments\u0018\u0003 \u0001(\t\u0012\u0019\n\u0011trailing_comments\u0018\u0004 \u0001(\tB)\n\u0013com.google.protobufB\u0010DescriptorProtosH\u0001"}, new h.g[0], a2);
    }

    public static h.g a() {
        return O;
    }

    public static final class com.google.protobuf.g$a
    extends com.google.protobuf.m
    implements f.a {
        public static x<com.google.protobuf.g$a> a;
        private static final com.google.protobuf.g$a e;
        int b;
        List<b> c;
        j d;
        private final af f;
        private Object g;
        private List<f> h;
        private List<f> i;
        private List<com.google.protobuf.g$a> j;
        private List<com.google.protobuf.g$b> k;
        private byte l;
        private int m;

        static {
            com.google.protobuf.g$a a2;
            a = new com.google.protobuf.c<com.google.protobuf.g$a>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new com.google.protobuf.g$a(e2, k2, 0);
                }
            };
            e = a2 = new com.google.protobuf.g$a();
            a2.i();
        }

        private com.google.protobuf.g$a() {
            this.l = -1;
            this.m = -1;
            this.f = af.b();
        }

        /*
         * Exception decompiling
         */
        private com.google.protobuf.g$a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_6) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ com.google.protobuf.g$a(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private com.google.protobuf.g$a(m.a<?> a2) {
            super(a2);
            this.l = -1;
            this.m = -1;
            this.f = a2.getUnknownFields();
        }

        /* synthetic */ com.google.protobuf.g$a(m.a a2, byte by2) {
            this(a2);
        }

        public static com.google.protobuf.g$a a() {
            return e;
        }

        private com.google.protobuf.d h() {
            Object object = this.g;
            if (object instanceof String) {
                this.g = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private void i() {
            this.g = "";
            this.h = Collections.emptyList();
            this.i = Collections.emptyList();
            this.j = Collections.emptyList();
            this.k = Collections.emptyList();
            this.c = Collections.emptyList();
            this.d = j.a();
        }

        private a j() {
            return a.a().a(this);
        }

        public final f a(int n2) {
            return this.h.get(n2);
        }

        public final f b(int n2) {
            return this.i.get(n2);
        }

        public final String b() {
            Object object = this.g;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.g = string;
            }
            return string;
        }

        public final int c() {
            return this.h.size();
        }

        public final com.google.protobuf.g$a c(int n2) {
            return this.j.get(n2);
        }

        public final int d() {
            return this.i.size();
        }

        public final com.google.protobuf.g$b d(int n2) {
            return this.k.get(n2);
        }

        public final int e() {
            return this.j.size();
        }

        public final int f() {
            return this.k.size();
        }

        public final boolean g() {
            if ((this.b & 2) == 2) {
                return true;
            }
            return false;
        }

        public final x<com.google.protobuf.g$a> getParserForType() {
            return a;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int getSerializedSize() {
            int n2;
            int n3 = 0;
            int n4 = this.m;
            if (n4 != -1) {
                return n4;
            }
            n4 = (this.b & 1) == 1 ? com.google.protobuf.f.c(1, this.h()) + 0 : 0;
            for (n2 = 0; n2 < this.h.size(); n4 += com.google.protobuf.f.d((int)2, (u)((u)this.h.get((int)n2))), ++n2) {
            }
            for (n2 = 0; n2 < this.j.size(); n4 += com.google.protobuf.f.d((int)3, (u)((u)this.j.get((int)n2))), ++n2) {
            }
            for (n2 = 0; n2 < this.k.size(); n4 += com.google.protobuf.f.d((int)4, (u)((u)this.k.get((int)n2))), ++n2) {
            }
            int n5 = 0;
            do {
                n2 = n4;
                if (n5 >= this.c.size()) break;
                n4 += com.google.protobuf.f.d(5, this.c.get(n5));
                ++n5;
            } while (true);
            for (int i2 = n3; i2 < this.i.size(); n2 += com.google.protobuf.f.d((int)6, (u)((u)this.i.get((int)i2))), ++i2) {
            }
            n4 = n2;
            if ((this.b & 2) == 2) {
                n4 = n2 + com.google.protobuf.f.d(7, this.d);
            }
            this.m = n4 = this.getUnknownFields().getSerializedSize() + n4;
            return n4;
        }

        @Override
        public final af getUnknownFields() {
            return this.f;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return f.a(com.google.protobuf.g$a.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.l;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.c(); ++n2) {
                if (this.a(n2).isInitialized()) continue;
                this.l = 0;
                return false;
            }
            for (n2 = 0; n2 < this.d(); ++n2) {
                if (this.b(n2).isInitialized()) continue;
                this.l = 0;
                return false;
            }
            for (n2 = 0; n2 < this.e(); ++n2) {
                if (this.c(n2).isInitialized()) continue;
                this.l = 0;
                return false;
            }
            for (n2 = 0; n2 < this.f(); ++n2) {
                if (this.d(n2).isInitialized()) continue;
                this.l = 0;
                return false;
            }
            if (this.g() && !this.d.isInitialized()) {
                this.l = 0;
                return false;
            }
            this.l = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.a();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.j();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.j();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            int n2;
            int n3 = 0;
            this.getSerializedSize();
            if ((this.b & 1) == 1) {
                f2.a(1, this.h());
            }
            for (n2 = 0; n2 < this.h.size(); ++n2) {
                f2.b(2, this.h.get(n2));
            }
            for (n2 = 0; n2 < this.j.size(); ++n2) {
                f2.b(3, this.j.get(n2));
            }
            for (n2 = 0; n2 < this.k.size(); ++n2) {
                f2.b(4, this.k.get(n2));
            }
            n2 = 0;
            do {
                if (n2 >= this.c.size()) break;
                f2.b(5, this.c.get(n2));
                ++n2;
            } while (true);
            for (int i2 = n3; i2 < this.i.size(); ++i2) {
                f2.b(6, this.i.get(i2));
            }
            if ((this.b & 2) == 2) {
                f2.b(7, this.d);
            }
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.a<a>
        implements f.a {
            private int c;
            private Object d = "";
            private List<f> e = Collections.emptyList();
            private z<f, f.a, f.a> f;
            private List<f> g = Collections.emptyList();
            private z<f, f.a, f.a> h;
            private List<com.google.protobuf.g$a> i = Collections.emptyList();
            private z<com.google.protobuf.g$a, a, f.a> j;
            private List<com.google.protobuf.g$b> k = Collections.emptyList();
            private z<com.google.protobuf.g$b, com.google.protobuf.g$b$a, f.a> l;
            private List<b> m = Collections.emptyList();
            private z<b, b.a, f.a> n;
            private j o = j.a();
            private ab<j, j.a, f.a> p;

            private a() {
                this.b();
            }

            private a(m.b b2) {
                super(b2);
                this.b();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            static /* synthetic */ a a() {
                return new a();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = com.google.protobuf.g$a.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((com.google.protobuf.g$a)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (com.google.protobuf.g$a)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((com.google.protobuf.g$a)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof com.google.protobuf.g$a) {
                    return this.a((com.google.protobuf.g$a)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            private void b() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.h();
                    this.i();
                    this.j();
                    this.k();
                    this.l();
                    if (this.p == null) {
                        this.p = new ab(this.o, this.getParentForChildren(), this.b);
                        this.o = null;
                    }
                }
            }

            /*
             * Enabled aggressive block sorting
             */
            private a c() {
                super.clear();
                this.d = "";
                this.c &= -2;
                if (this.f == null) {
                    this.e = Collections.emptyList();
                    this.c &= -3;
                } else {
                    this.f.f();
                }
                if (this.h == null) {
                    this.g = Collections.emptyList();
                    this.c &= -5;
                } else {
                    this.h.f();
                }
                if (this.j == null) {
                    this.i = Collections.emptyList();
                    this.c &= -9;
                } else {
                    this.j.f();
                }
                if (this.l == null) {
                    this.k = Collections.emptyList();
                    this.c &= -17;
                } else {
                    this.l.f();
                }
                if (this.n == null) {
                    this.m = Collections.emptyList();
                    this.c &= -33;
                } else {
                    this.n.f();
                }
                if (this.p == null) {
                    this.o = j.a();
                } else {
                    this.p.f();
                }
                this.c &= -65;
                return this;
            }

            private a d() {
                return new a().a(this.g());
            }

            private com.google.protobuf.g$a f() {
                com.google.protobuf.g$a a2 = this.g();
                if (!a2.isInitialized()) {
                    throw a.newUninitializedMessageException(a2);
                }
                return a2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private com.google.protobuf.g$a g() {
                int n2 = 1;
                com.google.protobuf.g$a a2 = new com.google.protobuf.g$a(this, 0);
                int n3 = this.c;
                if ((n3 & 1) != 1) {
                    n2 = 0;
                }
                a2.g = this.d;
                if (this.f == null) {
                    if ((this.c & 2) == 2) {
                        this.e = Collections.unmodifiableList(this.e);
                        this.c &= -3;
                    }
                    a2.h = this.e;
                } else {
                    a2.h = this.f.g();
                }
                if (this.h == null) {
                    if ((this.c & 4) == 4) {
                        this.g = Collections.unmodifiableList(this.g);
                        this.c &= -5;
                    }
                    a2.i = this.g;
                } else {
                    a2.i = this.h.g();
                }
                if (this.j == null) {
                    if ((this.c & 8) == 8) {
                        this.i = Collections.unmodifiableList(this.i);
                        this.c &= -9;
                    }
                    a2.j = this.i;
                } else {
                    a2.j = this.j.g();
                }
                if (this.l == null) {
                    if ((this.c & 16) == 16) {
                        this.k = Collections.unmodifiableList(this.k);
                        this.c &= -17;
                    }
                    a2.k = this.k;
                } else {
                    a2.k = this.l.g();
                }
                if (this.n == null) {
                    if ((this.c & 32) == 32) {
                        this.m = Collections.unmodifiableList(this.m);
                        this.c &= -33;
                    }
                    a2.c = this.m;
                } else {
                    a2.c = this.n.g();
                }
                if ((n3 & 64) == 64) {
                    n2 |= 2;
                }
                if (this.p == null) {
                    a2.d = this.o;
                } else {
                    a2.d = this.p.c();
                }
                a2.b = n2;
                this.onBuilt();
                return a2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<f, f.a, f.a> h() {
                if (this.f == null) {
                    List<f> list = this.e;
                    boolean bl2 = (this.c & 2) == 2;
                    this.f = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.e = null;
                }
                return this.f;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<f, f.a, f.a> i() {
                if (this.h == null) {
                    List<f> list = this.g;
                    boolean bl2 = (this.c & 4) == 4;
                    this.h = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.g = null;
                }
                return this.h;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<com.google.protobuf.g$a, a, f.a> j() {
                if (this.j == null) {
                    List<com.google.protobuf.g$a> list = this.i;
                    boolean bl2 = (this.c & 8) == 8;
                    this.j = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.i = null;
                }
                return this.j;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<com.google.protobuf.g$b, com.google.protobuf.g$b$a, f.a> k() {
                if (this.l == null) {
                    List<com.google.protobuf.g$b> list = this.k;
                    boolean bl2 = (this.c & 16) == 16;
                    this.l = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.k = null;
                }
                return this.l;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<b, b.a, f.a> l() {
                if (this.n == null) {
                    List<b> list = this.m;
                    boolean bl2 = (this.c & 32) == 32;
                    this.n = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.m = null;
                }
                return this.n;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(com.google.protobuf.g$a a2) {
                boolean bl2 = true;
                Object var3_3 = null;
                if (a2 == com.google.protobuf.g$a.a()) {
                    return this;
                }
                if ((a2.b & 1) != 1) {
                    bl2 = false;
                }
                if (bl2) {
                    this.c |= 1;
                    this.d = a2.g;
                    this.onChanged();
                }
                if (this.f == null) {
                    if (!a2.h.isEmpty()) {
                        if (this.e.isEmpty()) {
                            this.e = a2.h;
                            this.c &= -3;
                        } else {
                            if ((this.c & 2) != 2) {
                                this.e = new ArrayList<f>(this.e);
                                this.c |= 2;
                            }
                            this.e.addAll(a2.h);
                        }
                        this.onChanged();
                    }
                } else if (!a2.h.isEmpty()) {
                    if (this.f.e()) {
                        void var2_4;
                        this.f.a = null;
                        this.f = null;
                        this.e = a2.h;
                        this.c &= -3;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z<f, f.a, f.a> z2 = this.h();
                        } else {
                            Object var2_11 = null;
                        }
                        this.f = var2_4;
                    } else {
                        this.f.a(a2.h);
                    }
                }
                if (this.h == null) {
                    if (!a2.i.isEmpty()) {
                        if (this.g.isEmpty()) {
                            this.g = a2.i;
                            this.c &= -5;
                        } else {
                            if ((this.c & 4) != 4) {
                                this.g = new ArrayList<f>(this.g);
                                this.c |= 4;
                            }
                            this.g.addAll(a2.i);
                        }
                        this.onChanged();
                    }
                } else if (!a2.i.isEmpty()) {
                    if (this.h.e()) {
                        void var2_13;
                        this.h.a = null;
                        this.h = null;
                        this.g = a2.i;
                        this.c &= -5;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z<f, f.a, f.a> z3 = this.i();
                        } else {
                            Object var2_14 = null;
                        }
                        this.h = var2_13;
                    } else {
                        this.h.a(a2.i);
                    }
                }
                if (this.j == null) {
                    if (!a2.j.isEmpty()) {
                        if (this.i.isEmpty()) {
                            this.i = a2.j;
                            this.c &= -9;
                        } else {
                            if ((this.c & 8) != 8) {
                                this.i = new ArrayList<com.google.protobuf.g$a>(this.i);
                                this.c |= 8;
                            }
                            this.i.addAll(a2.j);
                        }
                        this.onChanged();
                    }
                } else if (!a2.j.isEmpty()) {
                    if (this.j.e()) {
                        void var2_16;
                        this.j.a = null;
                        this.j = null;
                        this.i = a2.j;
                        this.c &= -9;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z<com.google.protobuf.g$a, a, f.a> z4 = this.j();
                        } else {
                            Object var2_17 = null;
                        }
                        this.j = var2_16;
                    } else {
                        this.j.a(a2.j);
                    }
                }
                if (this.l == null) {
                    if (!a2.k.isEmpty()) {
                        if (this.k.isEmpty()) {
                            this.k = a2.k;
                            this.c &= -17;
                        } else {
                            if ((this.c & 16) != 16) {
                                this.k = new ArrayList<com.google.protobuf.g$b>(this.k);
                                this.c |= 16;
                            }
                            this.k.addAll(a2.k);
                        }
                        this.onChanged();
                    }
                } else if (!a2.k.isEmpty()) {
                    if (this.l.e()) {
                        void var2_19;
                        this.l.a = null;
                        this.l = null;
                        this.k = a2.k;
                        this.c &= -17;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z<com.google.protobuf.g$b, com.google.protobuf.g$b$a, f.a> z5 = this.k();
                        } else {
                            Object var2_20 = null;
                        }
                        this.l = var2_19;
                    } else {
                        this.l.a(a2.k);
                    }
                }
                if (this.n == null) {
                    if (!a2.c.isEmpty()) {
                        if (this.m.isEmpty()) {
                            this.m = a2.c;
                            this.c &= -33;
                        } else {
                            if ((this.c & 32) != 32) {
                                this.m = new ArrayList<b>(this.m);
                                this.c |= 32;
                            }
                            this.m.addAll(a2.c);
                        }
                        this.onChanged();
                    }
                } else if (!a2.c.isEmpty()) {
                    if (this.n.e()) {
                        void var2_23;
                        this.n.a = null;
                        this.n = null;
                        this.m = a2.c;
                        this.c &= -33;
                        Object var2_21 = var3_3;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z<b, b.a, f.a> z6 = this.l();
                        }
                        this.n = var2_23;
                    } else {
                        this.n.a(a2.c);
                    }
                }
                if (a2.g()) {
                    j j2 = a2.d;
                    if (this.p == null) {
                        this.o = (this.c & 64) == 64 && this.o != j.a() ? j.a(this.o).a(j2).a() : j2;
                        this.onChanged();
                    } else {
                        this.p.b(j2);
                    }
                    this.c |= 64;
                }
                this.mergeUnknownFields(a2.getUnknownFields());
                return this;
            }

            @Override
            public final /* synthetic */ t build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ com.google.protobuf.b$a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return com.google.protobuf.g$a.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return e;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return f.a(com.google.protobuf.g$a.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                int n3;
                for (n3 = 0; n3 < (n2 = this.f == null ? this.e.size() : this.f.d()); ++n3) {
                    void var1_2;
                    if (this.f == null) {
                        f f2 = this.e.get(n3);
                    } else {
                        f f3 = this.f.a(n3, false);
                    }
                    if (!var1_2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                n3 = 0;
                do {
                    void var1_7;
                    n2 = this.h == null ? this.g.size() : this.h.d();
                    if (n3 >= n2) break;
                    if (this.h == null) {
                        f f4 = this.g.get(n3);
                    } else {
                        f f5 = this.h.a(n3, false);
                    }
                    if (!var1_7.isInitialized()) return false;
                    {
                        ++n3;
                        continue;
                    }
                    break;
                } while (true);
                n3 = 0;
                do {
                    void var1_11;
                    n2 = this.j == null ? this.i.size() : this.j.d();
                    if (n3 >= n2) break;
                    if (this.j == null) {
                        com.google.protobuf.g$a a2 = this.i.get(n3);
                    } else {
                        com.google.protobuf.g$a a3 = this.j.a(n3, false);
                    }
                    if (!var1_11.isInitialized()) return false;
                    {
                        ++n3;
                        continue;
                    }
                    break;
                } while (true);
                n3 = 0;
                do {
                    void var1_15;
                    n2 = this.l == null ? this.k.size() : this.l.d();
                    if (n3 >= n2) break;
                    if (this.l == null) {
                        com.google.protobuf.g$b b2 = this.k.get(n3);
                    } else {
                        com.google.protobuf.g$b b3 = this.l.a(n3, false);
                    }
                    if (!var1_15.isInitialized()) return false;
                    {
                        ++n3;
                        continue;
                    }
                    break;
                } while (true);
                if ((this.c & 64) != 64) {
                    return true;
                }
                n3 = 1;
                if (n3 == 0) return true;
                {
                    void var1_18;
                    if (this.p == null) {
                        j j2 = this.o;
                    } else {
                        j j3 = this.p.b();
                    }
                    if (var1_18.isInitialized()) return true;
                }
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ com.google.protobuf.b$a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

        public static final class b
        extends com.google.protobuf.m
        implements f.a {
            public static x<b> a;
            private static final b e;
            int b;
            int c;
            int d;
            private final af f;
            private byte g;
            private int h;

            static {
                b b2;
                a = new com.google.protobuf.c<b>(){

                    @Override
                    public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                        return new b(e2, k2, 0);
                    }
                };
                e = b2 = new b();
                b2.b();
            }

            private b() {
                this.g = -1;
                this.h = -1;
                this.f = af.b();
            }

            /*
             * Exception decompiling
             */
            private b(com.google.protobuf.e var1_1, com.google.protobuf.k var2_6) {
                // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
                // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
                // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
                // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
                // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
                // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
                // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
                // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
                // org.benf.cfr.reader.Main.doJar(Main.java:129)
                // org.benf.cfr.reader.Main.main(Main.java:181)
                throw new IllegalStateException("Decompilation failed");
            }

            /* synthetic */ b(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
                this(e2, k2);
            }

            private b(m.a<?> a2) {
                super(a2);
                this.g = -1;
                this.h = -1;
                this.f = a2.getUnknownFields();
            }

            /* synthetic */ b(m.a a2, byte by2) {
                this(a2);
            }

            public static b a() {
                return e;
            }

            private void b() {
                this.c = 0;
                this.d = 0;
            }

            private a c() {
                return a.a().a(this);
            }

            public final x<b> getParserForType() {
                return a;
            }

            @Override
            public final int getSerializedSize() {
                int n2 = this.h;
                if (n2 != -1) {
                    return n2;
                }
                n2 = 0;
                if ((this.b & 1) == 1) {
                    n2 = com.google.protobuf.f.d(1, this.c) + 0;
                }
                int n3 = n2;
                if ((this.b & 2) == 2) {
                    n3 = n2 + com.google.protobuf.f.d(2, this.d);
                }
                this.h = n2 = n3 + this.getUnknownFields().getSerializedSize();
                return n2;
            }

            @Override
            public final af getUnknownFields() {
                return this.f;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return h.a(b.class, a.class);
            }

            @Override
            public final boolean isInitialized() {
                byte by2 = this.g;
                if (by2 != -1) {
                    if (by2 == 1) {
                        return true;
                    }
                    return false;
                }
                this.g = 1;
                return true;
            }

            @Override
            public final /* synthetic */ t.a newBuilderForType() {
                return a.a();
            }

            @Override
            protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
                return new a(b2, 0);
            }

            @Override
            public final /* synthetic */ t.a toBuilder() {
                return this.c();
            }

            @Override
            public final /* synthetic */ u.a toBuilder() {
                return this.c();
            }

            @Override
            protected final Object writeReplace() {
                return super.writeReplace();
            }

            @Override
            public final void writeTo(com.google.protobuf.f f2) {
                this.getSerializedSize();
                if ((this.b & 1) == 1) {
                    f2.a(1, this.c);
                }
                if ((this.b & 2) == 2) {
                    f2.a(2, this.d);
                }
                this.getUnknownFields().writeTo(f2);
            }

            public static final class a
            extends m.a<a>
            implements f.a {
                private int c;
                private int d;
                private int e;

                private a() {
                    boolean bl2 = com.google.protobuf.m.alwaysUseFieldBuilders;
                }

                private a(m.b b2) {
                    super(b2);
                    boolean bl2 = com.google.protobuf.m.alwaysUseFieldBuilders;
                }

                /* synthetic */ a(m.b b2, byte by2) {
                    this(b2);
                }

                static /* synthetic */ a a() {
                    return new a();
                }

                /*
                 * Unable to fully structure code
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 * Lifted jumps to return sites
                 */
                private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                    try {
                        var1_1 = b.a.b((com.google.protobuf.e)var1_1, var2_2);
                        if (var1_1 == null) return this;
                        this.a((b)var1_1);
                        return this;
                    }
                    catch (com.google.protobuf.o var2_3) {
                        var1_1 = (b)var2_3.a;
                        try {
                            throw var2_3;
                        }
                        catch (Throwable var2_4) {}
                        ** GOTO lbl-1000
                        catch (Throwable var2_6) {
                            var1_1 = null;
                        }
lbl-1000: // 2 sources:
                        {
                            if (var1_1 == null) throw var2_5;
                            this.a((b)var1_1);
                            throw var2_5;
                        }
                    }
                }

                private a a(t t2) {
                    if (t2 instanceof b) {
                        return this.a((b)t2);
                    }
                    super.mergeFrom(t2);
                    return this;
                }

                private a b() {
                    super.clear();
                    this.d = 0;
                    this.c &= -2;
                    this.e = 0;
                    this.c &= -3;
                    return this;
                }

                private a c() {
                    return new a().a(this.f());
                }

                private b d() {
                    b b2 = this.f();
                    if (!b2.isInitialized()) {
                        throw a.newUninitializedMessageException(b2);
                    }
                    return b2;
                }

                /*
                 * Enabled aggressive block sorting
                 */
                private b f() {
                    int n2 = 1;
                    b b2 = new b(this, 0);
                    int n3 = this.c;
                    if ((n3 & 1) != 1) {
                        n2 = 0;
                    }
                    b2.c = this.d;
                    int n4 = n2;
                    if ((n3 & 2) == 2) {
                        n4 = n2 | 2;
                    }
                    b2.d = this.e;
                    b2.b = n4;
                    this.onBuilt();
                    return b2;
                }

                /*
                 * Enabled aggressive block sorting
                 */
                public final a a(b b2) {
                    int n2 = 1;
                    if (b2 == b.a()) {
                        return this;
                    }
                    int n3 = (b2.b & 1) == 1 ? 1 : 0;
                    if (n3 != 0) {
                        n3 = b2.c;
                        this.c |= 1;
                        this.d = n3;
                        this.onChanged();
                    }
                    n3 = (b2.b & 2) == 2 ? n2 : 0;
                    if (n3 != 0) {
                        n3 = b2.d;
                        this.c |= 2;
                        this.e = n3;
                        this.onChanged();
                    }
                    this.mergeUnknownFields(b2.getUnknownFields());
                    return this;
                }

                @Override
                public final /* synthetic */ t build() {
                    return this.d();
                }

                @Override
                public final /* synthetic */ u build() {
                    return this.d();
                }

                @Override
                public final /* synthetic */ t buildPartial() {
                    return this.f();
                }

                @Override
                public final /* synthetic */ u buildPartial() {
                    return this.f();
                }

                @Override
                public final /* synthetic */ a.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ m.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ t.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ u.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ a.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ com.google.protobuf.b$a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ m.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ t.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ u.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ Object clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ t getDefaultInstanceForType() {
                    return b.a();
                }

                @Override
                public final h.a getDescriptorForType() {
                    return g;
                }

                @Override
                protected final m.e internalGetFieldAccessorTable() {
                    return h.a(b.class, a.class);
                }

                @Override
                public final boolean isInitialized() {
                    return true;
                }

                @Override
                public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }

                @Override
                public final /* synthetic */ a.a mergeFrom(t t2) {
                    return this.a(t2);
                }

                @Override
                public final /* synthetic */ com.google.protobuf.b$a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }

                @Override
                public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }

                @Override
                public final /* synthetic */ t.a mergeFrom(t t2) {
                    return this.a(t2);
                }

                @Override
                public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }
            }

        }

    }

    public static final class b
    extends com.google.protobuf.m
    implements f.a {
        public static x<b> a;
        private static final b d;
        int b;
        c c;
        private final af e;
        private Object f;
        private List<d> g;
        private byte h;
        private int i;

        static {
            b b2;
            a = new com.google.protobuf.c<b>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new b(e2, k2, 0);
                }
            };
            d = b2 = new b();
            b2.f();
        }

        private b() {
            this.h = -1;
            this.i = -1;
            this.e = af.b();
        }

        /*
         * Exception decompiling
         */
        private b(com.google.protobuf.e var1_1, com.google.protobuf.k var2_6) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ b(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private b(m.a<?> a2) {
            super(a2);
            this.h = -1;
            this.i = -1;
            this.e = a2.getUnknownFields();
        }

        /* synthetic */ b(m.a a2, byte by2) {
            this(a2);
        }

        public static b a() {
            return d;
        }

        private com.google.protobuf.d e() {
            Object object = this.f;
            if (object instanceof String) {
                this.f = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private void f() {
            this.f = "";
            this.g = Collections.emptyList();
            this.c = c.a();
        }

        private a g() {
            return a.a().a(this);
        }

        public final d a(int n2) {
            return this.g.get(n2);
        }

        public final String b() {
            Object object = this.f;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.f = string;
            }
            return string;
        }

        public final int c() {
            return this.g.size();
        }

        public final boolean d() {
            if ((this.b & 2) == 2) {
                return true;
            }
            return false;
        }

        public final x<b> getParserForType() {
            return a;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int getSerializedSize() {
            int n2;
            int n3 = this.i;
            if (n3 != -1) {
                return n3;
            }
            n3 = (this.b & 1) == 1 ? com.google.protobuf.f.c(1, this.e()) + 0 : 0;
            for (n2 = 0; n2 < this.g.size(); ++n2) {
                int n4 = com.google.protobuf.f.d(2, this.g.get(n2));
                n3 = n4 + n3;
            }
            n2 = n3;
            if ((this.b & 2) == 2) {
                n2 = n3 + com.google.protobuf.f.d(3, this.c);
            }
            this.i = n3 = this.getUnknownFields().getSerializedSize() + n2;
            return n3;
        }

        @Override
        public final af getUnknownFields() {
            return this.e;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return l.a(b.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.h;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.c(); ++n2) {
                if (this.a(n2).isInitialized()) continue;
                this.h = 0;
                return false;
            }
            if (this.d() && !this.c.isInitialized()) {
                this.h = 0;
                return false;
            }
            this.h = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.a();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.g();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.g();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            if ((this.b & 1) == 1) {
                f2.a(1, this.e());
            }
            for (int i2 = 0; i2 < this.g.size(); ++i2) {
                f2.b(2, this.g.get(i2));
            }
            if ((this.b & 2) == 2) {
                f2.b(3, this.c);
            }
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.a<a>
        implements f.a {
            private int c;
            private Object d = "";
            private List<d> e = Collections.emptyList();
            private z<d, d.a, f.a> f;
            private c g = c.a();
            private ab<c, c.a, f.a> h;

            private a() {
                this.b();
            }

            private a(m.b b2) {
                super(b2);
                this.b();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            static /* synthetic */ a a() {
                return new a();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = b.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((b)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (b)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((b)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof b) {
                    return this.a((b)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            private void b() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.h();
                    if (this.h == null) {
                        this.h = new ab(this.g, this.getParentForChildren(), this.b);
                        this.g = null;
                    }
                }
            }

            /*
             * Enabled aggressive block sorting
             */
            private a c() {
                super.clear();
                this.d = "";
                this.c &= -2;
                if (this.f == null) {
                    this.e = Collections.emptyList();
                    this.c &= -3;
                } else {
                    this.f.f();
                }
                if (this.h == null) {
                    this.g = c.a();
                } else {
                    this.h.f();
                }
                this.c &= -5;
                return this;
            }

            private a d() {
                return new a().a(this.g());
            }

            private b f() {
                b b2 = this.g();
                if (!b2.isInitialized()) {
                    throw a.newUninitializedMessageException(b2);
                }
                return b2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private b g() {
                int n2 = 1;
                b b2 = new b(this, 0);
                int n3 = this.c;
                if ((n3 & 1) != 1) {
                    n2 = 0;
                }
                b2.f = this.d;
                if (this.f == null) {
                    if ((this.c & 2) == 2) {
                        this.e = Collections.unmodifiableList(this.e);
                        this.c &= -3;
                    }
                    b2.g = this.e;
                } else {
                    b2.g = this.f.g();
                }
                if ((n3 & 4) == 4) {
                    n2 |= 2;
                }
                if (this.h == null) {
                    b2.c = this.g;
                } else {
                    b2.c = this.h.c();
                }
                b2.b = n2;
                this.onBuilt();
                return b2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<d, d.a, f.a> h() {
                if (this.f == null) {
                    List<d> list = this.e;
                    boolean bl2 = (this.c & 2) == 2;
                    this.f = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.e = null;
                }
                return this.f;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(b b2) {
                boolean bl2 = true;
                Object object = null;
                if (b2 == b.a()) {
                    return this;
                }
                if ((b2.b & 1) != 1) {
                    bl2 = false;
                }
                if (bl2) {
                    this.c |= 1;
                    this.d = b2.f;
                    this.onChanged();
                }
                if (this.f == null) {
                    if (!b2.g.isEmpty()) {
                        if (this.e.isEmpty()) {
                            this.e = b2.g;
                            this.c &= -3;
                        } else {
                            if ((this.c & 2) != 2) {
                                this.e = new ArrayList<d>(this.e);
                                this.c |= 2;
                            }
                            this.e.addAll(b2.g);
                        }
                        this.onChanged();
                    }
                } else if (!b2.g.isEmpty()) {
                    if (this.f.e()) {
                        this.f.a = null;
                        this.f = null;
                        this.e = b2.g;
                        this.c &= -3;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            object = this.h();
                        }
                        this.f = object;
                    } else {
                        this.f.a(b2.g);
                    }
                }
                if (b2.d()) {
                    object = b2.c;
                    if (this.h == null) {
                        this.g = (this.c & 4) == 4 && this.g != c.a() ? c.a(this.g).a((c)object).a() : object;
                        this.onChanged();
                    } else {
                        this.h.b((c)object);
                    }
                    this.c |= 4;
                }
                this.mergeUnknownFields(b2.getUnknownFields());
                return this;
            }

            @Override
            public final /* synthetic */ t build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return b.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return k;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return l.a(b.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                int n3;
                for (n3 = 0; n3 < (n2 = this.f == null ? this.e.size() : this.f.d()); ++n3) {
                    void var1_2;
                    if (this.f == null) {
                        d d2 = this.e.get(n3);
                    } else {
                        d d3 = this.f.a(n3, false);
                    }
                    if (!var1_2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                if ((this.c & 4) != 4) {
                    return true;
                }
                n3 = 1;
                if (n3 == 0) return true;
                {
                    void var1_6;
                    if (this.h == null) {
                        c c2 = this.g;
                    } else {
                        c c3 = this.h.b();
                    }
                    if (var1_6.isInitialized()) return true;
                }
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

    }

    public static final class c
    extends m.d<c>
    implements f.a {
        public static x<c> a;
        private static final c d;
        int b;
        boolean c;
        private final af e;
        private List<p> f;
        private byte g;
        private int h;

        static {
            c c2;
            a = new com.google.protobuf.c<c>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new c(e2, k2, 0);
                }
            };
            d = c2 = new c();
            c2.c();
        }

        private c() {
            this.g = -1;
            this.h = -1;
            this.e = af.b();
        }

        /*
         * Exception decompiling
         */
        private c(com.google.protobuf.e var1_1, com.google.protobuf.k var2_9) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ c(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private c(m.c<c, ?> c2) {
            super(c2);
            this.g = -1;
            this.h = -1;
            this.e = c2.getUnknownFields();
        }

        /* synthetic */ c(m.c c2, byte by2) {
            this(c2);
        }

        public static a a(c c2) {
            return a.d().a(c2);
        }

        public static c a() {
            return d;
        }

        private void c() {
            this.c = true;
            this.f = Collections.emptyList();
        }

        private a d() {
            return a.d().a(this);
        }

        public final x<c> getParserForType() {
            return a;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int getSerializedSize() {
            int n2 = 0;
            int n3 = this.h;
            if (n3 != -1) {
                return n3;
            }
            n3 = (this.b & 1) == 1 ? com.google.protobuf.f.d(2) + 1 + 0 : 0;
            do {
                if (n2 >= this.f.size()) {
                    this.h = n3 = this.i.g() + n3 + this.getUnknownFields().getSerializedSize();
                    return n3;
                }
                int n4 = com.google.protobuf.f.d(999, this.f.get(n2));
                ++n2;
                n3 = n4 + n3;
            } while (true);
        }

        @Override
        public final af getUnknownFields() {
            return this.e;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return z.a(c.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.g;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.f.size(); ++n2) {
                if (this.f.get(n2).isInitialized()) continue;
                this.g = 0;
                return false;
            }
            if (!this.i.f()) {
                this.g = 0;
                return false;
            }
            this.g = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.d();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.d();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.d();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            m.d.a a2 = this.b();
            if ((this.b & 1) == 1) {
                f2.a(2, this.c);
            }
            for (int i2 = 0; i2 < this.f.size(); ++i2) {
                f2.b(999, this.f.get(i2));
            }
            a2.a(f2);
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.c<c, a>
        implements f.a {
            private int d;
            private boolean e = true;
            private List<p> f = Collections.emptyList();
            private z<p, p.a, f.a> g;

            private a() {
                this.f();
            }

            private a(m.b b2) {
                super(b2);
                this.f();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = c.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((c)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (c)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((c)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof c) {
                    return this.a((c)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            static /* synthetic */ a d() {
                return new a();
            }

            private void f() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.j();
                }
            }

            private a g() {
                super.c();
                this.e = true;
                this.d &= -2;
                if (this.g == null) {
                    this.f = Collections.emptyList();
                    this.d &= -3;
                    return this;
                }
                this.g.f();
                return this;
            }

            private a h() {
                return new a().a(this.a());
            }

            private c i() {
                c c2 = this.a();
                if (!c2.isInitialized()) {
                    throw a.newUninitializedMessageException(c2);
                }
                return c2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<p, p.a, f.a> j() {
                if (this.g == null) {
                    List<p> list = this.f;
                    boolean bl2 = (this.d & 2) == 2;
                    this.g = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.f = null;
                }
                return this.g;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(c c2) {
                boolean bl2 = true;
                z<p, p.a, f.a> z2 = null;
                if (c2 == c.a()) {
                    return this;
                }
                if ((c2.b & 1) != 1) {
                    bl2 = false;
                }
                if (bl2) {
                    boolean bl3 = c2.c;
                    this.d |= 1;
                    this.e = bl3;
                    this.onChanged();
                }
                if (this.g == null) {
                    if (!c2.f.isEmpty()) {
                        if (this.f.isEmpty()) {
                            this.f = c2.f;
                            this.d &= -3;
                        } else {
                            if ((this.d & 2) != 2) {
                                this.f = new ArrayList<p>(this.f);
                                this.d |= 2;
                            }
                            this.f.addAll(c2.f);
                        }
                        this.onChanged();
                    }
                } else if (!c2.f.isEmpty()) {
                    if (this.g.e()) {
                        this.g.a = null;
                        this.g = null;
                        this.f = c2.f;
                        this.d &= -3;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z2 = this.j();
                        }
                        this.g = z2;
                    } else {
                        this.g.a(c2.f);
                    }
                }
                this.a(c2);
                this.mergeUnknownFields(c2.getUnknownFields());
                return this;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final c a() {
                int n2 = 1;
                c c2 = new c(this, 0);
                if ((this.d & 1) != 1) {
                    n2 = 0;
                }
                c2.c = this.e;
                if (this.g == null) {
                    if ((this.d & 2) == 2) {
                        this.f = Collections.unmodifiableList(this.f);
                        this.d &= -3;
                    }
                    c2.f = this.f;
                } else {
                    c2.f = this.g.g();
                }
                c2.b = n2;
                this.onBuilt();
                return c2;
            }

            @Override
            public final /* synthetic */ m.c b() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ m.c c() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return c.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return y;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return z.a(c.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                for (int i2 = 0; i2 < (n2 = this.g == null ? this.f.size() : this.g.d()); ++i2) {
                    p p2 = this.g == null ? this.f.get(i2) : this.g.a(i2, false);
                    if (!p2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                if (this.c.f()) return true;
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

    }

    public static final class d
    extends com.google.protobuf.m
    implements f.a {
        public static x<d> a;
        private static final d e;
        int b;
        int c;
        e d;
        private final af f;
        private Object g;
        private byte h;
        private int i;

        static {
            d d2;
            a = new com.google.protobuf.c<d>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new d(e2, k2, 0);
                }
            };
            e = d2 = new d();
            d2.e();
        }

        private d() {
            this.h = -1;
            this.i = -1;
            this.f = af.b();
        }

        /*
         * Exception decompiling
         */
        private d(com.google.protobuf.e var1_1, com.google.protobuf.k var2_6) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ d(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private d(m.a<?> a2) {
            super(a2);
            this.h = -1;
            this.i = -1;
            this.f = a2.getUnknownFields();
        }

        /* synthetic */ d(m.a a2, byte by2) {
            this(a2);
        }

        public static d a() {
            return e;
        }

        private com.google.protobuf.d d() {
            Object object = this.g;
            if (object instanceof String) {
                this.g = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private void e() {
            this.g = "";
            this.c = 0;
            this.d = e.a();
        }

        private a f() {
            return a.a().a(this);
        }

        public final String b() {
            Object object = this.g;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.g = string;
            }
            return string;
        }

        public final boolean c() {
            if ((this.b & 4) == 4) {
                return true;
            }
            return false;
        }

        public final x<d> getParserForType() {
            return a;
        }

        @Override
        public final int getSerializedSize() {
            int n2 = this.i;
            if (n2 != -1) {
                return n2;
            }
            int n3 = 0;
            if ((this.b & 1) == 1) {
                n3 = com.google.protobuf.f.c(1, this.d()) + 0;
            }
            n2 = n3;
            if ((this.b & 2) == 2) {
                n2 = n3 + com.google.protobuf.f.d(2, this.c);
            }
            n3 = n2;
            if ((this.b & 4) == 4) {
                n3 = n2 + com.google.protobuf.f.d(3, this.d);
            }
            this.i = n2 = n3 + this.getUnknownFields().getSerializedSize();
            return n2;
        }

        @Override
        public final af getUnknownFields() {
            return this.f;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return n.a(d.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            byte by2 = this.h;
            if (by2 != -1) {
                if (by2 == 1) {
                    return true;
                }
                return false;
            }
            if (this.c() && !this.d.isInitialized()) {
                this.h = 0;
                return false;
            }
            this.h = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.a();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.f();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.f();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            if ((this.b & 1) == 1) {
                f2.a(1, this.d());
            }
            if ((this.b & 2) == 2) {
                f2.a(2, this.c);
            }
            if ((this.b & 4) == 4) {
                f2.b(3, this.d);
            }
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.a<a>
        implements f.a {
            private int c;
            private Object d = "";
            private int e;
            private e f = e.a();
            private ab<e, e.a, f.a> g;

            private a() {
                this.b();
            }

            private a(m.b b2) {
                super(b2);
                this.b();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            static /* synthetic */ a a() {
                return new a();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = d.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((d)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (d)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((d)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof d) {
                    return this.a((d)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            private void b() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders && this.g == null) {
                    this.g = new ab(this.f, this.getParentForChildren(), this.b);
                    this.f = null;
                }
            }

            /*
             * Enabled aggressive block sorting
             */
            private a c() {
                super.clear();
                this.d = "";
                this.c &= -2;
                this.e = 0;
                this.c &= -3;
                if (this.g == null) {
                    this.f = e.a();
                } else {
                    this.g.f();
                }
                this.c &= -5;
                return this;
            }

            private a d() {
                return new a().a(this.g());
            }

            private d f() {
                d d2 = this.g();
                if (!d2.isInitialized()) {
                    throw a.newUninitializedMessageException(d2);
                }
                return d2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private d g() {
                int n2 = 1;
                d d2 = new d(this, 0);
                int n3 = this.c;
                if ((n3 & 1) != 1) {
                    n2 = 0;
                }
                d2.g = this.d;
                int n4 = n2;
                if ((n3 & 2) == 2) {
                    n4 = n2 | 2;
                }
                d2.c = this.e;
                n2 = (n3 & 4) == 4 ? n4 | 4 : n4;
                if (this.g == null) {
                    d2.d = this.f;
                } else {
                    d2.d = this.g.c();
                }
                d2.b = n2;
                this.onBuilt();
                return d2;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(d d2) {
                int n2 = 1;
                if (d2 == d.a()) {
                    return this;
                }
                int n3 = (d2.b & 1) == 1 ? 1 : 0;
                if (n3 != 0) {
                    this.c |= 1;
                    this.d = d2.g;
                    this.onChanged();
                }
                n3 = (d2.b & 2) == 2 ? n2 : 0;
                if (n3 != 0) {
                    n3 = d2.c;
                    this.c |= 2;
                    this.e = n3;
                    this.onChanged();
                }
                if (d2.c()) {
                    e e2 = d2.d;
                    if (this.g == null) {
                        this.f = (this.c & 4) == 4 && this.f != e.a() ? e.a(this.f).a(e2).a() : e2;
                        this.onChanged();
                    } else {
                        this.g.b(e2);
                    }
                    this.c |= 4;
                }
                this.mergeUnknownFields(d2.getUnknownFields());
                return this;
            }

            @Override
            public final /* synthetic */ t build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return d.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return m;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return n.a(d.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                if ((this.c & 4) != 4) {
                    return true;
                }
                boolean bl2 = true;
                if (bl2) {
                    e e2 = this.g == null ? this.f : this.g.b();
                    if (!e2.isInitialized()) {
                        return false;
                    }
                }
                return true;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

    }

    public static final class e
    extends m.d<e>
    implements f.a {
        public static x<e> a;
        private static final e b;
        private final af c;
        private List<p> d;
        private byte e;
        private int f;

        static {
            e e2;
            a = new com.google.protobuf.c<e>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new e(e2, k2, 0);
                }
            };
            b = e2 = new e();
            e2.d = Collections.emptyList();
        }

        private e() {
            this.e = -1;
            this.f = -1;
            this.c = af.b();
        }

        /*
         * Exception decompiling
         */
        private e(com.google.protobuf.e var1_1, com.google.protobuf.k var2_9) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ e(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private e(m.c<e, ?> c2) {
            super(c2);
            this.e = -1;
            this.f = -1;
            this.c = c2.getUnknownFields();
        }

        /* synthetic */ e(m.c c2, byte by2) {
            this(c2);
        }

        public static a a(e e2) {
            return a.d().a(e2);
        }

        public static e a() {
            return b;
        }

        private a c() {
            return a.d().a(this);
        }

        public final x<e> getParserForType() {
            return a;
        }

        @Override
        public final int getSerializedSize() {
            int n2 = this.f;
            if (n2 != -1) {
                return n2;
            }
            int n3 = 0;
            for (n2 = 0; n2 < this.d.size(); ++n2) {
                n3 += com.google.protobuf.f.d(999, this.d.get(n2));
            }
            this.f = n2 = this.i.g() + n3 + this.getUnknownFields().getSerializedSize();
            return n2;
        }

        @Override
        public final af getUnknownFields() {
            return this.c;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return B.a(e.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.e;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.d.size(); ++n2) {
                if (this.d.get(n2).isInitialized()) continue;
                this.e = 0;
                return false;
            }
            if (!this.i.f()) {
                this.e = 0;
                return false;
            }
            this.e = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.d();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.c();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.c();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            m.d.a a2 = this.b();
            for (int i2 = 0; i2 < this.d.size(); ++i2) {
                f2.b(999, this.d.get(i2));
            }
            a2.a(f2);
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.c<e, a>
        implements f.a {
            private int d;
            private List<p> e = Collections.emptyList();
            private z<p, p.a, f.a> f;

            private a() {
                this.f();
            }

            private a(m.b b2) {
                super(b2);
                this.f();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = e.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((e)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (e)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((e)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof e) {
                    return this.a((e)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            static /* synthetic */ a d() {
                return new a();
            }

            private void f() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.j();
                }
            }

            private a g() {
                super.c();
                if (this.f == null) {
                    this.e = Collections.emptyList();
                    this.d &= -2;
                    return this;
                }
                this.f.f();
                return this;
            }

            private a h() {
                return new a().a(this.a());
            }

            private e i() {
                e e2 = this.a();
                if (!e2.isInitialized()) {
                    throw a.newUninitializedMessageException(e2);
                }
                return e2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<p, p.a, f.a> j() {
                boolean bl2 = true;
                if (this.f != null) return this.f;
                List<p> list = this.e;
                if ((this.d & 1) != 1) {
                    bl2 = false;
                }
                this.f = new z(list, bl2, this.getParentForChildren(), this.b);
                this.e = null;
                return this.f;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(e e2) {
                z<p, p.a, f.a> z2 = null;
                if (e2 == e.a()) {
                    return this;
                }
                if (this.f == null) {
                    if (!e2.d.isEmpty()) {
                        if (this.e.isEmpty()) {
                            this.e = e2.d;
                            this.d &= -2;
                        } else {
                            if ((this.d & 1) != 1) {
                                this.e = new ArrayList<p>(this.e);
                                this.d |= 1;
                            }
                            this.e.addAll(e2.d);
                        }
                        this.onChanged();
                    }
                } else if (!e2.d.isEmpty()) {
                    if (this.f.e()) {
                        this.f.a = null;
                        this.f = null;
                        this.e = e2.d;
                        this.d &= -2;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z2 = this.j();
                        }
                        this.f = z2;
                    } else {
                        this.f.a(e2.d);
                    }
                }
                this.a(e2);
                this.mergeUnknownFields(e2.getUnknownFields());
                return this;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final e a() {
                e e2 = new e(this, 0);
                if (this.f == null) {
                    if ((this.d & 1) == 1) {
                        this.e = Collections.unmodifiableList(this.e);
                        this.d &= -2;
                    }
                    e2.d = this.e;
                } else {
                    e2.d = this.f.g();
                }
                this.onBuilt();
                return e2;
            }

            @Override
            public final /* synthetic */ m.c b() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ m.c c() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return e.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return A;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return B.a(e.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                for (int i2 = 0; i2 < (n2 = this.f == null ? this.e.size() : this.f.d()); ++i2) {
                    p p2 = this.f == null ? this.e.get(i2) : this.f.a(i2, false);
                    if (!p2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                if (this.c.f()) return true;
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

    }

    public static final class f
    extends com.google.protobuf.m
    implements f.a {
        public static x<f> a;
        private static final f g;
        int b;
        int c;
        b d;
        c e;
        g f;
        private final af h;
        private Object i;
        private Object j;
        private Object k;
        private Object l;
        private byte m;
        private int n;

        static {
            f f2;
            a = new com.google.protobuf.c<f>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new f(e2, k2, 0);
                }
            };
            g = f2 = new f();
            f2.o();
        }

        private f() {
            this.m = -1;
            this.n = -1;
            this.h = af.b();
        }

        /*
         * Exception decompiling
         */
        private f(com.google.protobuf.e var1_1, com.google.protobuf.k var2_6) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ f(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private f(m.a<?> a2) {
            super(a2);
            this.m = -1;
            this.n = -1;
            this.h = a2.getUnknownFields();
        }

        /* synthetic */ f(m.a a2, byte by2) {
            this(a2);
        }

        public static f a() {
            return g;
        }

        private com.google.protobuf.d k() {
            Object object = this.i;
            if (object instanceof String) {
                this.i = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private com.google.protobuf.d l() {
            Object object = this.j;
            if (object instanceof String) {
                this.j = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private com.google.protobuf.d m() {
            Object object = this.k;
            if (object instanceof String) {
                this.k = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private com.google.protobuf.d n() {
            Object object = this.l;
            if (object instanceof String) {
                this.l = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private void o() {
            this.i = "";
            this.c = 0;
            this.d = b.a;
            this.e = c.a;
            this.j = "";
            this.k = "";
            this.l = "";
            this.f = g.a();
        }

        private a p() {
            return a.a().a(this);
        }

        public final String b() {
            Object object = this.i;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.i = string;
            }
            return string;
        }

        public final boolean c() {
            if ((this.b & 8) == 8) {
                return true;
            }
            return false;
        }

        public final boolean d() {
            if ((this.b & 16) == 16) {
                return true;
            }
            return false;
        }

        public final String e() {
            Object object = this.j;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.j = string;
            }
            return string;
        }

        public final boolean f() {
            if ((this.b & 32) == 32) {
                return true;
            }
            return false;
        }

        public final String g() {
            Object object = this.k;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.k = string;
            }
            return string;
        }

        public final x<f> getParserForType() {
            return a;
        }

        @Override
        public final int getSerializedSize() {
            int n2 = this.n;
            if (n2 != -1) {
                return n2;
            }
            int n3 = 0;
            if ((this.b & 1) == 1) {
                n3 = com.google.protobuf.f.c(1, this.k()) + 0;
            }
            n2 = n3;
            if ((this.b & 32) == 32) {
                n2 = n3 + com.google.protobuf.f.c(2, this.m());
            }
            n3 = n2;
            if ((this.b & 2) == 2) {
                n3 = n2 + com.google.protobuf.f.d(3, this.c);
            }
            n2 = n3;
            if ((this.b & 4) == 4) {
                n2 = n3 + com.google.protobuf.f.f(4, this.d.getNumber());
            }
            n3 = n2;
            if ((this.b & 8) == 8) {
                n3 = n2 + com.google.protobuf.f.f(5, this.e.getNumber());
            }
            n2 = n3;
            if ((this.b & 16) == 16) {
                n2 = n3 + com.google.protobuf.f.c(6, this.l());
            }
            n3 = n2;
            if ((this.b & 64) == 64) {
                n3 = n2 + com.google.protobuf.f.c(7, this.n());
            }
            n2 = n3;
            if ((this.b & 128) == 128) {
                n2 = n3 + com.google.protobuf.f.d(8, this.f);
            }
            this.n = n2 += this.getUnknownFields().getSerializedSize();
            return n2;
        }

        @Override
        public final af getUnknownFields() {
            return this.h;
        }

        public final boolean h() {
            if ((this.b & 64) == 64) {
                return true;
            }
            return false;
        }

        public final String i() {
            Object object = this.l;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.l = string;
            }
            return string;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return j.a(f.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            byte by2 = this.m;
            if (by2 != -1) {
                if (by2 == 1) {
                    return true;
                }
                return false;
            }
            if (this.j() && !this.f.isInitialized()) {
                this.m = 0;
                return false;
            }
            this.m = 1;
            return true;
        }

        public final boolean j() {
            if ((this.b & 128) == 128) {
                return true;
            }
            return false;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.a();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.p();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.p();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            if ((this.b & 1) == 1) {
                f2.a(1, this.k());
            }
            if ((this.b & 32) == 32) {
                f2.a(2, this.m());
            }
            if ((this.b & 2) == 2) {
                f2.a(3, this.c);
            }
            if ((this.b & 4) == 4) {
                f2.c(4, this.d.getNumber());
            }
            if ((this.b & 8) == 8) {
                f2.c(5, this.e.getNumber());
            }
            if ((this.b & 16) == 16) {
                f2.a(6, this.l());
            }
            if ((this.b & 64) == 64) {
                f2.a(7, this.n());
            }
            if ((this.b & 128) == 128) {
                f2.b(8, this.f);
            }
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.a<a>
        implements f.a {
            private int c;
            private Object d = "";
            private int e;
            private b f = b.a;
            private c g = c.a;
            private Object h = "";
            private Object i = "";
            private Object j = "";
            private g k = g.a();
            private ab<g, g.a, f.a> l;

            private a() {
                this.b();
            }

            private a(m.b b2) {
                super(b2);
                this.b();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            static /* synthetic */ a a() {
                return new a();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = f.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((f)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (f)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((f)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof f) {
                    return this.a((f)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            private void b() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders && this.l == null) {
                    this.l = new ab(this.k, this.getParentForChildren(), this.b);
                    this.k = null;
                }
            }

            /*
             * Enabled aggressive block sorting
             */
            private a c() {
                super.clear();
                this.d = "";
                this.c &= -2;
                this.e = 0;
                this.c &= -3;
                this.f = b.a;
                this.c &= -5;
                this.g = c.a;
                this.c &= -9;
                this.h = "";
                this.c &= -17;
                this.i = "";
                this.c &= -33;
                this.j = "";
                this.c &= -65;
                if (this.l == null) {
                    this.k = g.a();
                } else {
                    this.l.f();
                }
                this.c &= -129;
                return this;
            }

            private a d() {
                return new a().a(this.g());
            }

            private f f() {
                f f2 = this.g();
                if (!f2.isInitialized()) {
                    throw a.newUninitializedMessageException(f2);
                }
                return f2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private f g() {
                int n2 = 1;
                f f2 = new f(this, 0);
                int n3 = this.c;
                if ((n3 & 1) != 1) {
                    n2 = 0;
                }
                f2.i = this.d;
                int n4 = n2;
                if ((n3 & 2) == 2) {
                    n4 = n2 | 2;
                }
                f2.c = this.e;
                n2 = n4;
                if ((n3 & 4) == 4) {
                    n2 = n4 | 4;
                }
                f2.d = this.f;
                n4 = n2;
                if ((n3 & 8) == 8) {
                    n4 = n2 | 8;
                }
                f2.e = this.g;
                n2 = n4;
                if ((n3 & 16) == 16) {
                    n2 = n4 | 16;
                }
                f2.j = this.h;
                n4 = n2;
                if ((n3 & 32) == 32) {
                    n4 = n2 | 32;
                }
                f2.k = this.i;
                n2 = n4;
                if ((n3 & 64) == 64) {
                    n2 = n4 | 64;
                }
                f2.l = this.j;
                n4 = (n3 & 128) == 128 ? n2 | 128 : n2;
                if (this.l == null) {
                    f2.f = this.k;
                } else {
                    f2.f = this.l.c();
                }
                f2.b = n4;
                this.onBuilt();
                return f2;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(f f2) {
                Object object;
                int n2 = 1;
                if (f2 == f.a()) {
                    return this;
                }
                int n3 = (f2.b & 1) == 1 ? 1 : 0;
                if (n3 != 0) {
                    this.c |= 1;
                    this.d = f2.i;
                    this.onChanged();
                }
                n3 = (f2.b & 2) == 2 ? 1 : 0;
                if (n3 != 0) {
                    n3 = f2.c;
                    this.c |= 2;
                    this.e = n3;
                    this.onChanged();
                }
                n3 = (f2.b & 4) == 4 ? n2 : 0;
                if (n3 != 0) {
                    object = f2.d;
                    if (object == null) {
                        throw new NullPointerException();
                    }
                    this.c |= 4;
                    this.f = object;
                    this.onChanged();
                }
                if (f2.c()) {
                    object = f2.e;
                    if (object == null) {
                        throw new NullPointerException();
                    }
                    this.c |= 8;
                    this.g = object;
                    this.onChanged();
                }
                if (f2.d()) {
                    this.c |= 16;
                    this.h = f2.j;
                    this.onChanged();
                }
                if (f2.f()) {
                    this.c |= 32;
                    this.i = f2.k;
                    this.onChanged();
                }
                if (f2.h()) {
                    this.c |= 64;
                    this.j = f2.l;
                    this.onChanged();
                }
                if (f2.j()) {
                    object = f2.f;
                    if (this.l == null) {
                        this.k = (this.c & 128) == 128 && this.k != g.a() ? g.a(this.k).a((g)object).a() : object;
                        this.onChanged();
                    } else {
                        this.l.b((g)object);
                    }
                    this.c |= 128;
                }
                this.mergeUnknownFields(f2.getUnknownFields());
                return this;
            }

            @Override
            public final /* synthetic */ t build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return f.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return i;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return j.a(f.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                if ((this.c & 128) != 128) {
                    return true;
                }
                boolean bl2 = true;
                if (bl2) {
                    g g2 = this.l == null ? this.k : this.l.b();
                    if (!g2.isInitialized()) {
                        return false;
                    }
                }
                return true;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

        public static enum b implements y
        {
            a(0, 1),
            b(1, 2),
            c(2, 3);
            
            private static f.a<b> d;
            private static final b[] e;
            private final int f;
            private final int g;

            static {
                d = new f.a<b>(){};
                e = b.values();
            }

            private b(int n3, int n4) {
                this.f = n3;
                this.g = n4;
            }

            public static b a(int n2) {
                switch (n2) {
                    default: {
                        return null;
                    }
                    case 1: {
                        return a;
                    }
                    case 2: {
                        return b;
                    }
                    case 3: 
                }
                return c;
            }

            @Override
            public final int getNumber() {
                return this.g;
            }

        }

        public static enum c implements y
        {
            a(0, 1),
            b(1, 2),
            c(2, 3),
            d(3, 4),
            e(4, 5),
            f(5, 6),
            g(6, 7),
            h(7, 8),
            i(8, 9),
            j(9, 10),
            k(10, 11),
            l(11, 12),
            m(12, 13),
            n(13, 14),
            o(14, 15),
            p(15, 16),
            q(16, 17),
            r(17, 18);
            
            private static f.a<c> s;
            private static final c[] t;
            private final int u;
            private final int v;

            static {
                s = new f.a<c>(){};
                t = c.values();
            }

            private c(int n3, int n4) {
                this.u = n3;
                this.v = n4;
            }

            public static c a(int n2) {
                switch (n2) {
                    default: {
                        return null;
                    }
                    case 1: {
                        return a;
                    }
                    case 2: {
                        return b;
                    }
                    case 3: {
                        return c;
                    }
                    case 4: {
                        return d;
                    }
                    case 5: {
                        return e;
                    }
                    case 6: {
                        return f;
                    }
                    case 7: {
                        return g;
                    }
                    case 8: {
                        return h;
                    }
                    case 9: {
                        return i;
                    }
                    case 10: {
                        return j;
                    }
                    case 11: {
                        return k;
                    }
                    case 12: {
                        return l;
                    }
                    case 13: {
                        return m;
                    }
                    case 14: {
                        return n;
                    }
                    case 15: {
                        return o;
                    }
                    case 16: {
                        return p;
                    }
                    case 17: {
                        return q;
                    }
                    case 18: 
                }
                return r;
            }

            @Override
            public final int getNumber() {
                return this.v;
            }

        }

    }

    public static final class g
    extends m.d<g>
    implements f.a {
        public static x<g> a;
        private static final g h;
        int b;
        b c;
        boolean d;
        boolean e;
        boolean f;
        boolean g;
        private final af j;
        private Object k;
        private List<p> l;
        private byte m;
        private int n;

        static {
            g g2;
            a = new com.google.protobuf.c<g>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new g(e2, k2, 0);
                }
            };
            h = g2 = new g();
            g2.d();
        }

        private g() {
            this.m = -1;
            this.n = -1;
            this.j = af.b();
        }

        /*
         * Exception decompiling
         */
        private g(com.google.protobuf.e var1_1, com.google.protobuf.k var2_9) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ g(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private g(m.c<g, ?> c2) {
            super(c2);
            this.m = -1;
            this.n = -1;
            this.j = c2.getUnknownFields();
        }

        /* synthetic */ g(m.c c2, byte by2) {
            this(c2);
        }

        public static a a(g g2) {
            return a.d().a(g2);
        }

        public static g a() {
            return h;
        }

        private com.google.protobuf.d c() {
            Object object = this.k;
            if (object instanceof String) {
                this.k = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private void d() {
            this.c = b.a;
            this.d = false;
            this.e = false;
            this.f = false;
            this.k = "";
            this.g = false;
            this.l = Collections.emptyList();
        }

        private a e() {
            return a.d().a(this);
        }

        public final x<g> getParserForType() {
            return a;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int getSerializedSize() {
            int n2 = 0;
            int n3 = this.n;
            if (n3 != -1) {
                return n3;
            }
            int n4 = (this.b & 1) == 1 ? com.google.protobuf.f.f(1, this.c.getNumber()) + 0 : 0;
            n3 = n4;
            if ((this.b & 2) == 2) {
                n3 = n4 + (com.google.protobuf.f.d(2) + 1);
            }
            n4 = n3;
            if ((this.b & 8) == 8) {
                n4 = n3 + (com.google.protobuf.f.d(3) + 1);
            }
            n3 = n4;
            if ((this.b & 4) == 4) {
                n3 = n4 + (com.google.protobuf.f.d(5) + 1);
            }
            n4 = n3;
            if ((this.b & 16) == 16) {
                n4 = n3 + com.google.protobuf.f.c(9, this.c());
            }
            n3 = n4;
            if ((this.b & 32) == 32) {
                n3 = n4 + (com.google.protobuf.f.d(10) + 1);
            }
            n4 = n2;
            do {
                if (n4 >= this.l.size()) {
                    this.n = n3 = this.i.g() + n3 + this.getUnknownFields().getSerializedSize();
                    return n3;
                }
                n2 = com.google.protobuf.f.d(999, this.l.get(n4));
                ++n4;
                n3 = n2 + n3;
            } while (true);
        }

        @Override
        public final af getUnknownFields() {
            return this.j;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return x.a(g.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.m;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.l.size(); ++n2) {
                if (this.l.get(n2).isInitialized()) continue;
                this.m = 0;
                return false;
            }
            if (!this.i.f()) {
                this.m = 0;
                return false;
            }
            this.m = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.d();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.e();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.e();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            m.d.a a2 = this.b();
            if ((this.b & 1) == 1) {
                f2.c(1, this.c.getNumber());
            }
            if ((this.b & 2) == 2) {
                f2.a(2, this.d);
            }
            if ((this.b & 8) == 8) {
                f2.a(3, this.f);
            }
            if ((this.b & 4) == 4) {
                f2.a(5, this.e);
            }
            if ((this.b & 16) == 16) {
                f2.a(9, this.c());
            }
            if ((this.b & 32) == 32) {
                f2.a(10, this.g);
            }
            for (int i2 = 0; i2 < this.l.size(); ++i2) {
                f2.b(999, this.l.get(i2));
            }
            a2.a(f2);
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.c<g, a>
        implements f.a {
            private int d;
            private b e = b.a;
            private boolean f;
            private boolean g;
            private boolean h;
            private Object i = "";
            private boolean j;
            private List<p> k = Collections.emptyList();
            private z<p, p.a, f.a> l;

            private a() {
                this.f();
            }

            private a(m.b b2) {
                super(b2);
                this.f();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = g.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((g)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (g)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((g)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof g) {
                    return this.a((g)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            static /* synthetic */ a d() {
                return new a();
            }

            private void f() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.j();
                }
            }

            private a g() {
                super.c();
                this.e = b.a;
                this.d &= -2;
                this.f = false;
                this.d &= -3;
                this.g = false;
                this.d &= -5;
                this.h = false;
                this.d &= -9;
                this.i = "";
                this.d &= -17;
                this.j = false;
                this.d &= -33;
                if (this.l == null) {
                    this.k = Collections.emptyList();
                    this.d &= -65;
                    return this;
                }
                this.l.f();
                return this;
            }

            private a h() {
                return new a().a(this.a());
            }

            private g i() {
                g g2 = this.a();
                if (!g2.isInitialized()) {
                    throw a.newUninitializedMessageException(g2);
                }
                return g2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<p, p.a, f.a> j() {
                if (this.l == null) {
                    List<p> list = this.k;
                    boolean bl2 = (this.d & 64) == 64;
                    this.l = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.k = null;
                }
                return this.l;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(g g2) {
                boolean bl2;
                z<p, p.a, f.a> z2 = null;
                boolean bl3 = true;
                if (g2 == g.a()) {
                    return this;
                }
                boolean bl4 = (g2.b & 1) == 1;
                if (bl4) {
                    b b2 = g2.c;
                    if (b2 == null) {
                        throw new NullPointerException();
                    }
                    this.d |= 1;
                    this.e = b2;
                    this.onChanged();
                }
                bl4 = (g2.b & 2) == 2;
                if (bl4) {
                    bl2 = g2.d;
                    this.d |= 2;
                    this.f = bl2;
                    this.onChanged();
                }
                bl4 = (g2.b & 4) == 4;
                if (bl4) {
                    bl2 = g2.e;
                    this.d |= 4;
                    this.g = bl2;
                    this.onChanged();
                }
                bl4 = (g2.b & 8) == 8;
                if (bl4) {
                    bl2 = g2.f;
                    this.d |= 8;
                    this.h = bl2;
                    this.onChanged();
                }
                bl4 = (g2.b & 16) == 16;
                if (bl4) {
                    this.d |= 16;
                    this.i = g2.k;
                    this.onChanged();
                }
                bl4 = (g2.b & 32) == 32 ? bl3 : false;
                if (bl4) {
                    bl2 = g2.g;
                    this.d |= 32;
                    this.j = bl2;
                    this.onChanged();
                }
                if (this.l == null) {
                    if (!g2.l.isEmpty()) {
                        if (this.k.isEmpty()) {
                            this.k = g2.l;
                            this.d &= -65;
                        } else {
                            if ((this.d & 64) != 64) {
                                this.k = new ArrayList<p>(this.k);
                                this.d |= 64;
                            }
                            this.k.addAll(g2.l);
                        }
                        this.onChanged();
                    }
                } else if (!g2.l.isEmpty()) {
                    if (this.l.e()) {
                        this.l.a = null;
                        this.l = null;
                        this.k = g2.l;
                        this.d &= -65;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z2 = this.j();
                        }
                        this.l = z2;
                    } else {
                        this.l.a(g2.l);
                    }
                }
                this.a(g2);
                this.mergeUnknownFields(g2.getUnknownFields());
                return this;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final g a() {
                int n2 = 1;
                g g2 = new g(this, 0);
                int n3 = this.d;
                if ((n3 & 1) != 1) {
                    n2 = 0;
                }
                g2.c = this.e;
                int n4 = n2;
                if ((n3 & 2) == 2) {
                    n4 = n2 | 2;
                }
                g2.d = this.f;
                n2 = n4;
                if ((n3 & 4) == 4) {
                    n2 = n4 | 4;
                }
                g2.e = this.g;
                n4 = n2;
                if ((n3 & 8) == 8) {
                    n4 = n2 | 8;
                }
                g2.f = this.h;
                n2 = n4;
                if ((n3 & 16) == 16) {
                    n2 = n4 | 16;
                }
                g2.k = this.i;
                n4 = n2;
                if ((n3 & 32) == 32) {
                    n4 = n2 | 32;
                }
                g2.g = this.j;
                if (this.l == null) {
                    if ((this.d & 64) == 64) {
                        this.k = Collections.unmodifiableList(this.k);
                        this.d &= -65;
                    }
                    g2.l = this.k;
                } else {
                    g2.l = this.l.g();
                }
                g2.b = n4;
                this.onBuilt();
                return g2;
            }

            @Override
            public final /* synthetic */ m.c b() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ m.c c() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return g.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return w;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return x.a(g.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                for (int i2 = 0; i2 < (n2 = this.l == null ? this.k.size() : this.l.d()); ++i2) {
                    p p2 = this.l == null ? this.k.get(i2) : this.l.a(i2, false);
                    if (!p2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                if (this.c.f()) return true;
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

        public static enum b implements y
        {
            a(0, 0),
            b(1, 1),
            c(2, 2);
            
            private static f.a<b> d;
            private static final b[] e;
            private final int f;
            private final int g;

            static {
                d = new f.a<b>(){};
                e = b.values();
            }

            private b(int n3, int n4) {
                this.f = n3;
                this.g = n4;
            }

            public static b a(int n2) {
                switch (n2) {
                    default: {
                        return null;
                    }
                    case 0: {
                        return a;
                    }
                    case 1: {
                        return b;
                    }
                    case 2: 
                }
                return c;
            }

            @Override
            public final int getNumber() {
                return this.g;
            }

        }

    }

    public static final class h
    extends com.google.protobuf.m
    implements f.a {
        public static x<h> a;
        private static final h g;
        int b;
        Object c;
        r d;
        i e;
        o f;
        private final af h;
        private Object i;
        private List<Integer> j;
        private List<Integer> k;
        private List<com.google.protobuf.g$a> l;
        private List<b> m;
        private List<m> n;
        private List<f> o;
        private byte p;
        private int q;

        static {
            h h2;
            a = new com.google.protobuf.c<h>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new h(e2, k2, 0);
                }
            };
            g = h2 = new h();
            h2.l();
        }

        private h() {
            this.p = -1;
            this.q = -1;
            this.h = af.b();
        }

        /*
         * Exception decompiling
         */
        private h(com.google.protobuf.e var1_1, com.google.protobuf.k var2_11) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ h(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private h(m.a<?> a2) {
            super(a2);
            this.p = -1;
            this.q = -1;
            this.h = a2.getUnknownFields();
        }

        /* synthetic */ h(m.a a2, byte by2) {
            this(a2);
        }

        public static h a() {
            return g;
        }

        public static h a(byte[] arrby) {
            return a.a(arrby);
        }

        private com.google.protobuf.d j() {
            Object object = this.i;
            if (object instanceof String) {
                this.i = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private com.google.protobuf.d k() {
            Object object = this.c;
            if (object instanceof String) {
                this.c = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private void l() {
            this.i = "";
            this.c = "";
            this.d = q.a;
            this.j = Collections.emptyList();
            this.k = Collections.emptyList();
            this.l = Collections.emptyList();
            this.m = Collections.emptyList();
            this.n = Collections.emptyList();
            this.o = Collections.emptyList();
            this.e = i.a();
            this.f = o.a();
        }

        private a m() {
            return a.a().a(this);
        }

        public final int a(int n2) {
            return this.j.get(n2);
        }

        public final com.google.protobuf.g$a b(int n2) {
            return this.l.get(n2);
        }

        public final String b() {
            Object object = this.i;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.i = string;
            }
            return string;
        }

        public final int c() {
            return this.d.size();
        }

        public final b c(int n2) {
            return this.m.get(n2);
        }

        public final int d() {
            return this.j.size();
        }

        public final m d(int n2) {
            return this.n.get(n2);
        }

        public final int e() {
            return this.l.size();
        }

        public final f e(int n2) {
            return this.o.get(n2);
        }

        public final int f() {
            return this.m.size();
        }

        public final int g() {
            return this.n.size();
        }

        public final x<h> getParserForType() {
            return a;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int getSerializedSize() {
            int n2;
            int n3 = 0;
            int n4 = this.q;
            if (n4 != -1) {
                return n4;
            }
            n4 = (this.b & 1) == 1 ? com.google.protobuf.f.c(1, this.j()) + 0 : 0;
            int n5 = n4;
            if ((this.b & 2) == 2) {
                n5 = n4 + com.google.protobuf.f.c(2, this.k());
            }
            n4 = 0;
            for (n2 = 0; n2 < this.d.size(); n4 += com.google.protobuf.f.b((com.google.protobuf.d)this.d.a((int)n2)), ++n2) {
            }
            int n6 = this.d.size();
            n2 = 0;
            n4 = n5 + n4 + n6 * 1;
            for (n5 = n2; n5 < this.l.size(); n4 += com.google.protobuf.f.d((int)4, (u)((u)this.l.get((int)n5))), ++n5) {
            }
            for (n5 = 0; n5 < this.m.size(); n4 += com.google.protobuf.f.d((int)5, (u)((u)this.m.get((int)n5))), ++n5) {
            }
            for (n5 = 0; n5 < this.n.size(); n4 += com.google.protobuf.f.d((int)6, (u)((u)this.n.get((int)n5))), ++n5) {
            }
            for (n5 = 0; n5 < this.o.size(); n4 += com.google.protobuf.f.d((int)7, (u)((u)this.o.get((int)n5))), ++n5) {
            }
            n5 = n4;
            if ((this.b & 4) == 4) {
                n5 = n4 + com.google.protobuf.f.d(8, this.e);
            }
            n4 = n5;
            if ((this.b & 8) == 8) {
                n4 = n5 + com.google.protobuf.f.d(9, this.f);
            }
            n5 = 0;
            for (n2 = 0; n2 < this.j.size(); n5 += com.google.protobuf.f.c((int)this.j.get((int)n2).intValue()), ++n2) {
            }
            n6 = this.j.size();
            n2 = 0;
            do {
                if (n3 >= this.k.size()) {
                    this.q = n4 = n4 + n5 + n6 * 1 + n2 + this.k.size() * 1 + this.getUnknownFields().getSerializedSize();
                    return n4;
                }
                int n7 = com.google.protobuf.f.c(this.k.get(n3));
                ++n3;
                n2 = n7 + n2;
            } while (true);
        }

        @Override
        public final af getUnknownFields() {
            return this.h;
        }

        public final int h() {
            return this.o.size();
        }

        public final boolean i() {
            if ((this.b & 4) == 4) {
                return true;
            }
            return false;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return d.a(h.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.p;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.e(); ++n2) {
                if (this.b(n2).isInitialized()) continue;
                this.p = 0;
                return false;
            }
            for (n2 = 0; n2 < this.f(); ++n2) {
                if (this.c(n2).isInitialized()) continue;
                this.p = 0;
                return false;
            }
            for (n2 = 0; n2 < this.g(); ++n2) {
                if (this.d(n2).isInitialized()) continue;
                this.p = 0;
                return false;
            }
            for (n2 = 0; n2 < this.h(); ++n2) {
                if (this.e(n2).isInitialized()) continue;
                this.p = 0;
                return false;
            }
            if (this.i() && !this.e.isInitialized()) {
                this.p = 0;
                return false;
            }
            this.p = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.a();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.m();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.m();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            int n2;
            int n3 = 0;
            this.getSerializedSize();
            if ((this.b & 1) == 1) {
                f2.a(1, this.j());
            }
            if ((this.b & 2) == 2) {
                f2.a(2, this.k());
            }
            for (n2 = 0; n2 < this.d.size(); ++n2) {
                f2.a(3, this.d.a(n2));
            }
            for (n2 = 0; n2 < this.l.size(); ++n2) {
                f2.b(4, this.l.get(n2));
            }
            for (n2 = 0; n2 < this.m.size(); ++n2) {
                f2.b(5, this.m.get(n2));
            }
            for (n2 = 0; n2 < this.n.size(); ++n2) {
                f2.b(6, this.n.get(n2));
            }
            for (n2 = 0; n2 < this.o.size(); ++n2) {
                f2.b(7, this.o.get(n2));
            }
            if ((this.b & 4) == 4) {
                f2.b(8, this.e);
            }
            if ((this.b & 8) == 8) {
                f2.b(9, this.f);
            }
            n2 = 0;
            do {
                if (n2 >= this.j.size()) break;
                f2.a(10, this.j.get(n2));
                ++n2;
            } while (true);
            for (int i2 = n3; i2 < this.k.size(); ++i2) {
                f2.a(11, this.k.get(i2));
            }
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.a<a>
        implements f.a {
            private int c;
            private Object d = "";
            private Object e = "";
            private r f = q.a;
            private List<Integer> g = Collections.emptyList();
            private List<Integer> h = Collections.emptyList();
            private List<com.google.protobuf.g$a> i = Collections.emptyList();
            private z<com.google.protobuf.g$a, a.a, f.a> j;
            private List<b> k = Collections.emptyList();
            private z<b, b.a, f.a> l;
            private List<m> m = Collections.emptyList();
            private z<m, m.a, f.a> n;
            private List<f> o = Collections.emptyList();
            private z<f, f.a, f.a> p;
            private i q = i.a();
            private ab<i, i.a, f.a> r;
            private o s = o.a();
            private ab<o, o.a, f.a> t;

            private a() {
                this.b();
            }

            private a(m.b b2) {
                super(b2);
                this.b();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            static /* synthetic */ a a() {
                return new a();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = h.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((h)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (h)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((h)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof h) {
                    return this.a((h)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            private void b() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.h();
                    this.i();
                    this.j();
                    this.k();
                    if (this.r == null) {
                        this.r = new ab(this.q, this.getParentForChildren(), this.b);
                        this.q = null;
                    }
                    if (this.t == null) {
                        this.t = new ab(this.s, this.getParentForChildren(), this.b);
                        this.s = null;
                    }
                }
            }

            /*
             * Enabled aggressive block sorting
             */
            private a c() {
                super.clear();
                this.d = "";
                this.c &= -2;
                this.e = "";
                this.c &= -3;
                this.f = q.a;
                this.c &= -5;
                this.g = Collections.emptyList();
                this.c &= -9;
                this.h = Collections.emptyList();
                this.c &= -17;
                if (this.j == null) {
                    this.i = Collections.emptyList();
                    this.c &= -33;
                } else {
                    this.j.f();
                }
                if (this.l == null) {
                    this.k = Collections.emptyList();
                    this.c &= -65;
                } else {
                    this.l.f();
                }
                if (this.n == null) {
                    this.m = Collections.emptyList();
                    this.c &= -129;
                } else {
                    this.n.f();
                }
                if (this.p == null) {
                    this.o = Collections.emptyList();
                    this.c &= -257;
                } else {
                    this.p.f();
                }
                if (this.r == null) {
                    this.q = i.a();
                } else {
                    this.r.f();
                }
                this.c &= -513;
                if (this.t == null) {
                    this.s = o.a();
                } else {
                    this.t.f();
                }
                this.c &= -1025;
                return this;
            }

            private a d() {
                return new a().a(this.g());
            }

            private h f() {
                h h2 = this.g();
                if (!h2.isInitialized()) {
                    throw a.newUninitializedMessageException(h2);
                }
                return h2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private h g() {
                int n2 = 1;
                h h2 = new h(this, 0);
                int n3 = this.c;
                if ((n3 & 1) != 1) {
                    n2 = 0;
                }
                h2.i = this.d;
                int n4 = n2;
                if ((n3 & 2) == 2) {
                    n4 = n2 | 2;
                }
                h2.c = this.e;
                if ((this.c & 4) == 4) {
                    this.f = new ag(this.f);
                    this.c &= -5;
                }
                h2.d = this.f;
                if ((this.c & 8) == 8) {
                    this.g = Collections.unmodifiableList(this.g);
                    this.c &= -9;
                }
                h2.j = this.g;
                if ((this.c & 16) == 16) {
                    this.h = Collections.unmodifiableList(this.h);
                    this.c &= -17;
                }
                h2.k = this.h;
                if (this.j == null) {
                    if ((this.c & 32) == 32) {
                        this.i = Collections.unmodifiableList(this.i);
                        this.c &= -33;
                    }
                    h2.l = this.i;
                } else {
                    h2.l = this.j.g();
                }
                if (this.l == null) {
                    if ((this.c & 64) == 64) {
                        this.k = Collections.unmodifiableList(this.k);
                        this.c &= -65;
                    }
                    h2.m = this.k;
                } else {
                    h2.m = this.l.g();
                }
                if (this.n == null) {
                    if ((this.c & 128) == 128) {
                        this.m = Collections.unmodifiableList(this.m);
                        this.c &= -129;
                    }
                    h2.n = this.m;
                } else {
                    h2.n = this.n.g();
                }
                if (this.p == null) {
                    if ((this.c & 256) == 256) {
                        this.o = Collections.unmodifiableList(this.o);
                        this.c &= -257;
                    }
                    h2.o = this.o;
                } else {
                    h2.o = this.p.g();
                }
                n2 = (n3 & 512) == 512 ? n4 | 4 : n4;
                if (this.r == null) {
                    h2.e = this.q;
                } else {
                    h2.e = this.r.c();
                }
                n4 = n2;
                if ((n3 & 1024) == 1024) {
                    n4 = n2 | 8;
                }
                if (this.t == null) {
                    h2.f = this.s;
                } else {
                    h2.f = this.t.c();
                }
                h2.b = n4;
                this.onBuilt();
                return h2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<com.google.protobuf.g$a, a.a, f.a> h() {
                if (this.j == null) {
                    List<com.google.protobuf.g$a> list = this.i;
                    boolean bl2 = (this.c & 32) == 32;
                    this.j = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.i = null;
                }
                return this.j;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<b, b.a, f.a> i() {
                if (this.l == null) {
                    List<b> list = this.k;
                    boolean bl2 = (this.c & 64) == 64;
                    this.l = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.k = null;
                }
                return this.l;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<m, m.a, f.a> j() {
                if (this.n == null) {
                    List<m> list = this.m;
                    boolean bl2 = (this.c & 128) == 128;
                    this.n = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.m = null;
                }
                return this.n;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<f, f.a, f.a> k() {
                if (this.p == null) {
                    List<f> list = this.o;
                    boolean bl2 = (this.c & 256) == 256;
                    this.p = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.o = null;
                }
                return this.p;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(h h2) {
                Object var3_2 = null;
                if (h2 == h.a()) {
                    return this;
                }
                boolean bl2 = (h2.b & 1) == 1;
                if (bl2) {
                    this.c |= 1;
                    this.d = h2.i;
                    this.onChanged();
                }
                bl2 = (h2.b & 2) == 2;
                if (bl2) {
                    this.c |= 2;
                    this.e = h2.c;
                    this.onChanged();
                }
                if (!h2.d.isEmpty()) {
                    if (this.f.isEmpty()) {
                        this.f = h2.d;
                        this.c &= -5;
                    } else {
                        if ((this.c & 4) != 4) {
                            this.f = new q(this.f);
                            this.c |= 4;
                        }
                        this.f.addAll(h2.d);
                    }
                    this.onChanged();
                }
                if (!h2.j.isEmpty()) {
                    if (this.g.isEmpty()) {
                        this.g = h2.j;
                        this.c &= -9;
                    } else {
                        if ((this.c & 8) != 8) {
                            this.g = new ArrayList<Integer>(this.g);
                            this.c |= 8;
                        }
                        this.g.addAll(h2.j);
                    }
                    this.onChanged();
                }
                if (!h2.k.isEmpty()) {
                    if (this.h.isEmpty()) {
                        this.h = h2.k;
                        this.c &= -17;
                    } else {
                        if ((this.c & 16) != 16) {
                            this.h = new ArrayList<Integer>(this.h);
                            this.c |= 16;
                        }
                        this.h.addAll(h2.k);
                    }
                    this.onChanged();
                }
                if (this.j == null) {
                    if (!h2.l.isEmpty()) {
                        if (this.i.isEmpty()) {
                            this.i = h2.l;
                            this.c &= -33;
                        } else {
                            if ((this.c & 32) != 32) {
                                this.i = new ArrayList<com.google.protobuf.g$a>(this.i);
                                this.c |= 32;
                            }
                            this.i.addAll(h2.l);
                        }
                        this.onChanged();
                    }
                } else if (!h2.l.isEmpty()) {
                    if (this.j.e()) {
                        void var2_4;
                        this.j.a = null;
                        this.j = null;
                        this.i = h2.l;
                        this.c &= -33;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z<com.google.protobuf.g$a, a.a, f.a> z2 = this.h();
                        } else {
                            Object var2_12 = null;
                        }
                        this.j = var2_4;
                    } else {
                        this.j.a(h2.l);
                    }
                }
                if (this.l == null) {
                    if (!h2.m.isEmpty()) {
                        if (this.k.isEmpty()) {
                            this.k = h2.m;
                            this.c &= -65;
                        } else {
                            if ((this.c & 64) != 64) {
                                this.k = new ArrayList<b>(this.k);
                                this.c |= 64;
                            }
                            this.k.addAll(h2.m);
                        }
                        this.onChanged();
                    }
                } else if (!h2.m.isEmpty()) {
                    if (this.l.e()) {
                        void var2_14;
                        this.l.a = null;
                        this.l = null;
                        this.k = h2.m;
                        this.c &= -65;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z<b, b.a, f.a> z3 = this.i();
                        } else {
                            Object var2_15 = null;
                        }
                        this.l = var2_14;
                    } else {
                        this.l.a(h2.m);
                    }
                }
                if (this.n == null) {
                    if (!h2.n.isEmpty()) {
                        if (this.m.isEmpty()) {
                            this.m = h2.n;
                            this.c &= -129;
                        } else {
                            if ((this.c & 128) != 128) {
                                this.m = new ArrayList<m>(this.m);
                                this.c |= 128;
                            }
                            this.m.addAll(h2.n);
                        }
                        this.onChanged();
                    }
                } else if (!h2.n.isEmpty()) {
                    if (this.n.e()) {
                        void var2_17;
                        this.n.a = null;
                        this.n = null;
                        this.m = h2.n;
                        this.c &= -129;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z<m, m.a, f.a> z4 = this.j();
                        } else {
                            Object var2_18 = null;
                        }
                        this.n = var2_17;
                    } else {
                        this.n.a(h2.n);
                    }
                }
                if (this.p == null) {
                    if (!h2.o.isEmpty()) {
                        if (this.o.isEmpty()) {
                            this.o = h2.o;
                            this.c &= -257;
                        } else {
                            if ((this.c & 256) != 256) {
                                this.o = new ArrayList<f>(this.o);
                                this.c |= 256;
                            }
                            this.o.addAll(h2.o);
                        }
                        this.onChanged();
                    }
                } else if (!h2.o.isEmpty()) {
                    if (this.p.e()) {
                        void var2_21;
                        this.p.a = null;
                        this.p = null;
                        this.o = h2.o;
                        this.c &= -257;
                        Object var2_19 = var3_2;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z<f, f.a, f.a> z5 = this.k();
                        }
                        this.p = var2_21;
                    } else {
                        this.p.a(h2.o);
                    }
                }
                if (h2.i()) {
                    i i2 = h2.e;
                    if (this.r == null) {
                        this.q = (this.c & 512) == 512 && this.q != i.a() ? i.a(this.q).a(i2).a() : i2;
                        this.onChanged();
                    } else {
                        this.r.b(i2);
                    }
                    this.c |= 512;
                }
                bl2 = (h2.b & 8) == 8;
                if (bl2) {
                    o o2 = h2.f;
                    if (this.t == null) {
                        this.s = (this.c & 1024) == 1024 && this.s != o.a() ? o.a(this.s).a(o2).a() : o2;
                        this.onChanged();
                    } else {
                        this.t.b(o2);
                    }
                    this.c |= 1024;
                }
                this.mergeUnknownFields(h2.getUnknownFields());
                return this;
            }

            @Override
            public final /* synthetic */ t build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return h.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return c;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return d.a(h.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                int n3;
                for (n3 = 0; n3 < (n2 = this.j == null ? this.i.size() : this.j.d()); ++n3) {
                    void var1_2;
                    if (this.j == null) {
                        com.google.protobuf.g$a a2 = this.i.get(n3);
                    } else {
                        com.google.protobuf.g$a a3 = this.j.a(n3, false);
                    }
                    if (!var1_2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                n3 = 0;
                do {
                    void var1_7;
                    n2 = this.l == null ? this.k.size() : this.l.d();
                    if (n3 >= n2) break;
                    if (this.l == null) {
                        b b2 = this.k.get(n3);
                    } else {
                        b b3 = this.l.a(n3, false);
                    }
                    if (!var1_7.isInitialized()) return false;
                    {
                        ++n3;
                        continue;
                    }
                    break;
                } while (true);
                n3 = 0;
                do {
                    void var1_11;
                    n2 = this.n == null ? this.m.size() : this.n.d();
                    if (n3 >= n2) break;
                    if (this.n == null) {
                        m m2 = this.m.get(n3);
                    } else {
                        m m3 = this.n.a(n3, false);
                    }
                    if (!var1_11.isInitialized()) return false;
                    {
                        ++n3;
                        continue;
                    }
                    break;
                } while (true);
                n3 = 0;
                do {
                    void var1_15;
                    n2 = this.p == null ? this.o.size() : this.p.d();
                    if (n3 >= n2) break;
                    if (this.p == null) {
                        f f2 = this.o.get(n3);
                    } else {
                        f f3 = this.p.a(n3, false);
                    }
                    if (!var1_15.isInitialized()) return false;
                    {
                        ++n3;
                        continue;
                    }
                    break;
                } while (true);
                if ((this.c & 512) != 512) {
                    return true;
                }
                n3 = 1;
                if (n3 == 0) return true;
                {
                    void var1_18;
                    if (this.r == null) {
                        i i2 = this.q;
                    } else {
                        i i3 = this.r.b();
                    }
                    if (var1_18.isInitialized()) return true;
                }
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

    }

    public static final class i
    extends m.d<i>
    implements f.a {
        public static x<i> a;
        private static final i j;
        int b;
        boolean c;
        boolean d;
        b e;
        boolean f;
        boolean g;
        boolean h;
        private final af k;
        private Object l;
        private Object m;
        private Object n;
        private List<p> o;
        private byte p;
        private int q;

        static {
            i i2;
            a = new com.google.protobuf.c<i>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new i(e2, k2, 0);
                }
            };
            j = i2 = new i();
            i2.f();
        }

        private i() {
            this.p = -1;
            this.q = -1;
            this.k = af.b();
        }

        /*
         * Exception decompiling
         */
        private i(com.google.protobuf.e var1_1, com.google.protobuf.k var2_9) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ i(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private i(m.c<i, ?> c2) {
            super(c2);
            this.p = -1;
            this.q = -1;
            this.k = c2.getUnknownFields();
        }

        /* synthetic */ i(m.c c2, byte by2) {
            this(c2);
        }

        public static a a(i i2) {
            return a.d().a(i2);
        }

        public static i a() {
            return j;
        }

        private com.google.protobuf.d c() {
            Object object = this.l;
            if (object instanceof String) {
                this.l = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private com.google.protobuf.d d() {
            Object object = this.m;
            if (object instanceof String) {
                this.m = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private com.google.protobuf.d e() {
            Object object = this.n;
            if (object instanceof String) {
                this.n = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private void f() {
            this.l = "";
            this.m = "";
            this.c = false;
            this.d = false;
            this.e = b.a;
            this.n = "";
            this.f = false;
            this.g = false;
            this.h = false;
            this.o = Collections.emptyList();
        }

        private a g() {
            return a.d().a(this);
        }

        public final x<i> getParserForType() {
            return a;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int getSerializedSize() {
            int n2 = 0;
            int n3 = this.q;
            if (n3 != -1) {
                return n3;
            }
            int n4 = (this.b & 1) == 1 ? com.google.protobuf.f.c(1, this.c()) + 0 : 0;
            n3 = n4;
            if ((this.b & 2) == 2) {
                n3 = n4 + com.google.protobuf.f.c(8, this.d());
            }
            n4 = n3;
            if ((this.b & 16) == 16) {
                n4 = n3 + com.google.protobuf.f.f(9, this.e.getNumber());
            }
            n3 = n4;
            if ((this.b & 4) == 4) {
                n3 = n4 + (com.google.protobuf.f.d(10) + 1);
            }
            n4 = n3;
            if ((this.b & 32) == 32) {
                n4 = n3 + com.google.protobuf.f.c(11, this.e());
            }
            n3 = n4;
            if ((this.b & 64) == 64) {
                n3 = n4 + (com.google.protobuf.f.d(16) + 1);
            }
            n4 = n3;
            if ((this.b & 128) == 128) {
                n4 = n3 + (com.google.protobuf.f.d(17) + 1);
            }
            n3 = n4;
            if ((this.b & 256) == 256) {
                n3 = n4 + (com.google.protobuf.f.d(18) + 1);
            }
            n4 = n3;
            if ((this.b & 8) == 8) {
                n4 = n3 + (com.google.protobuf.f.d(20) + 1);
            }
            n3 = n4;
            n4 = n2;
            do {
                if (n4 >= this.o.size()) {
                    this.q = n3 = this.i.g() + n3 + this.getUnknownFields().getSerializedSize();
                    return n3;
                }
                n2 = com.google.protobuf.f.d(999, this.o.get(n4));
                ++n4;
                n3 = n2 + n3;
            } while (true);
        }

        @Override
        public final af getUnknownFields() {
            return this.k;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return t.a(i.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.p;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.o.size(); ++n2) {
                if (this.o.get(n2).isInitialized()) continue;
                this.p = 0;
                return false;
            }
            if (!this.i.f()) {
                this.p = 0;
                return false;
            }
            this.p = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.d();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.g();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.g();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            m.d.a a2 = this.b();
            if ((this.b & 1) == 1) {
                f2.a(1, this.c());
            }
            if ((this.b & 2) == 2) {
                f2.a(8, this.d());
            }
            if ((this.b & 16) == 16) {
                f2.c(9, this.e.getNumber());
            }
            if ((this.b & 4) == 4) {
                f2.a(10, this.c);
            }
            if ((this.b & 32) == 32) {
                f2.a(11, this.e());
            }
            if ((this.b & 64) == 64) {
                f2.a(16, this.f);
            }
            if ((this.b & 128) == 128) {
                f2.a(17, this.g);
            }
            if ((this.b & 256) == 256) {
                f2.a(18, this.h);
            }
            if ((this.b & 8) == 8) {
                f2.a(20, this.d);
            }
            for (int i2 = 0; i2 < this.o.size(); ++i2) {
                f2.b(999, this.o.get(i2));
            }
            a2.a(f2);
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.c<i, a>
        implements f.a {
            private int d;
            private Object e = "";
            private Object f = "";
            private boolean g;
            private boolean h;
            private b i = b.a;
            private Object j = "";
            private boolean k;
            private boolean l;
            private boolean m;
            private List<p> n = Collections.emptyList();
            private z<p, p.a, f.a> o;

            private a() {
                this.f();
            }

            private a(m.b b2) {
                super(b2);
                this.f();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = i.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((i)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (i)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((i)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof i) {
                    return this.a((i)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            static /* synthetic */ a d() {
                return new a();
            }

            private void f() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.j();
                }
            }

            private a g() {
                super.c();
                this.e = "";
                this.d &= -2;
                this.f = "";
                this.d &= -3;
                this.g = false;
                this.d &= -5;
                this.h = false;
                this.d &= -9;
                this.i = b.a;
                this.d &= -17;
                this.j = "";
                this.d &= -33;
                this.k = false;
                this.d &= -65;
                this.l = false;
                this.d &= -129;
                this.m = false;
                this.d &= -257;
                if (this.o == null) {
                    this.n = Collections.emptyList();
                    this.d &= -513;
                    return this;
                }
                this.o.f();
                return this;
            }

            private a h() {
                return new a().a(this.a());
            }

            private i i() {
                i i2 = this.a();
                if (!i2.isInitialized()) {
                    throw a.newUninitializedMessageException(i2);
                }
                return i2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<p, p.a, f.a> j() {
                if (this.o == null) {
                    List<p> list = this.n;
                    boolean bl2 = (this.d & 512) == 512;
                    this.o = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.n = null;
                }
                return this.o;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(i i2) {
                boolean bl2;
                z<p, p.a, f.a> z2 = null;
                boolean bl3 = true;
                if (i2 == i.a()) {
                    return this;
                }
                boolean bl4 = (i2.b & 1) == 1;
                if (bl4) {
                    this.d |= 1;
                    this.e = i2.l;
                    this.onChanged();
                }
                bl4 = (i2.b & 2) == 2;
                if (bl4) {
                    this.d |= 2;
                    this.f = i2.m;
                    this.onChanged();
                }
                bl4 = (i2.b & 4) == 4;
                if (bl4) {
                    bl2 = i2.c;
                    this.d |= 4;
                    this.g = bl2;
                    this.onChanged();
                }
                bl4 = (i2.b & 8) == 8;
                if (bl4) {
                    bl2 = i2.d;
                    this.d |= 8;
                    this.h = bl2;
                    this.onChanged();
                }
                bl4 = (i2.b & 16) == 16;
                if (bl4) {
                    b b2 = i2.e;
                    if (b2 == null) {
                        throw new NullPointerException();
                    }
                    this.d |= 16;
                    this.i = b2;
                    this.onChanged();
                }
                bl4 = (i2.b & 32) == 32;
                if (bl4) {
                    this.d |= 32;
                    this.j = i2.n;
                    this.onChanged();
                }
                bl4 = (i2.b & 64) == 64;
                if (bl4) {
                    bl2 = i2.f;
                    this.d |= 64;
                    this.k = bl2;
                    this.onChanged();
                }
                bl4 = (i2.b & 128) == 128;
                if (bl4) {
                    bl2 = i2.g;
                    this.d |= 128;
                    this.l = bl2;
                    this.onChanged();
                }
                bl4 = (i2.b & 256) == 256 ? bl3 : false;
                if (bl4) {
                    bl2 = i2.h;
                    this.d |= 256;
                    this.m = bl2;
                    this.onChanged();
                }
                if (this.o == null) {
                    if (!i2.o.isEmpty()) {
                        if (this.n.isEmpty()) {
                            this.n = i2.o;
                            this.d &= -513;
                        } else {
                            if ((this.d & 512) != 512) {
                                this.n = new ArrayList<p>(this.n);
                                this.d |= 512;
                            }
                            this.n.addAll(i2.o);
                        }
                        this.onChanged();
                    }
                } else if (!i2.o.isEmpty()) {
                    if (this.o.e()) {
                        this.o.a = null;
                        this.o = null;
                        this.n = i2.o;
                        this.d &= -513;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z2 = this.j();
                        }
                        this.o = z2;
                    } else {
                        this.o.a(i2.o);
                    }
                }
                this.a(i2);
                this.mergeUnknownFields(i2.getUnknownFields());
                return this;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final i a() {
                int n2 = 1;
                i i2 = new i(this, 0);
                int n3 = this.d;
                if ((n3 & 1) != 1) {
                    n2 = 0;
                }
                i2.l = this.e;
                int n4 = n2;
                if ((n3 & 2) == 2) {
                    n4 = n2 | 2;
                }
                i2.m = this.f;
                n2 = n4;
                if ((n3 & 4) == 4) {
                    n2 = n4 | 4;
                }
                i2.c = this.g;
                n4 = n2;
                if ((n3 & 8) == 8) {
                    n4 = n2 | 8;
                }
                i2.d = this.h;
                n2 = n4;
                if ((n3 & 16) == 16) {
                    n2 = n4 | 16;
                }
                i2.e = this.i;
                n4 = n2;
                if ((n3 & 32) == 32) {
                    n4 = n2 | 32;
                }
                i2.n = this.j;
                n2 = n4;
                if ((n3 & 64) == 64) {
                    n2 = n4 | 64;
                }
                i2.f = this.k;
                n4 = n2;
                if ((n3 & 128) == 128) {
                    n4 = n2 | 128;
                }
                i2.g = this.l;
                n2 = n4;
                if ((n3 & 256) == 256) {
                    n2 = n4 | 256;
                }
                i2.h = this.m;
                if (this.o == null) {
                    if ((this.d & 512) == 512) {
                        this.n = Collections.unmodifiableList(this.n);
                        this.d &= -513;
                    }
                    i2.o = this.n;
                } else {
                    i2.o = this.o.g();
                }
                i2.b = n2;
                this.onBuilt();
                return i2;
            }

            @Override
            public final /* synthetic */ m.c b() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ m.c c() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return i.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return s;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return t.a(i.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                for (int i2 = 0; i2 < (n2 = this.o == null ? this.n.size() : this.o.d()); ++i2) {
                    p p2 = this.o == null ? this.n.get(i2) : this.o.a(i2, false);
                    if (!p2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                if (this.c.f()) return true;
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

        public static enum b implements y
        {
            a(0, 1),
            b(1, 2),
            c(2, 3);
            
            private static f.a<b> d;
            private static final b[] e;
            private final int f;
            private final int g;

            static {
                d = new f.a<b>(){};
                e = b.values();
            }

            private b(int n3, int n4) {
                this.f = n3;
                this.g = n4;
            }

            public static b a(int n2) {
                switch (n2) {
                    default: {
                        return null;
                    }
                    case 1: {
                        return a;
                    }
                    case 2: {
                        return b;
                    }
                    case 3: 
                }
                return c;
            }

            @Override
            public final int getNumber() {
                return this.g;
            }

        }

    }

    public static final class j
    extends m.d<j>
    implements f.a {
        public static x<j> a;
        private static final j e;
        int b;
        boolean c;
        boolean d;
        private final af f;
        private List<p> g;
        private byte h;
        private int j;

        static {
            j j2;
            a = new com.google.protobuf.c<j>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new j(e2, k2, 0);
                }
            };
            e = j2 = new j();
            j2.c();
        }

        private j() {
            this.h = -1;
            this.j = -1;
            this.f = af.b();
        }

        /*
         * Exception decompiling
         */
        private j(com.google.protobuf.e var1_1, com.google.protobuf.k var2_9) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ j(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private j(m.c<j, ?> c2) {
            super(c2);
            this.h = -1;
            this.j = -1;
            this.f = c2.getUnknownFields();
        }

        /* synthetic */ j(m.c c2, byte by2) {
            this(c2);
        }

        public static a a(j j2) {
            return a.d().a(j2);
        }

        public static j a() {
            return e;
        }

        private void c() {
            this.c = false;
            this.d = false;
            this.g = Collections.emptyList();
        }

        private a d() {
            return a.d().a(this);
        }

        public final x<j> getParserForType() {
            return a;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int getSerializedSize() {
            int n2 = 0;
            int n3 = this.j;
            if (n3 != -1) {
                return n3;
            }
            n3 = (this.b & 1) == 1 ? com.google.protobuf.f.d(1) + 1 + 0 : 0;
            int n4 = n3;
            if ((this.b & 2) == 2) {
                n4 = n3 + (com.google.protobuf.f.d(2) + 1);
            }
            n3 = n4;
            n4 = n2;
            do {
                if (n4 >= this.g.size()) {
                    this.j = n3 = this.i.g() + n3 + this.getUnknownFields().getSerializedSize();
                    return n3;
                }
                n2 = com.google.protobuf.f.d(999, this.g.get(n4));
                ++n4;
                n3 = n2 + n3;
            } while (true);
        }

        @Override
        public final af getUnknownFields() {
            return this.f;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return v.a(j.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.h;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.g.size(); ++n2) {
                if (this.g.get(n2).isInitialized()) continue;
                this.h = 0;
                return false;
            }
            if (!this.i.f()) {
                this.h = 0;
                return false;
            }
            this.h = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.d();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.d();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.d();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            m.d.a a2 = this.b();
            if ((this.b & 1) == 1) {
                f2.a(1, this.c);
            }
            if ((this.b & 2) == 2) {
                f2.a(2, this.d);
            }
            for (int i2 = 0; i2 < this.g.size(); ++i2) {
                f2.b(999, this.g.get(i2));
            }
            a2.a(f2);
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.c<j, a>
        implements f.a {
            private int d;
            private boolean e;
            private boolean f;
            private List<p> g = Collections.emptyList();
            private z<p, p.a, f.a> h;

            private a() {
                this.f();
            }

            private a(m.b b2) {
                super(b2);
                this.f();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = j.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((j)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (j)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((j)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof j) {
                    return this.a((j)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            static /* synthetic */ a d() {
                return new a();
            }

            private void f() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.j();
                }
            }

            private a g() {
                super.c();
                this.e = false;
                this.d &= -2;
                this.f = false;
                this.d &= -3;
                if (this.h == null) {
                    this.g = Collections.emptyList();
                    this.d &= -5;
                    return this;
                }
                this.h.f();
                return this;
            }

            private a h() {
                return new a().a(this.a());
            }

            private j i() {
                j j2 = this.a();
                if (!j2.isInitialized()) {
                    throw a.newUninitializedMessageException(j2);
                }
                return j2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<p, p.a, f.a> j() {
                if (this.h == null) {
                    List<p> list = this.g;
                    boolean bl2 = (this.d & 4) == 4;
                    this.h = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.g = null;
                }
                return this.h;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(j j2) {
                boolean bl2;
                z<p, p.a, f.a> z2 = null;
                boolean bl3 = true;
                if (j2 == j.a()) {
                    return this;
                }
                boolean bl4 = (j2.b & 1) == 1;
                if (bl4) {
                    bl2 = j2.c;
                    this.d |= 1;
                    this.e = bl2;
                    this.onChanged();
                }
                bl4 = (j2.b & 2) == 2 ? bl3 : false;
                if (bl4) {
                    bl2 = j2.d;
                    this.d |= 2;
                    this.f = bl2;
                    this.onChanged();
                }
                if (this.h == null) {
                    if (!j2.g.isEmpty()) {
                        if (this.g.isEmpty()) {
                            this.g = j2.g;
                            this.d &= -5;
                        } else {
                            if ((this.d & 4) != 4) {
                                this.g = new ArrayList<p>(this.g);
                                this.d |= 4;
                            }
                            this.g.addAll(j2.g);
                        }
                        this.onChanged();
                    }
                } else if (!j2.g.isEmpty()) {
                    if (this.h.e()) {
                        this.h.a = null;
                        this.h = null;
                        this.g = j2.g;
                        this.d &= -5;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z2 = this.j();
                        }
                        this.h = z2;
                    } else {
                        this.h.a(j2.g);
                    }
                }
                this.a(j2);
                this.mergeUnknownFields(j2.getUnknownFields());
                return this;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final j a() {
                int n2 = 1;
                j j2 = new j(this, 0);
                int n3 = this.d;
                if ((n3 & 1) != 1) {
                    n2 = 0;
                }
                j2.c = this.e;
                int n4 = n2;
                if ((n3 & 2) == 2) {
                    n4 = n2 | 2;
                }
                j2.d = this.f;
                if (this.h == null) {
                    if ((this.d & 4) == 4) {
                        this.g = Collections.unmodifiableList(this.g);
                        this.d &= -5;
                    }
                    j2.g = this.g;
                } else {
                    j2.g = this.h.g();
                }
                j2.b = n4;
                this.onBuilt();
                return j2;
            }

            @Override
            public final /* synthetic */ m.c b() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ m.c c() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return j.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return u;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return v.a(j.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                for (int i2 = 0; i2 < (n2 = this.h == null ? this.g.size() : this.h.d()); ++i2) {
                    p p2 = this.h == null ? this.g.get(i2) : this.h.a(i2, false);
                    if (!p2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                if (this.c.f()) return true;
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

    }

    public static final class k
    extends com.google.protobuf.m
    implements f.a {
        public static x<k> a;
        private static final k d;
        int b;
        l c;
        private final af e;
        private Object f;
        private Object g;
        private Object h;
        private byte i;
        private int j;

        static {
            k k2;
            a = new com.google.protobuf.c<k>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new k(e2, k2, 0);
                }
            };
            d = k2 = new k();
            k2.i();
        }

        private k() {
            this.i = -1;
            this.j = -1;
            this.e = af.b();
        }

        /*
         * Exception decompiling
         */
        private k(com.google.protobuf.e var1_1, com.google.protobuf.k var2_6) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ k(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private k(m.a<?> a2) {
            super(a2);
            this.i = -1;
            this.j = -1;
            this.e = a2.getUnknownFields();
        }

        /* synthetic */ k(m.a a2, byte by2) {
            this(a2);
        }

        public static k a() {
            return d;
        }

        private com.google.protobuf.d f() {
            Object object = this.f;
            if (object instanceof String) {
                this.f = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private com.google.protobuf.d g() {
            Object object = this.g;
            if (object instanceof String) {
                this.g = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private com.google.protobuf.d h() {
            Object object = this.h;
            if (object instanceof String) {
                this.h = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private void i() {
            this.f = "";
            this.g = "";
            this.h = "";
            this.c = l.a();
        }

        private a j() {
            return a.a().a(this);
        }

        public final String b() {
            Object object = this.f;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.f = string;
            }
            return string;
        }

        public final String c() {
            Object object = this.g;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.g = string;
            }
            return string;
        }

        public final String d() {
            Object object = this.h;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.h = string;
            }
            return string;
        }

        public final boolean e() {
            if ((this.b & 8) == 8) {
                return true;
            }
            return false;
        }

        public final x<k> getParserForType() {
            return a;
        }

        @Override
        public final int getSerializedSize() {
            int n2 = this.j;
            if (n2 != -1) {
                return n2;
            }
            int n3 = 0;
            if ((this.b & 1) == 1) {
                n3 = com.google.protobuf.f.c(1, this.f()) + 0;
            }
            n2 = n3;
            if ((this.b & 2) == 2) {
                n2 = n3 + com.google.protobuf.f.c(2, this.g());
            }
            n3 = n2;
            if ((this.b & 4) == 4) {
                n3 = n2 + com.google.protobuf.f.c(3, this.h());
            }
            n2 = n3;
            if ((this.b & 8) == 8) {
                n2 = n3 + com.google.protobuf.f.d(4, this.c);
            }
            this.j = n2 += this.getUnknownFields().getSerializedSize();
            return n2;
        }

        @Override
        public final af getUnknownFields() {
            return this.e;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return r.a(k.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            byte by2 = this.i;
            if (by2 != -1) {
                if (by2 == 1) {
                    return true;
                }
                return false;
            }
            if (this.e() && !this.c.isInitialized()) {
                this.i = 0;
                return false;
            }
            this.i = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.a();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.j();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.j();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            if ((this.b & 1) == 1) {
                f2.a(1, this.f());
            }
            if ((this.b & 2) == 2) {
                f2.a(2, this.g());
            }
            if ((this.b & 4) == 4) {
                f2.a(3, this.h());
            }
            if ((this.b & 8) == 8) {
                f2.b(4, this.c);
            }
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.a<a>
        implements f.a {
            private int c;
            private Object d = "";
            private Object e = "";
            private Object f = "";
            private l g = l.a();
            private ab<l, l.a, f.a> h;

            private a() {
                this.b();
            }

            private a(m.b b2) {
                super(b2);
                this.b();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            static /* synthetic */ a a() {
                return new a();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = k.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((k)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (k)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((k)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof k) {
                    return this.a((k)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            private void b() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders && this.h == null) {
                    this.h = new ab(this.g, this.getParentForChildren(), this.b);
                    this.g = null;
                }
            }

            /*
             * Enabled aggressive block sorting
             */
            private a c() {
                super.clear();
                this.d = "";
                this.c &= -2;
                this.e = "";
                this.c &= -3;
                this.f = "";
                this.c &= -5;
                if (this.h == null) {
                    this.g = l.a();
                } else {
                    this.h.f();
                }
                this.c &= -9;
                return this;
            }

            private a d() {
                return new a().a(this.g());
            }

            private k f() {
                k k2 = this.g();
                if (!k2.isInitialized()) {
                    throw a.newUninitializedMessageException(k2);
                }
                return k2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private k g() {
                int n2 = 1;
                k k2 = new k(this, 0);
                int n3 = this.c;
                if ((n3 & 1) != 1) {
                    n2 = 0;
                }
                k2.f = this.d;
                int n4 = n2;
                if ((n3 & 2) == 2) {
                    n4 = n2 | 2;
                }
                k2.g = this.e;
                n2 = n4;
                if ((n3 & 4) == 4) {
                    n2 = n4 | 4;
                }
                k2.h = this.f;
                n4 = (n3 & 8) == 8 ? n2 | 8 : n2;
                if (this.h == null) {
                    k2.c = this.g;
                } else {
                    k2.c = this.h.c();
                }
                k2.b = n4;
                this.onBuilt();
                return k2;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(k k2) {
                boolean bl2 = true;
                if (k2 == k.a()) {
                    return this;
                }
                boolean bl3 = (k2.b & 1) == 1;
                if (bl3) {
                    this.c |= 1;
                    this.d = k2.f;
                    this.onChanged();
                }
                bl3 = (k2.b & 2) == 2;
                if (bl3) {
                    this.c |= 2;
                    this.e = k2.g;
                    this.onChanged();
                }
                bl3 = (k2.b & 4) == 4 ? bl2 : false;
                if (bl3) {
                    this.c |= 4;
                    this.f = k2.h;
                    this.onChanged();
                }
                if (k2.e()) {
                    l l2 = k2.c;
                    if (this.h == null) {
                        this.g = (this.c & 8) == 8 && this.g != l.a() ? l.a(this.g).a(l2).a() : l2;
                        this.onChanged();
                    } else {
                        this.h.b(l2);
                    }
                    this.c |= 8;
                }
                this.mergeUnknownFields(k2.getUnknownFields());
                return this;
            }

            @Override
            public final /* synthetic */ t build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return k.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return q;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return r.a(k.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                if ((this.c & 8) != 8) {
                    return true;
                }
                boolean bl2 = true;
                if (bl2) {
                    l l2 = this.h == null ? this.g : this.h.b();
                    if (!l2.isInitialized()) {
                        return false;
                    }
                }
                return true;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

    }

    public static final class l
    extends m.d<l>
    implements f.a {
        public static x<l> a;
        private static final l b;
        private final af c;
        private List<p> d;
        private byte e;
        private int f;

        static {
            l l2;
            a = new com.google.protobuf.c<l>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new l(e2, k2, 0);
                }
            };
            b = l2 = new l();
            l2.d = Collections.emptyList();
        }

        private l() {
            this.e = -1;
            this.f = -1;
            this.c = af.b();
        }

        /*
         * Exception decompiling
         */
        private l(com.google.protobuf.e var1_1, com.google.protobuf.k var2_9) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ l(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private l(m.c<l, ?> c2) {
            super(c2);
            this.e = -1;
            this.f = -1;
            this.c = c2.getUnknownFields();
        }

        /* synthetic */ l(m.c c2, byte by2) {
            this(c2);
        }

        public static a a(l l2) {
            return a.d().a(l2);
        }

        public static l a() {
            return b;
        }

        private a c() {
            return a.d().a(this);
        }

        public final x<l> getParserForType() {
            return a;
        }

        @Override
        public final int getSerializedSize() {
            int n2 = this.f;
            if (n2 != -1) {
                return n2;
            }
            int n3 = 0;
            for (n2 = 0; n2 < this.d.size(); ++n2) {
                n3 += com.google.protobuf.f.d(999, this.d.get(n2));
            }
            this.f = n2 = this.i.g() + n3 + this.getUnknownFields().getSerializedSize();
            return n2;
        }

        @Override
        public final af getUnknownFields() {
            return this.c;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return F.a(l.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.e;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.d.size(); ++n2) {
                if (this.d.get(n2).isInitialized()) continue;
                this.e = 0;
                return false;
            }
            if (!this.i.f()) {
                this.e = 0;
                return false;
            }
            this.e = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.d();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.c();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.c();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            m.d.a a2 = this.b();
            for (int i2 = 0; i2 < this.d.size(); ++i2) {
                f2.b(999, this.d.get(i2));
            }
            a2.a(f2);
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.c<l, a>
        implements f.a {
            private int d;
            private List<p> e = Collections.emptyList();
            private z<p, p.a, f.a> f;

            private a() {
                this.f();
            }

            private a(m.b b2) {
                super(b2);
                this.f();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = l.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((l)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (l)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((l)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof l) {
                    return this.a((l)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            static /* synthetic */ a d() {
                return new a();
            }

            private void f() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.j();
                }
            }

            private a g() {
                super.c();
                if (this.f == null) {
                    this.e = Collections.emptyList();
                    this.d &= -2;
                    return this;
                }
                this.f.f();
                return this;
            }

            private a h() {
                return new a().a(this.a());
            }

            private l i() {
                l l2 = this.a();
                if (!l2.isInitialized()) {
                    throw a.newUninitializedMessageException(l2);
                }
                return l2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<p, p.a, f.a> j() {
                boolean bl2 = true;
                if (this.f != null) return this.f;
                List<p> list = this.e;
                if ((this.d & 1) != 1) {
                    bl2 = false;
                }
                this.f = new z(list, bl2, this.getParentForChildren(), this.b);
                this.e = null;
                return this.f;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(l l2) {
                z<p, p.a, f.a> z2 = null;
                if (l2 == l.a()) {
                    return this;
                }
                if (this.f == null) {
                    if (!l2.d.isEmpty()) {
                        if (this.e.isEmpty()) {
                            this.e = l2.d;
                            this.d &= -2;
                        } else {
                            if ((this.d & 1) != 1) {
                                this.e = new ArrayList<p>(this.e);
                                this.d |= 1;
                            }
                            this.e.addAll(l2.d);
                        }
                        this.onChanged();
                    }
                } else if (!l2.d.isEmpty()) {
                    if (this.f.e()) {
                        this.f.a = null;
                        this.f = null;
                        this.e = l2.d;
                        this.d &= -2;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z2 = this.j();
                        }
                        this.f = z2;
                    } else {
                        this.f.a(l2.d);
                    }
                }
                this.a(l2);
                this.mergeUnknownFields(l2.getUnknownFields());
                return this;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final l a() {
                l l2 = new l(this, 0);
                if (this.f == null) {
                    if ((this.d & 1) == 1) {
                        this.e = Collections.unmodifiableList(this.e);
                        this.d &= -2;
                    }
                    l2.d = this.e;
                } else {
                    l2.d = this.f.g();
                }
                this.onBuilt();
                return l2;
            }

            @Override
            public final /* synthetic */ m.c b() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ m.c c() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return l.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return E;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return F.a(l.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                for (int i2 = 0; i2 < (n2 = this.f == null ? this.e.size() : this.f.d()); ++i2) {
                    p p2 = this.f == null ? this.e.get(i2) : this.f.a(i2, false);
                    if (!p2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                if (this.c.f()) return true;
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

    }

    public static final class m
    extends com.google.protobuf.m
    implements f.a {
        public static x<m> a;
        private static final m d;
        int b;
        n c;
        private final af e;
        private Object f;
        private List<k> g;
        private byte h;
        private int i;

        static {
            m m2;
            a = new com.google.protobuf.c<m>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new m(e2, k2, 0);
                }
            };
            d = m2 = new m();
            m2.f();
        }

        private m() {
            this.h = -1;
            this.i = -1;
            this.e = af.b();
        }

        /*
         * Exception decompiling
         */
        private m(com.google.protobuf.e var1_1, com.google.protobuf.k var2_6) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ m(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private m(m.a<?> a2) {
            super(a2);
            this.h = -1;
            this.i = -1;
            this.e = a2.getUnknownFields();
        }

        /* synthetic */ m(m.a a2, byte by2) {
            this(a2);
        }

        public static m a() {
            return d;
        }

        private com.google.protobuf.d e() {
            Object object = this.f;
            if (object instanceof String) {
                this.f = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private void f() {
            this.f = "";
            this.g = Collections.emptyList();
            this.c = n.a();
        }

        private a g() {
            return a.a().a(this);
        }

        public final k a(int n2) {
            return this.g.get(n2);
        }

        public final String b() {
            Object object = this.f;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                this.f = string;
            }
            return string;
        }

        public final int c() {
            return this.g.size();
        }

        public final boolean d() {
            if ((this.b & 2) == 2) {
                return true;
            }
            return false;
        }

        public final x<m> getParserForType() {
            return a;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int getSerializedSize() {
            int n2;
            int n3 = this.i;
            if (n3 != -1) {
                return n3;
            }
            n3 = (this.b & 1) == 1 ? com.google.protobuf.f.c(1, this.e()) + 0 : 0;
            for (n2 = 0; n2 < this.g.size(); ++n2) {
                int n4 = com.google.protobuf.f.d(2, this.g.get(n2));
                n3 = n4 + n3;
            }
            n2 = n3;
            if ((this.b & 2) == 2) {
                n2 = n3 + com.google.protobuf.f.d(3, this.c);
            }
            this.i = n3 = this.getUnknownFields().getSerializedSize() + n2;
            return n3;
        }

        @Override
        public final af getUnknownFields() {
            return this.e;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return p.a(m.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.h;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.c(); ++n2) {
                if (this.a(n2).isInitialized()) continue;
                this.h = 0;
                return false;
            }
            if (this.d() && !this.c.isInitialized()) {
                this.h = 0;
                return false;
            }
            this.h = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.a();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.g();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.g();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            if ((this.b & 1) == 1) {
                f2.a(1, this.e());
            }
            for (int i2 = 0; i2 < this.g.size(); ++i2) {
                f2.b(2, this.g.get(i2));
            }
            if ((this.b & 2) == 2) {
                f2.b(3, this.c);
            }
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.a<a>
        implements f.a {
            private int c;
            private Object d = "";
            private List<k> e = Collections.emptyList();
            private z<k, k.a, f.a> f;
            private n g = n.a();
            private ab<n, n.a, f.a> h;

            private a() {
                this.b();
            }

            private a(m.b b2) {
                super(b2);
                this.b();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            static /* synthetic */ a a() {
                return new a();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = m.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((m)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (m)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((m)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof m) {
                    return this.a((m)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            private void b() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.h();
                    if (this.h == null) {
                        this.h = new ab(this.g, this.getParentForChildren(), this.b);
                        this.g = null;
                    }
                }
            }

            /*
             * Enabled aggressive block sorting
             */
            private a c() {
                super.clear();
                this.d = "";
                this.c &= -2;
                if (this.f == null) {
                    this.e = Collections.emptyList();
                    this.c &= -3;
                } else {
                    this.f.f();
                }
                if (this.h == null) {
                    this.g = n.a();
                } else {
                    this.h.f();
                }
                this.c &= -5;
                return this;
            }

            private a d() {
                return new a().a(this.g());
            }

            private m f() {
                m m2 = this.g();
                if (!m2.isInitialized()) {
                    throw a.newUninitializedMessageException(m2);
                }
                return m2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private m g() {
                int n2 = 1;
                m m2 = new m(this, 0);
                int n3 = this.c;
                if ((n3 & 1) != 1) {
                    n2 = 0;
                }
                m2.f = this.d;
                if (this.f == null) {
                    if ((this.c & 2) == 2) {
                        this.e = Collections.unmodifiableList(this.e);
                        this.c &= -3;
                    }
                    m2.g = this.e;
                } else {
                    m2.g = this.f.g();
                }
                if ((n3 & 4) == 4) {
                    n2 |= 2;
                }
                if (this.h == null) {
                    m2.c = this.g;
                } else {
                    m2.c = this.h.c();
                }
                m2.b = n2;
                this.onBuilt();
                return m2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<k, k.a, f.a> h() {
                if (this.f == null) {
                    List<k> list = this.e;
                    boolean bl2 = (this.c & 2) == 2;
                    this.f = new z(list, bl2, this.getParentForChildren(), this.b);
                    this.e = null;
                }
                return this.f;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(m m2) {
                boolean bl2 = true;
                Object object = null;
                if (m2 == m.a()) {
                    return this;
                }
                if ((m2.b & 1) != 1) {
                    bl2 = false;
                }
                if (bl2) {
                    this.c |= 1;
                    this.d = m2.f;
                    this.onChanged();
                }
                if (this.f == null) {
                    if (!m2.g.isEmpty()) {
                        if (this.e.isEmpty()) {
                            this.e = m2.g;
                            this.c &= -3;
                        } else {
                            if ((this.c & 2) != 2) {
                                this.e = new ArrayList<k>(this.e);
                                this.c |= 2;
                            }
                            this.e.addAll(m2.g);
                        }
                        this.onChanged();
                    }
                } else if (!m2.g.isEmpty()) {
                    if (this.f.e()) {
                        this.f.a = null;
                        this.f = null;
                        this.e = m2.g;
                        this.c &= -3;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            object = this.h();
                        }
                        this.f = object;
                    } else {
                        this.f.a(m2.g);
                    }
                }
                if (m2.d()) {
                    object = m2.c;
                    if (this.h == null) {
                        this.g = (this.c & 4) == 4 && this.g != n.a() ? n.a(this.g).a((n)object).a() : object;
                        this.onChanged();
                    } else {
                        this.h.b((n)object);
                    }
                    this.c |= 4;
                }
                this.mergeUnknownFields(m2.getUnknownFields());
                return this;
            }

            @Override
            public final /* synthetic */ t build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return m.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return o;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return p.a(m.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                int n3;
                for (n3 = 0; n3 < (n2 = this.f == null ? this.e.size() : this.f.d()); ++n3) {
                    void var1_2;
                    if (this.f == null) {
                        k k2 = this.e.get(n3);
                    } else {
                        k k3 = this.f.a(n3, false);
                    }
                    if (!var1_2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                if ((this.c & 4) != 4) {
                    return true;
                }
                n3 = 1;
                if (n3 == 0) return true;
                {
                    void var1_6;
                    if (this.h == null) {
                        n n4 = this.g;
                    } else {
                        n n5 = this.h.b();
                    }
                    if (var1_6.isInitialized()) return true;
                }
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

    }

    public static final class n
    extends m.d<n>
    implements f.a {
        public static x<n> a;
        private static final n b;
        private final af c;
        private List<p> d;
        private byte e;
        private int f;

        static {
            n n2;
            a = new com.google.protobuf.c<n>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new n(e2, k2, 0);
                }
            };
            b = n2 = new n();
            n2.d = Collections.emptyList();
        }

        private n() {
            this.e = -1;
            this.f = -1;
            this.c = af.b();
        }

        /*
         * Exception decompiling
         */
        private n(com.google.protobuf.e var1_1, com.google.protobuf.k var2_9) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ n(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private n(m.c<n, ?> c2) {
            super(c2);
            this.e = -1;
            this.f = -1;
            this.c = c2.getUnknownFields();
        }

        /* synthetic */ n(m.c c2, byte by2) {
            this(c2);
        }

        public static a a(n n2) {
            return a.d().a(n2);
        }

        public static n a() {
            return b;
        }

        private a c() {
            return a.d().a(this);
        }

        public final x<n> getParserForType() {
            return a;
        }

        @Override
        public final int getSerializedSize() {
            int n2 = this.f;
            if (n2 != -1) {
                return n2;
            }
            int n3 = 0;
            for (n2 = 0; n2 < this.d.size(); ++n2) {
                n3 += com.google.protobuf.f.d(999, this.d.get(n2));
            }
            this.f = n2 = this.i.g() + n3 + this.getUnknownFields().getSerializedSize();
            return n2;
        }

        @Override
        public final af getUnknownFields() {
            return this.c;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return D.a(n.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.e;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.d.size(); ++n2) {
                if (this.d.get(n2).isInitialized()) continue;
                this.e = 0;
                return false;
            }
            if (!this.i.f()) {
                this.e = 0;
                return false;
            }
            this.e = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.d();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.c();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.c();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            m.d.a a2 = this.b();
            for (int i2 = 0; i2 < this.d.size(); ++i2) {
                f2.b(999, this.d.get(i2));
            }
            a2.a(f2);
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.c<n, a>
        implements f.a {
            private int d;
            private List<p> e = Collections.emptyList();
            private z<p, p.a, f.a> f;

            private a() {
                this.f();
            }

            private a(m.b b2) {
                super(b2);
                this.f();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = n.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((n)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (n)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((n)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof n) {
                    return this.a((n)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            static /* synthetic */ a d() {
                return new a();
            }

            private void f() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.j();
                }
            }

            private a g() {
                super.c();
                if (this.f == null) {
                    this.e = Collections.emptyList();
                    this.d &= -2;
                    return this;
                }
                this.f.f();
                return this;
            }

            private a h() {
                return new a().a(this.a());
            }

            private n i() {
                n n2 = this.a();
                if (!n2.isInitialized()) {
                    throw a.newUninitializedMessageException(n2);
                }
                return n2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<p, p.a, f.a> j() {
                boolean bl2 = true;
                if (this.f != null) return this.f;
                List<p> list = this.e;
                if ((this.d & 1) != 1) {
                    bl2 = false;
                }
                this.f = new z(list, bl2, this.getParentForChildren(), this.b);
                this.e = null;
                return this.f;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(n n2) {
                z<p, p.a, f.a> z2 = null;
                if (n2 == n.a()) {
                    return this;
                }
                if (this.f == null) {
                    if (!n2.d.isEmpty()) {
                        if (this.e.isEmpty()) {
                            this.e = n2.d;
                            this.d &= -2;
                        } else {
                            if ((this.d & 1) != 1) {
                                this.e = new ArrayList<p>(this.e);
                                this.d |= 1;
                            }
                            this.e.addAll(n2.d);
                        }
                        this.onChanged();
                    }
                } else if (!n2.d.isEmpty()) {
                    if (this.f.e()) {
                        this.f.a = null;
                        this.f = null;
                        this.e = n2.d;
                        this.d &= -2;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z2 = this.j();
                        }
                        this.f = z2;
                    } else {
                        this.f.a(n2.d);
                    }
                }
                this.a(n2);
                this.mergeUnknownFields(n2.getUnknownFields());
                return this;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final n a() {
                n n2 = new n(this, 0);
                if (this.f == null) {
                    if ((this.d & 1) == 1) {
                        this.e = Collections.unmodifiableList(this.e);
                        this.d &= -2;
                    }
                    n2.d = this.e;
                } else {
                    n2.d = this.f.g();
                }
                this.onBuilt();
                return n2;
            }

            @Override
            public final /* synthetic */ m.c b() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.i();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ m.c c() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ b.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.h();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return n.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return C;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return D.a(n.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2;
                for (int i2 = 0; i2 < (n2 = this.f == null ? this.e.size() : this.f.d()); ++i2) {
                    p p2 = this.f == null ? this.e.get(i2) : this.f.a(i2, false);
                    if (!p2.isInitialized()) return false;
                    {
                        continue;
                    }
                }
                if (this.c.f()) return true;
                return false;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ b.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

    }

    public static final class o
    extends com.google.protobuf.m
    implements f.a {
        public static x<o> a;
        private static final o b;
        private final af c;
        private List<b> d;
        private byte e;
        private int f;

        static {
            o o2;
            a = new com.google.protobuf.c<o>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new o(e2, k2, 0);
                }
            };
            b = o2 = new o();
            o2.d = Collections.emptyList();
        }

        private o() {
            this.e = -1;
            this.f = -1;
            this.c = af.b();
        }

        /*
         * Exception decompiling
         */
        private o(com.google.protobuf.e var1_1, com.google.protobuf.k var2_9) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ o(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private o(m.a<?> a2) {
            super(a2);
            this.e = -1;
            this.f = -1;
            this.c = a2.getUnknownFields();
        }

        /* synthetic */ o(m.a a2, byte by2) {
            this(a2);
        }

        public static a a(o o2) {
            return a.b().a(o2);
        }

        public static o a() {
            return b;
        }

        private a b() {
            return a.b().a(this);
        }

        public final x<o> getParserForType() {
            return a;
        }

        @Override
        public final int getSerializedSize() {
            int n2 = this.f;
            if (n2 != -1) {
                return n2;
            }
            int n3 = 0;
            for (n2 = 0; n2 < this.d.size(); ++n2) {
                n3 += com.google.protobuf.f.d(1, this.d.get(n2));
            }
            this.f = n2 = this.getUnknownFields().getSerializedSize() + n3;
            return n2;
        }

        @Override
        public final af getUnknownFields() {
            return this.c;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return L.a(o.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            byte by2 = this.e;
            if (by2 != -1) {
                if (by2 == 1) {
                    return true;
                }
                return false;
            }
            this.e = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.b();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.b();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.b();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            for (int i2 = 0; i2 < this.d.size(); ++i2) {
                f2.b(1, this.d.get(i2));
            }
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.a<a>
        implements f.a {
            private int c;
            private List<b> d = Collections.emptyList();
            private z<b, b.a, f.a> e;

            private a() {
                this.c();
            }

            private a(m.b b2) {
                super(b2);
                this.c();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = o.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((o)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (o)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((o)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof o) {
                    return this.a((o)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            static /* synthetic */ a b() {
                return new a();
            }

            private void c() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.h();
                }
            }

            private a d() {
                super.clear();
                if (this.e == null) {
                    this.d = Collections.emptyList();
                    this.c &= -2;
                    return this;
                }
                this.e.f();
                return this;
            }

            private a f() {
                return new a().a(this.a());
            }

            private o g() {
                o o2 = this.a();
                if (!o2.isInitialized()) {
                    throw a.newUninitializedMessageException(o2);
                }
                return o2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<b, b.a, f.a> h() {
                boolean bl2 = true;
                if (this.e != null) return this.e;
                List<b> list = this.d;
                if ((this.c & 1) != 1) {
                    bl2 = false;
                }
                this.e = new z(list, bl2, this.getParentForChildren(), this.b);
                this.d = null;
                return this.e;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(o o2) {
                z<b, b.a, f.a> z2 = null;
                if (o2 == o.a()) {
                    return this;
                }
                if (this.e == null) {
                    if (!o2.d.isEmpty()) {
                        if (this.d.isEmpty()) {
                            this.d = o2.d;
                            this.c &= -2;
                        } else {
                            if ((this.c & 1) != 1) {
                                this.d = new ArrayList<b>(this.d);
                                this.c |= 1;
                            }
                            this.d.addAll(o2.d);
                        }
                        this.onChanged();
                    }
                } else if (!o2.d.isEmpty()) {
                    if (this.e.e()) {
                        this.e.a = null;
                        this.e = null;
                        this.d = o2.d;
                        this.c &= -2;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            z2 = this.h();
                        }
                        this.e = z2;
                    } else {
                        this.e.a(o2.d);
                    }
                }
                this.mergeUnknownFields(o2.getUnknownFields());
                return this;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final o a() {
                o o2 = new o(this, 0);
                if (this.e == null) {
                    if ((this.c & 1) == 1) {
                        this.d = Collections.unmodifiableList(this.d);
                        this.c &= -2;
                    }
                    o2.d = this.d;
                } else {
                    o2.d = this.e.g();
                }
                this.onBuilt();
                return o2;
            }

            @Override
            public final /* synthetic */ t build() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.g();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.a();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.d();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.d();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.d();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.f();
            }

            @Override
            public final /* synthetic */ com.google.protobuf.b$a clone() {
                return this.f();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.f();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.f();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.f();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.f();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return o.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return K;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return L.a(o.class, a.class);
            }

            @Override
            public final boolean isInitialized() {
                return true;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ com.google.protobuf.b$a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

        public static final class b
        extends com.google.protobuf.m
        implements f.a {
            public static x<b> a;
            private static final b c;
            int b;
            private final af d;
            private List<Integer> e;
            private int f;
            private List<Integer> g;
            private int h;
            private Object i;
            private Object j;
            private byte k;
            private int l;

            static {
                b b2;
                a = new com.google.protobuf.c<b>(){

                    @Override
                    public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                        return new b(e2, k2, 0);
                    }
                };
                c = b2 = new b();
                b2.d();
            }

            private b() {
                this.f = -1;
                this.h = -1;
                this.k = -1;
                this.l = -1;
                this.d = af.b();
            }

            /*
             * Exception decompiling
             */
            private b(com.google.protobuf.e var1_1, com.google.protobuf.k var2_6) {
                // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
                // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
                // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
                // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
                // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
                // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
                // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
                // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
                // org.benf.cfr.reader.Main.doJar(Main.java:129)
                // org.benf.cfr.reader.Main.main(Main.java:181)
                throw new IllegalStateException("Decompilation failed");
            }

            /* synthetic */ b(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
                this(e2, k2);
            }

            private b(m.a<?> a2) {
                super(a2);
                this.f = -1;
                this.h = -1;
                this.k = -1;
                this.l = -1;
                this.d = a2.getUnknownFields();
            }

            /* synthetic */ b(m.a a2, byte by2) {
                this(a2);
            }

            public static b a() {
                return c;
            }

            private com.google.protobuf.d b() {
                Object object = this.i;
                if (object instanceof String) {
                    this.i = object = com.google.protobuf.d.a((String)object);
                    return object;
                }
                return (com.google.protobuf.d)object;
            }

            private com.google.protobuf.d c() {
                Object object = this.j;
                if (object instanceof String) {
                    this.j = object = com.google.protobuf.d.a((String)object);
                    return object;
                }
                return (com.google.protobuf.d)object;
            }

            private void d() {
                this.e = Collections.emptyList();
                this.g = Collections.emptyList();
                this.i = "";
                this.j = "";
            }

            private a e() {
                return a.a().a(this);
            }

            public final x<b> getParserForType() {
                return a;
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final int getSerializedSize() {
                int n2;
                int n3 = 0;
                int n4 = this.l;
                if (n4 != -1) {
                    return n4;
                }
                n4 = 0;
                for (n2 = 0; n2 < this.e.size(); n4 += com.google.protobuf.f.c((int)this.e.get((int)n2).intValue()), ++n2) {
                }
                n2 = !this.e.isEmpty() ? n4 + 1 + com.google.protobuf.f.c(n4) : n4;
                this.f = n4;
                int n5 = 0;
                for (n4 = n3; n4 < this.g.size(); ++n4) {
                    n3 = com.google.protobuf.f.c(this.g.get(n4));
                    n5 = n3 + n5;
                }
                n4 = n2 += n5;
                if (!this.g.isEmpty()) {
                    n4 = n2 + 1 + com.google.protobuf.f.c(n5);
                }
                this.h = n5;
                n2 = n4;
                if ((this.b & 1) == 1) {
                    n2 = n4 + com.google.protobuf.f.c(3, this.b());
                }
                n4 = n2;
                if ((this.b & 2) == 2) {
                    n4 = n2 + com.google.protobuf.f.c(4, this.c());
                }
                this.l = n4 += this.getUnknownFields().getSerializedSize();
                return n4;
            }

            @Override
            public final af getUnknownFields() {
                return this.d;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return N.a(b.class, a.class);
            }

            @Override
            public final boolean isInitialized() {
                byte by2 = this.k;
                if (by2 != -1) {
                    if (by2 == 1) {
                        return true;
                    }
                    return false;
                }
                this.k = 1;
                return true;
            }

            @Override
            public final /* synthetic */ t.a newBuilderForType() {
                return a.a();
            }

            @Override
            protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
                return new a(b2, 0);
            }

            @Override
            public final /* synthetic */ t.a toBuilder() {
                return this.e();
            }

            @Override
            public final /* synthetic */ u.a toBuilder() {
                return this.e();
            }

            @Override
            protected final Object writeReplace() {
                return super.writeReplace();
            }

            @Override
            public final void writeTo(com.google.protobuf.f f2) {
                int n2;
                int n3 = 0;
                this.getSerializedSize();
                if (this.e.size() > 0) {
                    f2.e(10);
                    f2.e(this.f);
                }
                for (n2 = 0; n2 < this.e.size(); ++n2) {
                    f2.b(this.e.get(n2));
                }
                n2 = n3;
                if (this.g.size() > 0) {
                    f2.e(18);
                    f2.e(this.h);
                    n2 = n3;
                }
                while (n2 < this.g.size()) {
                    f2.b(this.g.get(n2));
                    ++n2;
                }
                if ((this.b & 1) == 1) {
                    f2.a(3, this.b());
                }
                if ((this.b & 2) == 2) {
                    f2.a(4, this.c());
                }
                this.getUnknownFields().writeTo(f2);
            }

            public static final class a
            extends m.a<a>
            implements f.a {
                private int c;
                private List<Integer> d = Collections.emptyList();
                private List<Integer> e = Collections.emptyList();
                private Object f = "";
                private Object g = "";

                private a() {
                    boolean bl2 = com.google.protobuf.m.alwaysUseFieldBuilders;
                }

                private a(m.b b2) {
                    super(b2);
                    boolean bl2 = com.google.protobuf.m.alwaysUseFieldBuilders;
                }

                /* synthetic */ a(m.b b2, byte by2) {
                    this(b2);
                }

                static /* synthetic */ a a() {
                    return new a();
                }

                /*
                 * Unable to fully structure code
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 * Lifted jumps to return sites
                 */
                private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                    try {
                        var1_1 = b.a.b((com.google.protobuf.e)var1_1, var2_2);
                        if (var1_1 == null) return this;
                        this.a((b)var1_1);
                        return this;
                    }
                    catch (com.google.protobuf.o var2_3) {
                        var1_1 = (b)var2_3.a;
                        try {
                            throw var2_3;
                        }
                        catch (Throwable var2_4) {}
                        ** GOTO lbl-1000
                        catch (Throwable var2_6) {
                            var1_1 = null;
                        }
lbl-1000: // 2 sources:
                        {
                            if (var1_1 == null) throw var2_5;
                            this.a((b)var1_1);
                            throw var2_5;
                        }
                    }
                }

                private a a(t t2) {
                    if (t2 instanceof b) {
                        return this.a((b)t2);
                    }
                    super.mergeFrom(t2);
                    return this;
                }

                private a b() {
                    super.clear();
                    this.d = Collections.emptyList();
                    this.c &= -2;
                    this.e = Collections.emptyList();
                    this.c &= -3;
                    this.f = "";
                    this.c &= -5;
                    this.g = "";
                    this.c &= -9;
                    return this;
                }

                private a c() {
                    return new a().a(this.f());
                }

                private b d() {
                    b b2 = this.f();
                    if (!b2.isInitialized()) {
                        throw a.newUninitializedMessageException(b2);
                    }
                    return b2;
                }

                /*
                 * Enabled aggressive block sorting
                 */
                private b f() {
                    int n2 = 1;
                    b b2 = new b(this, 0);
                    int n3 = this.c;
                    if ((this.c & 1) == 1) {
                        this.d = Collections.unmodifiableList(this.d);
                        this.c &= -2;
                    }
                    b2.e = this.d;
                    if ((this.c & 2) == 2) {
                        this.e = Collections.unmodifiableList(this.e);
                        this.c &= -3;
                    }
                    b2.g = this.e;
                    if ((n3 & 4) != 4) {
                        n2 = 0;
                    }
                    b2.i = this.f;
                    int n4 = n2;
                    if ((n3 & 8) == 8) {
                        n4 = n2 | 2;
                    }
                    b2.j = this.g;
                    b2.b = n4;
                    this.onBuilt();
                    return b2;
                }

                /*
                 * Enabled aggressive block sorting
                 */
                public final a a(b b2) {
                    boolean bl2 = true;
                    if (b2 == b.a()) {
                        return this;
                    }
                    if (!b2.e.isEmpty()) {
                        if (this.d.isEmpty()) {
                            this.d = b2.e;
                            this.c &= -2;
                        } else {
                            if ((this.c & 1) != 1) {
                                this.d = new ArrayList<Integer>(this.d);
                                this.c |= 1;
                            }
                            this.d.addAll(b2.e);
                        }
                        this.onChanged();
                    }
                    if (!b2.g.isEmpty()) {
                        if (this.e.isEmpty()) {
                            this.e = b2.g;
                            this.c &= -3;
                        } else {
                            if ((this.c & 2) != 2) {
                                this.e = new ArrayList<Integer>(this.e);
                                this.c |= 2;
                            }
                            this.e.addAll(b2.g);
                        }
                        this.onChanged();
                    }
                    boolean bl3 = (b2.b & 1) == 1;
                    if (bl3) {
                        this.c |= 4;
                        this.f = b2.i;
                        this.onChanged();
                    }
                    bl3 = (b2.b & 2) == 2 ? bl2 : false;
                    if (bl3) {
                        this.c |= 8;
                        this.g = b2.j;
                        this.onChanged();
                    }
                    this.mergeUnknownFields(b2.getUnknownFields());
                    return this;
                }

                @Override
                public final /* synthetic */ t build() {
                    return this.d();
                }

                @Override
                public final /* synthetic */ u build() {
                    return this.d();
                }

                @Override
                public final /* synthetic */ t buildPartial() {
                    return this.f();
                }

                @Override
                public final /* synthetic */ u buildPartial() {
                    return this.f();
                }

                @Override
                public final /* synthetic */ a.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ m.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ t.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ u.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ a.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ com.google.protobuf.b$a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ m.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ t.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ u.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ Object clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ t getDefaultInstanceForType() {
                    return b.a();
                }

                @Override
                public final h.a getDescriptorForType() {
                    return M;
                }

                @Override
                protected final m.e internalGetFieldAccessorTable() {
                    return N.a(b.class, a.class);
                }

                @Override
                public final boolean isInitialized() {
                    return true;
                }

                @Override
                public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }

                @Override
                public final /* synthetic */ a.a mergeFrom(t t2) {
                    return this.a(t2);
                }

                @Override
                public final /* synthetic */ com.google.protobuf.b$a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }

                @Override
                public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }

                @Override
                public final /* synthetic */ t.a mergeFrom(t t2) {
                    return this.a(t2);
                }

                @Override
                public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }
            }

        }

    }

    public static final class p
    extends com.google.protobuf.m
    implements f.a {
        public static x<p> a;
        private static final p g;
        int b;
        long c;
        long d;
        double e;
        com.google.protobuf.d f;
        private final af h;
        private List<b> i;
        private Object j;
        private Object k;
        private byte l;
        private int m;

        static {
            p p2;
            a = new com.google.protobuf.c<p>(){

                @Override
                public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return new p(e2, k2, 0);
                }
            };
            g = p2 = new p();
            p2.d();
        }

        private p() {
            this.l = -1;
            this.m = -1;
            this.h = af.b();
        }

        /*
         * Exception decompiling
         */
        private p(com.google.protobuf.e var1_1, com.google.protobuf.k var2_6) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /* synthetic */ p(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
            this(e2, k2);
        }

        private p(m.a<?> a2) {
            super(a2);
            this.l = -1;
            this.m = -1;
            this.h = a2.getUnknownFields();
        }

        /* synthetic */ p(m.a a2, byte by2) {
            this(a2);
        }

        public static p a() {
            return g;
        }

        private com.google.protobuf.d b() {
            Object object = this.j;
            if (object instanceof String) {
                this.j = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private com.google.protobuf.d c() {
            Object object = this.k;
            if (object instanceof String) {
                this.k = object = com.google.protobuf.d.a((String)object);
                return object;
            }
            return (com.google.protobuf.d)object;
        }

        private void d() {
            this.i = Collections.emptyList();
            this.j = "";
            this.c = 0;
            this.d = 0;
            this.e = 0.0;
            this.f = com.google.protobuf.d.a;
            this.k = "";
        }

        private a e() {
            return a.a().a(this);
        }

        public final x<p> getParserForType() {
            return a;
        }

        @Override
        public final int getSerializedSize() {
            int n2;
            int n3 = this.m;
            if (n3 != -1) {
                return n3;
            }
            n3 = 0;
            for (n2 = 0; n2 < this.i.size(); ++n2) {
                n3 += com.google.protobuf.f.d(2, this.i.get(n2));
            }
            n2 = n3;
            if ((this.b & 1) == 1) {
                n2 = n3 + com.google.protobuf.f.c(3, this.b());
            }
            n3 = n2;
            if ((this.b & 2) == 2) {
                n3 = n2 + com.google.protobuf.f.c(4, this.c);
            }
            n2 = n3;
            if ((this.b & 4) == 4) {
                long l2 = this.d;
                n2 = com.google.protobuf.f.d(5);
                n2 = n3 + (com.google.protobuf.f.b(l2) + n2);
            }
            n3 = n2;
            if ((this.b & 8) == 8) {
                n3 = n2 + (com.google.protobuf.f.d(6) + 8);
            }
            n2 = n3;
            if ((this.b & 16) == 16) {
                n2 = n3 + com.google.protobuf.f.c(7, this.f);
            }
            n3 = n2;
            if ((this.b & 32) == 32) {
                n3 = n2 + com.google.protobuf.f.c(8, this.c());
            }
            this.m = n3 = this.getUnknownFields().getSerializedSize() + n3;
            return n3;
        }

        @Override
        public final af getUnknownFields() {
            return this.h;
        }

        @Override
        protected final m.e internalGetFieldAccessorTable() {
            return H.a(p.class, a.class);
        }

        @Override
        public final boolean isInitialized() {
            boolean bl2 = false;
            int n2 = this.l;
            if (n2 != -1) {
                if (n2 == 1) {
                    bl2 = true;
                }
                return bl2;
            }
            for (n2 = 0; n2 < this.i.size(); ++n2) {
                if (this.i.get(n2).isInitialized()) continue;
                this.l = 0;
                return false;
            }
            this.l = 1;
            return true;
        }

        @Override
        public final /* synthetic */ t.a newBuilderForType() {
            return a.a();
        }

        @Override
        protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
            return new a(b2, 0);
        }

        @Override
        public final /* synthetic */ t.a toBuilder() {
            return this.e();
        }

        @Override
        public final /* synthetic */ u.a toBuilder() {
            return this.e();
        }

        @Override
        protected final Object writeReplace() {
            return super.writeReplace();
        }

        @Override
        public final void writeTo(com.google.protobuf.f f2) {
            this.getSerializedSize();
            for (int i2 = 0; i2 < this.i.size(); ++i2) {
                f2.b(2, this.i.get(i2));
            }
            if ((this.b & 1) == 1) {
                f2.a(3, this.b());
            }
            if ((this.b & 2) == 2) {
                f2.a(4, this.c);
            }
            if ((this.b & 4) == 4) {
                long l2 = this.d;
                f2.g(5, 0);
                f2.a(l2);
            }
            if ((this.b & 8) == 8) {
                double d2 = this.e;
                f2.g(6, 1);
                f2.a(d2);
            }
            if ((this.b & 16) == 16) {
                f2.a(7, this.f);
            }
            if ((this.b & 32) == 32) {
                f2.a(8, this.c());
            }
            this.getUnknownFields().writeTo(f2);
        }

        public static final class a
        extends m.a<a>
        implements f.a {
            private int c;
            private List<b> d = Collections.emptyList();
            private z<b, b.a, f.a> e;
            private Object f = "";
            private long g;
            private long h;
            private double i;
            private com.google.protobuf.d j = com.google.protobuf.d.a;
            private Object k = "";

            private a() {
                this.b();
            }

            private a(m.b b2) {
                super(b2);
                this.b();
            }

            /* synthetic */ a(m.b b2, byte by2) {
                this(b2);
            }

            static /* synthetic */ a a() {
                return new a();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                try {
                    var1_1 = p.a.b((com.google.protobuf.e)var1_1, var2_2);
                    if (var1_1 == null) return this;
                    this.a((p)var1_1);
                    return this;
                }
                catch (com.google.protobuf.o var2_3) {
                    var1_1 = (p)var2_3.a;
                    try {
                        throw var2_3;
                    }
                    catch (Throwable var2_4) {}
                    ** GOTO lbl-1000
                    catch (Throwable var2_6) {
                        var1_1 = null;
                    }
lbl-1000: // 2 sources:
                    {
                        if (var1_1 == null) throw var2_5;
                        this.a((p)var1_1);
                        throw var2_5;
                    }
                }
            }

            private a a(t t2) {
                if (t2 instanceof p) {
                    return this.a((p)t2);
                }
                super.mergeFrom(t2);
                return this;
            }

            private void b() {
                if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                    this.h();
                }
            }

            /*
             * Enabled aggressive block sorting
             */
            private a c() {
                super.clear();
                if (this.e == null) {
                    this.d = Collections.emptyList();
                    this.c &= -2;
                } else {
                    this.e.f();
                }
                this.f = "";
                this.c &= -3;
                this.g = 0;
                this.c &= -5;
                this.h = 0;
                this.c &= -9;
                this.i = 0.0;
                this.c &= -17;
                this.j = com.google.protobuf.d.a;
                this.c &= -33;
                this.k = "";
                this.c &= -65;
                return this;
            }

            private a d() {
                return new a().a(this.g());
            }

            private p f() {
                p p2 = this.g();
                if (!p2.isInitialized()) {
                    throw a.newUninitializedMessageException(p2);
                }
                return p2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private p g() {
                int n2 = 1;
                p p2 = new p(this, 0);
                int n3 = this.c;
                if (this.e == null) {
                    if ((this.c & 1) == 1) {
                        this.d = Collections.unmodifiableList(this.d);
                        this.c &= -2;
                    }
                    p2.i = this.d;
                } else {
                    p2.i = this.e.g();
                }
                if ((n3 & 2) != 2) {
                    n2 = 0;
                }
                p2.j = this.f;
                int n4 = n2;
                if ((n3 & 4) == 4) {
                    n4 = n2 | 2;
                }
                p2.c = this.g;
                n2 = n4;
                if ((n3 & 8) == 8) {
                    n2 = n4 | 4;
                }
                p2.d = this.h;
                n4 = n2;
                if ((n3 & 16) == 16) {
                    n4 = n2 | 8;
                }
                p2.e = this.i;
                n2 = n4;
                if ((n3 & 32) == 32) {
                    n2 = n4 | 16;
                }
                p2.f = this.j;
                n4 = n2;
                if ((n3 & 64) == 64) {
                    n4 = n2 | 32;
                }
                p2.k = this.k;
                p2.b = n4;
                this.onBuilt();
                return p2;
            }

            /*
             * Enabled aggressive block sorting
             */
            private z<b, b.a, f.a> h() {
                boolean bl2 = true;
                if (this.e != null) return this.e;
                List<b> list = this.d;
                if ((this.c & 1) != 1) {
                    bl2 = false;
                }
                this.e = new z(list, bl2, this.getParentForChildren(), this.b);
                this.d = null;
                return this.e;
            }

            /*
             * Enabled aggressive block sorting
             */
            public final a a(p p2) {
                long l2;
                Object object = null;
                if (p2 == p.a()) {
                    return this;
                }
                if (this.e == null) {
                    if (!p2.i.isEmpty()) {
                        if (this.d.isEmpty()) {
                            this.d = p2.i;
                            this.c &= -2;
                        } else {
                            if ((this.c & 1) != 1) {
                                this.d = new ArrayList<b>(this.d);
                                this.c |= 1;
                            }
                            this.d.addAll(p2.i);
                        }
                        this.onChanged();
                    }
                } else if (!p2.i.isEmpty()) {
                    if (this.e.e()) {
                        this.e.a = null;
                        this.e = null;
                        this.d = p2.i;
                        this.c &= -2;
                        if (com.google.protobuf.m.alwaysUseFieldBuilders) {
                            object = this.h();
                        }
                        this.e = object;
                    } else {
                        this.e.a(p2.i);
                    }
                }
                boolean bl2 = (p2.b & 1) == 1;
                if (bl2) {
                    this.c |= 2;
                    this.f = p2.j;
                    this.onChanged();
                }
                bl2 = (p2.b & 2) == 2;
                if (bl2) {
                    l2 = p2.c;
                    this.c |= 4;
                    this.g = l2;
                    this.onChanged();
                }
                bl2 = (p2.b & 4) == 4;
                if (bl2) {
                    l2 = p2.d;
                    this.c |= 8;
                    this.h = l2;
                    this.onChanged();
                }
                bl2 = (p2.b & 8) == 8;
                if (bl2) {
                    double d2 = p2.e;
                    this.c |= 16;
                    this.i = d2;
                    this.onChanged();
                }
                bl2 = (p2.b & 16) == 16;
                if (bl2) {
                    object = p2.f;
                    if (object == null) {
                        throw new NullPointerException();
                    }
                    this.c |= 32;
                    this.j = object;
                    this.onChanged();
                }
                bl2 = (p2.b & 32) == 32;
                if (bl2) {
                    this.c |= 64;
                    this.k = p2.k;
                    this.onChanged();
                }
                this.mergeUnknownFields(p2.getUnknownFields());
                return this;
            }

            @Override
            public final /* synthetic */ t build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ u build() {
                return this.f();
            }

            @Override
            public final /* synthetic */ t buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ u buildPartial() {
                return this.g();
            }

            @Override
            public final /* synthetic */ a.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ m.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ t.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ u.a clear() {
                return this.c();
            }

            @Override
            public final /* synthetic */ a.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ com.google.protobuf.b$a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ m.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ u.a clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ Object clone() {
                return this.d();
            }

            @Override
            public final /* synthetic */ t getDefaultInstanceForType() {
                return p.a();
            }

            @Override
            public final h.a getDescriptorForType() {
                return G;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return H.a(p.class, a.class);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final boolean isInitialized() {
                int n2 = 0;
                int n3;
                while (n2 < (n3 = this.e == null ? this.d.size() : this.e.d())) {
                    b b2 = this.e == null ? this.d.get(n2) : this.e.a(n2, false);
                    if (!b2.isInitialized()) {
                        return false;
                    }
                    ++n2;
                }
                return true;
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ a.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ com.google.protobuf.b$a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }

            @Override
            public final /* synthetic */ t.a mergeFrom(t t2) {
                return this.a(t2);
            }

            @Override
            public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                return this.a(e2, k2);
            }
        }

        public static final class b
        extends com.google.protobuf.m
        implements f.a {
            public static x<b> a;
            private static final b c;
            boolean b;
            private final af d;
            private int e;
            private Object f;
            private byte g;
            private int h;

            static {
                b b2;
                a = new com.google.protobuf.c<b>(){

                    @Override
                    public final /* synthetic */ Object b(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                        return new b(e2, k2, 0);
                    }
                };
                c = b2 = new b();
                b2.e();
            }

            private b() {
                this.g = -1;
                this.h = -1;
                this.d = af.b();
            }

            /*
             * Exception decompiling
             */
            private b(com.google.protobuf.e var1_1, com.google.protobuf.k var2_6) {
                // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
                // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
                // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
                // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
                // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
                // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
                // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
                // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
                // org.benf.cfr.reader.Main.doJar(Main.java:129)
                // org.benf.cfr.reader.Main.main(Main.java:181)
                throw new IllegalStateException("Decompilation failed");
            }

            /* synthetic */ b(com.google.protobuf.e e2, com.google.protobuf.k k2, byte by2) {
                this(e2, k2);
            }

            private b(m.a<?> a2) {
                super(a2);
                this.g = -1;
                this.h = -1;
                this.d = a2.getUnknownFields();
            }

            /* synthetic */ b(m.a a2, byte by2) {
                this(a2);
            }

            public static b a() {
                return c;
            }

            private com.google.protobuf.d d() {
                Object object = this.f;
                if (object instanceof String) {
                    this.f = object = com.google.protobuf.d.a((String)object);
                    return object;
                }
                return (com.google.protobuf.d)object;
            }

            private void e() {
                this.f = "";
                this.b = false;
            }

            private a f() {
                return a.a().a(this);
            }

            public final boolean b() {
                if ((this.e & 1) == 1) {
                    return true;
                }
                return false;
            }

            public final boolean c() {
                if ((this.e & 2) == 2) {
                    return true;
                }
                return false;
            }

            public final x<b> getParserForType() {
                return a;
            }

            @Override
            public final int getSerializedSize() {
                int n2 = this.h;
                if (n2 != -1) {
                    return n2;
                }
                n2 = 0;
                if ((this.e & 1) == 1) {
                    n2 = com.google.protobuf.f.c(1, this.d()) + 0;
                }
                int n3 = n2;
                if ((this.e & 2) == 2) {
                    n3 = n2 + (com.google.protobuf.f.d(2) + 1);
                }
                this.h = n2 = n3 + this.getUnknownFields().getSerializedSize();
                return n2;
            }

            @Override
            public final af getUnknownFields() {
                return this.d;
            }

            @Override
            protected final m.e internalGetFieldAccessorTable() {
                return J.a(b.class, a.class);
            }

            @Override
            public final boolean isInitialized() {
                byte by2 = this.g;
                if (by2 != -1) {
                    if (by2 == 1) {
                        return true;
                    }
                    return false;
                }
                if (!this.b()) {
                    this.g = 0;
                    return false;
                }
                if (!this.c()) {
                    this.g = 0;
                    return false;
                }
                this.g = 1;
                return true;
            }

            @Override
            public final /* synthetic */ t.a newBuilderForType() {
                return a.a();
            }

            @Override
            protected final /* synthetic */ t.a newBuilderForType(m.b b2) {
                return new a(b2, 0);
            }

            @Override
            public final /* synthetic */ t.a toBuilder() {
                return this.f();
            }

            @Override
            public final /* synthetic */ u.a toBuilder() {
                return this.f();
            }

            @Override
            protected final Object writeReplace() {
                return super.writeReplace();
            }

            @Override
            public final void writeTo(com.google.protobuf.f f2) {
                this.getSerializedSize();
                if ((this.e & 1) == 1) {
                    f2.a(1, this.d());
                }
                if ((this.e & 2) == 2) {
                    f2.a(2, this.b);
                }
                this.getUnknownFields().writeTo(f2);
            }

            public static final class a
            extends m.a<a>
            implements f.a {
                private int c;
                private Object d = "";
                private boolean e;

                private a() {
                    boolean bl2 = com.google.protobuf.m.alwaysUseFieldBuilders;
                }

                private a(m.b b2) {
                    super(b2);
                    boolean bl2 = com.google.protobuf.m.alwaysUseFieldBuilders;
                }

                /* synthetic */ a(m.b b2, byte by2) {
                    this(b2);
                }

                static /* synthetic */ a a() {
                    return new a();
                }

                /*
                 * Unable to fully structure code
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 * Lifted jumps to return sites
                 */
                private a a(com.google.protobuf.e var1_1, com.google.protobuf.k var2_2) {
                    try {
                        var1_1 = b.a.b((com.google.protobuf.e)var1_1, var2_2);
                        if (var1_1 == null) return this;
                        this.a((b)var1_1);
                        return this;
                    }
                    catch (com.google.protobuf.o var2_3) {
                        var1_1 = (b)var2_3.a;
                        try {
                            throw var2_3;
                        }
                        catch (Throwable var2_4) {}
                        ** GOTO lbl-1000
                        catch (Throwable var2_6) {
                            var1_1 = null;
                        }
lbl-1000: // 2 sources:
                        {
                            if (var1_1 == null) throw var2_5;
                            this.a((b)var1_1);
                            throw var2_5;
                        }
                    }
                }

                private a a(t t2) {
                    if (t2 instanceof b) {
                        return this.a((b)t2);
                    }
                    super.mergeFrom(t2);
                    return this;
                }

                private a b() {
                    super.clear();
                    this.d = "";
                    this.c &= -2;
                    this.e = false;
                    this.c &= -3;
                    return this;
                }

                private a c() {
                    return new a().a(this.f());
                }

                private b d() {
                    b b2 = this.f();
                    if (!b2.isInitialized()) {
                        throw a.newUninitializedMessageException(b2);
                    }
                    return b2;
                }

                /*
                 * Enabled aggressive block sorting
                 */
                private b f() {
                    int n2 = 1;
                    b b2 = new b(this, 0);
                    int n3 = this.c;
                    if ((n3 & 1) != 1) {
                        n2 = 0;
                    }
                    b2.f = this.d;
                    int n4 = n2;
                    if ((n3 & 2) == 2) {
                        n4 = n2 | 2;
                    }
                    b2.b = this.e;
                    b2.e = n4;
                    this.onBuilt();
                    return b2;
                }

                public final a a(b b2) {
                    if (b2 == b.a()) {
                        return this;
                    }
                    if (b2.b()) {
                        this.c |= 1;
                        this.d = b2.f;
                        this.onChanged();
                    }
                    if (b2.c()) {
                        boolean bl2 = b2.b;
                        this.c |= 2;
                        this.e = bl2;
                        this.onChanged();
                    }
                    this.mergeUnknownFields(b2.getUnknownFields());
                    return this;
                }

                @Override
                public final /* synthetic */ t build() {
                    return this.d();
                }

                @Override
                public final /* synthetic */ u build() {
                    return this.d();
                }

                @Override
                public final /* synthetic */ t buildPartial() {
                    return this.f();
                }

                @Override
                public final /* synthetic */ u buildPartial() {
                    return this.f();
                }

                @Override
                public final /* synthetic */ a.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ m.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ t.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ u.a clear() {
                    return this.b();
                }

                @Override
                public final /* synthetic */ a.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ com.google.protobuf.b$a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ m.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ t.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ u.a clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ Object clone() {
                    return this.c();
                }

                @Override
                public final /* synthetic */ t getDefaultInstanceForType() {
                    return b.a();
                }

                @Override
                public final h.a getDescriptorForType() {
                    return I;
                }

                @Override
                protected final m.e internalGetFieldAccessorTable() {
                    return J.a(b.class, a.class);
                }

                /*
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                @Override
                public final boolean isInitialized() {
                    if ((this.c & 1) != 1) return false;
                    boolean bl2 = true;
                    if (!bl2) {
                        return false;
                    }
                    if ((this.c & 2) != 2) return false;
                    return true;
                }

                @Override
                public final /* synthetic */ a.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }

                @Override
                public final /* synthetic */ a.a mergeFrom(t t2) {
                    return this.a(t2);
                }

                @Override
                public final /* synthetic */ com.google.protobuf.b$a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }

                @Override
                public final /* synthetic */ t.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }

                @Override
                public final /* synthetic */ t.a mergeFrom(t t2) {
                    return this.a(t2);
                }

                @Override
                public final /* synthetic */ u.a mergeFrom(com.google.protobuf.e e2, com.google.protobuf.k k2) {
                    return this.a(e2, k2);
                }
            }

        }

    }

}

