/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import android.support.design.widget.f;
import com.google.protobuf.ah;
import com.google.protobuf.g;
import com.google.protobuf.l;
import com.google.protobuf.n;
import com.google.protobuf.o;
import com.google.protobuf.r;
import com.google.protobuf.t;
import com.google.protobuf.u;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class h {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static /* synthetic */ String a(g g2, a object, String string) {
        if (object != null) {
            return object.b + '.' + string;
        }
        object = string;
        if (g2.a().length() <= 0) return object;
        return g2.a() + '.' + string;
    }

    /*
     * Exception performing whole class analysis ignored.
     */
    public static final class a
    implements h {
        g.a a;
        final String b;
        final g c;
        private final int d;
        private final a e;
        private final a[] f;
        private final d[] g;
        private final f[] h;
        private final f[] i;

        /* synthetic */ a(g.a a2, g g2, int n2) {
            this(a2, g2, null, n2);
        }

        private a(g.a a2, g g2, a a3, int n2) {
            this.d = n2;
            this.a = a2;
            this.b = h.a(g2, a3, a2.b());
            this.c = g2;
            this.e = a3;
            this.f = new a[a2.e()];
            for (n2 = 0; n2 < a2.e(); ++n2) {
                this.f[n2] = new a(a2.c(n2), g2, this, n2);
            }
            this.g = new d[a2.f()];
            for (n2 = 0; n2 < a2.f(); ++n2) {
                this.g[n2] = new d(a2.d(n2), g2, this, n2, 0);
            }
            this.h = new f[a2.c()];
            for (n2 = 0; n2 < a2.c(); ++n2) {
                this.h[n2] = new f(a2.a(n2), g2, this, n2, false, 0);
            }
            this.i = new f[a2.d()];
            for (n2 = 0; n2 < a2.d(); ++n2) {
                this.i[n2] = new f(a2.b(n2), g2, this, n2, true, 0);
            }
            g2.c.a(this);
        }

        @Override
        public final String a() {
            return this.a.b();
        }

        public final boolean a(int n2) {
            for (g.a.b b2 : this.a.c) {
                if (b2.c > n2 || n2 >= b2.d) continue;
                return true;
            }
            return false;
        }

        @Override
        public final String b() {
            return this.b;
        }

        @Override
        public final g c() {
            return this.c;
        }

        public final List<f> d() {
            return Collections.unmodifiableList(Arrays.asList(this.h));
        }

        public final List<a> e() {
            return Collections.unmodifiableList(Arrays.asList(this.f));
        }

        public final List<d> f() {
            return Collections.unmodifiableList(Arrays.asList(this.g));
        }

        final void g() {
            int n2;
            int n3 = 0;
            a[] arra = this.f;
            int n4 = arra.length;
            for (n2 = 0; n2 < n4; ++n2) {
                arra[n2].g();
            }
            arra = this.h;
            n4 = arra.length;
            for (n2 = 0; n2 < n4; ++n2) {
                f.a((f)((Object)arra[n2]));
            }
            arra = this.i;
            n4 = arra.length;
            for (n2 = n3; n2 < n4; ++n2) {
                f.a((f)((Object)arra[n2]));
            }
        }
    }

    static final class com.google.protobuf.h$b {
        static final /* synthetic */ boolean c;
        final Map<a, f> a = new HashMap<a, f>();
        final Map<a, e> b = new HashMap<a, e>();
        private final Set<g> d = new HashSet<g>();
        private final Map<String, h> e = new HashMap<String, h>();

        /*
         * Enabled aggressive block sorting
         */
        static {
            boolean bl2 = !h.class.desiredAssertionStatus();
            c = bl2;
        }

        com.google.protobuf.h$b(g[] object) {
            for (int i2 = 0; i2 < object.length; ++i2) {
                this.d.add(object[i2]);
                this.a((g)object[i2]);
            }
            for (g g2 : this.d) {
                try {
                    this.a(g2.a(), g2);
                    continue;
                }
                catch (com.google.protobuf.h$c var2_4) {
                    if (!c) {
                        throw new AssertionError();
                    }
                    continue;
                }
            }
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        private h a(String var1_1, int var2_2) {
            var4_3 = this.e.get(var1_1);
            if (var4_3 != null) {
                var3_4 = var4_3;
                if (var2_2 == c.c) return var3_4;
                if (var2_2 == c.a) {
                    var3_4 = var4_3;
                    if (com.google.protobuf.h$b.b(var4_3) != false) return var3_4;
                }
                if (var2_2 == c.b && com.google.protobuf.h$b.c(var4_3)) {
                    return var4_3;
                }
            }
            var5_5 = this.d.iterator();
            do lbl-1000: // 3 sources:
            {
                if (var5_5.hasNext() == false) return null;
                var4_3 = var5_5.next().c.e.get(var1_1);
                if (var4_3 == null) ** GOTO lbl-1000
                var3_4 = var4_3;
                if (var2_2 == c.c) return var3_4;
                if (var2_2 != c.a) continue;
                var3_4 = var4_3;
                if (com.google.protobuf.h$b.b(var4_3) != false) return var3_4;
            } while (var2_2 != c.b || !com.google.protobuf.h$b.c(var4_3));
            return var4_3;
        }

        static /* synthetic */ Map a(com.google.protobuf.h$b b2) {
            return b2.a;
        }

        private void a(g object) {
            for (g g2 : Collections.unmodifiableList(Arrays.asList(object.b))) {
                if (!this.d.add(g2)) continue;
                this.a(g2);
            }
        }

        private static boolean b(h h2) {
            if (h2 instanceof com.google.protobuf.h$a || h2 instanceof d) {
                return true;
            }
            return false;
        }

        private static boolean c(h h2) {
            if (h2 instanceof com.google.protobuf.h$a || h2 instanceof d || h2 instanceof b || h2 instanceof j) {
                return true;
            }
            return false;
        }

        final h a(String string) {
            return this.a(string, c.c);
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        final h a(String var1_1, h var2_2, int var3_3) {
            if (var1_1.startsWith(".")) {
                var4_4 = this.a(var1_1.substring(1), var3_3);
lbl3: // 4 sources:
                do {
                    if (var4_4 != null) return var4_4;
                    throw new com.google.protobuf.h$c(var2_2, "\"" + var1_1 + "\" is not defined.", 0);
                    break;
                } while (true);
            }
            var7_5 = var1_1.indexOf(46);
            var4_4 = var7_5 == -1 ? var1_1 : var1_1.substring(0, var7_5);
            var6_6 = new StringBuilder(var2_2.b());
            do {
                if ((var8_8 = var6_6.lastIndexOf(".")) != -1) ** GOTO lbl13
                var4_4 = this.a(var1_1, var3_3);
                ** GOTO lbl3
lbl13: // 1 sources:
                var6_6.setLength(var8_8 + 1);
                var6_6.append((String)var4_4);
                var5_7 = this.a(var6_6.toString(), c.b);
                if (var5_7 == null) ** GOTO lbl22
                if (var7_5 == -1) break;
                var6_6.setLength(var8_8 + 1);
                var6_6.append(var1_1);
                var4_4 = this.a(var6_6.toString(), var3_3);
                ** GOTO lbl3
lbl22: // 1 sources:
                var6_6.setLength(var8_8);
            } while (true);
            var4_4 = var5_7;
            ** while (true)
        }

        final void a(h h2) {
            String string = h2.a();
            if (string.length() == 0) {
                throw new com.google.protobuf.h$c(h2, "Missing name.", 0);
            }
            int n2 = 1;
            for (int i2 = 0; i2 < string.length(); ++i2) {
                char c2 = string.charAt(i2);
                int n3 = n2;
                if (c2 >= '') {
                    n3 = 0;
                }
                n2 = n3;
                if (Character.isLetter(c2)) continue;
                n2 = n3;
                if (c2 == '_') continue;
                if (Character.isDigit(c2)) {
                    n2 = n3;
                    if (i2 > 0) continue;
                }
                n2 = 0;
            }
            if (n2 == 0) {
                throw new com.google.protobuf.h$c(h2, "\"" + string + "\" is not a valid identifier.", 0);
            }
            string = h2.b();
            n2 = string.lastIndexOf(46);
            h h3 = this.e.put(string, h2);
            if (h3 != null) {
                this.e.put(string, h3);
                if (h2.c() == h3.c()) {
                    if (n2 == -1) {
                        throw new com.google.protobuf.h$c(h2, "\"" + string + "\" is already defined.", 0);
                    }
                    throw new com.google.protobuf.h$c(h2, "\"" + string.substring(n2 + 1) + "\" is already defined in \"" + string.substring(0, n2) + "\".", 0);
                }
                throw new com.google.protobuf.h$c(h2, "\"" + string + "\" is already defined in file \"" + h3.c().a.b() + "\".", 0);
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        final void a(String string, g g2) {
            String string2;
            h h2;
            int n2 = string.lastIndexOf(46);
            if (n2 == -1) {
                string2 = string;
            } else {
                this.a(string.substring(0, n2), g2);
                string2 = string.substring(n2 + 1);
            }
            if ((h2 = (h)this.e.put(string, new b(string2, string, g2))) != null) {
                this.e.put(string, h2);
                if (!(h2 instanceof b)) {
                    throw new com.google.protobuf.h$c(g2, "\"" + string2 + "\" is already defined (as something other than a package) in file \"" + h2.c().a.b() + "\".", 0);
                }
            }
        }

        static final class a {
            private final h a;
            private final int b;

            a(h h2, int n2) {
                this.a = h2;
                this.b = n2;
            }

            /*
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            public final boolean equals(Object object) {
                if (!(object instanceof a)) {
                    return false;
                }
                object = (a)object;
                if (this.a != object.a) return false;
                if (this.b != object.b) return false;
                return true;
            }

            public final int hashCode() {
                return this.a.hashCode() * 65535 + this.b;
            }
        }

        static final class b
        implements h {
            private final String a;
            private final String b;
            private final g c;

            b(String string, String string2, g g2) {
                this.c = g2;
                this.b = string2;
                this.a = string;
            }

            @Override
            public final String a() {
                return this.a;
            }

            @Override
            public final String b() {
                return this.b;
            }

            @Override
            public final g c() {
                return this.c;
            }

            @Override
            public final t h() {
                return this.c.a;
            }
        }

        static final class c
        extends Enum<c> {
            public static final /* enum */ int a = 1;
            public static final /* enum */ int b = 2;
            public static final /* enum */ int c = 3;
            private static final /* synthetic */ int[] d;

            static {
                d = new int[]{a, b, c};
            }
        }

    }

    public static final class c
    extends Exception {
        private final String a;
        private final t b;
        private final String c;

        private c(g g2, String string) {
            super(g2.a.b() + ": " + string);
            this.a = g2.a.b();
            this.b = g2.a;
            this.c = string;
        }

        /* synthetic */ c(g g2, String string, byte by2) {
            this(g2, string);
        }

        private c(h h2, String string) {
            super(h2.b() + ": " + string);
            this.a = h2.b();
            this.b = h2.h();
            this.c = string;
        }

        /* synthetic */ c(h h2, String string, byte by2) {
            this(h2, string);
        }

        private c(h h2, String string, Throwable throwable) {
            this(h2, string);
            this.initCause(throwable);
        }

        /* synthetic */ c(h h2, String string, Throwable throwable, byte by2) {
            this(h2, string, throwable);
        }
    }

    public static final class d
    implements f.a<e>,
    h {
        final String a;
        final g b;
        private final int c;
        private g.b d;
        private final a e;
        private e[] f;

        private d(g.b b2, g g2, a a2, int n2) {
            this.c = n2;
            this.d = b2;
            this.a = h.a(g2, a2, b2.b());
            this.b = g2;
            this.e = a2;
            if (b2.c() == 0) {
                throw new c((h)this, "Enums must contain at least one value.", 0);
            }
            this.f = new e[b2.c()];
            for (n2 = 0; n2 < b2.c(); ++n2) {
                this.f[n2] = new e(b2.a(n2), g2, this, n2, 0);
            }
            g2.c.a(this);
        }

        /* synthetic */ d(g.b b2, g g2, a a2, int n2, byte by2) {
            this(b2, g2, a2, n2);
        }

        public final e a(int n2) {
            return (e)this.b.c.b.get(new b.a(this, n2));
        }

        @Override
        public final String a() {
            return this.d.b();
        }

        @Override
        public final String b() {
            return this.a;
        }

        @Override
        public final g c() {
            return this.b;
        }

        public final List<e> d() {
            return Collections.unmodifiableList(Arrays.asList(this.f));
        }
    }

    public static final class e
    implements h,
    n {
        public final int a;
        g.d b;
        public final d c;
        private final String d;
        private final g e;

        private e(g.d object, g object2, d h2, int n2) {
            this.a = n2;
            this.b = object;
            this.e = object2;
            this.c = h2;
            this.d = h2.a + '.' + object.b();
            object2.c.a(this);
            object = object2.c;
            object2 = new b.a(this.c, this.getNumber());
            h2 = object.b.put((b.a)object2, this);
            if (h2 != null) {
                object.b.put((b.a)object2, (e)h2);
            }
        }

        /* synthetic */ e(g.d d2, g g2, d d3, int n2, byte by2) {
            this(d2, g2, d3, n2);
        }

        @Override
        public final String a() {
            return this.b.b();
        }

        @Override
        public final String b() {
            return this.d;
        }

        @Override
        public final g c() {
            return this.e;
        }

        @Override
        public final int getNumber() {
            return this.b.c;
        }
    }

    public static final class f
    implements h,
    l.a<f>,
    Comparable<f> {
        private static final ah.a[] g = ah.a.values();
        final int a;
        g.f b;
        final String c;
        final com.google.protobuf.h$a d;
        b e;
        com.google.protobuf.h$a f;
        private final g h;
        private com.google.protobuf.h$a i;
        private d j;
        private Object k;

        static {
            if (b.values().length != g.f.c.values().length) {
                throw new RuntimeException("descriptor.proto has a new declared type but Desrciptors.java wasn't updated.");
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        private f(g.f f2, g g2, com.google.protobuf.h$a a2, int n2, boolean bl2) {
            this.a = n2;
            this.b = f2;
            this.c = h.a(g2, a2, f2.b());
            this.h = g2;
            if (f2.c()) {
                this.e = b.a(f2.e);
            }
            if (this.b.c <= 0) {
                throw new c((h)this, "Field numbers must be positive integers.", 0);
            }
            if (f2.f.d && !this.l()) {
                throw new c((h)this, "[packed = true] can only be specified for repeated primitive fields.", 0);
            }
            if (bl2) {
                if (!f2.f()) {
                    throw new c((h)this, "FieldDescriptorProto.extendee not set for extension field.", 0);
                }
                this.f = null;
                this.d = a2 != null ? a2 : null;
            } else {
                if (f2.f()) {
                    throw new c((h)this, "FieldDescriptorProto.extendee set for non-extension field.", 0);
                }
                this.f = a2;
                this.d = null;
            }
            g2.c.a(this);
        }

        /* synthetic */ f(g.f f2, g g2, com.google.protobuf.h$a a2, int n2, boolean bl2, byte by2) {
            this(f2, g2, a2, n2, bl2);
        }

        /*
         * Exception decompiling
         */
        static /* synthetic */ void a(f var0) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.rebuildSwitches(SwitchReplacer.java:334)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:539)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        @Override
        public final u.a a(u.a a2, u u2) {
            return ((t.a)a2).mergeFrom((t)u2);
        }

        @Override
        public final String a() {
            return this.b.b();
        }

        @Override
        public final String b() {
            return this.c;
        }

        @Override
        public final g c() {
            return this.h;
        }

        @Override
        public final /* synthetic */ int compareTo(Object object) {
            object = (f)object;
            if (object.f != this.f) {
                throw new IllegalArgumentException("FieldDescriptors can only be compared to other FieldDescriptors for fields of the same message type.");
            }
            return this.b.c - object.b.c;
        }

        @Override
        public final int d() {
            return this.b.c;
        }

        @Override
        public final ah.b e() {
            return this.f().s;
        }

        @Override
        public final ah.a f() {
            return g[this.e.ordinal()];
        }

        public final boolean g() {
            if (this.b.d == g.f.b.b) {
                return true;
            }
            return false;
        }

        public final boolean i() {
            if (this.b.d == g.f.b.a) {
                return true;
            }
            return false;
        }

        @Override
        public final boolean j() {
            if (this.b.d == g.f.b.c) {
                return true;
            }
            return false;
        }

        @Override
        public final boolean k() {
            return this.b.f.d;
        }

        public final boolean l() {
            if (this.j() && this.f().a()) {
                return true;
            }
            return false;
        }

        public final Object m() {
            if (this.e.s == a.i) {
                throw new UnsupportedOperationException("FieldDescriptor.getDefaultValue() called on an embedded message field.");
            }
            return this.k;
        }

        public final com.google.protobuf.h$a n() {
            if (this.e.s != a.i) {
                throw new UnsupportedOperationException("This field is not of message type.");
            }
            return this.i;
        }

        public final d o() {
            if (this.e.s != a.h) {
                throw new UnsupportedOperationException("This field is not of enum type.");
            }
            return this.j;
        }

        public static enum a {
            a(0),
            b(0),
            c(Float.valueOf(0.0f)),
            d(0.0),
            e(false),
            f(""),
            g(com.google.protobuf.d.a),
            h(null),
            i(null);
            
            private final Object j;

            private a(Object object) {
                this.j = object;
            }

            static /* synthetic */ Object a(a a2) {
                return a2.j;
            }
        }

        public static enum b {
            a(a.d),
            b(a.c),
            c(a.b),
            d(a.b),
            e(a.a),
            f(a.b),
            g(a.a),
            h(a.e),
            i(a.f),
            j(a.i),
            k(a.i),
            l(a.g),
            m(a.a),
            n(a.h),
            o(a.a),
            p(a.b),
            q(a.a),
            r(a.b);
            
            a s;

            private b(a a2) {
                this.s = a2;
            }

            public static b a(g.f.c c2) {
                return b.values()[c2.getNumber() - 1];
            }
        }

    }

    /*
     * Exception performing whole class analysis ignored.
     */
    public static final class g {
        g.h a;
        final g[] b;
        final b c;
        private final com.google.protobuf.h$a[] d;
        private final d[] e;
        private final j[] f;
        private final f[] g;
        private final g[] h;

        private g(g.h h2, g[] arrg, b b2) {
            int n2;
            this.c = b2;
            this.a = h2;
            this.h = (g[])arrg.clone();
            this.b = new g[h2.d()];
            for (n2 = 0; n2 < h2.d(); ++n2) {
                int n3 = h2.a(n2);
                if (n3 < 0 || n3 >= this.h.length) {
                    throw new c(this, "Invalid public dependency index.", 0);
                }
                this.b[n2] = this.h[h2.a(n2)];
            }
            b2.a(this.a(), this);
            this.d = new com.google.protobuf.h$a[h2.e()];
            for (n2 = 0; n2 < h2.e(); ++n2) {
                this.d[n2] = new com.google.protobuf.h$a(h2.b(n2), this, n2);
            }
            this.e = new d[h2.f()];
            for (n2 = 0; n2 < h2.f(); ++n2) {
                this.e[n2] = new d(h2.c(n2), this, null, n2, 0);
            }
            this.f = new j[h2.g()];
            for (n2 = 0; n2 < h2.g(); ++n2) {
                this.f[n2] = new j(h2.d(n2), this, n2, 0);
            }
            this.g = new f[h2.h()];
            for (n2 = 0; n2 < h2.h(); ++n2) {
                this.g[n2] = new f(h2.e(n2), this, null, n2, true, 0);
            }
        }

        private static g a(g.h arra, g[] arrg) {
            int n2;
            int n3 = 0;
            g g2 = new g((g.h)arra, arrg, new b(arrg));
            if (arrg.length != arra.c()) {
                throw new c(g2, "Dependencies passed to FileDescriptor.buildFrom() don't match those listed in the FileDescriptorProto.", 0);
            }
            for (n2 = 0; n2 < arra.c(); ++n2) {
                if (arrg[n2].a.b().equals((String)arra.d.get(n2))) continue;
                throw new c(g2, "Dependencies passed to FileDescriptor.buildFrom() don't match those listed in the FileDescriptorProto.", 0);
            }
            arra = g2.d;
            int n4 = arra.length;
            for (n2 = 0; n2 < n4; ++n2) {
                arra[n2].g();
            }
            arra = g2.f;
            int n5 = arra.length;
            for (n2 = 0; n2 < n5; ++n2) {
                for (g g3 : arra[n2].c) {
                    h h2 = g3.b.c.a(g3.a.c(), (h)((Object)g3), b.c.a);
                    if (!(h2 instanceof com.google.protobuf.h$a)) {
                        throw new c((h)((Object)g3), "\"" + g3.a.c() + "\" is not a message type.", 0);
                    }
                    g3.c = (com.google.protobuf.h$a)h2;
                    h2 = g3.b.c.a(g3.a.d(), (h)((Object)g3), b.c.a);
                    if (!(h2 instanceof com.google.protobuf.h$a)) {
                        throw new c((h)((Object)g3), "\"" + g3.a.d() + "\" is not a message type.", 0);
                    }
                    g3.d = (com.google.protobuf.h$a)h2;
                }
            }
            arra = g2.g;
            n4 = arra.length;
            for (n2 = n3; n2 < n4; ++n2) {
                f.a((f)((Object)arra[n2]));
            }
            return g2;
        }

        public static void a(String[] object, g[] object2, a a2) {
            StringBuilder stringBuilder = new StringBuilder();
            int n2 = object.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                stringBuilder.append(object[i2]);
            }
            try {
                object = stringBuilder.toString().getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException var0_1) {
                throw new RuntimeException("Standard encoding ISO-8859-1 not supported by JVM.", var0_1);
            }
            try {
                object = g.h.a((byte[])object);
            }
            catch (o var0_2) {
                throw new IllegalArgumentException("Failed to parse protocol buffer descriptor for generated code.", var0_2);
            }
            try {
                object2 = g.a((g.h)object, (g[])object2);
                a2.a((g)object2);
                return;
            }
            catch (c var1_4) {
                throw new IllegalArgumentException("Invalid embedded descriptor for \"" + object.b() + "\".", var1_4);
            }
        }

        public final String a() {
            g.h h2 = this.a;
            Object object = h2.c;
            if (object instanceof String) {
                return (String)object;
            }
            object = (com.google.protobuf.d)object;
            String string = object.d();
            if (object.e()) {
                h2.c = string;
            }
            return string;
        }

        public final List<com.google.protobuf.h$a> b() {
            return Collections.unmodifiableList(Arrays.asList(this.d));
        }

        public static interface a {
            public com.google.protobuf.j a(g var1);
        }

    }

    static interface h {
        public String a();

        public String b();

        public g c();

        public t h();
    }

    public static final class i
    implements h {
        g.k a;
        final g b;
        a c;
        a d;
        private final int e;
        private final String f;
        private final j g;

        private i(g.k k2, g g2, j j2, int n2) {
            this.e = n2;
            this.a = k2;
            this.b = g2;
            this.g = j2;
            this.f = j2.b + '.' + k2.b();
            g2.c.a(this);
        }

        /* synthetic */ i(g.k k2, g g2, j j2, int n2, byte by2) {
            this(k2, g2, j2, n2);
        }

        @Override
        public final String a() {
            return this.a.b();
        }

        @Override
        public final String b() {
            return this.f;
        }

        @Override
        public final g c() {
            return this.b;
        }
    }

    public static final class j
    implements h {
        g.m a;
        final String b;
        i[] c;
        private final int d;
        private final g e;

        private j(g.m m2, g g2, int n2) {
            this.d = n2;
            this.a = m2;
            this.b = h.a(g2, null, m2.b());
            this.e = g2;
            this.c = new i[m2.c()];
            for (n2 = 0; n2 < m2.c(); ++n2) {
                this.c[n2] = new i(m2.a(n2), g2, this, n2, 0);
            }
            g2.c.a(this);
        }

        /* synthetic */ j(g.m m2, g g2, int n2, byte by2) {
            this(m2, g2, n2);
        }

        @Override
        public final String a() {
            return this.a.b();
        }

        @Override
        public final String b() {
            return this.b;
        }

        @Override
        public final g c() {
            return this.e;
        }
    }

}

