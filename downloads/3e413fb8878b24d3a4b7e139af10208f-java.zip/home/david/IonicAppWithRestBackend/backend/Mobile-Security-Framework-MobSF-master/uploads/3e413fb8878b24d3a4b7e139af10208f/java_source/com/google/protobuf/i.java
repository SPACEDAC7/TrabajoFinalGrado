/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.a;
import com.google.protobuf.ac;
import com.google.protobuf.af;
import com.google.protobuf.b;
import com.google.protobuf.c;
import com.google.protobuf.e;
import com.google.protobuf.f;
import com.google.protobuf.g;
import com.google.protobuf.h;
import com.google.protobuf.k;
import com.google.protobuf.l;
import com.google.protobuf.o;
import com.google.protobuf.t;
import com.google.protobuf.u;
import com.google.protobuf.x;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class i
extends com.google.protobuf.a {
    private final h.a a;
    private final l<h.f> b;
    private final af c;
    private int d = -1;

    private i(h.a a2, l<h.f> l2, af af2) {
        this.a = a2;
        this.b = l2;
        this.c = af2;
    }

    /* synthetic */ i(h.a a2, l l2, af af2, byte by2) {
        this(a2, l2, af2);
    }

    private a a() {
        return new a(this.a, 0);
    }

    public static i a(h.a a2) {
        return new i(a2, l.<h.f>b(), af.b());
    }

    private void a(h.f f2) {
        if (f2.f != this.a) {
            throw new IllegalArgumentException("FieldDescriptor does not match message type.");
        }
    }

    private a b() {
        return this.a().a(this);
    }

    public static a b(h.a a2) {
        return new a(a2, 0);
    }

    private static boolean b(h.a object, l<h.f> l2) {
        for (h.f f2 : object.d()) {
            if (!f2.g() || l2.a(f2)) continue;
            return false;
        }
        return l2.f();
    }

    @Override
    public final Map<h.f, Object> getAllFields() {
        return this.b.e();
    }

    @Override
    public final /* synthetic */ t getDefaultInstanceForType() {
        return i.a(this.a);
    }

    @Override
    public final h.a getDescriptorForType() {
        return this.a;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object getField(h.f f2) {
        List list;
        this.a(f2);
        List list2 = list = this.b.b(f2);
        if (list != null) return list2;
        if (f2.j()) {
            return Collections.emptyList();
        }
        if (f2.e.s != h.f.a.i) return f2.m();
        return i.a(f2.n());
    }

    public final x<i> getParserForType() {
        return new c<i>(){

            private i c(e e2, k k2) {
                a a2 = i.b(i.this.a);
                try {
                    a2.mergeFrom(e2, k2);
                    return a2.a();
                }
                catch (o var1_2) {
                    var1_2.a = a2.a();
                    throw var1_2;
                }
                catch (IOException var1_3) {
                    o o2 = new o(var1_3.getMessage());
                    o2.a = a2.a();
                    throw o2;
                }
            }

            @Override
            public final /* synthetic */ Object b(e e2, k k2) {
                return this.c(e2, k2);
            }
        };
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int getSerializedSize() {
        int n2 = this.d;
        if (n2 != -1) {
            return n2;
        }
        if (this.a.a.d.c) {
            Object object = this.b;
            n2 = 0;
            for (int i2 = 0; i2 < object.a.b(); n2 += l.a(object.a.b((int)i2)), ++i2) {
            }
            object = object.a.c().iterator();
            while (object.hasNext()) {
                n2 += l.a((Map.Entry)object.next());
            }
            n2 = this.c.c() + n2;
        } else {
            n2 = this.b.g() + this.c.getSerializedSize();
        }
        this.d = n2;
        return n2;
    }

    @Override
    public final af getUnknownFields() {
        return this.c;
    }

    @Override
    public final boolean hasField(h.f f2) {
        this.a(f2);
        return this.b.a(f2);
    }

    @Override
    public final boolean isInitialized() {
        return i.b(this.a, this.b);
    }

    @Override
    public final /* synthetic */ t.a newBuilderForType() {
        return this.a();
    }

    @Override
    public final /* synthetic */ t.a toBuilder() {
        return this.b();
    }

    @Override
    public final /* synthetic */ u.a toBuilder() {
        return this.b();
    }

    @Override
    public final void writeTo(f f2) {
        int n2;
        if (this.a.a.d.c) {
            Object object = this.b;
            for (n2 = 0; n2 < object.a.b(); ++n2) {
                l.a(object.a.b(n2), f2);
            }
            object = object.a.c().iterator();
            while (object.hasNext()) {
                l.a((Map.Entry)object.next(), f2);
            }
            this.c.a(f2);
            return;
        }
        l<h.f> l2 = this.b;
        for (n2 = 0; n2 < l2.a.b(); ++n2) {
            Map.Entry entry = l2.a.b(n2);
            l.a((l.a)entry.getKey(), entry.getValue(), f2);
        }
        for (Map.Entry entry : l2.a.c()) {
            l.a((l.a)entry.getKey(), entry.getValue(), f2);
        }
        this.c.writeTo(f2);
    }

    public static final class a
    extends a.a<a> {
        private final h.a a;
        private l<h.f> b;
        private af c;

        private a(h.a a2) {
            this.a = a2;
            this.b = l.a();
            this.c = af.b();
        }

        /* synthetic */ a(h.a a2, byte by2) {
            this(a2);
        }

        private a a(af af2) {
            this.c = af.a(this.c).a(af2).a();
            return this;
        }

        private void a(h.f f2) {
            if (f2.f != this.a) {
                throw new IllegalArgumentException("FieldDescriptor does not match message type.");
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        private a b() {
            if (this.b.b) {
                this.b = l.a();
            } else {
                l<h.f> l2 = this.b;
                l2.a.clear();
                l2.c = false;
            }
            this.c = af.b();
            return this;
        }

        private i c() {
            if (!this.isInitialized()) {
                throw a.newUninitializedMessageException(new i(this.a, this.b, this.c, 0));
            }
            return this.a();
        }

        private a d() {
            a a2 = new a(this.a);
            a2.b.a(this.b);
            a2.a(this.c);
            return a2;
        }

        private void e() {
            if (this.b.b) {
                this.b = this.b.d();
            }
        }

        public final a a(t t2) {
            if (t2 instanceof i) {
                if (((i)(t2 = (i)t2)).a != this.a) {
                    throw new IllegalArgumentException("mergeFrom(Message) can only merge messages of the same type.");
                }
                this.e();
                this.b.a(((i)t2).b);
                this.a(((i)t2).c);
                return this;
            }
            return (a)super.mergeFrom(t2);
        }

        public final i a() {
            this.b.c();
            return new i(this.a, this.b, this.c, 0);
        }

        @Override
        public final /* synthetic */ t.a addRepeatedField(h.f f2, Object object) {
            this.a(f2);
            this.e();
            this.b.b(f2, object);
            return this;
        }

        @Override
        public final /* synthetic */ t build() {
            return this.c();
        }

        @Override
        public final /* synthetic */ u build() {
            return this.c();
        }

        @Override
        public final /* synthetic */ t buildPartial() {
            return this.a();
        }

        @Override
        public final /* synthetic */ u buildPartial() {
            return this.a();
        }

        @Override
        public final /* synthetic */ a.a clear() {
            return this.b();
        }

        @Override
        public final /* synthetic */ t.a clear() {
            return this.b();
        }

        @Override
        public final /* synthetic */ u.a clear() {
            return this.b();
        }

        @Override
        public final /* synthetic */ t.a clearField(h.f f2) {
            this.a(f2);
            this.e();
            this.b.c(f2);
            return this;
        }

        @Override
        public final /* synthetic */ a.a clone() {
            return this.d();
        }

        @Override
        public final /* synthetic */ b.a clone() {
            return this.d();
        }

        @Override
        public final /* synthetic */ t.a clone() {
            return this.d();
        }

        @Override
        public final /* synthetic */ u.a clone() {
            return this.d();
        }

        @Override
        public final /* synthetic */ Object clone() {
            return this.d();
        }

        @Override
        public final Map<h.f, Object> getAllFields() {
            return this.b.e();
        }

        @Override
        public final /* synthetic */ t getDefaultInstanceForType() {
            return i.a(this.a);
        }

        @Override
        public final h.a getDescriptorForType() {
            return this.a;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        public final Object getField(h.f f2) {
            Object object;
            this.a(f2);
            Object object2 = object = this.b.b(f2);
            if (object != null) return object2;
            if (f2.e.s != h.f.a.i) return f2.m();
            return i.a(f2.n());
        }

        @Override
        public final t.a getFieldBuilder(h.f f2) {
            throw new UnsupportedOperationException("getFieldBuilder() called on a dynamic message type.");
        }

        @Override
        public final af getUnknownFields() {
            return this.c;
        }

        @Override
        public final boolean hasField(h.f f2) {
            this.a(f2);
            return this.b.a(f2);
        }

        @Override
        public final boolean isInitialized() {
            return i.b(this.a, this.b);
        }

        @Override
        public final /* synthetic */ a.a mergeFrom(t t2) {
            return this.a(t2);
        }

        @Override
        public final /* synthetic */ t.a mergeFrom(t t2) {
            return this.a(t2);
        }

        @Override
        public final /* synthetic */ a.a mergeUnknownFields(af af2) {
            return this.a(af2);
        }

        @Override
        public final /* synthetic */ t.a mergeUnknownFields(af af2) {
            return this.a(af2);
        }

        @Override
        public final /* synthetic */ t.a newBuilderForField(h.f f2) {
            this.a(f2);
            if (f2.e.s != h.f.a.i) {
                throw new IllegalArgumentException("newBuilderForField is only valid for fields with message type.");
            }
            return new a(f2.n());
        }

        @Override
        public final /* synthetic */ t.a setField(h.f f2, Object object) {
            this.a(f2);
            this.e();
            this.b.a(f2, object);
            return this;
        }
    }

}

