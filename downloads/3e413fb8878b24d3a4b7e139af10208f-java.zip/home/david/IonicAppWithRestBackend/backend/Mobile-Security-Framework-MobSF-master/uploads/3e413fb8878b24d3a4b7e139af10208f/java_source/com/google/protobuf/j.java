/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import android.support.design.widget.FloatingActionButton;
import com.google.protobuf.h;
import com.google.protobuf.k;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class j
extends k {
    private static final j d = new j(0);
    private final Map<String, FloatingActionButton> b;
    private final Map<a, FloatingActionButton> c;

    private j() {
        this.b = new HashMap<String, FloatingActionButton>();
        this.c = new HashMap<a, FloatingActionButton>();
    }

    private j(byte by2) {
        super(k.a);
        this.b = Collections.emptyMap();
        this.c = Collections.emptyMap();
    }

    public static j a() {
        return d;
    }

    public final FloatingActionButton a(h.a a2, int n2) {
        return this.c.get(new a(a2, n2));
    }

    static final class a {
        private final h.a a;
        private final int b;

        a(h.a a2, int n2) {
            this.a = a2;
            this.b = n2;
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public final boolean equals(Object object) {
            if (!(object instanceof a)) {
                return false;
            }
            object = (a)object;
            if (this.a != object.a) return false;
            if (this.b != object.b) return false;
            return true;
        }

        public final int hashCode() {
            return this.a.hashCode() * 65535 + this.b;
        }
    }

}

