/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class k {
    static final k a;
    private static volatile boolean b;
    private final Map<Object, Object<?, ?>> c;

    static {
        b = false;
        a = new k(0);
    }

    k() {
        this.c = new HashMap();
    }

    private k(byte by2) {
        this.c = Collections.emptyMap();
    }

    k(k k2) {
        if (k2 == a) {
            this.c = Collections.emptyMap();
            return;
        }
        this.c = Collections.unmodifiableMap(k2.c);
    }

    public static boolean b() {
        return b;
    }

    public static k c() {
        return a;
    }
}

