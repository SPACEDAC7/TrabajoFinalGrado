/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.ac;
import com.google.protobuf.ah;
import com.google.protobuf.d;
import com.google.protobuf.e;
import com.google.protobuf.f;
import com.google.protobuf.n;
import com.google.protobuf.p;
import com.google.protobuf.u;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

final class l<FieldDescriptorType extends a<FieldDescriptorType>> {
    private static final l d = new l<FieldDescriptorType>(0);
    final ac<FieldDescriptorType, Object> a;
    boolean b;
    boolean c = false;

    private l() {
        this.a = ac.a(16);
    }

    private l(byte by2) {
        this.a = ac.a(0);
        this.c();
    }

    private static int a(ah.a a2, int n2, Object object) {
        int n3;
        n2 = n3 = f.d(n2);
        if (a2 == ah.a.j) {
            n2 = n3 << 1;
        }
        return n2 + l.b(a2, object);
    }

    static int a(ah.a a2, boolean bl2) {
        if (bl2) {
            return 2;
        }
        return a2.t;
    }

    static int a(Map.Entry<FieldDescriptorType, Object> object) {
        a a2 = (a)object.getKey();
        Object object2 = object.getValue();
        if (a2.e() == ah.b.i && !a2.j() && !a2.k()) {
            if (object2 instanceof p) {
                int n2 = ((a)object.getKey()).d();
                object = (p)object2;
                int n3 = f.d(1);
                n2 = f.e(2, n2);
                int n4 = f.d(3);
                return f.a((p)object) + n4 + ((n3 << 1) + n2);
            }
            return f.e(((a)object.getKey()).d(), (u)object2);
        }
        return l.c(a2, object2);
    }

    public static <T extends a<T>> l<T> a() {
        return new l<FieldDescriptorType>();
    }

    public static Object a(e e2, ah.a object) {
        switch (.b[object.ordinal()]) {
            default: {
                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
            }
            case 1: {
                return Double.longBitsToDouble(e2.n());
            }
            case 2: {
                return Float.valueOf(Float.intBitsToFloat(e2.m()));
            }
            case 3: {
                return e2.l();
            }
            case 4: {
                return e2.l();
            }
            case 5: {
                return e2.k();
            }
            case 6: {
                return e2.n();
            }
            case 7: {
                return e2.m();
            }
            case 8: {
                return e2.e();
            }
            case 9: {
                int n2 = e2.k();
                if (n2 <= e2.b - e2.c && n2 > 0) {
                    object = new String(e2.a, e2.c, n2, "UTF-8");
                    e2.c = n2 + e2.c;
                    return object;
                }
                return new String(e2.e(n2), "UTF-8");
            }
            case 10: {
                return e2.f();
            }
            case 11: {
                return e2.g();
            }
            case 12: {
                return e2.m();
            }
            case 13: {
                return e2.n();
            }
            case 14: {
                return e2.i();
            }
            case 15: {
                return e2.j();
            }
            case 16: {
                throw new IllegalArgumentException("readPrimitiveField() cannot handle nested groups.");
            }
            case 17: {
                throw new IllegalArgumentException("readPrimitiveField() cannot handle embedded messages.");
            }
            case 18: 
        }
        throw new IllegalArgumentException("readPrimitiveField() cannot handle enums.");
    }

    /*
     * Enabled aggressive block sorting
     */
    static void a(ah.a a2, Object object) {
        boolean bl2 = false;
        if (object == null) {
            throw new NullPointerException();
        }
        switch (.a[a2.s.ordinal()]) {
            case 1: {
                bl2 = object instanceof Integer;
                break;
            }
            case 2: {
                bl2 = object instanceof Long;
                break;
            }
            case 3: {
                bl2 = object instanceof Float;
                break;
            }
            case 4: {
                bl2 = object instanceof Double;
                break;
            }
            case 5: {
                bl2 = object instanceof Boolean;
                break;
            }
            case 6: {
                bl2 = object instanceof String;
                break;
            }
            case 7: {
                bl2 = object instanceof d;
                break;
            }
            case 8: {
                bl2 = object instanceof n;
                break;
            }
            case 9: {
                if (!(object instanceof u) && !(object instanceof p)) break;
                return;
            }
        }
        if (!bl2) {
            throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
        }
    }

    private static void a(f f2, ah.a a2, int n2, Object object) {
        if (a2 == ah.a.j) {
            f2.a(n2, (u)object);
            return;
        }
        f2.g(n2, l.a(a2, false));
        l.a(f2, a2, object);
    }

    private static void a(f f2, ah.a arrby, Object object) {
        switch (.b[arrby.ordinal()]) {
            default: {
                return;
            }
            case 1: {
                f2.a((Double)object);
                return;
            }
            case 2: {
                f2.g(Float.floatToRawIntBits(((Float)object).floatValue()));
                return;
            }
            case 3: {
                f2.a((Long)object);
                return;
            }
            case 4: {
                f2.a((Long)object);
                return;
            }
            case 5: {
                f2.b((Integer)object);
                return;
            }
            case 6: {
                f2.c((Long)object);
                return;
            }
            case 7: {
                f2.g((Integer)object);
                return;
            }
            case 8: {
                f2.a((Boolean)object);
                return;
            }
            case 9: {
                arrby = ((String)object).getBytes("UTF-8");
                f2.e(arrby.length);
                int n2 = arrby.length;
                if (f2.b - f2.c >= n2) {
                    System.arraycopy(arrby, 0, f2.a, f2.c, n2);
                    f2.c += n2;
                    return;
                }
                int n3 = f2.b - f2.c;
                System.arraycopy(arrby, 0, f2.a, f2.c, n3);
                f2.c = f2.b;
                f2.a();
                if ((n2 -= n3) <= f2.b) {
                    System.arraycopy(arrby, n3, f2.a, 0, n2);
                    f2.c = n2;
                    return;
                }
                f2.d.write(arrby, n3, n2);
                return;
            }
            case 16: {
                ((u)object).writeTo(f2);
                return;
            }
            case 17: {
                f2.a((u)object);
                return;
            }
            case 10: {
                f2.a((d)object);
                return;
            }
            case 11: {
                f2.e((Integer)object);
                return;
            }
            case 12: {
                f2.g((Integer)object);
                return;
            }
            case 13: {
                f2.c((Long)object);
                return;
            }
            case 14: {
                f2.e(f.h((Integer)object));
                return;
            }
            case 15: {
                f2.a(f.d((Long)object));
                return;
            }
            case 18: 
        }
        f2.b(((n)object).getNumber());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void a(a<?> iterator, Object object, f f2) {
        ah.a a2 = iterator.f();
        int n2 = iterator.d();
        if (iterator.j()) {
            object = (List)object;
            if (iterator.k()) {
                f2.g(n2, 2);
                n2 = 0;
                iterator = object.iterator();
                while (iterator.hasNext()) {
                    n2 += l.b(a2, iterator.next());
                }
                f2.e(n2);
                iterator = object.iterator();
                while (iterator.hasNext()) {
                    l.a(f2, a2, iterator.next());
                }
                return;
            } else {
                iterator = object.iterator();
                while (iterator.hasNext()) {
                    l.a(f2, a2, n2, iterator.next());
                }
            }
            return;
        }
        if (object instanceof p) {
            l.a(f2, a2, n2, ((p)object).a());
            return;
        }
        l.a(f2, a2, n2, object);
    }

    static void a(Map.Entry<FieldDescriptorType, Object> entry, f f2) {
        a a2 = (a)entry.getKey();
        if (a2.e() == ah.b.i && !a2.j() && !a2.k()) {
            f2.c(((a)entry.getKey()).d(), (u)entry.getValue());
            return;
        }
        l.a(a2, entry.getValue(), f2);
    }

    private static void a(Map<FieldDescriptorType, Object> map, Map.Entry<FieldDescriptorType, Object> object) {
        a a2 = (a)object.getKey();
        if ((object = object.getValue()) instanceof p) {
            map.put((a)a2, ((p)object).a());
            return;
        }
        map.put((a)a2, object);
    }

    private static int b(ah.a a2, Object object) {
        switch (.b[a2.ordinal()]) {
            default: {
                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
            }
            case 1: {
                ((Double)object).doubleValue();
                return 8;
            }
            case 2: {
                ((Float)object).floatValue();
                return 4;
            }
            case 3: {
                return f.b((Long)object);
            }
            case 4: {
                return f.b((Long)object);
            }
            case 5: {
                return f.c((Integer)object);
            }
            case 6: {
                ((Long)object).longValue();
                return 8;
            }
            case 7: {
                ((Integer)object).intValue();
                return 4;
            }
            case 8: {
                ((Boolean)object).booleanValue();
                return 1;
            }
            case 9: {
                return f.a((String)object);
            }
            case 16: {
                return ((u)object).getSerializedSize();
            }
            case 10: {
                return f.b((d)object);
            }
            case 11: {
                return f.f((Integer)object);
            }
            case 12: {
                ((Integer)object).intValue();
                return 4;
            }
            case 13: {
                ((Long)object).longValue();
                return 8;
            }
            case 14: {
                return f.f(f.h((Integer)object));
            }
            case 15: {
                return f.b(f.d((Long)object));
            }
            case 17: {
                if (object instanceof p) {
                    return f.a((p)object);
                }
                return f.b((u)object);
            }
            case 18: 
        }
        return f.c(((n)object).getNumber());
    }

    public static <T extends a<T>> l<T> b() {
        return d;
    }

    private static boolean b(Map.Entry<FieldDescriptorType, Object> iterator) {
        a a2 = (a)iterator.getKey();
        if (a2.e() == ah.b.i) {
            if (a2.j()) {
                iterator = ((List)iterator.getValue()).iterator();
                while (iterator.hasNext()) {
                    if (((u)iterator.next()).isInitialized()) continue;
                    return false;
                }
            } else if ((iterator = iterator.getValue()) instanceof u) {
                if (!((u)((Object)iterator)).isInitialized()) {
                    return false;
                }
            } else {
                if (iterator instanceof p) {
                    return true;
                }
                throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
            }
        }
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int c(a<?> iterator, Object object) {
        int n2 = 0;
        int n3 = 0;
        ah.a a2 = iterator.f();
        int n4 = iterator.d();
        if (!iterator.j()) return l.a(a2, n4, object);
        if (iterator.k()) {
            iterator = ((List)object).iterator();
            while (iterator.hasNext()) {
                n3 += l.b(a2, iterator.next());
            }
            n2 = f.d(n4);
            return f.f(n3) + (n2 + n3);
        }
        iterator = ((List)object).iterator();
        n3 = n2;
        do {
            n2 = n3;
            if (!iterator.hasNext()) return n2;
            n3 += l.a(a2, n4, iterator.next());
        } while (true);
    }

    private void c(Map.Entry<FieldDescriptorType, Object> object) {
        Object object2;
        a a2 = (a)object.getKey();
        object = object2 = object.getValue();
        if (object2 instanceof p) {
            object = ((p)object2).a();
        }
        if (a2.j()) {
            object2 = this.b(a2);
            if (object2 == null) {
                this.a.a((a)a2, new ArrayList((List)object));
                return;
            }
            ((List)object2).addAll((List)object);
            return;
        }
        if (a2.e() == ah.b.i) {
            object2 = this.b(a2);
            if (object2 == null) {
                this.a.a((a)a2, object);
                return;
            }
            this.a.a((a)a2, a2.a(((u)object2).toBuilder(), (u)object).build());
            return;
        }
        this.a.a((a)a2, object);
    }

    public final Object a(FieldDescriptorType object, int n2) {
        if (!object.j()) {
            throw new IllegalArgumentException("getRepeatedField() can only be called on repeated fields.");
        }
        if ((object = this.b(object)) == null) {
            throw new IndexOutOfBoundsException();
        }
        return ((List)object).get(n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(FieldDescriptorType FieldDescriptorType, Object object) {
        if (FieldDescriptorType.j()) {
            if (!(object instanceof List)) {
                throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
            }
            ArrayList arrayList = new ArrayList();
            arrayList.addAll((List)object);
            for (Object e2 : arrayList) {
                l.a(FieldDescriptorType.f(), e2);
            }
            object = arrayList;
        } else {
            l.a(FieldDescriptorType.f(), object);
        }
        if (object instanceof p) {
            this.c = true;
        }
        this.a.a(FieldDescriptorType, object);
    }

    public final void a(l<FieldDescriptorType> object) {
        for (int i2 = 0; i2 < object.a.b(); ++i2) {
            this.c((FieldDescriptorType)object.a.b(i2));
        }
        object = object.a.c().iterator();
        while (object.hasNext()) {
            this.c((FieldDescriptorType)((Map.Entry)object.next()));
        }
    }

    public final boolean a(FieldDescriptorType FieldDescriptorType) {
        if (FieldDescriptorType.j()) {
            throw new IllegalArgumentException("hasField() can only be called on non-repeated fields.");
        }
        if (this.a.get(FieldDescriptorType) != null) {
            return true;
        }
        return false;
    }

    public final Object b(FieldDescriptorType object) {
        Object object2;
        object = object2 = this.a.get(object);
        if (object2 instanceof p) {
            object = ((p)object2).a();
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void b(FieldDescriptorType list, Object object) {
        if (!list.j()) {
            throw new IllegalArgumentException("addRepeatedField() can only be called on repeated fields.");
        }
        l.a(list.f(), object);
        ArrayList arrayList = this.b(list);
        if (arrayList == null) {
            arrayList = new ArrayList();
            this.a.a((List)list, arrayList);
            list = arrayList;
        } else {
            list = arrayList;
        }
        list.add(object);
    }

    public final void c() {
        if (this.b) {
            return;
        }
        this.a.a();
        this.b = true;
    }

    public final void c(FieldDescriptorType FieldDescriptorType) {
        this.a.remove(FieldDescriptorType);
        if (this.a.isEmpty()) {
            this.c = false;
        }
    }

    public final /* synthetic */ Object clone() {
        return this.d();
    }

    public final int d(FieldDescriptorType object) {
        if (!object.j()) {
            throw new IllegalArgumentException("getRepeatedField() can only be called on repeated fields.");
        }
        if ((object = this.b(object)) == null) {
            return 0;
        }
        return ((List)object).size();
    }

    public final l<FieldDescriptorType> d() {
        l<a> l2 = new l<a>();
        for (int i2 = 0; i2 < this.a.b(); ++i2) {
            Map.Entry<FieldDescriptorType, Object> entry = this.a.b(i2);
            l2.a((a)entry.getKey(), entry.getValue());
        }
        for (Map.Entry entry : this.a.c()) {
            l2.a((a)entry.getKey(), entry.getValue());
        }
        l2.c = this.c;
        return l2;
    }

    public final Map<FieldDescriptorType, Object> e() {
        if (this.c) {
            ac ac2 = ac.a(16);
            for (int i2 = 0; i2 < this.a.b(); ++i2) {
                l.a(ac2, this.a.b(i2));
            }
            Iterator<Map.Entry<FieldDescriptorType, Object>> iterator = this.a.c().iterator();
            while (iterator.hasNext()) {
                l.a(ac2, iterator.next());
            }
            if (this.a.a) {
                ac2.a();
            }
            return ac2;
        }
        if (this.a.a) {
            return this.a;
        }
        return Collections.unmodifiableMap(this.a);
    }

    public final boolean f() {
        for (int i2 = 0; i2 < this.a.b(); ++i2) {
            if (l.b(this.a.b(i2))) continue;
            return false;
        }
        Iterator<Map.Entry<FieldDescriptorType, Object>> iterator = this.a.c().iterator();
        while (iterator.hasNext()) {
            if (l.b(iterator.next())) continue;
            return false;
        }
        return true;
    }

    public final int g() {
        int n2 = 0;
        for (int i2 = 0; i2 < this.a.b(); ++i2) {
            Map.Entry<FieldDescriptorType, Object> entry = this.a.b(i2);
            n2 += l.c((a)entry.getKey(), entry.getValue());
        }
        for (Map.Entry entry : this.a.c()) {
            n2 += l.c((a)entry.getKey(), entry.getValue());
        }
        return n2;
    }

    public static interface a<T extends a<T>>
    extends Comparable<T> {
        public u.a a(u.a var1, u var2);

        public int d();

        public ah.b e();

        public ah.a f();

        public boolean j();

        public boolean k();
    }

}

