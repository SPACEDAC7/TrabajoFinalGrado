/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import android.support.design.widget.f;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.a;
import com.google.protobuf.ac;
import com.google.protobuf.af;
import com.google.protobuf.ah;
import com.google.protobuf.b;
import com.google.protobuf.g;
import com.google.protobuf.h;
import com.google.protobuf.i;
import com.google.protobuf.k;
import com.google.protobuf.l;
import com.google.protobuf.p;
import com.google.protobuf.t;
import com.google.protobuf.u;
import com.google.protobuf.x;
import com.google.protobuf.y;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public abstract class m
extends com.google.protobuf.a
implements Serializable {
    public static boolean alwaysUseFieldBuilders = false;
    private static final long serialVersionUID = 1;

    static {
        alwaysUseFieldBuilders = false;
    }

    public m() {
    }

    public m(a<?> a2) {
    }

    static void enableAlwaysUseFieldBuildersForTesting() {
        alwaysUseFieldBuilders = true;
    }

    private Map<h.f, Object> getAllFieldsMutable() {
        TreeMap<h.f, Object> treeMap = new TreeMap<h.f, Object>();
        for (h.f f2 : this.internalGetFieldAccessorTable().a.d()) {
            if (f2.j()) {
                List list = (List)this.getField(f2);
                if (list.isEmpty()) continue;
                treeMap.put(f2, list);
                continue;
            }
            if (!this.hasField(f2)) continue;
            treeMap.put(f2, this.getField(f2));
        }
        return treeMap;
    }

    private static /* varargs */ Method getMethodOrDie(Class class_, String string, Class ... object) {
        try {
            object = class_.getMethod(string, object);
            return object;
        }
        catch (NoSuchMethodException var2_3) {
            throw new RuntimeException("Generated message class \"" + class_.getName() + "\" missing method \"" + string + "\".", var2_3);
        }
    }

    private static /* varargs */ Object invokeOrDie(Method object, Object object2, Object ... arrobject) {
        try {
            object = object.invoke(object2, arrobject);
            return object;
        }
        catch (IllegalAccessException var0_1) {
            throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", var0_1);
        }
        catch (InvocationTargetException var0_2) {
            Throwable throwable = var0_2.getCause();
            if (throwable instanceof RuntimeException) {
                throw (RuntimeException)throwable;
            }
            if (throwable instanceof Error) {
                throw (Error)throwable;
            }
            throw new RuntimeException("Unexpected exception thrown by generated accessor method.", throwable);
        }
    }

    public static <ContainingType extends t, Type> f<ContainingType, Type> newFileScopedGeneratedExtension(Class class_, t t2) {
        return new f(null, class_, t2, 0);
    }

    public static <ContainingType extends t, Type> f<ContainingType, Type> newMessageScopedGeneratedExtension(final t t2, final int n2, Class class_, t t3) {
        return new f(new f.a(){}, class_, t3, 0);
    }

    @Override
    public Map<h.f, Object> getAllFields() {
        return Collections.unmodifiableMap(this.getAllFieldsMutable());
    }

    @Override
    public h.a getDescriptorForType() {
        return this.internalGetFieldAccessorTable().a;
    }

    @Override
    public Object getField(h.f f2) {
        return e.a(this.internalGetFieldAccessorTable(), f2).a(this);
    }

    @Override
    public x<? extends t> getParserForType() {
        throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
    }

    public Object getRepeatedField(h.f f2, int n2) {
        return e.a(this.internalGetFieldAccessorTable(), f2).a(this, n2);
    }

    public int getRepeatedFieldCount(h.f f2) {
        return e.a(this.internalGetFieldAccessorTable(), f2).c(this);
    }

    @Override
    public af getUnknownFields() {
        throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
    }

    @Override
    public boolean hasField(h.f f2) {
        return e.a(this.internalGetFieldAccessorTable(), f2).b(this);
    }

    public abstract e internalGetFieldAccessorTable();

    @Override
    public boolean isInitialized() {
        Iterator<h.f> iterator = this.getDescriptorForType().d().iterator();
        while (iterator.hasNext()) {
            Object object = iterator.next();
            if (object.g() && !this.hasField((h.f)object)) {
                return false;
            }
            if (object.e.s != h.f.a.i) continue;
            if (object.j()) {
                object = ((List)this.getField((h.f)object)).iterator();
                while (object.hasNext()) {
                    if (((t)object.next()).isInitialized()) continue;
                    return false;
                }
                continue;
            }
            if (!this.hasField((h.f)object) || ((t)this.getField((h.f)object)).isInitialized()) continue;
            return false;
        }
        return true;
    }

    public void makeExtensionsImmutable() {
    }

    public abstract t.a newBuilderForType(b var1);

    public boolean parseUnknownField(com.google.protobuf.e e2, af.a a2, k k2, int n2) {
        return a2.a(n2, e2);
    }

    public Object writeReplace() {
        return new GeneratedMessageLite.SerializedForm(this);
    }

    public static abstract class com.google.protobuf.m$a<BuilderType extends com.google.protobuf.m$a>
    extends a.a<BuilderType> {
        b a;
        public boolean b;
        private com.google.protobuf.m$a<BuilderType> c;
        private af d = af.b();

        public com.google.protobuf.m$a() {
            this(null);
        }

        public com.google.protobuf.m$a(b b2) {
            this.a = b2;
        }

        public BuilderType addRepeatedField(h.f f2, Object object) {
            e.a(this.internalGetFieldAccessorTable(), f2).b(this, object);
            return (BuilderType)this;
        }

        @Override
        public BuilderType clear() {
            this.d = af.b();
            this.onChanged();
            return (BuilderType)this;
        }

        public BuilderType clearField(h.f f2) {
            e.a(this.internalGetFieldAccessorTable(), f2).d(this);
            return (BuilderType)this;
        }

        @Override
        public BuilderType clone() {
            throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
        }

        final Map<h.f, Object> e() {
            TreeMap<h.f, Object> treeMap = new TreeMap<h.f, Object>();
            for (h.f f2 : this.internalGetFieldAccessorTable().a.d()) {
                if (f2.j()) {
                    List list = (List)this.getField(f2);
                    if (list.isEmpty()) continue;
                    treeMap.put(f2, list);
                    continue;
                }
                if (!this.hasField(f2)) continue;
                treeMap.put(f2, this.getField(f2));
            }
            return treeMap;
        }

        @Override
        public Map<h.f, Object> getAllFields() {
            return Collections.unmodifiableMap(this.e());
        }

        @Override
        public h.a getDescriptorForType() {
            return this.internalGetFieldAccessorTable().a;
        }

        @Override
        public Object getField(h.f f2) {
            List list;
            List list2 = list = e.a(this.internalGetFieldAccessorTable(), f2).a(this);
            if (f2.j()) {
                list2 = Collections.unmodifiableList(list);
            }
            return list2;
        }

        @Override
        public t.a getFieldBuilder(h.f f2) {
            return e.a(this.internalGetFieldAccessorTable(), f2).e(this);
        }

        public final b getParentForChildren() {
            if (this.c == null) {
                this.c = new a(0);
            }
            return this.c;
        }

        public Object getRepeatedField(h.f f2, int n2) {
            return e.a(this.internalGetFieldAccessorTable(), f2).a(this, n2);
        }

        public int getRepeatedFieldCount(h.f f2) {
            return e.a(this.internalGetFieldAccessorTable(), f2).c(this);
        }

        @Override
        public final af getUnknownFields() {
            return this.d;
        }

        @Override
        public boolean hasField(h.f f2) {
            return e.a(this.internalGetFieldAccessorTable(), f2).b(this);
        }

        public abstract e internalGetFieldAccessorTable();

        public final boolean isClean() {
            return this.b;
        }

        @Override
        public boolean isInitialized() {
            Iterator<h.f> iterator = this.getDescriptorForType().d().iterator();
            while (iterator.hasNext()) {
                Object object = iterator.next();
                if (object.g() && !this.hasField((h.f)object)) {
                    return false;
                }
                if (object.e.s != h.f.a.i) continue;
                if (object.j()) {
                    object = ((List)this.getField((h.f)object)).iterator();
                    while (object.hasNext()) {
                        if (((t)object.next()).isInitialized()) continue;
                        return false;
                    }
                    continue;
                }
                if (!this.hasField((h.f)object) || ((t)this.getField((h.f)object)).isInitialized()) continue;
                return false;
            }
            return true;
        }

        @Override
        public final BuilderType mergeUnknownFields(af af2) {
            this.d = af.a(this.d).a(af2).a();
            this.onChanged();
            return (BuilderType)this;
        }

        @Override
        public t.a newBuilderForField(h.f f2) {
            return e.a(this.internalGetFieldAccessorTable(), f2).a();
        }

        public final void onBuilt() {
            if (this.a != null) {
                this.b = true;
            }
        }

        public final void onChanged() {
            if (this.b && this.a != null) {
                this.a.a();
                this.b = false;
            }
        }

        public BuilderType setField(h.f f2, Object object) {
            e.a(this.internalGetFieldAccessorTable(), f2).a(this, object);
            return (BuilderType)this;
        }

        public BuilderType setRepeatedField(h.f f2, int n2, Object object) {
            e.a(this.internalGetFieldAccessorTable(), f2).a(this, n2, object);
            return (BuilderType)this;
        }

        public final BuilderType setUnknownFields(af af2) {
            this.d = af2;
            this.onChanged();
            return (BuilderType)this;
        }

        final class a
        implements b {
            private a() {
            }

            /* synthetic */ a(byte by2) {
                this();
            }

            @Override
            public final void a() {
                a.this.onChanged();
            }
        }

    }

    public static interface b {
        public void a();
    }

    public static abstract class c<MessageType extends d, BuilderType extends c>
    extends a<BuilderType>
    implements f.a<MessageType> {
        l<h.f> c = l.b();

        protected c() {
        }

        protected c(b b2) {
            super(b2);
        }

        static /* synthetic */ l a(c c2) {
            c2.c.c();
            return c2.c;
        }

        private BuilderType a(h.f f2) {
            if (f2.b.f()) {
                this.b(f2);
                this.a();
                this.c.c(f2);
                this.onChanged();
                return (BuilderType)this;
            }
            return (BuilderType)((c)super.clearField(f2));
        }

        private BuilderType a(h.f f2, int n2, Object object) {
            if (f2.b.f()) {
                this.b(f2);
                this.a();
                Object object2 = this.c;
                if (!f2.j()) {
                    throw new IllegalArgumentException("getRepeatedField() can only be called on repeated fields.");
                }
                if ((object2 = object2.b((h.f)f2)) == null) {
                    throw new IndexOutOfBoundsException();
                }
                l.a(f2.f(), object);
                ((List)object2).set(n2, object);
                this.onChanged();
                return (BuilderType)this;
            }
            return (BuilderType)((c)super.setRepeatedField(f2, n2, object));
        }

        private BuilderType a(h.f f2, Object object) {
            if (f2.b.f()) {
                this.b(f2);
                this.a();
                this.c.a(f2, object);
                this.onChanged();
                return (BuilderType)this;
            }
            return (BuilderType)((c)super.setField(f2, object));
        }

        private void a() {
            if (this.c.b) {
                this.c = this.c.d();
            }
        }

        private BuilderType b(h.f f2, Object object) {
            if (f2.b.f()) {
                this.b(f2);
                this.a();
                this.c.b(f2, object);
                this.onChanged();
                return (BuilderType)this;
            }
            return (BuilderType)((c)super.addRepeatedField(f2, object));
        }

        private void b(h.f f2) {
            if (f2.f != this.getDescriptorForType()) {
                throw new IllegalArgumentException("FieldDescriptor does not match message type.");
            }
        }

        protected final void a(d d2) {
            this.a();
            this.c.a(d2.i);
            this.onChanged();
        }

        @Override
        public /* synthetic */ a addRepeatedField(h.f f2, Object object) {
            return this.b(f2, object);
        }

        @Override
        public /* synthetic */ t.a addRepeatedField(h.f f2, Object object) {
            return this.b(f2, object);
        }

        public BuilderType b() {
            throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
        }

        public BuilderType c() {
            this.c = l.b();
            return (BuilderType)((c)super.clear());
        }

        @Override
        public /* synthetic */ a.a clear() {
            return this.c();
        }

        @Override
        public /* synthetic */ a clear() {
            return this.c();
        }

        @Override
        public /* synthetic */ t.a clear() {
            return this.c();
        }

        @Override
        public /* synthetic */ u.a clear() {
            return this.c();
        }

        @Override
        public /* synthetic */ a clearField(h.f f2) {
            return this.a(f2);
        }

        @Override
        public /* synthetic */ t.a clearField(h.f f2) {
            return this.a(f2);
        }

        @Override
        public /* synthetic */ a.a clone() {
            return this.b();
        }

        @Override
        public /* synthetic */ b.a clone() {
            return this.b();
        }

        @Override
        public /* synthetic */ a clone() {
            return this.b();
        }

        @Override
        public /* synthetic */ t.a clone() {
            return this.b();
        }

        @Override
        public /* synthetic */ u.a clone() {
            return this.b();
        }

        @Override
        public /* synthetic */ Object clone() {
            return this.b();
        }

        @Override
        public Map<h.f, Object> getAllFields() {
            Map<h.f, Object> map = super.e();
            map.putAll(this.c.e());
            return Collections.unmodifiableMap(map);
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        public Object getField(h.f f2) {
            Object object;
            if (!f2.b.f()) return super.getField(f2);
            this.b(f2);
            Object object2 = object = this.c.b(f2);
            if (object != null) return object2;
            if (f2.e.s != h.f.a.i) return f2.m();
            return i.a(f2.n());
        }

        @Override
        public Object getRepeatedField(h.f f2, int n2) {
            if (f2.b.f()) {
                this.b(f2);
                return this.c.a(f2, n2);
            }
            return super.getRepeatedField(f2, n2);
        }

        @Override
        public int getRepeatedFieldCount(h.f f2) {
            if (f2.b.f()) {
                this.b(f2);
                return this.c.d(f2);
            }
            return super.getRepeatedFieldCount(f2);
        }

        @Override
        public boolean hasField(h.f f2) {
            if (f2.b.f()) {
                this.b(f2);
                return this.c.a(f2);
            }
            return super.hasField(f2);
        }

        @Override
        public boolean isInitialized() {
            if (super.isInitialized() && this.c.f()) {
                return true;
            }
            return false;
        }

        @Override
        public /* synthetic */ a setField(h.f f2, Object object) {
            return this.a(f2, object);
        }

        @Override
        public /* synthetic */ t.a setField(h.f f2, Object object) {
            return this.a(f2, object);
        }

        @Override
        public /* synthetic */ a setRepeatedField(h.f f2, int n2, Object object) {
            return this.a(f2, n2, object);
        }

        @Override
        public /* synthetic */ t.a setRepeatedField(h.f f2, int n2, Object object) {
            return this.a(f2, n2, object);
        }
    }

    public static abstract class d<MessageType extends d>
    extends m
    implements f.a<MessageType> {
        final l<h.f> i;

        protected d() {
            this.i = l.a();
        }

        protected d(c<MessageType, ?> c2) {
            super(c2);
            this.i = c.a(c2);
        }

        private void a(h.f f2) {
            if (f2.f != this.getDescriptorForType()) {
                throw new IllegalArgumentException("FieldDescriptor does not match message type.");
            }
        }

        protected final d<MessageType> b() {
            return new a(0);
        }

        @Override
        public Map<h.f, Object> getAllFields() {
            Map map = this.getAllFieldsMutable();
            map.putAll(this.i.e());
            return Collections.unmodifiableMap(map);
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        public Object getField(h.f f2) {
            Object object;
            if (!f2.b.f()) return super.getField(f2);
            this.a(f2);
            Object object2 = object = this.i.b(f2);
            if (object != null) return object2;
            if (f2.e.s != h.f.a.i) return f2.m();
            return i.a(f2.n());
        }

        @Override
        public Object getRepeatedField(h.f f2, int n2) {
            if (f2.b.f()) {
                this.a(f2);
                return this.i.a(f2, n2);
            }
            return super.getRepeatedField(f2, n2);
        }

        @Override
        public int getRepeatedFieldCount(h.f f2) {
            if (f2.b.f()) {
                this.a(f2);
                return this.i.d(f2);
            }
            return super.getRepeatedFieldCount(f2);
        }

        @Override
        public boolean hasField(h.f f2) {
            if (f2.b.f()) {
                this.a(f2);
                return this.i.a(f2);
            }
            return super.hasField(f2);
        }

        @Override
        public boolean isInitialized() {
            if (super.isInitialized() && this.i.f()) {
                return true;
            }
            return false;
        }

        @Override
        protected void makeExtensionsImmutable() {
            this.i.c();
        }

        @Override
        protected boolean parseUnknownField(com.google.protobuf.e e2, af.a a2, k k2, int n2) {
            return a.a.a(e2, a2, k2, this.getDescriptorForType(), null, this.i, n2);
        }

        public final class a {
            private final Iterator<Map.Entry<h.f, Object>> b;
            private Map.Entry<h.f, Object> c;
            private final boolean d;

            /*
             * Enabled aggressive block sorting
             */
            private a() {
                Object.this = Object.this.i;
                Object.this = Object.this.c ? new p.b(Object.this.a.entrySet().iterator()) : Object.this.a.entrySet().iterator();
                this.b = Object.this;
                if (this.b.hasNext()) {
                    this.c = this.b.next();
                }
                this.d = false;
            }

            /* synthetic */ a(byte by2) {
                this();
            }

            /*
             * Enabled aggressive block sorting
             */
            public final void a(com.google.protobuf.f f2) {
                while (this.c != null && this.c.getKey().b.c < 536870912) {
                    h.f f3 = this.c.getKey();
                    if (this.d && f3.f().s == ah.b.i && !f3.j()) {
                        if (this.c instanceof p.a) {
                            f2.b(f3.b.c, ((p.a)this.c).a.getValue().b());
                        } else {
                            f2.c(f3.b.c, (t)this.c.getValue());
                        }
                    } else {
                        l.a(f3, this.c.getValue(), f2);
                    }
                    if (this.b.hasNext()) {
                        this.c = this.b.next();
                        continue;
                    }
                    this.c = null;
                }
            }
        }

    }

    public static final class com.google.protobuf.m$e {
        final h.a a;
        private final a[] b;
        private String[] c;
        private volatile boolean d;

        public com.google.protobuf.m$e(h.a a2, String[] arrstring) {
            this.a = a2;
            this.c = arrstring;
            this.b = new a[a2.d().size()];
            this.d = false;
        }

        static /* synthetic */ a a(com.google.protobuf.m$e e2, h.f f2) {
            if (f2.f != e2.a) {
                throw new IllegalArgumentException("FieldDescriptor does not match message type.");
            }
            if (f2.b.f()) {
                throw new IllegalArgumentException("This type does not have extensions.");
            }
            return e2.b[f2.a];
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public final com.google.protobuf.m$e a(Class<? extends m> class_, Class<? extends com.google.protobuf.m$a> class_2) {
            if (this.d) {
                return this;
            }
            synchronized (this) {
                if (this.d) {
                    return this;
                }
                int n2 = 0;
                do {
                    if (n2 >= this.b.length) {
                        this.d = true;
                        this.c = null;
                        return this;
                    }
                    h.f f2 = this.a.d().get(n2);
                    this.b[n2] = f2.j() ? (f2.e.s == h.f.a.i ? new d(this.c[n2], class_, class_2) : (f2.e.s == h.f.a.h ? new b(this.c[n2], class_, class_2) : new c(this.c[n2], class_, class_2))) : (f2.e.s == h.f.a.i ? new g(this.c[n2], class_, class_2) : (f2.e.s == h.f.a.h ? new e(this.c[n2], class_, class_2) : new f(this.c[n2], class_, class_2)));
                    ++n2;
                } while (true);
            }
        }

        static interface a {
            public t.a a();

            public Object a(com.google.protobuf.m$a var1);

            public Object a(com.google.protobuf.m$a var1, int var2);

            public Object a(m var1);

            public Object a(m var1, int var2);

            public void a(com.google.protobuf.m$a var1, int var2, Object var3);

            public void a(com.google.protobuf.m$a var1, Object var2);

            public void b(com.google.protobuf.m$a var1, Object var2);

            public boolean b(com.google.protobuf.m$a var1);

            public boolean b(m var1);

            public int c(com.google.protobuf.m$a var1);

            public int c(m var1);

            public void d(com.google.protobuf.m$a var1);

            public t.a e(com.google.protobuf.m$a var1);
        }

        static final class b
        extends c {
            private final Method k;
            private final Method l;

            b(String string, Class<? extends m> class_, Class<? extends com.google.protobuf.m$a> class_2) {
                super(string, class_, class_2);
                this.k = m.getMethodOrDie(this.a, "valueOf", new Class[]{h.e.class});
                this.l = m.getMethodOrDie(this.a, "getValueDescriptor", new Class[0]);
            }

            @Override
            public final Object a(com.google.protobuf.m$a object) {
                ArrayList<Object> arrayList = new ArrayList<Object>();
                for (Object e2 : (List)super.a((com.google.protobuf.m$a)object)) {
                    arrayList.add(m.invokeOrDie(this.l, e2, new Object[0]));
                }
                return Collections.unmodifiableList(arrayList);
            }

            @Override
            public final Object a(com.google.protobuf.m$a a2, int n2) {
                return m.invokeOrDie(this.l, super.a(a2, n2), new Object[0]);
            }

            @Override
            public final Object a(m object) {
                ArrayList<Object> arrayList = new ArrayList<Object>();
                for (Object e2 : (List)super.a((m)object)) {
                    arrayList.add(m.invokeOrDie(this.l, e2, new Object[0]));
                }
                return Collections.unmodifiableList(arrayList);
            }

            @Override
            public final Object a(m m2, int n2) {
                return m.invokeOrDie(this.l, super.a(m2, n2), new Object[0]);
            }

            @Override
            public final void a(com.google.protobuf.m$a a2, int n2, Object object) {
                super.a(a2, n2, m.invokeOrDie(this.k, null, new Object[]{object}));
            }

            @Override
            public final void b(com.google.protobuf.m$a a2, Object object) {
                super.b(a2, m.invokeOrDie(this.k, null, new Object[]{object}));
            }
        }

        static class c
        implements a {
            protected final Class a;
            protected final Method b;
            protected final Method c;
            protected final Method d;
            protected final Method e;
            protected final Method f;
            protected final Method g;
            protected final Method h;
            protected final Method i;
            protected final Method j;

            c(String string, Class<? extends m> class_, Class<? extends com.google.protobuf.m$a> class_2) {
                this.b = m.getMethodOrDie(class_, "get" + string + "List", new Class[0]);
                this.c = m.getMethodOrDie(class_2, "get" + string + "List", new Class[0]);
                this.d = m.getMethodOrDie(class_, "get" + string, new Class[]{Integer.TYPE});
                this.e = m.getMethodOrDie(class_2, "get" + string, new Class[]{Integer.TYPE});
                this.a = this.d.getReturnType();
                this.f = m.getMethodOrDie(class_2, "set" + string, new Class[]{Integer.TYPE, this.a});
                this.g = m.getMethodOrDie(class_2, "add" + string, new Class[]{this.a});
                this.h = m.getMethodOrDie(class_, "get" + string + "Count", new Class[0]);
                this.i = m.getMethodOrDie(class_2, "get" + string + "Count", new Class[0]);
                this.j = m.getMethodOrDie(class_2, "clear" + string, new Class[0]);
            }

            @Override
            public t.a a() {
                throw new UnsupportedOperationException("newBuilderForField() called on a non-Message type.");
            }

            @Override
            public Object a(com.google.protobuf.m$a a2) {
                return m.invokeOrDie(this.c, a2, new Object[0]);
            }

            @Override
            public Object a(com.google.protobuf.m$a a2, int n2) {
                return m.invokeOrDie(this.e, a2, new Object[]{n2});
            }

            @Override
            public Object a(m m2) {
                return m.invokeOrDie(this.b, m2, new Object[0]);
            }

            @Override
            public Object a(m m2, int n2) {
                return m.invokeOrDie(this.d, m2, new Object[]{n2});
            }

            @Override
            public void a(com.google.protobuf.m$a a2, int n2, Object object) {
                m.invokeOrDie(this.f, a2, new Object[]{n2, object});
            }

            @Override
            public final void a(com.google.protobuf.m$a a2, Object iterator) {
                this.d(a2);
                iterator = ((List)((Object)iterator)).iterator();
                while (iterator.hasNext()) {
                    this.b(a2, iterator.next());
                }
            }

            @Override
            public void b(com.google.protobuf.m$a a2, Object object) {
                m.invokeOrDie(this.g, a2, new Object[]{object});
            }

            @Override
            public final boolean b(com.google.protobuf.m$a a2) {
                throw new UnsupportedOperationException("hasField() called on a repeated field.");
            }

            @Override
            public final boolean b(m m2) {
                throw new UnsupportedOperationException("hasField() called on a repeated field.");
            }

            @Override
            public final int c(com.google.protobuf.m$a a2) {
                return (Integer)m.invokeOrDie(this.i, a2, new Object[0]);
            }

            @Override
            public final int c(m m2) {
                return (Integer)m.invokeOrDie(this.h, m2, new Object[0]);
            }

            @Override
            public final void d(com.google.protobuf.m$a a2) {
                m.invokeOrDie(this.j, a2, new Object[0]);
            }

            @Override
            public final t.a e(com.google.protobuf.m$a a2) {
                throw new UnsupportedOperationException("getFieldBuilder() called on a non-Message type.");
            }
        }

        static final class d
        extends c {
            private final Method k;

            d(String string, Class<? extends m> class_, Class<? extends com.google.protobuf.m$a> class_2) {
                super(string, class_, class_2);
                this.k = m.getMethodOrDie(this.a, "newBuilder", new Class[0]);
            }

            private Object a(Object object) {
                if (this.a.isInstance(object)) {
                    return object;
                }
                return ((t.a)m.invokeOrDie(this.k, null, new Object[0])).mergeFrom((t)object).build();
            }

            @Override
            public final t.a a() {
                return (t.a)m.invokeOrDie(this.k, null, new Object[0]);
            }

            @Override
            public final void a(com.google.protobuf.m$a a2, int n2, Object object) {
                super.a(a2, n2, this.a(object));
            }

            @Override
            public final void b(com.google.protobuf.m$a a2, Object object) {
                super.b(a2, this.a(object));
            }
        }

        static final class e
        extends f {
            private Method h;
            private Method i;

            e(String string, Class<? extends m> class_, Class<? extends com.google.protobuf.m$a> class_2) {
                super(string, class_, class_2);
                this.h = m.getMethodOrDie(this.a, "valueOf", new Class[]{h.e.class});
                this.i = m.getMethodOrDie(this.a, "getValueDescriptor", new Class[0]);
            }

            @Override
            public final Object a(com.google.protobuf.m$a a2) {
                return m.invokeOrDie(this.i, super.a(a2), new Object[0]);
            }

            @Override
            public final Object a(m m2) {
                return m.invokeOrDie(this.i, super.a(m2), new Object[0]);
            }

            @Override
            public final void a(com.google.protobuf.m$a a2, Object object) {
                super.a(a2, m.invokeOrDie(this.h, null, new Object[]{object}));
            }
        }

        static class f
        implements a {
            protected final Class<?> a;
            protected final Method b;
            protected final Method c;
            protected final Method d;
            protected final Method e;
            protected final Method f;
            protected final Method g;

            f(String string, Class<? extends m> class_, Class<? extends com.google.protobuf.m$a> class_2) {
                this.b = m.getMethodOrDie(class_, "get" + string, new Class[0]);
                this.c = m.getMethodOrDie(class_2, "get" + string, new Class[0]);
                this.a = this.b.getReturnType();
                this.d = m.getMethodOrDie(class_2, "set" + string, new Class[]{this.a});
                this.e = m.getMethodOrDie(class_, "has" + string, new Class[0]);
                this.f = m.getMethodOrDie(class_2, "has" + string, new Class[0]);
                this.g = m.getMethodOrDie(class_2, "clear" + string, new Class[0]);
            }

            @Override
            public t.a a() {
                throw new UnsupportedOperationException("newBuilderForField() called on a non-Message type.");
            }

            @Override
            public Object a(com.google.protobuf.m$a a2) {
                return m.invokeOrDie(this.c, a2, new Object[0]);
            }

            @Override
            public final Object a(com.google.protobuf.m$a a2, int n2) {
                throw new UnsupportedOperationException("getRepeatedField() called on a singular field.");
            }

            @Override
            public Object a(m m2) {
                return m.invokeOrDie(this.b, m2, new Object[0]);
            }

            @Override
            public final Object a(m m2, int n2) {
                throw new UnsupportedOperationException("getRepeatedField() called on a singular field.");
            }

            @Override
            public final void a(com.google.protobuf.m$a a2, int n2, Object object) {
                throw new UnsupportedOperationException("setRepeatedField() called on a singular field.");
            }

            @Override
            public void a(com.google.protobuf.m$a a2, Object object) {
                m.invokeOrDie(this.d, a2, new Object[]{object});
            }

            @Override
            public final void b(com.google.protobuf.m$a a2, Object object) {
                throw new UnsupportedOperationException("addRepeatedField() called on a singular field.");
            }

            @Override
            public final boolean b(com.google.protobuf.m$a a2) {
                return (Boolean)m.invokeOrDie(this.f, a2, new Object[0]);
            }

            @Override
            public final boolean b(m m2) {
                return (Boolean)m.invokeOrDie(this.e, m2, new Object[0]);
            }

            @Override
            public final int c(com.google.protobuf.m$a a2) {
                throw new UnsupportedOperationException("getRepeatedFieldSize() called on a singular field.");
            }

            @Override
            public final int c(m m2) {
                throw new UnsupportedOperationException("getRepeatedFieldSize() called on a singular field.");
            }

            @Override
            public final void d(com.google.protobuf.m$a a2) {
                m.invokeOrDie(this.g, a2, new Object[0]);
            }

            @Override
            public t.a e(com.google.protobuf.m$a a2) {
                throw new UnsupportedOperationException("getFieldBuilder() called on a non-Message type.");
            }
        }

        static final class g
        extends f {
            private final Method h;
            private final Method i;

            g(String string, Class<? extends m> class_, Class<? extends com.google.protobuf.m$a> class_2) {
                super(string, class_, class_2);
                this.h = m.getMethodOrDie(this.a, "newBuilder", new Class[0]);
                this.i = m.getMethodOrDie(class_2, "get" + string + "Builder", new Class[0]);
            }

            @Override
            public final t.a a() {
                return (t.a)m.invokeOrDie(this.h, null, new Object[0]);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public final void a(com.google.protobuf.m$a a2, Object object) {
                if (!this.a.isInstance(object)) {
                    object = ((t.a)m.invokeOrDie(this.h, null, new Object[0])).mergeFrom((t)object).buildPartial();
                }
                super.a(a2, object);
            }

            @Override
            public final t.a e(com.google.protobuf.m$a a2) {
                return (t.a)m.invokeOrDie(this.i, a2, new Object[0]);
            }
        }

    }

    public static final class f<ContainingType extends t, Type> {
        private f.a a;
        private final Class b;
        private final t c;
        private final Method d;
        private final Method e;

        private f(f.a a2, Class class_, t t2) {
            if (t.class.isAssignableFrom(class_) && !class_.isInstance(t2)) {
                throw new IllegalArgumentException("Bad messageDefaultInstance for " + class_.getName());
            }
            this.a = a2;
            this.b = class_;
            this.c = t2;
            if (y.class.isAssignableFrom(class_)) {
                this.d = m.getMethodOrDie(class_, "valueOf", new Class[]{h.e.class});
                this.e = m.getMethodOrDie(class_, "getValueDescriptor", new Class[0]);
                return;
            }
            this.d = null;
            this.e = null;
        }

        /* synthetic */ f(f.a a2, Class class_, t t2, byte by2) {
            this(a2, class_, t2);
        }
    }

}

