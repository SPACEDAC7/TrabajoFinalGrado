/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

public interface n {
    public int getNumber();
}

