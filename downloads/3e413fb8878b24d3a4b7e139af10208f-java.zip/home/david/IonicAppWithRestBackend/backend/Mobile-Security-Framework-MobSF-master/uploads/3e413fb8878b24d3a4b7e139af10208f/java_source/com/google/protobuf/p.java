/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.d;
import com.google.protobuf.k;
import com.google.protobuf.u;
import com.google.protobuf.x;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

final class p {
    d a;
    volatile u b;
    volatile boolean c = false;
    private final u d;
    private final k e;

    public p(u u2, k k2, d d2) {
        this.d = u2;
        this.e = k2;
        this.a = d2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void c() {
        if (this.b != null) {
            return;
        }
        synchronized (this) {
            if (this.b != null) {
                return;
            }
            try {
                if (this.a != null) {
                    this.b = this.d.getParserForType().b(this.a, this.e);
                }
            }
            catch (IOException var1_1) {}
            return;
        }
    }

    public final u a() {
        this.c();
        return this.b;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final d b() {
        if (!this.c) {
            return this.a;
        }
        synchronized (this) {
            if (!this.c) {
                return this.a;
            }
            this.a = this.b.toByteString();
            this.c = false;
            return this.a;
        }
    }

    public final boolean equals(Object object) {
        this.c();
        return this.b.equals(object);
    }

    public final int hashCode() {
        this.c();
        return this.b.hashCode();
    }

    public final String toString() {
        this.c();
        return this.b.toString();
    }

    static final class a<K>
    implements Map.Entry<K, Object> {
        Map.Entry<K, p> a;

        private a(Map.Entry<K, p> entry) {
            this.a = entry;
        }

        /* synthetic */ a(Map.Entry entry, byte by2) {
            this(entry);
        }

        @Override
        public final K getKey() {
            return this.a.getKey();
        }

        @Override
        public final Object getValue() {
            p p2 = this.a.getValue();
            if (p2 == null) {
                return null;
            }
            return p2.a();
        }

        @Override
        public final Object setValue(Object object) {
            if (!(object instanceof u)) {
                throw new IllegalArgumentException("LazyField now only used for MessageSet, and the value of MessageSet must be an instance of MessageLite");
            }
            p p2 = this.a.getValue();
            object = (u)object;
            u u2 = p2.b;
            p2.b = object;
            p2.a = null;
            p2.c = true;
            return u2;
        }
    }

    static final class b<K>
    implements Iterator<Map.Entry<K, Object>> {
        private Iterator<Map.Entry<K, Object>> a;

        public b(Iterator<Map.Entry<K, Object>> iterator) {
            this.a = iterator;
        }

        @Override
        public final boolean hasNext() {
            return this.a.hasNext();
        }

        @Override
        public final /* synthetic */ Object next() {
            Map.Entry<K, Object> entry;
            Map.Entry<K, Object> entry2 = entry = this.a.next();
            if (entry.getValue() instanceof p) {
                entry2 = new a(entry, 0);
            }
            return entry2;
        }

        @Override
        public final void remove() {
            this.a.remove();
        }
    }

}

