/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.ag;
import com.google.protobuf.d;
import com.google.protobuf.r;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;

public final class q
extends AbstractList<String>
implements r,
RandomAccess {
    public static final r a = new ag(new q());
    private final List<Object> b;

    public q() {
        this.b = new ArrayList<Object>();
    }

    public q(r r2) {
        this.b = new ArrayList<Object>(r2.size());
        this.addAll(r2);
    }

    private static String a(Object object) {
        if (object instanceof String) {
            return (String)object;
        }
        return ((d)object).d();
    }

    @Override
    public final d a(int n2) {
        Object object = this.b.get(n2);
        if (object instanceof String) {
            object = d.a((String)object);
            this.b.set(n2, object);
            return object;
        }
        return (d)object;
    }

    @Override
    public final List<?> a() {
        return Collections.unmodifiableList(this.b);
    }

    @Override
    public final void a(d d2) {
        this.b.add(d2);
        ++this.modCount;
    }

    @Override
    public final boolean addAll(int n2, Collection<? extends String> collection) {
        Collection<? extends String> collection2 = collection;
        if (collection instanceof r) {
            collection2 = ((r)collection).a();
        }
        boolean bl2 = this.b.addAll(n2, collection2);
        ++this.modCount;
        return bl2;
    }

    @Override
    public final boolean addAll(Collection<? extends String> collection) {
        return this.addAll(this.size(), collection);
    }

    @Override
    public final void clear() {
        this.b.clear();
        ++this.modCount;
    }

    @Override
    public final /* synthetic */ Object get(int n2) {
        Object object = this.b.get(n2);
        if (object instanceof String) {
            return (String)object;
        }
        object = (d)object;
        String string = object.d();
        if (object.e()) {
            this.b.set(n2, string);
        }
        return string;
    }

    @Override
    public final /* synthetic */ Object remove(int n2) {
        Object object = this.b.remove(n2);
        ++this.modCount;
        return q.a(object);
    }

    @Override
    public final /* synthetic */ Object set(int n2, Object object) {
        object = (String)object;
        return q.a(this.b.set(n2, object));
    }

    @Override
    public final int size() {
        return this.b.size();
    }
}

