/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.d;
import java.util.List;

public interface r
extends List<String> {
    public d a(int var1);

    public List<?> a();

    public void a(d var1);
}

