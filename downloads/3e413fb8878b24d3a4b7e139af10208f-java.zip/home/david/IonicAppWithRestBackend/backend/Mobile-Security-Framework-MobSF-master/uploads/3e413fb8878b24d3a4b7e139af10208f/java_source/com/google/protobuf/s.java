/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.aa;
import com.google.protobuf.d;
import com.google.protobuf.e;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Iterator;
import java.util.NoSuchElementException;

final class s
extends d {
    protected final byte[] c;
    private int d = 0;

    s(byte[] arrby) {
        this.c = arrby;
    }

    @Override
    public final byte a(int n2) {
        return this.c[n2];
    }

    @Override
    protected final int a(int n2, int n3, int n4) {
        return a.a.a.a.d.a(n2, this.c, n3, n3 + n4);
    }

    @Override
    public final d.a a() {
        return new a(0);
    }

    final boolean a(s arrby, int n2, int n3) {
        if (n3 > arrby.c.length) {
            throw new IllegalArgumentException("Length too large: " + n3 + this.c.length);
        }
        if (n2 + n3 > arrby.c.length) {
            throw new IllegalArgumentException("Ran off end of other: " + n2 + ", " + n3 + ", " + arrby.c.length);
        }
        byte[] arrby2 = this.c;
        arrby = arrby.c;
        int n4 = 0;
        while (n4 < n3) {
            if (arrby2[n4] != arrby[n2]) {
                return false;
            }
            ++n4;
            ++n2;
        }
        return true;
    }

    @Override
    public final int b() {
        return this.c.length;
    }

    @Override
    protected final int b(int n2, int n3, int n4) {
        byte[] arrby = this.c;
        for (int i2 = n3; i2 < n3 + n4; ++i2) {
            n2 = n2 * 31 + arrby[i2];
        }
        return n2;
    }

    @Override
    public final String b(String string) {
        return new String(this.c, 0, this.c.length, string);
    }

    @Override
    protected final void b(byte[] arrby, int n2, int n3, int n4) {
        System.arraycopy(this.c, n2, arrby, n3, n4);
    }

    @Override
    public final boolean e() {
        return a.a.a.a.d.a(this.c, this.c.length + 0);
    }

    @Override
    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof d)) {
            return false;
        }
        if (this.c.length != ((d)object).b()) {
            return false;
        }
        if (this.c.length == 0) {
            return true;
        }
        if (object instanceof s) {
            return this.a((s)object, 0, this.c.length);
        }
        if (object instanceof aa) {
            return object.equals(this);
        }
        throw new IllegalArgumentException("Has a new type of ByteString been created? Found " + object.getClass());
    }

    @Override
    public final InputStream f() {
        return new ByteArrayInputStream(this.c, 0, this.c.length);
    }

    @Override
    public final e g() {
        return e.a(this.c, 0, this.c.length);
    }

    @Override
    protected final int h() {
        return this.d;
    }

    public final int hashCode() {
        int n2;
        int n3 = n2 = this.d;
        if (n2 == 0) {
            n3 = this.c.length;
            n3 = n2 = this.b(n3, 0, n3);
            if (n2 == 0) {
                n3 = 1;
            }
            this.d = n3;
        }
        return n3;
    }

    @Override
    public final /* synthetic */ Iterator iterator() {
        return this.a();
    }

    final class a
    implements d.a {
        private int b;
        private final int c;

        private a() {
            this.b = 0;
            this.c = s.this.b();
        }

        /* synthetic */ a(byte by2) {
            this();
        }

        @Override
        public final byte a() {
            byte[] arrby;
            int n2;
            try {
                arrby = s.this.c;
                n2 = this.b;
                this.b = n2 + 1;
            }
            catch (ArrayIndexOutOfBoundsException var2_2) {
                throw new NoSuchElementException(var2_2.getMessage());
            }
            byte by2 = arrby[n2];
            return by2;
        }

        @Override
        public final boolean hasNext() {
            if (this.b < this.c) {
                return true;
            }
            return false;
        }

        @Override
        public final /* synthetic */ Object next() {
            return Byte.valueOf(this.a());
        }

        @Override
        public final void remove() {
            throw new UnsupportedOperationException();
        }
    }

}

