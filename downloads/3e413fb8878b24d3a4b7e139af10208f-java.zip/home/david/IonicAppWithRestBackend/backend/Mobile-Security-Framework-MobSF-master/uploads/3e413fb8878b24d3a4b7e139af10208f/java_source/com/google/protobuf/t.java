/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.af;
import com.google.protobuf.d;
import com.google.protobuf.h;
import com.google.protobuf.k;
import com.google.protobuf.u;
import com.google.protobuf.w;
import com.google.protobuf.x;

public interface t
extends u,
w {
    public x<? extends t> getParserForType();

    public a newBuilderForType();

    @Override
    public a toBuilder();

    public static interface a
    extends u.a,
    w {
        public a addRepeatedField(h.f var1, Object var2);

        @Override
        public t build();

        @Override
        public t buildPartial();

        public a clearField(h.f var1);

        @Override
        public h.a getDescriptorForType();

        public a mergeFrom(d var1, k var2);

        public a mergeFrom(t var1);

        public a newBuilderForField(h.f var1);

        public a setField(h.f var1, Object var2);

        public a setUnknownFields(af var1);
    }

}

