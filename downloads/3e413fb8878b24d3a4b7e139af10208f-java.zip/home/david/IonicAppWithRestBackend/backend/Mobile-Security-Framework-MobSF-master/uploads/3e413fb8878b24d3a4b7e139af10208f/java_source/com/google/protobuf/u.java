/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.d;
import com.google.protobuf.e;
import com.google.protobuf.f;
import com.google.protobuf.k;
import com.google.protobuf.v;
import com.google.protobuf.x;

public interface u
extends v {
    public x<? extends u> getParserForType();

    public int getSerializedSize();

    public a toBuilder();

    public byte[] toByteArray();

    public d toByteString();

    public void writeTo(f var1);

    public static interface a
    extends v,
    Cloneable {
        public u build();

        public u buildPartial();

        public a mergeFrom(e var1, k var2);

        public a mergeFrom(byte[] var1);
    }

}

