/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

public interface v {
    public boolean isInitialized();
}

