/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.af;
import com.google.protobuf.h;
import com.google.protobuf.t;
import com.google.protobuf.v;
import java.util.Map;

public interface w
extends v {
    public Map<h.f, Object> getAllFields();

    public t getDefaultInstanceForType();

    public h.a getDescriptorForType();

    public Object getField(h.f var1);

    public af getUnknownFields();

    public boolean hasField(h.f var1);
}

