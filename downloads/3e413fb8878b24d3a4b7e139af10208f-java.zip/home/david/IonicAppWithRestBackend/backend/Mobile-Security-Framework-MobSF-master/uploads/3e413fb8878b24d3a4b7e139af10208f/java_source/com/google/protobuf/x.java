/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.d;
import com.google.protobuf.e;
import com.google.protobuf.k;
import java.io.InputStream;

public interface x<MessageType> {
    public MessageType a(d var1);

    public MessageType a(d var1, k var2);

    public MessageType a(e var1);

    public MessageType a(e var1, k var2);

    public MessageType a(InputStream var1);

    public MessageType a(InputStream var1, k var2);

    public MessageType a(byte[] var1);

    public MessageType a(byte[] var1, k var2);

    public MessageType b(d var1, k var2);

    public MessageType b(e var1, k var2);

    public MessageType b(InputStream var1);

    public MessageType b(InputStream var1, k var2);
}

