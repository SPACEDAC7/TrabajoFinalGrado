/*
 * Decompiled with CFR 0_115.
 */
package com.google.protobuf;

import com.google.protobuf.ab;
import com.google.protobuf.m;
import com.google.protobuf.t;
import com.google.protobuf.w;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class z<MType extends m, BType extends m.a, IType extends w>
implements m.b {
    public m.b a;
    public List<MType> b;
    public List<ab<MType, BType, IType>> c;
    public boolean d;
    public b<MType, BType, IType> e;
    public a<MType, BType, IType> f;
    public c<MType, BType, IType> g;
    private boolean h;

    public z(List<MType> list, boolean bl2, m.b b2, boolean bl3) {
        this.b = list;
        this.h = bl2;
        this.a = b2;
        this.d = bl3;
    }

    public final BType a(int n2) {
        ab<MType, BType, IType> ab2;
        this.c();
        ab ab3 = ab2 = this.c.get(n2);
        if (ab2 == null) {
            ab3 = new ab((m)this.b.get(n2), this, this.d);
            this.c.set(n2, ab3);
        }
        return ab3.d();
    }

    public final MType a(int n2, boolean bl2) {
        if (this.c == null) {
            return (MType)((m)this.b.get(n2));
        }
        ab<MType, BType, IType> ab2 = this.c.get(n2);
        if (ab2 == null) {
            return (MType)((m)this.b.get(n2));
        }
        if (bl2) {
            return ab2.c();
        }
        return ab2.b();
    }

    public final z<MType, BType, IType> a(int n2, MType object) {
        if (object == null) {
            throw new NullPointerException();
        }
        this.b();
        this.b.set(n2, object);
        if (this.c != null && (object = (ab)this.c.set(n2, null)) != null) {
            object.a = null;
        }
        this.h();
        this.i();
        return this;
    }

    public final z<MType, BType, IType> a(MType MType) {
        if (MType == null) {
            throw new NullPointerException();
        }
        this.b();
        this.b.add(MType);
        if (this.c != null) {
            this.c.add(null);
        }
        this.h();
        this.i();
        return this;
    }

    public final z<MType, BType, IType> a(Iterable<? extends MType> iterator) {
        Iterator<MType> iterator2 = iterator.iterator();
        while (iterator2.hasNext()) {
            if ((m)iterator2.next() != null) continue;
            throw new NullPointerException();
        }
        if (iterator instanceof Collection) {
            if (((Collection)((Object)iterator)).size() == 0) {
                return this;
            }
            this.b();
            iterator = iterator.iterator();
            while (iterator.hasNext()) {
                this.a((m)iterator.next());
            }
        } else {
            this.b();
            iterator = iterator.iterator();
            while (iterator.hasNext()) {
                this.a((m)iterator.next());
            }
        }
        this.h();
        this.i();
        return this;
    }

    @Override
    public final void a() {
        this.h();
    }

    public final IType b(int n2) {
        if (this.c == null) {
            return (IType)((w)this.b.get(n2));
        }
        ab<MType, BType, IType> ab2 = this.c.get(n2);
        if (ab2 == null) {
            return (IType)((w)this.b.get(n2));
        }
        return ab2.e();
    }

    public final z<MType, BType, IType> b(int n2, MType MType) {
        if (MType == null) {
            throw new NullPointerException();
        }
        this.b();
        this.b.add(n2, MType);
        if (this.c != null) {
            this.c.add(n2, null);
        }
        this.h();
        this.i();
        return this;
    }

    public final void b() {
        if (!this.h) {
            this.b = new ArrayList<MType>(this.b);
            this.h = true;
        }
    }

    public final void c() {
        if (this.c == null) {
            this.c = new ArrayList<ab<MType, BType, IType>>(this.b.size());
            for (int i2 = 0; i2 < this.b.size(); ++i2) {
                this.c.add(null);
            }
        }
    }

    public final void c(int n2) {
        ab<MType, BType, IType> ab2;
        this.b();
        this.b.remove(n2);
        if (this.c != null && (ab2 = this.c.remove(n2)) != null) {
            ab2.a = null;
        }
        this.h();
        this.i();
    }

    public final int d() {
        return this.b.size();
    }

    public final boolean e() {
        return this.b.isEmpty();
    }

    public final void f() {
        this.b = Collections.emptyList();
        this.h = false;
        if (this.c != null) {
            for (ab<MType, BType, IType> ab2 : this.c) {
                if (ab2 == null) continue;
                ab2.a = null;
            }
            this.c = null;
        }
        this.h();
        this.i();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final List<MType> g() {
        int n2;
        block6 : {
            this.d = true;
            if (!this.h && this.c == null) {
                return this.b;
            }
            if (!this.h) {
                n2 = 0;
                while (n2 < this.b.size()) {
                    t t2 = (t)this.b.get(n2);
                    ab<MType, BType, IType> ab2 = this.c.get(n2);
                    if (ab2 != null && ab2.c() != t2) {
                        n2 = 0;
                        if (n2 != 0) {
                            return this.b;
                        }
                        break block6;
                    }
                    ++n2;
                }
                return this.b;
            }
        }
        this.b();
        for (n2 = 0; n2 < this.b.size(); ++n2) {
            this.b.set(n2, this.a(n2, true));
        }
        this.b = Collections.unmodifiableList(this.b);
        this.h = false;
        return this.b;
    }

    public final void h() {
        if (this.d && this.a != null) {
            this.a.a();
            this.d = false;
        }
    }

    public final void i() {
        if (this.e != null) {
            this.e.a();
        }
        if (this.f != null) {
            this.f.a();
        }
        if (this.g != null) {
            this.g.a();
        }
    }

    public static final class a<MType extends m, BType extends m.a, IType extends w>
    extends AbstractList<BType>
    implements List<BType> {
        z<MType, BType, IType> a;

        public a(z<MType, BType, IType> z2) {
            this.a = z2;
        }

        final void a() {
            ++this.modCount;
        }

        @Override
        public final /* synthetic */ Object get(int n2) {
            return this.a.a(n2);
        }

        @Override
        public final int size() {
            return this.a.d();
        }
    }

    public static final class b<MType extends m, BType extends m.a, IType extends w>
    extends AbstractList<MType>
    implements List<MType> {
        z<MType, BType, IType> a;

        public b(z<MType, BType, IType> z2) {
            this.a = z2;
        }

        final void a() {
            ++this.modCount;
        }

        @Override
        public final /* synthetic */ Object get(int n2) {
            return this.a.a(n2, false);
        }

        @Override
        public final int size() {
            return this.a.d();
        }
    }

    public static final class c<MType extends m, BType extends m.a, IType extends w>
    extends AbstractList<IType>
    implements List<IType> {
        z<MType, BType, IType> a;

        public c(z<MType, BType, IType> z2) {
            this.a = z2;
        }

        final void a() {
            ++this.modCount;
        }

        @Override
        public final /* synthetic */ Object get(int n2) {
            return this.a.b(n2);
        }

        @Override
        public final int size() {
            return this.a.d();
        }
    }

}

