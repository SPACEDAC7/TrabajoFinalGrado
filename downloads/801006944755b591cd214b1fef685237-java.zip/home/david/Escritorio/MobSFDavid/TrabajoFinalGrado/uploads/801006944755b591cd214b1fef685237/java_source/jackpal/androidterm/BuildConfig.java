/*
 * Decompiled with CFR 0_115.
 */
package jackpal.androidterm;

public final class BuildConfig {
    public static final String APPLICATION_ID = "jackpal.androidterm";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 71;
    public static final String VERSION_NAME = "";
}

