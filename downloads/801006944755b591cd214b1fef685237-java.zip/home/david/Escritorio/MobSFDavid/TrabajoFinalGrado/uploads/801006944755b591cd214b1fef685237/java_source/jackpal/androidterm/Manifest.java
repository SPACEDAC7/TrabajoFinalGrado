/*
 * Decompiled with CFR 0_115.
 */
package jackpal.androidterm;

public final class Manifest {

    public static final class permission {
        public static final String APPEND_TO_PATH = "jackpal.androidterm.permission.APPEND_TO_PATH";
        public static final String PREPEND_TO_PATH = "jackpal.androidterm.permission.PREPEND_TO_PATH";
        public static final String RUN_SCRIPT = "jackpal.androidterm.permission.RUN_SCRIPT";
    }

}

