/*
 * Decompiled with CFR 0_115.
 */
package jackpal.androidterm;

public final class R {

    public static final class array {
        public static final int control_keys_short_names = 2131034112;
        public static final int entries_actionbar_preference = 2131034113;
        public static final int entries_backaction_preference = 2131034114;
        public static final int entries_color_preference = 2131034115;
        public static final int entries_controlkey_preference = 2131034116;
        public static final int entries_cursorblink_preference = 2131034117;
        public static final int entries_cursorstyle_preference = 2131034118;
        public static final int entries_fnkey_preference = 2131034119;
        public static final int entries_fontsize_preference = 2131034120;
        public static final int entries_ime_preference = 2131034121;
        public static final int entries_orientation_preference = 2131034122;
        public static final int entries_statusbar_preference = 2131034123;
        public static final int entries_termtype_preference = 2131034124;
        public static final int entryvalues_actionbar_preference = 2131034125;
        public static final int entryvalues_backaction_preference = 2131034126;
        public static final int entryvalues_color_preference = 2131034127;
        public static final int entryvalues_controlkey_preference = 2131034128;
        public static final int entryvalues_cursorblink_preference = 2131034129;
        public static final int entryvalues_cursorstyle_preference = 2131034130;
        public static final int entryvalues_fnkey_preference = 2131034131;
        public static final int entryvalues_fontsize_preference = 2131034132;
        public static final int entryvalues_ime_preference = 2131034133;
        public static final int entryvalues_orientation_preference = 2131034134;
        public static final int entryvalues_statusbar_preference = 2131034135;
        public static final int fn_keys_short_names = 2131034136;
    }

    public static final class attr {
    }

    public static final class bool {
        public static final int pref_allow_prepend_path_default = 2131099648;
        public static final int pref_alt_sends_esc_default = 2131099649;
        public static final int pref_close_window_on_process_exit_default = 2131099650;
        public static final int pref_do_path_extensions_default = 2131099651;
        public static final int pref_mouse_tracking_default = 2131099652;
        public static final int pref_use_keyboard_shortcuts_default = 2131099653;
        public static final int pref_utf8_by_default_default = 2131099654;
        public static final int pref_verify_path_default = 2131099655;
    }

    public static final class color {
        public static final int accent = 2131427328;
        public static final int primary = 2131427329;
        public static final int primary_dark = 2131427330;
    }

    public static final class drawable {
        public static final int atari_small = 2130837504;
        public static final int atari_small_nodpi = 2130837505;
        public static final int btn_close_window = 2130837506;
        public static final int close_background = 2130837507;
        public static final int ic_folder = 2130837508;
        public static final int ic_folderup = 2130837509;
        public static final int ic_launcher = 2130837510;
        public static final int ic_menu_add = 2130837511;
        public static final int ic_menu_back = 2130837512;
        public static final int ic_menu_close_clear_cancel = 2130837513;
        public static final int ic_menu_forward = 2130837514;
        public static final int ic_menu_preferences = 2130837515;
        public static final int ic_menu_windows = 2130837516;
        public static final int ic_stat_service_notification_icon = 2130837517;
    }

    public static final class id {
        public static final int action_help = 2131165202;
        public static final int imageview = 2131165184;
        public static final int mainview = 2131165185;
        public static final int menu_close_window = 2131165193;
        public static final int menu_new_window = 2131165192;
        public static final int menu_preferences = 2131165197;
        public static final int menu_reset = 2131165198;
        public static final int menu_send_email = 2131165199;
        public static final int menu_special_keys = 2131165196;
        public static final int menu_toggle_soft_keyboard = 2131165195;
        public static final int menu_toggle_wakelock = 2131165200;
        public static final int menu_toggle_wifilock = 2131165201;
        public static final int menu_window_list = 2131165194;
        public static final int scrollview = 2131165186;
        public static final int textview = 2131165187;
        public static final int view_flipper = 2131165188;
        public static final int window_list_close = 2131165191;
        public static final int window_list_label = 2131165189;
        public static final int window_list_separator = 2131165190;
    }

    public static final class integer {
        public static final int pref_actionbar_default = 2131230720;
        public static final int pref_orientation_default = 2131230721;
    }

    public static final class layout {
        public static final int term_activity = 2130903040;
        public static final int window_list_item = 2130903041;
        public static final int window_list_new_window = 2130903042;
    }

    public static final class menu {
        public static final int main = 2131492864;
    }

    public static final class string {
        public static final int activity_shortcut_create = 2131296256;
        public static final int activity_term_here_title = 2131296257;
        public static final int addshortcut_arguments_label = 2131296258;
        public static final int addshortcut_button_find_command = 2131296259;
        public static final int addshortcut_button_text_icon = 2131296260;
        public static final int addshortcut_command_hint = 2131296261;
        public static final int addshortcut_command_window_instructions = 2131296262;
        public static final int addshortcut_example_hint = 2131296263;
        public static final int addshortcut_make_text_icon = 2131296264;
        public static final int addshortcut_navigator_title = 2131296265;
        public static final int addshortcut_shortcut_label = 2131296266;
        public static final int addshortcut_text_icon_instructions = 2131296267;
        public static final int addshortcut_title = 2131296268;
        public static final int alt_sends_esc = 2131296269;
        public static final int alt_sends_esc_summary_off = 2131296270;
        public static final int alt_sends_esc_summary_on = 2131296271;
        public static final int application_terminal = 2131296272;
        public static final int close_window = 2131296273;
        public static final int colorvalue_icon_text_entry_hint = 2131296274;
        public static final int colorvalue_label_lock_button_column = 2131296275;
        public static final int colorvalue_letter_alpha = 2131296276;
        public static final int colorvalue_letter_blue = 2131296277;
        public static final int colorvalue_letter_green = 2131296278;
        public static final int colorvalue_letter_red = 2131296279;
        public static final int confirm_window_close_message = 2131296280;
        public static final int control_key_dialog_control_disabled_text = 2131296281;
        public static final int control_key_dialog_control_text = 2131296282;
        public static final int control_key_dialog_fn_disabled_text = 2131296283;
        public static final int control_key_dialog_fn_text = 2131296284;
        public static final int control_key_dialog_title = 2131296285;
        public static final int copy_all = 2131296286;
        public static final int dialog_title_actionbar_preference = 2131296287;
        public static final int dialog_title_backaction_preference = 2131296288;
        public static final int dialog_title_color_preference = 2131296289;
        public static final int dialog_title_controlkey_preference = 2131296290;
        public static final int dialog_title_cursorblink_preference = 2131296291;
        public static final int dialog_title_cursorstyle_preference = 2131296292;
        public static final int dialog_title_fnkey_preference = 2131296293;
        public static final int dialog_title_fontsize_preference = 2131296294;
        public static final int dialog_title_ime_preference = 2131296295;
        public static final int dialog_title_initialcommand_preference = 2131296296;
        public static final int dialog_title_orientation_preference = 2131296297;
        public static final int dialog_title_shell_preference = 2131296298;
        public static final int dialog_title_statusbar_preference = 2131296299;
        public static final int dialog_title_termtype_preference = 2131296300;
        public static final int disable_wakelock = 2131296301;
        public static final int disable_wifilock = 2131296302;
        public static final int edit_text = 2131296303;
        public static final int email_transcript_chooser_title = 2131296304;
        public static final int email_transcript_no_email_activity_found = 2131296305;
        public static final int email_transcript_subject = 2131296306;
        public static final int enable_wakelock = 2131296307;
        public static final int enable_wifilock = 2131296308;
        public static final int fsnavigator_change_theme = 2131296309;
        public static final int fsnavigator_no_external_storage = 2131296310;
        public static final int fsnavigator_optional_enter_path = 2131296311;
        public static final int fsnavigator_title = 2131296312;
        public static final int help = 2131296313;
        public static final int help_url = 2131296314;
        public static final int keyboard_preferences = 2131296315;
        public static final int new_window = 2131296316;
        public static final int next_window = 2131296317;
        public static final int paste = 2131296318;
        public static final int perm_append_to_path = 2131296319;
        public static final int perm_prepend_to_path = 2131296320;
        public static final int perm_run_script = 2131296321;
        public static final int permdesc_append_to_path = 2131296322;
        public static final int permdesc_prepend_to_path = 2131296323;
        public static final int permdesc_run_script = 2131296324;
        public static final int pref_backaction_default = 2131296325;
        public static final int pref_color_default = 2131296326;
        public static final int pref_controlkey_default = 2131296327;
        public static final int pref_cursorblink_default = 2131296328;
        public static final int pref_cursorstyle_default = 2131296329;
        public static final int pref_fnkey_default = 2131296330;
        public static final int pref_fontsize_default = 2131296331;
        public static final int pref_ime_default = 2131296332;
        public static final int pref_initialcommand_default = 2131296333;
        public static final int pref_shell_default = 2131296334;
        public static final int pref_statusbar_default = 2131296335;
        public static final int pref_termtype_default = 2131296336;
        public static final int preferences = 2131296337;
        public static final int prev_window = 2131296338;
        public static final int process_exit_message = 2131296339;
        public static final int reset = 2131296340;
        public static final int reset_toast_notification = 2131296341;
        public static final int screen_preferences = 2131296342;
        public static final int select_text = 2131296343;
        public static final int send_control_key = 2131296344;
        public static final int send_email = 2131296345;
        public static final int send_fn_key = 2131296346;
        public static final int service_notify_text = 2131296347;
        public static final int shell_preferences = 2131296348;
        public static final int special_keys = 2131296349;
        public static final int summary_actionbar_preference = 2131296350;
        public static final int summary_allow_prepend_path_preference = 2131296351;
        public static final int summary_backaction_preference = 2131296352;
        public static final int summary_close_window_on_process_exit_preference = 2131296353;
        public static final int summary_color_preference = 2131296354;
        public static final int summary_controlkey_preference = 2131296355;
        public static final int summary_cursorblink_preference = 2131296356;
        public static final int summary_cursorstyle_preference = 2131296357;
        public static final int summary_do_path_extensions_preference = 2131296358;
        public static final int summary_fnkey_preference = 2131296359;
        public static final int summary_fontsize_preference = 2131296360;
        public static final int summary_home_path_preference = 2131296361;
        public static final int summary_ime_preference = 2131296362;
        public static final int summary_initialcommand_preference = 2131296363;
        public static final int summary_mouse_tracking_preference = 2131296364;
        public static final int summary_orientation_preference = 2131296365;
        public static final int summary_shell_preference = 2131296366;
        public static final int summary_statusbar_preference = 2131296367;
        public static final int summary_termtype_preference = 2131296368;
        public static final int summary_utf8_by_default_preference = 2131296369;
        public static final int summary_verify_path_preference = 2131296370;
        public static final int text_preferences = 2131296371;
        public static final int title_actionbar_preference = 2131296372;
        public static final int title_allow_prepend_path_preference = 2131296373;
        public static final int title_backaction_preference = 2131296374;
        public static final int title_close_window_on_process_exit_preference = 2131296375;
        public static final int title_color_preference = 2131296376;
        public static final int title_controlkey_preference = 2131296377;
        public static final int title_cursorblink_preference = 2131296378;
        public static final int title_cursorstyle_preference = 2131296379;
        public static final int title_do_path_extensions_preference = 2131296380;
        public static final int title_fnkey_preference = 2131296381;
        public static final int title_fontsize_preference = 2131296382;
        public static final int title_home_path_preference = 2131296383;
        public static final int title_ime_preference = 2131296384;
        public static final int title_initialcommand_preference = 2131296385;
        public static final int title_mouse_tracking_preference = 2131296386;
        public static final int title_orientation_preference = 2131296387;
        public static final int title_shell_preference = 2131296388;
        public static final int title_statusbar_preference = 2131296389;
        public static final int title_termtype_preference = 2131296390;
        public static final int title_use_keyboard_shortcuts = 2131296391;
        public static final int title_utf8_by_default_preference = 2131296392;
        public static final int title_verify_path_preference = 2131296393;
        public static final int toggle_soft_keyboard = 2131296394;
        public static final int use_keyboard_shortcuts_summary_off = 2131296395;
        public static final int use_keyboard_shortcuts_summary_on = 2131296396;
        public static final int window_list = 2131296397;
        public static final int window_title = 2131296398;
    }

    public static final class style {
        public static final int Theme = 2131361792;
        public static final int Theme_Holo = 2131361793;
        public static final int Theme_Holo_ActionBarOverlay = 2131361794;
        public static final int Widget_ActionBarOverlay = 2131361795;
    }

    public static final class styleable {
        public static final int[] EmulatorView = new int[0];
    }

    public static final class xml {
        public static final int preferences = 2130968576;
    }

}

