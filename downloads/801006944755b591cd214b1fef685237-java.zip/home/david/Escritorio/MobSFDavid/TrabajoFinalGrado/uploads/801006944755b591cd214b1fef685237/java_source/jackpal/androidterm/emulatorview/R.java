/*
 * Decompiled with CFR 0_115.
 */
package jackpal.androidterm.emulatorview;

public final class R {

    public static final class drawable {
        public static final int atari_small = 2130837504;
        public static final int atari_small_nodpi = 2130837505;
    }

}

