/*
 * Decompiled with CFR 0_115.
 */
package jackpal.androidterm.emulatorview;

public interface UpdateCallback {
    public void onUpdate();
}

