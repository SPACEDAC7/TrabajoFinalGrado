/*
 * Decompiled with CFR 0_115.
 */
package jackpal.androidterm.emulatorview.compat;

public interface ClipboardManagerCompat {
    public CharSequence getText();

    public boolean hasText();

    public void setText(CharSequence var1);
}

