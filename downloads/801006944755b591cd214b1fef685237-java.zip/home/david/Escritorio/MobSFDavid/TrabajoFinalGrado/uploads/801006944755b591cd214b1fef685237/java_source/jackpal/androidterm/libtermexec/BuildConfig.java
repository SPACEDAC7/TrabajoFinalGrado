/*
 * Decompiled with CFR 0_115.
 */
package jackpal.androidterm.libtermexec;

public final class BuildConfig {
    public static final String APPLICATION_ID = "jackpal.androidterm.libtermexec";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";
}

