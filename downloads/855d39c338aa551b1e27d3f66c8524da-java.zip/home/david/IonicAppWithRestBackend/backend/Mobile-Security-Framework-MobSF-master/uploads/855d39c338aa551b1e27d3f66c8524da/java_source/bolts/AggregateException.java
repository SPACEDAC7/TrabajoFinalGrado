/*
 * Decompiled with CFR 0_115.
 */
package bolts;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class AggregateException
extends Exception {
    private static final String DEFAULT_MESSAGE = "There were multiple errors.";
    private static final long serialVersionUID = 1;
    private List<Throwable> innerThrowables;

    /*
     * Enabled aggressive block sorting
     */
    public AggregateException(String string2, List<? extends Throwable> list) {
        Throwable throwable = list != null && list.size() > 0 ? list.get(0) : null;
        super(string2, throwable);
        this.innerThrowables = Collections.unmodifiableList(list);
    }

    public AggregateException(String string2, Throwable[] arrthrowable) {
        this(string2, Arrays.asList(arrthrowable));
    }

    public AggregateException(List<? extends Throwable> list) {
        this("There were multiple errors.", list);
    }

    @Deprecated
    public Throwable[] getCauses() {
        return this.innerThrowables.toArray(new Throwable[this.innerThrowables.size()]);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Deprecated
    public List<Exception> getErrors() {
        ArrayList<Exception> arrayList = new ArrayList<Exception>();
        if (this.innerThrowables != null) {
            for (Throwable throwable : this.innerThrowables) {
                if (throwable instanceof Exception) {
                    arrayList.add((Exception)throwable);
                    continue;
                }
                arrayList.add(new Exception(throwable));
            }
        }
        return arrayList;
    }

    public List<Throwable> getInnerThrowables() {
        return this.innerThrowables;
    }

    @Override
    public void printStackTrace(PrintStream printStream) {
        super.printStackTrace(printStream);
        int n = -1;
        for (Throwable throwable : this.innerThrowables) {
            printStream.append("\n");
            printStream.append("  Inner throwable #");
            printStream.append(Integer.toString(++n));
            printStream.append(": ");
            throwable.printStackTrace(printStream);
            printStream.append("\n");
        }
    }

    @Override
    public void printStackTrace(PrintWriter printWriter) {
        super.printStackTrace(printWriter);
        int n = -1;
        for (Throwable throwable : this.innerThrowables) {
            printWriter.append("\n");
            printWriter.append("  Inner throwable #");
            printWriter.append(Integer.toString(++n));
            printWriter.append(": ");
            throwable.printStackTrace(printWriter);
            printWriter.append("\n");
        }
    }
}

