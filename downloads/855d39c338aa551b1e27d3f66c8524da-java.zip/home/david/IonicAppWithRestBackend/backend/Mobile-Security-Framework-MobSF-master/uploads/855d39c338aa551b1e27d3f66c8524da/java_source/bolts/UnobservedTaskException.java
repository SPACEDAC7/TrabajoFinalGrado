/*
 * Decompiled with CFR 0_115.
 */
package bolts;

public class UnobservedTaskException
extends RuntimeException {
    public UnobservedTaskException(Throwable throwable) {
        super(throwable);
    }
}

