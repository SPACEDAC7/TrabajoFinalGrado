/*
 * Decompiled with CFR 0_115.
 */
package com.crashlytics.android.core;

public interface CrashlyticsListener {
    public void crashlyticsDidDetectCrashDuringPreviousExecution();
}

