/*
 * Decompiled with CFR 0_115.
 */
package com.crashlytics.android.core;

import com.crashlytics.android.core.CreateReportRequest;

interface CreateReportSpiCall {
    public boolean invoke(CreateReportRequest var1);
}

