/*
 * Decompiled with CFR 0_115.
 */
package com.crashlytics.android.core;

interface UnityVersionProvider {
    public String getUnityVersion();
}

