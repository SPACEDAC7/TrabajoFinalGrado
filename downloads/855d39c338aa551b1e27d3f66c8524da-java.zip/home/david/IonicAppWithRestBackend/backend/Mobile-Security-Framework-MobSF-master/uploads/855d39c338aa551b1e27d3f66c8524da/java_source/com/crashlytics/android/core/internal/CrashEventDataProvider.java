/*
 * Decompiled with CFR 0_115.
 */
package com.crashlytics.android.core.internal;

import com.crashlytics.android.core.internal.models.SessionEventData;

public interface CrashEventDataProvider {
    public SessionEventData getCrashEventData();
}

