/*
 * Decompiled with CFR 0_115.
 */
package com.crashlytics.android.core.internal.models;

public class CustomAttributeData {
    public final String key;
    public final String value;

    public CustomAttributeData(String string2, String string3) {
        this.key = string2;
        this.value = string3;
    }
}

