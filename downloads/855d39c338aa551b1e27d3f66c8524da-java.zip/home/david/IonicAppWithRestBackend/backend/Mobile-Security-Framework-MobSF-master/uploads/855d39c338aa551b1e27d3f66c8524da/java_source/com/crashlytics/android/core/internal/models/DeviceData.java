/*
 * Decompiled with CFR 0_115.
 */
package com.crashlytics.android.core.internal.models;

public class DeviceData {
    public final long availableInternalStorage;
    public final long availablePhysicalMemory;
    public final int batteryCapacity;
    public final int batteryVelocity;
    public final int orientation;
    public final boolean proximity;
    public final long totalInternalStorage;
    public final long totalPhysicalMemory;

    public DeviceData(int n, long l, long l2, long l3, long l4, int n2, int n3, boolean bl) {
        this.orientation = n;
        this.totalPhysicalMemory = l;
        this.totalInternalStorage = l2;
        this.availablePhysicalMemory = l3;
        this.availableInternalStorage = l4;
        this.batteryCapacity = n2;
        this.batteryVelocity = n3;
        this.proximity = bl;
    }
}

