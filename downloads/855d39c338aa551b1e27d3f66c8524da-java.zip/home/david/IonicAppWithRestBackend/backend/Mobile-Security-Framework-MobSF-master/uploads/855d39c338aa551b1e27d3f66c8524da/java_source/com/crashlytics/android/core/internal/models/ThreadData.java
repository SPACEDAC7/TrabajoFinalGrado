/*
 * Decompiled with CFR 0_115.
 */
package com.crashlytics.android.core.internal.models;

public class ThreadData {
    public static final int IMPORTANCE_CRASHED_THREAD = 4;
    public final FrameData[] frames;
    public final int importance;
    public final String name;

    public ThreadData(int n, FrameData[] arrframeData) {
        this(null, n, arrframeData);
    }

    public ThreadData(String string2, int n, FrameData[] arrframeData) {
        this.name = string2;
        this.importance = n;
        this.frames = arrframeData;
    }

    public static final class FrameData {
        public final long address;
        public final String file;
        public final int importance;
        public final long offset;
        public final String symbol;

        public FrameData(long l, int n) {
            this(l, "", n);
        }

        public FrameData(long l, String string2, int n) {
            this(l, string2, "", 0, n);
        }

        public FrameData(long l, String string2, String string3, long l2, int n) {
            this.address = l;
            this.symbol = string2;
            this.file = string3;
            this.offset = l2;
            this.importance = n;
        }
    }

}

