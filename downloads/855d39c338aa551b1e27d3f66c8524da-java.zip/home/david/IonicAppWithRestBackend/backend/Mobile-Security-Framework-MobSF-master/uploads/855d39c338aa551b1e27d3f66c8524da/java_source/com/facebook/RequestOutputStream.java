/*
 * Decompiled with CFR 0_115.
 */
package com.facebook;

import com.facebook.GraphRequest;

interface RequestOutputStream {
    public void setCurrentRequest(GraphRequest var1);
}

