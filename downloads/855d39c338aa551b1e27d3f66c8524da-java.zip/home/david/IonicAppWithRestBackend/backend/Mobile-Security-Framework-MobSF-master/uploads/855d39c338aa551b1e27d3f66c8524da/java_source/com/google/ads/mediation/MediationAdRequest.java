/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.location.Location
 */
package com.google.ads.mediation;

import android.location.Location;
import com.google.ads.AdRequest;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;

@Deprecated
public class MediationAdRequest {
    private final Date zzgr;
    private final AdRequest.Gender zzgs;
    private final Set<String> zzgt;
    private final boolean zzgu;
    private final Location zzgv;

    public MediationAdRequest(Date date, AdRequest.Gender gender, Set<String> set, boolean bl, Location location) {
        this.zzgr = date;
        this.zzgs = gender;
        this.zzgt = set;
        this.zzgu = bl;
        this.zzgv = location;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public Integer getAgeInYears() {
        if (this.zzgr == null) return null;
        Calendar calendar = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        calendar.setTime(this.zzgr);
        Integer n = calendar2.get(1) - calendar.get(1);
        if (calendar2.get(2) < calendar.get(2)) return n - 1;
        Integer n2 = n;
        if (calendar2.get(2) != calendar.get(2)) return n2;
        n2 = n;
        if (calendar2.get(5) >= calendar.get(5)) return n2;
        return n - 1;
    }

    public Date getBirthday() {
        return this.zzgr;
    }

    public AdRequest.Gender getGender() {
        return this.zzgs;
    }

    public Set<String> getKeywords() {
        return this.zzgt;
    }

    public Location getLocation() {
        return this.zzgv;
    }

    public boolean isTesting() {
        return this.zzgu;
    }
}

