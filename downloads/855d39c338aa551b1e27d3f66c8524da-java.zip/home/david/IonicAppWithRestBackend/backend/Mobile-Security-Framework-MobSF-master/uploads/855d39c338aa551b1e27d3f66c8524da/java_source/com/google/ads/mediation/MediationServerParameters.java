/*
 * Decompiled with CFR 0_115.
 */
package com.google.ads.mediation;

import com.google.android.gms.ads.internal.util.client.zzb;
import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

@Deprecated
public abstract class MediationServerParameters {
    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void load(Map<String, String> object) throws MappingException {
        Map.Entry entry;
        HashMap<String, Field> hashMap = new HashMap<String, Field>();
        for (Field field : this.getClass().getFields()) {
            Parameter parameter = (Parameter)field.getAnnotation(Parameter.class);
            if (parameter == null) continue;
            hashMap.put(parameter.name(), field);
        }
        if (hashMap.isEmpty()) {
            zzb.zzdi("No server options fields detected. To suppress this message either add a field with the @Parameter annotation, or override the load() method.");
        }
        object = object.entrySet().iterator();
        while (object.hasNext()) {
            entry = object.next();
            Field field2 = (Field)hashMap.remove(entry.getKey());
            if (field2 != null) {
                try {
                    field2.set(this, entry.getValue());
                }
                catch (IllegalAccessException var6_9) {
                    entry = (String)entry.getKey();
                    zzb.zzdi(new StringBuilder(String.valueOf(entry).length() + 49).append("Server option \"").append((String)((Object)entry)).append("\" could not be set: Illegal Access").toString());
                }
                catch (IllegalArgumentException var6_10) {
                    entry = (String)entry.getKey();
                    zzb.zzdi(new StringBuilder(String.valueOf(entry).length() + 43).append("Server option \"").append((String)((Object)entry)).append("\" could not be set: Bad Type").toString());
                }
                continue;
            }
            String string2 = (String)entry.getKey();
            entry = (String)entry.getValue();
            zzb.zzdg(new StringBuilder(String.valueOf(string2).length() + 31 + String.valueOf(entry).length()).append("Unexpected server option: ").append(string2).append(" = \"").append((String)((Object)entry)).append("\"").toString());
        }
        entry = new StringBuilder();
        for (Field field3 : hashMap.values()) {
            if (!((Parameter)field3.getAnnotation(Parameter.class)).required()) continue;
            object = String.valueOf(((Parameter)field3.getAnnotation(Parameter.class)).name());
            object = object.length() != 0 ? "Required server option missing: ".concat((String)object) : new String("Required server option missing: ");
            zzb.zzdi((String)object);
            if (entry.length() > 0) {
                entry.append(", ");
            }
            entry.append(((Parameter)field3.getAnnotation(Parameter.class)).name());
        }
        if (entry.length() <= 0) {
            this.zzab();
            return;
        }
        object = String.valueOf(entry.toString());
        if (object.length() != 0) {
            object = "Required server option(s) missing: ".concat((String)object);
            throw new MappingException((String)object);
        }
        object = new String("Required server option(s) missing: ");
        throw new MappingException((String)object);
    }

    protected void zzab() {
    }

    public static final class MappingException
    extends Exception {
        public MappingException(String string2) {
            super(string2);
        }
    }

    @Retention(value=RetentionPolicy.RUNTIME)
    @Target(value={ElementType.FIELD})
    protected static @interface Parameter {
        public String name();

        public boolean required() default 1;
    }

}

