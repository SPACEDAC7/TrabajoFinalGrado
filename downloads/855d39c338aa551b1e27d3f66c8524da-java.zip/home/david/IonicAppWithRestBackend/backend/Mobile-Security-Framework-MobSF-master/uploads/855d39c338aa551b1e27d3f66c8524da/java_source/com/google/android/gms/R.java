/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms;

public final class R {

    public static final class array {
    }

    public static final class attr {
        public static final int adSize = 2130772001;
        public static final int adSizes = 2130772002;
        public static final int adUnitId = 2130772003;
        public static final int buttonSize = 2130772184;
        public static final int circleCrop = 2130772155;
        public static final int colorScheme = 2130772185;
        public static final int imageAspectRatio = 2130772154;
        public static final int imageAspectRatioAdjust = 2130772153;
        public static final int scopeUris = 2130772186;
    }

    public static final class color {
        public static final int common_google_signin_btn_text_dark = 2131427472;
        public static final int common_google_signin_btn_text_dark_default = 2131427376;
        public static final int common_google_signin_btn_text_dark_disabled = 2131427377;
        public static final int common_google_signin_btn_text_dark_focused = 2131427378;
        public static final int common_google_signin_btn_text_dark_pressed = 2131427379;
        public static final int common_google_signin_btn_text_light = 2131427473;
        public static final int common_google_signin_btn_text_light_default = 2131427380;
        public static final int common_google_signin_btn_text_light_disabled = 2131427381;
        public static final int common_google_signin_btn_text_light_focused = 2131427382;
        public static final int common_google_signin_btn_text_light_pressed = 2131427383;
    }

    public static final class dimen {
    }

    public static final class drawable {
        public static final int common_full_open_on_phone = 2130837615;
        public static final int common_google_signin_btn_icon_dark = 2130837616;
        public static final int common_google_signin_btn_icon_dark_disabled = 2130837617;
        public static final int common_google_signin_btn_icon_dark_focused = 2130837618;
        public static final int common_google_signin_btn_icon_dark_normal = 2130837619;
        public static final int common_google_signin_btn_icon_dark_pressed = 2130837620;
        public static final int common_google_signin_btn_icon_light = 2130837621;
        public static final int common_google_signin_btn_icon_light_disabled = 2130837622;
        public static final int common_google_signin_btn_icon_light_focused = 2130837623;
        public static final int common_google_signin_btn_icon_light_normal = 2130837624;
        public static final int common_google_signin_btn_icon_light_pressed = 2130837625;
        public static final int common_google_signin_btn_text_dark = 2130837626;
        public static final int common_google_signin_btn_text_dark_disabled = 2130837627;
        public static final int common_google_signin_btn_text_dark_focused = 2130837628;
        public static final int common_google_signin_btn_text_dark_normal = 2130837629;
        public static final int common_google_signin_btn_text_dark_pressed = 2130837630;
        public static final int common_google_signin_btn_text_light = 2130837631;
        public static final int common_google_signin_btn_text_light_disabled = 2130837632;
        public static final int common_google_signin_btn_text_light_focused = 2130837633;
        public static final int common_google_signin_btn_text_light_normal = 2130837634;
        public static final int common_google_signin_btn_text_light_pressed = 2130837635;
    }

    public static final class id {
        public static final int adjust_height = 2131558429;
        public static final int adjust_width = 2131558430;
        public static final int auto = 2131558439;
        public static final int button = 2131558448;
        public static final int center = 2131558450;
        public static final int dark = 2131558440;
        public static final int icon_only = 2131558436;
        public static final int light = 2131558441;
        public static final int none = 2131558414;
        public static final int normal = 2131558410;
        public static final int radio = 2131558484;
        public static final int standard = 2131558437;
        public static final int text = 2131558739;
        public static final int text2 = 2131558737;
        public static final int wide = 2131558438;
        public static final int wrap_content = 2131558425;
    }

    public static final class integer {
        public static final int google_play_services_version = 2131623940;
    }

    public static final class layout {
    }

    public static final class raw {
        public static final int gtm_analytics = 2131099648;
    }

    public static final class string {
        public static final int accept = 2131165203;
        public static final int common_google_play_services_enable_button = 2131165221;
        public static final int common_google_play_services_enable_text = 2131165222;
        public static final int common_google_play_services_enable_title = 2131165223;
        public static final int common_google_play_services_install_button = 2131165224;
        public static final int common_google_play_services_install_text = 2131165225;
        public static final int common_google_play_services_install_title = 2131165226;
        public static final int common_google_play_services_notification_ticker = 2131165227;
        public static final int common_google_play_services_unknown_issue = 2131165228;
        public static final int common_google_play_services_unsupported_text = 2131165229;
        public static final int common_google_play_services_update_button = 2131165230;
        public static final int common_google_play_services_update_text = 2131165231;
        public static final int common_google_play_services_update_title = 2131165232;
        public static final int common_google_play_services_updating_text = 2131165233;
        public static final int common_google_play_services_wear_update_text = 2131165234;
        public static final int common_open_on_phone = 2131165235;
        public static final int common_signin_button_text = 2131165236;
        public static final int common_signin_button_text_long = 2131165237;
        public static final int create_calendar_message = 2131165238;
        public static final int create_calendar_title = 2131165239;
        public static final int debug_menu_ad_information = 2131165240;
        public static final int debug_menu_creative_preview = 2131165241;
        public static final int debug_menu_title = 2131165242;
        public static final int debug_menu_troubleshooting = 2131165243;
        public static final int decline = 2131165244;
        public static final int store_picture_message = 2131165248;
        public static final int store_picture_title = 2131165249;
    }

    public static final class style {
        public static final int Theme_IAPTheme = 2131296545;
    }

    public static final class styleable {
        public static final int[] AdsAttrs = new int[]{2130772001, 2130772002, 2130772003};
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;
        public static final int[] LoadingImageView = new int[]{2130772153, 2130772154, 2130772155};
        public static final int LoadingImageView_circleCrop = 2;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 0;
        public static final int[] SignInButton = new int[]{2130772184, 2130772185, 2130772186};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_colorScheme = 1;
        public static final int SignInButton_scopeUris = 2;
    }

}

