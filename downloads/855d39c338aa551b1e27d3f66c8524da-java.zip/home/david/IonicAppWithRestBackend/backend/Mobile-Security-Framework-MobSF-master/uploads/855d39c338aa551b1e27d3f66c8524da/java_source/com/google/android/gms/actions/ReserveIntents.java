/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.actions;

public class ReserveIntents {
    public static final String ACTION_RESERVE_TAXI_RESERVATION = "com.google.android.gms.actions.RESERVE_TAXI_RESERVATION";

    private ReserveIntents() {
    }
}

