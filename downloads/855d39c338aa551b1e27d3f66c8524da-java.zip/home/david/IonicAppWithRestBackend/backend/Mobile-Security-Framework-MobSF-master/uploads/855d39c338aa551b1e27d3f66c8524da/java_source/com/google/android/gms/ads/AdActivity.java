/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.os.RemoteException
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 */
package com.google.android.gms.ads;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.internal.zzhy;

public class AdActivity
extends Activity {
    public static final String CLASS_NAME = "com.google.android.gms.ads.AdActivity";
    public static final String SIMPLE_CLASS_NAME = "AdActivity";
    private zzhy zzakb;

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void zzds() {
        if (this.zzakb == null) return;
        try {
            this.zzakb.zzds();
            return;
        }
        catch (RemoteException var1_1) {
            zzb.zzc("Could not forward setContentViewSet to ad overlay:", (Throwable)var1_1);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onActivityResult(int n, int n2, Intent intent) {
        try {
            this.zzakb.onActivityResult(n, n2, intent);
        }
        catch (Exception var4_4) {
            zzb.zzc("Could not forward onActivityResult to ad overlay:", var4_4);
        }
        super.onActivityResult(n, n2, intent);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onBackPressed() {
        boolean bl;
        boolean bl2 = bl = true;
        try {
            if (this.zzakb != null) {
                bl2 = this.zzakb.zzpn();
            }
        }
        catch (RemoteException var3_3) {
            zzb.zzc("Could not forward onBackPressed to ad overlay:", (Throwable)var3_3);
            bl2 = bl;
        }
        if (bl2) {
            super.onBackPressed();
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        try {
            this.zzakb.zzn(zze.zzac(configuration));
            return;
        }
        catch (RemoteException var1_2) {
            zzb.zzc("Failed to wrap configuration.", (Throwable)var1_2);
            return;
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.zzakb = zzm.zzks().zzc(this);
        if (this.zzakb == null) {
            zzb.zzdi("Could not create ad overlay.");
            this.finish();
            return;
        }
        try {
            this.zzakb.onCreate(bundle);
            return;
        }
        catch (RemoteException var1_2) {
            zzb.zzc("Could not forward onCreate to ad overlay:", (Throwable)var1_2);
            this.finish();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onDestroy() {
        try {
            if (this.zzakb != null) {
                this.zzakb.onDestroy();
            }
        }
        catch (RemoteException var1_1) {
            zzb.zzc("Could not forward onDestroy to ad overlay:", (Throwable)var1_1);
        }
        super.onDestroy();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onPause() {
        try {
            if (this.zzakb != null) {
                this.zzakb.onPause();
            }
        }
        catch (RemoteException var1_1) {
            zzb.zzc("Could not forward onPause to ad overlay:", (Throwable)var1_1);
            this.finish();
        }
        super.onPause();
    }

    protected void onRestart() {
        super.onRestart();
        try {
            if (this.zzakb != null) {
                this.zzakb.onRestart();
            }
            return;
        }
        catch (RemoteException var1_1) {
            zzb.zzc("Could not forward onRestart to ad overlay:", (Throwable)var1_1);
            this.finish();
            return;
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            if (this.zzakb != null) {
                this.zzakb.onResume();
            }
            return;
        }
        catch (RemoteException var1_1) {
            zzb.zzc("Could not forward onResume to ad overlay:", (Throwable)var1_1);
            this.finish();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onSaveInstanceState(Bundle bundle) {
        try {
            if (this.zzakb != null) {
                this.zzakb.onSaveInstanceState(bundle);
            }
        }
        catch (RemoteException var2_2) {
            zzb.zzc("Could not forward onSaveInstanceState to ad overlay:", (Throwable)var2_2);
            this.finish();
        }
        super.onSaveInstanceState(bundle);
    }

    protected void onStart() {
        super.onStart();
        try {
            if (this.zzakb != null) {
                this.zzakb.onStart();
            }
            return;
        }
        catch (RemoteException var1_1) {
            zzb.zzc("Could not forward onStart to ad overlay:", (Throwable)var1_1);
            this.finish();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onStop() {
        try {
            if (this.zzakb != null) {
                this.zzakb.onStop();
            }
        }
        catch (RemoteException var1_1) {
            zzb.zzc("Could not forward onStop to ad overlay:", (Throwable)var1_1);
            this.finish();
        }
        super.onStop();
    }

    public void setContentView(int n) {
        super.setContentView(n);
        this.zzds();
    }

    public void setContentView(View view) {
        super.setContentView(view);
        this.zzds();
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        super.setContentView(view, layoutParams);
        this.zzds();
    }
}

