/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.util.DisplayMetrics
 */
package com.google.android.gms.ads;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.zzm;

public final class AdSize {
    public static final int AUTO_HEIGHT = -2;
    public static final AdSize BANNER = new AdSize(320, 50, "320x50_mb");
    public static final AdSize FLUID;
    public static final AdSize FULL_BANNER;
    public static final int FULL_WIDTH = -1;
    public static final AdSize LARGE_BANNER;
    public static final AdSize LEADERBOARD;
    public static final AdSize MEDIUM_RECTANGLE;
    public static final AdSize SEARCH;
    public static final AdSize SMART_BANNER;
    public static final AdSize WIDE_SKYSCRAPER;
    private final int zzakh;
    private final int zzaki;
    private final String zzakj;

    static {
        FULL_BANNER = new AdSize(468, 60, "468x60_as");
        LARGE_BANNER = new AdSize(320, 100, "320x100_as");
        LEADERBOARD = new AdSize(728, 90, "728x90_as");
        MEDIUM_RECTANGLE = new AdSize(300, 250, "300x250_as");
        WIDE_SKYSCRAPER = new AdSize(160, 600, "160x600_as");
        SMART_BANNER = new AdSize(-1, -2, "smart_banner");
        FLUID = new AdSize(-3, -4, "fluid");
        SEARCH = new AdSize(-3, 0, "search_v2");
    }

    /*
     * Enabled aggressive block sorting
     */
    public AdSize(int n, int n2) {
        String string2 = n == -1 ? "FULL" : String.valueOf(n);
        String string3 = n2 == -2 ? "AUTO" : String.valueOf(n2);
        String string4 = String.valueOf("_as");
        this(n, n2, new StringBuilder(String.valueOf(string2).length() + 1 + String.valueOf(string3).length() + String.valueOf(string4).length()).append(string2).append("x").append(string3).append(string4).toString());
    }

    AdSize(int n, int n2, String string2) {
        if (n < 0 && n != -1 && n != -3) {
            throw new IllegalArgumentException(new StringBuilder(37).append("Invalid width for AdSize: ").append(n).toString());
        }
        if (n2 < 0 && n2 != -2 && n2 != -4) {
            throw new IllegalArgumentException(new StringBuilder(38).append("Invalid height for AdSize: ").append(n2).toString());
        }
        this.zzakh = n;
        this.zzaki = n2;
        this.zzakj = string2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof AdSize)) {
            return false;
        }
        object = (AdSize)object;
        if (this.zzakh != object.zzakh) return false;
        if (this.zzaki != object.zzaki) return false;
        if (this.zzakj.equals(object.zzakj)) return true;
        return false;
    }

    public int getHeight() {
        return this.zzaki;
    }

    public int getHeightInPixels(Context context) {
        switch (this.zzaki) {
            default: {
                return zzm.zzkr().zzb(context, this.zzaki);
            }
            case -2: {
                return AdSizeParcel.zzb(context.getResources().getDisplayMetrics());
            }
            case -4: 
            case -3: 
        }
        return -1;
    }

    public int getWidth() {
        return this.zzakh;
    }

    public int getWidthInPixels(Context context) {
        switch (this.zzakh) {
            default: {
                return zzm.zzkr().zzb(context, this.zzakh);
            }
            case -1: {
                return AdSizeParcel.zza(context.getResources().getDisplayMetrics());
            }
            case -4: 
            case -3: 
        }
        return -1;
    }

    public int hashCode() {
        return this.zzakj.hashCode();
    }

    public boolean isAutoHeight() {
        if (this.zzaki == -2) {
            return true;
        }
        return false;
    }

    public boolean isFluid() {
        if (this.zzakh == -3 && this.zzaki == -4) {
            return true;
        }
        return false;
    }

    public boolean isFullWidth() {
        if (this.zzakh == -1) {
            return true;
        }
        return false;
    }

    public String toString() {
        return this.zzakj;
    }
}

