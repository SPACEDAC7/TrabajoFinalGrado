/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 */
package com.google.android.gms.ads;

import android.content.Context;
import android.support.annotation.RequiresPermission;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.client.zzad;
import com.google.android.gms.ads.internal.client.zzae;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.purchase.InAppPurchaseListener;
import com.google.android.gms.ads.purchase.PlayStorePurchaseListener;

class BaseAdView
extends ViewGroup {
    protected final zzae zzakk;

    public BaseAdView(Context context, int n) {
        super(context);
        this.zzakk = new zzae(this, n);
    }

    public BaseAdView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet);
        this.zzakk = new zzae(this, attributeSet, false, n);
    }

    public BaseAdView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n);
        this.zzakk = new zzae(this, attributeSet, false, n2);
    }

    public void destroy() {
        this.zzakk.destroy();
    }

    public AdListener getAdListener() {
        return this.zzakk.getAdListener();
    }

    public AdSize getAdSize() {
        return this.zzakk.getAdSize();
    }

    public String getAdUnitId() {
        return this.zzakk.getAdUnitId();
    }

    public InAppPurchaseListener getInAppPurchaseListener() {
        return this.zzakk.getInAppPurchaseListener();
    }

    public String getMediationAdapterClassName() {
        return this.zzakk.getMediationAdapterClassName();
    }

    public boolean isLoading() {
        return this.zzakk.isLoading();
    }

    @RequiresPermission(value="android.permission.INTERNET")
    public void loadAd(AdRequest adRequest) {
        this.zzakk.zza(adRequest.zzdt());
    }

    protected void onLayout(boolean bl, int n, int n2, int n3, int n4) {
        View view = this.getChildAt(0);
        if (view != null && view.getVisibility() != 8) {
            int n5 = view.getMeasuredWidth();
            int n6 = view.getMeasuredHeight();
            n = (n3 - n - n5) / 2;
            n2 = (n4 - n2 - n6) / 2;
            view.layout(n, n2, n5 + n, n6 + n2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onMeasure(int n, int n2) {
        int n3;
        int n4 = 0;
        Object object = this.getChildAt(0);
        if (object != null && object.getVisibility() != 8) {
            this.measureChild((View)object, n, n2);
            n3 = object.getMeasuredWidth();
            n4 = object.getMeasuredHeight();
        } else {
            try {
                object = this.getAdSize();
            }
            catch (NullPointerException var5_5) {
                zzb.zzb("Unable to retrieve ad size.", var5_5);
                object = null;
            }
            if (object != null) {
                Context context = this.getContext();
                n3 = object.getWidthInPixels(context);
                n4 = object.getHeightInPixels(context);
            } else {
                n3 = 0;
            }
        }
        n3 = Math.max(n3, this.getSuggestedMinimumWidth());
        n4 = Math.max(n4, this.getSuggestedMinimumHeight());
        this.setMeasuredDimension(View.resolveSize((int)n3, (int)n), View.resolveSize((int)n4, (int)n2));
    }

    public void pause() {
        this.zzakk.pause();
    }

    public void resume() {
        this.zzakk.resume();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setAdListener(AdListener adListener) {
        this.zzakk.setAdListener(adListener);
        if (adListener != null && adListener instanceof zza) {
            this.zzakk.zza((zza)((Object)adListener));
            return;
        } else {
            if (adListener != null) return;
            {
                this.zzakk.zza((zza)null);
                return;
            }
        }
    }

    public void setAdSize(AdSize adSize) {
        this.zzakk.setAdSizes(adSize);
    }

    public void setAdUnitId(String string2) {
        this.zzakk.setAdUnitId(string2);
    }

    public void setInAppPurchaseListener(InAppPurchaseListener inAppPurchaseListener) {
        this.zzakk.setInAppPurchaseListener(inAppPurchaseListener);
    }

    public void setPlayStorePurchaseParams(PlayStorePurchaseListener playStorePurchaseListener, String string2) {
        this.zzakk.setPlayStorePurchaseParams(playStorePurchaseListener, string2);
    }
}

