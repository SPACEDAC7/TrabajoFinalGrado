/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.google.android.gms.ads;

import android.content.Context;
import android.support.annotation.RequiresPermission;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.client.zzad;
import com.google.android.gms.ads.internal.client.zzaf;
import com.google.android.gms.ads.purchase.InAppPurchaseListener;
import com.google.android.gms.ads.purchase.PlayStorePurchaseListener;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;

public final class InterstitialAd {
    private final zzaf zzakm;

    public InterstitialAd(Context context) {
        this.zzakm = new zzaf(context);
    }

    public AdListener getAdListener() {
        return this.zzakm.getAdListener();
    }

    public String getAdUnitId() {
        return this.zzakm.getAdUnitId();
    }

    public InAppPurchaseListener getInAppPurchaseListener() {
        return this.zzakm.getInAppPurchaseListener();
    }

    public String getMediationAdapterClassName() {
        return this.zzakm.getMediationAdapterClassName();
    }

    public boolean isLoaded() {
        return this.zzakm.isLoaded();
    }

    public boolean isLoading() {
        return this.zzakm.isLoading();
    }

    @RequiresPermission(value="android.permission.INTERNET")
    public void loadAd(AdRequest adRequest) {
        this.zzakm.zza(adRequest.zzdt());
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setAdListener(AdListener adListener) {
        this.zzakm.setAdListener(adListener);
        if (adListener != null && adListener instanceof zza) {
            this.zzakm.zza((zza)((Object)adListener));
            return;
        } else {
            if (adListener != null) return;
            {
                this.zzakm.zza((zza)null);
                return;
            }
        }
    }

    public void setAdUnitId(String string2) {
        this.zzakm.setAdUnitId(string2);
    }

    public void setInAppPurchaseListener(InAppPurchaseListener inAppPurchaseListener) {
        this.zzakm.setInAppPurchaseListener(inAppPurchaseListener);
    }

    public void setPlayStorePurchaseParams(PlayStorePurchaseListener playStorePurchaseListener, String string2) {
        this.zzakm.setPlayStorePurchaseParams(playStorePurchaseListener, string2);
    }

    public void setRewardedVideoAdListener(RewardedVideoAdListener rewardedVideoAdListener) {
        this.zzakm.setRewardedVideoAdListener(rewardedVideoAdListener);
    }

    public void show() {
        this.zzakm.show();
    }

    public void zzd(boolean bl) {
        this.zzakm.zzd(bl);
    }
}

