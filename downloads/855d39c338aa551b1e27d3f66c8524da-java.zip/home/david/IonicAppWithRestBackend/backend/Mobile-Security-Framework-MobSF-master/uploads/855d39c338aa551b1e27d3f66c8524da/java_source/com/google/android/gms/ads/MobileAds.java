/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.google.android.gms.ads;

import android.content.Context;
import android.support.annotation.RequiresPermission;
import com.google.android.gms.ads.internal.client.zzag;
import com.google.android.gms.ads.internal.client.zzah;
import com.google.android.gms.ads.reward.RewardedVideoAd;

public class MobileAds {
    private MobileAds() {
    }

    public static RewardedVideoAd getRewardedVideoAdInstance(Context context) {
        return zzag.zzli().getRewardedVideoAdInstance(context);
    }

    public static void initialize(Context context) {
        MobileAds.initialize(context, null, null);
    }

    @RequiresPermission(value="android.permission.INTERNET")
    public static void initialize(Context context, String string2) {
        MobileAds.initialize(context, string2, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Deprecated
    @RequiresPermission(value="android.permission.INTERNET")
    public static void initialize(Context context, String string2, Settings object) {
        zzag zzag2 = zzag.zzli();
        object = object == null ? null : object.zzdv();
        zzag2.zza(context, string2, (zzah)object);
    }

    public static void openDebugMenu(Context context, String string2) {
        zzag.zzli().openDebugMenu(context, string2);
    }

    public static void setAppMuted(boolean bl) {
        zzag.zzli().setAppMuted(bl);
    }

    public static void setAppVolume(float f) {
        zzag.zzli().setAppVolume(f);
    }

    public static final class Settings {
        private final zzah zzakn = new zzah();

        @Deprecated
        public String getTrackingId() {
            zzah zzah2 = this.zzakn;
            return null;
        }

        @Deprecated
        public boolean isGoogleAnalyticsEnabled() {
            zzah zzah2 = this.zzakn;
            return false;
        }

        @Deprecated
        public Settings setGoogleAnalyticsEnabled(boolean bl) {
            this.zzakn.zzq(bl);
            return this;
        }

        @Deprecated
        public Settings setTrackingId(String string2) {
            this.zzakn.zzav(string2);
            return this;
        }

        zzah zzdv() {
            return this.zzakn;
        }
    }

}

