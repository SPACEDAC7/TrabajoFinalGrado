/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.RemoteException
 */
package com.google.android.gms.ads;

import android.os.RemoteException;
import android.support.annotation.Nullable;
import com.google.android.gms.ads.internal.client.zzab;
import com.google.android.gms.ads.internal.client.zzac;
import com.google.android.gms.ads.internal.client.zzap;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzji;

@zzji
public final class VideoController {
    private final Object zzako = new Object();
    @Nullable
    private zzab zzakp;
    @Nullable
    private VideoLifecycleCallbacks zzakq;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public float getAspectRatio() {
        Object object = this.zzako;
        synchronized (object) {
            if (this.zzakp == null) {
                return 0.0f;
            }
            try {
                return this.zzakp.getAspectRatio();
            }
            catch (RemoteException var3_3) {
                zzb.zzb("Unable to call getAspectRatio on video controller.", (Throwable)var3_3);
                return 0.0f;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Nullable
    public VideoLifecycleCallbacks getVideoLifecycleCallbacks() {
        Object object = this.zzako;
        synchronized (object) {
            return this.zzakq;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean hasVideoContent() {
        Object object = this.zzako;
        synchronized (object) {
            if (this.zzakp == null) return false;
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setVideoLifecycleCallbacks(VideoLifecycleCallbacks videoLifecycleCallbacks) {
        zzaa.zzb(videoLifecycleCallbacks, (Object)"VideoLifecycleCallbacks may not be null.");
        Object object = this.zzako;
        synchronized (object) {
            this.zzakq = videoLifecycleCallbacks;
            if (this.zzakp == null) {
                return;
            }
            try {
                this.zzakp.zza(new zzap(videoLifecycleCallbacks));
            }
            catch (RemoteException var1_2) {
                zzb.zzb("Unable to call setVideoLifecycleCallbacks on video controller.", (Throwable)var1_2);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zza(zzab zzab2) {
        Object object = this.zzako;
        synchronized (object) {
            this.zzakp = zzab2;
            if (this.zzakq != null) {
                this.setVideoLifecycleCallbacks(this.zzakq);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public zzab zzdw() {
        Object object = this.zzako;
        synchronized (object) {
            return this.zzakp;
        }
    }

    public static abstract class VideoLifecycleCallbacks {
        public void onVideoEnd() {
        }
    }

}

