/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.google.android.gms.ads.doubleclick;

import android.view.View;

public interface CustomRenderedAd {
    public String getBaseUrl();

    public String getContent();

    public void onAdRendered(View var1);

    public void recordClick();

    public void recordImpression();
}

