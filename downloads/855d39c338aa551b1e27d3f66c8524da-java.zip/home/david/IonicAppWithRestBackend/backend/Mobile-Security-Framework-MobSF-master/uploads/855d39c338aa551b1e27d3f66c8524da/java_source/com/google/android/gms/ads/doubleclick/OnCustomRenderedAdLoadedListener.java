/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.doubleclick;

import com.google.android.gms.ads.doubleclick.CustomRenderedAd;

public interface OnCustomRenderedAdLoadedListener {
    public void onCustomRenderedAdLoaded(CustomRenderedAd var1);
}

