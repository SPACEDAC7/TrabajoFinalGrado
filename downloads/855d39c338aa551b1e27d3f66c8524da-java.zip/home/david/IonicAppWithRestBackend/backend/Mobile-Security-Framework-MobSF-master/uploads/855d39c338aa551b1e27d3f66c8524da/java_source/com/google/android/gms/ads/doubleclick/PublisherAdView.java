/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 */
package com.google.android.gms.ads.doubleclick;

import android.content.Context;
import android.support.annotation.RequiresPermission;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.Correlator;
import com.google.android.gms.ads.doubleclick.AppEventListener;
import com.google.android.gms.ads.doubleclick.OnCustomRenderedAdLoadedListener;
import com.google.android.gms.ads.doubleclick.PublisherAdRequest;
import com.google.android.gms.ads.internal.client.zzad;
import com.google.android.gms.ads.internal.client.zzae;
import com.google.android.gms.ads.internal.util.client.zzb;

public final class PublisherAdView
extends ViewGroup {
    private final zzae zzakk;

    public PublisherAdView(Context context) {
        super(context);
        this.zzakk = new zzae(this);
    }

    public PublisherAdView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.zzakk = new zzae(this, attributeSet, true);
    }

    public PublisherAdView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.zzakk = new zzae(this, attributeSet, true);
    }

    public void destroy() {
        this.zzakk.destroy();
    }

    public AdListener getAdListener() {
        return this.zzakk.getAdListener();
    }

    public AdSize getAdSize() {
        return this.zzakk.getAdSize();
    }

    public AdSize[] getAdSizes() {
        return this.zzakk.getAdSizes();
    }

    public String getAdUnitId() {
        return this.zzakk.getAdUnitId();
    }

    public AppEventListener getAppEventListener() {
        return this.zzakk.getAppEventListener();
    }

    public String getMediationAdapterClassName() {
        return this.zzakk.getMediationAdapterClassName();
    }

    public OnCustomRenderedAdLoadedListener getOnCustomRenderedAdLoadedListener() {
        return this.zzakk.getOnCustomRenderedAdLoadedListener();
    }

    public boolean isLoading() {
        return this.zzakk.isLoading();
    }

    @RequiresPermission(value="android.permission.INTERNET")
    public void loadAd(PublisherAdRequest publisherAdRequest) {
        this.zzakk.zza(publisherAdRequest.zzdt());
    }

    protected void onLayout(boolean bl, int n, int n2, int n3, int n4) {
        View view = this.getChildAt(0);
        if (view != null && view.getVisibility() != 8) {
            int n5 = view.getMeasuredWidth();
            int n6 = view.getMeasuredHeight();
            n = (n3 - n - n5) / 2;
            n2 = (n4 - n2 - n6) / 2;
            view.layout(n, n2, n5 + n, n6 + n2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onMeasure(int n, int n2) {
        int n3;
        int n4 = 0;
        Object object = this.getChildAt(0);
        if (object != null && object.getVisibility() != 8) {
            this.measureChild((View)object, n, n2);
            n3 = object.getMeasuredWidth();
            n4 = object.getMeasuredHeight();
        } else {
            try {
                object = this.getAdSize();
            }
            catch (NullPointerException var5_5) {
                zzb.zzb("Unable to retrieve ad size.", var5_5);
                object = null;
            }
            if (object != null) {
                Context context = this.getContext();
                n3 = object.getWidthInPixels(context);
                n4 = object.getHeightInPixels(context);
            } else {
                n3 = 0;
            }
        }
        n3 = Math.max(n3, this.getSuggestedMinimumWidth());
        n4 = Math.max(n4, this.getSuggestedMinimumHeight());
        this.setMeasuredDimension(View.resolveSize((int)n3, (int)n), View.resolveSize((int)n4, (int)n2));
    }

    public void pause() {
        this.zzakk.pause();
    }

    public void recordManualImpression() {
        this.zzakk.recordManualImpression();
    }

    public void resume() {
        this.zzakk.resume();
    }

    public void setAdListener(AdListener adListener) {
        this.zzakk.setAdListener(adListener);
    }

    public /* varargs */ void setAdSizes(AdSize ... arradSize) {
        if (arradSize == null || arradSize.length < 1) {
            throw new IllegalArgumentException("The supported ad sizes must contain at least one valid ad size.");
        }
        this.zzakk.zza(arradSize);
    }

    public void setAdUnitId(String string2) {
        this.zzakk.setAdUnitId(string2);
    }

    public void setAppEventListener(AppEventListener appEventListener) {
        this.zzakk.setAppEventListener(appEventListener);
    }

    public void setCorrelator(Correlator correlator) {
        this.zzakk.setCorrelator(correlator);
    }

    public void setManualImpressionsEnabled(boolean bl) {
        this.zzakk.setManualImpressionsEnabled(bl);
    }

    public void setOnCustomRenderedAdLoadedListener(OnCustomRenderedAdLoadedListener onCustomRenderedAdLoadedListener) {
        this.zzakk.setOnCustomRenderedAdLoadedListener(onCustomRenderedAdLoadedListener);
    }
}

