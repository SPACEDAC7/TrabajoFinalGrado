/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.os.RemoteException
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 */
package com.google.android.gms.ads.formats;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.google.android.gms.ads.formats.NativeAd;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.internal.zzei;

public abstract class NativeAdView
extends FrameLayout {
    private final FrameLayout zzald;
    private final zzei zzale;

    public NativeAdView(Context context) {
        super(context);
        this.zzald = this.zzd(context);
        this.zzale = this.zzdz();
    }

    public NativeAdView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.zzald = this.zzd(context);
        this.zzale = this.zzdz();
    }

    public NativeAdView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.zzald = this.zzd(context);
        this.zzale = this.zzdz();
    }

    @TargetApi(value=21)
    public NativeAdView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.zzald = this.zzd(context);
        this.zzale = this.zzdz();
    }

    private FrameLayout zzd(Context context) {
        context = this.zze(context);
        context.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
        this.addView((View)context);
        return context;
    }

    private zzei zzdz() {
        zzaa.zzb(this.zzald, (Object)"createDelegate must be called after mOverlayFrame has been created");
        return zzm.zzks().zza(this.zzald.getContext(), this, this.zzald);
    }

    public void addView(View view, int n, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, n, layoutParams);
        super.bringChildToFront((View)this.zzald);
    }

    public void bringChildToFront(View view) {
        super.bringChildToFront(view);
        if (this.zzald != view) {
            super.bringChildToFront((View)this.zzald);
        }
    }

    public void destroy() {
        try {
            this.zzale.destroy();
            return;
        }
        catch (RemoteException var1_1) {
            zzb.zzb("Unable to destroy native ad view", (Throwable)var1_1);
            return;
        }
    }

    public void removeAllViews() {
        super.removeAllViews();
        super.addView((View)this.zzald);
    }

    public void removeView(View view) {
        if (this.zzald == view) {
            return;
        }
        super.removeView(view);
    }

    public void setNativeAd(NativeAd nativeAd) {
        try {
            this.zzale.zze((zzd)nativeAd.zzdy());
            return;
        }
        catch (RemoteException var1_2) {
            zzb.zzb("Unable to call setNativeAd on delegate", (Throwable)var1_2);
            return;
        }
    }

    protected void zza(String string2, View view) {
        try {
            this.zzale.zzc(string2, zze.zzac(view));
            return;
        }
        catch (RemoteException var1_2) {
            zzb.zzb("Unable to call setAssetView on delegate", (Throwable)var1_2);
            return;
        }
    }

    FrameLayout zze(Context context) {
        return new FrameLayout(context);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected View zzu(String object) {
        object = this.zzale.zzaw((String)object);
        if (object == null) return null;
        try {
            return (View)zze.zzae((zzd)object);
        }
        catch (RemoteException var1_2) {
            zzb.zzb("Unable to call getAssetView on delegate", (Throwable)var1_2);
        }
        return null;
    }
}

