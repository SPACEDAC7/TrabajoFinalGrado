/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.google.android.gms.ads.identifier;

import android.support.annotation.WorkerThread;
import android.util.Log;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class zza {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @WorkerThread
    public void zzv(String var1_1) {
        block8 : {
            var3_2 = (HttpURLConnection)new URL(var1_1).openConnection();
            var2_7 = var3_2.getResponseCode();
            if (var2_7 >= 200 && var2_7 < 300) break block8;
            Log.w((String)"HttpUrlPinger", (String)new StringBuilder(String.valueOf(var1_1).length() + 65).append("Received non-success response code ").append(var2_7).append(" from pinging URL: ").append(var1_1).toString());
            {
                catch (Throwable var4_8) {
                    var3_2.disconnect();
                    throw var4_8;
                }
            }
        }
        try {
            var3_2.disconnect();
            return;
        }
        catch (IndexOutOfBoundsException var3_3) {
            var4_9 = String.valueOf(var3_3.getMessage());
            Log.w((String)"HttpUrlPinger", (String)new StringBuilder(String.valueOf(var1_1).length() + 32 + String.valueOf(var4_9).length()).append("Error while parsing ping URL: ").append(var1_1).append(". ").append(var4_9).toString(), (Throwable)var3_3);
            return;
        }
        catch (RuntimeException var3_4) {}
        ** GOTO lbl-1000
        catch (IOException var3_6) {}
lbl-1000: // 2 sources:
        {
            var4_10 = String.valueOf(var3_5.getMessage());
            Log.w((String)"HttpUrlPinger", (String)new StringBuilder(String.valueOf(var1_1).length() + 27 + String.valueOf(var4_10).length()).append("Error while pinging URL: ").append(var1_1).append(". ").append(var4_10).toString(), (Throwable)var3_5);
            return;
        }
    }
}

