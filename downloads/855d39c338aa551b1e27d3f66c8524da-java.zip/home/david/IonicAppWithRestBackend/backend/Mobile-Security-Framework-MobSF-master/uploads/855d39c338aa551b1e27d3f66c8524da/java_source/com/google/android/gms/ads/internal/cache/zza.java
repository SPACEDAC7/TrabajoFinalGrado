/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Binder
 *  android.os.Bundle
 *  android.os.DeadObjectException
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.RemoteException
 */
package com.google.android.gms.ads.internal.cache;

import android.content.Context;
import android.os.Binder;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.google.android.gms.ads.internal.cache.CacheEntryParcel;
import com.google.android.gms.ads.internal.cache.CacheOffering;
import com.google.android.gms.ads.internal.cache.zzc;
import com.google.android.gms.ads.internal.cache.zzf;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.zze;
import com.google.android.gms.internal.zzcz;
import com.google.android.gms.internal.zzdn;
import com.google.android.gms.internal.zzdr;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;
import com.google.android.gms.internal.zzlb;

@zzji
public class zza {
    @Nullable
    private Context mContext;
    private final Object zzako;
    private final Runnable zzaxy;
    @Nullable
    private zzc zzaxz;
    @Nullable
    private zzf zzaya;

    public zza() {
        this.zzaxy = new Runnable(){

            @Override
            public void run() {
                zza.this.disconnect();
            }
        };
        this.zzako = new Object();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void connect() {
        Object object = this.zzako;
        synchronized (object) {
            if (this.mContext != null && this.zzaxz == null) {
                this.zzaxz = this.zza(new zze.zzb(){

                    /*
                     * Enabled aggressive block sorting
                     * Enabled unnecessary exception pruning
                     * Enabled aggressive exception aggregation
                     */
                    @Override
                    public void onConnected(@Nullable Bundle object) {
                        object = zza.this.zzako;
                        synchronized (object) {
                            try {
                                zza.this.zzaya = zza.this.zzaxz.zzjz();
                            }
                            catch (DeadObjectException var2_2) {
                                zzkx.zzb("Unable to obtain a cache service instance.", (Throwable)var2_2);
                                zza.this.disconnect();
                            }
                            zza.this.zzako.notifyAll();
                            return;
                        }
                    }

                    /*
                     * Enabled aggressive block sorting
                     * Enabled unnecessary exception pruning
                     * Enabled aggressive exception aggregation
                     */
                    @Override
                    public void onConnectionSuspended(int n) {
                        Object object = zza.this.zzako;
                        synchronized (object) {
                            zza.this.zzaxz = null;
                            zza.this.zzaya = null;
                            zza.this.zzako.notifyAll();
                            zzu.zzhc().zzwk();
                            return;
                        }
                    }
                }, new zze.zzc(){

                    /*
                     * Enabled aggressive block sorting
                     * Enabled unnecessary exception pruning
                     * Enabled aggressive exception aggregation
                     */
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult object) {
                        object = zza.this.zzako;
                        synchronized (object) {
                            zza.this.zzaxz = null;
                            zza.this.zzaya = null;
                            zza.this.zzako.notifyAll();
                            zzu.zzhc().zzwk();
                            return;
                        }
                    }
                });
                this.zzaxz.zzavd();
                return;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void disconnect() {
        Object object = this.zzako;
        synchronized (object) {
            if (this.zzaxz == null) {
                return;
            }
            if (this.zzaxz.isConnected() || this.zzaxz.isConnecting()) {
                this.zzaxz.disconnect();
            }
            this.zzaxz = null;
            this.zzaya = null;
            Binder.flushPendingCommands();
            zzu.zzhc().zzwk();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void initialize(Context context) {
        if (context == null) {
            return;
        }
        Object object = this.zzako;
        synchronized (object) {
            if (this.mContext != null) {
                return;
            }
            this.mContext = context.getApplicationContext();
            if (zzdr.zzbkr.get().booleanValue()) {
                this.connect();
            } else if (zzdr.zzbkq.get().booleanValue()) {
                this.zza(new zzcz.zzb(){

                    @Override
                    public void zzk(boolean bl) {
                        if (bl) {
                            zza.this.connect();
                            return;
                        }
                        zza.this.disconnect();
                    }
                });
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public CacheEntryParcel zza(CacheOffering abstractSafeParcelable) {
        Object object = this.zzako;
        synchronized (object) {
            if (this.zzaya == null) {
                return new CacheEntryParcel();
            }
            try {
                return this.zzaya.zza((CacheOffering)abstractSafeParcelable);
            }
            catch (RemoteException var1_2) {
                zzkx.zzb("Unable to call into cache service.", (Throwable)var1_2);
                return new CacheEntryParcel();
            }
        }
    }

    protected zzc zza(zze.zzb zzb2, zze.zzc zzc2) {
        return new zzc(this.mContext, zzu.zzhc().zzwj(), zzb2, zzc2);
    }

    protected void zza(zzcz.zzb zzb2) {
        zzu.zzgp().zza(zzb2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zzjt() {
        if (zzdr.zzbks.get().booleanValue()) {
            Object object = this.zzako;
            synchronized (object) {
                this.connect();
                zzu.zzgm();
                zzlb.zzcvl.removeCallbacks(this.zzaxy);
                zzu.zzgm();
                zzlb.zzcvl.postDelayed(this.zzaxy, zzdr.zzbkt.get().longValue());
                return;
            }
        }
    }

}

