/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.cache;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.cache.CacheOffering;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzd
implements Parcelable.Creator<CacheOffering> {
    static void zza(CacheOffering cacheOffering, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, cacheOffering.version);
        zzb.zza(parcel, 2, cacheOffering.url, false);
        zzb.zza(parcel, 3, cacheOffering.zzayd);
        zzb.zza(parcel, 4, cacheOffering.zzaye, false);
        zzb.zza(parcel, 5, cacheOffering.zzayf, false);
        zzb.zza(parcel, 6, cacheOffering.zzayg, false);
        zzb.zza(parcel, 7, cacheOffering.zzayh, false);
        zzb.zza(parcel, 8, cacheOffering.zzayi);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzd(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzu(n);
    }

    public CacheOffering zzd(Parcel parcel) {
        boolean bl = false;
        Bundle bundle = null;
        int n = zza.zzcr(parcel);
        long l = 0;
        String string2 = null;
        String string3 = null;
        String string4 = null;
        String string5 = null;
        int n2 = 0;
        block10 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block10;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block10;
                }
                case 2: {
                    string5 = zza.zzq(parcel, n3);
                    continue block10;
                }
                case 3: {
                    l = zza.zzi(parcel, n3);
                    continue block10;
                }
                case 4: {
                    string4 = zza.zzq(parcel, n3);
                    continue block10;
                }
                case 5: {
                    string3 = zza.zzq(parcel, n3);
                    continue block10;
                }
                case 6: {
                    string2 = zza.zzq(parcel, n3);
                    continue block10;
                }
                case 7: {
                    bundle = zza.zzs(parcel, n3);
                    continue block10;
                }
                case 8: 
            }
            bl = zza.zzc(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new CacheOffering(n2, string5, l, string4, string3, string2, bundle, bl);
    }

    public CacheOffering[] zzu(int n) {
        return new CacheOffering[n];
    }
}

