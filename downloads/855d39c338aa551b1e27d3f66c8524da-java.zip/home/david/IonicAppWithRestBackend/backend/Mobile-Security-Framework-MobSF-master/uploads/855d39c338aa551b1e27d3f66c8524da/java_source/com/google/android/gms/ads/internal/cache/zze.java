/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  org.json.JSONObject
 */
package com.google.android.gms.ads.internal.cache;

import android.content.Context;
import org.json.JSONObject;

public interface zze {
    public JSONObject zzi(Context var1);
}

