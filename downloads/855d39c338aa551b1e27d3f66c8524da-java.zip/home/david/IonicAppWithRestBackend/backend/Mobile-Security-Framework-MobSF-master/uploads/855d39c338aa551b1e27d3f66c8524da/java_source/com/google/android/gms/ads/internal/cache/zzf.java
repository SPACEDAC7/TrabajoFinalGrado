/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.ads.internal.cache;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.cache.CacheEntryParcel;
import com.google.android.gms.ads.internal.cache.CacheOffering;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public interface zzf
extends IInterface {
    public CacheEntryParcel zza(CacheOffering var1) throws RemoteException;

    public static abstract class com.google.android.gms.ads.internal.cache.zzf$zza
    extends Binder
    implements zzf {
        public static zzf zzi(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.cache.ICacheService");
            if (iInterface != null && iInterface instanceof zzf) {
                return (zzf)iInterface;
            }
            return new zza(iBinder);
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean onTransact(int n, Parcel object, Parcel parcel, int n2) throws RemoteException {
            switch (n) {
                default: {
                    return super.onTransact(n, (Parcel)object, parcel, n2);
                }
                case 1598968902: {
                    parcel.writeString("com.google.android.gms.ads.internal.cache.ICacheService");
                    return true;
                }
                case 1: 
            }
            object.enforceInterface("com.google.android.gms.ads.internal.cache.ICacheService");
            object = object.readInt() != 0 ? (CacheOffering)CacheOffering.CREATOR.createFromParcel((Parcel)object) : null;
            object = this.zza((CacheOffering)object);
            parcel.writeNoException();
            if (object != null) {
                parcel.writeInt(1);
                object.writeToParcel(parcel, 1);
                return true;
            }
            parcel.writeInt(0);
            return true;
        }

        private static class zza
        implements zzf {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public CacheEntryParcel zza(CacheOffering abstractSafeParcelable) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.cache.ICacheService");
                    if (abstractSafeParcelable != null) {
                        parcel.writeInt(1);
                        abstractSafeParcelable.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(1, parcel, parcel2, 0);
                    parcel2.readException();
                    abstractSafeParcelable = parcel2.readInt() != 0 ? (CacheEntryParcel)CacheEntryParcel.CREATOR.createFromParcel(parcel2) : null;
                    return abstractSafeParcelable;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

