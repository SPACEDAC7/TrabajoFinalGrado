/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.internal.client;

public interface zza {
    public void onAdClicked();
}

