/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.location.Location
 *  android.os.Bundle
 */
package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.admob.AdMobExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEvent;
import com.google.android.gms.ads.search.SearchAdRequest;
import com.google.android.gms.internal.zzji;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@zzji
public final class zzad {
    public static final String DEVICE_ID_EMULATOR = zzm.zzkr().zzdf("emulator");
    private final boolean zzamv;
    private final int zzazc;
    private final int zzazf;
    private final String zzazg;
    private final String zzazi;
    private final Bundle zzazk;
    private final String zzazm;
    private final boolean zzazo;
    private final Bundle zzbar;
    private final Map<Class<? extends NetworkExtras>, NetworkExtras> zzbas;
    private final SearchAdRequest zzbat;
    private final Set<String> zzbau;
    private final Set<String> zzbav;
    private final Date zzgr;
    private final Set<String> zzgt;
    private final Location zzgv;

    public zzad(zza zza2) {
        this(zza2, null);
    }

    public zzad(zza zza2, SearchAdRequest searchAdRequest) {
        this.zzgr = zza2.zzgr;
        this.zzazi = zza2.zzazi;
        this.zzazc = zza2.zzazc;
        this.zzgt = Collections.unmodifiableSet(zza2.zzbaw);
        this.zzgv = zza2.zzgv;
        this.zzamv = zza2.zzamv;
        this.zzbar = zza2.zzbar;
        this.zzbas = Collections.unmodifiableMap(zza2.zzbax);
        this.zzazg = zza2.zzazg;
        this.zzazm = zza2.zzazm;
        this.zzbat = searchAdRequest;
        this.zzazf = zza2.zzazf;
        this.zzbau = Collections.unmodifiableSet(zza2.zzbay);
        this.zzazk = zza2.zzazk;
        this.zzbav = Collections.unmodifiableSet(zza2.zzbaz);
        this.zzazo = zza2.zzazo;
    }

    public Date getBirthday() {
        return this.zzgr;
    }

    public String getContentUrl() {
        return this.zzazi;
    }

    public Bundle getCustomEventExtrasBundle(Class<? extends CustomEvent> class_) {
        Bundle bundle = this.zzbar.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter");
        if (bundle != null) {
            return bundle.getBundle(class_.getName());
        }
        return null;
    }

    public Bundle getCustomTargeting() {
        return this.zzazk;
    }

    public int getGender() {
        return this.zzazc;
    }

    public Set<String> getKeywords() {
        return this.zzgt;
    }

    public Location getLocation() {
        return this.zzgv;
    }

    public boolean getManualImpressionsEnabled() {
        return this.zzamv;
    }

    @Deprecated
    public <T extends NetworkExtras> T getNetworkExtras(Class<T> class_) {
        return (T)this.zzbas.get(class_);
    }

    public Bundle getNetworkExtrasBundle(Class<? extends MediationAdapter> class_) {
        return this.zzbar.getBundle(class_.getName());
    }

    public String getPublisherProvidedId() {
        return this.zzazg;
    }

    public boolean isDesignedForFamilies() {
        return this.zzazo;
    }

    public boolean isTestDevice(Context context) {
        return this.zzbau.contains(zzm.zzkr().zzao(context));
    }

    public String zzkz() {
        return this.zzazm;
    }

    public SearchAdRequest zzla() {
        return this.zzbat;
    }

    public Map<Class<? extends NetworkExtras>, NetworkExtras> zzlb() {
        return this.zzbas;
    }

    public Bundle zzlc() {
        return this.zzbar;
    }

    public int zzld() {
        return this.zzazf;
    }

    public Set<String> zzle() {
        return this.zzbav;
    }

    public static final class zza {
        private boolean zzamv = false;
        private int zzazc = -1;
        private int zzazf = -1;
        private String zzazg;
        private String zzazi;
        private final Bundle zzazk = new Bundle();
        private String zzazm;
        private boolean zzazo;
        private final Bundle zzbar = new Bundle();
        private final HashSet<String> zzbaw = new HashSet();
        private final HashMap<Class<? extends NetworkExtras>, NetworkExtras> zzbax = new HashMap();
        private final HashSet<String> zzbay = new HashSet();
        private final HashSet<String> zzbaz = new HashSet();
        private Date zzgr;
        private Location zzgv;

        public void setManualImpressionsEnabled(boolean bl) {
            this.zzamv = bl;
        }

        @Deprecated
        public void zza(NetworkExtras networkExtras) {
            if (networkExtras instanceof AdMobExtras) {
                this.zza(AdMobAdapter.class, ((AdMobExtras)networkExtras).getExtras());
                return;
            }
            this.zzbax.put(networkExtras.getClass(), networkExtras);
        }

        public void zza(Class<? extends MediationAdapter> class_, Bundle bundle) {
            this.zzbar.putBundle(class_.getName(), bundle);
        }

        public void zza(Date date) {
            this.zzgr = date;
        }

        public void zzam(String string2) {
            this.zzbaw.add(string2);
        }

        public void zzan(String string2) {
            this.zzbay.add(string2);
        }

        public void zzao(String string2) {
            this.zzbay.remove(string2);
        }

        public void zzap(String string2) {
            this.zzazi = string2;
        }

        public void zzaq(String string2) {
            this.zzazg = string2;
        }

        public void zzar(String string2) {
            this.zzazm = string2;
        }

        public void zzas(String string2) {
            this.zzbaz.add(string2);
        }

        public void zzb(Location location) {
            this.zzgv = location;
        }

        public void zzb(Class<? extends CustomEvent> class_, Bundle bundle) {
            if (this.zzbar.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter") == null) {
                this.zzbar.putBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter", new Bundle());
            }
            this.zzbar.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter").putBundle(class_.getName(), bundle);
        }

        public void zze(String string2, String string3) {
            this.zzazk.putString(string2, string3);
        }

        /*
         * Enabled aggressive block sorting
         */
        public void zzo(boolean bl) {
            int n = bl ? 1 : 0;
            this.zzazf = n;
        }

        public void zzp(boolean bl) {
            this.zzazo = bl;
        }

        public void zzx(int n) {
            this.zzazc = n;
        }
    }

}

