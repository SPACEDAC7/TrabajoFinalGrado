/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.RemoteException
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 */
package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.Correlator;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.doubleclick.AppEventListener;
import com.google.android.gms.ads.doubleclick.OnCustomRenderedAdLoadedListener;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.VideoOptionsParcel;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.client.zzab;
import com.google.android.gms.ads.internal.client.zzad;
import com.google.android.gms.ads.internal.client.zzb;
import com.google.android.gms.ads.internal.client.zzc;
import com.google.android.gms.ads.internal.client.zzh;
import com.google.android.gms.ads.internal.client.zzj;
import com.google.android.gms.ads.internal.client.zzk;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.client.zzn;
import com.google.android.gms.ads.internal.client.zzo;
import com.google.android.gms.ads.internal.client.zzp;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.client.zzu;
import com.google.android.gms.ads.internal.client.zzw;
import com.google.android.gms.ads.internal.client.zzy;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.purchase.InAppPurchaseListener;
import com.google.android.gms.ads.purchase.PlayStorePurchaseListener;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.internal.zzed;
import com.google.android.gms.internal.zzee;
import com.google.android.gms.internal.zzgy;
import com.google.android.gms.internal.zzgz;
import com.google.android.gms.internal.zzig;
import com.google.android.gms.internal.zzik;
import com.google.android.gms.internal.zzil;
import com.google.android.gms.internal.zzip;
import com.google.android.gms.internal.zzji;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

@zzji
public class zzae {
    private final zzh zzakc;
    private VideoOptions zzalc;
    private boolean zzamv;
    private String zzant;
    private zza zzayj;
    private AdListener zzayk;
    private AppEventListener zzazw;
    private AdSize[] zzazx;
    private final zzgy zzbba = new zzgy();
    private final AtomicBoolean zzbbb;
    private final VideoController zzbbc = new VideoController();
    final zzo zzbbd;
    private Correlator zzbbe;
    private zzu zzbbf;
    private InAppPurchaseListener zzbbg;
    private OnCustomRenderedAdLoadedListener zzbbh;
    private PlayStorePurchaseListener zzbbi;
    private String zzbbj;
    private ViewGroup zzbbk;
    private int zzbbl;

    public zzae(ViewGroup viewGroup) {
        this(viewGroup, null, false, zzh.zzkb(), 0);
    }

    public zzae(ViewGroup viewGroup, int n) {
        this(viewGroup, null, false, zzh.zzkb(), n);
    }

    public zzae(ViewGroup viewGroup, AttributeSet attributeSet, boolean bl) {
        this(viewGroup, attributeSet, bl, zzh.zzkb(), 0);
    }

    public zzae(ViewGroup viewGroup, AttributeSet attributeSet, boolean bl, int n) {
        this(viewGroup, attributeSet, bl, zzh.zzkb(), n);
    }

    zzae(ViewGroup viewGroup, AttributeSet attributeSet, boolean bl, zzh zzh2, int n) {
        this(viewGroup, attributeSet, bl, zzh2, null, n);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    zzae(ViewGroup viewGroup, AttributeSet object, boolean bl, zzh zzh2, zzu zzu2, int n) {
        this.zzbbd = new zzo(){

            @Override
            public void onAdFailedToLoad(int n) {
                zzae.this.zzbbc.zza(zzae.this.zzdw());
                super.onAdFailedToLoad(n);
            }

            @Override
            public void onAdLoaded() {
                zzae.this.zzbbc.zza(zzae.this.zzdw());
                super.onAdLoaded();
            }
        };
        this.zzbbk = viewGroup;
        this.zzakc = zzh2;
        this.zzbbf = zzu2;
        this.zzbbb = new AtomicBoolean(false);
        this.zzbbl = n;
        if (object == null) return;
        zzh2 = viewGroup.getContext();
        try {
            object = new zzk((Context)zzh2, (AttributeSet)object);
            this.zzazx = object.zzm(bl);
            this.zzant = object.getAdUnitId();
        }
        catch (IllegalArgumentException illegalArgumentException) {
            zzm.zzkr().zza(viewGroup, new AdSizeParcel((Context)zzh2, AdSize.BANNER), illegalArgumentException.getMessage(), illegalArgumentException.getMessage());
            return;
        }
        if (!viewGroup.isInEditMode()) return;
        zzm.zzkr().zza(viewGroup, zzae.zza((Context)zzh2, this.zzazx[0], this.zzbbl), "Ads by Google");
    }

    private static AdSizeParcel zza(Context object, AdSize adSize, int n) {
        object = new AdSizeParcel((Context)object, adSize);
        object.zzl(zzae.zzy(n));
        return object;
    }

    private static AdSizeParcel zza(Context object, AdSize[] arradSize, int n) {
        object = new AdSizeParcel((Context)object, arradSize);
        object.zzl(zzae.zzy(n));
        return object;
    }

    private void zzlf() {
        zzd zzd2;
        block3 : {
            try {
                zzd2 = this.zzbbf.zzef();
                if (zzd2 != null) break block3;
                return;
            }
            catch (RemoteException var1_2) {
                com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to get an ad frame.", (Throwable)var1_2);
                return;
            }
        }
        this.zzbbk.addView((View)zze.zzae(zzd2));
    }

    private static boolean zzy(int n) {
        if (n == 1) {
            return true;
        }
        return false;
    }

    public void destroy() {
        try {
            if (this.zzbbf != null) {
                this.zzbbf.destroy();
            }
            return;
        }
        catch (RemoteException var1_1) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to destroy AdView.", (Throwable)var1_1);
            return;
        }
    }

    public AdListener getAdListener() {
        return this.zzayk;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public AdSize getAdSize() {
        try {
            Object object;
            if (this.zzbbf != null && (object = this.zzbbf.zzeg()) != null) {
                return object.zzkd();
            }
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to get the current AdSize.", (Throwable)var1_2);
        }
        if (this.zzazx == null) return null;
        return this.zzazx[0];
    }

    public AdSize[] getAdSizes() {
        return this.zzazx;
    }

    public String getAdUnitId() {
        return this.zzant;
    }

    public AppEventListener getAppEventListener() {
        return this.zzazw;
    }

    public InAppPurchaseListener getInAppPurchaseListener() {
        return this.zzbbg;
    }

    public String getMediationAdapterClassName() {
        try {
            if (this.zzbbf != null) {
                String string2 = this.zzbbf.getMediationAdapterClassName();
                return string2;
            }
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to get the mediation adapter class name.", (Throwable)var1_2);
        }
        return null;
    }

    public OnCustomRenderedAdLoadedListener getOnCustomRenderedAdLoadedListener() {
        return this.zzbbh;
    }

    public VideoController getVideoController() {
        return this.zzbbc;
    }

    public VideoOptions getVideoOptions() {
        return this.zzalc;
    }

    public boolean isLoading() {
        try {
            if (this.zzbbf != null) {
                boolean bl = this.zzbbf.isLoading();
                return bl;
            }
        }
        catch (RemoteException var2_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to check if ad is loading.", (Throwable)var2_2);
        }
        return false;
    }

    public void pause() {
        try {
            if (this.zzbbf != null) {
                this.zzbbf.pause();
            }
            return;
        }
        catch (RemoteException var1_1) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to call pause.", (Throwable)var1_1);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void recordManualImpression() {
        if (this.zzbbb.getAndSet(true)) {
            return;
        }
        try {
            if (this.zzbbf == null) return;
            this.zzbbf.zzei();
            return;
        }
        catch (RemoteException var1_1) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to record impression.", (Throwable)var1_1);
            return;
        }
    }

    public void resume() {
        try {
            if (this.zzbbf != null) {
                this.zzbbf.resume();
            }
            return;
        }
        catch (RemoteException var1_1) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to call resume.", (Throwable)var1_1);
            return;
        }
    }

    public void setAdListener(AdListener adListener) {
        this.zzayk = adListener;
        this.zzbbd.zza(adListener);
    }

    public /* varargs */ void setAdSizes(AdSize ... arradSize) {
        if (this.zzazx != null) {
            throw new IllegalStateException("The ad size can only be set once on AdView.");
        }
        this.zza(arradSize);
    }

    public void setAdUnitId(String string2) {
        if (this.zzant != null) {
            throw new IllegalStateException("The ad unit ID can only be set once on AdView.");
        }
        this.zzant = string2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setAppEventListener(AppEventListener object) {
        try {
            this.zzazw = object;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzj((AppEventListener)object) : null;
                zzu2.zza((zzw)object);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the AppEventListener.", (Throwable)var1_2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setCorrelator(Correlator object) {
        this.zzbbe = object;
        try {
            if (this.zzbbf == null) return;
            {
                zzu zzu2 = this.zzbbf;
                object = this.zzbbe == null ? null : this.zzbbe.zzdu();
                zzu2.zza((zzy)object);
                return;
            }
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set correlator.", (Throwable)var1_2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setInAppPurchaseListener(InAppPurchaseListener object) {
        if (this.zzbbi != null) {
            throw new IllegalStateException("Play store purchase parameter has already been set.");
        }
        try {
            this.zzbbg = object;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzil((InAppPurchaseListener)object) : null;
                zzu2.zza((zzig)object);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the InAppPurchaseListener.", (Throwable)var1_2);
            return;
        }
    }

    public void setManualImpressionsEnabled(boolean bl) {
        this.zzamv = bl;
        try {
            if (this.zzbbf != null) {
                this.zzbbf.setManualImpressionsEnabled(this.zzamv);
            }
            return;
        }
        catch (RemoteException var2_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set manual impressions.", (Throwable)var2_2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setOnCustomRenderedAdLoadedListener(OnCustomRenderedAdLoadedListener object) {
        this.zzbbh = object;
        try {
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzee((OnCustomRenderedAdLoadedListener)object) : null;
                zzu2.zza((zzed)object);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the onCustomRenderedAdLoadedListener.", (Throwable)var1_2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setPlayStorePurchaseParams(PlayStorePurchaseListener object, String string2) {
        if (this.zzbbg != null) {
            throw new IllegalStateException("InAppPurchaseListener has already been set.");
        }
        try {
            this.zzbbi = object;
            this.zzbbj = string2;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzip((PlayStorePurchaseListener)object) : null;
                zzu2.zza((zzik)object, string2);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the play store purchase parameter.", (Throwable)var1_2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setVideoOptions(VideoOptions object) {
        this.zzalc = object;
        try {
            if (this.zzbbf == null) return;
            {
                zzu zzu2 = this.zzbbf;
                object = object == null ? null : new VideoOptionsParcel((VideoOptions)object);
                zzu2.zza((VideoOptionsParcel)object);
                return;
            }
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set video options.", (Throwable)var1_2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zza(zza object) {
        try {
            this.zzayj = object;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzb((zza)object) : null;
                zzu2.zza((zzp)object);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the AdClickListener.", (Throwable)var1_2);
            return;
        }
    }

    public void zza(zzad zzad2) {
        try {
            if (this.zzbbf == null) {
                this.zzlg();
            }
            if (this.zzbbf.zzb(this.zzakc.zza(this.zzbbk.getContext(), zzad2))) {
                this.zzbba.zzi(zzad2.zzlb());
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to load ad.", (Throwable)var1_2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public /* varargs */ void zza(AdSize ... arradSize) {
        this.zzazx = arradSize;
        try {
            if (this.zzbbf != null) {
                this.zzbbf.zza(zzae.zza(this.zzbbk.getContext(), this.zzazx, this.zzbbl));
            }
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the ad size.", (Throwable)var1_2);
        }
        this.zzbbk.requestLayout();
    }

    public boolean zzb(AdSizeParcel adSizeParcel) {
        return "search_v2".equals(adSizeParcel.zzazq);
    }

    public zzab zzdw() {
        if (this.zzbbf == null) {
            return null;
        }
        try {
            zzab zzab2 = this.zzbbf.zzej();
            return zzab2;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to retrieve VideoController.", (Throwable)var1_2);
            return null;
        }
    }

    void zzlg() throws RemoteException {
        if ((this.zzazx == null || this.zzant == null) && this.zzbbf == null) {
            throw new IllegalStateException("The ad size and ad unit ID must be set before loadAd is called.");
        }
        this.zzbbf = this.zzlh();
        this.zzbbf.zza(new zzc(this.zzbbd));
        if (this.zzayj != null) {
            this.zzbbf.zza(new zzb(this.zzayj));
        }
        if (this.zzazw != null) {
            this.zzbbf.zza(new zzj(this.zzazw));
        }
        if (this.zzbbg != null) {
            this.zzbbf.zza(new zzil(this.zzbbg));
        }
        if (this.zzbbi != null) {
            this.zzbbf.zza(new zzip(this.zzbbi), this.zzbbj);
        }
        if (this.zzbbh != null) {
            this.zzbbf.zza(new zzee(this.zzbbh));
        }
        if (this.zzbbe != null) {
            this.zzbbf.zza(this.zzbbe.zzdu());
        }
        if (this.zzalc != null) {
            this.zzbbf.zza(new VideoOptionsParcel(this.zzalc));
        }
        this.zzbbf.setManualImpressionsEnabled(this.zzamv);
        this.zzlf();
    }

    protected zzu zzlh() throws RemoteException {
        Context context = this.zzbbk.getContext();
        AdSizeParcel adSizeParcel = zzae.zza(context, this.zzazx, this.zzbbl);
        if (this.zzb(adSizeParcel)) {
            return zzm.zzks().zza(context, adSizeParcel, this.zzant);
        }
        return zzm.zzks().zza(context, adSizeParcel, this.zzant, this.zzbba);
    }

}

