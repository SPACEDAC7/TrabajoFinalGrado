/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.RemoteException
 */
package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.Correlator;
import com.google.android.gms.ads.doubleclick.AppEventListener;
import com.google.android.gms.ads.doubleclick.OnCustomRenderedAdLoadedListener;
import com.google.android.gms.ads.doubleclick.PublisherInterstitialAd;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.client.zzad;
import com.google.android.gms.ads.internal.client.zzb;
import com.google.android.gms.ads.internal.client.zzc;
import com.google.android.gms.ads.internal.client.zzh;
import com.google.android.gms.ads.internal.client.zzj;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.client.zzn;
import com.google.android.gms.ads.internal.client.zzp;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.client.zzu;
import com.google.android.gms.ads.internal.client.zzw;
import com.google.android.gms.ads.internal.client.zzy;
import com.google.android.gms.ads.internal.reward.client.zzd;
import com.google.android.gms.ads.internal.reward.client.zzg;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.purchase.InAppPurchaseListener;
import com.google.android.gms.ads.purchase.PlayStorePurchaseListener;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.android.gms.internal.zzed;
import com.google.android.gms.internal.zzee;
import com.google.android.gms.internal.zzgy;
import com.google.android.gms.internal.zzgz;
import com.google.android.gms.internal.zzig;
import com.google.android.gms.internal.zzik;
import com.google.android.gms.internal.zzil;
import com.google.android.gms.internal.zzip;
import com.google.android.gms.internal.zzji;
import java.util.Map;

@zzji
public class zzaf {
    private final Context mContext;
    private final zzh zzakc;
    private String zzant;
    private zza zzayj;
    private AdListener zzayk;
    private AppEventListener zzazw;
    private final zzgy zzbba = new zzgy();
    private Correlator zzbbe;
    private zzu zzbbf;
    private InAppPurchaseListener zzbbg;
    private OnCustomRenderedAdLoadedListener zzbbh;
    private PlayStorePurchaseListener zzbbi;
    private String zzbbj;
    private PublisherInterstitialAd zzbbn;
    private boolean zzbbo;
    private RewardedVideoAdListener zzgj;

    public zzaf(Context context) {
        this(context, zzh.zzkb(), null);
    }

    public zzaf(Context context, PublisherInterstitialAd publisherInterstitialAd) {
        this(context, zzh.zzkb(), publisherInterstitialAd);
    }

    public zzaf(Context context, zzh zzh2, PublisherInterstitialAd publisherInterstitialAd) {
        this.mContext = context;
        this.zzakc = zzh2;
        this.zzbbn = publisherInterstitialAd;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zzat(String object) throws RemoteException {
        if (this.zzant == null) {
            this.zzau((String)object);
        }
        object = this.zzbbo ? AdSizeParcel.zzkc() : new AdSizeParcel();
        this.zzbbf = zzm.zzks().zzb(this.mContext, (AdSizeParcel)object, this.zzant, this.zzbba);
        if (this.zzayk != null) {
            this.zzbbf.zza(new zzc(this.zzayk));
        }
        if (this.zzayj != null) {
            this.zzbbf.zza(new zzb(this.zzayj));
        }
        if (this.zzazw != null) {
            this.zzbbf.zza(new zzj(this.zzazw));
        }
        if (this.zzbbg != null) {
            this.zzbbf.zza(new zzil(this.zzbbg));
        }
        if (this.zzbbi != null) {
            this.zzbbf.zza(new zzip(this.zzbbi), this.zzbbj);
        }
        if (this.zzbbh != null) {
            this.zzbbf.zza(new zzee(this.zzbbh));
        }
        if (this.zzbbe != null) {
            this.zzbbf.zza(this.zzbbe.zzdu());
        }
        if (this.zzgj != null) {
            this.zzbbf.zza(new zzg(this.zzgj));
        }
    }

    private void zzau(String string2) {
        if (this.zzbbf == null) {
            throw new IllegalStateException(new StringBuilder(String.valueOf(string2).length() + 63).append("The ad unit ID must be set on InterstitialAd before ").append(string2).append(" is called.").toString());
        }
    }

    public AdListener getAdListener() {
        return this.zzayk;
    }

    public String getAdUnitId() {
        return this.zzant;
    }

    public AppEventListener getAppEventListener() {
        return this.zzazw;
    }

    public InAppPurchaseListener getInAppPurchaseListener() {
        return this.zzbbg;
    }

    public String getMediationAdapterClassName() {
        try {
            if (this.zzbbf != null) {
                String string2 = this.zzbbf.getMediationAdapterClassName();
                return string2;
            }
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to get the mediation adapter class name.", (Throwable)var1_2);
        }
        return null;
    }

    public OnCustomRenderedAdLoadedListener getOnCustomRenderedAdLoadedListener() {
        return this.zzbbh;
    }

    public boolean isLoaded() {
        block3 : {
            try {
                if (this.zzbbf != null) break block3;
                return false;
            }
            catch (RemoteException var2_2) {
                com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to check if ad is ready.", (Throwable)var2_2);
                return false;
            }
        }
        boolean bl = this.zzbbf.isReady();
        return bl;
    }

    public boolean isLoading() {
        block3 : {
            try {
                if (this.zzbbf != null) break block3;
                return false;
            }
            catch (RemoteException var2_2) {
                com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to check if ad is loading.", (Throwable)var2_2);
                return false;
            }
        }
        boolean bl = this.zzbbf.isLoading();
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setAdListener(AdListener object) {
        try {
            this.zzayk = object;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzc((AdListener)object) : null;
                zzu2.zza((zzq)object);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the AdListener.", (Throwable)var1_2);
            return;
        }
    }

    public void setAdUnitId(String string2) {
        if (this.zzant != null) {
            throw new IllegalStateException("The ad unit ID can only be set once on InterstitialAd.");
        }
        this.zzant = string2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setAppEventListener(AppEventListener object) {
        try {
            this.zzazw = object;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzj((AppEventListener)object) : null;
                zzu2.zza((zzw)object);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the AppEventListener.", (Throwable)var1_2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setCorrelator(Correlator object) {
        this.zzbbe = object;
        try {
            if (this.zzbbf == null) return;
            {
                zzu zzu2 = this.zzbbf;
                object = this.zzbbe == null ? null : this.zzbbe.zzdu();
                zzu2.zza((zzy)object);
                return;
            }
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set correlator.", (Throwable)var1_2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setInAppPurchaseListener(InAppPurchaseListener object) {
        if (this.zzbbi != null) {
            throw new IllegalStateException("Play store purchase parameter has already been set.");
        }
        try {
            this.zzbbg = object;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzil((InAppPurchaseListener)object) : null;
                zzu2.zza((zzig)object);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the InAppPurchaseListener.", (Throwable)var1_2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setOnCustomRenderedAdLoadedListener(OnCustomRenderedAdLoadedListener object) {
        try {
            this.zzbbh = object;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzee((OnCustomRenderedAdLoadedListener)object) : null;
                zzu2.zza((zzed)object);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the OnCustomRenderedAdLoadedListener.", (Throwable)var1_2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setPlayStorePurchaseParams(PlayStorePurchaseListener object, String string2) {
        if (this.zzbbg != null) {
            throw new IllegalStateException("In app purchase parameter has already been set.");
        }
        try {
            this.zzbbi = object;
            this.zzbbj = string2;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzip((PlayStorePurchaseListener)object) : null;
                zzu2.zza((zzik)object, string2);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the play store purchase parameter.", (Throwable)var1_2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setRewardedVideoAdListener(RewardedVideoAdListener object) {
        try {
            this.zzgj = object;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzg((RewardedVideoAdListener)object) : null;
                zzu2.zza((zzd)object);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the AdListener.", (Throwable)var1_2);
            return;
        }
    }

    public void show() {
        try {
            this.zzau("show");
            this.zzbbf.showInterstitial();
            return;
        }
        catch (RemoteException var1_1) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to show interstitial.", (Throwable)var1_1);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zza(zza object) {
        try {
            this.zzayj = object;
            if (this.zzbbf != null) {
                zzu zzu2 = this.zzbbf;
                object = object != null ? new zzb((zza)object) : null;
                zzu2.zza((zzp)object);
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to set the AdClickListener.", (Throwable)var1_2);
            return;
        }
    }

    public void zza(zzad zzad2) {
        try {
            if (this.zzbbf == null) {
                this.zzat("loadAd");
            }
            if (this.zzbbf.zzb(this.zzakc.zza(this.mContext, zzad2))) {
                this.zzbba.zzi(zzad2.zzlb());
            }
            return;
        }
        catch (RemoteException var1_2) {
            com.google.android.gms.ads.internal.util.client.zzb.zzc("Failed to load ad.", (Throwable)var1_2);
            return;
        }
    }

    public void zzd(boolean bl) {
        this.zzbbo = bl;
    }
}

