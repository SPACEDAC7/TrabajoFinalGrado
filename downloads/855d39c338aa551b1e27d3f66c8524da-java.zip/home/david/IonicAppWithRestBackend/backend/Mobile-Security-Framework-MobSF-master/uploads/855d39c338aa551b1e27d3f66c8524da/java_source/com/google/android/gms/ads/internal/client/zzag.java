/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.RemoteException
 */
package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzah;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.client.zzz;
import com.google.android.gms.ads.internal.reward.client.zzi;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.internal.zzgy;
import com.google.android.gms.internal.zzgz;
import com.google.android.gms.internal.zzji;

@zzji
public class zzag {
    private static final Object zzaox = new Object();
    private static zzag zzbbp;
    private zzz zzbbq;
    private RewardedVideoAd zzbbr;

    private zzag() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static zzag zzli() {
        Object object = zzaox;
        synchronized (object) {
            if (zzbbp != null) return zzbbp;
            zzbbp = new zzag();
            return zzbbp;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public RewardedVideoAd getRewardedVideoAdInstance(Context object) {
        Object object2 = zzaox;
        synchronized (object2) {
            if (this.zzbbr != null) {
                return this.zzbbr;
            }
            zzgy zzgy2 = new zzgy();
            this.zzbbr = new zzi((Context)object, zzm.zzks().zza((Context)object, zzgy2));
            return this.zzbbr;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void openDebugMenu(Context context, String string2) {
        boolean bl = this.zzbbq != null;
        zzaa.zza(bl, (Object)"MobileAds.initialize() must be called prior to opening debug menu.");
        try {
            this.zzbbq.zzb(zze.zzac(context), string2);
            return;
        }
        catch (RemoteException var1_2) {
            zzb.zzb("Unable to open debug menu.", (Throwable)var1_2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setAppMuted(boolean bl) {
        boolean bl2 = this.zzbbq != null;
        zzaa.zza(bl2, (Object)"MobileAds.initialize() must be called prior to setting the app volume.");
        try {
            this.zzbbq.setAppMuted(bl);
            return;
        }
        catch (RemoteException var3_3) {
            zzb.zzb("Unable to set app mute state.", (Throwable)var3_3);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setAppVolume(float f) {
        boolean bl = true;
        boolean bl2 = 0.0f <= f && f <= 1.0f;
        zzaa.zzb(bl2, (Object)"The app volume must be a value between 0 and 1 inclusive.");
        bl2 = this.zzbbq != null ? bl : false;
        zzaa.zza(bl2, (Object)"MobileAds.initialize() must be called prior to setting the app volume.");
        try {
            this.zzbbq.setAppVolume(f);
            return;
        }
        catch (RemoteException var4_4) {
            zzb.zzb("Unable to set app volume.", (Throwable)var4_4);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zza(Context context, String string2, zzah object) {
        object = zzaox;
        synchronized (object) {
            if (this.zzbbq != null) {
                return;
            }
            if (context == null) {
                throw new IllegalArgumentException("Context cannot be null.");
            }
            try {
                this.zzbbq = zzm.zzks().zzk(context);
                this.zzbbq.initialize();
                if (string2 != null) {
                    this.zzbbq.zzz(string2);
                }
            }
            catch (RemoteException var1_2) {
                zzb.zzc("Fail to initialize or set applicationCode on mobile ads setting manager", (Throwable)var1_2);
            }
            return;
        }
    }
}

