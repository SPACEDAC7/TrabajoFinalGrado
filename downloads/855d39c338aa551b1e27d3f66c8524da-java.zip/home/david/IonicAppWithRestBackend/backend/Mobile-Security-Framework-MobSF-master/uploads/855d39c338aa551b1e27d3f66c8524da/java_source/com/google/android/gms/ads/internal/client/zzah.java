/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.internal.client;

import com.google.android.gms.internal.zzji;

@zzji
public class zzah {
    public void zzav(String string2) {
    }

    public void zzq(boolean bl) {
    }
}

