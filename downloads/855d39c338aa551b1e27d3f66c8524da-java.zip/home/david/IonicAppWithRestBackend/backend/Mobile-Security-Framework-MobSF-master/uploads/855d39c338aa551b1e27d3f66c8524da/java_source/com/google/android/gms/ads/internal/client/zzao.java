/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.SearchAdRequestParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzao
implements Parcelable.Creator<SearchAdRequestParcel> {
    static void zza(SearchAdRequestParcel searchAdRequestParcel, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, searchAdRequestParcel.versionCode);
        zzb.zzc(parcel, 2, searchAdRequestParcel.zzbbx);
        zzb.zzc(parcel, 3, searchAdRequestParcel.backgroundColor);
        zzb.zzc(parcel, 4, searchAdRequestParcel.zzbby);
        zzb.zzc(parcel, 5, searchAdRequestParcel.zzbbz);
        zzb.zzc(parcel, 6, searchAdRequestParcel.zzbca);
        zzb.zzc(parcel, 7, searchAdRequestParcel.zzbcb);
        zzb.zzc(parcel, 8, searchAdRequestParcel.zzbcc);
        zzb.zzc(parcel, 9, searchAdRequestParcel.zzbcd);
        zzb.zza(parcel, 10, searchAdRequestParcel.zzbce, false);
        zzb.zzc(parcel, 11, searchAdRequestParcel.zzbcf);
        zzb.zza(parcel, 12, searchAdRequestParcel.zzbcg, false);
        zzb.zzc(parcel, 13, searchAdRequestParcel.zzbch);
        zzb.zzc(parcel, 14, searchAdRequestParcel.zzbci);
        zzb.zza(parcel, 15, searchAdRequestParcel.zzbcj, false);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzg(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzz(n);
    }

    public SearchAdRequestParcel zzg(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        int n8 = 0;
        int n9 = 0;
        int n10 = 0;
        String string2 = null;
        int n11 = 0;
        String string3 = null;
        int n12 = 0;
        int n13 = 0;
        String string4 = null;
        block17 : while (parcel.dataPosition() < n) {
            int n14 = zza.zzcq(parcel);
            switch (zza.zzgu(n14)) {
                default: {
                    zza.zzb(parcel, n14);
                    continue block17;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 2: {
                    n3 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 3: {
                    n4 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 4: {
                    n5 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 5: {
                    n6 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 6: {
                    n7 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 7: {
                    n8 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 8: {
                    n9 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 9: {
                    n10 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 10: {
                    string2 = zza.zzq(parcel, n14);
                    continue block17;
                }
                case 11: {
                    n11 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 12: {
                    string3 = zza.zzq(parcel, n14);
                    continue block17;
                }
                case 13: {
                    n12 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 14: {
                    n13 = zza.zzg(parcel, n14);
                    continue block17;
                }
                case 15: 
            }
            string4 = zza.zzq(parcel, n14);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new SearchAdRequestParcel(n2, n3, n4, n5, n6, n7, n8, n9, n10, string2, n11, string3, n12, n13, string4);
    }

    public SearchAdRequestParcel[] zzz(int n) {
        return new SearchAdRequestParcel[n];
    }
}

