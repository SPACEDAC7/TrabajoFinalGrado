/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.VideoOptionsParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzaq
implements Parcelable.Creator<VideoOptionsParcel> {
    static void zza(VideoOptionsParcel videoOptionsParcel, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, videoOptionsParcel.versionCode);
        zzb.zza(parcel, 2, videoOptionsParcel.zzbck);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzh(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzaa(n);
    }

    public VideoOptionsParcel[] zzaa(int n) {
        return new VideoOptionsParcel[n];
    }

    public VideoOptionsParcel zzh(Parcel parcel) {
        boolean bl = false;
        int n = zza.zzcr(parcel);
        int n2 = 0;
        block4 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block4;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block4;
                }
                case 2: 
            }
            bl = zza.zzc(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new VideoOptionsParcel(n2, bl);
    }
}

