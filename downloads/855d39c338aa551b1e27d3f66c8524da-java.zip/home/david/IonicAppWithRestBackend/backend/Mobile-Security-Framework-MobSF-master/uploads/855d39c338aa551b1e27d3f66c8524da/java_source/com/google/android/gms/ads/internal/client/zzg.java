/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.location.Location
 *  android.os.Bundle
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.client;

import android.location.Location;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.SearchAdRequestParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import java.util.ArrayList;
import java.util.List;

public class zzg
implements Parcelable.Creator<AdRequestParcel> {
    static void zza(AdRequestParcel adRequestParcel, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, adRequestParcel.versionCode);
        zzb.zza(parcel, 2, adRequestParcel.zzayl);
        zzb.zza(parcel, 3, adRequestParcel.extras, false);
        zzb.zzc(parcel, 4, adRequestParcel.zzaym);
        zzb.zzb(parcel, 5, adRequestParcel.zzayn, false);
        zzb.zza(parcel, 6, adRequestParcel.zzayo);
        zzb.zzc(parcel, 7, adRequestParcel.zzayp);
        zzb.zza(parcel, 8, adRequestParcel.zzayq);
        zzb.zza(parcel, 9, adRequestParcel.zzayr, false);
        zzb.zza(parcel, 10, adRequestParcel.zzays, n, false);
        zzb.zza(parcel, 11, (Parcelable)adRequestParcel.zzayt, n, false);
        zzb.zza(parcel, 12, adRequestParcel.zzayu, false);
        zzb.zza(parcel, 13, adRequestParcel.zzayv, false);
        zzb.zza(parcel, 14, adRequestParcel.zzayw, false);
        zzb.zzb(parcel, 15, adRequestParcel.zzayx, false);
        zzb.zza(parcel, 16, adRequestParcel.zzayy, false);
        zzb.zza(parcel, 17, adRequestParcel.zzayz, false);
        zzb.zza(parcel, 18, adRequestParcel.zzaza);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zze(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzv(n);
    }

    public AdRequestParcel zze(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        long l = 0;
        Bundle bundle = null;
        int n3 = 0;
        ArrayList<String> arrayList = null;
        boolean bl = false;
        int n4 = 0;
        boolean bl2 = false;
        String string2 = null;
        SearchAdRequestParcel searchAdRequestParcel = null;
        Location location = null;
        String string3 = null;
        Bundle bundle2 = null;
        Bundle bundle3 = null;
        ArrayList<String> arrayList2 = null;
        String string4 = null;
        String string5 = null;
        boolean bl3 = false;
        block20 : while (parcel.dataPosition() < n) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block20;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n5);
                    continue block20;
                }
                case 2: {
                    l = zza.zzi(parcel, n5);
                    continue block20;
                }
                case 3: {
                    bundle = zza.zzs(parcel, n5);
                    continue block20;
                }
                case 4: {
                    n3 = zza.zzg(parcel, n5);
                    continue block20;
                }
                case 5: {
                    arrayList = zza.zzae(parcel, n5);
                    continue block20;
                }
                case 6: {
                    bl = zza.zzc(parcel, n5);
                    continue block20;
                }
                case 7: {
                    n4 = zza.zzg(parcel, n5);
                    continue block20;
                }
                case 8: {
                    bl2 = zza.zzc(parcel, n5);
                    continue block20;
                }
                case 9: {
                    string2 = zza.zzq(parcel, n5);
                    continue block20;
                }
                case 10: {
                    searchAdRequestParcel = zza.zza(parcel, n5, SearchAdRequestParcel.CREATOR);
                    continue block20;
                }
                case 11: {
                    location = (Location)zza.zza(parcel, n5, Location.CREATOR);
                    continue block20;
                }
                case 12: {
                    string3 = zza.zzq(parcel, n5);
                    continue block20;
                }
                case 13: {
                    bundle2 = zza.zzs(parcel, n5);
                    continue block20;
                }
                case 14: {
                    bundle3 = zza.zzs(parcel, n5);
                    continue block20;
                }
                case 15: {
                    arrayList2 = zza.zzae(parcel, n5);
                    continue block20;
                }
                case 16: {
                    string4 = zza.zzq(parcel, n5);
                    continue block20;
                }
                case 17: {
                    string5 = zza.zzq(parcel, n5);
                    continue block20;
                }
                case 18: 
            }
            bl3 = zza.zzc(parcel, n5);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new AdRequestParcel(n2, l, bundle, n3, arrayList, bl, n4, bl2, string2, searchAdRequestParcel, location, string3, bundle2, bundle3, arrayList2, string4, string5, bl3);
    }

    public AdRequestParcel[] zzv(int n) {
        return new AdRequestParcel[n];
    }
}

