/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.location.Location
 *  android.os.Bundle
 */
package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.SearchAdRequestParcel;
import com.google.android.gms.ads.internal.client.zzad;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.reward.client.RewardedVideoAdRequestParcel;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.search.SearchAdRequest;
import com.google.android.gms.internal.zzji;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

@zzji
public class zzh {
    public static final zzh zzazp = new zzh();

    protected zzh() {
    }

    public static zzh zzkb() {
        return zzazp;
    }

    /*
     * Enabled aggressive block sorting
     */
    public AdRequestParcel zza(Context object, zzad zzad2) {
        Set<String> set = zzad2.getBirthday();
        long l = set != null ? set.getTime() : -1;
        String string2 = zzad2.getContentUrl();
        int n = zzad2.getGender();
        set = zzad2.getKeywords();
        set = !set.isEmpty() ? Collections.unmodifiableList(new ArrayList(set)) : null;
        boolean bl = zzad2.isTestDevice((Context)object);
        int n2 = zzad2.zzld();
        Location location = zzad2.getLocation();
        Bundle bundle = zzad2.getNetworkExtrasBundle(AdMobAdapter.class);
        boolean bl2 = zzad2.getManualImpressionsEnabled();
        String string3 = zzad2.getPublisherProvidedId();
        Object object2 = zzad2.zzla();
        object2 = object2 != null ? new SearchAdRequestParcel((SearchAdRequest)object2) : null;
        Object var12_14 = null;
        Context context = object.getApplicationContext();
        object = var12_14;
        if (context != null) {
            object = context.getPackageName();
            object = zzm.zzkr().zza(Thread.currentThread().getStackTrace(), (String)object);
        }
        boolean bl3 = zzad2.isDesignedForFamilies();
        return new AdRequestParcel(7, l, bundle, n, (List<String>)((Object)set), bl, n2, bl2, string3, (SearchAdRequestParcel)object2, location, string2, zzad2.zzlc(), zzad2.getCustomTargeting(), Collections.unmodifiableList(new ArrayList<String>(zzad2.zzle())), zzad2.zzkz(), (String)object, bl3);
    }

    public RewardedVideoAdRequestParcel zza(Context context, zzad zzad2, String string2) {
        return new RewardedVideoAdRequestParcel(this.zza(context, zzad2), string2);
    }
}

