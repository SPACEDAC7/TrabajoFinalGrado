/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzi
implements Parcelable.Creator<AdSizeParcel> {
    static void zza(AdSizeParcel adSizeParcel, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, adSizeParcel.versionCode);
        zzb.zza(parcel, 2, adSizeParcel.zzazq, false);
        zzb.zzc(parcel, 3, adSizeParcel.height);
        zzb.zzc(parcel, 4, adSizeParcel.heightPixels);
        zzb.zza(parcel, 5, adSizeParcel.zzazr);
        zzb.zzc(parcel, 6, adSizeParcel.width);
        zzb.zzc(parcel, 7, adSizeParcel.widthPixels);
        zzb.zza((Parcel)parcel, (int)8, (Parcelable[])adSizeParcel.zzazs, (int)n, (boolean)false);
        zzb.zza(parcel, 9, adSizeParcel.zzazt);
        zzb.zza(parcel, 10, adSizeParcel.zzazu);
        zzb.zza(parcel, 11, adSizeParcel.zzazv);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzf(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzw(n);
    }

    public AdSizeParcel zzf(Parcel parcel) {
        AdSizeParcel[] arradSizeParcel = null;
        boolean bl = false;
        int n = zza.zzcr(parcel);
        boolean bl2 = false;
        boolean bl3 = false;
        int n2 = 0;
        int n3 = 0;
        boolean bl4 = false;
        int n4 = 0;
        int n5 = 0;
        String string2 = null;
        int n6 = 0;
        block13 : while (parcel.dataPosition() < n) {
            int n7 = zza.zzcq(parcel);
            switch (zza.zzgu(n7)) {
                default: {
                    zza.zzb(parcel, n7);
                    continue block13;
                }
                case 1: {
                    n6 = zza.zzg(parcel, n7);
                    continue block13;
                }
                case 2: {
                    string2 = zza.zzq(parcel, n7);
                    continue block13;
                }
                case 3: {
                    n5 = zza.zzg(parcel, n7);
                    continue block13;
                }
                case 4: {
                    n4 = zza.zzg(parcel, n7);
                    continue block13;
                }
                case 5: {
                    bl4 = zza.zzc(parcel, n7);
                    continue block13;
                }
                case 6: {
                    n3 = zza.zzg(parcel, n7);
                    continue block13;
                }
                case 7: {
                    n2 = zza.zzg(parcel, n7);
                    continue block13;
                }
                case 8: {
                    arradSizeParcel = zza.zzb(parcel, n7, AdSizeParcel.CREATOR);
                    continue block13;
                }
                case 9: {
                    bl3 = zza.zzc(parcel, n7);
                    continue block13;
                }
                case 10: {
                    bl2 = zza.zzc(parcel, n7);
                    continue block13;
                }
                case 11: 
            }
            bl = zza.zzc(parcel, n7);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new AdSizeParcel(n6, string2, n5, n4, bl4, n3, n2, arradSizeParcel, bl3, bl2, bl);
    }

    public AdSizeParcel[] zzw(int n) {
        return new AdSizeParcel[n];
    }
}

