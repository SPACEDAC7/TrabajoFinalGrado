/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.text.TextUtils
 *  android.util.AttributeSet
 */
package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import com.google.android.gms.R;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.internal.zzji;

@zzji
public final class zzk {
    private final String zzant;
    private final AdSize[] zzazx;

    /*
     * Enabled aggressive block sorting
     */
    public zzk(Context context, AttributeSet object) {
        boolean bl = true;
        context = context.getResources().obtainAttributes((AttributeSet)object, R.styleable.AdsAttrs);
        object = context.getString(R.styleable.AdsAttrs_adSize);
        String string2 = context.getString(R.styleable.AdsAttrs_adSizes);
        boolean bl2 = !TextUtils.isEmpty((CharSequence)object);
        if (TextUtils.isEmpty((CharSequence)string2)) {
            bl = false;
        }
        if (bl2 && !bl) {
            this.zzazx = zzk.zzal((String)object);
        } else {
            if (bl2 || !bl) {
                if (!bl2) throw new IllegalArgumentException("Required XML attribute \"adSize\" was missing.");
                {
                    throw new IllegalArgumentException("Either XML attribute \"adSize\" or XML attribute \"supportedAdSizes\" should be specified, but not both.");
                }
            }
            this.zzazx = zzk.zzal(string2);
        }
        this.zzant = context.getString(R.styleable.AdsAttrs_adUnitId);
        if (!TextUtils.isEmpty((CharSequence)this.zzant)) return;
        {
            throw new IllegalArgumentException("Required XML attribute \"adUnitId\" was missing.");
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static AdSize[] zzal(String string2) {
        String[] arrstring = string2.split("\\s*,\\s*");
        AdSize[] arradSize = new AdSize[arrstring.length];
        for (int i = 0; i < arrstring.length; ++i) {
            String string3 = arrstring[i].trim();
            if (string3.matches("^(\\d+|FULL_WIDTH)\\s*[xX]\\s*(\\d+|AUTO_HEIGHT)$")) {
                int n;
                int n2;
                String[] arrstring2 = string3.split("[xX]");
                arrstring2[0] = arrstring2[0].trim();
                arrstring2[1] = arrstring2[1].trim();
                try {
                    n2 = "FULL_WIDTH".equals(arrstring2[0]) ? -1 : Integer.parseInt(arrstring2[0]);
                    boolean bl = "AUTO_HEIGHT".equals(arrstring2[1]);
                    n = bl ? -2 : Integer.parseInt(arrstring2[1]);
                }
                catch (NumberFormatException var0_1) {
                    String string4 = String.valueOf(string3);
                    if (string4.length() != 0) {
                        string4 = "Could not parse XML attribute \"adSize\": ".concat(string4);
                        throw new IllegalArgumentException(string4);
                    }
                    string4 = new String("Could not parse XML attribute \"adSize\": ");
                    throw new IllegalArgumentException(string4);
                }
                arradSize[i] = new AdSize(n2, n);
                continue;
            }
            if ("BANNER".equals(string3)) {
                arradSize[i] = AdSize.BANNER;
                continue;
            }
            if ("LARGE_BANNER".equals(string3)) {
                arradSize[i] = AdSize.LARGE_BANNER;
                continue;
            }
            if ("FULL_BANNER".equals(string3)) {
                arradSize[i] = AdSize.FULL_BANNER;
                continue;
            }
            if ("LEADERBOARD".equals(string3)) {
                arradSize[i] = AdSize.LEADERBOARD;
                continue;
            }
            if ("MEDIUM_RECTANGLE".equals(string3)) {
                arradSize[i] = AdSize.MEDIUM_RECTANGLE;
                continue;
            }
            if ("SMART_BANNER".equals(string3)) {
                arradSize[i] = AdSize.SMART_BANNER;
                continue;
            }
            if ("WIDE_SKYSCRAPER".equals(string3)) {
                arradSize[i] = AdSize.WIDE_SKYSCRAPER;
                continue;
            }
            if ("FLUID".equals(string3)) {
                arradSize[i] = AdSize.FLUID;
                continue;
            }
            string2 = String.valueOf(string3);
            if (string2.length() != 0) {
                string2 = "Could not parse XML attribute \"adSize\": ".concat(string2);
                throw new IllegalArgumentException(string2);
            }
            string2 = new String("Could not parse XML attribute \"adSize\": ");
            throw new IllegalArgumentException(string2);
        }
        if (arradSize.length != 0) return arradSize;
        if ((string2 = String.valueOf(string2)).length() != 0) {
            string2 = "Could not parse XML attribute \"adSize\": ".concat(string2);
            throw new IllegalArgumentException(string2);
        }
        string2 = new String("Could not parse XML attribute \"adSize\": ");
        throw new IllegalArgumentException(string2);
    }

    public String getAdUnitId() {
        return this.zzant;
    }

    public AdSize[] zzm(boolean bl) {
        if (!bl && this.zzazx.length != 1) {
            throw new IllegalArgumentException("The adSizes XML attribute is only allowed on PublisherAdViews.");
        }
        return this.zzazx;
    }
}

