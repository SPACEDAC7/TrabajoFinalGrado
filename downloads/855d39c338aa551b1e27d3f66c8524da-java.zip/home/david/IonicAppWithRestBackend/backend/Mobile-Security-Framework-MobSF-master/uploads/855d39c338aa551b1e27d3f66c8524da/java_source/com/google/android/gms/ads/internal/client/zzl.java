/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.RemoteException
 *  android.widget.FrameLayout
 */
package com.google.android.gms.ads.internal.client;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.support.annotation.VisibleForTesting;
import android.widget.FrameLayout;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.zzai;
import com.google.android.gms.ads.internal.client.zzaj;
import com.google.android.gms.ads.internal.client.zzak;
import com.google.android.gms.ads.internal.client.zzal;
import com.google.android.gms.ads.internal.client.zzam;
import com.google.android.gms.ads.internal.client.zzan;
import com.google.android.gms.ads.internal.client.zzd;
import com.google.android.gms.ads.internal.client.zze;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.client.zzs;
import com.google.android.gms.ads.internal.client.zzu;
import com.google.android.gms.ads.internal.client.zzx;
import com.google.android.gms.ads.internal.client.zzz;
import com.google.android.gms.ads.internal.reward.client.zzf;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.internal.zzei;
import com.google.android.gms.internal.zzeu;
import com.google.android.gms.internal.zzgz;
import com.google.android.gms.internal.zzhx;
import com.google.android.gms.internal.zzhy;
import com.google.android.gms.internal.zzih;
import com.google.android.gms.internal.zzim;
import com.google.android.gms.internal.zzji;

@zzji
public class zzl {
    private final Object zzako = new Object();
    private zzx zzazy;
    private final zze zzazz;
    private final zzd zzbaa;
    private final zzai zzbab;
    private final zzeu zzbac;
    private final zzf zzbad;
    private final zzim zzbae;
    private final zzhx zzbaf;

    public zzl(zze zze2, zzd zzd2, zzai zzai2, zzeu zzeu2, zzf zzf2, zzim zzim2, zzhx zzhx2) {
        this.zzazz = zze2;
        this.zzbaa = zzd2;
        this.zzbab = zzai2;
        this.zzbac = zzeu2;
        this.zzbad = zzf2;
        this.zzbae = zzim2;
        this.zzbaf = zzhx2;
    }

    private static boolean zza(Activity activity, String string2) {
        if (!(activity = activity.getIntent()).hasExtra(string2)) {
            zzb.e("useClientJar flag not found in activity intent extras.");
            return false;
        }
        return activity.getBooleanExtra(string2, false);
    }

    private void zzc(Context context, String string2) {
        Bundle bundle = new Bundle();
        bundle.putString("action", "no_ads_fallback");
        bundle.putString("flow", string2);
        zzm.zzkr().zza(context, null, "gmob-apps", bundle, true);
    }

    @Nullable
    private static zzx zzke() {
        Object object;
        block3 : {
            try {
                object = zzl.class.getClassLoader().loadClass("com.google.android.gms.ads.internal.ClientApi").newInstance();
                if (object instanceof IBinder) break block3;
                zzb.zzdi("ClientApi class is not an instance of IBinder");
                return null;
            }
            catch (Exception var0_1) {
                zzb.zzc("Failed to instantiate ClientApi class.", var0_1);
                return null;
            }
        }
        object = zzx.zza.asInterface((IBinder)object);
        return object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Nullable
    private zzx zzkf() {
        Object object = this.zzako;
        synchronized (object) {
            if (this.zzazy != null) return this.zzazy;
            this.zzazy = zzl.zzke();
            return this.zzazy;
        }
    }

    public zzu zza(final Context context, final AdSizeParcel adSizeParcel, final String string2) {
        return (zzu)this.zza(context, false, new zza<zzu>(){

            public zzu zza(zzx zzx2) throws RemoteException {
                return zzx2.createSearchAdManager(com.google.android.gms.dynamic.zze.zzac(context), adSizeParcel, string2, 9877000);
            }

            @Override
            public /* synthetic */ Object zzb(zzx zzx2) throws RemoteException {
                return this.zza(zzx2);
            }

            public zzu zzkg() {
                zzu zzu2 = zzl.this.zzazz.zza(context, adSizeParcel, string2, null, 3);
                if (zzu2 != null) {
                    return zzu2;
                }
                zzl.this.zzc(context, "search");
                return new zzak();
            }

            @Override
            public /* synthetic */ Object zzkh() throws RemoteException {
                return this.zzkg();
            }
        });
    }

    public zzu zza(final Context context, final AdSizeParcel adSizeParcel, final String string2, final zzgz zzgz2) {
        return (zzu)this.zza(context, false, new zza<zzu>(){

            public zzu zza(zzx zzx2) throws RemoteException {
                return zzx2.createBannerAdManager(com.google.android.gms.dynamic.zze.zzac(context), adSizeParcel, string2, zzgz2, 9877000);
            }

            @Override
            public /* synthetic */ Object zzb(zzx zzx2) throws RemoteException {
                return this.zza(zzx2);
            }

            public zzu zzkg() {
                zzu zzu2 = zzl.this.zzazz.zza(context, adSizeParcel, string2, zzgz2, 1);
                if (zzu2 != null) {
                    return zzu2;
                }
                zzl.this.zzc(context, "banner");
                return new zzak();
            }

            @Override
            public /* synthetic */ Object zzkh() throws RemoteException {
                return this.zzkg();
            }
        });
    }

    public com.google.android.gms.ads.internal.reward.client.zzb zza(final Context context, final zzgz zzgz2) {
        return (com.google.android.gms.ads.internal.reward.client.zzb)this.zza(context, false, new zza<com.google.android.gms.ads.internal.reward.client.zzb>(){

            @Override
            public /* synthetic */ Object zzb(zzx zzx2) throws RemoteException {
                return this.zzf(zzx2);
            }

            public com.google.android.gms.ads.internal.reward.client.zzb zzf(zzx zzx2) throws RemoteException {
                return zzx2.createRewardedVideoAd(com.google.android.gms.dynamic.zze.zzac(context), zzgz2, 9877000);
            }

            @Override
            public /* synthetic */ Object zzkh() throws RemoteException {
                return this.zzkl();
            }

            public com.google.android.gms.ads.internal.reward.client.zzb zzkl() {
                com.google.android.gms.ads.internal.reward.client.zzb zzb2 = zzl.this.zzbad.zzb(context, zzgz2);
                if (zzb2 != null) {
                    return zzb2;
                }
                zzl.this.zzc(context, "rewarded_video");
                return new zzan();
            }
        });
    }

    public zzei zza(final Context context, final FrameLayout frameLayout, final FrameLayout frameLayout2) {
        return (zzei)this.zza(context, false, new zza<zzei>(){

            @Override
            public /* synthetic */ Object zzb(zzx zzx2) throws RemoteException {
                return this.zze(zzx2);
            }

            public zzei zze(zzx zzx2) throws RemoteException {
                return zzx2.createNativeAdViewDelegate(com.google.android.gms.dynamic.zze.zzac(frameLayout), com.google.android.gms.dynamic.zze.zzac(frameLayout2));
            }

            @Override
            public /* synthetic */ Object zzkh() throws RemoteException {
                return this.zzkk();
            }

            public zzei zzkk() {
                zzei zzei2 = zzl.this.zzbac.zzb(context, frameLayout, frameLayout2);
                if (zzei2 != null) {
                    return zzei2;
                }
                zzl.this.zzc(context, "native_ad_view_delegate");
                return new zzam();
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     */
    @VisibleForTesting
    <T> T zza(Context object, boolean bl, zza<T> zza2) {
        boolean bl2 = bl;
        if (!bl) {
            bl2 = bl;
            if (!zzm.zzkr().zzap((Context)object)) {
                zzb.zzdg("Google Play Services is not available");
                bl2 = true;
            }
        }
        if (bl2) {
            T t;
            object = t = zza2.zzko();
            if (t != null) return (T)object;
            {
                object = zza2.zzkp();
                return (T)object;
            }
        } else {
            T t;
            object = t = zza2.zzkp();
            if (t != null) return (T)object;
            return zza2.zzko();
        }
    }

    public zzs zzb(final Context context, final String string2, final zzgz zzgz2) {
        return (zzs)this.zza(context, false, new zza<zzs>(){

            @Override
            public /* synthetic */ Object zzb(zzx zzx2) throws RemoteException {
                return this.zzc(zzx2);
            }

            public zzs zzc(zzx zzx2) throws RemoteException {
                return zzx2.createAdLoaderBuilder(com.google.android.gms.dynamic.zze.zzac(context), string2, zzgz2, 9877000);
            }

            @Override
            public /* synthetic */ Object zzkh() throws RemoteException {
                return this.zzki();
            }

            public zzs zzki() {
                zzs zzs2 = zzl.this.zzbaa.zza(context, string2, zzgz2);
                if (zzs2 != null) {
                    return zzs2;
                }
                zzl.this.zzc(context, "native_ad");
                return new zzaj();
            }
        });
    }

    public zzu zzb(final Context context, final AdSizeParcel adSizeParcel, final String string2, final zzgz zzgz2) {
        return (zzu)this.zza(context, false, new zza<zzu>(){

            public zzu zza(zzx zzx2) throws RemoteException {
                return zzx2.createInterstitialAdManager(com.google.android.gms.dynamic.zze.zzac(context), adSizeParcel, string2, zzgz2, 9877000);
            }

            @Override
            public /* synthetic */ Object zzb(zzx zzx2) throws RemoteException {
                return this.zza(zzx2);
            }

            public zzu zzkg() {
                zzu zzu2 = zzl.this.zzazz.zza(context, adSizeParcel, string2, zzgz2, 2);
                if (zzu2 != null) {
                    return zzu2;
                }
                zzl.this.zzc(context, "interstitial");
                return new zzak();
            }

            @Override
            public /* synthetic */ Object zzkh() throws RemoteException {
                return this.zzkg();
            }
        });
    }

    @Nullable
    public zzih zzb(final Activity activity) {
        return (zzih)this.zza((Context)activity, zzl.zza(activity, "com.google.android.gms.ads.internal.purchase.useClientJar"), new zza<zzih>(){

            @Override
            public /* synthetic */ Object zzb(zzx zzx2) throws RemoteException {
                return this.zzg(zzx2);
            }

            public zzih zzg(zzx zzx2) throws RemoteException {
                return zzx2.createInAppPurchaseManager(com.google.android.gms.dynamic.zze.zzac(activity));
            }

            @Override
            public /* synthetic */ Object zzkh() throws RemoteException {
                return this.zzkm();
            }

            public zzih zzkm() {
                zzih zzih2 = zzl.this.zzbae.zzg(activity);
                if (zzih2 != null) {
                    return zzih2;
                }
                zzl.this.zzc((Context)activity, "iap");
                return null;
            }
        });
    }

    @Nullable
    public zzhy zzc(final Activity activity) {
        return (zzhy)this.zza((Context)activity, zzl.zza(activity, "com.google.android.gms.ads.internal.overlay.useClientJar"), new zza<zzhy>(){

            @Override
            public /* synthetic */ Object zzb(zzx zzx2) throws RemoteException {
                return this.zzh(zzx2);
            }

            public zzhy zzh(zzx zzx2) throws RemoteException {
                return zzx2.createAdOverlay(com.google.android.gms.dynamic.zze.zzac(activity));
            }

            @Override
            public /* synthetic */ Object zzkh() throws RemoteException {
                return this.zzkn();
            }

            public zzhy zzkn() {
                zzhy zzhy2 = zzl.this.zzbaf.zzf(activity);
                if (zzhy2 != null) {
                    return zzhy2;
                }
                zzl.this.zzc((Context)activity, "ad_overlay");
                return null;
            }
        });
    }

    public zzz zzk(final Context context) {
        return (zzz)this.zza(context, false, new zza<zzz>(){

            @Override
            public /* synthetic */ Object zzb(zzx zzx2) throws RemoteException {
                return this.zzd(zzx2);
            }

            public zzz zzd(zzx zzx2) throws RemoteException {
                return zzx2.getMobileAdsSettingsManagerWithClientJarVersion(com.google.android.gms.dynamic.zze.zzac(context), 9877000);
            }

            @Override
            public /* synthetic */ Object zzkh() throws RemoteException {
                return this.zzkj();
            }

            public zzz zzkj() {
                zzz zzz2 = zzl.this.zzbab.zzl(context);
                if (zzz2 != null) {
                    return zzz2;
                }
                zzl.this.zzc(context, "mobile_ads_settings");
                return new zzal();
            }
        });
    }

    @VisibleForTesting
    abstract class zza<T> {
        zza() {
        }

        @Nullable
        protected abstract T zzb(zzx var1) throws RemoteException;

        @Nullable
        protected abstract T zzkh() throws RemoteException;

        @Nullable
        protected final T zzko() {
            zzx zzx2 = zzl.this.zzkf();
            if (zzx2 == null) {
                zzb.zzdi("ClientApi class cannot be loaded.");
                return null;
            }
            try {
                zzx2 = this.zzb(zzx2);
            }
            catch (RemoteException var1_2) {
                zzb.zzc("Cannot invoke local loader using ClientApi class", (Throwable)var1_2);
                return null;
            }
            return (T)zzx2;
        }

        @Nullable
        protected final T zzkp() {
            T t;
            try {
                t = this.zzkh();
            }
            catch (RemoteException var1_2) {
                zzb.zzc("Cannot invoke remote loader", (Throwable)var1_2);
                return null;
            }
            return t;
        }
    }

}

