/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.internal.client.zzai;
import com.google.android.gms.ads.internal.client.zzd;
import com.google.android.gms.ads.internal.client.zze;
import com.google.android.gms.ads.internal.client.zzl;
import com.google.android.gms.ads.internal.reward.client.zzf;
import com.google.android.gms.ads.internal.util.client.zza;
import com.google.android.gms.internal.zzeu;
import com.google.android.gms.internal.zzhx;
import com.google.android.gms.internal.zzim;
import com.google.android.gms.internal.zzji;

@zzji
public class zzm {
    private static final Object zzaox = new Object();
    private static zzm zzbal;
    private final zza zzbam = new zza();
    private final zzl zzban = new zzl(new zze(), new zzd(), new zzai(), new zzeu(), new zzf(), new zzim(), new zzhx());

    static {
        zzm.zza(new zzm());
    }

    protected zzm() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static void zza(zzm zzm2) {
        Object object = zzaox;
        synchronized (object) {
            zzbal = zzm2;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static zzm zzkq() {
        Object object = zzaox;
        synchronized (object) {
            return zzbal;
        }
    }

    public static zza zzkr() {
        return zzm.zzkq().zzbam;
    }

    public static zzl zzks() {
        return zzm.zzkq().zzban;
    }
}

