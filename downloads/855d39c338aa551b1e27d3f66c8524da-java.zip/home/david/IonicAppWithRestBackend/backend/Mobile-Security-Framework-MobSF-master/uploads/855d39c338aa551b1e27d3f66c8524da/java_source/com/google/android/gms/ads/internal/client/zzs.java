/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.ads.internal.client;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.client.zzr;
import com.google.android.gms.ads.internal.client.zzy;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.internal.zzeq;
import com.google.android.gms.internal.zzer;
import com.google.android.gms.internal.zzes;
import com.google.android.gms.internal.zzet;

public interface zzs
extends IInterface {
    public void zza(NativeAdOptionsParcel var1) throws RemoteException;

    public void zza(zzeq var1) throws RemoteException;

    public void zza(zzer var1) throws RemoteException;

    public void zza(String var1, zzet var2, zzes var3) throws RemoteException;

    public void zzb(zzq var1) throws RemoteException;

    public void zzb(zzy var1) throws RemoteException;

    public zzr zzfl() throws RemoteException;

    public static abstract class com.google.android.gms.ads.internal.client.zzs$zza
    extends Binder
    implements zzs {
        public com.google.android.gms.ads.internal.client.zzs$zza() {
            this.attachInterface((IInterface)this, "com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
        }

        public static zzs zzo(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
            if (iInterface != null && iInterface instanceof zzs) {
                return (zzs)iInterface;
            }
            return new zza(iBinder);
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int n, Parcel object, Parcel parcel, int n2) throws RemoteException {
            zzr zzr2 = null;
            Object object2 = null;
            switch (n) {
                default: {
                    return super.onTransact(n, (Parcel)object, parcel, n2);
                }
                case 1598968902: {
                    parcel.writeString("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    return true;
                }
                case 1: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    zzr2 = this.zzfl();
                    parcel.writeNoException();
                    object = object2;
                    if (zzr2 != null) {
                        object = zzr2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 2: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    this.zzb(zzq.zza.zzm(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 3: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    this.zza(zzeq.zza.zzah(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 4: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    this.zza(zzer.zza.zzai(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 5: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    this.zza(object.readString(), zzet.zza.zzak(object.readStrongBinder()), zzes.zza.zzaj(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 6: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    object2 = zzr2;
                    if (object.readInt() != 0) {
                        object2 = (NativeAdOptionsParcel)NativeAdOptionsParcel.CREATOR.createFromParcel((Parcel)object);
                    }
                    this.zza((NativeAdOptionsParcel)object2);
                    parcel.writeNoException();
                    return true;
                }
                case 7: 
            }
            object.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
            this.zzb(zzy.zza.zzt(object.readStrongBinder()));
            parcel.writeNoException();
            return true;
        }

        private static class zza
        implements zzs {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(NativeAdOptionsParcel nativeAdOptionsParcel) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    if (nativeAdOptionsParcel != null) {
                        parcel.writeInt(1);
                        nativeAdOptionsParcel.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(6, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzeq zzeq2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    zzeq2 = zzeq2 != null ? zzeq2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzeq2);
                    this.zzajq.transact(3, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzer zzer2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    zzer2 = zzer2 != null ? zzer2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzer2);
                    this.zzajq.transact(4, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(String string2, zzet zzet2, zzes zzes2) throws RemoteException {
                Object var4_5 = null;
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    parcel.writeString(string2);
                    string2 = zzet2 != null ? zzet2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)string2);
                    string2 = var4_5;
                    if (zzes2 != null) {
                        string2 = zzes2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)string2);
                    this.zzajq.transact(5, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zzb(zzq zzq2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    zzq2 = zzq2 != null ? zzq2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzq2);
                    this.zzajq.transact(2, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zzb(zzy zzy2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    zzy2 = zzy2 != null ? zzy2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzy2);
                    this.zzajq.transact(7, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public zzr zzfl() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
                    this.zzajq.transact(1, parcel, parcel2, 0);
                    parcel2.readException();
                    zzr zzr2 = zzr.zza.zzn(parcel2.readStrongBinder());
                    return zzr2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

