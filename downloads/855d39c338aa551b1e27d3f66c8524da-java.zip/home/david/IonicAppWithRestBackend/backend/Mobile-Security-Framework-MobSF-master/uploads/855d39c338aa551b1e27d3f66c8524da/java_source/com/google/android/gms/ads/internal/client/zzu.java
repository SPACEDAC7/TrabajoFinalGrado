/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.ads.internal.client;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.VideoOptionsParcel;
import com.google.android.gms.ads.internal.client.zzab;
import com.google.android.gms.ads.internal.client.zzp;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.client.zzw;
import com.google.android.gms.ads.internal.client.zzy;
import com.google.android.gms.ads.internal.reward.client.zzd;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.internal.zzed;
import com.google.android.gms.internal.zzig;
import com.google.android.gms.internal.zzik;

public interface zzu
extends IInterface {
    public void destroy() throws RemoteException;

    public String getMediationAdapterClassName() throws RemoteException;

    public boolean isLoading() throws RemoteException;

    public boolean isReady() throws RemoteException;

    public void pause() throws RemoteException;

    public void resume() throws RemoteException;

    public void setManualImpressionsEnabled(boolean var1) throws RemoteException;

    public void setUserId(String var1) throws RemoteException;

    public void showInterstitial() throws RemoteException;

    public void stopLoading() throws RemoteException;

    public void zza(AdSizeParcel var1) throws RemoteException;

    public void zza(VideoOptionsParcel var1) throws RemoteException;

    public void zza(zzp var1) throws RemoteException;

    public void zza(zzq var1) throws RemoteException;

    public void zza(zzw var1) throws RemoteException;

    public void zza(zzy var1) throws RemoteException;

    public void zza(zzd var1) throws RemoteException;

    public void zza(zzed var1) throws RemoteException;

    public void zza(zzig var1) throws RemoteException;

    public void zza(zzik var1, String var2) throws RemoteException;

    public boolean zzb(AdRequestParcel var1) throws RemoteException;

    public com.google.android.gms.dynamic.zzd zzef() throws RemoteException;

    public AdSizeParcel zzeg() throws RemoteException;

    public void zzei() throws RemoteException;

    public zzab zzej() throws RemoteException;

    public static abstract class com.google.android.gms.ads.internal.client.zzu$zza
    extends Binder
    implements zzu {
        public com.google.android.gms.ads.internal.client.zzu$zza() {
            this.attachInterface((IInterface)this, "com.google.android.gms.ads.internal.client.IAdManager");
        }

        public static zzu zzq(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
            if (iInterface != null && iInterface instanceof zzu) {
                return (zzu)iInterface;
            }
            return new zza(iBinder);
        }

        public IBinder asBinder() {
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean onTransact(int n, Parcel object, Parcel parcel, int n2) throws RemoteException {
            zzab zzab2 = null;
            zzab zzab3 = null;
            com.google.android.gms.dynamic.zzd zzd2 = null;
            zzab zzab4 = null;
            Object object2 = null;
            boolean bl = false;
            int n3 = 0;
            int n4 = 0;
            switch (n) {
                default: {
                    return super.onTransact(n, (Parcel)object, parcel, n2);
                }
                case 1598968902: {
                    parcel.writeString("com.google.android.gms.ads.internal.client.IAdManager");
                    return true;
                }
                case 1: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    zzd2 = this.zzef();
                    parcel.writeNoException();
                    object = object2;
                    if (zzd2 != null) {
                        object = zzd2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 2: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.destroy();
                    parcel.writeNoException();
                    return true;
                }
                case 3: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    bl = this.isReady();
                    parcel.writeNoException();
                    n = bl ? 1 : 0;
                    parcel.writeInt(n);
                    return true;
                }
                case 4: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    object2 = zzab2;
                    if (object.readInt() != 0) {
                        object2 = (AdRequestParcel)AdRequestParcel.CREATOR.createFromParcel((Parcel)object);
                    }
                    bl = this.zzb((AdRequestParcel)object2);
                    parcel.writeNoException();
                    n = n4;
                    if (bl) {
                        n = 1;
                    }
                    parcel.writeInt(n);
                    return true;
                }
                case 5: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.pause();
                    parcel.writeNoException();
                    return true;
                }
                case 6: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.resume();
                    parcel.writeNoException();
                    return true;
                }
                case 7: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zza(zzq.zza.zzm(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 8: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zza(zzw.zza.zzs(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 9: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.showInterstitial();
                    parcel.writeNoException();
                    return true;
                }
                case 10: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.stopLoading();
                    parcel.writeNoException();
                    return true;
                }
                case 11: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzei();
                    parcel.writeNoException();
                    return true;
                }
                case 12: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    object = this.zzeg();
                    parcel.writeNoException();
                    if (object != null) {
                        parcel.writeInt(1);
                        object.writeToParcel(parcel, 1);
                        return true;
                    }
                    parcel.writeInt(0);
                    return true;
                }
                case 13: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    object2 = zzab3;
                    if (object.readInt() != 0) {
                        object2 = (AdSizeParcel)AdSizeParcel.CREATOR.createFromParcel((Parcel)object);
                    }
                    this.zza((AdSizeParcel)object2);
                    parcel.writeNoException();
                    return true;
                }
                case 14: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zza(zzig.zza.zzax(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 15: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zza(zzik.zza.zzbb(object.readStrongBinder()), object.readString());
                    parcel.writeNoException();
                    return true;
                }
                case 18: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    object = this.getMediationAdapterClassName();
                    parcel.writeNoException();
                    parcel.writeString((String)object);
                    return true;
                }
                case 19: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zza(zzed.zza.zzaa(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 20: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zza(zzp.zza.zzl(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 21: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zza(zzy.zza.zzt(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 22: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    if (object.readInt() != 0) {
                        bl = true;
                    }
                    this.setManualImpressionsEnabled(bl);
                    parcel.writeNoException();
                    return true;
                }
                case 23: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    bl = this.isLoading();
                    parcel.writeNoException();
                    n = n3;
                    if (bl) {
                        n = 1;
                    }
                    parcel.writeInt(n);
                    return true;
                }
                case 24: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zza(zzd.zza.zzbj(object.readStrongBinder()));
                    parcel.writeNoException();
                    return true;
                }
                case 25: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    this.setUserId(object.readString());
                    parcel.writeNoException();
                    return true;
                }
                case 26: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
                    object2 = this.zzej();
                    parcel.writeNoException();
                    object = zzd2;
                    if (object2 != null) {
                        object = object2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 29: 
            }
            object.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
            object2 = zzab4;
            if (object.readInt() != 0) {
                object2 = (VideoOptionsParcel)VideoOptionsParcel.CREATOR.createFromParcel((Parcel)object);
            }
            this.zza((VideoOptionsParcel)object2);
            parcel.writeNoException();
            return true;
        }

        private static class zza
        implements zzu {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            @Override
            public void destroy() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzajq.transact(2, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public String getMediationAdapterClassName() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzajq.transact(18, parcel, parcel2, 0);
                    parcel2.readException();
                    String string2 = parcel2.readString();
                    return string2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public boolean isLoading() throws RemoteException {
                Parcel parcel;
                Parcel parcel2;
                boolean bl;
                block2 : {
                    bl = false;
                    parcel = Parcel.obtain();
                    parcel2 = Parcel.obtain();
                    try {
                        parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                        this.zzajq.transact(23, parcel, parcel2, 0);
                        parcel2.readException();
                        int n = parcel2.readInt();
                        if (n == 0) break block2;
                        bl = true;
                    }
                    catch (Throwable var5_5) {
                        parcel2.recycle();
                        parcel.recycle();
                        throw var5_5;
                    }
                }
                parcel2.recycle();
                parcel.recycle();
                return bl;
            }

            @Override
            public boolean isReady() throws RemoteException {
                Parcel parcel;
                Parcel parcel2;
                boolean bl;
                block2 : {
                    bl = false;
                    parcel = Parcel.obtain();
                    parcel2 = Parcel.obtain();
                    try {
                        parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                        this.zzajq.transact(3, parcel, parcel2, 0);
                        parcel2.readException();
                        int n = parcel2.readInt();
                        if (n == 0) break block2;
                        bl = true;
                    }
                    catch (Throwable var5_5) {
                        parcel2.recycle();
                        parcel.recycle();
                        throw var5_5;
                    }
                }
                parcel2.recycle();
                parcel.recycle();
                return bl;
            }

            @Override
            public void pause() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzajq.transact(5, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public void resume() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzajq.transact(6, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public void setManualImpressionsEnabled(boolean bl) throws RemoteException {
                int n;
                Parcel parcel;
                Parcel parcel2;
                block4 : {
                    n = 0;
                    parcel2 = Parcel.obtain();
                    parcel = Parcel.obtain();
                    parcel2.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    if (!bl) break block4;
                    n = 1;
                }
                try {
                    parcel2.writeInt(n);
                    this.zzajq.transact(22, parcel2, parcel, 0);
                    parcel.readException();
                    return;
                }
                finally {
                    parcel.recycle();
                    parcel2.recycle();
                }
            }

            @Override
            public void setUserId(String string2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    parcel.writeString(string2);
                    this.zzajq.transact(25, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public void showInterstitial() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzajq.transact(9, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public void stopLoading() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzajq.transact(10, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(AdSizeParcel adSizeParcel) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    if (adSizeParcel != null) {
                        parcel.writeInt(1);
                        adSizeParcel.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(13, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(VideoOptionsParcel videoOptionsParcel) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    if (videoOptionsParcel != null) {
                        parcel.writeInt(1);
                        videoOptionsParcel.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(29, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzp zzp2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    zzp2 = zzp2 != null ? zzp2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzp2);
                    this.zzajq.transact(20, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzq zzq2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    zzq2 = zzq2 != null ? zzq2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzq2);
                    this.zzajq.transact(7, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzw zzw2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    zzw2 = zzw2 != null ? zzw2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzw2);
                    this.zzajq.transact(8, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzy zzy2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    zzy2 = zzy2 != null ? zzy2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzy2);
                    this.zzajq.transact(21, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzd zzd2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    zzd2 = zzd2 != null ? zzd2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzd2);
                    this.zzajq.transact(24, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzed zzed2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    zzed2 = zzed2 != null ? zzed2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzed2);
                    this.zzajq.transact(19, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzig zzig2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    zzig2 = zzig2 != null ? zzig2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzig2);
                    this.zzajq.transact(14, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzik zzik2, String string2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    zzik2 = zzik2 != null ? zzik2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzik2);
                    parcel.writeString(string2);
                    this.zzajq.transact(15, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public boolean zzb(AdRequestParcel adRequestParcel) throws RemoteException {
                boolean bl;
                Parcel parcel;
                Parcel parcel2;
                block6 : {
                    block5 : {
                        bl = true;
                        parcel = Parcel.obtain();
                        parcel2 = Parcel.obtain();
                        try {
                            parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                            if (adRequestParcel != null) {
                                parcel.writeInt(1);
                                adRequestParcel.writeToParcel(parcel, 0);
                            } else {
                                parcel.writeInt(0);
                            }
                            this.zzajq.transact(4, parcel, parcel2, 0);
                            parcel2.readException();
                            int n = parcel2.readInt();
                            if (n == 0) break block5;
                            break block6;
                        }
                        catch (Throwable var1_2) {
                            parcel2.recycle();
                            parcel.recycle();
                            throw var1_2;
                        }
                    }
                    bl = false;
                }
                parcel2.recycle();
                parcel.recycle();
                return bl;
            }

            @Override
            public com.google.android.gms.dynamic.zzd zzef() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzajq.transact(1, parcel, parcel2, 0);
                    parcel2.readException();
                    com.google.android.gms.dynamic.zzd zzd2 = zzd.zza.zzfd(parcel2.readStrongBinder());
                    return zzd2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public AdSizeParcel zzeg() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzajq.transact(12, parcel, parcel2, 0);
                    parcel2.readException();
                    AdSizeParcel adSizeParcel = parcel2.readInt() != 0 ? (AdSizeParcel)AdSizeParcel.CREATOR.createFromParcel(parcel2) : null;
                    return adSizeParcel;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public void zzei() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzajq.transact(11, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public zzab zzej() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
                    this.zzajq.transact(26, parcel, parcel2, 0);
                    parcel2.readException();
                    zzab zzab2 = zzab.zza.zzw(parcel2.readStrongBinder());
                    return zzab2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

