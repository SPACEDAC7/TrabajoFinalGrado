/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.ads.internal.client;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.zzs;
import com.google.android.gms.ads.internal.client.zzu;
import com.google.android.gms.ads.internal.client.zzz;
import com.google.android.gms.ads.internal.reward.client.zzb;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.internal.zzei;
import com.google.android.gms.internal.zzgz;
import com.google.android.gms.internal.zzhy;
import com.google.android.gms.internal.zzih;

public interface zzx
extends IInterface {
    public zzs createAdLoaderBuilder(zzd var1, String var2, zzgz var3, int var4) throws RemoteException;

    public zzhy createAdOverlay(zzd var1) throws RemoteException;

    public zzu createBannerAdManager(zzd var1, AdSizeParcel var2, String var3, zzgz var4, int var5) throws RemoteException;

    public zzih createInAppPurchaseManager(zzd var1) throws RemoteException;

    public zzu createInterstitialAdManager(zzd var1, AdSizeParcel var2, String var3, zzgz var4, int var5) throws RemoteException;

    public zzei createNativeAdViewDelegate(zzd var1, zzd var2) throws RemoteException;

    public zzb createRewardedVideoAd(zzd var1, zzgz var2, int var3) throws RemoteException;

    public zzu createSearchAdManager(zzd var1, AdSizeParcel var2, String var3, int var4) throws RemoteException;

    public zzz getMobileAdsSettingsManager(zzd var1) throws RemoteException;

    public zzz getMobileAdsSettingsManagerWithClientJarVersion(zzd var1, int var2) throws RemoteException;

    public static abstract class com.google.android.gms.ads.internal.client.zzx$zza
    extends Binder
    implements zzx {
        public com.google.android.gms.ads.internal.client.zzx$zza() {
            this.attachInterface((IInterface)this, "com.google.android.gms.ads.internal.client.IClientApi");
        }

        public static zzx asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IClientApi");
            if (iInterface != null && iInterface instanceof zzx) {
                return (zzx)iInterface;
            }
            return new zza(iBinder);
        }

        public IBinder asBinder() {
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean onTransact(int n, Parcel object, Parcel parcel, int n2) throws RemoteException {
            zzd zzd2 = null;
            Object object2 = null;
            Object var9_7 = null;
            Object var10_8 = null;
            Object var11_9 = null;
            Object var12_10 = null;
            Object var13_11 = null;
            Object var14_12 = null;
            Object var8_13 = null;
            Object var6_14 = null;
            switch (n) {
                default: {
                    return super.onTransact(n, (Parcel)object, parcel, n2);
                }
                case 1598968902: {
                    parcel.writeString("com.google.android.gms.ads.internal.client.IClientApi");
                    return true;
                }
                case 1: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IClientApi");
                    zzd2 = zzd.zza.zzfd(object.readStrongBinder());
                    object2 = object.readInt() != 0 ? (AdSizeParcel)AdSizeParcel.CREATOR.createFromParcel((Parcel)object) : null;
                    object2 = this.createBannerAdManager(zzd2, (AdSizeParcel)object2, object.readString(), zzgz.zza.zzam(object.readStrongBinder()), object.readInt());
                    parcel.writeNoException();
                    object = var6_14;
                    if (object2 != null) {
                        object = object2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 2: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IClientApi");
                    zzd zzd3 = zzd.zza.zzfd(object.readStrongBinder());
                    object2 = object.readInt() != 0 ? (AdSizeParcel)AdSizeParcel.CREATOR.createFromParcel((Parcel)object) : null;
                    object2 = this.createInterstitialAdManager(zzd3, (AdSizeParcel)object2, object.readString(), zzgz.zza.zzam(object.readStrongBinder()), object.readInt());
                    parcel.writeNoException();
                    object = zzd2;
                    if (object2 != null) {
                        object = object2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 3: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IClientApi");
                    zzs zzs2 = this.createAdLoaderBuilder(zzd.zza.zzfd(object.readStrongBinder()), object.readString(), zzgz.zza.zzam(object.readStrongBinder()), object.readInt());
                    parcel.writeNoException();
                    object = object2;
                    if (zzs2 != null) {
                        object = zzs2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 4: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IClientApi");
                    object2 = this.getMobileAdsSettingsManager(zzd.zza.zzfd(object.readStrongBinder()));
                    parcel.writeNoException();
                    object = var9_7;
                    if (object2 != null) {
                        object = object2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 5: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IClientApi");
                    object2 = this.createNativeAdViewDelegate(zzd.zza.zzfd(object.readStrongBinder()), zzd.zza.zzfd(object.readStrongBinder()));
                    parcel.writeNoException();
                    object = var10_8;
                    if (object2 != null) {
                        object = object2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 6: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IClientApi");
                    object2 = this.createRewardedVideoAd(zzd.zza.zzfd(object.readStrongBinder()), zzgz.zza.zzam(object.readStrongBinder()), object.readInt());
                    parcel.writeNoException();
                    object = var11_9;
                    if (object2 != null) {
                        object = object2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 7: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IClientApi");
                    object2 = this.createInAppPurchaseManager(zzd.zza.zzfd(object.readStrongBinder()));
                    parcel.writeNoException();
                    object = var12_10;
                    if (object2 != null) {
                        object = object2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 8: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IClientApi");
                    object2 = this.createAdOverlay(zzd.zza.zzfd(object.readStrongBinder()));
                    parcel.writeNoException();
                    object = var13_11;
                    if (object2 != null) {
                        object = object2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 9: {
                    object.enforceInterface("com.google.android.gms.ads.internal.client.IClientApi");
                    object2 = this.getMobileAdsSettingsManagerWithClientJarVersion(zzd.zza.zzfd(object.readStrongBinder()), object.readInt());
                    parcel.writeNoException();
                    object = var14_12;
                    if (object2 != null) {
                        object = object2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 10: 
            }
            object.enforceInterface("com.google.android.gms.ads.internal.client.IClientApi");
            zzd zzd4 = zzd.zza.zzfd(object.readStrongBinder());
            object2 = object.readInt() != 0 ? (AdSizeParcel)AdSizeParcel.CREATOR.createFromParcel((Parcel)object) : null;
            object2 = this.createSearchAdManager(zzd4, (AdSizeParcel)object2, object.readString(), object.readInt());
            parcel.writeNoException();
            object = var8_13;
            if (object2 != null) {
                object = object2.asBinder();
            }
            parcel.writeStrongBinder((IBinder)object);
            return true;
        }

        private static class zza
        implements zzx {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzs createAdLoaderBuilder(zzd object, String string2, zzgz zzgz2, int n) throws RemoteException {
                Object var5_13 = null;
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    void var3_11;
                    void var1_3;
                    void var4_12;
                    void var1_6;
                    void var2_10;
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IClientApi");
                    if (object != null) {
                        IBinder iBinder = object.asBinder();
                    } else {
                        Object var1_8 = null;
                    }
                    parcel.writeStrongBinder((IBinder)var1_3);
                    parcel.writeString((String)var2_10);
                    Object var1_4 = var5_13;
                    if (var3_11 != null) {
                        IBinder iBinder = var3_11.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)var1_6);
                    parcel.writeInt((int)var4_12);
                    this.zzajq.transact(3, parcel, parcel2, 0);
                    parcel2.readException();
                    zzs zzs2 = zzs.zza.zzo(parcel2.readStrongBinder());
                    return zzs2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzhy createAdOverlay(zzd object) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    void var1_3;
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IClientApi");
                    if (object != null) {
                        IBinder iBinder = object.asBinder();
                    } else {
                        Object var1_5 = null;
                    }
                    parcel.writeStrongBinder((IBinder)var1_3);
                    this.zzajq.transact(8, parcel, parcel2, 0);
                    parcel2.readException();
                    zzhy zzhy2 = zzhy.zza.zzat(parcel2.readStrongBinder());
                    return zzhy2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzu createBannerAdManager(zzd object, AdSizeParcel adSizeParcel, String string2, zzgz zzgz2, int n) throws RemoteException {
                Object var6_7 = null;
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IClientApi");
                    object = object != null ? object.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)object);
                    if (adSizeParcel != null) {
                        parcel.writeInt(1);
                        adSizeParcel.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    parcel.writeString(string2);
                    object = var6_7;
                    if (zzgz2 != null) {
                        object = zzgz2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    parcel.writeInt(n);
                    this.zzajq.transact(1, parcel, parcel2, 0);
                    parcel2.readException();
                    object = zzu.zza.zzq(parcel2.readStrongBinder());
                    return object;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzih createInAppPurchaseManager(zzd object) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    void var1_3;
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IClientApi");
                    if (object != null) {
                        IBinder iBinder = object.asBinder();
                    } else {
                        Object var1_5 = null;
                    }
                    parcel.writeStrongBinder((IBinder)var1_3);
                    this.zzajq.transact(7, parcel, parcel2, 0);
                    parcel2.readException();
                    zzih zzih2 = zzih.zza.zzay(parcel2.readStrongBinder());
                    return zzih2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzu createInterstitialAdManager(zzd object, AdSizeParcel adSizeParcel, String string2, zzgz zzgz2, int n) throws RemoteException {
                Object var6_7 = null;
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IClientApi");
                    object = object != null ? object.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)object);
                    if (adSizeParcel != null) {
                        parcel.writeInt(1);
                        adSizeParcel.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    parcel.writeString(string2);
                    object = var6_7;
                    if (zzgz2 != null) {
                        object = zzgz2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    parcel.writeInt(n);
                    this.zzajq.transact(2, parcel, parcel2, 0);
                    parcel2.readException();
                    object = zzu.zza.zzq(parcel2.readStrongBinder());
                    return object;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzei createNativeAdViewDelegate(zzd object, zzd zzd2) throws RemoteException {
                Object var3_11 = null;
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    void var1_6;
                    void var2_10;
                    void var1_3;
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IClientApi");
                    if (object != null) {
                        IBinder iBinder = object.asBinder();
                    } else {
                        Object var1_8 = null;
                    }
                    parcel.writeStrongBinder((IBinder)var1_3);
                    Object var1_4 = var3_11;
                    if (var2_10 != null) {
                        IBinder iBinder = var2_10.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)var1_6);
                    this.zzajq.transact(5, parcel, parcel2, 0);
                    parcel2.readException();
                    zzei zzei2 = zzei.zza.zzac(parcel2.readStrongBinder());
                    return zzei2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzb createRewardedVideoAd(zzd object, zzgz zzgz2, int n) throws RemoteException {
                Object var4_12 = null;
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    void var3_11;
                    void var1_6;
                    void var2_10;
                    void var1_3;
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IClientApi");
                    if (object != null) {
                        IBinder iBinder = object.asBinder();
                    } else {
                        Object var1_8 = null;
                    }
                    parcel.writeStrongBinder((IBinder)var1_3);
                    Object var1_4 = var4_12;
                    if (var2_10 != null) {
                        IBinder iBinder = var2_10.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)var1_6);
                    parcel.writeInt((int)var3_11);
                    this.zzajq.transact(6, parcel, parcel2, 0);
                    parcel2.readException();
                    zzb zzb2 = zzb.zza.zzbh(parcel2.readStrongBinder());
                    return zzb2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzu createSearchAdManager(zzd object, AdSizeParcel adSizeParcel, String string2, int n) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    void var3_9;
                    void var2_8;
                    void var4_10;
                    void var1_3;
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IClientApi");
                    if (object != null) {
                        IBinder iBinder = object.asBinder();
                    } else {
                        Object var1_5 = null;
                    }
                    parcel.writeStrongBinder((IBinder)var1_3);
                    if (var2_8 != null) {
                        parcel.writeInt(1);
                        var2_8.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    parcel.writeString((String)var3_9);
                    parcel.writeInt((int)var4_10);
                    this.zzajq.transact(10, parcel, parcel2, 0);
                    parcel2.readException();
                    zzu zzu2 = zzu.zza.zzq(parcel2.readStrongBinder());
                    return zzu2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzz getMobileAdsSettingsManager(zzd object) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    void var1_3;
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IClientApi");
                    if (object != null) {
                        IBinder iBinder = object.asBinder();
                    } else {
                        Object var1_5 = null;
                    }
                    parcel.writeStrongBinder((IBinder)var1_3);
                    this.zzajq.transact(4, parcel, parcel2, 0);
                    parcel2.readException();
                    zzz zzz2 = zzz.zza.zzu(parcel2.readStrongBinder());
                    return zzz2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzz getMobileAdsSettingsManagerWithClientJarVersion(zzd object, int n) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    void var1_3;
                    void var2_7;
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.client.IClientApi");
                    if (object != null) {
                        IBinder iBinder = object.asBinder();
                    } else {
                        Object var1_5 = null;
                    }
                    parcel.writeStrongBinder((IBinder)var1_3);
                    parcel.writeInt((int)var2_7);
                    this.zzajq.transact(9, parcel, parcel2, 0);
                    parcel2.readException();
                    zzz zzz2 = zzz.zza.zzu(parcel2.readStrongBinder());
                    return zzz2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

