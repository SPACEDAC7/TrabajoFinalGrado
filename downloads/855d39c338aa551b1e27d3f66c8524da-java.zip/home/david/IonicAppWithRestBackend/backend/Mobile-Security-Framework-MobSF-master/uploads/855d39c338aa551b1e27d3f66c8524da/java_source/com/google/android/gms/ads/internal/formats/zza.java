/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  android.graphics.drawable.Drawable
 */
package com.google.android.gms.ads.internal.formats;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import com.google.android.gms.internal.zzji;
import java.util.List;

@zzji
public class zza {
    private static final int zzbmk = Color.rgb((int)12, (int)174, (int)206);
    private static final int zzbml;
    static final int zzbmm;
    static final int zzbmn;
    private final int mBackgroundColor;
    private final int mTextColor;
    private final String zzbmo;
    private final List<Drawable> zzbmp;
    private final int zzbmq;
    private final int zzbmr;
    private final int zzbms;

    static {
        zzbmm = zza.zzbml = Color.rgb((int)204, (int)204, (int)204);
        zzbmn = zzbmk;
    }

    /*
     * Enabled aggressive block sorting
     */
    public zza(String string2, List<Drawable> list, Integer n, Integer n2, Integer n3, int n4, int n5) {
        this.zzbmo = string2;
        this.zzbmp = list;
        int n6 = n != null ? n : zzbmm;
        this.mBackgroundColor = n6;
        n6 = n2 != null ? n2 : zzbmn;
        this.mTextColor = n6;
        n6 = n3 != null ? n3 : 12;
        this.zzbmq = n6;
        this.zzbmr = n4;
        this.zzbms = n5;
    }

    public int getBackgroundColor() {
        return this.mBackgroundColor;
    }

    public String getText() {
        return this.zzbmo;
    }

    public int getTextColor() {
        return this.mTextColor;
    }

    public int getTextSize() {
        return this.zzbmq;
    }

    public List<Drawable> zzmj() {
        return this.zzbmp;
    }

    public int zzmk() {
        return this.zzbmr;
    }

    public int zzml() {
        return this.zzbms;
    }
}

