/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  android.graphics.Typeface
 *  android.graphics.drawable.AnimationDrawable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.ShapeDrawable
 *  android.graphics.drawable.shapes.RoundRectShape
 *  android.graphics.drawable.shapes.Shape
 *  android.text.TextUtils
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 */
package com.google.android.gms.ads.internal.formats;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.formats.zza;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzji;
import java.util.Iterator;
import java.util.List;

@zzji
class zzb
extends RelativeLayout {
    private static final float[] zzbmt = new float[]{5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f};
    private final RelativeLayout zzbmu;
    @Nullable
    private AnimationDrawable zzbmv;

    /*
     * Enabled aggressive block sorting
     */
    public zzb(Context context, zza zza2) {
        super(context);
        zzaa.zzy(zza2);
        Iterator iterator = new RelativeLayout.LayoutParams(-2, -2);
        switch (zza2.zzml()) {
            default: {
                iterator.addRule(10);
                iterator.addRule(11);
                break;
            }
            case 0: {
                iterator.addRule(10);
                iterator.addRule(9);
                break;
            }
            case 3: {
                iterator.addRule(12);
                iterator.addRule(9);
                break;
            }
            case 2: {
                iterator.addRule(12);
                iterator.addRule(11);
            }
        }
        ShapeDrawable shapeDrawable = new ShapeDrawable((Shape)new RoundRectShape(zzbmt, null, null));
        shapeDrawable.getPaint().setColor(zza2.getBackgroundColor());
        this.zzbmu = new RelativeLayout(context);
        this.zzbmu.setLayoutParams((ViewGroup.LayoutParams)iterator);
        zzu.zzgo().zza((View)this.zzbmu, (Drawable)shapeDrawable);
        iterator = new RelativeLayout.LayoutParams(-2, -2);
        if (!TextUtils.isEmpty((CharSequence)zza2.getText())) {
            shapeDrawable = new RelativeLayout.LayoutParams(-2, -2);
            TextView textView = new TextView(context);
            textView.setLayoutParams((ViewGroup.LayoutParams)shapeDrawable);
            textView.setId(1195835393);
            textView.setTypeface(Typeface.DEFAULT);
            textView.setText((CharSequence)zza2.getText());
            textView.setTextColor(zza2.getTextColor());
            textView.setTextSize((float)zza2.getTextSize());
            textView.setPadding(zzm.zzkr().zzb(context, 4), 0, zzm.zzkr().zzb(context, 4), 0);
            this.zzbmu.addView((View)textView);
            iterator.addRule(1, textView.getId());
        }
        context = new ImageView(context);
        context.setLayoutParams((ViewGroup.LayoutParams)iterator);
        context.setId(1195835394);
        iterator = zza2.zzmj();
        if (iterator.size() > 1) {
            this.zzbmv = new AnimationDrawable();
            iterator = iterator.iterator();
            while (iterator.hasNext()) {
                shapeDrawable = (Drawable)iterator.next();
                this.zzbmv.addFrame((Drawable)shapeDrawable, zza2.zzmk());
            }
            zzu.zzgo().zza((View)context, (Drawable)this.zzbmv);
        } else if (iterator.size() == 1) {
            context.setImageDrawable((Drawable)iterator.get(0));
        }
        this.zzbmu.addView((View)context);
        this.addView((View)this.zzbmu);
    }

    public void onAttachedToWindow() {
        if (this.zzbmv != null) {
            this.zzbmv.start();
        }
        super.onAttachedToWindow();
    }

    public ViewGroup zzmm() {
        return this.zzbmu;
    }
}

