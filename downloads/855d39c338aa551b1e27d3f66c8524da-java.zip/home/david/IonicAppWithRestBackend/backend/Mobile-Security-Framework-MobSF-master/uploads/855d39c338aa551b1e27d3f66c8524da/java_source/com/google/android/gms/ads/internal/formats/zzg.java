/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.MotionEvent
 */
package com.google.android.gms.ads.internal.formats;

import android.view.MotionEvent;

public interface zzg {
    public void zzc(MotionEvent var1);

    public void zzmu();
}

