/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.MotionEvent
 *  android.view.View
 *  org.json.JSONObject
 */
package com.google.android.gms.ads.internal.formats;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import java.lang.ref.WeakReference;
import java.util.Map;
import org.json.JSONObject;

public interface zzi {
    public Context getContext();

    public void zza(View var1, String var2, JSONObject var3, Map<String, WeakReference<View>> var4, View var5);

    public void zza(View var1, Map<String, WeakReference<View>> var2, JSONObject var3, View var4);

    public void zzb(View var1, Map<String, WeakReference<View>> var2);

    public void zzc(View var1, Map<String, WeakReference<View>> var2);

    public void zzd(MotionEvent var1);

    public void zzd(View var1, Map<String, WeakReference<View>> var2);

    public void zzj(View var1);

    public View zzmy();

    public static interface zza {
        public String getCustomTemplateId();

        public void zzb(zzi var1);

        public String zzmq();

        public com.google.android.gms.ads.internal.formats.zza zzmr();
    }

}

