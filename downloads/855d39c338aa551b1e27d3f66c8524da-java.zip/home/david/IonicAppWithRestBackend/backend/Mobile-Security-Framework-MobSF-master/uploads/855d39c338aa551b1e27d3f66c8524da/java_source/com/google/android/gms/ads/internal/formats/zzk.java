/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.formats;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.VideoOptionsParcel;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzk
implements Parcelable.Creator<NativeAdOptionsParcel> {
    static void zza(NativeAdOptionsParcel nativeAdOptionsParcel, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, nativeAdOptionsParcel.versionCode);
        zzb.zza(parcel, 2, nativeAdOptionsParcel.zzboj);
        zzb.zzc(parcel, 3, nativeAdOptionsParcel.zzbok);
        zzb.zza(parcel, 4, nativeAdOptionsParcel.zzbol);
        zzb.zzc(parcel, 5, nativeAdOptionsParcel.zzbom);
        zzb.zza(parcel, 6, nativeAdOptionsParcel.zzbon, n, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzi(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzac(n);
    }

    public NativeAdOptionsParcel[] zzac(int n) {
        return new NativeAdOptionsParcel[n];
    }

    public NativeAdOptionsParcel zzi(Parcel parcel) {
        int n = 0;
        int n2 = zza.zzcr(parcel);
        VideoOptionsParcel videoOptionsParcel = null;
        boolean bl = false;
        int n3 = 0;
        boolean bl2 = false;
        int n4 = 0;
        block8 : while (parcel.dataPosition() < n2) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block8;
                }
                case 1: {
                    n4 = zza.zzg(parcel, n5);
                    continue block8;
                }
                case 2: {
                    bl2 = zza.zzc(parcel, n5);
                    continue block8;
                }
                case 3: {
                    n3 = zza.zzg(parcel, n5);
                    continue block8;
                }
                case 4: {
                    bl = zza.zzc(parcel, n5);
                    continue block8;
                }
                case 5: {
                    n = zza.zzg(parcel, n5);
                    continue block8;
                }
                case 6: 
            }
            videoOptionsParcel = zza.zza(parcel, n5, VideoOptionsParcel.CREATOR);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new NativeAdOptionsParcel(n4, bl2, n3, bl, n, videoOptionsParcel);
    }
}

