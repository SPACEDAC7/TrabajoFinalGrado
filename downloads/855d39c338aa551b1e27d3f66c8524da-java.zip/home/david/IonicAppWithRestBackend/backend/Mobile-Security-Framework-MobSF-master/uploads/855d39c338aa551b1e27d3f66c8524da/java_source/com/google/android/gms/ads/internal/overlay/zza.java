/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.text.TextUtils
 */
package com.google.android.gms.ads.internal.overlay;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.overlay.AdLauncherIntentInfoParcel;
import com.google.android.gms.ads.internal.overlay.zzp;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;

@zzji
public class zza {
    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean zza(Context context, Intent intent, zzp zzp2) {
        try {
            String string2 = String.valueOf(intent.toURI());
            string2 = string2.length() != 0 ? "Launching an intent: ".concat(string2) : new String("Launching an intent: ");
            zzkx.v(string2);
            zzu.zzgm().zzb(context, intent);
            if (zzp2 == null) return true;
            zzp2.zzeh();
            return true;
        }
        catch (ActivityNotFoundException var1_2) {
            zzkx.zzdi(var1_2.getMessage());
            return false;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean zza(Context object, AdLauncherIntentInfoParcel object2, zzp zzp2) {
        if (object2 == null) {
            zzkx.zzdi("No intent data for launcher overlay.");
            return false;
        }
        if (object2.intent != null) {
            return this.zza((Context)object, object2.intent, zzp2);
        }
        Intent intent = new Intent();
        if (TextUtils.isEmpty((CharSequence)object2.url)) {
            zzkx.zzdi("Open GMSG did not contain a URL.");
            return false;
        }
        if (!TextUtils.isEmpty((CharSequence)object2.mimeType)) {
            intent.setDataAndType(Uri.parse((String)object2.url), object2.mimeType);
        } else {
            intent.setData(Uri.parse((String)object2.url));
        }
        intent.setAction("android.intent.action.VIEW");
        if (!TextUtils.isEmpty((CharSequence)object2.packageName)) {
            intent.setPackage(object2.packageName);
        }
        if (!TextUtils.isEmpty((CharSequence)object2.zzbzm)) {
            String[] arrstring = object2.zzbzm.split("/", 2);
            if (arrstring.length < 2) {
                object = String.valueOf(object2.zzbzm);
                object = object.length() != 0 ? "Could not parse component name from open GMSG: ".concat((String)object) : new String("Could not parse component name from open GMSG: ");
                zzkx.zzdi((String)object);
                return false;
            }
            intent.setClassName(arrstring[0], arrstring[1]);
        }
        if (!TextUtils.isEmpty((CharSequence)(object2 = object2.zzbzn))) {
            int n;
            try {
                n = Integer.parseInt((String)object2);
            }
            catch (NumberFormatException var2_3) {
                zzkx.zzdi("Could not parse intent flags.");
                n = 0;
            }
            intent.addFlags(n);
        }
        return this.zza((Context)object, intent, zzp2);
    }
}

