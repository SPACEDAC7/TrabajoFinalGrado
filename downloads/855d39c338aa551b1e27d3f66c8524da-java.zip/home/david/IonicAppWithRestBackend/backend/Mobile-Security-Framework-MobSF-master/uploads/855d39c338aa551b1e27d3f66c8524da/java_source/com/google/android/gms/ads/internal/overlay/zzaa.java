/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.media.AudioManager
 *  android.media.AudioManager$OnAudioFocusChangeListener
 */
package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.content.Context;
import android.media.AudioManager;
import com.google.android.gms.internal.zzji;

@zzji
@TargetApi(value=14)
public class zzaa
implements AudioManager.OnAudioFocusChangeListener {
    private final AudioManager mAudioManager;
    private boolean zzccd;
    private final zza zzceq;
    private boolean zzcer;
    private boolean zzces;
    private float zzcet = 1.0f;

    public zzaa(Context context, zza zza2) {
        this.mAudioManager = (AudioManager)context.getSystemService("audio");
        this.zzceq = zza2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zzri() {
        boolean bl = this.zzccd && !this.zzces && this.zzcet > 0.0f;
        if (bl) {
            if (this.zzcer) return;
            this.zzrj();
            this.zzceq.zzpk();
            return;
        } else {
            if (bl) return;
            {
                if (!this.zzcer) return;
                this.zzrk();
                this.zzceq.zzpk();
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zzrj() {
        boolean bl = true;
        if (this.mAudioManager == null) return;
        if (this.zzcer) {
            return;
        }
        if (this.mAudioManager.requestAudioFocus((AudioManager.OnAudioFocusChangeListener)this, 3, 2) != 1) {
            bl = false;
        }
        this.zzcer = bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zzrk() {
        if (this.mAudioManager == null || !this.zzcer) {
            return;
        }
        boolean bl = this.mAudioManager.abandonAudioFocus((AudioManager.OnAudioFocusChangeListener)this) == 0;
        this.zzcer = bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onAudioFocusChange(int n) {
        boolean bl = n > 0;
        this.zzcer = bl;
        this.zzceq.zzpk();
    }

    public void setMuted(boolean bl) {
        this.zzces = bl;
        this.zzri();
    }

    public void zzb(float f) {
        this.zzcet = f;
        this.zzri();
    }

    public void zzre() {
        this.zzccd = true;
        this.zzri();
    }

    public void zzrf() {
        this.zzccd = false;
        this.zzri();
    }

    /*
     * Enabled aggressive block sorting
     */
    public float zzrh() {
        float f = this.zzces ? 0.0f : this.zzcet;
        if (!this.zzcer) return 0.0f;
        return f;
    }

    static interface zza {
        public void zzpk();
    }

}

