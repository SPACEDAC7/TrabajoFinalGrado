/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.overlay.AdLauncherIntentInfoParcel;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zzb
implements Parcelable.Creator<AdLauncherIntentInfoParcel> {
    static void zza(AdLauncherIntentInfoParcel adLauncherIntentInfoParcel, Parcel parcel, int n) {
        int n2 = com.google.android.gms.common.internal.safeparcel.zzb.zzcs(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1, adLauncherIntentInfoParcel.versionCode);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 2, adLauncherIntentInfoParcel.zzbzl, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 3, adLauncherIntentInfoParcel.url, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 4, adLauncherIntentInfoParcel.mimeType, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 5, adLauncherIntentInfoParcel.packageName, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 6, adLauncherIntentInfoParcel.zzbzm, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 7, adLauncherIntentInfoParcel.zzbzn, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 8, adLauncherIntentInfoParcel.zzbzo, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 9, (Parcelable)adLauncherIntentInfoParcel.intent, n, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzj(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzah(n);
    }

    public AdLauncherIntentInfoParcel[] zzah(int n) {
        return new AdLauncherIntentInfoParcel[n];
    }

    public AdLauncherIntentInfoParcel zzj(Parcel parcel) {
        Intent intent = null;
        int n = zza.zzcr(parcel);
        int n2 = 0;
        String string2 = null;
        String string3 = null;
        String string4 = null;
        String string5 = null;
        String string6 = null;
        String string7 = null;
        String string8 = null;
        block11 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block11;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block11;
                }
                case 2: {
                    string8 = zza.zzq(parcel, n3);
                    continue block11;
                }
                case 3: {
                    string7 = zza.zzq(parcel, n3);
                    continue block11;
                }
                case 4: {
                    string6 = zza.zzq(parcel, n3);
                    continue block11;
                }
                case 5: {
                    string5 = zza.zzq(parcel, n3);
                    continue block11;
                }
                case 6: {
                    string4 = zza.zzq(parcel, n3);
                    continue block11;
                }
                case 7: {
                    string3 = zza.zzq(parcel, n3);
                    continue block11;
                }
                case 8: {
                    string2 = zza.zzq(parcel, n3);
                    continue block11;
                }
                case 9: 
            }
            intent = (Intent)zza.zza(parcel, n3, Intent.CREATOR);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new AdLauncherIntentInfoParcel(n2, string8, string7, string6, string5, string4, string3, string2, intent);
    }
}

