/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 */
package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.overlay.AdLauncherIntentInfoParcel;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.internal.overlay.zzg;
import com.google.android.gms.ads.internal.overlay.zzp;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.util.zzs;
import com.google.android.gms.internal.zzji;

@zzji
public class zze {
    public void zza(Context context, AdOverlayInfoParcel adOverlayInfoParcel) {
        this.zza(context, adOverlayInfoParcel, true);
    }

    public void zza(Context context, AdOverlayInfoParcel adOverlayInfoParcel, boolean bl) {
        if (adOverlayInfoParcel.zzcbs == 4 && adOverlayInfoParcel.zzcbl == null) {
            if (adOverlayInfoParcel.zzcbk != null) {
                adOverlayInfoParcel.zzcbk.onAdClicked();
            }
            zzu.zzgj().zza(context, adOverlayInfoParcel.zzcbj, adOverlayInfoParcel.zzcbr);
            return;
        }
        Intent intent = new Intent();
        intent.setClassName(context, "com.google.android.gms.ads.AdActivity");
        intent.putExtra("com.google.android.gms.ads.internal.overlay.useClientJar", adOverlayInfoParcel.zzari.zzcyc);
        intent.putExtra("shouldCallOnOverlayOpened", bl);
        AdOverlayInfoParcel.zza(intent, adOverlayInfoParcel);
        if (!zzs.zzayw()) {
            intent.addFlags(524288);
        }
        if (!(context instanceof Activity)) {
            intent.addFlags(268435456);
        }
        zzu.zzgm().zzb(context, intent);
    }
}

