/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.overlay;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.InterstitialAdParameterParcel;
import com.google.android.gms.ads.internal.overlay.AdLauncherIntentInfoParcel;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzf
implements Parcelable.Creator<AdOverlayInfoParcel> {
    static void zza(AdOverlayInfoParcel adOverlayInfoParcel, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, adOverlayInfoParcel.versionCode);
        zzb.zza(parcel, 2, adOverlayInfoParcel.zzcbj, n, false);
        zzb.zza(parcel, 3, adOverlayInfoParcel.zzpv(), false);
        zzb.zza(parcel, 4, adOverlayInfoParcel.zzpw(), false);
        zzb.zza(parcel, 5, adOverlayInfoParcel.zzpx(), false);
        zzb.zza(parcel, 6, adOverlayInfoParcel.zzpy(), false);
        zzb.zza(parcel, 7, adOverlayInfoParcel.zzcbo, false);
        zzb.zza(parcel, 8, adOverlayInfoParcel.zzcbp);
        zzb.zza(parcel, 9, adOverlayInfoParcel.zzcbq, false);
        zzb.zza(parcel, 10, adOverlayInfoParcel.zzqa(), false);
        zzb.zzc(parcel, 11, adOverlayInfoParcel.orientation);
        zzb.zzc(parcel, 12, adOverlayInfoParcel.zzcbs);
        zzb.zza(parcel, 13, adOverlayInfoParcel.url, false);
        zzb.zza(parcel, 14, adOverlayInfoParcel.zzari, n, false);
        zzb.zza(parcel, 15, adOverlayInfoParcel.zzpz(), false);
        zzb.zza(parcel, 16, adOverlayInfoParcel.zzcbu, false);
        zzb.zza(parcel, 17, adOverlayInfoParcel.zzcbv, n, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzk(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzal(n);
    }

    public AdOverlayInfoParcel[] zzal(int n) {
        return new AdOverlayInfoParcel[n];
    }

    public AdOverlayInfoParcel zzk(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        AdLauncherIntentInfoParcel adLauncherIntentInfoParcel = null;
        IBinder iBinder = null;
        IBinder iBinder2 = null;
        IBinder iBinder3 = null;
        IBinder iBinder4 = null;
        String string2 = null;
        boolean bl = false;
        String string3 = null;
        IBinder iBinder5 = null;
        int n3 = 0;
        int n4 = 0;
        String string4 = null;
        VersionInfoParcel versionInfoParcel = null;
        IBinder iBinder6 = null;
        String string5 = null;
        InterstitialAdParameterParcel interstitialAdParameterParcel = null;
        block19 : while (parcel.dataPosition() < n) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block19;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n5);
                    continue block19;
                }
                case 2: {
                    adLauncherIntentInfoParcel = zza.zza(parcel, n5, AdLauncherIntentInfoParcel.CREATOR);
                    continue block19;
                }
                case 3: {
                    iBinder = zza.zzr(parcel, n5);
                    continue block19;
                }
                case 4: {
                    iBinder2 = zza.zzr(parcel, n5);
                    continue block19;
                }
                case 5: {
                    iBinder3 = zza.zzr(parcel, n5);
                    continue block19;
                }
                case 6: {
                    iBinder4 = zza.zzr(parcel, n5);
                    continue block19;
                }
                case 7: {
                    string2 = zza.zzq(parcel, n5);
                    continue block19;
                }
                case 8: {
                    bl = zza.zzc(parcel, n5);
                    continue block19;
                }
                case 9: {
                    string3 = zza.zzq(parcel, n5);
                    continue block19;
                }
                case 10: {
                    iBinder5 = zza.zzr(parcel, n5);
                    continue block19;
                }
                case 11: {
                    n3 = zza.zzg(parcel, n5);
                    continue block19;
                }
                case 12: {
                    n4 = zza.zzg(parcel, n5);
                    continue block19;
                }
                case 13: {
                    string4 = zza.zzq(parcel, n5);
                    continue block19;
                }
                case 14: {
                    versionInfoParcel = zza.zza(parcel, n5, VersionInfoParcel.CREATOR);
                    continue block19;
                }
                case 15: {
                    iBinder6 = zza.zzr(parcel, n5);
                    continue block19;
                }
                case 16: {
                    string5 = zza.zzq(parcel, n5);
                    continue block19;
                }
                case 17: 
            }
            interstitialAdParameterParcel = zza.zza(parcel, n5, InterstitialAdParameterParcel.CREATOR);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new AdOverlayInfoParcel(n2, adLauncherIntentInfoParcel, iBinder, iBinder2, iBinder3, iBinder4, string2, bl, string3, iBinder5, n3, n4, string4, versionInfoParcel, iBinder6, string5, interstitialAdParameterParcel);
    }
}

