/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.internal.overlay;

public interface zzg {
    public void onPause();

    public void onResume();

    public void zzeq();

    public void zzer();
}

