/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.internal.overlay;

import android.support.annotation.Nullable;

public interface zzh {
    public void onPaused();

    public void zzf(int var1, int var2);

    public void zzk(String var1, @Nullable String var2);

    public void zzqb();

    public void zzqc();

    public void zzqd();

    public void zzqe();

    public void zzqf();

    public void zzqg();
}

