/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 */
package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.support.annotation.Nullable;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.overlay.zzi;
import com.google.android.gms.common.util.zzs;
import com.google.android.gms.internal.zzdz;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzmd;

@zzji
public abstract class zzj {
    @Nullable
    public abstract zzi zza(Context var1, zzmd var2, int var3, boolean var4, zzdz var5);

    protected boolean zzh(zzmd zzmd2) {
        return zzmd2.zzeg().zzazr;
    }

    protected boolean zzp(Context context) {
        context = context.getApplicationInfo();
        if (zzs.zzayq() && (context == null || context.targetSdkVersion >= 11)) {
            return true;
        }
        return false;
    }
}

