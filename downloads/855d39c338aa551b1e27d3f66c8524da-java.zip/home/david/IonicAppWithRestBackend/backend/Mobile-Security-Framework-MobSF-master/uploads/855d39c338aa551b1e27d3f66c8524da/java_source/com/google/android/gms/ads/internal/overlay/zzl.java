/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.internal.overlay;

import com.google.android.gms.internal.zzmd;
import java.util.Map;

public interface zzl {
    public void destroy();

    public void pause();

    public void resume();

    public void zzg(zzmd var1, Map<String, String> var2);
}

