/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.widget.RelativeLayout
 */
package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.widget.RelativeLayout;
import com.google.android.gms.ads.internal.overlay.zzl;
import com.google.android.gms.internal.zzmd;

public interface zzm {
    public zzl zza(Activity var1, zzmd var2, RelativeLayout var3);
}

