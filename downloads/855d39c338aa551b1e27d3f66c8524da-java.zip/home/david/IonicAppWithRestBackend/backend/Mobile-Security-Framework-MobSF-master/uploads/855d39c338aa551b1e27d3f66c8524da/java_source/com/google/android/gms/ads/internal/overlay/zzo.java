/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.ImageButton
 */
package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.overlay.zzu;
import com.google.android.gms.internal.zzji;

@zzji
public class zzo
extends FrameLayout
implements View.OnClickListener {
    private final ImageButton zzccn;
    private final zzu zzcco;

    public zzo(Context context, int n, zzu zzu2) {
        super(context);
        this.zzcco = zzu2;
        this.setOnClickListener((View.OnClickListener)this);
        this.zzccn = new ImageButton(context);
        this.zzccn.setImageResource(17301527);
        this.zzccn.setBackgroundColor(0);
        this.zzccn.setOnClickListener((View.OnClickListener)this);
        this.zzccn.setPadding(0, 0, 0, 0);
        this.zzccn.setContentDescription((CharSequence)"Interstitial close button");
        n = zzm.zzkr().zzb(context, n);
        this.addView((View)this.zzccn, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(n, n, 17));
    }

    public void onClick(View view) {
        if (this.zzcco != null) {
            this.zzcco.zzpm();
        }
    }

    public void zza(boolean bl, boolean bl2) {
        if (bl2) {
            if (bl) {
                this.zzccn.setVisibility(4);
                return;
            }
            this.zzccn.setVisibility(8);
            return;
        }
        this.zzccn.setVisibility(0);
    }
}

