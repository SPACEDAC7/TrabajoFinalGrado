/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.MediaPlayer
 */
package com.google.android.gms.ads.internal.overlay;

import android.media.MediaPlayer;

public class zzq {
    public MediaPlayer zzqr() {
        return new MediaPlayer();
    }
}

