/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.SurfaceTexture
 *  android.view.Surface
 */
package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.graphics.SurfaceTexture;
import android.view.Surface;

public class zzr {
    @TargetApi(value=14)
    public Surface zza(SurfaceTexture surfaceTexture) {
        return new Surface(surfaceTexture);
    }
}

