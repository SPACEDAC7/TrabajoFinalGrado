/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.SurfaceTexture
 *  android.os.Handler
 */
package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.graphics.SurfaceTexture;
import android.os.Handler;
import com.google.android.gms.ads.internal.overlay.zzh;
import com.google.android.gms.internal.zzdn;
import com.google.android.gms.internal.zzdr;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzlb;
import java.util.concurrent.TimeUnit;

@zzji
@TargetApi(value=14)
public class zzv {
    private final long zzccp = TimeUnit.MILLISECONDS.toNanos(zzdr.zzbdy.get());
    private long zzccq;
    private boolean zzccr = true;

    zzv() {
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void zza(SurfaceTexture surfaceTexture, final zzh zzh2) {
        if (zzh2 == null) {
            return;
        }
        long l = surfaceTexture.getTimestamp();
        if (!this.zzccr) {
            if (Math.abs(l - this.zzccq) < this.zzccp) return;
        }
        this.zzccr = false;
        this.zzccq = l;
        zzlb.zzcvl.post(new Runnable(){

            @Override
            public void run() {
                zzh2.zzqg();
            }
        });
    }

    public void zzqd() {
        this.zzccr = true;
    }

}

