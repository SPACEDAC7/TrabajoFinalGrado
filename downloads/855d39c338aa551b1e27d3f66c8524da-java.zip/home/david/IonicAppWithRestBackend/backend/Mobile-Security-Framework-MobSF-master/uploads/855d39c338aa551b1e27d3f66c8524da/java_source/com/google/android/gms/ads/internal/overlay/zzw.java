/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.view.Display
 *  android.view.WindowManager
 */
package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.Display;
import android.view.WindowManager;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;

@zzji
class zzw
implements SensorEventListener {
    private final SensorManager zzccu;
    private final Object zzccv;
    private final Display zzccw;
    private final float[] zzccx;
    private final float[] zzccy;
    private float[] zzccz;
    private Handler zzcda;
    private zza zzcdb;

    zzw(Context context) {
        this.zzccu = (SensorManager)context.getSystemService("sensor");
        this.zzccw = ((WindowManager)context.getSystemService("window")).getDefaultDisplay();
        this.zzccx = new float[9];
        this.zzccy = new float[9];
        this.zzccv = new Object();
    }

    private void zzh(int n, int n2) {
        float f = this.zzccy[n];
        this.zzccy[n] = this.zzccy[n2];
        this.zzccy[n2] = f;
    }

    int getRotation() {
        return this.zzccw.getRotation();
    }

    public void onAccuracyChanged(Sensor sensor, int n) {
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        this.zza(sensorEvent.values);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    void start() {
        if (this.zzcda != null) {
            return;
        }
        Sensor sensor = this.zzccu.getDefaultSensor(11);
        if (sensor == null) {
            zzkx.e("No Sensor of TYPE_ROTATION_VECTOR");
            return;
        }
        HandlerThread handlerThread = new HandlerThread("OrientationMonitor");
        handlerThread.start();
        this.zzcda = new Handler(handlerThread.getLooper());
        if (this.zzccu.registerListener((SensorEventListener)this, sensor, 0, this.zzcda)) return;
        zzkx.e("SensorManager.registerListener failed.");
        this.stop();
    }

    void stop() {
        if (this.zzcda == null) {
            return;
        }
        this.zzccu.unregisterListener((SensorEventListener)this);
        this.zzcda.post(new Runnable(){

            @Override
            public void run() {
                Looper.myLooper().quit();
            }
        });
        this.zzcda = null;
    }

    void zza(zza zza2) {
        this.zzcdb = zza2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    void zza(float[] object) {
        if (object[0] == 0.0f && object[1] == 0.0f && object[2] == 0.0f) {
            return;
        }
        Object object2 = this.zzccv;
        // MONITORENTER : object2
        if (this.zzccz == null) {
            this.zzccz = new float[9];
        }
        // MONITOREXIT : object2
        SensorManager.getRotationMatrixFromVector((float[])this.zzccx, (float[])object);
        switch (this.getRotation()) {
            default: {
                System.arraycopy(this.zzccx, 0, this.zzccy, 0, 9);
                break;
            }
            case 1: {
                SensorManager.remapCoordinateSystem((float[])this.zzccx, (int)2, (int)129, (float[])this.zzccy);
                break;
            }
            case 2: {
                SensorManager.remapCoordinateSystem((float[])this.zzccx, (int)129, (int)130, (float[])this.zzccy);
                break;
            }
            case 3: {
                SensorManager.remapCoordinateSystem((float[])this.zzccx, (int)130, (int)1, (float[])this.zzccy);
            }
        }
        this.zzh(1, 3);
        this.zzh(2, 6);
        this.zzh(5, 7);
        object = this.zzccv;
        // MONITORENTER : object
        System.arraycopy(this.zzccy, 0, this.zzccz, 0, 9);
        // MONITOREXIT : object
        if (this.zzcdb == null) return;
        this.zzcdb.zzpr();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    boolean zzb(float[] arrf) {
        Object object = this.zzccv;
        synchronized (object) {
            if (this.zzccz == null) {
                return false;
            }
            System.arraycopy(this.zzccz, 0, arrf, 0, this.zzccz.length);
            return true;
        }
    }

    static interface zza {
        public void zzpr();
    }

}

