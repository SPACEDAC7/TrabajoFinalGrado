/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Color
 *  android.os.Bundle
 *  android.text.TextUtils
 *  android.view.TextureView
 */
package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.TextureView;
import com.google.android.gms.ads.internal.overlay.zzi;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zzdn;
import com.google.android.gms.internal.zzdr;
import com.google.android.gms.internal.zzdv;
import com.google.android.gms.internal.zzdx;
import com.google.android.gms.internal.zzdz;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;
import com.google.android.gms.internal.zzlh;
import java.util.List;
import java.util.concurrent.TimeUnit;

@zzji
public class zzy {
    private final Context mContext;
    private final VersionInfoParcel zzapc;
    @Nullable
    private final zzdz zzcbz;
    private boolean zzccd;
    private final String zzcec;
    @Nullable
    private final zzdx zzced;
    private final zzlh zzcee = new zzlh.zzb().zza("min_1", Double.MIN_VALUE, 1.0).zza("1_5", 1.0, 5.0).zza("5_10", 5.0, 10.0).zza("10_20", 10.0, 20.0).zza("20_30", 20.0, 30.0).zza("30_max", 30.0, Double.MAX_VALUE).zzwi();
    private final long[] zzcef;
    private final String[] zzceg;
    private boolean zzceh = false;
    private boolean zzcei = false;
    private boolean zzcej = false;
    private boolean zzcek = false;
    private zzi zzcel;
    private boolean zzcem;
    private boolean zzcen;
    private long zzceo = -1;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public zzy(Context arrstring, VersionInfoParcel versionInfoParcel, String string2, @Nullable zzdz zzdz2, @Nullable zzdx zzdx2) {
        this.mContext = arrstring;
        this.zzapc = versionInfoParcel;
        this.zzcec = string2;
        this.zzcbz = zzdz2;
        this.zzced = zzdx2;
        arrstring = zzdr.zzbdv.get();
        if (arrstring == null) {
            this.zzceg = new String[0];
            this.zzcef = new long[0];
            return;
        }
        arrstring = TextUtils.split((String)arrstring, (String)",");
        this.zzceg = new String[arrstring.length];
        this.zzcef = new long[arrstring.length];
        int n = 0;
        while (n < arrstring.length) {
            try {
                this.zzcef[n] = Long.parseLong(arrstring[n]);
            }
            catch (NumberFormatException var2_3) {
                zzkx.zzc("Unable to parse frame hash target time number.", var2_3);
                this.zzcef[n] = -1;
            }
            ++n;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zzc(zzi zzi2) {
        long l = zzdr.zzbdw.get();
        long l2 = zzi2.getCurrentPosition();
        int n = 0;
        while (n < this.zzceg.length) {
            if (this.zzceg[n] == null && l > Math.abs(l2 - this.zzcef[n])) {
                this.zzceg[n] = this.zza((TextureView)zzi2);
                return;
            }
            ++n;
        }
    }

    private void zzrd() {
        if (this.zzcej && !this.zzcek) {
            zzdv.zza(this.zzcbz, this.zzced, "vff2");
            this.zzcek = true;
        }
        long l = zzu.zzgs().nanoTime();
        if (this.zzccd && this.zzcen && this.zzceo != -1) {
            double d = (double)TimeUnit.SECONDS.toNanos(1) / (double)(l - this.zzceo);
            this.zzcee.zza(d);
        }
        this.zzcen = this.zzccd;
        this.zzceo = l;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onStop() {
        if (zzdr.zzbdu.get().booleanValue() && !this.zzcem) {
            String string2;
            Bundle bundle = new Bundle();
            bundle.putString("type", "native-player-metrics");
            bundle.putString("request", this.zzcec);
            bundle.putString("player", this.zzcel.zzpg());
            for (zzlh.zza zza2 : this.zzcee.getBuckets()) {
                string2 = String.valueOf("fps_c_");
                String string3 = String.valueOf(zza2.name);
                string2 = string3.length() != 0 ? string2.concat(string3) : new String(string2);
                bundle.putString(string2, Integer.toString(zza2.count));
                string2 = String.valueOf("fps_p_");
                string3 = String.valueOf(zza2.name);
                string2 = string3.length() != 0 ? string2.concat(string3) : new String(string2);
                bundle.putString(string2, Double.toString(zza2.zzcwo));
            }
            for (int i = 0; i < this.zzcef.length; ++i) {
                string2 = this.zzceg[i];
                if (string2 == null) continue;
                String string4 = String.valueOf("fh_");
                String string5 = String.valueOf((Object)this.zzcef[i]);
                bundle.putString(new StringBuilder(String.valueOf(string4).length() + 0 + String.valueOf(string5).length()).append(string4).append(string5).toString(), string2);
            }
            zzu.zzgm().zza(this.mContext, this.zzapc.zzda, "gmob-apps", bundle, true);
            this.zzcem = true;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @TargetApi(value=14)
    String zza(TextureView textureView) {
        textureView = textureView.getBitmap(8, 8);
        long l = 0;
        long l2 = 63;
        int n = 0;
        while (n < 8) {
            long l3 = l2;
            l2 = l;
            l = l3;
            for (int i = 0; i < 8; l2 |= l3 << (int)l, --l, ++i) {
                int n2 = textureView.getPixel(i, n);
                int n3 = Color.blue((int)n2);
                int n4 = Color.red((int)n2);
                l3 = Color.green((int)n2) + (n3 + n4) > 128 ? 1 : 0;
            }
            ++n;
            l3 = l2;
            l2 = l;
            l = l3;
        }
        return String.format("%016X", l);
    }

    public void zza(zzi zzi2) {
        zzdv.zza(this.zzcbz, this.zzced, "vpc2");
        this.zzceh = true;
        if (this.zzcbz != null) {
            this.zzcbz.zzg("vpn", zzi2.zzpg());
        }
        this.zzcel = zzi2;
    }

    public void zzb(zzi zzi2) {
        this.zzrd();
        this.zzc(zzi2);
    }

    public void zzqc() {
        if (!this.zzceh || this.zzcei) {
            return;
        }
        zzdv.zza(this.zzcbz, this.zzced, "vfr2");
        this.zzcei = true;
    }

    public void zzre() {
        this.zzccd = true;
        if (this.zzcei && !this.zzcej) {
            zzdv.zza(this.zzcbz, this.zzced, "vfp2");
            this.zzcej = true;
        }
    }

    public void zzrf() {
        this.zzccd = false;
    }
}

