/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.google.android.gms.ads.internal.overlay;

import android.os.Handler;
import com.google.android.gms.ads.internal.overlay.zzk;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzlb;

@zzji
class zzz
implements Runnable {
    private boolean mCancelled = false;
    private zzk zzcep;

    zzz(zzk zzk2) {
        this.zzcep = zzk2;
    }

    public void cancel() {
        this.mCancelled = true;
        zzlb.zzcvl.removeCallbacks((Runnable)this);
    }

    @Override
    public void run() {
        if (!this.mCancelled) {
            this.zzcep.zzqk();
            this.zzrg();
        }
    }

    public void zzrg() {
        zzlb.zzcvl.postDelayed((Runnable)this, 250);
    }
}

