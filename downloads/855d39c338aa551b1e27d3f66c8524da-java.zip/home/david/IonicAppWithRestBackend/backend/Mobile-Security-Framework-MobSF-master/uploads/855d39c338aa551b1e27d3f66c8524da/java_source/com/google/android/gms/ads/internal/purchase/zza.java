/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.purchase;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.purchase.GInAppPurchaseManagerInfoParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zza
implements Parcelable.Creator<GInAppPurchaseManagerInfoParcel> {
    static void zza(GInAppPurchaseManagerInfoParcel gInAppPurchaseManagerInfoParcel, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, gInAppPurchaseManagerInfoParcel.versionCode);
        zzb.zza(parcel, 3, gInAppPurchaseManagerInfoParcel.zzro(), false);
        zzb.zza(parcel, 4, gInAppPurchaseManagerInfoParcel.zzrp(), false);
        zzb.zza(parcel, 5, gInAppPurchaseManagerInfoParcel.zzrq(), false);
        zzb.zza(parcel, 6, gInAppPurchaseManagerInfoParcel.zzrn(), false);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzl(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzam(n);
    }

    public GInAppPurchaseManagerInfoParcel[] zzam(int n) {
        return new GInAppPurchaseManagerInfoParcel[n];
    }

    public GInAppPurchaseManagerInfoParcel zzl(Parcel parcel) {
        IBinder iBinder = null;
        int n = com.google.android.gms.common.internal.safeparcel.zza.zzcr(parcel);
        int n2 = 0;
        IBinder iBinder2 = null;
        IBinder iBinder3 = null;
        IBinder iBinder4 = null;
        block7 : while (parcel.dataPosition() < n) {
            int n3 = com.google.android.gms.common.internal.safeparcel.zza.zzcq(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zza.zzgu(n3)) {
                default: {
                    com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, n3);
                    continue block7;
                }
                case 1: {
                    n2 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n3);
                    continue block7;
                }
                case 3: {
                    iBinder4 = com.google.android.gms.common.internal.safeparcel.zza.zzr(parcel, n3);
                    continue block7;
                }
                case 4: {
                    iBinder3 = com.google.android.gms.common.internal.safeparcel.zza.zzr(parcel, n3);
                    continue block7;
                }
                case 5: {
                    iBinder2 = com.google.android.gms.common.internal.safeparcel.zza.zzr(parcel, n3);
                    continue block7;
                }
                case 6: 
            }
            iBinder = com.google.android.gms.common.internal.safeparcel.zza.zzr(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new GInAppPurchaseManagerInfoParcel(n2, iBinder4, iBinder3, iBinder2, iBinder);
    }
}

