/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.IBinder
 */
package com.google.android.gms.ads.internal.purchase;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;
import java.lang.reflect.Method;

@zzji
public class zzb {
    private final Context mContext;
    Object zzcfd;
    private final boolean zzcfe;

    public zzb(Context context) {
        this(context, true);
    }

    public zzb(Context context, boolean bl) {
        this.mContext = context;
        this.zzcfe = bl;
    }

    public void destroy() {
        this.zzcfd = null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zzav(IBinder iBinder) {
        try {
            this.zzcfd = this.mContext.getClassLoader().loadClass("com.android.vending.billing.IInAppBillingService$Stub").getDeclaredMethod("asInterface", IBinder.class).invoke(null, new Object[]{iBinder});
            return;
        }
        catch (Exception var1_2) {
            if (!this.zzcfe) return;
            zzkx.zzdi("IInAppBillingService is not available, please add com.android.vending.billing.IInAppBillingService to project.");
            return;
        }
    }

    public int zzb(int n, String string2, String string3) {
        try {
            Class class_ = this.mContext.getClassLoader().loadClass("com.android.vending.billing.IInAppBillingService");
            n = (Integer)class_.getDeclaredMethod("isBillingSupported", Integer.TYPE, String.class, String.class).invoke(class_.cast(this.zzcfd), n, string2, string3);
            return n;
        }
        catch (Exception var2_3) {
            if (this.zzcfe) {
                zzkx.zzc("IInAppBillingService is not available, please add com.android.vending.billing.IInAppBillingService to project.", var2_3);
            }
            return 5;
        }
    }

    public Bundle zzb(String string2, String string3, String string4) {
        try {
            Class class_ = this.mContext.getClassLoader().loadClass("com.android.vending.billing.IInAppBillingService");
            string2 = (Bundle)class_.getDeclaredMethod("getBuyIntent", Integer.TYPE, String.class, String.class, String.class, String.class).invoke(class_.cast(this.zzcfd), 3, string2, string3, "inapp", string4);
            return string2;
        }
        catch (Exception var1_2) {
            if (this.zzcfe) {
                zzkx.zzc("IInAppBillingService is not available, please add com.android.vending.billing.IInAppBillingService to project.", var1_2);
            }
            return null;
        }
    }

    public int zzl(String string2, String string3) {
        try {
            Class class_ = this.mContext.getClassLoader().loadClass("com.android.vending.billing.IInAppBillingService");
            int n = (Integer)class_.getDeclaredMethod("consumePurchase", Integer.TYPE, String.class, String.class).invoke(class_.cast(this.zzcfd), 3, string2, string3);
            return n;
        }
        catch (Exception var1_2) {
            if (this.zzcfe) {
                zzkx.zzc("IInAppBillingService is not available, please add com.android.vending.billing.IInAppBillingService to project.", var1_2);
            }
            return 5;
        }
    }

    public Bundle zzm(String string2, String string3) {
        try {
            Class class_ = this.mContext.getClassLoader().loadClass("com.android.vending.billing.IInAppBillingService");
            string2 = (Bundle)class_.getDeclaredMethod("getPurchases", Integer.TYPE, String.class, String.class, String.class).invoke(class_.cast(this.zzcfd), 3, string2, "inapp", string3);
            return string2;
        }
        catch (Exception var1_2) {
            if (this.zzcfe) {
                zzkx.zzc("IInAppBillingService is not available, please add com.android.vending.billing.IInAppBillingService to project.", var1_2);
            }
            return null;
        }
    }
}

