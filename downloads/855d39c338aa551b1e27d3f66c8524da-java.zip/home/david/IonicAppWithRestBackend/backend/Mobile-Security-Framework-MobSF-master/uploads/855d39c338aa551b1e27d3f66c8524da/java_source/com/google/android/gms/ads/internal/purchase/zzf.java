/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.internal.purchase;

import com.google.android.gms.internal.zzji;

@zzji
public final class zzf {
    public long zzcft;
    public final String zzcfu;
    public final String zzcfv;

    public zzf(long l, String string2, String string3) {
        this.zzcft = l;
        this.zzcfv = string2;
        this.zzcfu = string3;
    }

    public zzf(String string2, String string3) {
        this(-1, string2, string3);
    }
}

