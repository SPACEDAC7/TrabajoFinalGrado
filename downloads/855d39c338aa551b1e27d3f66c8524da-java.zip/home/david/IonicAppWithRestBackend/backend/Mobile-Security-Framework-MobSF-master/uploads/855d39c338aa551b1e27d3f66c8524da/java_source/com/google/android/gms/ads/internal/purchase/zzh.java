/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteDatabase$CursorFactory
 *  android.database.sqlite.SQLiteException
 *  android.database.sqlite.SQLiteOpenHelper
 *  android.os.SystemClock
 */
package com.google.android.gms.ads.internal.purchase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.SystemClock;
import com.google.android.gms.ads.internal.purchase.zzf;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

@zzji
public class zzh {
    private static final Object zzako;
    private static final String zzcfy;
    private static zzh zzcga;
    private final zza zzcfz;

    static {
        zzcfy = String.format(Locale.US, "CREATE TABLE IF NOT EXISTS %s ( %s INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, %s TEXT NOT NULL, %s TEXT NOT NULL, %s INTEGER)", "InAppPurchase", "purchase_id", "product_id", "developer_payload", "record_time");
        zzako = new Object();
    }

    zzh(Context context) {
        this.zzcfz = new zza(context, "google_inapp_purchase.db");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static zzh zzq(Context object) {
        Object object2 = zzako;
        synchronized (object2) {
            if (zzcga != null) return zzcga;
            zzcga = new zzh((Context)object);
            return zzcga;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public int getRecordCount() {
        SQLiteDatabase sQLiteDatabase;
        block15 : {
            int n;
            block16 : {
                SQLiteDatabase sQLiteDatabase2 = null;
                SQLiteDatabase sQLiteDatabase3 = null;
                Object object = zzako;
                // MONITORENTER : object
                sQLiteDatabase = this.getWritableDatabase();
                if (sQLiteDatabase == null) {
                    // MONITOREXIT : object
                    return 0;
                }
                try {
                    sQLiteDatabase3 = sQLiteDatabase = sQLiteDatabase.rawQuery("select count(*) from InAppPurchase", null);
                    sQLiteDatabase2 = sQLiteDatabase;
                    if (!sQLiteDatabase.moveToFirst()) break block15;
                    sQLiteDatabase3 = sQLiteDatabase;
                    sQLiteDatabase2 = sQLiteDatabase;
                    n = sQLiteDatabase.getInt(0);
                    if (sQLiteDatabase == null) break block16;
                }
                catch (SQLiteException var4_6) {
                    block17 : {
                        sQLiteDatabase2 = sQLiteDatabase3;
                        try {
                            String string2 = String.valueOf(var4_6.getMessage());
                            sQLiteDatabase2 = sQLiteDatabase3;
                            if (string2.length() != 0) {
                                sQLiteDatabase2 = sQLiteDatabase3;
                                string2 = "Error getting record count".concat(string2);
                            } else {
                                sQLiteDatabase2 = sQLiteDatabase3;
                                string2 = new String("Error getting record count");
                            }
                            sQLiteDatabase2 = sQLiteDatabase3;
                            zzkx.zzdi(string2);
                            if (sQLiteDatabase3 != null) break block17;
                        }
                        catch (Throwable var2_3) {
                            if (sQLiteDatabase2 == null) throw var2_3;
                            sQLiteDatabase2.close();
                            throw var2_3;
                        }
                        return 0;
                    }
                    sQLiteDatabase3.close();
                    return 0;
                }
                sQLiteDatabase.close();
            }
            // MONITOREXIT : object
            return n;
        }
        if (sQLiteDatabase == null) return 0;
        {
            sQLiteDatabase.close();
            return 0;
        }
    }

    public SQLiteDatabase getWritableDatabase() {
        try {
            SQLiteDatabase sQLiteDatabase = this.zzcfz.getWritableDatabase();
            return sQLiteDatabase;
        }
        catch (SQLiteException var1_2) {
            zzkx.zzdi("Error opening writable conversion tracking database");
            return null;
        }
    }

    public zzf zza(Cursor cursor) {
        if (cursor == null) {
            return null;
        }
        return new zzf(cursor.getLong(0), cursor.getString(1), cursor.getString(2));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zza(zzf zzf2) {
        if (zzf2 == null) {
            return;
        }
        Object object = zzako;
        synchronized (object) {
            SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
            if (sQLiteDatabase == null) {
                return;
            }
            sQLiteDatabase.delete("InAppPurchase", String.format(Locale.US, "%s = %d", "purchase_id", zzf2.zzcft), null);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zzb(zzf zzf2) {
        if (zzf2 == null) {
            return;
        }
        Object object = zzako;
        synchronized (object) {
            SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
            if (sQLiteDatabase == null) {
                return;
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put("product_id", zzf2.zzcfv);
            contentValues.put("developer_payload", zzf2.zzcfu);
            contentValues.put("record_time", Long.valueOf(SystemClock.elapsedRealtime()));
            zzf2.zzcft = sQLiteDatabase.insert("InAppPurchase", null, contentValues);
            if ((long)this.getRecordCount() > 20000) {
                this.zzru();
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public List<zzf> zzg(long var1_1) {
        var7_2 = zzh.zzako;
        // MONITORENTER : var7_2
        var8_3 = new LinkedList<zzf>();
        if (var1_1 <= 0) {
            // MONITOREXIT : var7_2
            return var8_3;
        }
        var4_4 = this.getWritableDatabase();
        if (var4_4 == null) {
            // MONITOREXIT : var7_2
            return var8_3;
        }
        var4_4 = var5_6 = var4_4.query("InAppPurchase", null, null, null, null, null, "record_time ASC", String.valueOf(var1_1));
        try {
            if (var5_6.moveToFirst()) {
                do {
                    var4_4 = var5_6;
                    var8_3.add(this.zza((Cursor)var5_6));
                    var4_4 = var5_6;
                } while (var3_7 = var5_6.moveToNext());
            }
            ** if (var5_6 == null) goto lbl23
        }
        catch (SQLiteException var6_11) {
            ** continue;
        }
lbl-1000: // 1 sources:
        {
            var5_6.close();
            return var8_3;
        }
lbl23: // 1 sources:
        ** GOTO lbl30
        catch (SQLiteException var6_8) {
            var5_6 = null;
            ** GOTO lbl33
            catch (Throwable var4_5) {
                var5_6 = null;
                ** GOTO lbl51
            }
lbl30: // 2 sources:
            do {
                // MONITOREXIT : var7_2
                return var8_3;
                break;
            } while (true);
lbl33: // 2 sources:
            do {
                var4_4 = var5_6;
                try {
                    var6_9 = String.valueOf(var6_9.getMessage());
                    var4_4 = var5_6;
                    if (var6_9.length() != 0) {
                        var4_4 = var5_6;
                        var6_9 = "Error extracing purchase info: ".concat(var6_9);
                    } else {
                        var4_4 = var5_6;
                        var6_9 = new String("Error extracing purchase info: ");
                    }
                    var4_4 = var5_6;
                    zzkx.zzdi(var6_9);
                    if (var5_6 == null) ** continue;
                }
                catch (Throwable var6_10) {
                    var5_6 = var4_4;
                    var4_4 = var6_10;
lbl51: // 2 sources:
                    if (var5_6 == null) throw var4_4;
                    var5_6.close();
                    throw var4_4;
                }
                var5_6.close();
                return var8_3;
                break;
            } while (true);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void zzru() {
        block19 : {
            var4_1 = zzh.zzako;
            // MONITORENTER : var4_1
            var1_2 = this.getWritableDatabase();
            if (var1_2 == null) {
                // MONITOREXIT : var4_1
                return;
            }
            var2_4 = var1_2.query("InAppPurchase", null, null, null, null, null, "record_time ASC", "1");
            if (var2_4 == null) break block19;
            var1_2 = var2_4;
            try {
                if (!var2_4.moveToFirst()) break block19;
                var1_2 = var2_4;
                this.zza(this.zza(var2_4));
            }
            catch (SQLiteException var3_8) {
                ** continue;
            }
        }
        if (var2_4 != null) {
            var2_4.close();
            return;
        }
        ** GOTO lbl26
        catch (SQLiteException var3_5) {
            var2_4 = null;
            ** GOTO lbl29
            catch (Throwable var1_3) {
                var2_4 = null;
                ** GOTO lbl47
            }
lbl26: // 2 sources:
            do {
                // MONITOREXIT : var4_1
                return;
                break;
            } while (true);
lbl29: // 2 sources:
            do {
                var1_2 = var2_4;
                try {
                    var3_6 = String.valueOf(var3_6.getMessage());
                    var1_2 = var2_4;
                    if (var3_6.length() != 0) {
                        var1_2 = var2_4;
                        var3_6 = "Error remove oldest record".concat(var3_6);
                    } else {
                        var1_2 = var2_4;
                        var3_6 = new String("Error remove oldest record");
                    }
                    var1_2 = var2_4;
                    zzkx.zzdi(var3_6);
                    if (var2_4 == null) ** continue;
                }
                catch (Throwable var3_7) {
                    var2_4 = var1_2;
                    var1_2 = var3_7;
lbl47: // 2 sources:
                    if (var2_4 == null) throw var1_2;
                    var2_4.close();
                    throw var1_2;
                }
                var2_4.close();
                return;
                break;
            } while (true);
        }
    }

    public class zza
    extends SQLiteOpenHelper {
        public zza(Context context, String string2) {
            super(context, string2, null, 4);
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL(zzcfy);
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int n, int n2) {
            zzkx.zzdh(new StringBuilder(64).append("Database updated from version ").append(n).append(" to version ").append(n2).toString());
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS InAppPurchase");
            this.onCreate(sQLiteDatabase);
        }
    }

}

