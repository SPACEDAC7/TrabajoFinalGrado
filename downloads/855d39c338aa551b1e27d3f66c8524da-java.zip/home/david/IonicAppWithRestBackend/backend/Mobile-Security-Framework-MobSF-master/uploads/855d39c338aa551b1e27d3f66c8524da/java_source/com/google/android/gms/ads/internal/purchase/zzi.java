/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.os.Bundle
 *  android.os.IBinder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.google.android.gms.ads.internal.purchase;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import com.google.android.gms.ads.internal.purchase.GInAppPurchaseManagerInfoParcel;
import com.google.android.gms.ads.internal.purchase.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.stats.zza;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;
import org.json.JSONException;
import org.json.JSONObject;

@zzji
public class zzi {
    public void zza(Context context, boolean bl, GInAppPurchaseManagerInfoParcel gInAppPurchaseManagerInfoParcel) {
        Intent intent = new Intent();
        intent.setClassName(context, "com.google.android.gms.ads.purchase.InAppPurchaseActivity");
        intent.putExtra("com.google.android.gms.ads.internal.purchase.useClientJar", bl);
        GInAppPurchaseManagerInfoParcel.zza(intent, gInAppPurchaseManagerInfoParcel);
        zzu.zzgm().zzb(context, intent);
    }

    public String zzcg(String string2) {
        if (string2 == null) {
            return null;
        }
        try {
            string2 = new JSONObject(string2).getString("developerPayload");
            return string2;
        }
        catch (JSONException var1_2) {
            zzkx.zzdi("Fail to parse purchase data");
            return null;
        }
    }

    public String zzch(String string2) {
        if (string2 == null) {
            return null;
        }
        try {
            string2 = new JSONObject(string2).getString("purchaseToken");
            return string2;
        }
        catch (JSONException var1_2) {
            zzkx.zzdi("Fail to parse purchase data");
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public int zzd(Intent object) {
        if (object == null) {
            return 5;
        }
        if ((object = object.getExtras().get("RESPONSE_CODE")) == null) {
            zzkx.zzdi("Intent with no response code, assuming OK (known issue)");
            return 0;
        }
        if (object instanceof Integer) {
            return (Integer)object;
        }
        if (object instanceof Long) {
            return (int)((Long)object).longValue();
        }
        object = (object = String.valueOf(object.getClass().getName())).length() != 0 ? "Unexpected type for intent response code. ".concat((String)object) : new String("Unexpected type for intent response code. ");
        zzkx.zzdi((String)object);
        return 5;
    }

    /*
     * Enabled aggressive block sorting
     */
    public int zzd(Bundle object) {
        if ((object = object.get("RESPONSE_CODE")) == null) {
            zzkx.zzdi("Bundle with null response code, assuming OK (known issue)");
            return 0;
        }
        if (object instanceof Integer) {
            return (Integer)object;
        }
        if (object instanceof Long) {
            return (int)((Long)object).longValue();
        }
        object = (object = String.valueOf(object.getClass().getName())).length() != 0 ? "Unexpected type for intent response code. ".concat((String)object) : new String("Unexpected type for intent response code. ");
        zzkx.zzdi((String)object);
        return 5;
    }

    public String zze(Intent intent) {
        if (intent == null) {
            return null;
        }
        return intent.getStringExtra("INAPP_PURCHASE_DATA");
    }

    public String zzf(Intent intent) {
        if (intent == null) {
            return null;
        }
        return intent.getStringExtra("INAPP_DATA_SIGNATURE");
    }

    public void zzr(final Context context) {
        ServiceConnection serviceConnection = new ServiceConnection(){

            public void onServiceConnected(ComponentName object, IBinder object2) {
                boolean bl = false;
                object = new zzb(context.getApplicationContext(), false);
                object.zzav((IBinder)object2);
                int n = object.zzb(3, context.getPackageName(), "inapp");
                object2 = zzu.zzgq();
                if (n == 0) {
                    bl = true;
                }
                object2.zzai(bl);
                zza.zzaxr().zza(context, this);
                object.destroy();
            }

            public void onServiceDisconnected(ComponentName componentName) {
            }
        };
        Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
        intent.setPackage("com.android.vending");
        zza.zzaxr().zza(context, intent, serviceConnection, 1);
    }

}

