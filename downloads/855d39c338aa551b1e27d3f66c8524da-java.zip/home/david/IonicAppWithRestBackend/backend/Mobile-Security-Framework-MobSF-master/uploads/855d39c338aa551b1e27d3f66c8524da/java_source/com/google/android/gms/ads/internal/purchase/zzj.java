/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 */
package com.google.android.gms.ads.internal.purchase;

import android.content.Intent;
import com.google.android.gms.ads.internal.purchase.zzf;

public interface zzj {
    public void zza(String var1, boolean var2, int var3, Intent var4, zzf var5);
}

