/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 */
package com.google.android.gms.ads.internal.purchase;

import android.content.Intent;
import com.google.android.gms.ads.internal.purchase.zzl;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;

@zzji
public class zzk {
    private final String zzbbj;

    public zzk(String string2) {
        this.zzbbj = string2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean zza(String string2, int n, Intent object) {
        if (string2 == null) return false;
        if (object == null) {
            return false;
        }
        String string3 = zzu.zzha().zze((Intent)object);
        object = zzu.zzha().zzf((Intent)object);
        if (string3 == null) return false;
        if (object == null) return false;
        if (!string2.equals(zzu.zzha().zzcg(string3))) {
            zzkx.zzdi("Developer payload not match.");
            return false;
        }
        if (this.zzbbj == null) return true;
        if (zzl.zzc(this.zzbbj, string3, (String)object)) return true;
        zzkx.zzdi("Fail to verify signature.");
        return false;
    }

    public String zzrv() {
        return zzu.zzgm().zzvs();
    }
}

