/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  android.util.Base64
 */
package com.google.android.gms.ads.internal.purchase;

import android.text.TextUtils;
import android.util.Base64;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.X509EncodedKeySpec;

@zzji
public class zzl {
    public static boolean zza(PublicKey publicKey, String string2, String string3) {
        try {
            Signature signature = Signature.getInstance("SHA1withRSA");
            signature.initVerify(publicKey);
            signature.update(string2.getBytes());
            if (!signature.verify(Base64.decode((String)string3, (int)0))) {
                zzkx.e("Signature verification failed.");
                return false;
            }
            return true;
        }
        catch (NoSuchAlgorithmException var0_1) {
            zzkx.e("NoSuchAlgorithmException.");
            return false;
        }
        catch (InvalidKeyException var0_2) {
            zzkx.e("Invalid key specification.");
            return false;
        }
        catch (SignatureException var0_3) {
            zzkx.e("Signature exception.");
            return false;
        }
    }

    public static boolean zzc(String string2, String string3, String string4) {
        if (TextUtils.isEmpty((CharSequence)string3) || TextUtils.isEmpty((CharSequence)string2) || TextUtils.isEmpty((CharSequence)string4)) {
            zzkx.e("Purchase verification failed: missing data.");
            return false;
        }
        return zzl.zza(zzl.zzci(string2), string3, string4);
    }

    public static PublicKey zzci(String object) {
        try {
            object = Base64.decode((String)object, (int)0);
            object = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec((byte[])object));
            return object;
        }
        catch (NoSuchAlgorithmException var0_1) {
            throw new RuntimeException(var0_1);
        }
        catch (InvalidKeySpecException var0_2) {
            zzkx.e("Invalid key specification.");
            throw new IllegalArgumentException(var0_2);
        }
    }
}

