/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 */
package com.google.android.gms.ads.internal.request;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.request.zzb;
import com.google.android.gms.ads.internal.request.zzn;
import com.google.android.gms.internal.zzav;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzko;
import com.google.android.gms.internal.zzkw;
import java.util.concurrent.Future;

@zzji
public class zza {
    /*
     * Enabled aggressive block sorting
     */
    public zzkw zza(Context object, AdRequestInfoParcel.zza object2, zzav zzav2, zza zza2) {
        object = object2.zzcju.extras.getBundle("sdk_less_server_data") != null ? new zzn((Context)object, (AdRequestInfoParcel.zza)object2, zza2) : new zzb((Context)object, (AdRequestInfoParcel.zza)object2, zzav2, zza2);
        object2 = (Future)object.zzrz();
        return object;
    }

    public static interface zza {
        public void zza(zzko.zza var1);
    }

}

