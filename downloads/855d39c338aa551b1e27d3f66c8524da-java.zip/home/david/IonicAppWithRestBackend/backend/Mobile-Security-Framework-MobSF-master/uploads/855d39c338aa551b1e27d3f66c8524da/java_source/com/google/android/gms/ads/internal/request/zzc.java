/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.google.android.gms.ads.internal.request;

import android.content.Context;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.request.zzd;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.common.util.zzi;
import com.google.android.gms.internal.zzdn;
import com.google.android.gms.internal.zzdr;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;
import com.google.android.gms.internal.zzld;
import com.google.android.gms.internal.zzlw;

@zzji
public final class zzc {
    public static zzld zza(Context context, VersionInfoParcel versionInfoParcel, zzlw<AdRequestInfoParcel> zzlw2, zza zza2) {
        return zzc.zza(context, versionInfoParcel, zzlw2, zza2, new zzb(){

            @Override
            public boolean zza(VersionInfoParcel versionInfoParcel) {
                if (versionInfoParcel.zzcyc || zzi.zzcj(Context.this) && !zzdr.zzbel.get().booleanValue()) {
                    return true;
                }
                return false;
            }
        });
    }

    static zzld zza(Context context, VersionInfoParcel versionInfoParcel, zzlw<AdRequestInfoParcel> zzlw2, zza zza2, zzb zzb2) {
        if (zzb2.zza(versionInfoParcel)) {
            return zzc.zza(context, zzlw2, zza2);
        }
        return zzc.zzb(context, versionInfoParcel, zzlw2, zza2);
    }

    private static zzld zza(Context object, zzlw<AdRequestInfoParcel> object2, zza zza2) {
        zzkx.zzdg("Fetching ad response from local ad request service.");
        object = new zzd.zza((Context)object, (zzlw<AdRequestInfoParcel>)object2, zza2);
        object2 = (Void)object.zzrz();
        return object;
    }

    private static zzld zzb(Context context, VersionInfoParcel versionInfoParcel, zzlw<AdRequestInfoParcel> zzlw2, zza zza2) {
        zzkx.zzdg("Fetching ad response from remote ad request service.");
        if (!zzm.zzkr().zzap(context)) {
            zzkx.zzdi("Failed to connect to remote ad request service.");
            return null;
        }
        return new zzd.zzb(context, versionInfoParcel, zzlw2, zza2);
    }

    public static interface zza {
        public void zzb(AdResponseParcel var1);
    }

    static interface zzb {
        public boolean zza(VersionInfoParcel var1);
    }

}

