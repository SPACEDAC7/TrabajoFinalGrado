/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.os.Bundle
 *  android.os.Messenger
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.request;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.request.CapabilityParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import java.util.ArrayList;
import java.util.List;

public class zzf
implements Parcelable.Creator<AdRequestInfoParcel> {
    static void zza(AdRequestInfoParcel adRequestInfoParcel, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, adRequestInfoParcel.versionCode);
        zzb.zza(parcel, 2, adRequestInfoParcel.zzcjt, false);
        zzb.zza(parcel, 3, adRequestInfoParcel.zzcju, n, false);
        zzb.zza(parcel, 4, adRequestInfoParcel.zzarm, n, false);
        zzb.zza(parcel, 5, adRequestInfoParcel.zzarg, false);
        zzb.zza(parcel, 6, (Parcelable)adRequestInfoParcel.applicationInfo, n, false);
        zzb.zza(parcel, 7, (Parcelable)adRequestInfoParcel.zzcjv, n, false);
        zzb.zza(parcel, 8, adRequestInfoParcel.zzcjw, false);
        zzb.zza(parcel, 9, adRequestInfoParcel.zzcjx, false);
        zzb.zza(parcel, 10, adRequestInfoParcel.zzcjy, false);
        zzb.zza(parcel, 11, adRequestInfoParcel.zzari, n, false);
        zzb.zza(parcel, 12, adRequestInfoParcel.zzcjz, false);
        zzb.zzc(parcel, 13, adRequestInfoParcel.zzcka);
        zzb.zzb(parcel, 14, adRequestInfoParcel.zzase, false);
        zzb.zza(parcel, 15, adRequestInfoParcel.zzckb, false);
        zzb.zza(parcel, 16, adRequestInfoParcel.zzckc);
        zzb.zza(parcel, 17, (Parcelable)adRequestInfoParcel.zzckd, n, false);
        zzb.zzc(parcel, 18, adRequestInfoParcel.zzcke);
        zzb.zzc(parcel, 19, adRequestInfoParcel.zzckf);
        zzb.zza(parcel, 20, adRequestInfoParcel.zzavd);
        zzb.zza(parcel, 21, adRequestInfoParcel.zzckg, false);
        zzb.zza(parcel, 25, adRequestInfoParcel.zzckh);
        zzb.zza(parcel, 26, adRequestInfoParcel.zzcki, false);
        zzb.zzb(parcel, 27, adRequestInfoParcel.zzckj, false);
        zzb.zza(parcel, 28, adRequestInfoParcel.zzarf, false);
        zzb.zza(parcel, 29, adRequestInfoParcel.zzasa, n, false);
        zzb.zzb(parcel, 30, adRequestInfoParcel.zzckk, false);
        zzb.zza(parcel, 31, adRequestInfoParcel.zzckl);
        zzb.zza(parcel, 32, adRequestInfoParcel.zzckm, n, false);
        zzb.zza(parcel, 33, adRequestInfoParcel.zzckn, false);
        zzb.zza(parcel, 34, adRequestInfoParcel.zzcko);
        zzb.zzc(parcel, 35, adRequestInfoParcel.zzckp);
        zzb.zzc(parcel, 36, adRequestInfoParcel.zzckq);
        zzb.zza(parcel, 37, adRequestInfoParcel.zzckr);
        zzb.zza(parcel, 38, adRequestInfoParcel.zzcks);
        zzb.zza(parcel, 39, adRequestInfoParcel.zzckt, false);
        zzb.zza(parcel, 40, adRequestInfoParcel.zzcku);
        zzb.zza(parcel, 41, adRequestInfoParcel.zzckv, false);
        zzb.zza(parcel, 42, adRequestInfoParcel.zzbvo);
        zzb.zzc(parcel, 43, adRequestInfoParcel.zzckw);
        zzb.zza(parcel, 44, adRequestInfoParcel.zzckx, false);
        zzb.zza(parcel, 45, adRequestInfoParcel.zzcky, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzm(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzat(n);
    }

    public AdRequestInfoParcel[] zzat(int n) {
        return new AdRequestInfoParcel[n];
    }

    public AdRequestInfoParcel zzm(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        Bundle bundle = null;
        AdRequestParcel adRequestParcel = null;
        AdSizeParcel adSizeParcel = null;
        String string2 = null;
        ApplicationInfo applicationInfo = null;
        PackageInfo packageInfo = null;
        String string3 = null;
        String string4 = null;
        String string5 = null;
        VersionInfoParcel versionInfoParcel = null;
        Bundle bundle2 = null;
        int n3 = 0;
        ArrayList<String> arrayList = null;
        Bundle bundle3 = null;
        boolean bl = false;
        Messenger messenger = null;
        int n4 = 0;
        int n5 = 0;
        float f = 0.0f;
        String string6 = null;
        long l = 0;
        String string7 = null;
        ArrayList<String> arrayList2 = null;
        String string8 = null;
        NativeAdOptionsParcel nativeAdOptionsParcel = null;
        ArrayList<String> arrayList3 = null;
        long l2 = 0;
        CapabilityParcel capabilityParcel = null;
        String string9 = null;
        float f2 = 0.0f;
        boolean bl2 = false;
        int n6 = 0;
        int n7 = 0;
        boolean bl3 = false;
        boolean bl4 = false;
        String string10 = null;
        String string11 = null;
        boolean bl5 = false;
        int n8 = 0;
        Bundle bundle4 = null;
        String string12 = null;
        block44 : while (parcel.dataPosition() < n) {
            int n9 = zza.zzcq(parcel);
            switch (zza.zzgu(n9)) {
                default: {
                    zza.zzb(parcel, n9);
                    continue block44;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n9);
                    continue block44;
                }
                case 2: {
                    bundle = zza.zzs(parcel, n9);
                    continue block44;
                }
                case 3: {
                    adRequestParcel = zza.zza(parcel, n9, AdRequestParcel.CREATOR);
                    continue block44;
                }
                case 4: {
                    adSizeParcel = zza.zza(parcel, n9, AdSizeParcel.CREATOR);
                    continue block44;
                }
                case 5: {
                    string2 = zza.zzq(parcel, n9);
                    continue block44;
                }
                case 6: {
                    applicationInfo = (ApplicationInfo)zza.zza(parcel, n9, ApplicationInfo.CREATOR);
                    continue block44;
                }
                case 7: {
                    packageInfo = (PackageInfo)zza.zza(parcel, n9, PackageInfo.CREATOR);
                    continue block44;
                }
                case 8: {
                    string3 = zza.zzq(parcel, n9);
                    continue block44;
                }
                case 9: {
                    string4 = zza.zzq(parcel, n9);
                    continue block44;
                }
                case 10: {
                    string5 = zza.zzq(parcel, n9);
                    continue block44;
                }
                case 11: {
                    versionInfoParcel = zza.zza(parcel, n9, VersionInfoParcel.CREATOR);
                    continue block44;
                }
                case 12: {
                    bundle2 = zza.zzs(parcel, n9);
                    continue block44;
                }
                case 13: {
                    n3 = zza.zzg(parcel, n9);
                    continue block44;
                }
                case 14: {
                    arrayList = zza.zzae(parcel, n9);
                    continue block44;
                }
                case 15: {
                    bundle3 = zza.zzs(parcel, n9);
                    continue block44;
                }
                case 16: {
                    bl = zza.zzc(parcel, n9);
                    continue block44;
                }
                case 17: {
                    messenger = (Messenger)zza.zza(parcel, n9, Messenger.CREATOR);
                    continue block44;
                }
                case 18: {
                    n4 = zza.zzg(parcel, n9);
                    continue block44;
                }
                case 19: {
                    n5 = zza.zzg(parcel, n9);
                    continue block44;
                }
                case 20: {
                    f = zza.zzl(parcel, n9);
                    continue block44;
                }
                case 21: {
                    string6 = zza.zzq(parcel, n9);
                    continue block44;
                }
                case 25: {
                    l = zza.zzi(parcel, n9);
                    continue block44;
                }
                case 26: {
                    string7 = zza.zzq(parcel, n9);
                    continue block44;
                }
                case 27: {
                    arrayList2 = zza.zzae(parcel, n9);
                    continue block44;
                }
                case 28: {
                    string8 = zza.zzq(parcel, n9);
                    continue block44;
                }
                case 29: {
                    nativeAdOptionsParcel = zza.zza(parcel, n9, NativeAdOptionsParcel.CREATOR);
                    continue block44;
                }
                case 30: {
                    arrayList3 = zza.zzae(parcel, n9);
                    continue block44;
                }
                case 31: {
                    l2 = zza.zzi(parcel, n9);
                    continue block44;
                }
                case 32: {
                    capabilityParcel = zza.zza(parcel, n9, CapabilityParcel.CREATOR);
                    continue block44;
                }
                case 33: {
                    string9 = zza.zzq(parcel, n9);
                    continue block44;
                }
                case 34: {
                    f2 = zza.zzl(parcel, n9);
                    continue block44;
                }
                case 35: {
                    n6 = zza.zzg(parcel, n9);
                    continue block44;
                }
                case 36: {
                    n7 = zza.zzg(parcel, n9);
                    continue block44;
                }
                case 37: {
                    bl3 = zza.zzc(parcel, n9);
                    continue block44;
                }
                case 38: {
                    bl4 = zza.zzc(parcel, n9);
                    continue block44;
                }
                case 39: {
                    string10 = zza.zzq(parcel, n9);
                    continue block44;
                }
                case 40: {
                    bl2 = zza.zzc(parcel, n9);
                    continue block44;
                }
                case 41: {
                    string11 = zza.zzq(parcel, n9);
                    continue block44;
                }
                case 42: {
                    bl5 = zza.zzc(parcel, n9);
                    continue block44;
                }
                case 43: {
                    n8 = zza.zzg(parcel, n9);
                    continue block44;
                }
                case 44: {
                    bundle4 = zza.zzs(parcel, n9);
                    continue block44;
                }
                case 45: 
            }
            string12 = zza.zzq(parcel, n9);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new AdRequestInfoParcel(n2, bundle, adRequestParcel, adSizeParcel, string2, applicationInfo, packageInfo, string3, string4, string5, versionInfoParcel, bundle2, n3, arrayList, bundle3, bl, messenger, n4, n5, f, string6, l, string7, arrayList2, string8, nativeAdOptionsParcel, arrayList3, l2, capabilityParcel, string9, f2, bl2, n6, n7, bl3, bl4, string10, string11, bl5, n8, bundle4, string12);
    }
}

