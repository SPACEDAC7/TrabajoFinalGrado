/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.request.AutoClickProtectionConfigurationParcel;
import com.google.android.gms.ads.internal.request.LargeParcelTeleporter;
import com.google.android.gms.ads.internal.reward.mediation.client.RewardItemParcel;
import com.google.android.gms.ads.internal.safebrowsing.SafeBrowsingConfigParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import java.util.ArrayList;
import java.util.List;

public class zzh
implements Parcelable.Creator<AdResponseParcel> {
    static void zza(AdResponseParcel adResponseParcel, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, adResponseParcel.versionCode);
        zzb.zza(parcel, 2, adResponseParcel.zzcbo, false);
        zzb.zza(parcel, 3, adResponseParcel.body, false);
        zzb.zzb(parcel, 4, adResponseParcel.zzbvk, false);
        zzb.zzc(parcel, 5, adResponseParcel.errorCode);
        zzb.zzb(parcel, 6, adResponseParcel.zzbvl, false);
        zzb.zza(parcel, 7, adResponseParcel.zzcla);
        zzb.zza(parcel, 8, adResponseParcel.zzclb);
        zzb.zza(parcel, 9, adResponseParcel.zzclc);
        zzb.zzb(parcel, 10, adResponseParcel.zzcld, false);
        zzb.zza(parcel, 11, adResponseParcel.zzbvq);
        zzb.zzc(parcel, 12, adResponseParcel.orientation);
        zzb.zza(parcel, 13, adResponseParcel.zzcle, false);
        zzb.zza(parcel, 14, adResponseParcel.zzclf);
        zzb.zza(parcel, 15, adResponseParcel.zzclg, false);
        zzb.zza(parcel, 18, adResponseParcel.zzclh);
        zzb.zza(parcel, 19, adResponseParcel.zzcli, false);
        zzb.zza(parcel, 21, adResponseParcel.zzclj, false);
        zzb.zza(parcel, 22, adResponseParcel.zzclk);
        zzb.zza(parcel, 23, adResponseParcel.zzazt);
        zzb.zza(parcel, 24, adResponseParcel.zzckc);
        zzb.zza(parcel, 25, adResponseParcel.zzcll);
        zzb.zza(parcel, 26, adResponseParcel.zzclm);
        zzb.zza(parcel, 28, adResponseParcel.zzcln, n, false);
        zzb.zza(parcel, 29, adResponseParcel.zzclo, false);
        zzb.zza(parcel, 30, adResponseParcel.zzclp, false);
        zzb.zza(parcel, 31, adResponseParcel.zzazu);
        zzb.zza(parcel, 32, adResponseParcel.zzazv);
        zzb.zza(parcel, 33, adResponseParcel.zzclq, n, false);
        zzb.zzb(parcel, 34, adResponseParcel.zzclr, false);
        zzb.zzb(parcel, 35, adResponseParcel.zzcls, false);
        zzb.zza(parcel, 36, adResponseParcel.zzclt);
        zzb.zza(parcel, 37, adResponseParcel.zzclu, n, false);
        zzb.zza(parcel, 38, adResponseParcel.zzcks);
        zzb.zza(parcel, 39, adResponseParcel.zzckt, false);
        zzb.zzb(parcel, 40, adResponseParcel.zzbvn, false);
        zzb.zza(parcel, 42, adResponseParcel.zzbvo);
        zzb.zza(parcel, 43, adResponseParcel.zzclv, false);
        zzb.zza(parcel, 44, adResponseParcel.zzclw, n, false);
        zzb.zza(parcel, 45, adResponseParcel.zzclx, false);
        zzb.zza(parcel, 46, adResponseParcel.zzcly);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzn(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzau(n);
    }

    public AdResponseParcel[] zzau(int n) {
        return new AdResponseParcel[n];
    }

    public AdResponseParcel zzn(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        String string2 = null;
        String string3 = null;
        ArrayList<String> arrayList = null;
        int n3 = 0;
        ArrayList<String> arrayList2 = null;
        long l = 0;
        boolean bl = false;
        long l2 = 0;
        ArrayList<String> arrayList3 = null;
        long l3 = 0;
        int n4 = 0;
        String string4 = null;
        long l4 = 0;
        String string5 = null;
        boolean bl2 = false;
        String string6 = null;
        String string7 = null;
        boolean bl3 = false;
        boolean bl4 = false;
        boolean bl5 = false;
        boolean bl6 = false;
        boolean bl7 = false;
        LargeParcelTeleporter largeParcelTeleporter = null;
        String string8 = null;
        String string9 = null;
        boolean bl8 = false;
        boolean bl9 = false;
        RewardItemParcel rewardItemParcel = null;
        ArrayList<String> arrayList4 = null;
        ArrayList<String> arrayList5 = null;
        boolean bl10 = false;
        AutoClickProtectionConfigurationParcel autoClickProtectionConfigurationParcel = null;
        boolean bl11 = false;
        String string10 = null;
        ArrayList<String> arrayList6 = null;
        boolean bl12 = false;
        String string11 = null;
        SafeBrowsingConfigParcel safeBrowsingConfigParcel = null;
        String string12 = null;
        boolean bl13 = false;
        block43 : while (parcel.dataPosition() < n) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block43;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n5);
                    continue block43;
                }
                case 2: {
                    string2 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 3: {
                    string3 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 4: {
                    arrayList = zza.zzae(parcel, n5);
                    continue block43;
                }
                case 5: {
                    n3 = zza.zzg(parcel, n5);
                    continue block43;
                }
                case 6: {
                    arrayList2 = zza.zzae(parcel, n5);
                    continue block43;
                }
                case 7: {
                    l = zza.zzi(parcel, n5);
                    continue block43;
                }
                case 8: {
                    bl = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 9: {
                    l2 = zza.zzi(parcel, n5);
                    continue block43;
                }
                case 10: {
                    arrayList3 = zza.zzae(parcel, n5);
                    continue block43;
                }
                case 11: {
                    l3 = zza.zzi(parcel, n5);
                    continue block43;
                }
                case 12: {
                    n4 = zza.zzg(parcel, n5);
                    continue block43;
                }
                case 13: {
                    string4 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 14: {
                    l4 = zza.zzi(parcel, n5);
                    continue block43;
                }
                case 15: {
                    string5 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 18: {
                    bl2 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 19: {
                    string6 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 21: {
                    string7 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 22: {
                    bl3 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 23: {
                    bl4 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 24: {
                    bl5 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 25: {
                    bl6 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 26: {
                    bl7 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 28: {
                    largeParcelTeleporter = zza.zza(parcel, n5, LargeParcelTeleporter.CREATOR);
                    continue block43;
                }
                case 29: {
                    string8 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 30: {
                    string9 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 31: {
                    bl8 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 32: {
                    bl9 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 33: {
                    rewardItemParcel = zza.zza(parcel, n5, RewardItemParcel.CREATOR);
                    continue block43;
                }
                case 34: {
                    arrayList4 = zza.zzae(parcel, n5);
                    continue block43;
                }
                case 35: {
                    arrayList5 = zza.zzae(parcel, n5);
                    continue block43;
                }
                case 36: {
                    bl10 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 37: {
                    autoClickProtectionConfigurationParcel = zza.zza(parcel, n5, AutoClickProtectionConfigurationParcel.CREATOR);
                    continue block43;
                }
                case 38: {
                    bl11 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 39: {
                    string10 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 40: {
                    arrayList6 = zza.zzae(parcel, n5);
                    continue block43;
                }
                case 42: {
                    bl12 = zza.zzc(parcel, n5);
                    continue block43;
                }
                case 43: {
                    string11 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 44: {
                    safeBrowsingConfigParcel = zza.zza(parcel, n5, SafeBrowsingConfigParcel.CREATOR);
                    continue block43;
                }
                case 45: {
                    string12 = zza.zzq(parcel, n5);
                    continue block43;
                }
                case 46: 
            }
            bl13 = zza.zzc(parcel, n5);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new AdResponseParcel(n2, string2, string3, arrayList, n3, arrayList2, l, bl, l2, arrayList3, l3, n4, string4, l4, string5, bl2, string6, string7, bl3, bl4, bl5, bl6, bl7, largeParcelTeleporter, string8, string9, bl8, bl9, rewardItemParcel, arrayList4, arrayList5, bl10, autoClickProtectionConfigurationParcel, bl11, string10, arrayList6, bl12, string11, safeBrowsingConfigParcel, string12, bl13);
    }
}

