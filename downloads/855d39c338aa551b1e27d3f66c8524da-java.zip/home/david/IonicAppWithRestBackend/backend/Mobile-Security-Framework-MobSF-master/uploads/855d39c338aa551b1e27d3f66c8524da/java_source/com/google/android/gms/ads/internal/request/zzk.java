/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.ads.internal.request;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.request.zzl;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public interface zzk
extends IInterface {
    public void zza(AdRequestInfoParcel var1, zzl var2) throws RemoteException;

    public AdResponseParcel zzd(AdRequestInfoParcel var1) throws RemoteException;

    public static abstract class com.google.android.gms.ads.internal.request.zzk$zza
    extends Binder
    implements zzk {
        public com.google.android.gms.ads.internal.request.zzk$zza() {
            this.attachInterface((IInterface)this, "com.google.android.gms.ads.internal.request.IAdRequestService");
        }

        public static zzk zzbe(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.request.IAdRequestService");
            if (iInterface != null && iInterface instanceof zzk) {
                return (zzk)iInterface;
            }
            return new zza(iBinder);
        }

        public IBinder asBinder() {
            return this;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean onTransact(int n, Parcel object, Parcel parcel, int n2) throws RemoteException {
            AdRequestInfoParcel adRequestInfoParcel = null;
            AdRequestInfoParcel adRequestInfoParcel2 = null;
            switch (n) {
                default: {
                    return super.onTransact(n, (Parcel)object, parcel, n2);
                }
                case 1598968902: {
                    parcel.writeString("com.google.android.gms.ads.internal.request.IAdRequestService");
                    return true;
                }
                case 1: {
                    object.enforceInterface("com.google.android.gms.ads.internal.request.IAdRequestService");
                    if (object.readInt() != 0) {
                        adRequestInfoParcel2 = (AdRequestInfoParcel)AdRequestInfoParcel.CREATOR.createFromParcel((Parcel)object);
                    }
                    object = this.zzd(adRequestInfoParcel2);
                    parcel.writeNoException();
                    if (object != null) {
                        parcel.writeInt(1);
                        object.writeToParcel(parcel, 1);
                        do {
                            return true;
                            break;
                        } while (true);
                    }
                    parcel.writeInt(0);
                    return true;
                }
                case 2: 
            }
            object.enforceInterface("com.google.android.gms.ads.internal.request.IAdRequestService");
            adRequestInfoParcel2 = adRequestInfoParcel;
            if (object.readInt() != 0) {
                adRequestInfoParcel2 = (AdRequestInfoParcel)AdRequestInfoParcel.CREATOR.createFromParcel((Parcel)object);
            }
            this.zza(adRequestInfoParcel2, zzl.zza.zzbf(object.readStrongBinder()));
            parcel.writeNoException();
            return true;
        }

        private static class zza
        implements zzk {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(AdRequestInfoParcel adRequestInfoParcel, zzl zzl2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.request.IAdRequestService");
                    if (adRequestInfoParcel != null) {
                        parcel.writeInt(1);
                        adRequestInfoParcel.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    adRequestInfoParcel = zzl2 != null ? zzl2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)adRequestInfoParcel);
                    this.zzajq.transact(2, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public AdResponseParcel zzd(AdRequestInfoParcel abstractSafeParcelable) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.ads.internal.request.IAdRequestService");
                    if (abstractSafeParcelable != null) {
                        parcel.writeInt(1);
                        abstractSafeParcelable.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(1, parcel, parcel2, 0);
                    parcel2.readException();
                    abstractSafeParcelable = parcel2.readInt() != 0 ? (AdResponseParcel)AdResponseParcel.CREATOR.createFromParcel(parcel2) : null;
                    return abstractSafeParcelable;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

