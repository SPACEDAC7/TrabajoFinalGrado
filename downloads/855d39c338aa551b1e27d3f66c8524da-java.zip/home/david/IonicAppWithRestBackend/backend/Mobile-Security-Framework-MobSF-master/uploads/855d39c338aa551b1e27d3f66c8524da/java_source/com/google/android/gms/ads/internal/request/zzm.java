/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.ParcelFileDescriptor
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.request;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.request.LargeParcelTeleporter;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzm
implements Parcelable.Creator<LargeParcelTeleporter> {
    static void zza(LargeParcelTeleporter largeParcelTeleporter, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, largeParcelTeleporter.mVersionCode);
        zzb.zza(parcel, 2, (Parcelable)largeParcelTeleporter.zzcme, n, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzq(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzax(n);
    }

    public LargeParcelTeleporter[] zzax(int n) {
        return new LargeParcelTeleporter[n];
    }

    public LargeParcelTeleporter zzq(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        ParcelFileDescriptor parcelFileDescriptor = null;
        block4 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block4;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block4;
                }
                case 2: 
            }
            parcelFileDescriptor = (ParcelFileDescriptor)zza.zza(parcel, n3, ParcelFileDescriptor.CREATOR);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new LargeParcelTeleporter(n2, parcelFileDescriptor);
    }
}

