/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.reward.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.reward.client.RewardedVideoAdRequestParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzh
implements Parcelable.Creator<RewardedVideoAdRequestParcel> {
    static void zza(RewardedVideoAdRequestParcel rewardedVideoAdRequestParcel, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, rewardedVideoAdRequestParcel.versionCode);
        zzb.zza(parcel, 2, rewardedVideoAdRequestParcel.zzcju, n, false);
        zzb.zza(parcel, 3, rewardedVideoAdRequestParcel.zzarg, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzs(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzba(n);
    }

    public RewardedVideoAdRequestParcel[] zzba(int n) {
        return new RewardedVideoAdRequestParcel[n];
    }

    public RewardedVideoAdRequestParcel zzs(Parcel parcel) {
        String string2 = null;
        int n = zza.zzcr(parcel);
        int n2 = 0;
        AdRequestParcel adRequestParcel = null;
        block5 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block5;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block5;
                }
                case 2: {
                    adRequestParcel = zza.zza(parcel, n3, AdRequestParcel.CREATOR);
                    continue block5;
                }
                case 3: 
            }
            string2 = zza.zzq(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new RewardedVideoAdRequestParcel(n2, adRequestParcel, string2);
    }
}

