/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.reward.mediation.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.reward.mediation.client.RewardItemParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzc
implements Parcelable.Creator<RewardItemParcel> {
    static void zza(RewardItemParcel rewardItemParcel, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, rewardItemParcel.versionCode);
        zzb.zza(parcel, 2, rewardItemParcel.type, false);
        zzb.zzc(parcel, 3, rewardItemParcel.zzcsc);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzt(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzbd(n);
    }

    public RewardItemParcel[] zzbd(int n) {
        return new RewardItemParcel[n];
    }

    public RewardItemParcel zzt(Parcel parcel) {
        int n = 0;
        int n2 = zza.zzcr(parcel);
        String string2 = null;
        int n3 = 0;
        block5 : while (parcel.dataPosition() < n2) {
            int n4 = zza.zzcq(parcel);
            switch (zza.zzgu(n4)) {
                default: {
                    zza.zzb(parcel, n4);
                    continue block5;
                }
                case 1: {
                    n3 = zza.zzg(parcel, n4);
                    continue block5;
                }
                case 2: {
                    string2 = zza.zzq(parcel, n4);
                    continue block5;
                }
                case 3: 
            }
            n = zza.zzg(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new RewardItemParcel(n3, string2, n);
    }
}

