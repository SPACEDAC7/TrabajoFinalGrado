/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.safebrowsing;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.safebrowsing.SafeBrowsingConfigParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import java.util.ArrayList;
import java.util.List;

public class zzb
implements Parcelable.Creator<SafeBrowsingConfigParcel> {
    static void zza(SafeBrowsingConfigParcel safeBrowsingConfigParcel, Parcel parcel, int n) {
        n = com.google.android.gms.common.internal.safeparcel.zzb.zzcs(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1, safeBrowsingConfigParcel.versionCode);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 2, safeBrowsingConfigParcel.zzcsd, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 3, safeBrowsingConfigParcel.zzcse, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 4, safeBrowsingConfigParcel.zzcsf);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 5, safeBrowsingConfigParcel.zzcsg);
        com.google.android.gms.common.internal.safeparcel.zzb.zzb(parcel, 6, safeBrowsingConfigParcel.zzcsh, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzu(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzbe(n);
    }

    public SafeBrowsingConfigParcel[] zzbe(int n) {
        return new SafeBrowsingConfigParcel[n];
    }

    public SafeBrowsingConfigParcel zzu(Parcel parcel) {
        ArrayList<String> arrayList = null;
        boolean bl = false;
        int n = zza.zzcr(parcel);
        boolean bl2 = false;
        String string2 = null;
        String string3 = null;
        int n2 = 0;
        block8 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block8;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block8;
                }
                case 2: {
                    string3 = zza.zzq(parcel, n3);
                    continue block8;
                }
                case 3: {
                    string2 = zza.zzq(parcel, n3);
                    continue block8;
                }
                case 4: {
                    bl2 = zza.zzc(parcel, n3);
                    continue block8;
                }
                case 5: {
                    bl = zza.zzc(parcel, n3);
                    continue block8;
                }
                case 6: 
            }
            arrayList = zza.zzae(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new SafeBrowsingConfigParcel(n2, string3, string2, bl2, bl, arrayList);
    }
}

