/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.google.android.gms.ads.internal.safebrowsing;

import android.view.View;
import java.util.Map;

public interface zzc {
    public void zzb(String var1, Map<String, String> var2);

    public void zzcu(String var1);

    public void zzp(View var1);

    public void zzuf();
}

