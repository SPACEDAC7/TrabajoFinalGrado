/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.net.Uri$Builder
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.Display
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.WindowManager
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.TextView
 */
package com.google.android.gms.ads.internal.util.client;

import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.doubleclick.PublisherAdView;
import com.google.android.gms.ads.doubleclick.PublisherInterstitialAd;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.util.client.zzc;
import com.google.android.gms.ads.search.SearchAdView;
import com.google.android.gms.common.util.zzs;
import com.google.android.gms.internal.zzji;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.Set;
import java.util.StringTokenizer;

@zzji
public class zza {
    public static final Handler zzcxr = new Handler(Looper.getMainLooper());
    private static final String zzcxs = AdView.class.getName();
    private static final String zzcxt = InterstitialAd.class.getName();
    private static final String zzcxu = PublisherAdView.class.getName();
    private static final String zzcxv = PublisherInterstitialAd.class.getName();
    private static final String zzcxw = SearchAdView.class.getName();
    private static final String zzcxx = AdLoader.class.getName();

    private void zza(ViewGroup viewGroup, AdSizeParcel adSizeParcel, String string2, int n, int n2) {
        if (viewGroup.getChildCount() != 0) {
            return;
        }
        Context context = viewGroup.getContext();
        TextView textView = new TextView(context);
        textView.setGravity(17);
        textView.setText((CharSequence)string2);
        textView.setTextColor(n);
        textView.setBackgroundColor(n2);
        string2 = new FrameLayout(context);
        string2.setBackgroundColor(n);
        n = this.zzb(context, 3);
        string2.addView((View)textView, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(adSizeParcel.widthPixels - n, adSizeParcel.heightPixels - n, 17));
        viewGroup.addView((View)string2, adSizeParcel.widthPixels, adSizeParcel.heightPixels);
    }

    public int zza(DisplayMetrics displayMetrics, int n) {
        return (int)TypedValue.applyDimension((int)1, (float)n, (DisplayMetrics)displayMetrics);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Nullable
    public String zza(StackTraceElement[] object, String string2) {
        block3 : {
            int n = 0;
            while (n + 1 < object.length) {
                Object object2 = object[n];
                String string3 = object2.getClassName();
                if ("loadAd".equalsIgnoreCase(object2.getMethodName()) && (zzcxs.equalsIgnoreCase(string3) || zzcxt.equalsIgnoreCase(string3) || zzcxu.equalsIgnoreCase(string3) || zzcxv.equalsIgnoreCase(string3) || zzcxw.equalsIgnoreCase(string3) || zzcxx.equalsIgnoreCase(string3))) {
                    object = object[n + 1].getClassName();
                    break block3;
                }
                ++n;
            }
            object = null;
        }
        if (string2 == null) return null;
        string2 = this.zzb(string2, ".", 3);
        if (object != null && !object.contains(string2)) {
            return object;
        }
        return null;
    }

    public void zza(Context context, @Nullable String string2, String string3, Bundle bundle, boolean bl) {
        this.zza(context, string2, string3, bundle, bl, new zza(){

            @Override
            public void zzv(final String string2) {
                new Thread(){

                    @Override
                    public void run() {
                        new zzc().zzv(string2);
                    }
                }.start();
            }

        });
    }

    public void zza(Context context, @Nullable String object, String string22, Bundle bundle, boolean bl, zza zza2) {
        if (bl) {
            Context context2;
            Object object2 = context2 = context.getApplicationContext();
            if (context2 == null) {
                object2 = context;
            }
            bundle.putString("os", Build.VERSION.RELEASE);
            bundle.putString("api", String.valueOf(Build.VERSION.SDK_INT));
            bundle.putString("appid", object2.getPackageName());
            object2 = object;
            if (object == null) {
                int n = com.google.android.gms.common.zzc.zzaql().zzbk(context);
                object2 = new StringBuilder(23).append(n).append(".").append(9877000).toString();
            }
            bundle.putString("js", (String)object2);
        }
        context = new Uri.Builder().scheme("https").path("//pagead2.googlesyndication.com/pagead/gen_204").appendQueryParameter("id", string22);
        for (String string22 : bundle.keySet()) {
            context.appendQueryParameter(string22, bundle.getString(string22));
        }
        zza2.zzv(context.toString());
    }

    public void zza(ViewGroup viewGroup, AdSizeParcel adSizeParcel, String string2) {
        this.zza(viewGroup, adSizeParcel, string2, -16777216, -1);
    }

    public void zza(ViewGroup viewGroup, AdSizeParcel adSizeParcel, String string2, String string3) {
        zzb.zzdi(string3);
        this.zza(viewGroup, adSizeParcel, string2, -65536, -16777216);
    }

    public void zza(boolean bl, HttpURLConnection httpURLConnection, @Nullable String string2) {
        httpURLConnection.setConnectTimeout(60000);
        httpURLConnection.setInstanceFollowRedirects(bl);
        httpURLConnection.setReadTimeout(60000);
        if (string2 != null) {
            httpURLConnection.setRequestProperty("User-Agent", string2);
        }
        httpURLConnection.setUseCaches(false);
    }

    /*
     * Enabled aggressive block sorting
     */
    public String zzao(Context object) {
        object = (object = object.getContentResolver()) == null ? null : Settings.Secure.getString((ContentResolver)object, (String)"android_id");
        if (object == null || this.zzwp()) {
            object = "emulator";
        }
        return this.zzdf((String)object);
    }

    public boolean zzap(Context context) {
        if (com.google.android.gms.common.zzc.zzaql().isGooglePlayServicesAvailable(context) == 0) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean zzaq(Context context) {
        if (context.getResources().getConfiguration().orientation != 2) {
            return false;
        }
        context = context.getResources().getDisplayMetrics();
        if ((int)((float)context.heightPixels / context.density) >= 600) return false;
        return true;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @TargetApi(value=17)
    public boolean zzar(Context context) {
        int n;
        int n2;
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        context = ((WindowManager)context.getSystemService("window")).getDefaultDisplay();
        if (zzs.zzays()) {
            context.getRealMetrics(displayMetrics);
            n = displayMetrics.heightPixels;
            n2 = displayMetrics.widthPixels;
        } else {
            n = (Integer)Display.class.getMethod("getRawHeight", new Class[0]).invoke((Object)context, new Object[0]);
            n2 = (Integer)Display.class.getMethod("getRawWidth", new Class[0]).invoke((Object)context, new Object[0]);
        }
        context.getMetrics(displayMetrics);
        int n3 = displayMetrics.heightPixels;
        int n4 = displayMetrics.widthPixels;
        if (n3 != n) return false;
        if (n4 != n2) return false;
        return true;
        catch (Exception exception) {
            return false;
        }
    }

    public int zzas(Context context) {
        int n = context.getResources().getIdentifier("navigation_bar_width", "dimen", "android");
        if (n > 0) {
            return context.getResources().getDimensionPixelSize(n);
        }
        return 0;
    }

    public int zzb(Context context, int n) {
        return this.zza(context.getResources().getDisplayMetrics(), n);
    }

    public int zzb(DisplayMetrics displayMetrics, int n) {
        return Math.round((float)n / displayMetrics.density);
    }

    String zzb(String string2, String string3, int n) {
        StringTokenizer stringTokenizer = new StringTokenizer(string2, string3);
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = n - 1;
        string3 = string2;
        if (n > 0) {
            string3 = string2;
            if (stringTokenizer.hasMoreElements()) {
                stringBuilder.append(stringTokenizer.nextToken());
                for (n = n2; n > 0 && stringTokenizer.hasMoreElements(); --n) {
                    stringBuilder.append(".").append(stringTokenizer.nextToken());
                }
                string3 = stringBuilder.toString();
            }
        }
        return string3;
    }

    public int zzc(Context context, int n) {
        context = ((WindowManager)context.getSystemService("window")).getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        context.getMetrics(displayMetrics);
        return this.zzb(displayMetrics, n);
    }

    public String zzdf(String string2) {
        for (int i = 0; i < 2; ++i) {
            try {
                Object object = MessageDigest.getInstance("MD5");
                object.update(string2.getBytes());
                object = String.format(Locale.US, "%032X", new BigInteger(1, object.digest()));
                return object;
            }
            catch (NoSuchAlgorithmException var3_3) {
                continue;
            }
        }
        return null;
    }

    public boolean zzwp() {
        return Build.DEVICE.startsWith("generic");
    }

    public boolean zzwq() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return true;
        }
        return false;
    }

    public static interface zza {
        public void zzv(String var1);
    }

}

