/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.google.android.gms.ads.internal.util.client;

import android.util.Log;
import com.google.android.gms.internal.zzji;

@zzji
public class zzb {
    public static void e(String string2) {
        if (zzb.zzbi(6)) {
            Log.e((String)"Ads", (String)string2);
        }
    }

    public static void zza(String string2, Throwable throwable) {
        if (zzb.zzbi(3)) {
            Log.d((String)"Ads", (String)string2, (Throwable)throwable);
        }
    }

    public static void zzb(String string2, Throwable throwable) {
        if (zzb.zzbi(6)) {
            Log.e((String)"Ads", (String)string2, (Throwable)throwable);
        }
    }

    public static boolean zzbi(int n) {
        if (n >= 5 || Log.isLoggable((String)"Ads", (int)n)) {
            return true;
        }
        return false;
    }

    public static void zzc(String string2, Throwable throwable) {
        if (zzb.zzbi(5)) {
            Log.w((String)"Ads", (String)string2, (Throwable)throwable);
        }
    }

    public static void zzdg(String string2) {
        if (zzb.zzbi(3)) {
            Log.d((String)"Ads", (String)string2);
        }
    }

    public static void zzdh(String string2) {
        if (zzb.zzbi(4)) {
            Log.i((String)"Ads", (String)string2);
        }
    }

    public static void zzdi(String string2) {
        if (zzb.zzbi(5)) {
            Log.w((String)"Ads", (String)string2);
        }
    }
}

