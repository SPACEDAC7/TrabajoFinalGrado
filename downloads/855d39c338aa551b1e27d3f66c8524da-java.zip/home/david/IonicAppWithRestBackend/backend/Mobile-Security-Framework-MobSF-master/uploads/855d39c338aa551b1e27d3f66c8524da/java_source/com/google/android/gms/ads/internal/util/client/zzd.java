/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal.util.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzd
implements Parcelable.Creator<VersionInfoParcel> {
    static void zza(VersionInfoParcel versionInfoParcel, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, versionInfoParcel.versionCode);
        zzb.zza(parcel, 2, versionInfoParcel.zzda, false);
        zzb.zzc(parcel, 3, versionInfoParcel.zzcya);
        zzb.zzc(parcel, 4, versionInfoParcel.zzcyb);
        zzb.zza(parcel, 5, versionInfoParcel.zzcyc);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzv(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzbj(n);
    }

    public VersionInfoParcel[] zzbj(int n) {
        return new VersionInfoParcel[n];
    }

    public VersionInfoParcel zzv(Parcel parcel) {
        boolean bl = false;
        int n = zza.zzcr(parcel);
        String string2 = null;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        block7 : while (parcel.dataPosition() < n) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block7;
                }
                case 1: {
                    n4 = zza.zzg(parcel, n5);
                    continue block7;
                }
                case 2: {
                    string2 = zza.zzq(parcel, n5);
                    continue block7;
                }
                case 3: {
                    n3 = zza.zzg(parcel, n5);
                    continue block7;
                }
                case 4: {
                    n2 = zza.zzg(parcel, n5);
                    continue block7;
                }
                case 5: 
            }
            bl = zza.zzc(parcel, n5);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new VersionInfoParcel(n4, string2, n3, n2, bl);
    }
}

