/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.internal;

import com.google.android.gms.ads.internal.overlay.zzj;
import com.google.android.gms.ads.internal.overlay.zzm;
import com.google.android.gms.ads.internal.overlay.zzn;
import com.google.android.gms.ads.internal.overlay.zzt;
import com.google.android.gms.ads.internal.safebrowsing.zza;
import com.google.android.gms.internal.zzfb;
import com.google.android.gms.internal.zzfu;
import com.google.android.gms.internal.zzji;

@zzji
public class zzd {
    public final zzfu zzamp;
    public final zzj zzamq;
    public final zzm zzamr;
    public final com.google.android.gms.ads.internal.safebrowsing.zzd zzams;

    public zzd(zzfu zzfu2, zzj zzj2, zzm zzm2, com.google.android.gms.ads.internal.safebrowsing.zzd zzd2) {
        this.zzamp = zzfu2;
        this.zzamq = zzj2;
        this.zzamr = zzm2;
        this.zzams = zzd2;
    }

    public static zzd zzfd() {
        return new zzd(new zzfb(), new zzn(), new zzt(), new zza());
    }
}

