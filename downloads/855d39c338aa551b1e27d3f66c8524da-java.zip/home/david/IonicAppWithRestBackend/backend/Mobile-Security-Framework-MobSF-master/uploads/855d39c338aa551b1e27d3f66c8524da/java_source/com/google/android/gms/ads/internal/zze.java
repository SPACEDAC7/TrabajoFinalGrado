/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.text.TextUtils
 */
package com.google.android.gms.ads.internal;

import android.content.Context;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.request.AutoClickProtectionConfigurationParcel;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzko;
import com.google.android.gms.internal.zzkx;
import java.util.Iterator;
import java.util.List;

@zzji
public class zze {
    private final Context mContext;
    private final AutoClickProtectionConfigurationParcel zzamt;
    private boolean zzamu;

    public zze(Context context) {
        this(context, false);
    }

    public zze(Context context, @Nullable zzko.zza zza2) {
        this.mContext = context;
        if (zza2 != null && zza2.zzcsu.zzclu != null) {
            this.zzamt = zza2.zzcsu.zzclu;
            return;
        }
        this.zzamt = new AutoClickProtectionConfigurationParcel();
    }

    public zze(Context context, boolean bl) {
        this.mContext = context;
        this.zzamt = new AutoClickProtectionConfigurationParcel(bl);
    }

    public void recordClick() {
        this.zzamu = true;
    }

    public boolean zzfe() {
        if (!this.zzamt.zzclz || this.zzamu) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void zzy(@Nullable String string2) {
        if (string2 == null) {
            string2 = "";
        }
        zzkx.zzdh("Action was blocked because no touch was detected.");
        if (this.zzamt.zzclz && this.zzamt.zzcma != null) {
            Iterator<String> iterator = this.zzamt.zzcma.iterator();
            while (iterator.hasNext()) {
                String string3 = iterator.next();
                if (TextUtils.isEmpty((CharSequence)string3)) continue;
                string3 = string3.replace("{NAVIGATION_URL}", Uri.encode((String)string2));
                zzu.zzgm().zzc(this.mContext, "", string3);
            }
        }
    }
}

