/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 *  android.text.TextUtils
 *  org.json.JSONObject
 */
package com.google.android.gms.ads.internal;

import android.content.Context;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zzdn;
import com.google.android.gms.internal.zzdr;
import com.google.android.gms.internal.zzfe;
import com.google.android.gms.internal.zzgh;
import com.google.android.gms.internal.zzgi;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkq;
import com.google.android.gms.internal.zzkx;
import com.google.android.gms.internal.zzlb;
import com.google.android.gms.internal.zzlw;
import com.google.android.gms.internal.zzmd;
import java.util.Map;
import java.util.concurrent.Future;
import org.json.JSONObject;

@zzji
public class zzg {
    private Context mContext;
    private final Object zzako = new Object();
    public final zzfe zzana;

    public zzg() {
        this.zzana = new zzfe(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzmd object, Map<String, String> object2) {
                object.zzb("/appSettingsFetched", this);
                object = zzg.this.zzako;
                synchronized (object) {
                    if (object2 != null && "true".equalsIgnoreCase(object2.get("isSuccessful"))) {
                        object2 = object2.get("appSettingsJson");
                        zzu.zzgq().zzd(zzg.this.mContext, (String)object2);
                    }
                    return;
                }
            }
        };
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean zza(@Nullable zzkq zzkq2) {
        if (zzkq2 == null) {
            return true;
        }
        long l = zzkq2.zzum();
        if (zzu.zzgs().currentTimeMillis() - l > zzdr.zzbjx.get()) {
            return true;
        }
        boolean bl = false;
        if (bl) return true;
        if (!zzkq2.zzun()) return true;
        return false;
    }

    public void zza(Context context, VersionInfoParcel object, boolean bl, @Nullable zzkq zzkq2, String string2, @Nullable String string3) {
        if (!zzg.zza(zzkq2)) {
            return;
        }
        if (context == null) {
            zzkx.zzdi("Context not provided to fetch application settings");
            return;
        }
        if (TextUtils.isEmpty((CharSequence)string2) && TextUtils.isEmpty((CharSequence)string3)) {
            zzkx.zzdi("App settings could not be fetched. Required parameters missing");
            return;
        }
        this.mContext = context;
        object = zzu.zzgm().zzd(context, (VersionInfoParcel)object);
        zzlb.zzcvl.post(new Runnable((zzgh)object, string2, string3, bl, context){
            final /* synthetic */ zzgh zzanc;
            final /* synthetic */ String zzand;
            final /* synthetic */ String zzane;
            final /* synthetic */ boolean zzanf;
            final /* synthetic */ Context zzang;

            @Override
            public void run() {
                this.zzanc.zzny().zza(new zzlw.zzc<zzgi>(){

                    /*
                     * Enabled aggressive block sorting
                     * Enabled unnecessary exception pruning
                     * Enabled aggressive exception aggregation
                     */
                    public void zzb(zzgi zzgi2) {
                        zzgi2.zza("/appSettingsFetched", zzg.this.zzana);
                        try {
                            JSONObject jSONObject = new JSONObject();
                            if (!TextUtils.isEmpty((CharSequence)2.this.zzand)) {
                                jSONObject.put("app_id", (Object)2.this.zzand);
                            } else if (!TextUtils.isEmpty((CharSequence)2.this.zzane)) {
                                jSONObject.put("ad_unit_id", (Object)2.this.zzane);
                            }
                            jSONObject.put("is_init", 2.this.zzanf);
                            jSONObject.put("pn", (Object)2.this.zzang.getPackageName());
                            zzgi2.zza("AFMA_fetchAppSettings", jSONObject);
                            return;
                        }
                        catch (Exception var2_3) {
                            zzgi2.zzb("/appSettingsFetched", zzg.this.zzana);
                            zzkx.zzb("Error requesting application settings", var2_3);
                            return;
                        }
                    }

                    @Override
                    public /* synthetic */ void zzd(Object object) {
                        this.zzb((zzgi)object);
                    }
                }, new zzlw.zzb());
            }

        });
    }

}

