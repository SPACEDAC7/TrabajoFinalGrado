/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.google.android.gms.ads.internal;

import android.view.View;

public interface zzh {
    public void zzc(View var1);

    public void zzfa();

    public void zzfb();
}

