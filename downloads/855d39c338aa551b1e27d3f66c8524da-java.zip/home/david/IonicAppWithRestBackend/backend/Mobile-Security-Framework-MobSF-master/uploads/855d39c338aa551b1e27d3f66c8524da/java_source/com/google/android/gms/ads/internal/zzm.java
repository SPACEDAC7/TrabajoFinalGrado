/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.ads.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.InterstitialAdParameterParcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzm
implements Parcelable.Creator<InterstitialAdParameterParcel> {
    static void zza(InterstitialAdParameterParcel interstitialAdParameterParcel, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, interstitialAdParameterParcel.versionCode);
        zzb.zza(parcel, 2, interstitialAdParameterParcel.zzaok);
        zzb.zza(parcel, 3, interstitialAdParameterParcel.zzaol);
        zzb.zza(parcel, 4, interstitialAdParameterParcel.zzaom, false);
        zzb.zza(parcel, 5, interstitialAdParameterParcel.zzaon);
        zzb.zza(parcel, 6, interstitialAdParameterParcel.zzaoo);
        zzb.zzc(parcel, 7, interstitialAdParameterParcel.zzaop);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzb(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzi(n);
    }

    public InterstitialAdParameterParcel zzb(Parcel parcel) {
        int n = 0;
        int n2 = zza.zzcr(parcel);
        String string2 = null;
        float f = 0.0f;
        boolean bl = false;
        boolean bl2 = false;
        boolean bl3 = false;
        int n3 = 0;
        block9 : while (parcel.dataPosition() < n2) {
            int n4 = zza.zzcq(parcel);
            switch (zza.zzgu(n4)) {
                default: {
                    zza.zzb(parcel, n4);
                    continue block9;
                }
                case 1: {
                    n3 = zza.zzg(parcel, n4);
                    continue block9;
                }
                case 2: {
                    bl3 = zza.zzc(parcel, n4);
                    continue block9;
                }
                case 3: {
                    bl2 = zza.zzc(parcel, n4);
                    continue block9;
                }
                case 4: {
                    string2 = zza.zzq(parcel, n4);
                    continue block9;
                }
                case 5: {
                    bl = zza.zzc(parcel, n4);
                    continue block9;
                }
                case 6: {
                    f = zza.zzl(parcel, n4);
                    continue block9;
                }
                case 7: 
            }
            n = zza.zzg(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new InterstitialAdParameterParcel(n3, bl3, bl2, string2, bl, f, n);
    }

    public InterstitialAdParameterParcel[] zzi(int n) {
        return new InterstitialAdParameterParcel[n];
    }
}

