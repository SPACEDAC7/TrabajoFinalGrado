/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.RemoteException
 *  android.text.TextUtils
 *  android.util.Base64
 *  android.view.View
 *  android.view.View$OnClickListener
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.google.android.gms.ads.internal;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import com.google.android.gms.ads.internal.client.zzab;
import com.google.android.gms.ads.internal.formats.zza;
import com.google.android.gms.ads.internal.formats.zzd;
import com.google.android.gms.ads.internal.formats.zze;
import com.google.android.gms.ads.internal.zzf;
import com.google.android.gms.internal.zzeg;
import com.google.android.gms.internal.zzfe;
import com.google.android.gms.internal.zzgp;
import com.google.android.gms.internal.zzgu;
import com.google.android.gms.internal.zzha;
import com.google.android.gms.internal.zzhd;
import com.google.android.gms.internal.zzhe;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzko;
import com.google.android.gms.internal.zzkx;
import com.google.android.gms.internal.zzmd;
import com.google.android.gms.internal.zzme;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@zzji
public class zzn {
    private static zzd zza(zzhd zzhd2) throws RemoteException {
        return new zzd(zzhd2.getHeadline(), zzhd2.getImages(), zzhd2.getBody(), zzhd2.zzmo(), zzhd2.getCallToAction(), zzhd2.getStarRating(), zzhd2.getStore(), zzhd2.getPrice(), null, zzhd2.getExtras(), null, null);
    }

    private static zze zza(zzhe zzhe2) throws RemoteException {
        return new zze(zzhe2.getHeadline(), zzhe2.getImages(), zzhe2.getBody(), zzhe2.zzmt(), zzhe2.getCallToAction(), zzhe2.getAdvertiser(), null, zzhe2.getExtras());
    }

    static zzfe zza(@Nullable zzhd zzhd2, final @Nullable zzhe zzhe2, final zzf.zza zza2) {
        return new zzfe(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            @Override
            public void zza(zzmd zzmd2, Map<String, String> view) {
                view = zzmd2.getView();
                if (view == null) {
                    return;
                }
                try {
                    if (zzhd.this != null) {
                        if (!zzhd.this.getOverrideClickHandling()) {
                            zzhd.this.zzk(com.google.android.gms.dynamic.zze.zzac(view));
                            zza2.onClick();
                            return;
                        }
                        zzn.zza(zzmd2);
                        return;
                    }
                }
                catch (RemoteException var1_2) {
                    zzkx.zzc("Unable to call handleClick on mapper", (Throwable)var1_2);
                    return;
                }
                if (zzhe2 == null) return;
                if (!zzhe2.getOverrideClickHandling()) {
                    zzhe2.zzk(com.google.android.gms.dynamic.zze.zzac(view));
                    zza2.onClick();
                    return;
                }
                zzn.zza(zzmd2);
            }
        };
    }

    static zzfe zza(CountDownLatch countDownLatch) {
        return new zzfe(){

            @Override
            public void zza(zzmd zzmd2, Map<String, String> map) {
                CountDownLatch.this.countDown();
                zzmd2.getView().setVisibility(0);
            }
        };
    }

    private static String zza(@Nullable Bitmap object) {
        Object object2 = new ByteArrayOutputStream();
        if (object == null) {
            zzkx.zzdi("Bitmap is null. Returning empty string");
            return "";
        }
        object.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream)object2);
        object2 = Base64.encodeToString((byte[])object2.toByteArray(), (int)0);
        object = String.valueOf("data:image/png;base64,");
        object2 = String.valueOf(object2);
        if (object2.length() != 0) {
            return object.concat((String)object2);
        }
        return new String((String)object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static String zza(@Nullable zzeg zzeg2) {
        if (zzeg2 == null) {
            zzkx.zzdi("Image is null. Returning empty string");
            return "";
        }
        Uri uri = zzeg2.getUri();
        if (uri == null) return zzn.zzb(zzeg2);
        try {
            return uri.toString();
        }
        catch (RemoteException var1_2) {
            zzkx.zzdi("Unable to get image uri. Trying data uri next");
        }
        return zzn.zzb(zzeg2);
    }

    private static JSONObject zza(@Nullable Bundle bundle, String string2) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        if (bundle == null || TextUtils.isEmpty((CharSequence)string2)) {
            return jSONObject;
        }
        string2 = new JSONObject(string2);
        Iterator iterator = string2.keys();
        while (iterator.hasNext()) {
            String string3 = (String)iterator.next();
            if (!bundle.containsKey(string3)) continue;
            if ("image".equals(string2.getString(string3))) {
                Object object = bundle.get(string3);
                if (object instanceof Bitmap) {
                    jSONObject.put(string3, (Object)zzn.zza((Bitmap)object));
                    continue;
                }
                zzkx.zzdi("Invalid type. An image type extra should return a bitmap");
                continue;
            }
            if (bundle.get(string3) instanceof Bitmap) {
                zzkx.zzdi("Invalid asset type. Bitmap should be returned only for image type");
                continue;
            }
            jSONObject.put(string3, (Object)String.valueOf(bundle.get(string3)));
        }
        return jSONObject;
    }

    /*
     * Exception decompiling
     */
    public static void zza(@Nullable zzko var0, zzf.zza var1_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl23 : TryStatement: try { 1[TRYBLOCK]

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps.apply(RemoveDeterministicJumps.java:35)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:519)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private static void zza(zzmd zzmd2) {
        View.OnClickListener onClickListener = zzmd2.zzxr();
        if (onClickListener != null) {
            onClickListener.onClick(zzmd2.getView());
        }
    }

    private static void zza(final zzmd zzmd2, zzd zzd2, final String string2) {
        zzmd2.zzxc().zza(new zzme.zza(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzmd zzmd22, boolean bl) {
                try {
                    zzmd22 = new JSONObject();
                    zzmd22.put("headline", (Object)zzd.this.getHeadline());
                    zzmd22.put("body", (Object)zzd.this.getBody());
                    zzmd22.put("call_to_action", (Object)zzd.this.getCallToAction());
                    zzmd22.put("price", (Object)zzd.this.getPrice());
                    zzmd22.put("star_rating", (Object)String.valueOf(zzd.this.getStarRating()));
                    zzmd22.put("store", (Object)zzd.this.getStore());
                    zzmd22.put("icon", (Object)zzn.zza(zzd.this.zzmo()));
                    JSONArray jSONArray = new JSONArray();
                    Object object = zzd.this.getImages();
                    if (object != null) {
                        object = object.iterator();
                        while (object.hasNext()) {
                            jSONArray.put((Object)zzn.zza(zzn.zze(object.next())));
                        }
                    }
                    zzmd22.put("images", (Object)jSONArray);
                    zzmd22.put("extras", (Object)zzn.zza(zzd.this.getExtras(), string2));
                    jSONArray = new JSONObject();
                    jSONArray.put("assets", (Object)zzmd22);
                    jSONArray.put("template_id", (Object)"2");
                    zzmd2.zza("google.afma.nativeExpressAds.loadAssets", (JSONObject)jSONArray);
                    return;
                }
                catch (JSONException var1_2) {
                    zzkx.zzc("Exception occurred when loading assets", (Throwable)var1_2);
                    return;
                }
            }
        });
    }

    private static void zza(final zzmd zzmd2, zze zze2, final String string2) {
        zzmd2.zzxc().zza(new zzme.zza(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzmd zzmd22, boolean bl) {
                try {
                    zzmd22 = new JSONObject();
                    zzmd22.put("headline", (Object)zze.this.getHeadline());
                    zzmd22.put("body", (Object)zze.this.getBody());
                    zzmd22.put("call_to_action", (Object)zze.this.getCallToAction());
                    zzmd22.put("advertiser", (Object)zze.this.getAdvertiser());
                    zzmd22.put("logo", (Object)zzn.zza(zze.this.zzmt()));
                    JSONArray jSONArray = new JSONArray();
                    Object object = zze.this.getImages();
                    if (object != null) {
                        object = object.iterator();
                        while (object.hasNext()) {
                            jSONArray.put((Object)zzn.zza(zzn.zze(object.next())));
                        }
                    }
                    zzmd22.put("images", (Object)jSONArray);
                    zzmd22.put("extras", (Object)zzn.zza(zze.this.getExtras(), string2));
                    jSONArray = new JSONObject();
                    jSONArray.put("assets", (Object)zzmd22);
                    jSONArray.put("template_id", (Object)"1");
                    zzmd2.zza("google.afma.nativeExpressAds.loadAssets", (JSONObject)jSONArray);
                    return;
                }
                catch (JSONException var1_2) {
                    zzkx.zzc("Exception occurred when loading assets", (Throwable)var1_2);
                    return;
                }
            }
        });
    }

    private static void zza(zzmd zzmd2, CountDownLatch countDownLatch) {
        zzmd2.zzxc().zza("/nativeExpressAssetsLoaded", zzn.zza(countDownLatch));
        zzmd2.zzxc().zza("/nativeExpressAssetsLoadingFailed", zzn.zzb(countDownLatch));
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean zza(zzmd zzmd2, zzgu zzgu2, CountDownLatch countDownLatch) {
        boolean bl = false;
        try {
            boolean bl2;
            bl = bl2 = zzn.zzb(zzmd2, zzgu2, countDownLatch);
        }
        catch (RemoteException var0_1) {
            zzkx.zzc("Unable to invoke load assets", (Throwable)var0_1);
        }
        if (bl) return bl;
        countDownLatch.countDown();
        return bl;
        catch (RuntimeException runtimeException) {
            countDownLatch.countDown();
            throw runtimeException;
        }
    }

    static zzfe zzb(CountDownLatch countDownLatch) {
        return new zzfe(){

            @Override
            public void zza(zzmd zzmd2, Map<String, String> map) {
                zzkx.zzdi("Adapter returned an ad, but assets substitution failed");
                CountDownLatch.this.countDown();
                zzmd2.destroy();
            }
        };
    }

    private static String zzb(zzeg object) {
        block5 : {
            try {
                object = object.zzmn();
                if (object != null) break block5;
            }
            catch (RemoteException var0_1) {
                zzkx.zzdi("Unable to get drawable. Returning empty string");
                return "";
            }
            zzkx.zzdi("Drawable is null. Returning empty string");
            return "";
        }
        object = (Drawable)com.google.android.gms.dynamic.zze.zzae((com.google.android.gms.dynamic.zzd)object);
        if (!(object instanceof BitmapDrawable)) {
            zzkx.zzdi("Drawable is not an instance of BitmapDrawable. Returning empty string");
            return "";
        }
        return zzn.zza(((BitmapDrawable)object).getBitmap());
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean zzb(zzmd zzmd2, zzgu object, CountDownLatch object2) throws RemoteException {
        Object object3 = zzmd2.getView();
        if (object3 == null) {
            zzkx.zzdi("AdWebView is null");
            return false;
        }
        object3.setVisibility(4);
        object3 = object.zzbwm.zzbvg;
        if (object3 == null || object3.isEmpty()) {
            zzkx.zzdi("No template ids present in mediation response");
            return false;
        }
        zzn.zza(zzmd2, (CountDownLatch)object2);
        object2 = object.zzbwn.zzom();
        zzhe zzhe2 = object.zzbwn.zzon();
        if (object3.contains("2") && object2 != null) {
            zzn.zza(zzmd2, zzn.zza((zzhd)object2), object.zzbwm.zzbvf);
        } else {
            if (!object3.contains("1") || zzhe2 == null) {
                zzkx.zzdi("No matching template id and mapper");
                return false;
            }
            zzn.zza(zzmd2, zzn.zza(zzhe2), object.zzbwm.zzbvf);
        }
        object2 = object.zzbwm.zzbvd;
        object = object.zzbwm.zzbve;
        if (object != null) {
            zzmd2.loadDataWithBaseURL((String)object, (String)object2, "text/html", "UTF-8", null);
            return true;
        }
        zzmd2.loadData((String)object2, "text/html", "UTF-8");
        return true;
    }

    @Nullable
    private static zzeg zze(Object object) {
        if (object instanceof IBinder) {
            return zzeg.zza.zzab((IBinder)object);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Nullable
    public static View zzg(@Nullable zzko object) {
        if (object == null) {
            zzkx.e("AdState is null");
            return null;
        }
        if (zzn.zzh((zzko)object) && object.zzcbm != null) {
            return object.zzcbm.getView();
        }
        try {
            object = object.zzbwn != null ? object.zzbwn.getView() : null;
            if (object != null) return (View)com.google.android.gms.dynamic.zze.zzae((com.google.android.gms.dynamic.zzd)object);
            zzkx.zzdi("View in mediation adapter is null.");
            return null;
        }
        catch (RemoteException var0_1) {
            zzkx.zzc("Could not get View from mediation adapter.", (Throwable)var0_1);
            return null;
        }
    }

    public static boolean zzh(@Nullable zzko zzko2) {
        if (zzko2 != null && zzko2.zzclb && zzko2.zzbwm != null && zzko2.zzbwm.zzbvd != null) {
            return true;
        }
        return false;
    }

}

