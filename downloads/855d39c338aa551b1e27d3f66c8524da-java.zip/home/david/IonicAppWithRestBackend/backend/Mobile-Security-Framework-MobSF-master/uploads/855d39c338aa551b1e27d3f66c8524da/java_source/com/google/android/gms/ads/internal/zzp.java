/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.internal;

import android.support.annotation.Nullable;
import com.google.android.gms.ads.internal.zzo;
import com.google.android.gms.internal.zzji;

@zzji
public class zzp {
    @Nullable
    public zzo zzfq() {
        return zzo.zzfq();
    }
}

