/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.google.android.gms.ads.internal;

import android.os.Handler;
import android.support.annotation.Nullable;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzkx;
import com.google.android.gms.internal.zzlb;
import java.lang.ref.WeakReference;

@zzji
public class zzr {
    private final zza zzapi;
    @Nullable
    private AdRequestParcel zzapj;
    private boolean zzapk = false;
    private boolean zzapl = false;
    private long zzapm = 0;
    private final Runnable zzw;

    public zzr(com.google.android.gms.ads.internal.zza zza2) {
        this(zza2, new zza(zzlb.zzcvl));
    }

    zzr(com.google.android.gms.ads.internal.zza zza2, zza zza3) {
        this.zzapi = zza3;
        this.zzw = new Runnable(new WeakReference<com.google.android.gms.ads.internal.zza>(zza2)){
            final /* synthetic */ WeakReference zzapn;

            @Override
            public void run() {
                zzr.this.zzapk = false;
                com.google.android.gms.ads.internal.zza zza2 = (com.google.android.gms.ads.internal.zza)this.zzapn.get();
                if (zza2 != null) {
                    zza2.zzd(zzr.this.zzapj);
                }
            }
        };
    }

    public void cancel() {
        this.zzapk = false;
        this.zzapi.removeCallbacks(this.zzw);
    }

    public void pause() {
        this.zzapl = true;
        if (this.zzapk) {
            this.zzapi.removeCallbacks(this.zzw);
        }
    }

    public void resume() {
        this.zzapl = false;
        if (this.zzapk) {
            this.zzapk = false;
            this.zza(this.zzapj, this.zzapm);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void zza(AdRequestParcel adRequestParcel, long l) {
        if (this.zzapk) {
            zzkx.zzdi("An ad refresh is already scheduled.");
            return;
        } else {
            this.zzapj = adRequestParcel;
            this.zzapk = true;
            this.zzapm = l;
            if (this.zzapl) return;
            {
                zzkx.zzdh(new StringBuilder(65).append("Scheduling ad refresh ").append(l).append(" milliseconds from now.").toString());
                this.zzapi.postDelayed(this.zzw, l);
                return;
            }
        }
    }

    public boolean zzfy() {
        return this.zzapk;
    }

    public void zzg(AdRequestParcel adRequestParcel) {
        this.zzapj = adRequestParcel;
    }

    public void zzh(AdRequestParcel adRequestParcel) {
        this.zza(adRequestParcel, 60000);
    }

    public static class zza {
        private final Handler mHandler;

        public zza(Handler handler) {
            this.mHandler = handler;
        }

        public boolean postDelayed(Runnable runnable, long l) {
            return this.mHandler.postDelayed(runnable, l);
        }

        public void removeCallbacks(Runnable runnable) {
            this.mHandler.removeCallbacks(runnable);
        }
    }

}

