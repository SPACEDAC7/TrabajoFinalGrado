/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.internal;

public interface zzs {
    public void zzey();

    public void zzez();
}

