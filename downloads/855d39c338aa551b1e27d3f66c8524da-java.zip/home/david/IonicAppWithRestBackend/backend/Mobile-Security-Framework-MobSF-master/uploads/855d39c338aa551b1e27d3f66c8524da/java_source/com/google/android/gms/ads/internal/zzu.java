/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package com.google.android.gms.ads.internal;

import android.os.Build;
import com.google.android.gms.ads.internal.overlay.zza;
import com.google.android.gms.ads.internal.overlay.zze;
import com.google.android.gms.ads.internal.overlay.zzq;
import com.google.android.gms.ads.internal.overlay.zzr;
import com.google.android.gms.ads.internal.purchase.zzi;
import com.google.android.gms.ads.internal.zzg;
import com.google.android.gms.ads.internal.zzp;
import com.google.android.gms.common.util.zzh;
import com.google.android.gms.internal.zzcz;
import com.google.android.gms.internal.zzdo;
import com.google.android.gms.internal.zzdp;
import com.google.android.gms.internal.zzdq;
import com.google.android.gms.internal.zzdu;
import com.google.android.gms.internal.zzfr;
import com.google.android.gms.internal.zzfz;
import com.google.android.gms.internal.zzgl;
import com.google.android.gms.internal.zzgv;
import com.google.android.gms.internal.zziu;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzjs;
import com.google.android.gms.internal.zzkr;
import com.google.android.gms.internal.zzlb;
import com.google.android.gms.internal.zzlc;
import com.google.android.gms.internal.zzlf;
import com.google.android.gms.internal.zzlj;
import com.google.android.gms.internal.zzlk;
import com.google.android.gms.internal.zzlv;
import com.google.android.gms.internal.zzly;
import com.google.android.gms.internal.zzmf;

@zzji
public class zzu {
    private static final Object zzaox = new Object();
    private static zzu zzaqa;
    private final zza zzaqb = new zza();
    private final com.google.android.gms.ads.internal.request.zza zzaqc = new com.google.android.gms.ads.internal.request.zza();
    private final zze zzaqd = new zze();
    private final zziu zzaqe = new zziu();
    private final zzlb zzaqf = new zzlb();
    private final zzmf zzaqg = new zzmf();
    private final zzlc zzaqh = zzlc.zzbh(Build.VERSION.SDK_INT);
    private final zzcz zzaqi = new zzcz();
    private final zzkr zzaqj = new zzkr(this.zzaqf);
    private final com.google.android.gms.ads.internal.cache.zza zzaqk = new com.google.android.gms.ads.internal.cache.zza();
    private final com.google.android.gms.common.util.zze zzaql = zzh.zzayl();
    private final zzg zzaqm = new zzg();
    private final zzdu zzaqn = new zzdu();
    private final zzlf zzaqo = new zzlf();
    private final zzjs zzaqp = new zzjs();
    private final zzdo zzaqq = new zzdo();
    private final zzdp zzaqr = new zzdp();
    private final zzdq zzaqs = new zzdq();
    private final zzlv zzaqt = new zzlv();
    private final zzi zzaqu = new zzi();
    private final zzfz zzaqv = new zzfz();
    private final zzgl zzaqw = new zzgl();
    private final zzlj zzaqx = new zzlj();
    private final zzq zzaqy = new zzq();
    private final zzr zzaqz = new zzr();
    private final zzgv zzara = new zzgv();
    private final zzlk zzarb = new zzlk();
    private final zzp zzarc = new zzp();
    private final zzfr zzard = new zzfr();
    private final zzly zzare = new zzly();

    static {
        zzu.zza(new zzu());
    }

    protected zzu() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static void zza(zzu zzu2) {
        Object object = zzaox;
        synchronized (object) {
            zzaqa = zzu2;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static zzu zzgh() {
        Object object = zzaox;
        synchronized (object) {
            return zzaqa;
        }
    }

    public static com.google.android.gms.ads.internal.request.zza zzgi() {
        return zzu.zzgh().zzaqc;
    }

    public static zza zzgj() {
        return zzu.zzgh().zzaqb;
    }

    public static zze zzgk() {
        return zzu.zzgh().zzaqd;
    }

    public static zziu zzgl() {
        return zzu.zzgh().zzaqe;
    }

    public static zzlb zzgm() {
        return zzu.zzgh().zzaqf;
    }

    public static zzmf zzgn() {
        return zzu.zzgh().zzaqg;
    }

    public static zzlc zzgo() {
        return zzu.zzgh().zzaqh;
    }

    public static zzcz zzgp() {
        return zzu.zzgh().zzaqi;
    }

    public static zzkr zzgq() {
        return zzu.zzgh().zzaqj;
    }

    public static com.google.android.gms.ads.internal.cache.zza zzgr() {
        return zzu.zzgh().zzaqk;
    }

    public static com.google.android.gms.common.util.zze zzgs() {
        return zzu.zzgh().zzaql;
    }

    public static zzdu zzgt() {
        return zzu.zzgh().zzaqn;
    }

    public static zzlf zzgu() {
        return zzu.zzgh().zzaqo;
    }

    public static zzjs zzgv() {
        return zzu.zzgh().zzaqp;
    }

    public static zzdp zzgw() {
        return zzu.zzgh().zzaqr;
    }

    public static zzdo zzgx() {
        return zzu.zzgh().zzaqq;
    }

    public static zzdq zzgy() {
        return zzu.zzgh().zzaqs;
    }

    public static zzlv zzgz() {
        return zzu.zzgh().zzaqt;
    }

    public static zzi zzha() {
        return zzu.zzgh().zzaqu;
    }

    public static zzfz zzhb() {
        return zzu.zzgh().zzaqv;
    }

    public static zzlj zzhc() {
        return zzu.zzgh().zzaqx;
    }

    public static zzq zzhd() {
        return zzu.zzgh().zzaqy;
    }

    public static zzr zzhe() {
        return zzu.zzgh().zzaqz;
    }

    public static zzgv zzhf() {
        return zzu.zzgh().zzara;
    }

    public static zzp zzhg() {
        return zzu.zzgh().zzarc;
    }

    public static zzlk zzhh() {
        return zzu.zzgh().zzarb;
    }

    public static zzg zzhi() {
        return zzu.zzgh().zzaqm;
    }

    public static zzfr zzhj() {
        return zzu.zzgh().zzard;
    }

    public static zzly zzhk() {
        return zzu.zzgh().zzare;
    }
}

