/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.graphics.Rect
 *  android.os.RemoteException
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.ViewTreeObserver
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  android.view.ViewTreeObserver$OnScrollChangedListener
 *  android.widget.ViewSwitcher
 */
package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.support.v4.util.SimpleArrayMap;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ViewSwitcher;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.VideoOptionsParcel;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.client.zzp;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.client.zzw;
import com.google.android.gms.ads.internal.client.zzy;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.purchase.zzk;
import com.google.android.gms.ads.internal.reward.client.zzd;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzi;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zzaq;
import com.google.android.gms.internal.zzav;
import com.google.android.gms.internal.zzdr;
import com.google.android.gms.internal.zzdt;
import com.google.android.gms.internal.zzed;
import com.google.android.gms.internal.zzeq;
import com.google.android.gms.internal.zzer;
import com.google.android.gms.internal.zzes;
import com.google.android.gms.internal.zzet;
import com.google.android.gms.internal.zzha;
import com.google.android.gms.internal.zzig;
import com.google.android.gms.internal.zzik;
import com.google.android.gms.internal.zzji;
import com.google.android.gms.internal.zzko;
import com.google.android.gms.internal.zzkp;
import com.google.android.gms.internal.zzku;
import com.google.android.gms.internal.zzkw;
import com.google.android.gms.internal.zzkx;
import com.google.android.gms.internal.zzld;
import com.google.android.gms.internal.zzle;
import com.google.android.gms.internal.zzlm;
import com.google.android.gms.internal.zzlp;
import com.google.android.gms.internal.zzmd;
import com.google.android.gms.internal.zzme;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

@zzji
public final class zzv
implements ViewTreeObserver.OnGlobalLayoutListener,
ViewTreeObserver.OnScrollChangedListener {
    public final Context zzahs;
    boolean zzaok = false;
    final String zzarf;
    public String zzarg;
    final zzav zzarh;
    public final VersionInfoParcel zzari;
    @Nullable
    zza zzarj;
    @Nullable
    public zzkw zzark;
    @Nullable
    public zzld zzarl;
    public AdSizeParcel zzarm;
    @Nullable
    public zzko zzarn;
    public zzko.zza zzaro;
    @Nullable
    public zzkp zzarp;
    @Nullable
    zzp zzarq;
    @Nullable
    zzq zzarr;
    @Nullable
    zzw zzars;
    @Nullable
    zzy zzart;
    @Nullable
    zzig zzaru;
    @Nullable
    zzik zzarv;
    @Nullable
    zzeq zzarw;
    @Nullable
    zzer zzarx;
    SimpleArrayMap<String, zzes> zzary;
    SimpleArrayMap<String, zzet> zzarz;
    NativeAdOptionsParcel zzasa;
    @Nullable
    VideoOptionsParcel zzasb;
    @Nullable
    zzed zzasc;
    @Nullable
    zzd zzasd;
    @Nullable
    List<String> zzase;
    @Nullable
    zzk zzasf;
    @Nullable
    public zzku zzasg = null;
    @Nullable
    View zzash = null;
    public int zzasi = 0;
    boolean zzasj = false;
    private HashSet<zzkp> zzask = null;
    private int zzasl = -1;
    private int zzasm = -1;
    private zzlm zzasn;
    private boolean zzaso = true;
    private boolean zzasp = true;
    private boolean zzasq = false;

    public zzv(Context context, AdSizeParcel adSizeParcel, String string2, VersionInfoParcel versionInfoParcel) {
        this(context, adSizeParcel, string2, versionInfoParcel, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    zzv(Context context, AdSizeParcel adSizeParcel, String string2, VersionInfoParcel versionInfoParcel, zzav zzav2) {
        zzdr.initialize(context);
        if (zzu.zzgq().zzuu() != null) {
            List<String> list = zzdr.zzlr();
            if (versionInfoParcel.zzcya != 0) {
                list.add(Integer.toString(versionInfoParcel.zzcya));
            }
            zzu.zzgq().zzuu().zzc(list);
        }
        this.zzarf = UUID.randomUUID().toString();
        if (adSizeParcel.zzazr || adSizeParcel.zzazt) {
            this.zzarj = null;
        } else {
            this.zzarj = new zza(context, string2, this, this);
            this.zzarj.setMinimumWidth(adSizeParcel.widthPixels);
            this.zzarj.setMinimumHeight(adSizeParcel.heightPixels);
            this.zzarj.setVisibility(4);
        }
        this.zzarm = adSizeParcel;
        this.zzarg = string2;
        this.zzahs = context;
        this.zzari = versionInfoParcel;
        if (zzav2 == null) {
            zzav2 = new zzav(new zzi(this));
        }
        this.zzarh = zzav2;
        this.zzasn = new zzlm(200);
        this.zzarz = new SimpleArrayMap();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zzh(boolean bl) {
        boolean bl2 = true;
        if (this.zzarj == null) return;
        if (this.zzarn == null || this.zzarn.zzcbm == null || this.zzarn.zzcbm.zzxc() == null || bl && !this.zzasn.tryAcquire()) {
            return;
        }
        if (this.zzarn.zzcbm.zzxc().zzic()) {
            Object object = new int[2];
            this.zzarj.getLocationOnScreen((int[])object);
            int n = zzm.zzkr().zzc(this.zzahs, object[0]);
            int n2 = zzm.zzkr().zzc(this.zzahs, object[1]);
            if (n != this.zzasl || n2 != this.zzasm) {
                this.zzasl = n;
                this.zzasm = n2;
                object = this.zzarn.zzcbm.zzxc();
                n = this.zzasl;
                n2 = this.zzasm;
                bl = !bl ? bl2 : false;
                object.zza(n, n2, bl);
            }
        }
        this.zzhs();
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void zzhs() {
        if (this.zzarj == null) {
            return;
        }
        View view = this.zzarj.getRootView().findViewById(16908290);
        if (view == null) return;
        Rect rect = new Rect();
        Rect rect2 = new Rect();
        this.zzarj.getGlobalVisibleRect(rect);
        view.getGlobalVisibleRect(rect2);
        if (rect.top != rect2.top) {
            this.zzaso = false;
        }
        if (rect.bottom == rect2.bottom) return;
        this.zzasp = false;
    }

    public void destroy() {
        this.zzhr();
        this.zzarr = null;
        this.zzars = null;
        this.zzarv = null;
        this.zzaru = null;
        this.zzasc = null;
        this.zzart = null;
        this.zzi(false);
        if (this.zzarj != null) {
            this.zzarj.removeAllViews();
        }
        this.zzhm();
        this.zzho();
        this.zzarn = null;
    }

    public void onGlobalLayout() {
        this.zzh(false);
    }

    public void onScrollChanged() {
        this.zzh(true);
        this.zzasq = true;
    }

    public void zza(HashSet<zzkp> hashSet) {
        this.zzask = hashSet;
    }

    public HashSet<zzkp> zzhl() {
        return this.zzask;
    }

    public void zzhm() {
        if (this.zzarn != null && this.zzarn.zzcbm != null) {
            this.zzarn.zzcbm.destroy();
        }
    }

    public void zzhn() {
        if (this.zzarn != null && this.zzarn.zzcbm != null) {
            this.zzarn.zzcbm.stopLoading();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void zzho() {
        if (this.zzarn == null || this.zzarn.zzbwn == null) return;
        try {
            this.zzarn.zzbwn.destroy();
            return;
        }
        catch (RemoteException var1_1) {
            zzkx.zzdi("Could not destroy mediation adapter.");
            return;
        }
    }

    public boolean zzhp() {
        if (this.zzasi == 0) {
            return true;
        }
        return false;
    }

    public boolean zzhq() {
        if (this.zzasi == 1) {
            return true;
        }
        return false;
    }

    public void zzhr() {
        if (this.zzarj != null) {
            this.zzarj.zzhr();
        }
    }

    public String zzht() {
        if (this.zzaso && this.zzasp) {
            return "";
        }
        if (this.zzaso) {
            if (this.zzasq) {
                return "top-scrollable";
            }
            return "top-locked";
        }
        if (this.zzasp) {
            if (this.zzasq) {
                return "bottom-scrollable";
            }
            return "bottom-locked";
        }
        return "";
    }

    public void zzhu() {
        if (this.zzarp == null) {
            return;
        }
        if (this.zzarn != null) {
            this.zzarp.zzm(this.zzarn.zzcso);
            this.zzarp.zzn(this.zzarn.zzcsp);
            this.zzarp.zzae(this.zzarn.zzclb);
        }
        this.zzarp.zzad(this.zzarm.zzazr);
    }

    public void zzi(boolean bl) {
        if (this.zzasi == 0) {
            this.zzhn();
        }
        if (this.zzark != null) {
            this.zzark.cancel();
        }
        if (this.zzarl != null) {
            this.zzarl.cancel();
        }
        if (bl) {
            this.zzarn = null;
        }
    }

    public static class zza
    extends ViewSwitcher {
        private final zzle zzasr;
        @Nullable
        private final zzlp zzass;
        private boolean zzast;

        /*
         * Enabled aggressive block sorting
         */
        public zza(Context context, String string2, ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener, ViewTreeObserver.OnScrollChangedListener onScrollChangedListener) {
            super(context);
            this.zzasr = new zzle(context);
            this.zzasr.setAdUnitId(string2);
            this.zzast = true;
            this.zzass = context instanceof Activity ? new zzlp((Activity)context, (View)this, onGlobalLayoutListener, onScrollChangedListener) : new zzlp(null, (View)this, onGlobalLayoutListener, onScrollChangedListener);
            this.zzass.zzwl();
        }

        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (this.zzass != null) {
                this.zzass.onAttachedToWindow();
            }
        }

        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (this.zzass != null) {
                this.zzass.onDetachedFromWindow();
            }
        }

        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (this.zzast) {
                this.zzasr.zzg(motionEvent);
            }
            return false;
        }

        public void removeAllViews() {
            Object object = new ArrayList();
            for (int i = 0; i < this.getChildCount(); ++i) {
                View view = this.getChildAt(i);
                if (view == null || !(view instanceof zzmd)) continue;
                object.add((zzmd)view);
            }
            super.removeAllViews();
            object = object.iterator();
            while (object.hasNext()) {
                ((zzmd)object.next()).destroy();
            }
        }

        public void zzhr() {
            zzkx.v("Disable position monitoring on adFrame.");
            if (this.zzass != null) {
                this.zzass.zzwm();
            }
        }

        public zzle zzhv() {
            return this.zzasr;
        }

        public void zzhw() {
            zzkx.v("Enable debug gesture detector on adFrame.");
            this.zzast = true;
        }

        public void zzhx() {
            zzkx.v("Disable debug gesture detector on adFrame.");
            this.zzast = false;
        }
    }

}

