/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 */
package com.google.android.gms.ads.mediation;

import android.os.Bundle;

public interface MediationAdapter {
    public void onDestroy();

    public void onPause();

    public void onResume();

    public static class zza {
        private int P;

        public zza zzbk(int n) {
            this.P = n;
            return this;
        }

        public Bundle zzys() {
            Bundle bundle = new Bundle();
            bundle.putInt("capabilities", this.P);
            return bundle;
        }
    }

}

