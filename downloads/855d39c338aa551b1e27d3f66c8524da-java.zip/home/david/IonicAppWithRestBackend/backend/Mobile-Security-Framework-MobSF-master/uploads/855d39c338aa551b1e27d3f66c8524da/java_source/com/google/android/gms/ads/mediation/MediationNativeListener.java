/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.mediation;

import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.mediation.NativeAdMapper;

public interface MediationNativeListener {
    public void onAdClicked(MediationNativeAdapter var1);

    public void onAdClosed(MediationNativeAdapter var1);

    public void onAdFailedToLoad(MediationNativeAdapter var1, int var2);

    public void onAdImpression(MediationNativeAdapter var1);

    public void onAdLeftApplication(MediationNativeAdapter var1);

    public void onAdLoaded(MediationNativeAdapter var1, NativeAdMapper var2);

    public void onAdOpened(MediationNativeAdapter var1);
}

