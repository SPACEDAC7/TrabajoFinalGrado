/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 */
package com.google.android.gms.ads.mediation;

import android.os.Bundle;
import android.view.View;
import com.google.android.gms.internal.zzji;

@zzji
public abstract class NativeAdMapper {
    protected Bundle mExtras = new Bundle();
    protected boolean mOverrideClickHandling;
    protected boolean mOverrideImpressionRecording;

    public final Bundle getExtras() {
        return this.mExtras;
    }

    public final boolean getOverrideClickHandling() {
        return this.mOverrideClickHandling;
    }

    public final boolean getOverrideImpressionRecording() {
        return this.mOverrideImpressionRecording;
    }

    public void handleClick(View view) {
    }

    public void recordImpression() {
    }

    public final void setExtras(Bundle bundle) {
        this.mExtras = bundle;
    }

    public final void setOverrideClickHandling(boolean bl) {
        this.mOverrideClickHandling = bl;
    }

    public final void setOverrideImpressionRecording(boolean bl) {
        this.mOverrideImpressionRecording = bl;
    }

    public void trackView(View view) {
    }

    public void untrackView(View view) {
    }
}

