/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.google.android.gms.ads.mediation;

import android.content.Context;

public interface OnContextChangedListener {
    public void onContextChanged(Context var1);
}

