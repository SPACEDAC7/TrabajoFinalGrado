/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.mediation.customevent;

public interface CustomEvent {
    public void onDestroy();

    public void onPause();

    public void onResume();
}

