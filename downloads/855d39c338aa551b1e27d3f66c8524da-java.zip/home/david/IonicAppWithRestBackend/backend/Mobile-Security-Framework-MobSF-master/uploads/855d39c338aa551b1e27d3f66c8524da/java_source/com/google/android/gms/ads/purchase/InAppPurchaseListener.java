/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.purchase;

import com.google.android.gms.ads.purchase.InAppPurchase;

public interface InAppPurchaseListener {
    public void onInAppPurchaseRequested(InAppPurchase var1);
}

