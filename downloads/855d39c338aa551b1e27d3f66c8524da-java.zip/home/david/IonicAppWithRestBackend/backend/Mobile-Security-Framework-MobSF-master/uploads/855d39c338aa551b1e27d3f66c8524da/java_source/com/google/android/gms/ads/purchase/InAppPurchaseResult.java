/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 */
package com.google.android.gms.ads.purchase;

import android.content.Intent;

public interface InAppPurchaseResult {
    public void finishPurchase();

    public String getProductId();

    public Intent getPurchaseData();

    public int getResultCode();

    public boolean isVerified();
}

