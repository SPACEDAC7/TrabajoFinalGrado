/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.google.android.gms.ads.reward;

import android.content.Context;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;

public interface RewardedVideoAd {
    @Deprecated
    public void destroy();

    public void destroy(Context var1);

    public RewardedVideoAdListener getRewardedVideoAdListener();

    @Deprecated
    public String getUserId();

    public boolean isLoaded();

    public void loadAd(String var1, AdRequest var2);

    @Deprecated
    public void pause();

    public void pause(Context var1);

    @Deprecated
    public void resume();

    public void resume(Context var1);

    public void setRewardedVideoAdListener(RewardedVideoAdListener var1);

    @Deprecated
    public void setUserId(String var1);

    public void show();
}

