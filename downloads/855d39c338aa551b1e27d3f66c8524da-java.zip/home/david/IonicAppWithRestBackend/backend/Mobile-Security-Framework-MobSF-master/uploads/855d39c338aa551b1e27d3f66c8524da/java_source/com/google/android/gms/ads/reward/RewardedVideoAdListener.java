/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.reward;

import com.google.android.gms.ads.reward.RewardItem;

public interface RewardedVideoAdListener {
    public void onRewarded(RewardItem var1);

    public void onRewardedVideoAdClosed();

    public void onRewardedVideoAdFailedToLoad(int var1);

    public void onRewardedVideoAdLeftApplication();

    public void onRewardedVideoAdLoaded();

    public void onRewardedVideoAdOpened();

    public void onRewardedVideoStarted();
}

