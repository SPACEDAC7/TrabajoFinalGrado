/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads.reward.mediation;

import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;

public interface MediationRewardedVideoAdListener {
    public void onAdClicked(MediationRewardedVideoAdAdapter var1);

    public void onAdClosed(MediationRewardedVideoAdAdapter var1);

    public void onAdFailedToLoad(MediationRewardedVideoAdAdapter var1, int var2);

    public void onAdLeftApplication(MediationRewardedVideoAdAdapter var1);

    public void onAdLoaded(MediationRewardedVideoAdAdapter var1);

    public void onAdOpened(MediationRewardedVideoAdAdapter var1);

    public void onInitializationFailed(MediationRewardedVideoAdAdapter var1, int var2);

    public void onInitializationSucceeded(MediationRewardedVideoAdAdapter var1);

    public void onRewarded(MediationRewardedVideoAdAdapter var1, RewardItem var2);

    public void onVideoStarted(MediationRewardedVideoAdAdapter var1);
}

