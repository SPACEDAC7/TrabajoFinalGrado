/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 */
package com.google.android.gms.ads.search;

import android.content.Context;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.internal.client.zzad;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEvent;
import com.google.android.gms.ads.search.SearchAdRequest;

public final class DynamicHeightSearchAdRequest {
    private final SearchAdRequest Z;

    private DynamicHeightSearchAdRequest(Builder builder) {
        this.Z = builder.aa.build();
    }

    public <T extends CustomEvent> Bundle getCustomEventExtrasBundle(Class<T> class_) {
        return this.Z.getCustomEventExtrasBundle(class_);
    }

    @Deprecated
    public <T extends NetworkExtras> T getNetworkExtras(Class<T> class_) {
        return this.Z.getNetworkExtras(class_);
    }

    public <T extends MediationAdapter> Bundle getNetworkExtrasBundle(Class<T> class_) {
        return this.Z.getNetworkExtrasBundle(class_);
    }

    public String getQuery() {
        return this.Z.getQuery();
    }

    public boolean isTestDevice(Context context) {
        return this.Z.isTestDevice(context);
    }

    zzad zzdt() {
        return this.Z.zzdt();
    }

    public static final class Builder {
        private final SearchAdRequest.Builder aa = new SearchAdRequest.Builder();
        private final Bundle ab = new Bundle();

        public Builder addCustomEventExtrasBundle(Class<? extends CustomEvent> class_, Bundle bundle) {
            this.aa.addCustomEventExtrasBundle(class_, bundle);
            return this;
        }

        public Builder addNetworkExtras(NetworkExtras networkExtras) {
            this.aa.addNetworkExtras(networkExtras);
            return this;
        }

        public Builder addNetworkExtrasBundle(Class<? extends MediationAdapter> class_, Bundle bundle) {
            this.aa.addNetworkExtrasBundle(class_, bundle);
            return this;
        }

        public DynamicHeightSearchAdRequest build() {
            this.aa.addNetworkExtrasBundle(AdMobAdapter.class, this.ab);
            return new DynamicHeightSearchAdRequest(this);
        }

        public Builder setAdBorderSelectors(String string2) {
            this.ab.putString("csa_adBorderSelectors", string2);
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public Builder setAdTest(boolean bl) {
            Bundle bundle = this.ab;
            String string2 = bl ? "on" : "off";
            bundle.putString("csa_adtest", string2);
            return this;
        }

        public Builder setAdjustableLineHeight(int n) {
            this.ab.putString("csa_adjustableLineHeight", Integer.toString(n));
            return this;
        }

        public Builder setAdvancedOptionValue(String string2, String string3) {
            this.ab.putString(string2, string3);
            return this;
        }

        public Builder setAttributionSpacingBelow(int n) {
            this.ab.putString("csa_attributionSpacingBelow", Integer.toString(n));
            return this;
        }

        public Builder setBorderSelections(String string2) {
            this.ab.putString("csa_borderSelections", string2);
            return this;
        }

        public Builder setChannel(String string2) {
            this.ab.putString("csa_channel", string2);
            return this;
        }

        public Builder setColorAdBorder(String string2) {
            this.ab.putString("csa_colorAdBorder", string2);
            return this;
        }

        public Builder setColorAdSeparator(String string2) {
            this.ab.putString("csa_colorAdSeparator", string2);
            return this;
        }

        public Builder setColorAnnotation(String string2) {
            this.ab.putString("csa_colorAnnotation", string2);
            return this;
        }

        public Builder setColorAttribution(String string2) {
            this.ab.putString("csa_colorAttribution", string2);
            return this;
        }

        public Builder setColorBackground(String string2) {
            this.ab.putString("csa_colorBackground", string2);
            return this;
        }

        public Builder setColorBorder(String string2) {
            this.ab.putString("csa_colorBorder", string2);
            return this;
        }

        public Builder setColorDomainLink(String string2) {
            this.ab.putString("csa_colorDomainLink", string2);
            return this;
        }

        public Builder setColorText(String string2) {
            this.ab.putString("csa_colorText", string2);
            return this;
        }

        public Builder setColorTitleLink(String string2) {
            this.ab.putString("csa_colorTitleLink", string2);
            return this;
        }

        public Builder setCssWidth(int n) {
            this.ab.putString("csa_width", Integer.toString(n));
            return this;
        }

        public Builder setDetailedAttribution(boolean bl) {
            this.ab.putString("csa_detailedAttribution", Boolean.toString(bl));
            return this;
        }

        @Deprecated
        public Builder setFontFamily(int n) {
            return this.setFontFamily(Integer.toString(n));
        }

        public Builder setFontFamily(String string2) {
            this.ab.putString("csa_fontFamily", string2);
            return this;
        }

        public Builder setFontFamilyAttribution(String string2) {
            this.ab.putString("csa_fontFamilyAttribution", string2);
            return this;
        }

        public Builder setFontSizeAnnotation(int n) {
            this.ab.putString("csa_fontSizeAnnotation", Integer.toString(n));
            return this;
        }

        public Builder setFontSizeAttribution(int n) {
            this.ab.putString("csa_fontSizeAttribution", Integer.toString(n));
            return this;
        }

        public Builder setFontSizeDescription(int n) {
            this.ab.putString("csa_fontSizeDescription", Integer.toString(n));
            return this;
        }

        public Builder setFontSizeDomainLink(int n) {
            this.ab.putString("csa_fontSizeDomainLink", Integer.toString(n));
            return this;
        }

        public Builder setFontSizeTitle(int n) {
            this.ab.putString("csa_fontSizeTitle", Integer.toString(n));
            return this;
        }

        public Builder setHostLanguage(String string2) {
            this.ab.putString("csa_hl", string2);
            return this;
        }

        public Builder setIsClickToCallEnabled(boolean bl) {
            this.ab.putString("csa_clickToCall", Boolean.toString(bl));
            return this;
        }

        public Builder setIsLocationEnabled(boolean bl) {
            this.ab.putString("csa_location", Boolean.toString(bl));
            return this;
        }

        public Builder setIsPlusOnesEnabled(boolean bl) {
            this.ab.putString("csa_plusOnes", Boolean.toString(bl));
            return this;
        }

        public Builder setIsSellerRatingsEnabled(boolean bl) {
            this.ab.putString("csa_sellerRatings", Boolean.toString(bl));
            return this;
        }

        public Builder setIsSiteLinksEnabled(boolean bl) {
            this.ab.putString("csa_siteLinks", Boolean.toString(bl));
            return this;
        }

        public Builder setIsTitleBold(boolean bl) {
            this.ab.putString("csa_titleBold", Boolean.toString(bl));
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public Builder setIsTitleUnderlined(boolean bl) {
            Bundle bundle = this.ab;
            bl = !bl;
            bundle.putString("csa_noTitleUnderline", Boolean.toString(bl));
            return this;
        }

        public Builder setLocationColor(String string2) {
            this.ab.putString("csa_colorLocation", string2);
            return this;
        }

        public Builder setLocationFontSize(int n) {
            this.ab.putString("csa_fontSizeLocation", Integer.toString(n));
            return this;
        }

        public Builder setLongerHeadlines(boolean bl) {
            this.ab.putString("csa_longerHeadlines", Boolean.toString(bl));
            return this;
        }

        public Builder setNumber(int n) {
            this.ab.putString("csa_number", Integer.toString(n));
            return this;
        }

        public Builder setPage(int n) {
            this.ab.putString("csa_adPage", Integer.toString(n));
            return this;
        }

        public Builder setQuery(String string2) {
            this.aa.setQuery(string2);
            return this;
        }

        public Builder setVerticalSpacing(int n) {
            this.ab.putString("csa_verticalSpacing", Integer.toString(n));
            return this;
        }
    }

}

