/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Color
 *  android.location.Location
 *  android.os.Bundle
 */
package com.google.android.gms.ads.search;

import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import com.google.android.gms.ads.internal.client.zzad;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEvent;

public final class SearchAdRequest {
    public static final int BORDER_TYPE_DASHED = 1;
    public static final int BORDER_TYPE_DOTTED = 2;
    public static final int BORDER_TYPE_NONE = 0;
    public static final int BORDER_TYPE_SOLID = 3;
    public static final int CALL_BUTTON_COLOR_DARK = 2;
    public static final int CALL_BUTTON_COLOR_LIGHT = 0;
    public static final int CALL_BUTTON_COLOR_MEDIUM = 1;
    public static final String DEVICE_ID_EMULATOR = zzad.DEVICE_ID_EMULATOR;
    public static final int ERROR_CODE_INTERNAL_ERROR = 0;
    public static final int ERROR_CODE_INVALID_REQUEST = 1;
    public static final int ERROR_CODE_NETWORK_ERROR = 2;
    public static final int ERROR_CODE_NO_FILL = 3;
    private final int ac;
    private final int ad;
    private final int ae;
    private final int af;
    private final int ag;
    private final int ah;
    private final int ai;
    private final String aj;
    private final int ak;
    private final String al;
    private final int am;
    private final int an;
    private final int mBackgroundColor;
    private final zzad zzakf;
    private final String zzapy;

    private SearchAdRequest(Builder builder) {
        this.ac = builder.ac;
        this.mBackgroundColor = builder.mBackgroundColor;
        this.ad = builder.ad;
        this.ae = builder.ae;
        this.af = builder.af;
        this.ag = builder.ag;
        this.ah = builder.ah;
        this.ai = builder.ai;
        this.aj = builder.aj;
        this.ak = builder.ak;
        this.al = builder.al;
        this.am = builder.am;
        this.an = builder.an;
        this.zzapy = builder.zzapy;
        this.zzakf = new zzad(builder.zzakg, this);
    }

    public int getAnchorTextColor() {
        return this.ac;
    }

    public int getBackgroundColor() {
        return this.mBackgroundColor;
    }

    public int getBackgroundGradientBottom() {
        return this.ad;
    }

    public int getBackgroundGradientTop() {
        return this.ae;
    }

    public int getBorderColor() {
        return this.af;
    }

    public int getBorderThickness() {
        return this.ag;
    }

    public int getBorderType() {
        return this.ah;
    }

    public int getCallButtonColor() {
        return this.ai;
    }

    public String getCustomChannels() {
        return this.aj;
    }

    public <T extends CustomEvent> Bundle getCustomEventExtrasBundle(Class<T> class_) {
        return this.zzakf.getCustomEventExtrasBundle(class_);
    }

    public int getDescriptionTextColor() {
        return this.ak;
    }

    public String getFontFace() {
        return this.al;
    }

    public int getHeaderTextColor() {
        return this.am;
    }

    public int getHeaderTextSize() {
        return this.an;
    }

    public Location getLocation() {
        return this.zzakf.getLocation();
    }

    @Deprecated
    public <T extends NetworkExtras> T getNetworkExtras(Class<T> class_) {
        return this.zzakf.getNetworkExtras(class_);
    }

    public <T extends MediationAdapter> Bundle getNetworkExtrasBundle(Class<T> class_) {
        return this.zzakf.getNetworkExtrasBundle(class_);
    }

    public String getQuery() {
        return this.zzapy;
    }

    public boolean isTestDevice(Context context) {
        return this.zzakf.isTestDevice(context);
    }

    zzad zzdt() {
        return this.zzakf;
    }

    public static final class Builder {
        private int ac;
        private int ad;
        private int ae;
        private int af;
        private int ag;
        private int ah = 0;
        private int ai;
        private String aj;
        private int ak;
        private String al;
        private int am;
        private int an;
        private int mBackgroundColor;
        private final zzad.zza zzakg = new zzad.zza();
        private String zzapy;

        public Builder addCustomEventExtrasBundle(Class<? extends CustomEvent> class_, Bundle bundle) {
            this.zzakg.zzb(class_, bundle);
            return this;
        }

        public Builder addNetworkExtras(NetworkExtras networkExtras) {
            this.zzakg.zza(networkExtras);
            return this;
        }

        public Builder addNetworkExtrasBundle(Class<? extends MediationAdapter> class_, Bundle bundle) {
            this.zzakg.zza(class_, bundle);
            return this;
        }

        public Builder addTestDevice(String string2) {
            this.zzakg.zzan(string2);
            return this;
        }

        public SearchAdRequest build() {
            return new SearchAdRequest(this);
        }

        public Builder setAnchorTextColor(int n) {
            this.ac = n;
            return this;
        }

        public Builder setBackgroundColor(int n) {
            this.mBackgroundColor = n;
            this.ad = Color.argb((int)0, (int)0, (int)0, (int)0);
            this.ae = Color.argb((int)0, (int)0, (int)0, (int)0);
            return this;
        }

        public Builder setBackgroundGradient(int n, int n2) {
            this.mBackgroundColor = Color.argb((int)0, (int)0, (int)0, (int)0);
            this.ad = n2;
            this.ae = n;
            return this;
        }

        public Builder setBorderColor(int n) {
            this.af = n;
            return this;
        }

        public Builder setBorderThickness(int n) {
            this.ag = n;
            return this;
        }

        public Builder setBorderType(int n) {
            this.ah = n;
            return this;
        }

        public Builder setCallButtonColor(int n) {
            this.ai = n;
            return this;
        }

        public Builder setCustomChannels(String string2) {
            this.aj = string2;
            return this;
        }

        public Builder setDescriptionTextColor(int n) {
            this.ak = n;
            return this;
        }

        public Builder setFontFace(String string2) {
            this.al = string2;
            return this;
        }

        public Builder setHeaderTextColor(int n) {
            this.am = n;
            return this;
        }

        public Builder setHeaderTextSize(int n) {
            this.an = n;
            return this;
        }

        public Builder setLocation(Location location) {
            this.zzakg.zzb(location);
            return this;
        }

        public Builder setQuery(String string2) {
            this.zzapy = string2;
            return this;
        }

        public Builder setRequestAgent(String string2) {
            this.zzakg.zzar(string2);
            return this;
        }

        public Builder tagForChildDirectedTreatment(boolean bl) {
            this.zzakg.zzo(bl);
            return this;
        }
    }

}

