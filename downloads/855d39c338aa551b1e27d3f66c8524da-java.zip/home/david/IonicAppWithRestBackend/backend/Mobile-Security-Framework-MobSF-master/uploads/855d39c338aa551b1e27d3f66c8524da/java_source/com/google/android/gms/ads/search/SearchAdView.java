/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 */
package com.google.android.gms.ads.search;

import android.content.Context;
import android.support.annotation.RequiresPermission;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.internal.client.zzad;
import com.google.android.gms.ads.internal.client.zzae;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.search.DynamicHeightSearchAdRequest;
import com.google.android.gms.ads.search.SearchAdRequest;
import com.google.android.gms.internal.zzji;

@zzji
public final class SearchAdView
extends ViewGroup {
    private final zzae zzakk;

    public SearchAdView(Context context) {
        super(context);
        this.zzakk = new zzae(this);
    }

    public SearchAdView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.zzakk = new zzae(this, attributeSet, false);
    }

    public SearchAdView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.zzakk = new zzae(this, attributeSet, false);
    }

    public void destroy() {
        this.zzakk.destroy();
    }

    public AdListener getAdListener() {
        return this.zzakk.getAdListener();
    }

    public AdSize getAdSize() {
        return this.zzakk.getAdSize();
    }

    public String getAdUnitId() {
        return this.zzakk.getAdUnitId();
    }

    @RequiresPermission(value="android.permission.INTERNET")
    public void loadAd(DynamicHeightSearchAdRequest dynamicHeightSearchAdRequest) {
        if (!AdSize.SEARCH.equals(this.getAdSize())) {
            throw new IllegalStateException("You must use AdSize.SEARCH for a DynamicHeightSearchAdRequest");
        }
        this.zzakk.zza(dynamicHeightSearchAdRequest.zzdt());
    }

    @RequiresPermission(value="android.permission.INTERNET")
    public void loadAd(SearchAdRequest searchAdRequest) {
        this.zzakk.zza(searchAdRequest.zzdt());
    }

    protected void onLayout(boolean bl, int n, int n2, int n3, int n4) {
        View view = this.getChildAt(0);
        if (view != null && view.getVisibility() != 8) {
            int n5 = view.getMeasuredWidth();
            int n6 = view.getMeasuredHeight();
            n = (n3 - n - n5) / 2;
            n2 = (n4 - n2 - n6) / 2;
            view.layout(n, n2, n5 + n, n6 + n2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onMeasure(int n, int n2) {
        int n3;
        int n4 = 0;
        Object object = this.getChildAt(0);
        if (object != null && object.getVisibility() != 8) {
            this.measureChild((View)object, n, n2);
            n3 = object.getMeasuredWidth();
            n4 = object.getMeasuredHeight();
        } else {
            try {
                object = this.getAdSize();
            }
            catch (NullPointerException var5_5) {
                zzb.zzb("Unable to retrieve ad size.", var5_5);
                object = null;
            }
            if (object != null) {
                Context context = this.getContext();
                n3 = object.getWidthInPixels(context);
                n4 = object.getHeightInPixels(context);
            } else {
                n3 = 0;
            }
        }
        n3 = Math.max(n3, this.getSuggestedMinimumWidth());
        n4 = Math.max(n4, this.getSuggestedMinimumHeight());
        this.setMeasuredDimension(View.resolveSize((int)n3, (int)n), View.resolveSize((int)n4, (int)n2));
    }

    public void pause() {
        this.zzakk.pause();
    }

    public void resume() {
        this.zzakk.resume();
    }

    public void setAdListener(AdListener adListener) {
        this.zzakk.setAdListener(adListener);
    }

    public void setAdSize(AdSize adSize) {
        this.zzakk.setAdSizes(adSize);
    }

    public void setAdUnitId(String string2) {
        this.zzakk.setAdUnitId(string2);
    }
}

