/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.ads;

import com.google.android.gms.ads.AdSize;

public final class zza {
    public static AdSize zza(int n, int n2, String string2) {
        return new AdSize(n, n2, string2);
    }
}

