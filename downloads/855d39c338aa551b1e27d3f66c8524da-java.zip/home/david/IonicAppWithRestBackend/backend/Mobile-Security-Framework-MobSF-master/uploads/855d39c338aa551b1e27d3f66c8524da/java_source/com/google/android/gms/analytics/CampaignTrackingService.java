/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.text.TextUtils
 */
package com.google.android.gms.analytics;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.support.annotation.RequiresPermission;
import android.text.TextUtils;
import com.google.android.gms.analytics.CampaignTrackingReceiver;
import com.google.android.gms.analytics.internal.zzaf;
import com.google.android.gms.analytics.internal.zzao;
import com.google.android.gms.analytics.internal.zzb;
import com.google.android.gms.analytics.internal.zzf;
import com.google.android.gms.analytics.internal.zzr;
import com.google.android.gms.analytics.zzi;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzxr;

public class CampaignTrackingService
extends Service {
    private static Boolean az;
    private Handler mHandler;

    private Handler getHandler() {
        Handler handler;
        Handler handler2 = handler = this.mHandler;
        if (handler == null) {
            this.mHandler = handler2 = new Handler(this.getMainLooper());
        }
        return handler2;
    }

    public static boolean zzau(Context context) {
        zzaa.zzy(context);
        if (az != null) {
            return az;
        }
        boolean bl = zzao.zzr(context, "com.google.android.gms.analytics.CampaignTrackingService");
        az = bl;
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void zzyz() {
        zzxr zzxr2;
        try {
            Object object = CampaignTrackingReceiver.zzaox;
            synchronized (object) {
                zzxr2 = CampaignTrackingReceiver.ax;
            }
        }
        catch (SecurityException var1_2) {
            return;
        }
        {
            if (zzxr2 != null && zzxr2.isHeld()) {
                zzxr2.release();
            }
            return;
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    @RequiresPermission(allOf={"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"})
    public void onCreate() {
        super.onCreate();
        zzf.zzaw((Context)this).zzaca().zzes("CampaignTrackingService is starting up");
    }

    @RequiresPermission(allOf={"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"})
    public void onDestroy() {
        zzf.zzaw((Context)this).zzaca().zzes("CampaignTrackingService is shutting down");
        super.onDestroy();
    }

    /*
     * Enabled aggressive block sorting
     */
    @RequiresPermission(allOf={"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"})
    public int onStartCommand(Intent object, int n, final int n2) {
        this.zzyz();
        zzf zzf2 = zzf.zzaw((Context)this);
        final zzaf zzaf2 = zzf2.zzaca();
        zzf2.zzacb();
        object = object.getStringExtra("referrer");
        final Handler handler = this.getHandler();
        if (TextUtils.isEmpty((CharSequence)object)) {
            zzf2.zzacb();
            zzaf2.zzev("No campaign found on com.android.vending.INSTALL_REFERRER \"referrer\" extra");
            zzf2.zzacc().zzg(new Runnable(){

                @Override
                public void run() {
                    CampaignTrackingService.this.zza(zzaf2, handler, n2);
                }
            });
            return 2;
        }
        n = zzf2.zzacb().zzaei();
        if (object.length() > n) {
            zzaf2.zzc("Campaign data exceed the maximum supported size and will be clipped. size, limit", object.length(), n);
            object = object.substring(0, n);
        }
        zzaf2.zza("CampaignTrackingService called. startId, campaign", n2, object);
        zzf2.zzzg().zza((String)object, new Runnable(){

            @Override
            public void run() {
                CampaignTrackingService.this.zza(zzaf2, handler, n2);
            }
        });
        return 2;
    }

    protected void zza(final zzaf zzaf2, Handler handler, final int n) {
        handler.post(new Runnable(){

            @Override
            public void run() {
                boolean bl = CampaignTrackingService.this.stopSelfResult(n);
                if (bl) {
                    zzaf2.zza("Install campaign broadcast processed", bl);
                }
            }
        });
    }

}

