/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics;

public interface ExceptionParser {
    public String getDescription(String var1, Throwable var2);
}

