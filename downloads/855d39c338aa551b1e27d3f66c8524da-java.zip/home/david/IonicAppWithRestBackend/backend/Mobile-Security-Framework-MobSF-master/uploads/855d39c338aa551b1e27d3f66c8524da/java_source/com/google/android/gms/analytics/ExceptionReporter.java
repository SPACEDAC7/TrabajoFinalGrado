/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.google.android.gms.analytics;

import android.content.Context;
import com.google.android.gms.analytics.ExceptionParser;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.StandardExceptionParser;
import com.google.android.gms.analytics.Tracker;
import com.google.android.gms.analytics.internal.zzae;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public class ExceptionReporter
implements Thread.UncaughtExceptionHandler {
    private final Thread.UncaughtExceptionHandler aD;
    private final Tracker aE;
    private ExceptionParser aF;
    private GoogleAnalytics aG;
    private final Context mContext;

    /*
     * Enabled aggressive block sorting
     */
    public ExceptionReporter(Tracker object, Thread.UncaughtExceptionHandler uncaughtExceptionHandler, Context context) {
        if (object == null) {
            throw new NullPointerException("tracker cannot be null");
        }
        if (context == null) {
            throw new NullPointerException("context cannot be null");
        }
        this.aD = uncaughtExceptionHandler;
        this.aE = object;
        this.aF = new StandardExceptionParser(context, new ArrayList<String>());
        this.mContext = context.getApplicationContext();
        object = uncaughtExceptionHandler == null ? "null" : uncaughtExceptionHandler.getClass().getName();
        object = (object = String.valueOf(object)).length() != 0 ? "ExceptionReporter created, original handler is ".concat((String)object) : new String("ExceptionReporter created, original handler is ");
        zzae.v((String)object);
    }

    public ExceptionParser getExceptionParser() {
        return this.aF;
    }

    public void setExceptionParser(ExceptionParser exceptionParser) {
        this.aF = exceptionParser;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void uncaughtException(Thread thread, Throwable throwable) {
        String string2;
        Object object = "UncaughtException";
        if (this.aF != null) {
            object = thread != null ? thread.getName() : null;
            object = this.aF.getDescription((String)object, throwable);
        }
        string2 = (string2 = String.valueOf(object)).length() != 0 ? "Reporting uncaught exception: ".concat(string2) : new String("Reporting uncaught exception: ");
        zzae.v(string2);
        this.aE.send(new HitBuilders.ExceptionBuilder().setDescription((String)object).setFatal(true).build());
        object = this.zzza();
        object.dispatchLocalHits();
        object.zzzf();
        if (this.aD != null) {
            zzae.v("Passing exception to the original handler");
            this.aD.uncaughtException(thread, throwable);
        }
    }

    GoogleAnalytics zzza() {
        if (this.aG == null) {
            this.aG = GoogleAnalytics.getInstance(this.mContext);
        }
        return this.aG;
    }

    Thread.UncaughtExceptionHandler zzzb() {
        return this.aD;
    }
}

