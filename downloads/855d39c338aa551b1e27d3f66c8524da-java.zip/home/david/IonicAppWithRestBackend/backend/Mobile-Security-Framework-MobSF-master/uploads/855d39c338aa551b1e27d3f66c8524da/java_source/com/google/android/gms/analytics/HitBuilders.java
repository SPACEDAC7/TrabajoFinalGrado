/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 */
package com.google.android.gms.analytics;

import android.text.TextUtils;
import com.google.android.gms.analytics.ecommerce.Product;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.google.android.gms.analytics.internal.zzae;
import com.google.android.gms.analytics.internal.zzao;
import com.google.android.gms.analytics.zzc;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class HitBuilders {

    @Deprecated
    public static class AppViewBuilder
    extends HitBuilder<AppViewBuilder> {
        public AppViewBuilder() {
            this.set("&t", "screenview");
        }
    }

    public static class EventBuilder
    extends HitBuilder<EventBuilder> {
        public EventBuilder() {
            this.set("&t", "event");
        }

        public EventBuilder(String string2, String string3) {
            this();
            this.setCategory(string2);
            this.setAction(string3);
        }

        public EventBuilder setAction(String string2) {
            this.set("&ea", string2);
            return this;
        }

        public EventBuilder setCategory(String string2) {
            this.set("&ec", string2);
            return this;
        }

        public EventBuilder setLabel(String string2) {
            this.set("&el", string2);
            return this;
        }

        public EventBuilder setValue(long l) {
            this.set("&ev", Long.toString(l));
            return this;
        }
    }

    public static class ExceptionBuilder
    extends HitBuilder<ExceptionBuilder> {
        public ExceptionBuilder() {
            this.set("&t", "exception");
        }

        public ExceptionBuilder setDescription(String string2) {
            this.set("&exd", string2);
            return this;
        }

        public ExceptionBuilder setFatal(boolean bl) {
            this.set("&exf", zzao.zzax(bl));
            return this;
        }
    }

    protected static class HitBuilder<T extends HitBuilder> {
        private Map<String, String> aO = new HashMap<String, String>();
        ProductAction aP;
        Map<String, List<Product>> aQ = new HashMap<String, List<Product>>();
        List<Promotion> aR = new ArrayList<Promotion>();
        List<Product> aS = new ArrayList<Product>();

        protected HitBuilder() {
        }

        private T zzn(String string2, String string3) {
            if (string2 != null) {
                if (string3 != null) {
                    this.aO.put(string2, string3);
                }
                return (T)this;
            }
            zzae.zzdi("HitBuilder.setIfNonNull() called with a null paramName.");
            return (T)this;
        }

        public T addImpression(Product product, String string2) {
            if (product == null) {
                zzae.zzdi("product should be non-null");
                return (T)this;
            }
            String string3 = string2;
            if (string2 == null) {
                string3 = "";
            }
            if (!this.aQ.containsKey(string3)) {
                this.aQ.put(string3, new ArrayList());
            }
            this.aQ.get(string3).add(product);
            return (T)this;
        }

        public T addProduct(Product product) {
            if (product == null) {
                zzae.zzdi("product should be non-null");
                return (T)this;
            }
            this.aS.add(product);
            return (T)this;
        }

        public T addPromotion(Promotion promotion) {
            if (promotion == null) {
                zzae.zzdi("promotion should be non-null");
                return (T)this;
            }
            this.aR.add(promotion);
            return (T)this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public Map<String, String> build() {
            HashMap<String, String> hashMap = new HashMap<String, String>(this.aO);
            if (this.aP != null) {
                hashMap.putAll(this.aP.build());
            }
            Object object = this.aR.iterator();
            int n = 1;
            while (object.hasNext()) {
                hashMap.putAll(object.next().zzep(zzc.zzbr(n)));
                ++n;
            }
            object = this.aS.iterator();
            n = 1;
            while (object.hasNext()) {
                hashMap.putAll(((Product)object.next()).zzep(zzc.zzbp(n)));
                ++n;
            }
            Iterator<Map.Entry<String, List<Product>>> iterator = this.aQ.entrySet().iterator();
            n = 1;
            while (iterator.hasNext()) {
                Map.Entry<String, List<Product>> entry = iterator.next();
                object = entry.getValue();
                String string2 = zzc.zzbu(n);
                Iterator iterator2 = object.iterator();
                int n2 = 1;
                while (iterator2.hasNext()) {
                    Product product = (Product)iterator2.next();
                    object = String.valueOf(string2);
                    String string3 = String.valueOf(zzc.zzbt(n2));
                    object = string3.length() != 0 ? object.concat(string3) : new String((String)object);
                    hashMap.putAll(product.zzep((String)object));
                    ++n2;
                }
                if (!TextUtils.isEmpty((CharSequence)entry.getKey())) {
                    object = String.valueOf(string2);
                    string2 = String.valueOf("nm");
                    object = string2.length() != 0 ? object.concat(string2) : new String((String)object);
                    hashMap.put((String)object, entry.getKey());
                }
                ++n;
            }
            return hashMap;
        }

        protected String get(String string2) {
            return this.aO.get(string2);
        }

        public final T set(String string2, String string3) {
            if (string2 != null) {
                this.aO.put(string2, string3);
                return (T)this;
            }
            zzae.zzdi("HitBuilder.set() called with a null paramName.");
            return (T)this;
        }

        public final T setAll(Map<String, String> map) {
            if (map == null) {
                return (T)this;
            }
            this.aO.putAll(new HashMap<String, String>(map));
            return (T)this;
        }

        public T setCampaignParamsFromUrl(String object) {
            if (TextUtils.isEmpty((CharSequence)(object = zzao.zzfk((String)object)))) {
                return (T)this;
            }
            object = zzao.zzfi((String)object);
            this.zzn("&cc", (String)object.get("utm_content"));
            this.zzn("&cm", (String)object.get("utm_medium"));
            this.zzn("&cn", (String)object.get("utm_campaign"));
            this.zzn("&cs", (String)object.get("utm_source"));
            this.zzn("&ck", (String)object.get("utm_term"));
            this.zzn("&ci", (String)object.get("utm_id"));
            this.zzn("&anid", (String)object.get("anid"));
            this.zzn("&gclid", (String)object.get("gclid"));
            this.zzn("&dclid", (String)object.get("dclid"));
            this.zzn("&aclid", (String)object.get("aclid"));
            this.zzn("&gmob_t", (String)object.get("gmob_t"));
            return (T)this;
        }

        public T setCustomDimension(int n, String string2) {
            this.set(zzc.zzbl(n), string2);
            return (T)this;
        }

        public T setCustomMetric(int n, float f) {
            this.set(zzc.zzbn(n), Float.toString(f));
            return (T)this;
        }

        protected T setHitType(String string2) {
            this.set("&t", string2);
            return (T)this;
        }

        public T setNewSession() {
            this.set("&sc", "start");
            return (T)this;
        }

        public T setNonInteraction(boolean bl) {
            this.set("&ni", zzao.zzax(bl));
            return (T)this;
        }

        public T setProductAction(ProductAction productAction) {
            this.aP = productAction;
            return (T)this;
        }

        public T setPromotionAction(String string2) {
            this.aO.put("&promoa", string2);
            return (T)this;
        }
    }

    @Deprecated
    public static class ItemBuilder
    extends HitBuilder<ItemBuilder> {
        public ItemBuilder() {
            this.set("&t", "item");
        }

        public ItemBuilder setCategory(String string2) {
            this.set("&iv", string2);
            return this;
        }

        public ItemBuilder setCurrencyCode(String string2) {
            this.set("&cu", string2);
            return this;
        }

        public ItemBuilder setName(String string2) {
            this.set("&in", string2);
            return this;
        }

        public ItemBuilder setPrice(double d) {
            this.set("&ip", Double.toString(d));
            return this;
        }

        public ItemBuilder setQuantity(long l) {
            this.set("&iq", Long.toString(l));
            return this;
        }

        public ItemBuilder setSku(String string2) {
            this.set("&ic", string2);
            return this;
        }

        public ItemBuilder setTransactionId(String string2) {
            this.set("&ti", string2);
            return this;
        }
    }

    public static class ScreenViewBuilder
    extends HitBuilder<ScreenViewBuilder> {
        public ScreenViewBuilder() {
            this.set("&t", "screenview");
        }
    }

    public static class SocialBuilder
    extends HitBuilder<SocialBuilder> {
        public SocialBuilder() {
            this.set("&t", "social");
        }

        public SocialBuilder setAction(String string2) {
            this.set("&sa", string2);
            return this;
        }

        public SocialBuilder setNetwork(String string2) {
            this.set("&sn", string2);
            return this;
        }

        public SocialBuilder setTarget(String string2) {
            this.set("&st", string2);
            return this;
        }
    }

    public static class TimingBuilder
    extends HitBuilder<TimingBuilder> {
        public TimingBuilder() {
            this.set("&t", "timing");
        }

        public TimingBuilder(String string2, String string3, long l) {
            this();
            this.setVariable(string3);
            this.setValue(l);
            this.setCategory(string2);
        }

        public TimingBuilder setCategory(String string2) {
            this.set("&utc", string2);
            return this;
        }

        public TimingBuilder setLabel(String string2) {
            this.set("&utl", string2);
            return this;
        }

        public TimingBuilder setValue(long l) {
            this.set("&utt", Long.toString(l));
            return this;
        }

        public TimingBuilder setVariable(String string2) {
            this.set("&utv", string2);
            return this;
        }
    }

    @Deprecated
    public static class TransactionBuilder
    extends HitBuilder<TransactionBuilder> {
        public TransactionBuilder() {
            this.set("&t", "transaction");
        }

        public TransactionBuilder setAffiliation(String string2) {
            this.set("&ta", string2);
            return this;
        }

        public TransactionBuilder setCurrencyCode(String string2) {
            this.set("&cu", string2);
            return this;
        }

        public TransactionBuilder setRevenue(double d) {
            this.set("&tr", Double.toString(d));
            return this;
        }

        public TransactionBuilder setShipping(double d) {
            this.set("&ts", Double.toString(d));
            return this;
        }

        public TransactionBuilder setTax(double d) {
            this.set("&tt", Double.toString(d));
            return this;
        }

        public TransactionBuilder setTransactionId(String string2) {
            this.set("&ti", string2);
            return this;
        }
    }

}

