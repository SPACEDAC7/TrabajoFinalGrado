/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.ecommerce;

import com.google.android.gms.analytics.zzc;
import com.google.android.gms.analytics.zzg;
import com.google.android.gms.common.internal.zzaa;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Product {
    Map<String, String> cB = new HashMap<String, String>();

    void put(String string2, String string3) {
        zzaa.zzb(string2, (Object)"Name should be non-null");
        this.cB.put(string2, string3);
    }

    public Product setBrand(String string2) {
        this.put("br", string2);
        return this;
    }

    public Product setCategory(String string2) {
        this.put("ca", string2);
        return this;
    }

    public Product setCouponCode(String string2) {
        this.put("cc", string2);
        return this;
    }

    public Product setCustomDimension(int n, String string2) {
        this.put(zzc.zzbw(n), string2);
        return this;
    }

    public Product setCustomMetric(int n, int n2) {
        this.put(zzc.zzbx(n), Integer.toString(n2));
        return this;
    }

    public Product setId(String string2) {
        this.put("id", string2);
        return this;
    }

    public Product setName(String string2) {
        this.put("nm", string2);
        return this;
    }

    public Product setPosition(int n) {
        this.put("ps", Integer.toString(n));
        return this;
    }

    public Product setPrice(double d) {
        this.put("pr", Double.toString(d));
        return this;
    }

    public Product setQuantity(int n) {
        this.put("qt", Integer.toString(n));
        return this;
    }

    public Product setVariant(String string2) {
        this.put("va", string2);
        return this;
    }

    public String toString() {
        return zzg.zzar(this.cB);
    }

    /*
     * Enabled aggressive block sorting
     */
    public Map<String, String> zzep(String string2) {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        Iterator<Map.Entry<String, String>> iterator = this.cB.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String string3 = String.valueOf(string2);
            String string4 = String.valueOf(entry.getKey());
            string3 = string4.length() != 0 ? string3.concat(string4) : new String(string3);
            hashMap.put(string3, entry.getValue());
        }
        return hashMap;
    }
}

