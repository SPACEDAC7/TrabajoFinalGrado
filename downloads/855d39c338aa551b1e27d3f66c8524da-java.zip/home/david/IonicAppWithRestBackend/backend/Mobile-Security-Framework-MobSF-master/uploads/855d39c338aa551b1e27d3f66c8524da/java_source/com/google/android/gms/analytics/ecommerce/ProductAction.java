/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.ecommerce;

import com.google.android.gms.analytics.zzg;
import com.google.android.gms.common.internal.zzaa;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ProductAction {
    public static final String ACTION_ADD = "add";
    public static final String ACTION_CHECKOUT = "checkout";
    public static final String ACTION_CHECKOUT_OPTION = "checkout_option";
    @Deprecated
    public static final String ACTION_CHECKOUT_OPTIONS = "checkout_options";
    public static final String ACTION_CLICK = "click";
    public static final String ACTION_DETAIL = "detail";
    public static final String ACTION_PURCHASE = "purchase";
    public static final String ACTION_REFUND = "refund";
    public static final String ACTION_REMOVE = "remove";
    Map<String, String> cB = new HashMap<String, String>();

    public ProductAction(String string2) {
        this.put("&pa", string2);
    }

    public Map<String, String> build() {
        return new HashMap<String, String>(this.cB);
    }

    void put(String string2, String string3) {
        zzaa.zzb(string2, (Object)"Name should be non-null");
        this.cB.put(string2, string3);
    }

    public ProductAction setCheckoutOptions(String string2) {
        this.put("&col", string2);
        return this;
    }

    public ProductAction setCheckoutStep(int n) {
        this.put("&cos", Integer.toString(n));
        return this;
    }

    public ProductAction setProductActionList(String string2) {
        this.put("&pal", string2);
        return this;
    }

    public ProductAction setProductListSource(String string2) {
        this.put("&pls", string2);
        return this;
    }

    public ProductAction setTransactionAffiliation(String string2) {
        this.put("&ta", string2);
        return this;
    }

    public ProductAction setTransactionCouponCode(String string2) {
        this.put("&tcc", string2);
        return this;
    }

    public ProductAction setTransactionId(String string2) {
        this.put("&ti", string2);
        return this;
    }

    public ProductAction setTransactionRevenue(double d) {
        this.put("&tr", Double.toString(d));
        return this;
    }

    public ProductAction setTransactionShipping(double d) {
        this.put("&ts", Double.toString(d));
        return this;
    }

    public ProductAction setTransactionTax(double d) {
        this.put("&tt", Double.toString(d));
        return this;
    }

    public String toString() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        for (Map.Entry<String, String> entry : this.cB.entrySet()) {
            if (entry.getKey().startsWith("&")) {
                hashMap.put(entry.getKey().substring(1), entry.getValue());
                continue;
            }
            hashMap.put(entry.getKey(), entry.getValue());
        }
        return zzg.zzar(hashMap);
    }
}

