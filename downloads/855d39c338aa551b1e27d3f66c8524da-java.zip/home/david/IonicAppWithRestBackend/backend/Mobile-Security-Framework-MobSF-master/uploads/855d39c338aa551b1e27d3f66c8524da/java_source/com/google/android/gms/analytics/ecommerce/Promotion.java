/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.ecommerce;

import com.google.android.gms.analytics.zzg;
import com.google.android.gms.common.internal.zzaa;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Promotion {
    public static final String ACTION_CLICK = "click";
    public static final String ACTION_VIEW = "view";
    Map<String, String> cB = new HashMap<String, String>();

    void put(String string2, String string3) {
        zzaa.zzb(string2, (Object)"Name should be non-null");
        this.cB.put(string2, string3);
    }

    public Promotion setCreative(String string2) {
        this.put("cr", string2);
        return this;
    }

    public Promotion setId(String string2) {
        this.put("id", string2);
        return this;
    }

    public Promotion setName(String string2) {
        this.put("nm", string2);
        return this;
    }

    public Promotion setPosition(String string2) {
        this.put("ps", string2);
        return this;
    }

    public String toString() {
        return zzg.zzar(this.cB);
    }

    /*
     * Enabled aggressive block sorting
     */
    public Map<String, String> zzep(String string2) {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        Iterator<Map.Entry<String, String>> iterator = this.cB.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String string3 = String.valueOf(string2);
            String string4 = String.valueOf(entry.getKey());
            string3 = string4.length() != 0 ? string3.concat(string4) : new String(string3);
            hashMap.put(string3, entry.getValue());
        }
        return hashMap;
    }
}

