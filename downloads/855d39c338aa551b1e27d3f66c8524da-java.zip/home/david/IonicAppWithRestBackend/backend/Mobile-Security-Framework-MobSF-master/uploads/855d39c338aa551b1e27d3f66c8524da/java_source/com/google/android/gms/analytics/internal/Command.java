/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.analytics.internal;

import android.os.Parcel;
import android.os.Parcelable;

public class Command
implements Parcelable {
    @Deprecated
    public static final Parcelable.Creator<Command> CREATOR = new Parcelable.Creator<Command>(){

        @Deprecated
        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return this.zzw(parcel);
        }

        @Deprecated
        public /* synthetic */ Object[] newArray(int n) {
            return this.zzcf(n);
        }

        @Deprecated
        public Command[] zzcf(int n) {
            return new Command[n];
        }

        @Deprecated
        public Command zzw(Parcel parcel) {
            return new Command(parcel);
        }
    };
    private String dW;
    private String mValue;
    private String zzboa;

    @Deprecated
    public Command() {
    }

    @Deprecated
    Command(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    @Deprecated
    private void readFromParcel(Parcel parcel) {
        this.zzboa = parcel.readString();
        this.dW = parcel.readString();
        this.mValue = parcel.readString();
    }

    @Deprecated
    public int describeContents() {
        return 0;
    }

    public String getId() {
        return this.zzboa;
    }

    public String getValue() {
        return this.mValue;
    }

    @Deprecated
    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.zzboa);
        parcel.writeString(this.dW);
        parcel.writeString(this.mValue);
    }

}

