/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 */
package com.google.android.gms.analytics.internal;

import android.text.TextUtils;
import com.google.android.gms.analytics.internal.Command;
import com.google.android.gms.analytics.internal.zzao;
import com.google.android.gms.analytics.internal.zzc;
import com.google.android.gms.common.internal.zzaa;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class zzab {
    private final List<Command> fi;
    private final long fj;
    private final long fk;
    private final int fl;
    private final boolean fm;
    private final String fn;
    private final Map<String, String> zzbly;

    public zzab(zzc zzc2, Map<String, String> map, long l, boolean bl) {
        this(zzc2, map, l, bl, 0, 0, null);
    }

    public zzab(zzc zzc2, Map<String, String> map, long l, boolean bl, long l2, int n) {
        this(zzc2, map, l, bl, l2, n, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public zzab(zzc zzc2, Map<String, String> iterator, long l, boolean bl, long l2, int n, List<Command> map) {
        void var10_9;
        zzaa.zzy(zzc2);
        zzaa.zzy(iterator);
        this.fk = l;
        this.fm = bl;
        this.fj = l2;
        this.fl = n;
        if (map != null) {
            Map map2 = map;
        } else {
            List list = Collections.emptyList();
        }
        this.fi = var10_9;
        this.fn = zzab.zzs(map);
        map = new HashMap();
        for (Map.Entry entry : iterator.entrySet()) {
            String string2;
            if (!zzab.zzl(entry.getKey()) || (string2 = zzab.zza(zzc2, entry.getKey())) == null) continue;
            map.put(string2, zzab.zzb(zzc2, entry.getValue()));
        }
        for (Map.Entry entry2 : iterator.entrySet()) {
            String string3;
            if (zzab.zzl(entry2.getKey()) || (string3 = zzab.zza(zzc2, entry2.getKey())) == null) continue;
            map.put(string3, zzab.zzb(zzc2, entry2.getValue()));
        }
        if (!TextUtils.isEmpty((CharSequence)this.fn)) {
            zzao.zzc(map, "_v", this.fn);
            if (this.fn.equals("ma4.0.0") || this.fn.equals("ma4.0.1")) {
                map.remove("adid");
            }
        }
        this.zzbly = Collections.unmodifiableMap(map);
    }

    public static zzab zza(zzc zzc2, zzab zzab2, Map<String, String> map) {
        return new zzab(zzc2, map, zzab2.zzaga(), zzab2.zzagc(), zzab2.zzafz(), zzab2.zzafy(), zzab2.zzagb());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static String zza(zzc object, Object object2) {
        Object object3;
        if (object2 == null) {
            return null;
        }
        object2 = object3 = object2.toString();
        if (object3.startsWith("&")) {
            object2 = object3.substring(1);
        }
        int n = object2.length();
        object3 = object2;
        if (n > 256) {
            object3 = object2.substring(0, 256);
            object.zzc("Hit param name is too long and will be trimmed", n, object3);
        }
        object = object3;
        if (!TextUtils.isEmpty((CharSequence)object3)) return object;
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String zzb(zzc zzc2, Object object) {
        object = object == null ? "" : object.toString();
        int n = object.length();
        Object object2 = object;
        if (n > 8192) {
            object2 = object.substring(0, 8192);
            zzc2.zzc("Hit param value is too long and will be trimmed", n, object2);
        }
        return object2;
    }

    private static boolean zzl(Object object) {
        if (object == null) {
            return false;
        }
        return object.toString().startsWith("&");
    }

    /*
     * Enabled aggressive block sorting
     */
    private String zzr(String string2, String string3) {
        zzaa.zzib(string2);
        boolean bl = !string2.startsWith("&");
        zzaa.zzb(bl, (Object)"Short param name required");
        string2 = this.zzbly.get(string2);
        if (string2 != null) {
            return string2;
        }
        return string3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String zzs(List<Command> object) {
        if (object != null) {
            object = object.iterator();
            while (object.hasNext()) {
                Command command = (Command)object.next();
                if (!"appendVersion".equals(command.getId())) continue;
                object = command.getValue();
                break;
            }
        } else {
            object = null;
        }
        if (TextUtils.isEmpty(object)) {
            return null;
        }
        return object;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("ht=").append(this.fk);
        if (this.fj != 0) {
            stringBuffer.append(", dbId=").append(this.fj);
        }
        if (this.fl != 0) {
            stringBuffer.append(", appUID=").append(this.fl);
        }
        Object object = new ArrayList<String>(this.zzbly.keySet());
        Collections.sort(object);
        object = object.iterator();
        while (object.hasNext()) {
            String string2 = (String)object.next();
            stringBuffer.append(", ");
            stringBuffer.append(string2);
            stringBuffer.append("=");
            stringBuffer.append(this.zzbly.get(string2));
        }
        return stringBuffer.toString();
    }

    public int zzafy() {
        return this.fl;
    }

    public long zzafz() {
        return this.fj;
    }

    public long zzaga() {
        return this.fk;
    }

    public List<Command> zzagb() {
        return this.fi;
    }

    public boolean zzagc() {
        return this.fm;
    }

    public long zzagd() {
        return zzao.zzfj(this.zzr("_s", "0"));
    }

    public String zzage() {
        return this.zzr("_m", "");
    }

    public Map<String, String> zzmc() {
        return this.zzbly;
    }
}

