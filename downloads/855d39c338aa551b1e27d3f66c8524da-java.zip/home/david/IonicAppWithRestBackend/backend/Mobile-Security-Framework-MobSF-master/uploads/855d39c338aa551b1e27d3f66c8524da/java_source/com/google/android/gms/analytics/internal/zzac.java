/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.analytics.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.analytics.internal.Command;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface zzac
extends IInterface {
    public String getVersion() throws RemoteException;

    public void zza(Map var1, long var2, String var4, List<Command> var5) throws RemoteException;

    public void zzabr() throws RemoteException;

    public static abstract class com.google.android.gms.analytics.internal.zzac$zza
    extends Binder
    implements zzac {
        public static zzac zzbm(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.analytics.internal.IAnalyticsService");
            if (iInterface != null && iInterface instanceof zzac) {
                return (zzac)iInterface;
            }
            return new zza(iBinder);
        }

        public boolean onTransact(int n, Parcel object, Parcel parcel, int n2) throws RemoteException {
            switch (n) {
                default: {
                    return super.onTransact(n, (Parcel)object, parcel, n2);
                }
                case 1598968902: {
                    parcel.writeString("com.google.android.gms.analytics.internal.IAnalyticsService");
                    return true;
                }
                case 1: {
                    object.enforceInterface("com.google.android.gms.analytics.internal.IAnalyticsService");
                    this.zza((Map)object.readHashMap(this.getClass().getClassLoader()), object.readLong(), object.readString(), (List)object.createTypedArrayList(Command.CREATOR));
                    parcel.writeNoException();
                    return true;
                }
                case 2: {
                    object.enforceInterface("com.google.android.gms.analytics.internal.IAnalyticsService");
                    this.zzabr();
                    parcel.writeNoException();
                    return true;
                }
                case 3: 
            }
            object.enforceInterface("com.google.android.gms.analytics.internal.IAnalyticsService");
            object = this.getVersion();
            parcel.writeNoException();
            parcel.writeString((String)object);
            return true;
        }

        private static class zza
        implements zzac {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            @Override
            public String getVersion() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.analytics.internal.IAnalyticsService");
                    this.zzajq.transact(3, parcel, parcel2, 0);
                    parcel2.readException();
                    String string2 = parcel2.readString();
                    return string2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public void zza(Map map, long l, String string2, List<Command> list) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.analytics.internal.IAnalyticsService");
                    parcel.writeMap(map);
                    parcel.writeLong(l);
                    parcel.writeString(string2);
                    parcel.writeTypedList(list);
                    this.zzajq.transact(1, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public void zzabr() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.analytics.internal.IAnalyticsService");
                    this.zzajq.transact(2, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

