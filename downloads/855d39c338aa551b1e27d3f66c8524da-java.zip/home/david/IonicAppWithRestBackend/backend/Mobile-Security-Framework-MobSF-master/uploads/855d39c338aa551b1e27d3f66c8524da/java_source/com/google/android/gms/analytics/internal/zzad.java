/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.internal;

import com.google.android.gms.analytics.internal.zzae;
import com.google.android.gms.common.util.zze;

public class zzad {
    private final String cd;
    private final long fo;
    private final int fp;
    private double fq;
    private long fr;
    private final Object fs = new Object();
    private final zze zzaql;

    public zzad(int n, long l, String string2, zze zze2) {
        this.fp = n;
        this.fq = this.fp;
        this.fo = l;
        this.cd = string2;
        this.zzaql = zze2;
    }

    public zzad(String string2, zze zze2) {
        this(60, 2000, string2, zze2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean zzagf() {
        Object object = this.fs;
        synchronized (object) {
            double d;
            long l = this.zzaql.currentTimeMillis();
            if (this.fq < (double)this.fp && (d = (double)(l - this.fr) / (double)this.fo) > 0.0) {
                this.fq = Math.min((double)this.fp, d + this.fq);
            }
            this.fr = l;
            if (this.fq >= 1.0) {
                this.fq -= 1.0;
                return true;
            }
            String string2 = this.cd;
            zzae.zzdi(new StringBuilder(String.valueOf(string2).length() + 34).append("Excessive ").append(string2).append(" detected; call ignored.").toString());
            return false;
        }
    }
}

