/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.google.android.gms.analytics.internal;

import android.util.Log;
import com.google.android.gms.analytics.Logger;
import com.google.android.gms.analytics.internal.zzaf;
import com.google.android.gms.analytics.internal.zzs;
import com.google.android.gms.analytics.internal.zzy;

@Deprecated
public class zzae {
    private static volatile Logger ft;

    static {
        zzae.setLogger(new zzs());
    }

    public static Logger getLogger() {
        return ft;
    }

    public static void setLogger(Logger logger) {
        ft = logger;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void v(String string2) {
        Object object = zzaf.zzagg();
        if (object != null) {
            object.zzes(string2);
        } else if (zzae.zzbi(0)) {
            Log.v((String)zzy.en.get(), (String)string2);
        }
        if ((object = ft) != null) {
            object.verbose(string2);
        }
    }

    public static boolean zzbi(int n) {
        boolean bl;
        boolean bl2 = bl = false;
        if (zzae.getLogger() != null) {
            bl2 = bl;
            if (zzae.getLogger().getLogLevel() <= n) {
                bl2 = true;
            }
        }
        return bl2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void zzdh(String string2) {
        Object object = zzaf.zzagg();
        if (object != null) {
            object.zzeu(string2);
        } else if (zzae.zzbi(1)) {
            Log.i((String)zzy.en.get(), (String)string2);
        }
        if ((object = ft) != null) {
            object.info(string2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void zzdi(String string2) {
        Object object = zzaf.zzagg();
        if (object != null) {
            object.zzev(string2);
        } else if (zzae.zzbi(2)) {
            Log.w((String)zzy.en.get(), (String)string2);
        }
        if ((object = ft) != null) {
            object.warn(string2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void zzf(String string2, Object object) {
        zzaf zzaf2 = zzaf.zzagg();
        if (zzaf2 != null) {
            zzaf2.zze(string2, object);
        } else if (zzae.zzbi(3)) {
            if (object != null) {
                object = String.valueOf(object);
                object = new StringBuilder(String.valueOf(string2).length() + 1 + String.valueOf(object).length()).append(string2).append(":").append((String)object).toString();
            } else {
                object = string2;
            }
            Log.e((String)zzy.en.get(), (String)object);
        }
        if ((object = ft) != null) {
            object.error(string2);
        }
    }
}

