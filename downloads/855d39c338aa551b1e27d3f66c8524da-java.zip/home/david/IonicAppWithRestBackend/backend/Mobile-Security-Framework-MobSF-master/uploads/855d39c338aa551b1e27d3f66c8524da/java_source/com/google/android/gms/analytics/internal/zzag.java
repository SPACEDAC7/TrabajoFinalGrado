/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package com.google.android.gms.analytics.internal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import com.google.android.gms.analytics.internal.zzaf;
import com.google.android.gms.analytics.internal.zzb;
import com.google.android.gms.analytics.internal.zzf;
import com.google.android.gms.common.internal.zzaa;

class zzag
extends BroadcastReceiver {
    static final String fx = zzag.class.getName();
    private final zzf cQ;
    private boolean fy;
    private boolean fz;

    zzag(zzf zzf2) {
        zzaa.zzy(zzf2);
        this.cQ = zzf2;
    }

    private Context getContext() {
        return this.cQ.getContext();
    }

    private zzaf zzaca() {
        return this.cQ.zzaca();
    }

    private void zzagi() {
        this.zzaca();
        this.zzzg();
    }

    private zzb zzzg() {
        return this.cQ.zzzg();
    }

    public boolean isConnected() {
        if (!this.fy) {
            this.cQ.zzaca().zzev("Connectivity unknown. Receiver not registered");
        }
        return this.fz;
    }

    public boolean isRegistered() {
        return this.fy;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onReceive(Context object, Intent intent) {
        this.zzagi();
        object = intent.getAction();
        this.cQ.zzaca().zza("NetworkBroadcastReceiver received action", object);
        if ("android.net.conn.CONNECTIVITY_CHANGE".equals(object)) {
            boolean bl = this.zzagk();
            if (this.fz == bl) return;
            {
                this.fz = bl;
                this.zzzg().zzaw(bl);
                return;
            }
        } else {
            if (!"com.google.analytics.RADIO_POWERED".equals(object)) {
                this.cQ.zzaca().zzd("NetworkBroadcastReceiver received unknown action", object);
                return;
            }
            if (intent.hasExtra(fx)) return;
            {
                this.zzzg().zzabv();
                return;
            }
        }
    }

    public void unregister() {
        if (!this.isRegistered()) {
            return;
        }
        this.cQ.zzaca().zzes("Unregistering connectivity change receiver");
        this.fy = false;
        this.fz = false;
        Context context = this.getContext();
        try {
            context.unregisterReceiver((BroadcastReceiver)this);
            return;
        }
        catch (IllegalArgumentException var1_2) {
            this.zzaca().zze("Failed to unregister the network broadcast receiver", var1_2);
            return;
        }
    }

    public void zzagh() {
        this.zzagi();
        if (this.fy) {
            return;
        }
        Context context = this.getContext();
        context.registerReceiver((BroadcastReceiver)this, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        IntentFilter intentFilter = new IntentFilter("com.google.analytics.RADIO_POWERED");
        intentFilter.addCategory(context.getPackageName());
        context.registerReceiver((BroadcastReceiver)this, intentFilter);
        this.fz = this.zzagk();
        this.cQ.zzaca().zza("Registering connectivity change receiver. Network connected", this.fz);
        this.fy = true;
    }

    public void zzagj() {
        if (Build.VERSION.SDK_INT <= 10) {
            return;
        }
        Context context = this.getContext();
        Intent intent = new Intent("com.google.analytics.RADIO_POWERED");
        intent.addCategory(context.getPackageName());
        intent.putExtra(fx, true);
        context.sendOrderedBroadcast(intent, null);
    }

    protected boolean zzagk() {
        block3 : {
            ConnectivityManager connectivityManager = (ConnectivityManager)this.getContext().getSystemService("connectivity");
            try {
                connectivityManager = connectivityManager.getActiveNetworkInfo();
                if (connectivityManager == null) break block3;
            }
            catch (SecurityException var2_2) {
                return false;
            }
            boolean bl = connectivityManager.isConnected();
            if (!bl) break block3;
            return true;
        }
        return false;
    }
}

