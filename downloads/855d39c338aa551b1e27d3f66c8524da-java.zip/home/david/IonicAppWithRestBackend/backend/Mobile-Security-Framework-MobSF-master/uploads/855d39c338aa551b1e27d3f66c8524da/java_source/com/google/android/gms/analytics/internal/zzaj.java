/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 */
package com.google.android.gms.analytics.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.RequiresPermission;
import com.google.android.gms.analytics.internal.zzaf;
import com.google.android.gms.analytics.internal.zzak;
import com.google.android.gms.analytics.internal.zzao;
import com.google.android.gms.analytics.internal.zzf;
import com.google.android.gms.analytics.internal.zzr;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzxr;

public final class zzaj {
    static zzxr ax;
    static Boolean ay;
    static Object zzaox;

    static {
        zzaox = new Object();
    }

    public static boolean zzat(Context context) {
        zzaa.zzy(context);
        if (ay != null) {
            return ay;
        }
        boolean bl = zzao.zza(context, "com.google.android.gms.analytics.AnalyticsReceiver", false);
        ay = bl;
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @RequiresPermission(allOf={"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"})
    public void onReceive(Context context, Intent object) {
        zzf zzf2 = zzf.zzaw(context);
        zzaf zzaf2 = zzf2.zzaca();
        if (object == null) {
            zzaf2.zzev("AnalyticsReceiver called with null intent");
            return;
        }
        object = object.getAction();
        zzf2.zzacb();
        zzaf2.zza("Local AnalyticsReceiver got", object);
        if (!"com.google.android.gms.analytics.ANALYTICS_DISPATCH".equals(object)) return;
        boolean bl = zzak.zzau(context);
        zzf2 = new Intent("com.google.android.gms.analytics.ANALYTICS_DISPATCH");
        zzf2.setComponent(new ComponentName(context, "com.google.android.gms.analytics.AnalyticsService"));
        zzf2.setAction("com.google.android.gms.analytics.ANALYTICS_DISPATCH");
        object = zzaox;
        // MONITORENTER : object
        context.startService((Intent)zzf2);
        if (!bl) {
            // MONITOREXIT : object
            return;
        }
        try {
            if (ax == null) {
                ax = new zzxr(context, 1, "Analytics WakeLock");
                ax.setReferenceCounted(false);
            }
            ax.acquire(1000);
            // MONITOREXIT : object
            return;
        }
        catch (SecurityException var1_2) {
            zzaf2.zzev("Analytics service at risk of not starting. For more reliable analytics, add the WAKE_LOCK permission to your manifest. See http://goo.gl/8Rd3yj for instructions.");
            return;
        }
    }
}

