/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Handler
 */
package com.google.android.gms.analytics.internal;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.RequiresPermission;
import com.google.android.gms.analytics.internal.zzaf;
import com.google.android.gms.analytics.internal.zzaj;
import com.google.android.gms.analytics.internal.zzao;
import com.google.android.gms.analytics.internal.zzb;
import com.google.android.gms.analytics.internal.zzf;
import com.google.android.gms.analytics.internal.zzr;
import com.google.android.gms.analytics.internal.zzw;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzxr;

public final class zzak {
    private static Boolean az;
    private final zza fL;
    private final Context mContext;
    private final Handler mHandler;

    public zzak(zza zza2) {
        this.mContext = zza2.getContext();
        zzaa.zzy(this.mContext);
        this.fL = zza2;
        this.mHandler = new Handler();
    }

    public static boolean zzau(Context context) {
        zzaa.zzy(context);
        if (az != null) {
            return az;
        }
        boolean bl = zzao.zzr(context, "com.google.android.gms.analytics.AnalyticsService");
        az = bl;
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void zzyz() {
        zzxr zzxr2;
        try {
            Object object = zzaj.zzaox;
            synchronized (object) {
                zzxr2 = zzaj.ax;
            }
        }
        catch (SecurityException var1_2) {
            return;
        }
        {
            if (zzxr2 != null && zzxr2.isHeld()) {
                zzxr2.release();
            }
            return;
        }
    }

    @RequiresPermission(allOf={"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"})
    public void onCreate() {
        zzf zzf2 = zzf.zzaw(this.mContext);
        zzaf zzaf2 = zzf2.zzaca();
        zzf2.zzacb();
        zzaf2.zzes("Local AnalyticsService is starting up");
    }

    @RequiresPermission(allOf={"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"})
    public void onDestroy() {
        zzf zzf2 = zzf.zzaw(this.mContext);
        zzaf zzaf2 = zzf2.zzaca();
        zzf2.zzacb();
        zzaf2.zzes("Local AnalyticsService is shutting down");
    }

    /*
     * Enabled aggressive block sorting
     */
    @RequiresPermission(allOf={"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"})
    public int onStartCommand(Intent object, int n, final int n2) {
        this.zzyz();
        final zzf zzf2 = zzf.zzaw(this.mContext);
        final zzaf zzaf2 = zzf2.zzaca();
        if (object == null) {
            zzaf2.zzev("AnalyticsService started with null intent");
            return 2;
        } else {
            object = object.getAction();
            zzf2.zzacb();
            zzaf2.zza("Local AnalyticsService called. startId, action", n2, object);
            if (!"com.google.android.gms.analytics.ANALYTICS_DISPATCH".equals(object)) return 2;
            {
                zzf2.zzzg().zza(new zzw(){

                    @Override
                    public void zzf(Throwable throwable) {
                        zzak.this.mHandler.post(new Runnable(){

                            @Override
                            public void run() {
                                if (zzak.this.fL.callServiceStopSelfResult(n2)) {
                                    zzf2.zzacb();
                                    zzaf2.zzes("Local AnalyticsService processed last dispatch request");
                                }
                            }
                        });
                    }

                });
                return 2;
            }
        }
    }

    public static interface zza {
        public boolean callServiceStopSelfResult(int var1);

        public Context getContext();
    }

}

