/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.internal;

import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.util.zze;

class zzal {
    private final zze zzaql;
    private long zzbwt;

    public zzal(zze zze2) {
        zzaa.zzy(zze2);
        this.zzaql = zze2;
    }

    public zzal(zze zze2, long l) {
        zzaa.zzy(zze2);
        this.zzaql = zze2;
        this.zzbwt = l;
    }

    public void clear() {
        this.zzbwt = 0;
    }

    public void start() {
        this.zzbwt = this.zzaql.elapsedRealtime();
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean zzz(long l) {
        if (this.zzbwt == 0 || this.zzaql.elapsedRealtime() - this.zzbwt > l) {
            return true;
        }
        return false;
    }
}

