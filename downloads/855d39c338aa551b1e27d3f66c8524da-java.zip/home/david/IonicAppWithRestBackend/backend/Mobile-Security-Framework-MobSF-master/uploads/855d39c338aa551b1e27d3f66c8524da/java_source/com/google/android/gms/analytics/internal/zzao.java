/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ServiceInfo
 *  android.text.TextUtils
 */
package com.google.android.gms.analytics.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.text.TextUtils;
import com.google.android.gms.analytics.internal.zzaf;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.util.zzn;
import com.google.android.gms.internal.zzmt;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class zzao {
    private static final char[] fW = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    public static double zza(String string2, double d) {
        if (string2 == null) {
            return d;
        }
        try {
            double d2 = Double.parseDouble(string2);
            return d2;
        }
        catch (NumberFormatException var0_1) {
            return d;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static zzmt zza(zzaf object, String object2) {
        zzaa.zzy(object);
        if (TextUtils.isEmpty(object2)) {
            return null;
        }
        new HashMap();
        try {
            object2 = String.valueOf(object2);
            object2 = object2.length() != 0 ? "?".concat((String)object2) : new String("?");
            object2 = zzn.zza(new URI((String)object2), "UTF-8");
            object = new zzmt();
            object.zzdx(object2.get("utm_content"));
            object.zzdv(object2.get("utm_medium"));
            object.setName(object2.get("utm_campaign"));
            object.zzdu(object2.get("utm_source"));
            object.zzdw(object2.get("utm_term"));
            object.zzdy(object2.get("utm_id"));
            object.zzdz(object2.get("anid"));
            object.zzea(object2.get("gclid"));
            object.zzeb(object2.get("dclid"));
            object.zzec(object2.get("aclid"));
            return object;
        }
        catch (URISyntaxException var1_2) {
            object.zzd("No valid campaign data found", var1_2);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String zza(Locale locale) {
        String string2;
        if (locale == null || TextUtils.isEmpty((CharSequence)(string2 = locale.getLanguage()))) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2.toLowerCase());
        if (!TextUtils.isEmpty((CharSequence)locale.getCountry())) {
            stringBuilder.append("-").append(locale.getCountry().toLowerCase());
        }
        return stringBuilder.toString();
    }

    public static void zza(Map<String, String> map, String string2, Map<String, String> map2) {
        zzao.zzc(map, string2, map2.get(string2));
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean zza(double d, String string2) {
        if (d <= 0.0 || d >= 100.0 || (double)(zzao.zzfm(string2) % 10000) < 100.0 * d) {
            return false;
        }
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean zza(Context context, String string2, boolean bl) {
        context = context.getPackageManager().getReceiverInfo(new ComponentName(context, string2), 2);
        if (context == null) return false;
        if (!context.enabled) return false;
        if (!bl) return true;
        try {
            bl = context.exported;
            if (!bl) return false;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            // empty catch block
        }
        return true;
        return false;
    }

    public static String zzax(boolean bl) {
        if (bl) {
            return "1";
        }
        return "0";
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void zzb(Map<String, String> map, String string2, boolean bl) {
        if (!map.containsKey(string2)) {
            String string3 = bl ? "1" : "0";
            map.put(string2, string3);
        }
    }

    public static void zzc(Map<String, String> map, String string2, String string3) {
        if (string3 != null && !map.containsKey(string2)) {
            map.put(string2, string3);
        }
    }

    public static void zzd(Map<String, String> map, String string2, String string3) {
        if (string3 != null && TextUtils.isEmpty((CharSequence)map.get(string2))) {
            map.put(string2, string3);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Map<String, String> zzfi(String string2) {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        String[] arrstring = string2.split("&");
        int n = arrstring.length;
        int n2 = 0;
        while (n2 < n) {
            String[] arrstring2 = arrstring[n2].split("=", 3);
            if (arrstring2.length > 1) {
                String string3 = arrstring2[0];
                string2 = TextUtils.isEmpty((CharSequence)arrstring2[1]) ? null : arrstring2[1];
                hashMap.put(string3, string2);
                if (arrstring2.length == 3 && !TextUtils.isEmpty((CharSequence)arrstring2[1]) && !hashMap.containsKey(arrstring2[1])) {
                    string3 = arrstring2[1];
                    string2 = TextUtils.isEmpty((CharSequence)arrstring2[2]) ? null : arrstring2[2];
                    hashMap.put(string3, string2);
                }
            } else if (arrstring2.length == 1 && arrstring2[0].length() != 0) {
                hashMap.put(arrstring2[0], null);
            }
            ++n2;
        }
        return hashMap;
    }

    public static long zzfj(String string2) {
        if (string2 == null) {
            return 0;
        }
        try {
            long l = Long.parseLong(string2);
            return l;
        }
        catch (NumberFormatException var0_1) {
            return 0;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String zzfk(String map) {
        Object object;
        int n = 0;
        if (TextUtils.isEmpty(map)) {
            return null;
        }
        String[] arrstring = map;
        if (map.contains((CharSequence)"?")) {
            object = map.split("[\\?]");
            arrstring = map;
            if (object.length > 1) {
                arrstring = object[1];
            }
        }
        if (arrstring.contains("%3D")) {
            map = URLDecoder.decode(arrstring, "UTF-8");
        } else {
            map = arrstring;
            if (!arrstring.contains("=")) {
                return null;
            }
        }
        map = zzao.zzfi((String)((Object)map));
        arrstring = new String[]{"dclid", "utm_source", "gclid", "aclid", "utm_campaign", "utm_medium", "utm_term", "utm_content", "utm_id", "anid", "gmob_t"};
        object = new StringBuilder();
        while (n < 11) {
            if (!TextUtils.isEmpty((CharSequence)map.get(arrstring[n]))) {
                if (object.length() > 0) {
                    object.append("&");
                }
                object.append(arrstring[n]).append("=").append(map.get(arrstring[n]));
            }
            ++n;
        }
        return object.toString();
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            return null;
        }
    }

    public static MessageDigest zzfl(String string2) {
        for (int i = 0; i < 2; ++i) {
            try {
                MessageDigest messageDigest = MessageDigest.getInstance(string2);
                if (messageDigest == null) continue;
                return messageDigest;
            }
            catch (NoSuchAlgorithmException var2_3) {
                // empty catch block
            }
        }
        return null;
    }

    public static int zzfm(String string2) {
        int n = 1;
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            int n2 = string2.length();
            int n3 = 0;
            --n2;
            do {
                n = n3;
                if (n2 < 0) break;
                n = string2.charAt(n2);
                n = (n3 << 6 & 268435455) + n + (n << 14);
                int n4 = 266338304 & n;
                n3 = n;
                if (n4 != 0) {
                    n3 = n ^ n4 >> 21;
                }
                --n2;
            } while (true);
        }
        return n;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean zzfn(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2) || !string2.startsWith("http:")) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean zzg(String string2, boolean bl) {
        boolean bl2 = bl;
        if (string2 == null) return bl2;
        if (string2.equalsIgnoreCase("true")) return true;
        if (string2.equalsIgnoreCase("yes")) return true;
        if (string2.equalsIgnoreCase("1")) {
            return true;
        }
        if (string2.equalsIgnoreCase("false")) return false;
        if (string2.equalsIgnoreCase("no")) return false;
        bl2 = bl;
        if (!string2.equalsIgnoreCase("0")) return bl2;
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean zzr(Context context, String string2) {
        context = context.getPackageManager().getServiceInfo(new ComponentName(context, string2), 4);
        if (context == null) return false;
        try {
            boolean bl = context.enabled;
            if (!bl) return false;
            return true;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            // empty catch block
        }
        return false;
    }
}

