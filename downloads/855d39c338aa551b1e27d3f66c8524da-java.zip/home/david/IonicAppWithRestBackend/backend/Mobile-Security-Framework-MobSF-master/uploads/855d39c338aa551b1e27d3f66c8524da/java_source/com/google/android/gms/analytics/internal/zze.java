/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.internal;

import com.google.android.gms.common.zzc;

public class zze {
    public static final String VERSION = String.valueOf(zzc.GOOGLE_PLAY_SERVICES_VERSION_CODE / 1000).replaceAll("(\\d+)(\\d)(\\d\\d)", "$1.$2.$3");
    public static final String cS;

    /*
     * Enabled aggressive block sorting
     */
    static {
        String string2 = String.valueOf(VERSION);
        string2 = string2.length() != 0 ? "ma".concat(string2) : new String("ma");
        cS = string2;
    }
}

