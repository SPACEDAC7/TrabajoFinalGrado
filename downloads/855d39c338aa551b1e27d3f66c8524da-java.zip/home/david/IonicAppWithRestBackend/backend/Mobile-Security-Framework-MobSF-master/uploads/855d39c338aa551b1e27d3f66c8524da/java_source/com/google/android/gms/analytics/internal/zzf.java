/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.google.android.gms.analytics.internal;

import android.content.Context;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.internal.zza;
import com.google.android.gms.analytics.internal.zzaf;
import com.google.android.gms.analytics.internal.zzai;
import com.google.android.gms.analytics.internal.zzap;
import com.google.android.gms.analytics.internal.zzb;
import com.google.android.gms.analytics.internal.zzd;
import com.google.android.gms.analytics.internal.zze;
import com.google.android.gms.analytics.internal.zzg;
import com.google.android.gms.analytics.internal.zzk;
import com.google.android.gms.analytics.internal.zzn;
import com.google.android.gms.analytics.internal.zzr;
import com.google.android.gms.analytics.internal.zzu;
import com.google.android.gms.analytics.internal.zzv;
import com.google.android.gms.analytics.internal.zzy;
import com.google.android.gms.analytics.zzi;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.util.zzh;

public class zzf {
    private static volatile zzf cT;
    private final Context cU;
    private final zzr cV;
    private final zzaf cW;
    private final zzi cX;
    private final zzb cY;
    private final zzv cZ;
    private final zzap da;
    private final zzai db;
    private final GoogleAnalytics dc;
    private final zzn dd;
    private final zza de;
    private final zzk df;
    private final zzu dg;
    private final Context mContext;
    private final com.google.android.gms.common.util.zze zzaql;

    protected zzf(zzg object) {
        Object object2 = object.getApplicationContext();
        zzaa.zzb(object2, (Object)"Application context can't be null");
        Object object3 = object.zzacl();
        zzaa.zzy(object3);
        this.mContext = object2;
        this.cU = object3;
        this.zzaql = object.zzh(this);
        this.cV = object.zzg(this);
        object3 = object.zzf(this);
        object3.initialize();
        this.cW = object3;
        this.zzacb();
        object3 = this.zzaca();
        Object object4 = zze.VERSION;
        object3.zzeu(new StringBuilder(String.valueOf(object4).length() + 134).append("Google Analytics ").append((String)object4).append(" is starting up. To enable debug logging on a device run:\n  adb shell setprop log.tag.GAv4 DEBUG\n  adb logcat -s GAv4").toString());
        object3 = object.zzq(this);
        object3.initialize();
        this.db = object3;
        object3 = object.zze(this);
        object3.initialize();
        this.da = object3;
        object3 = object.zzl(this);
        object4 = object.zzd(this);
        zza zza2 = object.zzc(this);
        zzk zzk2 = object.zzb(this);
        zzu zzu2 = object.zza(this);
        object2 = object.zzax((Context)object2);
        object2.zza(this.zzack());
        this.cX = object2;
        object2 = object.zzi(this);
        object4.initialize();
        this.dd = object4;
        zza2.initialize();
        this.de = zza2;
        zzk2.initialize();
        this.df = zzk2;
        zzu2.initialize();
        this.dg = zzu2;
        object = object.zzp(this);
        object.initialize();
        this.cZ = object;
        object3.initialize();
        this.cY = object3;
        this.zzacb();
        object2.initialize();
        this.dc = object2;
        object3.start();
    }

    private void zza(zzd zzd2) {
        zzaa.zzb(zzd2, (Object)"Analytics service not created/initialized");
        zzaa.zzb(zzd2.isInitialized(), (Object)"Analytics service not initialized");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static zzf zzaw(Context object) {
        zzaa.zzy(object);
        if (cT == null) {
            synchronized (zzf.class) {
                if (cT == null) {
                    com.google.android.gms.common.util.zze zze2 = zzh.zzayl();
                    long l = zze2.elapsedRealtime();
                    cT = object = new zzf(new zzg((Context)object));
                    GoogleAnalytics.zzzd();
                    l = zze2.elapsedRealtime() - l;
                    long l2 = zzy.fb.get();
                    if (l > l2) {
                        object.zzaca().zzc("Slow initialization (ms)", l, l2);
                    }
                }
            }
        }
        return cT;
    }

    public Context getContext() {
        return this.mContext;
    }

    public com.google.android.gms.common.util.zze zzabz() {
        return this.zzaql;
    }

    public zzaf zzaca() {
        this.zza(this.cW);
        return this.cW;
    }

    public zzr zzacb() {
        return this.cV;
    }

    public zzi zzacc() {
        zzaa.zzy(this.cX);
        return this.cX;
    }

    public zzv zzacd() {
        this.zza(this.cZ);
        return this.cZ;
    }

    public zzai zzace() {
        this.zza(this.db);
        return this.db;
    }

    public zzk zzach() {
        this.zza(this.df);
        return this.df;
    }

    public zzu zzaci() {
        return this.dg;
    }

    protected Thread.UncaughtExceptionHandler zzack() {
        return new Thread.UncaughtExceptionHandler(){

            @Override
            public void uncaughtException(Thread object, Throwable throwable) {
                object = zzf.this.zzacm();
                if (object != null) {
                    object.zze("Job execution failed", throwable);
                }
            }
        };
    }

    public Context zzacl() {
        return this.cU;
    }

    public zzaf zzacm() {
        return this.cW;
    }

    public GoogleAnalytics zzacn() {
        zzaa.zzy(this.dc);
        zzaa.zzb(this.dc.isInitialized(), (Object)"Analytics instance not initialized");
        return this.dc;
    }

    public zzai zzaco() {
        if (this.db == null || !this.db.isInitialized()) {
            return null;
        }
        return this.db;
    }

    public zza zzacp() {
        this.zza(this.de);
        return this.de;
    }

    public zzn zzacq() {
        this.zza(this.dd);
        return this.dd;
    }

    public zzb zzzg() {
        this.zza(this.cY);
        return this.cY;
    }

    public zzap zzzh() {
        this.zza(this.da);
        return this.da;
    }

    public void zzzx() {
        zzi.zzzx();
    }

}

