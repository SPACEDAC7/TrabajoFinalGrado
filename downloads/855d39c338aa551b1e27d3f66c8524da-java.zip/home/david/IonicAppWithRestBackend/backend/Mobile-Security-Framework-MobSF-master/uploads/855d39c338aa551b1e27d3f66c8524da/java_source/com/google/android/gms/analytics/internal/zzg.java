/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.google.android.gms.analytics.internal;

import android.content.Context;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.internal.zza;
import com.google.android.gms.analytics.internal.zzaf;
import com.google.android.gms.analytics.internal.zzag;
import com.google.android.gms.analytics.internal.zzah;
import com.google.android.gms.analytics.internal.zzai;
import com.google.android.gms.analytics.internal.zzap;
import com.google.android.gms.analytics.internal.zzb;
import com.google.android.gms.analytics.internal.zzf;
import com.google.android.gms.analytics.internal.zzi;
import com.google.android.gms.analytics.internal.zzj;
import com.google.android.gms.analytics.internal.zzk;
import com.google.android.gms.analytics.internal.zzl;
import com.google.android.gms.analytics.internal.zzn;
import com.google.android.gms.analytics.internal.zzr;
import com.google.android.gms.analytics.internal.zzu;
import com.google.android.gms.analytics.internal.zzv;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.util.zze;
import com.google.android.gms.common.util.zzh;

public class zzg {
    private final Context di;
    private final Context zzatc;

    public zzg(Context context) {
        zzaa.zzy(context);
        context = context.getApplicationContext();
        zzaa.zzb(context, (Object)"Application context can't be null");
        this.zzatc = context;
        this.di = context;
    }

    public Context getApplicationContext() {
        return this.zzatc;
    }

    protected zzu zza(zzf zzf2) {
        return new zzu(zzf2);
    }

    public Context zzacl() {
        return this.di;
    }

    protected com.google.android.gms.analytics.zzi zzax(Context context) {
        return com.google.android.gms.analytics.zzi.zzav(context);
    }

    protected zzk zzb(zzf zzf2) {
        return new zzk(zzf2);
    }

    protected zza zzc(zzf zzf2) {
        return new zza(zzf2);
    }

    protected zzn zzd(zzf zzf2) {
        return new zzn(zzf2);
    }

    protected zzap zze(zzf zzf2) {
        return new zzap(zzf2);
    }

    protected zzaf zzf(zzf zzf2) {
        return new zzaf(zzf2);
    }

    protected zzr zzg(zzf zzf2) {
        return new zzr(zzf2);
    }

    protected zze zzh(zzf zzf2) {
        return zzh.zzayl();
    }

    protected GoogleAnalytics zzi(zzf zzf2) {
        return new GoogleAnalytics(zzf2);
    }

    zzl zzj(zzf zzf2) {
        return new zzl(zzf2, this);
    }

    zzag zzk(zzf zzf2) {
        return new zzag(zzf2);
    }

    protected zzb zzl(zzf zzf2) {
        return new zzb(zzf2, this);
    }

    public zzj zzm(zzf zzf2) {
        return new zzj(zzf2);
    }

    public zzah zzn(zzf zzf2) {
        return new zzah(zzf2);
    }

    public zzi zzo(zzf zzf2) {
        return new zzi(zzf2);
    }

    public zzv zzp(zzf zzf2) {
        return new zzv(zzf2);
    }

    public zzai zzq(zzf zzf2) {
        return new zzai(zzf2);
    }
}

