/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.internal;

import com.google.android.gms.common.internal.zzaa;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class zzh {
    private final String cj;
    private final long dj;
    private final String dk;
    private final boolean dl;
    private long dm;
    private final Map<String, String> zzbly;

    public zzh(long l, String string2, String string3, boolean bl, long l2, Map<String, String> map) {
        zzaa.zzib(string2);
        zzaa.zzib(string3);
        this.dj = l;
        this.cj = string2;
        this.dk = string3;
        this.dl = bl;
        this.dm = l2;
        if (map != null) {
            this.zzbly = new HashMap<String, String>(map);
            return;
        }
        this.zzbly = Collections.emptyMap();
    }

    public long zzacr() {
        return this.dj;
    }

    public String zzacs() {
        return this.dk;
    }

    public boolean zzact() {
        return this.dl;
    }

    public long zzacu() {
        return this.dm;
    }

    public Map<String, String> zzmc() {
        return this.zzbly;
    }

    public void zzr(long l) {
        this.dm = l;
    }

    public String zzze() {
        return this.cj;
    }
}

