/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.internal;

public final class zzm
extends Enum<zzm> {
    public static final /* enum */ zzm dN = new zzm();
    public static final /* enum */ zzm dO = new zzm();
    public static final /* enum */ zzm dP = new zzm();
    public static final /* enum */ zzm dQ = new zzm();
    public static final /* enum */ zzm dR = new zzm();
    public static final /* enum */ zzm dS = new zzm();
    private static final /* synthetic */ zzm[] dT;

    static {
        dT = new zzm[]{dN, dO, dP, dQ, dR, dS};
    }

    private zzm() {
        super(string2, n);
    }

    public static zzm[] values() {
        return (zzm[])dT.clone();
    }

    public static zzm zzfb(String string2) {
        if ("BATCH_BY_SESSION".equalsIgnoreCase(string2)) {
            return dO;
        }
        if ("BATCH_BY_TIME".equalsIgnoreCase(string2)) {
            return dP;
        }
        if ("BATCH_BY_BRUTE_FORCE".equalsIgnoreCase(string2)) {
            return dQ;
        }
        if ("BATCH_BY_COUNT".equalsIgnoreCase(string2)) {
            return dR;
        }
        if ("BATCH_BY_SIZE".equalsIgnoreCase(string2)) {
            return dS;
        }
        return dN;
    }
}

