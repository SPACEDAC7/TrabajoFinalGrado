/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.internal;

public final class zzo
extends Enum<zzo> {
    public static final /* enum */ zzo dX = new zzo();
    public static final /* enum */ zzo dY = new zzo();
    private static final /* synthetic */ zzo[] dZ;

    static {
        dZ = new zzo[]{dX, dY};
    }

    private zzo() {
        super(string2, n);
    }

    public static zzo[] values() {
        return (zzo[])dZ.clone();
    }

    public static zzo zzfc(String string2) {
        if ("GZIP".equalsIgnoreCase(string2)) {
            return dY;
        }
        return dX;
    }
}

