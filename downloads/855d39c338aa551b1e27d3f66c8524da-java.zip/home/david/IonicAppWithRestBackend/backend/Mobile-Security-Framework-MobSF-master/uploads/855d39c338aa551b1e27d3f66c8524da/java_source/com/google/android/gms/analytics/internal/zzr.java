/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.text.TextUtils
 */
package com.google.android.gms.analytics.internal;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.text.TextUtils;
import com.google.android.gms.analytics.internal.zzaf;
import com.google.android.gms.analytics.internal.zzf;
import com.google.android.gms.analytics.internal.zzm;
import com.google.android.gms.analytics.internal.zzo;
import com.google.android.gms.analytics.internal.zzy;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.util.zzt;
import java.util.HashSet;
import java.util.Set;

public class zzr {
    private final zzf ao;
    private volatile Boolean eb;
    private String ec;
    private Set<Integer> ed;

    protected zzr(zzf zzf2) {
        zzaa.zzy(zzf2);
        this.ao = zzf2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean zzaef() {
        if (this.eb == null) {
            synchronized (this) {
                if (this.eb == null) {
                    Object object = this.ao.getContext().getApplicationInfo();
                    String string2 = zzt.zzayz();
                    if (object != null) {
                        object = object.processName;
                        boolean bl = object != null && object.equals(string2);
                        this.eb = bl;
                    }
                    if ((this.eb == null || !this.eb.booleanValue()) && "com.google.android.gms.analytics".equals(string2)) {
                        this.eb = Boolean.TRUE;
                    }
                    if (this.eb == null) {
                        this.eb = Boolean.TRUE;
                        this.ao.zzaca().zzew("My process not in the list of running processes");
                    }
                }
            }
        }
        return this.eb;
    }

    public boolean zzaeg() {
        return zzy.em.get();
    }

    public int zzaeh() {
        return zzy.eF.get();
    }

    public int zzaei() {
        return zzy.eJ.get();
    }

    public int zzaej() {
        return zzy.eK.get();
    }

    public int zzaek() {
        return zzy.eL.get();
    }

    public long zzael() {
        return zzy.eu.get();
    }

    public long zzaem() {
        return zzy.et.get();
    }

    public long zzaen() {
        return zzy.ex.get();
    }

    public long zzaeo() {
        return zzy.ey.get();
    }

    public int zzaep() {
        return zzy.ez.get();
    }

    public int zzaeq() {
        return zzy.eA.get();
    }

    public long zzaer() {
        return zzy.eN.get().intValue();
    }

    public String zzaes() {
        return zzy.eC.get();
    }

    public String zzaet() {
        return zzy.eB.get();
    }

    public String zzaeu() {
        return zzy.eD.get();
    }

    public String zzaev() {
        return zzy.eE.get();
    }

    public zzm zzaew() {
        return zzm.zzfb(zzy.eG.get());
    }

    public zzo zzaex() {
        return zzo.zzfc(zzy.eH.get());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public Set<Integer> zzaey() {
        String string2 = zzy.eM.get();
        if (this.ed != null && this.ec != null) {
            if (this.ec.equals(string2)) return this.ed;
        }
        String[] arrstring = TextUtils.split((String)string2, (String)",");
        HashSet<Integer> hashSet = new HashSet<Integer>();
        int n = arrstring.length;
        int n2 = 0;
        do {
            if (n2 >= n) {
                this.ec = string2;
                this.ed = hashSet;
                return this.ed;
            }
            String string3 = arrstring[n2];
            try {
                hashSet.add(Integer.parseInt(string3));
            }
            catch (NumberFormatException numberFormatException) {}
            ++n2;
        } while (true);
    }

    public long zzaez() {
        return zzy.eV.get();
    }

    public long zzafa() {
        return zzy.eW.get();
    }

    public long zzafb() {
        return zzy.eZ.get();
    }

    public int zzafc() {
        return zzy.eq.get();
    }

    public int zzafd() {
        return zzy.es.get();
    }

    public String zzafe() {
        return "google_analytics_v4.db";
    }

    public String zzaff() {
        return "google_analytics2_v4.db";
    }

    public int zzafg() {
        return zzy.eP.get();
    }

    public int zzafh() {
        return zzy.eQ.get();
    }

    public long zzafi() {
        return zzy.eR.get();
    }

    public long zzafj() {
        return zzy.fa.get();
    }
}

