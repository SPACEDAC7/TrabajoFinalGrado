/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 *  android.os.Looper
 */
package com.google.android.gms.analytics.internal;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.analytics.internal.zzaf;
import com.google.android.gms.analytics.internal.zzf;
import com.google.android.gms.analytics.zzi;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.util.zze;

abstract class zzt {
    private static volatile Handler ef;
    private final zzf cQ;
    private volatile long eg;
    private final Runnable zzw;

    zzt(zzf zzf2) {
        zzaa.zzy(zzf2);
        this.cQ = zzf2;
        this.zzw = new Runnable(){

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public void run() {
                if (Looper.myLooper() == Looper.getMainLooper()) {
                    zzt.this.cQ.zzacc().zzg(this);
                    return;
                } else {
                    boolean bl = zzt.this.zzfy();
                    zzt.this.eg = 0;
                    if (!bl || zzt.zzb(zzt.this)) return;
                    {
                        zzt.this.run();
                        return;
                    }
                }
            }
        };
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Handler getHandler() {
        if (ef != null) {
            return ef;
        }
        synchronized (zzt.class) {
            if (ef != null) return ef;
            ef = new Handler(this.cQ.getContext().getMainLooper());
            return ef;
        }
    }

    static /* synthetic */ boolean zzb(zzt zzt2) {
        return false;
    }

    public void cancel() {
        this.eg = 0;
        this.getHandler().removeCallbacks(this.zzw);
    }

    public abstract void run();

    public long zzafk() {
        if (this.eg == 0) {
            return 0;
        }
        return Math.abs(this.cQ.zzabz().currentTimeMillis() - this.eg);
    }

    public boolean zzfy() {
        if (this.eg != 0) {
            return true;
        }
        return false;
    }

    public void zzx(long l) {
        this.cancel();
        if (l >= 0) {
            this.eg = this.cQ.zzabz().currentTimeMillis();
            if (!this.getHandler().postDelayed(this.zzw, l)) {
                this.cQ.zzaca().zze("Failed to schedule delayed post. time", l);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void zzy(long l) {
        long l2 = 0;
        if (!this.zzfy()) {
            return;
        }
        if (l < 0) {
            this.cancel();
            return;
        }
        if ((l -= Math.abs(this.cQ.zzabz().currentTimeMillis() - this.eg)) < 0) {
            l = l2;
        }
        this.getHandler().removeCallbacks(this.zzw);
        if (this.getHandler().postDelayed(this.zzw, l)) return;
        this.cQ.zzaca().zze("Failed to adjust delayed post. time", l);
    }

}

