/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.internal;

public interface zzw {
    public void zzf(Throwable var1);
}

