/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package com.google.android.gms.analytics.internal;

import android.os.Build;
import com.google.android.gms.analytics.internal.zzae;
import java.io.File;

public class zzx {
    public static int version() {
        try {
            int n = Integer.parseInt(Build.VERSION.SDK);
            return n;
        }
        catch (NumberFormatException var1_1) {
            zzae.zzf("Invalid version number", Build.VERSION.SDK);
            return 0;
        }
    }

    public static boolean zzfd(String object) {
        if (zzx.version() < 9) {
            return false;
        }
        object = new File((String)object);
        object.setReadable(false, false);
        object.setWritable(false, false);
        object.setReadable(true, true);
        object.setWritable(true, true);
        return true;
    }
}

