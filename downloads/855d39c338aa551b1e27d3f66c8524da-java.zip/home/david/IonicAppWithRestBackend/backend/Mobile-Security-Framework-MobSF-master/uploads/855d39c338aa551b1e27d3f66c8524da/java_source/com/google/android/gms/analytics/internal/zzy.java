/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics.internal;

import com.google.android.gms.analytics.internal.zzm;
import com.google.android.gms.analytics.internal.zzo;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzsi;

public final class zzy {
    public static zza<Integer> eA;
    public static zza<String> eB;
    public static zza<String> eC;
    public static zza<String> eD;
    public static zza<String> eE;
    public static zza<Integer> eF;
    public static zza<String> eG;
    public static zza<String> eH;
    public static zza<Integer> eI;
    public static zza<Integer> eJ;
    public static zza<Integer> eK;
    public static zza<Integer> eL;
    public static zza<String> eM;
    public static zza<Integer> eN;
    public static zza<Long> eO;
    public static zza<Integer> eP;
    public static zza<Integer> eQ;
    public static zza<Long> eR;
    public static zza<String> eS;
    public static zza<Integer> eT;
    public static zza<Boolean> eU;
    public static zza<Long> eV;
    public static zza<Long> eW;
    public static zza<Long> eX;
    public static zza<Long> eY;
    public static zza<Long> eZ;
    public static zza<Boolean> el;
    public static zza<Boolean> em;
    public static zza<String> en;
    public static zza<Long> eo;
    public static zza<Float> ep;
    public static zza<Integer> eq;
    public static zza<Integer> er;
    public static zza<Integer> es;
    public static zza<Long> et;
    public static zza<Long> eu;
    public static zza<Long> ev;
    public static zza<Long> ew;
    public static zza<Long> ex;
    public static zza<Long> ey;
    public static zza<Integer> ez;
    public static zza<Long> fa;
    public static zza<Long> fb;

    static {
        el = zza.zzf("analytics.service_enabled", false);
        em = zza.zzf("analytics.service_client_enabled", true);
        en = zza.zzd("analytics.log_tag", "GAv4", "GAv4-SVC");
        eo = zza.zzb("analytics.max_tokens", 60);
        ep = zza.zza("analytics.tokens_per_sec", 0.5f);
        eq = zza.zza("analytics.max_stored_hits", 2000, 20000);
        er = zza.zze("analytics.max_stored_hits_per_app", 2000);
        es = zza.zze("analytics.max_stored_properties_per_app", 100);
        et = zza.zza("analytics.local_dispatch_millis", 1800000, 120000);
        eu = zza.zza("analytics.initial_local_dispatch_millis", 5000, 5000);
        ev = zza.zzb("analytics.min_local_dispatch_millis", 120000);
        ew = zza.zzb("analytics.max_local_dispatch_millis", 7200000);
        ex = zza.zzb("analytics.dispatch_alarm_millis", 7200000);
        ey = zza.zzb("analytics.max_dispatch_alarm_millis", 32400000);
        ez = zza.zze("analytics.max_hits_per_dispatch", 20);
        eA = zza.zze("analytics.max_hits_per_batch", 20);
        eB = zza.zzq("analytics.insecure_host", "http://www.google-analytics.com");
        eC = zza.zzq("analytics.secure_host", "https://ssl.google-analytics.com");
        eD = zza.zzq("analytics.simple_endpoint", "/collect");
        eE = zza.zzq("analytics.batching_endpoint", "/batch");
        eF = zza.zze("analytics.max_get_length", 2036);
        eG = zza.zzd("analytics.batching_strategy.k", zzm.dR.name(), zzm.dR.name());
        eH = zza.zzq("analytics.compression_strategy.k", zzo.dY.name());
        eI = zza.zze("analytics.max_hits_per_request.k", 20);
        eJ = zza.zze("analytics.max_hit_length.k", 8192);
        eK = zza.zze("analytics.max_post_length.k", 8192);
        eL = zza.zze("analytics.max_batch_post_length", 8192);
        eM = zza.zzq("analytics.fallback_responses.k", "404,502");
        eN = zza.zze("analytics.batch_retry_interval.seconds.k", 3600);
        eO = zza.zzb("analytics.service_monitor_interval", 86400000);
        eP = zza.zze("analytics.http_connection.connect_timeout_millis", 60000);
        eQ = zza.zze("analytics.http_connection.read_timeout_millis", 61000);
        eR = zza.zzb("analytics.campaigns.time_limit", 86400000);
        eS = zza.zzq("analytics.first_party_experiment_id", "");
        eT = zza.zze("analytics.first_party_experiment_variant", 0);
        eU = zza.zzf("analytics.test.disable_receiver", false);
        eV = zza.zza("analytics.service_client.idle_disconnect_millis", 10000, 10000);
        eW = zza.zzb("analytics.service_client.connect_timeout_millis", 5000);
        eX = zza.zzb("analytics.service_client.second_connect_delay_millis", 5000);
        eY = zza.zzb("analytics.service_client.unexpected_reconnect_millis", 60000);
        eZ = zza.zzb("analytics.service_client.reconnect_throttle_millis", 1800000);
        fa = zza.zzb("analytics.monitoring.sample_period_millis", 86400000);
        fb = zza.zzb("analytics.initialization_warning_threshold", 5000);
    }

    public static final class zza<V> {
        private final V fc;
        private final zzsi<V> fd;

        private zza(zzsi<V> zzsi2, V v) {
            zzaa.zzy(zzsi2);
            this.fd = zzsi2;
            this.fc = v;
        }

        static zza<Float> zza(String string2, float f) {
            return zza.zza(string2, f, f);
        }

        static zza<Float> zza(String string2, float f, float f2) {
            return new zza<Float>(zzsi.zza(string2, Float.valueOf(f2)), Float.valueOf(f));
        }

        static zza<Integer> zza(String string2, int n, int n2) {
            return new zza<Integer>(zzsi.zza(string2, n2), n);
        }

        static zza<Long> zza(String string2, long l, long l2) {
            return new zza<Long>(zzsi.zza(string2, l2), l);
        }

        static zza<Boolean> zza(String string2, boolean bl, boolean bl2) {
            return new zza<Boolean>(zzsi.zzk(string2, bl2), bl);
        }

        static zza<Long> zzb(String string2, long l) {
            return zza.zza(string2, l, l);
        }

        static zza<String> zzd(String string2, String string3, String string4) {
            return new zza<String>(zzsi.zzaa(string2, string4), string3);
        }

        static zza<Integer> zze(String string2, int n) {
            return zza.zza(string2, n, n);
        }

        static zza<Boolean> zzf(String string2, boolean bl) {
            return zza.zza(string2, bl, bl);
        }

        static zza<String> zzq(String string2, String string3) {
            return zza.zzd(string2, string3, string3);
        }

        public V get() {
            return this.fc;
        }
    }

}

