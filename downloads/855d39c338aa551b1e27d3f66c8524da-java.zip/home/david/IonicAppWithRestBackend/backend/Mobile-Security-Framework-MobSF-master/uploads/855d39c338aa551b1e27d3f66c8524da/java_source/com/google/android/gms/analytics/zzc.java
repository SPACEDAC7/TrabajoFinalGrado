/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics;

import com.google.android.gms.analytics.internal.zzae;

public final class zzc {
    public static String zzbl(int n) {
        return zzc.zzc("&cd", n);
    }

    public static String zzbm(int n) {
        return zzc.zzc("cd", n);
    }

    public static String zzbn(int n) {
        return zzc.zzc("&cm", n);
    }

    public static String zzbo(int n) {
        return zzc.zzc("cm", n);
    }

    public static String zzbp(int n) {
        return zzc.zzc("&pr", n);
    }

    public static String zzbq(int n) {
        return zzc.zzc("pr", n);
    }

    public static String zzbr(int n) {
        return zzc.zzc("&promo", n);
    }

    public static String zzbs(int n) {
        return zzc.zzc("promo", n);
    }

    public static String zzbt(int n) {
        return zzc.zzc("pi", n);
    }

    public static String zzbu(int n) {
        return zzc.zzc("&il", n);
    }

    public static String zzbv(int n) {
        return zzc.zzc("il", n);
    }

    public static String zzbw(int n) {
        return zzc.zzc("cd", n);
    }

    public static String zzbx(int n) {
        return zzc.zzc("cm", n);
    }

    private static String zzc(String string2, int n) {
        if (n < 1) {
            zzae.zzf("index out of range for prefix", string2);
            return "";
        }
        return new StringBuilder(String.valueOf(string2).length() + 11).append(string2).append(n).toString();
    }
}

