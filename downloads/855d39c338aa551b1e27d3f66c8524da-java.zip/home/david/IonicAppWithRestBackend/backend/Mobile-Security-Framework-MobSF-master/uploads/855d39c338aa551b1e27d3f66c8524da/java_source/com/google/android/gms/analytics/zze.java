/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics;

import com.google.android.gms.analytics.zzg;
import com.google.android.gms.analytics.zzh;
import com.google.android.gms.analytics.zzi;
import com.google.android.gms.analytics.zzk;
import com.google.android.gms.common.internal.zzaa;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class zze {
    private final zzh aW;
    private boolean aX;
    private long aY;
    private long aZ;
    private long ba;
    private long bb;
    private long bc;
    private boolean bd;
    private final Map<Class<? extends zzg>, zzg> be;
    private final List<zzk> bf;
    private final com.google.android.gms.common.util.zze zzaql;

    zze(zze object) {
        this.aW = object.aW;
        this.zzaql = object.zzaql;
        this.aY = object.aY;
        this.aZ = object.aZ;
        this.ba = object.ba;
        this.bb = object.bb;
        this.bc = object.bc;
        this.bf = new ArrayList<zzk>(object.bf);
        this.be = new HashMap<Class<? extends zzg>, zzg>(object.be.size());
        for (Map.Entry<Class<? extends zzg>, zzg> entry : object.be.entrySet()) {
            zzg t = zze.zzc(entry.getKey());
            entry.getValue().zzb(t);
            this.be.put(entry.getKey(), t);
        }
    }

    zze(zzh zzh2, com.google.android.gms.common.util.zze zze2) {
        zzaa.zzy(zzh2);
        zzaa.zzy(zze2);
        this.aW = zzh2;
        this.zzaql = zze2;
        this.bb = 1800000;
        this.bc = 3024000000L;
        this.be = new HashMap<Class<? extends zzg>, zzg>();
        this.bf = new ArrayList<zzk>();
    }

    private static <T extends zzg> T zzc(Class<T> object) {
        try {
            object = (zzg)object.newInstance();
        }
        catch (InstantiationException var0_1) {
            throw new IllegalArgumentException("dataType doesn't have default constructor", var0_1);
        }
        catch (IllegalAccessException var0_2) {
            throw new IllegalArgumentException("dataType default constructor is not accessible", var0_2);
        }
        return (T)object;
    }

    public <T extends zzg> T zza(Class<T> class_) {
        return (T)this.be.get(class_);
    }

    public void zza(zzg zzg2) {
        zzaa.zzy(zzg2);
        Class class_ = zzg2.getClass();
        if (class_.getSuperclass() != zzg.class) {
            throw new IllegalArgumentException();
        }
        zzg2.zzb(this.zzb(class_));
    }

    public <T extends zzg> T zzb(Class<T> class_) {
        zzg zzg2;
        zzg zzg3 = zzg2 = this.be.get(class_);
        if (zzg2 == null) {
            zzg3 = zze.zzc(class_);
            this.be.put(class_, zzg3);
        }
        return (T)zzg3;
    }

    public void zzp(long l) {
        this.aZ = l;
    }

    public zze zzzi() {
        return new zze(this);
    }

    public Collection<zzg> zzzj() {
        return this.be.values();
    }

    public List<zzk> zzzk() {
        return this.bf;
    }

    public long zzzl() {
        return this.aY;
    }

    public void zzzm() {
        this.zzzq().zze(this);
    }

    public boolean zzzn() {
        return this.aX;
    }

    /*
     * Enabled aggressive block sorting
     */
    void zzzo() {
        this.ba = this.zzaql.elapsedRealtime();
        this.aY = this.aZ != 0 ? this.aZ : this.zzaql.currentTimeMillis();
        this.aX = true;
    }

    zzh zzzp() {
        return this.aW;
    }

    zzi zzzq() {
        return this.aW.zzzq();
    }

    boolean zzzr() {
        return this.bd;
    }

    void zzzs() {
        this.bd = true;
    }
}

