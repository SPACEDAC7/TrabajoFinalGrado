/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics;

import com.google.android.gms.analytics.zze;
import com.google.android.gms.analytics.zzh;

public interface zzf {
    public void zza(zzh var1, zze var2);
}

