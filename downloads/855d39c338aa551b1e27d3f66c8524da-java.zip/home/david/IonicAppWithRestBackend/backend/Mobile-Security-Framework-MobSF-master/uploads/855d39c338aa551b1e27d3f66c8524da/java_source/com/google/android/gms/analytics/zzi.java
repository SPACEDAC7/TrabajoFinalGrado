/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.os.Process
 *  android.text.TextUtils
 *  android.util.DisplayMetrics
 *  android.util.Log
 */
package com.google.android.gms.analytics;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Process;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import com.google.android.gms.analytics.internal.zzao;
import com.google.android.gms.analytics.zzd;
import com.google.android.gms.analytics.zze;
import com.google.android.gms.analytics.zzh;
import com.google.android.gms.analytics.zzj;
import com.google.android.gms.analytics.zzk;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzms;
import com.google.android.gms.internal.zzmx;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public final class zzi {
    private static volatile zzi bj;
    private final List<zzj> bk;
    private final zzd bl;
    private final zza bm;
    private volatile zzms bn;
    private Thread.UncaughtExceptionHandler bo;
    private final Context mContext;

    zzi(Context context) {
        context = context.getApplicationContext();
        zzaa.zzy(context);
        this.mContext = context;
        this.bm = new zza();
        this.bk = new CopyOnWriteArrayList<zzj>();
        this.bl = new zzd();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static zzi zzav(Context context) {
        zzaa.zzy(context);
        if (bj == null) {
            synchronized (zzi.class) {
                if (bj == null) {
                    bj = new zzi(context);
                }
            }
        }
        return bj;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zzb(zze zze2) {
        zzaa.zzht("deliver should be called from worker thread");
        zzaa.zzb(zze2.zzzn(), (Object)"Measurement must be submitted");
        Object object = zze2.zzzk();
        if (!object.isEmpty()) {
            HashSet<Uri> hashSet = new HashSet<Uri>();
            object = object.iterator();
            while (object.hasNext()) {
                zzk zzk2 = (zzk)object.next();
                Uri uri = zzk2.zzyx();
                if (hashSet.contains((Object)uri)) continue;
                hashSet.add(uri);
                zzk2.zzb(zze2);
            }
        }
    }

    public static void zzzx() {
        if (!(Thread.currentThread() instanceof zzc)) {
            throw new IllegalStateException("Call expected from worker thread");
        }
    }

    public Context getContext() {
        return this.mContext;
    }

    public void zza(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
        this.bo = uncaughtExceptionHandler;
    }

    public <V> Future<V> zzc(Callable<V> object) {
        zzaa.zzy(object);
        if (Thread.currentThread() instanceof zzc) {
            object = new FutureTask<V>((Callable<V>)object);
            object.run();
            return object;
        }
        return this.bm.submit(object);
    }

    void zze(final zze zze2) {
        if (zze2.zzzr()) {
            throw new IllegalStateException("Measurement prototype can't be submitted");
        }
        if (zze2.zzzn()) {
            throw new IllegalStateException("Measurement can only be submitted once");
        }
        zze2 = zze2.zzzi();
        zze2.zzzo();
        this.bm.execute(new Runnable(){

            @Override
            public void run() {
                zze2.zzzp().zza(zze2);
                Iterator iterator = zzi.this.bk.iterator();
                while (iterator.hasNext()) {
                    ((zzj)iterator.next()).zza(zze2);
                }
                zzi.this.zzb(zze2);
            }
        });
    }

    public void zzg(Runnable runnable) {
        zzaa.zzy(runnable);
        this.bm.submit(runnable);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public zzms zzzv() {
        if (this.bn == null) {
            synchronized (this) {
                if (this.bn == null) {
                    String string2;
                    CharSequence charSequence;
                    zzms zzms2 = new zzms();
                    PackageManager packageManager = this.mContext.getPackageManager();
                    String string3 = this.mContext.getPackageName();
                    zzms2.setAppId(string3);
                    zzms2.setAppInstallerId(packageManager.getInstallerPackageName(string3));
                    CharSequence charSequence2 = null;
                    String string4 = string3;
                    try {
                        PackageInfo packageInfo = packageManager.getPackageInfo(this.mContext.getPackageName(), 0);
                        charSequence = charSequence2;
                        string2 = string3;
                        if (packageInfo != null) {
                            string4 = string3;
                            charSequence = packageManager.getApplicationLabel(packageInfo.applicationInfo);
                            string2 = string3;
                            string4 = string3;
                            if (!TextUtils.isEmpty((CharSequence)charSequence)) {
                                string4 = string3;
                                string2 = charSequence.toString();
                            }
                            string4 = string2;
                            charSequence = packageInfo.versionName;
                        }
                    }
                    catch (PackageManager.NameNotFoundException var1_9) {
                        string2 = String.valueOf(string4);
                        string2 = string2.length() != 0 ? "Error retrieving package info: appName set to ".concat(string2) : new String("Error retrieving package info: appName set to ");
                        Log.e((String)"GAv4", (String)string2);
                        charSequence = charSequence2;
                        string2 = string4;
                    }
                    zzms2.setAppName(string2);
                    zzms2.setAppVersion((String)charSequence);
                    this.bn = zzms2;
                }
            }
        }
        return this.bn;
    }

    public zzmx zzzw() {
        DisplayMetrics displayMetrics = this.mContext.getResources().getDisplayMetrics();
        zzmx zzmx2 = new zzmx();
        zzmx2.setLanguage(zzao.zza(Locale.getDefault()));
        zzmx2.zzbz(displayMetrics.widthPixels);
        zzmx2.zzca(displayMetrics.heightPixels);
        return zzmx2;
    }

    private class zza
    extends ThreadPoolExecutor {
        public zza() {
            super(1, 1, 1, TimeUnit.MINUTES, new LinkedBlockingQueue<Runnable>());
            this.setThreadFactory(new zzb());
            this.allowCoreThreadTimeOut(true);
        }

        @Override
        protected <T> RunnableFuture<T> newTaskFor(Runnable runnable, T t) {
            return new FutureTask<T>(runnable, t){

                /*
                 * Enabled aggressive block sorting
                 */
                @Override
                protected void setException(Throwable throwable) {
                    Object object = zzi.this.bo;
                    if (object != null) {
                        object.uncaughtException(Thread.currentThread(), throwable);
                    } else if (Log.isLoggable((String)"GAv4", (int)6)) {
                        object = String.valueOf(throwable);
                        Log.e((String)"GAv4", (String)new StringBuilder(String.valueOf(object).length() + 37).append("MeasurementExecutor: job failed with ").append((String)object).toString());
                    }
                    super.setException(throwable);
                }
            };
        }

    }

    private static class zzb
    implements ThreadFactory {
        private static final AtomicInteger bs = new AtomicInteger();

        private zzb() {
        }

        @Override
        public Thread newThread(Runnable runnable) {
            int n = bs.incrementAndGet();
            return new zzc(runnable, new StringBuilder(23).append("measurement-").append(n).toString());
        }
    }

    private static class zzc
    extends Thread {
        zzc(Runnable runnable, String string2) {
            super(runnable, string2);
        }

        @Override
        public void run() {
            Process.setThreadPriority((int)10);
            super.run();
        }
    }

}

