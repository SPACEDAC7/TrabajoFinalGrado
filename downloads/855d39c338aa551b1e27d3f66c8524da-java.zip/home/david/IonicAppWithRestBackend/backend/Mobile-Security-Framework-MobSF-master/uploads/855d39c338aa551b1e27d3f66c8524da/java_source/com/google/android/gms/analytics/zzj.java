/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.analytics;

import com.google.android.gms.analytics.zze;

public interface zzj {
    public void zza(zze var1);
}

