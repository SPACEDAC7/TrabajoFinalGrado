/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.google.android.gms.analytics;

import android.net.Uri;
import com.google.android.gms.analytics.zze;

public interface zzk {
    public void zzb(zze var1);

    public Uri zzyx();
}

