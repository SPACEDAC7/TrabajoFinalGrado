/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.auth;

public class GoogleAuthException
extends Exception {
    public GoogleAuthException() {
    }

    public GoogleAuthException(String string2) {
        super(string2);
    }

    public GoogleAuthException(String string2, Throwable throwable) {
        super(string2, throwable);
    }

    public GoogleAuthException(Throwable throwable) {
        super(throwable);
    }
}

