/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Looper
 */
package com.google.android.gms.auth.account;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.auth.account.WorkAccountApi;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.internal.zzf;
import com.google.android.gms.internal.zznq;
import com.google.android.gms.internal.zznr;

public class WorkAccount {
    public static final Api<Api.ApiOptions.NoOptions> API;
    public static final WorkAccountApi WorkAccountApi;
    private static final Api.zzf<zznr> hg;
    private static final Api.zza<zznr, Api.ApiOptions.NoOptions> hh;

    static {
        hg = new Api.zzf();
        hh = new Api.zza<zznr, Api.ApiOptions.NoOptions>(){

            @Override
            public /* synthetic */ Api.zze zza(Context context, Looper looper, zzf zzf2, Object object, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener) {
                return this.zzc(context, looper, zzf2, (Api.ApiOptions.NoOptions)object, connectionCallbacks, onConnectionFailedListener);
            }

            public zznr zzc(Context context, Looper looper, zzf zzf2, Api.ApiOptions.NoOptions noOptions, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener) {
                return new zznr(context, looper, zzf2, connectionCallbacks, onConnectionFailedListener);
            }
        };
        API = new Api<Api.ApiOptions.NoOptions>("WorkAccount.API", hh, hg);
        WorkAccountApi = new zznq();
    }

    private WorkAccount() {
    }

}

