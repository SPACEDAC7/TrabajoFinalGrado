/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.auth.account;

import android.accounts.Account;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;

public interface zza
extends IInterface {
    public void zzbc(boolean var1) throws RemoteException;

    public void zzd(Account var1) throws RemoteException;

    public static abstract class com.google.android.gms.auth.account.zza$zza
    extends Binder
    implements com.google.android.gms.auth.account.zza {
        public com.google.android.gms.auth.account.zza$zza() {
            this.attachInterface((IInterface)this, "com.google.android.gms.auth.account.IWorkAccountCallback");
        }

        public static com.google.android.gms.auth.account.zza zzby(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.auth.account.IWorkAccountCallback");
            if (iInterface != null && iInterface instanceof com.google.android.gms.auth.account.zza) {
                return (com.google.android.gms.auth.account.zza)iInterface;
            }
            return new zza(iBinder);
        }

        public IBinder asBinder() {
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) throws RemoteException {
            switch (n) {
                default: {
                    return super.onTransact(n, parcel, parcel2, n2);
                }
                case 1598968902: {
                    parcel2.writeString("com.google.android.gms.auth.account.IWorkAccountCallback");
                    return true;
                }
                case 1: {
                    parcel.enforceInterface("com.google.android.gms.auth.account.IWorkAccountCallback");
                    parcel = parcel.readInt() != 0 ? (Account)Account.CREATOR.createFromParcel(parcel) : null;
                    this.zzd((Account)parcel);
                    return true;
                }
                case 2: 
            }
            parcel.enforceInterface("com.google.android.gms.auth.account.IWorkAccountCallback");
            boolean bl = parcel.readInt() != 0;
            this.zzbc(bl);
            return true;
        }

        private static class zza
        implements com.google.android.gms.auth.account.zza {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zzbc(boolean bl) throws RemoteException {
                int n = 1;
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.account.IWorkAccountCallback");
                    if (!bl) {
                        n = 0;
                    }
                    parcel.writeInt(n);
                    this.zzajq.transact(2, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zzd(Account account) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.account.IWorkAccountCallback");
                    if (account != null) {
                        parcel.writeInt(1);
                        account.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(1, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }
        }

    }

}

