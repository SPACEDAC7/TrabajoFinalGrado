/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.text.TextUtils
 */
package com.google.android.gms.auth.api.credentials.internal;

import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.common.internal.zzaa;

public class zzb {
    /*
     * Enabled aggressive block sorting
     */
    public static String zzfx(String string2) {
        boolean bl;
        block2 : {
            boolean bl2 = false;
            bl = !TextUtils.isEmpty((CharSequence)string2);
            zzaa.zzb(bl, (Object)"account type cannot be empty");
            String string3 = Uri.parse((String)string2).getScheme();
            if (!"http".equalsIgnoreCase(string3)) {
                bl = bl2;
                if (!"https".equalsIgnoreCase(string3)) break block2;
            }
            bl = true;
        }
        zzaa.zzb(bl, (Object)"Account type must be an http or https URI");
        return string2;
    }
}

