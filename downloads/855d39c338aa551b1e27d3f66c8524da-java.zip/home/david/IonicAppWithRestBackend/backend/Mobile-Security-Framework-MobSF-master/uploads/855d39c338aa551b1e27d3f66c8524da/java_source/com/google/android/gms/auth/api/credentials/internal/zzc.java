/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Parcelable
 */
package com.google.android.gms.auth.api.credentials.internal;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.HintRequest;
import com.google.android.gms.auth.api.credentials.PasswordSpecification;

public final class zzc {
    public static Intent zza(Context context, HintRequest hintRequest, PasswordSpecification passwordSpecification) {
        return new Intent("com.google.android.gms.auth.api.credentials.PICKER").putExtra("com.google.android.gms.credentials.RequestType", "Hints").putExtra("com.google.android.gms.credentials.HintRequest", (Parcelable)hintRequest).putExtra("com.google.android.gms.credentials.PasswordSpecification", (Parcelable)passwordSpecification);
    }
}

