/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.credentials.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.auth.api.credentials.internal.DeleteRequest;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzh
implements Parcelable.Creator<DeleteRequest> {
    static void zza(DeleteRequest deleteRequest, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zza(parcel, 1, deleteRequest.getCredential(), n, false);
        zzb.zzc(parcel, 1000, deleteRequest.mVersionCode);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzap(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzdd(n);
    }

    public DeleteRequest zzap(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        Credential credential = null;
        block4 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block4;
                }
                case 1: {
                    credential = zza.zza(parcel, n3, Credential.CREATOR);
                    continue block4;
                }
                case 1000: 
            }
            n2 = zza.zzg(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new DeleteRequest(n2, credential);
    }

    public DeleteRequest[] zzdd(int n) {
        return new DeleteRequest[n];
    }
}

