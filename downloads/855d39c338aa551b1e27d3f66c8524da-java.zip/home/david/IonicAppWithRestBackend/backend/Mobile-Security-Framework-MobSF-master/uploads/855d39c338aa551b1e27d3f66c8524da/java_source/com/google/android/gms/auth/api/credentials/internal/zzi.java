/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.credentials.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.PasswordSpecification;
import com.google.android.gms.auth.api.credentials.internal.GeneratePasswordRequest;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzi
implements Parcelable.Creator<GeneratePasswordRequest> {
    static void zza(GeneratePasswordRequest generatePasswordRequest, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zza(parcel, 1, generatePasswordRequest.zzaid(), n, false);
        zzb.zzc(parcel, 1000, generatePasswordRequest.mVersionCode);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzaq(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzde(n);
    }

    public GeneratePasswordRequest zzaq(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        PasswordSpecification passwordSpecification = null;
        block4 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block4;
                }
                case 1: {
                    passwordSpecification = zza.zza(parcel, n3, PasswordSpecification.CREATOR);
                    continue block4;
                }
                case 1000: 
            }
            n2 = zza.zzg(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new GeneratePasswordRequest(n2, passwordSpecification);
    }

    public GeneratePasswordRequest[] zzde(int n) {
        return new GeneratePasswordRequest[n];
    }
}

