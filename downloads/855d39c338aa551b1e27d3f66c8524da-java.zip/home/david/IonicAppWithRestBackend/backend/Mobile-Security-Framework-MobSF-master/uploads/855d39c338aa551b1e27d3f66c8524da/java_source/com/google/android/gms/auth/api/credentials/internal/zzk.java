/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.auth.api.credentials.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.auth.api.credentials.CredentialRequest;
import com.google.android.gms.auth.api.credentials.internal.DeleteRequest;
import com.google.android.gms.auth.api.credentials.internal.GeneratePasswordRequest;
import com.google.android.gms.auth.api.credentials.internal.SaveRequest;
import com.google.android.gms.auth.api.credentials.internal.zzj;

public interface zzk
extends IInterface {
    public void zza(zzj var1) throws RemoteException;

    public void zza(zzj var1, CredentialRequest var2) throws RemoteException;

    public void zza(zzj var1, DeleteRequest var2) throws RemoteException;

    public void zza(zzj var1, GeneratePasswordRequest var2) throws RemoteException;

    public void zza(zzj var1, SaveRequest var2) throws RemoteException;

    public static abstract class com.google.android.gms.auth.api.credentials.internal.zzk$zza
    extends Binder
    implements zzk {
        public static zzk zzcg(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
            if (iInterface != null && iInterface instanceof zzk) {
                return (zzk)iInterface;
            }
            return new zza(iBinder);
        }

        public boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) throws RemoteException {
            zzj zzj2 = null;
            zzj zzj3 = null;
            Object var8_7 = null;
            Object object = null;
            switch (n) {
                default: {
                    return super.onTransact(n, parcel, parcel2, n2);
                }
                case 1598968902: {
                    parcel2.writeString("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
                    return true;
                }
                case 1: {
                    parcel.enforceInterface("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
                    zzj2 = zzj.zza.zzcf(parcel.readStrongBinder());
                    if (parcel.readInt() != 0) {
                        object = (CredentialRequest)CredentialRequest.CREATOR.createFromParcel(parcel);
                    }
                    this.zza(zzj2, (CredentialRequest)object);
                    parcel2.writeNoException();
                    return true;
                }
                case 2: {
                    parcel.enforceInterface("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
                    zzj3 = zzj.zza.zzcf(parcel.readStrongBinder());
                    object = zzj2;
                    if (parcel.readInt() != 0) {
                        object = (SaveRequest)SaveRequest.CREATOR.createFromParcel(parcel);
                    }
                    this.zza(zzj3, (SaveRequest)object);
                    parcel2.writeNoException();
                    return true;
                }
                case 3: {
                    parcel.enforceInterface("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
                    zzj2 = zzj.zza.zzcf(parcel.readStrongBinder());
                    object = zzj3;
                    if (parcel.readInt() != 0) {
                        object = (DeleteRequest)DeleteRequest.CREATOR.createFromParcel(parcel);
                    }
                    this.zza(zzj2, (DeleteRequest)object);
                    parcel2.writeNoException();
                    return true;
                }
                case 4: {
                    parcel.enforceInterface("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
                    this.zza(zzj.zza.zzcf(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                }
                case 5: 
            }
            parcel.enforceInterface("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
            zzj2 = zzj.zza.zzcf(parcel.readStrongBinder());
            object = var8_7;
            if (parcel.readInt() != 0) {
                object = (GeneratePasswordRequest)GeneratePasswordRequest.CREATOR.createFromParcel(parcel);
            }
            this.zza(zzj2, (GeneratePasswordRequest)object);
            parcel2.writeNoException();
            return true;
        }

        private static class zza
        implements zzk {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzj zzj2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
                    zzj2 = zzj2 != null ? zzj2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzj2);
                    this.zzajq.transact(4, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzj zzj2, CredentialRequest credentialRequest) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
                    zzj2 = zzj2 != null ? zzj2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzj2);
                    if (credentialRequest != null) {
                        parcel.writeInt(1);
                        credentialRequest.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(1, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzj zzj2, DeleteRequest deleteRequest) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
                    zzj2 = zzj2 != null ? zzj2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzj2);
                    if (deleteRequest != null) {
                        parcel.writeInt(1);
                        deleteRequest.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(3, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzj zzj2, GeneratePasswordRequest generatePasswordRequest) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
                    zzj2 = zzj2 != null ? zzj2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzj2);
                    if (generatePasswordRequest != null) {
                        parcel.writeInt(1);
                        generatePasswordRequest.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(5, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzj zzj2, SaveRequest saveRequest) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
                    zzj2 = zzj2 != null ? zzj2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzj2);
                    if (saveRequest != null) {
                        parcel.writeInt(1);
                        saveRequest.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(2, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

