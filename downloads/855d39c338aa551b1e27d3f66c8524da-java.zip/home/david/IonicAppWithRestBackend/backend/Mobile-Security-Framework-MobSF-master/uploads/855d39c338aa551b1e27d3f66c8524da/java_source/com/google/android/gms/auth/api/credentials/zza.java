/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.credentials;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.auth.api.credentials.IdToken;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import java.util.ArrayList;
import java.util.List;

public class zza
implements Parcelable.Creator<Credential> {
    static void zza(Credential credential, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zza(parcel, 1, credential.getId(), false);
        zzb.zza(parcel, 2, credential.getName(), false);
        zzb.zza(parcel, 3, (Parcelable)credential.getProfilePictureUri(), n, false);
        zzb.zzc(parcel, 4, credential.getIdTokens(), false);
        zzb.zza(parcel, 5, credential.getPassword(), false);
        zzb.zza(parcel, 6, credential.getAccountType(), false);
        zzb.zza(parcel, 7, credential.getGeneratedPassword(), false);
        zzb.zzc(parcel, 1000, credential.mVersionCode);
        zzb.zza(parcel, 8, credential.zzaif(), false);
        zzb.zza(parcel, 9, credential.getGivenName(), false);
        zzb.zza(parcel, 10, credential.getFamilyName(), false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzaj(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzcx(n);
    }

    public Credential zzaj(Parcel parcel) {
        String string2 = null;
        int n = com.google.android.gms.common.internal.safeparcel.zza.zzcr(parcel);
        int n2 = 0;
        String string3 = null;
        String string4 = null;
        String string5 = null;
        String string6 = null;
        String string7 = null;
        ArrayList<IdToken> arrayList = null;
        Uri uri = null;
        String string8 = null;
        String string9 = null;
        block13 : while (parcel.dataPosition() < n) {
            int n3 = com.google.android.gms.common.internal.safeparcel.zza.zzcq(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zza.zzgu(n3)) {
                default: {
                    com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, n3);
                    continue block13;
                }
                case 1: {
                    string9 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block13;
                }
                case 2: {
                    string8 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block13;
                }
                case 3: {
                    uri = (Uri)com.google.android.gms.common.internal.safeparcel.zza.zza(parcel, n3, Uri.CREATOR);
                    continue block13;
                }
                case 4: {
                    arrayList = com.google.android.gms.common.internal.safeparcel.zza.zzc(parcel, n3, IdToken.CREATOR);
                    continue block13;
                }
                case 5: {
                    string7 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block13;
                }
                case 6: {
                    string6 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block13;
                }
                case 7: {
                    string5 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block13;
                }
                case 1000: {
                    n2 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n3);
                    continue block13;
                }
                case 8: {
                    string4 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block13;
                }
                case 9: {
                    string3 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block13;
                }
                case 10: 
            }
            string2 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new Credential(n2, string9, string8, uri, arrayList, string7, string6, string5, string4, string3, string2);
    }

    public Credential[] zzcx(int n) {
        return new Credential[n];
    }
}

