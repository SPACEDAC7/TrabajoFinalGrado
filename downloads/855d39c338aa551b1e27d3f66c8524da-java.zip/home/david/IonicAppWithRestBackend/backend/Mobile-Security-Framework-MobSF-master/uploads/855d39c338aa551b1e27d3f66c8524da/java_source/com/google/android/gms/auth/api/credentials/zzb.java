/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.credentials;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.CredentialPickerConfig;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zzb
implements Parcelable.Creator<CredentialPickerConfig> {
    static void zza(CredentialPickerConfig credentialPickerConfig, Parcel parcel, int n) {
        n = com.google.android.gms.common.internal.safeparcel.zzb.zzcs(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 1, credentialPickerConfig.shouldShowAddAccountButton());
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 2, credentialPickerConfig.shouldShowCancelButton());
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 3, credentialPickerConfig.isForNewAccount());
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 4, credentialPickerConfig.zzaig());
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1000, credentialPickerConfig.mVersionCode);
        com.google.android.gms.common.internal.safeparcel.zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzak(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzcy(n);
    }

    public CredentialPickerConfig zzak(Parcel parcel) {
        int n = 0;
        int n2 = zza.zzcr(parcel);
        boolean bl = false;
        boolean bl2 = false;
        boolean bl3 = false;
        int n3 = 0;
        block7 : while (parcel.dataPosition() < n2) {
            int n4 = zza.zzcq(parcel);
            switch (zza.zzgu(n4)) {
                default: {
                    zza.zzb(parcel, n4);
                    continue block7;
                }
                case 1: {
                    bl3 = zza.zzc(parcel, n4);
                    continue block7;
                }
                case 2: {
                    bl2 = zza.zzc(parcel, n4);
                    continue block7;
                }
                case 3: {
                    bl = zza.zzc(parcel, n4);
                    continue block7;
                }
                case 4: {
                    n = zza.zzg(parcel, n4);
                    continue block7;
                }
                case 1000: 
            }
            n3 = zza.zzg(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new CredentialPickerConfig(n3, bl3, bl2, bl, n);
    }

    public CredentialPickerConfig[] zzcy(int n) {
        return new CredentialPickerConfig[n];
    }
}

