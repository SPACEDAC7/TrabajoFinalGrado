/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.credentials;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.CredentialPickerConfig;
import com.google.android.gms.auth.api.credentials.CredentialRequest;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzc
implements Parcelable.Creator<CredentialRequest> {
    static void zza(CredentialRequest credentialRequest, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zza(parcel, 1, credentialRequest.isPasswordLoginSupported());
        zzb.zza(parcel, 2, credentialRequest.getAccountTypes(), false);
        zzb.zza(parcel, 3, credentialRequest.getCredentialPickerConfig(), n, false);
        zzb.zza(parcel, 4, credentialRequest.getCredentialHintPickerConfig(), n, false);
        zzb.zzc(parcel, 1000, credentialRequest.mVersionCode);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzal(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzcz(n);
    }

    public CredentialRequest zzal(Parcel parcel) {
        boolean bl = false;
        CredentialPickerConfig credentialPickerConfig = null;
        int n = zza.zzcr(parcel);
        CredentialPickerConfig credentialPickerConfig2 = null;
        String[] arrstring = null;
        int n2 = 0;
        block7 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block7;
                }
                case 1: {
                    bl = zza.zzc(parcel, n3);
                    continue block7;
                }
                case 2: {
                    arrstring = zza.zzac(parcel, n3);
                    continue block7;
                }
                case 3: {
                    credentialPickerConfig2 = zza.zza(parcel, n3, CredentialPickerConfig.CREATOR);
                    continue block7;
                }
                case 4: {
                    credentialPickerConfig = zza.zza(parcel, n3, CredentialPickerConfig.CREATOR);
                    continue block7;
                }
                case 1000: 
            }
            n2 = zza.zzg(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new CredentialRequest(n2, bl, arrstring, credentialPickerConfig2, credentialPickerConfig);
    }

    public CredentialRequest[] zzcz(int n) {
        return new CredentialRequest[n];
    }
}

