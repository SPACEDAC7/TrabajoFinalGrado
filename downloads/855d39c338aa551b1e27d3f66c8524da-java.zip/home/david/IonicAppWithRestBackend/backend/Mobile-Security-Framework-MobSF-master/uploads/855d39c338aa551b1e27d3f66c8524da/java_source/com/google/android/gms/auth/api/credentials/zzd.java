/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.credentials;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.CredentialPickerConfig;
import com.google.android.gms.auth.api.credentials.HintRequest;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzd
implements Parcelable.Creator<HintRequest> {
    static void zza(HintRequest hintRequest, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zza(parcel, 1, hintRequest.getHintPickerConfig(), n, false);
        zzb.zza(parcel, 2, hintRequest.isEmailAddressIdentifierSupported());
        zzb.zza(parcel, 3, hintRequest.zzaih());
        zzb.zza(parcel, 4, hintRequest.getAccountTypes(), false);
        zzb.zzc(parcel, 1000, hintRequest.mVersionCode);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzam(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzda(n);
    }

    public HintRequest zzam(Parcel parcel) {
        String[] arrstring = null;
        boolean bl = false;
        int n = zza.zzcr(parcel);
        boolean bl2 = false;
        CredentialPickerConfig credentialPickerConfig = null;
        int n2 = 0;
        block7 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block7;
                }
                case 1: {
                    credentialPickerConfig = zza.zza(parcel, n3, CredentialPickerConfig.CREATOR);
                    continue block7;
                }
                case 2: {
                    bl2 = zza.zzc(parcel, n3);
                    continue block7;
                }
                case 3: {
                    bl = zza.zzc(parcel, n3);
                    continue block7;
                }
                case 4: {
                    arrstring = zza.zzac(parcel, n3);
                    continue block7;
                }
                case 1000: 
            }
            n2 = zza.zzg(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new HintRequest(n2, credentialPickerConfig, bl2, bl, arrstring);
    }

    public HintRequest[] zzda(int n) {
        return new HintRequest[n];
    }
}

