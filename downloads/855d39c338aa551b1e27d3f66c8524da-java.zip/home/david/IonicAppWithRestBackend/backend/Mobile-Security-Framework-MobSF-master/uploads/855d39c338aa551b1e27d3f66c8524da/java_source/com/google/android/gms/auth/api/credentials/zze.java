/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.credentials;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.IdToken;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zze
implements Parcelable.Creator<IdToken> {
    static void zza(IdToken idToken, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zza(parcel, 1, idToken.getAccountType(), false);
        zzb.zza(parcel, 2, idToken.getIdToken(), false);
        zzb.zzc(parcel, 1000, idToken.mVersionCode);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzan(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzdb(n);
    }

    public IdToken zzan(Parcel parcel) {
        String string2 = null;
        int n = zza.zzcr(parcel);
        int n2 = 0;
        String string3 = null;
        block5 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block5;
                }
                case 1: {
                    string3 = zza.zzq(parcel, n3);
                    continue block5;
                }
                case 2: {
                    string2 = zza.zzq(parcel, n3);
                    continue block5;
                }
                case 1000: 
            }
            n2 = zza.zzg(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new IdToken(n2, string3, string2);
    }

    public IdToken[] zzdb(int n) {
        return new IdToken[n];
    }
}

