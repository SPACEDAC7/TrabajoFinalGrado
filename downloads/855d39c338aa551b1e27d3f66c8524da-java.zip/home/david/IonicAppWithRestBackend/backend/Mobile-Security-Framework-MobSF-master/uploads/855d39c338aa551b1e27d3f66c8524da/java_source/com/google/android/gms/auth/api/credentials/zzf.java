/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.credentials;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.PasswordSpecification;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import java.util.ArrayList;
import java.util.List;

public class zzf
implements Parcelable.Creator<PasswordSpecification> {
    static void zza(PasswordSpecification passwordSpecification, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zza(parcel, 1, passwordSpecification.iI, false);
        zzb.zzb(parcel, 2, passwordSpecification.iJ, false);
        zzb.zza(parcel, 3, passwordSpecification.iK, false);
        zzb.zzc(parcel, 4, passwordSpecification.iL);
        zzb.zzc(parcel, 5, passwordSpecification.iM);
        zzb.zzc(parcel, 1000, passwordSpecification.mVersionCode);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzao(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzdc(n);
    }

    public PasswordSpecification zzao(Parcel parcel) {
        ArrayList<Integer> arrayList = null;
        int n = 0;
        int n2 = zza.zzcr(parcel);
        int n3 = 0;
        ArrayList<String> arrayList2 = null;
        String string2 = null;
        int n4 = 0;
        block8 : while (parcel.dataPosition() < n2) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block8;
                }
                case 1: {
                    string2 = zza.zzq(parcel, n5);
                    continue block8;
                }
                case 2: {
                    arrayList2 = zza.zzae(parcel, n5);
                    continue block8;
                }
                case 3: {
                    arrayList = zza.zzad(parcel, n5);
                    continue block8;
                }
                case 4: {
                    n3 = zza.zzg(parcel, n5);
                    continue block8;
                }
                case 5: {
                    n = zza.zzg(parcel, n5);
                    continue block8;
                }
                case 1000: 
            }
            n4 = zza.zzg(parcel, n5);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new PasswordSpecification(n4, string2, arrayList2, arrayList, n3, n);
    }

    public PasswordSpecification[] zzdc(int n) {
        return new PasswordSpecification[n];
    }
}

