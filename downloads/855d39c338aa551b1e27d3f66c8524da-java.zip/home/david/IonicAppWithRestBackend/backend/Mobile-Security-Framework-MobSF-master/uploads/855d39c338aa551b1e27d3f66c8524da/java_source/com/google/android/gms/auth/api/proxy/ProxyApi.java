/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.auth.api.proxy;

import com.google.android.gms.auth.api.proxy.ProxyRequest;
import com.google.android.gms.auth.api.proxy.ProxyResponse;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;

public interface ProxyApi {
    public PendingResult<ProxyResult> performProxyRequest(GoogleApiClient var1, ProxyRequest var2);

    public static interface ProxyResult
    extends Result {
        public ProxyResponse getResponse();
    }

}

