/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.proxy;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.proxy.ProxyGrpcRequest;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zza
implements Parcelable.Creator<ProxyGrpcRequest> {
    static void zza(ProxyGrpcRequest proxyGrpcRequest, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zza(parcel, 1, proxyGrpcRequest.hostname, false);
        zzb.zzc(parcel, 2, proxyGrpcRequest.port);
        zzb.zza(parcel, 3, proxyGrpcRequest.timeoutMillis);
        zzb.zza(parcel, 4, proxyGrpcRequest.body, false);
        zzb.zza(parcel, 5, proxyGrpcRequest.method, false);
        zzb.zzc(parcel, 1000, proxyGrpcRequest.versionCode);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzas(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzdg(n);
    }

    public ProxyGrpcRequest zzas(Parcel parcel) {
        int n = 0;
        String string2 = null;
        int n2 = com.google.android.gms.common.internal.safeparcel.zza.zzcr(parcel);
        long l = 0;
        byte[] arrby = null;
        String string3 = null;
        int n3 = 0;
        block8 : while (parcel.dataPosition() < n2) {
            int n4 = com.google.android.gms.common.internal.safeparcel.zza.zzcq(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zza.zzgu(n4)) {
                default: {
                    com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, n4);
                    continue block8;
                }
                case 1: {
                    string3 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n4);
                    continue block8;
                }
                case 2: {
                    n = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n4);
                    continue block8;
                }
                case 3: {
                    l = com.google.android.gms.common.internal.safeparcel.zza.zzi(parcel, n4);
                    continue block8;
                }
                case 4: {
                    arrby = com.google.android.gms.common.internal.safeparcel.zza.zzt(parcel, n4);
                    continue block8;
                }
                case 5: {
                    string2 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n4);
                    continue block8;
                }
                case 1000: 
            }
            n3 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new ProxyGrpcRequest(n3, string3, n, l, arrby, string2);
    }

    public ProxyGrpcRequest[] zzdg(int n) {
        return new ProxyGrpcRequest[n];
    }
}

