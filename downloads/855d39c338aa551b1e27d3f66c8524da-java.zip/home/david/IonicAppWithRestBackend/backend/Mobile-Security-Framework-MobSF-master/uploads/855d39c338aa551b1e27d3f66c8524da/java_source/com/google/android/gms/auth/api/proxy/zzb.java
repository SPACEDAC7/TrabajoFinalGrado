/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.proxy;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.proxy.ProxyRequest;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zzb
implements Parcelable.Creator<ProxyRequest> {
    static void zza(ProxyRequest proxyRequest, Parcel parcel, int n) {
        n = com.google.android.gms.common.internal.safeparcel.zzb.zzcs(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 1, proxyRequest.url, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 2, proxyRequest.httpMethod);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 3, proxyRequest.timeoutMillis);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 4, proxyRequest.body, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 5, proxyRequest.iW, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1000, proxyRequest.versionCode);
        com.google.android.gms.common.internal.safeparcel.zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzat(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzdh(n);
    }

    public ProxyRequest zzat(Parcel parcel) {
        int n = 0;
        Bundle bundle = null;
        int n2 = zza.zzcr(parcel);
        long l = 0;
        byte[] arrby = null;
        String string2 = null;
        int n3 = 0;
        block8 : while (parcel.dataPosition() < n2) {
            int n4 = zza.zzcq(parcel);
            switch (zza.zzgu(n4)) {
                default: {
                    zza.zzb(parcel, n4);
                    continue block8;
                }
                case 1: {
                    string2 = zza.zzq(parcel, n4);
                    continue block8;
                }
                case 2: {
                    n = zza.zzg(parcel, n4);
                    continue block8;
                }
                case 3: {
                    l = zza.zzi(parcel, n4);
                    continue block8;
                }
                case 4: {
                    arrby = zza.zzt(parcel, n4);
                    continue block8;
                }
                case 5: {
                    bundle = zza.zzs(parcel, n4);
                    continue block8;
                }
                case 1000: 
            }
            n3 = zza.zzg(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new ProxyRequest(n3, string2, n, l, arrby, bundle);
    }

    public ProxyRequest[] zzdh(int n) {
        return new ProxyRequest[n];
    }
}

