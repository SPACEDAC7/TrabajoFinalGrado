/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.os.Bundle
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.proxy;

import android.app.PendingIntent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.proxy.ProxyResponse;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzc
implements Parcelable.Creator<ProxyResponse> {
    static void zza(ProxyResponse proxyResponse, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, proxyResponse.googlePlayServicesStatusCode);
        zzb.zza(parcel, 2, (Parcelable)proxyResponse.recoveryAction, n, false);
        zzb.zzc(parcel, 3, proxyResponse.statusCode);
        zzb.zza(parcel, 4, proxyResponse.iW, false);
        zzb.zza(parcel, 5, proxyResponse.body, false);
        zzb.zzc(parcel, 1000, proxyResponse.versionCode);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzau(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzdi(n);
    }

    public ProxyResponse zzau(Parcel parcel) {
        byte[] arrby = null;
        int n = 0;
        int n2 = zza.zzcr(parcel);
        Bundle bundle = null;
        PendingIntent pendingIntent = null;
        int n3 = 0;
        int n4 = 0;
        block8 : while (parcel.dataPosition() < n2) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block8;
                }
                case 1: {
                    n3 = zza.zzg(parcel, n5);
                    continue block8;
                }
                case 2: {
                    pendingIntent = (PendingIntent)zza.zza(parcel, n5, PendingIntent.CREATOR);
                    continue block8;
                }
                case 3: {
                    n = zza.zzg(parcel, n5);
                    continue block8;
                }
                case 4: {
                    bundle = zza.zzs(parcel, n5);
                    continue block8;
                }
                case 5: {
                    arrby = zza.zzt(parcel, n5);
                    continue block8;
                }
                case 1000: 
            }
            n4 = zza.zzg(parcel, n5);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new ProxyResponse(n4, n3, pendingIntent, n, bundle, arrby);
    }

    public ProxyResponse[] zzdi(int n) {
        return new ProxyResponse[n];
    }
}

