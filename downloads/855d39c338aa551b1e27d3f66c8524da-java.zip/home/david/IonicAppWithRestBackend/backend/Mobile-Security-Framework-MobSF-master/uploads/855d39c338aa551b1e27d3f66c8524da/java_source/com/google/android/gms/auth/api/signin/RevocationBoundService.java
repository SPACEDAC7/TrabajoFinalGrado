/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.os.IBinder
 *  android.util.Log
 */
package com.google.android.gms.auth.api.signin;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import com.google.android.gms.auth.api.signin.internal.zzi;

public final class RevocationBoundService
extends Service {
    /*
     * Enabled aggressive block sorting
     */
    public IBinder onBind(Intent object) {
        if ("com.google.android.gms.auth.api.signin.RevocationBoundService.disconnect".equals(object.getAction())) {
            if (Log.isLoggable((String)"RevocationService", (int)2)) {
                Log.v((String)"RevocationService", (String)"RevocationBoundService handling disconnect.");
            }
            return new zzi((Context)this);
        }
        object = (object = String.valueOf(object.getAction())).length() != 0 ? "Unknown action sent to RevocationBoundService: ".concat((String)object) : new String("Unknown action sent to RevocationBoundService: ");
        Log.w((String)"RevocationService", (String)object);
        return null;
    }
}

