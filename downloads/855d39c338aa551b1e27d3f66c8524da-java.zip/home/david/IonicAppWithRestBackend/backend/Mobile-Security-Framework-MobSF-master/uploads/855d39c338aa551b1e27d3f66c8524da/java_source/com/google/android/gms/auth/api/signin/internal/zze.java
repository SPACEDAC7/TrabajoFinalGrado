/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.auth.api.signin.internal;

public class zze {
    static int jI = 31;
    private int jJ = 1;

    public int zzajf() {
        return this.jJ;
    }

    /*
     * Enabled aggressive block sorting
     */
    public zze zzbe(boolean bl) {
        int n = jI;
        int n2 = this.jJ;
        int n3 = bl ? 1 : 0;
        this.jJ = n3 + n2 * n;
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    public zze zzq(Object object) {
        int n = jI;
        int n2 = this.jJ;
        int n3 = object == null ? 0 : object.hashCode();
        this.jJ = n3 + n2 * n;
        return this;
    }
}

