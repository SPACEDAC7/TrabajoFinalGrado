/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.auth.api.signin.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Status;

public interface zzg
extends IInterface {
    public void zza(GoogleSignInAccount var1, Status var2) throws RemoteException;

    public void zzl(Status var1) throws RemoteException;

    public void zzm(Status var1) throws RemoteException;

    public static abstract class com.google.android.gms.auth.api.signin.internal.zzg$zza
    extends Binder
    implements zzg {
        public com.google.android.gms.auth.api.signin.internal.zzg$zza() {
            this.attachInterface((IInterface)this, "com.google.android.gms.auth.api.signin.internal.ISignInCallbacks");
        }

        public static zzg zzcl(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.auth.api.signin.internal.ISignInCallbacks");
            if (iInterface != null && iInterface instanceof zzg) {
                return (zzg)iInterface;
            }
            return new zza(iBinder);
        }

        public IBinder asBinder() {
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean onTransact(int n, Parcel object, Parcel parcel, int n2) throws RemoteException {
            switch (n) {
                default: {
                    return super.onTransact(n, (Parcel)object, parcel, n2);
                }
                case 1598968902: {
                    parcel.writeString("com.google.android.gms.auth.api.signin.internal.ISignInCallbacks");
                    return true;
                }
                case 101: {
                    object.enforceInterface("com.google.android.gms.auth.api.signin.internal.ISignInCallbacks");
                    GoogleSignInAccount googleSignInAccount = object.readInt() != 0 ? (GoogleSignInAccount)GoogleSignInAccount.CREATOR.createFromParcel((Parcel)object) : null;
                    object = object.readInt() != 0 ? (Status)Status.CREATOR.createFromParcel((Parcel)object) : null;
                    this.zza(googleSignInAccount, (Status)object);
                    parcel.writeNoException();
                    return true;
                }
                case 102: {
                    object.enforceInterface("com.google.android.gms.auth.api.signin.internal.ISignInCallbacks");
                    object = object.readInt() != 0 ? (Status)Status.CREATOR.createFromParcel((Parcel)object) : null;
                    this.zzl((Status)object);
                    parcel.writeNoException();
                    return true;
                }
                case 103: 
            }
            object.enforceInterface("com.google.android.gms.auth.api.signin.internal.ISignInCallbacks");
            object = object.readInt() != 0 ? (Status)Status.CREATOR.createFromParcel((Parcel)object) : null;
            this.zzm((Status)object);
            parcel.writeNoException();
            return true;
        }

        private static class zza
        implements zzg {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(GoogleSignInAccount googleSignInAccount, Status status) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.signin.internal.ISignInCallbacks");
                    if (googleSignInAccount != null) {
                        parcel.writeInt(1);
                        googleSignInAccount.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    if (status != null) {
                        parcel.writeInt(1);
                        status.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(101, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zzl(Status status) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.signin.internal.ISignInCallbacks");
                    if (status != null) {
                        parcel.writeInt(1);
                        status.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(102, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zzm(Status status) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.signin.internal.ISignInCallbacks");
                    if (status != null) {
                        parcel.writeInt(1);
                        status.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(103, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

