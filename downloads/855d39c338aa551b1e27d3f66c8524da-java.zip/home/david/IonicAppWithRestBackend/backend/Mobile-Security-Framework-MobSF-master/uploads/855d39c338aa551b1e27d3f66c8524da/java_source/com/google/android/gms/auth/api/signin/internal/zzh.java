/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.auth.api.signin.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.internal.zzg;

public interface zzh
extends IInterface {
    public void zza(zzg var1, GoogleSignInOptions var2) throws RemoteException;

    public void zzb(zzg var1, GoogleSignInOptions var2) throws RemoteException;

    public void zzc(zzg var1, GoogleSignInOptions var2) throws RemoteException;

    public static abstract class com.google.android.gms.auth.api.signin.internal.zzh$zza
    extends Binder
    implements zzh {
        public static zzh zzcm(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.auth.api.signin.internal.ISignInService");
            if (iInterface != null && iInterface instanceof zzh) {
                return (zzh)iInterface;
            }
            return new zza(iBinder);
        }

        public boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) throws RemoteException {
            zzg zzg2 = null;
            zzg zzg3 = null;
            Object object = null;
            switch (n) {
                default: {
                    return super.onTransact(n, parcel, parcel2, n2);
                }
                case 1598968902: {
                    parcel2.writeString("com.google.android.gms.auth.api.signin.internal.ISignInService");
                    return true;
                }
                case 101: {
                    parcel.enforceInterface("com.google.android.gms.auth.api.signin.internal.ISignInService");
                    zzg2 = zzg.zza.zzcl(parcel.readStrongBinder());
                    if (parcel.readInt() != 0) {
                        object = (GoogleSignInOptions)GoogleSignInOptions.CREATOR.createFromParcel(parcel);
                    }
                    this.zza(zzg2, (GoogleSignInOptions)object);
                    parcel2.writeNoException();
                    return true;
                }
                case 102: {
                    parcel.enforceInterface("com.google.android.gms.auth.api.signin.internal.ISignInService");
                    zzg3 = zzg.zza.zzcl(parcel.readStrongBinder());
                    object = zzg2;
                    if (parcel.readInt() != 0) {
                        object = (GoogleSignInOptions)GoogleSignInOptions.CREATOR.createFromParcel(parcel);
                    }
                    this.zzb(zzg3, (GoogleSignInOptions)object);
                    parcel2.writeNoException();
                    return true;
                }
                case 103: 
            }
            parcel.enforceInterface("com.google.android.gms.auth.api.signin.internal.ISignInService");
            zzg2 = zzg.zza.zzcl(parcel.readStrongBinder());
            object = zzg3;
            if (parcel.readInt() != 0) {
                object = (GoogleSignInOptions)GoogleSignInOptions.CREATOR.createFromParcel(parcel);
            }
            this.zzc(zzg2, (GoogleSignInOptions)object);
            parcel2.writeNoException();
            return true;
        }

        private static class zza
        implements zzh {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zza(zzg zzg2, GoogleSignInOptions googleSignInOptions) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.signin.internal.ISignInService");
                    zzg2 = zzg2 != null ? zzg2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzg2);
                    if (googleSignInOptions != null) {
                        parcel.writeInt(1);
                        googleSignInOptions.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(101, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zzb(zzg zzg2, GoogleSignInOptions googleSignInOptions) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.signin.internal.ISignInService");
                    zzg2 = zzg2 != null ? zzg2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzg2);
                    if (googleSignInOptions != null) {
                        parcel.writeInt(1);
                        googleSignInOptions.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(102, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void zzc(zzg zzg2, GoogleSignInOptions googleSignInOptions) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.auth.api.signin.internal.ISignInService");
                    zzg2 = zzg2 != null ? zzg2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzg2);
                    if (googleSignInOptions != null) {
                        parcel.writeInt(1);
                        googleSignInOptions.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(103, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

