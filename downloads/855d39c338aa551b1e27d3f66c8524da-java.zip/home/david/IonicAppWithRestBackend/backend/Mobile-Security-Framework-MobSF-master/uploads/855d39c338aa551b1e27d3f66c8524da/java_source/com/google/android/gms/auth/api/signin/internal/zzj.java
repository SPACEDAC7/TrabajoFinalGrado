/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.signin.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.internal.SignInConfiguration;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzj
implements Parcelable.Creator<SignInConfiguration> {
    static void zza(SignInConfiguration signInConfiguration, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, signInConfiguration.versionCode);
        zzb.zza(parcel, 2, signInConfiguration.zzajj(), false);
        zzb.zza(parcel, 5, signInConfiguration.zzajk(), n, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzay(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzdm(n);
    }

    public SignInConfiguration zzay(Parcel parcel) {
        GoogleSignInOptions googleSignInOptions = null;
        int n = zza.zzcr(parcel);
        int n2 = 0;
        String string2 = null;
        block5 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block5;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block5;
                }
                case 2: {
                    string2 = zza.zzq(parcel, n3);
                    continue block5;
                }
                case 5: 
            }
            googleSignInOptions = zza.zza(parcel, n3, GoogleSignInOptions.CREATOR);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new SignInConfiguration(n2, string2, googleSignInOptions);
    }

    public SignInConfiguration[] zzdm(int n) {
        return new SignInConfiguration[n];
    }
}

