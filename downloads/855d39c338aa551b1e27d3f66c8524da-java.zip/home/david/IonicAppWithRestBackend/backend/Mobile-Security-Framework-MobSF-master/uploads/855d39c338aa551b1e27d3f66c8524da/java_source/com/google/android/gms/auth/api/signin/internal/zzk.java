/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.text.TextUtils
 *  org.json.JSONException
 */
package com.google.android.gms.auth.api.signin.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.internal.zzaa;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONException;

public class zzk {
    private static final Lock jS = new ReentrantLock();
    private static zzk jT;
    private final Lock jU = new ReentrantLock();
    private final SharedPreferences jV;

    zzk(Context context) {
        this.jV = context.getSharedPreferences("com.google.android.gms.signin", 0);
    }

    public static zzk zzba(Context object) {
        zzaa.zzy(object);
        jS.lock();
        try {
            if (jT == null) {
                jT = new zzk(object.getApplicationContext());
            }
            object = jT;
            return object;
        }
        finally {
            jS.unlock();
        }
    }

    private String zzx(String string2, String string3) {
        String string4 = String.valueOf(":");
        return new StringBuilder(String.valueOf(string2).length() + 0 + String.valueOf(string4).length() + String.valueOf(string3).length()).append(string2).append(string4).append(string3).toString();
    }

    void zza(GoogleSignInAccount googleSignInAccount, GoogleSignInOptions googleSignInOptions) {
        zzaa.zzy(googleSignInAccount);
        zzaa.zzy(googleSignInOptions);
        String string2 = googleSignInAccount.zzaip();
        this.zzw(this.zzx("googleSignInAccount", string2), googleSignInAccount.zzair());
        this.zzw(this.zzx("googleSignInOptions", string2), googleSignInOptions.zzaiq());
    }

    public GoogleSignInAccount zzajm() {
        return this.zzgd(this.zzgf("defaultGoogleSignInAccount"));
    }

    public GoogleSignInOptions zzajn() {
        return this.zzge(this.zzgf("defaultGoogleSignInAccount"));
    }

    public void zzajo() {
        String string2 = this.zzgf("defaultGoogleSignInAccount");
        this.zzgh("defaultGoogleSignInAccount");
        this.zzgg(string2);
    }

    public void zzb(GoogleSignInAccount googleSignInAccount, GoogleSignInOptions googleSignInOptions) {
        zzaa.zzy(googleSignInAccount);
        zzaa.zzy(googleSignInOptions);
        this.zzw("defaultGoogleSignInAccount", googleSignInAccount.zzaip());
        this.zza(googleSignInAccount, googleSignInOptions);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    GoogleSignInAccount zzgd(String object) {
        if (TextUtils.isEmpty((CharSequence)object)) {
            return null;
        }
        if ((object = this.zzgf(this.zzx("googleSignInAccount", (String)object))) == null) return null;
        try {
            return GoogleSignInAccount.zzfz((String)object);
        }
        catch (JSONException var1_2) {
            return null;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    GoogleSignInOptions zzge(String object) {
        if (TextUtils.isEmpty((CharSequence)object)) {
            return null;
        }
        if ((object = this.zzgf(this.zzx("googleSignInOptions", (String)object))) == null) return null;
        try {
            return GoogleSignInOptions.zzgb((String)object);
        }
        catch (JSONException var1_2) {
            return null;
        }
    }

    protected String zzgf(String string2) {
        this.jU.lock();
        try {
            string2 = this.jV.getString(string2, null);
            return string2;
        }
        finally {
            this.jU.unlock();
        }
    }

    void zzgg(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return;
        }
        this.zzgh(this.zzx("googleSignInAccount", string2));
        this.zzgh(this.zzx("googleSignInOptions", string2));
    }

    protected void zzgh(String string2) {
        this.jU.lock();
        try {
            this.jV.edit().remove(string2).apply();
            return;
        }
        finally {
            this.jU.unlock();
        }
    }

    protected void zzw(String string2, String string3) {
        this.jU.lock();
        try {
            this.jV.edit().putString(string2, string3).apply();
            return;
        }
        finally {
            this.jU.unlock();
        }
    }
}

