/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import java.util.ArrayList;
import java.util.List;

public class zza
implements Parcelable.Creator<GoogleSignInAccount> {
    static void zza(GoogleSignInAccount googleSignInAccount, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, googleSignInAccount.versionCode);
        zzb.zza(parcel, 2, googleSignInAccount.getId(), false);
        zzb.zza(parcel, 3, googleSignInAccount.getIdToken(), false);
        zzb.zza(parcel, 4, googleSignInAccount.getEmail(), false);
        zzb.zza(parcel, 5, googleSignInAccount.getDisplayName(), false);
        zzb.zza(parcel, 6, (Parcelable)googleSignInAccount.getPhotoUrl(), n, false);
        zzb.zza(parcel, 7, googleSignInAccount.getServerAuthCode(), false);
        zzb.zza(parcel, 8, googleSignInAccount.zzaio());
        zzb.zza(parcel, 9, googleSignInAccount.zzaip(), false);
        zzb.zzc(parcel, 10, googleSignInAccount.hR, false);
        zzb.zza(parcel, 11, googleSignInAccount.getGivenName(), false);
        zzb.zza(parcel, 12, googleSignInAccount.getFamilyName(), false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzav(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzdj(n);
    }

    public GoogleSignInAccount zzav(Parcel parcel) {
        int n = com.google.android.gms.common.internal.safeparcel.zza.zzcr(parcel);
        int n2 = 0;
        String string2 = null;
        String string3 = null;
        String string4 = null;
        String string5 = null;
        Uri uri = null;
        String string6 = null;
        long l = 0;
        String string7 = null;
        ArrayList<Scope> arrayList = null;
        String string8 = null;
        String string9 = null;
        block14 : while (parcel.dataPosition() < n) {
            int n3 = com.google.android.gms.common.internal.safeparcel.zza.zzcq(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zza.zzgu(n3)) {
                default: {
                    com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, n3);
                    continue block14;
                }
                case 1: {
                    n2 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n3);
                    continue block14;
                }
                case 2: {
                    string2 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block14;
                }
                case 3: {
                    string3 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block14;
                }
                case 4: {
                    string4 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block14;
                }
                case 5: {
                    string5 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block14;
                }
                case 6: {
                    uri = (Uri)com.google.android.gms.common.internal.safeparcel.zza.zza(parcel, n3, Uri.CREATOR);
                    continue block14;
                }
                case 7: {
                    string6 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block14;
                }
                case 8: {
                    l = com.google.android.gms.common.internal.safeparcel.zza.zzi(parcel, n3);
                    continue block14;
                }
                case 9: {
                    string7 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block14;
                }
                case 10: {
                    arrayList = com.google.android.gms.common.internal.safeparcel.zza.zzc(parcel, n3, Scope.CREATOR);
                    continue block14;
                }
                case 11: {
                    string8 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block14;
                }
                case 12: 
            }
            string9 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new GoogleSignInAccount(n2, string2, string3, string4, string5, uri, string6, l, string7, arrayList, string8, string9);
    }

    public GoogleSignInAccount[] zzdj(int n) {
        return new GoogleSignInAccount[n];
    }
}

