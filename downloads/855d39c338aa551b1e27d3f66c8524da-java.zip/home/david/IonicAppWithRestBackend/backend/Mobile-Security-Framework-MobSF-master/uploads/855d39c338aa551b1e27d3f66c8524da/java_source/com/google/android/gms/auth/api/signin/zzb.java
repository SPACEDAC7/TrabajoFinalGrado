/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.signin;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.zza;
import java.util.ArrayList;

public class zzb
implements Parcelable.Creator<GoogleSignInOptions> {
    static void zza(GoogleSignInOptions googleSignInOptions, Parcel parcel, int n) {
        int n2 = com.google.android.gms.common.internal.safeparcel.zzb.zzcs(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1, googleSignInOptions.versionCode);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 2, googleSignInOptions.zzait(), false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 3, (Parcelable)googleSignInOptions.getAccount(), n, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 4, googleSignInOptions.zzaiu());
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 5, googleSignInOptions.zzaiv());
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 6, googleSignInOptions.zzaiw());
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 7, googleSignInOptions.zzaix(), false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 8, googleSignInOptions.zzaiy(), false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzaw(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzdk(n);
    }

    public GoogleSignInOptions zzaw(Parcel parcel) {
        String string2 = null;
        boolean bl = false;
        int n = zza.zzcr(parcel);
        String string3 = null;
        boolean bl2 = false;
        boolean bl3 = false;
        Account account = null;
        ArrayList<Scope> arrayList = null;
        int n2 = 0;
        block10 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block10;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block10;
                }
                case 2: {
                    arrayList = zza.zzc(parcel, n3, Scope.CREATOR);
                    continue block10;
                }
                case 3: {
                    account = (Account)zza.zza(parcel, n3, Account.CREATOR);
                    continue block10;
                }
                case 4: {
                    bl3 = zza.zzc(parcel, n3);
                    continue block10;
                }
                case 5: {
                    bl2 = zza.zzc(parcel, n3);
                    continue block10;
                }
                case 6: {
                    bl = zza.zzc(parcel, n3);
                    continue block10;
                }
                case 7: {
                    string3 = zza.zzq(parcel, n3);
                    continue block10;
                }
                case 8: 
            }
            string2 = zza.zzq(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new GoogleSignInOptions(n2, arrayList, account, bl3, bl2, bl, string3, string2);
    }

    public GoogleSignInOptions[] zzdk(int n) {
        return new GoogleSignInOptions[n];
    }
}

