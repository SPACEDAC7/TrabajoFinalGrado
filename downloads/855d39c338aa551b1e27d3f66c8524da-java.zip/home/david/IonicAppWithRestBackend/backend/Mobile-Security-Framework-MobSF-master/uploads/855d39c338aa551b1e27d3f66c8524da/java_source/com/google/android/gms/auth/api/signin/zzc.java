/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth.api.signin;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.SignInAccount;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzc
implements Parcelable.Creator<SignInAccount> {
    static void zza(SignInAccount signInAccount, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, signInAccount.versionCode);
        zzb.zza(parcel, 4, signInAccount.jg, false);
        zzb.zza(parcel, 7, signInAccount.zzaiz(), n, false);
        zzb.zza(parcel, 8, signInAccount.ck, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzax(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzdl(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public SignInAccount zzax(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        Object object = "";
        Object object2 = null;
        String string2 = "";
        while (parcel.dataPosition() < n) {
            Object object3;
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    object3 = object2;
                    object2 = object;
                    object = object3;
                    break;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    object3 = object;
                    object = object2;
                    object2 = object3;
                    break;
                }
                case 4: {
                    object3 = zza.zzq(parcel, n3);
                    object = object2;
                    object2 = object3;
                    break;
                }
                case 7: {
                    object3 = zza.zza(parcel, n3, GoogleSignInAccount.CREATOR);
                    object2 = object;
                    object = object3;
                    break;
                }
                case 8: {
                    string2 = zza.zzq(parcel, n3);
                    object3 = object;
                    object = object2;
                    object2 = object3;
                }
            }
            object3 = object2;
            object2 = object;
            object = object3;
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new SignInAccount(n2, (String)object, (GoogleSignInAccount)object2, string2);
    }

    public SignInAccount[] zzdl(int n) {
        return new SignInAccount[n];
    }
}

