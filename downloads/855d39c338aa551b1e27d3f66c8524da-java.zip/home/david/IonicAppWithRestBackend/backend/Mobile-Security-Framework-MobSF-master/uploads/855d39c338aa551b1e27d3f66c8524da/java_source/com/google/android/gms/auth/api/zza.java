/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Looper
 */
package com.google.android.gms.auth.api;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.auth.api.zzb;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.internal.zzf;
import com.google.android.gms.internal.zzny;

public final class zza {
    public static final Api<zzb> API;
    public static final Api.zzf<zzny> ii;
    private static final Api.zza<zzny, zzb> ij;

    static {
        ii = new Api.zzf();
        ij = new Api.zza<zzny, zzb>(){

            @Override
            public zzny zza(Context context, Looper looper, zzf zzf2, zzb zzb2, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener) {
                return new zzny(context, looper, zzf2, zzb2, connectionCallbacks, onConnectionFailedListener);
            }
        };
        API = new Api<zzb>("Auth.PROXY_API", ij, ii);
    }

}

