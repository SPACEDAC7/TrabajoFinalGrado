/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.AccountChangeEvent;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zza
implements Parcelable.Creator<AccountChangeEvent> {
    static void zza(AccountChangeEvent accountChangeEvent, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, accountChangeEvent.mVersion);
        zzb.zza(parcel, 2, accountChangeEvent.hx);
        zzb.zza(parcel, 3, accountChangeEvent.hy, false);
        zzb.zzc(parcel, 4, accountChangeEvent.hz);
        zzb.zzc(parcel, 5, accountChangeEvent.hA);
        zzb.zza(parcel, 6, accountChangeEvent.hB, false);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzaf(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzct(n);
    }

    public AccountChangeEvent zzaf(Parcel parcel) {
        String string2 = null;
        int n = 0;
        int n2 = com.google.android.gms.common.internal.safeparcel.zza.zzcr(parcel);
        long l = 0;
        int n3 = 0;
        String string3 = null;
        int n4 = 0;
        block8 : while (parcel.dataPosition() < n2) {
            int n5 = com.google.android.gms.common.internal.safeparcel.zza.zzcq(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zza.zzgu(n5)) {
                default: {
                    com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, n5);
                    continue block8;
                }
                case 1: {
                    n4 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n5);
                    continue block8;
                }
                case 2: {
                    l = com.google.android.gms.common.internal.safeparcel.zza.zzi(parcel, n5);
                    continue block8;
                }
                case 3: {
                    string3 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n5);
                    continue block8;
                }
                case 4: {
                    n3 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n5);
                    continue block8;
                }
                case 5: {
                    n = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n5);
                    continue block8;
                }
                case 6: 
            }
            string2 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n5);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new AccountChangeEvent(n4, l, string3, n3, n, string2);
    }

    public AccountChangeEvent[] zzct(int n) {
        return new AccountChangeEvent[n];
    }
}

