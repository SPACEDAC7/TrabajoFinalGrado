/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.AccountChangeEventsRequest;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zzb
implements Parcelable.Creator<AccountChangeEventsRequest> {
    static void zza(AccountChangeEventsRequest accountChangeEventsRequest, Parcel parcel, int n) {
        int n2 = com.google.android.gms.common.internal.safeparcel.zzb.zzcs(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1, accountChangeEventsRequest.mVersion);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 2, accountChangeEventsRequest.hA);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 3, accountChangeEventsRequest.hy, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 4, (Parcelable)accountChangeEventsRequest.gj, n, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzag(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzcu(n);
    }

    public AccountChangeEventsRequest zzag(Parcel parcel) {
        Account account = null;
        int n = 0;
        int n2 = zza.zzcr(parcel);
        String string2 = null;
        int n3 = 0;
        block6 : while (parcel.dataPosition() < n2) {
            int n4 = zza.zzcq(parcel);
            switch (zza.zzgu(n4)) {
                default: {
                    zza.zzb(parcel, n4);
                    continue block6;
                }
                case 1: {
                    n3 = zza.zzg(parcel, n4);
                    continue block6;
                }
                case 2: {
                    n = zza.zzg(parcel, n4);
                    continue block6;
                }
                case 3: {
                    string2 = zza.zzq(parcel, n4);
                    continue block6;
                }
                case 4: 
            }
            account = (Account)zza.zza(parcel, n4, Account.CREATOR);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new AccountChangeEventsRequest(n3, n, string2, account);
    }

    public AccountChangeEventsRequest[] zzcu(int n) {
        return new AccountChangeEventsRequest[n];
    }
}

