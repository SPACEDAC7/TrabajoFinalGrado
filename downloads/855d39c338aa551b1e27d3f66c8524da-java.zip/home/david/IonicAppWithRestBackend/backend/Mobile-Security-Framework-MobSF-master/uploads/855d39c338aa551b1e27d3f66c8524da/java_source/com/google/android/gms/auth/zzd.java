/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.auth;

import com.google.android.gms.internal.zzsu;

public class zzd {
    public static /* varargs */ zzsu zzb(String ... arrstring) {
        return new zzsu("Auth", arrstring);
    }
}

