/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.AccountManager
 *  android.annotation.TargetApi
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.content.pm.ApplicationInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  android.os.RemoteException
 *  android.os.SystemClock
 *  android.text.TextUtils
 */
package com.google.android.gms.auth;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.SystemClock;
import android.support.annotation.RequiresPermission;
import android.text.TextUtils;
import com.google.android.gms.auth.AccountChangeEvent;
import com.google.android.gms.auth.AccountChangeEventsRequest;
import com.google.android.gms.auth.AccountChangeEventsResponse;
import com.google.android.gms.auth.GoogleAuthException;
import com.google.android.gms.auth.GooglePlayServicesAvailabilityException;
import com.google.android.gms.auth.TokenData;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.auth.zzd;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.internal.zzl;
import com.google.android.gms.internal.zzbz;
import com.google.android.gms.internal.zzoe;
import com.google.android.gms.internal.zzsu;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

public class zze {
    public static final int CHANGE_TYPE_ACCOUNT_ADDED = 1;
    public static final int CHANGE_TYPE_ACCOUNT_REMOVED = 2;
    public static final int CHANGE_TYPE_ACCOUNT_RENAMED_FROM = 3;
    public static final int CHANGE_TYPE_ACCOUNT_RENAMED_TO = 4;
    public static final String GOOGLE_ACCOUNT_TYPE = "com.google";
    public static final String KEY_ANDROID_PACKAGE_NAME;
    public static final String KEY_CALLER_UID;
    public static final String KEY_SUPPRESS_PROGRESS_SCREEN = "suppressProgressScreen";
    public static final String WORK_ACCOUNT_TYPE = "com.google.work";
    private static final String[] hC;
    private static final ComponentName hD;
    private static final ComponentName hE;
    private static final zzsu hF;

    static {
        hC = new String[]{"com.google", "com.google.work", "cn.google"};
        if (Build.VERSION.SDK_INT >= 11) {
            // empty if block
        }
        KEY_CALLER_UID = "callerUid";
        if (Build.VERSION.SDK_INT >= 14) {
            // empty if block
        }
        KEY_ANDROID_PACKAGE_NAME = "androidPackageName";
        hD = new ComponentName("com.google.android.gms", "com.google.android.gms.auth.GetToken");
        hE = new ComponentName("com.google.android.gms", "com.google.android.gms.recovery.RecoveryService");
        hF = zzd.zzb("GoogleAuthUtil");
    }

    zze() {
    }

    public static void clearToken(Context context, String object) throws GooglePlayServicesAvailabilityException, GoogleAuthException, IOException {
        zzaa.zzht("Calling this from your main thread can lead to deadlock");
        zze.zzaz(context);
        final Bundle bundle = new Bundle();
        String string2 = context.getApplicationInfo().packageName;
        bundle.putString("clientPackageName", string2);
        if (!bundle.containsKey(KEY_ANDROID_PACKAGE_NAME)) {
            bundle.putString(KEY_ANDROID_PACKAGE_NAME, string2);
        }
        object = new zza<Void>(){

            @Override
            public /* synthetic */ Object zzbu(IBinder iBinder) throws RemoteException, IOException, GoogleAuthException {
                return this.zzbv(iBinder);
            }

            public Void zzbv(IBinder iBinder) throws RemoteException, IOException, GoogleAuthException {
                iBinder = (Bundle)zze.zzn((Object)zzbz.zza.zza(iBinder).zza(String.this, bundle));
                String string2 = iBinder.getString("Error");
                if (!iBinder.getBoolean("booleanResult")) {
                    throw new GoogleAuthException(string2);
                }
                return null;
            }
        };
        zze.zza(context, hD, object);
    }

    public static List<AccountChangeEvent> getAccountChangeEvents(Context context, final int n, String object) throws GoogleAuthException, IOException {
        zzaa.zzh((String)object, "accountName must be provided");
        zzaa.zzht("Calling this from your main thread can lead to deadlock");
        zze.zzaz(context);
        object = new zza<List<AccountChangeEvent>>(){

            @Override
            public /* synthetic */ Object zzbu(IBinder iBinder) throws RemoteException, IOException, GoogleAuthException {
                return this.zzbw(iBinder);
            }

            public List<AccountChangeEvent> zzbw(IBinder iBinder) throws RemoteException, IOException, GoogleAuthException {
                return ((AccountChangeEventsResponse)zze.zzn(zzbz.zza.zza(iBinder).zza(new AccountChangeEventsRequest().setAccountName(String.this).setEventIndex(n)))).getEvents();
            }
        };
        return (List)zze.zza(context, hD, object);
    }

    public static String getAccountId(Context context, String string2) throws GoogleAuthException, IOException {
        zzaa.zzh(string2, "accountName must be provided");
        zzaa.zzht("Calling this from your main thread can lead to deadlock");
        zze.zzaz(context);
        return zze.getToken(context, string2, "^^_account_id_^^", new Bundle());
    }

    public static String getToken(Context context, Account account, String string2) throws IOException, UserRecoverableAuthException, GoogleAuthException {
        return zze.getToken(context, account, string2, new Bundle());
    }

    public static String getToken(Context context, Account account, String string2, Bundle bundle) throws IOException, UserRecoverableAuthException, GoogleAuthException {
        zze.zzc(account);
        return zze.zzc(context, account, string2, bundle).getToken();
    }

    @Deprecated
    public static String getToken(Context context, String string2, String string3) throws IOException, UserRecoverableAuthException, GoogleAuthException {
        return zze.getToken(context, new Account(string2, "com.google"), string3);
    }

    @Deprecated
    public static String getToken(Context context, String string2, String string3, Bundle bundle) throws IOException, UserRecoverableAuthException, GoogleAuthException {
        return zze.getToken(context, new Account(string2, "com.google"), string3, bundle);
    }

    @Deprecated
    @RequiresPermission(value="android.permission.MANAGE_ACCOUNTS")
    public static void invalidateToken(Context context, String string2) {
        AccountManager.get((Context)context).invalidateAuthToken("com.google", string2);
    }

    @TargetApi(value=23)
    public static Bundle removeAccount(Context context, Account object) throws GoogleAuthException, IOException {
        zzaa.zzy(context);
        zze.zzc((Account)object);
        zze.zzaz(context);
        object = new zza<Bundle>(){

            @Override
            public /* synthetic */ Object zzbu(IBinder iBinder) throws RemoteException, IOException, GoogleAuthException {
                return this.zzbx(iBinder);
            }

            public Bundle zzbx(IBinder iBinder) throws RemoteException, IOException, GoogleAuthException {
                return (Bundle)zze.zzn((Object)zzbz.zza.zza(iBinder).zza(Account.this));
            }
        };
        return (Bundle)zze.zza(context, hD, object);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static <T> T zza(Context var0, ComponentName var1_4, zza<T> var2_5) throws IOException, GoogleAuthException {
        var3_6 = new com.google.android.gms.common.zza();
        var4_7 = zzl.zzcc((Context)var0);
        if (var4_7.zza(var1_4, var3_6, "GoogleAuthUtil") == false) throw new IOException("Could not bind to service.");
        try {
            var0 = var2_5.zzbu(var3_6.zzaqk());
            return (T)var0;
        }
        catch (InterruptedException var0_1) {}
        ** GOTO lbl-1000
        catch (RemoteException var0_3) {}
lbl-1000: // 2 sources:
        {
            zze.hF.zze("GoogleAuthUtil", new Object[]{"Error on service connection.", var0});
            throw new IOException("Error on service connection.", (Throwable)var0);
        }
        finally {
            var4_7.zzb(var1_4, var3_6, "GoogleAuthUtil");
        }
    }

    private static void zzaz(Context context) throws GoogleAuthException {
        try {
            com.google.android.gms.common.zze.zzaz(context.getApplicationContext());
            return;
        }
        catch (GooglePlayServicesRepairableException var0_1) {
            throw new GooglePlayServicesAvailabilityException(var0_1.getConnectionStatusCode(), var0_1.getMessage(), var0_1.getIntent());
        }
        catch (GooglePlayServicesNotAvailableException var0_2) {
            throw new GoogleAuthException(var0_2.getMessage());
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static TokenData zzc(Context context, Account object, final String string2, final Bundle bundle) throws IOException, UserRecoverableAuthException, GoogleAuthException {
        zzaa.zzht("Calling this from your main thread can lead to deadlock");
        zzaa.zzh(string2, "Scope cannot be empty or null.");
        zze.zzc((Account)object);
        zze.zzaz(context);
        bundle = bundle == null ? new Bundle() : new Bundle(bundle);
        String string3 = context.getApplicationInfo().packageName;
        bundle.putString("clientPackageName", string3);
        if (TextUtils.isEmpty((CharSequence)bundle.getString(KEY_ANDROID_PACKAGE_NAME))) {
            bundle.putString(KEY_ANDROID_PACKAGE_NAME, string3);
        }
        bundle.putLong("service_connection_start_time_millis", SystemClock.elapsedRealtime());
        object = new zza<TokenData>(){

            public TokenData zzbt(IBinder object) throws RemoteException, IOException, GoogleAuthException {
                Bundle bundle2 = (Bundle)zze.zzn((Object)zzbz.zza.zza((IBinder)object).zza(Account.this, string2, bundle));
                object = TokenData.zzd(bundle2, "tokenDetails");
                if (object != null) {
                    return object;
                }
                object = bundle2.getString("Error");
                bundle2 = (Intent)bundle2.getParcelable("userRecoveryIntent");
                Object object2 = zzoe.zzgi((String)object);
                if (zzoe.zza((zzoe)((Object)object2))) {
                    zzsu zzsu2 = hF;
                    object2 = String.valueOf(object2);
                    zzsu2.zzf("GoogleAuthUtil", new StringBuilder(String.valueOf(object2).length() + 31).append("isUserRecoverableError status: ").append((String)object2).toString());
                    throw new UserRecoverableAuthException((String)object, (Intent)bundle2);
                }
                if (zzoe.zzb((zzoe)((Object)object2))) {
                    throw new IOException((String)object);
                }
                throw new GoogleAuthException((String)object);
            }

            @Override
            public /* synthetic */ Object zzbu(IBinder iBinder) throws RemoteException, IOException, GoogleAuthException {
                return this.zzbt(iBinder);
            }
        };
        return (TokenData)zze.zza(context, hD, object);
    }

    private static void zzc(Account account) {
        if (account == null) {
            throw new IllegalArgumentException("Account cannot be null");
        }
        if (TextUtils.isEmpty((CharSequence)account.name)) {
            throw new IllegalArgumentException("Account name cannot be empty!");
        }
        String[] arrstring = hC;
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            if (!arrstring[i].equals(account.type)) continue;
            return;
        }
        throw new IllegalArgumentException("Account type not supported");
    }

    static void zzi(Intent object) {
        if (object == null) {
            throw new IllegalArgumentException("Callback cannot be null.");
        }
        object = object.toUri(1);
        try {
            Intent.parseUri((String)object, (int)1);
            return;
        }
        catch (URISyntaxException var0_1) {
            throw new IllegalArgumentException("Parameter callback contains invalid data. It must be serializable using toUri() and parseUri().");
        }
    }

    private static <T> T zzn(T t) throws IOException {
        if (t == null) {
            hF.zzf("GoogleAuthUtil", "Binder call returned null.");
            throw new IOException("Service unavailable.");
        }
        return t;
    }

    private static interface zza<T> {
        public T zzbu(IBinder var1) throws RemoteException, IOException, GoogleAuthException;
    }

}

