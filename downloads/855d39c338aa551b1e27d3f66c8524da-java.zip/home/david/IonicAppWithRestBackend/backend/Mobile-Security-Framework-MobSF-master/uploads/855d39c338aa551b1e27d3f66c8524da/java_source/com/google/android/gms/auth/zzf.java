/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.auth;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.TokenData;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import java.util.ArrayList;
import java.util.List;

public class zzf
implements Parcelable.Creator<TokenData> {
    static void zza(TokenData tokenData, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, tokenData.mVersionCode);
        zzb.zza(parcel, 2, tokenData.getToken(), false);
        zzb.zza(parcel, 3, tokenData.zzahy(), false);
        zzb.zza(parcel, 4, tokenData.zzahz());
        zzb.zza(parcel, 5, tokenData.zzaia());
        zzb.zzb(parcel, 6, tokenData.zzaib(), false);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzai(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzcw(n);
    }

    public TokenData zzai(Parcel parcel) {
        ArrayList<String> arrayList = null;
        boolean bl = false;
        int n = zza.zzcr(parcel);
        boolean bl2 = false;
        Long l = null;
        String string2 = null;
        int n2 = 0;
        block8 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block8;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block8;
                }
                case 2: {
                    string2 = zza.zzq(parcel, n3);
                    continue block8;
                }
                case 3: {
                    l = zza.zzj(parcel, n3);
                    continue block8;
                }
                case 4: {
                    bl2 = zza.zzc(parcel, n3);
                    continue block8;
                }
                case 5: {
                    bl = zza.zzc(parcel, n3);
                    continue block8;
                }
                case 6: 
            }
            arrayList = zza.zzae(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new TokenData(n2, string2, l, bl2, bl, arrayList);
    }

    public TokenData[] zzcw(int n) {
        return new TokenData[n];
    }
}

