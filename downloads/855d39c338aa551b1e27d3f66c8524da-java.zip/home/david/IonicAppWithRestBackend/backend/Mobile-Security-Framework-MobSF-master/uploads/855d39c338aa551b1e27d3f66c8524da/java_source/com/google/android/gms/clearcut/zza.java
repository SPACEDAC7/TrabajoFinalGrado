/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Looper
 *  android.util.Log
 */
package com.google.android.gms.clearcut;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Looper;
import android.util.Log;
import com.google.android.gms.clearcut.LogEventParcelable;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.PendingResults;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.internal.zzf;
import com.google.android.gms.common.util.zze;
import com.google.android.gms.common.util.zzh;
import com.google.android.gms.internal.zzasf;
import com.google.android.gms.internal.zzqc;
import com.google.android.gms.internal.zzqd;
import com.google.android.gms.internal.zzqh;
import com.google.android.gms.playlog.internal.PlayLoggerContext;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TimeZone;

public final class zza {
    @Deprecated
    public static final Api<Api.ApiOptions.NoOptions> API;
    public static final Api.zzf<zzqd> hg;
    public static final Api.zza<zzqd, Api.ApiOptions.NoOptions> hh;
    private final int wc;
    private String wd;
    private int we;
    private String wf;
    private String wg;
    private final boolean wh;
    private int wi;
    private final com.google.android.gms.clearcut.zzb wj;
    private zzd wk;
    private final zzb wl;
    private final zze zzaql;
    private final String zzcjc;

    static {
        hg = new Api.zzf();
        hh = new Api.zza<zzqd, Api.ApiOptions.NoOptions>(){

            @Override
            public /* synthetic */ Api.zze zza(Context context, Looper looper, zzf zzf2, Object object, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener) {
                return this.zze(context, looper, zzf2, (Api.ApiOptions.NoOptions)object, connectionCallbacks, onConnectionFailedListener);
            }

            public zzqd zze(Context context, Looper looper, zzf zzf2, Api.ApiOptions.NoOptions noOptions, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener) {
                return new zzqd(context, looper, zzf2, connectionCallbacks, onConnectionFailedListener);
            }
        };
        API = new Api<Api.ApiOptions.NoOptions>("ClearcutLogger.API", hh, hg);
    }

    /*
     * Enabled aggressive block sorting
     */
    public zza(Context context, int n, String string2, String string3, String string4, boolean bl, com.google.android.gms.clearcut.zzb zzb2, zze zze2, zzd zzd2, zzb zzb3) {
        boolean bl2 = false;
        this.we = -1;
        this.wi = 0;
        this.zzcjc = context.getPackageName();
        this.wc = this.zzbh(context);
        this.we = n;
        this.wd = string2;
        this.wf = string3;
        this.wg = string4;
        this.wh = bl;
        this.wj = zzb2;
        this.zzaql = zze2;
        if (zzd2 == null) {
            zzd2 = new zzd();
        }
        this.wk = zzd2;
        this.wi = 0;
        this.wl = zzb3;
        if (this.wh) {
            bl = bl2;
            if (this.wf == null) {
                bl = true;
            }
            zzaa.zzb(bl, (Object)"can't be anonymous with an upload account");
        }
    }

    public zza(Context context, String string2, String string3) {
        this(context, -1, string2, string3, null, false, zzqc.zzbi(context), zzh.zzayl(), null, new zzqh(context));
    }

    private static int[] zzb(ArrayList<Integer> object) {
        if (object == null) {
            return null;
        }
        int[] arrn = new int[object.size()];
        object = object.iterator();
        int n = 0;
        while (object.hasNext()) {
            arrn[n] = (Integer)object.next();
            ++n;
        }
        return arrn;
    }

    private int zzbh(Context context) {
        try {
            int n = context.getPackageManager().getPackageInfo((String)context.getPackageName(), (int)0).versionCode;
            return n;
        }
        catch (PackageManager.NameNotFoundException var1_2) {
            Log.wtf((String)"ClearcutLogger", (String)"This can't happen.");
            return 0;
        }
    }

    private static String[] zzc(ArrayList<String> arrayList) {
        if (arrayList == null) {
            return null;
        }
        return arrayList.toArray(new String[0]);
    }

    private static byte[][] zzd(ArrayList<byte[]> arrayList) {
        if (arrayList == null) {
            return null;
        }
        return (byte[][])arrayList.toArray((T[])new byte[0][]);
    }

    static /* synthetic */ int zze(zza zza2) {
        return 0;
    }

    public zza zzm(byte[] arrby) {
        return new zza(arrby);
    }

    public class zza {
        private String wd;
        private int we;
        private String wf;
        private String wg;
        private int wi;
        private final zzc wm;
        private ArrayList<Integer> wn;
        private ArrayList<String> wo;
        private ArrayList<Integer> wp;
        private ArrayList<byte[]> wq;
        private boolean wr;
        private final zzasf.zzc ws;
        private boolean wt;

        private zza(byte[] arrby) {
            this(arrby, (zzc)null);
        }

        private zza(byte[] arrby, zzc zzc2) {
            this.we = zza.this.we;
            this.wd = zza.this.wd;
            this.wf = zza.this.wf;
            this.wg = zza.this.wg;
            this.wi = zza.zze(zza.this);
            this.wn = null;
            this.wo = null;
            this.wp = null;
            this.wq = null;
            this.wr = true;
            this.ws = new zzasf.zzc();
            this.wt = false;
            this.wf = zza.this.wf;
            this.wg = zza.this.wg;
            this.ws.buh = zza.this.zzaql.currentTimeMillis();
            this.ws.bui = zza.this.zzaql.elapsedRealtime();
            this.ws.bus = zza.this.wk.zzag(this.ws.buh);
            if (arrby != null) {
                this.ws.buo = arrby;
            }
            this.wm = zzc2;
        }

        public LogEventParcelable zzaqg() {
            return new LogEventParcelable(new PlayLoggerContext(zza.this.zzcjc, zza.this.wc, this.we, this.wd, this.wf, this.wg, zza.this.wh, this.wi), this.ws, this.wm, null, zza.zzb(null), zza.zzc(null), zza.zzb(null), zza.zzd(null), this.wr);
        }

        @Deprecated
        public PendingResult<Status> zzaqh() {
            if (this.wt) {
                throw new IllegalStateException("do not reuse LogEventBuilder");
            }
            this.wt = true;
            LogEventParcelable logEventParcelable = this.zzaqg();
            PlayLoggerContext playLoggerContext = logEventParcelable.wv;
            if (zza.this.wl.zzh(playLoggerContext.aAG, playLoggerContext.aAC)) {
                return zza.this.wj.zza(logEventParcelable);
            }
            return PendingResults.immediatePendingResult(Status.xZ);
        }

        @Deprecated
        public PendingResult<Status> zze(GoogleApiClient googleApiClient) {
            return this.zzaqh();
        }

        public zza zzfl(int n) {
            this.ws.buk = n;
            return this;
        }

        public zza zzfm(int n) {
            this.ws.zzajo = n;
            return this;
        }
    }

    public static interface zzb {
        public boolean zzh(String var1, int var2);
    }

    public static interface zzc {
        public byte[] zzaqi();
    }

    public static class zzd {
        public long zzag(long l) {
            return TimeZone.getDefault().getOffset(l) / 1000;
        }
    }

}

