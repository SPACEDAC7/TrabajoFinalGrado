/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.clearcut;

import com.google.android.gms.clearcut.LogEventParcelable;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;

public interface zzb {
    public PendingResult<Status> zza(LogEventParcelable var1);
}

