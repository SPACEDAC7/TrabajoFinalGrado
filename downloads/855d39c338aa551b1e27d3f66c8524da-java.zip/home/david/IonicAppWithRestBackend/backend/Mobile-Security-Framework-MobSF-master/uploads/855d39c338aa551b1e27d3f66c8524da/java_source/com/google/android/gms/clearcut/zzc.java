/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.clearcut;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.clearcut.LogEventParcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.playlog.internal.PlayLoggerContext;

public class zzc
implements Parcelable.Creator<LogEventParcelable> {
    static void zza(LogEventParcelable logEventParcelable, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, logEventParcelable.versionCode);
        zzb.zza(parcel, 2, logEventParcelable.wv, n, false);
        zzb.zza(parcel, 3, logEventParcelable.ww, false);
        zzb.zza(parcel, 4, logEventParcelable.wx, false);
        zzb.zza(parcel, 5, logEventParcelable.wy, false);
        zzb.zza(parcel, 6, logEventParcelable.wz, false);
        zzb.zza(parcel, 7, logEventParcelable.wA, false);
        zzb.zza(parcel, 8, logEventParcelable.wB);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcc(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzfn(n);
    }

    public LogEventParcelable zzcc(Parcel parcel) {
        byte[][] arrby = null;
        int n = zza.zzcr(parcel);
        int n2 = 0;
        boolean bl = true;
        int[] arrn = null;
        String[] arrstring = null;
        int[] arrn2 = null;
        byte[] arrby2 = null;
        PlayLoggerContext playLoggerContext = null;
        block10 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block10;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block10;
                }
                case 2: {
                    playLoggerContext = zza.zza(parcel, n3, PlayLoggerContext.CREATOR);
                    continue block10;
                }
                case 3: {
                    arrby2 = zza.zzt(parcel, n3);
                    continue block10;
                }
                case 4: {
                    arrn2 = zza.zzw(parcel, n3);
                    continue block10;
                }
                case 5: {
                    arrstring = zza.zzac(parcel, n3);
                    continue block10;
                }
                case 6: {
                    arrn = zza.zzw(parcel, n3);
                    continue block10;
                }
                case 7: {
                    arrby = zza.zzu(parcel, n3);
                    continue block10;
                }
                case 8: 
            }
            bl = zza.zzc(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new LogEventParcelable(n2, playLoggerContext, arrby2, arrn2, arrstring, arrn, arrby, bl);
    }

    public LogEventParcelable[] zzfn(int n) {
        return new LogEventParcelable[n];
    }
}

