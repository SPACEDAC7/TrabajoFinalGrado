/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.FrameLayout
 */
package com.google.android.gms.common;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import com.google.android.gms.R;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.zzae;
import com.google.android.gms.common.internal.zzaf;
import com.google.android.gms.dynamic.zzg;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class SignInButton
extends FrameLayout
implements View.OnClickListener {
    public static final int COLOR_AUTO = 2;
    public static final int COLOR_DARK = 0;
    public static final int COLOR_LIGHT = 1;
    public static final int SIZE_ICON_ONLY = 2;
    public static final int SIZE_STANDARD = 0;
    public static final int SIZE_WIDE = 1;
    private int mColor;
    private int mSize;
    private View xi;
    private View.OnClickListener xj = null;

    public SignInButton(Context context) {
        this(context, null);
    }

    public SignInButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public SignInButton(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.zzb(context, attributeSet);
        this.setStyle(this.mSize, this.mColor);
    }

    private static Button zza(Context context, int n, int n2) {
        zzaf zzaf2 = new zzaf(context);
        zzaf2.zza(context.getResources(), n, n2);
        return zzaf2;
    }

    private void zzb(Context context, AttributeSet attributeSet) {
        context = context.getTheme().obtainStyledAttributes(attributeSet, R.styleable.SignInButton, 0, 0);
        try {
            this.mSize = context.getInt(R.styleable.SignInButton_buttonSize, 0);
            this.mColor = context.getInt(R.styleable.SignInButton_colorScheme, 2);
            return;
        }
        finally {
            context.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void zzbw(Context context) {
        if (this.xi != null) {
            this.removeView(this.xi);
        }
        try {
            this.xi = zzae.zzb(context, this.mSize, this.mColor);
        }
        catch (zzg.zza var2_2) {
            Log.w((String)"SignInButton", (String)"Sign in button not found, using placeholder instead");
            this.xi = SignInButton.zza(context, this.mSize, this.mColor);
        }
        this.addView(this.xi);
        this.xi.setEnabled(this.isEnabled());
        this.xi.setOnClickListener((View.OnClickListener)this);
    }

    public void onClick(View view) {
        if (this.xj != null && view == this.xi) {
            this.xj.onClick((View)this);
        }
    }

    public void setColorScheme(int n) {
        this.setStyle(this.mSize, n);
    }

    public void setEnabled(boolean bl) {
        super.setEnabled(bl);
        this.xi.setEnabled(bl);
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.xj = onClickListener;
        if (this.xi != null) {
            this.xi.setOnClickListener((View.OnClickListener)this);
        }
    }

    @Deprecated
    public void setScopes(Scope[] arrscope) {
        this.setStyle(this.mSize, this.mColor);
    }

    public void setSize(int n) {
        this.setStyle(n, this.mColor);
    }

    public void setStyle(int n, int n2) {
        this.mSize = n;
        this.mColor = n2;
        this.zzbw(this.getContext());
    }

    @Deprecated
    public void setStyle(int n, int n2, Scope[] arrscope) {
        this.setStyle(n, n2);
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface ButtonSize {
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface ColorScheme {
    }

}

