/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Looper
 */
package com.google.android.gms.common.api;

import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.support.annotation.Nullable;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.internal.zze;
import com.google.android.gms.common.internal.zzp;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public final class Api<O extends ApiOptions> {
    private final String mName;
    private final zza<?, O> xk;
    private final zzh<?, O> xl;
    private final zzf<?> xm;
    private final zzi<?> xn;

    public <C extends zze> Api(String string2, zza<C, O> zza2, zzf<C> zzf2) {
        zzaa.zzb(zza2, (Object)"Cannot construct an Api with a null ClientBuilder");
        zzaa.zzb(zzf2, (Object)"Cannot construct an Api with a null ClientKey");
        this.mName = string2;
        this.xk = zza2;
        this.xl = null;
        this.xm = zzf2;
        this.xn = null;
    }

    public String getName() {
        return this.mName;
    }

    public zzd<?, O> zzaqs() {
        if (this.zzaqw()) {
            return null;
        }
        return this.xk;
    }

    /*
     * Enabled aggressive block sorting
     */
    public zza<?, O> zzaqt() {
        boolean bl = this.xk != null;
        zzaa.zza(bl, (Object)"This API was constructed with a SimpleClientBuilder. Use getSimpleClientBuilder");
        return this.xk;
    }

    public zzh<?, O> zzaqu() {
        zzaa.zza(false, (Object)"This API was constructed with a ClientBuilder. Use getClientBuilder");
        return null;
    }

    public zzc<?> zzaqv() {
        if (this.xm != null) {
            return this.xm;
        }
        throw new IllegalStateException("This API was constructed with null client keys. This should not be possible.");
    }

    public boolean zzaqw() {
        return false;
    }

    public static interface ApiOptions {

        public static interface HasOptions
        extends ApiOptions {
        }

        public static final class NoOptions
        implements NotRequiredOptions {
            private NoOptions() {
            }
        }

        public static interface NotRequiredOptions
        extends ApiOptions {
        }

        public static interface Optional
        extends HasOptions,
        NotRequiredOptions {
        }

    }

    public static abstract class zza<T extends zze, O>
    extends zzd<T, O> {
        public abstract T zza(Context var1, Looper var2, com.google.android.gms.common.internal.zzf var3, O var4, GoogleApiClient.ConnectionCallbacks var5, GoogleApiClient.OnConnectionFailedListener var6);
    }

    public static interface zzb {
    }

    public static class zzc<C extends zzb> {
    }

    public static abstract class zzd<T extends zzb, O> {
        public int getPriority() {
            return Integer.MAX_VALUE;
        }

        public List<Scope> zzp(O o) {
            return Collections.emptyList();
        }
    }

    public static interface zze
    extends zzb {
        public void disconnect();

        public void dump(String var1, FileDescriptor var2, PrintWriter var3, String[] var4);

        public boolean isConnected();

        public boolean isConnecting();

        public void zza(zze.zzf var1);

        public void zza(zzp var1, Set<Scope> var2);

        public boolean zzain();

        public boolean zzajc();

        public Intent zzajd();

        public boolean zzaqx();

        @Nullable
        public IBinder zzaqy();
    }

    public static final class zzf<C extends zze>
    extends zzc<C> {
    }

    public static interface zzg<T extends IInterface>
    extends zzb {
        public void zza(int var1, T var2);

        public T zzh(IBinder var1);

        public String zzjx();

        public String zzjy();
    }

    public static abstract class zzh<T extends zzg, O>
    extends zzd<T, O> {
        public abstract int zzaqz();

        public abstract T zzr(O var1);
    }

    public static final class zzi<C extends zzg>
    extends zzc<C> {
    }

}

