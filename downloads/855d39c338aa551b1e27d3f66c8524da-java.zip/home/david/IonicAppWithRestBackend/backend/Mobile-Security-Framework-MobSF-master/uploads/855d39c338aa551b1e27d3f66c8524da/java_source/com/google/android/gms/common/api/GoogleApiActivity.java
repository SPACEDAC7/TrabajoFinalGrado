/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.Intent
 *  android.content.IntentSender
 *  android.content.IntentSender$SendIntentException
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.util.Log
 */
package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.internal.zzrh;

public class GoogleApiActivity
extends Activity
implements DialogInterface.OnCancelListener {
    protected int xD = 0;

    public static PendingIntent zza(Context context, PendingIntent pendingIntent, int n) {
        return GoogleApiActivity.zza(context, pendingIntent, n, true);
    }

    public static PendingIntent zza(Context context, PendingIntent pendingIntent, int n, boolean bl) {
        return PendingIntent.getActivity((Context)context, (int)0, (Intent)GoogleApiActivity.zzb(context, pendingIntent, n, bl), (int)134217728);
    }

    private void zza(int n, zzrh zzrh2) {
        switch (n) {
            default: {
                return;
            }
            case 0: {
                zzrh2.zza(new ConnectionResult(13, null), this.getIntent().getIntExtra("failing_client_id", -1));
                return;
            }
            case -1: 
        }
        zzrh2.zzarm();
    }

    private void zzarb() {
        Object object = this.getIntent().getExtras();
        if (object == null) {
            Log.e((String)"GoogleApiActivity", (String)"Activity started without extras");
            this.finish();
            return;
        }
        PendingIntent pendingIntent = (PendingIntent)object.get("pending_intent");
        object = (Integer)object.get("error_code");
        if (pendingIntent == null && object == null) {
            Log.e((String)"GoogleApiActivity", (String)"Activity started without resolution");
            this.finish();
            return;
        }
        if (pendingIntent != null) {
            try {
                this.startIntentSenderForResult(pendingIntent.getIntentSender(), 1, null, 0, 0, 0);
                this.xD = 1;
                return;
            }
            catch (IntentSender.SendIntentException var1_3) {
                Log.e((String)"GoogleApiActivity", (String)"Failed to launch pendingIntent", (Throwable)var1_3);
                this.finish();
                return;
            }
        }
        GoogleApiAvailability.getInstance().showErrorDialogFragment(this, object.intValue(), 2, this);
        this.xD = 1;
    }

    public static Intent zzb(Context context, PendingIntent pendingIntent, int n, boolean bl) {
        context = new Intent(context, (Class)GoogleApiActivity.class);
        context.putExtra("pending_intent", (Parcelable)pendingIntent);
        context.putExtra("failing_client_id", n);
        context.putExtra("notify_manager", bl);
        return context;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
        if (n == 1) {
            boolean bl = this.getIntent().getBooleanExtra("notify_manager", true);
            this.xD = 0;
            this.setResultCode(n2);
            if (bl) {
                this.zza(n2, zzrh.zzbx((Context)this));
            }
        } else if (n == 2) {
            this.xD = 0;
            this.setResultCode(n2);
        }
        this.finish();
    }

    public void onCancel(DialogInterface dialogInterface) {
        this.xD = 0;
        this.setResult(0);
        this.finish();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle != null) {
            this.xD = bundle.getInt("resolution");
        }
        if (this.xD != 1) {
            this.zzarb();
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        bundle.putInt("resolution", this.xD);
        super.onSaveInstanceState(bundle);
    }

    protected void setResultCode(int n) {
        this.setResult(n);
    }
}

