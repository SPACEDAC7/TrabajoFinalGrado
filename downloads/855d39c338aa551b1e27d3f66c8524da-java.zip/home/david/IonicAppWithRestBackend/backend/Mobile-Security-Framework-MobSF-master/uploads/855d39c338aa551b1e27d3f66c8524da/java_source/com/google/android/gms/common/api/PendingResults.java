/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Looper
 */
package com.google.android.gms.common.api;

import android.os.Looper;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.OptionalPendingResult;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzqq;
import com.google.android.gms.internal.zzru;
import com.google.android.gms.internal.zzsc;

public final class PendingResults {
    private PendingResults() {
    }

    public static PendingResult<Status> canceledPendingResult() {
        zzsc zzsc2 = new zzsc(Looper.getMainLooper());
        zzsc2.cancel();
        return zzsc2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static <R extends Result> PendingResult<R> canceledPendingResult(R zza2) {
        zzaa.zzb(zza2, (Object)"Result must not be null");
        boolean bl = zza2.getStatus().getStatusCode() == 16;
        zzaa.zzb(bl, (Object)"Status code must be CommonStatusCodes.CANCELED");
        zza2 = new zza<zza<Object>>(zza2);
        zza2.cancel();
        return zza2;
    }

    public static <R extends Result> OptionalPendingResult<R> immediatePendingResult(R r) {
        zzaa.zzb(r, (Object)"Result must not be null");
        zzc<R> zzc2 = new zzc<R>(null);
        zzc2.zzc(r);
        return new zzru(zzc2);
    }

    public static PendingResult<Status> immediatePendingResult(Status status) {
        zzaa.zzb(status, (Object)"Result must not be null");
        zzsc zzsc2 = new zzsc(Looper.getMainLooper());
        zzsc2.zzc(status);
        return zzsc2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static <R extends Result> PendingResult<R> zza(R r, GoogleApiClient zzb2) {
        zzaa.zzb(r, (Object)"Result must not be null");
        boolean bl = !r.getStatus().isSuccess();
        zzaa.zzb(bl, (Object)"Status code must not be SUCCESS");
        zzb2 = new zzb<R>((GoogleApiClient)((Object)zzb2), r);
        zzb2.zzc(r);
        return zzb2;
    }

    public static PendingResult<Status> zza(Status status, GoogleApiClient object) {
        zzaa.zzb(status, (Object)"Result must not be null");
        object = new zzsc((GoogleApiClient)object);
        object.zzc(status);
        return object;
    }

    public static <R extends Result> OptionalPendingResult<R> zzb(R r, GoogleApiClient object) {
        zzaa.zzb(r, (Object)"Result must not be null");
        object = new zzc((GoogleApiClient)object);
        object.zzc(r);
        return new zzru(object);
    }

    private static final class zza<R extends Result>
    extends zzqq<R> {
        private final R xU;

        public zza(R r) {
            super(Looper.getMainLooper());
            this.xU = r;
        }

        @Override
        protected R zzc(Status status) {
            if (status.getStatusCode() != this.xU.getStatus().getStatusCode()) {
                throw new UnsupportedOperationException("Creating failed results is not supported");
            }
            return this.xU;
        }
    }

    private static final class zzb<R extends Result>
    extends zzqq<R> {
        private final R xV;

        public zzb(GoogleApiClient googleApiClient, R r) {
            super(googleApiClient);
            this.xV = r;
        }

        @Override
        protected R zzc(Status status) {
            return this.xV;
        }
    }

    private static final class zzc<R extends Result>
    extends zzqq<R> {
        public zzc(GoogleApiClient googleApiClient) {
            super(googleApiClient);
        }

        @Override
        protected R zzc(Status status) {
            throw new UnsupportedOperationException("Creating failed results is not supported");
        }
    }

}

