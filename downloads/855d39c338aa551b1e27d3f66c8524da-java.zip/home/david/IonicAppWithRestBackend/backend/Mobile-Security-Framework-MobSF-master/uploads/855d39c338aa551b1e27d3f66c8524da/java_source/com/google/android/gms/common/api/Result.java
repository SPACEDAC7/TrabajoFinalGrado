/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import com.google.android.gms.common.api.Status;

public interface Result {
    public Status getStatus();
}

