/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import android.support.annotation.NonNull;
import com.google.android.gms.common.api.Status;

public class zza
extends Exception {
    protected final Status hv;

    public zza(@NonNull Status status) {
        super(status.getStatusMessage());
        this.hv = status;
    }
}

