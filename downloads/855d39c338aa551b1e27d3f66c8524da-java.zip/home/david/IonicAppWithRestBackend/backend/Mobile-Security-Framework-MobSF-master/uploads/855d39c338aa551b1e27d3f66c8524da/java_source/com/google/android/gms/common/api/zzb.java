/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import android.support.v4.util.ArrayMap;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.zzx;
import com.google.android.gms.internal.zzql;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

public class zzb
extends Exception {
    private final ArrayMap<zzql<?>, ConnectionResult> xo;

    public zzb(ArrayMap<zzql<?>, ConnectionResult> arrayMap) {
        this.xo = arrayMap;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public String getMessage() {
        ArrayList<String> arrayList = new ArrayList<String>();
        Object object = this.xo.keySet().iterator();
        boolean bl = true;
        while (object.hasNext()) {
            zzql zzql2 = object.next();
            Object object2 = this.xo.get(zzql2);
            if (object2.isSuccess()) {
                bl = false;
            }
            zzql2 = String.valueOf(zzql2.zzarl());
            object2 = String.valueOf(object2);
            arrayList.add(new StringBuilder(String.valueOf(zzql2).length() + 2 + String.valueOf(object2).length()).append((String)((Object)zzql2)).append(": ").append((String)object2).toString());
        }
        object = new StringBuilder();
        if (bl) {
            object.append("None of the queried APIs are available. ");
        } else {
            object.append("Some of the queried APIs are unavailable. ");
        }
        zzx.zzia("; ").zza((StringBuilder)object, arrayList);
        return object.toString();
    }

    public ArrayMap<zzql<?>, ConnectionResult> zzara() {
        return this.xo;
    }
}

