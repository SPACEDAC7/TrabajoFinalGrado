/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzf
implements Parcelable.Creator<Scope> {
    static void zza(Scope scope, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, scope.mVersionCode);
        zzb.zza(parcel, 2, scope.zzari(), false);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzce(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzfq(n);
    }

    public Scope zzce(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        String string2 = null;
        block4 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block4;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block4;
                }
                case 2: 
            }
            string2 = zza.zzq(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new Scope(n2, string2);
    }

    public Scope[] zzfq(int n) {
        return new Scope[n];
    }
}

