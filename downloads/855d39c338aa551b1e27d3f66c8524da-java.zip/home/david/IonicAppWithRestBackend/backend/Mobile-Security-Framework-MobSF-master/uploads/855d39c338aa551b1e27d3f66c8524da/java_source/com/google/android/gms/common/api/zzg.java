/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzg
implements Parcelable.Creator<Status> {
    static void zza(Status status, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, status.getStatusCode());
        zzb.zza(parcel, 2, status.getStatusMessage(), false);
        zzb.zza(parcel, 3, (Parcelable)status.zzarj(), n, false);
        zzb.zzc(parcel, 1000, status.mVersionCode);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcf(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzfr(n);
    }

    public Status zzcf(Parcel parcel) {
        PendingIntent pendingIntent = null;
        int n = 0;
        int n2 = zza.zzcr(parcel);
        String string2 = null;
        int n3 = 0;
        block6 : while (parcel.dataPosition() < n2) {
            int n4 = zza.zzcq(parcel);
            switch (zza.zzgu(n4)) {
                default: {
                    zza.zzb(parcel, n4);
                    continue block6;
                }
                case 1: {
                    n = zza.zzg(parcel, n4);
                    continue block6;
                }
                case 2: {
                    string2 = zza.zzq(parcel, n4);
                    continue block6;
                }
                case 3: {
                    pendingIntent = (PendingIntent)zza.zza(parcel, n4, PendingIntent.CREATOR);
                    continue block6;
                }
                case 1000: 
            }
            n3 = zza.zzg(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new Status(n3, n, string2, pendingIntent);
    }

    public Status[] zzfr(int n) {
        return new Status[n];
    }
}

