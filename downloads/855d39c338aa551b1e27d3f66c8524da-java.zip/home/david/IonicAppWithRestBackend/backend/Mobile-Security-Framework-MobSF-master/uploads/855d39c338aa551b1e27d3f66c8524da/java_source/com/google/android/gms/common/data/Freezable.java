/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.data;

public interface Freezable<T> {
    public T freeze();

    public boolean isDataValid();
}

