/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.data;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.internal.zzaa;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class zzb<T>
implements Iterator<T> {
    protected final DataBuffer<T> BR;
    protected int BS;

    public zzb(DataBuffer<T> dataBuffer) {
        this.BR = zzaa.zzy(dataBuffer);
        this.BS = -1;
    }

    @Override
    public boolean hasNext() {
        if (this.BS < this.BR.getCount() - 1) {
            return true;
        }
        return false;
    }

    @Override
    public T next() {
        int n;
        if (!this.hasNext()) {
            int n2 = this.BS;
            throw new NoSuchElementException(new StringBuilder(46).append("Cannot advance the iterator beyond ").append(n2).toString());
        }
        DataBuffer<T> dataBuffer = this.BR;
        this.BS = n = this.BS + 1;
        return dataBuffer.get(n);
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("Cannot remove elements from a DataBufferIterator");
    }
}

