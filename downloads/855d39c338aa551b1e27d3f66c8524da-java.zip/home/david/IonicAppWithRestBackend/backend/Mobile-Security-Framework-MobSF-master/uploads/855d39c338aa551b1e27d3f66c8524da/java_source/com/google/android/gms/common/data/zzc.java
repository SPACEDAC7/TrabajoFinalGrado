/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.database.CharArrayBuffer
 *  android.net.Uri
 */
package com.google.android.gms.common.data;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.internal.zzz;

public abstract class zzc {
    protected int BU;
    private int BV;
    protected final DataHolder zy;

    public zzc(DataHolder dataHolder, int n) {
        this.zy = zzaa.zzy(dataHolder);
        this.zzfy(n);
    }

    public boolean equals(Object object) {
        boolean bl;
        boolean bl2 = bl = false;
        if (object instanceof zzc) {
            object = (zzc)object;
            bl2 = bl;
            if (zzz.equal(object.BU, this.BU)) {
                bl2 = bl;
                if (zzz.equal(object.BV, this.BV)) {
                    bl2 = bl;
                    if (object.zy == this.zy) {
                        bl2 = true;
                    }
                }
            }
        }
        return bl2;
    }

    protected boolean getBoolean(String string2) {
        return this.zy.zze(string2, this.BU, this.BV);
    }

    protected byte[] getByteArray(String string2) {
        return this.zy.zzg(string2, this.BU, this.BV);
    }

    protected float getFloat(String string2) {
        return this.zy.zzf(string2, this.BU, this.BV);
    }

    protected int getInteger(String string2) {
        return this.zy.zzc(string2, this.BU, this.BV);
    }

    protected long getLong(String string2) {
        return this.zy.zzb(string2, this.BU, this.BV);
    }

    protected String getString(String string2) {
        return this.zy.zzd(string2, this.BU, this.BV);
    }

    public int hashCode() {
        return zzz.hashCode(this.BU, this.BV, this.zy);
    }

    public boolean isDataValid() {
        if (!this.zy.isClosed()) {
            return true;
        }
        return false;
    }

    protected void zza(String string2, CharArrayBuffer charArrayBuffer) {
        this.zy.zza(string2, this.BU, this.BV, charArrayBuffer);
    }

    protected int zzaul() {
        return this.BU;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void zzfy(int n) {
        boolean bl = n >= 0 && n < this.zy.getCount();
        zzaa.zzbs(bl);
        this.BU = n;
        this.BV = this.zy.zzga(this.BU);
    }

    public boolean zzho(String string2) {
        return this.zy.zzho(string2);
    }

    protected Uri zzhp(String string2) {
        return this.zy.zzh(string2, this.BU, this.BV);
    }

    protected boolean zzhq(String string2) {
        return this.zy.zzi(string2, this.BU, this.BV);
    }
}

