/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.database.CursorWindow
 *  android.os.Bundle
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.data;

import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zze
implements Parcelable.Creator<DataHolder> {
    static void zza(DataHolder dataHolder, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zza(parcel, 1, dataHolder.zzauo(), false);
        zzb.zza((Parcel)parcel, (int)2, (Parcelable[])dataHolder.zzaup(), (int)n, (boolean)false);
        zzb.zzc(parcel, 3, dataHolder.getStatusCode());
        zzb.zza(parcel, 4, dataHolder.zzaui(), false);
        zzb.zzc(parcel, 1000, dataHolder.mVersionCode);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzch(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgd(n);
    }

    public DataHolder zzch(Parcel object) {
        int n = 0;
        Bundle bundle = null;
        int n2 = zza.zzcr((Parcel)object);
        CursorWindow[] arrcursorWindow = null;
        String[] arrstring = null;
        int n3 = 0;
        block7 : while (object.dataPosition() < n2) {
            int n4 = zza.zzcq((Parcel)object);
            switch (zza.zzgu(n4)) {
                default: {
                    zza.zzb((Parcel)object, n4);
                    continue block7;
                }
                case 1: {
                    arrstring = zza.zzac((Parcel)object, n4);
                    continue block7;
                }
                case 2: {
                    arrcursorWindow = (CursorWindow[])zza.zzb((Parcel)object, n4, CursorWindow.CREATOR);
                    continue block7;
                }
                case 3: {
                    n = zza.zzg((Parcel)object, n4);
                    continue block7;
                }
                case 4: {
                    bundle = zza.zzs((Parcel)object, n4);
                    continue block7;
                }
                case 1000: 
            }
            n3 = zza.zzg((Parcel)object, n4);
        }
        if (object.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), (Parcel)object);
        }
        object = new DataHolder(n3, arrstring, arrcursorWindow, n, bundle);
        object.zzaun();
        return object;
    }

    public DataHolder[] zzgd(int n) {
        return new DataHolder[n];
    }
}

