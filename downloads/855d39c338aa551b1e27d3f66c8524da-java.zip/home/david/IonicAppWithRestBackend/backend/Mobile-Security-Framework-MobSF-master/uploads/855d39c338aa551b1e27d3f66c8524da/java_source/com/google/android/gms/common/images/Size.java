/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.images;

public final class Size {
    private final int zzakh;
    private final int zzaki;

    public Size(int n, int n2) {
        this.zzakh = n;
        this.zzaki = n2;
    }

    public static Size parseSize(String string2) throws NumberFormatException {
        int n;
        if (string2 == null) {
            throw new IllegalArgumentException("string must not be null");
        }
        int n2 = n = string2.indexOf(42);
        if (n < 0) {
            n2 = string2.indexOf(120);
        }
        if (n2 < 0) {
            throw Size.zzhr(string2);
        }
        try {
            Size size = new Size(Integer.parseInt(string2.substring(0, n2)), Integer.parseInt(string2.substring(n2 + 1)));
            return size;
        }
        catch (NumberFormatException var3_4) {
            throw Size.zzhr(string2);
        }
    }

    private static NumberFormatException zzhr(String string2) {
        throw new NumberFormatException(new StringBuilder(String.valueOf(string2).length() + 16).append("Invalid Size: \"").append(string2).append("\"").toString());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl = true;
        if (object == null) {
            return false;
        }
        if (this == object) {
            return true;
        }
        if (!(object instanceof Size)) return false;
        object = (Size)object;
        if (this.zzakh != object.zzakh) return false;
        if (this.zzaki != object.zzaki) return false;
        return bl;
    }

    public int getHeight() {
        return this.zzaki;
    }

    public int getWidth() {
        return this.zzakh;
    }

    public int hashCode() {
        return this.zzaki ^ (this.zzakh << 16 | this.zzakh >>> 16);
    }

    public String toString() {
        int n = this.zzakh;
        int n2 = this.zzaki;
        return new StringBuilder(23).append(n).append("x").append(n2).toString();
    }
}

