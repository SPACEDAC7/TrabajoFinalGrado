/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  android.widget.ImageView
 */
package com.google.android.gms.common.images;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.ImageView;
import com.google.android.gms.common.images.ImageManager;
import com.google.android.gms.common.internal.zzz;
import com.google.android.gms.internal.zzsj;
import com.google.android.gms.internal.zzsk;
import com.google.android.gms.internal.zzsl;
import java.lang.ref.WeakReference;

public abstract class zza {
    final zza CD;
    protected int CE = 0;
    protected int CF = 0;
    protected boolean CG = false;
    private boolean CH = true;
    private boolean CI = false;
    private boolean CJ = true;

    public zza(Uri uri, int n) {
        this.CD = new zza(uri);
        this.CF = n;
    }

    private Drawable zza(Context context, zzsl zzsl2, int n) {
        return context.getResources().getDrawable(n);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected zzsj zza(Drawable drawable2, Drawable drawable3) {
        Drawable drawable4;
        if (drawable2 != null) {
            drawable4 = drawable2;
            if (drawable2 instanceof zzsj) {
                drawable4 = ((zzsj)drawable2).zzauw();
            }
            do {
                return new zzsj(drawable4, drawable3);
                break;
            } while (true);
        }
        drawable4 = null;
        return new zzsj(drawable4, drawable3);
    }

    void zza(Context context, Bitmap bitmap, boolean bl) {
        com.google.android.gms.common.internal.zzc.zzu((Object)bitmap);
        this.zza((Drawable)new BitmapDrawable(context.getResources(), bitmap), bl, false, true);
    }

    void zza(Context context, zzsl zzsl2) {
        if (this.CJ) {
            this.zza(null, false, true, false);
        }
    }

    void zza(Context context, zzsl zzsl2, boolean bl) {
        Drawable drawable2 = null;
        if (this.CF != 0) {
            drawable2 = this.zza(context, zzsl2, this.CF);
        }
        this.zza(drawable2, bl, false, false);
    }

    protected abstract void zza(Drawable var1, boolean var2, boolean var3, boolean var4);

    protected boolean zzc(boolean bl, boolean bl2) {
        if (!this.CH || bl2 || bl) {
            return false;
        }
        return true;
    }

    public void zzgg(int n) {
        this.CF = n;
    }

    static final class zza {
        public final Uri uri;

        public zza(Uri uri) {
            this.uri = uri;
        }

        public boolean equals(Object object) {
            if (!(object instanceof zza)) {
                return false;
            }
            if (this == object) {
                return true;
            }
            return zzz.equal((Object)((zza)object).uri, (Object)this.uri);
        }

        public int hashCode() {
            return zzz.hashCode(new Object[]{this.uri});
        }
    }

    public static final class zzb
    extends zza {
        private WeakReference<ImageView> CK;

        public zzb(ImageView imageView, int n) {
            super(null, n);
            com.google.android.gms.common.internal.zzc.zzu((Object)imageView);
            this.CK = new WeakReference<ImageView>(imageView);
        }

        public zzb(ImageView imageView, Uri uri) {
            super(uri, 0);
            com.google.android.gms.common.internal.zzc.zzu((Object)imageView);
            this.CK = new WeakReference<ImageView>(imageView);
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        private void zza(ImageView imageView, Drawable drawable2, boolean bl, boolean bl2, boolean bl3) {
            int n = !bl2 && !bl3 ? 1 : 0;
            if (n != 0 && imageView instanceof zzsk) {
                int n2 = ((zzsk)imageView).zzauy();
                if (this.CF != 0 && n2 == this.CF) {
                    return;
                }
            }
            if (bl = this.zzc(bl, bl2)) {
                drawable2 = this.zza(imageView.getDrawable(), drawable2);
            }
            imageView.setImageDrawable(drawable2);
            if (imageView instanceof zzsk) {
                zzsk zzsk2 = (zzsk)imageView;
                imageView = bl3 ? this.CD.uri : null;
                zzsk2.zzr((Uri)imageView);
                n = n != 0 ? this.CF : 0;
                zzsk2.zzgi(n);
            }
            if (!bl) return;
            ((zzsj)drawable2).startTransition(250);
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean equals(Object object) {
            if (!(object instanceof zzb)) {
                return false;
            }
            if (this == object) {
                return true;
            }
            zzb zzb2 = (zzb)object;
            object = this.CK.get();
            zzb2 = zzb2.CK.get();
            if (zzb2 == null) return false;
            if (object == null) return false;
            if (!zzz.equal(zzb2, object)) return false;
            return true;
        }

        public int hashCode() {
            return 0;
        }

        @Override
        protected void zza(Drawable drawable2, boolean bl, boolean bl2, boolean bl3) {
            ImageView imageView = this.CK.get();
            if (imageView != null) {
                this.zza(imageView, drawable2, bl, bl2, bl3);
            }
        }
    }

    public static final class zzc
    extends zza {
        private WeakReference<ImageManager.OnImageLoadedListener> CL;

        public zzc(ImageManager.OnImageLoadedListener onImageLoadedListener, Uri uri) {
            super(uri, 0);
            com.google.android.gms.common.internal.zzc.zzu(onImageLoadedListener);
            this.CL = new WeakReference<ImageManager.OnImageLoadedListener>(onImageLoadedListener);
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean equals(Object object) {
            if (!(object instanceof zzc)) {
                return false;
            }
            if (this == object) {
                return true;
            }
            object = (zzc)object;
            ImageManager.OnImageLoadedListener onImageLoadedListener = this.CL.get();
            ImageManager.OnImageLoadedListener onImageLoadedListener2 = object.CL.get();
            if (onImageLoadedListener2 == null) return false;
            if (onImageLoadedListener == null) return false;
            if (!zzz.equal(onImageLoadedListener2, onImageLoadedListener)) return false;
            if (!zzz.equal(object.CD, this.CD)) return false;
            return true;
        }

        public int hashCode() {
            return zzz.hashCode(this.CD);
        }

        @Override
        protected void zza(Drawable drawable2, boolean bl, boolean bl2, boolean bl3) {
            ImageManager.OnImageLoadedListener onImageLoadedListener;
            if (!bl2 && (onImageLoadedListener = this.CL.get()) != null) {
                onImageLoadedListener.onImageLoaded(this.CD.uri, drawable2, bl3);
            }
        }
    }

}

