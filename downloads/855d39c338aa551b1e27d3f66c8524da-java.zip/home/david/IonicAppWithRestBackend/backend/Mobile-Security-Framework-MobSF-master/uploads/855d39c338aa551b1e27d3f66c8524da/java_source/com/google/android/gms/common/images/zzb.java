/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.images;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zzb
implements Parcelable.Creator<WebImage> {
    static void zza(WebImage webImage, Parcel parcel, int n) {
        int n2 = com.google.android.gms.common.internal.safeparcel.zzb.zzcs(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1, webImage.mVersionCode);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 2, (Parcelable)webImage.getUrl(), n, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 3, webImage.getWidth());
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 4, webImage.getHeight());
        com.google.android.gms.common.internal.safeparcel.zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzci(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgh(n);
    }

    public WebImage zzci(Parcel parcel) {
        int n = 0;
        int n2 = zza.zzcr(parcel);
        Uri uri = null;
        int n3 = 0;
        int n4 = 0;
        block6 : while (parcel.dataPosition() < n2) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block6;
                }
                case 1: {
                    n4 = zza.zzg(parcel, n5);
                    continue block6;
                }
                case 2: {
                    uri = (Uri)zza.zza(parcel, n5, Uri.CREATOR);
                    continue block6;
                }
                case 3: {
                    n3 = zza.zzg(parcel, n5);
                    continue block6;
                }
                case 4: 
            }
            n = zza.zzg(parcel, n5);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new WebImage(n4, uri, n3, n);
    }

    public WebImage[] zzgh(int n) {
        return new WebImage[n];
    }
}

