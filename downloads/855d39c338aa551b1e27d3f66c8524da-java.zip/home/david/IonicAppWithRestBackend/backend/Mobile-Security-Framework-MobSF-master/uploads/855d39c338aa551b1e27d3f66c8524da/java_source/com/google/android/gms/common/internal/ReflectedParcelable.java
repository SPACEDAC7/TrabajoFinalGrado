/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcelable
 */
package com.google.android.gms.common.internal;

import android.os.Parcelable;

public interface ReflectedParcelable
extends Parcelable {
}

