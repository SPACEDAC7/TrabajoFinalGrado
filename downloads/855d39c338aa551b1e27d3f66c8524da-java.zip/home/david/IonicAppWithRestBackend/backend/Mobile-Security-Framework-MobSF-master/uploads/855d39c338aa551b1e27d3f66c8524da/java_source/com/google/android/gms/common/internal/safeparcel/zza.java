/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.internal.safeparcel;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class zza {
    public static int zza(Parcel parcel, int n) {
        if ((n & -65536) != -65536) {
            return n >> 16 & 65535;
        }
        return parcel.readInt();
    }

    public static <T extends Parcelable> T zza(Parcel parcel, int n, Parcelable.Creator<T> parcelable) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        parcelable = (Parcelable)parcelable.createFromParcel(parcel);
        parcel.setDataPosition(n + n2);
        return (T)parcelable;
    }

    private static void zza(Parcel parcel, int n, int n2) {
        if ((n = zza.zza(parcel, n)) != n2) {
            String string2 = String.valueOf(Integer.toHexString(n));
            throw new zza(new StringBuilder(String.valueOf(string2).length() + 46).append("Expected size ").append(n2).append(" got ").append(n).append(" (0x").append(string2).append(")").toString(), parcel);
        }
    }

    private static void zza(Parcel parcel, int n, int n2, int n3) {
        if (n2 != n3) {
            String string2 = String.valueOf(Integer.toHexString(n2));
            throw new zza(new StringBuilder(String.valueOf(string2).length() + 46).append("Expected size ").append(n3).append(" got ").append(n2).append(" (0x").append(string2).append(")").toString(), parcel);
        }
    }

    public static void zza(Parcel parcel, int n, List list, ClassLoader classLoader) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return;
        }
        parcel.readList(list, classLoader);
        parcel.setDataPosition(n + n2);
    }

    public static double[] zzaa(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        double[] arrd = parcel.createDoubleArray();
        parcel.setDataPosition(n + n2);
        return arrd;
    }

    public static BigDecimal[] zzab(Parcel parcel, int n) {
        int n2 = zza.zza(parcel, n);
        int n3 = parcel.dataPosition();
        if (n2 == 0) {
            return null;
        }
        int n4 = parcel.readInt();
        BigDecimal[] arrbigDecimal = new BigDecimal[n4];
        for (n = 0; n < n4; ++n) {
            byte[] arrby = parcel.createByteArray();
            int n5 = parcel.readInt();
            arrbigDecimal[n] = new BigDecimal(new BigInteger(arrby), n5);
        }
        parcel.setDataPosition(n3 + n2);
        return arrbigDecimal;
    }

    public static String[] zzac(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        String[] arrstring = parcel.createStringArray();
        parcel.setDataPosition(n + n2);
        return arrstring;
    }

    public static ArrayList<Integer> zzad(Parcel parcel, int n) {
        int n2 = zza.zza(parcel, n);
        int n3 = parcel.dataPosition();
        if (n2 == 0) {
            return null;
        }
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        int n4 = parcel.readInt();
        for (n = 0; n < n4; ++n) {
            arrayList.add(parcel.readInt());
        }
        parcel.setDataPosition(n3 + n2);
        return arrayList;
    }

    public static ArrayList<String> zzae(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        ArrayList arrayList = parcel.createStringArrayList();
        parcel.setDataPosition(n + n2);
        return arrayList;
    }

    public static Parcel zzaf(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        Parcel parcel2 = Parcel.obtain();
        parcel2.appendFrom(parcel, n2, n);
        parcel.setDataPosition(n + n2);
        return parcel2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Parcel[] zzag(Parcel parcel, int n) {
        int n2 = zza.zza(parcel, n);
        int n3 = parcel.dataPosition();
        if (n2 == 0) {
            return null;
        }
        int n4 = parcel.readInt();
        Parcel[] arrparcel = new Parcel[n4];
        n = 0;
        do {
            if (n >= n4) {
                parcel.setDataPosition(n3 + n2);
                return arrparcel;
            }
            int n5 = parcel.readInt();
            if (n5 != 0) {
                int n6 = parcel.dataPosition();
                Parcel parcel2 = Parcel.obtain();
                parcel2.appendFrom(parcel, n6, n5);
                arrparcel[n] = parcel2;
                parcel.setDataPosition(n5 + n6);
            } else {
                arrparcel[n] = null;
            }
            ++n;
        } while (true);
    }

    public static void zzb(Parcel parcel, int n) {
        parcel.setDataPosition(zza.zza(parcel, n) + parcel.dataPosition());
    }

    public static <T> T[] zzb(Parcel parcel, int n, Parcelable.Creator<T> arrobject) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        arrobject = parcel.createTypedArray(arrobject);
        parcel.setDataPosition(n + n2);
        return arrobject;
    }

    public static <T> ArrayList<T> zzc(Parcel parcel, int n, Parcelable.Creator<T> object) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        object = parcel.createTypedArrayList(object);
        parcel.setDataPosition(n + n2);
        return object;
    }

    public static boolean zzc(Parcel parcel, int n) {
        zza.zza(parcel, n, 4);
        if (parcel.readInt() != 0) {
            return true;
        }
        return false;
    }

    public static int zzcq(Parcel parcel) {
        return parcel.readInt();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int zzcr(Parcel parcel) {
        int n = zza.zzcq(parcel);
        int n2 = zza.zza(parcel, n);
        int n3 = parcel.dataPosition();
        if (zza.zzgu(n) != 20293) {
            String string2 = String.valueOf(Integer.toHexString(n));
            if (string2.length() != 0) {
                string2 = "Expected object header. Got 0x".concat(string2);
                do {
                    throw new zza(string2, parcel);
                    break;
                } while (true);
            }
            string2 = new String("Expected object header. Got 0x");
            throw new zza(string2, parcel);
        }
        n = n3 + n2;
        if (n >= n3 && n <= parcel.dataSize()) return n;
        throw new zza(new StringBuilder(54).append("Size read is invalid start=").append(n3).append(" end=").append(n).toString(), parcel);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Boolean zzd(Parcel parcel, int n) {
        boolean bl;
        int n2 = zza.zza(parcel, n);
        if (n2 == 0) {
            return null;
        }
        zza.zza(parcel, n, n2, 4);
        if (parcel.readInt() != 0) {
            bl = true;
            do {
                return bl;
                break;
            } while (true);
        }
        bl = false;
        return bl;
    }

    public static byte zze(Parcel parcel, int n) {
        zza.zza(parcel, n, 4);
        return (byte)parcel.readInt();
    }

    public static short zzf(Parcel parcel, int n) {
        zza.zza(parcel, n, 4);
        return (short)parcel.readInt();
    }

    public static int zzg(Parcel parcel, int n) {
        zza.zza(parcel, n, 4);
        return parcel.readInt();
    }

    public static int zzgu(int n) {
        return 65535 & n;
    }

    public static Integer zzh(Parcel parcel, int n) {
        int n2 = zza.zza(parcel, n);
        if (n2 == 0) {
            return null;
        }
        zza.zza(parcel, n, n2, 4);
        return parcel.readInt();
    }

    public static long zzi(Parcel parcel, int n) {
        zza.zza(parcel, n, 8);
        return parcel.readLong();
    }

    public static Long zzj(Parcel parcel, int n) {
        int n2 = zza.zza(parcel, n);
        if (n2 == 0) {
            return null;
        }
        zza.zza(parcel, n, n2, 8);
        return parcel.readLong();
    }

    public static BigInteger zzk(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        byte[] arrby = parcel.createByteArray();
        parcel.setDataPosition(n + n2);
        return new BigInteger(arrby);
    }

    public static float zzl(Parcel parcel, int n) {
        zza.zza(parcel, n, 4);
        return parcel.readFloat();
    }

    public static Float zzm(Parcel parcel, int n) {
        int n2 = zza.zza(parcel, n);
        if (n2 == 0) {
            return null;
        }
        zza.zza(parcel, n, n2, 4);
        return Float.valueOf(parcel.readFloat());
    }

    public static double zzn(Parcel parcel, int n) {
        zza.zza(parcel, n, 8);
        return parcel.readDouble();
    }

    public static Double zzo(Parcel parcel, int n) {
        int n2 = zza.zza(parcel, n);
        if (n2 == 0) {
            return null;
        }
        zza.zza(parcel, n, n2, 8);
        return parcel.readDouble();
    }

    public static BigDecimal zzp(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        byte[] arrby = parcel.createByteArray();
        int n3 = parcel.readInt();
        parcel.setDataPosition(n + n2);
        return new BigDecimal(new BigInteger(arrby), n3);
    }

    public static String zzq(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        String string2 = parcel.readString();
        parcel.setDataPosition(n + n2);
        return string2;
    }

    public static IBinder zzr(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        IBinder iBinder = parcel.readStrongBinder();
        parcel.setDataPosition(n + n2);
        return iBinder;
    }

    public static Bundle zzs(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        Bundle bundle = parcel.readBundle();
        parcel.setDataPosition(n + n2);
        return bundle;
    }

    public static byte[] zzt(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        byte[] arrby = parcel.createByteArray();
        parcel.setDataPosition(n + n2);
        return arrby;
    }

    public static byte[][] zzu(Parcel parcel, int n) {
        int n2 = zza.zza(parcel, n);
        int n3 = parcel.dataPosition();
        if (n2 == 0) {
            return null;
        }
        int n4 = parcel.readInt();
        byte[][] arrarrby = new byte[n4][];
        for (n = 0; n < n4; ++n) {
            arrarrby[n] = parcel.createByteArray();
        }
        parcel.setDataPosition(n3 + n2);
        return arrarrby;
    }

    public static boolean[] zzv(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        boolean[] arrbl = parcel.createBooleanArray();
        parcel.setDataPosition(n + n2);
        return arrbl;
    }

    public static int[] zzw(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        int[] arrn = parcel.createIntArray();
        parcel.setDataPosition(n + n2);
        return arrn;
    }

    public static long[] zzx(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        long[] arrl = parcel.createLongArray();
        parcel.setDataPosition(n + n2);
        return arrl;
    }

    public static BigInteger[] zzy(Parcel parcel, int n) {
        int n2 = zza.zza(parcel, n);
        int n3 = parcel.dataPosition();
        if (n2 == 0) {
            return null;
        }
        int n4 = parcel.readInt();
        BigInteger[] arrbigInteger = new BigInteger[n4];
        for (n = 0; n < n4; ++n) {
            arrbigInteger[n] = new BigInteger(parcel.createByteArray());
        }
        parcel.setDataPosition(n3 + n2);
        return arrbigInteger;
    }

    public static float[] zzz(Parcel parcel, int n) {
        n = zza.zza(parcel, n);
        int n2 = parcel.dataPosition();
        if (n == 0) {
            return null;
        }
        float[] arrf = parcel.createFloatArray();
        parcel.setDataPosition(n + n2);
        return arrf;
    }

    public static class zza
    extends RuntimeException {
        public zza(String string2, Parcel parcel) {
            int n = parcel.dataPosition();
            int n2 = parcel.dataSize();
            super(new StringBuilder(String.valueOf(string2).length() + 41).append(string2).append(" Parcel: pos=").append(n).append(" size=").append(n2).toString());
        }
    }

}

