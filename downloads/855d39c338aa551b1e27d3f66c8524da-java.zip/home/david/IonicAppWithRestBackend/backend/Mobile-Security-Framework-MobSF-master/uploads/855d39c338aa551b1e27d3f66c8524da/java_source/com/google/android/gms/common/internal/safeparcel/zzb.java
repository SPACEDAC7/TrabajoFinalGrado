/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 */
package com.google.android.gms.common.internal.safeparcel;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;

public class zzb {
    public static void zza(Parcel parcel, int n, byte by) {
        zzb.zzb(parcel, n, 4);
        parcel.writeInt((int)by);
    }

    public static void zza(Parcel parcel, int n, double d) {
        zzb.zzb(parcel, n, 8);
        parcel.writeDouble(d);
    }

    public static void zza(Parcel parcel, int n, float f) {
        zzb.zzb(parcel, n, 4);
        parcel.writeFloat(f);
    }

    public static void zza(Parcel parcel, int n, long l) {
        zzb.zzb(parcel, n, 8);
        parcel.writeLong(l);
    }

    public static void zza(Parcel parcel, int n, Bundle bundle, boolean bl) {
        if (bundle == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeBundle(bundle);
        zzb.zzai(parcel, n);
    }

    public static void zza(Parcel parcel, int n, IBinder iBinder, boolean bl) {
        if (iBinder == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeStrongBinder(iBinder);
        zzb.zzai(parcel, n);
    }

    public static void zza(Parcel parcel, int n, Parcel parcel2, boolean bl) {
        if (parcel2 == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.appendFrom(parcel2, 0, parcel2.dataSize());
        zzb.zzai(parcel, n);
    }

    public static void zza(Parcel parcel, int n, Parcelable parcelable, int n2, boolean bl) {
        if (parcelable == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcelable.writeToParcel(parcel, n2);
        zzb.zzai(parcel, n);
    }

    public static void zza(Parcel parcel, int n, Boolean bl, boolean bl2) {
        int n2 = 0;
        if (bl == null) {
            if (bl2) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        zzb.zzb(parcel, n, 4);
        n = n2;
        if (bl.booleanValue()) {
            n = 1;
        }
        parcel.writeInt(n);
    }

    public static void zza(Parcel parcel, int n, Double d, boolean bl) {
        if (d == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        zzb.zzb(parcel, n, 8);
        parcel.writeDouble(d.doubleValue());
    }

    public static void zza(Parcel parcel, int n, Float f, boolean bl) {
        if (f == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        zzb.zzb(parcel, n, 4);
        parcel.writeFloat(f.floatValue());
    }

    public static void zza(Parcel parcel, int n, Integer n2, boolean bl) {
        if (n2 == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        zzb.zzb(parcel, n, 4);
        parcel.writeInt(n2.intValue());
    }

    public static void zza(Parcel parcel, int n, Long l, boolean bl) {
        if (l == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        zzb.zzb(parcel, n, 8);
        parcel.writeLong(l.longValue());
    }

    public static void zza(Parcel parcel, int n, String string2, boolean bl) {
        if (string2 == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeString(string2);
        zzb.zzai(parcel, n);
    }

    public static void zza(Parcel parcel, int n, List<Integer> list, boolean bl) {
        if (list == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        int n2 = zzb.zzah(parcel, n);
        int n3 = list.size();
        parcel.writeInt(n3);
        for (n = 0; n < n3; ++n) {
            parcel.writeInt(list.get(n).intValue());
        }
        zzb.zzai(parcel, n2);
    }

    public static void zza(Parcel parcel, int n, short s) {
        zzb.zzb(parcel, n, 4);
        parcel.writeInt((int)s);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void zza(Parcel parcel, int n, boolean bl) {
        zzb.zzb(parcel, n, 4);
        n = bl ? 1 : 0;
        parcel.writeInt(n);
    }

    public static void zza(Parcel parcel, int n, byte[] arrby, boolean bl) {
        if (arrby == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeByteArray(arrby);
        zzb.zzai(parcel, n);
    }

    public static void zza(Parcel parcel, int n, float[] arrf, boolean bl) {
        if (arrf == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeFloatArray(arrf);
        zzb.zzai(parcel, n);
    }

    public static void zza(Parcel parcel, int n, int[] arrn, boolean bl) {
        if (arrn == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeIntArray(arrn);
        zzb.zzai(parcel, n);
    }

    public static void zza(Parcel parcel, int n, long[] arrl, boolean bl) {
        if (arrl == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeLongArray(arrl);
        zzb.zzai(parcel, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static <T extends Parcelable> void zza(Parcel parcel, int n, T[] arrT, int n2, boolean bl) {
        if (arrT == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        int n3 = zzb.zzah(parcel, n);
        int n4 = arrT.length;
        parcel.writeInt(n4);
        n = 0;
        do {
            if (n >= n4) {
                zzb.zzai(parcel, n3);
                return;
            }
            T t = arrT[n];
            if (t == null) {
                parcel.writeInt(0);
            } else {
                zzb.zza(parcel, t, n2);
            }
            ++n;
        } while (true);
    }

    public static void zza(Parcel parcel, int n, String[] arrstring, boolean bl) {
        if (arrstring == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeStringArray(arrstring);
        zzb.zzai(parcel, n);
    }

    public static void zza(Parcel parcel, int n, boolean[] arrbl, boolean bl) {
        if (arrbl == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeBooleanArray(arrbl);
        zzb.zzai(parcel, n);
    }

    public static void zza(Parcel parcel, int n, byte[][] arrby, boolean bl) {
        int n2 = 0;
        if (arrby == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        int n3 = zzb.zzah(parcel, n);
        int n4 = arrby.length;
        parcel.writeInt(n4);
        for (n = n2; n < n4; ++n) {
            parcel.writeByteArray(arrby[n]);
        }
        zzb.zzai(parcel, n3);
    }

    private static <T extends Parcelable> void zza(Parcel parcel, T t, int n) {
        int n2 = parcel.dataPosition();
        parcel.writeInt(1);
        int n3 = parcel.dataPosition();
        t.writeToParcel(parcel, n);
        n = parcel.dataPosition();
        parcel.setDataPosition(n2);
        parcel.writeInt(n - n3);
        parcel.setDataPosition(n);
    }

    private static int zzah(Parcel parcel, int n) {
        parcel.writeInt(-65536 | n);
        parcel.writeInt(0);
        return parcel.dataPosition();
    }

    private static void zzai(Parcel parcel, int n) {
        int n2 = parcel.dataPosition();
        parcel.setDataPosition(n - 4);
        parcel.writeInt(n2 - n);
        parcel.setDataPosition(n2);
    }

    public static void zzaj(Parcel parcel, int n) {
        zzb.zzai(parcel, n);
    }

    private static void zzb(Parcel parcel, int n, int n2) {
        if (n2 >= 65535) {
            parcel.writeInt(-65536 | n);
            parcel.writeInt(n2);
            return;
        }
        parcel.writeInt(n2 << 16 | n);
    }

    public static void zzb(Parcel parcel, int n, List<String> list, boolean bl) {
        if (list == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeStringList(list);
        zzb.zzai(parcel, n);
    }

    public static void zzc(Parcel parcel, int n, int n2) {
        zzb.zzb(parcel, n, 4);
        parcel.writeInt(n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static <T extends Parcelable> void zzc(Parcel parcel, int n, List<T> list, boolean bl) {
        if (list == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        int n2 = zzb.zzah(parcel, n);
        int n3 = list.size();
        parcel.writeInt(n3);
        n = 0;
        do {
            if (n >= n3) {
                zzb.zzai(parcel, n2);
                return;
            }
            Parcelable parcelable = (Parcelable)list.get(n);
            if (parcelable == null) {
                parcel.writeInt(0);
            } else {
                zzb.zza(parcel, parcelable, 0);
            }
            ++n;
        } while (true);
    }

    public static int zzcs(Parcel parcel) {
        return zzb.zzah(parcel, 20293);
    }

    public static void zzd(Parcel parcel, int n, List list, boolean bl) {
        if (list == null) {
            if (bl) {
                zzb.zzb(parcel, n, 0);
            }
            return;
        }
        n = zzb.zzah(parcel, n);
        parcel.writeList(list);
        zzb.zzai(parcel, n);
    }
}

