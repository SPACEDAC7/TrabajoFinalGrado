/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Looper
 *  android.text.TextUtils
 */
package com.google.android.gms.common.internal;

import android.os.Looper;
import android.text.TextUtils;

public final class zzaa {
    public static int zza(int n, Object object) {
        if (n == 0) {
            throw new IllegalArgumentException(String.valueOf(object));
        }
        return n;
    }

    public static long zza(long l, Object object) {
        if (l == 0) {
            throw new IllegalArgumentException(String.valueOf(object));
        }
        return l;
    }

    public static void zza(boolean bl, Object object) {
        if (!bl) {
            throw new IllegalStateException(String.valueOf(object));
        }
    }

    public static /* varargs */ void zza(boolean bl, String string2, Object ... arrobject) {
        if (!bl) {
            throw new IllegalStateException(String.format(string2, arrobject));
        }
    }

    public static void zzawk() {
        zzaa.zzht("Must not be called on the main application thread");
    }

    public static <T> T zzb(T t, Object object) {
        if (t == null) {
            throw new NullPointerException(String.valueOf(object));
        }
        return t;
    }

    public static void zzb(boolean bl, Object object) {
        if (!bl) {
            throw new IllegalArgumentException(String.valueOf(object));
        }
    }

    public static /* varargs */ void zzb(boolean bl, String string2, Object ... arrobject) {
        if (!bl) {
            throw new IllegalArgumentException(String.format(string2, arrobject));
        }
    }

    public static void zzbs(boolean bl) {
        if (!bl) {
            throw new IllegalStateException();
        }
    }

    public static void zzbt(boolean bl) {
        if (!bl) {
            throw new IllegalArgumentException();
        }
    }

    public static int zzgp(int n) {
        if (n == 0) {
            throw new IllegalArgumentException("Given Integer is zero");
        }
        return n;
    }

    public static String zzh(String string2, Object object) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            throw new IllegalArgumentException(String.valueOf(object));
        }
        return string2;
    }

    public static void zzhs(String string2) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new IllegalStateException(string2);
        }
    }

    public static void zzht(String string2) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            throw new IllegalStateException(string2);
        }
    }

    public static String zzib(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            throw new IllegalArgumentException("Given String is empty or null");
        }
        return string2;
    }

    public static <T> T zzy(T t) {
        if (t == null) {
            throw new NullPointerException("null reference");
        }
        return t;
    }
}

