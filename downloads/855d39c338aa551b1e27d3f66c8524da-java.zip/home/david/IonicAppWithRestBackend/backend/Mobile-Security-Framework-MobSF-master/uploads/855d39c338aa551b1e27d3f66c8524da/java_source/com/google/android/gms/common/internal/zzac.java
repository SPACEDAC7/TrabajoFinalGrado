/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.ResolveAccountResponse;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzac
implements Parcelable.Creator<ResolveAccountResponse> {
    static void zza(ResolveAccountResponse resolveAccountResponse, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, resolveAccountResponse.mVersionCode);
        zzb.zza(parcel, 2, resolveAccountResponse.Df, false);
        zzb.zza(parcel, 3, resolveAccountResponse.zzawn(), n, false);
        zzb.zza(parcel, 4, resolveAccountResponse.zzawo());
        zzb.zza(parcel, 5, resolveAccountResponse.zzawp());
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcn(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgr(n);
    }

    public ResolveAccountResponse zzcn(Parcel parcel) {
        ConnectionResult connectionResult = null;
        boolean bl = false;
        int n = zza.zzcr(parcel);
        boolean bl2 = false;
        IBinder iBinder = null;
        int n2 = 0;
        block7 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block7;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block7;
                }
                case 2: {
                    iBinder = zza.zzr(parcel, n3);
                    continue block7;
                }
                case 3: {
                    connectionResult = zza.zza(parcel, n3, ConnectionResult.CREATOR);
                    continue block7;
                }
                case 4: {
                    bl2 = zza.zzc(parcel, n3);
                    continue block7;
                }
                case 5: 
            }
            bl = zza.zzc(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new ResolveAccountResponse(n2, iBinder, connectionResult, bl2, bl);
    }

    public ResolveAccountResponse[] zzgr(int n) {
        return new ResolveAccountResponse[n];
    }
}

