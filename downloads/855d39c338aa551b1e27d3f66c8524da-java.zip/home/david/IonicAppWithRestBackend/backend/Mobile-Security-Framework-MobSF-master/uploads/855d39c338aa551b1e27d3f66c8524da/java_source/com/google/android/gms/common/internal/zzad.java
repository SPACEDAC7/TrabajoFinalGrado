/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.SignInButtonConfig;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzad
implements Parcelable.Creator<SignInButtonConfig> {
    static void zza(SignInButtonConfig signInButtonConfig, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, signInButtonConfig.mVersionCode);
        zzb.zzc(parcel, 2, signInButtonConfig.zzawq());
        zzb.zzc(parcel, 3, signInButtonConfig.zzawr());
        zzb.zza((Parcel)parcel, (int)4, (Parcelable[])signInButtonConfig.zzaws(), (int)n, (boolean)false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzco(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgs(n);
    }

    public SignInButtonConfig zzco(Parcel parcel) {
        int n = 0;
        int n2 = zza.zzcr(parcel);
        Scope[] arrscope = null;
        int n3 = 0;
        int n4 = 0;
        block6 : while (parcel.dataPosition() < n2) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block6;
                }
                case 1: {
                    n4 = zza.zzg(parcel, n5);
                    continue block6;
                }
                case 2: {
                    n3 = zza.zzg(parcel, n5);
                    continue block6;
                }
                case 3: {
                    n = zza.zzg(parcel, n5);
                    continue block6;
                }
                case 4: 
            }
            arrscope = zza.zzb(parcel, n5, Scope.CREATOR);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new SignInButtonConfig(n4, n3, n, arrscope);
    }

    public SignInButtonConfig[] zzgs(int n) {
        return new SignInButtonConfig[n];
    }
}

