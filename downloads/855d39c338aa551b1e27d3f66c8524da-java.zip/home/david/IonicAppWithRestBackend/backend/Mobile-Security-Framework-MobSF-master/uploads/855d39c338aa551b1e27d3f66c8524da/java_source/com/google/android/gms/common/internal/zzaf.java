/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.text.method.TransformationMethod
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.widget.Button
 */
package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.widget.Button;
import com.google.android.gms.R;
import com.google.android.gms.common.internal.zzaa;

public final class zzaf
extends Button {
    public zzaf(Context context) {
        this(context, null);
    }

    public zzaf(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 16842824);
    }

    private void zza(Resources resources) {
        this.setTypeface(Typeface.DEFAULT_BOLD);
        this.setTextSize(14.0f);
        float f = resources.getDisplayMetrics().density;
        this.setMinHeight((int)(f * 48.0f + 0.5f));
        this.setMinWidth((int)(f * 48.0f + 0.5f));
    }

    private void zzb(Resources resources, int n, int n2) {
        this.setBackgroundDrawable(resources.getDrawable(this.zze(n, this.zzg(n2, R.drawable.common_google_signin_btn_icon_dark, R.drawable.common_google_signin_btn_icon_light, R.drawable.common_google_signin_btn_icon_light), this.zzg(n2, R.drawable.common_google_signin_btn_text_dark, R.drawable.common_google_signin_btn_text_light, R.drawable.common_google_signin_btn_text_light))));
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zzc(Resources resources, int n, int n2) {
        this.setTextColor(zzaa.zzy(resources.getColorStateList(this.zzg(n2, R.color.common_google_signin_btn_text_dark, R.color.common_google_signin_btn_text_light, R.color.common_google_signin_btn_text_light))));
        switch (n) {
            default: {
                throw new IllegalStateException(new StringBuilder(32).append("Unknown button size: ").append(n).toString());
            }
            case 0: {
                this.setText((CharSequence)resources.getString(R.string.common_signin_button_text));
                break;
            }
            case 1: {
                this.setText((CharSequence)resources.getString(R.string.common_signin_button_text_long));
                break;
            }
            case 2: {
                this.setText(null);
            }
        }
        this.setTransformationMethod(null);
    }

    private int zze(int n, int n2, int n3) {
        switch (n) {
            default: {
                throw new IllegalStateException(new StringBuilder(32).append("Unknown button size: ").append(n).toString());
            }
            case 2: {
                n3 = n2;
            }
            case 0: 
            case 1: 
        }
        return n3;
    }

    private int zzg(int n, int n2, int n3, int n4) {
        switch (n) {
            default: {
                throw new IllegalStateException(new StringBuilder(33).append("Unknown color scheme: ").append(n).toString());
            }
            case 1: {
                n2 = n3;
            }
            case 0: {
                return n2;
            }
            case 2: 
        }
        return n4;
    }

    public void zza(Resources resources, int n, int n2) {
        this.zza(resources);
        this.zzb(resources, n, n2);
        this.zzc(resources, n, n2);
    }
}

