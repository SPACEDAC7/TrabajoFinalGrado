/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 */
package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.res.Resources;
import com.google.android.gms.R;
import com.google.android.gms.common.internal.zzaa;

public class zzah {
    private final Resources EP;
    private final String EQ;

    public zzah(Context context) {
        zzaa.zzy(context);
        this.EP = context.getResources();
        this.EQ = this.EP.getResourcePackageName(R.string.common_google_play_services_unknown_issue);
    }

    public String getString(String string2) {
        int n = this.EP.getIdentifier(string2, "string", this.EQ);
        if (n == 0) {
            return null;
        }
        return this.EP.getString(n);
    }
}

