/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ValidateAccountRequest;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzai
implements Parcelable.Creator<ValidateAccountRequest> {
    static void zza(ValidateAccountRequest validateAccountRequest, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, validateAccountRequest.mVersionCode);
        zzb.zzc(parcel, 2, validateAccountRequest.zzawu());
        zzb.zza(parcel, 3, validateAccountRequest.Df, false);
        zzb.zza((Parcel)parcel, (int)4, (Parcelable[])validateAccountRequest.zzaws(), (int)n, (boolean)false);
        zzb.zza(parcel, 5, validateAccountRequest.zzawv(), false);
        zzb.zza(parcel, 6, validateAccountRequest.getCallingPackage(), false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcp(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgt(n);
    }

    public ValidateAccountRequest zzcp(Parcel parcel) {
        int n = 0;
        String string2 = null;
        int n2 = zza.zzcr(parcel);
        Bundle bundle = null;
        Scope[] arrscope = null;
        IBinder iBinder = null;
        int n3 = 0;
        block8 : while (parcel.dataPosition() < n2) {
            int n4 = zza.zzcq(parcel);
            switch (zza.zzgu(n4)) {
                default: {
                    zza.zzb(parcel, n4);
                    continue block8;
                }
                case 1: {
                    n3 = zza.zzg(parcel, n4);
                    continue block8;
                }
                case 2: {
                    n = zza.zzg(parcel, n4);
                    continue block8;
                }
                case 3: {
                    iBinder = zza.zzr(parcel, n4);
                    continue block8;
                }
                case 4: {
                    arrscope = zza.zzb(parcel, n4, Scope.CREATOR);
                    continue block8;
                }
                case 5: {
                    bundle = zza.zzs(parcel, n4);
                    continue block8;
                }
                case 6: 
            }
            string2 = zza.zzq(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new ValidateAccountRequest(n3, n, iBinder, arrscope, bundle, string2);
    }

    public ValidateAccountRequest[] zzgt(int n) {
        return new ValidateAccountRequest[n];
    }
}

