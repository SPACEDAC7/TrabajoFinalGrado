/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$NotFoundException
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.util.TypedValue
 */
package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;

public class zzaj {
    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String zza(String string2, String string3, Context object, AttributeSet object2, boolean bl, boolean bl2, String string4) {
        string2 = object2 == null ? null : object2.getAttributeValue(string2, string3);
        object2 = string2;
        if (string2 != null) {
            object2 = string2;
            if (string2.startsWith("@string/")) {
                object2 = string2;
                if (bl) {
                    String string5 = string2.substring("@string/".length());
                    String string6 = object.getPackageName();
                    object2 = new TypedValue();
                    try {
                        object.getResources().getValue(new StringBuilder(String.valueOf(string6).length() + 8 + String.valueOf(string5).length()).append(string6).append(":string/").append(string5).toString(), (TypedValue)object2, true);
                    }
                    catch (Resources.NotFoundException var2_3) {
                        Log.w((String)string4, (String)new StringBuilder(String.valueOf(string3).length() + 30 + String.valueOf(string2).length()).append("Could not find resource for ").append(string3).append(": ").append(string2).toString());
                    }
                    if (object2.string != null) {
                        object2 = object2.string.toString();
                    } else {
                        object = String.valueOf(object2);
                        Log.w((String)string4, (String)new StringBuilder(String.valueOf(string3).length() + 28 + String.valueOf(object).length()).append("Resource ").append(string3).append(" was not a string: ").append((String)object).toString());
                        object2 = string2;
                    }
                }
            }
        }
        if (bl2 && object2 == null) {
            Log.w((String)string4, (String)new StringBuilder(String.valueOf(string3).length() + 33).append("Required XML attribute \"").append(string3).append("\" missing").toString());
        }
        return object2;
    }
}

