/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Looper
 *  android.util.Log
 */
package com.google.android.gms.common.internal;

import android.os.Looper;
import android.util.Log;

public final class zzc {
    public static void zza(boolean bl, Object object) {
        if (!bl) {
            throw new IllegalStateException(String.valueOf(object));
        }
    }

    public static void zzbs(boolean bl) {
        if (!bl) {
            throw new IllegalStateException();
        }
    }

    public static void zzhs(String string2) {
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            String string3 = String.valueOf(Thread.currentThread());
            String string4 = String.valueOf(Looper.getMainLooper().getThread());
            Log.e((String)"Asserts", (String)new StringBuilder(String.valueOf(string3).length() + 57 + String.valueOf(string4).length()).append("checkMainThread: current thread ").append(string3).append(" IS NOT the main thread ").append(string4).append("!").toString());
            throw new IllegalStateException(string2);
        }
    }

    public static void zzht(String string2) {
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            String string3 = String.valueOf(Thread.currentThread());
            String string4 = String.valueOf(Looper.getMainLooper().getThread());
            Log.e((String)"Asserts", (String)new StringBuilder(String.valueOf(string3).length() + 56 + String.valueOf(string4).length()).append("checkNotMainThread: current thread ").append(string3).append(" IS the main thread ").append(string4).append("!").toString());
            throw new IllegalStateException(string2);
        }
    }

    public static void zzu(Object object) {
        if (object == null) {
            throw new IllegalArgumentException("null reference");
        }
    }
}

