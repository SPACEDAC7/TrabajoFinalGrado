/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.AuthAccountRequest;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzd
implements Parcelable.Creator<AuthAccountRequest> {
    static void zza(AuthAccountRequest authAccountRequest, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, authAccountRequest.mVersionCode);
        zzb.zza(parcel, 2, authAccountRequest.Df, false);
        zzb.zza((Parcel)parcel, (int)3, (Parcelable[])authAccountRequest.Dg, (int)n, (boolean)false);
        zzb.zza(parcel, 4, authAccountRequest.Dh, false);
        zzb.zza(parcel, 5, authAccountRequest.Di, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcj(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgj(n);
    }

    public AuthAccountRequest zzcj(Parcel parcel) {
        Integer n = null;
        int n2 = zza.zzcr(parcel);
        int n3 = 0;
        Integer n4 = null;
        Scope[] arrscope = null;
        IBinder iBinder = null;
        block7 : while (parcel.dataPosition() < n2) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block7;
                }
                case 1: {
                    n3 = zza.zzg(parcel, n5);
                    continue block7;
                }
                case 2: {
                    iBinder = zza.zzr(parcel, n5);
                    continue block7;
                }
                case 3: {
                    arrscope = zza.zzb(parcel, n5, Scope.CREATOR);
                    continue block7;
                }
                case 4: {
                    n4 = zza.zzh(parcel, n5);
                    continue block7;
                }
                case 5: 
            }
            n = zza.zzh(parcel, n5);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new AuthAccountRequest(n3, iBinder, arrscope, n4, n);
    }

    public AuthAccountRequest[] zzgj(int n) {
        return new AuthAccountRequest[n];
    }
}

