/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.os.Bundle
 *  android.os.DeadObjectException
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Looper
 *  android.os.Message
 *  android.os.Parcelable
 *  android.os.RemoteException
 *  android.util.Log
 */
package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.annotation.BinderThread;
import android.support.annotation.CallSuper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.WorkerThread;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.GetServiceRequest;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.internal.zzl;
import com.google.android.gms.common.internal.zzp;
import com.google.android.gms.common.internal.zzs;
import com.google.android.gms.common.internal.zzt;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class zze<T extends IInterface> {
    public static final String[] DB = new String[]{"service_esmobile", "service_googleme"};
    protected AtomicInteger DA = new AtomicInteger(0);
    private int Dj;
    private long Dk;
    private long Dl;
    private int Dm;
    private long Dn;
    private final zzl Do;
    private final Object Dp = new Object();
    private zzt Dq;
    protected zzf Dr;
    private T Ds;
    private final ArrayList<zze<?>> Dt = new ArrayList();
    private zzh Du;
    private int Dv = 1;
    private final zzb Dw;
    private final zzc Dx;
    private final int Dy;
    private final String Dz;
    private final Context mContext;
    final Handler mHandler;
    private final com.google.android.gms.common.zzc zm;
    private final Looper zzajy;
    private final Object zzako = new Object();

    protected zze(Context context, Looper looper, int n, zzb zzb2, zzc zzc2, String string2) {
        this(context, looper, zzl.zzcc(context), com.google.android.gms.common.zzc.zzaql(), n, zzaa.zzy(zzb2), zzaa.zzy(zzc2), string2);
    }

    protected zze(Context context, Looper looper, zzl zzl2, com.google.android.gms.common.zzc zzc2, int n, zzb zzb2, zzc zzc3, String string2) {
        this.mContext = zzaa.zzb(context, (Object)"Context must not be null");
        this.zzajy = zzaa.zzb(looper, (Object)"Looper must not be null");
        this.Do = zzaa.zzb(zzl2, (Object)"Supervisor must not be null");
        this.zm = zzaa.zzb(zzc2, (Object)"API availability must not be null");
        this.mHandler = new zzd(looper);
        this.Dy = n;
        this.Dw = zzb2;
        this.Dx = zzc3;
        this.Dz = string2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean zza(int n, int n2, T t) {
        Object object = this.zzako;
        synchronized (object) {
            if (this.Dv != n) {
                return false;
            }
            this.zzb(n2, t);
            return true;
        }
    }

    private void zzavb() {
        String string2;
        String string3;
        if (this.Du != null) {
            string3 = String.valueOf(this.zzjx());
            string2 = String.valueOf(this.zzauz());
            Log.e((String)"GmsClient", (String)new StringBuilder(String.valueOf(string3).length() + 70 + String.valueOf(string2).length()).append("Calling connect() while still connected, missing disconnect() for ").append(string3).append(" on ").append(string2).toString());
            this.Do.zzb(this.zzjx(), this.zzauz(), this.Du, this.zzava());
            this.DA.incrementAndGet();
        }
        this.Du = new zzh(this.DA.get());
        if (!this.Do.zza(this.zzjx(), this.zzauz(), this.Du, this.zzava())) {
            string3 = String.valueOf(this.zzjx());
            string2 = String.valueOf(this.zzauz());
            Log.e((String)"GmsClient", (String)new StringBuilder(String.valueOf(string3).length() + 34 + String.valueOf(string2).length()).append("unable to connect to service: ").append(string3).append(" on ").append(string2).toString());
            this.zza(16, null, this.DA.get());
        }
    }

    private void zzavc() {
        if (this.Du != null) {
            this.Do.zzb(this.zzjx(), this.zzauz(), this.Du, this.zzava());
            this.Du = null;
        }
    }

    /*
     * Exception decompiling
     */
    private void zzb(int var1_1, T var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private void zzl(ConnectionResult connectionResult) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(3, this.DA.get(), connectionResult.getErrorCode(), (Object)connectionResult.getResolution()));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void disconnect() {
        this.DA.incrementAndGet();
        Object object = this.Dt;
        synchronized (object) {
            int n = this.Dt.size();
            int n2 = 0;
            do {
                if (n2 >= n) {
                    this.Dt.clear();
                    // MONITOREXIT [5, 7, 8] lbl9 : MonitorExitStatement: MONITOREXIT : var3_1
                    object = this.Dp;
                    synchronized (object) {
                        this.Dq = null;
                    }
                    this.zzb(1, null);
                    return;
                }
                this.Dt.get(n2).zzavm();
                ++n2;
            } while (true);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void dump(String object, FileDescriptor object2, PrintWriter printWriter, String[] object3) {
        int n;
        long l;
        String string2;
        object2 = this.zzako;
        synchronized (object2) {
            n = this.Dv;
            object3 = this.Ds;
        }
        printWriter.append((CharSequence)object).append("mConnectState=");
        switch (n) {
            default: {
                printWriter.print("UNKNOWN");
                break;
            }
            case 2: {
                printWriter.print("CONNECTING");
                break;
            }
            case 3: {
                printWriter.print("CONNECTED");
                break;
            }
            case 4: {
                printWriter.print("DISCONNECTING");
                break;
            }
            case 1: {
                printWriter.print("DISCONNECTED");
            }
        }
        printWriter.append(" mService=");
        if (object3 == null) {
            printWriter.println("null");
        } else {
            printWriter.append(this.zzjy()).append("@").println(Integer.toHexString(System.identityHashCode((Object)object3.asBinder())));
        }
        object2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);
        if (this.Dl > 0) {
            object3 = printWriter.append((CharSequence)object).append("lastConnectedTime=");
            l = this.Dl;
            string2 = String.valueOf(object2.format(new Date(this.Dl)));
            object3.println(new StringBuilder(String.valueOf(string2).length() + 21).append(l).append(" ").append(string2).toString());
        }
        if (this.Dk > 0) {
            printWriter.append((CharSequence)object).append("lastSuspendedCause=");
            switch (this.Dj) {
                default: {
                    printWriter.append(String.valueOf(this.Dj));
                    break;
                }
                case 1: {
                    printWriter.append("CAUSE_SERVICE_DISCONNECTED");
                    break;
                }
                case 2: {
                    printWriter.append("CAUSE_NETWORK_LOST");
                }
            }
            object3 = printWriter.append(" lastSuspendedTime=");
            l = this.Dk;
            string2 = String.valueOf(object2.format(new Date(this.Dk)));
            object3.println(new StringBuilder(String.valueOf(string2).length() + 21).append(l).append(" ").append(string2).toString());
        }
        if (this.Dn > 0) {
            printWriter.append((CharSequence)object).append("lastFailedStatus=").append(CommonStatusCodes.getStatusCodeString(this.Dm));
            object = printWriter.append(" lastFailedTime=");
            l = this.Dn;
            object2 = String.valueOf(object2.format(new Date(this.Dn)));
            object.println(new StringBuilder(String.valueOf(object2).length() + 21).append(l).append(" ").append((String)object2).toString());
        }
    }

    public Account getAccount() {
        return null;
    }

    public final Context getContext() {
        return this.mContext;
    }

    public final Looper getLooper() {
        return this.zzajy;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean isConnected() {
        Object object = this.zzako;
        synchronized (object) {
            if (this.Dv != 3) return false;
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean isConnecting() {
        Object object = this.zzako;
        synchronized (object) {
            if (this.Dv != 2) return false;
            return true;
        }
    }

    @CallSuper
    protected void onConnectionFailed(ConnectionResult connectionResult) {
        this.Dm = connectionResult.getErrorCode();
        this.Dn = System.currentTimeMillis();
    }

    @CallSuper
    protected void onConnectionSuspended(int n) {
        this.Dj = n;
        this.Dk = System.currentTimeMillis();
    }

    protected void zza(int n, @Nullable Bundle bundle, int n2) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(5, n2, -1, (Object)new zzk(n, bundle)));
    }

    @BinderThread
    protected void zza(int n, IBinder iBinder, Bundle bundle, int n2) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(1, n2, -1, (Object)new zzj(n, iBinder, bundle)));
    }

    @CallSuper
    protected void zza(@NonNull T t) {
        this.Dl = System.currentTimeMillis();
    }

    public void zza(@NonNull zzf zzf2) {
        this.Dr = zzaa.zzb(zzf2, (Object)"Connection progress callbacks cannot be null.");
        this.zzb(2, null);
    }

    public void zza(zzf zzf2, ConnectionResult connectionResult) {
        this.Dr = zzaa.zzb(zzf2, (Object)"Connection progress callbacks cannot be null.");
        this.mHandler.sendMessage(this.mHandler.obtainMessage(3, this.DA.get(), connectionResult.getErrorCode(), (Object)connectionResult.getResolution()));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @WorkerThread
    public void zza(zzp object, Set<Scope> set) {
        block13 : {
            Object object2 = this.zzahv();
            object2 = new GetServiceRequest(this.Dy).zzhv(this.mContext.getPackageName()).zzo((Bundle)object2);
            if (set != null) {
                object2.zzf(set);
            }
            if (this.zzain()) {
                object2.zze(this.zzave()).zzb((zzp)object);
            } else if (this.zzavh()) {
                object2.zze(this.getAccount());
            }
            try {
                object = this.Dp;
                // MONITORENTER : object
                if (this.Dq == null) break block13;
            }
            catch (DeadObjectException var1_2) {
                Log.w((String)"GmsClient", (String)"service died");
                this.zzgk(1);
                return;
            }
            catch (RemoteException var1_3) {
                Log.w((String)"GmsClient", (String)"Remote exception occurred", (Throwable)var1_3);
                return;
            }
            catch (SecurityException var1_4) {
                throw var1_4;
            }
            catch (RuntimeException var1_5) {
                Log.w((String)"GmsClient", (String)"IGmsServiceBroker.getService failed", (Throwable)var1_5);
                this.zzl(new ConnectionResult(8, null, "IGmsServiceBroker.getService failed."));
                return;
            }
            this.Dq.zza((zzs)new zzg(this, this.DA.get()), (GetServiceRequest)object2);
            // MONITOREXIT : object
            return;
        }
        Log.w((String)"GmsClient", (String)"mServiceBroker is null, client disconnected");
        return;
    }

    protected Bundle zzahv() {
        return new Bundle();
    }

    public boolean zzain() {
        return false;
    }

    public boolean zzajc() {
        return false;
    }

    public Intent zzajd() {
        throw new UnsupportedOperationException("Not a sign in API");
    }

    public Bundle zzapn() {
        return null;
    }

    public boolean zzaqx() {
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Nullable
    public IBinder zzaqy() {
        Object object = this.Dp;
        synchronized (object) {
            if (this.Dq != null) return this.Dq.asBinder();
            return null;
        }
    }

    protected String zzauz() {
        return "com.google.android.gms";
    }

    @Nullable
    protected final String zzava() {
        if (this.Dz == null) {
            return this.mContext.getClass().getName();
        }
        return this.Dz;
    }

    public void zzavd() {
        int n = this.zm.isGooglePlayServicesAvailable(this.mContext);
        if (n != 0) {
            this.zzb(1, null);
            this.Dr = new zzi();
            this.mHandler.sendMessage(this.mHandler.obtainMessage(3, this.DA.get(), n));
            return;
        }
        this.zza(new zzi());
    }

    public final Account zzave() {
        if (this.getAccount() != null) {
            return this.getAccount();
        }
        return new Account("<<default account>>", "com.google");
    }

    protected final void zzavf() {
        if (!this.isConnected()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final T zzavg() throws DeadObjectException {
        Object object = this.zzako;
        synchronized (object) {
            if (this.Dv == 4) {
                throw new DeadObjectException();
            }
            this.zzavf();
            boolean bl = this.Ds != null;
            zzaa.zza(bl, (Object)"Client is connected but service is null");
            T t = this.Ds;
            return t;
        }
    }

    public boolean zzavh() {
        return false;
    }

    protected Set<Scope> zzavi() {
        return Collections.EMPTY_SET;
    }

    void zzc(int n, T t) {
    }

    public void zzgk(int n) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(4, this.DA.get(), n));
    }

    @Nullable
    protected abstract T zzh(IBinder var1);

    @NonNull
    protected abstract String zzjx();

    @NonNull
    protected abstract String zzjy();

    private abstract class zza
    extends zze<Boolean> {
        public final Bundle DC;
        public final int statusCode;

        @BinderThread
        protected zza(int n, Bundle bundle) {
            super(true);
            this.statusCode = n;
            this.DC = bundle;
        }

        protected abstract boolean zzavj();

        @Override
        protected void zzavk() {
        }

        /*
         * Enabled aggressive block sorting
         */
        protected void zzc(Boolean bl) {
            Object var2_2 = null;
            if (bl == null) {
                zze.this.zzb(1, (T)null);
                return;
            }
            switch (this.statusCode) {
                default: {
                    zze.this.zzb(1, (T)null);
                    bl = var2_2;
                    if (this.DC != null) {
                        bl = (PendingIntent)this.DC.getParcelable("pendingIntent");
                    }
                    this.zzm(new ConnectionResult(this.statusCode, (PendingIntent)bl));
                    return;
                }
                case 0: {
                    if (this.zzavj()) return;
                    {
                        zze.this.zzb(1, (T)null);
                        this.zzm(new ConnectionResult(8, null));
                        return;
                    }
                }
                case 10: 
            }
            zze.this.zzb(1, (T)null);
            throw new IllegalStateException("A fatal developer error has occurred. Check the logs for further information.");
        }

        protected abstract void zzm(ConnectionResult var1);

        @Override
        protected /* synthetic */ void zzv(Object object) {
            this.zzc((Boolean)object);
        }
    }

    public static interface zzb {
        public void onConnected(@Nullable Bundle var1);

        public void onConnectionSuspended(int var1);
    }

    public static interface zzc {
        public void onConnectionFailed(@NonNull ConnectionResult var1);
    }

    final class zzd
    extends Handler {
        public zzd(Looper looper) {
            super(looper);
        }

        private void zza(Message object) {
            object = (zze)object.obj;
            object.zzavk();
            object.unregister();
        }

        private boolean zzb(Message message) {
            if (message.what == 2 || message.what == 1 || message.what == 5) {
                return true;
            }
            return false;
        }

        public void handleMessage(Message object) {
            PendingIntent pendingIntent = null;
            if (zze.this.DA.get() != object.arg1) {
                if (this.zzb((Message)object)) {
                    this.zza((Message)object);
                }
                return;
            }
            if (!(object.what != 1 && object.what != 5 || zze.this.isConnecting())) {
                this.zza((Message)object);
                return;
            }
            if (object.what == 3) {
                if (object.obj instanceof PendingIntent) {
                    pendingIntent = (PendingIntent)object.obj;
                }
                object = new ConnectionResult(object.arg2, pendingIntent);
                zze.this.Dr.zzg((ConnectionResult)object);
                zze.this.onConnectionFailed((ConnectionResult)object);
                return;
            }
            if (object.what == 4) {
                zze.this.zzb(4, (T)null);
                if (zze.this.Dw != null) {
                    zze.this.Dw.onConnectionSuspended(object.arg2);
                }
                zze.this.onConnectionSuspended(object.arg2);
                zze.this.zza(4, 1, (T)null);
                return;
            }
            if (object.what == 2 && !zze.this.isConnected()) {
                this.zza((Message)object);
                return;
            }
            if (this.zzb((Message)object)) {
                ((zze)object.obj).zzavl();
                return;
            }
            int n = object.what;
            Log.wtf((String)"GmsClient", (String)new StringBuilder(45).append("Don't know how to handle message: ").append(n).toString(), (Throwable)new Exception());
        }
    }

    protected abstract class zze<TListener> {
        private boolean DE;
        private TListener mListener;

        public zze(TListener TListener) {
            this.mListener = TListener;
            this.DE = false;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void unregister() {
            this.zzavm();
            ArrayList arrayList = zze.this.Dt;
            synchronized (arrayList) {
                zze.this.Dt.remove(this);
                return;
            }
        }

        protected abstract void zzavk();

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Converted monitor instructions to comments
         * Lifted jumps to return sites
         */
        public void zzavl() {
            // MONITORENTER : this
            TListener TListener = this.mListener;
            if (this.DE) {
                String string2 = String.valueOf(this);
                Log.w((String)"GmsClient", (String)new StringBuilder(String.valueOf(string2).length() + 47).append("Callback proxy ").append(string2).append(" being reused. This is not safe.").toString());
            }
            // MONITOREXIT : this
            if (TListener != null) {
                try {
                    this.zzv(TListener);
                }
                catch (RuntimeException var1_2) {
                    this.zzavk();
                    throw var1_2;
                }
            } else {
                this.zzavk();
            }
            // MONITORENTER : this
            this.DE = true;
            // MONITOREXIT : this
            this.unregister();
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void zzavm() {
            synchronized (this) {
                this.mListener = null;
                return;
            }
        }

        protected abstract void zzv(TListener var1);
    }

    public static interface zzf {
        public void zzg(@NonNull ConnectionResult var1);
    }

    public static final class zzg
    extends zzs.zza {
        private zze DF;
        private final int DG;

        public zzg(@NonNull zze zze2, int n) {
            this.DF = zze2;
            this.DG = n;
        }

        private void zzavn() {
            this.DF = null;
        }

        @BinderThread
        @Override
        public void zza(int n, @NonNull IBinder iBinder, @Nullable Bundle bundle) {
            zzaa.zzb(this.DF, (Object)"onPostInitComplete can be called only once per call to getRemoteService");
            this.DF.zza(n, iBinder, bundle, this.DG);
            this.zzavn();
        }

        @BinderThread
        @Override
        public void zzb(int n, @Nullable Bundle bundle) {
            Log.wtf((String)"GmsClient", (String)"received deprecated onAccountValidationComplete callback, ignoring", (Throwable)new Exception());
        }
    }

    public final class zzh
    implements ServiceConnection {
        private final int DG;

        public zzh(int n) {
            this.DG = n;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void onServiceConnected(ComponentName object, IBinder iBinder) {
            if (iBinder == null) {
                zze.this.zzl(new ConnectionResult(8, null, "ServiceBroker IBinder is null"));
                return;
            }
            object = zze.this.Dp;
            synchronized (object) {
                zze.this.Dq = zzt.zza.zzdu(iBinder);
            }
            zze.this.zza(0, null, this.DG);
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void onServiceDisconnected(ComponentName object) {
            object = zze.this.Dp;
            synchronized (object) {
                zze.this.Dq = null;
            }
            zze.this.mHandler.sendMessage(zze.this.mHandler.obtainMessage(4, this.DG, 1));
        }
    }

    protected class zzi
    implements zzf {
        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void zzg(@NonNull ConnectionResult connectionResult) {
            if (connectionResult.isSuccess()) {
                zze.this.zza(null, zze.this.zzavi());
                return;
            } else {
                if (zze.this.Dx == null) return;
                {
                    zze.this.Dx.onConnectionFailed(connectionResult);
                    return;
                }
            }
        }
    }

    protected final class zzj
    extends zza {
        public final IBinder DH;

        @BinderThread
        public zzj(int n, IBinder iBinder, Bundle bundle) {
            super(n, bundle);
            this.DH = iBinder;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        protected boolean zzavj() {
            String string2;
            try {
                string2 = this.DH.getInterfaceDescriptor();
            }
            catch (RemoteException var1_2) {
                Log.w((String)"GmsClient", (String)"service probably died");
                return false;
            }
            if (!zze.this.zzjy().equals(string2)) {
                String string3 = String.valueOf(zze.this.zzjy());
                Log.e((String)"GmsClient", (String)new StringBuilder(String.valueOf(string3).length() + 34 + String.valueOf(string2).length()).append("service descriptor mismatch: ").append(string3).append(" vs. ").append(string2).toString());
                return false;
            } else {
                Object t = zze.this.zzh(this.DH);
                if (t == null || !zze.this.zza(2, 3, (T)t)) return false;
                {
                    Bundle bundle = zze.this.zzapn();
                    if (zze.this.Dw == null) return true;
                    {
                        zze.this.Dw.onConnected(bundle);
                    }
                    return true;
                }
            }
        }

        @Override
        protected void zzm(ConnectionResult connectionResult) {
            if (zze.this.Dx != null) {
                zze.this.Dx.onConnectionFailed(connectionResult);
            }
            zze.this.onConnectionFailed(connectionResult);
        }
    }

    protected final class zzk
    extends zza {
        @BinderThread
        public zzk(int n, @Nullable Bundle bundle) {
            super(n, bundle);
        }

        @Override
        protected boolean zzavj() {
            zze.this.Dr.zzg(ConnectionResult.wO);
            return true;
        }

        @Override
        protected void zzm(ConnectionResult connectionResult) {
            zze.this.Dr.zzg(connectionResult);
            zze.this.onConnectionFailed(connectionResult);
        }
    }

}

