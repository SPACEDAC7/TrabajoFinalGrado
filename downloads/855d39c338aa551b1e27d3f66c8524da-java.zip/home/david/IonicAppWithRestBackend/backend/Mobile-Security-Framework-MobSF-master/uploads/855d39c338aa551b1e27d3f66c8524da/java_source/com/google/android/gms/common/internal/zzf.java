/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.content.Context
 *  android.view.View
 */
package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.content.Context;
import android.view.View;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzxq;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class zzf {
    private final Set<Scope> DJ;
    private final Map<Api<?>, zza> DK;
    private final zzxq DL;
    private Integer DM;
    private final Account gj;
    private final String hu;
    private final Set<Scope> xF;
    private final int xH;
    private final View xI;
    private final String xJ;

    /*
     * Enabled aggressive block sorting
     */
    public zzf(Account set, Set<Scope> iterator, Map<Api<?>, zza> map, int n, View view, String string2, String string3, zzxq zzxq2) {
        this.gj = set;
        set = iterator == null ? Collections.EMPTY_SET : Collections.unmodifiableSet(iterator);
        this.xF = set;
        set = map;
        if (map == null) {
            set = Collections.EMPTY_MAP;
        }
        this.DK = set;
        this.xI = view;
        this.xH = n;
        this.hu = string2;
        this.xJ = string3;
        this.DL = zzxq2;
        set = new HashSet<Scope>(this.xF);
        iterator = this.DK.values().iterator();
        do {
            if (!iterator.hasNext()) {
                this.DJ = Collections.unmodifiableSet(set);
                return;
            }
            set.addAll(iterator.next().jw);
        } while (true);
    }

    public static zzf zzca(Context context) {
        return new GoogleApiClient.Builder(context).zzarf();
    }

    public Account getAccount() {
        return this.gj;
    }

    @Deprecated
    public String getAccountName() {
        if (this.gj != null) {
            return this.gj.name;
        }
        return null;
    }

    public Account zzave() {
        if (this.gj != null) {
            return this.gj;
        }
        return new Account("<<default account>>", "com.google");
    }

    public int zzavo() {
        return this.xH;
    }

    public Set<Scope> zzavp() {
        return this.xF;
    }

    public Set<Scope> zzavq() {
        return this.DJ;
    }

    public Map<Api<?>, zza> zzavr() {
        return this.DK;
    }

    public String zzavs() {
        return this.hu;
    }

    public String zzavt() {
        return this.xJ;
    }

    public View zzavu() {
        return this.xI;
    }

    public zzxq zzavv() {
        return this.DL;
    }

    public Integer zzavw() {
        return this.DM;
    }

    public Set<Scope> zzc(Api<?> object) {
        if ((object = this.DK.get(object)) == null || object.jw.isEmpty()) {
            return this.xF;
        }
        HashSet<Scope> hashSet = new HashSet<Scope>(this.xF);
        hashSet.addAll(object.jw);
        return hashSet;
    }

    public void zzc(Integer n) {
        this.DM = n;
    }

    public static final class zza {
        public final boolean DN;
        public final Set<Scope> jw;

        public zza(Set<Scope> set, boolean bl) {
            zzaa.zzy(set);
            this.jw = Collections.unmodifiableSet(set);
            this.DN = bl;
        }
    }

}

