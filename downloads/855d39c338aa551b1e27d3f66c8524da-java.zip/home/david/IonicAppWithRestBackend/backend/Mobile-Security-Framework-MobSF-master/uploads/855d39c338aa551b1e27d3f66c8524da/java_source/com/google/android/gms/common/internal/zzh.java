/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Activity
 *  android.content.ActivityNotFoundException
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.util.Log
 */
package com.google.android.gms.common.internal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import com.google.android.gms.internal.zzrp;

public abstract class zzh
implements DialogInterface.OnClickListener {
    public static zzh zza(final Activity activity, Intent intent, final int n) {
        return new zzh(){

            @Override
            public void zzavx() {
                if (Intent.this != null) {
                    activity.startActivityForResult(Intent.this, n);
                }
            }
        };
    }

    public static zzh zza(final @NonNull Fragment fragment, Intent intent, final int n) {
        return new zzh(){

            @Override
            public void zzavx() {
                if (Intent.this != null) {
                    fragment.startActivityForResult(Intent.this, n);
                }
            }
        };
    }

    public static zzh zza(final @NonNull zzrp zzrp2, Intent intent, final int n) {
        return new zzh(){

            @TargetApi(value=11)
            @Override
            public void zzavx() {
                if (Intent.this != null) {
                    zzrp2.startActivityForResult(Intent.this, n);
                }
            }
        };
    }

    public void onClick(DialogInterface dialogInterface, int n) {
        try {
            this.zzavx();
            return;
        }
        catch (ActivityNotFoundException var3_3) {
            Log.e((String)"DialogRedirect", (String)"Failed to start resolution intent", (Throwable)var3_3);
            return;
        }
        finally {
            dialogInterface.dismiss();
        }
    }

    protected abstract void zzavx();

}

