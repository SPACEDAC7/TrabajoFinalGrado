/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.GetServiceRequest;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

public class zzi
implements Parcelable.Creator<GetServiceRequest> {
    static void zza(GetServiceRequest getServiceRequest, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, getServiceRequest.version);
        zzb.zzc(parcel, 2, getServiceRequest.DU);
        zzb.zzc(parcel, 3, getServiceRequest.DV);
        zzb.zza(parcel, 4, getServiceRequest.DW, false);
        zzb.zza(parcel, 5, getServiceRequest.DX, false);
        zzb.zza((Parcel)parcel, (int)6, (Parcelable[])getServiceRequest.DY, (int)n, (boolean)false);
        zzb.zza(parcel, 7, getServiceRequest.DZ, false);
        zzb.zza(parcel, 8, (Parcelable)getServiceRequest.Ea, n, false);
        zzb.zza(parcel, 9, getServiceRequest.Eb);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcl(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgm(n);
    }

    public GetServiceRequest zzcl(Parcel parcel) {
        int n = 0;
        Account account = null;
        int n2 = zza.zzcr(parcel);
        long l = 0;
        Bundle bundle = null;
        Scope[] arrscope = null;
        IBinder iBinder = null;
        String string2 = null;
        int n3 = 0;
        int n4 = 0;
        block11 : while (parcel.dataPosition() < n2) {
            int n5 = zza.zzcq(parcel);
            switch (zza.zzgu(n5)) {
                default: {
                    zza.zzb(parcel, n5);
                    continue block11;
                }
                case 1: {
                    n4 = zza.zzg(parcel, n5);
                    continue block11;
                }
                case 2: {
                    n3 = zza.zzg(parcel, n5);
                    continue block11;
                }
                case 3: {
                    n = zza.zzg(parcel, n5);
                    continue block11;
                }
                case 4: {
                    string2 = zza.zzq(parcel, n5);
                    continue block11;
                }
                case 5: {
                    iBinder = zza.zzr(parcel, n5);
                    continue block11;
                }
                case 6: {
                    arrscope = zza.zzb(parcel, n5, Scope.CREATOR);
                    continue block11;
                }
                case 7: {
                    bundle = zza.zzs(parcel, n5);
                    continue block11;
                }
                case 8: {
                    account = (Account)zza.zza(parcel, n5, Account.CREATOR);
                    continue block11;
                }
                case 9: 
            }
            l = zza.zzi(parcel, n5);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new GetServiceRequest(n4, n3, n, string2, iBinder, arrscope, bundle, account, l);
    }

    public GetServiceRequest[] zzgm(int n) {
        return new GetServiceRequest[n];
    }
}

