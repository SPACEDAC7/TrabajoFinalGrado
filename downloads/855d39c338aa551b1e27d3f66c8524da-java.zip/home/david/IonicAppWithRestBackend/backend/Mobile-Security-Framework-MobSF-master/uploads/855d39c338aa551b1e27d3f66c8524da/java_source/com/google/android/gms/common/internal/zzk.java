/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.Looper
 *  android.os.Message
 *  android.util.Log
 */
package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.internal.zzaa;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

public final class zzk
implements Handler.Callback {
    private final zza Ee;
    private final ArrayList<GoogleApiClient.ConnectionCallbacks> Ef = new ArrayList();
    final ArrayList<GoogleApiClient.ConnectionCallbacks> Eg = new ArrayList();
    private final ArrayList<GoogleApiClient.OnConnectionFailedListener> Eh = new ArrayList();
    private volatile boolean Ei = false;
    private final AtomicInteger Ej = new AtomicInteger(0);
    private boolean Ek = false;
    private final Handler mHandler;
    private final Object zzako = new Object();

    public zzk(Looper looper, zza zza2) {
        this.Ee = zza2;
        this.mHandler = new Handler(looper, (Handler.Callback)this);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean handleMessage(Message object) {
        if (object.what != 1) {
            int n = object.what;
            Log.wtf((String)"GmsClientEvents", (String)new StringBuilder(45).append("Don't know how to handle message: ").append(n).toString(), (Throwable)new Exception());
            return false;
        }
        GoogleApiClient.ConnectionCallbacks connectionCallbacks = (GoogleApiClient.ConnectionCallbacks)object.obj;
        object = this.zzako;
        synchronized (object) {
            if (this.Ei && this.Ee.isConnected() && this.Ef.contains(connectionCallbacks)) {
                connectionCallbacks.onConnected(this.Ee.zzapn());
            }
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean isConnectionCallbacksRegistered(GoogleApiClient.ConnectionCallbacks connectionCallbacks) {
        zzaa.zzy(connectionCallbacks);
        Object object = this.zzako;
        synchronized (object) {
            return this.Ef.contains(connectionCallbacks);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean isConnectionFailedListenerRegistered(GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener) {
        zzaa.zzy(onConnectionFailedListener);
        Object object = this.zzako;
        synchronized (object) {
            return this.Eh.contains(onConnectionFailedListener);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void registerConnectionCallbacks(GoogleApiClient.ConnectionCallbacks connectionCallbacks) {
        zzaa.zzy(connectionCallbacks);
        Object object = this.zzako;
        // MONITORENTER : object
        if (this.Ef.contains(connectionCallbacks)) {
            String string2 = String.valueOf(connectionCallbacks);
            Log.w((String)"GmsClientEvents", (String)new StringBuilder(String.valueOf(string2).length() + 62).append("registerConnectionCallbacks(): listener ").append(string2).append(" is already registered").toString());
        } else {
            this.Ef.add(connectionCallbacks);
        }
        // MONITOREXIT : object
        if (!this.Ee.isConnected()) return;
        this.mHandler.sendMessage(this.mHandler.obtainMessage(1, (Object)connectionCallbacks));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void registerConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener object) {
        zzaa.zzy(object);
        Object object2 = this.zzako;
        synchronized (object2) {
            if (this.Eh.contains(object)) {
                object = String.valueOf(object);
                Log.w((String)"GmsClientEvents", (String)new StringBuilder(String.valueOf(object).length() + 67).append("registerConnectionFailedListener(): listener ").append((String)object).append(" is already registered").toString());
            } else {
                this.Eh.add((GoogleApiClient.OnConnectionFailedListener)object);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void unregisterConnectionCallbacks(GoogleApiClient.ConnectionCallbacks object) {
        zzaa.zzy(object);
        Object object2 = this.zzako;
        synchronized (object2) {
            if (!this.Ef.remove(object)) {
                object = String.valueOf(object);
                Log.w((String)"GmsClientEvents", (String)new StringBuilder(String.valueOf(object).length() + 52).append("unregisterConnectionCallbacks(): listener ").append((String)object).append(" not found").toString());
            } else if (this.Ek) {
                this.Eg.add((GoogleApiClient.ConnectionCallbacks)object);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void unregisterConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener object) {
        zzaa.zzy(object);
        Object object2 = this.zzako;
        synchronized (object2) {
            if (!this.Eh.remove(object)) {
                object = String.valueOf(object);
                Log.w((String)"GmsClientEvents", (String)new StringBuilder(String.valueOf(object).length() + 57).append("unregisterConnectionFailedListener(): listener ").append((String)object).append(" not found").toString());
            }
            return;
        }
    }

    public void zzawc() {
        this.Ei = false;
        this.Ej.incrementAndGet();
    }

    public void zzawd() {
        this.Ei = true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void zzgn(int var1_1) {
        var3_2 = false;
        if (Looper.myLooper() == this.mHandler.getLooper()) {
            var3_2 = true;
        }
        zzaa.zza(var3_2, (Object)"onUnintentionalDisconnection must only be called on the Handler thread");
        this.mHandler.removeMessages(1);
        var4_3 = this.zzako;
        // MONITORENTER : var4_3
        this.Ek = true;
        var5_4 = new ArrayList<GoogleApiClient.ConnectionCallbacks>(this.Ef);
        var2_5 = this.Ej.get();
        var5_4 = var5_4.iterator();
        do {
            if (!var5_4.hasNext()) ** GOTO lbl-1000
            var6_6 = (GoogleApiClient.ConnectionCallbacks)var5_4.next();
            if (!this.Ei || this.Ej.get() != var2_5) lbl-1000: // 2 sources:
            {
                this.Eg.clear();
                this.Ek = false;
                // MONITOREXIT : var4_3
                return;
            }
            if (!this.Ef.contains(var6_6)) continue;
            var6_6.onConnectionSuspended(var1_1);
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zzn(ConnectionResult connectionResult) {
        boolean bl = Looper.myLooper() == this.mHandler.getLooper();
        zzaa.zza(bl, (Object)"onConnectionFailure must only be called on the Handler thread");
        this.mHandler.removeMessages(1);
        Object object = this.zzako;
        synchronized (object) {
            Object object2 = new ArrayList<GoogleApiClient.OnConnectionFailedListener>(this.Eh);
            int n = this.Ej.get();
            object2 = object2.iterator();
            while (object2.hasNext()) {
                GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener = (GoogleApiClient.OnConnectionFailedListener)object2.next();
                if (!this.Ei || this.Ej.get() != n) {
                    return;
                }
                if (!this.Eh.contains(onConnectionFailedListener)) continue;
                onConnectionFailedListener.onConnectionFailed(connectionResult);
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void zzp(Bundle var1_1) {
        var4_2 = true;
        var3_3 = Looper.myLooper() == this.mHandler.getLooper();
        zzaa.zza(var3_3, (Object)"onConnectionSuccess must only be called on the Handler thread");
        var5_4 = this.zzako;
        // MONITORENTER : var5_4
        var3_3 = this.Ek == false;
        zzaa.zzbs(var3_3);
        this.mHandler.removeMessages(1);
        this.Ek = true;
        var3_3 = this.Eg.size() == 0 ? var4_2 : false;
        zzaa.zzbs(var3_3);
        var6_5 = new ArrayList<GoogleApiClient.ConnectionCallbacks>(this.Ef);
        var2_6 = this.Ej.get();
        var6_5 = var6_5.iterator();
        do {
            if (!var6_5.hasNext()) ** GOTO lbl-1000
            var7_7 = (GoogleApiClient.ConnectionCallbacks)var6_5.next();
            if (!this.Ei || !this.Ee.isConnected() || this.Ej.get() != var2_6) lbl-1000: // 2 sources:
            {
                this.Eg.clear();
                this.Ek = false;
                // MONITOREXIT : var5_4
                return;
            }
            if (this.Eg.contains(var7_7)) continue;
            var7_7.onConnected(var1_1);
        } while (true);
    }

    public static interface zza {
        public boolean isConnected();

        public Bundle zzapn();
    }

}

