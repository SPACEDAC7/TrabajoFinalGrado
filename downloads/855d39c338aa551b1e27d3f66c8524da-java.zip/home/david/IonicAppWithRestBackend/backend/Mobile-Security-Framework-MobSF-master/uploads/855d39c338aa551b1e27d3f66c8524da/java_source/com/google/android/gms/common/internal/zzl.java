/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.ServiceConnection
 */
package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import com.google.android.gms.common.internal.zzm;

public abstract class zzl {
    private static final Object El = new Object();
    private static zzl Em;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static zzl zzcc(Context context) {
        Object object = El;
        synchronized (object) {
            if (Em == null) {
                Em = new zzm(context.getApplicationContext());
            }
            return Em;
        }
    }

    public abstract boolean zza(ComponentName var1, ServiceConnection var2, String var3);

    public abstract boolean zza(String var1, String var2, ServiceConnection var3, String var4);

    public abstract void zzb(ComponentName var1, ServiceConnection var2, String var3);

    public abstract void zzb(String var1, String var2, ServiceConnection var3, String var4);
}

