/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.google.android.gms.common.internal;

import android.util.Log;
import com.google.android.gms.common.internal.zzaa;

public final class zzo {
    public static final int EA = 23 - " PII_LOG".length();
    private static final String EB = null;
    private final String EC;
    private final String ED;

    public zzo(String string2) {
        this(string2, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public zzo(String string2, String string3) {
        zzaa.zzb(string2, (Object)"log tag cannot be null");
        boolean bl = string2.length() <= 23;
        zzaa.zzb(bl, "tag \"%s\" is longer than the %d character maximum", string2, 23);
        this.EC = string2;
        if (string3 != null && string3.length() > 0) {
            this.ED = string3;
            return;
        }
        this.ED = null;
    }

    private String zzhz(String string2) {
        if (this.ED == null) {
            return string2;
        }
        return this.ED.concat(string2);
    }

    public void zzad(String string2, String string3) {
        if (this.zzgo(3)) {
            Log.d((String)string2, (String)this.zzhz(string3));
        }
    }

    public void zzae(String string2, String string3) {
        if (this.zzgo(5)) {
            Log.w((String)string2, (String)this.zzhz(string3));
        }
    }

    public void zzaf(String string2, String string3) {
        if (this.zzgo(6)) {
            Log.e((String)string2, (String)this.zzhz(string3));
        }
    }

    public void zzb(String string2, String string3, Throwable throwable) {
        if (this.zzgo(4)) {
            Log.i((String)string2, (String)this.zzhz(string3), (Throwable)throwable);
        }
    }

    public void zzc(String string2, String string3, Throwable throwable) {
        if (this.zzgo(5)) {
            Log.w((String)string2, (String)this.zzhz(string3), (Throwable)throwable);
        }
    }

    public void zzd(String string2, String string3, Throwable throwable) {
        if (this.zzgo(6)) {
            Log.e((String)string2, (String)this.zzhz(string3), (Throwable)throwable);
        }
    }

    public void zze(String string2, String string3, Throwable throwable) {
        if (this.zzgo(7)) {
            Log.e((String)string2, (String)this.zzhz(string3), (Throwable)throwable);
            Log.wtf((String)string2, (String)this.zzhz(string3), (Throwable)throwable);
        }
    }

    public boolean zzgo(int n) {
        return Log.isLoggable((String)this.EC, (int)n);
    }
}

