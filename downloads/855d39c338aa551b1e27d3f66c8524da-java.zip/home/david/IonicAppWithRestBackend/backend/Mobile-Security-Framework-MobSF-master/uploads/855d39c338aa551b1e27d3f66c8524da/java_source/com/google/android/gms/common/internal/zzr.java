/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.RemoteException
 */
package com.google.android.gms.common.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.zzd;

public interface zzr
extends IInterface {
    public zzd zzaqn() throws RemoteException;

    public int zzaqo() throws RemoteException;

    public static abstract class zza
    extends Binder
    implements zzr {
        public zza() {
            this.attachInterface((IInterface)this, "com.google.android.gms.common.internal.ICertData");
        }

        public IBinder asBinder() {
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean onTransact(int n, Parcel object, Parcel parcel, int n2) throws RemoteException {
            switch (n) {
                default: {
                    return super.onTransact(n, (Parcel)object, parcel, n2);
                }
                case 1598968902: {
                    parcel.writeString("com.google.android.gms.common.internal.ICertData");
                    return true;
                }
                case 1: {
                    object.enforceInterface("com.google.android.gms.common.internal.ICertData");
                    object = this.zzaqn();
                    parcel.writeNoException();
                    object = object != null ? object.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 2: 
            }
            object.enforceInterface("com.google.android.gms.common.internal.ICertData");
            n = this.zzaqo();
            parcel.writeNoException();
            parcel.writeInt(n);
            return true;
        }
    }

}

