/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.RemoteException
 */
package com.google.android.gms.common.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.zzd;

public interface zzu
extends IInterface {
    public zzd zzawi() throws RemoteException;

    public zzd zzawj() throws RemoteException;

    public boolean zzd(String var1, zzd var2) throws RemoteException;

    public boolean zze(String var1, zzd var2) throws RemoteException;

    public static abstract class com.google.android.gms.common.internal.zzu$zza
    extends Binder
    implements zzu {
        public static zzu zzdv(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.IGoogleCertificatesApi");
            if (iInterface != null && iInterface instanceof zzu) {
                return (zzu)iInterface;
            }
            return new zza(iBinder);
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean onTransact(int n, Parcel object, Parcel parcel, int n2) throws RemoteException {
            zzd zzd2 = null;
            zzd zzd3 = null;
            int n3 = 0;
            switch (n) {
                default: {
                    return super.onTransact(n, (Parcel)object, parcel, n2);
                }
                case 1598968902: {
                    parcel.writeString("com.google.android.gms.common.internal.IGoogleCertificatesApi");
                    return true;
                }
                case 1: {
                    object.enforceInterface("com.google.android.gms.common.internal.IGoogleCertificatesApi");
                    zzd2 = this.zzawi();
                    parcel.writeNoException();
                    object = zzd3;
                    if (zzd2 != null) {
                        object = zzd2.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 2: {
                    object.enforceInterface("com.google.android.gms.common.internal.IGoogleCertificatesApi");
                    zzd3 = this.zzawj();
                    parcel.writeNoException();
                    object = zzd2;
                    if (zzd3 != null) {
                        object = zzd3.asBinder();
                    }
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 3: {
                    object.enforceInterface("com.google.android.gms.common.internal.IGoogleCertificatesApi");
                    boolean bl = this.zzd(object.readString(), zzd.zza.zzfd(object.readStrongBinder()));
                    parcel.writeNoException();
                    n = bl ? 1 : 0;
                    parcel.writeInt(n);
                    return true;
                }
                case 4: 
            }
            object.enforceInterface("com.google.android.gms.common.internal.IGoogleCertificatesApi");
            boolean bl = this.zze(object.readString(), zzd.zza.zzfd(object.readStrongBinder()));
            parcel.writeNoException();
            n = n3;
            if (bl) {
                n = 1;
            }
            parcel.writeInt(n);
            return true;
        }

        private static class zza
        implements zzu {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            @Override
            public zzd zzawi() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.common.internal.IGoogleCertificatesApi");
                    this.zzajq.transact(1, parcel, parcel2, 0);
                    parcel2.readException();
                    zzd zzd2 = zzd.zza.zzfd(parcel2.readStrongBinder());
                    return zzd2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            @Override
            public zzd zzawj() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.common.internal.IGoogleCertificatesApi");
                    this.zzajq.transact(2, parcel, parcel2, 0);
                    parcel2.readException();
                    zzd zzd2 = zzd.zza.zzfd(parcel2.readStrongBinder());
                    return zzd2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public boolean zzd(String string2, zzd zzd2) throws RemoteException {
                boolean bl = false;
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.common.internal.IGoogleCertificatesApi");
                    parcel.writeString(string2);
                    string2 = zzd2 != null ? zzd2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)string2);
                    this.zzajq.transact(3, parcel, parcel2, 0);
                    parcel2.readException();
                    int n = parcel2.readInt();
                    if (n != 0) {
                        bl = true;
                    }
                    return bl;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public boolean zze(String string2, zzd zzd2) throws RemoteException {
                boolean bl = false;
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.common.internal.IGoogleCertificatesApi");
                    parcel.writeString(string2);
                    string2 = zzd2 != null ? zzd2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)string2);
                    this.zzajq.transact(4, parcel, parcel2, 0);
                    parcel2.readException();
                    int n = parcel2.readInt();
                    if (n != 0) {
                        bl = true;
                    }
                    return bl;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

