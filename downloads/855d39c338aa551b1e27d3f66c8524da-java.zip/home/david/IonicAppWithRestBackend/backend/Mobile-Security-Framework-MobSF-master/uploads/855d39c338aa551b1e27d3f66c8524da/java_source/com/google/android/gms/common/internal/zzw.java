/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.common.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.common.internal.SignInButtonConfig;
import com.google.android.gms.dynamic.zzd;

public interface zzw
extends IInterface {
    public zzd zza(zzd var1, int var2, int var3) throws RemoteException;

    public zzd zza(zzd var1, SignInButtonConfig var2) throws RemoteException;

    public static abstract class com.google.android.gms.common.internal.zzw$zza
    extends Binder
    implements zzw {
        public static zzw zzdx(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.ISignInButtonCreator");
            if (iInterface != null && iInterface instanceof zzw) {
                return (zzw)iInterface;
            }
            return new zza(iBinder);
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean onTransact(int n, Parcel object, Parcel parcel, int n2) throws RemoteException {
            Object var5_5 = null;
            switch (n) {
                default: {
                    return super.onTransact(n, (Parcel)object, parcel, n2);
                }
                case 1598968902: {
                    parcel.writeString("com.google.android.gms.common.internal.ISignInButtonCreator");
                    return true;
                }
                case 1: {
                    object.enforceInterface("com.google.android.gms.common.internal.ISignInButtonCreator");
                    object = this.zza(zzd.zza.zzfd(object.readStrongBinder()), object.readInt(), object.readInt());
                    parcel.writeNoException();
                    object = object != null ? object.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)object);
                    return true;
                }
                case 2: 
            }
            object.enforceInterface("com.google.android.gms.common.internal.ISignInButtonCreator");
            zzd zzd2 = zzd.zza.zzfd(object.readStrongBinder());
            object = object.readInt() != 0 ? (SignInButtonConfig)SignInButtonConfig.CREATOR.createFromParcel((Parcel)object) : null;
            zzd2 = this.zza(zzd2, (SignInButtonConfig)object);
            parcel.writeNoException();
            object = var5_5;
            if (zzd2 != null) {
                object = zzd2.asBinder();
            }
            parcel.writeStrongBinder((IBinder)object);
            return true;
        }

        private static class zza
        implements zzw {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzd zza(zzd zzd2, int n, int n2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.common.internal.ISignInButtonCreator");
                    zzd2 = zzd2 != null ? zzd2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzd2);
                    parcel.writeInt(n);
                    parcel.writeInt(n2);
                    this.zzajq.transact(1, parcel, parcel2, 0);
                    parcel2.readException();
                    zzd2 = zzd.zza.zzfd(parcel2.readStrongBinder());
                    return zzd2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public zzd zza(zzd zzd2, SignInButtonConfig signInButtonConfig) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.common.internal.ISignInButtonCreator");
                    zzd2 = zzd2 != null ? zzd2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)zzd2);
                    if (signInButtonConfig != null) {
                        parcel.writeInt(1);
                        signInButtonConfig.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.zzajq.transact(2, parcel, parcel2, 0);
                    parcel2.readException();
                    zzd2 = zzd.zza.zzfd(parcel2.readStrongBinder());
                    return zzd2;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

