/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

import java.util.Iterator;

public class zzx {
    private final String separator;

    private zzx(String string2) {
        this.separator = string2;
    }

    public static zzx zzia(String string2) {
        return new zzx(string2);
    }

    public final StringBuilder zza(StringBuilder stringBuilder, Iterable<?> object) {
        if ((object = object.iterator()).hasNext()) {
            stringBuilder.append(this.zzw(object.next()));
            while (object.hasNext()) {
                stringBuilder.append(this.separator);
                stringBuilder.append(this.zzw(object.next()));
            }
        }
        return stringBuilder;
    }

    public final String zzb(Iterable<?> iterable) {
        return this.zza(new StringBuilder(), iterable).toString();
    }

    CharSequence zzw(Object object) {
        if (object instanceof CharSequence) {
            return (CharSequence)object;
        }
        return object.toString();
    }
}

