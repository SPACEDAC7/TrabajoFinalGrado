/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  android.util.Log
 */
package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.internal.zzsz;

public class zzy {
    private static String EE;
    private static int EF;
    private static Object zzaox;
    private static boolean zzchk;

    static {
        zzaox = new Object();
    }

    public static String zzcd(Context context) {
        zzy.zzcf(context);
        return EE;
    }

    public static int zzce(Context context) {
        zzy.zzcf(context);
        return EF;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void zzcf(Context object) {
        Object object2 = zzaox;
        synchronized (object2) {
            block7 : {
                if (zzchk) {
                    return;
                }
                zzchk = true;
                String string2 = object.getPackageName();
                object = zzsz.zzco((Context)object);
                object = object.getApplicationInfo((String)string2, (int)128).metaData;
                if (object != null) break block7;
                return;
            }
            try {
                EE = object.getString("com.google.app.id");
                EF = object.getInt("com.google.android.gms.version");
            }
            catch (PackageManager.NameNotFoundException var0_1) {
                Log.wtf((String)"MetadataValueReader", (String)"This should never happen.", (Throwable)var0_1);
            }
            return;
        }
    }
}

