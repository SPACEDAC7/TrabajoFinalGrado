/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

import android.support.annotation.Nullable;
import com.google.android.gms.common.internal.zzaa;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class zzz {
    public static boolean equal(@Nullable Object object, @Nullable Object object2) {
        if (object == object2 || object != null && object.equals(object2)) {
            return true;
        }
        return false;
    }

    public static /* varargs */ int hashCode(Object ... arrobject) {
        return Arrays.hashCode(arrobject);
    }

    public static zza zzx(Object object) {
        return new zza(object);
    }

    public static final class zza {
        private final List<String> EG;
        private final Object zzcxk;

        private zza(Object object) {
            this.zzcxk = zzaa.zzy(object);
            this.EG = new ArrayList<String>();
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder(100).append(this.zzcxk.getClass().getSimpleName()).append('{');
            int n = this.EG.size();
            for (int i = 0; i < n; ++i) {
                stringBuilder.append(this.EG.get(i));
                if (i >= n - 1) continue;
                stringBuilder.append(", ");
            }
            return stringBuilder.append('}').toString();
        }

        public zza zzg(String string2, Object object) {
            List<String> list = this.EG;
            string2 = zzaa.zzy(string2);
            object = String.valueOf(String.valueOf(object));
            list.add(new StringBuilder(String.valueOf(string2).length() + 1 + String.valueOf(object).length()).append(string2).append("=").append((String)object).toString());
            return this;
        }
    }

}

