/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.server.converter;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.server.converter.ConverterWrapper;
import com.google.android.gms.common.server.converter.StringToIntConverter;

public class zza
implements Parcelable.Creator<ConverterWrapper> {
    static void zza(ConverterWrapper converterWrapper, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, converterWrapper.mVersionCode);
        zzb.zza(parcel, 2, converterWrapper.zzaww(), n, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcu(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgx(n);
    }

    public ConverterWrapper zzcu(Parcel parcel) {
        int n = com.google.android.gms.common.internal.safeparcel.zza.zzcr(parcel);
        int n2 = 0;
        StringToIntConverter stringToIntConverter = null;
        block4 : while (parcel.dataPosition() < n) {
            int n3 = com.google.android.gms.common.internal.safeparcel.zza.zzcq(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zza.zzgu(n3)) {
                default: {
                    com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, n3);
                    continue block4;
                }
                case 1: {
                    n2 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n3);
                    continue block4;
                }
                case 2: 
            }
            stringToIntConverter = com.google.android.gms.common.internal.safeparcel.zza.zza(parcel, n3, StringToIntConverter.CREATOR);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new ConverterWrapper(n2, stringToIntConverter);
    }

    public ConverterWrapper[] zzgx(int n) {
        return new ConverterWrapper[n];
    }
}

