/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.server.converter;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.server.converter.StringToIntConverter;
import java.util.ArrayList;

public class zzb
implements Parcelable.Creator<StringToIntConverter> {
    static void zza(StringToIntConverter stringToIntConverter, Parcel parcel, int n) {
        n = com.google.android.gms.common.internal.safeparcel.zzb.zzcs(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1, stringToIntConverter.mVersionCode);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 2, stringToIntConverter.zzawy(), false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcv(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgy(n);
    }

    public StringToIntConverter zzcv(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        ArrayList<StringToIntConverter.Entry> arrayList = null;
        block4 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block4;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block4;
                }
                case 2: 
            }
            arrayList = zza.zzc(parcel, n3, StringToIntConverter.Entry.CREATOR);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new StringToIntConverter(n2, arrayList);
    }

    public StringToIntConverter[] zzgy(int n) {
        return new StringToIntConverter[n];
    }
}

