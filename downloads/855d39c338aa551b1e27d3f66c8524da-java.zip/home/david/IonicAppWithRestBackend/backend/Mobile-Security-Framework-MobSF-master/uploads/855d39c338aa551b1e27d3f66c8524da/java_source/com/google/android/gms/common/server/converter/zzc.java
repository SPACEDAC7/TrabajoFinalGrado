/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.server.converter;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.server.converter.StringToIntConverter;

public class zzc
implements Parcelable.Creator<StringToIntConverter.Entry> {
    static void zza(StringToIntConverter.Entry entry, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, entry.versionCode);
        zzb.zza(parcel, 2, entry.Fe, false);
        zzb.zzc(parcel, 3, entry.Ff);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcw(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgz(n);
    }

    public StringToIntConverter.Entry zzcw(Parcel parcel) {
        int n = 0;
        int n2 = zza.zzcr(parcel);
        String string2 = null;
        int n3 = 0;
        block5 : while (parcel.dataPosition() < n2) {
            int n4 = zza.zzcq(parcel);
            switch (zza.zzgu(n4)) {
                default: {
                    zza.zzb(parcel, n4);
                    continue block5;
                }
                case 1: {
                    n3 = zza.zzg(parcel, n4);
                    continue block5;
                }
                case 2: {
                    string2 = zza.zzq(parcel, n4);
                    continue block5;
                }
                case 3: 
            }
            n = zza.zzg(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new StringToIntConverter.Entry(n3, string2, n);
    }

    public StringToIntConverter.Entry[] zzgz(int n) {
        return new StringToIntConverter.Entry[n];
    }
}

