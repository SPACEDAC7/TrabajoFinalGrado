/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package com.google.android.gms.common.server.response;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.internal.zzz;
import com.google.android.gms.common.server.converter.ConverterWrapper;
import com.google.android.gms.common.server.response.FieldMappingDictionary;
import com.google.android.gms.common.server.response.SafeParcelResponse;
import com.google.android.gms.common.util.zzc;
import com.google.android.gms.common.util.zzp;
import com.google.android.gms.common.util.zzq;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public abstract class FastJsonResponse {
    private void zza(StringBuilder stringBuilder, Field field, Object object) {
        if (field.zzaxa() == 11) {
            stringBuilder.append(field.zzaxg().cast(object).toString());
            return;
        }
        if (field.zzaxa() == 7) {
            stringBuilder.append("\"");
            stringBuilder.append(zzp.zzii((String)object));
            stringBuilder.append("\"");
            return;
        }
        stringBuilder.append(object);
    }

    private void zza(StringBuilder stringBuilder, Field field, ArrayList<Object> arrayList) {
        stringBuilder.append("[");
        int n = arrayList.size();
        for (int i = 0; i < n; ++i) {
            Object object;
            if (i > 0) {
                stringBuilder.append(",");
            }
            if ((object = arrayList.get(i)) == null) continue;
            this.zza(stringBuilder, field, object);
        }
        stringBuilder.append("]");
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        Map map = this.zzawz();
        StringBuilder stringBuilder = new StringBuilder(100);
        block5 : for (String string2 : map.keySet()) {
            Field field = map.get(string2);
            if (!this.zza(field)) continue;
            Object obj = this.zza(field, this.zzb(field));
            if (stringBuilder.length() == 0) {
                stringBuilder.append("{");
            } else {
                stringBuilder.append(",");
            }
            stringBuilder.append("\"").append(string2).append("\":");
            if (obj == null) {
                stringBuilder.append("null");
                continue;
            }
            switch (field.zzaxc()) {
                default: {
                    if (!field.zzaxb()) break;
                    this.zza(stringBuilder, field, (ArrayList)obj);
                    continue block5;
                }
                case 8: {
                    stringBuilder.append("\"").append(zzc.zzq((byte[])obj)).append("\"");
                    continue block5;
                }
                case 9: {
                    stringBuilder.append("\"").append(zzc.zzr((byte[])obj)).append("\"");
                    continue block5;
                }
                case 10: {
                    zzq.zza(stringBuilder, (HashMap)obj);
                    continue block5;
                }
            }
            this.zza(stringBuilder, field, obj);
        }
        if (stringBuilder.length() > 0) {
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
        stringBuilder.append("{}");
        return stringBuilder.toString();
    }

    protected <O, I> I zza(Field<I, O> field, Object object) {
        Object object2 = object;
        if (field.Fp != null) {
            object2 = field.convertBack(object);
        }
        return (I)object2;
    }

    protected boolean zza(Field field) {
        if (field.zzaxc() == 11) {
            if (field.zzaxd()) {
                return this.zzif(field.zzaxe());
            }
            return this.zzie(field.zzaxe());
        }
        return this.zzid(field.zzaxe());
    }

    public abstract Map<String, Field<?, ?>> zzawz();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected Object zzb(Field object) {
        String string2 = object.zzaxe();
        if (object.zzaxg() == null) {
            return this.zzic(object.zzaxe());
        }
        boolean bl = this.zzic(object.zzaxe()) == null;
        zzaa.zza(bl, "Concrete field shouldn't be value object: %s", object.zzaxe());
        if (object.zzaxd()) {
            // empty if block
        }
        try {
            char c = Character.toUpperCase(string2.charAt(0));
            object = String.valueOf(string2.substring(1));
            object = new StringBuilder(String.valueOf(object).length() + 4).append("get").append(c).append((String)object).toString();
            return this.getClass().getMethod((String)object, new Class[0]).invoke(this, new Object[0]);
        }
        catch (Exception var1_2) {
            throw new RuntimeException(var1_2);
        }
    }

    protected abstract Object zzic(String var1);

    protected abstract boolean zzid(String var1);

    protected boolean zzie(String string2) {
        throw new UnsupportedOperationException("Concrete types not supported");
    }

    protected boolean zzif(String string2) {
        throw new UnsupportedOperationException("Concrete type arrays not supported");
    }

    public static class Field<I, O>
    extends AbstractSafeParcelable {
        public static final com.google.android.gms.common.server.response.zza CREATOR = new com.google.android.gms.common.server.response.zza();
        protected final int Fg;
        protected final boolean Fh;
        protected final int Fi;
        protected final boolean Fj;
        protected final String Fk;
        protected final int Fl;
        protected final Class<? extends FastJsonResponse> Fm;
        protected final String Fn;
        private FieldMappingDictionary Fo;
        private zza<I, O> Fp;
        private final int mVersionCode;

        /*
         * Enabled aggressive block sorting
         */
        Field(int n, int n2, boolean bl, int n3, boolean bl2, String string2, int n4, String string3, ConverterWrapper converterWrapper) {
            this.mVersionCode = n;
            this.Fg = n2;
            this.Fh = bl;
            this.Fi = n3;
            this.Fj = bl2;
            this.Fk = string2;
            this.Fl = n4;
            if (string3 == null) {
                this.Fm = null;
                this.Fn = null;
            } else {
                this.Fm = SafeParcelResponse.class;
                this.Fn = string3;
            }
            if (converterWrapper == null) {
                this.Fp = null;
                return;
            }
            this.Fp = converterWrapper.zzawx();
        }

        /*
         * Enabled aggressive block sorting
         */
        protected Field(int n, boolean bl, int n2, boolean bl2, String string2, int n3, Class<? extends FastJsonResponse> class_, zza<I, O> zza2) {
            this.mVersionCode = 1;
            this.Fg = n;
            this.Fh = bl;
            this.Fi = n2;
            this.Fj = bl2;
            this.Fk = string2;
            this.Fl = n3;
            this.Fm = class_;
            this.Fn = class_ == null ? null : class_.getCanonicalName();
            this.Fp = zza2;
        }

        public static Field zza(String string2, int n, zza<?, ?> zza2, boolean bl) {
            return new Field(7, bl, 0, false, string2, n, null, zza2);
        }

        public static <T extends FastJsonResponse> Field<T, T> zza(String string2, int n, Class<T> class_) {
            return new Field<I, O>(11, false, 11, false, string2, n, class_, null);
        }

        public static <T extends FastJsonResponse> Field<ArrayList<T>, ArrayList<T>> zzb(String string2, int n, Class<T> class_) {
            return new Field<ArrayList<T>, ArrayList<T>>(11, true, 11, true, string2, n, class_, null);
        }

        public static Field<Integer, Integer> zzk(String string2, int n) {
            return new Field<Integer, Integer>(0, false, 0, false, string2, n, null, null);
        }

        public static Field<Boolean, Boolean> zzl(String string2, int n) {
            return new Field<Boolean, Boolean>(6, false, 6, false, string2, n, null, null);
        }

        public static Field<String, String> zzm(String string2, int n) {
            return new Field<String, String>(7, false, 7, false, string2, n, null, null);
        }

        public I convertBack(O o) {
            return this.Fp.convertBack(o);
        }

        public int getVersionCode() {
            return this.mVersionCode;
        }

        public String toString() {
            zzz.zza zza2 = zzz.zzx(this).zzg("versionCode", this.mVersionCode).zzg("typeIn", this.Fg).zzg("typeInArray", this.Fh).zzg("typeOut", this.Fi).zzg("typeOutArray", this.Fj).zzg("outputFieldName", this.Fk).zzg("safeParcelFieldId", this.Fl).zzg("concreteTypeName", this.zzaxh());
            Class<FastJsonResponse> class_ = this.zzaxg();
            if (class_ != null) {
                zza2.zzg("concreteType.class", class_.getCanonicalName());
            }
            if (this.Fp != null) {
                zza2.zzg("converterName", this.Fp.getClass().getCanonicalName());
            }
            return zza2.toString();
        }

        public void writeToParcel(Parcel parcel, int n) {
            com.google.android.gms.common.server.response.zza.zza(this, parcel, n);
        }

        public void zza(FieldMappingDictionary fieldMappingDictionary) {
            this.Fo = fieldMappingDictionary;
        }

        public int zzaxa() {
            return this.Fg;
        }

        public boolean zzaxb() {
            return this.Fh;
        }

        public int zzaxc() {
            return this.Fi;
        }

        public boolean zzaxd() {
            return this.Fj;
        }

        public String zzaxe() {
            return this.Fk;
        }

        public int zzaxf() {
            return this.Fl;
        }

        public Class<? extends FastJsonResponse> zzaxg() {
            return this.Fm;
        }

        String zzaxh() {
            if (this.Fn == null) {
                return null;
            }
            return this.Fn;
        }

        public boolean zzaxi() {
            if (this.Fp != null) {
                return true;
            }
            return false;
        }

        ConverterWrapper zzaxj() {
            if (this.Fp == null) {
                return null;
            }
            return ConverterWrapper.zza(this.Fp);
        }

        public Map<String, Field<?, ?>> zzaxk() {
            zzaa.zzy(this.Fn);
            zzaa.zzy(this.Fo);
            return this.Fo.zzig(this.Fn);
        }
    }

    public static interface zza<I, O> {
        public I convertBack(O var1);
    }

}

