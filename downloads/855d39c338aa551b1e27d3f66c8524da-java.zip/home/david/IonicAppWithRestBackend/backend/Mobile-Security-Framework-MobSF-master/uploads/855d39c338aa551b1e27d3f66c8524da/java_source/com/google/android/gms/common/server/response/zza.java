/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.server.converter.ConverterWrapper;
import com.google.android.gms.common.server.response.FastJsonResponse;

public class zza
implements Parcelable.Creator<FastJsonResponse.Field> {
    static void zza(FastJsonResponse.Field field, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, field.getVersionCode());
        zzb.zzc(parcel, 2, field.zzaxa());
        zzb.zza(parcel, 3, field.zzaxb());
        zzb.zzc(parcel, 4, field.zzaxc());
        zzb.zza(parcel, 5, field.zzaxd());
        zzb.zza(parcel, 6, field.zzaxe(), false);
        zzb.zzc(parcel, 7, field.zzaxf());
        zzb.zza(parcel, 8, field.zzaxh(), false);
        zzb.zza(parcel, 9, field.zzaxj(), n, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcx(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzha(n);
    }

    public FastJsonResponse.Field zzcx(Parcel parcel) {
        ConverterWrapper converterWrapper = null;
        int n = 0;
        int n2 = com.google.android.gms.common.internal.safeparcel.zza.zzcr(parcel);
        String string2 = null;
        String string3 = null;
        boolean bl = false;
        int n3 = 0;
        boolean bl2 = false;
        int n4 = 0;
        int n5 = 0;
        block11 : while (parcel.dataPosition() < n2) {
            int n6 = com.google.android.gms.common.internal.safeparcel.zza.zzcq(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zza.zzgu(n6)) {
                default: {
                    com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, n6);
                    continue block11;
                }
                case 1: {
                    n5 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n6);
                    continue block11;
                }
                case 2: {
                    n4 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n6);
                    continue block11;
                }
                case 3: {
                    bl2 = com.google.android.gms.common.internal.safeparcel.zza.zzc(parcel, n6);
                    continue block11;
                }
                case 4: {
                    n3 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n6);
                    continue block11;
                }
                case 5: {
                    bl = com.google.android.gms.common.internal.safeparcel.zza.zzc(parcel, n6);
                    continue block11;
                }
                case 6: {
                    string3 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n6);
                    continue block11;
                }
                case 7: {
                    n = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n6);
                    continue block11;
                }
                case 8: {
                    string2 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n6);
                    continue block11;
                }
                case 9: 
            }
            converterWrapper = com.google.android.gms.common.internal.safeparcel.zza.zza(parcel, n6, ConverterWrapper.CREATOR);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new FastJsonResponse.Field(n5, n4, bl2, n3, bl, string3, n, string2, converterWrapper);
    }

    public FastJsonResponse.Field[] zzha(int n) {
        return new FastJsonResponse.Field[n];
    }
}

