/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.server.response.FastJsonResponse;
import com.google.android.gms.common.server.response.FieldMappingDictionary;
import com.google.android.gms.common.server.response.zza;

public class zzb
implements Parcelable.Creator<FieldMappingDictionary.FieldMapPair> {
    static void zza(FieldMappingDictionary.FieldMapPair fieldMapPair, Parcel parcel, int n) {
        int n2 = com.google.android.gms.common.internal.safeparcel.zzb.zzcs(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1, fieldMapPair.versionCode);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 2, fieldMapPair.zzcb, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 3, fieldMapPair.Fu, n, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcy(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzhb(n);
    }

    public FieldMappingDictionary.FieldMapPair zzcy(Parcel parcel) {
        FastJsonResponse.Field field = null;
        int n = com.google.android.gms.common.internal.safeparcel.zza.zzcr(parcel);
        int n2 = 0;
        String string2 = null;
        block5 : while (parcel.dataPosition() < n) {
            int n3 = com.google.android.gms.common.internal.safeparcel.zza.zzcq(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zza.zzgu(n3)) {
                default: {
                    com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, n3);
                    continue block5;
                }
                case 1: {
                    n2 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n3);
                    continue block5;
                }
                case 2: {
                    string2 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n3);
                    continue block5;
                }
                case 3: 
            }
            field = (FastJsonResponse.Field)com.google.android.gms.common.internal.safeparcel.zza.zza(parcel, n3, FastJsonResponse.Field.CREATOR);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new FieldMappingDictionary.FieldMapPair(n2, string2, field);
    }

    public FieldMappingDictionary.FieldMapPair[] zzhb(int n) {
        return new FieldMappingDictionary.FieldMapPair[n];
    }
}

