/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.server.response.FieldMappingDictionary;
import java.util.ArrayList;

public class zzc
implements Parcelable.Creator<FieldMappingDictionary> {
    static void zza(FieldMappingDictionary fieldMappingDictionary, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, fieldMappingDictionary.mVersionCode);
        zzb.zzc(parcel, 2, fieldMappingDictionary.zzaxm(), false);
        zzb.zza(parcel, 3, fieldMappingDictionary.zzaxn(), false);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcz(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzhc(n);
    }

    public FieldMappingDictionary zzcz(Parcel parcel) {
        String string2 = null;
        int n = zza.zzcr(parcel);
        int n2 = 0;
        ArrayList<FieldMappingDictionary.Entry> arrayList = null;
        block5 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block5;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block5;
                }
                case 2: {
                    arrayList = zza.zzc(parcel, n3, FieldMappingDictionary.Entry.CREATOR);
                    continue block5;
                }
                case 3: 
            }
            string2 = zza.zzq(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new FieldMappingDictionary(n2, arrayList, string2);
    }

    public FieldMappingDictionary[] zzhc(int n) {
        return new FieldMappingDictionary[n];
    }
}

