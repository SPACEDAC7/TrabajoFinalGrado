/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.server.response.FieldMappingDictionary;
import java.util.ArrayList;

public class zzd
implements Parcelable.Creator<FieldMappingDictionary.Entry> {
    static void zza(FieldMappingDictionary.Entry entry, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, entry.versionCode);
        zzb.zza(parcel, 2, entry.className, false);
        zzb.zzc(parcel, 3, entry.Ft, false);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzda(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzhd(n);
    }

    public FieldMappingDictionary.Entry zzda(Parcel parcel) {
        ArrayList<FieldMappingDictionary.FieldMapPair> arrayList = null;
        int n = zza.zzcr(parcel);
        int n2 = 0;
        String string2 = null;
        block5 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block5;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block5;
                }
                case 2: {
                    string2 = zza.zzq(parcel, n3);
                    continue block5;
                }
                case 3: 
            }
            arrayList = zza.zzc(parcel, n3, FieldMappingDictionary.FieldMapPair.CREATOR);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new FieldMappingDictionary.Entry(n2, string2, arrayList);
    }

    public FieldMappingDictionary.Entry[] zzhd(int n) {
        return new FieldMappingDictionary.Entry[n];
    }
}

