/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.server.response.FieldMappingDictionary;
import com.google.android.gms.common.server.response.SafeParcelResponse;

public class zze
implements Parcelable.Creator<SafeParcelResponse> {
    static void zza(SafeParcelResponse safeParcelResponse, Parcel parcel, int n) {
        int n2 = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, safeParcelResponse.getVersionCode());
        zzb.zza(parcel, 2, safeParcelResponse.zzaxp(), false);
        zzb.zza(parcel, 3, safeParcelResponse.zzaxq(), n, false);
        zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzdb(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzhe(n);
    }

    public SafeParcelResponse zzdb(Parcel parcel) {
        FieldMappingDictionary fieldMappingDictionary = null;
        int n = zza.zzcr(parcel);
        int n2 = 0;
        Parcel parcel2 = null;
        block5 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block5;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block5;
                }
                case 2: {
                    parcel2 = zza.zzaf(parcel, n3);
                    continue block5;
                }
                case 3: 
            }
            fieldMappingDictionary = zza.zza(parcel, n3, FieldMappingDictionary.CREATOR);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new SafeParcelResponse(n2, parcel2, fieldMappingDictionary);
    }

    public SafeParcelResponse[] zzhe(int n) {
        return new SafeParcelResponse[n];
    }
}

