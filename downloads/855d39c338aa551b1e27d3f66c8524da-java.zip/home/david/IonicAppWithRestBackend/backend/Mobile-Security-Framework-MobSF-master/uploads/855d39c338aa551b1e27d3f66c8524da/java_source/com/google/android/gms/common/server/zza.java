/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.server;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.server.FavaDiagnosticsEntity;

public class zza
implements Parcelable.Creator<FavaDiagnosticsEntity> {
    static void zza(FavaDiagnosticsEntity favaDiagnosticsEntity, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, favaDiagnosticsEntity.mVersionCode);
        zzb.zza(parcel, 2, favaDiagnosticsEntity.EY, false);
        zzb.zzc(parcel, 3, favaDiagnosticsEntity.EZ);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzct(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzgw(n);
    }

    public FavaDiagnosticsEntity zzct(Parcel parcel) {
        int n = 0;
        int n2 = com.google.android.gms.common.internal.safeparcel.zza.zzcr(parcel);
        String string2 = null;
        int n3 = 0;
        block5 : while (parcel.dataPosition() < n2) {
            int n4 = com.google.android.gms.common.internal.safeparcel.zza.zzcq(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zza.zzgu(n4)) {
                default: {
                    com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, n4);
                    continue block5;
                }
                case 1: {
                    n3 = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n4);
                    continue block5;
                }
                case 2: {
                    string2 = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, n4);
                    continue block5;
                }
                case 3: 
            }
            n = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, n4);
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new FavaDiagnosticsEntity(n3, string2, n);
    }

    public FavaDiagnosticsEntity[] zzgw(int n) {
        return new FavaDiagnosticsEntity[n];
    }
}

