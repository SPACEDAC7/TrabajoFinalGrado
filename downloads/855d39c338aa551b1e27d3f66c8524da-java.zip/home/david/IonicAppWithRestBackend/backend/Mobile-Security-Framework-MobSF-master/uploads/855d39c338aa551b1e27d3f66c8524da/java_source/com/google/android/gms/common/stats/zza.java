/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.util.Log
 */
package com.google.android.gms.common.stats;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.util.Log;
import com.google.android.gms.common.stats.zzb;
import com.google.android.gms.common.stats.zzc;
import com.google.android.gms.common.stats.zzd;
import com.google.android.gms.internal.zzsi;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class zza {
    private static final Object El = new Object();
    private static Integer FF;
    private static zza Fz;
    private final List<String> FA;
    private final List<String> FB;
    private final List<String> FC;
    private final List<String> FD;
    private zzd FE;
    private zzd FG;

    /*
     * Enabled aggressive block sorting
     */
    private zza() {
        if (this.zzaxs()) {
            this.FA = Collections.EMPTY_LIST;
            this.FB = Collections.EMPTY_LIST;
            this.FC = Collections.EMPTY_LIST;
            this.FD = Collections.EMPTY_LIST;
            return;
        }
        Object object = zzb.zza.FK.get();
        object = object == null ? Collections.EMPTY_LIST : Arrays.asList(object.split(","));
        this.FA = object;
        object = zzb.zza.FL.get();
        object = object == null ? Collections.EMPTY_LIST : Arrays.asList(object.split(","));
        this.FB = object;
        object = zzb.zza.FM.get();
        object = object == null ? Collections.EMPTY_LIST : Arrays.asList(object.split(","));
        this.FC = object;
        object = zzb.zza.FN.get();
        object = object == null ? Collections.EMPTY_LIST : Arrays.asList(object.split(","));
        this.FD = object;
        this.FE = new zzd(1024, zzb.zza.FO.get());
        this.FG = new zzd(1024, zzb.zza.FO.get());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static int getLogLevel() {
        if (FF != null) return FF;
        try {
            int n = com.google.android.gms.common.util.zzd.zzayi() ? zzb.zza.FJ.get() : zzc.LOG_LEVEL_OFF;
            FF = n;
        }
        catch (SecurityException var1_1) {
            FF = zzc.LOG_LEVEL_OFF;
            return FF;
        }
        return FF;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static zza zzaxr() {
        Object object = El;
        synchronized (object) {
            if (Fz == null) {
                Fz = new zza();
            }
            return Fz;
        }
    }

    private boolean zzaxs() {
        if (zza.getLogLevel() == zzc.LOG_LEVEL_OFF) {
            return true;
        }
        return false;
    }

    private boolean zzc(Context context, Intent intent) {
        if ((intent = intent.getComponent()) == null) {
            return false;
        }
        return com.google.android.gms.common.util.zzd.zzx(context, intent.getPackageName());
    }

    @SuppressLint(value={"UntrackedBindService"})
    public void zza(Context context, ServiceConnection serviceConnection) {
        context.unbindService(serviceConnection);
    }

    public void zza(Context context, ServiceConnection serviceConnection, String string2, Intent intent) {
    }

    public boolean zza(Context context, Intent intent, ServiceConnection serviceConnection, int n) {
        return this.zza(context, context.getClass().getName(), intent, serviceConnection, n);
    }

    @SuppressLint(value={"UntrackedBindService"})
    public boolean zza(Context context, String string2, Intent intent, ServiceConnection serviceConnection, int n) {
        if (this.zzc(context, intent)) {
            Log.w((String)"ConnectionTracker", (String)"Attempted to bind to a service in a STOPPED package.");
            return false;
        }
        return context.bindService(intent, serviceConnection, n);
    }

    public void zzb(Context context, ServiceConnection serviceConnection) {
    }
}

