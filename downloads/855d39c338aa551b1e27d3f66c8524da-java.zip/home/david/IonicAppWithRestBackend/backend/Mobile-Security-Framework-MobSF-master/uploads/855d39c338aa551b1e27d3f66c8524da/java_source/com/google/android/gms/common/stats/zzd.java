/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.stats;

import android.support.v4.util.SimpleArrayMap;

public class zzd {
    private final long FX;
    private final int FY;
    private final SimpleArrayMap<String, Long> FZ;

    public zzd() {
        this.FX = 60000;
        this.FY = 10;
        this.FZ = new SimpleArrayMap(10);
    }

    public zzd(int n, long l) {
        this.FX = l;
        this.FY = n;
        this.FZ = new SimpleArrayMap();
    }
}

