/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.PowerManager
 *  android.os.PowerManager$WakeLock
 *  android.os.Process
 *  android.text.TextUtils
 */
package com.google.android.gms.common.stats;

import android.os.PowerManager;
import android.os.Process;
import android.text.TextUtils;
import java.util.List;

public class zze {
    public static String zza(PowerManager.WakeLock object, String string2) {
        String string3 = String.valueOf(String.valueOf((long)Process.myPid() << 32 | (long)System.identityHashCode(object)));
        object = string2;
        if (TextUtils.isEmpty((CharSequence)string2)) {
            object = "";
        }
        if ((object = String.valueOf(object)).length() != 0) {
            return string3.concat((String)object);
        }
        return new String(string3);
    }

    static String zzih(String string2) {
        String string3 = string2;
        if ("com.google.android.gms".equals(string2)) {
            string3 = null;
        }
        return string3;
    }

    static List<String> zzz(List<String> list) {
        List<String> list2 = list;
        if (list != null) {
            list2 = list;
            if (list.size() == 1) {
                list2 = list;
                if ("com.google.android.gms".equals(list.get(0))) {
                    list2 = null;
                }
            }
        }
        return list2;
    }
}

