/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.stats.WakeLockEvent;
import java.util.ArrayList;
import java.util.List;

public class zzf
implements Parcelable.Creator<WakeLockEvent> {
    static void zza(WakeLockEvent wakeLockEvent, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, wakeLockEvent.mVersionCode);
        zzb.zza(parcel, 2, wakeLockEvent.getTimeMillis());
        zzb.zza(parcel, 4, wakeLockEvent.zzaxv(), false);
        zzb.zzc(parcel, 5, wakeLockEvent.zzaxy());
        zzb.zzb(parcel, 6, wakeLockEvent.zzaxz(), false);
        zzb.zza(parcel, 8, wakeLockEvent.zzayb());
        zzb.zza(parcel, 10, wakeLockEvent.zzaxw(), false);
        zzb.zzc(parcel, 11, wakeLockEvent.getEventType());
        zzb.zza(parcel, 12, wakeLockEvent.zzaya(), false);
        zzb.zza(parcel, 13, wakeLockEvent.zzayd(), false);
        zzb.zzc(parcel, 14, wakeLockEvent.zzayc());
        zzb.zza(parcel, 15, wakeLockEvent.zzaye());
        zzb.zza(parcel, 16, wakeLockEvent.zzayf());
        zzb.zza(parcel, 17, wakeLockEvent.zzaxx(), false);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzdc(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzhf(n);
    }

    public WakeLockEvent zzdc(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        long l = 0;
        int n3 = 0;
        String string2 = null;
        int n4 = 0;
        ArrayList<String> arrayList = null;
        String string3 = null;
        long l2 = 0;
        int n5 = 0;
        String string4 = null;
        String string5 = null;
        float f = 0.0f;
        long l3 = 0;
        String string6 = null;
        block16 : while (parcel.dataPosition() < n) {
            int n6 = zza.zzcq(parcel);
            switch (zza.zzgu(n6)) {
                default: {
                    zza.zzb(parcel, n6);
                    continue block16;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n6);
                    continue block16;
                }
                case 2: {
                    l = zza.zzi(parcel, n6);
                    continue block16;
                }
                case 4: {
                    string2 = zza.zzq(parcel, n6);
                    continue block16;
                }
                case 5: {
                    n4 = zza.zzg(parcel, n6);
                    continue block16;
                }
                case 6: {
                    arrayList = zza.zzae(parcel, n6);
                    continue block16;
                }
                case 8: {
                    l2 = zza.zzi(parcel, n6);
                    continue block16;
                }
                case 10: {
                    string4 = zza.zzq(parcel, n6);
                    continue block16;
                }
                case 11: {
                    n3 = zza.zzg(parcel, n6);
                    continue block16;
                }
                case 12: {
                    string3 = zza.zzq(parcel, n6);
                    continue block16;
                }
                case 13: {
                    string5 = zza.zzq(parcel, n6);
                    continue block16;
                }
                case 14: {
                    n5 = zza.zzg(parcel, n6);
                    continue block16;
                }
                case 15: {
                    f = zza.zzl(parcel, n6);
                    continue block16;
                }
                case 16: {
                    l3 = zza.zzi(parcel, n6);
                    continue block16;
                }
                case 17: 
            }
            string6 = zza.zzq(parcel, n6);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new WakeLockEvent(n2, l, n3, string2, n4, arrayList, string3, l2, n5, string4, string5, f, l3, string6);
    }

    public WakeLockEvent[] zzhf(int n) {
        return new WakeLockEvent[n];
    }
}

