/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Parcelable
 *  android.os.SystemClock
 *  android.text.TextUtils
 *  android.util.Log
 */
package com.google.android.gms.common.stats;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.stats.WakeLockEvent;
import com.google.android.gms.common.stats.zzb;
import com.google.android.gms.common.stats.zzc;
import com.google.android.gms.common.stats.zze;
import com.google.android.gms.common.util.zzd;
import com.google.android.gms.common.util.zzj;
import com.google.android.gms.internal.zzsi;
import java.util.List;

public class zzg {
    private static zzg Gn;
    private static Boolean Go;
    private static String TAG;

    static {
        TAG = "WakeLockTracker";
        Gn = new zzg();
    }

    public static zzg zzayg() {
        return Gn;
    }

    private static boolean zzcg(Context context) {
        if (Go == null) {
            Go = zzg.zzch(context);
        }
        return Go;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean zzch(Context context) {
        boolean bl = false;
        try {
            int n;
            if (!zzd.zzayi()) return bl;
            int n2 = zzb.zzb.FJ.get();
            if (n2 == (n = zzc.LOG_LEVEL_OFF)) return false;
            return true;
        }
        catch (SecurityException var0_1) {
            return false;
        }
    }

    public void zza(Context context, String string2, int n, String string3, String string4, String string5, int n2, List<String> list) {
        this.zza(context, string2, n, string3, string4, string5, n2, list, 0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void zza(Context object, String object2, int n, String string2, String string3, String string4, int n2, List<String> list, long l) {
        if (!zzg.zzcg((Context)object)) {
            return;
        }
        if (TextUtils.isEmpty((CharSequence)object2)) {
            string2 = TAG;
            object = String.valueOf(object2);
            object = object.length() != 0 ? "missing wakeLock key. ".concat((String)object) : new String("missing wakeLock key. ");
            Log.e((String)string2, (String)object);
            return;
        }
        long l2 = System.currentTimeMillis();
        if (7 != n && 8 != n && 10 != n) {
            if (11 != n) return;
        }
        object2 = new WakeLockEvent(l2, n, string2, n2, zze.zzz(list), (String)object2, SystemClock.elapsedRealtime(), zzj.zzck((Context)object), string3, zze.zzih(object.getPackageName()), zzj.zzcl((Context)object), l, string4);
        try {
            object.startService(new Intent().setComponent(zzc.FP).putExtra("com.google.android.gms.common.stats.EXTRA_LOG_EVENT", (Parcelable)object2));
            return;
        }
        catch (Exception var1_2) {
            Log.wtf((String)TAG, (Throwable)var1_2);
            return;
        }
    }
}

