/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.util;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target(value={ElementType.TYPE})
public @interface DynamiteApi {
}

