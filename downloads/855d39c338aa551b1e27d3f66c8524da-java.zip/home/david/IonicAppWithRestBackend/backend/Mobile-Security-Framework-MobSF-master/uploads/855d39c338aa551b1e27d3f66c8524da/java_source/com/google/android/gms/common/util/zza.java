/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.util;

import android.support.v4.util.ArrayMap;
import android.support.v4.util.SimpleArrayMap;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public class zza<E>
extends AbstractSet<E> {
    private final ArrayMap<E, E> Gp;

    public zza() {
        this.Gp = new ArrayMap();
    }

    public zza(int n) {
        this.Gp = new ArrayMap(n);
    }

    public zza(Collection<E> collection) {
        this(collection.size());
        this.addAll(collection);
    }

    @Override
    public boolean add(E e) {
        if (this.Gp.containsKey(e)) {
            return false;
        }
        this.Gp.put(e, e);
        return true;
    }

    @Override
    public boolean addAll(Collection<? extends E> collection) {
        if (collection instanceof zza) {
            return this.zza((zza)collection);
        }
        return super.addAll(collection);
    }

    @Override
    public void clear() {
        this.Gp.clear();
    }

    @Override
    public boolean contains(Object object) {
        return this.Gp.containsKey(object);
    }

    @Override
    public Iterator<E> iterator() {
        return this.Gp.keySet().iterator();
    }

    @Override
    public boolean remove(Object object) {
        if (!this.Gp.containsKey(object)) {
            return false;
        }
        this.Gp.remove(object);
        return true;
    }

    @Override
    public int size() {
        return this.Gp.size();
    }

    public boolean zza(zza<? extends E> zza2) {
        int n = this.size();
        this.Gp.putAll(zza2.Gp);
        if (this.size() > n) {
            return true;
        }
        return false;
    }
}

