/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.util;

import com.google.android.gms.common.internal.zzz;
import java.util.ArrayList;
import java.util.Arrays;

public final class zzb {
    /*
     * Enabled aggressive block sorting
     */
    public static <T> int zza(T[] arrT, T t) {
        int n = 0;
        int n2 = arrT != null ? arrT.length : 0;
        while (n < n2) {
            if (zzz.equal(arrT[n], t)) {
                return n;
            }
            ++n;
        }
        return -1;
    }

    public static void zza(StringBuilder stringBuilder, double[] arrd) {
        int n = arrd.length;
        for (int i = 0; i < n; ++i) {
            if (i != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append(Double.toString(arrd[i]));
        }
    }

    public static void zza(StringBuilder stringBuilder, float[] arrf) {
        int n = arrf.length;
        for (int i = 0; i < n; ++i) {
            if (i != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append(Float.toString(arrf[i]));
        }
    }

    public static void zza(StringBuilder stringBuilder, int[] arrn) {
        int n = arrn.length;
        for (int i = 0; i < n; ++i) {
            if (i != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append(Integer.toString(arrn[i]));
        }
    }

    public static void zza(StringBuilder stringBuilder, long[] arrl) {
        int n = arrl.length;
        for (int i = 0; i < n; ++i) {
            if (i != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append(Long.toString(arrl[i]));
        }
    }

    public static <T> void zza(StringBuilder stringBuilder, T[] arrT) {
        int n = arrT.length;
        for (int i = 0; i < n; ++i) {
            if (i != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append(arrT[i].toString());
        }
    }

    public static void zza(StringBuilder stringBuilder, String[] arrstring) {
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            if (i != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append("\"").append(arrstring[i]).append("\"");
        }
    }

    public static void zza(StringBuilder stringBuilder, boolean[] arrbl) {
        int n = arrbl.length;
        for (int i = 0; i < n; ++i) {
            if (i != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append(Boolean.toString(arrbl[i]));
        }
    }

    public static /* varargs */ byte[] zza(byte[] ... arrby) {
        int n;
        if (arrby.length == 0) {
            return new byte[0];
        }
        int n2 = 0;
        for (n = 0; n < arrby.length; ++n) {
            n2 += arrby[n].length;
        }
        byte[] arrby2 = Arrays.copyOf(arrby[0], n2);
        n2 = arrby[0].length;
        for (n = 1; n < arrby.length; ++n) {
            byte[] arrby3 = arrby[n];
            System.arraycopy(arrby3, 0, arrby2, n2, arrby3.length);
            n2 += arrby3.length;
        }
        return arrby2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Integer[] zza(int[] arrn) {
        if (arrn == null) {
            return null;
        }
        int n = arrn.length;
        Integer[] arrinteger = new Integer[n];
        int n2 = 0;
        do {
            Integer[] arrinteger2 = arrinteger;
            if (n2 >= n) return arrinteger2;
            arrinteger[n2] = arrn[n2];
            ++n2;
        } while (true);
    }

    public static <T> ArrayList<T> zzayh() {
        return new ArrayList();
    }

    public static <T> ArrayList<T> zzb(T[] arrT) {
        int n = arrT.length;
        ArrayList<T> arrayList = new ArrayList<T>(n);
        for (int i = 0; i < n; ++i) {
            arrayList.add(arrT[i]);
        }
        return arrayList;
    }

    public static <T> boolean zzb(T[] arrT, T t) {
        if (zzb.zza(arrT, t) >= 0) {
            return true;
        }
        return false;
    }
}

