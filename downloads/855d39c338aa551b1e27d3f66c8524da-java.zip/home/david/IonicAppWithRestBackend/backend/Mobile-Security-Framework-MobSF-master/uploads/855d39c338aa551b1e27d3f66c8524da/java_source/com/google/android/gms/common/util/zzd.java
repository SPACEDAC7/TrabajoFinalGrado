/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 */
package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import com.google.android.gms.common.util.zzs;
import com.google.android.gms.internal.zzsz;

public class zzd {
    /*
     * Enabled aggressive block sorting
     */
    public static int zza(PackageInfo packageInfo) {
        if (packageInfo == null || packageInfo.applicationInfo == null || (packageInfo = packageInfo.applicationInfo.metaData) == null) {
            return -1;
        }
        return packageInfo.getInt("com.google.android.gms.version", -1);
    }

    public static boolean zzayi() {
        return false;
    }

    public static int zzv(Context context, String string2) {
        return zzd.zza(zzd.zzw(context, string2));
    }

    @Nullable
    public static PackageInfo zzw(Context context, String string2) {
        try {
            context = zzsz.zzco(context).getPackageInfo(string2, 128);
            return context;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @TargetApi(value=12)
    public static boolean zzx(Context context, String string2) {
        if (!zzs.zzayo()) {
            return false;
        }
        if ("com.google.android.gms".equals(string2)) {
            if (zzd.zzayi()) return false;
        }
        try {
            int n = zzsz.zzco((Context)context).getApplicationInfo((String)string2, (int)0).flags;
            if ((n & 2097152) == 0) return false;
            return true;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            return false;
        }
    }
}

