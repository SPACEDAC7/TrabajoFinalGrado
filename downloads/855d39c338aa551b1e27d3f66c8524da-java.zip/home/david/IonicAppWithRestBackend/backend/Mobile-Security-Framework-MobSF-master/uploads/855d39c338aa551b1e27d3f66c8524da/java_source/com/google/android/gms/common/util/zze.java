/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.util;

public interface zze {
    public long currentTimeMillis();

    public long elapsedRealtime();

    public long nanoTime();
}

