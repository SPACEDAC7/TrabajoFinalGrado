/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.util;

import android.support.v4.util.ArrayMap;
import com.google.android.gms.common.util.zza;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class zzf {
    public static <K, V> Map<K, V> zza(K k, V v, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5, K k6, V v6) {
        ArrayMap<K, V> arrayMap = new ArrayMap<K, V>(6);
        arrayMap.put(k, v);
        arrayMap.put(k2, v2);
        arrayMap.put(k3, v3);
        arrayMap.put(k4, v4);
        arrayMap.put(k5, v5);
        arrayMap.put(k6, v6);
        return Collections.unmodifiableMap(arrayMap);
    }

    public static <T> Set<T> zza(T t, T t2, T t3) {
        zza<T> zza2 = new zza<T>(3);
        zza2.add(t);
        zza2.add(t2);
        zza2.add(t3);
        return Collections.unmodifiableSet(zza2);
    }

    public static <T> Set<T> zza(T t, T t2, T t3, T t4) {
        zza<T> zza2 = new zza<T>(4);
        zza2.add(t);
        zza2.add(t2);
        zza2.add(t3);
        zza2.add(t4);
        return Collections.unmodifiableSet(zza2);
    }

    private static <K, V> void zza(K[] arrK, V[] arrV) {
        if (arrK.length != arrV.length) {
            int n = arrK.length;
            int n2 = arrV.length;
            throw new IllegalArgumentException(new StringBuilder(66).append("Key and values array lengths not equal: ").append(n).append(" != ").append(n2).toString());
        }
    }

    public static <T> Set<T> zzaa(T t) {
        return Collections.singleton(t);
    }

    public static <T> Set<T> zzayj() {
        return Collections.emptySet();
    }

    public static <K, V> Map<K, V> zzayk() {
        return Collections.emptyMap();
    }

    /*
     * Enabled aggressive block sorting
     */
    public static <K, V> Map<K, V> zzb(K[] arrK, V[] arrV) {
        Map map;
        zzf.zza(arrK, arrV);
        int n = arrK.length;
        switch (n) {
            default: {
                map = n <= 32 ? new ArrayMap(n) : new HashMap(n, 1.0f);
            }
            case 0: {
                return zzf.zzayk();
            }
            case 1: {
                return zzf.zze(arrK[0], arrV[0]);
            }
        }
        for (int i = 0; i < n; ++i) {
            map.put(arrK[i], arrV[i]);
        }
        return Collections.unmodifiableMap(map);
    }

    public static <T> List<T> zzc(T t, T t2) {
        ArrayList<T> arrayList = new ArrayList<T>(2);
        arrayList.add(t);
        arrayList.add(t2);
        return Collections.unmodifiableList(arrayList);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static /* varargs */ <T> Set<T> zzc(T ... abstractSet) {
        switch (abstractSet.length) {
            default: {
                if (abstractSet.length > 32) break;
                abstractSet = new zza(Arrays.asList(abstractSet));
                do {
                    return Collections.unmodifiableSet(abstractSet);
                    break;
                } while (true);
            }
            case 0: {
                return zzf.zzayj();
            }
            case 1: {
                return zzf.zzaa(abstractSet[0]);
            }
            case 2: {
                return zzf.zzd(abstractSet[0], abstractSet[1]);
            }
            case 3: {
                return zzf.zza(abstractSet[0], abstractSet[1], abstractSet[2]);
            }
            case 4: {
                return zzf.zza(abstractSet[0], abstractSet[1], abstractSet[2], abstractSet[3]);
            }
        }
        abstractSet = new HashSet(Arrays.asList(abstractSet));
        return Collections.unmodifiableSet(abstractSet);
    }

    public static <T> Set<T> zzd(T t, T t2) {
        zza<T> zza2 = new zza<T>(2);
        zza2.add(t);
        zza2.add(t2);
        return Collections.unmodifiableSet(zza2);
    }

    public static <K, V> Map<K, V> zze(K k, V v) {
        return Collections.singletonMap(k, v);
    }

    public static <T> List<T> zzz(T t) {
        return Collections.singletonList(t);
    }
}

