/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.pm.PackageManager
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.os.Build
 */
package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import com.google.android.gms.common.util.zzs;
import com.google.android.gms.common.zze;

public final class zzi {
    private static Boolean Gr;
    private static Boolean Gs;
    private static Boolean Gt;
    private static Boolean Gu;

    public static boolean zzaym() {
        boolean bl = zze.xb;
        return "user".equals(Build.TYPE);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean zzb(Resources resources) {
        boolean bl = false;
        if (resources == null) {
            return false;
        }
        if (Gr == null) {
            boolean bl2 = (resources.getConfiguration().screenLayout & 15) > 3;
            if (zzs.zzayn() && bl2 || zzi.zzc(resources)) {
                bl = true;
            }
            Gr = bl;
        }
        return Gr;
    }

    /*
     * Enabled aggressive block sorting
     */
    @TargetApi(value=13)
    private static boolean zzc(Resources resources) {
        if (Gs == null) {
            resources = resources.getConfiguration();
            boolean bl = zzs.zzayp() && (resources.screenLayout & 15) <= 3 && resources.smallestScreenWidthDp >= 600;
            Gs = bl;
        }
        return Gs;
    }

    /*
     * Enabled aggressive block sorting
     */
    @TargetApi(value=20)
    public static boolean zzci(Context context) {
        if (Gt == null) {
            boolean bl = zzs.zzayv() && context.getPackageManager().hasSystemFeature("android.hardware.type.watch");
            Gt = bl;
        }
        return Gt;
    }

    /*
     * Enabled aggressive block sorting
     */
    @TargetApi(value=21)
    public static boolean zzcj(Context context) {
        if (Gu == null) {
            boolean bl = zzs.zzayx() && context.getPackageManager().hasSystemFeature("cn.google");
            Gu = bl;
        }
        return Gu;
    }
}

