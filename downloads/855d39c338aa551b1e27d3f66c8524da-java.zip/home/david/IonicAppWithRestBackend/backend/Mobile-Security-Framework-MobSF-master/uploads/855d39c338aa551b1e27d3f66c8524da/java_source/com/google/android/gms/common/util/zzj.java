/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.PowerManager
 *  android.os.SystemClock
 */
package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.PowerManager;
import android.os.SystemClock;
import com.google.android.gms.common.util.zzs;

public final class zzj {
    private static IntentFilter Gv = new IntentFilter("android.intent.action.BATTERY_CHANGED");
    private static long Gw;
    private static float Gx;

    static {
        Gx = Float.NaN;
    }

    @TargetApi(value=20)
    public static boolean zzb(PowerManager powerManager) {
        if (zzs.zzayv()) {
            return powerManager.isInteractive();
        }
        return powerManager.isScreenOn();
    }

    /*
     * Enabled aggressive block sorting
     */
    @TargetApi(value=20)
    public static int zzck(Context context) {
        int n = 1;
        if (context == null) return -1;
        if (context.getApplicationContext() == null) {
            return -1;
        }
        Intent intent = context.getApplicationContext().registerReceiver(null, Gv);
        int n2 = intent == null ? 0 : intent.getIntExtra("plugged", 0);
        n2 = (n2 & 7) != 0 ? 1 : 0;
        if ((context = (PowerManager)context.getSystemService("power")) == null) {
            return -1;
        }
        int n3 = zzj.zzb((PowerManager)context) ? 1 : 0;
        if (n2 != 0) {
            n2 = n;
            return n3 << 1 | n2;
        }
        n2 = 0;
        return n3 << 1 | n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static float zzcl(Context context) {
        synchronized (zzj.class) {
            float f;
            if (SystemClock.elapsedRealtime() - Gw < 60000 && !Float.isNaN(Gx)) {
                f = Gx;
                do {
                    return f;
                    break;
                } while (true);
            }
            if ((context = context.getApplicationContext().registerReceiver(null, Gv)) != null) {
                int n = context.getIntExtra("level", -1);
                int n2 = context.getIntExtra("scale", -1);
                Gx = (float)n / (float)n2;
            }
            Gw = SystemClock.elapsedRealtime();
            f = Gx;
            return f;
        }
    }
}

