/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.util;

public final class zzk {
    public static boolean zzhg(int n) {
        if (n >= 3200000) {
            return true;
        }
        return false;
    }
}

