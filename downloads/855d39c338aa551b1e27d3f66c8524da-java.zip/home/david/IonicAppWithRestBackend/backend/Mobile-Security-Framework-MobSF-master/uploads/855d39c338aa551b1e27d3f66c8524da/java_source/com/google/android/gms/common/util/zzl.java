/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.util;

import java.util.regex.Pattern;

public final class zzl {
    private static Pattern Gy = null;

    public static int zzhh(int n) {
        return n / 1000;
    }
}

