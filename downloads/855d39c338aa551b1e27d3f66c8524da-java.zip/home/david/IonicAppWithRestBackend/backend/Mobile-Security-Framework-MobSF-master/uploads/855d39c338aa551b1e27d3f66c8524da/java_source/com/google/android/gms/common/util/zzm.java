/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.util;

public final class zzm {
    /*
     * Unable to fully structure code
     */
    public static String zza(byte[] var0, int var1_1, int var2_2, boolean var3_3) {
        block15 : {
            if (var0 == null || var0.length == 0 || var1_1 < 0 || var2_2 <= 0 || var1_1 + var2_2 > var0.length) {
                return null;
            }
            var5_4 = 57;
            if (var3_3) {
                var5_4 = 75;
            }
            var10_5 = new StringBuilder(var5_4 * ((var2_2 + 16 - 1) / 16));
            var7_6 = var2_2;
            var8_7 = 0;
            var6_8 = 0;
            block0 : while (var7_6 > 0) {
                block13 : {
                    block14 : {
                        if (var6_8 != 0) ** GOTO lbl28
                        if (var2_2 < 65536) {
                            var10_5.append(String.format("%04X:", new Object[]{var1_1}));
                            var5_4 = var1_1;
lbl15: // 4 sources:
                            do {
                                var10_5.append(String.format(" %02X", new Object[]{var0[var1_1] & 255}));
                                var8_7 = var6_8 + 1;
                                if (!var3_3 || var8_7 != 16 && --var7_6 != 0) break block13;
                                var9_10 = 16 - var8_7;
                                if (var9_10 > 0) {
                                    for (var6_8 = 0; var6_8 < var9_10; ++var6_8) {
                                        var10_5.append("   ");
                                    }
                                }
                                break block14;
                                break;
                            } while (true);
                        }
                        var10_5.append(String.format("%08X:", new Object[]{var1_1}));
                        var5_4 = var1_1;
                        ** GOTO lbl15
lbl28: // 1 sources:
                        var5_4 = var8_7;
                        if (var6_8 != 8) ** GOTO lbl15
                        var10_5.append(" -");
                        var5_4 = var8_7;
                        ** continue;
                    }
                    if (var9_10 >= 8) {
                        var10_5.append("  ");
                    }
                    var10_5.append("  ");
                    block3 : for (var6_8 = 0; var6_8 < var8_7; ++var6_8) {
                        var4_9 = var0[var5_4 + var6_8];
                        if (var4_9 >= ' ' && var4_9 <= '~') lbl-1000: // 2 sources:
                        {
                            do {
                                var10_5.append(var4_9);
                                continue block3;
                                break;
                            } while (true);
                        }
                        var4_9 = '.';
                        ** continue;
                    }
                }
                if (var8_7 == 16 || var7_6 == 0) {
                    var10_5.append('\n');
                    var6_8 = 0;
lbl49: // 2 sources:
                    do {
                        ++var1_1;
                        var8_7 = var5_4;
                        continue block0;
                        break;
                    } while (true);
                }
                break block15;
            }
            return var10_5.toString();
        }
        var6_8 = var8_7;
        ** while (true)
    }
}

