/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class zzq {
    /*
     * Enabled aggressive block sorting
     */
    public static void zza(StringBuilder stringBuilder, HashMap<String, String> hashMap) {
        stringBuilder.append("{");
        Iterator<String> iterator = hashMap.keySet().iterator();
        boolean bl = true;
        do {
            if (!iterator.hasNext()) {
                stringBuilder.append("}");
                return;
            }
            String string2 = iterator.next();
            if (!bl) {
                stringBuilder.append(",");
            } else {
                bl = false;
            }
            String string3 = hashMap.get(string2);
            stringBuilder.append("\"").append(string2).append("\":");
            if (string3 == null) {
                stringBuilder.append("null");
                continue;
            }
            stringBuilder.append("\"").append(string3).append("\"");
        } while (true);
    }
}

