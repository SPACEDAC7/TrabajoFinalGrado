/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package com.google.android.gms.common.util;

import android.os.Build;

public final class zzs {
    public static boolean isAtLeastN() {
        if (Build.VERSION.SDK_INT >= 24) {
            return true;
        }
        return false;
    }

    public static boolean zzayn() {
        if (Build.VERSION.SDK_INT >= 11) {
            return true;
        }
        return false;
    }

    public static boolean zzayo() {
        if (Build.VERSION.SDK_INT >= 12) {
            return true;
        }
        return false;
    }

    public static boolean zzayp() {
        if (Build.VERSION.SDK_INT >= 13) {
            return true;
        }
        return false;
    }

    public static boolean zzayq() {
        if (Build.VERSION.SDK_INT >= 14) {
            return true;
        }
        return false;
    }

    public static boolean zzayr() {
        if (Build.VERSION.SDK_INT >= 16) {
            return true;
        }
        return false;
    }

    public static boolean zzays() {
        if (Build.VERSION.SDK_INT >= 17) {
            return true;
        }
        return false;
    }

    public static boolean zzayt() {
        if (Build.VERSION.SDK_INT >= 18) {
            return true;
        }
        return false;
    }

    public static boolean zzayu() {
        if (Build.VERSION.SDK_INT >= 19) {
            return true;
        }
        return false;
    }

    public static boolean zzayv() {
        if (Build.VERSION.SDK_INT >= 20) {
            return true;
        }
        return false;
    }

    @Deprecated
    public static boolean zzayw() {
        return zzs.zzayx();
    }

    public static boolean zzayx() {
        if (Build.VERSION.SDK_INT >= 21) {
            return true;
        }
        return false;
    }

    public static boolean zzayy() {
        if (Build.VERSION.SDK_INT >= 23) {
            return true;
        }
        return false;
    }
}

