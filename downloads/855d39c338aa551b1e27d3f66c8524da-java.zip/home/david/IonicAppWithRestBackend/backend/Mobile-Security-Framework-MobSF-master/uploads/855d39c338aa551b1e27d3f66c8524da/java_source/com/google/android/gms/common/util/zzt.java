/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Process
 *  android.os.StrictMode
 *  android.os.StrictMode$ThreadPolicy
 */
package com.google.android.gms.common.util;

import android.os.Process;
import android.os.StrictMode;
import com.google.android.gms.common.util.zzo;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class zzt {
    private static String GE = null;
    private static final int GF = Process.myPid();

    public static String zzayz() {
        if (GE == null) {
            GE = zzt.zzhi(GF);
        }
        return GE;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static String zzhi(int var0) {
        if (var0 <= 0) {
            return null;
        }
        var2_1 = StrictMode.allowThreadDiskReads();
        var1_4 = new BufferedReader(new FileReader(new StringBuilder(25).append("/proc/").append(var0).append("/cmdline").toString()));
        StrictMode.setThreadPolicy((StrictMode.ThreadPolicy)var2_1);
        var2_1 = var1_4.readLine().trim();
        zzo.zzb(var1_4);
        return var2_1;
        catch (Throwable var1_5) {
            try {
                StrictMode.setThreadPolicy((StrictMode.ThreadPolicy)var2_1);
                throw var1_5;
            }
            catch (IOException var1_6) {
                var1_4 = null;
                ** GOTO lbl28
                catch (Throwable var1_7) {
                    var3_8 = null;
                    var2_1 = var1_7;
                    ** GOTO lbl25
                    catch (Throwable var2_2) {
                        var3_8 = var1_4;
                    }
lbl25: // 2 sources:
                    zzo.zzb(var3_8);
                    throw var2_1;
                }
                catch (IOException var2_3) {}
lbl28: // 2 sources:
                zzo.zzb(var1_4);
                return null;
            }
        }
    }
}

