/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.util;

import java.util.regex.Pattern;

public class zzv {
    private static final Pattern GG = Pattern.compile("\\$\\{(.*?)\\}");

    public static boolean zzij(String string2) {
        if (string2 == null || string2.trim().isEmpty()) {
            return true;
        }
        return false;
    }
}

