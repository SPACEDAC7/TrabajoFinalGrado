/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.util.Log
 */
package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import com.google.android.gms.common.util.zzs;
import java.io.File;

public class zzw {
    @TargetApi(value=21)
    public static File getNoBackupFilesDir(Context context) {
        if (zzs.zzayx()) {
            return context.getNoBackupFilesDir();
        }
        return zzw.zze(new File(context.getApplicationInfo().dataDir, "no_backup"));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static File zze(File object) {
        synchronized (zzw.class) {
            Object object2 = object;
            if (object.exists()) return object2;
            object2 = object;
            if (object.mkdirs()) return object2;
            boolean bl = object.exists();
            if (bl) {
                return object;
            }
            object = (object = String.valueOf(object.getPath())).length() != 0 ? "Unable to create no-backup dir ".concat((String)object) : new String("Unable to create no-backup dir ");
            Log.w((String)"SupportV4Utils", (String)object);
            return null;
        }
    }
}

