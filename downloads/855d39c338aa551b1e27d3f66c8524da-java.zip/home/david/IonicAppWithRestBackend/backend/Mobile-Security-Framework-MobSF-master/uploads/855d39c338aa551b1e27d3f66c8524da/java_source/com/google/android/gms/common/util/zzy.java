/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.WorkSource
 *  android.util.Log
 */
package com.google.android.gms.common.util;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.WorkSource;
import android.util.Log;
import com.google.android.gms.common.util.zzs;
import com.google.android.gms.common.util.zzv;
import com.google.android.gms.internal.zzsz;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class zzy {
    private static final Method GH = zzy.zzaza();
    private static final Method GI = zzy.zzazb();
    private static final Method GJ = zzy.zzazc();
    private static final Method GK = zzy.zzazd();
    private static final Method GL = zzy.zzaze();

    public static int zza(WorkSource workSource) {
        if (GJ != null) {
            try {
                int n = (Integer)GJ.invoke((Object)workSource, new Object[0]);
                return n;
            }
            catch (Exception var0_1) {
                Log.wtf((String)"WorkSourceUtil", (String)"Unable to assign blame through WorkSource", (Throwable)var0_1);
            }
        }
        return 0;
    }

    public static String zza(WorkSource object, int n) {
        if (GL != null) {
            try {
                object = (String)GL.invoke(object, n);
                return object;
            }
            catch (Exception var0_1) {
                Log.wtf((String)"WorkSourceUtil", (String)"Unable to assign blame through WorkSource", (Throwable)var0_1);
            }
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void zza(WorkSource workSource, int n, String string2) {
        if (GI != null) {
            String string3 = string2;
            if (string2 == null) {
                string3 = "";
            }
            try {
                GI.invoke((Object)workSource, n, string3);
                return;
            }
            catch (Exception var0_1) {
                Log.wtf((String)"WorkSourceUtil", (String)"Unable to assign blame through WorkSource", (Throwable)var0_1);
                return;
            }
        }
        if (GH == null) return;
        try {
            GH.invoke((Object)workSource, n);
            return;
        }
        catch (Exception var0_2) {
            Log.wtf((String)"WorkSourceUtil", (String)"Unable to assign blame through WorkSource", (Throwable)var0_2);
            return;
        }
    }

    private static Method zzaza() {
        try {
            Method method = WorkSource.class.getMethod("add", Integer.TYPE);
            return method;
        }
        catch (Exception var0_1) {
            return null;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Method zzazb() {
        Method method = null;
        if (!zzs.zzayt()) return method;
        try {
            return WorkSource.class.getMethod("add", Integer.TYPE, String.class);
        }
        catch (Exception exception) {
            return null;
        }
    }

    private static Method zzazc() {
        try {
            Method method = WorkSource.class.getMethod("size", new Class[0]);
            return method;
        }
        catch (Exception var0_1) {
            return null;
        }
    }

    private static Method zzazd() {
        try {
            Method method = WorkSource.class.getMethod("get", Integer.TYPE);
            return method;
        }
        catch (Exception var0_1) {
            return null;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Method zzaze() {
        Method method = null;
        if (!zzs.zzayt()) return method;
        try {
            return WorkSource.class.getMethod("getName", Integer.TYPE);
        }
        catch (Exception exception) {
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static List<String> zzb(WorkSource workSource) {
        int n = 0;
        int n2 = workSource == null ? 0 : zzy.zza(workSource);
        if (n2 == 0) {
            return Collections.EMPTY_LIST;
        }
        ArrayList<Object> arrayList = new ArrayList<Object>();
        do {
            Object object = arrayList;
            if (n >= n2) return object;
            object = zzy.zza(workSource, n);
            if (!zzv.zzij((String)object)) {
                arrayList.add(object);
            }
            ++n;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean zzcm(Context context) {
        if (context == null || context.getPackageManager() == null || zzsz.zzco(context).checkPermission("android.permission.UPDATE_DEVICE_STATS", context.getPackageName()) != 0) {
            return false;
        }
        return true;
    }

    public static WorkSource zzf(int n, String string2) {
        WorkSource workSource = new WorkSource();
        zzy.zza(workSource, n, string2);
        return workSource;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static WorkSource zzy(Context object, String string2) {
        if (object == null || object.getPackageManager() == null) {
            return null;
        }
        try {
            object = zzsz.zzco((Context)object).getApplicationInfo(string2, 0);
            if (object != null) return zzy.zzf(object.uid, string2);
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            String string3 = String.valueOf(string2);
            string3 = string3.length() != 0 ? "Could not find package: ".concat(string3) : new String("Could not find package: ");
            Log.e((String)"WorkSourceUtil", (String)string3);
            return null;
        }
        {
            object = String.valueOf(string2);
            object = object.length() != 0 ? "Could not get applicationInfo from package: ".concat((String)object) : new String("Could not get applicationInfo from package: ");
            Log.e((String)"WorkSourceUtil", (String)object);
            return null;
        }
    }
}

