/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.ServiceConnection
 *  android.os.IBinder
 */
package com.google.android.gms.common;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.google.android.gms.common.internal.zzaa;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class zza
implements ServiceConnection {
    boolean wM = false;
    private final BlockingQueue<IBinder> wN = new LinkedBlockingQueue<IBinder>();

    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        this.wN.add(iBinder);
    }

    public void onServiceDisconnected(ComponentName componentName) {
    }

    public IBinder zza(long l, TimeUnit timeUnit) throws InterruptedException, TimeoutException {
        zzaa.zzht("BlockingServiceConnection.getServiceWithTimeout() called on main thread");
        if (this.wM) {
            throw new IllegalStateException("Cannot call get on this connection more than once");
        }
        this.wM = true;
        if ((timeUnit = this.wN.poll(l, timeUnit)) == null) {
            throw new TimeoutException("Timed out waiting for the service connection");
        }
        return timeUnit;
    }

    public IBinder zzaqk() throws InterruptedException {
        zzaa.zzht("BlockingServiceConnection.getService() called on main thread");
        if (this.wM) {
            throw new IllegalStateException("Cannot call get on this connection more than once");
        }
        this.wM = true;
        return this.wN.take();
    }
}

