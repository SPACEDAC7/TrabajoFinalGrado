/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zzb
implements Parcelable.Creator<ConnectionResult> {
    static void zza(ConnectionResult connectionResult, Parcel parcel, int n) {
        int n2 = com.google.android.gms.common.internal.safeparcel.zzb.zzcs(parcel);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 1, connectionResult.mVersionCode);
        com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, 2, connectionResult.getErrorCode());
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 3, (Parcelable)connectionResult.getResolution(), n, false);
        com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, 4, connectionResult.getErrorMessage(), false);
        com.google.android.gms.common.internal.safeparcel.zzb.zzaj(parcel, n2);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzcd(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zzfo(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public ConnectionResult zzcd(Parcel parcel) {
        String string2 = null;
        int n = 0;
        int n2 = zza.zzcr(parcel);
        PendingIntent pendingIntent = null;
        int n3 = 0;
        while (parcel.dataPosition() < n2) {
            int n4 = zza.zzcq(parcel);
            switch (zza.zzgu(n4)) {
                default: {
                    zza.zzb(parcel, n4);
                    n4 = n;
                    n = n3;
                    n3 = n4;
                    break;
                }
                case 1: {
                    n4 = zza.zzg(parcel, n4);
                    n3 = n;
                    n = n4;
                    break;
                }
                case 2: {
                    n4 = zza.zzg(parcel, n4);
                    n = n3;
                    n3 = n4;
                    break;
                }
                case 3: {
                    pendingIntent = (PendingIntent)zza.zza(parcel, n4, PendingIntent.CREATOR);
                    n4 = n3;
                    n3 = n;
                    n = n4;
                    break;
                }
                case 4: {
                    string2 = zza.zzq(parcel, n4);
                    n4 = n3;
                    n3 = n;
                    n = n4;
                }
            }
            n4 = n;
            n = n3;
            n3 = n4;
        }
        if (parcel.dataPosition() != n2) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n2).toString(), parcel);
        }
        return new ConnectionResult(n3, n, pendingIntent, string2);
    }

    public ConnectionResult[] zzfo(int n) {
        return new ConnectionResult[n];
    }
}

