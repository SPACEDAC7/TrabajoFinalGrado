/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageInstaller
 *  android.content.pm.PackageInstaller$SessionInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.net.Uri$Builder
 *  android.os.Bundle
 *  android.os.UserManager
 *  android.util.Log
 */
package com.google.android.gms.common;

import android.annotation.TargetApi;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.os.UserManager;
import android.util.Log;
import com.google.android.gms.R;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.internal.zzy;
import com.google.android.gms.common.util.zzi;
import com.google.android.gms.common.util.zzl;
import com.google.android.gms.common.util.zzs;
import com.google.android.gms.common.util.zzx;
import com.google.android.gms.common.zzc;
import com.google.android.gms.common.zzd;
import com.google.android.gms.common.zzf;
import com.google.android.gms.internal.zzsz;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicBoolean;

public class zze {
    @Deprecated
    public static final String GOOGLE_PLAY_SERVICES_PACKAGE = "com.google.android.gms";
    @Deprecated
    public static final int GOOGLE_PLAY_SERVICES_VERSION_CODE = zze.zzaqq();
    public static final String GOOGLE_PLAY_STORE_PACKAGE = "com.android.vending";
    public static boolean xb = false;
    public static boolean xc = false;
    static boolean xd = false;
    private static boolean xe = false;
    static final AtomicBoolean xf = new AtomicBoolean();
    private static final AtomicBoolean xg = new AtomicBoolean();

    zze() {
    }

    @Deprecated
    public static PendingIntent getErrorPendingIntent(int n, Context context, int n2) {
        return zzc.zzaql().getErrorResolutionPendingIntent(context, n, n2);
    }

    @Deprecated
    public static String getErrorString(int n) {
        return ConnectionResult.getStatusString(n);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Deprecated
    public static String getOpenSourceSoftwareLicenseInfo(Context object) {
        InputStream inputStream;
        Object object2 = new Uri.Builder().scheme("android.resource").authority("com.google.android.gms").appendPath("raw").appendPath("oss_notice").build();
        try {
            inputStream = object.getContentResolver().openInputStream((Uri)object2);
        }
        catch (Exception var0_3) {
            return null;
        }
        object2 = object = new Scanner(inputStream).useDelimiter("\\A").next();
        if (inputStream == null) return object2;
        inputStream.close();
        return object;
        catch (NoSuchElementException noSuchElementException) {
            if (inputStream == null) return null;
            inputStream.close();
            return null;
        }
        catch (Throwable throwable) {
            if (inputStream == null) throw throwable;
            inputStream.close();
            throw throwable;
        }
    }

    public static Context getRemoteContext(Context context) {
        try {
            context = context.createPackageContext("com.google.android.gms", 3);
            return context;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            return null;
        }
    }

    public static Resources getRemoteResource(Context context) {
        try {
            context = context.getPackageManager().getResourcesForApplication("com.google.android.gms");
            return context;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            return null;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Deprecated
    public static int isGooglePlayServicesAvailable(Context var0) {
        var4_4 = var0.getPackageManager();
        try {
            var0.getResources().getString(R.string.common_google_play_services_unknown_issue);
        }
        catch (Throwable var3_5) {
            Log.e((String)"GooglePlayServicesUtil", (String)"The Google Play services resources were not found. Check your project configuration to ensure that the resources are included.");
        }
        if (!"com.google.android.gms".equals(var0.getPackageName())) {
            zze.zzbp((Context)var0);
        }
        var1_7 = zzi.zzci((Context)var0) == false ? 1 : 0;
        var3_6 = null;
        if (var1_7 != 0) {
            var3_6 = var4_4.getPackageInfo("com.android.vending", 8256);
        }
        try {
            var5_8 = var4_4.getPackageInfo("com.google.android.gms", 64);
        }
        catch (PackageManager.NameNotFoundException var0_2) {
            Log.w((String)"GooglePlayServicesUtil", (String)"Google Play services is missing.");
            return 1;
        }
        var0 = zzf.zzbv((Context)var0);
        if (var1_7 == 0) ** GOTO lbl32
        if ((var3_6 = var0.zza((PackageInfo)var3_6, zzd.zzd.xa)) == null) {
            Log.w((String)"GooglePlayServicesUtil", (String)"Google Play Store signature invalid.");
            return 9;
        }
        ** GOTO lbl28
        catch (PackageManager.NameNotFoundException var0_1) {
            Log.w((String)"GooglePlayServicesUtil", (String)"Google Play Store is missing.");
            return 9;
        }
lbl28: // 1 sources:
        if (var0.zza(var5_8, new zzd.zza[]{var3_6}) == null) {
            Log.w((String)"GooglePlayServicesUtil", (String)"Google Play services signature invalid.");
            return 9;
        }
        ** GOTO lbl35
lbl32: // 1 sources:
        if (var0.zza(var5_8, zzd.zzd.xa) == null) {
            Log.w((String)"GooglePlayServicesUtil", (String)"Google Play services signature invalid.");
            return 9;
        }
lbl35: // 3 sources:
        var1_7 = zzl.zzhh(zze.GOOGLE_PLAY_SERVICES_VERSION_CODE);
        if (zzl.zzhh(var5_8.versionCode) < var1_7) {
            var1_7 = zze.GOOGLE_PLAY_SERVICES_VERSION_CODE;
            var2_9 = var5_8.versionCode;
            Log.w((String)"GooglePlayServicesUtil", (String)new StringBuilder(77).append("Google Play services out of date.  Requires ").append(var1_7).append(" but found ").append(var2_9).toString());
            return 2;
        }
        var0 = var3_6 = var5_8.applicationInfo;
        if (var3_6 == null) {
            var0 = var4_4.getApplicationInfo("com.google.android.gms", 0);
        }
        if (var0.enabled != false) return 0;
        return 3;
        catch (PackageManager.NameNotFoundException var0_3) {
            Log.wtf((String)"GooglePlayServicesUtil", (String)"Google Play services missing when getting application info.", (Throwable)var0_3);
            return 1;
        }
    }

    @Deprecated
    public static boolean isUserRecoverableError(int n) {
        switch (n) {
            default: {
                return false;
            }
            case 1: 
            case 2: 
            case 3: 
            case 9: 
        }
        return true;
    }

    private static int zzaqq() {
        return 9877000;
    }

    @Deprecated
    public static boolean zzaqr() {
        return zzi.zzaym();
    }

    @Deprecated
    public static void zzaz(Context context) throws GooglePlayServicesRepairableException, GooglePlayServicesNotAvailableException {
        int n = zzc.zzaql().isGooglePlayServicesAvailable(context);
        if (n != 0) {
            context = zzc.zzaql().zzb(context, n, "e");
            Log.e((String)"GooglePlayServicesUtil", (String)new StringBuilder(57).append("GooglePlayServices not available due to error ").append(n).toString());
            if (context == null) {
                throw new GooglePlayServicesNotAvailableException(n);
            }
            throw new GooglePlayServicesRepairableException(n, "Google Play Services not available", (Intent)context);
        }
    }

    @Deprecated
    public static int zzbk(Context context) {
        try {
            context = context.getPackageManager().getPackageInfo("com.google.android.gms", 0);
            return context.versionCode;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            Log.w((String)"GooglePlayServicesUtil", (String)"Google Play services is missing.");
            return 0;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Deprecated
    public static void zzbn(Context context) {
        if (xf.getAndSet(true)) {
            return;
        }
        try {
            if ((context = (NotificationManager)context.getSystemService("notification")) == null) return;
            context.cancel(10436);
            return;
        }
        catch (SecurityException var0_1) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void zzbp(Context object) {
        if (xg.get()) {
            return;
        }
        int n = zzy.zzce((Context)object);
        if (n == 0) {
            throw new IllegalStateException("A required meta-data tag in your app's AndroidManifest.xml does not exist.  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />");
        }
        if (n == GOOGLE_PLAY_SERVICES_VERSION_CODE) return;
        int n2 = GOOGLE_PLAY_SERVICES_VERSION_CODE;
        object = String.valueOf("com.google.android.gms.version");
        throw new IllegalStateException(new StringBuilder(String.valueOf(object).length() + 290).append("The meta-data tag in your app's AndroidManifest.xml does not have the right value.  Expected ").append(n2).append(" but found ").append(n).append(".  You must have the following declaration within the <application> element:     <meta-data android:name=\"").append((String)object).append("\" android:value=\"@integer/google_play_services_version\" />").toString());
    }

    public static boolean zzbq(Context context) {
        zze.zzbt(context);
        return xd;
    }

    public static boolean zzbr(Context context) {
        if (zze.zzbq(context) || !zze.zzaqr()) {
            return true;
        }
        return false;
    }

    @TargetApi(value=18)
    public static boolean zzbs(Context context) {
        if (zzs.zzayt() && (context = ((UserManager)context.getSystemService("user")).getApplicationRestrictions(context.getPackageName())) != null && "true".equals(context.getString("restricted_profile"))) {
            return true;
        }
        return false;
    }

    private static void zzbt(Context context) {
        if (!xe) {
            zze.zzbu(context);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void zzbu(Context context) {
        try {
            PackageInfo packageInfo = zzsz.zzco(context).getPackageInfo("com.google.android.gms", 64);
            if (packageInfo != null && zzf.zzbv(context).zza(packageInfo, zzd.zzd.xa[1]) != null) {
                xd = true;
                do {
                    return;
                    break;
                } while (true);
            }
            xd = false;
            return;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            Log.w((String)"GooglePlayServicesUtil", (String)"Cannot find Google Play services package name.", (Throwable)var0_1);
            return;
        }
        finally {
            xe = true;
        }
    }

    @Deprecated
    @TargetApi(value=19)
    public static boolean zzc(Context context, int n, String string2) {
        return zzx.zzc(context, n, string2);
    }

    @Deprecated
    public static boolean zzd(Context context, int n) {
        if (n == 18) {
            return true;
        }
        if (n == 1) {
            return zze.zzs(context, "com.google.android.gms");
        }
        return false;
    }

    @Deprecated
    public static boolean zze(Context context, int n) {
        if (n == 9) {
            return zze.zzs(context, "com.android.vending");
        }
        return false;
    }

    @Deprecated
    public static boolean zzf(Context context, int n) {
        return zzx.zzf(context, n);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @TargetApi(value=21)
    static boolean zzs(Context context, String string2) {
        Object object;
        boolean bl = string2.equals("com.google.android.gms");
        if (bl && com.google.android.gms.common.util.zzd.zzayi()) {
            return false;
        }
        if (zzs.zzayx()) {
            object = context.getPackageManager().getPackageInstaller().getAllSessions().iterator();
            while (object.hasNext()) {
                if (!string2.equals(((PackageInstaller.SessionInfo)object.next()).getAppPackageName())) continue;
                return true;
            }
        }
        object = context.getPackageManager();
        try {
            string2 = object.getApplicationInfo(string2, 8192);
            if (bl) {
                return string2.enabled;
            }
            if (!string2.enabled) return false;
            bl = zze.zzbs(context);
            if (bl) return false;
            return true;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            return false;
        }
    }
}

