/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.Signature
 *  android.util.Log
 */
package com.google.android.gms.common;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Log;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.zzd;
import com.google.android.gms.common.zze;
import com.google.android.gms.internal.zzsz;

public class zzf {
    private static zzf xh;
    private final Context mContext;

    private zzf(Context context) {
        this.mContext = context.getApplicationContext();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static zzf zzbv(Context context) {
        zzaa.zzy(context);
        synchronized (zzf.class) {
            if (xh == null) {
                zzd.zzbo(context);
                xh = new zzf(context);
            }
            return xh;
        }
    }

    /* varargs */ zzd.zza zza(PackageInfo object, zzd.zza ... arrzza) {
        if (object.signatures == null) {
            return null;
        }
        if (object.signatures.length != 1) {
            Log.w((String)"GoogleSignatureVerifier", (String)"Package has more than one signature.");
            return null;
        }
        object = new zzd.zzb(object.signatures[0].toByteArray());
        for (int i = 0; i < arrzza.length; ++i) {
            if (!arrzza[i].equals(object)) continue;
            return arrzza[i];
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean zza(PackageInfo object, boolean bl) {
        if (object != null && object.signatures != null) {
            object = bl ? this.zza((PackageInfo)object, zzd.zzd.xa) : this.zza((PackageInfo)object, zzd.zzd.xa[0]);
            if (object != null) {
                return true;
            }
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean zza(PackageManager packageManager, int n) {
        String[] arrstring = zzsz.zzco(this.mContext).getPackagesForUid(n);
        if (arrstring == null || arrstring.length == 0) {
            return false;
        }
        int n2 = arrstring.length;
        n = 0;
        while (n < n2) {
            if (this.zzb(packageManager, arrstring[n])) {
                return true;
            }
            ++n;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean zza(PackageManager packageManager, PackageInfo packageInfo) {
        boolean bl;
        boolean bl2 = false;
        if (packageInfo == null) {
            return bl2;
        }
        if (zze.zzbr(this.mContext)) {
            return this.zzb(packageInfo, true);
        }
        bl2 = bl = this.zzb(packageInfo, false);
        if (bl) return bl2;
        bl2 = bl;
        if (!this.zzb(packageInfo, true)) return bl2;
        Log.w((String)"GoogleSignatureVerifier", (String)"Test-keys aren't accepted on this build.");
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    boolean zzb(PackageInfo object, boolean bl) {
        boolean bl2 = false;
        if (object.signatures.length != 1) {
            Log.w((String)"GoogleSignatureVerifier", (String)"Package has more than one signature.");
            return bl2;
        } else {
            zzd.zzb zzb2 = new zzd.zzb(object.signatures[0].toByteArray());
            object = object.packageName;
            bl = bl ? zzd.zzb((String)object, zzb2) : zzd.zza((String)object, zzb2);
            bl2 = bl;
            if (bl) return bl2;
            return bl;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean zzb(PackageManager packageManager, PackageInfo packageInfo) {
        if (packageInfo == null) {
            return false;
        }
        if (this.zza(packageInfo, false)) {
            return true;
        }
        if (!this.zza(packageInfo, true)) return false;
        if (zze.zzbr(this.mContext)) {
            return true;
        }
        Log.w((String)"GoogleSignatureVerifier", (String)"Test-keys aren't accepted on this build.");
        return false;
    }

    public boolean zzb(PackageManager packageManager, String string2) {
        try {
            string2 = zzsz.zzco(this.mContext).getPackageInfo(string2, 64);
        }
        catch (PackageManager.NameNotFoundException var1_2) {
            return false;
        }
        return this.zza(packageManager, (PackageInfo)string2);
    }
}

