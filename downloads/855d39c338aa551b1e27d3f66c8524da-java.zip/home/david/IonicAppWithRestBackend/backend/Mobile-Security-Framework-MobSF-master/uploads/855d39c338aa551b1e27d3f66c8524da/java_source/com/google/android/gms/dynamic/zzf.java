/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.dynamic;

import com.google.android.gms.dynamic.LifecycleDelegate;

public interface zzf<T extends LifecycleDelegate> {
    public void zza(T var1);
}

