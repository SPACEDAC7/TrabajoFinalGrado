/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 */
package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import com.google.android.gms.internal.zzvv;
import java.util.concurrent.Callable;

public abstract class zza<T> {

    public static class zza
    extends zza<Boolean> {
        public static Boolean zza(SharedPreferences sharedPreferences, final String string2, final Boolean bl) {
            return (Boolean)zzvv.zzb(new Callable<Boolean>(){

                @Override
                public /* synthetic */ Object call() throws Exception {
                    return this.zzwa();
                }

                public Boolean zzwa() {
                    return SharedPreferences.this.getBoolean(string2, bl.booleanValue());
                }
            });
        }

    }

    public static class zzb
    extends zza<Integer> {
        public static Integer zza(SharedPreferences sharedPreferences, final String string2, final Integer n) {
            return (Integer)zzvv.zzb(new Callable<Integer>(){

                @Override
                public /* synthetic */ Object call() throws Exception {
                    return this.zzbhg();
                }

                public Integer zzbhg() {
                    return SharedPreferences.this.getInt(string2, n.intValue());
                }
            });
        }

    }

    public static class zzc
    extends zza<Long> {
        public static Long zza(SharedPreferences sharedPreferences, final String string2, final Long l) {
            return (Long)zzvv.zzb(new Callable<Long>(){

                @Override
                public /* synthetic */ Object call() throws Exception {
                    return this.zzbhh();
                }

                public Long zzbhh() {
                    return SharedPreferences.this.getLong(string2, l.longValue());
                }
            });
        }

    }

    public static class zzd
    extends zza<String> {
        public static String zza(SharedPreferences sharedPreferences, final String string2, final String string3) {
            return (String)zzvv.zzb(new Callable<String>(){

                @Override
                public /* synthetic */ Object call() throws Exception {
                    return this.zzaed();
                }

                public String zzaed() {
                    return SharedPreferences.this.getString(string2, string3);
                }
            });
        }

    }

}

