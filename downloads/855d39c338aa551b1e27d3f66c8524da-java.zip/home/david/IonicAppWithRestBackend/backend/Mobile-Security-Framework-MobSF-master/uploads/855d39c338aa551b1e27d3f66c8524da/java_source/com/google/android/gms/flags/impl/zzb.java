/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 */
package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.android.gms.internal.zzvv;
import java.util.concurrent.Callable;

public class zzb {
    private static SharedPreferences WM = null;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static SharedPreferences zzm(Context context) {
        synchronized (SharedPreferences.class) {
            if (WM != null) return WM;
            WM = (SharedPreferences)zzvv.zzb(new Callable<SharedPreferences>(){

                @Override
                public /* synthetic */ Object call() throws Exception {
                    return this.zzbhi();
                }

                public SharedPreferences zzbhi() {
                    return Context.this.getSharedPreferences("google_sdk_flags", 1);
                }
            });
            return WM;
        }
    }

}

