/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.DeadObjectException
 *  android.os.HandlerThread
 *  android.os.Looper
 */
package com.google.android.gms.gass.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.HandlerThread;
import android.os.Looper;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.zze;
import com.google.android.gms.gass.internal.GassRequestParcel;
import com.google.android.gms.gass.internal.GassResponseParcel;
import com.google.android.gms.gass.internal.zzb;
import com.google.android.gms.gass.internal.zze;
import com.google.android.gms.internal.zzaf;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class zza {
    public static zzaf.zza zzi(Context context, String string2, String string3) {
        return new zza(context, string2, string3).zzcv();
    }

    static class zza
    implements zze.zzb,
    zze.zzc {
        protected zzb agD;
        private final String agE;
        private final LinkedBlockingQueue<zzaf.zza> agF;
        private final HandlerThread agG;
        private final String packageName;

        public zza(Context context, String string2, String string3) {
            this.packageName = string2;
            this.agE = string3;
            this.agG = new HandlerThread("GassClient");
            this.agG.start();
            this.agD = new zzb(context, this.agG.getLooper(), this, this);
            this.agF = new LinkedBlockingQueue();
            this.connect();
        }

        protected void connect() {
            this.agD.zzavd();
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        public void onConnected(Bundle object) {
            object = this.zzbnl();
            if (object == null) return;
            try {
                object = object.zza(new GassRequestParcel(this.packageName, this.agE)).zzbno();
                this.agF.put((zzaf.zza)object);
            }
            catch (Throwable throwable) {
                return;
            }
            finally {
                this.zztb();
                this.agG.quit();
            }
            return;
        }

        @Override
        public void onConnectionFailed(ConnectionResult connectionResult) {
            try {
                this.agF.put(new zzaf.zza());
                return;
            }
            catch (InterruptedException var1_2) {
                return;
            }
        }

        @Override
        public void onConnectionSuspended(int n) {
            try {
                this.agF.put(new zzaf.zza());
                return;
            }
            catch (InterruptedException var2_2) {
                return;
            }
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        protected zze zzbnl() {
            try {
                return this.agD.zzbnm();
            }
            catch (IllegalStateException var1_2) {
                do {
                    return null;
                    break;
                } while (true);
            }
            catch (DeadObjectException var1_3) {
                return null;
            }
        }

        public zzaf.zza zzcv() {
            return this.zzti(2000);
        }

        public void zztb() {
            if (this.agD != null && (this.agD.isConnected() || this.agD.isConnecting())) {
                this.agD.disconnect();
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public zzaf.zza zzti(int n) {
            zzaf.zza zza2;
            try {
                zza2 = this.agF.poll(n, TimeUnit.MILLISECONDS);
            }
            catch (InterruptedException var2_3) {
                zza2 = null;
            }
            zzaf.zza zza3 = zza2;
            if (zza2 != null) return zza3;
            return new zzaf.zza();
        }
    }

}

