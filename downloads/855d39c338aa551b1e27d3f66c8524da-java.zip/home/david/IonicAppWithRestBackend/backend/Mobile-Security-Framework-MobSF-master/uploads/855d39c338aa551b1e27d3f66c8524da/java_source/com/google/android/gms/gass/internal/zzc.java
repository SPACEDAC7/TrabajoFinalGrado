/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.gass.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.gass.internal.GassRequestParcel;

public class zzc
implements Parcelable.Creator<GassRequestParcel> {
    static void zza(GassRequestParcel gassRequestParcel, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, gassRequestParcel.versionCode);
        zzb.zza(parcel, 2, gassRequestParcel.packageName, false);
        zzb.zza(parcel, 3, gassRequestParcel.agH, false);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzmx(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zztj(n);
    }

    public GassRequestParcel zzmx(Parcel parcel) {
        String string2 = null;
        int n = zza.zzcr(parcel);
        int n2 = 0;
        String string3 = null;
        block5 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block5;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block5;
                }
                case 2: {
                    string3 = zza.zzq(parcel, n3);
                    continue block5;
                }
                case 3: 
            }
            string2 = zza.zzq(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new GassRequestParcel(n2, string3, string2);
    }

    public GassRequestParcel[] zztj(int n) {
        return new GassRequestParcel[n];
    }
}

