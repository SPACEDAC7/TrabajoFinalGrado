/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.google.android.gms.gass.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.gass.internal.GassResponseParcel;

public class zzd
implements Parcelable.Creator<GassResponseParcel> {
    static void zza(GassResponseParcel gassResponseParcel, Parcel parcel, int n) {
        n = zzb.zzcs(parcel);
        zzb.zzc(parcel, 1, gassResponseParcel.versionCode);
        zzb.zza(parcel, 2, gassResponseParcel.zzbnn(), false);
        zzb.zzaj(parcel, n);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return this.zzmy(parcel);
    }

    public /* synthetic */ Object[] newArray(int n) {
        return this.zztk(n);
    }

    public GassResponseParcel zzmy(Parcel parcel) {
        int n = zza.zzcr(parcel);
        int n2 = 0;
        byte[] arrby = null;
        block4 : while (parcel.dataPosition() < n) {
            int n3 = zza.zzcq(parcel);
            switch (zza.zzgu(n3)) {
                default: {
                    zza.zzb(parcel, n3);
                    continue block4;
                }
                case 1: {
                    n2 = zza.zzg(parcel, n3);
                    continue block4;
                }
                case 2: 
            }
            arrby = zza.zzt(parcel, n3);
        }
        if (parcel.dataPosition() != n) {
            throw new zza.zza(new StringBuilder(37).append("Overread allowed size end=").append(n).toString(), parcel);
        }
        return new GassResponseParcel(n2, arrby);
    }

    public GassResponseParcel[] zztk(int n) {
        return new GassResponseParcel[n];
    }
}

