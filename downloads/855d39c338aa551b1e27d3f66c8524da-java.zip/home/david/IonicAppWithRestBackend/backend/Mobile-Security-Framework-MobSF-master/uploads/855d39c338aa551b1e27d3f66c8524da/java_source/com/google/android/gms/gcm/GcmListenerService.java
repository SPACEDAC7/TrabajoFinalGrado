/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.os.AsyncTask
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.util.Log
 */
package com.google.android.gms.gcm;

import android.annotation.TargetApi;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import com.google.android.gms.gcm.zza;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.Executor;

public abstract class GcmListenerService
extends Service {
    private int agK;
    private int agL = 0;
    private final Object zzako = new Object();

    static void zzac(Bundle object) {
        object = object.keySet().iterator();
        while (object.hasNext()) {
            String string2 = (String)object.next();
            if (string2 == null || !string2.startsWith("google.c.")) continue;
            object.remove();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void zzbnp() {
        Object object = this.zzako;
        synchronized (object) {
            --this.agL;
            if (this.agL == 0) {
                this.zztl(this.agK);
            }
            return;
        }
    }

    @TargetApi(value=11)
    private void zzl(final Intent intent) {
        if (Build.VERSION.SDK_INT >= 11) {
            AsyncTask.THREAD_POOL_EXECUTOR.execute(new Runnable(){

                @Override
                public void run() {
                    GcmListenerService.this.zzm(intent);
                }
            });
            return;
        }
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void doInBackground(Void ... arrvoid) {
                GcmListenerService.this.zzm(intent);
                return null;
            }
        }.execute((Object[])new Void[0]);
    }

    /*
     * Exception decompiling
     */
    private void zzm(Intent var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zzn(Intent object) {
        String string2;
        String string3 = string2 = object.getStringExtra("message_type");
        if (string2 == null) {
            string3 = "gcm";
        }
        int n = -1;
        switch (string3.hashCode()) {
            case 102161: {
                if (!string3.equals("gcm")) break;
                n = 0;
                break;
            }
            case -2062414158: {
                if (!string3.equals("deleted_messages")) break;
                n = 1;
                break;
            }
            case 814800675: {
                if (!string3.equals("send_event")) break;
                n = 2;
                break;
            }
            case 814694033: {
                if (!string3.equals("send_error")) break;
                n = 3;
                break;
            }
        }
        switch (n) {
            default: {
                object = String.valueOf(string3);
                object = object.length() != 0 ? "Received message with unknown type: ".concat((String)object) : new String("Received message with unknown type: ");
            }
            case 0: {
                this.zzo((Intent)object);
                return;
            }
            case 1: {
                this.onDeletedMessages();
                return;
            }
            case 2: {
                this.onMessageSent(object.getStringExtra("google.message_id"));
                return;
            }
            case 3: {
                this.onSendError(this.zzp((Intent)object), object.getStringExtra("error"));
                return;
            }
        }
        Log.w((String)"GcmListenerService", (String)object);
    }

    private void zzo(Intent intent) {
        intent = intent.getExtras();
        intent.remove("message_type");
        intent.remove("android.support.content.wakelockid");
        if (zza.zzad((Bundle)intent)) {
            if (!zza.zzda((Context)this)) {
                zza.zzcz((Context)this).zzaf((Bundle)intent);
                return;
            }
            zza.zzae((Bundle)intent);
        }
        String string2 = intent.getString("from");
        intent.remove("from");
        GcmListenerService.zzac((Bundle)intent);
        this.onMessageReceived(string2, (Bundle)intent);
    }

    private String zzp(Intent intent) {
        String string2;
        String string3 = string2 = intent.getStringExtra("google.message_id");
        if (string2 == null) {
            string3 = intent.getStringExtra("message_id");
        }
        return string3;
    }

    public final IBinder onBind(Intent intent) {
        return null;
    }

    public void onDeletedMessages() {
    }

    public void onMessageReceived(String string2, Bundle bundle) {
    }

    public void onMessageSent(String string2) {
    }

    public void onSendError(String string2, String string3) {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final int onStartCommand(Intent intent, int n, int n2) {
        Object object = this.zzako;
        // MONITORENTER : object
        this.agK = n2;
        ++this.agL;
        // MONITOREXIT : object
        if (intent == null) {
            this.zzbnp();
            return 2;
        }
        this.zzl(intent);
        return 3;
    }

    boolean zztl(int n) {
        return this.stopSelfResult(n);
    }

}

