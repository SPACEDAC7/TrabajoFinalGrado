/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.app.Service
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  android.util.Log
 */
package com.google.android.gms.gcm;

import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.gcm.GcmTaskService;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.android.gms.gcm.Task;
import java.util.Iterator;
import java.util.List;

public class GcmNetworkManager {
    public static final int RESULT_FAILURE = 2;
    public static final int RESULT_RESCHEDULE = 1;
    public static final int RESULT_SUCCESS = 0;
    private static GcmNetworkManager agN;
    private Context mContext;
    private final PendingIntent mPendingIntent;

    private GcmNetworkManager(Context context) {
        this.mContext = context;
        this.mPendingIntent = PendingIntent.getBroadcast((Context)this.mContext, (int)0, (Intent)new Intent().setPackage("com.google.example.invalidpackage"), (int)0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static GcmNetworkManager getInstance(Context object) {
        synchronized (GcmNetworkManager.class) {
            if (agN != null) return agN;
            agN = new GcmNetworkManager(object.getApplicationContext());
            return agN;
        }
    }

    private void zza(ComponentName componentName) {
        this.zzkj(componentName.getClassName());
        Intent intent = this.zzbnq();
        if (intent == null) {
            return;
        }
        intent.putExtra("scheduler_action", "CANCEL_ALL");
        intent.putExtra("component", (Parcelable)componentName);
        this.mContext.sendBroadcast(intent);
    }

    private void zza(String string2, ComponentName componentName) {
        GcmNetworkManager.zzki(string2);
        this.zzkj(componentName.getClassName());
        Intent intent = this.zzbnq();
        if (intent == null) {
            return;
        }
        intent.putExtra("scheduler_action", "CANCEL_TASK");
        intent.putExtra("tag", string2);
        intent.putExtra("component", (Parcelable)componentName);
        this.mContext.sendBroadcast(intent);
    }

    private Intent zzbnq() {
        String string2 = GoogleCloudMessaging.zzdb(this.mContext);
        int n = -1;
        if (string2 != null) {
            n = GoogleCloudMessaging.zzdc(this.mContext);
        }
        if (string2 == null || n < GoogleCloudMessaging.agY) {
            Log.e((String)"GcmNetworkManager", (String)new StringBuilder(91).append("Google Play Services is not available, dropping GcmNetworkManager request. code=").append(n).toString());
            return null;
        }
        Intent intent = new Intent("com.google.android.gms.gcm.ACTION_SCHEDULE");
        intent.setPackage(string2);
        intent.putExtra("app", (Parcelable)this.mPendingIntent);
        return intent;
    }

    static void zzki(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            throw new IllegalArgumentException("Must provide a valid tag.");
        }
        if (100 < string2.length()) {
            throw new IllegalArgumentException("Tag is larger than max permissible tag length (100)");
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zzkj(String string2) {
        boolean bl;
        block1 : {
            boolean bl2 = true;
            zzaa.zzb(string2, (Object)"GcmTaskService must not be null.");
            Iterator iterator = new Intent("com.google.android.gms.gcm.ACTION_TASK_READY");
            iterator.setPackage(this.mContext.getPackageName());
            iterator = this.mContext.getPackageManager().queryIntentServices((Intent)iterator, 0);
            bl = iterator != null && iterator.size() != 0;
            zzaa.zzb(bl, (Object)"There is no GcmTaskService component registered within this package. Have you extended GcmTaskService correctly?");
            iterator = iterator.iterator();
            while (iterator.hasNext()) {
                if (!((ResolveInfo)iterator.next()).serviceInfo.name.equals(string2)) continue;
                bl = bl2;
                break block1;
            }
            bl = false;
        }
        zzaa.zzb(bl, (Object)new StringBuilder(String.valueOf(string2).length() + 119).append("The GcmTaskService class you provided ").append(string2).append(" does not seem to support receiving com.google.android.gms.gcm.ACTION_TASK_READY.").toString());
    }

    public void cancelAllTasks(Class<? extends GcmTaskService> class_) {
        this.zze(class_);
    }

    public void cancelTask(String string2, Class<? extends GcmTaskService> class_) {
        this.zzb(string2, class_);
    }

    public void schedule(Task task) {
        this.zzkj(task.getServiceName());
        Intent intent = this.zzbnq();
        if (intent == null) {
            return;
        }
        Bundle bundle = intent.getExtras();
        bundle.putString("scheduler_action", "SCHEDULE_TASK");
        task.toBundle(bundle);
        intent.putExtras(bundle);
        this.mContext.sendBroadcast(intent);
    }

    public void zzb(String string2, Class<? extends Service> class_) {
        this.zza(string2, new ComponentName(this.mContext, class_));
    }

    public void zze(Class<? extends Service> class_) {
        this.zza(new ComponentName(this.mContext, class_));
    }
}

