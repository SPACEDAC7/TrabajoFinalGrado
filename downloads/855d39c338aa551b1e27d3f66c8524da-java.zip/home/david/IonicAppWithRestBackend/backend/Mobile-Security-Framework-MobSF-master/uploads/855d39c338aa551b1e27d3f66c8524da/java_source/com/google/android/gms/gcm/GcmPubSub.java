/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 */
package com.google.android.gms.gcm;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.RequiresPermission;
import com.google.android.gms.iid.InstanceID;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GcmPubSub {
    private static GcmPubSub agP;
    private static final Pattern agR;
    private InstanceID agQ;

    static {
        agR = Pattern.compile("/topics/[a-zA-Z0-9-_.~%]{1,900}");
    }

    private GcmPubSub(Context context) {
        this.agQ = InstanceID.getInstance(context);
    }

    public static GcmPubSub getInstance(Context object) {
        synchronized (GcmPubSub.class) {
            if (agP == null) {
                agP = new GcmPubSub((Context)object);
            }
            object = agP;
            return object;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @RequiresPermission(value="com.google.android.c2dm.permission.RECEIVE")
    public void subscribe(String string2, String string3, Bundle bundle) throws IOException {
        if (string2 == null || string2.isEmpty()) {
            if ((string2 = String.valueOf(string2)).length() != 0) {
                string2 = "Invalid appInstanceToken: ".concat(string2);
                do {
                    throw new IllegalArgumentException(string2);
                    break;
                } while (true);
            }
            string2 = new String("Invalid appInstanceToken: ");
            throw new IllegalArgumentException(string2);
        }
        if (string3 == null || !agR.matcher(string3).matches()) {
            string2 = String.valueOf(string3);
            if (string2.length() != 0) {
                string2 = "Invalid topic name: ".concat(string2);
                do {
                    throw new IllegalArgumentException(string2);
                    break;
                } while (true);
            }
            string2 = new String("Invalid topic name: ");
            throw new IllegalArgumentException(string2);
        }
        Bundle bundle2 = bundle;
        if (bundle == null) {
            bundle2 = new Bundle();
        }
        bundle2.putString("gcm.topic", string3);
        this.agQ.getToken(string2, string3, bundle2);
    }

    @RequiresPermission(value="com.google.android.c2dm.permission.RECEIVE")
    public void unsubscribe(String string2, String string3) throws IOException {
        Bundle bundle = new Bundle();
        bundle.putString("gcm.topic", string3);
        this.agQ.zzb(string2, string3, bundle);
    }
}

