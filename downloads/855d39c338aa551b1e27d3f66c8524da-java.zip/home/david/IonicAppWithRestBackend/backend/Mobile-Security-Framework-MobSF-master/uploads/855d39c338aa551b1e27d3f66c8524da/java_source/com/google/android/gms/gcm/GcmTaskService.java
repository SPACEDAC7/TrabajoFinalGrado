/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  android.os.RemoteException
 *  android.util.Log
 */
package com.google.android.gms.gcm;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.annotation.CallSuper;
import android.support.annotation.NonNull;
import android.util.Log;
import com.google.android.gms.gcm.PendingCallback;
import com.google.android.gms.gcm.TaskParams;
import com.google.android.gms.gcm.zzb;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class GcmTaskService
extends Service {
    public static final String SERVICE_ACTION_EXECUTE_TASK = "com.google.android.gms.gcm.ACTION_TASK_READY";
    public static final String SERVICE_ACTION_INITIALIZE = "com.google.android.gms.gcm.SERVICE_ACTION_INITIALIZE";
    public static final String SERVICE_PERMISSION = "com.google.android.gms.permission.BIND_NETWORK_TASK_SERVICE";
    private final Set<String> agT = new HashSet<String>();
    private int agU;
    private ExecutorService zzahu;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void zzkn(String string2) {
        Set<String> set = this.agT;
        synchronized (set) {
            this.agT.remove(string2);
            if (this.agT.size() == 0) {
                this.stopSelf(this.agU);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void zztm(int n) {
        Set<String> set = this.agT;
        synchronized (set) {
            this.agU = n;
            if (this.agT.size() == 0) {
                this.stopSelf(this.agU);
            }
            return;
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    @CallSuper
    public void onCreate() {
        super.onCreate();
        this.zzahu = this.zzbns();
    }

    @CallSuper
    public void onDestroy() {
        super.onDestroy();
        List<Runnable> list = this.zzahu.shutdownNow();
        if (!list.isEmpty()) {
            int n = list.size();
            Log.e((String)"GcmTaskService", (String)new StringBuilder(79).append("Shutting down, but not all tasks are finished executing. Remaining: ").append(n).toString());
        }
    }

    public void onInitializeTasks() {
    }

    public abstract int onRunTask(TaskParams var1);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @CallSuper
    public int onStartCommand(Intent set, int n, int n2) {
        String string2;
        block14 : {
            Bundle bundle;
            Object object;
            block15 : {
                if (set == null) {
                    this.zztm(n2);
                    return 2;
                }
                set.setExtrasClassLoader(PendingCallback.class.getClassLoader());
                string2 = set.getAction();
                if (!"com.google.android.gms.gcm.ACTION_TASK_READY".equals(string2)) break block14;
                string2 = set.getStringExtra("tag");
                object = set.getParcelableExtra("callback");
                bundle = (Bundle)set.getParcelableExtra("extras");
                if (object == null || !(object instanceof PendingCallback)) {
                    set = String.valueOf(this.getPackageName());
                    Log.e((String)"GcmTaskService", (String)new StringBuilder(String.valueOf(set).length() + 47 + String.valueOf(string2).length()).append((String)((Object)set)).append(" ").append(string2).append(": Could not process request, invalid callback.").toString());
                    this.zztm(n2);
                    return 2;
                }
                set = this.agT;
                synchronized (set) {
                    if (this.agT.add(string2)) break block15;
                }
                {
                    object = String.valueOf(this.getPackageName());
                    Log.w((String)"GcmTaskService", (String)new StringBuilder(String.valueOf(object).length() + 44 + String.valueOf(string2).length()).append((String)object).append(" ").append(string2).append(": Task already running, won't start another").toString());
                }
                this.zztm(n2);
                return 2;
            }
            try {
                this.zzahu.execute(new zza(string2, ((PendingCallback)object).getIBinder(), bundle));
                return 2;
            }
            finally {
                this.zztm(n2);
            }
        }
        if ("com.google.android.gms.gcm.SERVICE_ACTION_INITIALIZE".equals(string2)) {
            this.onInitializeTasks();
            return 2;
        }
        Log.e((String)"GcmTaskService", (String)new StringBuilder(String.valueOf(string2).length() + 37).append("Unknown action received ").append(string2).append(", terminating").toString());
        return 2;
    }

    protected ExecutorService zzbns() {
        return Executors.newFixedThreadPool(2, new ThreadFactory(){
            private final AtomicInteger agV;

            @Override
            public Thread newThread(@NonNull Runnable runnable) {
                int n = this.agV.getAndIncrement();
                runnable = new Thread(runnable, new StringBuilder(20).append("gcm-task#").append(n).toString());
                runnable.setPriority(4);
                return runnable;
            }
        });
    }

    private class zza
    implements Runnable {
        private final zzb agX;
        private final Bundle mExtras;
        private final String mTag;

        zza(String string2, IBinder iBinder, Bundle bundle) {
            this.mTag = string2;
            this.agX = zzb.zza.zzgt(iBinder);
            this.mExtras = bundle;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public void run() {
            int n = GcmTaskService.this.onRunTask(new TaskParams(this.mTag, this.mExtras));
            try {
                this.agX.zztn(n);
                return;
            }
            catch (RemoteException var2_2) {
                String string2 = String.valueOf(this.mTag);
                string2 = string2.length() != 0 ? "Error reporting result of operation to scheduler for ".concat(string2) : new String("Error reporting result of operation to scheduler for ");
                Log.e((String)"GcmTaskService", (String)string2);
                return;
            }
            finally {
                GcmTaskService.this.zzkn(this.mTag);
            }
        }
    }

}

