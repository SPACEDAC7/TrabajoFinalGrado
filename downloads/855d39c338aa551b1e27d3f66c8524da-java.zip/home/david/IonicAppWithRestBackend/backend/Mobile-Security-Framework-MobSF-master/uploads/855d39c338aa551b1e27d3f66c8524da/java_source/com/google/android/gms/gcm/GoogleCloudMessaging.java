/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  android.os.Messenger
 *  android.os.Parcelable
 *  android.util.Log
 */
package com.google.android.gms.gcm;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcelable;
import android.support.annotation.RequiresPermission;
import android.util.Log;
import com.google.android.gms.gcm.zza;
import com.google.android.gms.iid.InstanceID;
import com.google.android.gms.iid.zzc;
import com.google.android.gms.iid.zzd;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class GoogleCloudMessaging {
    public static final String ERROR_MAIN_THREAD = "MAIN_THREAD";
    public static final String ERROR_SERVICE_NOT_AVAILABLE = "SERVICE_NOT_AVAILABLE";
    public static final String INSTANCE_ID_SCOPE = "GCM";
    @Deprecated
    public static final String MESSAGE_TYPE_DELETED = "deleted_messages";
    @Deprecated
    public static final String MESSAGE_TYPE_MESSAGE = "gcm";
    @Deprecated
    public static final String MESSAGE_TYPE_SEND_ERROR = "send_error";
    @Deprecated
    public static final String MESSAGE_TYPE_SEND_EVENT = "send_event";
    public static int agY = 5000000;
    public static int agZ = 6500000;
    public static int aha = 7000000;
    static GoogleCloudMessaging ahb;
    private static final AtomicInteger ahe;
    private PendingIntent ahc;
    private Map<String, Handler> ahd = Collections.synchronizedMap(new HashMap());
    private final BlockingQueue<Intent> ahf = new LinkedBlockingQueue<Intent>();
    final Messenger ahg;
    private Context zzahs;

    static {
        ahe = new AtomicInteger(1);
    }

    public GoogleCloudMessaging() {
        this.ahg = new Messenger(new Handler(Looper.getMainLooper()){

            /*
             * Enabled aggressive block sorting
             */
            public void handleMessage(Message message) {
                if (message == null || !(message.obj instanceof Intent)) {
                    Log.w((String)"GCM", (String)"Dropping invalid message");
                }
                if ("com.google.android.c2dm.intent.REGISTRATION".equals((message = (Intent)message.obj).getAction())) {
                    GoogleCloudMessaging.this.ahf.add(message);
                    return;
                } else {
                    if (GoogleCloudMessaging.this.zzq((Intent)message)) return;
                    {
                        message.setPackage(GoogleCloudMessaging.this.zzahs.getPackageName());
                        GoogleCloudMessaging.this.zzahs.sendBroadcast((Intent)message);
                        return;
                    }
                }
            }
        });
    }

    public static GoogleCloudMessaging getInstance(Context object) {
        synchronized (GoogleCloudMessaging.class) {
            if (ahb == null) {
                ahb = new GoogleCloudMessaging();
                GoogleCloudMessaging.ahb.zzahs = object.getApplicationContext();
            }
            object = ahb;
            return object;
        }
    }

    static String zza(Intent object, String string2) throws IOException {
        if (object == null) {
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
        if ((string2 = object.getStringExtra(string2)) != null) {
            return string2;
        }
        if ((object = object.getStringExtra("error")) != null) {
            throw new IOException((String)object);
        }
        throw new IOException("SERVICE_NOT_AVAILABLE");
    }

    /*
     * Enabled aggressive block sorting
     */
    private void zza(String string2, String string3, long l, int n, Bundle bundle) throws IOException {
        if (string2 == null) {
            throw new IllegalArgumentException("Missing 'to'");
        }
        String string4 = GoogleCloudMessaging.zzdb(this.zzahs);
        if (string4 == null) {
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
        Intent intent = new Intent("com.google.android.gcm.intent.SEND");
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        this.zzr(intent);
        intent.setPackage(string4);
        intent.putExtra("google.to", string2);
        intent.putExtra("google.message_id", string3);
        intent.putExtra("google.ttl", Long.toString(l));
        intent.putExtra("google.delay", Integer.toString(n));
        intent.putExtra("google.from", this.zzko(string2));
        if (!string4.contains(".gsf")) {
            this.zzahs.sendOrderedBroadcast(intent, "com.google.android.gtalkservice.permission.GTALK_SERVICE");
            return;
        }
        intent = new Bundle();
        Iterator iterator = bundle.keySet().iterator();
        do {
            if (!iterator.hasNext()) {
                intent.putString("google.to", string2);
                intent.putString("google.message_id", string3);
                InstanceID.getInstance(this.zzahs).zzc("GCM", "upstream", (Bundle)intent);
                return;
            }
            string4 = (String)iterator.next();
            Object object = bundle.get(string4);
            if (!(object instanceof String)) continue;
            string4 = (string4 = String.valueOf(string4)).length() != 0 ? "gcm.".concat(string4) : new String("gcm.");
            intent.putString(string4, (String)object);
        } while (true);
    }

    private String zzbnt() {
        String string2 = String.valueOf("google.rpc");
        String string3 = String.valueOf(String.valueOf(ahe.getAndIncrement()));
        if (string3.length() != 0) {
            return string2.concat(string3);
        }
        return new String(string2);
    }

    public static String zzdb(Context context) {
        return zzc.zzdg(context);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int zzdc(Context object) {
        PackageManager packageManager = object.getPackageManager();
        if ((object = GoogleCloudMessaging.zzdb((Context)object)) == null) return -1;
        object = packageManager.getPackageInfo((String)object, 0);
        if (object == null) return -1;
        try {
            return object.versionCode;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            // empty catch block
        }
        return -1;
    }

    private String zzko(String string2) {
        int n = string2.indexOf(64);
        String string3 = string2;
        if (n > 0) {
            string3 = string2.substring(0, n);
        }
        return InstanceID.getInstance(this.zzahs).zzbok().zzh("", string3, "GCM");
    }

    private boolean zzq(Intent intent) {
        String string2;
        String string3 = string2 = intent.getStringExtra("In-Reply-To");
        if (string2 == null) {
            string3 = string2;
            if (intent.hasExtra("error")) {
                string3 = intent.getStringExtra("google.message_id");
            }
        }
        if (string3 != null && (string3 = this.ahd.remove(string3)) != null) {
            string2 = Message.obtain();
            string2.obj = intent;
            return string3.sendMessage((Message)string2);
        }
        return false;
    }

    public void close() {
        ahb = null;
        zza.agO = null;
        this.zzbnu();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public String getMessageType(Intent object) {
        String string2;
        if (!"com.google.android.c2dm.intent.RECEIVE".equals(object.getAction())) {
            return null;
        }
        object = string2 = object.getStringExtra("message_type");
        if (string2 != null) return object;
        return "gcm";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Deprecated
    @RequiresPermission(value="com.google.android.c2dm.permission.RECEIVE")
    public /* varargs */ String register(String ... object) throws IOException {
        synchronized (this) {
            String string2 = GoogleCloudMessaging.zzdb(this.zzahs);
            if (string2 == null) {
                throw new IOException("SERVICE_NOT_AVAILABLE");
            }
            object = this.zzf((String[])object);
            Bundle bundle = new Bundle();
            if (string2.contains(".gsf")) {
                bundle.putString("legacy.sender", (String)object);
                return InstanceID.getInstance(this.zzahs).getToken((String)object, "GCM", bundle);
            }
            bundle.putString("sender", (String)object);
            return GoogleCloudMessaging.zza(this.zzai(bundle), "registration_id");
        }
    }

    @RequiresPermission(value="com.google.android.c2dm.permission.RECEIVE")
    public void send(String string2, String string3, long l, Bundle bundle) throws IOException {
        this.zza(string2, string3, l, -1, bundle);
    }

    @RequiresPermission(value="com.google.android.c2dm.permission.RECEIVE")
    public void send(String string2, String string3, Bundle bundle) throws IOException {
        this.send(string2, string3, -1, bundle);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Deprecated
    @RequiresPermission(value="com.google.android.c2dm.permission.RECEIVE")
    public void unregister() throws IOException {
        synchronized (this) {
            if (Looper.getMainLooper() == Looper.myLooper()) {
                throw new IOException("MAIN_THREAD");
            }
            InstanceID.getInstance(this.zzahs).deleteInstanceID();
            return;
        }
    }

    @Deprecated
    Intent zzai(Bundle bundle) throws IOException {
        if (Looper.getMainLooper() == Looper.myLooper()) {
            throw new IOException("MAIN_THREAD");
        }
        if (GoogleCloudMessaging.zzdc(this.zzahs) < 0) {
            throw new IOException("Google Play Services missing");
        }
        Bundle bundle2 = bundle;
        if (bundle == null) {
            bundle2 = new Bundle();
        }
        bundle = new Intent("com.google.android.c2dm.intent.REGISTER");
        bundle.setPackage(GoogleCloudMessaging.zzdb(this.zzahs));
        this.zzr((Intent)bundle);
        bundle.putExtra("google.message_id", this.zzbnt());
        bundle.putExtras(bundle2);
        bundle.putExtra("google.messenger", (Parcelable)this.ahg);
        this.zzahs.startService((Intent)bundle);
        try {
            bundle = this.ahf.poll(30000, TimeUnit.MILLISECONDS);
            return bundle;
        }
        catch (InterruptedException var1_2) {
            throw new IOException(var1_2.getMessage());
        }
    }

    void zzbnu() {
        synchronized (this) {
            if (this.ahc != null) {
                this.ahc.cancel();
                this.ahc = null;
            }
            return;
        }
    }

    /* varargs */ String zzf(String ... arrstring) {
        if (arrstring == null || arrstring.length == 0) {
            throw new IllegalArgumentException("No senderIds");
        }
        StringBuilder stringBuilder = new StringBuilder(arrstring[0]);
        for (int i = 1; i < arrstring.length; ++i) {
            stringBuilder.append(',').append(arrstring[i]);
        }
        return stringBuilder.toString();
    }

    void zzr(Intent intent) {
        synchronized (this) {
            if (this.ahc == null) {
                Intent intent2 = new Intent();
                intent2.setPackage("com.google.example.invalidpackage");
                this.ahc = PendingIntent.getBroadcast((Context)this.zzahs, (int)0, (Intent)intent2, (int)0);
            }
            intent.putExtra("app", (Parcelable)this.ahc);
            return;
        }
    }

}

