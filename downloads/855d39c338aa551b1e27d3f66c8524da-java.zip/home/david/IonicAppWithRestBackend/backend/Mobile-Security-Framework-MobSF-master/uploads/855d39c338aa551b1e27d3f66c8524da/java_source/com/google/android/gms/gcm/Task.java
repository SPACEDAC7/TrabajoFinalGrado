/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.util.Log
 */
package com.google.android.gms.gcm;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.CallSuper;
import android.util.Log;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.gcm.GcmNetworkManager;
import com.google.android.gms.gcm.GcmTaskService;
import com.google.android.gms.gcm.zzc;
import java.util.Iterator;
import java.util.Set;

public abstract class Task
implements Parcelable {
    public static final int EXTRAS_LIMIT_BYTES = 10240;
    public static final int NETWORK_STATE_ANY = 2;
    public static final int NETWORK_STATE_CONNECTED = 0;
    public static final int NETWORK_STATE_UNMETERED = 1;
    protected static final long UNINITIALIZED = -1;
    private final String aht;
    private final boolean ahu;
    private final boolean ahv;
    private final int ahw;
    private final boolean ahx;
    private final boolean ahy;
    private final zzc ahz;
    private final Bundle mExtras;
    private final String mTag;

    /*
     * Enabled aggressive block sorting
     */
    @Deprecated
    Task(Parcel parcel) {
        boolean bl = true;
        Log.e((String)"Task", (String)"Constructing a Task object using a parcel.");
        this.aht = parcel.readString();
        this.mTag = parcel.readString();
        boolean bl2 = parcel.readInt() == 1;
        this.ahu = bl2;
        bl2 = parcel.readInt() == 1 ? bl : false;
        this.ahv = bl2;
        this.ahw = 2;
        this.ahx = false;
        this.ahy = false;
        this.ahz = zzc.aho;
        this.mExtras = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    Task(Builder object) {
        this.aht = object.gcmTaskService;
        this.mTag = object.tag;
        this.ahu = object.updateCurrent;
        this.ahv = object.isPersisted;
        this.ahw = object.requiredNetworkState;
        this.ahx = object.requiresCharging;
        this.ahy = false;
        this.mExtras = object.extras;
        object = object.ahA != null ? object.ahA : zzc.aho;
        this.ahz = object;
    }

    public static void zza(zzc zzc2) {
        if (zzc2 != null) {
            int n = zzc2.zzbnv();
            if (n != 1 && n != 0) {
                throw new IllegalArgumentException(new StringBuilder(45).append("Must provide a valid RetryPolicy: ").append(n).toString());
            }
            int n2 = zzc2.zzbnw();
            int n3 = zzc2.zzbnx();
            if (n == 0 && n2 < 0) {
                throw new IllegalArgumentException(new StringBuilder(52).append("InitialBackoffSeconds can't be negative: ").append(n2).toString());
            }
            if (n == 1 && n2 < 10) {
                throw new IllegalArgumentException("RETRY_POLICY_LINEAR must have an initial backoff at least 10 seconds.");
            }
            if (n3 < n2) {
                n = zzc2.zzbnx();
                throw new IllegalArgumentException(new StringBuilder(77).append("MaximumBackoffSeconds must be greater than InitialBackoffSeconds: ").append(n).toString());
            }
        }
    }

    private static boolean zzah(Object object) {
        if (object instanceof Integer || object instanceof Long || object instanceof Double || object instanceof String || object instanceof Boolean) {
            return true;
        }
        return false;
    }

    public static void zzak(Bundle object) {
        if (object != null) {
            Object object2 = Parcel.obtain();
            object.writeToParcel((Parcel)object2, 0);
            int n = object2.dataSize();
            if (n > 10240) {
                object2.recycle();
                object = String.valueOf("Extras exceeding maximum size(10240 bytes): ");
                throw new IllegalArgumentException(new StringBuilder(String.valueOf(object).length() + 11).append((String)object).append(n).toString());
            }
            object2.recycle();
            object2 = object.keySet().iterator();
            while (object2.hasNext()) {
                if (Task.zzah(object.get((String)object2.next()))) continue;
                throw new IllegalArgumentException("Only the following extra parameter types are supported: Integer, Long, Double, String, and Boolean. ");
            }
        }
    }

    public int describeContents() {
        return 0;
    }

    public Bundle getExtras() {
        return this.mExtras;
    }

    public int getRequiredNetwork() {
        return this.ahw;
    }

    public boolean getRequiresCharging() {
        return this.ahx;
    }

    public String getServiceName() {
        return this.aht;
    }

    public String getTag() {
        return this.mTag;
    }

    public boolean isPersisted() {
        return this.ahv;
    }

    public boolean isUpdateCurrent() {
        return this.ahu;
    }

    public void toBundle(Bundle bundle) {
        bundle.putString("tag", this.mTag);
        bundle.putBoolean("update_current", this.ahu);
        bundle.putBoolean("persisted", this.ahv);
        bundle.putString("service", this.aht);
        bundle.putInt("requiredNetwork", this.ahw);
        bundle.putBoolean("requiresCharging", this.ahx);
        bundle.putBoolean("requiresIdle", this.ahy);
        bundle.putBundle("retryStrategy", this.ahz.zzaj(new Bundle()));
        bundle.putBundle("extras", this.mExtras);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void writeToParcel(Parcel parcel, int n) {
        int n2 = 1;
        parcel.writeString(this.aht);
        parcel.writeString(this.mTag);
        n = this.ahu ? 1 : 0;
        parcel.writeInt(n);
        n = this.ahv ? n2 : 0;
        parcel.writeInt(n);
    }

    public static abstract class Builder {
        protected zzc ahA = zzc.aho;
        protected Bundle extras;
        protected String gcmTaskService;
        protected boolean isPersisted;
        protected int requiredNetworkState;
        protected boolean requiresCharging;
        protected String tag;
        protected boolean updateCurrent;

        public abstract Task build();

        /*
         * Enabled aggressive block sorting
         */
        @CallSuper
        protected void checkConditions() {
            boolean bl = this.gcmTaskService != null;
            zzaa.zzb(bl, (Object)"Must provide an endpoint for this task by calling setService(ComponentName).");
            GcmNetworkManager.zzki(this.tag);
            Task.zza(this.ahA);
            if (this.isPersisted) {
                Task.zzak(this.extras);
            }
        }

        public abstract Builder setExtras(Bundle var1);

        public abstract Builder setPersisted(boolean var1);

        public abstract Builder setRequiredNetwork(int var1);

        public abstract Builder setRequiresCharging(boolean var1);

        public abstract Builder setService(Class<? extends GcmTaskService> var1);

        public abstract Builder setTag(String var1);

        public abstract Builder setUpdateCurrent(boolean var1);
    }

}

