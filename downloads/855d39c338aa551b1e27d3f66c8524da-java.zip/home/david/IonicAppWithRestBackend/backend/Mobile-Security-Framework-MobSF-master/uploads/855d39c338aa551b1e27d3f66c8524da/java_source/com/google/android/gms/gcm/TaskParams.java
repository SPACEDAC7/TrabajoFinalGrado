/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 */
package com.google.android.gms.gcm;

import android.os.Bundle;

public class TaskParams {
    private final Bundle extras;
    private final String tag;

    public TaskParams(String string2) {
        this(string2, null);
    }

    public TaskParams(String string2, Bundle bundle) {
        this.tag = string2;
        this.extras = bundle;
    }

    public Bundle getExtras() {
        return this.extras;
    }

    public String getTag() {
        return this.tag;
    }
}

