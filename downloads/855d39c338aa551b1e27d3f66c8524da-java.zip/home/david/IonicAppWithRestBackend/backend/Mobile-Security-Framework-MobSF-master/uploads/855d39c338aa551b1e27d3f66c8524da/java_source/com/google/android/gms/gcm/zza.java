/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningAppProcessInfo
 *  android.app.KeyguardManager
 *  android.app.Notification
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.res.Resources
 *  android.graphics.Color
 *  android.media.RingtoneManager
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Process
 *  android.os.SystemClock
 *  android.text.TextUtils
 *  android.util.Log
 *  org.json.JSONArray
 *  org.json.JSONException
 */
package com.google.android.gms.gcm;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.os.SystemClock;
import android.support.v4.app.NotificationCompat;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.gcm.GcmListenerService;
import java.util.Iterator;
import java.util.List;
import java.util.MissingFormatArgumentException;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;

class zza {
    static zza agO;
    private final Context mContext;

    private zza(Context context) {
        this.mContext = context.getApplicationContext();
    }

    private void zza(String string2, Notification notification) {
        if (Log.isLoggable((String)"GcmNotification", (int)3)) {
            Log.d((String)"GcmNotification", (String)"Showing notification");
        }
        NotificationManager notificationManager = (NotificationManager)this.mContext.getSystemService("notification");
        String string3 = string2;
        if (TextUtils.isEmpty((CharSequence)string2)) {
            long l = SystemClock.uptimeMillis();
            string3 = new StringBuilder(37).append("GCM-Notification:").append(l).toString();
        }
        notificationManager.notify(string3, 0, notification);
    }

    static boolean zzad(Bundle bundle) {
        if ("1".equals(zza.zzf(bundle, "gcm.n.e")) || zza.zzf(bundle, "gcm.n.icon") != null) {
            return true;
        }
        return false;
    }

    static void zzae(Bundle bundle) {
        String string2;
        Bundle bundle2 = new Bundle();
        Iterator iterator = bundle.keySet().iterator();
        while (iterator.hasNext()) {
            String string3 = (String)iterator.next();
            String string4 = bundle.getString(string3);
            string2 = string3;
            if (string3.startsWith("gcm.notification.")) {
                string2 = string3.replace("gcm.notification.", "gcm.n.");
            }
            if (!string2.startsWith("gcm.n.")) continue;
            if (!"gcm.n.e".equals(string2)) {
                bundle2.putString(string2.substring("gcm.n.".length()), string4);
            }
            iterator.remove();
        }
        string2 = bundle2.getString("sound2");
        if (string2 != null) {
            bundle2.remove("sound2");
            bundle2.putString("sound", string2);
        }
        if (!bundle2.isEmpty()) {
            bundle.putBundle("notification", bundle2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private Notification zzag(Bundle bundle) {
        String string2 = this.zzg(bundle, "gcm.n.title");
        String string3 = this.zzg(bundle, "gcm.n.body");
        int n = this.zzkl(zza.zzf(bundle, "gcm.n.icon"));
        String string4 = zza.zzf(bundle, "gcm.n.color");
        Uri uri = this.zzkm(zza.zzf(bundle, "gcm.n.sound2"));
        bundle = this.zzah(bundle);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this.mContext).setAutoCancel(true).setSmallIcon(n);
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            builder.setContentTitle(string2);
        } else {
            builder.setContentTitle(this.mContext.getApplicationInfo().loadLabel(this.mContext.getPackageManager()));
        }
        if (!TextUtils.isEmpty((CharSequence)string3)) {
            builder.setContentText(string3);
        }
        if (!TextUtils.isEmpty((CharSequence)string4)) {
            builder.setColor(Color.parseColor((String)string4));
        }
        if (uri != null) {
            builder.setSound(uri);
        }
        if (bundle != null) {
            builder.setContentIntent((PendingIntent)bundle);
        }
        return builder.build();
    }

    /*
     * Enabled aggressive block sorting
     */
    private PendingIntent zzah(Bundle iterator) {
        String string2 = zza.zzf((Bundle)iterator, "gcm.n.click_action");
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            string2 = new Intent(string2);
            string2.setPackage(this.mContext.getPackageName());
            string2.setFlags(268435456);
        } else {
            string2 = this.mContext.getPackageManager().getLaunchIntentForPackage(this.mContext.getPackageName());
            if (string2 == null) {
                Log.w((String)"GcmNotification", (String)"No activity found to launch app");
                return null;
            }
        }
        iterator = new Bundle((Bundle)iterator);
        GcmListenerService.zzac((Bundle)iterator);
        string2.putExtras((Bundle)iterator);
        iterator = iterator.keySet().iterator();
        while (iterator.hasNext()) {
            String string3 = (String)iterator.next();
            if (!string3.startsWith("gcm.n.") && !string3.startsWith("gcm.notification.")) continue;
            string2.removeExtra(string3);
        }
        return PendingIntent.getActivity((Context)this.mContext, (int)this.zzbnr(), (Intent)string2, (int)1073741824);
    }

    private int zzbnr() {
        return (int)SystemClock.uptimeMillis();
    }

    static zza zzcz(Context object) {
        synchronized (zza.class) {
            if (agO == null) {
                agO = new zza((Context)object);
            }
            object = agO;
            return object;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static boolean zzda(Context iterator) {
        if (((KeyguardManager)iterator.getSystemService("keyguard")).inKeyguardRestrictedInputMode()) {
            return false;
        }
        int n = Process.myPid();
        if ((iterator = ((ActivityManager)iterator.getSystemService("activity")).getRunningAppProcesses()) == null) return false;
        iterator = iterator.iterator();
        do {
            if (!iterator.hasNext()) return false;
            ActivityManager.RunningAppProcessInfo runningAppProcessInfo = (ActivityManager.RunningAppProcessInfo)iterator.next();
        } while (runningAppProcessInfo.pid != n);
        if (runningAppProcessInfo.importance != 100) return false;
        return true;
    }

    static String zzf(Bundle bundle, String string2) {
        String string3;
        String string4 = string3 = bundle.getString(string2);
        if (string3 == null) {
            string4 = bundle.getString(string2.replace("gcm.n.", "gcm.notification."));
        }
        return string4;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String zzg(Bundle object, String string2) {
        String string3 = zza.zzf((Bundle)object, string2);
        if (!TextUtils.isEmpty((CharSequence)string3)) {
            return string3;
        }
        string3 = String.valueOf(string2);
        String string4 = String.valueOf("_loc_key");
        string3 = string4.length() != 0 ? string3.concat(string4) : new String(string3);
        string4 = zza.zzf((Bundle)object, string3);
        if (TextUtils.isEmpty((CharSequence)string4)) {
            return null;
        }
        Resources resources = this.mContext.getResources();
        int n = resources.getIdentifier(string4, "string", this.mContext.getPackageName());
        if (n == 0) {
            object = String.valueOf(string2);
            string2 = String.valueOf("_loc_key");
            object = string2.length() != 0 ? object.concat(string2) : new String((String)object);
            object = String.valueOf(this.zzkk((String)object));
            Log.w((String)"GcmNotification", (String)new StringBuilder(String.valueOf(object).length() + 49 + String.valueOf(string4).length()).append((String)object).append(" resource not found: ").append(string4).append(" Default value will be used.").toString());
            return null;
        }
        string3 = String.valueOf(string2);
        Object[] arrobject = String.valueOf("_loc_args");
        string3 = arrobject.length() != 0 ? string3.concat((String)arrobject) : new String(string3);
        if (TextUtils.isEmpty((CharSequence)(string3 = zza.zzf((Bundle)object, string3)))) {
            return resources.getString(n);
        }
        try {
            object = new JSONArray(string3);
            arrobject = new String[object.length()];
            int n2 = 0;
            while (n2 < arrobject.length) {
                arrobject[n2] = object.opt(n2);
                ++n2;
            }
            return resources.getString(n, arrobject);
        }
        catch (JSONException var1_2) {
            String string5 = String.valueOf(string2);
            string2 = String.valueOf("_loc_args");
            string5 = string2.length() != 0 ? string5.concat(string2) : new String(string5);
            string5 = String.valueOf(this.zzkk(string5));
            Log.w((String)"GcmNotification", (String)new StringBuilder(String.valueOf(string5).length() + 41 + String.valueOf(string3).length()).append("Malformed ").append(string5).append(": ").append(string3).append("  Default value will be used.").toString());
            return null;
        }
        catch (MissingFormatArgumentException var1_4) {
            Log.w((String)"GcmNotification", (String)new StringBuilder(String.valueOf(string4).length() + 58 + String.valueOf(string3).length()).append("Missing format argument for ").append(string4).append(": ").append(string3).append(" Default value will be used.").toString(), (Throwable)var1_4);
            return null;
        }
    }

    private String zzkk(String string2) {
        return string2.substring("gcm.n.".length());
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private int zzkl(String string2) {
        int n;
        int n2;
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            Resources resources = this.mContext.getResources();
            n2 = resources.getIdentifier(string2, "drawable", this.mContext.getPackageName());
            if (n2 != 0) {
                return n2;
            }
            n2 = n = resources.getIdentifier(string2, "mipmap", this.mContext.getPackageName());
            if (n != 0) return n2;
            Log.w((String)"GcmNotification", (String)new StringBuilder(String.valueOf(string2).length() + 57).append("Icon resource ").append(string2).append(" not found. Notification will use app icon.").toString());
        }
        n2 = n = this.mContext.getApplicationInfo().icon;
        if (n != 0) return n2;
        return 17301651;
    }

    private Uri zzkm(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return null;
        }
        if (!"default".equals(string2) && this.mContext.getResources().getIdentifier(string2, "raw", this.mContext.getPackageName()) != 0) {
            String string3 = String.valueOf("android.resource://");
            String string4 = String.valueOf(this.mContext.getPackageName());
            return Uri.parse((String)new StringBuilder(String.valueOf(string3).length() + 5 + String.valueOf(string4).length() + String.valueOf(string2).length()).append(string3).append(string4).append("/raw/").append(string2).toString());
        }
        return RingtoneManager.getDefaultUri((int)2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    boolean zzaf(Bundle bundle) {
        try {
            Notification notification = this.zzag(bundle);
            this.zza(zza.zzf(bundle, "gcm.n.tag"), notification);
            return true;
        }
        catch (zza var1_2) {
            String string2 = String.valueOf(var1_2.getMessage());
            string2 = string2.length() != 0 ? "Failed to show notification: ".concat(string2) : new String("Failed to show notification: ");
            Log.e((String)"GcmNotification", (String)string2);
            return false;
        }
    }

    private class zza
    extends IllegalArgumentException {
    }

}

