/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.RemoteException
 */
package com.google.android.gms.gcm;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface zzb
extends IInterface {
    public void zztn(int var1) throws RemoteException;

    public static abstract class com.google.android.gms.gcm.zzb$zza
    extends Binder
    implements zzb {
        public static zzb zzgt(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.gcm.INetworkTaskCallback");
            if (iInterface != null && iInterface instanceof zzb) {
                return (zzb)iInterface;
            }
            return new zza(iBinder);
        }

        public boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) throws RemoteException {
            switch (n) {
                default: {
                    return super.onTransact(n, parcel, parcel2, n2);
                }
                case 1598968902: {
                    parcel2.writeString("com.google.android.gms.gcm.INetworkTaskCallback");
                    return true;
                }
                case 2: 
            }
            parcel.enforceInterface("com.google.android.gms.gcm.INetworkTaskCallback");
            this.zztn(parcel.readInt());
            parcel2.writeNoException();
            return true;
        }

        private static class zza
        implements zzb {
            private IBinder zzajq;

            zza(IBinder iBinder) {
                this.zzajq = iBinder;
            }

            public IBinder asBinder() {
                return this.zzajq;
            }

            @Override
            public void zztn(int n) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                Parcel parcel2 = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken("com.google.android.gms.gcm.INetworkTaskCallback");
                    parcel.writeInt(n);
                    this.zzajq.transact(2, parcel, parcel2, 0);
                    parcel2.readException();
                    return;
                }
                finally {
                    parcel2.recycle();
                    parcel.recycle();
                }
            }
        }

    }

}

