/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 */
package com.google.android.gms.gcm;

import android.os.Bundle;

public class zzc {
    public static final zzc aho = new zzc(0, 30, 3600);
    public static final zzc ahp = new zzc(1, 30, 3600);
    private final int ahq;
    private final int ahr;
    private final int ahs;

    private zzc(int n, int n2, int n3) {
        this.ahq = n;
        this.ahr = n2;
        this.ahs = n3;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof zzc)) {
            return false;
        }
        object = (zzc)object;
        if (object.ahq != this.ahq) return false;
        if (object.ahr != this.ahr) return false;
        if (object.ahs == this.ahs) return true;
        return false;
    }

    public int hashCode() {
        return ((this.ahq + 1 ^ 1000003) * 1000003 ^ this.ahr) * 1000003 ^ this.ahs;
    }

    public String toString() {
        int n = this.ahq;
        int n2 = this.ahr;
        int n3 = this.ahs;
        return new StringBuilder(74).append("policy=").append(n).append(" initial_backoff=").append(n2).append(" maximum_backoff=").append(n3).toString();
    }

    public Bundle zzaj(Bundle bundle) {
        bundle.putInt("retry_policy", this.ahq);
        bundle.putInt("initial_backoff_seconds", this.ahr);
        bundle.putInt("maximum_backoff_seconds", this.ahs);
        return bundle;
    }

    public int zzbnv() {
        return this.ahq;
    }

    public int zzbnw() {
        return this.ahr;
    }

    public int zzbnx() {
        return this.ahs;
    }
}

