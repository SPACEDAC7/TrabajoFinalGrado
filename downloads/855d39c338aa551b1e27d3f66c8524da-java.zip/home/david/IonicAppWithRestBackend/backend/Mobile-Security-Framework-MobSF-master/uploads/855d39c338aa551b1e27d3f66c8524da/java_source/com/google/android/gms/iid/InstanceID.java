/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  android.os.Looper
 *  android.util.Base64
 *  android.util.Log
 */
package com.google.android.gms.iid;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.iid.zzc;
import com.google.android.gms.iid.zzd;
import java.io.IOException;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;

public class InstanceID {
    public static final String ERROR_BACKOFF = "RETRY_LATER";
    public static final String ERROR_MAIN_THREAD = "MAIN_THREAD";
    public static final String ERROR_MISSING_INSTANCEID_SERVICE = "MISSING_INSTANCEID_SERVICE";
    public static final String ERROR_SERVICE_NOT_AVAILABLE = "SERVICE_NOT_AVAILABLE";
    public static final String ERROR_TIMEOUT = "TIMEOUT";
    static Map<String, InstanceID> aic = new HashMap<String, InstanceID>();
    private static zzd aid;
    private static zzc aie;
    static String aii;
    KeyPair aif;
    String aig = "";
    long aih;
    Context mContext;

    protected InstanceID(Context context, String string2, Bundle bundle) {
        this.mContext = context.getApplicationContext();
        this.aig = string2;
    }

    public static InstanceID getInstance(Context context) {
        return InstanceID.zza(context, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static InstanceID zza(Context object, Bundle bundle) {
        synchronized (InstanceID.class) {
            InstanceID instanceID;
            void var1_1;
            String string2 = var1_1 == null ? "" : var1_1.getString("subtype");
            if (string2 == null) {
                string2 = "";
            }
            Context context = object.getApplicationContext();
            if (aid == null) {
                aid = new zzd(context);
                aie = new zzc(context);
            }
            aii = Integer.toString(InstanceID.zzdd(context));
            object = instanceID = aic.get(string2);
            if (instanceID == null) {
                object = new InstanceID(context, string2, (Bundle)var1_1);
                aic.put(string2, (InstanceID)object);
            }
            return object;
        }
    }

    static String zza(KeyPair object) {
        object = object.getPublic().getEncoded();
        try {
            object = MessageDigest.getInstance("SHA1").digest((byte[])object);
        }
        catch (NoSuchAlgorithmException var0_1) {
            Log.w((String)"InstanceID", (String)"Unexpected error, device missing required alghorithms");
            return null;
        }
        object[0] = (byte)((object[0] & 15) + 112 & 255);
        object = Base64.encodeToString((byte[])object, (int)0, (int)8, (int)11);
        return object;
    }

    static int zzdd(Context context) {
        try {
            int n = context.getPackageManager().getPackageInfo((String)context.getPackageName(), (int)0).versionCode;
            return n;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            String string2 = String.valueOf((Object)var0_1);
            Log.w((String)"InstanceID", (String)new StringBuilder(String.valueOf(string2).length() + 38).append("Never happens: can't find own package ").append(string2).toString());
            return 0;
        }
    }

    static String zzde(Context object) {
        try {
            object = object.getPackageManager().getPackageInfo((String)object.getPackageName(), (int)0).versionName;
            return object;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            String string2 = String.valueOf((Object)var0_1);
            Log.w((String)"InstanceID", (String)new StringBuilder(String.valueOf(string2).length() + 38).append("Never happens: can't find own package ").append(string2).toString());
            return null;
        }
    }

    static String zzv(byte[] arrby) {
        return Base64.encodeToString((byte[])arrby, (int)11);
    }

    public void deleteInstanceID() throws IOException {
        this.zzb("*", "*", null);
        this.zzboj();
    }

    public void deleteToken(String string2, String string3) throws IOException {
        this.zzb(string2, string3, null);
    }

    public long getCreationTime() {
        String string2;
        if (this.aih == 0 && (string2 = aid.get(this.aig, "cre")) != null) {
            this.aih = Long.parseLong(string2);
        }
        return this.aih;
    }

    public String getId() {
        return InstanceID.zza(this.zzboi());
    }

    public String getToken(String string2, String string3) throws IOException {
        return this.getToken(string2, string3, null);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public String getToken(String string2, String string3, Bundle object) throws IOException {
        boolean bl = false;
        if (Looper.getMainLooper() == Looper.myLooper()) {
            throw new IOException("MAIN_THREAD");
        }
        boolean bl2 = true;
        Object object2 = this.zzbom() ? null : aid.zzh(this.aig, string2, string3);
        if (object2 != null) {
            return object2;
        }
        object2 = object;
        if (object == null) {
            object2 = new Bundle();
        }
        if (object2.getString("ttl") != null) {
            bl2 = false;
        }
        if ("jwt".equals(object2.getString("type"))) {
            bl2 = bl;
        }
        object2 = object = this.zzc(string2, string3, (Bundle)object2);
        if (object == null) return object2;
        object2 = object;
        if (!bl2) return object2;
        aid.zza(this.aig, string2, string3, (String)object, aii);
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void zzb(String string2, String string3, Bundle bundle) throws IOException {
        if (Looper.getMainLooper() == Looper.myLooper()) {
            throw new IOException("MAIN_THREAD");
        }
        aid.zzi(this.aig, string2, string3);
        Bundle bundle2 = bundle;
        if (bundle == null) {
            bundle2 = new Bundle();
        }
        bundle2.putString("sender", string2);
        if (string3 != null) {
            bundle2.putString("scope", string3);
        }
        bundle2.putString("subscription", string2);
        bundle2.putString("delete", "1");
        bundle2.putString("X-delete", "1");
        string3 = "".equals(this.aig) ? string2 : this.aig;
        bundle2.putString("subtype", string3);
        if (!"".equals(this.aig)) {
            string2 = this.aig;
        }
        bundle2.putString("X-subtype", string2);
        string2 = aie.zza(bundle2, this.zzboi());
        aie.zzt((Intent)string2);
    }

    KeyPair zzboi() {
        if (this.aif == null) {
            this.aif = aid.zzks(this.aig);
        }
        if (this.aif == null) {
            this.aih = System.currentTimeMillis();
            this.aif = aid.zze(this.aig, this.aih);
        }
        return this.aif;
    }

    public void zzboj() {
        this.aih = 0;
        aid.zzkt(this.aig);
        this.aif = null;
    }

    public zzd zzbok() {
        return aid;
    }

    public zzc zzbol() {
        return aie;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    boolean zzbom() {
        String string2 = aid.get("appVersion");
        if (string2 == null) return true;
        if (!string2.equals(aii)) {
            return true;
        }
        string2 = aid.get("lastToken");
        if (string2 == null) return true;
        long l = Long.parseLong(string2);
        if (System.currentTimeMillis() / 1000 - Long.valueOf(l) > 604800) return true;
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public String zzc(String string2, String string3, Bundle bundle) throws IOException {
        if (string3 != null) {
            bundle.putString("scope", string3);
        }
        bundle.putString("sender", string2);
        string3 = "".equals(this.aig) ? string2 : this.aig;
        if (!bundle.containsKey("legacy.register")) {
            bundle.putString("subscription", string2);
            bundle.putString("subtype", string3);
            bundle.putString("X-subscription", string2);
            bundle.putString("X-subtype", string3);
        }
        string2 = aie.zza(bundle, this.zzboi());
        return aie.zzt((Intent)string2);
    }
}

