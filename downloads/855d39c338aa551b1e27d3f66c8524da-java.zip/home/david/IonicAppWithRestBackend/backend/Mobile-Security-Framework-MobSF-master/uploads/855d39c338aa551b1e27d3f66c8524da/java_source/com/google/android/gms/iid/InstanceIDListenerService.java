/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.pm.PackageManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.Message
 *  android.os.Parcelable
 *  android.util.Log
 */
package com.google.android.gms.iid;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;
import com.google.android.gms.iid.InstanceID;
import com.google.android.gms.iid.MessengerCompat;
import com.google.android.gms.iid.zzc;
import com.google.android.gms.iid.zzd;

public class InstanceIDListenerService
extends Service {
    static String ACTION = "action";
    private static String agS;
    private static String ail;
    private static String aim;
    MessengerCompat aij;
    BroadcastReceiver aik;
    int ain;
    int aio;

    static {
        ail = "google.com/iid";
        aim = "CMD";
        agS = "gcm.googleapis.com/refresh";
    }

    public InstanceIDListenerService() {
        this.aij = new MessengerCompat(new Handler(Looper.getMainLooper()){

            public void handleMessage(Message message) {
                InstanceIDListenerService.this.zza(message, MessengerCompat.zzc(message));
            }
        });
        this.aik = new BroadcastReceiver(){

            public void onReceive(Context object, Intent intent) {
                if (Log.isLoggable((String)"InstanceID", (int)3)) {
                    intent.getStringExtra("registration_id");
                    object = String.valueOf((Object)intent.getExtras());
                    Log.d((String)"InstanceID", (String)new StringBuilder(String.valueOf(object).length() + 46).append("Received GSF callback using dynamic receiver: ").append((String)object).toString());
                }
                InstanceIDListenerService.this.zzn(intent);
                InstanceIDListenerService.this.stop();
            }
        };
    }

    static void zza(Context context, zzd zzd2) {
        zzd2.zzbop();
        zzd2 = new Intent("com.google.android.gms.iid.InstanceID");
        zzd2.putExtra(aim, "RST");
        zzd2.setPackage(context.getPackageName());
        context.startService((Intent)zzd2);
    }

    private void zza(Message message, int n) {
        zzc.zzdg((Context)this);
        this.getPackageManager();
        if (n != zzc.aiv && n != zzc.aiu) {
            int n2 = zzc.aiu;
            int n3 = zzc.aiv;
            Log.w((String)"InstanceID", (String)new StringBuilder(77).append("Message from unexpected caller ").append(n).append(" mine=").append(n2).append(" appid=").append(n3).toString());
            return;
        }
        this.zzn((Intent)message.obj);
    }

    static void zzdf(Context context) {
        Intent intent = new Intent("com.google.android.gms.iid.InstanceID");
        intent.setPackage(context.getPackageName());
        intent.putExtra(aim, "SYNC");
        context.startService(intent);
    }

    public IBinder onBind(Intent intent) {
        if (intent != null && "com.google.android.gms.iid.InstanceID".equals(intent.getAction())) {
            return this.aij.getBinder();
        }
        return null;
    }

    public void onCreate() {
        IntentFilter intentFilter = new IntentFilter("com.google.android.c2dm.intent.REGISTRATION");
        intentFilter.addCategory(this.getPackageName());
        this.registerReceiver(this.aik, intentFilter, "com.google.android.c2dm.permission.RECEIVE", null);
    }

    public void onDestroy() {
        this.unregisterReceiver(this.aik);
    }

    public int onStartCommand(Intent intent, int n, int n2) {
        block8 : {
            this.zztu(n2);
            if (intent == null) {
                this.stop();
                return 2;
            }
            if ("com.google.android.gms.iid.InstanceID".equals(intent.getAction())) {
                Intent intent2;
                if (Build.VERSION.SDK_INT <= 18 && (intent2 = (Intent)intent.getParcelableExtra("GSF")) != null) {
                    this.startService(intent2);
                    return 1;
                }
                this.zzn(intent);
            }
            if (intent.getStringExtra("from") == null) break block8;
            WakefulBroadcastReceiver.completeWakefulIntent(intent);
        }
        return 2;
        finally {
            this.stop();
        }
    }

    public void onTokenRefresh() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void stop() {
        synchronized (this) {
            --this.ain;
            if (this.ain == 0) {
                this.stopSelf(this.aio);
            }
            if (Log.isLoggable((String)"InstanceID", (int)3)) {
                int n = this.ain;
                int n2 = this.aio;
                Log.d((String)"InstanceID", (String)new StringBuilder(28).append("Stop ").append(n).append(" ").append(n2).toString());
            }
            return;
        }
    }

    public void zzcc(boolean bl) {
        this.onTokenRefresh();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void zzn(Intent intent) {
        InstanceID instanceID;
        String string2 = intent.getStringExtra("subtype");
        if (string2 == null) {
            instanceID = InstanceID.getInstance((Context)this);
        } else {
            instanceID = new Bundle();
            instanceID.putString("subtype", string2);
            instanceID = InstanceID.zza((Context)this, (Bundle)instanceID);
        }
        String string3 = intent.getStringExtra(aim);
        if (intent.getStringExtra("error") != null || intent.getStringExtra("registration_id") != null) {
            if (Log.isLoggable((String)"InstanceID", (int)3)) {
                string3 = String.valueOf(string2);
                string3 = string3.length() != 0 ? "Register result in service ".concat(string3) : new String("Register result in service ");
                Log.d((String)"InstanceID", (String)string3);
            }
            instanceID.zzbol().zzv(intent);
            return;
        } else {
            Object object;
            if (Log.isLoggable((String)"InstanceID", (int)3)) {
                object = String.valueOf((Object)intent.getExtras());
                Log.d((String)"InstanceID", (String)new StringBuilder(String.valueOf(string2).length() + 18 + String.valueOf(string3).length() + String.valueOf(object).length()).append("Service command ").append(string2).append(" ").append(string3).append(" ").append((String)object).toString());
            }
            if (intent.getStringExtra("unregistered") != null) {
                object = instanceID.zzbok();
                string3 = string2;
                if (string2 == null) {
                    string3 = "";
                }
                object.zzku(string3);
                instanceID.zzbol().zzv(intent);
                return;
            }
            if (agS.equals(intent.getStringExtra("from"))) {
                instanceID.zzbok().zzku(string2);
                this.zzcc(false);
                return;
            }
            if ("RST".equals(string3)) {
                instanceID.zzboj();
                this.zzcc(true);
                return;
            }
            if ("RST_FULL".equals(string3)) {
                if (instanceID.zzbok().isEmpty()) return;
                {
                    instanceID.zzbok().zzbop();
                    this.zzcc(true);
                    return;
                }
            } else {
                if ("SYNC".equals(string3)) {
                    instanceID.zzbok().zzku(string2);
                    this.zzcc(false);
                    return;
                }
                if (!"PING".equals(string3)) return;
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void zztu(int n) {
        synchronized (this) {
            ++this.ain;
            if (n > this.aio) {
                this.aio = n;
            }
            return;
        }
    }

}

