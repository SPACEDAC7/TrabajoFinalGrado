/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.os.Binder
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Message
 *  android.os.Messenger
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 */
package com.google.android.gms.iid;

import android.annotation.TargetApi;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.iid.zzb;

public class MessengerCompat
implements Parcelable {
    public static final Parcelable.Creator<MessengerCompat> CREATOR = new Parcelable.Creator<MessengerCompat>(){

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return this.zznf(parcel);
        }

        public /* synthetic */ Object[] newArray(int n) {
            return this.zztv(n);
        }

        public MessengerCompat zznf(Parcel parcel) {
            if ((parcel = parcel.readStrongBinder()) != null) {
                return new MessengerCompat((IBinder)parcel);
            }
            return null;
        }

        public MessengerCompat[] zztv(int n) {
            return new MessengerCompat[n];
        }
    };
    Messenger aiq;
    zzb air;

    public MessengerCompat(Handler handler) {
        if (Build.VERSION.SDK_INT >= 21) {
            this.aiq = new Messenger(handler);
            return;
        }
        this.air = new zza(handler);
    }

    public MessengerCompat(IBinder iBinder) {
        if (Build.VERSION.SDK_INT >= 21) {
            this.aiq = new Messenger(iBinder);
            return;
        }
        this.air = zzb.zza.zzgx(iBinder);
    }

    public static int zzc(Message message) {
        if (Build.VERSION.SDK_INT >= 21) {
            return MessengerCompat.zzd(message);
        }
        return message.arg2;
    }

    @TargetApi(value=21)
    private static int zzd(Message message) {
        return message.sendingUid;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        try {
            boolean bl = this.getBinder().equals((Object)((MessengerCompat)object).getBinder());
            return bl;
        }
        catch (ClassCastException var1_2) {
            return false;
        }
    }

    public IBinder getBinder() {
        if (this.aiq != null) {
            return this.aiq.getBinder();
        }
        return this.air.asBinder();
    }

    public int hashCode() {
        return this.getBinder().hashCode();
    }

    public void send(Message message) throws RemoteException {
        if (this.aiq != null) {
            this.aiq.send(message);
            return;
        }
        this.air.send(message);
    }

    public void writeToParcel(Parcel parcel, int n) {
        if (this.aiq != null) {
            parcel.writeStrongBinder(this.aiq.getBinder());
            return;
        }
        parcel.writeStrongBinder(this.air.asBinder());
    }

    private final class zza
    extends zzb.zza {
        Handler handler;

        zza(Handler handler) {
            this.handler = handler;
        }

        @Override
        public void send(Message message) throws RemoteException {
            message.arg2 = Binder.getCallingUid();
            this.handler.dispatchMessage(message);
        }
    }

}

