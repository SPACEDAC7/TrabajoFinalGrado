/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.iid;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;

public class zza {
    public static KeyPair zzboh() {
        try {
            Object object = KeyPairGenerator.getInstance("RSA");
            object.initialize(2048);
            object = object.generateKeyPair();
            return object;
        }
        catch (NoSuchAlgorithmException var0_1) {
            throw new AssertionError(var0_1);
        }
    }
}

