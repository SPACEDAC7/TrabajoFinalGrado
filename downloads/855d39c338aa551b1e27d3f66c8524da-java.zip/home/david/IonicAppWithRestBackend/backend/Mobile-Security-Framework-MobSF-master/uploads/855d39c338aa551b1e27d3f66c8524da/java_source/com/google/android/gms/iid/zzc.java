/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.ConditionVariable
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  android.os.Messenger
 *  android.os.Parcelable
 *  android.os.Process
 *  android.os.RemoteException
 *  android.os.SystemClock
 *  android.text.TextUtils
 *  android.util.Log
 */
package com.google.android.gms.iid;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcelable;
import android.os.Process;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.iid.InstanceID;
import com.google.android.gms.iid.InstanceIDListenerService;
import com.google.android.gms.iid.MessengerCompat;
import com.google.android.gms.iid.zzd;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.RSAPrivateKey;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class zzc {
    static String ait = null;
    static int aiu = 0;
    static int aiv = 0;
    static int aiw = 0;
    PendingIntent ahc;
    Messenger ahg;
    long aiA;
    long aiB;
    int aiC;
    int aiD;
    long aiE;
    Map<String, Object> aix = new HashMap<String, Object>();
    Messenger aiy;
    MessengerCompat aiz;
    Context zzahs;

    public zzc(Context context) {
        this.zzahs = context;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static /* varargs */ String zza(KeyPair object, String ... arrstring) {
        try {
            arrstring = TextUtils.join((CharSequence)"\n", (Object[])arrstring).getBytes("UTF-8");
        }
        catch (UnsupportedEncodingException var0_1) {
            Log.e((String)"InstanceID/Rpc", (String)"Unable to encode string", (Throwable)var0_1);
            return null;
        }
        try {
            PrivateKey privateKey = object.getPrivate();
            object = privateKey instanceof RSAPrivateKey ? "SHA256withRSA" : "SHA256withECDSA";
            object = Signature.getInstance((String)object);
            object.initSign(privateKey);
            object.update((byte[])arrstring);
            return InstanceID.zzv(object.sign());
        }
        catch (GeneralSecurityException var0_2) {
            Log.e((String)"InstanceID/Rpc", (String)"Unable to sign registration request", (Throwable)var0_2);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void zzai(Object object) {
        Class class_ = this.getClass();
        synchronized (class_) {
            Iterator<String> iterator = this.aix.keySet().iterator();
            while (iterator.hasNext()) {
                String string2 = iterator.next();
                Object object2 = this.aix.get(string2);
                this.aix.put(string2, object);
                this.zzh(object2, object);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Intent zzb(Bundle object, KeyPair object2) throws IOException {
        ConditionVariable conditionVariable = new ConditionVariable();
        String string2 = zzc.zzboo();
        Class class_ = this.getClass();
        synchronized (class_) {
            this.aix.put(string2, (Object)conditionVariable);
        }
        this.zza((Bundle)object, (KeyPair)object2, string2);
        conditionVariable.block(30000);
        object = this.getClass();
        synchronized (object) {
            object2 = this.aix.remove(string2);
            if (object2 instanceof Intent) {
                return (Intent)object2;
            }
            if (object2 instanceof String) {
                throw new IOException((String)object2);
            }
            object2 = String.valueOf(object2);
            Log.w((String)"InstanceID/Rpc", (String)new StringBuilder(String.valueOf(object2).length() + 12).append("No response ").append((String)object2).toString());
            throw new IOException("TIMEOUT");
        }
    }

    public static String zzboo() {
        synchronized (zzc.class) {
            int n = aiw;
            aiw = n + 1;
            String string2 = Integer.toString(n);
            return string2;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String zzdg(Context object) {
        if (ait != null) {
            return ait;
        }
        aiu = Process.myUid();
        object = object.getPackageManager();
        Object object2 = object.queryIntentServices(new Intent("com.google.android.c2dm.intent.REGISTER"), 0).iterator();
        do {
            if (object2.hasNext()) {
                Object object3;
                Object object4 = (ResolveInfo)object2.next();
                if (object.checkPermission("com.google.android.c2dm.permission.RECEIVE", object4.serviceInfo.packageName) == 0) {
                    object3 = object.getApplicationInfo(object4.serviceInfo.packageName, 0);
                    int n = object3.uid;
                    Log.w((String)"InstanceID/Rpc", (String)new StringBuilder(17).append("Found ").append(n).toString());
                    aiv = object3.uid;
                    ait = object4.serviceInfo.packageName;
                    return ait;
                }
                object4 = String.valueOf(object4.serviceInfo.packageName);
                object3 = String.valueOf("com.google.android.c2dm.intent.REGISTER");
                Log.w((String)"InstanceID/Rpc", (String)new StringBuilder(String.valueOf(object4).length() + 56 + String.valueOf(object3).length()).append("Possible malicious package ").append((String)object4).append(" declares ").append((String)object3).append(" without permission").toString());
                continue;
            }
            Log.w((String)"InstanceID/Rpc", (String)"Failed to resolve REGISTER intent, falling back");
            try {
                object2 = object.getApplicationInfo("com.google.android.gms", 0);
                ait = object2.packageName;
                aiv = object2.uid;
                return ait;
            }
            catch (PackageManager.NameNotFoundException var2_3) {
                try {
                    object = object.getApplicationInfo("com.google.android.gsf", 0);
                    ait = object.packageName;
                    aiv = object.uid;
                    return ait;
                }
                catch (PackageManager.NameNotFoundException var0_1) {
                    Log.w((String)"InstanceID/Rpc", (String)"Both Google Play Services and legacy GSF package are missing");
                    return null;
                }
            }
            catch (PackageManager.NameNotFoundException nameNotFoundException) {
                continue;
            }
            break;
        } while (true);
    }

    private static int zzdh(Context context) {
        PackageManager packageManager = context.getPackageManager();
        try {
            int n = packageManager.getPackageInfo((String)zzc.zzdg((Context)context), (int)0).versionCode;
            return n;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            return -1;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void zzh(Object object, Object object2) {
        if (object instanceof ConditionVariable) {
            ((ConditionVariable)object).open();
        }
        if (!(object instanceof Messenger)) return;
        object = (Messenger)object;
        Message message = Message.obtain();
        message.obj = object2;
        try {
            object.send(message);
            return;
        }
        catch (RemoteException var1_2) {
            String string2 = String.valueOf((Object)var1_2);
            Log.w((String)"InstanceID/Rpc", (String)new StringBuilder(String.valueOf(string2).length() + 24).append("Failed to send response ").append(string2).toString());
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void zzi(String string2, Object object) {
        Class class_ = this.getClass();
        synchronized (class_) {
            Object object2 = this.aix.get(string2);
            this.aix.put(string2, object);
            this.zzh(object2, object);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void zzkp(String string2) {
        if (!"com.google.android.gsf".equals(ait)) {
            return;
        }
        ++this.aiC;
        if (this.aiC < 3) return;
        if (this.aiC == 3) {
            this.aiD = new Random().nextInt(1000) + 1000;
        }
        this.aiD *= 2;
        this.aiE = SystemClock.elapsedRealtime() + (long)this.aiD;
        int n = this.aiD;
        Log.w((String)"InstanceID/Rpc", (String)new StringBuilder(String.valueOf(string2).length() + 31).append("Backoff due to ").append(string2).append(" for ").append(n).toString());
    }

    Intent zza(Bundle bundle, KeyPair keyPair) throws IOException {
        Intent intent;
        Intent intent2 = intent = this.zzb(bundle, keyPair);
        if (intent != null) {
            intent2 = intent;
            if (intent.hasExtra("google.messenger")) {
                intent2 = this.zzb(bundle, keyPair);
            }
        }
        return intent2;
    }

    void zza(Bundle bundle, KeyPair keyPair, String string2) throws IOException {
        long l = SystemClock.elapsedRealtime();
        if (this.aiE != 0 && l <= this.aiE) {
            long l2 = this.aiE;
            int n = this.aiD;
            Log.w((String)"InstanceID/Rpc", (String)new StringBuilder(78).append("Backoff mode, next request attempt: ").append(l2 - l).append(" interval: ").append(n).toString());
            throw new IOException("RETRY_LATER");
        }
        this.zzbon();
        if (ait == null) {
            throw new IOException("MISSING_INSTANCEID_SERVICE");
        }
        this.aiA = SystemClock.elapsedRealtime();
        Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
        intent.setPackage(ait);
        bundle.putString("gmsv", Integer.toString(zzc.zzdh(this.zzahs)));
        bundle.putString("osv", Integer.toString(Build.VERSION.SDK_INT));
        bundle.putString("app_ver", Integer.toString(InstanceID.zzdd(this.zzahs)));
        bundle.putString("app_ver_name", InstanceID.zzde(this.zzahs));
        bundle.putString("cliv", "iid-9877000");
        bundle.putString("appid", InstanceID.zza(keyPair));
        String string3 = InstanceID.zzv(keyPair.getPublic().getEncoded());
        bundle.putString("pub2", string3);
        bundle.putString("sig", zzc.zza(keyPair, this.zzahs.getPackageName(), string3));
        intent.putExtras(bundle);
        this.zzs(intent);
        this.zzb(intent, string2);
    }

    protected void zzb(Intent intent, String string2) {
        block10 : {
            boolean bl;
            block9 : {
                this.aiA = SystemClock.elapsedRealtime();
                intent.putExtra("kid", new StringBuilder(String.valueOf(string2).length() + 5).append("|ID|").append(string2).append("|").toString());
                intent.putExtra("X-kid", new StringBuilder(String.valueOf(string2).length() + 5).append("|ID|").append(string2).append("|").toString());
                bl = "com.google.android.gsf".equals(ait);
                string2 = intent.getStringExtra("useGsf");
                if (string2 != null) {
                    bl = "1".equals(string2);
                }
                if (Log.isLoggable((String)"InstanceID/Rpc", (int)3)) {
                    string2 = String.valueOf((Object)intent.getExtras());
                    Log.d((String)"InstanceID/Rpc", (String)new StringBuilder(String.valueOf(string2).length() + 8).append("Sending ").append(string2).toString());
                }
                if (this.aiy != null) {
                    intent.putExtra("google.messenger", (Parcelable)this.ahg);
                    string2 = Message.obtain();
                    string2.obj = intent;
                    try {
                        this.aiy.send((Message)string2);
                        return;
                    }
                    catch (RemoteException var2_3) {
                        if (!Log.isLoggable((String)"InstanceID/Rpc", (int)3)) break block9;
                        Log.d((String)"InstanceID/Rpc", (String)"Messenger failed, fallback to startService");
                    }
                }
            }
            if (bl) {
                string2 = new Intent("com.google.android.gms.iid.InstanceID");
                string2.setPackage(this.zzahs.getPackageName());
                string2.putExtra("GSF", (Parcelable)intent);
                this.zzahs.startService((Intent)string2);
                return;
            }
            intent.putExtra("google.messenger", (Parcelable)this.ahg);
            intent.putExtra("messenger2", "1");
            if (this.aiz != null) {
                string2 = Message.obtain();
                string2.obj = intent;
                try {
                    this.aiz.send((Message)string2);
                    return;
                }
                catch (RemoteException var2_4) {
                    if (!Log.isLoggable((String)"InstanceID/Rpc", (int)3)) break block10;
                    Log.d((String)"InstanceID/Rpc", (String)"Messenger failed, fallback to startService");
                }
            }
        }
        this.zzahs.startService(intent);
    }

    void zzbon() {
        if (this.ahg != null) {
            return;
        }
        zzc.zzdg(this.zzahs);
        this.ahg = new Messenger(new Handler(Looper.getMainLooper()){

            public void handleMessage(Message message) {
                zzc.this.zze(message);
            }
        });
    }

    public void zze(Message message) {
        if (message == null) {
            return;
        }
        if (message.obj instanceof Intent) {
            Intent intent = (Intent)message.obj;
            intent.setExtrasClassLoader(MessengerCompat.class.getClassLoader());
            if (intent.hasExtra("google.messenger")) {
                if ((intent = intent.getParcelableExtra("google.messenger")) instanceof MessengerCompat) {
                    this.aiz = (MessengerCompat)intent;
                }
                if (intent instanceof Messenger) {
                    this.aiy = (Messenger)intent;
                }
            }
            this.zzv((Intent)message.obj);
            return;
        }
        Log.w((String)"InstanceID/Rpc", (String)"Dropping invalid message");
    }

    void zzs(Intent intent) {
        synchronized (this) {
            if (this.ahc == null) {
                Intent intent2 = new Intent();
                intent2.setPackage("com.google.example.invalidpackage");
                this.ahc = PendingIntent.getBroadcast((Context)this.zzahs, (int)0, (Intent)intent2, (int)0);
            }
            intent.putExtra("app", (Parcelable)this.ahc);
            return;
        }
    }

    String zzt(Intent object) throws IOException {
        String string2;
        if (object == null) {
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
        String string3 = string2 = object.getStringExtra("registration_id");
        if (string2 == null) {
            string3 = object.getStringExtra("unregistered");
        }
        object.getLongExtra("Retry-After", 0);
        if (string3 != null) {
            // empty if block
        }
        if (string3 == null) {
            string3 = object.getStringExtra("error");
            if (string3 != null) {
                throw new IOException(string3);
            }
            object = String.valueOf((Object)object.getExtras());
            Log.w((String)"InstanceID/Rpc", (String)new StringBuilder(String.valueOf(object).length() + 29).append("Unexpected response from GCM ").append((String)object).toString(), (Throwable)new Throwable());
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
        return string3;
    }

    /*
     * Enabled aggressive block sorting
     */
    void zzu(Intent object) {
        String string2 = object.getStringExtra("error");
        if (string2 == null) {
            object = String.valueOf((Object)object.getExtras());
            Log.w((String)"InstanceID/Rpc", (String)new StringBuilder(String.valueOf(object).length() + 49).append("Unexpected response, no error or registration id ").append((String)object).toString());
            return;
        } else {
            long l;
            Object object2;
            if (Log.isLoggable((String)"InstanceID/Rpc", (int)3)) {
                object2 = String.valueOf(string2);
                object2 = object2.length() != 0 ? "Received InstanceID error ".concat((String)object2) : new String("Received InstanceID error ");
                Log.d((String)"InstanceID/Rpc", (String)object2);
            }
            if (string2.startsWith("|")) {
                String[] arrstring = string2.split("\\|");
                if (!"ID".equals(arrstring[1])) {
                    object2 = String.valueOf(string2);
                    object2 = object2.length() != 0 ? "Unexpected structured response ".concat((String)object2) : new String("Unexpected structured response ");
                    Log.w((String)"InstanceID/Rpc", (String)object2);
                }
                if (arrstring.length > 2) {
                    String string3 = arrstring[2];
                    arrstring = arrstring[3];
                    string2 = string3;
                    object2 = arrstring;
                    if (arrstring.startsWith(":")) {
                        object2 = arrstring.substring(1);
                        string2 = string3;
                    }
                } else {
                    object2 = "UNKNOWN";
                    string2 = null;
                }
                object.putExtra("error", (String)object2);
            } else {
                Object var7_6 = null;
                object2 = string2;
                string2 = var7_6;
            }
            if (string2 == null) {
                this.zzai(object2);
            } else {
                this.zzi(string2, object2);
            }
            if ((l = object.getLongExtra("Retry-After", 0)) > 0) {
                this.aiB = SystemClock.elapsedRealtime();
                this.aiD = (int)l * 1000;
                this.aiE = SystemClock.elapsedRealtime() + (long)this.aiD;
                int n = this.aiD;
                Log.w((String)"InstanceID/Rpc", (String)new StringBuilder(52).append("Explicit request from server to backoff: ").append(n).toString());
                return;
            }
            if (!"SERVICE_NOT_AVAILABLE".equals(object2) && !"AUTHENTICATION_FAILED".equals(object2)) return;
            {
                this.zzkp((String)object2);
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void zzv(Intent object) {
        if (object == null) {
            if (!Log.isLoggable((String)"InstanceID/Rpc", (int)3)) return;
            Log.d((String)"InstanceID/Rpc", (String)"Unexpected response: null");
            return;
        }
        Object object2 = object.getAction();
        if (!"com.google.android.c2dm.intent.REGISTRATION".equals(object2) && !"com.google.android.gms.iid.InstanceID".equals(object2)) {
            if (!Log.isLoggable((String)"InstanceID/Rpc", (int)3)) return;
            object = (object = String.valueOf(object.getAction())).length() != 0 ? "Unexpected response ".concat((String)object) : new String("Unexpected response ");
            Log.d((String)"InstanceID/Rpc", (String)object);
            return;
        }
        object2 = object.getStringExtra("registration_id");
        if (object2 == null) {
            object2 = object.getStringExtra("unregistered");
        }
        if (object2 == null) {
            this.zzu((Intent)object);
            return;
        }
        this.aiA = SystemClock.elapsedRealtime();
        this.aiE = 0;
        this.aiC = 0;
        this.aiD = 0;
        String string2 = null;
        if (object2.startsWith("|")) {
            String[] arrstring = object2.split("\\|");
            if (!"ID".equals(arrstring[1])) {
                object2 = (object2 = String.valueOf(object2)).length() != 0 ? "Unexpected structured response ".concat((String)object2) : new String("Unexpected structured response ");
                Log.w((String)"InstanceID/Rpc", (String)object2);
            }
            string2 = arrstring[2];
            if (arrstring.length > 4) {
                if ("SYNC".equals(arrstring[3])) {
                    InstanceIDListenerService.zzdf(this.zzahs);
                } else if ("RST".equals(arrstring[3])) {
                    InstanceIDListenerService.zza(this.zzahs, InstanceID.getInstance(this.zzahs).zzbok());
                    object.removeExtra("registration_id");
                    this.zzi(string2, object);
                    return;
                }
            }
            object2 = arrstring = arrstring[arrstring.length - 1];
            if (arrstring.startsWith(":")) {
                object2 = arrstring.substring(1);
            }
            object.putExtra("registration_id", (String)object2);
            if (string2 != null) {
                this.zzi(string2, object);
                return;
            }
        }
        this.zzai(object);
    }

}

