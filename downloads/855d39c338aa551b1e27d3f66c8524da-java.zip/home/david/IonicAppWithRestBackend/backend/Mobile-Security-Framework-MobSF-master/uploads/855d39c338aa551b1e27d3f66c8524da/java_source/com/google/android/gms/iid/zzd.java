/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.util.Base64
 *  android.util.Log
 */
package com.google.android.gms.iid;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.common.util.zzw;
import com.google.android.gms.iid.InstanceID;
import com.google.android.gms.iid.InstanceIDListenerService;
import com.google.android.gms.iid.zza;
import java.io.File;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class zzd {
    SharedPreferences aiG;
    Context zzahs;

    public zzd(Context context) {
        this(context, "com.google.android.gms.appid");
    }

    /*
     * Enabled aggressive block sorting
     */
    public zzd(Context object, String string2) {
        this.zzahs = object;
        this.aiG = object.getSharedPreferences(string2, 4);
        object = String.valueOf(string2);
        string2 = String.valueOf("-no-backup");
        object = string2.length() != 0 ? object.concat(string2) : new String((String)object);
        this.zzkq((String)object);
    }

    private String zzg(String string2, String string3, String string4) {
        String string5 = String.valueOf("|T|");
        return new StringBuilder(String.valueOf(string2).length() + 1 + String.valueOf(string5).length() + String.valueOf(string3).length() + String.valueOf(string4).length()).append(string2).append(string5).append(string3).append("|").append(string4).toString();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void zzkq(String object) {
        object = new File(zzw.getNoBackupFilesDir(this.zzahs), (String)object);
        if (object.exists()) return;
        try {
            if (!object.createNewFile() || this.isEmpty()) return;
            {
                Log.i((String)"InstanceID/Store", (String)"App restored, clearing state");
                InstanceIDListenerService.zza(this.zzahs, this);
                return;
            }
        }
        catch (IOException var1_2) {
            if (!Log.isLoggable((String)"InstanceID/Store", (int)3)) {
                return;
            }
            String string2 = String.valueOf(var1_2.getMessage());
            string2 = string2.length() != 0 ? "Error creating file in no backup dir: ".concat(string2) : new String("Error creating file in no backup dir: ");
            Log.d((String)"InstanceID/Store", (String)string2);
            return;
        }
    }

    String get(String string2) {
        synchronized (this) {
            string2 = this.aiG.getString(string2, null);
            return string2;
        }
    }

    String get(String string2, String string3) {
        synchronized (this) {
            SharedPreferences sharedPreferences = this.aiG;
            String string4 = String.valueOf("|S|");
            string2 = sharedPreferences.getString(new StringBuilder(String.valueOf(string2).length() + 0 + String.valueOf(string4).length() + String.valueOf(string3).length()).append(string2).append(string4).append(string3).toString(), null);
            return string2;
        }
    }

    public boolean isEmpty() {
        return this.aiG.getAll().isEmpty();
    }

    void zza(SharedPreferences.Editor editor, String string2, String string3, String string4) {
        synchronized (this) {
            String string5 = String.valueOf("|S|");
            editor.putString(new StringBuilder(String.valueOf(string2).length() + 0 + String.valueOf(string5).length() + String.valueOf(string3).length()).append(string2).append(string5).append(string3).toString(), string4);
            return;
        }
    }

    public void zza(String string2, String string3, String string4, String string5, String string6) {
        synchronized (this) {
            string2 = this.zzg(string2, string3, string4);
            string3 = this.aiG.edit();
            string3.putString(string2, string5);
            string3.putString("appVersion", string6);
            string3.putString("lastToken", Long.toString(System.currentTimeMillis() / 1000));
            string3.commit();
            return;
        }
    }

    public void zzbop() {
        synchronized (this) {
            this.aiG.edit().clear().commit();
            return;
        }
    }

    KeyPair zze(String string2, long l) {
        synchronized (this) {
            KeyPair keyPair = zza.zzboh();
            SharedPreferences.Editor editor = this.aiG.edit();
            this.zza(editor, string2, "|P|", InstanceID.zzv(keyPair.getPublic().getEncoded()));
            this.zza(editor, string2, "|K|", InstanceID.zzv(keyPair.getPrivate().getEncoded()));
            this.zza(editor, string2, "cre", Long.toString(l));
            editor.commit();
            return keyPair;
        }
    }

    public String zzh(String string2, String string3, String string4) {
        synchronized (this) {
            string2 = this.zzg(string2, string3, string4);
            string2 = this.aiG.getString(string2, null);
            return string2;
        }
    }

    public void zzi(String string2, String string3, String string4) {
        synchronized (this) {
            string2 = this.zzg(string2, string3, string4);
            string3 = this.aiG.edit();
            string3.remove(string2);
            string3.commit();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zzkr(String string2) {
        synchronized (this) {
            SharedPreferences.Editor editor = this.aiG.edit();
            Iterator iterator = this.aiG.getAll().keySet().iterator();
            do {
                if (!iterator.hasNext()) {
                    editor.commit();
                    return;
                }
                String string3 = (String)iterator.next();
                if (!string3.startsWith(string2)) continue;
                editor.remove(string3);
            } while (true);
        }
    }

    public KeyPair zzks(String string2) {
        return this.zzkv(string2);
    }

    void zzkt(String string2) {
        this.zzkr(String.valueOf(string2).concat("|"));
    }

    public void zzku(String string2) {
        this.zzkr(String.valueOf(string2).concat("|T|"));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    KeyPair zzkv(String var1_1) {
        var2_5 = this.get((String)var1_1, "|P|");
        var3_6 = this.get((String)var1_1, "|K|");
        if (var2_5 == null) return null;
        if (var3_6 == null) {
            return null;
        }
        try {
            var1_1 = Base64.decode((String)var2_5, (int)8);
            var2_5 = Base64.decode((String)var3_6, (int)8);
            var3_6 = KeyFactory.getInstance("RSA");
            return new KeyPair(var3_6.generatePublic(new X509EncodedKeySpec((byte[])var1_1)), var3_6.generatePrivate(new PKCS8EncodedKeySpec(var2_5)));
        }
        catch (InvalidKeySpecException var1_2) {}
        ** GOTO lbl-1000
        catch (NoSuchAlgorithmException var1_4) {}
lbl-1000: // 2 sources:
        {
            var1_3 = String.valueOf(var1_3);
            Log.w((String)"InstanceID/Store", (String)new StringBuilder(String.valueOf(var1_3).length() + 19).append("Invalid key stored ").append(var1_3).toString());
            InstanceIDListenerService.zza(this.zzahs, this);
            return null;
        }
    }
}

