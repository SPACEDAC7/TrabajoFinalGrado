/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.net.http.AndroidHttpClient
 *  android.os.Build
 *  android.os.Build$VERSION
 *  org.apache.http.client.HttpClient
 */
package com.google.android.gms.internal;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.http.AndroidHttpClient;
import android.os.Build;
import com.google.android.gms.internal.zzb;
import com.google.android.gms.internal.zzf;
import com.google.android.gms.internal.zzl;
import com.google.android.gms.internal.zzt;
import com.google.android.gms.internal.zzv;
import com.google.android.gms.internal.zzw;
import com.google.android.gms.internal.zzy;
import com.google.android.gms.internal.zzz;
import java.io.File;
import org.apache.http.client.HttpClient;

public class zzac {
    public static zzl zza(Context context) {
        return zzac.zza(context, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static zzl zza(Context object, zzy zzy2) {
        File file;
        Object object2;
        file = new File(object.getCacheDir(), "volley");
        object2 = "volley/0";
        try {
            String string2 = object.getPackageName();
            int n = object.getPackageManager().getPackageInfo((String)string2, (int)0).versionCode;
            object2 = object = new StringBuilder(String.valueOf(string2).length() + 12).append(string2).append("/").append(n).toString();
        }
        catch (PackageManager.NameNotFoundException var0_1) {}
        object = zzy2;
        if (zzy2 == null) {
            object = Build.VERSION.SDK_INT >= 9 ? new zzz() : new zzw((HttpClient)AndroidHttpClient.newInstance((String)object2));
        }
        object = new zzt((zzy)object);
        object = new zzl(new zzv(file), (zzf)object);
        object.start();
        return object;
    }
}

