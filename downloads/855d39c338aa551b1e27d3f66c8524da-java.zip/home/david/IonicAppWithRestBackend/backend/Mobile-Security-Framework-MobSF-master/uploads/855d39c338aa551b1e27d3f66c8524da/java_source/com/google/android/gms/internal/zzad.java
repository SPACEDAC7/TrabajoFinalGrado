/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import com.google.android.gms.internal.zzars;
import com.google.android.gms.internal.zzart;
import com.google.android.gms.internal.zzarz;
import com.google.android.gms.internal.zzasa;
import com.google.android.gms.internal.zzasd;
import java.io.IOException;

public interface zzad {

    public static final class zza
    extends zzasa {
        public zzb zzck;
        public zzc zzcl;

        public zza() {
            this.zzw();
        }

        public static zza zzc(byte[] arrby) throws zzarz {
            return zzasa.zza(new zza(), arrby);
        }

        public zza zza(zzars zzars2) throws IOException {
            block5 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (zzasd.zzb(zzars2, n)) continue block5;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        if (this.zzck == null) {
                            this.zzck = new zzb();
                        }
                        zzars2.zza(this.zzck);
                        continue block5;
                    }
                    case 18: 
                }
                if (this.zzcl == null) {
                    this.zzcl = new zzc();
                }
                zzars2.zza(this.zzcl);
            } while (true);
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzck != null) {
                zzart2.zza(1, this.zzck);
            }
            if (this.zzcl != null) {
                zzart2.zza(2, this.zzcl);
            }
            super.zza(zzart2);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zza(zzars2);
        }

        public zza zzw() {
            this.zzck = null;
            this.zzcl = null;
            this.btP = -1;
            return this;
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.zzck != null) {
                n2 = n + zzart.zzc(1, this.zzck);
            }
            n = n2;
            if (this.zzcl != null) {
                n = n2 + zzart.zzc(2, this.zzcl);
            }
            return n;
        }
    }

    public static final class zzb
    extends zzasa {
        public Integer zzcm;

        public zzb() {
            this.zzy();
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzcm != null) {
                zzart2.zzaf(27, this.zzcm);
            }
            super.zza(zzart2);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzc(zzars2);
        }

        public zzb zzc(zzars zzars2) throws IOException {
            block7 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (zzasd.zzb(zzars2, n)) continue block7;
                    }
                    case 0: {
                        return this;
                    }
                    case 216: 
                }
                n = zzars2.bY();
                switch (n) {
                    default: {
                        continue block7;
                    }
                    case 0: 
                    case 1: 
                    case 2: 
                    case 3: 
                    case 4: 
                }
                this.zzcm = n;
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.zzcm != null) {
                n2 = n + zzart.zzah(27, this.zzcm);
            }
            return n2;
        }

        public zzb zzy() {
            this.btP = -1;
            return this;
        }
    }

    public static final class zzc
    extends zzasa {
        public String zzcn;
        public String zzco;
        public String zzcp;
        public String zzcq;
        public String zzcr;

        public zzc() {
            this.zzz();
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzcn != null) {
                zzart2.zzq(1, this.zzcn);
            }
            if (this.zzco != null) {
                zzart2.zzq(2, this.zzco);
            }
            if (this.zzcp != null) {
                zzart2.zzq(3, this.zzcp);
            }
            if (this.zzcq != null) {
                zzart2.zzq(4, this.zzcq);
            }
            if (this.zzcr != null) {
                zzart2.zzq(5, this.zzcr);
            }
            super.zza(zzart2);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzd(zzars2);
        }

        public zzc zzd(zzars zzars2) throws IOException {
            block8 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (zzasd.zzb(zzars2, n)) continue block8;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        this.zzcn = zzars2.readString();
                        continue block8;
                    }
                    case 18: {
                        this.zzco = zzars2.readString();
                        continue block8;
                    }
                    case 26: {
                        this.zzcp = zzars2.readString();
                        continue block8;
                    }
                    case 34: {
                        this.zzcq = zzars2.readString();
                        continue block8;
                    }
                    case 42: 
                }
                this.zzcr = zzars2.readString();
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.zzcn != null) {
                n2 = n + zzart.zzr(1, this.zzcn);
            }
            n = n2;
            if (this.zzco != null) {
                n = n2 + zzart.zzr(2, this.zzco);
            }
            n2 = n;
            if (this.zzcp != null) {
                n2 = n + zzart.zzr(3, this.zzcp);
            }
            n = n2;
            if (this.zzcq != null) {
                n = n2 + zzart.zzr(4, this.zzcq);
            }
            n2 = n;
            if (this.zzcr != null) {
                n2 = n + zzart.zzr(5, this.zzcr);
            }
            return n2;
        }

        public zzc zzz() {
            this.zzcn = null;
            this.zzco = null;
            this.zzcp = null;
            this.zzcq = null;
            this.zzcr = null;
            this.btP = -1;
            return this;
        }
    }

}

