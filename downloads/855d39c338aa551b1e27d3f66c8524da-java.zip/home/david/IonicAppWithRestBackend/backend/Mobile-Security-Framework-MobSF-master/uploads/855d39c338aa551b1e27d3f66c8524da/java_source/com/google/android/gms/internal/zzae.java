/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import com.google.android.gms.internal.zzars;
import com.google.android.gms.internal.zzart;
import com.google.android.gms.internal.zzaru;
import com.google.android.gms.internal.zzasa;
import java.io.IOException;

public interface zzae {

    public static final class zza
    extends zzaru<zza> {
        public String stackTrace = null;
        public String zzcs = null;
        public Long zzct = null;
        public String zzcu = null;
        public String zzcv = null;
        public Long zzcw = null;
        public Long zzcx = null;
        public String zzcy = null;
        public Long zzcz = null;
        public String zzda = null;

        public zza() {
            this.btP = -1;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzcs != null) {
                zzart2.zzq(1, this.zzcs);
            }
            if (this.zzct != null) {
                zzart2.zzb(2, this.zzct);
            }
            if (this.stackTrace != null) {
                zzart2.zzq(3, this.stackTrace);
            }
            if (this.zzcu != null) {
                zzart2.zzq(4, this.zzcu);
            }
            if (this.zzcv != null) {
                zzart2.zzq(5, this.zzcv);
            }
            if (this.zzcw != null) {
                zzart2.zzb(6, this.zzcw);
            }
            if (this.zzcx != null) {
                zzart2.zzb(7, this.zzcx);
            }
            if (this.zzcy != null) {
                zzart2.zzq(8, this.zzcy);
            }
            if (this.zzcz != null) {
                zzart2.zzb(9, this.zzcz);
            }
            if (this.zzda != null) {
                zzart2.zzq(10, this.zzda);
            }
            super.zza(zzart2);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zze(zzars2);
        }

        public zza zze(zzars zzars2) throws IOException {
            block13 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block13;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        this.zzcs = zzars2.readString();
                        continue block13;
                    }
                    case 16: {
                        this.zzct = zzars2.bX();
                        continue block13;
                    }
                    case 26: {
                        this.stackTrace = zzars2.readString();
                        continue block13;
                    }
                    case 34: {
                        this.zzcu = zzars2.readString();
                        continue block13;
                    }
                    case 42: {
                        this.zzcv = zzars2.readString();
                        continue block13;
                    }
                    case 48: {
                        this.zzcw = zzars2.bX();
                        continue block13;
                    }
                    case 56: {
                        this.zzcx = zzars2.bX();
                        continue block13;
                    }
                    case 66: {
                        this.zzcy = zzars2.readString();
                        continue block13;
                    }
                    case 72: {
                        this.zzcz = zzars2.bX();
                        continue block13;
                    }
                    case 82: 
                }
                this.zzda = zzars2.readString();
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.zzcs != null) {
                n2 = n + zzart.zzr(1, this.zzcs);
            }
            n = n2;
            if (this.zzct != null) {
                n = n2 + zzart.zzf(2, this.zzct);
            }
            n2 = n;
            if (this.stackTrace != null) {
                n2 = n + zzart.zzr(3, this.stackTrace);
            }
            n = n2;
            if (this.zzcu != null) {
                n = n2 + zzart.zzr(4, this.zzcu);
            }
            n2 = n;
            if (this.zzcv != null) {
                n2 = n + zzart.zzr(5, this.zzcv);
            }
            n = n2;
            if (this.zzcw != null) {
                n = n2 + zzart.zzf(6, this.zzcw);
            }
            n2 = n;
            if (this.zzcx != null) {
                n2 = n + zzart.zzf(7, this.zzcx);
            }
            n = n2;
            if (this.zzcy != null) {
                n = n2 + zzart.zzr(8, this.zzcy);
            }
            n2 = n;
            if (this.zzcz != null) {
                n2 = n + zzart.zzf(9, this.zzcz);
            }
            n = n2;
            if (this.zzda != null) {
                n = n2 + zzart.zzr(10, this.zzda);
            }
            return n;
        }
    }

}

