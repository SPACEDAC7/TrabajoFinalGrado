/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import com.google.android.gms.internal.zzars;
import com.google.android.gms.internal.zzart;
import com.google.android.gms.internal.zzaru;
import com.google.android.gms.internal.zzary;
import com.google.android.gms.internal.zzarz;
import com.google.android.gms.internal.zzasa;
import com.google.android.gms.internal.zzasd;
import java.io.IOException;

public interface zzaf {

    public static final class com.google.android.gms.internal.zzaf$zza
    extends zzaru<com.google.android.gms.internal.zzaf$zza> {
        public String zzcn = null;
        public String zzcp = null;
        public String zzcq = null;
        public String zzcr = null;
        public String zzda = null;
        public String zzdb = null;
        public Long zzdc = null;
        public Long zzdd = null;
        public Long zzde = null;
        public Long zzdf = null;
        public Long zzdg = null;
        public Long zzdh = null;
        public Long zzdi = null;
        public Long zzdj = null;
        public Long zzdk = null;
        public Long zzdl = null;
        public String zzdm = null;
        public Long zzdn = null;
        public Long zzdo = null;
        public Long zzdp = null;
        public Long zzdq = null;
        public Long zzdr = null;
        public Long zzds = null;
        public Long zzdt = null;
        public Long zzdu = null;
        public Long zzdv = null;
        public String zzdw = null;
        public Long zzdx = null;
        public Long zzdy = null;
        public Long zzdz = null;
        public Long zzea = null;
        public Long zzeb = null;
        public Long zzec = null;
        public com.google.android.gms.internal.zzaf$zzb zzed;
        public Long zzee = null;
        public Long zzef = null;
        public Long zzeg = null;
        public Long zzeh = null;
        public Long zzei = null;
        public Long zzej = null;
        public Integer zzek = null;
        public Integer zzel = null;
        public Long zzem = null;
        public Long zzen = null;
        public Long zzeo = null;
        public Long zzep = null;
        public Long zzeq = null;
        public Integer zzer = null;
        public zza zzes;
        public zza[] zzet = zza.zzaa();
        public zzb zzeu;
        public Long zzev = null;
        public String zzew = null;
        public Integer zzex = null;
        public Boolean zzey = null;
        public String zzez = null;
        public Long zzfa = null;
        public zze zzfb;

        public com.google.android.gms.internal.zzaf$zza() {
            this.btP = -1;
        }

        public static com.google.android.gms.internal.zzaf$zza zzd(byte[] arrby) throws zzarz {
            return zzasa.zza(new com.google.android.gms.internal.zzaf$zza(), arrby);
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzdb != null) {
                zzart2.zzq(1, this.zzdb);
            }
            if (this.zzda != null) {
                zzart2.zzq(2, this.zzda);
            }
            if (this.zzdc != null) {
                zzart2.zzb(3, this.zzdc);
            }
            if (this.zzdd != null) {
                zzart2.zzb(4, this.zzdd);
            }
            if (this.zzde != null) {
                zzart2.zzb(5, this.zzde);
            }
            if (this.zzdf != null) {
                zzart2.zzb(6, this.zzdf);
            }
            if (this.zzdg != null) {
                zzart2.zzb(7, this.zzdg);
            }
            if (this.zzdh != null) {
                zzart2.zzb(8, this.zzdh);
            }
            if (this.zzdi != null) {
                zzart2.zzb(9, this.zzdi);
            }
            if (this.zzdj != null) {
                zzart2.zzb(10, this.zzdj);
            }
            if (this.zzdk != null) {
                zzart2.zzb(11, this.zzdk);
            }
            if (this.zzdl != null) {
                zzart2.zzb(12, this.zzdl);
            }
            if (this.zzdm != null) {
                zzart2.zzq(13, this.zzdm);
            }
            if (this.zzdn != null) {
                zzart2.zzb(14, this.zzdn);
            }
            if (this.zzdo != null) {
                zzart2.zzb(15, this.zzdo);
            }
            if (this.zzdp != null) {
                zzart2.zzb(16, this.zzdp);
            }
            if (this.zzdq != null) {
                zzart2.zzb(17, this.zzdq);
            }
            if (this.zzdr != null) {
                zzart2.zzb(18, this.zzdr);
            }
            if (this.zzds != null) {
                zzart2.zzb(19, this.zzds);
            }
            if (this.zzdt != null) {
                zzart2.zzb(20, this.zzdt);
            }
            if (this.zzev != null) {
                zzart2.zzb(21, this.zzev);
            }
            if (this.zzdu != null) {
                zzart2.zzb(22, this.zzdu);
            }
            if (this.zzdv != null) {
                zzart2.zzb(23, this.zzdv);
            }
            if (this.zzew != null) {
                zzart2.zzq(24, this.zzew);
            }
            if (this.zzfa != null) {
                zzart2.zzb(25, this.zzfa);
            }
            if (this.zzex != null) {
                zzart2.zzaf(26, this.zzex);
            }
            if (this.zzcn != null) {
                zzart2.zzq(27, this.zzcn);
            }
            if (this.zzey != null) {
                zzart2.zzg(28, this.zzey);
            }
            if (this.zzdw != null) {
                zzart2.zzq(29, this.zzdw);
            }
            if (this.zzez != null) {
                zzart2.zzq(30, this.zzez);
            }
            if (this.zzdx != null) {
                zzart2.zzb(31, this.zzdx);
            }
            if (this.zzdy != null) {
                zzart2.zzb(32, this.zzdy);
            }
            if (this.zzdz != null) {
                zzart2.zzb(33, this.zzdz);
            }
            if (this.zzcp != null) {
                zzart2.zzq(34, this.zzcp);
            }
            if (this.zzea != null) {
                zzart2.zzb(35, this.zzea);
            }
            if (this.zzeb != null) {
                zzart2.zzb(36, this.zzeb);
            }
            if (this.zzec != null) {
                zzart2.zzb(37, this.zzec);
            }
            if (this.zzed != null) {
                zzart2.zza(38, this.zzed);
            }
            if (this.zzee != null) {
                zzart2.zzb(39, this.zzee);
            }
            if (this.zzef != null) {
                zzart2.zzb(40, this.zzef);
            }
            if (this.zzeg != null) {
                zzart2.zzb(41, this.zzeg);
            }
            if (this.zzeh != null) {
                zzart2.zzb(42, this.zzeh);
            }
            if (this.zzet != null && this.zzet.length > 0) {
                for (int i = 0; i < this.zzet.length; ++i) {
                    zza zza2 = this.zzet[i];
                    if (zza2 == null) continue;
                    zzart2.zza(43, zza2);
                }
            }
            if (this.zzei != null) {
                zzart2.zzb(44, this.zzei);
            }
            if (this.zzej != null) {
                zzart2.zzb(45, this.zzej);
            }
            if (this.zzcq != null) {
                zzart2.zzq(46, this.zzcq);
            }
            if (this.zzcr != null) {
                zzart2.zzq(47, this.zzcr);
            }
            if (this.zzek != null) {
                zzart2.zzaf(48, this.zzek);
            }
            if (this.zzel != null) {
                zzart2.zzaf(49, this.zzel);
            }
            if (this.zzes != null) {
                zzart2.zza(50, this.zzes);
            }
            if (this.zzem != null) {
                zzart2.zzb(51, this.zzem);
            }
            if (this.zzen != null) {
                zzart2.zzb(52, this.zzen);
            }
            if (this.zzeo != null) {
                zzart2.zzb(53, this.zzeo);
            }
            if (this.zzep != null) {
                zzart2.zzb(54, this.zzep);
            }
            if (this.zzeq != null) {
                zzart2.zzb(55, this.zzeq);
            }
            if (this.zzer != null) {
                zzart2.zzaf(56, this.zzer);
            }
            if (this.zzeu != null) {
                zzart2.zza(57, this.zzeu);
            }
            if (this.zzfb != null) {
                zzart2.zza(201, this.zzfb);
            }
            super.zza(zzart2);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzf(zzars2);
        }

        /*
         * Enabled aggressive block sorting
         */
        public com.google.android.gms.internal.zzaf$zza zzf(zzars zzars2) throws IOException {
            block73 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block73;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        this.zzdb = zzars2.readString();
                        continue block73;
                    }
                    case 18: {
                        this.zzda = zzars2.readString();
                        continue block73;
                    }
                    case 24: {
                        this.zzdc = zzars2.bX();
                        continue block73;
                    }
                    case 32: {
                        this.zzdd = zzars2.bX();
                        continue block73;
                    }
                    case 40: {
                        this.zzde = zzars2.bX();
                        continue block73;
                    }
                    case 48: {
                        this.zzdf = zzars2.bX();
                        continue block73;
                    }
                    case 56: {
                        this.zzdg = zzars2.bX();
                        continue block73;
                    }
                    case 64: {
                        this.zzdh = zzars2.bX();
                        continue block73;
                    }
                    case 72: {
                        this.zzdi = zzars2.bX();
                        continue block73;
                    }
                    case 80: {
                        this.zzdj = zzars2.bX();
                        continue block73;
                    }
                    case 88: {
                        this.zzdk = zzars2.bX();
                        continue block73;
                    }
                    case 96: {
                        this.zzdl = zzars2.bX();
                        continue block73;
                    }
                    case 106: {
                        this.zzdm = zzars2.readString();
                        continue block73;
                    }
                    case 112: {
                        this.zzdn = zzars2.bX();
                        continue block73;
                    }
                    case 120: {
                        this.zzdo = zzars2.bX();
                        continue block73;
                    }
                    case 128: {
                        this.zzdp = zzars2.bX();
                        continue block73;
                    }
                    case 136: {
                        this.zzdq = zzars2.bX();
                        continue block73;
                    }
                    case 144: {
                        this.zzdr = zzars2.bX();
                        continue block73;
                    }
                    case 152: {
                        this.zzds = zzars2.bX();
                        continue block73;
                    }
                    case 160: {
                        this.zzdt = zzars2.bX();
                        continue block73;
                    }
                    case 168: {
                        this.zzev = zzars2.bX();
                        continue block73;
                    }
                    case 176: {
                        this.zzdu = zzars2.bX();
                        continue block73;
                    }
                    case 184: {
                        this.zzdv = zzars2.bX();
                        continue block73;
                    }
                    case 194: {
                        this.zzew = zzars2.readString();
                        continue block73;
                    }
                    case 200: {
                        this.zzfa = zzars2.bX();
                        continue block73;
                    }
                    case 208: {
                        n = zzars2.bY();
                        switch (n) {
                            default: {
                                continue block73;
                            }
                            case 0: 
                            case 1: 
                            case 2: 
                            case 3: 
                            case 4: 
                            case 5: 
                            case 6: 
                        }
                        this.zzex = n;
                        continue block73;
                    }
                    case 218: {
                        this.zzcn = zzars2.readString();
                        continue block73;
                    }
                    case 224: {
                        this.zzey = zzars2.ca();
                        continue block73;
                    }
                    case 234: {
                        this.zzdw = zzars2.readString();
                        continue block73;
                    }
                    case 242: {
                        this.zzez = zzars2.readString();
                        continue block73;
                    }
                    case 248: {
                        this.zzdx = zzars2.bX();
                        continue block73;
                    }
                    case 256: {
                        this.zzdy = zzars2.bX();
                        continue block73;
                    }
                    case 264: {
                        this.zzdz = zzars2.bX();
                        continue block73;
                    }
                    case 274: {
                        this.zzcp = zzars2.readString();
                        continue block73;
                    }
                    case 280: {
                        this.zzea = zzars2.bX();
                        continue block73;
                    }
                    case 288: {
                        this.zzeb = zzars2.bX();
                        continue block73;
                    }
                    case 296: {
                        this.zzec = zzars2.bX();
                        continue block73;
                    }
                    case 306: {
                        if (this.zzed == null) {
                            this.zzed = new com.google.android.gms.internal.zzaf$zzb();
                        }
                        zzars2.zza(this.zzed);
                        continue block73;
                    }
                    case 312: {
                        this.zzee = zzars2.bX();
                        continue block73;
                    }
                    case 320: {
                        this.zzef = zzars2.bX();
                        continue block73;
                    }
                    case 328: {
                        this.zzeg = zzars2.bX();
                        continue block73;
                    }
                    case 336: {
                        this.zzeh = zzars2.bX();
                        continue block73;
                    }
                    case 346: {
                        int n2 = zzasd.zzc(zzars2, 346);
                        n = this.zzet == null ? 0 : this.zzet.length;
                        zza[] arrzza = new zza[n2 + n];
                        n2 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzet, 0, arrzza, 0, n);
                            n2 = n;
                        }
                        while (n2 < arrzza.length - 1) {
                            arrzza[n2] = new zza();
                            zzars2.zza(arrzza[n2]);
                            zzars2.bU();
                            ++n2;
                        }
                        arrzza[n2] = new zza();
                        zzars2.zza(arrzza[n2]);
                        this.zzet = arrzza;
                        continue block73;
                    }
                    case 352: {
                        this.zzei = zzars2.bX();
                        continue block73;
                    }
                    case 360: {
                        this.zzej = zzars2.bX();
                        continue block73;
                    }
                    case 370: {
                        this.zzcq = zzars2.readString();
                        continue block73;
                    }
                    case 378: {
                        this.zzcr = zzars2.readString();
                        continue block73;
                    }
                    case 384: {
                        n = zzars2.bY();
                        switch (n) {
                            default: {
                                continue block73;
                            }
                            case 0: 
                            case 1: 
                            case 2: 
                            case 1000: 
                        }
                        this.zzek = n;
                        continue block73;
                    }
                    case 392: {
                        n = zzars2.bY();
                        switch (n) {
                            default: {
                                continue block73;
                            }
                            case 0: 
                            case 1: 
                            case 2: 
                            case 1000: 
                        }
                        this.zzel = n;
                        continue block73;
                    }
                    case 402: {
                        if (this.zzes == null) {
                            this.zzes = new zza();
                        }
                        zzars2.zza(this.zzes);
                        continue block73;
                    }
                    case 408: {
                        this.zzem = zzars2.bX();
                        continue block73;
                    }
                    case 416: {
                        this.zzen = zzars2.bX();
                        continue block73;
                    }
                    case 424: {
                        this.zzeo = zzars2.bX();
                        continue block73;
                    }
                    case 432: {
                        this.zzep = zzars2.bX();
                        continue block73;
                    }
                    case 440: {
                        this.zzeq = zzars2.bX();
                        continue block73;
                    }
                    case 448: {
                        n = zzars2.bY();
                        switch (n) {
                            default: {
                                continue block73;
                            }
                            case 0: 
                            case 1: 
                            case 2: 
                            case 1000: 
                        }
                        this.zzer = n;
                        continue block73;
                    }
                    case 458: {
                        if (this.zzeu == null) {
                            this.zzeu = new zzb();
                        }
                        zzars2.zza(this.zzeu);
                        continue block73;
                    }
                    case 1610: 
                }
                if (this.zzfb == null) {
                    this.zzfb = new zze();
                }
                zzars2.zza(this.zzfb);
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.zzdb != null) {
                n2 = n + zzart.zzr(1, this.zzdb);
            }
            n = n2;
            if (this.zzda != null) {
                n = n2 + zzart.zzr(2, this.zzda);
            }
            n2 = n;
            if (this.zzdc != null) {
                n2 = n + zzart.zzf(3, this.zzdc);
            }
            n = n2;
            if (this.zzdd != null) {
                n = n2 + zzart.zzf(4, this.zzdd);
            }
            n2 = n;
            if (this.zzde != null) {
                n2 = n + zzart.zzf(5, this.zzde);
            }
            n = n2;
            if (this.zzdf != null) {
                n = n2 + zzart.zzf(6, this.zzdf);
            }
            n2 = n;
            if (this.zzdg != null) {
                n2 = n + zzart.zzf(7, this.zzdg);
            }
            n = n2;
            if (this.zzdh != null) {
                n = n2 + zzart.zzf(8, this.zzdh);
            }
            n2 = n;
            if (this.zzdi != null) {
                n2 = n + zzart.zzf(9, this.zzdi);
            }
            n = n2;
            if (this.zzdj != null) {
                n = n2 + zzart.zzf(10, this.zzdj);
            }
            n2 = n;
            if (this.zzdk != null) {
                n2 = n + zzart.zzf(11, this.zzdk);
            }
            n = n2;
            if (this.zzdl != null) {
                n = n2 + zzart.zzf(12, this.zzdl);
            }
            n2 = n;
            if (this.zzdm != null) {
                n2 = n + zzart.zzr(13, this.zzdm);
            }
            n = n2;
            if (this.zzdn != null) {
                n = n2 + zzart.zzf(14, this.zzdn);
            }
            n2 = n;
            if (this.zzdo != null) {
                n2 = n + zzart.zzf(15, this.zzdo);
            }
            n = n2;
            if (this.zzdp != null) {
                n = n2 + zzart.zzf(16, this.zzdp);
            }
            n2 = n;
            if (this.zzdq != null) {
                n2 = n + zzart.zzf(17, this.zzdq);
            }
            n = n2;
            if (this.zzdr != null) {
                n = n2 + zzart.zzf(18, this.zzdr);
            }
            n2 = n;
            if (this.zzds != null) {
                n2 = n + zzart.zzf(19, this.zzds);
            }
            n = n2;
            if (this.zzdt != null) {
                n = n2 + zzart.zzf(20, this.zzdt);
            }
            n2 = n;
            if (this.zzev != null) {
                n2 = n + zzart.zzf(21, this.zzev);
            }
            n = n2;
            if (this.zzdu != null) {
                n = n2 + zzart.zzf(22, this.zzdu);
            }
            n2 = n;
            if (this.zzdv != null) {
                n2 = n + zzart.zzf(23, this.zzdv);
            }
            n = n2;
            if (this.zzew != null) {
                n = n2 + zzart.zzr(24, this.zzew);
            }
            n2 = n;
            if (this.zzfa != null) {
                n2 = n + zzart.zzf(25, this.zzfa);
            }
            n = n2;
            if (this.zzex != null) {
                n = n2 + zzart.zzah(26, this.zzex);
            }
            n2 = n;
            if (this.zzcn != null) {
                n2 = n + zzart.zzr(27, this.zzcn);
            }
            n = n2;
            if (this.zzey != null) {
                n = n2 + zzart.zzh(28, this.zzey);
            }
            n2 = n;
            if (this.zzdw != null) {
                n2 = n + zzart.zzr(29, this.zzdw);
            }
            n = n2;
            if (this.zzez != null) {
                n = n2 + zzart.zzr(30, this.zzez);
            }
            n2 = n;
            if (this.zzdx != null) {
                n2 = n + zzart.zzf(31, this.zzdx);
            }
            n = n2;
            if (this.zzdy != null) {
                n = n2 + zzart.zzf(32, this.zzdy);
            }
            n2 = n;
            if (this.zzdz != null) {
                n2 = n + zzart.zzf(33, this.zzdz);
            }
            n = n2;
            if (this.zzcp != null) {
                n = n2 + zzart.zzr(34, this.zzcp);
            }
            n2 = n;
            if (this.zzea != null) {
                n2 = n + zzart.zzf(35, this.zzea);
            }
            n = n2;
            if (this.zzeb != null) {
                n = n2 + zzart.zzf(36, this.zzeb);
            }
            n2 = n;
            if (this.zzec != null) {
                n2 = n + zzart.zzf(37, this.zzec);
            }
            n = n2;
            if (this.zzed != null) {
                n = n2 + zzart.zzc(38, this.zzed);
            }
            n2 = n;
            if (this.zzee != null) {
                n2 = n + zzart.zzf(39, this.zzee);
            }
            n = n2;
            if (this.zzef != null) {
                n = n2 + zzart.zzf(40, this.zzef);
            }
            int n3 = n;
            if (this.zzeg != null) {
                n3 = n + zzart.zzf(41, this.zzeg);
            }
            n2 = n3;
            if (this.zzeh != null) {
                n2 = n3 + zzart.zzf(42, this.zzeh);
            }
            n = n2;
            if (this.zzet != null) {
                n = n2;
                if (this.zzet.length > 0) {
                    for (n = 0; n < this.zzet.length; ++n) {
                        zza zza2 = this.zzet[n];
                        n3 = n2;
                        if (zza2 != null) {
                            n3 = n2 + zzart.zzc(43, zza2);
                        }
                        n2 = n3;
                    }
                    n = n2;
                }
            }
            n2 = n;
            if (this.zzei != null) {
                n2 = n + zzart.zzf(44, this.zzei);
            }
            n = n2;
            if (this.zzej != null) {
                n = n2 + zzart.zzf(45, this.zzej);
            }
            n2 = n;
            if (this.zzcq != null) {
                n2 = n + zzart.zzr(46, this.zzcq);
            }
            n = n2;
            if (this.zzcr != null) {
                n = n2 + zzart.zzr(47, this.zzcr);
            }
            n2 = n;
            if (this.zzek != null) {
                n2 = n + zzart.zzah(48, this.zzek);
            }
            n = n2;
            if (this.zzel != null) {
                n = n2 + zzart.zzah(49, this.zzel);
            }
            n2 = n;
            if (this.zzes != null) {
                n2 = n + zzart.zzc(50, this.zzes);
            }
            n = n2;
            if (this.zzem != null) {
                n = n2 + zzart.zzf(51, this.zzem);
            }
            n2 = n;
            if (this.zzen != null) {
                n2 = n + zzart.zzf(52, this.zzen);
            }
            n = n2;
            if (this.zzeo != null) {
                n = n2 + zzart.zzf(53, this.zzeo);
            }
            n2 = n;
            if (this.zzep != null) {
                n2 = n + zzart.zzf(54, this.zzep);
            }
            n = n2;
            if (this.zzeq != null) {
                n = n2 + zzart.zzf(55, this.zzeq);
            }
            n2 = n;
            if (this.zzer != null) {
                n2 = n + zzart.zzah(56, this.zzer);
            }
            n = n2;
            if (this.zzeu != null) {
                n = n2 + zzart.zzc(57, this.zzeu);
            }
            n2 = n;
            if (this.zzfb != null) {
                n2 = n + zzart.zzc(201, this.zzfb);
            }
            return n2;
        }

        public static final class zza
        extends zzaru<zza> {
            private static volatile zza[] zzfc;
            public Long zzdn = null;
            public Long zzdo = null;
            public Long zzfd = null;
            public Long zzfe = null;
            public Long zzff = null;
            public Long zzfg = null;
            public Integer zzfh = null;
            public Long zzfi = null;
            public Long zzfj = null;
            public Long zzfk = null;
            public Integer zzfl = null;
            public Long zzfm = null;

            public zza() {
                this.btP = -1;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public static zza[] zzaa() {
                if (zzfc == null) {
                    Object object = zzary.btO;
                    synchronized (object) {
                        if (zzfc == null) {
                            zzfc = new zza[0];
                        }
                    }
                }
                return zzfc;
            }

            @Override
            public void zza(zzart zzart2) throws IOException {
                if (this.zzdn != null) {
                    zzart2.zzb(1, this.zzdn);
                }
                if (this.zzdo != null) {
                    zzart2.zzb(2, this.zzdo);
                }
                if (this.zzfd != null) {
                    zzart2.zzb(3, this.zzfd);
                }
                if (this.zzfe != null) {
                    zzart2.zzb(4, this.zzfe);
                }
                if (this.zzff != null) {
                    zzart2.zzb(5, this.zzff);
                }
                if (this.zzfg != null) {
                    zzart2.zzb(6, this.zzfg);
                }
                if (this.zzfh != null) {
                    zzart2.zzaf(7, this.zzfh);
                }
                if (this.zzfi != null) {
                    zzart2.zzb(8, this.zzfi);
                }
                if (this.zzfj != null) {
                    zzart2.zzb(9, this.zzfj);
                }
                if (this.zzfk != null) {
                    zzart2.zzb(10, this.zzfk);
                }
                if (this.zzfl != null) {
                    zzart2.zzaf(11, this.zzfl);
                }
                if (this.zzfm != null) {
                    zzart2.zzb(12, this.zzfm);
                }
                super.zza(zzart2);
            }

            @Override
            public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
                return this.zzg(zzars2);
            }

            public zza zzg(zzars zzars2) throws IOException {
                block21 : do {
                    int n = zzars2.bU();
                    switch (n) {
                        default: {
                            if (super.zza(zzars2, n)) continue block21;
                        }
                        case 0: {
                            return this;
                        }
                        case 8: {
                            this.zzdn = zzars2.bX();
                            continue block21;
                        }
                        case 16: {
                            this.zzdo = zzars2.bX();
                            continue block21;
                        }
                        case 24: {
                            this.zzfd = zzars2.bX();
                            continue block21;
                        }
                        case 32: {
                            this.zzfe = zzars2.bX();
                            continue block21;
                        }
                        case 40: {
                            this.zzff = zzars2.bX();
                            continue block21;
                        }
                        case 48: {
                            this.zzfg = zzars2.bX();
                            continue block21;
                        }
                        case 56: {
                            n = zzars2.bY();
                            switch (n) {
                                default: {
                                    continue block21;
                                }
                                case 0: 
                                case 1: 
                                case 2: 
                                case 1000: 
                            }
                            this.zzfh = n;
                            continue block21;
                        }
                        case 64: {
                            this.zzfi = zzars2.bX();
                            continue block21;
                        }
                        case 72: {
                            this.zzfj = zzars2.bX();
                            continue block21;
                        }
                        case 80: {
                            this.zzfk = zzars2.bX();
                            continue block21;
                        }
                        case 88: {
                            n = zzars2.bY();
                            switch (n) {
                                default: {
                                    continue block21;
                                }
                                case 0: 
                                case 1: 
                                case 2: 
                                case 1000: 
                            }
                            this.zzfl = n;
                            continue block21;
                        }
                        case 96: 
                    }
                    this.zzfm = zzars2.bX();
                } while (true);
            }

            @Override
            protected int zzx() {
                int n;
                int n2 = n = super.zzx();
                if (this.zzdn != null) {
                    n2 = n + zzart.zzf(1, this.zzdn);
                }
                n = n2;
                if (this.zzdo != null) {
                    n = n2 + zzart.zzf(2, this.zzdo);
                }
                n2 = n;
                if (this.zzfd != null) {
                    n2 = n + zzart.zzf(3, this.zzfd);
                }
                n = n2;
                if (this.zzfe != null) {
                    n = n2 + zzart.zzf(4, this.zzfe);
                }
                n2 = n;
                if (this.zzff != null) {
                    n2 = n + zzart.zzf(5, this.zzff);
                }
                n = n2;
                if (this.zzfg != null) {
                    n = n2 + zzart.zzf(6, this.zzfg);
                }
                n2 = n;
                if (this.zzfh != null) {
                    n2 = n + zzart.zzah(7, this.zzfh);
                }
                n = n2;
                if (this.zzfi != null) {
                    n = n2 + zzart.zzf(8, this.zzfi);
                }
                n2 = n;
                if (this.zzfj != null) {
                    n2 = n + zzart.zzf(9, this.zzfj);
                }
                n = n2;
                if (this.zzfk != null) {
                    n = n2 + zzart.zzf(10, this.zzfk);
                }
                n2 = n;
                if (this.zzfl != null) {
                    n2 = n + zzart.zzah(11, this.zzfl);
                }
                n = n2;
                if (this.zzfm != null) {
                    n = n2 + zzart.zzf(12, this.zzfm);
                }
                return n;
            }
        }

        public static final class zzb
        extends zzaru<zzb> {
            public Long zzep = null;
            public Long zzeq = null;
            public Long zzfn = null;

            public zzb() {
                this.btP = -1;
            }

            @Override
            public void zza(zzart zzart2) throws IOException {
                if (this.zzep != null) {
                    zzart2.zzb(1, this.zzep);
                }
                if (this.zzeq != null) {
                    zzart2.zzb(2, this.zzeq);
                }
                if (this.zzfn != null) {
                    zzart2.zzb(3, this.zzfn);
                }
                super.zza(zzart2);
            }

            @Override
            public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
                return this.zzh(zzars2);
            }

            public zzb zzh(zzars zzars2) throws IOException {
                block6 : do {
                    int n = zzars2.bU();
                    switch (n) {
                        default: {
                            if (super.zza(zzars2, n)) continue block6;
                        }
                        case 0: {
                            return this;
                        }
                        case 8: {
                            this.zzep = zzars2.bX();
                            continue block6;
                        }
                        case 16: {
                            this.zzeq = zzars2.bX();
                            continue block6;
                        }
                        case 24: 
                    }
                    this.zzfn = zzars2.bX();
                } while (true);
            }

            @Override
            protected int zzx() {
                int n;
                int n2 = n = super.zzx();
                if (this.zzep != null) {
                    n2 = n + zzart.zzf(1, this.zzep);
                }
                n = n2;
                if (this.zzeq != null) {
                    n = n2 + zzart.zzf(2, this.zzeq);
                }
                n2 = n;
                if (this.zzfn != null) {
                    n2 = n + zzart.zzf(3, this.zzfn);
                }
                return n2;
            }
        }

    }

    public static final class zzb
    extends zzaru<zzb> {
        public Long zzfo = null;
        public Integer zzfp = null;
        public Boolean zzfq = null;
        public int[] zzfr = zzasd.btR;
        public Long zzfs = null;

        public zzb() {
            this.btP = -1;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzfo != null) {
                zzart2.zzb(1, this.zzfo);
            }
            if (this.zzfp != null) {
                zzart2.zzaf(2, this.zzfp);
            }
            if (this.zzfq != null) {
                zzart2.zzg(3, this.zzfq);
            }
            if (this.zzfr != null && this.zzfr.length > 0) {
                for (int i = 0; i < this.zzfr.length; ++i) {
                    zzart2.zzaf(4, this.zzfr[i]);
                }
            }
            if (this.zzfs != null) {
                zzart2.zza(5, this.zzfs);
            }
            super.zza(zzart2);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzi(zzars2);
        }

        /*
         * Enabled aggressive block sorting
         */
        public zzb zzi(zzars zzars2) throws IOException {
            block9 : do {
                int n = zzars2.bU();
                switch (n) {
                    int[] arrn;
                    int n2;
                    default: {
                        if (super.zza(zzars2, n)) continue block9;
                    }
                    case 0: {
                        return this;
                    }
                    case 8: {
                        this.zzfo = zzars2.bX();
                        continue block9;
                    }
                    case 16: {
                        this.zzfp = zzars2.bY();
                        continue block9;
                    }
                    case 24: {
                        this.zzfq = zzars2.ca();
                        continue block9;
                    }
                    case 32: {
                        n2 = zzasd.zzc(zzars2, 32);
                        n = this.zzfr == null ? 0 : this.zzfr.length;
                        arrn = new int[n2 + n];
                        n2 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzfr, 0, arrn, 0, n);
                            n2 = n;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzfr = arrn;
                        continue block9;
                    }
                    case 34: {
                        int n3 = zzars2.zzagt(zzars2.cd());
                        n = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n);
                        n = this.zzfr == null ? 0 : this.zzfr.length;
                        arrn = new int[n2 + n];
                        n2 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzfr, 0, arrn, 0, n);
                            n2 = n;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzfr = arrn;
                        zzars2.zzagu(n3);
                        continue block9;
                    }
                    case 40: 
                }
                this.zzfs = zzars2.bW();
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = 0;
            int n3 = n = super.zzx();
            if (this.zzfo != null) {
                n3 = n + zzart.zzf(1, this.zzfo);
            }
            n = n3;
            if (this.zzfp != null) {
                n = n3 + zzart.zzah(2, this.zzfp);
            }
            n3 = n;
            if (this.zzfq != null) {
                n3 = n + zzart.zzh(3, this.zzfq);
            }
            n = n3;
            if (this.zzfr != null) {
                n = n3;
                if (this.zzfr.length > 0) {
                    int n4 = 0;
                    for (n = n2; n < this.zzfr.length; ++n) {
                        n4 += zzart.zzagz(this.zzfr[n]);
                    }
                    n = n3 + n4 + this.zzfr.length * 1;
                }
            }
            n3 = n;
            if (this.zzfs != null) {
                n3 = n + zzart.zze(5, this.zzfs);
            }
            return n3;
        }
    }

    public static final class zzc
    extends zzaru<zzc> {
        public byte[] zzft = null;
        public byte[] zzfu = null;

        public zzc() {
            this.btP = -1;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzft != null) {
                zzart2.zzb(1, this.zzft);
            }
            if (this.zzfu != null) {
                zzart2.zzb(2, this.zzfu);
            }
            super.zza(zzart2);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzj(zzars2);
        }

        public zzc zzj(zzars zzars2) throws IOException {
            block5 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block5;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        this.zzft = zzars2.readBytes();
                        continue block5;
                    }
                    case 18: 
                }
                this.zzfu = zzars2.readBytes();
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.zzft != null) {
                n2 = n + zzart.zzc(1, this.zzft);
            }
            n = n2;
            if (this.zzfu != null) {
                n = n2 + zzart.zzc(2, this.zzfu);
            }
            return n;
        }
    }

    public static final class zzd
    extends zzaru<zzd> {
        public byte[] data = null;
        public byte[] zzfv = null;
        public byte[] zzfw = null;
        public byte[] zzfx = null;

        public zzd() {
            this.btP = -1;
        }

        public static zzd zze(byte[] arrby) throws zzarz {
            return zzasa.zza(new zzd(), arrby);
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.data != null) {
                zzart2.zzb(1, this.data);
            }
            if (this.zzfv != null) {
                zzart2.zzb(2, this.zzfv);
            }
            if (this.zzfw != null) {
                zzart2.zzb(3, this.zzfw);
            }
            if (this.zzfx != null) {
                zzart2.zzb(4, this.zzfx);
            }
            super.zza(zzart2);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzk(zzars2);
        }

        public zzd zzk(zzars zzars2) throws IOException {
            block7 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block7;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        this.data = zzars2.readBytes();
                        continue block7;
                    }
                    case 18: {
                        this.zzfv = zzars2.readBytes();
                        continue block7;
                    }
                    case 26: {
                        this.zzfw = zzars2.readBytes();
                        continue block7;
                    }
                    case 34: 
                }
                this.zzfx = zzars2.readBytes();
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.data != null) {
                n2 = n + zzart.zzc(1, this.data);
            }
            n = n2;
            if (this.zzfv != null) {
                n = n2 + zzart.zzc(2, this.zzfv);
            }
            n2 = n;
            if (this.zzfw != null) {
                n2 = n + zzart.zzc(3, this.zzfw);
            }
            n = n2;
            if (this.zzfx != null) {
                n = n2 + zzart.zzc(4, this.zzfx);
            }
            return n;
        }
    }

    public static final class zze
    extends zzaru<zze> {
        public Long zzfo = null;
        public String zzfy = null;
        public byte[] zzfz = null;

        public zze() {
            this.btP = -1;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzfo != null) {
                zzart2.zzb(1, this.zzfo);
            }
            if (this.zzfy != null) {
                zzart2.zzq(3, this.zzfy);
            }
            if (this.zzfz != null) {
                zzart2.zzb(4, this.zzfz);
            }
            super.zza(zzart2);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzl(zzars2);
        }

        public zze zzl(zzars zzars2) throws IOException {
            block6 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block6;
                    }
                    case 0: {
                        return this;
                    }
                    case 8: {
                        this.zzfo = zzars2.bX();
                        continue block6;
                    }
                    case 26: {
                        this.zzfy = zzars2.readString();
                        continue block6;
                    }
                    case 34: 
                }
                this.zzfz = zzars2.readBytes();
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.zzfo != null) {
                n2 = n + zzart.zzf(1, this.zzfo);
            }
            n = n2;
            if (this.zzfy != null) {
                n = n2 + zzart.zzr(3, this.zzfy);
            }
            n2 = n;
            if (this.zzfz != null) {
                n2 = n + zzart.zzc(4, this.zzfz);
            }
            return n2;
        }
    }

    public static final class zzf
    extends zzaru<zzf> {
        public byte[] zzfv = null;
        public byte[][] zzga = zzasd.btX;
        public Integer zzgb = null;
        public Integer zzgc = null;

        public zzf() {
            this.btP = -1;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzga != null && this.zzga.length > 0) {
                for (int i = 0; i < this.zzga.length; ++i) {
                    byte[] arrby = this.zzga[i];
                    if (arrby == null) continue;
                    zzart2.zzb(1, arrby);
                }
            }
            if (this.zzfv != null) {
                zzart2.zzb(2, this.zzfv);
            }
            if (this.zzgb != null) {
                zzart2.zzaf(3, this.zzgb);
            }
            if (this.zzgc != null) {
                zzart2.zzaf(4, this.zzgc);
            }
            super.zza(zzart2);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzm(zzars2);
        }

        /*
         * Enabled aggressive block sorting
         */
        public zzf zzm(zzars zzars2) throws IOException {
            block13 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block13;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        int n2 = zzasd.zzc(zzars2, 10);
                        n = this.zzga == null ? 0 : this.zzga.length;
                        byte[][] arrarrby = new byte[n2 + n][];
                        n2 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzga, 0, arrarrby, 0, n);
                            n2 = n;
                        }
                        while (n2 < arrarrby.length - 1) {
                            arrarrby[n2] = zzars2.readBytes();
                            zzars2.bU();
                            ++n2;
                        }
                        arrarrby[n2] = zzars2.readBytes();
                        this.zzga = arrarrby;
                        continue block13;
                    }
                    case 18: {
                        this.zzfv = zzars2.readBytes();
                        continue block13;
                    }
                    case 24: {
                        n = zzars2.bY();
                        switch (n) {
                            default: {
                                continue block13;
                            }
                            case 0: 
                            case 1: 
                        }
                        this.zzgb = n;
                        continue block13;
                    }
                    case 32: 
                }
                n = zzars2.bY();
                switch (n) {
                    default: {
                        continue block13;
                    }
                    case 0: 
                    case 1: 
                }
                this.zzgc = n;
            } while (true);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        protected int zzx() {
            int n;
            int n2;
            int n3 = super.zzx();
            if (this.zzga != null && this.zzga.length > 0) {
                n2 = 0;
                int n4 = 0;
                for (n = 0; n < this.zzga.length; ++n) {
                    byte[] arrby = this.zzga[n];
                    int n5 = n2;
                    int n6 = n4;
                    if (arrby != null) {
                        n6 = n4 + 1;
                        n5 = n2 + zzart.zzbg(arrby);
                    }
                    n2 = n5;
                    n4 = n6;
                }
                n2 = n3 + n2 + n4 * 1;
            } else {
                n2 = n3;
            }
            n = n2;
            if (this.zzfv != null) {
                n = n2 + zzart.zzc(2, this.zzfv);
            }
            n2 = n;
            if (this.zzgb != null) {
                n2 = n + zzart.zzah(3, this.zzgb);
            }
            n = n2;
            if (this.zzgc == null) return n;
            return n2 + zzart.zzah(4, this.zzgc);
        }
    }

}

