/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import com.google.android.gms.internal.zzai;
import com.google.android.gms.internal.zzars;
import com.google.android.gms.internal.zzart;
import com.google.android.gms.internal.zzaru;
import com.google.android.gms.internal.zzarw;
import com.google.android.gms.internal.zzarz;
import com.google.android.gms.internal.zzasa;
import java.io.IOException;

public interface zzafu {

    public static final class zza
    extends zzaru<zza> {
        public long aMu;
        public zzai.zzj aMv;
        public zzai.zzf zzxv;

        public zza() {
            this.zzckt();
        }

        public static zza zzap(byte[] arrby) throws zzarz {
            return zzasa.zza(new zza(), arrby);
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zza)) return bl2;
            object = (zza)object;
            bl2 = bl;
            if (this.aMu != object.aMu) return bl2;
            if (this.zzxv == null) {
                bl2 = bl;
                if (object.zzxv != null) return bl2;
            } else if (!this.zzxv.equals(object.zzxv)) {
                return false;
            }
            if (this.aMv == null) {
                bl2 = bl;
                if (object.aMv != null) return bl2;
            } else if (!this.aMv.equals(object.aMv)) {
                return false;
            }
            if (this.btG != null && !this.btG.isEmpty()) {
                return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        public int hashCode() {
            int n = 0;
            int n2 = this.getClass().getName().hashCode();
            int n3 = (int)(this.aMu ^ this.aMu >>> 32);
            int n4 = this.zzxv == null ? 0 : this.zzxv.hashCode();
            int n5 = this.aMv == null ? 0 : this.aMv.hashCode();
            int n6 = n;
            if (this.btG == null) return (n5 + (n4 + ((n2 + 527) * 31 + n3) * 31) * 31) * 31 + n6;
            if (this.btG.isEmpty()) {
                n6 = n;
                return (n5 + (n4 + ((n2 + 527) * 31 + n3) * 31) * 31) * 31 + n6;
            }
            n6 = this.btG.hashCode();
            return (n5 + (n4 + ((n2 + 527) * 31 + n3) * 31) * 31) * 31 + n6;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            zzart2.zzb(1, this.aMu);
            if (this.zzxv != null) {
                zzart2.zza(2, this.zzxv);
            }
            if (this.aMv != null) {
                zzart2.zza(3, this.aMv);
            }
            super.zza(zzart2);
        }

        public zza zzaw(zzars zzars2) throws IOException {
            block6 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block6;
                    }
                    case 0: {
                        return this;
                    }
                    case 8: {
                        this.aMu = zzars2.bX();
                        continue block6;
                    }
                    case 18: {
                        if (this.zzxv == null) {
                            this.zzxv = new zzai.zzf();
                        }
                        zzars2.zza(this.zzxv);
                        continue block6;
                    }
                    case 26: 
                }
                if (this.aMv == null) {
                    this.aMv = new zzai.zzj();
                }
                zzars2.zza(this.aMv);
            } while (true);
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzaw(zzars2);
        }

        public zza zzckt() {
            this.aMu = 0;
            this.zzxv = null;
            this.aMv = null;
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx() + zzart.zzf(1, this.aMu);
            if (this.zzxv != null) {
                n2 = n + zzart.zzc(2, this.zzxv);
            }
            n = n2;
            if (this.aMv != null) {
                n = n2 + zzart.zzc(3, this.aMv);
            }
            return n;
        }
    }

}

