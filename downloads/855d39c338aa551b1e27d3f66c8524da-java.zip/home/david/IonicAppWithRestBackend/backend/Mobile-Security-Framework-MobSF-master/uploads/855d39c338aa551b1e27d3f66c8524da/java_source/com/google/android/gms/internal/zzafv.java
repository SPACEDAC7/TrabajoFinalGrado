/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.common.util.zze;
import com.google.android.gms.common.util.zzh;
import com.google.android.gms.internal.zzafx;
import java.util.HashMap;
import java.util.Map;

public class zzafv {
    private String aEC = null;
    Map<String, Object> aLk = new HashMap<String, Object>();
    private final Map<String, Object> aLl;
    private final zzafx aMw;
    private final Context mContext;
    private final zze zzaql;

    public zzafv(Context context) {
        this(context, new HashMap<String, Object>(), new zzafx(context), zzh.zzayl());
    }

    zzafv(Context context, Map<String, Object> map, zzafx zzafx2, zze zze2) {
        this.mContext = context;
        this.zzaql = zze2;
        this.aMw = zzafx2;
        this.aLl = map;
    }

    public void zzqy(String string2) {
        this.aEC = string2;
    }
}

