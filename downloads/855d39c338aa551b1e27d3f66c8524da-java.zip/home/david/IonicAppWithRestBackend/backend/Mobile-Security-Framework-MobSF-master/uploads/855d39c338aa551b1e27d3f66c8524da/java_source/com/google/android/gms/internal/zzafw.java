/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import com.google.android.gms.internal.zzah;
import com.google.android.gms.internal.zzai;
import com.google.android.gms.internal.zzaj;
import com.google.android.gms.internal.zzarv;
import com.google.android.gms.tagmanager.zzbo;
import com.google.android.gms.tagmanager.zzdm;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class zzafw {
    /*
     * Enabled aggressive block sorting
     */
    private static zza zza(zzai.zzb arrn, zzai.zzf zzf2, zzaj.zza[] arrzza, int n) throws zzg {
        zzb zzb2 = zza.zzcku();
        arrn = arrn.zzvu;
        int n2 = arrn.length;
        n = 0;
        while (n < n2) {
            int n3 = arrn[n];
            zzai.zze zze2 = zzafw.zza(zzf2.zzwk, n3, "properties");
            String string2 = zzafw.zza(zzf2.zzwi, zze2.key, "keys");
            zzaj.zza zza2 = zzafw.zza(arrzza, zze2.value, "values");
            if (zzah.zzst.toString().equals(string2)) {
                zzb2.zzq(zza2);
            } else {
                zzb2.zzb(string2, zza2);
            }
            ++n;
        }
        return zzb2.zzckv();
    }

    private static zze zza(zzai.zzg arrn, List<zza> arrn2, List<zza> list, List<zza> arrn3, zzai.zzf zzf2) {
        int n;
        zzf zzf3 = zze.zzckz();
        int[] arrn4 = arrn.zzwy;
        int n2 = arrn4.length;
        for (n = 0; n < n2; ++n) {
            zzf3.zzd(arrn3.get(arrn4[n]));
        }
        arrn4 = arrn.zzwz;
        n2 = arrn4.length;
        for (n = 0; n < n2; ++n) {
            zzf3.zze((zza)arrn3.get(arrn4[n]));
        }
        arrn3 = arrn.zzxa;
        n2 = arrn3.length;
        for (n = 0; n < n2; ++n) {
            zzf3.zzf(arrn2.get(arrn3[n]));
        }
        for (int n3222 : arrn.zzxc) {
            zzf3.zzrj(zzf2.zzwj[Integer.valueOf((int)n3222).intValue()].string);
        }
        arrn3 = arrn.zzxb;
        n2 = arrn3.length;
        for (n = 0; n < n2; ++n) {
            zzf3.zzg((zza)arrn2.get(arrn3[n]));
        }
        for (int n3222 : arrn.zzxd) {
            zzf3.zzrk(zzf2.zzwj[Integer.valueOf((int)n3222).intValue()].string);
        }
        arrn2 = arrn.zzxe;
        n2 = arrn2.length;
        for (n = 0; n < n2; ++n) {
            zzf3.zzh(list.get(arrn2[n]));
        }
        for (int n3222 : arrn.zzxg) {
            zzf3.zzrl(zzf2.zzwj[Integer.valueOf((int)n3222).intValue()].string);
        }
        arrn2 = arrn.zzxf;
        n2 = arrn2.length;
        for (n = 0; n < n2; ++n) {
            zzf3.zzi(list.get(arrn2[n]));
        }
        for (int n3222 : arrn.zzxh) {
            zzf3.zzrm(zzf2.zzwj[Integer.valueOf((int)n3222).intValue()].string);
        }
        return zzf3.zzcle();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static zzaj.zza zza(int var0, zzai.zzf var1_1, zzaj.zza[] var2_2, Set<Integer> var3_3) throws zzg {
        var6_4 = 0;
        var7_5 = 0;
        var5_6 = 0;
        if (var3_3.contains(var0)) {
            var9_7 = String.valueOf(var3_3);
            zzafw.zzqt(new StringBuilder(String.valueOf(var9_7).length() + 90).append("Value cycle detected.  Current value reference: ").append(var0).append(".  Previous value references: ").append((String)var9_7).append(".").toString());
        }
        var10_8 = zzafw.zza(var1_1.zzwj, var0, "values");
        if (var2_2[var0] != null) {
            return var2_2[var0];
        }
        var9_7 = null;
        var3_3.add(var0);
        switch (var10_8.type) {
            case 2: {
                var9_7 = zzafw.zzp(var10_8);
                var11_9 = zzafw.zzo(var10_8);
                var11_9.zzxy = new zzaj.zza[var9_7.zzxk.length];
                var12_12 = var9_7.zzxk;
                var6_4 = var12_12.length;
                var4_15 = 0;
                do {
                    var9_7 = var11_9;
                    if (var5_6 < var6_4) {
                        var7_5 = var12_12[var5_6];
                        var11_9.zzxy[var4_15] = zzafw.zza(var7_5, (zzai.zzf)var1_1, var2_2, var3_3);
                        ++var5_6;
                        ++var4_15;
                        continue;
                    }
                    ** GOTO lbl78
                    break;
                } while (true);
            }
            case 3: {
                var11_10 = zzafw.zzo(var10_8);
                var9_7 = zzafw.zzp(var10_8);
                if (var9_7.zzxl.length != var9_7.zzxm.length) {
                    var4_16 = var9_7.zzxl.length;
                    var5_6 = var9_7.zzxm.length;
                    zzafw.zzqt(new StringBuilder(58).append("Uneven map keys (").append(var4_16).append(") and map values (").append(var5_6).append(")").toString());
                }
                var11_10.zzxz = new zzaj.zza[var9_7.zzxl.length];
                var11_10.zzya = new zzaj.zza[var9_7.zzxl.length];
                var12_13 = var9_7.zzxl;
                var7_5 = var12_13.length;
                var4_16 = 0;
                for (var5_6 = 0; var5_6 < var7_5; ++var5_6, ++var4_16) {
                    var8_18 = var12_13[var5_6];
                    var11_10.zzxz[var4_16] = zzafw.zza(var8_18, (zzai.zzf)var1_1, var2_2, var3_3);
                }
                var12_13 = var9_7.zzxm;
                var7_5 = var12_13.length;
                var4_16 = 0;
                var5_6 = var6_4;
                do {
                    var9_7 = var11_10;
                    if (var5_6 < var7_5) {
                        var6_4 = var12_13[var5_6];
                        var11_10.zzya[var4_16] = zzafw.zza(var6_4, (zzai.zzf)var1_1, var2_2, var3_3);
                        ++var5_6;
                        ++var4_16;
                        continue;
                    }
                    ** GOTO lbl78
                    break;
                } while (true);
            }
            case 4: {
                var9_7 = zzafw.zzo(var10_8);
                var9_7.zzyb = zzdm.zzg(zzafw.zza(zzafw.zzp((zzaj.zza)var10_8).zzxp, (zzai.zzf)var1_1, var2_2, var3_3));
                ** break;
            }
            case 7: {
                var11_11 = zzafw.zzo(var10_8);
                var9_7 = zzafw.zzp(var10_8);
                var11_11.zzyf = new zzaj.zza[var9_7.zzxo.length];
                var12_14 = var9_7.zzxo;
                var6_4 = var12_14.length;
                var4_17 = 0;
                var5_6 = var7_5;
                do {
                    var9_7 = var11_11;
                    if (var5_6 >= var6_4) break;
                    var7_5 = var12_14[var5_6];
                    var11_11.zzyf[var4_17] = zzafw.zza(var7_5, (zzai.zzf)var1_1, var2_2, var3_3);
                    ++var5_6;
                    ++var4_17;
                } while (true);
            }
lbl78: // 5 sources:
            default: {
                ** GOTO lbl82
            }
            case 1: 
            case 5: 
            case 6: 
            case 8: 
        }
        var9_7 = var10_8;
lbl82: // 2 sources:
        if (var9_7 == null) {
            var1_1 = String.valueOf(var10_8);
            zzafw.zzqt(new StringBuilder(String.valueOf(var1_1).length() + 15).append("Invalid value: ").append((String)var1_1).toString());
        }
        var2_2[var0] = var9_7;
        var3_3.remove(var0);
        return var9_7;
    }

    private static <T> T zza(T[] arrT, int n, String string2) throws zzg {
        if (n < 0 || n >= arrT.length) {
            zzafw.zzqt(new StringBuilder(String.valueOf(string2).length() + 45).append("Index out of bounds detected: ").append(n).append(" in ").append(string2).toString());
        }
        return arrT[n];
    }

    public static zzc zzb(zzai.zzf zzf2) throws zzg {
        int n;
        int n2 = 0;
        zzaj.zza[] arrzza = new zzaj.zza[zzf2.zzwj.length];
        for (n = 0; n < zzf2.zzwj.length; ++n) {
            zzafw.zza(n, zzf2, arrzza, new HashSet<Integer>(0));
        }
        zzd zzd2 = zzc.zzckw();
        ArrayList<zza> arrayList = new ArrayList<zza>();
        for (n = 0; n < zzf2.zzwm.length; ++n) {
            arrayList.add(zzafw.zza(zzf2.zzwm[n], zzf2, arrzza, n));
        }
        ArrayList<zza> arrayList2 = new ArrayList<zza>();
        for (n = 0; n < zzf2.zzwn.length; ++n) {
            arrayList2.add(zzafw.zza(zzf2.zzwn[n], zzf2, arrzza, n));
        }
        ArrayList<zza> arrayList3 = new ArrayList<zza>();
        for (n = 0; n < zzf2.zzwl.length; ++n) {
            zza zza2 = zzafw.zza(zzf2.zzwl[n], zzf2, arrzza, n);
            zzd2.zzc(zza2);
            arrayList3.add(zza2);
        }
        arrzza = zzf2.zzwo;
        int n3 = arrzza.length;
        for (n = n2; n < n3; ++n) {
            zzd2.zzb(zzafw.zza((zzai.zzg)((Object)arrzza[n]), arrayList, arrayList3, arrayList2, zzf2));
        }
        zzd2.zzri(zzf2.version);
        zzd2.zzaao(zzf2.zzww);
        return zzd2.zzcky();
    }

    public static void zzc(InputStream inputStream, OutputStream outputStream) throws IOException {
        byte[] arrby = new byte[1024];
        int n;
        while ((n = inputStream.read(arrby)) != -1) {
            outputStream.write(arrby, 0, n);
        }
        return;
    }

    public static zzaj.zza zzo(zzaj.zza zza2) {
        zzaj.zza zza3 = new zzaj.zza();
        zza3.type = zza2.type;
        zza3.zzyg = (int[])zza2.zzyg.clone();
        if (zza2.zzyh) {
            zza3.zzyh = zza2.zzyh;
        }
        return zza3;
    }

    private static zzai.zzh zzp(zzaj.zza zza2) throws zzg {
        if (zza2.zza(zzai.zzh.zzxi) == null) {
            String string2 = String.valueOf(zza2);
            zzafw.zzqt(new StringBuilder(String.valueOf(string2).length() + 54).append("Expected a ServingValue and didn't get one. Value is: ").append(string2).toString());
        }
        return zza2.zza(zzai.zzh.zzxi);
    }

    private static void zzqt(String string2) throws zzg {
        zzbo.e(string2);
        throw new zzg(string2);
    }

    public static class zza {
        private final zzaj.zza aHd;
        private final Map<String, zzaj.zza> aLM;

        private zza(Map<String, zzaj.zza> map, zzaj.zza zza2) {
            this.aLM = map;
            this.aHd = zza2;
        }

        public static zzb zzcku() {
            return new zzb();
        }

        public String toString() {
            String string2 = String.valueOf(this.zzcjt());
            String string3 = String.valueOf(this.aHd);
            return new StringBuilder(String.valueOf(string2).length() + 32 + String.valueOf(string3).length()).append("Properties: ").append(string2).append(" pushAfterEvaluate: ").append(string3).toString();
        }

        public void zza(String string2, zzaj.zza zza2) {
            this.aLM.put(string2, zza2);
        }

        public zzaj.zza zzcgm() {
            return this.aHd;
        }

        public Map<String, zzaj.zza> zzcjt() {
            return Collections.unmodifiableMap(this.aLM);
        }
    }

    public static class zzb {
        private zzaj.zza aHd;
        private final Map<String, zzaj.zza> aLM = new HashMap<String, zzaj.zza>();

        private zzb() {
        }

        public zzb zzb(String string2, zzaj.zza zza2) {
            this.aLM.put(string2, zza2);
            return this;
        }

        public zza zzckv() {
            return new zza(this.aLM, this.aHd);
        }

        public zzb zzq(zzaj.zza zza2) {
            this.aHd = zza2;
            return this;
        }
    }

    public static class zzc {
        private final List<zze> aLJ;
        private final Map<String, List<zza>> aLK;
        private final int aLL;
        private final String um;

        private zzc(List<zze> list, Map<String, List<zza>> map, String string2, int n) {
            this.aLJ = Collections.unmodifiableList(list);
            this.aLK = Collections.unmodifiableMap(map);
            this.um = string2;
            this.aLL = n;
        }

        public static zzd zzckw() {
            return new zzd();
        }

        public String getVersion() {
            return this.um;
        }

        public String toString() {
            String string2 = String.valueOf(this.zzcjr());
            String string3 = String.valueOf(this.aLK);
            return new StringBuilder(String.valueOf(string2).length() + 17 + String.valueOf(string3).length()).append("Rules: ").append(string2).append("  Macros: ").append(string3).toString();
        }

        public List<zze> zzcjr() {
            return this.aLJ;
        }

        public Map<String, List<zza>> zzckx() {
            return this.aLK;
        }
    }

    public static class zzd {
        private final List<zze> aLJ = new ArrayList<zze>();
        private final Map<String, List<zza>> aLK = new HashMap<String, List<zza>>();
        private int aLL = 0;
        private String um = "";

        private zzd() {
        }

        public zzd zzaao(int n) {
            this.aLL = n;
            return this;
        }

        public zzd zzb(zze zze2) {
            this.aLJ.add(zze2);
            return this;
        }

        public zzd zzc(zza zza2) {
            List<zza> list;
            String string2 = zzdm.zzg(zza2.zzcjt().get(zzah.zzqm.toString()));
            List<zza> list2 = list = this.aLK.get(string2);
            if (list == null) {
                list2 = new ArrayList<zza>();
                this.aLK.put(string2, list2);
            }
            list2.add(zza2);
            return this;
        }

        public zzc zzcky() {
            return new zzc(this.aLJ, this.aLK, this.um, this.aLL);
        }

        public zzd zzri(String string2) {
            this.um = string2;
            return this;
        }
    }

    public static class zze {
        private final List<zza> aLO;
        private final List<zza> aLP;
        private final List<zza> aLQ;
        private final List<zza> aLR;
        private final List<String> aMA;
        private final List<String> aMB;
        private final List<String> aMC;
        private final List<zza> aMx;
        private final List<zza> aMy;
        private final List<String> aMz;

        private zze(List<zza> list, List<zza> list2, List<zza> list3, List<zza> list4, List<zza> list5, List<zza> list6, List<String> list7, List<String> list8, List<String> list9, List<String> list10) {
            this.aLO = Collections.unmodifiableList(list);
            this.aLP = Collections.unmodifiableList(list2);
            this.aLQ = Collections.unmodifiableList(list3);
            this.aLR = Collections.unmodifiableList(list4);
            this.aMx = Collections.unmodifiableList(list5);
            this.aMy = Collections.unmodifiableList(list6);
            this.aMz = Collections.unmodifiableList(list7);
            this.aMA = Collections.unmodifiableList(list8);
            this.aMB = Collections.unmodifiableList(list9);
            this.aMC = Collections.unmodifiableList(list10);
        }

        public static zzf zzckz() {
            return new zzf();
        }

        public String toString() {
            String string2 = String.valueOf(this.zzcjv());
            String string3 = String.valueOf(this.zzcjw());
            String string4 = String.valueOf(this.zzcjx());
            String string5 = String.valueOf(this.zzcjy());
            String string6 = String.valueOf(this.zzcla());
            String string7 = String.valueOf(this.zzcld());
            return new StringBuilder(String.valueOf(string2).length() + 102 + String.valueOf(string3).length() + String.valueOf(string4).length() + String.valueOf(string5).length() + String.valueOf(string6).length() + String.valueOf(string7).length()).append("Positive predicates: ").append(string2).append("  Negative predicates: ").append(string3).append("  Add tags: ").append(string4).append("  Remove tags: ").append(string5).append("  Add macros: ").append(string6).append("  Remove macros: ").append(string7).toString();
        }

        public List<zza> zzcjv() {
            return this.aLO;
        }

        public List<zza> zzcjw() {
            return this.aLP;
        }

        public List<zza> zzcjx() {
            return this.aLQ;
        }

        public List<zza> zzcjy() {
            return this.aLR;
        }

        public List<zza> zzcla() {
            return this.aMx;
        }

        public List<String> zzclb() {
            return this.aMB;
        }

        public List<String> zzclc() {
            return this.aMC;
        }

        public List<zza> zzcld() {
            return this.aMy;
        }
    }

    public static class zzf {
        private final List<zza> aLO = new ArrayList<zza>();
        private final List<zza> aLP = new ArrayList<zza>();
        private final List<zza> aLQ = new ArrayList<zza>();
        private final List<zza> aLR = new ArrayList<zza>();
        private final List<String> aMA = new ArrayList<String>();
        private final List<String> aMB = new ArrayList<String>();
        private final List<String> aMC = new ArrayList<String>();
        private final List<zza> aMx = new ArrayList<zza>();
        private final List<zza> aMy = new ArrayList<zza>();
        private final List<String> aMz = new ArrayList<String>();

        private zzf() {
        }

        public zze zzcle() {
            return new zze(this.aLO, this.aLP, this.aLQ, this.aLR, this.aMx, this.aMy, this.aMz, this.aMA, this.aMB, this.aMC);
        }

        public zzf zzd(zza zza2) {
            this.aLO.add(zza2);
            return this;
        }

        public zzf zze(zza zza2) {
            this.aLP.add(zza2);
            return this;
        }

        public zzf zzf(zza zza2) {
            this.aLQ.add(zza2);
            return this;
        }

        public zzf zzg(zza zza2) {
            this.aLR.add(zza2);
            return this;
        }

        public zzf zzh(zza zza2) {
            this.aMx.add(zza2);
            return this;
        }

        public zzf zzi(zza zza2) {
            this.aMy.add(zza2);
            return this;
        }

        public zzf zzrj(String string2) {
            this.aMB.add(string2);
            return this;
        }

        public zzf zzrk(String string2) {
            this.aMC.add(string2);
            return this;
        }

        public zzf zzrl(String string2) {
            this.aMz.add(string2);
            return this;
        }

        public zzf zzrm(String string2) {
            this.aMA.add(string2);
            return this;
        }
    }

    public static class zzg
    extends Exception {
        public zzg(String string2) {
            super(string2);
        }
    }

}

