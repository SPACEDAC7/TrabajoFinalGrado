/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import java.io.IOException;
import java.io.InputStream;

public interface zzafz {
    public void close();

    public InputStream zzqz(String var1) throws IOException;
}

