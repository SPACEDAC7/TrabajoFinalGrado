/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import com.google.android.gms.internal.zzafy;
import com.google.android.gms.internal.zzafz;

public class zzaga {
    public zzafz zzclf() {
        return new zzafy();
    }
}

