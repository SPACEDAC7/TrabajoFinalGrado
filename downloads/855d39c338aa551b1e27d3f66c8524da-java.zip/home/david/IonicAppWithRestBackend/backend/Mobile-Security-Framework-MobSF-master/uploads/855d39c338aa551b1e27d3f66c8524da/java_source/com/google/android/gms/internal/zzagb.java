/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import java.io.IOException;

public class zzagb
extends IOException {
    public zzagb(String string2) {
        super(string2);
    }
}

