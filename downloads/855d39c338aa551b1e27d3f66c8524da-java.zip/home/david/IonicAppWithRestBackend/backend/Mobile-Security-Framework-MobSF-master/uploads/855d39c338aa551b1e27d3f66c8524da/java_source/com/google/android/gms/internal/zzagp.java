/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.database.ContentObserver
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Handler
 *  android.os.Looper
 */
package com.google.android.gms.internal;

import android.content.ContentResolver;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

public class zzagp {
    public static final Uri CONTENT_URI = Uri.parse((String)"content://com.google.android.gsf.gservices");
    public static final Uri aVg = Uri.parse((String)"content://com.google.android.gsf.gservices/prefix");
    public static final Pattern aVh = Pattern.compile("^(1|true|t|on|yes|y)$", 2);
    public static final Pattern aVi = Pattern.compile("^(0|false|f|off|no|n)$", 2);
    private static final AtomicBoolean aVj = new AtomicBoolean();
    static HashMap<String, String> aVk;
    private static Object aVl;
    private static boolean aVm;
    static String[] aVn;

    static {
        aVn = new String[0];
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static long getLong(ContentResolver object, String string2, long l) {
        object = zzagp.getString((ContentResolver)object, string2);
        long l2 = l;
        if (object == null) return l2;
        try {
            return Long.parseLong((String)object);
        }
        catch (NumberFormatException numberFormatException) {
            return l;
        }
    }

    @Deprecated
    public static String getString(ContentResolver contentResolver, String string2) {
        return zzagp.zza(contentResolver, string2, null);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static String zza(ContentResolver var0, String var1_2, String var2_3) {
        // MONITORENTER : com.google.android.gms.internal.zzagp.class
        zzagp.zza((ContentResolver)var0);
        var7_4 = zzagp.aVl;
        if (zzagp.aVk.containsKey(var1_2)) {
            var0 = zzagp.aVk.get(var1_2);
            if (var0 != null) {
                var2_3 = var0;
            }
            // MONITOREXIT : com.google.android.gms.internal.zzagp.class
            return var2_3;
        }
        var5_5 = zzagp.aVn;
        var4_6 = var5_5.length;
        var3_7 = 0;
        do {
            block16 : {
                if (var3_7 >= var4_6) ** GOTO lbl27
                if (var1_2.startsWith(var5_5[var3_7])) {
                    if (!zzagp.aVm || zzagp.aVk.isEmpty()) {
                        zzagp.zzc((ContentResolver)var0, zzagp.aVn);
                        if (zzagp.aVk.containsKey(var1_2)) {
                            var0 = zzagp.aVk.get(var1_2);
                            if (var0 != null) {
                                var2_3 = var0;
                            }
                            // MONITOREXIT : com.google.android.gms.internal.zzagp.class
                            return var2_3;
                        }
                    }
                    // MONITOREXIT : com.google.android.gms.internal.zzagp.class
                    return var2_3;
                }
                ** GOTO lbl55
lbl27: // 1 sources:
                // MONITOREXIT : com.google.android.gms.internal.zzagp.class
                var6_8 = var0.query(zzagp.CONTENT_URI, null, null, new String[]{var1_2}, null);
                if (var6_8 == null) ** GOTO lbl32
                try {
                    if (var6_8.moveToFirst()) break block16;
lbl32: // 2 sources:
                    zzagp.zza(var7_4, var1_2, null);
                    var0 = var2_3;
                    if (var6_8 == null) return var0;
                }
                catch (Throwable var0_1) {
                    if (var6_8 == null) throw var0_1;
                    var6_8.close();
                    throw var0_1;
                }
                var6_8.close();
                return var2_3;
            }
            var0 = var5_5 = var6_8.getString(1);
            if (var5_5 != null) {
                var0 = var5_5;
                if (var5_5.equals(var2_3)) {
                    var0 = var2_3;
                }
            }
            zzagp.zza(var7_4, var1_2, (String)var0);
            if (var0 != null) {
                var2_3 = var0;
            }
            var0 = var2_3;
            if (var6_8 == null) return var0;
            var6_8.close();
            return var2_3;
lbl55: // 1 sources:
            ++var3_7;
        } while (true);
    }

    public static /* varargs */ Map<String, String> zza(ContentResolver contentResolver, String ... object) {
        contentResolver = contentResolver.query(aVg, null, null, (String[])object, null);
        object = new TreeMap();
        if (contentResolver == null) {
            return object;
        }
        try {
            while (contentResolver.moveToNext()) {
                object.put(contentResolver.getString(0), contentResolver.getString(1));
            }
        }
        finally {
            contentResolver.close();
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void zza(ContentResolver contentResolver) {
        if (aVk == null) {
            aVj.set(false);
            aVk = new HashMap();
            aVl = new Object();
            aVm = false;
            contentResolver.registerContentObserver(CONTENT_URI, true, new ContentObserver(new Handler(Looper.getMainLooper())){

                public void onChange(boolean bl) {
                    aVj.set(true);
                }
            });
            return;
        } else {
            if (!aVj.getAndSet(false)) return;
            {
                aVk.clear();
                aVl = new Object();
                aVm = false;
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void zza(Object object, String string2, String string3) {
        synchronized (zzagp.class) {
            if (object == aVl) {
                aVk.put(string2, string3);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static /* varargs */ void zzb(ContentResolver contentResolver, String ... arrstring) {
        if (arrstring.length == 0) {
            return;
        }
        synchronized (zzagp.class) {
            zzagp.zza(contentResolver);
            arrstring = zzagp.zzk(arrstring);
            if (!aVm || aVk.isEmpty()) {
                zzagp.zzc(contentResolver, aVn);
            } else if (arrstring.length != 0) {
                zzagp.zzc(contentResolver, arrstring);
            }
            return;
        }
    }

    private static void zzc(ContentResolver contentResolver, String[] arrstring) {
        aVk.putAll(zzagp.zza(contentResolver, arrstring));
        aVm = true;
    }

    private static String[] zzk(String[] arrstring) {
        HashSet<String> hashSet = new HashSet<String>((aVn.length + arrstring.length) * 4 / 3 + 1);
        hashSet.addAll(Arrays.asList(aVn));
        ArrayList<String> arrayList = new ArrayList<String>();
        for (String string2 : arrstring) {
            if (!hashSet.add(string2)) continue;
            arrayList.add(string2);
        }
        if (arrayList.isEmpty()) {
            return new String[0];
        }
        aVn = hashSet.toArray(new String[hashSet.size()]);
        return arrayList.toArray(new String[arrayList.size()]);
    }

}

