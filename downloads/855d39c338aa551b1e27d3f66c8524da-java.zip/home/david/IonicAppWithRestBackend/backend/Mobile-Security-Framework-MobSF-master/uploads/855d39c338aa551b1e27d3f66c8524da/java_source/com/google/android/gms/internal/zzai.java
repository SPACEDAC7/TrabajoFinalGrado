/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import com.google.android.gms.internal.zzaj;
import com.google.android.gms.internal.zzars;
import com.google.android.gms.internal.zzart;
import com.google.android.gms.internal.zzaru;
import com.google.android.gms.internal.zzarv;
import com.google.android.gms.internal.zzarw;
import com.google.android.gms.internal.zzary;
import com.google.android.gms.internal.zzarz;
import com.google.android.gms.internal.zzasa;
import com.google.android.gms.internal.zzasd;
import java.io.IOException;

public interface zzai {

    public static final class zza
    extends zzaru<zza> {
        public int level;
        public int zzvr;
        public int zzvs;

        public zza() {
            this.zzac();
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zza)) return bl2;
            object = (zza)object;
            bl2 = bl;
            if (this.level != object.level) return bl2;
            bl2 = bl;
            if (this.zzvr != object.zzvr) return bl2;
            bl2 = bl;
            if (this.zzvs != object.zzvs) return bl2;
            if (this.btG != null) {
                if (!this.btG.isEmpty()) return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public int hashCode() {
            int n;
            int n2 = this.getClass().getName().hashCode();
            int n3 = this.level;
            int n4 = this.zzvr;
            int n5 = this.zzvs;
            if (this.btG == null || this.btG.isEmpty()) {
                n = 0;
                do {
                    return n + ((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31;
                    break;
                } while (true);
            }
            n = this.btG.hashCode();
            return n + ((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.level != 1) {
                zzart2.zzaf(1, this.level);
            }
            if (this.zzvr != 0) {
                zzart2.zzaf(2, this.zzvr);
            }
            if (this.zzvs != 0) {
                zzart2.zzaf(3, this.zzvs);
            }
            super.zza(zzart2);
        }

        public zza zzac() {
            this.level = 1;
            this.zzvr = 0;
            this.zzvs = 0;
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzn(zzars2);
        }

        public zza zzn(zzars zzars2) throws IOException {
            block9 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block9;
                    }
                    case 0: {
                        return this;
                    }
                    case 8: {
                        n = zzars2.bY();
                        switch (n) {
                            default: {
                                continue block9;
                            }
                            case 1: 
                            case 2: 
                            case 3: 
                        }
                        this.level = n;
                        continue block9;
                    }
                    case 16: {
                        this.zzvr = zzars2.bY();
                        continue block9;
                    }
                    case 24: 
                }
                this.zzvs = zzars2.bY();
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.level != 1) {
                n2 = n + zzart.zzah(1, this.level);
            }
            n = n2;
            if (this.zzvr != 0) {
                n = n2 + zzart.zzah(2, this.zzvr);
            }
            n2 = n;
            if (this.zzvs != 0) {
                n2 = n + zzart.zzah(3, this.zzvs);
            }
            return n2;
        }
    }

    public static final class zzb
    extends zzaru<zzb> {
        private static volatile zzb[] zzvt;
        public int name;
        public int[] zzvu;
        public int zzvv;
        public boolean zzvw;
        public boolean zzvx;

        public zzb() {
            this.zzae();
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public static zzb[] zzad() {
            if (zzvt == null) {
                Object object = zzary.btO;
                synchronized (object) {
                    if (zzvt == null) {
                        zzvt = new zzb[0];
                    }
                }
            }
            return zzvt;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zzb)) return bl2;
            object = (zzb)object;
            bl2 = bl;
            if (!zzary.equals(this.zzvu, object.zzvu)) return bl2;
            bl2 = bl;
            if (this.zzvv != object.zzvv) return bl2;
            bl2 = bl;
            if (this.name != object.name) return bl2;
            bl2 = bl;
            if (this.zzvw != object.zzvw) return bl2;
            bl2 = bl;
            if (this.zzvx != object.zzvx) return bl2;
            if (this.btG != null) {
                if (!this.btG.isEmpty()) return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        public int hashCode() {
            int n;
            int n2 = 1231;
            int n3 = this.getClass().getName().hashCode();
            int n4 = zzary.hashCode(this.zzvu);
            int n5 = this.zzvv;
            int n6 = this.name;
            int n7 = this.zzvw ? 1231 : 1237;
            if (!this.zzvx) {
                n2 = 1237;
            }
            if (this.btG != null && !this.btG.isEmpty()) {
                n = this.btG.hashCode();
                return n + ((n7 + ((((n3 + 527) * 31 + n4) * 31 + n5) * 31 + n6) * 31) * 31 + n2) * 31;
            }
            n = 0;
            return n + ((n7 + ((((n3 + 527) * 31 + n4) * 31 + n5) * 31 + n6) * 31) * 31 + n2) * 31;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzvx) {
                zzart2.zzg(1, this.zzvx);
            }
            zzart2.zzaf(2, this.zzvv);
            if (this.zzvu != null && this.zzvu.length > 0) {
                for (int i = 0; i < this.zzvu.length; ++i) {
                    zzart2.zzaf(3, this.zzvu[i]);
                }
            }
            if (this.name != 0) {
                zzart2.zzaf(4, this.name);
            }
            if (this.zzvw) {
                zzart2.zzg(6, this.zzvw);
            }
            super.zza(zzart2);
        }

        public zzb zzae() {
            this.zzvu = zzasd.btR;
            this.zzvv = 0;
            this.name = 0;
            this.zzvw = false;
            this.zzvx = false;
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzo(zzars2);
        }

        /*
         * Enabled aggressive block sorting
         */
        public zzb zzo(zzars zzars2) throws IOException {
            block9 : do {
                int n = zzars2.bU();
                switch (n) {
                    int[] arrn;
                    int n2;
                    default: {
                        if (super.zza(zzars2, n)) continue block9;
                    }
                    case 0: {
                        return this;
                    }
                    case 8: {
                        this.zzvx = zzars2.ca();
                        continue block9;
                    }
                    case 16: {
                        this.zzvv = zzars2.bY();
                        continue block9;
                    }
                    case 24: {
                        n2 = zzasd.zzc(zzars2, 24);
                        n = this.zzvu == null ? 0 : this.zzvu.length;
                        arrn = new int[n2 + n];
                        n2 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzvu, 0, arrn, 0, n);
                            n2 = n;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzvu = arrn;
                        continue block9;
                    }
                    case 26: {
                        int n3 = zzars2.zzagt(zzars2.cd());
                        n = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n);
                        n = this.zzvu == null ? 0 : this.zzvu.length;
                        arrn = new int[n2 + n];
                        n2 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzvu, 0, arrn, 0, n);
                            n2 = n;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzvu = arrn;
                        zzars2.zzagu(n3);
                        continue block9;
                    }
                    case 32: {
                        this.name = zzars2.bY();
                        continue block9;
                    }
                    case 48: 
                }
                this.zzvw = zzars2.ca();
            } while (true);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        protected int zzx() {
            int n;
            int n2 = 0;
            int n3 = n = super.zzx();
            if (this.zzvx) {
                n3 = n + zzart.zzh(1, this.zzvx);
            }
            n = zzart.zzah(2, this.zzvv) + n3;
            if (this.zzvu != null && this.zzvu.length > 0) {
                for (n3 = 0; n3 < this.zzvu.length; n2 += zzart.zzagz((int)this.zzvu[n3]), ++n3) {
                }
                n2 = n + n2 + this.zzvu.length * 1;
            } else {
                n2 = n;
            }
            n3 = n2;
            if (this.name != 0) {
                n3 = n2 + zzart.zzah(4, this.name);
            }
            n2 = n3;
            if (!this.zzvw) return n2;
            return n3 + zzart.zzh(6, this.zzvw);
        }
    }

    public static final class zzc
    extends zzaru<zzc> {
        private static volatile zzc[] zzvy;
        public String zzcb;
        public long zzvz;
        public long zzwa;
        public boolean zzwb;
        public long zzwc;

        public zzc() {
            this.zzag();
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public static zzc[] zzaf() {
            if (zzvy == null) {
                Object object = zzary.btO;
                synchronized (object) {
                    if (zzvy == null) {
                        zzvy = new zzc[0];
                    }
                }
            }
            return zzvy;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zzc)) return bl2;
            object = (zzc)object;
            if (this.zzcb == null) {
                bl2 = bl;
                if (object.zzcb != null) return bl2;
            } else if (!this.zzcb.equals(object.zzcb)) {
                return false;
            }
            bl2 = bl;
            if (this.zzvz != object.zzvz) return bl2;
            bl2 = bl;
            if (this.zzwa != object.zzwa) return bl2;
            bl2 = bl;
            if (this.zzwb != object.zzwb) return bl2;
            bl2 = bl;
            if (this.zzwc != object.zzwc) return bl2;
            if (this.btG != null && !this.btG.isEmpty()) {
                return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        public int hashCode() {
            int n = 0;
            int n2 = this.getClass().getName().hashCode();
            int n3 = this.zzcb == null ? 0 : this.zzcb.hashCode();
            int n4 = (int)(this.zzvz ^ this.zzvz >>> 32);
            int n5 = (int)(this.zzwa ^ this.zzwa >>> 32);
            int n6 = this.zzwb ? 1231 : 1237;
            int n7 = (int)(this.zzwc ^ this.zzwc >>> 32);
            int n8 = n;
            if (this.btG == null) return ((n6 + (((n3 + (n2 + 527) * 31) * 31 + n4) * 31 + n5) * 31) * 31 + n7) * 31 + n8;
            if (this.btG.isEmpty()) {
                n8 = n;
                return ((n6 + (((n3 + (n2 + 527) * 31) * 31 + n4) * 31 + n5) * 31) * 31 + n7) * 31 + n8;
            }
            n8 = this.btG.hashCode();
            return ((n6 + (((n3 + (n2 + 527) * 31) * 31 + n4) * 31 + n5) * 31) * 31 + n7) * 31 + n8;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzcb != null && !this.zzcb.equals("")) {
                zzart2.zzq(1, this.zzcb);
            }
            if (this.zzvz != 0) {
                zzart2.zzb(2, this.zzvz);
            }
            if (this.zzwa != Integer.MAX_VALUE) {
                zzart2.zzb(3, this.zzwa);
            }
            if (this.zzwb) {
                zzart2.zzg(4, this.zzwb);
            }
            if (this.zzwc != 0) {
                zzart2.zzb(5, this.zzwc);
            }
            super.zza(zzart2);
        }

        public zzc zzag() {
            this.zzcb = "";
            this.zzvz = 0;
            this.zzwa = Integer.MAX_VALUE;
            this.zzwb = false;
            this.zzwc = 0;
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzp(zzars2);
        }

        public zzc zzp(zzars zzars2) throws IOException {
            block8 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block8;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        this.zzcb = zzars2.readString();
                        continue block8;
                    }
                    case 16: {
                        this.zzvz = zzars2.bX();
                        continue block8;
                    }
                    case 24: {
                        this.zzwa = zzars2.bX();
                        continue block8;
                    }
                    case 32: {
                        this.zzwb = zzars2.ca();
                        continue block8;
                    }
                    case 40: 
                }
                this.zzwc = zzars2.bX();
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.zzcb != null) {
                n2 = n;
                if (!this.zzcb.equals("")) {
                    n2 = n + zzart.zzr(1, this.zzcb);
                }
            }
            n = n2;
            if (this.zzvz != 0) {
                n = n2 + zzart.zzf(2, this.zzvz);
            }
            n2 = n;
            if (this.zzwa != Integer.MAX_VALUE) {
                n2 = n + zzart.zzf(3, this.zzwa);
            }
            n = n2;
            if (this.zzwb) {
                n = n2 + zzart.zzh(4, this.zzwb);
            }
            n2 = n;
            if (this.zzwc != 0) {
                n2 = n + zzart.zzf(5, this.zzwc);
            }
            return n2;
        }
    }

    public static final class zzd
    extends zzaru<zzd> {
        public zzaj.zza[] zzwd;
        public zzaj.zza[] zzwe;
        public zzc[] zzwf;

        public zzd() {
            this.zzah();
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zzd)) return bl2;
            object = (zzd)object;
            bl2 = bl;
            if (!zzary.equals(this.zzwd, object.zzwd)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwe, object.zzwe)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwf, object.zzwf)) return bl2;
            if (this.btG != null) {
                if (!this.btG.isEmpty()) return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public int hashCode() {
            int n;
            int n2 = this.getClass().getName().hashCode();
            int n3 = zzary.hashCode(this.zzwd);
            int n4 = zzary.hashCode(this.zzwe);
            int n5 = zzary.hashCode(this.zzwf);
            if (this.btG == null || this.btG.isEmpty()) {
                n = 0;
                do {
                    return n + ((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31;
                    break;
                } while (true);
            }
            n = this.btG.hashCode();
            return n + ((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            int n;
            int n2 = 0;
            if (this.zzwd != null && this.zzwd.length > 0) {
                for (n = 0; n < this.zzwd.length; ++n) {
                    zzaj.zza zza2 = this.zzwd[n];
                    if (zza2 == null) continue;
                    zzart2.zza(1, zza2);
                }
            }
            if (this.zzwe != null && this.zzwe.length > 0) {
                for (n = 0; n < this.zzwe.length; ++n) {
                    zzaj.zza zza2 = this.zzwe[n];
                    if (zza2 == null) continue;
                    zzart2.zza(2, zza2);
                }
            }
            if (this.zzwf != null && this.zzwf.length > 0) {
                for (n = n2; n < this.zzwf.length; ++n) {
                    zzc zzc2 = this.zzwf[n];
                    if (zzc2 == null) continue;
                    zzart2.zza(3, zzc2);
                }
            }
            super.zza(zzart2);
        }

        public zzd zzah() {
            this.zzwd = zzaj.zza.zzar();
            this.zzwe = zzaj.zza.zzar();
            this.zzwf = zzc.zzaf();
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzq(zzars2);
        }

        /*
         * Enabled aggressive block sorting
         */
        public zzd zzq(zzars zzars2) throws IOException {
            block6 : do {
                zzaj.zza[] arrzza;
                int n;
                int n2 = zzars2.bU();
                switch (n2) {
                    default: {
                        if (super.zza(zzars2, n2)) continue block6;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        n = zzasd.zzc(zzars2, 10);
                        n2 = this.zzwd == null ? 0 : this.zzwd.length;
                        arrzza = new zzaj.zza[n + n2];
                        n = n2;
                        if (n2 != 0) {
                            System.arraycopy(this.zzwd, 0, arrzza, 0, n2);
                            n = n2;
                        }
                        while (n < arrzza.length - 1) {
                            arrzza[n] = new zzaj.zza();
                            zzars2.zza(arrzza[n]);
                            zzars2.bU();
                            ++n;
                        }
                        arrzza[n] = new zzaj.zza();
                        zzars2.zza(arrzza[n]);
                        this.zzwd = arrzza;
                        continue block6;
                    }
                    case 18: {
                        n = zzasd.zzc(zzars2, 18);
                        n2 = this.zzwe == null ? 0 : this.zzwe.length;
                        arrzza = new zzaj.zza[n + n2];
                        n = n2;
                        if (n2 != 0) {
                            System.arraycopy(this.zzwe, 0, arrzza, 0, n2);
                            n = n2;
                        }
                        while (n < arrzza.length - 1) {
                            arrzza[n] = new zzaj.zza();
                            zzars2.zza(arrzza[n]);
                            zzars2.bU();
                            ++n;
                        }
                        arrzza[n] = new zzaj.zza();
                        zzars2.zza(arrzza[n]);
                        this.zzwe = arrzza;
                        continue block6;
                    }
                    case 26: 
                }
                n = zzasd.zzc(zzars2, 26);
                n2 = this.zzwf == null ? 0 : this.zzwf.length;
                arrzza = new zzc[n + n2];
                n = n2;
                if (n2 != 0) {
                    System.arraycopy(this.zzwf, 0, arrzza, 0, n2);
                    n = n2;
                }
                while (n < arrzza.length - 1) {
                    arrzza[n] = new zzc();
                    zzars2.zza(arrzza[n]);
                    zzars2.bU();
                    ++n;
                }
                arrzza[n] = new zzc();
                zzars2.zza(arrzza[n]);
                this.zzwf = arrzza;
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2;
            int n3 = 0;
            int n4 = n2 = super.zzx();
            if (this.zzwd != null) {
                n4 = n2;
                if (this.zzwd.length > 0) {
                    for (n4 = 0; n4 < this.zzwd.length; ++n4) {
                        zzaj.zza zza2 = this.zzwd[n4];
                        n = n2;
                        if (zza2 != null) {
                            n = n2 + zzart.zzc(1, zza2);
                        }
                        n2 = n;
                    }
                    n4 = n2;
                }
            }
            n2 = n4;
            if (this.zzwe != null) {
                n2 = n4;
                if (this.zzwe.length > 0) {
                    n2 = n4;
                    for (n4 = 0; n4 < this.zzwe.length; ++n4) {
                        zzaj.zza zza2 = this.zzwe[n4];
                        n = n2;
                        if (zza2 != null) {
                            n = n2 + zzart.zzc(2, zza2);
                        }
                        n2 = n;
                    }
                }
            }
            n = n2;
            if (this.zzwf != null) {
                n = n2;
                if (this.zzwf.length > 0) {
                    n4 = n3;
                    do {
                        n = n2;
                        if (n4 >= this.zzwf.length) break;
                        zzc zzc2 = this.zzwf[n4];
                        n = n2;
                        if (zzc2 != null) {
                            n = n2 + zzart.zzc(3, zzc2);
                        }
                        ++n4;
                        n2 = n;
                    } while (true);
                }
            }
            return n;
        }
    }

    public static final class zze
    extends zzaru<zze> {
        private static volatile zze[] zzwg;
        public int key;
        public int value;

        public zze() {
            this.zzaj();
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public static zze[] zzai() {
            if (zzwg == null) {
                Object object = zzary.btO;
                synchronized (object) {
                    if (zzwg == null) {
                        zzwg = new zze[0];
                    }
                }
            }
            return zzwg;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zze)) return bl2;
            object = (zze)object;
            bl2 = bl;
            if (this.key != object.key) return bl2;
            bl2 = bl;
            if (this.value != object.value) return bl2;
            if (this.btG != null) {
                if (!this.btG.isEmpty()) return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public int hashCode() {
            int n;
            int n2 = this.getClass().getName().hashCode();
            int n3 = this.key;
            int n4 = this.value;
            if (this.btG == null || this.btG.isEmpty()) {
                n = 0;
                do {
                    return n + (((n2 + 527) * 31 + n3) * 31 + n4) * 31;
                    break;
                } while (true);
            }
            n = this.btG.hashCode();
            return n + (((n2 + 527) * 31 + n3) * 31 + n4) * 31;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            zzart2.zzaf(1, this.key);
            zzart2.zzaf(2, this.value);
            super.zza(zzart2);
        }

        public zze zzaj() {
            this.key = 0;
            this.value = 0;
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzr(zzars2);
        }

        public zze zzr(zzars zzars2) throws IOException {
            block5 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block5;
                    }
                    case 0: {
                        return this;
                    }
                    case 8: {
                        this.key = zzars2.bY();
                        continue block5;
                    }
                    case 16: 
                }
                this.value = zzars2.bY();
            } while (true);
        }

        @Override
        protected int zzx() {
            return super.zzx() + zzart.zzah(1, this.key) + zzart.zzah(2, this.value);
        }
    }

    public static final class zzf
    extends zzaru<zzf> {
        public String version;
        public String[] zzwh;
        public String[] zzwi;
        public zzaj.zza[] zzwj;
        public zze[] zzwk;
        public zzb[] zzwl;
        public zzb[] zzwm;
        public zzb[] zzwn;
        public zzg[] zzwo;
        public String zzwp;
        public String zzwq;
        public String zzwr;
        public zza zzws;
        public float zzwt;
        public boolean zzwu;
        public String[] zzwv;
        public int zzww;

        public zzf() {
            this.zzak();
        }

        public static zzf zzf(byte[] arrby) throws zzarz {
            return zzasa.zza(new zzf(), arrby);
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zzf)) return bl2;
            object = (zzf)object;
            bl2 = bl;
            if (!zzary.equals(this.zzwh, object.zzwh)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwi, object.zzwi)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwj, object.zzwj)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwk, object.zzwk)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwl, object.zzwl)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwm, object.zzwm)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwn, object.zzwn)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwo, object.zzwo)) return bl2;
            if (this.zzwp == null) {
                bl2 = bl;
                if (object.zzwp != null) return bl2;
            } else if (!this.zzwp.equals(object.zzwp)) {
                return false;
            }
            if (this.zzwq == null) {
                bl2 = bl;
                if (object.zzwq != null) return bl2;
            } else if (!this.zzwq.equals(object.zzwq)) {
                return false;
            }
            if (this.zzwr == null) {
                bl2 = bl;
                if (object.zzwr != null) return bl2;
            } else if (!this.zzwr.equals(object.zzwr)) {
                return false;
            }
            if (this.version == null) {
                bl2 = bl;
                if (object.version != null) return bl2;
            } else if (!this.version.equals(object.version)) {
                return false;
            }
            if (this.zzws == null) {
                bl2 = bl;
                if (object.zzws != null) return bl2;
            } else if (!this.zzws.equals(object.zzws)) {
                return false;
            }
            bl2 = bl;
            if (Float.floatToIntBits(this.zzwt) != Float.floatToIntBits(object.zzwt)) return bl2;
            bl2 = bl;
            if (this.zzwu != object.zzwu) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwv, object.zzwv)) return bl2;
            bl2 = bl;
            if (this.zzww != object.zzww) return bl2;
            if (this.btG != null && !this.btG.isEmpty()) {
                return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        public int hashCode() {
            int n = 0;
            int n2 = this.getClass().getName().hashCode();
            int n3 = zzary.hashCode(this.zzwh);
            int n4 = zzary.hashCode(this.zzwi);
            int n5 = zzary.hashCode(this.zzwj);
            int n6 = zzary.hashCode(this.zzwk);
            int n7 = zzary.hashCode(this.zzwl);
            int n8 = zzary.hashCode(this.zzwm);
            int n9 = zzary.hashCode(this.zzwn);
            int n10 = zzary.hashCode(this.zzwo);
            int n11 = this.zzwp == null ? 0 : this.zzwp.hashCode();
            int n12 = this.zzwq == null ? 0 : this.zzwq.hashCode();
            int n13 = this.zzwr == null ? 0 : this.zzwr.hashCode();
            int n14 = this.version == null ? 0 : this.version.hashCode();
            int n15 = this.zzws == null ? 0 : this.zzws.hashCode();
            int n16 = Float.floatToIntBits(this.zzwt);
            int n17 = this.zzwu ? 1231 : 1237;
            int n18 = zzary.hashCode(this.zzwv);
            int n19 = this.zzww;
            int n20 = n;
            if (this.btG == null) return (((n17 + ((n15 + (n14 + (n13 + (n12 + (n11 + (((((((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31 + n6) * 31 + n7) * 31 + n8) * 31 + n9) * 31 + n10) * 31) * 31) * 31) * 31) * 31) * 31 + n16) * 31) * 31 + n18) * 31 + n19) * 31 + n20;
            if (this.btG.isEmpty()) {
                n20 = n;
                return (((n17 + ((n15 + (n14 + (n13 + (n12 + (n11 + (((((((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31 + n6) * 31 + n7) * 31 + n8) * 31 + n9) * 31 + n10) * 31) * 31) * 31) * 31) * 31) * 31 + n16) * 31) * 31 + n18) * 31 + n19) * 31 + n20;
            }
            n20 = this.btG.hashCode();
            return (((n17 + ((n15 + (n14 + (n13 + (n12 + (n11 + (((((((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31 + n6) * 31 + n7) * 31 + n8) * 31 + n9) * 31 + n10) * 31) * 31) * 31) * 31) * 31) * 31 + n16) * 31) * 31 + n18) * 31 + n19) * 31 + n20;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            Object object;
            int n;
            int n2 = 0;
            if (this.zzwi != null && this.zzwi.length > 0) {
                for (n = 0; n < this.zzwi.length; ++n) {
                    object = this.zzwi[n];
                    if (object == null) continue;
                    zzart2.zzq(1, (String)object);
                }
            }
            if (this.zzwj != null && this.zzwj.length > 0) {
                for (n = 0; n < this.zzwj.length; ++n) {
                    object = this.zzwj[n];
                    if (object == null) continue;
                    zzart2.zza(2, (zzasa)object);
                }
            }
            if (this.zzwk != null && this.zzwk.length > 0) {
                for (n = 0; n < this.zzwk.length; ++n) {
                    object = this.zzwk[n];
                    if (object == null) continue;
                    zzart2.zza(3, (zzasa)object);
                }
            }
            if (this.zzwl != null && this.zzwl.length > 0) {
                for (n = 0; n < this.zzwl.length; ++n) {
                    object = this.zzwl[n];
                    if (object == null) continue;
                    zzart2.zza(4, (zzasa)object);
                }
            }
            if (this.zzwm != null && this.zzwm.length > 0) {
                for (n = 0; n < this.zzwm.length; ++n) {
                    object = this.zzwm[n];
                    if (object == null) continue;
                    zzart2.zza(5, (zzasa)object);
                }
            }
            if (this.zzwn != null && this.zzwn.length > 0) {
                for (n = 0; n < this.zzwn.length; ++n) {
                    object = this.zzwn[n];
                    if (object == null) continue;
                    zzart2.zza(6, (zzasa)object);
                }
            }
            if (this.zzwo != null && this.zzwo.length > 0) {
                for (n = 0; n < this.zzwo.length; ++n) {
                    object = this.zzwo[n];
                    if (object == null) continue;
                    zzart2.zza(7, (zzasa)object);
                }
            }
            if (this.zzwp != null && !this.zzwp.equals("")) {
                zzart2.zzq(9, this.zzwp);
            }
            if (this.zzwq != null && !this.zzwq.equals("")) {
                zzart2.zzq(10, this.zzwq);
            }
            if (this.zzwr != null && !this.zzwr.equals("0")) {
                zzart2.zzq(12, this.zzwr);
            }
            if (this.version != null && !this.version.equals("")) {
                zzart2.zzq(13, this.version);
            }
            if (this.zzws != null) {
                zzart2.zza(14, this.zzws);
            }
            if (Float.floatToIntBits(this.zzwt) != Float.floatToIntBits(0.0f)) {
                zzart2.zzc(15, this.zzwt);
            }
            if (this.zzwv != null && this.zzwv.length > 0) {
                for (n = 0; n < this.zzwv.length; ++n) {
                    object = this.zzwv[n];
                    if (object == null) continue;
                    zzart2.zzq(16, (String)object);
                }
            }
            if (this.zzww != 0) {
                zzart2.zzaf(17, this.zzww);
            }
            if (this.zzwu) {
                zzart2.zzg(18, this.zzwu);
            }
            if (this.zzwh != null && this.zzwh.length > 0) {
                for (n = n2; n < this.zzwh.length; ++n) {
                    object = this.zzwh[n];
                    if (object == null) continue;
                    zzart2.zzq(19, (String)object);
                }
            }
            super.zza(zzart2);
        }

        public zzf zzak() {
            this.zzwh = zzasd.btW;
            this.zzwi = zzasd.btW;
            this.zzwj = zzaj.zza.zzar();
            this.zzwk = zze.zzai();
            this.zzwl = zzb.zzad();
            this.zzwm = zzb.zzad();
            this.zzwn = zzb.zzad();
            this.zzwo = zzg.zzal();
            this.zzwp = "";
            this.zzwq = "";
            this.zzwr = "0";
            this.version = "";
            this.zzws = null;
            this.zzwt = 0.0f;
            this.zzwu = false;
            this.zzwv = zzasd.btW;
            this.zzww = 0;
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzs(zzars2);
        }

        /*
         * Enabled aggressive block sorting
         */
        public zzf zzs(zzars zzars2) throws IOException {
            block20 : do {
                String[] arrstring;
                int n;
                int n2 = zzars2.bU();
                switch (n2) {
                    default: {
                        if (super.zza(zzars2, n2)) continue block20;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        n = zzasd.zzc(zzars2, 10);
                        n2 = this.zzwi == null ? 0 : this.zzwi.length;
                        arrstring = new String[n + n2];
                        n = n2;
                        if (n2 != 0) {
                            System.arraycopy(this.zzwi, 0, arrstring, 0, n2);
                            n = n2;
                        }
                        while (n < arrstring.length - 1) {
                            arrstring[n] = zzars2.readString();
                            zzars2.bU();
                            ++n;
                        }
                        arrstring[n] = zzars2.readString();
                        this.zzwi = arrstring;
                        continue block20;
                    }
                    case 18: {
                        n = zzasd.zzc(zzars2, 18);
                        n2 = this.zzwj == null ? 0 : this.zzwj.length;
                        arrstring = new zzaj.zza[n + n2];
                        n = n2;
                        if (n2 != 0) {
                            System.arraycopy(this.zzwj, 0, arrstring, 0, n2);
                            n = n2;
                        }
                        while (n < arrstring.length - 1) {
                            arrstring[n] = new zzaj.zza();
                            zzars2.zza((zzasa)((Object)arrstring[n]));
                            zzars2.bU();
                            ++n;
                        }
                        arrstring[n] = new zzaj.zza();
                        zzars2.zza((zzasa)((Object)arrstring[n]));
                        this.zzwj = arrstring;
                        continue block20;
                    }
                    case 26: {
                        n = zzasd.zzc(zzars2, 26);
                        n2 = this.zzwk == null ? 0 : this.zzwk.length;
                        arrstring = new zze[n + n2];
                        n = n2;
                        if (n2 != 0) {
                            System.arraycopy(this.zzwk, 0, arrstring, 0, n2);
                            n = n2;
                        }
                        while (n < arrstring.length - 1) {
                            arrstring[n] = new zze();
                            zzars2.zza((zzasa)((Object)arrstring[n]));
                            zzars2.bU();
                            ++n;
                        }
                        arrstring[n] = new zze();
                        zzars2.zza((zzasa)((Object)arrstring[n]));
                        this.zzwk = arrstring;
                        continue block20;
                    }
                    case 34: {
                        n = zzasd.zzc(zzars2, 34);
                        n2 = this.zzwl == null ? 0 : this.zzwl.length;
                        arrstring = new zzb[n + n2];
                        n = n2;
                        if (n2 != 0) {
                            System.arraycopy(this.zzwl, 0, arrstring, 0, n2);
                            n = n2;
                        }
                        while (n < arrstring.length - 1) {
                            arrstring[n] = new zzb();
                            zzars2.zza((zzasa)((Object)arrstring[n]));
                            zzars2.bU();
                            ++n;
                        }
                        arrstring[n] = new zzb();
                        zzars2.zza((zzasa)((Object)arrstring[n]));
                        this.zzwl = arrstring;
                        continue block20;
                    }
                    case 42: {
                        n = zzasd.zzc(zzars2, 42);
                        n2 = this.zzwm == null ? 0 : this.zzwm.length;
                        arrstring = new zzb[n + n2];
                        n = n2;
                        if (n2 != 0) {
                            System.arraycopy(this.zzwm, 0, arrstring, 0, n2);
                            n = n2;
                        }
                        while (n < arrstring.length - 1) {
                            arrstring[n] = new zzb();
                            zzars2.zza((zzasa)((Object)arrstring[n]));
                            zzars2.bU();
                            ++n;
                        }
                        arrstring[n] = new zzb();
                        zzars2.zza((zzasa)((Object)arrstring[n]));
                        this.zzwm = arrstring;
                        continue block20;
                    }
                    case 50: {
                        n = zzasd.zzc(zzars2, 50);
                        n2 = this.zzwn == null ? 0 : this.zzwn.length;
                        arrstring = new zzb[n + n2];
                        n = n2;
                        if (n2 != 0) {
                            System.arraycopy(this.zzwn, 0, arrstring, 0, n2);
                            n = n2;
                        }
                        while (n < arrstring.length - 1) {
                            arrstring[n] = new zzb();
                            zzars2.zza((zzasa)((Object)arrstring[n]));
                            zzars2.bU();
                            ++n;
                        }
                        arrstring[n] = new zzb();
                        zzars2.zza((zzasa)((Object)arrstring[n]));
                        this.zzwn = arrstring;
                        continue block20;
                    }
                    case 58: {
                        n = zzasd.zzc(zzars2, 58);
                        n2 = this.zzwo == null ? 0 : this.zzwo.length;
                        arrstring = new zzg[n + n2];
                        n = n2;
                        if (n2 != 0) {
                            System.arraycopy(this.zzwo, 0, arrstring, 0, n2);
                            n = n2;
                        }
                        while (n < arrstring.length - 1) {
                            arrstring[n] = new zzg();
                            zzars2.zza((zzasa)((Object)arrstring[n]));
                            zzars2.bU();
                            ++n;
                        }
                        arrstring[n] = new zzg();
                        zzars2.zza((zzasa)((Object)arrstring[n]));
                        this.zzwo = arrstring;
                        continue block20;
                    }
                    case 74: {
                        this.zzwp = zzars2.readString();
                        continue block20;
                    }
                    case 82: {
                        this.zzwq = zzars2.readString();
                        continue block20;
                    }
                    case 98: {
                        this.zzwr = zzars2.readString();
                        continue block20;
                    }
                    case 106: {
                        this.version = zzars2.readString();
                        continue block20;
                    }
                    case 114: {
                        if (this.zzws == null) {
                            this.zzws = new zza();
                        }
                        zzars2.zza(this.zzws);
                        continue block20;
                    }
                    case 125: {
                        this.zzwt = zzars2.readFloat();
                        continue block20;
                    }
                    case 130: {
                        n = zzasd.zzc(zzars2, 130);
                        n2 = this.zzwv == null ? 0 : this.zzwv.length;
                        arrstring = new String[n + n2];
                        n = n2;
                        if (n2 != 0) {
                            System.arraycopy(this.zzwv, 0, arrstring, 0, n2);
                            n = n2;
                        }
                        while (n < arrstring.length - 1) {
                            arrstring[n] = zzars2.readString();
                            zzars2.bU();
                            ++n;
                        }
                        arrstring[n] = zzars2.readString();
                        this.zzwv = arrstring;
                        continue block20;
                    }
                    case 136: {
                        this.zzww = zzars2.bY();
                        continue block20;
                    }
                    case 144: {
                        this.zzwu = zzars2.ca();
                        continue block20;
                    }
                    case 154: 
                }
                n = zzasd.zzc(zzars2, 154);
                n2 = this.zzwh == null ? 0 : this.zzwh.length;
                arrstring = new String[n + n2];
                n = n2;
                if (n2 != 0) {
                    System.arraycopy(this.zzwh, 0, arrstring, 0, n2);
                    n = n2;
                }
                while (n < arrstring.length - 1) {
                    arrstring[n] = zzars2.readString();
                    zzars2.bU();
                    ++n;
                }
                arrstring[n] = zzars2.readString();
                this.zzwh = arrstring;
            } while (true);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        protected int zzx() {
            int n;
            int n2;
            int n3;
            int n4;
            int n5;
            Object object;
            int n6 = 0;
            int n7 = super.zzx();
            if (this.zzwi != null && this.zzwi.length > 0) {
                n5 = 0;
                n = 0;
                for (n3 = 0; n3 < this.zzwi.length; ++n3) {
                    object = this.zzwi[n3];
                    n4 = n5;
                    n2 = n;
                    if (object != null) {
                        n2 = n + 1;
                        n4 = n5 + zzart.zzuy((String)object);
                    }
                    n5 = n4;
                    n = n2;
                }
                n5 = n7 + n5 + n * 1;
            } else {
                n5 = n7;
            }
            n3 = n5;
            if (this.zzwj != null) {
                n3 = n5;
                if (this.zzwj.length > 0) {
                    n3 = n5;
                    for (n5 = 0; n5 < this.zzwj.length; ++n5) {
                        object = this.zzwj[n5];
                        n = n3;
                        if (object != null) {
                            n = n3 + zzart.zzc(2, (zzasa)object);
                        }
                        n3 = n;
                    }
                }
            }
            n5 = n3;
            if (this.zzwk != null) {
                n5 = n3;
                if (this.zzwk.length > 0) {
                    for (n5 = 0; n5 < this.zzwk.length; ++n5) {
                        object = this.zzwk[n5];
                        n = n3;
                        if (object != null) {
                            n = n3 + zzart.zzc(3, (zzasa)object);
                        }
                        n3 = n;
                    }
                    n5 = n3;
                }
            }
            n3 = n5;
            if (this.zzwl != null) {
                n3 = n5;
                if (this.zzwl.length > 0) {
                    n3 = n5;
                    for (n5 = 0; n5 < this.zzwl.length; ++n5) {
                        object = this.zzwl[n5];
                        n = n3;
                        if (object != null) {
                            n = n3 + zzart.zzc(4, (zzasa)object);
                        }
                        n3 = n;
                    }
                }
            }
            n5 = n3;
            if (this.zzwm != null) {
                n5 = n3;
                if (this.zzwm.length > 0) {
                    for (n5 = 0; n5 < this.zzwm.length; ++n5) {
                        object = this.zzwm[n5];
                        n = n3;
                        if (object != null) {
                            n = n3 + zzart.zzc(5, (zzasa)object);
                        }
                        n3 = n;
                    }
                    n5 = n3;
                }
            }
            n3 = n5;
            if (this.zzwn != null) {
                n3 = n5;
                if (this.zzwn.length > 0) {
                    n3 = n5;
                    for (n5 = 0; n5 < this.zzwn.length; ++n5) {
                        object = this.zzwn[n5];
                        n = n3;
                        if (object != null) {
                            n = n3 + zzart.zzc(6, (zzasa)object);
                        }
                        n3 = n;
                    }
                }
            }
            n5 = n3;
            if (this.zzwo != null) {
                n5 = n3;
                if (this.zzwo.length > 0) {
                    for (n5 = 0; n5 < this.zzwo.length; ++n5) {
                        object = this.zzwo[n5];
                        n = n3;
                        if (object != null) {
                            n = n3 + zzart.zzc(7, (zzasa)object);
                        }
                        n3 = n;
                    }
                    n5 = n3;
                }
            }
            n3 = n5;
            if (this.zzwp != null) {
                n3 = n5;
                if (!this.zzwp.equals("")) {
                    n3 = n5 + zzart.zzr(9, this.zzwp);
                }
            }
            n5 = n3;
            if (this.zzwq != null) {
                n5 = n3;
                if (!this.zzwq.equals("")) {
                    n5 = n3 + zzart.zzr(10, this.zzwq);
                }
            }
            n3 = n5;
            if (this.zzwr != null) {
                n3 = n5;
                if (!this.zzwr.equals("0")) {
                    n3 = n5 + zzart.zzr(12, this.zzwr);
                }
            }
            n5 = n3;
            if (this.version != null) {
                n5 = n3;
                if (!this.version.equals("")) {
                    n5 = n3 + zzart.zzr(13, this.version);
                }
            }
            n = n5;
            if (this.zzws != null) {
                n = n5 + zzart.zzc(14, this.zzws);
            }
            n3 = n;
            if (Float.floatToIntBits(this.zzwt) != Float.floatToIntBits(0.0f)) {
                n3 = n + zzart.zzd(15, this.zzwt);
            }
            n5 = n3;
            if (this.zzwv != null) {
                n5 = n3;
                if (this.zzwv.length > 0) {
                    n = 0;
                    n2 = 0;
                    for (n5 = 0; n5 < this.zzwv.length; ++n5) {
                        object = this.zzwv[n5];
                        n7 = n;
                        n4 = n2;
                        if (object != null) {
                            n4 = n2 + 1;
                            n7 = n + zzart.zzuy((String)object);
                        }
                        n = n7;
                        n2 = n4;
                    }
                    n5 = n3 + n + n2 * 2;
                }
            }
            n = n5;
            if (this.zzww != 0) {
                n = n5 + zzart.zzah(17, this.zzww);
            }
            n3 = n;
            if (this.zzwu) {
                n3 = n + zzart.zzh(18, this.zzwu);
            }
            n5 = n3;
            if (this.zzwh == null) return n5;
            n5 = n3;
            if (this.zzwh.length <= 0) return n5;
            n = 0;
            n2 = 0;
            n5 = n6;
            while (n5 < this.zzwh.length) {
                object = this.zzwh[n5];
                n7 = n;
                n4 = n2;
                if (object != null) {
                    n4 = n2 + 1;
                    n7 = n + zzart.zzuy((String)object);
                }
                ++n5;
                n = n7;
                n2 = n4;
            }
            return n3 + n + n2 * 2;
        }
    }

    public static final class zzg
    extends zzaru<zzg> {
        private static volatile zzg[] zzwx;
        public int[] zzwy;
        public int[] zzwz;
        public int[] zzxa;
        public int[] zzxb;
        public int[] zzxc;
        public int[] zzxd;
        public int[] zzxe;
        public int[] zzxf;
        public int[] zzxg;
        public int[] zzxh;

        public zzg() {
            this.zzam();
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public static zzg[] zzal() {
            if (zzwx == null) {
                Object object = zzary.btO;
                synchronized (object) {
                    if (zzwx == null) {
                        zzwx = new zzg[0];
                    }
                }
            }
            return zzwx;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zzg)) return bl2;
            object = (zzg)object;
            bl2 = bl;
            if (!zzary.equals(this.zzwy, object.zzwy)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzwz, object.zzwz)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxa, object.zzxa)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxb, object.zzxb)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxc, object.zzxc)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxd, object.zzxd)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxe, object.zzxe)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxf, object.zzxf)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxg, object.zzxg)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxh, object.zzxh)) return bl2;
            if (this.btG != null) {
                if (!this.btG.isEmpty()) return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public int hashCode() {
            int n;
            int n2 = this.getClass().getName().hashCode();
            int n3 = zzary.hashCode(this.zzwy);
            int n4 = zzary.hashCode(this.zzwz);
            int n5 = zzary.hashCode(this.zzxa);
            int n6 = zzary.hashCode(this.zzxb);
            int n7 = zzary.hashCode(this.zzxc);
            int n8 = zzary.hashCode(this.zzxd);
            int n9 = zzary.hashCode(this.zzxe);
            int n10 = zzary.hashCode(this.zzxf);
            int n11 = zzary.hashCode(this.zzxg);
            int n12 = zzary.hashCode(this.zzxh);
            if (this.btG == null || this.btG.isEmpty()) {
                n = 0;
                do {
                    return n + (((((((((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31 + n6) * 31 + n7) * 31 + n8) * 31 + n9) * 31 + n10) * 31 + n11) * 31 + n12) * 31;
                    break;
                } while (true);
            }
            n = this.btG.hashCode();
            return n + (((((((((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31 + n6) * 31 + n7) * 31 + n8) * 31 + n9) * 31 + n10) * 31 + n11) * 31 + n12) * 31;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            int n;
            int n2 = 0;
            if (this.zzwy != null && this.zzwy.length > 0) {
                for (n = 0; n < this.zzwy.length; ++n) {
                    zzart2.zzaf(1, this.zzwy[n]);
                }
            }
            if (this.zzwz != null && this.zzwz.length > 0) {
                for (n = 0; n < this.zzwz.length; ++n) {
                    zzart2.zzaf(2, this.zzwz[n]);
                }
            }
            if (this.zzxa != null && this.zzxa.length > 0) {
                for (n = 0; n < this.zzxa.length; ++n) {
                    zzart2.zzaf(3, this.zzxa[n]);
                }
            }
            if (this.zzxb != null && this.zzxb.length > 0) {
                for (n = 0; n < this.zzxb.length; ++n) {
                    zzart2.zzaf(4, this.zzxb[n]);
                }
            }
            if (this.zzxc != null && this.zzxc.length > 0) {
                for (n = 0; n < this.zzxc.length; ++n) {
                    zzart2.zzaf(5, this.zzxc[n]);
                }
            }
            if (this.zzxd != null && this.zzxd.length > 0) {
                for (n = 0; n < this.zzxd.length; ++n) {
                    zzart2.zzaf(6, this.zzxd[n]);
                }
            }
            if (this.zzxe != null && this.zzxe.length > 0) {
                for (n = 0; n < this.zzxe.length; ++n) {
                    zzart2.zzaf(7, this.zzxe[n]);
                }
            }
            if (this.zzxf != null && this.zzxf.length > 0) {
                for (n = 0; n < this.zzxf.length; ++n) {
                    zzart2.zzaf(8, this.zzxf[n]);
                }
            }
            if (this.zzxg != null && this.zzxg.length > 0) {
                for (n = 0; n < this.zzxg.length; ++n) {
                    zzart2.zzaf(9, this.zzxg[n]);
                }
            }
            if (this.zzxh != null && this.zzxh.length > 0) {
                for (n = n2; n < this.zzxh.length; ++n) {
                    zzart2.zzaf(10, this.zzxh[n]);
                }
            }
            super.zza(zzart2);
        }

        public zzg zzam() {
            this.zzwy = zzasd.btR;
            this.zzwz = zzasd.btR;
            this.zzxa = zzasd.btR;
            this.zzxb = zzasd.btR;
            this.zzxc = zzasd.btR;
            this.zzxd = zzasd.btR;
            this.zzxe = zzasd.btR;
            this.zzxf = zzasd.btR;
            this.zzxg = zzasd.btR;
            this.zzxh = zzasd.btR;
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzt(zzars2);
        }

        /*
         * Enabled aggressive block sorting
         */
        public zzg zzt(zzars zzars2) throws IOException {
            block23 : do {
                int n;
                int[] arrn;
                int n2;
                int n3 = zzars2.bU();
                switch (n3) {
                    default: {
                        if (super.zza(zzars2, n3)) continue block23;
                    }
                    case 0: {
                        return this;
                    }
                    case 8: {
                        n2 = zzasd.zzc(zzars2, 8);
                        n3 = this.zzwy == null ? 0 : this.zzwy.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzwy, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzwy = arrn;
                        continue block23;
                    }
                    case 10: {
                        n = zzars2.zzagt(zzars2.cd());
                        n3 = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n3);
                        n3 = this.zzwy == null ? 0 : this.zzwy.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzwy, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzwy = arrn;
                        zzars2.zzagu(n);
                        continue block23;
                    }
                    case 16: {
                        n2 = zzasd.zzc(zzars2, 16);
                        n3 = this.zzwz == null ? 0 : this.zzwz.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzwz, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzwz = arrn;
                        continue block23;
                    }
                    case 18: {
                        n = zzars2.zzagt(zzars2.cd());
                        n3 = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n3);
                        n3 = this.zzwz == null ? 0 : this.zzwz.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzwz, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzwz = arrn;
                        zzars2.zzagu(n);
                        continue block23;
                    }
                    case 24: {
                        n2 = zzasd.zzc(zzars2, 24);
                        n3 = this.zzxa == null ? 0 : this.zzxa.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxa, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzxa = arrn;
                        continue block23;
                    }
                    case 26: {
                        n = zzars2.zzagt(zzars2.cd());
                        n3 = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n3);
                        n3 = this.zzxa == null ? 0 : this.zzxa.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxa, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzxa = arrn;
                        zzars2.zzagu(n);
                        continue block23;
                    }
                    case 32: {
                        n2 = zzasd.zzc(zzars2, 32);
                        n3 = this.zzxb == null ? 0 : this.zzxb.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxb, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzxb = arrn;
                        continue block23;
                    }
                    case 34: {
                        n = zzars2.zzagt(zzars2.cd());
                        n3 = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n3);
                        n3 = this.zzxb == null ? 0 : this.zzxb.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxb, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzxb = arrn;
                        zzars2.zzagu(n);
                        continue block23;
                    }
                    case 40: {
                        n2 = zzasd.zzc(zzars2, 40);
                        n3 = this.zzxc == null ? 0 : this.zzxc.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxc, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzxc = arrn;
                        continue block23;
                    }
                    case 42: {
                        n = zzars2.zzagt(zzars2.cd());
                        n3 = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n3);
                        n3 = this.zzxc == null ? 0 : this.zzxc.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxc, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzxc = arrn;
                        zzars2.zzagu(n);
                        continue block23;
                    }
                    case 48: {
                        n2 = zzasd.zzc(zzars2, 48);
                        n3 = this.zzxd == null ? 0 : this.zzxd.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxd, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzxd = arrn;
                        continue block23;
                    }
                    case 50: {
                        n = zzars2.zzagt(zzars2.cd());
                        n3 = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n3);
                        n3 = this.zzxd == null ? 0 : this.zzxd.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxd, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzxd = arrn;
                        zzars2.zzagu(n);
                        continue block23;
                    }
                    case 56: {
                        n2 = zzasd.zzc(zzars2, 56);
                        n3 = this.zzxe == null ? 0 : this.zzxe.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxe, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzxe = arrn;
                        continue block23;
                    }
                    case 58: {
                        n = zzars2.zzagt(zzars2.cd());
                        n3 = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n3);
                        n3 = this.zzxe == null ? 0 : this.zzxe.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxe, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzxe = arrn;
                        zzars2.zzagu(n);
                        continue block23;
                    }
                    case 64: {
                        n2 = zzasd.zzc(zzars2, 64);
                        n3 = this.zzxf == null ? 0 : this.zzxf.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxf, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzxf = arrn;
                        continue block23;
                    }
                    case 66: {
                        n = zzars2.zzagt(zzars2.cd());
                        n3 = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n3);
                        n3 = this.zzxf == null ? 0 : this.zzxf.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxf, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzxf = arrn;
                        zzars2.zzagu(n);
                        continue block23;
                    }
                    case 72: {
                        n2 = zzasd.zzc(zzars2, 72);
                        n3 = this.zzxg == null ? 0 : this.zzxg.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxg, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzxg = arrn;
                        continue block23;
                    }
                    case 74: {
                        n = zzars2.zzagt(zzars2.cd());
                        n3 = zzars2.getPosition();
                        n2 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n2;
                        }
                        zzars2.zzagv(n3);
                        n3 = this.zzxg == null ? 0 : this.zzxg.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxg, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length) {
                            arrn[n2] = zzars2.bY();
                            ++n2;
                        }
                        this.zzxg = arrn;
                        zzars2.zzagu(n);
                        continue block23;
                    }
                    case 80: {
                        n2 = zzasd.zzc(zzars2, 80);
                        n3 = this.zzxh == null ? 0 : this.zzxh.length;
                        arrn = new int[n2 + n3];
                        n2 = n3;
                        if (n3 != 0) {
                            System.arraycopy(this.zzxh, 0, arrn, 0, n3);
                            n2 = n3;
                        }
                        while (n2 < arrn.length - 1) {
                            arrn[n2] = zzars2.bY();
                            zzars2.bU();
                            ++n2;
                        }
                        arrn[n2] = zzars2.bY();
                        this.zzxh = arrn;
                        continue block23;
                    }
                    case 82: 
                }
                n = zzars2.zzagt(zzars2.cd());
                n3 = zzars2.getPosition();
                n2 = 0;
                while (zzars2.ci() > 0) {
                    zzars2.bY();
                    ++n2;
                }
                zzars2.zzagv(n3);
                n3 = this.zzxh == null ? 0 : this.zzxh.length;
                arrn = new int[n2 + n3];
                n2 = n3;
                if (n3 != 0) {
                    System.arraycopy(this.zzxh, 0, arrn, 0, n3);
                    n2 = n3;
                }
                while (n2 < arrn.length) {
                    arrn[n2] = zzars2.bY();
                    ++n2;
                }
                this.zzxh = arrn;
                zzars2.zzagu(n);
            } while (true);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        protected int zzx() {
            int n;
            int n2;
            int n3 = 0;
            int n4 = super.zzx();
            if (this.zzwy != null && this.zzwy.length > 0) {
                n2 = 0;
                for (n = 0; n < this.zzwy.length; n2 += zzart.zzagz((int)this.zzwy[n]), ++n) {
                }
                n2 = n4 + n2 + this.zzwy.length * 1;
            } else {
                n2 = n4;
            }
            n = n2;
            if (this.zzwz != null) {
                n = n2;
                if (this.zzwz.length > 0) {
                    n4 = 0;
                    for (n = 0; n < this.zzwz.length; n4 += zzart.zzagz((int)this.zzwz[n]), ++n) {
                    }
                    n = n2 + n4 + this.zzwz.length * 1;
                }
            }
            n2 = n;
            if (this.zzxa != null) {
                n2 = n;
                if (this.zzxa.length > 0) {
                    n4 = 0;
                    for (n2 = 0; n2 < this.zzxa.length; n4 += zzart.zzagz((int)this.zzxa[n2]), ++n2) {
                    }
                    n2 = n + n4 + this.zzxa.length * 1;
                }
            }
            n = n2;
            if (this.zzxb != null) {
                n = n2;
                if (this.zzxb.length > 0) {
                    n4 = 0;
                    for (n = 0; n < this.zzxb.length; n4 += zzart.zzagz((int)this.zzxb[n]), ++n) {
                    }
                    n = n2 + n4 + this.zzxb.length * 1;
                }
            }
            n2 = n;
            if (this.zzxc != null) {
                n2 = n;
                if (this.zzxc.length > 0) {
                    n4 = 0;
                    for (n2 = 0; n2 < this.zzxc.length; n4 += zzart.zzagz((int)this.zzxc[n2]), ++n2) {
                    }
                    n2 = n + n4 + this.zzxc.length * 1;
                }
            }
            n = n2;
            if (this.zzxd != null) {
                n = n2;
                if (this.zzxd.length > 0) {
                    n4 = 0;
                    for (n = 0; n < this.zzxd.length; n4 += zzart.zzagz((int)this.zzxd[n]), ++n) {
                    }
                    n = n2 + n4 + this.zzxd.length * 1;
                }
            }
            n2 = n;
            if (this.zzxe != null) {
                n2 = n;
                if (this.zzxe.length > 0) {
                    n4 = 0;
                    for (n2 = 0; n2 < this.zzxe.length; n4 += zzart.zzagz((int)this.zzxe[n2]), ++n2) {
                    }
                    n2 = n + n4 + this.zzxe.length * 1;
                }
            }
            n = n2;
            if (this.zzxf != null) {
                n = n2;
                if (this.zzxf.length > 0) {
                    n4 = 0;
                    for (n = 0; n < this.zzxf.length; n4 += zzart.zzagz((int)this.zzxf[n]), ++n) {
                    }
                    n = n2 + n4 + this.zzxf.length * 1;
                }
            }
            n2 = n;
            if (this.zzxg != null) {
                n2 = n;
                if (this.zzxg.length > 0) {
                    n4 = 0;
                    for (n2 = 0; n2 < this.zzxg.length; n4 += zzart.zzagz((int)this.zzxg[n2]), ++n2) {
                    }
                    n2 = n + n4 + this.zzxg.length * 1;
                }
            }
            n = n2;
            if (this.zzxh == null) return n;
            n = n2;
            if (this.zzxh.length <= 0) return n;
            n4 = 0;
            n = n3;
            while (n < this.zzxh.length) {
                n4 += zzart.zzagz(this.zzxh[n]);
                ++n;
            }
            return n2 + n4 + this.zzxh.length * 1;
        }
    }

    public static final class zzh
    extends zzaru<zzh> {
        public static final zzarv<zzaj.zza, zzh> zzxi = zzarv.zza(11, zzh.class, 810);
        private static final zzh[] zzxj = new zzh[0];
        public int[] zzxk;
        public int[] zzxl;
        public int[] zzxm;
        public int zzxn;
        public int[] zzxo;
        public int zzxp;
        public int zzxq;

        public zzh() {
            this.zzan();
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zzh)) return bl2;
            object = (zzh)object;
            bl2 = bl;
            if (!zzary.equals(this.zzxk, object.zzxk)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxl, object.zzxl)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxm, object.zzxm)) return bl2;
            bl2 = bl;
            if (this.zzxn != object.zzxn) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxo, object.zzxo)) return bl2;
            bl2 = bl;
            if (this.zzxp != object.zzxp) return bl2;
            bl2 = bl;
            if (this.zzxq != object.zzxq) return bl2;
            if (this.btG != null) {
                if (!this.btG.isEmpty()) return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public int hashCode() {
            int n;
            int n2 = this.getClass().getName().hashCode();
            int n3 = zzary.hashCode(this.zzxk);
            int n4 = zzary.hashCode(this.zzxl);
            int n5 = zzary.hashCode(this.zzxm);
            int n6 = this.zzxn;
            int n7 = zzary.hashCode(this.zzxo);
            int n8 = this.zzxp;
            int n9 = this.zzxq;
            if (this.btG == null || this.btG.isEmpty()) {
                n = 0;
                do {
                    return n + ((((((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31 + n6) * 31 + n7) * 31 + n8) * 31 + n9) * 31;
                    break;
                } while (true);
            }
            n = this.btG.hashCode();
            return n + ((((((((n2 + 527) * 31 + n3) * 31 + n4) * 31 + n5) * 31 + n6) * 31 + n7) * 31 + n8) * 31 + n9) * 31;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            int n;
            int n2 = 0;
            if (this.zzxk != null && this.zzxk.length > 0) {
                for (n = 0; n < this.zzxk.length; ++n) {
                    zzart2.zzaf(1, this.zzxk[n]);
                }
            }
            if (this.zzxl != null && this.zzxl.length > 0) {
                for (n = 0; n < this.zzxl.length; ++n) {
                    zzart2.zzaf(2, this.zzxl[n]);
                }
            }
            if (this.zzxm != null && this.zzxm.length > 0) {
                for (n = 0; n < this.zzxm.length; ++n) {
                    zzart2.zzaf(3, this.zzxm[n]);
                }
            }
            if (this.zzxn != 0) {
                zzart2.zzaf(4, this.zzxn);
            }
            if (this.zzxo != null && this.zzxo.length > 0) {
                for (n = n2; n < this.zzxo.length; ++n) {
                    zzart2.zzaf(5, this.zzxo[n]);
                }
            }
            if (this.zzxp != 0) {
                zzart2.zzaf(6, this.zzxp);
            }
            if (this.zzxq != 0) {
                zzart2.zzaf(7, this.zzxq);
            }
            super.zza(zzart2);
        }

        public zzh zzan() {
            this.zzxk = zzasd.btR;
            this.zzxl = zzasd.btR;
            this.zzxm = zzasd.btR;
            this.zzxn = 0;
            this.zzxo = zzasd.btR;
            this.zzxp = 0;
            this.zzxq = 0;
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzu(zzars2);
        }

        /*
         * Enabled aggressive block sorting
         */
        public zzh zzu(zzars zzars2) throws IOException {
            block14 : do {
                int n = zzars2.bU();
                switch (n) {
                    int n2;
                    int[] arrn;
                    int n3;
                    default: {
                        if (super.zza(zzars2, n)) continue block14;
                    }
                    case 0: {
                        return this;
                    }
                    case 8: {
                        n3 = zzasd.zzc(zzars2, 8);
                        n = this.zzxk == null ? 0 : this.zzxk.length;
                        arrn = new int[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxk, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length - 1) {
                            arrn[n3] = zzars2.bY();
                            zzars2.bU();
                            ++n3;
                        }
                        arrn[n3] = zzars2.bY();
                        this.zzxk = arrn;
                        continue block14;
                    }
                    case 10: {
                        n2 = zzars2.zzagt(zzars2.cd());
                        n = zzars2.getPosition();
                        n3 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n3;
                        }
                        zzars2.zzagv(n);
                        n = this.zzxk == null ? 0 : this.zzxk.length;
                        arrn = new int[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxk, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length) {
                            arrn[n3] = zzars2.bY();
                            ++n3;
                        }
                        this.zzxk = arrn;
                        zzars2.zzagu(n2);
                        continue block14;
                    }
                    case 16: {
                        n3 = zzasd.zzc(zzars2, 16);
                        n = this.zzxl == null ? 0 : this.zzxl.length;
                        arrn = new int[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxl, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length - 1) {
                            arrn[n3] = zzars2.bY();
                            zzars2.bU();
                            ++n3;
                        }
                        arrn[n3] = zzars2.bY();
                        this.zzxl = arrn;
                        continue block14;
                    }
                    case 18: {
                        n2 = zzars2.zzagt(zzars2.cd());
                        n = zzars2.getPosition();
                        n3 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n3;
                        }
                        zzars2.zzagv(n);
                        n = this.zzxl == null ? 0 : this.zzxl.length;
                        arrn = new int[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxl, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length) {
                            arrn[n3] = zzars2.bY();
                            ++n3;
                        }
                        this.zzxl = arrn;
                        zzars2.zzagu(n2);
                        continue block14;
                    }
                    case 24: {
                        n3 = zzasd.zzc(zzars2, 24);
                        n = this.zzxm == null ? 0 : this.zzxm.length;
                        arrn = new int[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxm, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length - 1) {
                            arrn[n3] = zzars2.bY();
                            zzars2.bU();
                            ++n3;
                        }
                        arrn[n3] = zzars2.bY();
                        this.zzxm = arrn;
                        continue block14;
                    }
                    case 26: {
                        n2 = zzars2.zzagt(zzars2.cd());
                        n = zzars2.getPosition();
                        n3 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n3;
                        }
                        zzars2.zzagv(n);
                        n = this.zzxm == null ? 0 : this.zzxm.length;
                        arrn = new int[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxm, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length) {
                            arrn[n3] = zzars2.bY();
                            ++n3;
                        }
                        this.zzxm = arrn;
                        zzars2.zzagu(n2);
                        continue block14;
                    }
                    case 32: {
                        this.zzxn = zzars2.bY();
                        continue block14;
                    }
                    case 40: {
                        n3 = zzasd.zzc(zzars2, 40);
                        n = this.zzxo == null ? 0 : this.zzxo.length;
                        arrn = new int[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxo, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length - 1) {
                            arrn[n3] = zzars2.bY();
                            zzars2.bU();
                            ++n3;
                        }
                        arrn[n3] = zzars2.bY();
                        this.zzxo = arrn;
                        continue block14;
                    }
                    case 42: {
                        n2 = zzars2.zzagt(zzars2.cd());
                        n = zzars2.getPosition();
                        n3 = 0;
                        while (zzars2.ci() > 0) {
                            zzars2.bY();
                            ++n3;
                        }
                        zzars2.zzagv(n);
                        n = this.zzxo == null ? 0 : this.zzxo.length;
                        arrn = new int[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxo, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length) {
                            arrn[n3] = zzars2.bY();
                            ++n3;
                        }
                        this.zzxo = arrn;
                        zzars2.zzagu(n2);
                        continue block14;
                    }
                    case 48: {
                        this.zzxp = zzars2.bY();
                        continue block14;
                    }
                    case 56: 
                }
                this.zzxq = zzars2.bY();
            } while (true);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        protected int zzx() {
            int n;
            int n2;
            int n3 = 0;
            int n4 = super.zzx();
            if (this.zzxk != null && this.zzxk.length > 0) {
                n2 = 0;
                for (n = 0; n < this.zzxk.length; n2 += zzart.zzagz((int)this.zzxk[n]), ++n) {
                }
                n2 = n4 + n2 + this.zzxk.length * 1;
            } else {
                n2 = n4;
            }
            n = n2;
            if (this.zzxl != null) {
                n = n2;
                if (this.zzxl.length > 0) {
                    n4 = 0;
                    for (n = 0; n < this.zzxl.length; n4 += zzart.zzagz((int)this.zzxl[n]), ++n) {
                    }
                    n = n2 + n4 + this.zzxl.length * 1;
                }
            }
            n2 = n;
            if (this.zzxm != null) {
                n2 = n;
                if (this.zzxm.length > 0) {
                    n4 = 0;
                    for (n2 = 0; n2 < this.zzxm.length; n4 += zzart.zzagz((int)this.zzxm[n2]), ++n2) {
                    }
                    n2 = n + n4 + this.zzxm.length * 1;
                }
            }
            n = n2;
            if (this.zzxn != 0) {
                n = n2 + zzart.zzah(4, this.zzxn);
            }
            n2 = n;
            if (this.zzxo != null) {
                n2 = n;
                if (this.zzxo.length > 0) {
                    n4 = 0;
                    for (n2 = n3; n2 < this.zzxo.length; n4 += zzart.zzagz((int)this.zzxo[n2]), ++n2) {
                    }
                    n2 = n + n4 + this.zzxo.length * 1;
                }
            }
            n = n2;
            if (this.zzxp != 0) {
                n = n2 + zzart.zzah(6, this.zzxp);
            }
            n2 = n;
            if (this.zzxq == 0) return n2;
            return n + zzart.zzah(7, this.zzxq);
        }
    }

    public static final class zzi
    extends zzaru<zzi> {
        private static volatile zzi[] zzxr;
        public String name;
        public zzaj.zza zzxs;
        public zzd zzxt;

        public zzi() {
            this.zzap();
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public static zzi[] zzao() {
            if (zzxr == null) {
                Object object = zzary.btO;
                synchronized (object) {
                    if (zzxr == null) {
                        zzxr = new zzi[0];
                    }
                }
            }
            return zzxr;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zzi)) return bl2;
            object = (zzi)object;
            if (this.name == null) {
                bl2 = bl;
                if (object.name != null) return bl2;
            } else if (!this.name.equals(object.name)) {
                return false;
            }
            if (this.zzxs == null) {
                bl2 = bl;
                if (object.zzxs != null) return bl2;
            } else if (!this.zzxs.equals(object.zzxs)) {
                return false;
            }
            if (this.zzxt == null) {
                bl2 = bl;
                if (object.zzxt != null) return bl2;
            } else if (!this.zzxt.equals(object.zzxt)) {
                return false;
            }
            if (this.btG != null && !this.btG.isEmpty()) {
                return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        public int hashCode() {
            int n = 0;
            int n2 = this.getClass().getName().hashCode();
            int n3 = this.name == null ? 0 : this.name.hashCode();
            int n4 = this.zzxs == null ? 0 : this.zzxs.hashCode();
            int n5 = this.zzxt == null ? 0 : this.zzxt.hashCode();
            int n6 = n;
            if (this.btG == null) return (n5 + (n4 + (n3 + (n2 + 527) * 31) * 31) * 31) * 31 + n6;
            if (this.btG.isEmpty()) {
                n6 = n;
                return (n5 + (n4 + (n3 + (n2 + 527) * 31) * 31) * 31) * 31 + n6;
            }
            n6 = this.btG.hashCode();
            return (n5 + (n4 + (n3 + (n2 + 527) * 31) * 31) * 31) * 31 + n6;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.name != null && !this.name.equals("")) {
                zzart2.zzq(1, this.name);
            }
            if (this.zzxs != null) {
                zzart2.zza(2, this.zzxs);
            }
            if (this.zzxt != null) {
                zzart2.zza(3, this.zzxt);
            }
            super.zza(zzart2);
        }

        public zzi zzap() {
            this.name = "";
            this.zzxs = null;
            this.zzxt = null;
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzv(zzars2);
        }

        public zzi zzv(zzars zzars2) throws IOException {
            block6 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block6;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        this.name = zzars2.readString();
                        continue block6;
                    }
                    case 18: {
                        if (this.zzxs == null) {
                            this.zzxs = new zzaj.zza();
                        }
                        zzars2.zza(this.zzxs);
                        continue block6;
                    }
                    case 26: 
                }
                if (this.zzxt == null) {
                    this.zzxt = new zzd();
                }
                zzars2.zza(this.zzxt);
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.name != null) {
                n2 = n;
                if (!this.name.equals("")) {
                    n2 = n + zzart.zzr(1, this.name);
                }
            }
            n = n2;
            if (this.zzxs != null) {
                n = n2 + zzart.zzc(2, this.zzxs);
            }
            n2 = n;
            if (this.zzxt != null) {
                n2 = n + zzart.zzc(3, this.zzxt);
            }
            return n2;
        }
    }

    public static final class zzj
    extends zzaru<zzj> {
        public zzi[] zzxu;
        public zzf zzxv;
        public String zzxw;

        public zzj() {
            this.zzaq();
        }

        public static zzj zzg(byte[] arrby) throws zzarz {
            return zzasa.zza(new zzj(), arrby);
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zzj)) return bl2;
            object = (zzj)object;
            bl2 = bl;
            if (!zzary.equals(this.zzxu, object.zzxu)) return bl2;
            if (this.zzxv == null) {
                bl2 = bl;
                if (object.zzxv != null) return bl2;
            } else if (!this.zzxv.equals(object.zzxv)) {
                return false;
            }
            if (this.zzxw == null) {
                bl2 = bl;
                if (object.zzxw != null) return bl2;
            } else if (!this.zzxw.equals(object.zzxw)) {
                return false;
            }
            if (this.btG != null && !this.btG.isEmpty()) {
                return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        public int hashCode() {
            int n = 0;
            int n2 = this.getClass().getName().hashCode();
            int n3 = zzary.hashCode(this.zzxu);
            int n4 = this.zzxv == null ? 0 : this.zzxv.hashCode();
            int n5 = this.zzxw == null ? 0 : this.zzxw.hashCode();
            int n6 = n;
            if (this.btG == null) return (n5 + (n4 + ((n2 + 527) * 31 + n3) * 31) * 31) * 31 + n6;
            if (this.btG.isEmpty()) {
                n6 = n;
                return (n5 + (n4 + ((n2 + 527) * 31 + n3) * 31) * 31) * 31 + n6;
            }
            n6 = this.btG.hashCode();
            return (n5 + (n4 + ((n2 + 527) * 31 + n3) * 31) * 31) * 31 + n6;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            if (this.zzxu != null && this.zzxu.length > 0) {
                for (int i = 0; i < this.zzxu.length; ++i) {
                    zzi zzi2 = this.zzxu[i];
                    if (zzi2 == null) continue;
                    zzart2.zza(1, zzi2);
                }
            }
            if (this.zzxv != null) {
                zzart2.zza(2, this.zzxv);
            }
            if (this.zzxw != null && !this.zzxw.equals("")) {
                zzart2.zzq(3, this.zzxw);
            }
            super.zza(zzart2);
        }

        public zzj zzaq() {
            this.zzxu = zzi.zzao();
            this.zzxv = null;
            this.zzxw = "";
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzw(zzars2);
        }

        /*
         * Enabled aggressive block sorting
         */
        public zzj zzw(zzars zzars2) throws IOException {
            block6 : do {
                int n = zzars2.bU();
                switch (n) {
                    default: {
                        if (super.zza(zzars2, n)) continue block6;
                    }
                    case 0: {
                        return this;
                    }
                    case 10: {
                        int n2 = zzasd.zzc(zzars2, 10);
                        n = this.zzxu == null ? 0 : this.zzxu.length;
                        zzi[] arrzzi = new zzi[n2 + n];
                        n2 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxu, 0, arrzzi, 0, n);
                            n2 = n;
                        }
                        while (n2 < arrzzi.length - 1) {
                            arrzzi[n2] = new zzi();
                            zzars2.zza(arrzzi[n2]);
                            zzars2.bU();
                            ++n2;
                        }
                        arrzzi[n2] = new zzi();
                        zzars2.zza(arrzzi[n2]);
                        this.zzxu = arrzzi;
                        continue block6;
                    }
                    case 18: {
                        if (this.zzxv == null) {
                            this.zzxv = new zzf();
                        }
                        zzars2.zza(this.zzxv);
                        continue block6;
                    }
                    case 26: 
                }
                this.zzxw = zzars2.readString();
            } while (true);
        }

        @Override
        protected int zzx() {
            int n;
            int n2 = n = super.zzx();
            if (this.zzxu != null) {
                n2 = n;
                if (this.zzxu.length > 0) {
                    int n3 = 0;
                    do {
                        n2 = n;
                        if (n3 >= this.zzxu.length) break;
                        zzi zzi2 = this.zzxu[n3];
                        n2 = n;
                        if (zzi2 != null) {
                            n2 = n + zzart.zzc(1, zzi2);
                        }
                        ++n3;
                        n = n2;
                    } while (true);
                }
            }
            n = n2;
            if (this.zzxv != null) {
                n = n2 + zzart.zzc(2, this.zzxv);
            }
            n2 = n;
            if (this.zzxw != null) {
                n2 = n;
                if (!this.zzxw.equals("")) {
                    n2 = n + zzart.zzr(3, this.zzxw);
                }
            }
            return n2;
        }
    }

}

