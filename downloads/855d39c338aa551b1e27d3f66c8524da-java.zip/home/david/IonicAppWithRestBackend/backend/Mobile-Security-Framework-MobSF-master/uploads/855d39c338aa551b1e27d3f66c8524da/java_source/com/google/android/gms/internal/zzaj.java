/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import com.google.android.gms.internal.zzars;
import com.google.android.gms.internal.zzart;
import com.google.android.gms.internal.zzaru;
import com.google.android.gms.internal.zzarw;
import com.google.android.gms.internal.zzary;
import com.google.android.gms.internal.zzasa;
import com.google.android.gms.internal.zzasd;
import java.io.IOException;

public interface zzaj {

    public static final class zza
    extends zzaru<zza> {
        private static volatile zza[] zzxx;
        public String string;
        public int type;
        public zza[] zzxy;
        public zza[] zzxz;
        public zza[] zzya;
        public String zzyb;
        public String zzyc;
        public long zzyd;
        public boolean zzye;
        public zza[] zzyf;
        public int[] zzyg;
        public boolean zzyh;

        public zza() {
            this.zzas();
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public static zza[] zzar() {
            if (zzxx == null) {
                Object object = zzary.btO;
                synchronized (object) {
                    if (zzxx == null) {
                        zzxx = new zza[0];
                    }
                }
            }
            return zzxx;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean equals(Object object) {
            boolean bl = false;
            if (object == this) {
                return true;
            }
            boolean bl2 = bl;
            if (!(object instanceof zza)) return bl2;
            object = (zza)object;
            bl2 = bl;
            if (this.type != object.type) return bl2;
            if (this.string == null) {
                bl2 = bl;
                if (object.string != null) return bl2;
            } else if (!this.string.equals(object.string)) {
                return false;
            }
            bl2 = bl;
            if (!zzary.equals(this.zzxy, object.zzxy)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzxz, object.zzxz)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzya, object.zzya)) return bl2;
            if (this.zzyb == null) {
                bl2 = bl;
                if (object.zzyb != null) return bl2;
            } else if (!this.zzyb.equals(object.zzyb)) {
                return false;
            }
            if (this.zzyc == null) {
                bl2 = bl;
                if (object.zzyc != null) return bl2;
            } else if (!this.zzyc.equals(object.zzyc)) {
                return false;
            }
            bl2 = bl;
            if (this.zzyd != object.zzyd) return bl2;
            bl2 = bl;
            if (this.zzye != object.zzye) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzyf, object.zzyf)) return bl2;
            bl2 = bl;
            if (!zzary.equals(this.zzyg, object.zzyg)) return bl2;
            bl2 = bl;
            if (this.zzyh != object.zzyh) return bl2;
            if (this.btG != null && !this.btG.isEmpty()) {
                return this.btG.equals(object.btG);
            }
            if (object.btG == null) return true;
            bl2 = bl;
            if (!object.btG.isEmpty()) return bl2;
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        public int hashCode() {
            int n = 1231;
            int n2 = 0;
            int n3 = this.getClass().getName().hashCode();
            int n4 = this.type;
            int n5 = this.string == null ? 0 : this.string.hashCode();
            int n6 = zzary.hashCode(this.zzxy);
            int n7 = zzary.hashCode(this.zzxz);
            int n8 = zzary.hashCode(this.zzya);
            int n9 = this.zzyb == null ? 0 : this.zzyb.hashCode();
            int n10 = this.zzyc == null ? 0 : this.zzyc.hashCode();
            int n11 = (int)(this.zzyd ^ this.zzyd >>> 32);
            int n12 = this.zzye ? 1231 : 1237;
            int n13 = zzary.hashCode(this.zzyf);
            int n14 = zzary.hashCode(this.zzyg);
            if (!this.zzyh) {
                n = 1237;
            }
            int n15 = n2;
            if (this.btG == null) return ((((n12 + ((n10 + (n9 + ((((n5 + ((n3 + 527) * 31 + n4) * 31) * 31 + n6) * 31 + n7) * 31 + n8) * 31) * 31) * 31 + n11) * 31) * 31 + n13) * 31 + n14) * 31 + n) * 31 + n15;
            if (this.btG.isEmpty()) {
                n15 = n2;
                return ((((n12 + ((n10 + (n9 + ((((n5 + ((n3 + 527) * 31 + n4) * 31) * 31 + n6) * 31 + n7) * 31 + n8) * 31) * 31) * 31 + n11) * 31) * 31 + n13) * 31 + n14) * 31 + n) * 31 + n15;
            }
            n15 = this.btG.hashCode();
            return ((((n12 + ((n10 + (n9 + ((((n5 + ((n3 + 527) * 31 + n4) * 31) * 31 + n6) * 31 + n7) * 31 + n8) * 31) * 31) * 31 + n11) * 31) * 31 + n13) * 31 + n14) * 31 + n) * 31 + n15;
        }

        @Override
        public void zza(zzart zzart2) throws IOException {
            zza zza2;
            int n;
            int n2 = 0;
            zzart2.zzaf(1, this.type);
            if (this.string != null && !this.string.equals("")) {
                zzart2.zzq(2, this.string);
            }
            if (this.zzxy != null && this.zzxy.length > 0) {
                for (n = 0; n < this.zzxy.length; ++n) {
                    zza2 = this.zzxy[n];
                    if (zza2 == null) continue;
                    zzart2.zza(3, zza2);
                }
            }
            if (this.zzxz != null && this.zzxz.length > 0) {
                for (n = 0; n < this.zzxz.length; ++n) {
                    zza2 = this.zzxz[n];
                    if (zza2 == null) continue;
                    zzart2.zza(4, zza2);
                }
            }
            if (this.zzya != null && this.zzya.length > 0) {
                for (n = 0; n < this.zzya.length; ++n) {
                    zza2 = this.zzya[n];
                    if (zza2 == null) continue;
                    zzart2.zza(5, zza2);
                }
            }
            if (this.zzyb != null && !this.zzyb.equals("")) {
                zzart2.zzq(6, this.zzyb);
            }
            if (this.zzyc != null && !this.zzyc.equals("")) {
                zzart2.zzq(7, this.zzyc);
            }
            if (this.zzyd != 0) {
                zzart2.zzb(8, this.zzyd);
            }
            if (this.zzyh) {
                zzart2.zzg(9, this.zzyh);
            }
            if (this.zzyg != null && this.zzyg.length > 0) {
                for (n = 0; n < this.zzyg.length; ++n) {
                    zzart2.zzaf(10, this.zzyg[n]);
                }
            }
            if (this.zzyf != null && this.zzyf.length > 0) {
                for (n = n2; n < this.zzyf.length; ++n) {
                    zza2 = this.zzyf[n];
                    if (zza2 == null) continue;
                    zzart2.zza(11, zza2);
                }
            }
            if (this.zzye) {
                zzart2.zzg(12, this.zzye);
            }
            super.zza(zzart2);
        }

        public zza zzas() {
            this.type = 1;
            this.string = "";
            this.zzxy = zza.zzar();
            this.zzxz = zza.zzar();
            this.zzya = zza.zzar();
            this.zzyb = "";
            this.zzyc = "";
            this.zzyd = 0;
            this.zzye = false;
            this.zzyf = zza.zzar();
            this.zzyg = zzasd.btR;
            this.zzyh = false;
            this.btG = null;
            this.btP = -1;
            return this;
        }

        @Override
        public /* synthetic */ zzasa zzb(zzars zzars2) throws IOException {
            return this.zzx(zzars2);
        }

        @Override
        protected int zzx() {
            int n;
            zza zza2;
            int n2;
            int n3 = 0;
            int n4 = n2 = super.zzx() + zzart.zzah(1, this.type);
            if (this.string != null) {
                n4 = n2;
                if (!this.string.equals("")) {
                    n4 = n2 + zzart.zzr(2, this.string);
                }
            }
            n2 = n4;
            if (this.zzxy != null) {
                n2 = n4;
                if (this.zzxy.length > 0) {
                    for (n2 = 0; n2 < this.zzxy.length; ++n2) {
                        zza2 = this.zzxy[n2];
                        n = n4;
                        if (zza2 != null) {
                            n = n4 + zzart.zzc(3, zza2);
                        }
                        n4 = n;
                    }
                    n2 = n4;
                }
            }
            n4 = n2;
            if (this.zzxz != null) {
                n4 = n2;
                if (this.zzxz.length > 0) {
                    n4 = n2;
                    for (n2 = 0; n2 < this.zzxz.length; ++n2) {
                        zza2 = this.zzxz[n2];
                        n = n4;
                        if (zza2 != null) {
                            n = n4 + zzart.zzc(4, zza2);
                        }
                        n4 = n;
                    }
                }
            }
            n2 = n4;
            if (this.zzya != null) {
                n2 = n4;
                if (this.zzya.length > 0) {
                    for (n2 = 0; n2 < this.zzya.length; ++n2) {
                        zza2 = this.zzya[n2];
                        n = n4;
                        if (zza2 != null) {
                            n = n4 + zzart.zzc(5, zza2);
                        }
                        n4 = n;
                    }
                    n2 = n4;
                }
            }
            n4 = n2;
            if (this.zzyb != null) {
                n4 = n2;
                if (!this.zzyb.equals("")) {
                    n4 = n2 + zzart.zzr(6, this.zzyb);
                }
            }
            n2 = n4;
            if (this.zzyc != null) {
                n2 = n4;
                if (!this.zzyc.equals("")) {
                    n2 = n4 + zzart.zzr(7, this.zzyc);
                }
            }
            n4 = n2;
            if (this.zzyd != 0) {
                n4 = n2 + zzart.zzf(8, this.zzyd);
            }
            n2 = n4;
            if (this.zzyh) {
                n2 = n4 + zzart.zzh(9, this.zzyh);
            }
            n4 = n2;
            if (this.zzyg != null) {
                n4 = n2;
                if (this.zzyg.length > 0) {
                    n = 0;
                    for (n4 = 0; n4 < this.zzyg.length; ++n4) {
                        n += zzart.zzagz(this.zzyg[n4]);
                    }
                    n4 = n2 + n + this.zzyg.length * 1;
                }
            }
            n2 = n4;
            if (this.zzyf != null) {
                n2 = n4;
                if (this.zzyf.length > 0) {
                    n = n3;
                    do {
                        n2 = n4;
                        if (n >= this.zzyf.length) break;
                        zza2 = this.zzyf[n];
                        n2 = n4;
                        if (zza2 != null) {
                            n2 = n4 + zzart.zzc(11, zza2);
                        }
                        ++n;
                        n4 = n2;
                    } while (true);
                }
            }
            n4 = n2;
            if (this.zzye) {
                n4 = n2 + zzart.zzh(12, this.zzye);
            }
            return n4;
        }

        /*
         * Enabled aggressive block sorting
         */
        public zza zzx(zzars zzars2) throws IOException {
            block28 : do {
                int n = zzars2.bU();
                switch (n) {
                    int[] arrn;
                    int n2;
                    int n3;
                    default: {
                        if (super.zza(zzars2, n)) continue block28;
                    }
                    case 0: {
                        return this;
                    }
                    case 8: {
                        n = zzars2.bY();
                        switch (n) {
                            default: {
                                continue block28;
                            }
                            case 1: 
                            case 2: 
                            case 3: 
                            case 4: 
                            case 5: 
                            case 6: 
                            case 7: 
                            case 8: 
                        }
                        this.type = n;
                        continue block28;
                    }
                    case 18: {
                        this.string = zzars2.readString();
                        continue block28;
                    }
                    case 26: {
                        n3 = zzasd.zzc(zzars2, 26);
                        n = this.zzxy == null ? 0 : this.zzxy.length;
                        arrn = new zza[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxy, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length - 1) {
                            arrn[n3] = new zza();
                            zzars2.zza((zzasa)arrn[n3]);
                            zzars2.bU();
                            ++n3;
                        }
                        arrn[n3] = new zza();
                        zzars2.zza((zzasa)arrn[n3]);
                        this.zzxy = arrn;
                        continue block28;
                    }
                    case 34: {
                        n3 = zzasd.zzc(zzars2, 34);
                        n = this.zzxz == null ? 0 : this.zzxz.length;
                        arrn = new zza[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzxz, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length - 1) {
                            arrn[n3] = new zza();
                            zzars2.zza((zzasa)arrn[n3]);
                            zzars2.bU();
                            ++n3;
                        }
                        arrn[n3] = new zza();
                        zzars2.zza((zzasa)arrn[n3]);
                        this.zzxz = arrn;
                        continue block28;
                    }
                    case 42: {
                        n3 = zzasd.zzc(zzars2, 42);
                        n = this.zzya == null ? 0 : this.zzya.length;
                        arrn = new zza[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzya, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length - 1) {
                            arrn[n3] = new zza();
                            zzars2.zza((zzasa)arrn[n3]);
                            zzars2.bU();
                            ++n3;
                        }
                        arrn[n3] = new zza();
                        zzars2.zza((zzasa)arrn[n3]);
                        this.zzya = arrn;
                        continue block28;
                    }
                    case 50: {
                        this.zzyb = zzars2.readString();
                        continue block28;
                    }
                    case 58: {
                        this.zzyc = zzars2.readString();
                        continue block28;
                    }
                    case 64: {
                        this.zzyd = zzars2.bX();
                        continue block28;
                    }
                    case 72: {
                        this.zzyh = zzars2.ca();
                        continue block28;
                    }
                    case 80: {
                        int n4 = zzasd.zzc(zzars2, 80);
                        arrn = new int[n4];
                        n3 = 0;
                        n = 0;
                        do {
                            if (n3 >= n4) continue block28;
                            if (n3 != 0) {
                                zzars2.bU();
                            }
                            int n5 = zzars2.bY();
                            switch (n5) {
                                default: {
                                    break;
                                }
                                case 1: 
                                case 2: 
                                case 3: 
                                case 4: 
                                case 5: 
                                case 6: 
                                case 7: 
                                case 8: 
                                case 9: 
                                case 10: 
                                case 11: 
                                case 12: 
                                case 13: 
                                case 14: 
                                case 15: 
                                case 16: 
                                case 17: {
                                    n2 = n + 1;
                                    arrn[n] = n5;
                                    n = n2;
                                }
                            }
                            ++n3;
                        } while (true);
                    }
                    case 82: {
                        n2 = zzars2.zzagt(zzars2.cd());
                        n = zzars2.getPosition();
                        n3 = 0;
                        block33 : while (zzars2.ci() > 0) {
                            switch (zzars2.bY()) {
                                default: {
                                    continue block33;
                                }
                                case 1: 
                                case 2: 
                                case 3: 
                                case 4: 
                                case 5: 
                                case 6: 
                                case 7: 
                                case 8: 
                                case 9: 
                                case 10: 
                                case 11: 
                                case 12: 
                                case 13: 
                                case 14: 
                                case 15: 
                                case 16: 
                                case 17: 
                            }
                            ++n3;
                        }
                        zzars2.zzagu(n2);
                        continue block28;
                    }
                    case 90: {
                        n3 = zzasd.zzc(zzars2, 90);
                        n = this.zzyf == null ? 0 : this.zzyf.length;
                        arrn = new zza[n3 + n];
                        n3 = n;
                        if (n != 0) {
                            System.arraycopy(this.zzyf, 0, arrn, 0, n);
                            n3 = n;
                        }
                        while (n3 < arrn.length - 1) {
                            arrn[n3] = new zza();
                            zzars2.zza((zzasa)arrn[n3]);
                            zzars2.bU();
                            ++n3;
                        }
                        arrn[n3] = new zza();
                        zzars2.zza((zzasa)arrn[n3]);
                        this.zzyf = arrn;
                        continue block28;
                    }
                    case 96: 
                }
                this.zzye = zzars2.ca();
            } while (true);
        }
    }

}

