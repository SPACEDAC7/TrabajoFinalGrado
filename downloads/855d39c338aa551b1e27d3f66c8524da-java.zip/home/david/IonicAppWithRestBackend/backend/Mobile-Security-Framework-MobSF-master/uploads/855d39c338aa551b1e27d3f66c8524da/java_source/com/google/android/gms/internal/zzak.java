/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  android.util.Base64
 *  android.util.Log
 */
package com.google.android.gms.internal;

import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.HashMap;

public abstract class zzak<K, V> {
    private static final String TAG = zzak.class.getSimpleName();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected static <K, V> HashMap<K, V> zzl(String var0) {
        try {
            if (TextUtils.isEmpty((CharSequence)var0) != false) return null;
            return (HashMap)new ObjectInputStream(new ByteArrayInputStream(Base64.decode((byte[])var0.getBytes(), (int)0))).readObject();
        }
        catch (ClassNotFoundException var0_1) {}
        ** GOTO lbl-1000
        catch (IOException var0_2) {}
lbl-1000: // 2 sources:
        {
            Log.d((String)zzak.TAG, (String)"decode object failure");
        }
        return null;
    }

    public String toString() {
        try {
            Object object = new ByteArrayOutputStream();
            ObjectOutputStream objectOutputStream = new ObjectOutputStream((OutputStream)object);
            objectOutputStream.writeObject(this.zzat());
            objectOutputStream.close();
            object = Base64.encodeToString((byte[])object.toByteArray(), (int)0);
            return object;
        }
        catch (IOException var1_2) {
            return null;
        }
    }

    protected abstract HashMap<K, V> zzat();

    protected abstract void zzk(String var1);
}

