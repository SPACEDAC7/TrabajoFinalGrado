/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Base64
 */
package com.google.android.gms.internal;

import android.util.Base64;

public final class zzal {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String zza(byte[] arrby, boolean bl) {
        int n;
        if (bl) {
            n = 11;
            do {
                return Base64.encodeToString((byte[])arrby, (int)n);
                break;
            } while (true);
        }
        n = 2;
        return Base64.encodeToString((byte[])arrby, (int)n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static byte[] zza(String string2, boolean bl) throws IllegalArgumentException {
        int n = bl ? 11 : 2;
        byte[] arrby = Base64.decode((String)string2, (int)n);
        if (arrby.length != 0) return arrby;
        if (string2.length() <= 0) return arrby;
        if ((string2 = String.valueOf(string2)).length() != 0) {
            string2 = "Unable to decode ".concat(string2);
            throw new IllegalArgumentException(string2);
        }
        string2 = new String("Unable to decode ");
        throw new IllegalArgumentException(string2);
    }
}

