/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.internal;

import com.google.android.gms.internal.zzaf;
import com.google.android.gms.internal.zzal;
import com.google.android.gms.internal.zzao;
import com.google.android.gms.internal.zzaqt;
import com.google.android.gms.internal.zzasa;
import com.google.android.gms.internal.zzdn;
import com.google.android.gms.internal.zzdr;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

final class zzan {
    static boolean zzyj = false;
    private static MessageDigest zzyk = null;
    private static final Object zzyl = new Object();
    private static final Object zzym = new Object();
    static CountDownLatch zzyn = new CountDownLatch(1);

    private static int zza(boolean bl) {
        if (bl) {
            return 239;
        }
        return 255;
    }

    static String zza(zzaf.zza zza2, String string2, boolean bl) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        return zzan.zza(zzasa.zzf(zza2), string2, bl);
    }

    static String zza(String arrby, String string2, boolean bl) {
        if ((arrby = zzan.zzb((String)arrby, string2, bl)) != null) {
            return zzal.zza(arrby, true);
        }
        return Integer.toString(7);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static String zza(byte[] arrby, String string2, boolean bl) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        if (bl) {
            arrby = zzan.zzb(arrby, string2);
            do {
                return zzal.zza(arrby, true);
                break;
            } while (true);
        }
        arrby = zzan.zza(arrby, string2);
        return zzal.zza(arrby, true);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static Vector<byte[]> zza(byte[] arrby, int n) {
        if (arrby == null) return null;
        if (arrby.length <= 0) {
            return null;
        }
        int n2 = (arrby.length + n - 1) / n;
        Vector<byte[]> vector = new Vector<byte[]>();
        int n3 = 0;
        while (n3 < n2) {
            int n4 = n3 * n;
            int n5 = arrby.length - n4 > n ? n4 + n : arrby.length;
            vector.add(Arrays.copyOfRange(arrby, n4, n5));
            ++n3;
            continue;
        }
        return vector;
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return null;
        }
    }

    static void zza(String string2, byte[] arrby) throws UnsupportedEncodingException {
        String string3 = string2;
        if (string2.length() > 32) {
            string3 = string2.substring(0, 32);
        }
        new zzaqt(string3.getBytes("UTF-8")).zzay(arrby);
    }

    static byte[] zza(byte[] arrby, String string2) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        Vector<byte[]> vector = zzan.zza(arrby, 255);
        if (vector == null || vector.size() == 0) {
            return zzan.zzb(zzasa.zzf(zzan.zzb(4096)), string2);
        }
        zzaf.zzf zzf2 = new zzaf.zzf();
        zzf2.zzga = new byte[vector.size()][];
        vector = vector.iterator();
        int n = 0;
        while (vector.hasNext()) {
            byte[] arrby2;
            zzf2.zzga[n] = arrby2 = zzan.zzb((byte[])vector.next(), string2, false);
            ++n;
        }
        zzf2.zzfv = zzan.zzh(arrby);
        return zzasa.zzf(zzf2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void zzau() {
        Object object = zzym;
        synchronized (object) {
            if (!zzyj) {
                zzyj = true;
                new Thread(new zza()).start();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static MessageDigest zzav() {
        boolean bl;
        zzan.zzau();
        bl = false;
        try {
            boolean bl2;
            bl = bl2 = zzyn.await(2, TimeUnit.SECONDS);
        }
        catch (InterruptedException var2_2) {}
        if (!bl || zzyk == null) {
            return null;
        }
        return zzyk;
    }

    static zzaf.zza zzb(long l) {
        zzaf.zza zza2 = new zzaf.zza();
        zza2.zzdt = l;
        return zza2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static byte[] zzb(String arrby, String string2, boolean bl) {
        zzaf.zzc zzc2 = new zzaf.zzc();
        try {
            arrby = arrby.length() < 3 ? arrby.getBytes("ISO-8859-1") : zzal.zza((String)arrby, true);
            zzc2.zzft = arrby;
            arrby = bl ? (string2.length() < 3 ? string2.getBytes("ISO-8859-1") : zzal.zza(string2, true)) : (string2 == null || string2.length() == 0 ? Integer.toString(5).getBytes("ISO-8859-1") : zzal.zza(zzan.zza(string2.getBytes("ISO-8859-1"), null, (boolean)zzdr.zzbho.get()), true));
            zzc2.zzfu = arrby;
            return zzasa.zzf(zzc2);
        }
        catch (NoSuchAlgorithmException var0_1) {
            return null;
        }
        catch (UnsupportedEncodingException var0_2) {
            return null;
        }
    }

    static byte[] zzb(byte[] arrby, String string2) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        return zzan.zzb(arrby, string2, true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static byte[] zzb(byte[] arrby, String string2, boolean bl) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        int n = zzan.zza(bl);
        byte[] arrby2 = arrby;
        if (arrby.length > n) {
            arrby2 = zzasa.zzf(zzan.zzb(4096));
        }
        if (arrby2.length < n) {
            arrby = new byte[n - arrby2.length];
            new SecureRandom().nextBytes(arrby);
            arrby = ByteBuffer.allocate(n + 1).put((byte)arrby2.length).put(arrby2).put(arrby).array();
        } else {
            arrby = ByteBuffer.allocate(n + 1).put((byte)arrby2.length).put(arrby2).array();
        }
        arrby2 = arrby;
        if (bl) {
            arrby2 = zzan.zzh(arrby);
            arrby2 = ByteBuffer.allocate(256).put(arrby2).put(arrby).array();
        }
        arrby = new byte[256];
        new zzao().zzb(arrby2, arrby);
        if (string2 != null && string2.length() > 0) {
            zzan.zza(string2, arrby);
        }
        return arrby;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static byte[] zzh(byte[] arrby) throws NoSuchAlgorithmException {
        Object object = zzyl;
        synchronized (object) {
            MessageDigest messageDigest = zzan.zzav();
            if (messageDigest == null) {
                throw new NoSuchAlgorithmException("Cannot compute hash");
            }
            messageDigest.reset();
            messageDigest.update(arrby);
            return zzyk.digest();
        }
    }

    private static final class zza
    implements Runnable {
        private zza() {
        }

        @Override
        public void run() {
            try {
                zzyk = MessageDigest.getInstance("MD5");
                return;
            }
            catch (NoSuchAlgorithmException var1_1) {
                return;
            }
            finally {
                zzan.zzyn.countDown();
            }
        }
    }

}

