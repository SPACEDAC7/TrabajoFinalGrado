/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.app;

import android.support.v4.app.NotificationCompatBase;

interface NotificationBuilderWithActions {
    public void addAction(NotificationCompatBase.Action var1);
}

