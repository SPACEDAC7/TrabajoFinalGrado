/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.AndroidRuntimeException
 */
package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class SuperNotCalledException
extends AndroidRuntimeException {
    public SuperNotCalledException(String string2) {
        super(string2);
    }
}

