/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 */
package android.support.v4.content;

import android.content.Intent;

class IntentCompatIcsMr1 {
    IntentCompatIcsMr1() {
    }

    public static Intent makeMainSelectorActivity(String string2, String string3) {
        return Intent.makeMainSelectorActivity((String)string2, (String)string3);
    }
}

