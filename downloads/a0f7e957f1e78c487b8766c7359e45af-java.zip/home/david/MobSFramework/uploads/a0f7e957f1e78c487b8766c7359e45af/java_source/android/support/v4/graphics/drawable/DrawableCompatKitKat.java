/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 */
package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;

class DrawableCompatKitKat {
    DrawableCompatKitKat() {
    }

    public static boolean isAutoMirrored(Drawable drawable2) {
        return drawable2.isAutoMirrored();
    }

    public static void setAutoMirrored(Drawable drawable2, boolean bl) {
        drawable2.setAutoMirrored(bl);
    }
}

