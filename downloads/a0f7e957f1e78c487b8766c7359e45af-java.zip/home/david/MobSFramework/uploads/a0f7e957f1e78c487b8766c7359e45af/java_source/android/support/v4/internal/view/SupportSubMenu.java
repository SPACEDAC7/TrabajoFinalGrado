/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.SubMenu
 */
package android.support.v4.internal.view;

import android.support.v4.internal.view.SupportMenu;
import android.view.SubMenu;

public interface SupportSubMenu
extends SupportMenu,
SubMenu {
}

