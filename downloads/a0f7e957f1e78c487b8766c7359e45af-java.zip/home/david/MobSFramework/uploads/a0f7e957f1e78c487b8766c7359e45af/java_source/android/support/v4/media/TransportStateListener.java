/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.media;

import android.support.v4.media.TransportController;

public class TransportStateListener {
    public void onPlayingChanged(TransportController transportController) {
    }

    public void onTransportControlsChanged(TransportController transportController) {
    }
}

