/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.text;

public interface TextDirectionHeuristicCompat {
    public boolean isRtl(CharSequence var1, int var2, int var3);

    public boolean isRtl(char[] var1, int var2, int var3);
}

