/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.MenuItem
 */
package android.support.v4.view;

import android.support.v4.view.MenuItemCompat;
import android.view.MenuItem;

public class MenuCompat {
    @Deprecated
    public static void setShowAsAction(MenuItem menuItem, int n2) {
        MenuItemCompat.setShowAsAction(menuItem, n2);
    }
}

