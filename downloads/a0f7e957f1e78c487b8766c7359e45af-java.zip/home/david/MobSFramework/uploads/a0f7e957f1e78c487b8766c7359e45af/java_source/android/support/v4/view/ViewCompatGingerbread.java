/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package android.support.v4.view;

import android.view.View;

class ViewCompatGingerbread {
    ViewCompatGingerbread() {
    }

    public static int getOverScrollMode(View view) {
        return view.getOverScrollMode();
    }

    public static void setOverScrollMode(View view, int n2) {
        view.setOverScrollMode(n2);
    }
}

