/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.ViewConfiguration
 */
package android.support.v4.view;

import android.view.ViewConfiguration;

class ViewConfigurationCompatFroyo {
    ViewConfigurationCompatFroyo() {
    }

    public static int getScaledPagingTouchSlop(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledPagingTouchSlop();
    }
}

