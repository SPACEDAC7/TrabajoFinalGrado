/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package android.support.v4.view;

import android.view.View;

public interface ViewPropertyAnimatorListener {
    public void onAnimationCancel(View var1);

    public void onAnimationEnd(View var1);

    public void onAnimationStart(View var1);
}

