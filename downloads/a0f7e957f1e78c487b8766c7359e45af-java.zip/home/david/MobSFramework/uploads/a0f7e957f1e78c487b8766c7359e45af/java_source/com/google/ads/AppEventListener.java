/*
 * Decompiled with CFR 0_115.
 */
package com.google.ads;

import com.google.ads.Ad;

public interface AppEventListener {
    public void onAppEvent(Ad var1, String var2, String var3);
}

