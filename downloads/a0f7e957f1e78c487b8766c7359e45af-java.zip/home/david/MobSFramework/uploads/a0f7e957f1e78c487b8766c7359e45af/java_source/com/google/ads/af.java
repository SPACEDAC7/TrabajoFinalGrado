/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.google.ads;

import android.net.Uri;

public class af {
    public static final Uri a = Uri.parse((String)"content://com.google.plus.platform/ads");
    public static final Uri b = Uri.parse((String)"content://com.google.plus.platform/token");
    public static final String[] c = new String[]{"_id", "has_plus1"};
    public static final String[] d = new String[]{"drt"};
}

