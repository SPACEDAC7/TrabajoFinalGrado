/*
 * Decompiled with CFR 0_115.
 */
package com.google.ads.mediation;

import com.google.ads.mediation.NetworkExtras;

public final class EmptyNetworkExtras
implements NetworkExtras {
}

