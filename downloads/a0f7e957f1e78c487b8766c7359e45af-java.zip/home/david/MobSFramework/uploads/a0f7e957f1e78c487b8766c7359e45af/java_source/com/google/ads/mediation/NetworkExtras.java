/*
 * Decompiled with CFR 0_115.
 */
package com.google.ads.mediation;

public interface NetworkExtras {
}

