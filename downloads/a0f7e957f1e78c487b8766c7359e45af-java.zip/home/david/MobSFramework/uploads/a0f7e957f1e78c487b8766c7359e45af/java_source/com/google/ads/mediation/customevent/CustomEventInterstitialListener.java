/*
 * Decompiled with CFR 0_115.
 */
package com.google.ads.mediation.customevent;

import com.google.ads.mediation.customevent.CustomEventListener;

public interface CustomEventInterstitialListener
extends CustomEventListener {
    public void onReceivedAd();
}

