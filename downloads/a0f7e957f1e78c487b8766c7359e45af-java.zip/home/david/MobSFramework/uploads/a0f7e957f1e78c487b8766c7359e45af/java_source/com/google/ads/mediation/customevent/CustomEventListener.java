/*
 * Decompiled with CFR 0_115.
 */
package com.google.ads.mediation.customevent;

public interface CustomEventListener {
    public void onDismissScreen();

    public void onFailedToReceiveAd();

    public void onLeaveApplication();

    public void onPresentScreen();
}

