/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.webkit.WebView
 */
package com.google.ads;

import android.webkit.WebView;
import com.google.ads.internal.d;
import java.util.HashMap;

public interface n {
    public void a(d var1, HashMap<String, String> var2, WebView var3);
}

