/*
 * Decompiled with CFR 0_115.
 */
package com.google.ads.util;

public interface f<T> {
    public T b();
}

