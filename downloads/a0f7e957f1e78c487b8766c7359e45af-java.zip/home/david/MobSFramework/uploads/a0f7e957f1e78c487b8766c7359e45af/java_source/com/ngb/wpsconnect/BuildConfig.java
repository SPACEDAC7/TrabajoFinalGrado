/*
 * Decompiled with CFR 0_115.
 */
package com.ngb.wpsconnect;

public final class BuildConfig {
    public static final boolean DEBUG = false;
}

