/*
 * Decompiled with CFR 0_115.
 */
package com.ngb.wpsconnect;

public final class R {

    public static final class attr {
    }

    public static final class dimen {
        public static final int activity_horizontal_margin = 2131034112;
        public static final int activity_vertical_margin = 2131034113;
    }

    public static final class drawable {
        public static final int ic_launcher = 2130837504;
        public static final int iwps = 2130837505;
        public static final int lock = 2130837506;
        public static final int unlock = 2130837507;
        public static final int wifisignal1 = 2130837508;
        public static final int wifisignal2 = 2130837509;
        public static final int wifisignal3 = 2130837510;
        public static final int wifisignal4 = 2130837511;
    }

    public static final class id {
        public static final int ImgLock = 2131296260;
        public static final int ImgWiFiSignal = 2131296262;
        public static final int LblBSSID = 2131296264;
        public static final int LblESSID = 2131296261;
        public static final int LblInfo = 2131296263;
        public static final int LblNetworkName = 2131296258;
        public static final int LblNetworkPassword = 2131296259;
        public static final int LblSignal = 2131296265;
        public static final int action_about = 2131296271;
        public static final int action_backupPass = 2131296272;
        public static final int action_scan = 2131296268;
        public static final int action_scanOption = 2131296269;
        public static final int action_showpwd = 2131296270;
        public static final int adView = 2131296256;
        public static final int adViewPwd = 2131296266;
        public static final int list = 2131296257;
        public static final int listpwd = 2131296267;
    }

    public static final class layout {
        public static final int about = 2130903040;
        public static final int activity_main = 2130903041;
        public static final int listitem_pwd = 2130903042;
        public static final int listitem_titular = 2130903043;
        public static final int no_networks = 2130903044;
        public static final int show_password = 2130903045;
    }

    public static final class menu {
        public static final int main = 2131230720;
        public static final int menu_pass = 2131230721;
    }

    public static final class raw {
        public static final int wpa_cli = 2130968576;
    }

    public static final class string {
        public static final int aboutMsg = 2131099655;
        public static final int action_about = 2131099649;
        public static final int action_backupPass = 2131099673;
        public static final int action_scan = 2131099650;
        public static final int action_scanAuto = 2131099651;
        public static final int action_scanManual = 2131099652;
        public static final int action_showpwd = 2131099653;
        public static final int alertDialog_trycustompin = 2131099657;
        public static final int alertDialog_trypin = 2131099656;
        public static final int app_descrip = 2131099654;
        public static final int app_name = 2131099648;
        public static final int cancel = 2131099659;
        public static final int choosePIN = 2131099661;
        public static final int clipBoard = 2131099665;
        public static final int connected = 2131099669;
        public static final int copyClipBoard = 2131099666;
        public static final int enableWiFi = 2131099658;
        public static final int enablingWiFi = 2131099672;
        public static final int failDialogMsg = 2131099676;
        public static final int lblInsertPIN = 2131099664;
        public static final int lblPassword = 2131099663;
        public static final int lblSSID = 2131099662;
        public static final int noInfoToClipBoard = 2131099667;
        public static final int noNetAvailable = 2131099668;
        public static final int noRootInfo = 2131099677;
        public static final int no_available = 2131099675;
        public static final int ok = 2131099660;
        public static final int saveprocess = 2131099674;
        public static final int scanning = 2131099671;
        public static final int tryConnection = 2131099670;
    }

    public static final class style {
        public static final int AppBaseTheme = 2131165184;
        public static final int AppTheme = 2131165185;
    }

}

