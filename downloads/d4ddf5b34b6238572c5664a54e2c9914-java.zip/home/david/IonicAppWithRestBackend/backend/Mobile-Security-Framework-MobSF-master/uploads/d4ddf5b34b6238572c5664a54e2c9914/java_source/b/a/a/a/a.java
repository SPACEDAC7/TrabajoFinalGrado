/*
 * Decompiled with CFR 0_115.
 */
package b.a.a.a;

import b.a.a.a.b;
import java.security.GeneralSecurityException;
import java.security.Principal;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.LinkedList;
import javax.security.auth.x500.X500Principal;

public final class a {
    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static X509Certificate[] a(Certificate[] object, b b2) {
        boolean bl2;
        boolean bl3 = false;
        boolean bl4 = true;
        LinkedList<Object> linkedList = new LinkedList<Object>();
        X509Certificate x509Certificate = (X509Certificate)object[0];
        if (b2.a(x509Certificate)) {
            bl3 = true;
        }
        linkedList.add(x509Certificate);
        int n2 = 1;
        do {
            bl2 = bl3;
            if (n2 >= object.length) break;
            x509Certificate = (X509Certificate)object[n2];
            X509Certificate x509Certificate2 = (X509Certificate)object[n2 - 1];
            if (b2.a(x509Certificate)) {
                bl3 = true;
            }
            boolean bl5 = false;
            if (x509Certificate.getSubjectX500Principal().equals(x509Certificate2.getIssuerX500Principal())) {
                try {
                    x509Certificate2.verify(x509Certificate.getPublicKey());
                    bl5 = true;
                }
                catch (GeneralSecurityException var9_11) {}
            }
            bl2 = bl3;
            if (!bl5) break;
            linkedList.add(x509Certificate);
            ++n2;
        } while (true);
        x509Certificate = (X509Certificate)object[n2 - 1];
        object = b2.c.get(x509Certificate.getIssuerX500Principal());
        if (object == null) {
            object = null;
        } else if (object.getSubjectX500Principal().equals(x509Certificate.getSubjectX500Principal())) {
            object = null;
        } else {
            try {
                x509Certificate.verify(object.getPublicKey());
            }
            catch (GeneralSecurityException var0_1) {
                object = null;
            }
        }
        if (object != null) {
            linkedList.add(object);
            bl3 = bl4;
        } else {
            bl3 = bl2;
        }
        if (bl3) {
            return linkedList.toArray(new X509Certificate[linkedList.size()]);
        }
        throw new CertificateException("Didn't find a trust anchor in chain cleanup!");
    }
}

