/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 */
package b.a.a.a;

import android.annotation.TargetApi;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import java.util.HashMap;
import javax.security.auth.x500.X500Principal;

public final class b {
    private static b b;
    public final KeyStore a;
    public final HashMap<Principal, X509Certificate> c;

    private b() {
        KeyStore keyStore = b.b();
        this.c = b.a(keyStore);
        this.a = keyStore;
    }

    public static b a() {
        synchronized (b.class) {
            if (b == null) {
                b = new b();
            }
            b b2 = b;
            return b2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static HashMap<Principal, X509Certificate> a(KeyStore keyStore) {
        try {
            HashMap<Principal, X509Certificate> hashMap = new HashMap<Principal, X509Certificate>();
            Enumeration<String> enumeration = keyStore.aliases();
            while (enumeration.hasMoreElements()) {
                X509Certificate x509Certificate = (X509Certificate)keyStore.getCertificate(enumeration.nextElement());
                if (x509Certificate == null) continue;
                hashMap.put(x509Certificate.getSubjectX500Principal(), x509Certificate);
            }
            return hashMap;
        }
        catch (KeyStoreException var0_1) {
            throw new AssertionError(var0_1);
        }
    }

    @TargetApi(value=14)
    private static KeyStore b() {
        try {
            KeyStore keyStore = KeyStore.getInstance("AndroidCAStore");
            keyStore.load(null, null);
            return keyStore;
        }
        catch (NoSuchAlgorithmException var0_1) {
            throw new AssertionError(var0_1);
        }
        catch (KeyStoreException var0_2) {
            throw new AssertionError(var0_2);
        }
        catch (CertificateException var0_3) {
            throw new AssertionError(var0_3);
        }
        catch (FileNotFoundException var0_4) {
            throw new AssertionError(var0_4);
        }
        catch (IOException var0_5) {
            throw new AssertionError(var0_5);
        }
    }

    public final boolean a(X509Certificate x509Certificate) {
        X509Certificate x509Certificate2 = this.c.get(x509Certificate.getSubjectX500Principal());
        if (x509Certificate2 != null && x509Certificate2.getPublicKey().equals(x509Certificate.getPublicKey())) {
            return true;
        }
        return false;
    }
}

