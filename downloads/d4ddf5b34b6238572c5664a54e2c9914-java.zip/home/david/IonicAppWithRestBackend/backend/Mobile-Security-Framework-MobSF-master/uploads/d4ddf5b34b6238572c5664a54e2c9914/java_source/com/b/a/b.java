/*
 * Decompiled with CFR 0_115.
 */
package com.b.a;

final class b {
    long a;
    boolean b;
    b c;

    b() {
    }
}

