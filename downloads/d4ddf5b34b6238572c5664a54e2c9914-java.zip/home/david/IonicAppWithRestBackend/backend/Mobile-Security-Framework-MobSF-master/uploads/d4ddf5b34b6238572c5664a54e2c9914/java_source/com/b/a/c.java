/*
 * Decompiled with CFR 0_115.
 */
package com.b.a;

import com.b.a.b;

final class c {
    b a;

    c() {
    }
}

