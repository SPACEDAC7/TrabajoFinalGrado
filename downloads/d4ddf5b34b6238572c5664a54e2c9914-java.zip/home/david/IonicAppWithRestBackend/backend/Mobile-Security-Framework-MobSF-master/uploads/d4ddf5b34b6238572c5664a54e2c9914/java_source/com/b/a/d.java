/*
 * Decompiled with CFR 0_115.
 */
package com.b.a;

import com.b.a.b;
import com.b.a.c;

final class d {
    final c a = new c();
    b b;
    b c;
    int d;
    int e;

    d() {
    }
}

