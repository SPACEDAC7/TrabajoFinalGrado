/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 */
package com.b.a;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import com.b.a.a;
import com.b.a.b;
import com.b.a.c;
import com.b.a.d;

public final class e
implements SensorEventListener {
    public SensorManager a;
    public Sensor b;
    private final d c = new d();
    private final a d;

    public e(a a2) {
        this.d = a2;
    }

    public final void onAccuracyChanged(Sensor sensor, int n2) {
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void onSensorChanged(SensorEvent object) {
        c c2;
        float f2 = object.values[0];
        float f3 = object.values[1];
        float f4 = object.values[2];
        boolean bl2 = Math.sqrt(f2 * f2 + f3 * f3 + f4 * f4) > 13.0;
        long l2 = object.timestamp;
        Object object2 = this.c;
        while (object2.d >= 4 && object2.b != null && l2 - 500000000 - object2.b.a > 0) {
            object = object2.b;
            if (object.b) {
                --object2.e;
            }
            --object2.d;
            object2.b = object.c;
            if (object2.b == null) {
                object2.c = null;
            }
            c2 = object2.a;
            object.c = c2.a;
            c2.a = object;
        }
        c2 = object2.a;
        object = c2.a;
        if (object == null) {
            object = new b();
        } else {
            c2.a = object.c;
        }
        object.a = l2;
        object.b = bl2;
        object.c = null;
        if (object2.c != null) {
            object2.c.c = object;
        }
        object2.c = object;
        if (object2.b == null) {
            object2.b = object;
        }
        ++object2.d;
        if (bl2) {
            ++object2.e;
        }
        object = this.c;
        if (object.c == null) return;
        if (object.b == null) return;
        if (object.c.a - object.b.a < 250000000) return;
        int n2 = object.e;
        int n3 = object.d;
        if (n2 < (object.d >> 2) + (n3 >> 1)) return;
        n2 = 1;
        if (n2 == 0) return;
        object = this.c;
        do {
            if (object.b == null) {
                object.c = null;
                object.d = 0;
                object.e = 0;
                this.d.a();
                return;
            }
            object2 = object.b;
            object.b = object2.c;
            c2 = object.a;
            object2.c = c2.a;
            c2.a = object2;
        } while (true);
    }
}

