/*
 * Decompiled with CFR 0_115.
 */
package com.c.a;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import javax.net.SocketFactory;

public class a {
    private SocketFactory mSocketFactory = SocketFactory.getDefault();

    public void connectSocket(Socket socket, String string, int n2) {
        socket.connect(new InetSocketAddress(string, n2));
    }

    public Socket createSocket(boolean bl2) {
        if (!bl2) {
            return this.mSocketFactory.createSocket();
        }
        throw new UnsupportedOperationException();
    }
}

