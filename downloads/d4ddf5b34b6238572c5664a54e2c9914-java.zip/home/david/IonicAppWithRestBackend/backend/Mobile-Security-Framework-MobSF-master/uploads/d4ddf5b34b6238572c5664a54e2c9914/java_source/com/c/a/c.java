/*
 * Decompiled with CFR 0_115.
 */
package com.c.a;

import java.io.IOException;

public final class c
extends IOException {
    public c(String string) {
        super(string);
    }
}

