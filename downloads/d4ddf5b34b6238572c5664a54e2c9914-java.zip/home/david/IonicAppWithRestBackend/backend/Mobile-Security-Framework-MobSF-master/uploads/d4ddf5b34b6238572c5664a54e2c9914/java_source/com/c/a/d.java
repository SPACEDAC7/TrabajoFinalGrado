/*
 * Decompiled with CFR 0_115.
 */
package com.c.a;

import java.io.DataInputStream;
import java.io.InputStream;

public final class d
extends DataInputStream {
    public d(InputStream inputStream) {
        super(inputStream);
    }
}

