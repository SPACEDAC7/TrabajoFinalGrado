/*
 * Decompiled with CFR 0_115.
 */
package com.c.a;

import com.c.a.c;
import com.c.a.d;
import com.c.a.i;
import com.c.a.q;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.List;

public final class e {
    private static final List<Integer> o = Arrays.asList(0, 1, 2, 8, 9, 10);
    private static final List<Integer> p = Arrays.asList(0, 1, 2);
    private q a;
    private i b;
    private boolean c = true;
    private int d;
    private boolean e;
    private boolean f;
    private int g;
    private int h;
    private int i;
    private int j;
    private byte[] k = new byte[0];
    private byte[] l = new byte[0];
    private boolean m = false;
    private ByteArrayOutputStream n = new ByteArrayOutputStream();

    public e(q q2, i i2) {
        this.a = q2;
        this.b = i2;
    }

    private static String a(byte[] object) {
        try {
            object = new String((byte[])object, "UTF-8");
            return object;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw new RuntimeException(var0_1);
        }
    }

    private static byte[] a(String arrby) {
        try {
            arrby = arrby.getBytes("UTF-8");
            return arrby;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw new RuntimeException(var0_1);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static byte[] a(byte[] arrby, byte[] arrby2, int n2) {
        if (arrby2.length == 0) {
            return arrby;
        }
        int n3 = 0;
        while (n3 < arrby.length - n2) {
            arrby[n2 + n3] = (byte)(arrby[n2 + n3] ^ arrby2[n3 % 4]);
            ++n3;
        }
        return arrby;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(d d2) {
        block7 : do {
            int n2;
            Object object;
            if (d2.available() == -1) {
                this.b.onDisconnect(0, "EOF");
                return;
            }
            switch (this.d) {
                int n3;
                boolean bl2;
                default: {
                    continue block7;
                }
                case 0: {
                    byte by2 = d2.readByte();
                    n2 = (by2 & 64) == 64 ? 1 : 0;
                    n3 = (by2 & 32) == 32 ? 1 : 0;
                    boolean bl3 = (by2 & 16) == 16;
                    if (n2 != 0 || n3 != 0 || bl3) {
                        throw new c("RSV not zero");
                    }
                    bl2 = (by2 & 128) == 128;
                    this.e = bl2;
                    this.g = by2 & 15;
                    this.k = new byte[0];
                    this.l = new byte[0];
                    if (!o.contains(this.g)) {
                        throw new c("Bad opcode");
                    }
                    if (!p.contains(this.g) && !this.e) {
                        throw new c("Expected non-final packet");
                    }
                    this.d = 1;
                    continue block7;
                }
                case 1: {
                    n2 = d2.readByte();
                    bl2 = (n2 & 128) == 128;
                    this.f = bl2;
                    this.i = n2 & 127;
                    if (this.i >= 0 && this.i <= 125) {
                        n2 = this.f ? 3 : 4;
                        this.d = n2;
                        continue block7;
                    }
                    n2 = this.i == 126 ? 2 : 8;
                    this.h = n2;
                    this.d = 2;
                    continue block7;
                }
                case 2: {
                    n3 = this.h;
                    object = new byte[n3];
                    d2.readFully((byte[])object);
                    long l2 = 0;
                    for (n2 = 0; n2 < n3; l2 += (long)((object[n2 + 0] & 255) << (n3 - 1 - n2) * 8), ++n2) {
                    }
                    if (l2 < 0 || l2 > Integer.MAX_VALUE) {
                        throw new c("Bad integer: " + l2);
                    }
                    this.i = (int)l2;
                    n2 = this.f ? 3 : 4;
                    this.d = n2;
                    continue block7;
                }
                case 3: {
                    object = new byte[4];
                    d2.readFully((byte[])object);
                    this.k = object;
                    this.d = 4;
                    continue block7;
                }
                case 4: 
            }
            object = new byte[this.i];
            d2.readFully((byte[])object);
            this.l = object;
            object = e.a(this.l, this.k, 0);
            n2 = this.g;
            if (n2 == 0) {
                if (this.j == 0) {
                    throw new c("Mode was not set.");
                }
                this.n.write((byte[])object);
                if (this.e) {
                    object = this.n.toByteArray();
                    if (this.j == 1) {
                        this.b.onMessage(e.a((byte[])object));
                    } else {
                        this.b.onMessage((byte[])object);
                    }
                    this.j = 0;
                    this.n.reset();
                }
            } else if (n2 == 1) {
                if (this.e) {
                    object = e.a((byte[])object);
                    this.b.onMessage((String)object);
                } else {
                    this.j = 1;
                    this.n.write((byte[])object);
                }
            } else if (n2 == 2) {
                if (this.e) {
                    this.b.onMessage((byte[])object);
                } else {
                    this.j = 2;
                    this.n.write((byte[])object);
                }
            } else if (n2 == 8) {
                n2 = object.length >= 2 ? object[0] * 256 + object[1] : 0;
                object = object.length > 2 ? e.a(Arrays.copyOfRange((byte[])object, 2, object.length)) : null;
                new StringBuilder("Got close op! ").append(n2).append(" ").append((String)object);
                this.b.onDisconnect(n2, (String)object);
            } else if (n2 == 9) {
                if (object.length > 125) {
                    throw new c("Ping payload too large");
                }
                this.b.onPing();
                this.a.a(this.a(object, 10, -1));
            } else if (n2 == 10) {
                e.a((byte[])object);
            }
            this.d = 0;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    final byte[] a(Object arrby, int n2, int n3) {
        int n4;
        if (this.m) {
            return null;
        }
        new StringBuilder("Creating frame for: ").append(arrby).append(" op: ").append(n2).append(" err: -1");
        if (arrby instanceof String) {
            arrby = e.a((String)arrby);
        }
        n3 = (n4 = arrby.length + 0) <= 125 ? 2 : (n4 <= 65535 ? 4 : 10);
        int n5 = this.c ? 4 : 0;
        int n6 = n3 + n5;
        n5 = this.c ? 128 : 0;
        byte[] arrby2 = new byte[n4 + n6];
        arrby2[0] = (byte)((byte)n2 | -128);
        if (n4 <= 125) {
            arrby2[1] = (byte)(n5 | n4);
        } else if (n4 <= 65535) {
            arrby2[1] = (byte)(n5 | 126);
            arrby2[2] = (byte)Math.floor(n4 / 256);
            arrby2[3] = (byte)(n4 & 255);
        } else {
            arrby2[1] = (byte)(n5 | 127);
            arrby2[2] = (byte)((int)Math.floor((double)n4 / Math.pow(2.0, 56.0)) & 255);
            arrby2[3] = (byte)((int)Math.floor((double)n4 / Math.pow(2.0, 48.0)) & 255);
            arrby2[4] = (byte)((int)Math.floor((double)n4 / Math.pow(2.0, 40.0)) & 255);
            arrby2[5] = (byte)((int)Math.floor((double)n4 / Math.pow(2.0, 32.0)) & 255);
            arrby2[6] = (byte)((int)Math.floor((double)n4 / Math.pow(2.0, 24.0)) & 255);
            arrby2[7] = (byte)((int)Math.floor((double)n4 / Math.pow(2.0, 16.0)) & 255);
            arrby2[8] = (byte)((int)Math.floor((double)n4 / Math.pow(2.0, 8.0)) & 255);
            arrby2[9] = (byte)(n4 & 255);
        }
        System.arraycopy(arrby, 0, arrby2, n6 + 0, arrby.length);
        if (this.c) {
            arrby = new byte[]{(byte)Math.floor(Math.random() * 256.0), (byte)Math.floor(Math.random() * 256.0), (byte)Math.floor(Math.random() * 256.0), (byte)Math.floor(Math.random() * 256.0)};
            System.arraycopy(arrby, 0, arrby2, n3, 4);
            e.a(arrby2, arrby, n6);
        }
        return arrby2;
    }
}

