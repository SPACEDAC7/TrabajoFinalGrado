/*
 * Decompiled with CFR 0_115.
 */
package com.c.a;

import com.c.a.p;
import com.c.a.q;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

final class h
implements Runnable {
    final /* synthetic */ byte[] a;
    final /* synthetic */ q b;

    h(q q2, byte[] arrby) {
        this.b = q2;
        this.a = arrby;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void run() {
        Object object;
        block7 : {
            try {
                object = this.b.h;
                synchronized (object) {
                    if (this.b.c != null) break block7;
                }
            }
            catch (IOException var1_2) {
                this.b.b.onError(var1_2);
                return;
            }
            return;
        }
        object = this.b.c.getOutputStream();
        object.write(this.a);
        object.flush();
    }
}

