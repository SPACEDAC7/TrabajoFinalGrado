/*
 * Decompiled with CFR 0_115.
 */
package com.c.a;

public interface i {
    public void onConnect();

    public void onDisconnect(int var1, String var2);

    public void onError(Exception var1);

    public void onMessage(String var1);

    public void onMessage(byte[] var1);

    public void onPing();
}

