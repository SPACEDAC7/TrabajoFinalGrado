/*
 * Decompiled with CFR 0_115.
 */
package com.c.a;

import com.c.a.i;
import com.c.a.p;

final class k
implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ p b;

    k(p p2, String string) {
        this.b = p2;
        this.a = string;
    }

    @Override
    public final void run() {
        if (this.b.a != null) {
            this.b.a.onMessage(this.a);
        }
    }
}

