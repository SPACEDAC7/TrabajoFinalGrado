/*
 * Decompiled with CFR 0_115.
 */
package com.c.a;

import com.c.a.i;
import com.c.a.p;

final class l
implements Runnable {
    final /* synthetic */ byte[] a;
    final /* synthetic */ p b;

    l(p p2, byte[] arrby) {
        this.b = p2;
        this.a = arrby;
    }

    @Override
    public final void run() {
        if (this.b.a != null) {
            this.b.a.onMessage(this.a);
        }
    }
}

