/*
 * Decompiled with CFR 0_115.
 */
package com.c.a;

import com.c.a.i;
import com.c.a.p;

final class m
implements Runnable {
    final /* synthetic */ p a;

    m(p p2) {
        this.a = p2;
    }

    @Override
    public final void run() {
        if (this.a.a != null) {
            this.a.a.onPing();
        }
    }
}

