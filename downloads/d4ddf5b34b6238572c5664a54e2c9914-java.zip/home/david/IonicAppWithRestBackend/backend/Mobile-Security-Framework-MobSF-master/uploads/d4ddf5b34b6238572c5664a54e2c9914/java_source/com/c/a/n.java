/*
 * Decompiled with CFR 0_115.
 */
package com.c.a;

import com.c.a.i;
import com.c.a.p;

final class n
implements Runnable {
    final /* synthetic */ int a;
    final /* synthetic */ String b;
    final /* synthetic */ p c;

    n(p p2, int n2, String string) {
        this.c = p2;
        this.a = n2;
        this.b = string;
    }

    @Override
    public final void run() {
        if (this.c.a != null) {
            this.c.a.onDisconnect(this.a, this.b);
        }
    }
}

