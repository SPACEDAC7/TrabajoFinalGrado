/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.c.a;

import android.os.Handler;
import com.c.a.i;
import com.c.a.j;
import com.c.a.k;
import com.c.a.l;
import com.c.a.m;
import com.c.a.n;
import com.c.a.o;
import com.c.a.q;

public final class p
implements i {
    public i a;
    final /* synthetic */ q b;
    private Handler c;

    public p(q q2, Handler handler) {
        this.b = q2;
        this.c = handler;
    }

    @Override
    public final void onConnect() {
        this.c.post((Runnable)new j(this));
    }

    @Override
    public final void onDisconnect(int n2, String string) {
        this.c.post((Runnable)new n(this, n2, string));
    }

    @Override
    public final void onError(Exception exception) {
        this.c.post((Runnable)new o(this, exception));
    }

    @Override
    public final void onMessage(String string) {
        this.c.post((Runnable)new k(this, string));
    }

    @Override
    public final void onMessage(byte[] arrby) {
        this.c.post((Runnable)new l(this, arrby));
    }

    @Override
    public final void onPing() {
        this.c.post((Runnable)new m(this));
    }
}

