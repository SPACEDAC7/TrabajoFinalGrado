/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.util.Base64
 *  com.c.a.b
 *  org.apache.http.message.BasicNameValuePair
 */
package com.c.a;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Base64;
import com.c.a.a;
import com.c.a.b;
import com.c.a.d;
import com.c.a.e;
import com.c.a.g;
import com.c.a.h;
import com.c.a.i;
import com.c.a.p;
import java.net.Socket;
import java.net.URI;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;

public final class q {
    URI a;
    public p b;
    Socket c;
    public Thread d;
    HandlerThread e;
    List<BasicNameValuePair> f;
    e g;
    Object h;
    a i;
    private Handler j;

    public q(URI object, List<BasicNameValuePair> list, b b2) {
        this.a = object;
        this.h = new Object();
        this.b = new p(this, new Handler());
        this.f = list;
        this.g = new e(this, this.b);
        this.e = new HandlerThread("websocket-write-thread");
        this.e.start();
        this.j = new Handler(this.e.getLooper());
        object = b2;
        if (b2 == null) {
            object = new a();
        }
        this.i = object;
    }

    static /* synthetic */ String a(d d2) {
        int n2 = d2.read();
        if (n2 == -1) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder("");
        while (n2 != 10) {
            int n3;
            if (n2 != 13) {
                stringBuilder.append((char)n2);
            }
            n2 = n3 = d2.read();
            if (n3 != -1) continue;
            return null;
        }
        return stringBuilder.toString();
    }

    static String b(String string) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
            messageDigest.update((string + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes());
            string = Base64.encodeToString((byte[])messageDigest.digest(), (int)0).trim();
            return string;
        }
        catch (NoSuchAlgorithmException var0_1) {
            throw new RuntimeException(var0_1);
        }
    }

    public final void a() {
        this.j.post((Runnable)new g(this));
    }

    public final void a(String string) {
        this.a(this.g.a(string, 1, -1));
    }

    final void a(byte[] arrby) {
        this.j.post((Runnable)new h(this, arrby));
    }
}

