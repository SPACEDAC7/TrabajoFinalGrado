/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a.a;

import com.d.a.a.a.a.c;
import com.d.a.a.a.a.i;

public interface a {
    public void a(i var1, c var2);

    public void a(i var1, c var2, c var3);

    public void b(i var1, c var2);
}

