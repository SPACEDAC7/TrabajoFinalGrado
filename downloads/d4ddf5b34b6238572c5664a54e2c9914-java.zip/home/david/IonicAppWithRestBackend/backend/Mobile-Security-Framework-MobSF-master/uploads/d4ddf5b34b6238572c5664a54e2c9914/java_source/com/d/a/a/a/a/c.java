/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a.a;

import com.d.a.a.d.ah;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class c
implements Comparable<c> {
    private static final Pattern g = Pattern.compile("^(.+)\\.(\\d+)\\.(\\d+)\\.v1\\.exo$");
    private static final Pattern h = Pattern.compile("^(.+)\\.(\\d+)\\.(\\d+)\\.v2\\.exo$");
    public final String a;
    public final long b;
    public final long c;
    public final boolean d;
    public final File e;
    public final long f;

    private c(String string, long l2, long l3, boolean bl2, long l4, File file) {
        this.a = string;
        this.b = l2;
        this.c = l3;
        this.d = bl2;
        this.e = file;
        this.f = l4;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static c a(File file) {
        Matcher matcher = h.matcher(file.getName());
        if (!matcher.matches()) {
            return null;
        }
        String string = matcher.group(1);
        int n2 = string.length();
        int n3 = 0;
        int n4 = 0;
        do {
            if (n3 >= n2) {
                if (string == null) return null;
                return c.a(string, Long.parseLong(matcher.group(2)), Long.parseLong(matcher.group(3)), file);
            }
            int n5 = n4;
            if (string.charAt(n3) == '%') {
                n5 = n4 + 1;
            }
            ++n3;
            n4 = n5;
        } while (true);
    }

    public static c a(String string, long l2) {
        return new c(string, l2, -1, false, -1, null);
    }

    public static c a(String string, long l2, long l3) {
        return new c(string, l2, l3, false, -1, null);
    }

    static c a(String string, long l2, long l3, File file) {
        return new c(string, l2, file.length(), true, l3, file);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static File a(File file, String string, long l2, long l3) {
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = string.length();
        int n3 = 0;
        int n4 = 0;
        while (n3 < n2) {
            int n5 = n4;
            if (ah.a(string.charAt(n3))) {
                n5 = n4 + 1;
            }
            ++n3;
            n4 = n5;
        }
        return new File(file, stringBuilder.append(string).append(".").append(l2).append(".").append(l3).append(".v2.exo").toString());
    }

    public static c b(String string, long l2) {
        return new c(string, l2, -1, false, -1, null);
    }

    public static File b(File file) {
        Object object = g.matcher(file.getName());
        if (!object.matches()) {
            return file;
        }
        String string = object.group(1);
        object = c.a(file.getParentFile(), string, Long.parseLong(object.group(2)), Long.parseLong(object.group(3)));
        file.renameTo((File)object);
        return object;
    }

    public final int a(c c2) {
        if (!this.a.equals(c2.a)) {
            return this.a.compareTo(c2.a);
        }
        long l2 = this.b - c2.b;
        if (l2 == 0) {
            return 0;
        }
        if (l2 < 0) {
            return -1;
        }
        return 1;
    }

    @Override
    public final /* synthetic */ int compareTo(Object object) {
        return this.a((c)object);
    }
}

