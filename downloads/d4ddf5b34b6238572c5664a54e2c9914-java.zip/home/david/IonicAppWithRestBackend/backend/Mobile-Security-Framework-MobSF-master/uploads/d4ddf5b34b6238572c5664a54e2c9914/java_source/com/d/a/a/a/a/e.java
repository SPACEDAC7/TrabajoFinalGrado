/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a.a;

import com.d.a.a.a.a.d;
import com.d.a.a.a.a.i;
import com.d.a.a.d.ah;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public final class e {
    private final i a;
    private final long b;
    private com.d.a.a.a.i c;
    private File d;
    private FileOutputStream e;
    private long f;
    private long g;

    public e(i i2) {
        if (i2 == null) {
            throw new NullPointerException();
        }
        this.a = i2;
        this.b = Long.MAX_VALUE;
    }

    private void b() {
        this.d = this.a.a(this.c.f, this.c.c + this.g, Math.min(this.c.e - this.g, this.b));
        this.e = new FileOutputStream(this.d);
        this.f = 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final e a(com.d.a.a.a.i i2) {
        boolean bl2 = i2.e != -1;
        if (!bl2) {
            throw new IllegalStateException();
        }
        try {
            this.c = i2;
            this.g = 0;
            this.b();
            return this;
        }
        catch (FileNotFoundException var1_2) {
            throw new d(var1_2);
        }
    }

    public void a() {
        if (this.e == null) {
            return;
        }
        try {
            this.e.flush();
            this.e.getFD().sync();
        }
        catch (Throwable var1_1) {
            ah.a(this.e);
            this.d.delete();
            this.e = null;
            this.d = null;
            throw var1_1;
        }
        ah.a(this.e);
        this.a.a(this.d);
        this.e = null;
        this.d = null;
    }

    public final void a(byte[] arrby, int n2, int n3) {
        int n4 = 0;
        while (n4 < n3) {
            int n5;
            try {
                if (this.f == this.b) {
                    this.a();
                    this.b();
                }
                n5 = (int)Math.min((long)(n3 - n4), this.b - this.f);
                this.e.write(arrby, n2 + n4, n5);
                n4 += n5;
            }
            catch (IOException var1_2) {
                throw new d(var1_2);
            }
            this.f += (long)n5;
            this.g += (long)n5;
            continue;
        }
    }
}

