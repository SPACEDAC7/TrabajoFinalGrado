/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a.a;

import com.d.a.a.a.a.a;
import com.d.a.a.a.a.i;

public interface f
extends a {
    public void a(i var1, String var2, long var3, long var5);
}

