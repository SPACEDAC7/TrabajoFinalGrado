/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a.a;

import com.d.a.a.a.a.c;
import com.d.a.a.a.a.f;
import com.d.a.a.a.a.i;
import java.util.Comparator;
import java.util.TreeSet;

public class g
implements f,
Comparator<c> {
    private final long a;
    private final TreeSet<c> b;
    private long c;

    public g(long l2) {
        this.a = l2;
        this.b = new TreeSet(this);
    }

    private void a(i i2, long l2) {
        while (this.c + l2 > this.a) {
            i2.b(this.b.first());
        }
    }

    public int a(c c2, c c3) {
        if (c2.f - c3.f == 0) {
            return c2.a(c3);
        }
        if (c2.f < c3.f) {
            return -1;
        }
        return 1;
    }

    @Override
    public void a(i i2, c c2) {
        this.b.add(c2);
        this.c += c2.c;
        this.a(i2, 0);
    }

    @Override
    public void a(i i2, c c2, c c3) {
        this.b(i2, c2);
        this.a(i2, c3);
    }

    @Override
    public void a(i i2, String string, long l2, long l3) {
        this.a(i2, l3);
    }

    @Override
    public void b(i i2, c c2) {
        this.b.remove(c2);
        this.c -= c2.c;
    }

    @Override
    public /* synthetic */ int compare(Object object, Object object2) {
        return this.a((c)object, (c)object2);
    }
}

