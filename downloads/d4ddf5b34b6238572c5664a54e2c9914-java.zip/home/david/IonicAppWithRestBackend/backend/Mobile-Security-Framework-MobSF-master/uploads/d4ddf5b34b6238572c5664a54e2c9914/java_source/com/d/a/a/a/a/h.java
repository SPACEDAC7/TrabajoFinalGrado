/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.ConditionVariable
 */
package com.d.a.a.a.a;

import android.os.ConditionVariable;
import com.d.a.a.a.a.c;
import com.d.a.a.a.a.i;
import java.io.File;

final class h
extends Thread {
    final /* synthetic */ ConditionVariable a;
    final /* synthetic */ i b;

    h(i i2, ConditionVariable conditionVariable) {
        this.b = i2;
        this.a = conditionVariable;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void run() {
        i i2 = this.b;
        synchronized (i2) {
            File[] arrfile;
            this.a.open();
            i i3 = this.b;
            if (!i3.b.exists()) {
                i3.b.mkdirs();
            }
            if ((arrfile = i3.b.listFiles()) == null) {
                return;
            }
            int n2 = 0;
            while (n2 < arrfile.length) {
                File file = arrfile[n2];
                if (file.length() == 0) {
                    new StringBuilder().append(i3.hashCode()).append(" initialize. file.length() == 0. span is null ");
                    file.delete();
                } else {
                    c c2 = c.a(file = c.b(file));
                    if (c2 == null) {
                        new StringBuilder().append(i3.hashCode()).append(" initialize. span == null ");
                        file.delete();
                    } else {
                        i.d(i3, c2);
                    }
                }
                ++n2;
            }
            return;
        }
    }
}

