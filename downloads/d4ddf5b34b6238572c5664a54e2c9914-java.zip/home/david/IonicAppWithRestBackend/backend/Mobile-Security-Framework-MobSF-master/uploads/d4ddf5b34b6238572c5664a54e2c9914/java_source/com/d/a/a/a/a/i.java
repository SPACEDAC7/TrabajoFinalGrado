/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.ConditionVariable
 */
package com.d.a.a.a.a;

import android.os.ConditionVariable;
import com.d.a.a.a.a.a;
import com.d.a.a.a.a.c;
import com.d.a.a.a.a.f;
import com.d.a.a.a.a.h;
import java.io.File;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.NavigableSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public final class i {
    private static final String a = i.class.getSimpleName();
    public final File b;
    public final f c;
    public final HashMap<String, c> d;
    public final HashMap<String, TreeSet<c>> e;
    public final HashMap<String, ArrayList<a>> f;
    private long g = 0;

    public i(File file, f f2) {
        this.b = file;
        this.c = f2;
        this.d = new HashMap();
        this.e = new HashMap();
        this.f = new HashMap();
        file = new ConditionVariable();
        new h(this, (ConditionVariable)file).start();
        file.block();
    }

    private static void a(i i2, String string, c c2) {
        if (c2 == null) {
            new StringBuilder().append(i2.hashCode()).append(" ").append(string).append(" :Span Change: Span is null. ");
            return;
        }
        new StringBuilder().append(i2.hashCode()).append(" ").append(string).append(" :Span Change: key is ").append(c2.a).append("; isCached ").append(c2.d).append("; length is ").append(c2.c);
    }

    /*
     * Exception decompiling
     */
    public static void a(Map<String, c> var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Invisible function parameters on a non-constructor
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.assignSSAIdentifiers(Op02WithProcessedDataAndRefs.java:1505)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.discoverStorageLiveness(Op02WithProcessedDataAndRefs.java:1728)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:384)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private void b() {
        new StringBuilder().append(this.hashCode()).append(" removeStaleSpans ");
        Iterator<Map.Entry<String, TreeSet<c>>> iterator = this.e.entrySet().iterator();
        while (iterator.hasNext()) {
            Iterator<c> iterator2 = iterator.next().getValue().iterator();
            boolean bl2 = true;
            while (iterator2.hasNext()) {
                c c2 = iterator2.next();
                if (!c2.e.exists()) {
                    i.a(this, "removeStaleSpans: span.file.not.exists", c2);
                    iterator2.remove();
                    if (c2.d) {
                        this.g -= c2.c;
                    }
                    this.e(c2);
                    continue;
                }
                bl2 = false;
            }
            if (!bl2) continue;
            iterator.remove();
        }
    }

    /*
     * Exception decompiling
     */
    public static void b(Map<String, TreeSet<c>> var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Invisible function parameters on a non-constructor
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.assignSSAIdentifiers(Op02WithProcessedDataAndRefs.java:1505)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.discoverStorageLiveness(Op02WithProcessedDataAndRefs.java:1728)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:384)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private c c(c comparable) {
        synchronized (this) {
            AbstractCollection abstractCollection2;
            c c2;
            long l2;
            block13 : {
                TreeSet<c> treeSet;
                do {
                    i.a(this, "getSpan", comparable);
                    AbstractCollection abstractCollection2 = comparable.a;
                    l2 = comparable.b;
                    treeSet = this.e.get(abstractCollection2);
                    if (treeSet == null) {
                        c2 = c.b((String)((Object)abstractCollection2), comparable.b);
                    } else {
                        c2 = treeSet.floor((c)comparable);
                        if (c2 == null || c2.b > l2 || l2 >= c2.b + c2.c) break;
                        if (!c2.e.exists()) {
                            this.b();
                            continue;
                        }
                    }
                    break block13;
                    break;
                } while (true);
                c2 = treeSet.ceiling((c)comparable);
                c2 = c2 == null ? c.b((String)((Object)abstractCollection2), comparable.b) : c.a((String)((Object)abstractCollection2), comparable.b, c2.b - comparable.b);
            }
            if (c2.d) {
                abstractCollection2 = this.e.get(c2.a);
                if (!abstractCollection2.remove(c2)) {
                    throw new IllegalStateException();
                }
                l2 = System.currentTimeMillis();
                comparable = c.a(c2.e.getParentFile(), c2.a, c2.b, l2);
                c2.e.renameTo((File)comparable);
                comparable = c.a(c2.a, c2.b, l2, (File)comparable);
                abstractCollection2.add((a)((Object)comparable));
                new StringBuilder().append(this.hashCode()).append(" notifySpanTouched");
                i.a((i)this, this.d);
                i.b((i)this, this.e);
                abstractCollection2 = this.f.get(c2.a);
                if (abstractCollection2 != null) {
                    for (int i2 = abstractCollection2.size() - 1; i2 >= 0; --i2) {
                        abstractCollection2.get(i2).a(this, c2, (c)comparable);
                    }
                }
            } else {
                if (this.d.containsKey(comparable.a)) return null;
                this.d.put(comparable.a, c2);
                return c2;
            }
            this.c.a(this, c2, (c)comparable);
            return comparable;
        }
    }

    public static void d(i i2, c c2) {
        TreeSet<c> treeSet;
        i.a(i2, "addSpan", c2);
        AbstractCollection abstractCollection = treeSet = i2.e.get(c2.a);
        if (treeSet == null) {
            abstractCollection = new TreeSet();
            i2.e.put(c2.a, (TreeSet<c>)abstractCollection);
        }
        abstractCollection.add(c2);
        i2.g += c2.c;
        new StringBuilder().append(i2.hashCode()).append(" notifySpanAdded ");
        i.a((i)i2, i2.d);
        i.b((i)i2, i2.e);
        abstractCollection = i2.f.get(c2.a);
        if (abstractCollection != null) {
            for (int i3 = abstractCollection.size() - 1; i3 >= 0; --i3) {
                ((a)((Object)abstractCollection.get(i3))).a(i2, c2);
            }
        }
        i2.c.a(i2, c2);
    }

    private void e(c c2) {
        new StringBuilder().append(this.hashCode()).append(" notifySpanRemoved ");
        i.a((i)this, this.d);
        i.b((i)this, this.e);
        ArrayList<a> arrayList = this.f.get(c2.a);
        if (arrayList != null) {
            for (int i2 = arrayList.size() - 1; i2 >= 0; --i2) {
                arrayList.get(i2).b(this, c2);
            }
        }
        this.c.b(this, c2);
    }

    public final c a(String object, long l2) {
        synchronized (this) {
            object = this.c(c.a((String)object, l2));
            return object;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final File a(String object, long l2, long l3) {
        synchronized (this) {
            new StringBuilder().append(this.hashCode()).append(" startFile: key is ").append((String)object).append(" ; position is ").append(l2).append(" ; length is ").append(l2);
            i.a((i)this, this.d);
            i.b((i)this, this.e);
            if (!this.d.containsKey(object)) {
                throw new IllegalStateException();
            }
            if (!this.b.exists()) {
                this.b();
                this.b.mkdirs();
            }
            this.c.a(this, (String)object, l2, l3);
            return c.a(this.b, (String)object, l2, System.currentTimeMillis());
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final NavigableSet<c> a(String treeSet) {
        synchronized (this) {
            block6 : {
                treeSet = this.e.get(treeSet);
                if (treeSet != null) break block6;
                return null;
            }
            treeSet = new TreeSet(treeSet);
            return treeSet;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final NavigableSet<c> a(String navigableSet, a a2) {
        synchronized (this) {
            void var2_2;
            void var3_6;
            ArrayList<a> arrayList;
            ArrayList<a> arrayList2 = arrayList = this.f.get(navigableSet);
            if (arrayList == null) {
                ArrayList arrayList3 = new ArrayList();
                this.f.put((String)((Object)navigableSet), arrayList3);
            }
            var3_6.add(var2_2);
            return this.a((String)((Object)navigableSet));
        }
    }

    public final Set<String> a() {
        synchronized (this) {
            HashSet<String> hashSet = new HashSet<String>(this.e.keySet());
            return hashSet;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(c c2) {
        synchronized (this) {
            boolean bl2 = c2 == this.d.remove(c2.a);
            if (!bl2) {
                throw new IllegalStateException();
            }
            this.notifyAll();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(File file) {
        synchronized (this) {
            c c2 = c.a(file);
            boolean bl2 = c2 != null;
            if (!bl2) {
                throw new IllegalStateException();
            }
            if (!this.d.containsKey(c2.a)) {
                throw new IllegalStateException();
            }
            boolean bl3 = file.exists();
            if (bl3) {
                if (file.length() == 0) {
                    file.delete();
                } else {
                    i.d(this, c2);
                    this.notifyAll();
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void b(c c2) {
        synchronized (this) {
            TreeSet<c> treeSet = this.e.get(c2.a);
            this.g -= c2.c;
            if (!treeSet.remove(c2)) {
                throw new IllegalStateException();
            }
            i.a(this, "removeSpan", c2);
            c2.e.delete();
            if (treeSet.isEmpty()) {
                this.e.remove(c2.a);
            }
            this.e(c2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void b(String string, a a2) {
        synchronized (this) {
            ArrayList<a> arrayList = this.f.get(string);
            if (arrayList != null) {
                void var2_2;
                arrayList.remove(var2_2);
                if (arrayList.isEmpty()) {
                    this.f.remove(string);
                }
            }
            return;
        }
    }
}

