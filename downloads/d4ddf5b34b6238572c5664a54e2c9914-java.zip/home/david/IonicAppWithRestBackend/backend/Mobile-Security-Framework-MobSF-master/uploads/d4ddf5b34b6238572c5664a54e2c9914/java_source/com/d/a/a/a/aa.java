/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import com.d.a.a.a.b;
import com.d.a.a.d.ah;
import java.util.Arrays;

public final class aa {
    public final int a;
    private final byte[] b;
    private int c;
    private int d;
    private b[] e;

    public aa(int n2) {
        this(n2, 0);
    }

    /*
     * Enabled aggressive block sorting
     */
    private aa(int n2, byte by2) {
        by2 = n2 > 0 ? 1 : 0;
        if (by2 == 0) {
            throw new IllegalArgumentException();
        }
        this.a = n2;
        this.d = 0;
        this.e = new b[100];
        this.b = null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final b a() {
        synchronized (this) {
            int n2;
            ++this.c;
            if (this.d <= 0) return new b(new byte[this.a], 0);
            Object object = this.e;
            this.d = n2 = this.d - 1;
            object = object[n2];
            this.e[this.d] = null;
            return object;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    public final void a(int var1_1) {
        var2_2 = 0;
        synchronized (this) {
            block10 : {
                var3_3 = Math.max(0, ah.a(var1_1, this.a) - this.c);
                var1_1 = this.d;
                if (var3_3 < var1_1) break block10;
lbl7: // 3 sources:
                do {
                    return;
                    break;
                } while (true);
            }
            var1_1 = var3_3;
            if (this.b == null) ** GOTO lbl38
            var4_4 = this.d - 1;
            var1_1 = var2_2;
            var2_2 = var4_4;
            while (var1_1 <= var2_2) {
                var5_5 = this.e[var1_1];
                if (var5_5.a != this.b) break block11;
            }
            {
                block12 : {
                    block11 : {
                        ++var1_1;
                        continue;
                    }
                    var6_7 = this.e[var1_1];
                    if (var6_7.a == this.b) break block12;
                    --var2_2;
                    continue;
                }
                this.e[var1_1] = var6_7;
                this.e[var2_2] = var5_5;
                --var2_2;
                ++var1_1;
                continue;
            }
            if ((var1_1 = Math.max(var3_3, var1_1)) >= this.d) ** GOTO lbl7
lbl38: // 2 sources:
            Arrays.fill(this.e, var1_1, this.d, null);
            this.d = var1_1;
            ** continue;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(b b2) {
        synchronized (this) {
            int n2 = b2.a != this.b && b2.a.length != this.a ? 0 : 1;
            if (n2 == 0) {
                throw new IllegalArgumentException();
            }
            --this.c;
            if (this.d == this.e.length) {
                this.e = Arrays.copyOf(this.e, this.e.length * 2);
            }
            b[] arrb = this.e;
            n2 = this.d;
            this.d = n2 + 1;
            arrb[n2] = b2;
            this.notifyAll();
            return;
        }
    }

    public final int b() {
        synchronized (this) {
            int n2 = this.c;
            int n3 = this.a;
            return n2 * n3;
        }
    }

    public final void b(int n2) {
        synchronized (this) {
            while (this.b() > n2) {
                this.wait();
            }
            return;
        }
    }
}

