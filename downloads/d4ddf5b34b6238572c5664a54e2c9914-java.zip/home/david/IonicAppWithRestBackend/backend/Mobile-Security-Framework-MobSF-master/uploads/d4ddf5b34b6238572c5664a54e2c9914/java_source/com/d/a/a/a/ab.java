/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import com.d.a.a.a.ac;

final class ab
implements Runnable {
    final /* synthetic */ int a;
    final /* synthetic */ long b;
    final /* synthetic */ long c;
    final /* synthetic */ ac d;

    ab(ac ac2, int n2, long l2, long l3) {
        this.d = ac2;
        this.a = n2;
        this.b = l2;
        this.c = l3;
    }

    @Override
    public final void run() {
    }
}

