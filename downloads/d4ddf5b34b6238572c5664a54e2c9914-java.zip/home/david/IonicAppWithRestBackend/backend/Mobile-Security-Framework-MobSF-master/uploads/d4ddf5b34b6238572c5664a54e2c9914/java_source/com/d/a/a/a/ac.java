/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.d.a.a.a;

import android.os.Handler;
import com.d.a.a.a.ab;
import com.d.a.a.a.m;
import com.d.a.a.a.o;
import com.d.a.a.d.ae;
import com.d.a.a.d.w;

public final class ac
implements o {
    private final Handler a;
    private final m b;
    private final ae c;
    private final w d;
    private long e;
    private long f;
    private long g;
    private int h;

    public ac() {
        this(0);
    }

    private ac(byte by2) {
        this(null, null, new ae());
    }

    private ac(Handler handler, m m2, ae ae2) {
        this(null, null, ae2, 0);
    }

    private ac(Handler handler, m m2, ae ae2, byte by2) {
        this.a = handler;
        this.b = m2;
        this.c = ae2;
        this.d = new w(2000);
        this.g = -1;
    }

    public final long a() {
        synchronized (this) {
            long l2 = this.g;
            return l2;
        }
    }

    @Override
    public final void a(int n2) {
        synchronized (this) {
            this.e += (long)n2;
            return;
        }
    }

    @Override
    public final void b() {
        synchronized (this) {
            if (this.h == 0) {
                this.f = this.c.a();
            }
            ++this.h;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void c() {
        synchronized (this) {
            int n2 = this.h > 0 ? 1 : 0;
            if (n2 == 0) {
                throw new IllegalStateException();
            }
            long l2 = this.c.a();
            n2 = (int)(l2 - this.f);
            if (n2 > 0) {
                float f2 = this.e * 8000 / (long)n2;
                this.d.a((int)Math.sqrt(this.e), f2);
                f2 = this.d.a();
                long l3 = Float.isNaN(f2) ? -1 : (long)f2;
                this.g = l3;
                l3 = this.e;
                long l4 = this.g;
                if (this.a != null && this.b != null) {
                    this.a.post((Runnable)new ab(this, n2, l3, l4));
                }
            }
            --this.h;
            if (this.h > 0) {
                this.f = l2;
            }
            this.e = 0;
            return;
        }
    }
}

