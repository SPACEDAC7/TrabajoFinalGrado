/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  android.util.Log
 *  com.d.a.a.d.s
 */
package com.d.a.a.a;

import android.text.TextUtils;
import android.util.Log;
import com.d.a.a.a.i;
import com.d.a.a.a.o;
import com.d.a.a.a.p;
import com.d.a.a.a.q;
import com.d.a.a.a.t;
import com.d.a.a.d.ah;
import com.d.a.a.d.s;
import com.d.a.a.d.y;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ad
implements t {
    private static final Pattern b = Pattern.compile("^bytes (\\d+)-(\\d+)/(\\d+)$");
    private static final AtomicReference<byte[]> c = new AtomicReference();
    private final boolean d;
    private final int e;
    private final int f;
    private final String g;
    private final s<String> h;
    private final HashMap<String, String> i;
    private final o j;
    private i k;
    private HttpURLConnection l;
    private InputStream m;
    private boolean n;
    private long o;
    private long p;
    private long q;
    private long r;

    public ad(String string, o o2, int n2, int n3) {
        this(string, null, o2, n2, n3, false);
    }

    public ad(String string, s<String> s2, o o2, int n2, int n3, boolean bl2) {
        this.g = y.a(string);
        this.h = null;
        this.j = o2;
        this.i = new HashMap();
        this.e = n2;
        this.f = n3;
        this.d = false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static long a(HttpURLConnection object) {
        long l2 = -1;
        String string = object.getHeaderField("Content-Length");
        long l3 = l2;
        if (!TextUtils.isEmpty((CharSequence)string)) {
            try {
                l3 = Long.parseLong(string);
            }
            catch (NumberFormatException var8_5) {
                Log.e((String)"DefaultHttpDataSource", (String)("Unexpected Content-Length [" + string + "]"));
                l3 = l2;
            }
        }
        object = object.getHeaderField("Content-Range");
        l2 = l3;
        if (TextUtils.isEmpty((CharSequence)object)) return l2;
        Matcher matcher = b.matcher((CharSequence)object);
        l2 = l3;
        if (!matcher.find()) return l2;
        try {
            l2 = Long.parseLong(matcher.group(2));
            long l4 = Long.parseLong(matcher.group(1));
            l4 = l2 - l4 + 1;
            if (l3 < 0) {
                return l4;
            }
            l2 = l3;
            if (l3 == l4) return l2;
            Log.w((String)"DefaultHttpDataSource", (String)("Inconsistent headers [" + string + "] [" + (String)object + "]"));
            return Math.max(l3, l4);
        }
        catch (NumberFormatException var7_3) {
            Log.e((String)"DefaultHttpDataSource", (String)("Unexpected Content-Range [" + (String)object + "]"));
            return l3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private HttpURLConnection a(URL object, byte[] arrby, long l2, long l3, boolean bl2, boolean bl3) {
        object = InetAddress.getByName(object.getHost()).isLoopbackAddress() ? (HttpURLConnection)object.openConnection(Proxy.NO_PROXY) : (HttpURLConnection)object.openConnection();
        object.setConnectTimeout(this.e);
        object.setReadTimeout(this.f);
        Object object2 = this.i;
        // MONITORENTER : object2
        Object object3 = this.i.entrySet().iterator();
        while (object3.hasNext()) {
            Map.Entry<String, String> entry = object3.next();
            object.setRequestProperty(entry.getKey(), entry.getValue());
        }
        // MONITOREXIT : object2
        if (l2 != 0 || l3 != -1) {
            object2 = object3 = "bytes=" + l2 + "-";
            if (l3 != -1) {
                object2 = (String)object3 + (l2 + l3 - 1);
            }
            object.setRequestProperty("Range", (String)object2);
        }
        object.setRequestProperty("User-Agent", this.g);
        if (!bl2) {
            object.setRequestProperty("Accept-Encoding", "identity");
        }
        object.setInstanceFollowRedirects(bl3);
        bl2 = arrby != null;
        object.setDoOutput(bl2);
        if (arrby != null) {
            object.setFixedLengthStreamingMode(arrby.length);
            object.connect();
            object2 = object.getOutputStream();
            object2.write(arrby);
            object2.close();
            return object;
        }
        object.connect();
        return object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void d() {
        if (this.l != null) {
            try {
                this.l.disconnect();
            }
            catch (Exception var1_1) {
                Log.e((String)"DefaultHttpDataSource", (String)"Unexpected error while disconnecting", (Throwable)var1_1);
            }
            this.l = null;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final int a(byte[] var1_1, int var2_3, int var3_4) {
        block11 : {
            block12 : {
                try {
                    if (this.q == this.o) break block11;
                    var5_6 = var6_5 = (byte[])ad.c.getAndSet(null);
                    if (var6_5 == null) {
                        var5_6 = new byte[4096];
                    }
lbl6: // 5 sources:
                    if (this.q == this.o) break block12;
                    var4_7 = (int)Math.min(this.o - this.q, (long)var5_6.length);
                    var4_7 = this.m.read(var5_6, 0, var4_7);
                    if (Thread.interrupted()) {
                        throw new InterruptedIOException();
                    }
                    if (var4_7 == -1) {
                        throw new EOFException();
                    }
                }
                catch (IOException var1_2) {
                    throw new q(var1_2, this.k);
                }
                this.q += (long)var4_7;
                if (this.j == null) ** GOTO lbl6
                this.j.a(var4_7);
                ** GOTO lbl6
            }
            ad.c.set(var5_6);
        }
        if (this.p != -1) {
            var3_4 = (int)Math.min((long)var3_4, this.p - this.r);
        }
        if (var3_4 == 0) {
            return -1;
        }
        if ((var3_4 = this.m.read(var1_1, var2_3, var3_4)) == -1) {
            if (this.p == -1) return -1;
            if (this.p == this.r) return -1;
            throw new EOFException();
        }
        this.r += (long)var3_4;
        var2_3 = var3_4;
        if (this.j == null) return var2_3;
        this.j.a(var3_4);
        return var3_4;
    }

    /*
     * Exception decompiling
     */
    @Override
    public final long a(i var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 9[DOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void a() {
        block13 : {
            block14 : {
                Object object;
                try {
                    if (this.m == null) break block13;
                    object = this.l;
                    long l2 = this.p == -1 ? this.p : this.p - this.r;
                    if (ah.a != 19 && ah.a != 20) break block14;
                    object = object.getInputStream();
                    if (!(l2 == -1 ? object.read() != -1 : l2 > 2048)) break block14;
                }
                catch (Throwable var3_3) {
                    this.m = null;
                    this.d();
                    if (this.n) {
                        this.n = false;
                        if (this.j != null) {
                            this.j.c();
                        }
                    }
                    throw var3_3;
                }
                Object object2 = object.getClass().getName();
                if (object2.equals("com.android.okhttp.internal.http.HttpTransport$ChunkedInputStream") || object2.equals("com.android.okhttp.internal.http.HttpTransport$FixedLengthInputStream")) {
                    object2 = object.getClass().getSuperclass().getDeclaredMethod("unexpectedEndOfInput", new Class[0]);
                    object2.setAccessible(true);
                    object2.invoke(object, new Object[0]);
                }
            }
            try {
                this.m.close();
            }
            catch (IOException var3_2) {
                throw new q(var3_2, this.k);
            }
        }
        this.m = null;
        this.d();
        if (this.n) {
            this.n = false;
            if (this.j != null) {
                this.j.c();
            }
        }
    }

    @Override
    public final String b() {
        if (this.l == null) {
            return null;
        }
        return this.l.getURL().toString();
    }

    @Override
    public final Map<String, List<String>> c() {
        if (this.l == null) {
            return null;
        }
        return this.l.getHeaderFields();
    }
}

