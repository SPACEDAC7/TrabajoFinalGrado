/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.text.TextUtils
 */
package com.d.a.a.a;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import com.d.a.a.a.ad;
import com.d.a.a.a.ag;
import com.d.a.a.a.i;
import com.d.a.a.a.l;
import com.d.a.a.a.o;
import com.d.a.a.a.p;
import com.d.a.a.a.v;
import com.d.a.a.a.y;

public final class ae
implements l {
    private final l a;
    private final l b;
    private final l c;
    private final l d;
    private l e;

    public ae(Context context, o o2, l l2) {
        if (l2 == null) {
            throw new NullPointerException();
        }
        this.a = l2;
        this.b = new ag(o2);
        this.c = new v(context, o2);
        this.d = new y(context, o2);
    }

    private ae(Context context, o o2, String string) {
        this(context, null, new ad(string, null, null, 8000, 8000, false));
    }

    public ae(Context context, String string) {
        this(context, null, string);
    }

    public ae(Context context, String string, byte by2) {
        this(context, null, string);
    }

    @Override
    public final int a(byte[] arrby, int n2, int n3) {
        return this.e.a(arrby, n2, n3);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a(i i2) {
        boolean bl2 = this.e == null;
        if (!bl2) {
            throw new IllegalStateException();
        }
        String string = i2.a.getScheme();
        String string2 = i2.a.getScheme();
        bl2 = TextUtils.isEmpty((CharSequence)string2) || string2.equals("file");
        if (bl2) {
            if (i2.a.getPath().startsWith("/android_asset/")) {
                this.e = this.c;
                return this.e.a(i2);
            }
            this.e = this.b;
            return this.e.a(i2);
        }
        if ("asset".equals(string)) {
            this.e = this.c;
            return this.e.a(i2);
        }
        if ("content".equals(string)) {
            this.e = this.d;
            return this.e.a(i2);
        }
        this.e = this.a;
        return this.e.a(i2);
    }

    @Override
    public final void a() {
        if (this.e != null) {
            this.e.a();
        }
        return;
        finally {
            this.e = null;
        }
    }

    @Override
    public final String b() {
        if (this.e == null) {
            return null;
        }
        return this.e.b();
    }
}

