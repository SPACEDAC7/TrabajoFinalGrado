/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import java.io.IOException;

public final class af
extends IOException {
    public af(IOException iOException) {
        super(iOException);
    }
}

