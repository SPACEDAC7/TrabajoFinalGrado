/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.d.a.a.a;

import android.net.Uri;
import com.d.a.a.a.af;
import com.d.a.a.a.i;
import com.d.a.a.a.l;
import com.d.a.a.a.o;
import java.io.EOFException;
import java.io.IOException;
import java.io.RandomAccessFile;

public final class ag
implements l {
    private final o a;
    private RandomAccessFile b;
    private String c;
    private long d;
    private boolean e;

    public ag() {
        this(null);
    }

    public ag(o o2) {
        this.a = o2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final int a(byte[] arrby, int n2, int n3) {
        if (this.d == 0) {
            return -1;
        }
        try {
            n2 = n3 = this.b.read(arrby, n2, (int)Math.min(this.d, (long)n3));
            if (n3 <= 0) return n2;
        }
        catch (IOException var1_2) {
            throw new af(var1_2);
        }
        this.d -= (long)n3;
        n2 = n3;
        if (this.a == null) return n2;
        this.a.a(n3);
        return n3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final long a(i i2) {
        try {
            this.c = i2.a.toString();
            this.b = new RandomAccessFile(i2.a.getPath(), "r");
            this.b.seek(i2.d);
            long l2 = i2.e == -1 ? this.b.length() - i2.d : i2.e;
            this.d = l2;
            if (this.d < 0) {
                throw new EOFException();
            }
        }
        catch (IOException var1_2) {
            throw new af(var1_2);
        }
        this.e = true;
        if (this.a != null) {
            this.a.b();
        }
        return this.d;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void a() {
        this.c = null;
        if (this.b == null) return;
        try {
            this.b.close();
        }
        catch (IOException iOException) {
            throw new af(iOException);
        }
        finally {
            this.b = null;
            if (this.e) {
                this.e = false;
                if (this.a != null) {
                    this.a.c();
                }
            }
        }
        return;
    }

    @Override
    public final String b() {
        return this.c;
    }
}

