/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import java.util.PriorityQueue;

public final class ah {
    public static final ah a = new ah();
    private final Object b = new Object();
    private final PriorityQueue<Integer> c = new PriorityQueue();
    private int d = Integer.MAX_VALUE;

    private ah() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a() {
        Object object = this.b;
        synchronized (object) {
            this.c.add(0);
            this.d = Math.min(this.d, 0);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void b() {
        Object object = this.b;
        synchronized (object) {
            this.c.remove(0);
            int n2 = this.c.isEmpty() ? Integer.MAX_VALUE : this.c.peek();
            this.d = n2;
            this.b.notifyAll();
            return;
        }
    }
}

