/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

public final class b {
    public final byte[] a;
    public final int b;

    public b(byte[] arrby, int n2) {
        this.a = arrby;
        this.b = 0;
    }
}

