/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import java.io.IOException;

public final class c
extends IOException {
    public c(Exception exception) {
        super("Unexpected " + exception.getClass().getSimpleName() + ": " + exception.getMessage(), exception);
    }
}

