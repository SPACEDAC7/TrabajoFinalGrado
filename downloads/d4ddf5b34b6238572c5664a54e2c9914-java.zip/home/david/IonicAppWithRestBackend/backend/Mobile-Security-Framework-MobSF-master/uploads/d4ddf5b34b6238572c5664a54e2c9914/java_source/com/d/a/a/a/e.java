/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import com.d.a.a.a.d;
import java.io.IOException;

public interface e {
    public void a(d var1);

    public void a(d var1, IOException var2);

    public void j();
}

