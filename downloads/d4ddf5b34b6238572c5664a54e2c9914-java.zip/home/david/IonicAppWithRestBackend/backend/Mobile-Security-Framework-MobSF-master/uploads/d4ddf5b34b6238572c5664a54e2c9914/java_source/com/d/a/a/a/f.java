/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  android.os.Trace
 *  android.util.Log
 */
package com.d.a.a.a;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Trace;
import android.util.Log;
import com.d.a.a.a.c;
import com.d.a.a.a.d;
import com.d.a.a.a.e;
import com.d.a.a.a.g;
import com.d.a.a.d.ah;
import java.io.IOException;

@SuppressLint(value={"HandlerLeak"})
final class f
extends Handler
implements Runnable {
    final d a;
    volatile Thread b;
    final /* synthetic */ g c;
    private final e d;

    public f(g g2, Looper looper, d d2, e e2) {
        this.c = g2;
        super(looper);
        this.a = d2;
        this.d = e2;
    }

    public final void handleMessage(Message message) {
        if (message.what == 2) {
            throw (Error)message.obj;
        }
        this.c.b = false;
        this.c.a = null;
        if (this.a.h()) {
            this.d.j();
            return;
        }
        switch (message.what) {
            default: {
                return;
            }
            case 0: {
                this.d.a(this.a);
                return;
            }
            case 1: 
        }
        this.d.a(this.a, (IOException)message.obj);
    }

    @Override
    public final void run() {
        try {
            this.b = Thread.currentThread();
            if (!this.a.h()) {
                String string = this.a.getClass().getSimpleName() + ".load()";
                if (ah.a >= 18) {
                    Trace.beginSection((String)string);
                }
                this.a.i();
                if (ah.a >= 18) {
                    Trace.endSection();
                }
            }
            this.sendEmptyMessage(0);
            return;
        }
        catch (IOException var1_2) {
            this.obtainMessage(1, (Object)var1_2).sendToTarget();
            return;
        }
        catch (InterruptedException var1_3) {
            if (!this.a.h()) {
                throw new IllegalStateException();
            }
            this.sendEmptyMessage(0);
            return;
        }
        catch (Exception var1_4) {
            Log.e((String)"LoadTask", (String)"Unexpected exception loading stream", (Throwable)var1_4);
            this.obtainMessage(1, (Object)new c(var1_4)).sendToTarget();
            return;
        }
        catch (Error var1_5) {
            Log.e((String)"LoadTask", (String)"Unexpected error loading stream", (Throwable)var1_5);
            this.obtainMessage(2, (Object)var1_5).sendToTarget();
            throw var1_5;
        }
    }
}

