/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Looper
 */
package com.d.a.a.a;

import android.os.Looper;
import com.d.a.a.a.d;
import com.d.a.a.a.e;
import com.d.a.a.a.f;
import com.d.a.a.d.ag;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class g {
    f a;
    public boolean b;
    private final ExecutorService c;

    public g(String string) {
        this.c = Executors.newSingleThreadExecutor(new ag(string));
    }

    public final void a() {
        if (!this.b) {
            throw new IllegalStateException();
        }
        f f2 = this.a;
        f2.a.g();
        if (f2.b != null) {
            f2.b.interrupt();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(Looper looper, d d2, e e2) {
        boolean bl2 = !this.b;
        if (!bl2) {
            throw new IllegalStateException();
        }
        this.b = true;
        this.a = new f(this, looper, d2, e2);
        this.c.submit(this.a);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(d d2, e e2) {
        Looper looper = Looper.myLooper();
        boolean bl2 = looper != null;
        if (!bl2) {
            throw new IllegalStateException();
        }
        this.a(looper, d2, e2);
    }

    public final void b() {
        if (this.b) {
            this.a();
        }
        this.c.shutdown();
    }
}

