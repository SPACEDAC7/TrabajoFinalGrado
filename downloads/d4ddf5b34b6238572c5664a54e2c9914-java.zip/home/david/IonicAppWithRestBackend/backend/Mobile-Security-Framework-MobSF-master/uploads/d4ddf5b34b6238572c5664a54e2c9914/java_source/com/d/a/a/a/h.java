/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import com.d.a.a.a.i;

public interface h {
    public int a(byte[] var1, int var2, int var3);

    public long a(i var1);

    public void a();
}

