/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.d.a.a.a;

import android.net.Uri;
import java.util.Arrays;

public final class i {
    public final Uri a;
    public final byte[] b;
    public final long c;
    public final long d;
    public final long e;
    public final String f;
    public final int g;
    public final int h;
    public final int i;

    public i(Uri uri) {
        this(uri, 0);
    }

    public i(Uri uri, int n2) {
        this(uri, 0, -1, null, n2);
    }

    public i(Uri uri, long l2, long l3, long l4, String string, int n2, int n3, int n4) {
        this(uri, null, l2, l3, l4, string, n2, n3, n4);
    }

    public i(Uri uri, long l2, long l3, String string) {
        this(uri, l2, l2, l3, string, 0, 0, 0);
    }

    public i(Uri uri, long l2, long l3, String string, int n2) {
        this(uri, l2, l2, l3, string, n2, 0, 0);
    }

    /*
     * Enabled aggressive block sorting
     */
    public i(Uri uri, byte[] arrby, long l2, long l3, long l4, String string, int n2, int n3, int n4) {
        boolean bl2 = l2 >= 0;
        if (!bl2) {
            throw new IllegalArgumentException();
        }
        bl2 = l3 >= 0;
        if (!bl2) {
            throw new IllegalArgumentException();
        }
        bl2 = l4 > 0 || l4 == -1;
        if (!bl2) {
            throw new IllegalArgumentException();
        }
        this.a = uri;
        this.b = arrby;
        this.c = l2;
        this.d = l3;
        this.e = l4;
        this.f = string;
        this.g = n2;
        this.h = n3;
        this.i = n4;
    }

    public final String toString() {
        return "DataSpec[" + (Object)this.a + ", " + Arrays.toString(this.b) + ", " + this.c + ", " + this.d + ", " + this.e + ", " + this.f + ", " + this.g + "," + this.h + "," + this.i + "]";
    }
}

