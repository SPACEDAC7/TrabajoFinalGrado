/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import java.io.InputStream;

public interface j<T> {
    public T a(String var1, InputStream var2);
}

