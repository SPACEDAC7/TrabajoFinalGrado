/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.d.a.a.a;

import android.net.Uri;
import com.d.a.a.a.d;
import com.d.a.a.a.h;
import com.d.a.a.a.i;
import com.d.a.a.a.j;
import com.d.a.a.a.l;
import com.d.a.a.a.z;
import java.io.InputStream;

public final class k<T>
implements d {
    public volatile T a;
    private final i b;
    private final l c;
    private final j<T> d;
    private volatile boolean e;

    public k(String string, l l2, j<T> j2) {
        this.c = l2;
        this.d = j2;
        this.b = new i(Uri.parse((String)string), 1);
    }

    @Override
    public final void g() {
        this.e = true;
    }

    @Override
    public final boolean h() {
        return this.e;
    }

    @Override
    public final void i() {
        z z2 = new z(this.c, this.b);
        try {
            z2.a();
            this.a = this.d.a(this.c.b(), z2);
            return;
        }
        finally {
            z2.close();
        }
    }
}

