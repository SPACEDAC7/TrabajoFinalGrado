/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

public interface o {
    public void a(int var1);

    public void b();

    public void c();
}

