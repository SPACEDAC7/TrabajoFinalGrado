/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  com.d.a.a.d.s
 */
package com.d.a.a.a;

import android.text.TextUtils;
import com.d.a.a.d.ah;
import com.d.a.a.d.s;

public final class p
implements s<String> {
    p() {
    }

    public final /* synthetic */ boolean a(Object object) {
        if (!(TextUtils.isEmpty((CharSequence)(object = ah.b((String)object))) || object.contains("text") && !object.contains("text/vtt") || object.contains("html") || object.contains("xml"))) {
            return true;
        }
        return false;
    }
}

