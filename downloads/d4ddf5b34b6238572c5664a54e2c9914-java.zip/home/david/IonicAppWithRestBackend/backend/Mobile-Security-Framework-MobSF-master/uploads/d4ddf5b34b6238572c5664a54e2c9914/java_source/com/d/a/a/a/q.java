/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import com.d.a.a.a.i;
import java.io.IOException;

public class q
extends IOException {
    public final i a;

    public q(IOException iOException, i i2) {
        super(iOException);
        this.a = i2;
    }

    public q(String string, i i2) {
        super(string);
        this.a = i2;
    }

    public q(String string, IOException iOException, i i2) {
        super(string, iOException);
        this.a = i2;
    }
}

