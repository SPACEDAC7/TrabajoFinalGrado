/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import com.d.a.a.a.i;
import com.d.a.a.a.q;

public final class r
extends q {
    public final String b;

    public r(String string, i i2) {
        super("Invalid content type: " + string, i2);
        this.b = string;
    }
}

