/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import com.d.a.a.a.i;
import com.d.a.a.a.q;
import java.util.List;
import java.util.Map;

public final class s
extends q {
    public final int b;
    public final Map<String, List<String>> c;

    public s(int n2, Map<String, List<String>> map, i i2) {
        super("Response code: " + n2, i2);
        this.b = n2;
        this.c = map;
    }
}

