/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  com.d.a.a.d.s
 */
package com.d.a.a.a;

import com.d.a.a.a.i;
import com.d.a.a.a.l;
import com.d.a.a.a.p;
import com.d.a.a.d.s;
import java.util.List;
import java.util.Map;

public interface t
extends l {
    public static final s<String> a = new p();

    @Override
    public int a(byte[] var1, int var2, int var3);

    @Override
    public long a(i var1);

    @Override
    public void a();

    public Map<String, List<String>> c();
}

