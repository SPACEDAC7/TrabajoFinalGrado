/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import java.io.IOException;

public final class u
extends IOException {
    public u(IOException iOException) {
        super(iOException);
    }
}

