/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetManager
 *  android.net.Uri
 */
package com.d.a.a.a;

import android.content.Context;
import android.content.res.AssetManager;
import android.net.Uri;
import com.d.a.a.a.i;
import com.d.a.a.a.l;
import com.d.a.a.a.o;
import com.d.a.a.a.u;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public final class v
implements l {
    private final AssetManager a;
    private final o b;
    private String c;
    private InputStream d;
    private long e;
    private boolean f;

    public v(Context context, o o2) {
        this.a = context.getAssets();
        this.b = o2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final int a(byte[] arrby, int n2, int n3) {
        if (this.e == 0) {
            return -1;
        }
        try {
            if (this.e != -1) {
                long l2 = Math.min(this.e, (long)n3);
                n3 = (int)l2;
            }
            n2 = n3 = this.d.read(arrby, n2, n3);
            if (n3 <= 0) return n2;
            if (this.e != -1) {
                this.e -= (long)n3;
            }
            n2 = n3;
            if (this.b == null) return n2;
            this.b.a(n3);
            return n3;
        }
        catch (IOException var1_2) {
            throw new u(var1_2);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final long a(i var1_1) {
        block8 : {
            block7 : {
                try {
                    this.c = var1_1.a.toString();
                    var3_3 = var1_1.a.getPath();
                    if (!var3_3.startsWith("/android_asset/")) ** GOTO lbl7
                    var2_4 = var3_3.substring(15);
                    ** GOTO lbl11
lbl7: // 1 sources:
                    var2_4 = var3_3;
                    if (var3_3.startsWith("/")) {
                        var2_4 = var3_3.substring(1);
                    }
lbl11: // 4 sources:
                    this.c = var1_1.a.toString();
                    this.d = this.a.open(var2_4, 1);
                    if (this.d.skip(var1_1.d) < var1_1.d) {
                        throw new EOFException();
                    }
                    if (var1_1.e == -1) break block7;
                    this.e = var1_1.e;
                    break block8;
                }
                catch (IOException var1_2) {
                    throw new u(var1_2);
                }
            }
            this.e = this.d.available();
            if (this.e == Integer.MAX_VALUE) {
                this.e = -1;
            }
        }
        this.f = true;
        if (this.b == null) return this.e;
        this.b.b();
        return this.e;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void a() {
        this.c = null;
        if (this.d == null) return;
        try {
            this.d.close();
        }
        catch (IOException iOException) {
            throw new u(iOException);
        }
        finally {
            this.d = null;
            if (this.f) {
                this.f = false;
                if (this.b != null) {
                    this.b.c();
                }
            }
        }
        return;
    }

    @Override
    public final String b() {
        return this.c;
    }
}

