/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import java.io.IOException;

public final class x
extends IOException {
    public x(IOException iOException) {
        super(iOException);
    }
}

