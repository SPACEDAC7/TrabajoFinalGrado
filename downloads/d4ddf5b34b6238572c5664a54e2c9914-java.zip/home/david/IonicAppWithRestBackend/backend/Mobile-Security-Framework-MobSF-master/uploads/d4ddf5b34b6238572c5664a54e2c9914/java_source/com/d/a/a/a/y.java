/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.res.AssetFileDescriptor
 *  android.net.Uri
 */
package com.d.a.a.a;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import com.d.a.a.a.i;
import com.d.a.a.a.l;
import com.d.a.a.a.o;
import com.d.a.a.a.x;
import java.io.EOFException;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public final class y
implements l {
    private final ContentResolver a;
    private final o b;
    private InputStream c;
    private String d;
    private long e;
    private boolean f;

    public y(Context context, o o2) {
        this.a = context.getContentResolver();
        this.b = o2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final int a(byte[] arrby, int n2, int n3) {
        if (this.e == 0) {
            return -1;
        }
        try {
            if (this.e != -1) {
                long l2 = Math.min(this.e, (long)n3);
                n3 = (int)l2;
            }
            n2 = n3 = this.c.read(arrby, n2, n3);
            if (n3 <= 0) return n2;
            if (this.e != -1) {
                this.e -= (long)n3;
            }
            n2 = n3;
            if (this.b == null) return n2;
            this.b.a(n3);
            return n3;
        }
        catch (IOException var1_2) {
            throw new x(var1_2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final long a(i i2) {
        try {
            this.d = i2.a.toString();
            this.c = new FileInputStream(this.a.openAssetFileDescriptor(i2.a, "r").getFileDescriptor());
            if (this.c.skip(i2.d) < i2.d) {
                throw new EOFException();
            }
            if (i2.e != -1) {
                this.e = i2.e;
            } else {
                this.e = this.c.available();
                if (this.e == 0) {
                    this.e = -1;
                }
            }
        }
        catch (IOException var1_2) {
            throw new x(var1_2);
        }
        this.f = true;
        if (this.b != null) {
            this.b.b();
        }
        return this.e;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void a() {
        this.d = null;
        if (this.c == null) return;
        try {
            this.c.close();
        }
        catch (IOException iOException) {
            throw new x(iOException);
        }
        finally {
            this.c = null;
            if (this.f) {
                this.f = false;
                if (this.b != null) {
                    this.b.c();
                }
            }
        }
        return;
    }

    @Override
    public final String b() {
        return this.d;
    }
}

