/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.a;

import com.d.a.a.a.h;
import com.d.a.a.a.i;
import java.io.InputStream;

public final class z
extends InputStream {
    private final h a;
    private final i b;
    private final byte[] c;
    private boolean d = false;
    private boolean e = false;

    public z(h h2, i i2) {
        this.a = h2;
        this.b = i2;
        this.c = new byte[1];
    }

    final void a() {
        if (!this.d) {
            this.a.a(this.b);
            this.d = true;
        }
    }

    @Override
    public final void close() {
        if (!this.e) {
            this.a.a();
            this.e = true;
        }
    }

    @Override
    public final int read() {
        if (this.read(this.c) == -1) {
            return -1;
        }
        return this.c[0] & 255;
    }

    @Override
    public final int read(byte[] arrby) {
        return this.read(arrby, 0, arrby.length);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int read(byte[] arrby, int n2, int n3) {
        boolean bl2 = !this.e;
        if (!bl2) {
            throw new IllegalStateException();
        }
        this.a();
        return this.a.a(arrby, n2, n3);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long skip(long l2) {
        boolean bl2 = !this.e;
        if (!bl2) {
            throw new IllegalStateException();
        }
        this.a();
        return super.skip(l2);
    }
}

