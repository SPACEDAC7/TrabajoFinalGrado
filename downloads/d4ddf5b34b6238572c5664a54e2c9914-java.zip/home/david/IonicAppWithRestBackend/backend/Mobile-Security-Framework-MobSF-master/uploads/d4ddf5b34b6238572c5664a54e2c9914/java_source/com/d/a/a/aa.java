/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import java.io.IOException;

public final class aa
extends IOException {
    public aa(Throwable throwable) {
        super("Failed to query underlying media codecs", throwable);
    }
}

