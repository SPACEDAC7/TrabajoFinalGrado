/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.MediaCodecInfo
 *  android.media.MediaCodecInfo$CodecCapabilities
 */
package com.d.a.a;

import android.media.MediaCodecInfo;

interface ab {
    public int a();

    public MediaCodecInfo a(int var1);

    public boolean a(String var1, MediaCodecInfo.CodecCapabilities var2);

    public boolean b();
}

