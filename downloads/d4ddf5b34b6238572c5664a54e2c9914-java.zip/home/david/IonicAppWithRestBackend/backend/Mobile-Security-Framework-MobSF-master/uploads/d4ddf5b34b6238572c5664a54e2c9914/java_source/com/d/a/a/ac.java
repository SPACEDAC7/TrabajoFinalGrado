/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.MediaCodecInfo
 *  android.media.MediaCodecInfo$CodecCapabilities
 *  android.media.MediaCodecList
 */
package com.d.a.a;

import android.annotation.TargetApi;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import com.d.a.a.ab;

@TargetApi(value=21)
final class ac
implements ab {
    private final int a;
    private MediaCodecInfo[] b;

    /*
     * Enabled aggressive block sorting
     */
    public ac(boolean bl2) {
        int n2 = bl2 ? 1 : 0;
        this.a = n2;
    }

    private void c() {
        if (this.b == null) {
            this.b = new MediaCodecList(this.a).getCodecInfos();
        }
    }

    @Override
    public final int a() {
        this.c();
        return this.b.length;
    }

    @Override
    public final MediaCodecInfo a(int n2) {
        this.c();
        return this.b[n2];
    }

    @Override
    public final boolean a(String string, MediaCodecInfo.CodecCapabilities codecCapabilities) {
        return codecCapabilities.isFeatureSupported("secure-playback");
    }

    @Override
    public final boolean b() {
        return true;
    }
}

