/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.MediaCodecInfo
 *  android.media.MediaCodecInfo$CodecCapabilities
 *  android.media.MediaCodecList
 */
package com.d.a.a;

import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import com.d.a.a.ab;

final class ad
implements ab {
    @Override
    public final int a() {
        return MediaCodecList.getCodecCount();
    }

    @Override
    public final MediaCodecInfo a(int n2) {
        return MediaCodecList.getCodecInfoAt((int)n2);
    }

    @Override
    public final boolean a(String string, MediaCodecInfo.CodecCapabilities codecCapabilities) {
        return "video/avc".equals(string);
    }

    @Override
    public final boolean b() {
        return false;
    }
}

