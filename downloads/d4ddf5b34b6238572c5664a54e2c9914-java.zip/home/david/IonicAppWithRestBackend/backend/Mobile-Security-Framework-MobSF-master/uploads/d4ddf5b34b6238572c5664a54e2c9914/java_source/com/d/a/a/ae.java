/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 */
package com.d.a.a;

import android.text.TextUtils;

final class ae {
    public final String a;
    public final boolean b;

    public ae(String string, boolean bl2) {
        this.a = string;
        this.b = bl2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (object.getClass() != ae.class) {
            return false;
        }
        object = (ae)object;
        if (!TextUtils.equals((CharSequence)this.a, (CharSequence)object.a)) return false;
        if (this.b == object.b) return true;
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int hashCode() {
        int n2;
        int n3 = this.a == null ? 0 : this.a.hashCode();
        if (this.b) {
            n2 = 1231;
            return n2 + (n3 + 31) * 31;
        }
        n2 = 1237;
        return n2 + (n3 + 31) * 31;
    }
}

