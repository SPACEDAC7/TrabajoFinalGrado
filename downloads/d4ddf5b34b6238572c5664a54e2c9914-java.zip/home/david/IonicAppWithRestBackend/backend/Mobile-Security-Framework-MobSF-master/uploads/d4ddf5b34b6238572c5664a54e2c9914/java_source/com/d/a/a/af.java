/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.MediaCodecInfo
 *  android.media.MediaCodecInfo$CodecCapabilities
 *  android.media.MediaCodecInfo$CodecProfileLevel
 *  android.media.MediaCodecInfo$VideoCapabilities
 *  android.util.Log
 *  android.util.Pair
 */
package com.d.a.a;

import android.annotation.TargetApi;
import android.media.MediaCodecInfo;
import android.util.Log;
import android.util.Pair;
import com.d.a.a.ab;
import com.d.a.a.ac;
import com.d.a.a.ad;
import com.d.a.a.ae;
import com.d.a.a.d.ah;
import java.util.HashMap;

@TargetApi(value=16)
public final class af {
    private static final HashMap<ae, Pair<String, MediaCodecInfo.CodecCapabilities>> a = new HashMap();

    /*
     * Enabled aggressive block sorting
     */
    public static int a() {
        int n2 = 0;
        MediaCodecInfo.CodecCapabilities codecCapabilities = af.b("video/avc", false);
        if (codecCapabilities == null) {
            return 0;
        }
        codecCapabilities = (MediaCodecInfo.CodecCapabilities)codecCapabilities.second;
        int n3 = 0;
        while (n2 < codecCapabilities.profileLevels.length) {
            int n4;
            switch (codecCapabilities.profileLevels[n2].level) {
                default: {
                    n4 = -1;
                    break;
                }
                case 1: {
                    n4 = 25344;
                    break;
                }
                case 2: {
                    n4 = 25344;
                    break;
                }
                case 8: {
                    n4 = 101376;
                    break;
                }
                case 16: {
                    n4 = 101376;
                    break;
                }
                case 32: {
                    n4 = 101376;
                    break;
                }
                case 64: {
                    n4 = 202752;
                    break;
                }
                case 128: {
                    n4 = 414720;
                    break;
                }
                case 256: {
                    n4 = 414720;
                    break;
                }
                case 512: {
                    n4 = 921600;
                    break;
                }
                case 1024: {
                    n4 = 1310720;
                    break;
                }
                case 2048: {
                    n4 = 2097152;
                    break;
                }
                case 4096: {
                    n4 = 2097152;
                    break;
                }
                case 8192: {
                    n4 = 2228224;
                    break;
                }
                case 16384: {
                    n4 = 5652480;
                    break;
                }
                case 32768: {
                    n4 = 9437184;
                }
            }
            n3 = Math.max(n4, n3);
            ++n2;
        }
        return n3;
    }

    /*
     * Exception decompiling
     */
    private static Pair<String, MediaCodecInfo.CodecCapabilities> a(ae var0, ab var1_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl80 : TryStatement: try { 2[TRYBLOCK]

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps.apply(RemoveDeterministicJumps.java:35)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:519)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    @TargetApi(value=21)
    public static boolean a(String string, int n2, int n3) {
        boolean bl2 = ah.a >= 21;
        if (!bl2) {
            throw new IllegalStateException();
        }
        if ((string = af.c(string, false)) == null) return false;
        if (string.isSizeSupported(n2, n3)) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    @TargetApi(value=21)
    public static boolean a(String string, int n2, int n3, double d2) {
        boolean bl2 = ah.a >= 21;
        if (!bl2) {
            throw new IllegalStateException();
        }
        if ((string = af.c(string, false)) == null) return false;
        if (string.areSizeAndRateSupported(n2, n3, d2)) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Pair<String, MediaCodecInfo.CodecCapabilities> b(String string, boolean bl2) {
        synchronized (af.class) {
            Pair<String, MediaCodecInfo.CodecCapabilities> pair;
            void var1_1;
            ae ae2 = new ae(string, (boolean)var1_1);
            if (a.containsKey(ae2)) {
                return a.get(ae2);
            }
            Pair<String, MediaCodecInfo.CodecCapabilities> pair2 = ah.a >= 21 ? new ac((boolean)var1_1) : new ad();
            pair2 = pair = af.a(ae2, (ab)pair2);
            if (var1_1 == false) return pair2;
            pair2 = pair;
            if (pair != null) return pair2;
            pair2 = pair;
            if (21 > ah.a) return pair2;
            pair2 = pair;
            if (ah.a > 23) return pair2;
            pair2 = af.a(ae2, new ad());
            if (pair2 == null) return pair2;
            Log.w((String)"MediaCodecUtil", (String)("MediaCodecList API didn't list secure decoder for: " + string + ". Assuming: " + (String)pair2.first));
            return pair2;
        }
    }

    @TargetApi(value=21)
    private static MediaCodecInfo.VideoCapabilities c(String pair, boolean bl2) {
        if ((pair = af.b((String)pair, false)) == null) {
            return null;
        }
        return ((MediaCodecInfo.CodecCapabilities)pair.second).getVideoCapabilities();
    }
}

