/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.ak;
import com.d.a.a.c.a;

final class ah
implements Runnable {
    final /* synthetic */ a a;
    final /* synthetic */ ak b;

    ah(ak ak2, a a2) {
        this.b = ak2;
        this.a = a2;
    }

    @Override
    public final void run() {
    }
}

