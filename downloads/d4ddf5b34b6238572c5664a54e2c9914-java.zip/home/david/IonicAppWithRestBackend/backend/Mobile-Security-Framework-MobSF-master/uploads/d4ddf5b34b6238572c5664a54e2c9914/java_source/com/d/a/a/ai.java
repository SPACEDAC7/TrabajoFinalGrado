/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.ak;
import com.d.a.a.c.b;

final class ai
implements Runnable {
    final /* synthetic */ b a;
    final /* synthetic */ ak b;

    ai(ak ak2, b b2) {
        this.b = ak2;
        this.a = b2;
    }

    @Override
    public final void run() {
    }
}

