/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.ak;

final class aj
implements Runnable {
    final /* synthetic */ int a;
    final /* synthetic */ long b;
    final /* synthetic */ long c;
    final /* synthetic */ ak d;

    aj(ak ak2, int n2, long l2, long l3) {
        this.d = ak2;
        this.a = n2;
        this.b = l2;
        this.c = l3;
    }

    @Override
    public final void run() {
    }
}

