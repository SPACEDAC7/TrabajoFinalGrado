/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.AudioTrack
 *  android.media.MediaCodec
 *  android.media.MediaCodec$BufferInfo
 *  android.media.MediaCrypto
 *  android.media.MediaFormat
 *  android.media.PlaybackParams
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.util.Log
 *  android.view.Surface
 */
package com.d.a.a;

import android.annotation.TargetApi;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.media.PlaybackParams;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.Surface;
import com.d.a.a.ag;
import com.d.a.a.ah;
import com.d.a.a.ai;
import com.d.a.a.aj;
import com.d.a.a.al;
import com.d.a.a.aq;
import com.d.a.a.at;
import com.d.a.a.b;
import com.d.a.a.c;
import com.d.a.a.c.a;
import com.d.a.a.c.f;
import com.d.a.a.c.i;
import com.d.a.a.c.j;
import com.d.a.a.d.ab;
import com.d.a.a.e;
import com.d.a.a.o;
import com.d.a.a.p;
import com.d.a.a.q;
import com.d.a.a.r;
import com.d.a.a.x;
import java.lang.reflect.Method;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.util.Arrays;

@TargetApi(value=16)
public class ak
extends aq
implements r {
    private final ag g;
    private final i h;
    private boolean i;
    private MediaFormat j;
    private int k;
    private long l;
    private boolean m;
    private boolean n;
    private long o;

    public ak(x x2, at at2, Handler handler) {
        this(x2, at2, null, true, handler, null);
    }

    public ak(x x2, at at2, com.d.a.a.b.e e2, boolean bl2, Handler handler, ag ag2) {
        this(x2, at2, null, true, handler, ag2, 0);
    }

    private ak(x x2, at at2, com.d.a.a.b.e e2, boolean bl2, Handler handler, ag ag2, byte by2) {
        this(new x[]{x2}, at2, e2, bl2, handler, ag2, null, 3);
    }

    private ak(x[] arrx, at at2, com.d.a.a.b.e e2, boolean bl2, Handler handler, ag ag2, j j2, int n2) {
        super(arrx, at2, e2, bl2, handler, (al)ag2);
        this.g = ag2;
        this.k = 0;
        this.h = new i(null, 3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(String string) {
        Object object = this.h;
        if (object.c == null) return false;
        object = object.c;
        int n2 = i.a(string);
        if (Arrays.binarySearch(object.b, n2) < 0) return false;
        return true;
    }

    @Override
    protected final e a(at object, String string, boolean bl2) {
        if (this.a(string)) {
            object = object.a();
            this.i = true;
            return new e((String)object, false);
        }
        this.i = false;
        return super.a((at)object, string, bl2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(int n2, Object object) {
        switch (n2) {
            default: {
                super.a(n2, object);
                return;
            }
            case 1: {
                i i2 = this.h;
                float f2 = ((Float)object).floatValue();
                if (i2.B == f2) return;
                {
                    i2.B = f2;
                    i2.c();
                    return;
                }
            }
            case 2: 
        }
        i i3 = this.h;
        object = (PlaybackParams)object;
        i3.e.a((PlaybackParams)object);
    }

    @Override
    protected final void a(MediaCodec mediaCodec, boolean bl2, MediaFormat mediaFormat, MediaCrypto mediaCrypto) {
        String string = mediaFormat.getString("mime");
        if (this.i) {
            mediaFormat.setString("mime", "audio/raw");
            mediaCodec.configure(mediaFormat, null, mediaCrypto, 0);
            mediaFormat.setString("mime", string);
            this.j = mediaFormat;
            return;
        }
        mediaCodec.configure(mediaFormat, null, mediaCrypto, 0);
        this.j = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(MediaFormat object) {
        int n2;
        int n3 = 1;
        boolean bl2 = this.j != null;
        i i2 = this.h;
        if (bl2) {
            object = this.j;
        }
        int n4 = object.getInteger("channel-count");
        switch (n4) {
            default: {
                throw new IllegalArgumentException("Unsupported channel count: " + n4);
            }
            case 1: {
                n2 = 4;
                break;
            }
            case 2: {
                n2 = 12;
                break;
            }
            case 3: {
                n2 = 28;
                break;
            }
            case 4: {
                n2 = 204;
                break;
            }
            case 5: {
                n2 = 220;
                break;
            }
            case 6: {
                n2 = 252;
                break;
            }
            case 7: {
                n2 = 1276;
                break;
            }
            case 8: {
                n2 = b.a;
            }
        }
        int n5 = object.getInteger("sample-rate");
        object = object.getString("mime");
        int n6 = bl2 ? i.a((String)object) : 2;
        int n7 = i2.f != null ? 1 : 0;
        if (n7 == 0 || i2.g != n5 || i2.h != n2 || i2.i != n6) {
            i2.d();
            i2.i = n6;
            i2.j = bl2;
            i2.g = n5;
            i2.h = n2;
            i2.k = n4 * 2;
            if (bl2) {
                n2 = n6 == 5 || n6 == 6 ? 20480 : 49152;
            } else {
                n7 = AudioTrack.getMinBufferSize((int)n5, (int)n2, (int)n6);
                n2 = n7 != -2 ? n3 : 0;
                if (n2 == 0) {
                    throw new IllegalStateException();
                }
                n2 = n7 * 4;
                n6 = (int)(250000 * (long)i2.g / 1000000) * i2.k;
                n7 = (int)Math.max((long)n7, 750000 * (long)i2.g / 1000000 * (long)i2.k);
                if (n2 < n6) {
                    n2 = n6;
                } else if (n2 > n7) {
                    n2 = n7;
                }
            }
            i2.l = n2;
            long l2 = bl2 ? -1 : (long)i2.l / (long)i2.k * 1000000 / (long)i2.g;
            i2.m = l2;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected final boolean a(long var1_1, long var3_2, MediaCodec var5_3, ByteBuffer var6_6, MediaCodec.BufferInfo var7_7, int var8_8, boolean var9_9) {
        block35 : {
            block36 : {
                block38 : {
                    block37 : {
                        if (this.i && (var7_7.flags & 2) != 0) {
                            var5_3.releaseOutputBuffer(var8_8, false);
                            return true;
                        }
                        if (var9_9) {
                            var5_3.releaseOutputBuffer(var8_8, false);
                            var5_3 = this.b;
                            ++var5_3.g;
                            var5_3 = this.h;
                            if (var5_3.x != 1) return true;
                            var5_3.x = 2;
                            return true;
                        }
                        var10_10 = this.h.f != null ? 1 : 0;
                        if (var10_10 == 0) {
                            try {
                                if (this.k != 0) {
                                    this.h.a(this.k);
                                } else {
                                    this.k = this.h.a(0);
                                }
                                this.n = false;
                                if (this.a != 3) ** GOTO lbl38
                                this.h.a();
                            }
                            catch (a var5_4) {
                                if (this.d == null) throw new p(var5_4);
                                if (this.g == null) throw new p(var5_4);
                                this.d.post((Runnable)new ah(this, var5_4));
                                throw new p(var5_4);
                            }
                        } else {
                            var9_9 = this.n;
                            this.n = this.h.b();
                            if (var9_9 && !this.n && this.a == 3) {
                                var3_2 = SystemClock.elapsedRealtime();
                                var14_14 = this.o;
                                var1_1 = this.h.m;
                                var1_1 = var1_1 == -1 ? -1 : (var1_1 /= 1000);
                                var10_10 = this.h.l;
                                if (this.d != null && this.g != null) {
                                    this.d.post((Runnable)new aj(this, var10_10, var1_1, var3_2 - var14_14));
                                }
                            }
                        }
lbl38: // 7 sources:
                        try {
                            var16_11 = this.h;
                            var13_12 = var7_7.offset;
                            var12_13 = var7_7.size;
                            var3_2 = var7_7.presentationTimeUs;
                            if (var12_13 == 0) {
                                var10_10 = 2;
                                break block35;
                            }
                            if (var16_11.h()) {
                                if (var16_11.f.getPlayState() == 2) {
                                    var10_10 = 0;
                                    break block35;
                                }
                                if (var16_11.f.getPlayState() == 1 && var16_11.e.b() != 0) {
                                    var10_10 = 0;
                                    break block35;
                                }
                            }
                            var10_10 = 0;
                            var11_15 = 0;
                            if (var16_11.E != 0) break block36;
                            var16_11.E = var12_13;
                            var6_6.position(var13_12);
                            if (var16_11.j && var16_11.w == 0) {
                                var16_11.w = i.a(var16_11.i, var6_6);
                            }
                            if (var16_11.j) {
                                var1_1 = var16_11.w;
                            } else {
                                var1_1 = var12_13;
                                var1_1 /= (long)var16_11.k;
                            }
                            var1_1 = var3_2 - var1_1 * 1000000 / (long)var16_11.g;
                            if (var16_11.x != 0) break block37;
                            var16_11.y = Math.max(0, var1_1);
                            var16_11.x = 1;
                            break block38;
                        }
                        catch (com.d.a.a.c.b var5_5) {
                            if (this.d == null) throw new p(var5_5);
                            if (this.g == null) throw new p(var5_5);
                            this.d.post((Runnable)new ai(this, var5_5));
                            throw new p(var5_5);
                        }
                    }
                    var3_2 = var16_11.y + var16_11.f() * 1000000 / (long)var16_11.g;
                    if (var16_11.x == 1 && Math.abs(var3_2 - var1_1) > 200000) {
                        Log.e((String)"AudioTrack", (String)("Discontinuity detected [expected " + var3_2 + ", got " + var1_1 + "]"));
                        var16_11.x = 2;
                    }
                    if (var16_11.x == 2) {
                        var16_11.y += var1_1 - var3_2;
                        var16_11.x = 1;
                        var11_15 = 1;
                    }
                }
                var10_10 = var11_15;
                if (com.d.a.a.d.ah.a < 21) {
                    if (var16_11.C == null || var16_11.C.length < var12_13) {
                        var16_11.C = new byte[var12_13];
                    }
                    var6_6.get(var16_11.C, 0, var12_13);
                    var16_11.D = 0;
                    var10_10 = var11_15;
                }
            }
            var11_15 = 0;
            if (com.d.a.a.d.ah.a < 21) {
                var12_13 = (int)(var16_11.u - var16_11.e.b() * (long)var16_11.k);
                if ((var12_13 = var16_11.l - var12_13) > 0) {
                    var11_15 = Math.min(var16_11.E, var12_13);
                    var11_15 = var12_13 = var16_11.f.write(var16_11.C, var16_11.D, var11_15);
                    if (var12_13 >= 0) {
                        var16_11.D += var12_13;
                        var11_15 = var12_13;
                    }
                }
            } else {
                var11_15 = i.a(var16_11.f, var6_6, var16_11.E);
            }
            if (var11_15 < 0) {
                throw new com.d.a.a.c.b(var11_15);
            }
            var16_11.E -= var11_15;
            if (!var16_11.j) {
                var16_11.u += (long)var11_15;
            }
            if (var16_11.E == 0) {
                if (var16_11.j) {
                    var16_11.v += (long)var16_11.w;
                }
                var10_10 |= 2;
            }
        }
        this.o = SystemClock.elapsedRealtime();
        if ((var10_10 & 1) != 0) {
            this.m = true;
        }
        if ((var10_10 & 2) == 0) return false;
        var5_3.releaseOutputBuffer(var8_8, false);
        var5_3 = this.b;
        ++var5_3.f;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected final boolean a(at at2, q object) {
        boolean bl2 = false;
        object = object.b;
        boolean bl3 = bl2;
        if (!ab.a((String)object).equals("audio")) return bl3;
        if ("audio/x-unknown".equals(object)) return true;
        if (this.a((String)object)) {
            at2.a();
            do {
                return true;
                break;
            } while (true);
        }
        bl3 = bl2;
        if (at2.a((String)object, false) == null) return bl3;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final long a_() {
        long l2;
        long l3;
        i i2 = this.h;
        boolean bl2 = this.c();
        if (i2.f == null) {
            return this.l;
        }
        int n2 = 1;
        if (n2 == 0) {
            return this.l;
        }
        if (i2.x == 0) return this.l;
        n2 = 1;
        if (n2 == 0) {
            return this.l;
        }
        if (i2.f.getPlayState() == 3 && (l3 = i2.e.c()) != 0) {
            l2 = System.nanoTime() / 1000;
            if (l2 - i2.q >= 30000) {
                i2.d[i2.n] = l3 - l2;
                i2.n = (i2.n + 1) % 10;
                if (i2.o < 10) {
                    ++i2.o;
                }
                i2.q = l2;
                i2.p = 0;
                for (n2 = 0; n2 < i2.o; i2.p += i2.d[n2] / (long)i2.o, ++n2) {
                }
            }
            if (!i2.h() && l2 - i2.s >= 500000) {
                i2.r = i2.e.d();
                if (i2.r) {
                    long l4 = i2.e.e() / 1000;
                    long l5 = i2.e.f();
                    if (l4 < i2.z) {
                        i2.r = false;
                    } else if (Math.abs(l4 - l2) > 5000000) {
                        String string = "Spurious audio timestamp (system clock mismatch): " + l5 + ", " + l4 + ", " + l2 + ", " + l3;
                        if (i.b) {
                            throw new com.d.a.a.c.c(string);
                        }
                        Log.w((String)"AudioTrack", (String)string);
                        i2.r = false;
                    } else if (Math.abs(1000000 * l5 / (long)i2.g - l3) > 5000000) {
                        String string = "Spurious audio timestamp (frame position mismatch): " + l5 + ", " + l4 + ", " + l2 + ", " + l3;
                        if (i.b) {
                            throw new com.d.a.a.c.c(string);
                        }
                        Log.w((String)"AudioTrack", (String)string);
                        i2.r = false;
                    }
                }
                if (i2.t != null && !i2.j) {
                    try {
                        i2.A = (long)((Integer)i2.t.invoke((Object)i2.f, null)).intValue() * 1000 - i2.m;
                        i2.A = Math.max(i2.A, 0);
                        if (i2.A > 5000000) {
                            Log.w((String)"AudioTrack", (String)("Ignoring impossibly large audio latency: " + i2.A));
                            i2.A = 0;
                        }
                    }
                    catch (Exception var12_10) {
                        i2.t = null;
                    }
                }
                i2.s = l2;
            }
        }
        l3 = System.nanoTime() / 1000;
        if (i2.r) {
            l3 = ((long)((float)(l3 - i2.e.e() / 1000) * i2.e.g()) * (long)i2.g / 1000000 + i2.e.f()) * 1000000 / (long)i2.g + i2.y;
        } else {
            l2 = i2.o == 0 ? i2.e.c() + i2.y : l3 + i2.p + i2.y;
            l3 = l2;
            if (!bl2) {
                l3 = l2 - i2.A;
            }
        }
        if (l3 != Long.MIN_VALUE) {
            if (!this.m) {
                l3 = Math.max(this.l, l3);
            }
            this.l = l3;
            this.m = false;
        }
        return this.l;
    }

    @Override
    protected final void c(long l2) {
        super.c(l2);
        this.h.d();
        this.l = l2;
        this.m = true;
    }

    @Override
    protected final boolean c() {
        if (super.c() && !this.h.b()) {
            return true;
        }
        return false;
    }

    @Override
    protected final boolean d() {
        if (this.h.b() || super.d()) {
            return true;
        }
        return false;
    }

    @Override
    public r h() {
        return this;
    }

    @Override
    protected final void j() {
        super.j();
        this.h.a();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void l() {
        Object object = this.h;
        boolean bl2 = object.f != null;
        if (bl2) {
            object.g();
            object = object.e;
            if (object.g == -1) {
                object.a.pause();
            }
        }
        super.l();
    }

    @Override
    protected final void m() {
        this.k = 0;
        try {
            i i2 = this.h;
            i2.d();
            i2.e();
            return;
        }
        finally {
            super.m();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected final void p() {
        i i2 = this.h;
        if (i2.f == null) return;
        boolean bl2 = true;
        if (!bl2) return;
        f f2 = i2.e;
        long l2 = i2.f();
        f2.h = f2.b();
        f2.g = SystemClock.elapsedRealtime() * 1000;
        f2.i = l2;
        f2.a.stop();
    }
}

