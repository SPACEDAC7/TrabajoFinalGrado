/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.am;

public interface al {
    public void a(am var1);
}

