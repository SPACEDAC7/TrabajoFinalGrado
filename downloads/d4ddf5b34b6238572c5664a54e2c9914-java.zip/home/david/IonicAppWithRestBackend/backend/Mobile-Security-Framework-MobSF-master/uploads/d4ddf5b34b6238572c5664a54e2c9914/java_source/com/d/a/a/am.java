/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.MediaCodec
 *  android.media.MediaCodec$CodecException
 */
package com.d.a.a;

import android.media.MediaCodec;
import com.d.a.a.d.ah;
import com.d.a.a.q;

public final class am
extends Exception {
    public final String a;
    public final boolean b;
    public final String c;
    public final String d;

    /*
     * Enabled aggressive block sorting
     */
    public am(q object, Throwable throwable, boolean bl2, int n2) {
        super("Decoder init failed: [" + n2 + "], " + object, throwable);
        this.a = object.b;
        this.b = bl2;
        this.c = null;
        object = n2 < 0 ? "neg_" : "";
        this.d = "com.google.android.exoplayer.MediaCodecTrackRenderer_" + (String)object + Math.abs(n2);
    }

    public am(q object, Throwable throwable, boolean bl2, String string) {
        Object var5_5 = null;
        super("Decoder init failed: " + string + ", " + object, throwable);
        this.a = object.b;
        this.b = bl2;
        this.c = string;
        object = var5_5;
        if (ah.a >= 21) {
            object = var5_5;
            if (throwable instanceof MediaCodec.CodecException) {
                object = ((MediaCodec.CodecException)throwable).getDiagnosticInfo();
            }
        }
        this.d = object;
    }
}

