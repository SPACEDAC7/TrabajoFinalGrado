/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.al;
import com.d.a.a.am;
import com.d.a.a.aq;

final class an
implements Runnable {
    final /* synthetic */ am a;
    final /* synthetic */ aq b;

    an(aq aq2, am am2) {
        this.b = aq2;
        this.a = am2;
    }

    @Override
    public final void run() {
        this.b.c.a(this.a);
    }
}

