/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.MediaCodec
 *  android.media.MediaCodec$CryptoException
 */
package com.d.a.a;

import android.media.MediaCodec;
import com.d.a.a.aq;

final class ao
implements Runnable {
    final /* synthetic */ MediaCodec.CryptoException a;
    final /* synthetic */ aq b;

    ao(aq aq2, MediaCodec.CryptoException cryptoException) {
        this.b = aq2;
        this.a = cryptoException;
    }

    @Override
    public final void run() {
    }
}

