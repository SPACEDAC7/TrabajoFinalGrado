/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.aq;

final class ap
implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ long b;
    final /* synthetic */ long c;
    final /* synthetic */ aq d;

    ap(aq aq2, String string, long l2, long l3) {
        this.d = aq2;
        this.a = string;
        this.b = l2;
        this.c = l3;
    }

    @Override
    public final void run() {
    }
}

