/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.MediaCodec
 *  android.media.MediaCodec$BufferInfo
 *  android.media.MediaCodec$CryptoException
 *  android.media.MediaCrypto
 *  android.media.MediaFormat
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.os.Trace
 */
package com.d.a.a;

import android.annotation.TargetApi;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Trace;
import com.d.a.a.aa;
import com.d.a.a.al;
import com.d.a.a.am;
import com.d.a.a.an;
import com.d.a.a.ao;
import com.d.a.a.ap;
import com.d.a.a.ar;
import com.d.a.a.at;
import com.d.a.a.b.d;
import com.d.a.a.c;
import com.d.a.a.d.ah;
import com.d.a.a.e;
import com.d.a.a.o;
import com.d.a.a.p;
import com.d.a.a.q;
import com.d.a.a.x;
import com.d.a.a.y;
import com.d.a.a.z;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

@TargetApi(value=16)
public abstract class aq
extends ar {
    private int A;
    private boolean B;
    private boolean C;
    private int D;
    private int E;
    private boolean F;
    private boolean G;
    private boolean H;
    private boolean I;
    private boolean J;
    private boolean K;
    public final c b;
    final al c;
    protected final Handler d;
    MediaCodec e;
    int f;
    private final at g;
    private final com.d.a.a.b.e h;
    private final boolean i;
    private final z j;
    private final y k;
    private final List<Long> l;
    private final MediaCodec.BufferInfo m;
    private final boolean n;
    private q o;
    private d p;
    private boolean q;
    private boolean r;
    private boolean s;
    private boolean t;
    private boolean u;
    private boolean v;
    private ByteBuffer[] w;
    private ByteBuffer[] x;
    private long y;
    private int z;

    public aq(x x2, at at2, com.d.a.a.b.e e2, boolean bl2, Handler handler, al al2) {
        this(new x[]{x2}, at2, null, false, handler, al2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aq(x[] arrx, at at2, com.d.a.a.b.e e2, boolean bl2, Handler handler, al al2) {
        boolean bl3 = true;
        super(arrx);
        boolean bl4 = ah.a >= 16;
        if (!bl4) {
            throw new IllegalStateException();
        }
        if (at2 == null) {
            throw new NullPointerException();
        }
        this.g = at2;
        this.h = e2;
        this.i = bl2;
        this.d = handler;
        this.c = al2;
        bl2 = ah.a <= 22 && "foster".equals(ah.b) && "NVIDIA".equals(ah.c) ? bl3 : false;
        this.n = bl2;
        this.b = new c();
        this.j = new z(0);
        this.k = new y();
        this.l = new ArrayList<Long>();
        this.m = new MediaCodec.BufferInfo();
        this.D = 0;
        this.E = 0;
    }

    private void a(MediaCodec.CryptoException cryptoException) {
        if (this.d != null && this.c != null) {
            this.d.post((Runnable)new ao(this, cryptoException));
        }
    }

    private void a(am am2) {
        if (this.d != null && this.c != null) {
            this.d.post((Runnable)new an(this, am2));
        }
        throw new p(am2);
    }

    /*
     * Exception decompiling
     */
    private boolean a(long var1_1, boolean var3_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl142 : TryStatement: try { 2[TRYBLOCK]

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps.apply(RemoveDeterministicJumps.java:35)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:519)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private void t() {
        if (this.E == 2) {
            this.s();
            this.q();
            return;
        }
        this.I = true;
        this.p();
    }

    protected e a(at at2, String string, boolean bl2) {
        return at2.a(string, bl2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final void a(long var1_1, long var3_2, boolean var5_3) {
        block23 : {
            block22 : {
                var6_4 = var5_3 ? (this.f == 0 ? 1 : this.f) : 0;
                this.f = var6_4;
                if (this.o == null && this.a(var1_1, this.k, null) == -4) {
                    this.a(this.k);
                }
                this.q();
                if (this.e == null) ** GOTO lbl46
                if (ah.a >= 18) {
                    Trace.beginSection((String)"drainAndFeed");
                }
                while (!this.I) {
                    if (this.A < 0) {
                        this.A = this.e.dequeueOutputBuffer(this.m, 0);
                    }
                    if (this.A == -2) {
                        var10_7 = this.e.getOutputFormat();
                        if (this.v) {
                            var10_7.setInteger("channel-count", 1);
                        }
                        this.a((MediaFormat)var10_7);
                        var10_7 = this.b;
                        ++var10_7.d;
                        var6_4 = 1;
                    } else if (this.A == -3) {
                        this.x = this.e.getOutputBuffers();
                        var10_7 = this.b;
                        ++var10_7.e;
                        var6_4 = 1;
                    } else if (this.A < 0) {
                        if (this.t && (this.H || this.E == 2)) {
                            this.t();
                            var6_4 = 1;
                        } else {
                            var6_4 = 0;
                        }
                    } else {
                        if ((this.m.flags & 4) != 0) {
                            this.t();
                            break;
                        }
                        var8_6 = this.m.presentationTimeUs;
                        var7_5 = this.l.size();
                        break block22;
                    }
lbl40: // 6 sources:
                    while (var6_4 == 0) {
                        if (this.a(var1_1, true)) {
                            while (this.a(var1_1, false)) {
                            }
                        }
                        if (ah.a >= 18) {
                            Trace.endSection();
                        }
lbl46: // 4 sources:
                        this.b.a();
                        return;
                    }
                }
lbl49: // 3 sources:
                do {
                    var6_4 = 0;
                    ** GOTO lbl40
                    break;
                } while (true);
            }
            for (var6_4 = 0; var6_4 < var7_5; ++var6_4) {
                if (this.l.get(var6_4) != var8_6) {
                    continue;
                }
                break block23;
            }
            var6_4 = -1;
        }
        var10_7 = this.e;
        var11_8 = this.x[this.A];
        var12_9 = this.m;
        var7_5 = this.A;
        var5_3 = var6_4 != -1;
        ** while (!this.a((long)var1_1, (long)var3_2, (MediaCodec)var10_7, (ByteBuffer)var11_8, (MediaCodec.BufferInfo)var12_9, (int)var7_5, (boolean)var5_3))
lbl65: // 1 sources:
        var8_6 = this.m.presentationTimeUs;
        if (var6_4 != -1) {
            this.l.remove(var6_4);
        }
        this.A = -1;
        var6_4 = 1;
        ** GOTO lbl40
    }

    protected abstract void a(MediaCodec var1, boolean var2, MediaFormat var3, MediaCrypto var4);

    protected void a(MediaFormat mediaFormat) {
    }

    protected void a(y y2) {
        q q2 = this.o;
        this.o = y2.a;
        this.p = y2.b;
        if (this.e != null && this.a(this.q, q2, this.o)) {
            this.C = true;
            this.D = 1;
            return;
        }
        if (this.F) {
            this.E = 1;
            return;
        }
        this.s();
        this.q();
    }

    protected abstract boolean a(long var1, long var3, MediaCodec var5, ByteBuffer var6, MediaCodec.BufferInfo var7, int var8, boolean var9);

    protected abstract boolean a(at var1, q var2);

    @Override
    protected final boolean a(q q2) {
        return this.a(this.g, q2);
    }

    protected boolean a(boolean bl2, q q2, q q3) {
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void c(long l2) {
        this.f = 0;
        this.H = false;
        this.I = false;
        if (this.e != null) {
            this.y = -1;
            this.z = -1;
            this.A = -1;
            this.K = true;
            this.J = false;
            this.l.clear();
            if (this.s || this.u && this.G) {
                this.s();
                this.q();
            } else if (this.E != 0) {
                this.s();
                this.q();
            } else {
                this.e.flush();
                this.F = false;
            }
            if (this.C && this.o != null) {
                this.D = 1;
            }
        }
    }

    @Override
    protected boolean c() {
        return this.I;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean d() {
        if (this.o == null || this.J) return false;
        if (this.f != 0 || this.A >= 0) return true;
        if (SystemClock.elapsedRealtime() >= this.y + 1000) return false;
        return true;
    }

    @Override
    protected void j() {
    }

    @Override
    protected void l() {
    }

    @Override
    protected void m() {
        this.o = null;
        this.p = null;
        try {
            this.s();
        }
        catch (Throwable var1_2) {
            try {
                if (this.B) {
                    this.B = false;
                }
                throw var1_2;
            }
            finally {
                super.m();
            }
        }
        try {
            if (this.B) {
                this.B = false;
            }
            return;
        }
        finally {
            super.m();
        }
    }

    protected void p() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected final void q() {
        long l2;
        boolean bl2;
        Object object;
        boolean bl3 = false;
        if (!this.r()) {
            return;
        }
        Object object2 = this.o.b;
        if (this.p != null) {
            int n2;
            if (this.h == null) {
                throw new p("Media requires a DrmSessionManager");
            }
            if (!this.B) {
                this.B = true;
            }
            if ((n2 = this.h.a()) == 0) {
                throw new p(this.h.d());
            }
            if (n2 != 3) {
                if (n2 != 4) return;
            }
            object = this.h.b();
            bl2 = this.h.c();
        } else {
            bl2 = false;
            object = null;
        }
        try {
            object2 = this.a(this.g, (String)object2, bl2);
        }
        catch (aa var10_3) {
            this.a(new am(this.o, (Throwable)var10_3, bl2, -49998));
            object2 = null;
        }
        if (object2 == null) {
            this.a(new am(this.o, null, bl2, -49999));
        }
        String string = object2.a;
        this.q = object2.b;
        Object object3 = this.o;
        boolean bl4 = ah.a < 21 && object3.f.isEmpty() && "OMX.MTK.VIDEO.DECODER.AVC".equals(string);
        this.r = bl4;
        bl4 = ah.a < 18 || ah.a == 18 && ("OMX.SEC.avc.dec".equals(string) || "OMX.SEC.avc.dec.secure".equals(string)) || ah.a == 19 && ah.d.startsWith("SM-G800") && ("OMX.Exynos.avc.dec".equals(string) || "OMX.Exynos.avc.dec.secure".equals(string));
        this.s = bl4;
        bl4 = ah.a <= 17 && "OMX.rk.video_decoder.avc".equals(string);
        this.t = bl4;
        bl4 = ah.a <= 23 && "OMX.google.vorbis.decoder".equals(string);
        this.u = bl4;
        object3 = this.o;
        bl4 = bl3;
        if (ah.a <= 18) {
            bl4 = bl3;
            if (object3.n == 1) {
                bl4 = bl3;
                if ("OMX.MTK.AUDIO.DECODER.MP3".equals(string)) {
                    bl4 = true;
                }
            }
        }
        this.v = bl4;
        try {
            l2 = SystemClock.elapsedRealtime();
            object3 = "createByCodecName(" + string + ")";
            if (ah.a >= 18) {
                Trace.beginSection((String)object3);
            }
            this.e = MediaCodec.createByCodecName((String)string);
            if (ah.a >= 18) {
                Trace.endSection();
            }
            if (ah.a >= 18) {
                Trace.beginSection((String)"configureCodec");
            }
            object3 = this.e;
            bl4 = object2.b;
            object2 = this.o.b();
            if (this.n) {
                object2.setInteger("auto-frc", 0);
            }
            this.a((MediaCodec)object3, bl4, (MediaFormat)object2, (MediaCrypto)object);
            if (ah.a >= 18) {
                Trace.endSection();
            }
            if (ah.a >= 18) {
                Trace.beginSection((String)"codec.start()");
            }
            this.e.start();
            if (ah.a >= 18) {
                Trace.endSection();
            }
            long l3 = SystemClock.elapsedRealtime();
            if (this.d != null && this.c != null) {
                this.d.post((Runnable)new ap(this, string, l3, l3 - l2));
            }
            this.w = this.e.getInputBuffers();
            this.x = this.e.getOutputBuffers();
        }
        catch (Exception var9_6) {
            this.a(new am(this.o, (Throwable)var9_6, bl2, string));
        }
        l2 = this.a == 3 ? SystemClock.elapsedRealtime() : -1;
        this.y = l2;
        this.z = -1;
        this.A = -1;
        this.K = true;
        object = this.b;
        ++object.a;
    }

    protected boolean r() {
        if (this.e == null && this.o != null) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void s() {
        if (this.e == null) return;
        this.y = -1;
        this.z = -1;
        this.A = -1;
        this.J = false;
        this.l.clear();
        this.w = null;
        this.x = null;
        this.C = false;
        this.F = false;
        this.q = false;
        this.r = false;
        this.s = false;
        this.t = false;
        this.u = false;
        this.v = false;
        this.G = false;
        this.D = 0;
        this.E = 0;
        c c2 = this.b;
        ++c2.b;
        try {
            this.e.stop();
        }
        catch (Throwable throwable) {
            try {
                this.e.release();
                throw throwable;
            }
            finally {
                this.e = null;
            }
        }
        this.e.release();
        return;
        finally {
            this.e = null;
        }
    }
}

