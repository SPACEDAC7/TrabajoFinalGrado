/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.aa;
import com.d.a.a.o;
import com.d.a.a.p;
import com.d.a.a.q;
import com.d.a.a.w;
import com.d.a.a.x;
import com.d.a.a.y;
import com.d.a.a.z;
import java.io.IOException;
import java.util.Arrays;

public abstract class ar
extends o {
    private final w[] b;
    private int[] c;
    private int[] d;
    private w e;
    private int f;
    private long g;

    public /* varargs */ ar(x ... arrx) {
        this.b = new w[arrx.length];
        for (int i2 = 0; i2 < arrx.length; ++i2) {
            this.b[i2] = arrx[i2].f();
        }
    }

    private static void a(w w2) {
        try {
            w2.b_();
            return;
        }
        catch (IOException var0_1) {
            throw new p(var0_1);
        }
    }

    private long d(long l2) {
        long l3 = this.e.b(this.f);
        if (l3 != Long.MIN_VALUE) {
            this.c(l3);
            l2 = l3;
        }
        return l2;
    }

    public final int a(long l2, y y2, z z2) {
        return this.e.a(this.f, l2, y2, z2);
    }

    @Override
    public final q a(int n2) {
        return this.b[this.c[n2]].a(this.d[n2]);
    }

    @Override
    public void a(int n2, long l2, boolean bl2) {
        this.e = this.b[this.c[n2]];
        this.f = this.d[n2];
        this.e.a(this.f, l2);
        this.c(l2);
    }

    @Override
    protected final void a(long l2) {
        this.e.a(l2);
        this.d(l2);
    }

    @Override
    protected final void a(long l2, long l3) {
        boolean bl2 = this.e.b(this.f, l2);
        this.a(this.d(l2), l3, bl2);
    }

    public abstract void a(long var1, long var3, boolean var5);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected final boolean a() {
        int n2;
        int n3 = 1;
        for (n2 = 0; n2 < this.b.length; n3 &= this.b[n2].b(), ++n2) {
        }
        if (n3 == 0) {
            return false;
        }
        n3 = 0;
        for (n2 = 0; n2 < this.b.length; n3 += this.b[n2].c(), ++n2) {
        }
        int[] arrn = new int[n3];
        int[] arrn2 = new int[n3];
        int n4 = this.b.length;
        n2 = 0;
        long l2 = 0;
        n3 = 0;
        do {
            if (n3 >= n4) {
                this.g = l2;
                this.c = Arrays.copyOf(arrn, n2);
                this.d = Arrays.copyOf(arrn2, n2);
                return true;
            }
            w w2 = this.b[n3];
            int n5 = w2.c();
            for (int i2 = 0; i2 < n5; ++i2) {
                long l3;
                int n6;
                block9 : {
                    long l4;
                    block10 : {
                        q q2 = w2.a(i2);
                        try {
                            boolean bl2 = this.a(q2);
                            n6 = n2++;
                            l3 = l2;
                            if (!bl2) break block9;
                            arrn[n2] = n3;
                            arrn2[n2] = i2;
                            n6 = n2;
                            l3 = l2;
                            if (l2 == -1) break block9;
                            l4 = q2.e;
                            if (l4 != -1) break block10;
                            l3 = -1;
                            n6 = n2;
                            break block9;
                        }
                        catch (aa var14_4) {
                            throw new p(var14_4);
                        }
                    }
                    n6 = n2;
                    l3 = l2;
                    if (l4 != -2) {
                        l3 = Math.max(l2, l4);
                        n6 = n2;
                    }
                }
                n2 = n6;
                l2 = l3;
            }
            ++n3;
        } while (true);
    }

    public abstract boolean a(q var1);

    @Override
    protected final int b() {
        return this.d.length;
    }

    public abstract void c(long var1);

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected final void e() {
        if (this.e != null) {
            ar.a(this.e);
            return;
        }
        int n2 = this.b.length;
        int n3 = 0;
        while (n3 < n2) {
            ar.a(this.b[n3]);
            ++n3;
        }
    }

    @Override
    protected final long f() {
        return this.g;
    }

    @Override
    public long g() {
        return this.e.d();
    }

    @Override
    public void m() {
        this.e.c(this.f);
        this.e = null;
    }

    @Override
    protected final void o() {
        int n2 = this.b.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            this.b[i2].e();
        }
    }
}

