/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.MediaCodecInfo
 *  android.media.MediaCodecInfo$CodecCapabilities
 *  android.util.Pair
 */
package com.d.a.a;

import android.media.MediaCodecInfo;
import android.util.Pair;
import com.d.a.a.af;
import com.d.a.a.at;
import com.d.a.a.d.ah;
import com.d.a.a.e;

final class as
implements at {
    as() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final e a(String object, boolean bl2) {
        MediaCodecInfo.CodecCapabilities codecCapabilities = af.b((String)object, bl2);
        if (codecCapabilities == null) {
            return null;
        }
        object = (String)codecCapabilities.first;
        codecCapabilities = (MediaCodecInfo.CodecCapabilities)codecCapabilities.second;
        if (ah.a >= 19) {
            bl2 = codecCapabilities.isFeatureSupported("adaptive-playback");
            do {
                return new e((String)object, bl2);
                break;
            } while (true);
        }
        bl2 = false;
        return new e((String)object, bl2);
    }

    @Override
    public final String a() {
        return "OMX.google.raw.decoder";
    }
}

