/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.as;
import com.d.a.a.e;

public interface at {
    public static final at a = new as();

    public e a(String var1, boolean var2);

    public String a();
}

