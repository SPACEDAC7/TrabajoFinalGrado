/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.RemoteException
 */
package com.d.a.a;

import android.os.RemoteException;
import com.d.a.a.ay;
import com.instagram.exoplayer.ipc.f;
import com.instagram.exoplayer.service.n;
import com.instagram.exoplayer.service.q;

final class av
implements Runnable {
    final /* synthetic */ int a;
    final /* synthetic */ int b;
    final /* synthetic */ int c;
    final /* synthetic */ float d;
    final /* synthetic */ ay e;

    av(ay ay2, int n2, int n3, int n4, float f2) {
        this.e = ay2;
        this.a = n2;
        this.b = n3;
        this.c = n4;
        this.d = f2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void run() {
        n n2 = this.e.g;
        int n3 = this.a;
        int n4 = this.b;
        if (n2.a.d == null) return;
        try {
            n2.a.d.a(n3, n4);
            return;
        }
        catch (RemoteException var3_2) {
            return;
        }
    }
}

