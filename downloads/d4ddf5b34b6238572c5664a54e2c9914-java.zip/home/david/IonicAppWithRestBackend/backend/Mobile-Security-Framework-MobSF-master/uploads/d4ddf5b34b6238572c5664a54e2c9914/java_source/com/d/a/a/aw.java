/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.Surface
 */
package com.d.a.a;

import android.view.Surface;
import com.d.a.a.ay;

final class aw
implements Runnable {
    final /* synthetic */ Surface a;
    final /* synthetic */ ay b;

    aw(ay ay2, Surface surface) {
        this.b = ay2;
        this.a = surface;
    }

    @Override
    public final void run() {
    }
}

