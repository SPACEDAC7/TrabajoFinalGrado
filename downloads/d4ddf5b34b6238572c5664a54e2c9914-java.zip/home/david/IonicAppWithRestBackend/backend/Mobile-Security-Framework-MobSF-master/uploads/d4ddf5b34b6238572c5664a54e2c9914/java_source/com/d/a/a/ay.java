/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.media.MediaCodec
 *  android.media.MediaCodec$BufferInfo
 *  android.media.MediaCrypto
 *  android.media.MediaFormat
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.os.Trace
 *  android.view.Surface
 */
package com.d.a.a;

import android.annotation.TargetApi;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Trace;
import android.view.Surface;
import com.d.a.a.al;
import com.d.a.a.aq;
import com.d.a.a.at;
import com.d.a.a.av;
import com.d.a.a.aw;
import com.d.a.a.ax;
import com.d.a.a.az;
import com.d.a.a.ba;
import com.d.a.a.c;
import com.d.a.a.d.ab;
import com.d.a.a.d.ah;
import com.d.a.a.e;
import com.d.a.a.o;
import com.d.a.a.q;
import com.d.a.a.x;
import com.d.a.a.y;
import com.instagram.exoplayer.service.n;
import java.nio.ByteBuffer;

@TargetApi(value=16)
public final class ay
extends aq {
    private int A;
    private float B;
    final n g;
    private final ba h;
    private final long i;
    private final int j;
    private final int k;
    private Surface l;
    private boolean m;
    private boolean n;
    private long o;
    private long p;
    private int q;
    private int r;
    private int s;
    private float t;
    private int u;
    private int v;
    private int w;
    private float x;
    private int y;
    private int z;

    private ay(Context context, x x2, at at2, int n2, long l2, Handler handler, n n3, int n4) {
        super(x2, at2, null, false, handler, (al)n3);
        this.h = new ba(context);
        this.j = 1;
        this.i = 0;
        this.g = n3;
        this.k = -1;
        this.o = -1;
        this.u = -1;
        this.v = -1;
        this.x = -1.0f;
        this.t = -1.0f;
        this.y = -1;
        this.z = -1;
        this.B = -1.0f;
    }

    public ay(Context context, x x2, at at2, Handler handler, n n2) {
        this(context, x2, at2, 1, 0, handler, n2, -1);
    }

    private void a(MediaCodec object, int n2) {
        this.t();
        if (ah.a >= 18) {
            Trace.beginSection((String)"releaseOutputBuffer");
        }
        object.releaseOutputBuffer(n2, true);
        if (ah.a >= 18) {
            Trace.endSection();
        }
        object = this.b;
        ++object.f;
        this.n = true;
        this.u();
    }

    @TargetApi(value=21)
    private void a(MediaCodec object, int n2, long l2) {
        this.t();
        if (ah.a >= 18) {
            Trace.beginSection((String)"releaseOutputBuffer");
        }
        object.releaseOutputBuffer(n2, l2);
        if (ah.a >= 18) {
            Trace.endSection();
        }
        object = this.b;
        ++object.f;
        this.n = true;
        this.u();
    }

    private void t() {
        if (this.d == null || this.g == null || this.y == this.u && this.z == this.v && this.A == this.w && this.B == this.x) {
            return;
        }
        int n2 = this.u;
        int n3 = this.v;
        int n4 = this.w;
        float f2 = this.x;
        this.d.post((Runnable)new av(this, n2, n3, n4, f2));
        this.y = n2;
        this.z = n3;
        this.A = n4;
        this.B = f2;
    }

    private void u() {
        if (this.d == null || this.g == null || this.m) {
            return;
        }
        Surface surface = this.l;
        this.d.post((Runnable)new aw(this, surface));
        this.m = true;
    }

    private void v() {
        if (this.d == null || this.g == null || this.q == 0) {
            return;
        }
        long l2 = SystemClock.elapsedRealtime();
        int n2 = this.q;
        long l3 = this.p;
        this.d.post((Runnable)new ax(this, n2, l2 - l3));
        this.q = 0;
        this.p = l2;
    }

    @Override
    protected final void a(int n2, long l2, boolean bl2) {
        super.a(n2, l2, bl2);
        if (bl2 && this.i > 0) {
            this.o = SystemClock.elapsedRealtime() * 1000 + this.i;
        }
        ba ba2 = this.h;
        ba2.h = false;
        if (ba2.b) {
            ba2.a.b.sendEmptyMessage(1);
        }
    }

    @Override
    public final void a(int n2, Object object) {
        if (n2 == 1) {
            if (this.l != (object = (Surface)object)) {
                this.l = object;
                this.m = false;
                n2 = this.a;
                if (n2 == 2 || n2 == 3) {
                    this.s();
                    this.q();
                }
            }
            return;
        }
        super.a(n2, object);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final void a(MediaCodec var1_1, boolean var2_2, MediaFormat var3_3, MediaCrypto var4_4) {
        if (var3_3.containsKey("max-input-size")) ** GOTO lbl62
        var6_6 = var5_5 = var3_3.getInteger("height");
        if (var2_2) {
            var6_6 = var5_5;
            if (var3_3.containsKey("max-height")) {
                var6_6 = Math.max(var5_5, var3_3.getInteger("max-height"));
            }
        }
        var7_7 = var5_5 = var3_3.getInteger("width");
        if (var2_2) {
            var7_7 = var5_5;
            if (var3_3.containsKey("max-width")) {
                var7_7 = Math.max(var6_6, var3_3.getInteger("max-width"));
            }
        }
        var8_8 = var3_3.getString("mime");
        var5_5 = -1;
        switch (var8_8.hashCode()) {
            case -1664118616: {
                if (var8_8.equals("video/3gpp")) {
                    var5_5 = 0;
                    ** break;
                }
                ** GOTO lbl38
            }
            case 1187890754: {
                if (var8_8.equals("video/mp4v-es")) {
                    var5_5 = 1;
                    ** break;
                }
                ** GOTO lbl38
            }
            case 1331836730: {
                if (var8_8.equals("video/avc")) {
                    var5_5 = 2;
                    ** break;
                }
                ** GOTO lbl38
            }
            case 1599127256: {
                if (var8_8.equals("video/x-vnd.on2.vp8")) {
                    var5_5 = 3;
                    ** break;
                }
                ** GOTO lbl38
            }
            case -1662541442: {
                if (var8_8.equals("video/hevc")) {
                    var5_5 = 4;
                }
            }
lbl38: // 12 sources:
            default: {
                ** GOTO lbl43
            }
            case 1599127257: 
        }
        if (var8_8.equals("video/x-vnd.on2.vp9")) {
            var5_5 = 5;
        }
lbl43: // 4 sources:
        switch (var5_5) {
            case 0: 
            case 1: {
                var6_6 *= var7_7;
                var5_5 = 2;
                ** GOTO lbl61
            }
            case 2: {
                if ("BRAVIA 4K 2015".equals(ah.d)) break;
                var5_5 = (var7_7 + 15) / 16;
                var6_6 = (var6_6 + 15) / 16 * var5_5 * 16 * 16;
                var5_5 = 2;
                ** GOTO lbl61
            }
            case 3: {
                var6_6 *= var7_7;
                var5_5 = 2;
                ** GOTO lbl61
            }
            case 4: 
            case 5: {
                var6_6 *= var7_7;
                var5_5 = 4;
lbl61: // 4 sources:
                var3_3.setInteger("max-input-size", var6_6 * 3 / (var5_5 * 2));
            }
        }
lbl62: // 4 sources:
        var1_1.configure(var3_3, this.l, var4_4, 0);
        var1_1.setVideoScalingMode(this.j);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(MediaFormat mediaFormat) {
        int n2 = mediaFormat.containsKey("crop-right") && mediaFormat.containsKey("crop-left") && mediaFormat.containsKey("crop-bottom") && mediaFormat.containsKey("crop-top") ? 1 : 0;
        int n3 = n2 != 0 ? mediaFormat.getInteger("crop-right") - mediaFormat.getInteger("crop-left") + 1 : mediaFormat.getInteger("width");
        this.u = n3;
        n2 = n2 != 0 ? mediaFormat.getInteger("crop-bottom") - mediaFormat.getInteger("crop-top") + 1 : mediaFormat.getInteger("height");
        this.v = n2;
        this.x = this.t;
        if (ah.a < 21) {
            this.w = this.s;
            return;
        }
        if (this.s == 90 || this.s == 270) {
            n2 = this.u;
            this.u = this.v;
            this.v = n2;
            this.x = 1.0f / this.x;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(y y2) {
        super.a(y2);
        float f2 = y2.a.m == -1.0f ? 1.0f : y2.a.m;
        this.t = f2;
        int n2 = y2.a.l == -1 ? 0 : y2.a.l;
        this.s = n2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected final boolean a(long var1_1, long var3_2, MediaCodec var5_3, ByteBuffer var6_4, MediaCodec.BufferInfo var7_6, int var8_7, boolean var9_8) {
        if (var9_8) {
            if (ah.a >= 18) {
                Trace.beginSection((String)"skipVideoBuffer");
            }
            var5_3.releaseOutputBuffer(var8_7, false);
            if (ah.a >= 18) {
                Trace.endSection();
            }
            var5_3 = this.b;
            ++var5_3.g;
            this.r = 0;
            return true;
        }
        if (!this.n) {
            if (ah.a >= 21) {
                this.a((MediaCodec)var5_3, var8_7, System.nanoTime());
            } else {
                this.a((MediaCodec)var5_3, var8_7);
            }
            this.r = 0;
            return true;
        }
        if (this.a != 3) {
            return false;
        }
        var10_9 = SystemClock.elapsedRealtime();
        var12_10 = var7_6.presentationTimeUs;
        var14_11 = System.nanoTime();
        var10_9 = var14_11 + (var12_10 - var1_1 - (var10_9 * 1000 - var3_2)) * 1000;
        var6_4 = this.h;
        var16_12 = var7_6.presentationTimeUs;
        var12_10 = var16_12 * 1000;
        if (!var6_4.h) ** GOTO lbl43
        if (var16_12 != var6_4.e) {
            ++var6_4.k;
            var6_4.f = var6_4.g;
        }
        if (var6_4.k >= 6) {
            var1_1 = (var12_10 - var6_4.j) / var6_4.k;
            var3_2 = var6_4.f + var1_1;
            if (var6_4.a(var3_2, var10_9)) {
                var6_4.h = false;
                var1_1 = var10_9;
                var3_2 = var12_10;
            } else {
                var1_1 = var6_4.i + var3_2 - var6_4.j;
            }
        } else {
            if (var6_4.a(var12_10, var10_9)) {
                var6_4.h = false;
            }
lbl43: // 4 sources:
            var1_1 = var10_9;
            var3_2 = var12_10;
        }
        if (!var6_4.h) {
            var6_4.j = var12_10;
            var6_4.i = var10_9;
            var6_4.k = 0;
            var6_4.h = true;
        }
        var6_4.e = var16_12;
        var6_4.g = var3_2;
        var3_2 = var1_1;
        if (var6_4.a != null) {
            if (var6_4.a.a == 0) {
                var3_2 = var1_1;
            } else {
                var3_2 = var6_4.a.a;
                var12_10 = var6_4.c;
                if (var1_1 <= (var3_2 += (var1_1 - var3_2) / var12_10 * var12_10)) {
                    var10_9 = var3_2 - var12_10;
                } else {
                    var10_9 = var3_2;
                    var3_2 = var12_10 + var3_2;
                }
                if (var3_2 - var1_1 >= var1_1 - var10_9) {
                    var3_2 = var10_9;
                }
                var3_2 -= var6_4.d;
            }
        }
        if ((var1_1 = (var3_2 - var14_11) / 1000) < -30000) {
            if (ah.a >= 18) {
                Trace.beginSection((String)"dropVideoBuffer");
            }
            var5_3.releaseOutputBuffer(var8_7, false);
            if (ah.a >= 18) {
                Trace.endSection();
            }
            var5_3 = this.b;
            ++var5_3.h;
            ++this.q;
            ++this.r;
            this.b.i = Math.max(this.r, this.b.i);
            if (this.q != this.k) return true;
            this.v();
            return true;
        }
        if (ah.a >= 21) {
            if (var1_1 >= 50000) return false;
            this.a((MediaCodec)var5_3, var8_7, var3_2);
            this.r = 0;
            return true;
        }
        if (var1_1 >= 30000) return false;
        if (var1_1 > 11000) {
            try {
                Thread.sleep((var1_1 - 10000) / 1000);
            }
            catch (InterruptedException var6_5) {
                Thread.currentThread().interrupt();
            }
        }
        this.a((MediaCodec)var5_3, var8_7);
        this.r = 0;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected final boolean a(at at2, q object) {
        boolean bl2 = false;
        object = object.b;
        boolean bl3 = bl2;
        if (!ab.a((String)object).equals("video")) return bl3;
        if ("video/x-unknown".equals(object)) return true;
        bl3 = bl2;
        if (at2.a((String)object, false) == null) return bl3;
        return true;
    }

    @Override
    protected final boolean a(boolean bl2, q q2, q q3) {
        if (q3.b.equals(q2.b) && (bl2 || q2.h == q3.h && q2.i == q3.i)) {
            return true;
        }
        return false;
    }

    @Override
    protected final void c(long l2) {
        super.c(l2);
        this.n = false;
        this.r = 0;
        this.o = -1;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final boolean d() {
        if (!super.d()) ** GOTO lbl7
        if (this.n) ** GOTO lbl-1000
        var1_1 = this.e != null;
        if (!var1_1 || this.f == 2) lbl-1000: // 2 sources:
        {
            this.o = -1;
            return true;
        }
lbl7: // 3 sources:
        if (this.o == -1) {
            return false;
        }
        if (SystemClock.elapsedRealtime() * 1000 < this.o) return true;
        this.o = -1;
        return false;
    }

    @Override
    protected final void j() {
        super.j();
        this.q = 0;
        this.p = SystemClock.elapsedRealtime();
    }

    @Override
    protected final void l() {
        this.o = -1;
        this.v();
        super.l();
    }

    @Override
    protected final void m() {
        this.u = -1;
        this.v = -1;
        this.x = -1.0f;
        this.t = -1.0f;
        this.y = -1;
        this.z = -1;
        this.B = -1.0f;
        ba ba2 = this.h;
        if (ba2.b) {
            ba2.a.b.sendEmptyMessage(2);
        }
        super.m();
    }

    @Override
    protected final boolean r() {
        if (super.r() && this.l != null && this.l.isValid()) {
            return true;
        }
        return false;
    }
}

