/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.os.Message
 *  android.view.Choreographer
 *  android.view.Choreographer$FrameCallback
 */
package com.d.a.a;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.view.Choreographer;

public final class az
implements Handler.Callback,
Choreographer.FrameCallback {
    public static final az c = new az();
    public volatile long a;
    final Handler b;
    private final HandlerThread d = new HandlerThread("ChoreographerOwner:Handler");
    private Choreographer e;
    private int f;

    private az() {
        this.d.start();
        this.b = new Handler(this.d.getLooper(), (Handler.Callback)this);
        this.b.sendEmptyMessage(0);
    }

    public final void doFrame(long l2) {
        this.a = l2;
        this.e.postFrameCallbackDelayed((Choreographer.FrameCallback)this, 500);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean handleMessage(Message message) {
        boolean bl2 = true;
        switch (message.what) {
            default: {
                return false;
            }
            case 0: {
                this.e = Choreographer.getInstance();
                return true;
            }
            case 1: {
                ++this.f;
                if (this.f != 1) return bl2;
                this.e.postFrameCallback((Choreographer.FrameCallback)this);
                return true;
            }
            case 2: 
        }
        --this.f;
        if (this.f != 0) return bl2;
        this.e.removeFrameCallback((Choreographer.FrameCallback)this);
        this.a = 0;
        return true;
    }
}

