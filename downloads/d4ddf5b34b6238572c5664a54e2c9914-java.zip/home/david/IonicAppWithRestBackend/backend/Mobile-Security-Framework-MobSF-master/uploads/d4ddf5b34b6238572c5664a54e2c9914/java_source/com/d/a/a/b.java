/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.d.ah;

public final class b {
    public static final int a;

    /*
     * Enabled aggressive block sorting
     */
    static {
        int n2 = ah.a < 23 ? 1020 : 6396;
        a = n2;
    }
}

