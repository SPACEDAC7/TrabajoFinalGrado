/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.b;

import com.d.a.a.b.c;
import com.d.a.a.b.d;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class a
implements d {
    public final Map<UUID, c> a = new HashMap<UUID, c>();
}

