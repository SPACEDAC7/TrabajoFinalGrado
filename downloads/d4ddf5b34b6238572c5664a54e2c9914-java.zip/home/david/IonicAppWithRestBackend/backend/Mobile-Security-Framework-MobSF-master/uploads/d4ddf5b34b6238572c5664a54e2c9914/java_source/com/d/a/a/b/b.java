/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.b;

import com.d.a.a.b.c;
import com.d.a.a.b.d;

public final class b
implements d {
    private c a;

    public b(c c2) {
        this.a = c2;
    }
}

