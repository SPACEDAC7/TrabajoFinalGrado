/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.b;

import java.util.Arrays;

public final class c {
    public final String a;
    public final byte[] b;

    public c(String string, byte[] arrby) {
        this.a = string;
        if (arrby == null) {
            throw new NullPointerException();
        }
        this.b = arrby;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (!(object instanceof c)) {
            return false;
        }
        if (object == this) {
            return true;
        }
        object = (c)object;
        if (!this.a.equals(object.a)) return false;
        if (!Arrays.equals(this.b, object.b)) return false;
        return true;
    }

    public final int hashCode() {
        return this.a.hashCode() + Arrays.hashCode(this.b) * 31;
    }
}

