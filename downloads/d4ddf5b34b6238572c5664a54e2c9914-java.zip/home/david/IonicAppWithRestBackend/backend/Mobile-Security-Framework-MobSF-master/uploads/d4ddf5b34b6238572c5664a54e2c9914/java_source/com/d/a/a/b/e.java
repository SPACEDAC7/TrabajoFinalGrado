/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.MediaCrypto
 */
package com.d.a.a.b;

import android.annotation.TargetApi;
import android.media.MediaCrypto;

@TargetApi(value=16)
public interface e {
    public int a();

    public MediaCrypto b();

    public boolean c();

    public Exception d();
}

