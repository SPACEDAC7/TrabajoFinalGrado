/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.view.Display
 *  android.view.WindowManager
 */
package com.d.a.a;

import android.annotation.TargetApi;
import android.content.Context;
import android.view.Display;
import android.view.WindowManager;
import com.d.a.a.az;

@TargetApi(value=16)
public final class ba {
    final az a;
    final boolean b;
    final long c;
    final long d;
    long e;
    long f;
    long g;
    boolean h;
    long i;
    long j;
    long k;

    public ba() {
        this(-1.0f, false);
    }

    private ba(float f2, boolean bl2) {
        this.b = bl2;
        if (bl2) {
            this.a = az.c;
            this.c = (long)(1.0E9 / (double)f2);
            this.d = this.c * 80 / 100;
            return;
        }
        this.a = null;
        this.c = -1;
        this.d = -1;
    }

    public ba(Context context) {
        this(((WindowManager)context.getSystemService("window")).getDefaultDisplay().getRefreshRate(), true);
    }

    final boolean a(long l2, long l3) {
        long l4 = this.j;
        if (Math.abs(l3 - this.i - (l2 - l4)) > 20000000) {
            return true;
        }
        return false;
    }
}

