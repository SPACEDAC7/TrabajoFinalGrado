/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import java.io.IOException;

public class bb
extends IOException {
    public bb() {
    }

    public bb(String string) {
        super(string);
    }

    public bb(String string, Throwable throwable) {
        super(string, throwable);
    }

    public bb(Throwable throwable) {
        super(throwable);
    }
}

