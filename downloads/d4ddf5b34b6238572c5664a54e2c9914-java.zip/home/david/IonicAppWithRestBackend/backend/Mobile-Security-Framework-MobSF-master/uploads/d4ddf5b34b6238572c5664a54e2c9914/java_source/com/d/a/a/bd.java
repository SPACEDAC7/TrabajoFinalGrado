/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.be;
import java.io.IOException;

final class bd
implements Runnable {
    final /* synthetic */ IOException a;
    final /* synthetic */ be b;

    bd(be be2, IOException iOException) {
        this.b = be2;
        this.a = iOException;
    }

    @Override
    public final void run() {
    }
}

