/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Handler
 *  android.os.SystemClock
 */
package com.d.a.a;

import android.net.Uri;
import android.os.Handler;
import android.os.SystemClock;
import com.d.a.a.a.d;
import com.d.a.a.a.e;
import com.d.a.a.a.g;
import com.d.a.a.a.h;
import com.d.a.a.a.i;
import com.d.a.a.bc;
import com.d.a.a.bd;
import com.d.a.a.q;
import com.d.a.a.w;
import com.d.a.a.x;
import com.d.a.a.y;
import com.d.a.a.z;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;

public final class be
implements d,
e,
w,
x {
    private final Uri a;
    private final h b;
    private final q c;
    private final int d;
    private final Handler e;
    private final bc f;
    private final int g;
    private int h;
    private byte[] i;
    private int j;
    private long k;
    private boolean l;
    private g m;
    private IOException n;
    private int o;
    private long p;

    public be(Uri uri, h h2, q q2) {
        this(uri, h2, q2, 0);
    }

    private be(Uri uri, h h2, q q2, byte by2) {
        this(uri, h2, q2, 3);
    }

    private be(Uri uri, h h2, q q2, int n2) {
        this.a = uri;
        this.b = h2;
        this.c = q2;
        this.d = 3;
        this.e = null;
        this.f = null;
        this.g = 0;
        this.i = new byte[1];
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void k() {
        if (this.l) return;
        if (this.h == 2) return;
        if (this.m.b) {
            return;
        }
        if (this.n != null) {
            if (SystemClock.elapsedRealtime() - this.p < Math.min(((long)this.o - 1) * 1000, 5000)) return;
            this.n = null;
        }
        this.m.a(this, this);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int a(int n2, long l2, y y2, z z2) {
        if (this.h == 2) {
            return -1;
        }
        if (this.h == 0) {
            y2.a = this.c;
            this.h = 1;
            return -4;
        }
        n2 = this.h == 1 ? 1 : 0;
        if (n2 == 0) {
            throw new IllegalStateException();
        }
        if (!this.l) {
            return -2;
        }
        z2.e = 0;
        z2.c = this.j;
        z2.d = 1;
        z2.a(z2.c);
        z2.b.put(this.i, 0, this.j);
        this.h = 2;
        return -3;
    }

    @Override
    public final q a(int n2) {
        return this.c;
    }

    @Override
    public final void a(int n2, long l2) {
        this.h = 0;
        this.k = Long.MIN_VALUE;
        this.n = null;
        this.o = 0;
        this.k();
    }

    @Override
    public final void a(long l2) {
        if (this.h == 2) {
            this.k = l2;
            this.h = 1;
        }
    }

    @Override
    public final void a(d d2) {
        this.l = true;
        this.n = null;
        this.o = 0;
    }

    @Override
    public final void a(d d2, IOException iOException) {
        this.n = iOException;
        ++this.o;
        this.p = SystemClock.elapsedRealtime();
        if (this.e != null && this.f != null) {
            this.e.post((Runnable)new bd(this, iOException));
        }
        this.k();
    }

    @Override
    public final long b(int n2) {
        long l2 = this.k;
        this.k = Long.MIN_VALUE;
        return l2;
    }

    @Override
    public final boolean b() {
        if (this.m == null) {
            this.m = new g("Loader:" + this.c.b);
        }
        return true;
    }

    @Override
    public final boolean b(int n2, long l2) {
        this.k();
        return this.l;
    }

    @Override
    public final void b_() {
        if (this.n != null && this.o > this.d) {
            throw this.n;
        }
    }

    @Override
    public final int c() {
        return 1;
    }

    @Override
    public final void c(int n2) {
        this.h = 2;
    }

    @Override
    public final long d() {
        if (this.l) {
            return -3;
        }
        return 0;
    }

    @Override
    public final void e() {
        if (this.m != null) {
            this.m.b();
            this.m = null;
        }
    }

    @Override
    public final w f() {
        return this;
    }

    @Override
    public final void g() {
    }

    @Override
    public final boolean h() {
        return false;
    }

    @Override
    public final void i() {
        int n2 = 0;
        this.j = 0;
        try {
            this.b.a(new i(this.a));
        }
        catch (Throwable var2_2) {
            this.b.a();
            throw var2_2;
        }
        while (n2 != -1) {
            this.j = n2 + this.j;
            if (this.j == this.i.length) {
                this.i = Arrays.copyOf(this.i, this.i.length * 2);
            }
            n2 = this.b.a(this.i, this.j, this.i.length - this.j);
            continue;
        }
        this.b.a();
        return;
    }

    @Override
    public final void j() {
    }
}

