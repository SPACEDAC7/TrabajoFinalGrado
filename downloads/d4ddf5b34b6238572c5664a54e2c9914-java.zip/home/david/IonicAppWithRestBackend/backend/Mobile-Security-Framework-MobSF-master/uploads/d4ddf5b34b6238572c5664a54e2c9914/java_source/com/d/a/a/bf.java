/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.bh;

public final class bf
implements bh {
    private final long a;
    private final long b;

    public bf(long l2, long l3) {
        this.a = l2;
        this.b = l3;
    }

    @Override
    public final long[] a(long[] arrl) {
        arrl = this.b(arrl);
        arrl[0] = arrl[0] / 1000;
        arrl[1] = arrl[1] / 1000;
        return arrl;
    }

    @Override
    public final long[] b(long[] arrl) {
        long[] arrl2;
        block2 : {
            if (arrl != null) {
                arrl2 = arrl;
                if (arrl.length >= 2) break block2;
            }
            arrl2 = new long[]{this.a, this.b};
        }
        return arrl2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (bf)object;
        if (object.a != this.a) return false;
        if (object.b == this.b) return true;
        return false;
    }

    public final int hashCode() {
        return ((int)this.a + 527) * 31 + (int)this.b;
    }
}

