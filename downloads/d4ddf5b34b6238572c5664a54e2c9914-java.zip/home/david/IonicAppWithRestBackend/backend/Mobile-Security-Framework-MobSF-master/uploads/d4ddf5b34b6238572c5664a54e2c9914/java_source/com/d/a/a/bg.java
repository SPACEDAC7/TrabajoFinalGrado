/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.bh;
import com.d.a.a.d.ae;

public final class bg
implements bh {
    private final long a;
    private final long b;
    private final long c;
    private final long d;
    private final ae e;

    public bg(long l2, long l3, long l4, long l5, ae ae2) {
        this.a = l2;
        this.b = l3;
        this.c = l4;
        this.d = l5;
        this.e = ae2;
    }

    @Override
    public final long[] a(long[] arrl) {
        arrl = this.b(arrl);
        arrl[0] = arrl[0] / 1000;
        arrl[1] = arrl[1] / 1000;
        return arrl;
    }

    @Override
    public final long[] b(long[] arrl) {
        long l2;
        long[] arrl2;
        block3 : {
            if (arrl != null) {
                arrl2 = arrl;
                if (arrl.length >= 2) break block3;
            }
            arrl2 = new long[2];
        }
        long l3 = Math.min(this.b, this.e.a() * 1000 - this.c);
        long l4 = l2 = this.a;
        if (this.d != -1) {
            l4 = Math.max(l2, l3 - this.d);
        }
        arrl2[0] = l4;
        arrl2[1] = l3;
        return arrl2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (bg)object;
        if (object.a != this.a) return false;
        if (object.b != this.b) return false;
        if (object.c != this.c) return false;
        if (object.d == this.d) return true;
        return false;
    }

    public final int hashCode() {
        return ((((int)this.a + 527) * 31 + (int)this.b) * 31 + (int)this.c) * 31 + (int)this.d;
    }
}

