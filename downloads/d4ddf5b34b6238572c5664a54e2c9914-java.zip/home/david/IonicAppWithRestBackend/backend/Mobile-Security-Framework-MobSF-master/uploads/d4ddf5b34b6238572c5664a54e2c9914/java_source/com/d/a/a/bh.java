/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

public interface bh {
    public long[] a(long[] var1);

    public long[] b(long[] var1);
}

