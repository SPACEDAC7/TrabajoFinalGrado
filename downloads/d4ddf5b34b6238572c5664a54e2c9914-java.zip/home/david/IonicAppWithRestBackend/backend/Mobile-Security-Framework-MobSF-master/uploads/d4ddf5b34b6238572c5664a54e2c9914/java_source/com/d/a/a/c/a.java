/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.c;

public final class a
extends Exception {
    public final int a;

    public a(int n2, int n3, int n4, int n5) {
        super("AudioTrack init failed: " + n2 + ", Config(" + n3 + ", " + n4 + ", " + n5 + ")");
        this.a = n2;
    }
}

