/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.c;

public final class b
extends Exception {
    public final int a;

    public b(int n2) {
        super("AudioTrack write failed: " + n2);
        this.a = n2;
    }
}

