/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.c;

public final class c
extends RuntimeException {
    public c(String string) {
        super(string);
    }
}

