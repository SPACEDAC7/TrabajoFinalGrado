/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.AudioTrack
 *  android.os.ConditionVariable
 */
package com.d.a.a.c;

import android.media.AudioTrack;
import android.os.ConditionVariable;
import com.d.a.a.c.i;

final class d
extends Thread {
    final /* synthetic */ AudioTrack a;
    final /* synthetic */ i b;

    d(i i2, AudioTrack audioTrack) {
        this.b = i2;
        this.a = audioTrack;
    }

    @Override
    public final void run() {
        try {
            this.a.flush();
            this.a.release();
            return;
        }
        finally {
            this.b.G.open();
        }
    }
}

