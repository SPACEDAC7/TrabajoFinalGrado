/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.AudioTrack
 */
package com.d.a.a.c;

import android.media.AudioTrack;
import com.d.a.a.c.i;

final class e
extends Thread {
    final /* synthetic */ AudioTrack a;
    final /* synthetic */ i b;

    e(i i2, AudioTrack audioTrack) {
        this.b = i2;
        this.a = audioTrack;
    }

    @Override
    public final void run() {
        this.a.release();
    }
}

