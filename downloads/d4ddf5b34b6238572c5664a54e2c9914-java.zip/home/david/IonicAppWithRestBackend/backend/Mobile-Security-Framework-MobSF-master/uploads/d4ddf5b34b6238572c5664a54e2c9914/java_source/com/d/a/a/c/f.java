/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.AudioTrack
 *  android.media.PlaybackParams
 *  android.os.SystemClock
 */
package com.d.a.a.c;

import android.media.AudioTrack;
import android.media.PlaybackParams;
import android.os.SystemClock;

public class f {
    public AudioTrack a;
    private boolean b;
    private int c;
    private long d;
    private long e;
    private long f;
    public long g;
    public long h;
    public long i;

    public void a(AudioTrack audioTrack, boolean bl2) {
        this.a = audioTrack;
        this.b = bl2;
        this.g = -1;
        this.d = 0;
        this.e = 0;
        this.f = 0;
        if (audioTrack != null) {
            this.c = audioTrack.getSampleRate();
        }
    }

    public void a(PlaybackParams playbackParams) {
        throw new UnsupportedOperationException();
    }

    public final long b() {
        long l2;
        if (this.g != -1) {
            long l3 = (SystemClock.elapsedRealtime() * 1000 - this.g) * (long)this.c / 1000000;
            return Math.min(this.i, l3 + this.h);
        }
        int n2 = this.a.getPlayState();
        if (n2 == 1) {
            return 0;
        }
        long l4 = l2 = 0xFFFFFFFFL & (long)this.a.getPlaybackHeadPosition();
        if (this.b) {
            if (n2 == 2 && l2 == 0) {
                this.f = this.d;
            }
            l4 = l2 + this.f;
        }
        if (this.d > l4) {
            ++this.e;
        }
        this.d = l4;
        return l4 + (this.e << 32);
    }

    public final long c() {
        return this.b() * 1000000 / (long)this.c;
    }

    public boolean d() {
        return false;
    }

    public long e() {
        throw new UnsupportedOperationException();
    }

    public long f() {
        throw new UnsupportedOperationException();
    }

    public float g() {
        return 1.0f;
    }
}

