/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.AudioTimestamp
 *  android.media.AudioTrack
 */
package com.d.a.a.c;

import android.annotation.TargetApi;
import android.media.AudioTimestamp;
import android.media.AudioTrack;
import com.d.a.a.c.f;

@TargetApi(value=19)
class g
extends f {
    private final AudioTimestamp b = new AudioTimestamp();
    private long c;
    private long d;
    private long e;

    @Override
    public void a(AudioTrack audioTrack, boolean bl2) {
        super.a(audioTrack, bl2);
        this.c = 0;
        this.d = 0;
        this.e = 0;
    }

    @Override
    public final boolean d() {
        boolean bl2 = this.a.getTimestamp(this.b);
        if (bl2) {
            long l2 = this.b.framePosition;
            if (this.d > l2) {
                ++this.c;
            }
            this.d = l2;
            this.e = l2 + (this.c << 32);
        }
        return bl2;
    }

    @Override
    public final long e() {
        return this.b.nanoTime;
    }

    @Override
    public final long f() {
        return this.e;
    }
}

