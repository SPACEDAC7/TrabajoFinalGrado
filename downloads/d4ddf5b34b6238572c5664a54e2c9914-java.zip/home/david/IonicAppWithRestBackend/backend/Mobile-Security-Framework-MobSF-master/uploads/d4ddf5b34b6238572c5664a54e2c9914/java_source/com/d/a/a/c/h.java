/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.AudioTrack
 *  android.media.PlaybackParams
 */
package com.d.a.a.c;

import android.annotation.TargetApi;
import android.media.AudioTrack;
import android.media.PlaybackParams;
import com.d.a.a.c.f;
import com.d.a.a.c.g;

@TargetApi(value=23)
final class h
extends g {
    private PlaybackParams b;
    private float c = 1.0f;

    private void h() {
        if (this.a != null && this.b != null) {
            this.a.setPlaybackParams(this.b);
        }
    }

    @Override
    public final void a(AudioTrack audioTrack, boolean bl2) {
        super.a(audioTrack, bl2);
        this.h();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(PlaybackParams playbackParams) {
        if (playbackParams == null) {
            playbackParams = new PlaybackParams();
        }
        this.b = playbackParams = playbackParams.allowDefaults();
        this.c = playbackParams.getSpeed();
        this.h();
    }

    @Override
    public final float g() {
        return this.c;
    }
}

