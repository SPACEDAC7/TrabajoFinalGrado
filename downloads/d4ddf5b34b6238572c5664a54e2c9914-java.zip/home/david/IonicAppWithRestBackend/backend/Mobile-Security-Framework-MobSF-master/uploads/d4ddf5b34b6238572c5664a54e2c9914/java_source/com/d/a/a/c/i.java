/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.media.AudioTrack
 *  android.os.ConditionVariable
 */
package com.d.a.a.c;

import android.annotation.TargetApi;
import android.media.AudioTrack;
import android.os.ConditionVariable;
import com.d.a.a.c.a;
import com.d.a.a.c.d;
import com.d.a.a.c.e;
import com.d.a.a.c.f;
import com.d.a.a.c.g;
import com.d.a.a.c.h;
import com.d.a.a.c.j;
import com.d.a.a.d.ah;
import com.d.a.a.d.x;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

@TargetApi(value=16)
public final class i {
    public static boolean a = false;
    public static boolean b = false;
    public long A;
    public float B;
    public byte[] C;
    public int D;
    public int E;
    private final int F;
    public final ConditionVariable G;
    private AudioTrack H;
    public final j c;
    public final long[] d;
    public final f e;
    public AudioTrack f;
    public int g;
    public int h;
    public int i;
    public boolean j;
    public int k;
    public int l;
    public long m;
    public int n;
    public int o;
    public long p;
    public long q;
    public boolean r;
    public long s;
    public Method t;
    public long u;
    public long v;
    public int w;
    public int x;
    public long y;
    public long z;

    public i() {
        this(null, 3);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public i(j j2, int n2) {
        this.c = j2;
        this.F = n2;
        this.G = new ConditionVariable(true);
        if (ah.a >= 18) {
            try {
                this.t = AudioTrack.class.getMethod("getLatency", null);
            }
            catch (NoSuchMethodException var1_2) {}
        }
        this.e = ah.a >= 23 ? new h() : (ah.a >= 19 ? new g() : new f());
        this.d = new long[10];
        this.B = 1.0f;
        this.x = 0;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int a(int n2, ByteBuffer byteBuffer) {
        if (n2 == 7 || n2 == 8) {
            n2 = byteBuffer.position();
            byte by2 = byteBuffer.get(n2 + 4);
            return (((byteBuffer.get(n2 + 5) & 252) >> 2 | (by2 & 1) << 6) + 1) * 32;
        }
        if (n2 == 5) {
            return 1536;
        }
        if (n2 != 6) throw new IllegalStateException("Unexpected audio encoding: " + n2);
        if ((byteBuffer.get(byteBuffer.position() + 4) & 192) >> 6 == 3) {
            n2 = 6;
            do {
                return n2 * 256;
                break;
            } while (true);
        }
        n2 = x.a[(byteBuffer.get(byteBuffer.position() + 4) & 48) >> 4];
        return n2 * 256;
    }

    @TargetApi(value=21)
    public static int a(AudioTrack audioTrack, ByteBuffer byteBuffer, int n2) {
        return audioTrack.write(byteBuffer, n2, 1);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static int a(String var0) {
        var1_1 = -1;
        switch (var0.hashCode()) {
            case 187078296: {
                if (var0.equals("audio/ac3")) {
                    var1_1 = 0;
                    ** break;
                }
                ** GOTO lbl16
            }
            case 1504578661: {
                if (var0.equals("audio/eac3")) {
                    var1_1 = 1;
                    ** break;
                }
                ** GOTO lbl16
            }
            case -1095064472: {
                if (var0.equals("audio/vnd.dts")) {
                    var1_1 = 2;
                }
            }
lbl16: // 8 sources:
            default: {
                ** GOTO lbl21
            }
            case 1505942594: 
        }
        if (var0.equals("audio/vnd.dts.hd")) {
            var1_1 = 3;
        }
lbl21: // 4 sources:
        switch (var1_1) {
            default: {
                return 0;
            }
            case 0: {
                return 5;
            }
            case 1: {
                return 6;
            }
            case 2: {
                return 7;
            }
            case 3: 
        }
        return 8;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int a(int n2) {
        this.G.block();
        this.f = n2 == 0 ? new AudioTrack(this.F, this.g, this.h, this.i, this.l, 1) : new AudioTrack(this.F, this.g, this.h, this.i, this.l, 1, n2);
        n2 = this.f.getState();
        if (n2 != 1) {
            try {
                this.f.release();
            }
            catch (Exception var2_2) {}
            throw new a(n2, this.g, this.h, this.l);
            throw new a(n2, this.g, this.h, this.l);
            finally {
                this.f = null;
                throw new a(n2, this.g, this.h, this.l);
            }
        }
        n2 = this.f.getAudioSessionId();
        if (a && ah.a < 21) {
            if (this.H != null && n2 != this.H.getAudioSessionId()) {
                this.e();
            }
            if (this.H == null) {
                this.H = new AudioTrack(this.F, 4000, 4, 2, 2, 0, n2);
            }
        }
        this.e.a(this.f, this.h());
        this.c();
        return n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void a() {
        if (this.f == null) return;
        boolean bl2 = true;
        if (!bl2) return;
        this.z = System.nanoTime() / 1000;
        this.f.play();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean b() {
        if (this.f == null) return false;
        boolean bl2 = true;
        if (!bl2) return false;
        if (this.f() > this.e.b()) return true;
        if (!this.h() || this.f.getPlayState() != 2 || this.f.getPlaybackHeadPosition() != 0) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void c() {
        if (this.f == null) return;
        boolean bl2 = true;
        if (!bl2) return;
        if (ah.a >= 21) {
            this.f.setVolume(this.B);
            return;
        }
        AudioTrack audioTrack = this.f;
        float f2 = this.B;
        audioTrack.setStereoVolume(f2, f2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void d() {
        if (this.f == null) return;
        boolean bl2 = true;
        if (!bl2) return;
        this.u = 0;
        this.v = 0;
        this.w = 0;
        this.E = 0;
        this.x = 0;
        this.A = 0;
        this.g();
        if (this.f.getPlayState() == 3) {
            this.f.pause();
        }
        AudioTrack audioTrack = this.f;
        this.f = null;
        this.e.a(null, false);
        this.G.close();
        new d(this, audioTrack).start();
    }

    public final void e() {
        if (this.H == null) {
            return;
        }
        AudioTrack audioTrack = this.H;
        this.H = null;
        new e(this, audioTrack).start();
    }

    public final long f() {
        if (this.j) {
            return this.v;
        }
        return this.u / (long)this.k;
    }

    public final void g() {
        this.p = 0;
        this.o = 0;
        this.n = 0;
        this.q = 0;
        this.r = false;
        this.s = 0;
    }

    public final boolean h() {
        if (ah.a < 23 && (this.i == 5 || this.i == 6)) {
            return true;
        }
        return false;
    }
}

