/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 */
package com.d.a.a.c;

import android.annotation.TargetApi;
import java.util.Arrays;

@TargetApi(value=21)
public final class j {
    public static final j a = new j(new int[]{2});
    public final int[] b;
    private final int c;

    private j(int[] arrn) {
        this.b = Arrays.copyOf(arrn, 1);
        Arrays.sort(this.b);
        this.c = 2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof j)) {
            return false;
        }
        object = (j)object;
        if (!Arrays.equals(this.b, object.b)) return false;
        if (this.c == object.c) return true;
        return false;
    }

    public final int hashCode() {
        return this.c + Arrays.hashCode(this.b) * 31;
    }

    public final String toString() {
        return "AudioCapabilities[maxChannelCount=" + this.c + ", supportedEncodings=" + Arrays.toString(this.b) + "]";
    }
}

