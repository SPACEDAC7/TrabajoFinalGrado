/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.MediaCodec
 *  android.media.MediaCodec$CryptoInfo
 */
package com.d.a.a;

import android.media.MediaCodec;
import com.d.a.a.d.ah;

public final class d {
    public byte[] a;
    public byte[] b;
    public int c;
    public int[] d;
    public int[] e;
    public int f;
    public final MediaCodec.CryptoInfo g;

    /*
     * Enabled aggressive block sorting
     */
    public d() {
        MediaCodec.CryptoInfo cryptoInfo = ah.a >= 16 ? new MediaCodec.CryptoInfo() : null;
        this.g = cryptoInfo;
    }
}

