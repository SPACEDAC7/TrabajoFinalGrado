/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

import com.d.a.a.d.c;
import com.d.a.a.q;

public final class aa {
    private static final int[] a = new int[]{1, 2, 2, 2, 2, 3, 3, 4, 4, 5, 6, 6, 6, 7, 8, 8};
    private static final int[] b = new int[]{-1, 8000, 16000, 32000, -1, -1, 11025, 22050, 44100, -1, -1, 12000, 24000, 48000, -1, -1};
    private static final int[] c = new int[]{64, 112, 128, 192, 224, 256, 384, 448, 512, 640, 768, 896, 1024, 1152, 1280, 1536, 1920, 2048, 2304, 2560, 2688, 2816, 2823, 2944, 3072, 3840, 4096, 6144, 7680};
    private static final c d = new c();

    /*
     * Enabled aggressive block sorting
     */
    public static q a(byte[] arrby) {
        int n2;
        c c2 = d;
        c2.a(arrby, arrby.length);
        c2.b(60);
        int n3 = c2.c(6);
        int n4 = a[n3];
        n3 = c2.c(4);
        int n5 = b[n3];
        n3 = c2.c(5);
        n3 = n3 >= c.length ? -1 : c[n3] * 1000 / 2;
        c2.b(10);
        if (c2.c(2) > 0) {
            n2 = 1;
            return q.a(null, "audio/vnd.dts", n3, -1, -1, n4 + n2, n5, null, null);
        }
        n2 = 0;
        return q.a(null, "audio/vnd.dts", n3, -1, -1, n4 + n2, n5, null, null);
    }
}

