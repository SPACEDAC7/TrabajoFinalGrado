/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

public final class ab {
    public static String a(String string) {
        int n2 = string.indexOf(47);
        if (n2 == -1) {
            throw new IllegalArgumentException("Invalid mime type: " + string);
        }
        return string.substring(0, n2);
    }

    public static String b(String arrstring) {
        if (arrstring == null) {
            return "video/x-unknown";
        }
        arrstring = arrstring.split(",");
        int n2 = arrstring.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            String string = arrstring[i2].trim();
            if (string.startsWith("avc1") || string.startsWith("avc3")) {
                return "video/avc";
            }
            if (string.startsWith("hev1") || string.startsWith("hvc1")) {
                return "video/hevc";
            }
            if (string.startsWith("vp9")) {
                return "video/x-vnd.on2.vp9";
            }
            if (!string.startsWith("vp8")) continue;
            return "video/x-vnd.on2.vp8";
        }
        return "video/x-unknown";
    }
}

