/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.xmlpull.v1.XmlPullParser
 */
package com.d.a.a.d;

import org.xmlpull.v1.XmlPullParser;

public final class ac {
    public static boolean a(XmlPullParser xmlPullParser, String string) {
        if (xmlPullParser.getEventType() == 3 && string.equals(xmlPullParser.getName())) {
            return true;
        }
        return false;
    }

    public static boolean b(XmlPullParser xmlPullParser, String string) {
        if (xmlPullParser.getEventType() == 2 && string.equals(xmlPullParser.getName())) {
            return true;
        }
        return false;
    }
}

