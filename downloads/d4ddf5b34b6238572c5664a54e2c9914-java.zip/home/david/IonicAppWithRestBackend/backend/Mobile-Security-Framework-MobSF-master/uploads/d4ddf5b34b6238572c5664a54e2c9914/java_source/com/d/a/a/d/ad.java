/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.HandlerThread
 *  android.os.Process
 */
package com.d.a.a.d;

import android.os.HandlerThread;
import android.os.Process;

public final class ad
extends HandlerThread {
    private final int a = -16;

    public ad(String string) {
        super(string);
    }

    public final void run() {
        Process.setThreadPriority((int)this.a);
        super.run();
    }
}

