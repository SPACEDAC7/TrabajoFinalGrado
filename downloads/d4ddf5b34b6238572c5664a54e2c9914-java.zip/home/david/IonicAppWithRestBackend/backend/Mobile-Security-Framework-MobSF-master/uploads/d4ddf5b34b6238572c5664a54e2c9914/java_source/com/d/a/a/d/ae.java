/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.SystemClock
 */
package com.d.a.a.d;

import android.os.SystemClock;

public final class ae {
    public final long a() {
        return SystemClock.elapsedRealtime();
    }
}

