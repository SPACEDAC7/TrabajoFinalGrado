/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 */
package com.d.a.a.d;

import android.text.TextUtils;

public final class af {
    /*
     * Enabled aggressive block sorting
     */
    public static String a(String object, String arrn) {
        StringBuilder stringBuilder = new StringBuilder();
        int[] arrn2 = object;
        if (object == null) {
            arrn2 = "";
        }
        object = arrn;
        if (arrn == null) {
            object = "";
        }
        if ((arrn = af.a((String)object))[0] != -1) {
            stringBuilder.append((String)object);
            af.a(stringBuilder, arrn[1], arrn[2]);
            return stringBuilder.toString();
        }
        int[] arrn3 = af.a((String)arrn2);
        if (arrn[3] == 0) {
            return stringBuilder.append((CharSequence)arrn2, 0, arrn3[3]).append((String)object).toString();
        }
        if (arrn[2] == 0) {
            return stringBuilder.append((CharSequence)arrn2, 0, arrn3[2]).append((String)object).toString();
        }
        if (arrn[1] != 0) {
            int n2 = arrn3[0] + 1;
            stringBuilder.append((CharSequence)arrn2, 0, n2).append((String)object);
            return af.a(stringBuilder, arrn[1] + n2, n2 + arrn[2]);
        }
        if (arrn[1] != arrn[2] && object.charAt(arrn[1]) == '/') {
            stringBuilder.append((CharSequence)arrn2, 0, arrn3[1]).append((String)object);
            int n3 = arrn3[1];
            int n4 = arrn3[1];
            return af.a(stringBuilder, n3, arrn[2] + n4);
        }
        if (arrn3[0] + 2 < arrn3[1] && arrn3[1] == arrn3[2]) {
            stringBuilder.append((CharSequence)arrn2, 0, arrn3[1]).append('/').append((String)object);
            int n5 = arrn3[1];
            int n6 = arrn3[1];
            return af.a(stringBuilder, n5, arrn[2] + n6 + 1);
        }
        int n7 = arrn2.lastIndexOf(47, arrn3[2] - 1);
        n7 = n7 == -1 ? arrn3[1] : ++n7;
        stringBuilder.append((CharSequence)arrn2, 0, n7).append((String)object);
        return af.a(stringBuilder, arrn3[1], n7 + arrn[2]);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static String a(StringBuilder var0, int var1_1, int var2_2) {
        if (var1_1 >= var2_2) {
            return var0.toString();
        }
        var3_3 = var1_1;
        if (var0.charAt(var1_1) == '/') {
            var3_3 = var1_1 + 1;
        }
        var1_1 = var3_3;
        var5_4 = var3_3;
        var4_5 = var2_2;
        var2_2 = var5_4;
        while (var1_1 <= var4_5) {
            if (var1_1 != var4_5) ** GOTO lbl14
            var5_4 = var1_1;
            ** GOTO lbl16
lbl14: // 1 sources:
            if (var0.charAt(var1_1) == '/') {
                var5_4 = var1_1 + 1;
lbl16: // 2 sources:
                if (var1_1 == var2_2 + 1 && var0.charAt(var2_2) == '.') {
                    var0.delete(var2_2, var5_4);
                    var4_5 -= var5_4 - var2_2;
                    var1_1 = var2_2;
                    continue;
                }
            } else {
                ++var1_1;
                continue;
            }
            if (var1_1 == var2_2 + 2 && var0.charAt(var2_2) == '.' && var0.charAt(var2_2 + 1) == '.') {
                var1_1 = var0.lastIndexOf("/", var2_2 - 2) + 1;
                var2_2 = var1_1 > var3_3 ? var1_1 : var3_3;
                var0.delete(var2_2, var5_4);
                var5_4 = var4_5 - (var5_4 - var2_2);
                var2_2 = var1_1;
                var4_5 = var1_1;
                var1_1 = var2_2;
                var2_2 = var4_5;
                var4_5 = var5_4;
                continue;
            }
            var2_2 = ++var1_1;
        }
        return var0.toString();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int[] a(String var0) {
        block9 : {
            block8 : {
                var6_1 = new int[4];
                if (TextUtils.isEmpty((CharSequence)var0)) {
                    var6_1[0] = -1;
                    return var6_1;
                }
                var2_2 = var0.length();
                var1_3 = var0.indexOf(35);
                if (var1_3 != -1) {
                    var2_2 = var1_3;
                }
                if ((var3_4 = var0.indexOf(63)) != -1) {
                    var1_3 = var3_4;
                    if (var3_4 <= var2_2) break block8;
                }
                var1_3 = var2_2;
            }
            if ((var4_5 = var0.indexOf(47)) != -1) {
                var3_4 = var4_5;
                if (var4_5 <= var1_3) break block9;
            }
            var3_4 = var1_3;
        }
        var4_5 = var5_6 = var0.indexOf(58);
        if (var5_6 > var3_4) {
            var4_5 = -1;
        }
        var3_4 = var4_5 + 2 < var1_3 && var0.charAt(var4_5 + 1) == '/' && var0.charAt(var4_5 + 2) == '/' ? 1 : 0;
        if (var3_4 == 0) ** GOTO lbl30
        var5_6 = var0.indexOf(47, var4_5 + 3);
        if (var5_6 == -1) ** GOTO lbl-1000
        var3_4 = var5_6;
        if (var5_6 > var1_3) lbl-1000: // 2 sources:
        {
            var3_4 = var1_3;
        }
        ** GOTO lbl31
lbl30: // 1 sources:
        var3_4 = var4_5 + 1;
lbl31: // 2 sources:
        var6_1[0] = var4_5;
        var6_1[1] = var3_4;
        var6_1[2] = var1_3;
        var6_1[3] = var2_2;
        return var6_1;
    }
}

