/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

import java.util.concurrent.ThreadFactory;

public final class ag
implements ThreadFactory {
    final /* synthetic */ String a;

    public ag(String string) {
        this.a = string;
    }

    @Override
    public final Thread newThread(Runnable runnable) {
        return new Thread(runnable, this.a);
    }
}

