/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.TextUtils
 */
package com.d.a.a.d;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import com.d.a.a.a.i;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ah {
    public static final int a;
    public static final String b;
    public static final String c;
    public static final String d;
    private static final Pattern e;
    private static final Pattern f;
    public static final Pattern g;

    /*
     * Enabled aggressive block sorting
     */
    static {
        int n2 = Build.VERSION.SDK_INT == 23 && Build.VERSION.CODENAME.charAt(0) == 'N' ? 24 : Build.VERSION.SDK_INT;
        a = n2;
        b = Build.DEVICE;
        c = Build.MANUFACTURER;
        d = Build.MODEL;
        e = Pattern.compile("(\\d\\d\\d\\d)\\-(\\d\\d)\\-(\\d\\d)[Tt](\\d\\d):(\\d\\d):(\\d\\d)(\\.(\\d+))?([Zz]|((\\+|\\-)(\\d\\d):(\\d\\d)))?");
        f = Pattern.compile("^(-)?P(([0-9]*)Y)?(([0-9]*)M)?(([0-9]*)D)?(T(([0-9]*)H)?(([0-9]*)M)?(([0-9.]*)S)?)?$");
        g = Pattern.compile("%([A-Fa-f0-9]{2})");
    }

    public static int a(int n2, int n3) {
        return (n2 + n3 - 1) / n3;
    }

    public static int a(long l2) {
        return (int)(l2 >>> 32);
    }

    public static int a(long[] arrl, long l2, boolean bl2) {
        int n2;
        int n3 = n2 = Arrays.binarySearch(arrl, l2);
        if (n2 < 0) {
            n3 = - n2 + 2;
        }
        n2 = n3;
        if (bl2) {
            n2 = Math.max(0, n3);
        }
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static int a(long[] arrl, long l2, boolean bl2, boolean bl3) {
        int n2;
        int n3 = Arrays.binarySearch(arrl, l2);
        if (n3 < 0) {
            n2 = ~ n3;
        } else {
            n2 = n3;
            if (!bl2) {
                n2 = n3 + 1;
            }
        }
        n3 = n2;
        if (!bl3) return n3;
        return Math.min(arrl.length - 1, n2);
    }

    public static long a(long l2, long l3, long l4) {
        if (l4 >= l3 && l4 % l3 == 0) {
            return l2 / (l4 / l3);
        }
        if (l4 < l3 && l3 % l4 == 0) {
            return l3 / l4 * l2;
        }
        return (long)((double)l3 / (double)l4 * (double)l2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static i a(i i2, int n2) {
        long l2 = -1;
        if (n2 == 0) {
            return i2;
        }
        if (i2.e == -1) {
            do {
                return new i(i2.a, i2.d + (long)n2, l2, i2.f, i2.g);
                break;
            } while (true);
        }
        l2 = i2.e - (long)n2;
        return new i(i2.a, i2.d + (long)n2, l2, i2.f, i2.g);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String a(Context object, String string) {
        try {
            String string2 = object.getPackageName();
            object = object.getPackageManager().getPackageInfo((String)string2, (int)0).versionName;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            object = "?";
            return string + "/" + (String)object + " (Linux;Android " + Build.VERSION.RELEASE + ") ExoPlayerLib/1.5.7";
        }
        do {
            return string + "/" + (String)object + " (Linux;Android " + Build.VERSION.RELEASE + ") ExoPlayerLib/1.5.7";
            break;
        } while (true);
    }

    public static void a(OutputStream outputStream) {
        try {
            outputStream.close();
            return;
        }
        catch (IOException var0_1) {
            return;
        }
    }

    public static void a(long[] arrl, long l2) {
        int n2;
        int n3 = 0;
        int n4 = 0;
        if (l2 >= 1000000 && l2 % 1000000 == 0) {
            l2 /= 1000000;
            for (n2 = 0; n2 < arrl.length; ++n2) {
                arrl[n2] = arrl[n2] / l2;
            }
        } else if (l2 < 1000000 && 1000000 % l2 == 0) {
            l2 = 1000000 / l2;
            for (n2 = n3; n2 < arrl.length; ++n2) {
                arrl[n2] = arrl[n2] * l2;
            }
        } else {
            double d2 = 1000000.0 / (double)l2;
            for (n2 = n4; n2 < arrl.length; ++n2) {
                arrl[n2] = (long)((double)arrl[n2] * d2);
            }
        }
    }

    public static boolean a(char c2) {
        switch (c2) {
            default: {
                return false;
            }
            case '\"': 
            case '%': 
            case '*': 
            case '/': 
            case ':': 
            case '<': 
            case '>': 
            case '?': 
            case '\\': 
            case '|': 
        }
        return true;
    }

    public static boolean a(Object object, Object object2) {
        if (object == null) {
            if (object2 == null) {
                return true;
            }
            return false;
        }
        return object.equals(object2);
    }

    public static int[] a(List<Integer> list) {
        int n2 = list.size();
        int[] arrn = new int[n2];
        for (int i2 = 0; i2 < n2; ++i2) {
            arrn[i2] = list.get(i2);
        }
        return arrn;
    }

    public static long b(int n2, int n3) {
        return (long)n2 << 32 | (long)n3 & 0xFFFFFFFFL;
    }

    public static String b(String string) {
        if (string == null) {
            return null;
        }
        return string.toLowerCase(Locale.US);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static long c(String string) {
        boolean bl2 = true;
        double d2 = 0.0;
        Matcher matcher = f.matcher(string);
        if (!matcher.matches()) return (long)(Double.parseDouble(string) * 3600.0 * 1000.0);
        if (TextUtils.isEmpty((CharSequence)matcher.group(1))) {
            bl2 = false;
        }
        double d3 = (string = matcher.group(3)) != null ? Double.parseDouble(string) * 3.1556908E7 : 0.0;
        string = matcher.group(5);
        double d4 = string != null ? Double.parseDouble(string) * 2629739.0 : 0.0;
        string = matcher.group(7);
        double d5 = string != null ? Double.parseDouble(string) * 86400.0 : 0.0;
        string = matcher.group(10);
        double d6 = string != null ? Double.parseDouble(string) * 3600.0 : 0.0;
        string = matcher.group(12);
        double d7 = string != null ? Double.parseDouble(string) * 60.0 : 0.0;
        string = matcher.group(14);
        if (string != null) {
            d2 = Double.parseDouble(string);
        }
        long l2 = (long)((d7 + (d4 + d3 + d5 + d6) + d2) * 1000.0);
        if (bl2) {
            return - l2;
        }
        return l2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static long d(String object) {
        long l2;
        int n2;
        Matcher matcher = e.matcher((CharSequence)object);
        if (!matcher.matches()) {
            throw new ParseException("Invalid date/time format: " + (String)object, 0);
        }
        if (matcher.group(9) == null) {
            n2 = 0;
        } else if (matcher.group(9).equalsIgnoreCase("Z")) {
            n2 = 0;
        } else {
            n2 = Integer.parseInt(matcher.group(12)) * 60 + Integer.parseInt(matcher.group(13));
            if (matcher.group(11).equals("-")) {
                n2 *= -1;
            }
        }
        object = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        object.clear();
        object.set(Integer.parseInt(matcher.group(1)), Integer.parseInt(matcher.group(2)) - 1, Integer.parseInt(matcher.group(3)), Integer.parseInt(matcher.group(4)), Integer.parseInt(matcher.group(5)), Integer.parseInt(matcher.group(6)));
        if (!TextUtils.isEmpty((CharSequence)matcher.group(8))) {
            object.set(14, new BigDecimal("0." + matcher.group(8)).movePointRight(3).intValue());
        }
        long l3 = l2 = object.getTimeInMillis();
        if (n2 == 0) return l3;
        return l2 - (long)(60000 * n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static int e(String string) {
        int n2 = 0;
        int n3 = string.length();
        int n4 = n3 <= 4 ? 1 : 0;
        if (n4 == 0) {
            throw new IllegalArgumentException();
        }
        int n5 = 0;
        n4 = n2;
        while (n4 < n3) {
            n5 = n5 << 8 | string.charAt(n4);
            ++n4;
        }
        return n5;
    }
}

