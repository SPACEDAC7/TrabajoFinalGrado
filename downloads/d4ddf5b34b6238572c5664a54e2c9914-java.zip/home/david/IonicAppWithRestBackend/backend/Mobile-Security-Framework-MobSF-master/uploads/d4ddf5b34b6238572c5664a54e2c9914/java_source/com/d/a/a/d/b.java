/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

import java.nio.charset.Charset;

public final class b {
    public byte[] a;
    public int b;
    public int c;

    public b() {
    }

    public b(int n2) {
        this.a = new byte[n2];
        this.c = this.a.length;
    }

    public b(byte[] arrby) {
        this.a = arrby;
        this.c = arrby.length;
    }

    public b(byte[] arrby, int n2) {
        this.a = arrby;
        this.c = n2;
    }

    public final int a() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        return arrby[n2] & 255;
    }

    public final String a(int n2, Charset object) {
        object = new String(this.a, this.b, n2, (Charset)object);
        this.b += n2;
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2) {
        boolean bl2 = n2 >= 0 && n2 <= this.a.length;
        if (!bl2) {
            throw new IllegalArgumentException();
        }
        this.c = n2;
    }

    public final void a(byte[] arrby, int n2, int n3) {
        System.arraycopy(this.a, this.b, arrby, n2, n3);
        this.b += n3;
    }

    public final int b() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        n2 = arrby[n2];
        arrby = this.a;
        int n3 = this.b;
        this.b = n3 + 1;
        return (n2 & 255) << 8 | arrby[n3] & 255;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void b(int n2) {
        boolean bl2 = n2 >= 0 && n2 <= this.c;
        if (!bl2) {
            throw new IllegalArgumentException();
        }
        this.b = n2;
    }

    public final int c() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        n2 = arrby[n2];
        arrby = this.a;
        int n3 = this.b;
        this.b = n3 + 1;
        return n2 & 255 | (arrby[n3] & 255) << 8;
    }

    public final int d() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        n2 = arrby[n2];
        arrby = this.a;
        int n3 = this.b;
        this.b = n3 + 1;
        n3 = arrby[n3];
        arrby = this.a;
        int n4 = this.b;
        this.b = n4 + 1;
        return (n2 & 255) << 16 | (n3 & 255) << 8 | arrby[n4] & 255;
    }

    public final long e() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        long l2 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l3 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l4 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        return (l2 & 255) << 24 | (l3 & 255) << 16 | (l4 & 255) << 8 | (long)arrby[n2] & 255;
    }

    public final long f() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        long l2 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l3 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l4 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        return l2 & 255 | (l3 & 255) << 8 | (l4 & 255) << 16 | ((long)arrby[n2] & 255) << 24;
    }

    public final int g() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        n2 = arrby[n2];
        arrby = this.a;
        int n3 = this.b;
        this.b = n3 + 1;
        n3 = arrby[n3];
        arrby = this.a;
        int n4 = this.b;
        this.b = n4 + 1;
        n4 = arrby[n4];
        arrby = this.a;
        int n5 = this.b;
        this.b = n5 + 1;
        return (n2 & 255) << 24 | (n3 & 255) << 16 | (n4 & 255) << 8 | arrby[n5] & 255;
    }

    public final int h() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        n2 = arrby[n2];
        arrby = this.a;
        int n3 = this.b;
        this.b = n3 + 1;
        n3 = arrby[n3];
        arrby = this.a;
        int n4 = this.b;
        this.b = n4 + 1;
        n4 = arrby[n4];
        arrby = this.a;
        int n5 = this.b;
        this.b = n5 + 1;
        return n2 & 255 | (n3 & 255) << 8 | (n4 & 255) << 16 | (arrby[n5] & 255) << 24;
    }

    public final long i() {
        byte[] arrby = this.a;
        int n2 = this.b;
        this.b = n2 + 1;
        long l2 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l3 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l4 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l5 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l6 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l7 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        long l8 = arrby[n2];
        arrby = this.a;
        n2 = this.b;
        this.b = n2 + 1;
        return (l2 & 255) << 56 | (l3 & 255) << 48 | (l4 & 255) << 40 | (l5 & 255) << 32 | (l6 & 255) << 24 | (l7 & 255) << 16 | (l8 & 255) << 8 | (long)arrby[n2] & 255;
    }

    public final int j() {
        return this.a() << 21 | this.a() << 14 | this.a() << 7 | this.a();
    }

    public final int k() {
        int n2 = this.g();
        if (n2 < 0) {
            throw new IllegalStateException("Top bit not zero: " + n2);
        }
        return n2;
    }

    public final int l() {
        int n2 = this.h();
        if (n2 < 0) {
            throw new IllegalStateException("Top bit not zero: " + n2);
        }
        return n2;
    }

    public final long m() {
        long l2 = this.i();
        if (l2 < 0) {
            throw new IllegalStateException("Top bit not zero: " + l2);
        }
        return l2;
    }

    public final String n() {
        int n2;
        if (this.c - this.b == 0) {
            return null;
        }
        for (n2 = this.b; n2 < this.c && this.a[n2] != 10 && this.a[n2] != 13; ++n2) {
        }
        if (n2 - this.b >= 3 && this.a[this.b] == -17 && this.a[this.b + 1] == -69 && this.a[this.b + 2] == -65) {
            this.b += 3;
        }
        String string = new String(this.a, this.b, n2 - this.b);
        this.b = n2;
        if (this.b == this.c) {
            return string;
        }
        if (this.a[this.b] == 13) {
            ++this.b;
            if (this.b == this.c) {
                return string;
            }
        }
        if (this.a[this.b] == 10) {
            ++this.b;
        }
        return string;
    }
}

