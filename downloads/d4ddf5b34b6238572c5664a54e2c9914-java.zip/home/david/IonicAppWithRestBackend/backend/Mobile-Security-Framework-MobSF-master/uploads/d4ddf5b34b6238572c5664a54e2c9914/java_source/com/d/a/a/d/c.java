/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

public final class c {
    public byte[] a;
    private int b;
    private int c;
    private int d;

    public c() {
    }

    public c(byte[] arrby) {
        this(arrby, arrby.length);
    }

    public c(byte[] arrby, int n2) {
        this.a = arrby;
        this.d = n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void f() {
        if (this.b >= 0 && this.c >= 0 && this.c < 8 && (this.b < this.d || this.b == this.d && this.c == 0)) {
            return;
        }
        boolean bl2 = false;
        if (!bl2) {
            throw new IllegalStateException();
        }
    }

    public final int a() {
        return (this.d - this.b) * 8 - this.c;
    }

    public final void a(int n2) {
        this.b = n2 / 8;
        this.c = n2 - this.b * 8;
        this.f();
    }

    public final void a(byte[] arrby, int n2) {
        this.a = arrby;
        this.b = 0;
        this.c = 0;
        this.d = n2;
    }

    public final void b(int n2) {
        this.b += n2 / 8;
        this.c += n2 % 8;
        if (this.c > 7) {
            ++this.b;
            this.c -= 8;
        }
        this.f();
    }

    public final boolean b() {
        if (this.c(1) == 1) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int c(int n2) {
        int n3;
        if (n2 == 0) {
            return 0;
        }
        int n4 = n2 / 8;
        int n5 = 0;
        int n6 = n2;
        n2 = n5;
        for (n3 = 0; n3 < n4; n2 |= (n5 & 255) << (n6 -= 8), ++this.b, ++n3) {
            n5 = this.c != 0 ? (this.a[this.b] & 255) << this.c | (this.a[this.b + 1] & 255) >>> 8 - this.c : this.a[this.b];
        }
        if (n6 > 0) {
            n5 = this.c + n6;
            n3 = (byte)(255 >> 8 - n6);
            if (n5 > 8) {
                n2 = n3 & ((this.a[this.b] & 255) << n5 - 8 | (this.a[this.b + 1] & 255) >> 16 - n5) | n2;
                ++this.b;
            } else {
                n2 = n3 = n3 & (this.a[this.b] & 255) >> 8 - n5 | n2;
                if (n5 == 8) {
                    ++this.b;
                    n2 = n3;
                }
            }
            this.c = n5 % 8;
        }
        this.f();
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean c() {
        boolean bl2;
        int n2 = this.b;
        int n3 = this.c;
        int n4 = 0;
        while (this.b < this.d && !(bl2 = this.c(1) == 1)) {
            ++n4;
        }
        bl2 = this.b == this.d;
        this.b = n2;
        this.c = n3;
        if (!bl2 && this.a() >= n4 * 2 + 1) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final int d() {
        int n2;
        int n3 = this.e();
        if (n3 % 2 == 0) {
            n2 = -1;
            do {
                return n2 * ((n3 + 1) / 2);
                break;
            } while (true);
        }
        n2 = 1;
        return n2 * ((n3 + 1) / 2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int e() {
        int n2;
        int n3 = 0;
        int n4 = 0;
        while ((n2 = this.c(1) == 1 ? 1 : 0) == 0) {
            ++n4;
        }
        n2 = n3;
        if (n4 > 0) {
            n2 = this.c(n4);
        }
        return (1 << n4) - 1 + n2;
    }
}

