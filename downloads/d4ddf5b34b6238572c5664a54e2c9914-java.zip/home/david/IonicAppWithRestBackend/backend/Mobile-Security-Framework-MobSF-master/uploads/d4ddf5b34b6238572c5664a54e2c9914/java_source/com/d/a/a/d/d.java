/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

import java.io.IOException;

public final class d
extends IOException {
    public d(Throwable throwable) {
        super(throwable);
    }
}

