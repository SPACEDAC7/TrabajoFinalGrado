/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

import java.io.IOException;

public interface f<T> {
    public void a(T var1);

    public void b(IOException var1);
}

