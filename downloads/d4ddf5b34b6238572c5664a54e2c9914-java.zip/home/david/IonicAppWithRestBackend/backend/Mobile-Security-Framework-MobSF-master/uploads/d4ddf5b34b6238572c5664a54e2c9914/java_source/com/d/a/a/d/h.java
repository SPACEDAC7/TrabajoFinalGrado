/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.d.a.a.d;

import android.net.Uri;
import com.d.a.a.d.m;
import com.facebook.exoplayer.b.j;
import com.facebook.exoplayer.ipc.VpsManifestMisalignedEvent;
import com.facebook.exoplayer.o;

final class h
implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ String b;
    final /* synthetic */ m c;

    h(m m2, String string, String string2) {
        this.c = m2;
        this.a = string;
        this.b = string2;
    }

    @Override
    public final void run() {
        o o2 = this.c.d;
        String string = this.a;
        String string2 = this.b;
        String.format("Manifest misalign happened: %s, expectedSegmentInfo=%s, actualSegmentInfo=%s", o2.m.toString(), string, string2);
        if (o2.x != null) {
            com.facebook.exoplayer.ipc.m m2 = com.facebook.exoplayer.ipc.m.c;
            new VpsManifestMisalignedEvent(o2.o, o2.m.toString(), string, string2);
        }
    }
}

