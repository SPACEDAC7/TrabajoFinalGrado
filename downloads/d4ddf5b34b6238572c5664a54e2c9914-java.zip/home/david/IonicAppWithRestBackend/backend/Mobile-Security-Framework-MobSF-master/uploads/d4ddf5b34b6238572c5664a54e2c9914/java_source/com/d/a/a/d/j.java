/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.d.a.a.d;

import android.net.Uri;
import com.d.a.a.d.m;
import com.d.a.a.g.a.a;
import com.facebook.exoplayer.o;

final class j
implements Runnable {
    final /* synthetic */ m a;

    j(m m2) {
        this.a = m2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void run() {
        o o2 = this.a.d;
        String string = o2.c.m == null ? "Not available" : String.valueOf(((a)o2.c.m).e);
        String.format("Manifest refresh completed, vid=%s, uri=%s, dynamic=%s", new Object[]{o2.o, o2.m, string});
    }
}

