/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.d.a.a.d;

import android.net.Uri;
import com.d.a.a.d.m;
import com.facebook.exoplayer.b.b;
import com.facebook.exoplayer.o;
import java.io.IOException;

final class k
implements Runnable {
    final /* synthetic */ IOException a;
    final /* synthetic */ m b;

    k(m m2, IOException iOException) {
        this.b = m2;
        this.a = iOException;
    }

    @Override
    public final void run() {
        o o2 = this.b.d;
        IOException iOException = this.a;
        String.format("Manifest refresh error: %s, vid=%s, uri=%s", new Object[]{iOException.getMessage(), o2.o, o2.m});
        o2.j.a(iOException);
    }
}

