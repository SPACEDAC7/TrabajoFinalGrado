/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Looper
 *  android.os.SystemClock
 */
package com.d.a.a.d;

import android.os.Looper;
import android.os.SystemClock;
import com.d.a.a.a.e;
import com.d.a.a.a.g;
import com.d.a.a.a.k;
import com.d.a.a.d.d;
import com.d.a.a.d.f;
import com.d.a.a.d.m;
import java.io.IOException;
import java.util.concurrent.CancellationException;

final class l
implements e {
    final k<T> a;
    final Looper b;
    final g c;
    long d;
    final /* synthetic */ m e;
    private final f<T> f;

    public l(k<T> var1_1, Looper k2, f<T> looper) {
        this.e = var1_1;
        this.a = k2;
        this.b = looper;
        this.f = f2;
        this.c = new g("manifestLoader:single");
    }

    @Override
    public final void a(com.d.a.a.a.d d2) {
        try {
            d2 = this.a.a;
            m m2 = this.e;
            long l2 = this.d;
            m2.m = d2;
            m2.n = l2;
            m2.o = SystemClock.elapsedRealtime();
            this.f.a(d2);
            return;
        }
        finally {
            this.c.b();
        }
    }

    @Override
    public final void a(com.d.a.a.a.d d2, IOException iOException) {
        try {
            this.f.b(iOException);
            return;
        }
        finally {
            this.c.b();
        }
    }

    @Override
    public final void j() {
        try {
            d d2 = new d(new CancellationException());
            this.f.b(d2);
            return;
        }
        finally {
            this.c.b();
        }
    }
}

