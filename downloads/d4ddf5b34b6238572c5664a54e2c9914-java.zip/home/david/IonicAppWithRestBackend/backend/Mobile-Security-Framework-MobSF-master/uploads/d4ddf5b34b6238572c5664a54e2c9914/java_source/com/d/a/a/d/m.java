/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.SystemClock
 *  android.text.TextUtils
 *  com.d.a.a.d.e
 */
package com.d.a.a.d;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import com.d.a.a.a.g;
import com.d.a.a.d.d;
import com.d.a.a.d.e;
import com.d.a.a.d.f;
import com.d.a.a.d.h;
import com.d.a.a.d.j;
import com.d.a.a.d.k;
import com.d.a.a.d.l;
import com.d.a.a.g.a.a;
import com.facebook.exoplayer.o;
import java.io.IOException;

public final class m<T>
implements com.d.a.a.a.e {
    public final com.d.a.a.a.j<T> a;
    public final com.d.a.a.a.l b;
    public final Handler c;
    public final o d;
    public volatile String e;
    public int f;
    public g g;
    public com.d.a.a.a.k<T> h;
    public long i;
    public int j;
    public long k;
    public d l;
    public volatile T m;
    public volatile long n;
    volatile long o;

    public m(String string, com.d.a.a.a.l l2, com.d.a.a.a.j<T> j2) {
        this(string, l2, j2, 0);
    }

    private m(String string, com.d.a.a.a.l l2, com.d.a.a.a.j<T> j2, byte by2) {
        this.a = j2;
        this.e = string;
        this.b = l2;
        this.c = null;
        this.d = null;
    }

    public m(String string, com.d.a.a.a.l l2, com.d.a.a.a.j<T> j2, Handler handler, e e2, T t2) {
        this.a = j2;
        this.e = string;
        this.b = l2;
        this.c = handler;
        this.d = e2;
        this.m = t2;
    }

    public final void a(Looper object, f<T> f2) {
        object = new l(this, new com.d.a.a.a.k<T>(this.e, this.b, this.a), (Looper)object, f2);
        object.d = SystemClock.elapsedRealtime();
        object.c.a(object.b, object.a, (com.d.a.a.a.e)object);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(com.d.a.a.a.d object) {
        if (this.h != object) {
            return;
        }
        this.m = this.h.a;
        this.n = this.i;
        this.o = SystemClock.elapsedRealtime();
        this.j = 0;
        this.l = null;
        if (this.m instanceof a && !TextUtils.isEmpty((CharSequence)(object = ((a)this.m).i))) {
            this.e = object;
        }
        if (this.c == null) return;
        if (this.d == null) return;
        this.c.post((Runnable)new j(this));
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(com.d.a.a.a.d object, IOException iOException) {
        if (this.h != object) {
            return;
        }
        ++this.j;
        this.k = SystemClock.elapsedRealtime();
        object = this.l = new d(iOException);
        if (this.c == null) return;
        if (this.d == null) return;
        this.c.post((Runnable)new k(this, (IOException)object));
    }

    public final void a(String string, String string2) {
        if (this.c != null && this.d != null) {
            this.c.post((Runnable)new h(this, string, string2));
        }
    }

    @Override
    public final void j() {
    }
}

