/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

public final class n {
    private static final String[] h = new String[]{"audio/mpeg-L1", "audio/mpeg-L2", "audio/mpeg"};
    private static final int[] i = new int[]{44100, 48000, 32000};
    private static final int[] j = new int[]{32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448};
    private static final int[] k = new int[]{32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256};
    private static final int[] l = new int[]{32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384};
    private static final int[] m = new int[]{32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320};
    private static final int[] n = new int[]{8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160};
    public int a;
    public String b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;

    /*
     * Enabled aggressive block sorting
     */
    public static int a(int n2) {
        if ((n2 & -2097152) != -2097152) {
            return -1;
        }
        int n3 = n2 >>> 19 & 3;
        if (n3 == 1) return -1;
        int n4 = n2 >>> 17 & 3;
        if (n4 == 0) return -1;
        int n5 = n2 >>> 12 & 15;
        if (n5 == 0) return -1;
        if (n5 == 15) return -1;
        int n6 = n2 >>> 10 & 3;
        if (n6 == 3) return -1;
        n6 = i[n6];
        if (n3 == 2) {
            n6 /= 2;
        } else if (n3 == 0) {
            n6 /= 4;
        }
        int n7 = n2 >>> 9 & 1;
        if (n4 == 3) {
            if (n3 == 3) {
                n2 = j[n5 - 1];
                return (n2 * 12000 / n6 + n7) * 4;
            }
            n2 = k[n5 - 1];
            return (n2 * 12000 / n6 + n7) * 4;
        }
        n2 = n3 == 3 ? (n4 == 2 ? l[n5 - 1] : m[n5 - 1]) : n[n5 - 1];
        if (n3 == 3) {
            return 144000 * n2 / n6 + n7;
        }
        if (n4 == 1) {
            n3 = 72000;
            return n3 * n2 / n6 + n7;
        }
        n3 = 144000;
        return n3 * n2 / n6 + n7;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static boolean a(int var0, n var1_1) {
        var7_2 = 2;
        if ((var0 & -2097152) != -2097152) {
            return false;
        }
        var8_3 = var0 >>> 19 & 3;
        if (var8_3 == 1) {
            return false;
        }
        var9_4 = var0 >>> 17 & 3;
        if (var9_4 == 0) {
            return false;
        }
        var2_5 = var0 >>> 12 & 15;
        if (var2_5 == 0) return false;
        if (var2_5 == 15) {
            return false;
        }
        var3_6 = var0 >>> 10 & 3;
        if (var3_6 == 3) {
            return false;
        }
        var3_6 = n.i[var3_6];
        if (var8_3 == 2) {
            var3_6 /= 2;
        } else if (var8_3 == 0) {
            var3_6 /= 4;
        }
        var10_7 = var0 >>> 9 & 1;
        if (var9_4 != 3) ** GOTO lbl30
        var2_5 = var8_3 == 3 ? n.j[var2_5 - 1] : n.k[var2_5 - 1];
        var5_8 = var2_5 * 12000 / var3_6;
        var4_9 = 384;
        var5_8 = (var5_8 + var10_7) * 4;
        ** GOTO lbl47
lbl30: // 1 sources:
        if (var8_3 != 3) ** GOTO lbl35
        var2_5 = var9_4 == 2 ? n.l[var2_5 - 1] : n.m[var2_5 - 1];
        var4_9 = 1152;
        var5_8 = var2_5;
        ** GOTO lbl-1000
lbl35: // 1 sources:
        var6_10 = n.n[var2_5 - 1];
        var2_5 = var9_4 == 1 ? 576 : 1152;
        var4_9 = var2_5;
        var5_8 = var6_10;
        if (var9_4 == 1) {
            var5_8 = 72000;
            var4_9 = var2_5;
            var2_5 = var6_10;
        } else lbl-1000: // 2 sources:
        {
            var2_5 = var5_8;
            var5_8 = 144000;
        }
        var5_8 = var5_8 * var2_5 / var3_6 + var10_7;
lbl47: // 2 sources:
        var11_11 = n.h[3 - var9_4];
        var6_10 = var7_2;
        if ((var0 >> 6 & 3) == 3) {
            var6_10 = 1;
        }
        var1_1.a = var8_3;
        var1_1.b = var11_11;
        var1_1.c = var5_8;
        var1_1.d = var3_6;
        var1_1.e = var6_10;
        var1_1.f = var2_5 * 1000;
        var1_1.g = var4_9;
        return true;
    }
}

