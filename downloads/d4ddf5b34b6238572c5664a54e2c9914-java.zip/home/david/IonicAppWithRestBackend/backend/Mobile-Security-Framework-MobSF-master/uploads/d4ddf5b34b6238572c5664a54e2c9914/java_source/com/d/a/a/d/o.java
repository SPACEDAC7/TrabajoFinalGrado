/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

public final class o {
    public final int a;
    public final int b;
    public final int c;
    public final float d;
    public final boolean e;
    public final boolean f;
    public final int g;
    public final int h;
    public final int i;
    public final boolean j;

    public o(int n2, int n3, int n4, float f2, boolean bl2, boolean bl3, int n5, int n6, int n7, boolean bl4) {
        this.a = n2;
        this.b = n3;
        this.c = n4;
        this.d = f2;
        this.e = bl2;
        this.f = bl3;
        this.g = n5;
        this.h = n6;
        this.i = n7;
        this.j = bl4;
    }
}

