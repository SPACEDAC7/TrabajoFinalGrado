/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

public final class p {
    public final int a;
    public final int b;
    public final boolean c;

    public p(int n2, int n3, boolean bl2) {
        this.a = n2;
        this.b = n3;
        this.c = bl2;
    }
}

