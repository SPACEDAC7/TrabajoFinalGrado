/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.d.a.a.d;

import android.util.Log;
import com.d.a.a.d.b;
import com.d.a.a.d.c;
import com.d.a.a.d.o;
import com.d.a.a.d.p;
import com.d.a.a.d.z;
import java.util.Arrays;

public final class q {
    public static final byte[] a = new byte[]{0, 0, 0, 1};
    public static final float[] b = new float[]{1.0f, 1.0f, 1.0909091f, 0.90909094f, 1.4545455f, 1.2121212f, 2.1818182f, 1.8181819f, 2.909091f, 2.4242425f, 1.6363636f, 1.3636364f, 1.939394f, 1.6161616f, 1.3333334f, 1.5f, 2.0f};
    private static final Object c = new Object();
    private static int[] d = new int[10];

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static int a(byte[] arrby, int n2) {
        int n3 = 0;
        Object object = c;
        synchronized (object) {
            int n4 = 0;
            int n5 = 0;
            do {
                int n6;
                block11 : {
                    if (n5 >= n2) {
                        int n7 = n2 - n4;
                        n6 = 0;
                        n5 = 0;
                        n2 = n3;
                        do {
                            if (n2 >= n4) {
                                System.arraycopy(arrby, n5, arrby, n6, n7 - n6);
                                return n7;
                            }
                            n3 = d[n2] - n5;
                            System.arraycopy(arrby, n5, arrby, n6, n3);
                            int n8 = (n6 += n3) + 1;
                            arrby[n6] = 0;
                            n6 = n8 + 1;
                            arrby[n8] = 0;
                            n5 += n3 + 3;
                            ++n2;
                        } while (true);
                    }
                    while (n5 < n2 - 2) {
                        if (arrby[n5] == 0 && arrby[n5 + 1] == 0 && arrby[n5 + 2] == 3) {
                            n6 = n5;
                            break block11;
                        }
                        ++n5;
                    }
                    n6 = n2;
                }
                n5 = n6;
                if (n6 >= n2) continue;
                if (d.length <= n4) {
                    d = Arrays.copyOf(d, d.length * 2);
                }
                q.d[n4] = n6;
                n5 = n6 + 3;
                ++n4;
            } while (true);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static int a(byte[] arrby, int n2, int n3, boolean[] arrbl) {
        boolean bl2 = true;
        int n4 = n3 - n2;
        int n5 = n4 >= 0 ? 1 : 0;
        if (n5 == 0) {
            throw new IllegalStateException();
        }
        if (n4 == 0) {
            return n3;
        }
        if (arrbl != null) {
            if (arrbl[0]) {
                arrbl[0] = false;
                arrbl[1] = false;
                arrbl[2] = false;
                return n2 - 3;
            }
            if (n4 > 1 && arrbl[1] && arrby[n2] == 1) {
                arrbl[0] = false;
                arrbl[1] = false;
                arrbl[2] = false;
                return n2 - 2;
            }
            if (n4 > 2 && arrbl[2] && arrby[n2] == 0 && arrby[n2 + 1] == 1) {
                arrbl[0] = false;
                arrbl[1] = false;
                arrbl[2] = false;
                return n2 - 1;
            }
        }
        n2 += 2;
        while (n2 < n3 - 1) {
            n5 = n2;
            if ((arrby[n2] & 254) == 0) {
                if (arrby[n2 - 2] == 0 && arrby[n2 - 1] == 0 && arrby[n2] == 1) {
                    if (arrbl == null) return n2 - 2;
                    arrbl[0] = false;
                    arrbl[1] = false;
                    arrbl[2] = false;
                    return n2 - 2;
                }
                n5 = n2 - 2;
            }
            n2 = n5 + 3;
        }
        if (arrbl == null) return n3;
        boolean bl3 = n4 > 2 ? arrby[n3 - 3] == 0 && arrby[n3 - 2] == 0 && arrby[n3 - 1] == 1 : (n4 == 2 ? arrbl[2] && arrby[n3 - 2] == 0 && arrby[n3 - 1] == 1 : arrbl[1] && arrby[n3 - 1] == 1);
        arrbl[0] = bl3;
        bl3 = n4 > 1 ? arrby[n3 - 2] == 0 && arrby[n3 - 1] == 0 : arrbl[2] && arrby[n3 - 1] == 0;
        arrbl[1] = bl3;
        bl3 = arrby[n3 - 1] == 0 ? bl2 : false;
        arrbl[2] = bl3;
        return n3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static o a(c var0) {
        var3_1 = var0.c(8);
        var0.b(16);
        var11_2 = var0.e();
        var16_3 = false;
        if (var3_1 != 100 && var3_1 != 110 && var3_1 != 122 && var3_1 != 244 && var3_1 != 44 && var3_1 != 83 && var3_1 != 86 && var3_1 != 118 && var3_1 != 128 && var3_1 != 138) ** GOTO lbl16
        var10_4 = var0.e();
        if (var10_4 == 3) {
            var16_3 = var0.c(1) == 1;
        }
        var0.e();
        var0.e();
        var0.b(1);
        var3_1 = var0.c(1) == 1 ? 1 : 0;
        if (var3_1 == 0) ** GOTO lbl34
        var4_5 = var10_4 != 3 ? 8 : 12;
        ** GOTO lbl19
lbl16: // 1 sources:
        var17_11 = false;
        var5_6 = 1;
        ** GOTO lbl36
lbl19: // 3 sources:
        for (var5_6 = 0; var5_6 < var4_5; ++var5_6) {
            var3_1 = var0.c(1) == 1 ? 1 : 0;
            if (var3_1 == 0) continue;
            var6_7 = var5_6 < 6 ? 16 : 64;
            var9_10 = 8;
            var8_9 = 8;
            for (var7_8 = 0; var7_8 < var6_7; ++var7_8) {
                var3_1 = var9_10;
                if (var9_10 != 0) {
                    var3_1 = (var0.d() + var8_9 + 256) % 256;
                }
                if (var3_1 != 0) {
                    var8_9 = var3_1;
                }
                var9_10 = var3_1;
            }
        }
lbl34: // 2 sources:
        var5_6 = var10_4;
        var17_11 = var16_3;
lbl36: // 2 sources:
        var9_10 = var0.e();
        var10_4 = var0.e();
        var6_7 = 0;
        var16_3 = false;
        if (var10_4 == 0) {
            var4_5 = var0.e() + 4;
        } else {
            var4_5 = var6_7;
            if (var10_4 == 1) {
                var16_3 = var0.c(1) == 1;
                var0.d();
                var0.d();
                var19_19 = var0.e();
                var3_1 = 0;
                while ((long)var3_1 < var19_19) {
                    var0.e();
                    ++var3_1;
                }
                var4_5 = var6_7;
            }
        }
        var0.e();
        var0.b(1);
        var7_8 = var0.e();
        var6_7 = var0.e();
        var18_12 = var0.c(1) == 1;
        var3_1 = var18_12 != false ? 1 : 0;
        if (!var18_12) {
            var0.b(1);
        }
        var0.b(1);
        var8_9 = (var7_8 + 1) * 16;
        var7_8 = (2 - var3_1) * (var6_7 + 1) * 16;
        var3_1 = var0.c(1) == 1 ? 1 : 0;
        if (var3_1 != 0) {
            var14_13 = var0.e();
            var15_14 = var0.e();
            var12_15 = var0.e();
            var13_16 = var0.e();
            if (var5_6 == 0) {
                var5_6 = 1;
                var3_1 = var18_12 != false ? 1 : 0;
                var6_7 = 2 - var3_1;
                var3_1 = var5_6;
                var5_6 = var6_7;
            } else {
                var3_1 = var5_6 == 3 ? 1 : 2;
                var5_6 = var5_6 == 1 ? 2 : 1;
                var6_7 = var18_12 != false ? 1 : 0;
                var5_6 = (2 - var6_7) * var5_6;
            }
            var3_1 = var8_9 - var3_1 * (var14_13 + var15_14);
            var5_6 = var7_8 - var5_6 * (var12_15 + var13_16);
        } else {
            var3_1 = var8_9;
            var5_6 = var7_8;
        }
        var2_17 = 1.0f;
        var6_7 = var0.c(1) == 1 ? 1 : 0;
        if (var6_7 != 0) {
            var6_7 = var0.c(1) == 1 ? 1 : 0;
            if (var6_7 != 0) {
                var6_7 = var0.c(8);
                if (var6_7 == 255) {
                    var6_7 = var0.c(16);
                    var7_8 = var0.c(16);
                    var1_18 = var2_17;
                    if (var6_7 == 0) return new o(var11_2, var3_1, var5_6, var1_18, var17_11, var18_12, var9_10 + 4, var10_4, var4_5, var16_3);
                    var1_18 = var2_17;
                    if (var7_8 == 0) return new o(var11_2, var3_1, var5_6, var1_18, var17_11, var18_12, var9_10 + 4, var10_4, var4_5, var16_3);
                    var1_18 = (float)var6_7 / (float)var7_8;
                    return new o(var11_2, var3_1, var5_6, var1_18, var17_11, var18_12, var9_10 + 4, var10_4, var4_5, var16_3);
                }
                if (var6_7 < q.b.length) {
                    var1_18 = q.b[var6_7];
                    return new o(var11_2, var3_1, var5_6, var1_18, var17_11, var18_12, var9_10 + 4, var10_4, var4_5, var16_3);
                }
                Log.w((String)"NalUnitUtil", (String)("Unexpected aspect_ratio_idc value: " + var6_7));
            }
        }
        var1_18 = 1.0f;
        return new o(var11_2, var3_1, var5_6, var1_18, var17_11, var18_12, var9_10 + 4, var10_4, var4_5, var16_3);
    }

    public static void a(boolean[] arrbl) {
        arrbl[0] = false;
        arrbl[1] = false;
        arrbl[2] = false;
    }

    public static byte[] a(b arrby) {
        int n2 = arrby.b();
        int n3 = arrby.b;
        arrby.b(arrby.b + n2);
        arrby = arrby.a;
        byte[] arrby2 = new byte[z.a.length + n2];
        System.arraycopy(z.a, 0, arrby2, 0, z.a.length);
        System.arraycopy(arrby, n3, arrby2, z.a.length, n2);
        return arrby2;
    }

    public static int b(byte[] arrby, int n2) {
        return arrby[n2 + 3] & 31;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static p b(c c2) {
        boolean bl2 = true;
        int n2 = c2.e();
        int n3 = c2.e();
        c2.b(1);
        if (c2.c(1) == 1) {
            do {
                return new p(n2, n3, bl2);
                break;
            } while (true);
        }
        bl2 = false;
        return new p(n2, n3, bl2);
    }

    public static int c(byte[] arrby, int n2) {
        return (arrby[n2 + 3] & 126) >> 1;
    }
}

