/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

final class v {
    public int a;
    public int b;
    public float c;
}

