/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

import com.d.a.a.d.t;
import com.d.a.a.d.u;
import com.d.a.a.d.v;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public final class w {
    private static final Comparator<v> a = new t();
    private static final Comparator<v> b = new u();
    private final int c;
    private final ArrayList<v> d;
    private final v[] e;
    private int f;
    private int g;
    private int h;
    private int i;

    public w(int n2) {
        this.c = n2;
        this.e = new v[5];
        this.d = new ArrayList();
        this.f = -1;
    }

    public final float a() {
        if (this.f != 0) {
            Collections.sort(this.d, b);
            this.f = 0;
        }
        float f2 = this.h;
        int n2 = 0;
        for (int i2 = 0; i2 < this.d.size(); ++i2) {
            v v2 = this.d.get(i2);
            if ((float)(n2 += v2.b) < 0.5f * f2) continue;
            return v2.c;
        }
        if (this.d.isEmpty()) {
            return Float.NaN;
        }
        return this.d.get((int)(this.d.size() - 1)).c;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2, float f2) {
        Object object;
        int n3;
        if (this.f != 1) {
            Collections.sort(this.d, a);
            this.f = 1;
        }
        if (this.i > 0) {
            object = this.e;
            this.i = n3 = this.i - 1;
            object = object[n3];
        } else {
            object = new v();
        }
        n3 = this.g;
        this.g = n3 + 1;
        object.a = n3;
        object.b = n2;
        object.c = f2;
        this.d.add((v)object);
        this.h += n2;
        while (this.h > this.c) {
            n2 = this.h - this.c;
            object = this.d.get(0);
            if (object.b <= n2) {
                this.h -= object.b;
                this.d.remove(0);
                if (this.i >= 5) continue;
                v[] arrv = this.e;
                n2 = this.i;
                this.i = n2 + 1;
                arrv[n2] = object;
                continue;
            }
            object.b -= n2;
            this.h -= n2;
        }
        return;
    }
}

