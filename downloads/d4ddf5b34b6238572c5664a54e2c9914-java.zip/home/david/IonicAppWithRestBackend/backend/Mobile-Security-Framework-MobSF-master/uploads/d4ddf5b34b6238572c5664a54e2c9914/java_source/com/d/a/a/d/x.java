/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.d;

import com.d.a.a.d.b;
import com.d.a.a.d.c;
import com.d.a.a.q;

public final class x {
    public static final int[] a = new int[]{1, 2, 3, 6};
    public static final int[] b = new int[]{48000, 44100, 32000};
    private static final int[] c = new int[]{24000, 22050, 16000};
    private static final int[] d = new int[]{2, 1, 2, 3, 3, 4, 4, 5};
    public static final int[] e = new int[]{32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 448, 512, 576, 640};
    public static final int[] f = new int[]{69, 87, 104, 121, 139, 174, 208, 243, 278, 348, 417, 487, 557, 696, 835, 975, 1114, 1253, 1393};

    public static q a(b b2, String string, long l2, String string2) {
        int n2;
        int n3 = b2.a();
        int n4 = b[(n3 & 192) >> 6];
        int n5 = b2.a();
        n3 = n2 = d[(n5 & 56) >> 3];
        if ((n5 & 4) != 0) {
            n3 = n2 + 1;
        }
        return q.a(string, "audio/ac3", -1, -1, l2, n3, n4, null, string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static q a(c c2) {
        int n2 = 1;
        c2.b(32);
        int n3 = c2.c(2);
        c2.b(14);
        int n4 = c2.c(3);
        if ((n4 & 1) != 0 && n4 != 1) {
            c2.b(2);
        }
        if ((n4 & 4) != 0) {
            c2.b(2);
        }
        if (n4 == 2) {
            c2.b(2);
        }
        int n5 = c2.c(1) == 1 ? 1 : 0;
        n4 = d[n4];
        if (n5 != 0) {
            n5 = n2;
            return q.a(null, "audio/ac3", -1, -1, -1, n5 + n4, b[n3], null, null);
        }
        n5 = 0;
        return q.a(null, "audio/ac3", -1, -1, -1, n5 + n4, b[n3], null, null);
    }

    public static q b(b b2, String string, long l2, String string2) {
        int n2;
        b2.b(b2.b + 2);
        int n3 = b2.a();
        int n4 = b[(n3 & 192) >> 6];
        int n5 = b2.a();
        n3 = n2 = d[(n5 & 14) >> 1];
        if ((n5 & 1) != 0) {
            n3 = n2 + 1;
        }
        return q.a(string, "audio/eac3", -1, -1, l2, n3, n4, null, string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static q b(c c2) {
        int n2 = 1;
        c2.b(32);
        int n3 = c2.c(2);
        if (n3 == 3) {
            n3 = c[c2.c(2)];
        } else {
            c2.b(2);
            n3 = b[n3];
        }
        int n4 = c2.c(3);
        int n5 = c2.c(1) == 1 ? 1 : 0;
        n4 = d[n4];
        if (n5 != 0) {
            n5 = n2;
            return q.a(null, "audio/eac3", -1, -1, -1, n5 + n4, n3, null, null);
        }
        n5 = 0;
        return q.a(null, "audio/eac3", -1, -1, -1, n5 + n4, n3, null, null);
    }
}

