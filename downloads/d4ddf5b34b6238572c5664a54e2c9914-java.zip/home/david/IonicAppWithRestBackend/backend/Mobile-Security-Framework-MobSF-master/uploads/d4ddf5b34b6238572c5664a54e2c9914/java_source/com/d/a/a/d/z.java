/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 */
package com.d.a.a.d;

import android.util.Pair;
import com.d.a.a.d.c;

public final class z {
    public static final byte[] a = new byte[]{0, 0, 0, 1};
    private static final int[] b = new int[]{96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350};
    private static final int[] c = new int[]{0, 1, 2, 3, 4, 5, 6, 8, -1, -1, -1, 7, 8, -1, 8, -1};

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static Pair<Integer, Integer> a(byte[] var0) {
        var0 = new c((byte[])var0);
        var4_1 = var0.c(5);
        var2_2 = var0.c(4);
        if (var2_2 == 15) {
            var2_2 = var0.c(24);
        } else {
            var1_3 = var2_2 < 13 ? 1 : 0;
            if (var1_3 == 0) {
                throw new IllegalArgumentException();
            }
            var2_2 = z.b[var2_2];
        }
        var3_4 = var0.c(4);
        if (var4_1 != 5 && var4_1 != 29) ** GOTO lbl-1000
        var2_2 = var0.c(4);
        if (var2_2 == 15) {
            var1_3 = var0.c(24);
        } else {
            var1_3 = var2_2 < 13 ? 1 : 0;
            if (var1_3 == 0) {
                throw new IllegalArgumentException();
            }
            var1_3 = z.b[var2_2];
        }
        var2_2 = var1_3;
        if (var0.c(5) == 22) {
            var2_2 = var0.c(4);
        } else lbl-1000: // 2 sources:
        {
            var1_3 = var2_2;
            var2_2 = var3_4;
        }
        if ((var3_4 = z.c[var2_2]) != -1) {
            return Pair.create((Object)var1_3, (Object)var3_4);
        }
        var2_2 = 0;
        if (var2_2 != 0) return Pair.create((Object)var1_3, (Object)var3_4);
        throw new IllegalArgumentException();
    }
}

