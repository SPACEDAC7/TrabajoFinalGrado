/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.c;

public final class aa {
    public int a;
    public int b = 1;
    public c c;
}

