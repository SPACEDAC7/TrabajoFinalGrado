/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.aa;
import com.d.a.a.e.ad;
import com.d.a.a.e.c;
import com.d.a.a.e.e;
import com.d.a.a.g.j;
import com.d.a.a.g.l;
import java.util.List;

public final class ab
implements ad {
    @Override
    public final c a(List<? extends e> list, int n2, long l2, c[] arrc, j j2, boolean bl2, l l3) {
        return null;
    }

    @Override
    public final void a(List<? extends e> list, long l2, c[] arrc, aa aa2) {
        aa2.c = arrc[0];
    }
}

