/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.aa;
import com.d.a.a.e.ad;
import com.d.a.a.e.c;
import com.d.a.a.e.e;
import com.d.a.a.e.f;
import com.d.a.a.g.j;
import com.d.a.a.g.l;
import java.util.List;

public final class ac
implements ad {
    private final com.d.a.a.a.ac a;
    private final int b;
    private final long c;
    private final long d;
    private final long e;
    private final float f;

    public ac(com.d.a.a.a.ac ac2) {
        this(ac2, 0);
    }

    private ac(com.d.a.a.a.ac ac2, byte by2) {
        this.a = ac2;
        this.b = 800000;
        this.c = 10000000;
        this.d = 25000000;
        this.e = 25000000;
        this.f = 0.75f;
    }

    @Override
    public final c a(List<? extends e> list, int n2, long l2, c[] arrc, j j2, boolean bl2, l l3) {
        return null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(List<? extends e> var1_1, long var2_2, c[] var4_3, aa var5_4) {
        block6 : {
            var8_5 = var1_1.isEmpty() != false ? 0 : ((e)var1_1.get((int)(var1_1.size() - 1))).f - var2_2;
            var12_6 = var5_4.c;
            var10_7 = this.a.a();
            var10_7 = var10_7 == -1 ? (long)this.b : (long)((float)var10_7 * this.f);
            for (var6_8 = 0; var6_8 < var4_3.length; ++var6_8) {
                var13_9 = var4_3[var6_8];
                if ((long)var13_9.c > var10_7) continue;
                var4_3 = var13_9;
                break block6;
            }
            var4_3 = var4_3[var4_3.length - 1];
        }
        var6_8 = var4_3 != null && var12_6 != null && var4_3.c > var12_6.c ? 1 : 0;
        var7_10 = var4_3 != null && var12_6 != null && var4_3.c < var12_6.c;
        if (var6_8 == 0) ** GOTO lbl20
        if (var8_5 >= this.c) ** GOTO lbl18
        var1_1 = var12_6;
        ** GOTO lbl24
lbl18: // 1 sources:
        if (var8_5 < this.e) ** GOTO lbl-1000
        ** GOTO lbl29
lbl20: // 1 sources:
        if (var12_6 != null && var8_5 >= this.d) {
            var1_1 = var12_6;
        } else lbl-1000: // 2 sources:
        {
            var1_1 = var4_3;
        }
lbl24: // 5 sources:
        do {
            if (var12_6 != null && var1_1 != var12_6) {
                var5_4.b = 3;
            }
            var5_4.c = var1_1;
            return;
            break;
        } while (true);
lbl29: // 2 sources:
        for (var6_8 = 1; var6_8 < var1_1.size(); ++var6_8) {
            var13_9 = (e)var1_1.get(var6_8);
            if (var13_9.e - var2_2 < this.e || var13_9.j.c >= var4_3.c || var13_9.j.g >= var4_3.g || var13_9.j.g >= 720 || var13_9.j.f >= 1280) continue;
            var5_4.a = var6_8;
            var1_1 = var4_3;
            ** GOTO lbl24
        }
        var1_1 = var4_3;
        ** while (true)
    }
}

