/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.aa;
import com.d.a.a.e.c;
import com.d.a.a.e.e;
import com.d.a.a.g.j;
import com.d.a.a.g.l;
import java.util.List;

public interface ad {
    public c a(List<? extends e> var1, int var2, long var3, c[] var5, j var6, boolean var7, l var8);

    public void a(List<? extends e> var1, long var2, c[] var4, aa var5);
}

