/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.a.i;
import com.d.a.a.b.d;
import com.d.a.a.d.ah;
import com.d.a.a.d.b;
import com.d.a.a.e.c;
import com.d.a.a.e.f;
import com.d.a.a.e.g;
import com.d.a.a.e.h;
import com.d.a.a.f.a;
import com.d.a.a.f.j;
import com.d.a.a.f.m;
import com.d.a.a.q;

public final class af
extends f
implements g {
    public q a;
    public d b;
    public j c;
    a d;
    private final h e;
    private volatile int f;
    private volatile boolean g;

    public af(com.d.a.a.a.h h2, i i2, int n2, c c2, h h3, int n3) {
        super(h2, i2, 2, n2, c2, n3);
        this.e = h3;
    }

    @Override
    public final int a(m m2, int n2, boolean bl2) {
        throw new IllegalStateException("Unexpected sample data in initialization chunk");
    }

    @Override
    public final void a(long l2, int n2, int n3, int n4, byte[] arrby) {
        throw new IllegalStateException("Unexpected sample data in initialization chunk");
    }

    @Override
    public final void a(d d2) {
        this.b = d2;
    }

    @Override
    public final void a(b b2, int n2) {
        throw new IllegalStateException("Unexpected sample data in initialization chunk");
    }

    @Override
    public final void a(j j2) {
        this.c = j2;
    }

    @Override
    public final void a(q q2) {
        this.a = q2;
    }

    @Override
    public final long c() {
        return this.f;
    }

    @Override
    public final void g() {
        this.g = true;
    }

    @Override
    public final boolean h() {
        return this.g;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final void i() {
        Object object = ah.a(this.k, this.f);
        object = new m(this.m, object.c, this.m.a((i)object));
        if (this.f == 0) {
            this.e.a(this, this.d);
        }
        int n2 = 0;
        while (n2 == 0) {
            if (this.g) break;
            n2 = this.e.a((m)object);
            continue;
        }
        this.f = (int)(object.d - this.k.c);
        return;
        catch (Throwable throwable) {
            this.f = (int)(object.d - this.k.c);
            throw throwable;
        }
        finally {
            this.m.a();
        }
    }
}

