/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.a.b;
import com.d.a.a.a.h;
import com.d.a.a.a.i;
import com.d.a.a.d.ah;
import com.d.a.a.e.c;
import com.d.a.a.e.d;
import com.d.a.a.e.e;
import com.d.a.a.e.f;
import com.d.a.a.f.a;
import com.d.a.a.q;

public final class ag
extends d {
    private final q n;
    private final com.d.a.a.b.d o;
    private volatile int p;
    private volatile boolean q;

    public ag(h h2, i i2, c c2, long l2, long l3, int n2, q q2, int n3) {
        super(h2, i2, 1, c2, l2, l3, n2, true, n3);
        this.n = q2;
        this.o = null;
    }

    @Override
    public final q a() {
        return this.n;
    }

    @Override
    public final com.d.a.a.b.d b() {
        return this.o;
    }

    @Override
    public final long c() {
        return this.p;
    }

    @Override
    public final void g() {
        this.q = true;
    }

    @Override
    public final boolean h() {
        return this.q;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void i() {
        int n2 = 0;
        Object object = ah.a(this.k, this.p);
        try {
            this.m.a((i)object);
            while (n2 != -1) {
                this.p = n2 + this.p;
                Object object2 = this.b;
                object = this.m;
                object2 = object2.a;
                n2 = object2.a(Integer.MAX_VALUE);
                byte[] arrby = object2.i.a;
                b b2 = object2.i;
                int n3 = object2.j;
                if ((n2 = object.a(arrby, b2.b + n3, n2)) == -1) {
                    n2 = -1;
                    continue;
                }
                object2.j += n2;
                object2.h += (long)n2;
            }
            n2 = this.p;
            this.b.a(this.e, 1, n2, 0, null);
            return;
        }
        finally {
            this.m.a();
        }
    }
}

