/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  com.d.a.a.e.ae
 */
package com.d.a.a.e;

import android.graphics.Point;
import com.d.a.a.af;
import com.d.a.a.d.ab;
import com.d.a.a.e.ae;
import com.d.a.a.e.c;
import com.d.a.a.g.a.j;
import java.util.ArrayList;
import java.util.List;

public final class ah {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static int[] a(List<? extends ae> var0, String[] var1_1, boolean var2_2, int var3_3, int var4_4) {
        var5_5 = Integer.MAX_VALUE;
        var15_6 = new ArrayList<Integer>();
        var9_7 = af.a();
        var10_8 = var0.size();
        for (var6_9 = 0; var6_9 < var10_8; ++var6_9) {
            var16_16 = ((j)var0.get(var6_9)).e();
            if (!var2_2 || var16_16.f < 1280 && var16_16.g < 720) ** GOTO lbl10
            var13_14 = false;
            ** GOTO lbl21
lbl10: // 1 sources:
            if (var16_16.f <= 0 || var16_16.g <= 0) ** GOTO lbl-1000
            if (com.d.a.a.d.ah.a >= 21) {
                var1_1 = var14_15 = ab.b(var16_16.k);
                if ("video/x-unknown".equals(var14_15)) {
                    var1_1 = "video/avc";
                }
                var13_14 = var16_16.h > 0.0f ? af.a((String)var1_1, var16_16.f, var16_16.g, var16_16.h) : af.a((String)var1_1, var16_16.f, var16_16.g);
            } else if (var16_16.f * var16_16.g > var9_7) {
                var13_14 = false;
            } else lbl-1000: // 2 sources:
            {
                var13_14 = true;
            }
lbl21: // 4 sources:
            if (!var13_14) continue;
            var15_6.add(var6_9);
            if (var16_16.f <= 0 || var16_16.g <= 0 || var3_3 <= 0 || var4_4 <= 0) continue;
            var11_12 = var16_16.f;
            var12_13 = var16_16.g;
            var7_10 = var11_12 > var12_13 ? 1 : 0;
            var8_11 = var3_3 > var4_4 ? 1 : 0;
            if (var7_10 != var8_11) {
                var7_10 = var3_3;
                var8_11 = var4_4;
            } else {
                var7_10 = var4_4;
                var8_11 = var3_3;
            }
            var1_1 = var11_12 * var7_10 >= var12_13 * var8_11 ? new Point(var8_11, com.d.a.a.d.ah.a(var8_11 * var12_13, var11_12)) : new Point(com.d.a.a.d.ah.a(var7_10 * var11_12, var12_13), var7_10);
            var7_10 = var16_16.f * var16_16.g;
            if (var16_16.f < (int)((float)var1_1.x * 0.98f) || var16_16.g < (int)((float)var1_1.y * 0.98f) || var7_10 >= var5_5) continue;
            var5_5 = var7_10;
        }
        if (var5_5 == Integer.MAX_VALUE) return com.d.a.a.d.ah.a(var15_6);
        var3_3 = var15_6.size() - 1;
        while (var3_3 >= 0) {
            var1_1 = ((j)var0.get(var15_6.get(var3_3))).e();
            if (var1_1.f > 0 && var1_1.g > 0 && var1_1.g * (var4_4 = var1_1.f) > var5_5) {
                var15_6.remove(var3_3);
            }
            --var3_3;
        }
        return com.d.a.a.d.ah.a(var15_6);
    }
}

