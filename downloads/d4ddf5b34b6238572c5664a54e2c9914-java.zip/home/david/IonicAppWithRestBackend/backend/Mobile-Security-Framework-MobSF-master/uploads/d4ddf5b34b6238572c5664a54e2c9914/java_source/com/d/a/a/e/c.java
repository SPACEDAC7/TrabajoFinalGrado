/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

public class c {
    public final String a;
    public final String b;
    public final int c;
    public final String d;
    public final boolean e;
    public final int f;
    public final int g;
    public final float h;
    public final int i;
    public final int j;
    public final String k;
    public final String l;

    public c(String string, String string2, int n2, int n3, float f2, int n4, int n5, int n6, String string3, String string4, String string5) {
        this(string, string2, n2, n3, f2, n4, n5, n6, string3, string4, string5, false);
    }

    public c(String string, String string2, int n2, int n3, float f2, int n4, int n5, int n6, String string3, String string4, String string5, boolean bl2) {
        if (string == null) {
            throw new NullPointerException();
        }
        this.a = string;
        this.b = string2;
        this.f = n2;
        this.g = n3;
        this.h = f2;
        this.i = n4;
        this.j = n5;
        this.c = n6;
        this.l = string3;
        this.k = string4;
        this.d = string5;
        this.e = bl2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        return ((c)object).a.equals(this.a);
    }

    public int hashCode() {
        return this.a.hashCode();
    }
}

