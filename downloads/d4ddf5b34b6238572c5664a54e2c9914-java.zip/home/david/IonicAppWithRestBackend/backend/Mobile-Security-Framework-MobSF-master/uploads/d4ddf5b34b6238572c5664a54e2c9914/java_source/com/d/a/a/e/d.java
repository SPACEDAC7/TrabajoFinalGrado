/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.a.h;
import com.d.a.a.a.i;
import com.d.a.a.e.c;
import com.d.a.a.e.e;
import com.d.a.a.f.a;
import com.d.a.a.q;

public abstract class d
extends e {
    public final boolean a;
    a b;
    protected a c;
    int d;

    public d(h h2, i i2, int n2, c c2, long l2, long l3, int n3, boolean bl2, int n4) {
        super(h2, i2, n2, c2, l2, l3, n3, n4);
        this.a = bl2;
    }

    public abstract q a();

    public final void a(a object, a a2) {
        this.b = object;
        this.c = a2;
        object = object.a.c;
        int n2 = object.e;
        this.d = object.d + n2;
    }

    public abstract com.d.a.a.b.d b();
}

