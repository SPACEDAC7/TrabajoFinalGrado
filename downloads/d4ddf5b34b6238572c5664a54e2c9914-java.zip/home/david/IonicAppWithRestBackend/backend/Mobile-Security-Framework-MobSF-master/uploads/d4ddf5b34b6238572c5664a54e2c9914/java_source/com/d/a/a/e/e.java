/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.a.h;
import com.d.a.a.a.i;
import com.d.a.a.e.c;
import com.d.a.a.e.f;

public abstract class e
extends f {
    public final long e;
    public final long f;
    public final int g;

    public e(h h2, i i2, int n2, c c2, long l2, long l3, int n3, int n4) {
        super(h2, i2, 1, n2, c2, n4);
        if (c2 == null) {
            throw new NullPointerException();
        }
        this.e = l2;
        this.f = l3;
        this.g = n3;
    }
}

