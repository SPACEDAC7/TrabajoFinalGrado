/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.a.d;
import com.d.a.a.a.h;
import com.d.a.a.a.i;
import com.d.a.a.e.c;

public abstract class f
implements d {
    public final int h;
    public final int i;
    public final c j;
    public final i k;
    public final int l;
    protected final h m;

    public f(h h2, i i2, int n2, int n3, c c2, int n4) {
        if (h2 == null) {
            throw new NullPointerException();
        }
        this.m = h2;
        if (i2 == null) {
            throw new NullPointerException();
        }
        this.k = i2;
        this.h = n2;
        this.i = n3;
        this.j = c2;
        this.l = n4;
    }

    public abstract long c();
}

