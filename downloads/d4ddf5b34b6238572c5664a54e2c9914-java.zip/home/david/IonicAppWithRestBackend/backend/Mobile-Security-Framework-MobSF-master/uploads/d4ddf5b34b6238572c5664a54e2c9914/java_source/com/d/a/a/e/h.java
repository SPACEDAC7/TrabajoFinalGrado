/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.b.d;
import com.d.a.a.e.g;
import com.d.a.a.f.a;
import com.d.a.a.f.b;
import com.d.a.a.f.j;
import com.d.a.a.f.k;
import com.d.a.a.f.m;
import com.d.a.a.q;

public final class h
implements b,
com.d.a.a.f.g {
    private final com.d.a.a.f.h a;
    private boolean b;
    private g c;
    private a d;
    private boolean e;
    private boolean f;

    public h(com.d.a.a.f.h h2) {
        this.a = h2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int a(m m2) {
        boolean bl2 = true;
        int n2 = this.a.a(m2, null);
        if (n2 == 1) {
            bl2 = false;
        }
        if (!bl2) {
            throw new IllegalStateException();
        }
        return n2;
    }

    @Override
    public final int a(m m2, int n2, boolean bl2) {
        return this.c.a(m2, n2, bl2);
    }

    @Override
    public final void a() {
        if (!this.e) {
            throw new IllegalStateException();
        }
    }

    @Override
    public final void a(long l2, int n2, int n3, int n4, byte[] arrby) {
        this.c.a(l2, n2, n3, n4, arrby);
    }

    @Override
    public final void a(d d2) {
        this.c.a(d2);
    }

    @Override
    public final void a(com.d.a.a.d.b b2, int n2) {
        this.c.a(b2, n2);
    }

    public final void a(g g2, a a2) {
        this.c = g2;
        this.d = a2;
        if (!this.b) {
            this.a.a(this);
            this.b = true;
            return;
        }
        this.a.c_();
    }

    @Override
    public final void a(j j2) {
        this.c.a(j2);
    }

    @Override
    public final void a(q q2) {
        this.c.a(q2);
    }

    @Override
    public final b a_(int n2) {
        int n3 = 0;
        int n4 = 0;
        if (n2 > 0 && this.d != null) {
            n2 = n4;
            if (!this.f) {
                n2 = 1;
            }
            if (n2 == 0) {
                throw new IllegalStateException();
            }
            this.f = true;
            return this.d;
        }
        n2 = n3;
        if (!this.e) {
            n2 = 1;
        }
        if (n2 == 0) {
            throw new IllegalStateException();
        }
        this.e = true;
        return this;
    }
}

