/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.f;

public final class i {
    public int a;
    public f b;
    public boolean c;
}

