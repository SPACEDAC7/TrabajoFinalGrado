/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.q;

final class m
implements Runnable {
    final /* synthetic */ long a;
    final /* synthetic */ q b;

    m(q q2, long l2) {
        this.b = q2;
        this.a = l2;
    }

    @Override
    public final void run() {
    }
}

