/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.q;
import java.io.IOException;

final class n
implements Runnable {
    final /* synthetic */ IOException a;
    final /* synthetic */ q b;

    n(q q2, IOException iOException) {
        this.b = q2;
        this.a = iOException;
    }

    @Override
    public final void run() {
    }
}

