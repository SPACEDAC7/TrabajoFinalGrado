/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Handler
 *  android.os.SystemClock
 */
package com.d.a.a.e;

import android.net.Uri;
import android.os.Handler;
import android.os.SystemClock;
import com.d.a.a.a.aa;
import com.d.a.a.a.g;
import com.d.a.a.e.c;
import com.d.a.a.e.d;
import com.d.a.a.e.e;
import com.d.a.a.e.f;
import com.d.a.a.e.i;
import com.d.a.a.e.k;
import com.d.a.a.e.l;
import com.d.a.a.e.m;
import com.d.a.a.e.n;
import com.d.a.a.e.o;
import com.d.a.a.e.p;
import com.d.a.a.f.a;
import com.d.a.a.j;
import com.d.a.a.w;
import com.d.a.a.x;
import com.d.a.a.y;
import com.d.a.a.z;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public final class q
implements com.d.a.a.a.e,
w,
x {
    final int a;
    final com.instagram.exoplayer.service.o b;
    private final j c;
    private final com.d.a.a.g.l d;
    private final i e;
    private final LinkedList<d> f;
    private final List<d> g;
    private final a h;
    private final int i;
    private final Handler j;
    private final int k;
    private int l;
    private long m;
    private long n;
    private long o;
    private long p;
    private boolean q;
    private g r;
    private boolean s;
    private IOException t;
    private int u;
    private int v;
    private long w;
    private long x;
    private com.d.a.a.q y;
    private c z;

    public q(com.d.a.a.g.l l2, j j2, int n2) {
        this(l2, j2, n2, null, null, 0);
    }

    public q(com.d.a.a.g.l l2, j j2, int n2, Handler handler, com.instagram.exoplayer.service.o o2, int n3) {
        this(l2, j2, n2, handler, o2, n3, 0);
    }

    private q(com.d.a.a.g.l l2, j j2, int n2, Handler handler, com.instagram.exoplayer.service.o o2, int n3, byte by2) {
        this.d = l2;
        this.c = j2;
        this.i = n2;
        this.j = handler;
        this.b = o2;
        this.a = n3;
        this.k = 3;
        this.e = new i();
        this.f = new LinkedList();
        this.g = Collections.unmodifiableList(this.f);
        this.h = new a(j2.b());
        this.l = 0;
        this.o = Long.MIN_VALUE;
    }

    private void a(long l2, int n2, int n3, c c2, long l3, long l4) {
        if (this.j != null && this.b != null) {
            this.j.post((Runnable)new k(this, l2, n2, n3, c2, l3, l4));
        }
    }

    private void a(long l2, int n2, int n3, c c2, long l3, long l4, long l5, long l6) {
        if (this.j != null && this.b != null) {
            this.j.post((Runnable)new l(this, l2, n2, n3, c2, l3, l4, l5, l6));
        }
    }

    private void b(long l2) {
        this.o = l2;
        this.s = false;
        if (this.r.b) {
            this.r.a();
            return;
        }
        this.h.a();
        this.f.clear();
        this.e.b = null;
        this.t = null;
        this.v = 0;
        this.g();
    }

    private void c(long l2) {
        if (this.j != null && this.b != null) {
            this.j.post((Runnable)new m(this, l2));
        }
    }

    private boolean d(int n2) {
        if (this.f.size() <= n2) {
            return false;
        }
        long l2 = 0;
        long l3 = this.f.getLast().f;
        d d2 = null;
        while (this.f.size() > n2) {
            d2 = this.f.removeLast();
            l2 = d2.e;
            this.s = false;
        }
        this.h.a(d2.d);
        if (this.j != null && this.b != null) {
            this.j.post((Runnable)new o(this, l2, l3));
        }
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void g() {
        var2_1 = true;
        var7_2 = SystemClock.elapsedRealtime();
        var5_3 = this.h();
        var1_4 = this.t != null;
        var9_5 = this.r.b != false || var1_4 != false;
        var3_6 = var5_3;
        if (var9_5) ** GOTO lbl20
        if (this.e.b == null && var5_3 != -1) ** GOTO lbl-1000
        var3_6 = var5_3;
        if (var7_2 - this.p > 2000) lbl-1000: // 2 sources:
        {
            this.p = var7_2;
            this.k();
            var10_7 = this.d(this.e.a);
            if (this.e.b == null) {
                var3_6 = -1;
            } else {
                var3_6 = var5_3;
                if (var10_7) {
                    var3_6 = this.h();
                }
            }
        }
lbl20: // 7 sources:
        var9_5 = this.c.a(this, this.m, var3_6, var9_5);
        if (!var1_4) {
            if (this.r.b != false) return;
            if (var9_5 == false) return;
            this.i();
            return;
        }
        if (var7_2 - this.w < Math.min(((long)this.v - 1) * 1000, 5000)) return;
        this.t = null;
        var11_8 = this.e.b;
        if (!(var11_8 instanceof d)) {
            this.k();
            this.d(this.e.a);
            if (this.e.b == var11_8) {
                this.r.a(var11_8, this);
                return;
            }
            this.c(var11_8.c());
            this.i();
            return;
        }
        if (var11_8 == this.f.getFirst()) {
            this.r.a(var11_8, this);
            return;
        }
        var12_9 = this.f.removeLast();
        var1_4 = var11_8 == var12_9 ? var2_1 : false;
        if (!var1_4) {
            throw new IllegalStateException();
        }
        this.k();
        this.f.add(var12_9);
        if (this.e.b == var11_8) {
            this.r.a(var11_8, this);
            return;
        }
        this.c(var11_8.c());
        this.d(this.e.a);
        this.t = null;
        this.v = 0;
        this.i();
    }

    /*
     * Enabled aggressive block sorting
     */
    private long h() {
        if (this.o != Long.MIN_VALUE) {
            return this.o;
        }
        boolean bl2 = false;
        if (bl2) {
            return this.o;
        }
        if (!this.s) return this.f.getLast().f;
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void i() {
        f f2 = this.e.b;
        if (f2 == null) {
            return;
        }
        this.x = SystemClock.elapsedRealtime();
        if (f2 instanceof d) {
            d d2 = (d)f2;
            d2.a(this.h, null);
            this.f.add(d2);
            boolean bl2 = this.o != Long.MIN_VALUE;
            if (bl2) {
                this.o = Long.MIN_VALUE;
            }
            this.a(d2.k.e, d2.h, d2.i, d2.j, d2.e, d2.f);
        } else {
            this.a(f2.k.e, f2.h, f2.i, f2.j, -1, -1);
        }
        this.r.a(f2, this);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void k() {
        this.e.c = false;
        this.e.a = this.g.size();
        com.d.a.a.g.l l2 = this.d;
        List<d> list = this.g;
        long l3 = this.o != Long.MIN_VALUE ? this.o : this.m;
        l2.a(list, l3, this.e);
        this.s = this.e.c;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(int n2, long l2, y y2, z z2) {
        Object object;
        int n3;
        n2 = this.l == 3 ? 1 : 0;
        if (n2 == 0) {
            throw new IllegalStateException();
        }
        this.m = l2;
        if (this.q) return -2;
        if (this.o != Long.MIN_VALUE) {
            return -2;
        }
        n2 = 0;
        if (n2 != 0) {
            return -2;
        }
        n2 = !this.h.b() ? 1 : 0;
        d d2 = this.f.getFirst();
        while (n2 != 0 && this.f.size() > 1 && this.f.get((int)1).d <= this.h.a.c.e) {
            this.f.removeFirst();
            d2 = this.f.getFirst();
        }
        if (this.z == null || !this.z.equals(d2.j)) {
            object = d2.j;
            n3 = d2.i;
            l2 = d2.e;
            String string = d2.k.a.toString();
            if (this.j != null && this.b != null) {
                this.j.post((Runnable)new p(this, (c)object, n3, l2, string));
            }
            this.z = d2.j;
        }
        if ((n2 != 0 || d2.a) && !(object = d2.a()).equals(this.y)) {
            y2.a = object;
            y2.b = d2.b();
            this.y = object;
            return -4;
        }
        if (n2 == 0) {
            if (!this.s) return -2;
            return -1;
        }
        if (!this.h.a(z2)) return -2;
        n2 = z2.e < this.n ? 1 : 0;
        n3 = z2.d;
        n2 = n2 != 0 ? 134217728 : 0;
        z2.d = n2 | n3;
        return -3;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final com.d.a.a.q a(int n2) {
        if (this.l == 2 || this.l == 3) {
            return this.d.a(n2);
        }
        boolean bl2 = false;
        if (!bl2) {
            throw new IllegalStateException();
        }
        return this.d.a(n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(int n2, long l2) {
        int n3 = 1;
        int n4 = this.l == 2 ? 1 : 0;
        if (n4 == 0) {
            throw new IllegalStateException();
        }
        n4 = this.u;
        this.u = n4 + 1;
        n4 = n4 == 0 ? n3 : 0;
        if (n4 == 0) {
            throw new IllegalStateException();
        }
        this.l = 3;
        this.d.b(n2);
        this.c.a(this, this.i);
        this.z = null;
        this.y = null;
        this.m = l2;
        this.n = l2;
        this.q = false;
        this.b(l2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(long l2) {
        boolean bl2 = this.l == 3;
        if (!bl2) {
            throw new IllegalStateException();
        }
        bl2 = this.o != Long.MIN_VALUE;
        long l3 = bl2 ? this.o : this.m;
        this.m = l2;
        this.n = l2;
        if (l3 == l2) {
            return;
        }
        bl2 = this.o != Long.MIN_VALUE;
        bl2 = !bl2 && this.h.a(l2);
        if (bl2) {
            bl2 = !this.h.b();
            while (bl2 && this.f.size() > 1 && this.f.get((int)1).d <= this.h.a.c.e) {
                this.f.removeFirst();
            }
        } else {
            this.b(l2);
        }
        this.q = true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(com.d.a.a.a.d d2) {
        long l2 = SystemClock.elapsedRealtime();
        long l3 = l2 - this.x;
        d2 = this.e.b;
        this.d.a((f)d2);
        if (d2 instanceof d) {
            d d3 = (d)d2;
            this.a(d2.c(), d3.h, d3.i, d3.j, d3.e, d3.f, l2, l3);
        } else {
            this.a(d2.c(), d2.h, d2.i, d2.j, -1, -1, l2, l3);
        }
        this.e.b = null;
        this.t = null;
        this.v = 0;
        this.g();
    }

    @Override
    public final void a(com.d.a.a.a.d d2, IOException iOException) {
        this.t = iOException;
        ++this.v;
        this.w = SystemClock.elapsedRealtime();
        if (this.j != null && this.b != null) {
            this.j.post((Runnable)new n(this, iOException));
        }
        this.g();
    }

    @Override
    public final long b(int n2) {
        if (this.q) {
            this.q = false;
            return this.n;
        }
        return Long.MIN_VALUE;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean b() {
        boolean bl2 = this.l == 1 || this.l == 2;
        if (!bl2) {
            throw new IllegalStateException();
        }
        if (this.l == 2) {
            return true;
        }
        if (!this.d.b()) {
            return false;
        }
        if (this.d.c() > 0) {
            this.r = new g("Loader:" + this.d.a((int)0).b);
        }
        this.l = 2;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean b(int n2, long l2) {
        boolean bl2 = false;
        n2 = this.l == 3 ? 1 : 0;
        if (n2 == 0) {
            throw new IllegalStateException();
        }
        this.m = l2;
        this.d.a(l2);
        this.g();
        if (this.s) return true;
        if (this.h.b()) return bl2;
        return true;
    }

    @Override
    public final void b_() {
        if (this.t != null && this.v > this.k) {
            throw this.t;
        }
        if (this.e.b == null) {
            this.d.a();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int c() {
        if (this.l == 2 || this.l == 3) {
            return this.d.c();
        }
        boolean bl2 = false;
        if (!bl2) {
            throw new IllegalStateException();
        }
        return this.d.c();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void c(int n2) {
        int n3 = 1;
        n2 = this.l == 3 ? 1 : 0;
        if (n2 == 0) {
            throw new IllegalStateException();
        }
        this.u = n2 = this.u - 1;
        n2 = n2 == 0 ? n3 : 0;
        if (n2 == 0) {
            throw new IllegalStateException();
        }
        this.l = 2;
        try {
            this.d.d();
            this.c.a(this);
            if (this.r.b) {
                this.r.a();
                return;
            }
            this.h.a();
            this.f.clear();
            this.e.b = null;
            this.t = null;
            this.v = 0;
            this.c.a();
            return;
        }
        catch (Throwable var3_3) {
            this.c.a(this);
            if (this.r.b) {
                this.r.a();
                throw var3_3;
            }
            this.h.a();
            this.f.clear();
            this.e.b = null;
            this.t = null;
            this.v = 0;
            this.c.a();
            throw var3_3;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long d() {
        long l2;
        boolean bl2 = true;
        boolean bl3 = this.l == 3;
        if (!bl3) {
            throw new IllegalStateException();
        }
        bl3 = this.o != Long.MIN_VALUE ? bl2 : false;
        if (bl3) {
            return this.o;
        }
        if (this.s) {
            return -3;
        }
        long l3 = l2 = this.h.e;
        if (l2 != Long.MIN_VALUE) return l3;
        return this.m;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void e() {
        boolean bl2 = this.l != 3;
        if (!bl2) {
            throw new IllegalStateException();
        }
        if (this.r != null) {
            this.r.b();
            this.r = null;
        }
        this.l = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final w f() {
        boolean bl2 = this.l == 0;
        if (!bl2) {
            throw new IllegalStateException();
        }
        this.l = 1;
        return this;
    }

    @Override
    public final void j() {
        this.c(this.e.b.c());
        this.e.b = null;
        this.t = null;
        this.v = 0;
        if (this.l == 3) {
            this.b(this.o);
            return;
        }
        this.h.a();
        this.f.clear();
        this.e.b = null;
        this.t = null;
        this.v = 0;
        this.c.a();
    }
}

