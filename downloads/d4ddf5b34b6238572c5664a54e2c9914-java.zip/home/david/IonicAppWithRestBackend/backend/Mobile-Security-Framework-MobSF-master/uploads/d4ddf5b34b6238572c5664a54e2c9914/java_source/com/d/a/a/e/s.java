/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.c;
import com.d.a.a.e.y;

final class s
implements Runnable {
    final /* synthetic */ long a;
    final /* synthetic */ int b;
    final /* synthetic */ int c;
    final /* synthetic */ c d;
    final /* synthetic */ long e;
    final /* synthetic */ long f;
    final /* synthetic */ y g;

    s(y y2, long l2, int n2, int n3, c c2, long l3, long l4) {
        this.g = y2;
        this.a = l2;
        this.b = n2;
        this.c = n3;
        this.d = c2;
        this.e = l3;
        this.f = l4;
    }

    @Override
    public final void run() {
    }
}

