/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.y;

final class u
implements Runnable {
    final /* synthetic */ long a;
    final /* synthetic */ y b;

    u(y y2, long l2) {
        this.b = y2;
        this.a = l2;
    }

    @Override
    public final void run() {
    }
}

