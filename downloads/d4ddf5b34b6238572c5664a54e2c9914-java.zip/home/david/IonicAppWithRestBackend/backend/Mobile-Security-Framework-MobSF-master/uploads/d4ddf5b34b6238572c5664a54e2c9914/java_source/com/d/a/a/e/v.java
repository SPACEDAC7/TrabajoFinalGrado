/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.y;
import java.io.IOException;

final class v
implements Runnable {
    final /* synthetic */ IOException a;
    final /* synthetic */ y b;

    v(y y2, IOException iOException) {
        this.b = y2;
        this.a = iOException;
    }

    @Override
    public final void run() {
    }
}

