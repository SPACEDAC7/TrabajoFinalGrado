/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.y;

final class w
implements Runnable {
    final /* synthetic */ long a;
    final /* synthetic */ long b;
    final /* synthetic */ y c;

    w(y y2, long l2, long l3) {
        this.c = y2;
        this.a = l2;
        this.b = l3;
    }

    @Override
    public final void run() {
    }
}

