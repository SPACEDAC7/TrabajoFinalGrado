/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.e.c;
import com.d.a.a.e.y;
import com.instagram.exoplayer.service.o;

final class x
implements Runnable {
    final /* synthetic */ c a;
    final /* synthetic */ int b;
    final /* synthetic */ long c;
    final /* synthetic */ String d;
    final /* synthetic */ y e;

    x(y y2, c c2, int n2, long l2, String string) {
        this.e = y2;
        this.a = c2;
        this.b = n2;
        this.c = l2;
        this.d = string;
    }

    @Override
    public final void run() {
        this.e.b.a(this.e.a, this.a, this.b, this.c / 1000);
    }
}

