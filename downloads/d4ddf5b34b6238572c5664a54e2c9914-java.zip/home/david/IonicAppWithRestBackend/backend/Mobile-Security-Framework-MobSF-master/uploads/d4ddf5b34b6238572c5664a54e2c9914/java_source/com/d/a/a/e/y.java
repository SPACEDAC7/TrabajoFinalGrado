/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.util.SparseArray
 */
package com.d.a.a.e;

import android.net.Uri;
import android.os.Handler;
import android.os.SystemClock;
import android.util.SparseArray;
import com.d.a.a.a.aa;
import com.d.a.a.a.g;
import com.d.a.a.e.af;
import com.d.a.a.e.c;
import com.d.a.a.e.d;
import com.d.a.a.e.e;
import com.d.a.a.e.f;
import com.d.a.a.e.i;
import com.d.a.a.e.s;
import com.d.a.a.e.t;
import com.d.a.a.e.u;
import com.d.a.a.e.v;
import com.d.a.a.e.w;
import com.d.a.a.e.x;
import com.d.a.a.f.a;
import com.d.a.a.g.l;
import com.d.a.a.j;
import com.d.a.a.q;
import com.d.a.a.z;
import com.instagram.exoplayer.service.o;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public final class y
implements com.d.a.a.a.e,
com.d.a.a.w,
com.d.a.a.x {
    private long A;
    private q B;
    private c C;
    final int a;
    final o b;
    private int c;
    private final j d;
    private final l e;
    private final i f;
    private final LinkedList<d> g;
    private final List<d> h;
    private final SparseArray<a> i;
    private final int j;
    private final Handler k;
    private final int l;
    private int m;
    private long n;
    private long o;
    private long p;
    private long q;
    private boolean[] r;
    private boolean[] s;
    private boolean t;
    private g u;
    private boolean v;
    private IOException w;
    private int x;
    private int y;
    private long z;

    public y(l l2, j j2, int n2, Handler handler, o o2) {
        this(l2, j2, n2, handler, o2, 1001);
    }

    private y(l l2, j j2, int n2, Handler handler, o o2, int n3) {
        this.e = l2;
        this.d = j2;
        this.j = n2;
        this.k = handler;
        this.b = o2;
        this.a = 1001;
        this.l = 3;
        this.f = new i();
        this.g = new LinkedList();
        this.h = Collections.unmodifiableList(this.g);
        this.i = new SparseArray(2);
        this.i.put(0, (Object)new a(j2.b()));
        this.i.put(1, (Object)new a(j2.b()));
        this.r = new boolean[2];
        this.s = new boolean[2];
        this.m = 0;
        this.p = Long.MIN_VALUE;
    }

    private void a(long l2, int n2, int n3, c c2, long l3, long l4) {
        if (this.k != null && this.b != null) {
            this.k.post((Runnable)new s(this, l2, n2, n3, c2, l3, l4));
        }
    }

    private void a(long l2, int n2, int n3, c c2, long l3, long l4, long l5, long l6) {
        if (this.k != null && this.b != null) {
            this.k.post((Runnable)new t(this, l2, n2, n3, c2, l3, l4, l5, l6));
        }
    }

    private void b(long l2) {
        this.p = l2;
        this.v = false;
        if (this.u.b) {
            this.u.a();
            return;
        }
        this.l();
        this.g.clear();
        this.f.b = null;
        this.w = null;
        this.y = 0;
        this.g();
    }

    private void c(long l2) {
        if (this.k != null && this.b != null) {
            this.k.post((Runnable)new u(this, l2));
        }
    }

    private boolean d(int n2) {
        if (this.g.size() <= n2) {
            return false;
        }
        long l2 = 0;
        long l3 = this.g.getLast().f;
        d d2 = null;
        while (this.g.size() > n2) {
            d2 = this.g.removeLast();
            l2 = d2.e;
            this.v = false;
        }
        ((a)this.i.valueAt(0)).a(d2.d);
        if (this.k != null && this.b != null) {
            this.k.post((Runnable)new w(this, l2, l3));
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int e(int n2) {
        q q2 = this.e.a(n2);
        if (q2 != null) {
            if (q2.b == "application/eia-608") return 1;
            return 0;
        }
        if (n2 != this.e.c() - 1) return 0;
        return 1;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void g() {
        var2_1 = true;
        var7_2 = SystemClock.elapsedRealtime();
        var5_3 = this.h();
        var1_4 = this.w != null;
        var9_5 = this.u.b != false || var1_4 != false;
        var3_6 = var5_3;
        if (var9_5) ** GOTO lbl20
        if (this.f.b == null && var5_3 != -1) ** GOTO lbl-1000
        var3_6 = var5_3;
        if (var7_2 - this.q > 2000) lbl-1000: // 2 sources:
        {
            this.q = var7_2;
            this.k();
            var10_7 = this.d(this.f.a);
            if (this.f.b == null) {
                var3_6 = -1;
            } else {
                var3_6 = var5_3;
                if (var10_7) {
                    var3_6 = this.h();
                }
            }
        }
lbl20: // 7 sources:
        var9_5 = this.d.a(this, this.n, var3_6, var9_5);
        if (!var1_4) {
            if (this.u.b != false) return;
            if (var9_5 == false) return;
            this.i();
            return;
        }
        if (var7_2 - this.z < Math.min(((long)this.y - 1) * 1000, 5000)) return;
        this.w = null;
        var11_8 = this.f.b;
        if (!(var11_8 instanceof d)) {
            this.k();
            this.d(this.f.a);
            if (this.f.b == var11_8) {
                this.u.a(var11_8, this);
                return;
            }
            this.c(var11_8.c());
            this.i();
            return;
        }
        if (var11_8 == this.g.getFirst()) {
            this.u.a(var11_8, this);
            return;
        }
        var12_9 = this.g.removeLast();
        var1_4 = var11_8 == var12_9 ? var2_1 : false;
        if (!var1_4) {
            throw new IllegalStateException();
        }
        this.k();
        this.g.add(var12_9);
        if (this.f.b == var11_8) {
            this.u.a(var11_8, this);
            return;
        }
        this.c(var11_8.c());
        this.d(this.f.a);
        this.w = null;
        this.y = 0;
        this.i();
    }

    /*
     * Enabled aggressive block sorting
     */
    private long h() {
        if (this.p != Long.MIN_VALUE) {
            return this.p;
        }
        boolean bl2 = false;
        if (bl2) {
            return this.p;
        }
        if (!this.v) return this.g.getLast().f;
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void i() {
        f f2 = this.f.b;
        if (f2 == null) {
            return;
        }
        this.A = SystemClock.elapsedRealtime();
        if (f2 instanceof d) {
            d d2 = (d)f2;
            d2.a((a)this.i.valueAt(0), (a)this.i.valueAt(1));
            this.g.add(d2);
            boolean bl2 = this.p != Long.MIN_VALUE;
            if (bl2) {
                this.p = Long.MIN_VALUE;
            }
            this.a(d2.k.e, d2.h, d2.i, d2.j, d2.e, d2.f);
        } else {
            if (f2 instanceof af) {
                ((af)f2).d = (a)this.i.valueAt(1);
            }
            this.a(f2.k.e, f2.h, f2.i, f2.j, -1, -1);
        }
        this.u.a(f2, this);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void k() {
        this.f.c = false;
        this.f.a = this.h.size();
        l l2 = this.e;
        List<d> list = this.h;
        long l3 = this.p != Long.MIN_VALUE ? this.p : this.n;
        l2.a(list, l3, this.f);
        this.v = this.f.c;
    }

    private void l() {
        for (int i2 = 0; i2 < this.i.size(); ++i2) {
            ((a)this.i.valueAt(i2)).a();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(int n2, long l2, com.d.a.a.y y2, z z2) {
        int n3 = this.e(n2);
        if (!this.s[n3]) {
            throw new IllegalStateException();
        }
        this.n = l2;
        if (this.r[this.e(n2)]) return -2;
        if (this.p != Long.MIN_VALUE) {
            return -2;
        }
        int n4 = 0;
        if (n4 != 0) {
            return -2;
        }
        a a2 = (a)this.i.get(this.e(n2));
        n2 = !a2.b() ? 1 : 0;
        d d2 = this.g.getFirst();
        if (n3 == 1) {
            if (this.t) {
                y2.a = a2.f;
                y2.b = d2.b();
                this.t = false;
                return -4;
            }
        } else {
            Object object;
            while (n2 != 0 && this.g.size() > 1 && this.g.get((int)1).d <= a2.a.c.e) {
                this.g.removeFirst();
                d2 = this.g.getFirst();
            }
            if (this.C == null || !this.C.equals(d2.j)) {
                object = d2.j;
                n4 = d2.i;
                l2 = d2.e;
                String string = d2.k.a.toString();
                if (this.k != null && this.b != null) {
                    this.k.post((Runnable)new x(this, (c)object, n4, l2, string));
                }
                this.C = d2.j;
            }
            if ((n2 != 0 || d2.a) && !(object = d2.a()).equals(this.B)) {
                y2.a = object;
                y2.b = d2.b();
                this.B = object;
                return -4;
            }
        }
        if (n2 == 0) {
            if (!this.v) return -2;
            return -1;
        }
        if (!a2.a(z2)) return -2;
        n2 = z2.e < this.o ? 1 : 0;
        n4 = z2.d;
        n2 = n2 != 0 ? 134217728 : 0;
        z2.d = n2 | n4;
        return -3;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final q a(int n2) {
        if (this.m == 2 || this.s[this.e(n2)]) {
            return this.e.a(n2);
        }
        boolean bl2 = false;
        if (!bl2) {
            throw new IllegalStateException();
        }
        return this.e.a(n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(int n2, long l2) {
        int n3 = this.e(n2);
        boolean bl2 = this.m == 2;
        if (!bl2) {
            throw new IllegalStateException();
        }
        bl2 = !this.s[n3];
        if (!bl2) {
            throw new IllegalStateException();
        }
        ++this.x;
        this.r[n3] = false;
        this.s[n3] = true;
        if (this.x == 1) {
            this.e.b(n2);
            this.d.a(this, this.j);
            this.C = null;
            this.B = null;
            this.n = l2;
            this.o = l2;
            this.t = true;
            this.b(l2);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(long var1_1) {
        var5_2 = 0;
        var3_3 = this.m == 2 ? 1 : 0;
        if (var3_3 == 0) {
            throw new IllegalStateException();
        }
        var3_3 = this.x > 0 ? 1 : 0;
        if (var3_3 == 0) {
            throw new IllegalStateException();
        }
        var3_3 = this.p != Long.MIN_VALUE ? 1 : 0;
        var7_4 = var3_3 != 0 ? this.p : this.n;
        this.n = var1_1;
        this.o = var1_1;
        if (var7_4 == var1_1) {
            return;
        }
        var3_3 = this.p != Long.MIN_VALUE ? 1 : 0;
        var3_3 = var3_3 == 0 ? 1 : 0;
        var6_5 = 0;
        var4_6 = var3_3;
        var3_3 = var6_5;
        while (var4_6 != 0) {
            if (var3_3 < this.i.size()) {
                var4_6 &= ((a)this.i.valueAt(var3_3)).a(var1_1);
                ++var3_3;
                continue;
            }
            ** GOTO lbl-1000
        }
        if (var4_6 != 0) lbl-1000: // 2 sources:
        {
            var3_3 = (var9_7 = (a)this.i.get(this.e(0))).b() == false ? 1 : 0;
            do {
                var4_6 = var5_2;
                if (var3_3 != 0) {
                    var4_6 = var5_2;
                    if (this.g.size() > 1) {
                        var4_6 = var5_2;
                        if (this.g.get((int)1).d <= var9_7.a.c.e) {
                            this.g.removeFirst();
                            continue;
                        }
                    }
                }
                break;
                break;
            } while (true);
        } else {
            this.b(var1_1);
            var4_6 = var5_2;
        }
        while (var4_6 < this.r.length) {
            this.r[var4_6] = true;
            ++var4_6;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(com.d.a.a.a.d d2) {
        long l2 = SystemClock.elapsedRealtime();
        long l3 = l2 - this.A;
        d2 = this.f.b;
        this.e.a((f)d2);
        if (d2 instanceof d) {
            d d3 = (d)d2;
            this.a(d2.c(), d3.h, d3.i, d3.j, d3.e, d3.f, l2, l3);
        } else {
            this.a(d2.c(), d2.h, d2.i, d2.j, -1, -1, l2, l3);
        }
        this.f.b = null;
        this.w = null;
        this.y = 0;
        this.g();
    }

    @Override
    public final void a(com.d.a.a.a.d d2, IOException iOException) {
        this.w = iOException;
        ++this.y;
        this.z = SystemClock.elapsedRealtime();
        if (this.k != null && this.b != null) {
            this.k.post((Runnable)new v(this, iOException));
        }
        this.g();
    }

    @Override
    public final long b(int n2) {
        if (this.r[n2 = this.e(n2)]) {
            this.r[n2] = false;
            return this.o;
        }
        return Long.MIN_VALUE;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean b() {
        boolean bl2 = this.m == 1 || this.m == 2;
        if (!bl2) {
            throw new IllegalStateException();
        }
        if (this.m == 2) {
            return true;
        }
        if (!this.e.b()) {
            return false;
        }
        if (this.e.c() > 0) {
            ((a)this.i.valueAt((int)1)).f = this.e.a(this.e.c() - 1);
            this.u = new g("Loader:" + this.e.a((int)0).b);
        }
        this.m = 2;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean b(int n2, long l2) {
        boolean bl2 = this.m == 2;
        if (!bl2) {
            throw new IllegalStateException();
        }
        if (!this.s[this.e(n2)]) {
            throw new IllegalStateException();
        }
        this.n = l2;
        this.e.a(l2);
        this.g();
        if (!this.v && ((a)this.i.get(this.e(n2))).b()) {
            return false;
        }
        return true;
    }

    @Override
    public final void b_() {
        if (this.w != null && this.y > this.l) {
            throw this.w;
        }
        if (this.f.b == null) {
            this.e.a();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int c() {
        if (this.m == 2) {
            return this.e.c();
        }
        boolean bl2 = false;
        if (!bl2) {
            throw new IllegalStateException();
        }
        return this.e.c();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void c(int n2) {
        block5 : {
            if (!this.s[n2 = this.e(n2)]) {
                throw new IllegalStateException();
            }
            --this.x;
            if (this.x != 0) return;
            this.m = 2;
            try {
                this.e.d();
                this.d.a(this);
                if (!this.u.b) break block5;
                this.u.a();
            }
            catch (Throwable var2_2) {
                this.d.a(this);
                if (this.u.b) {
                    this.u.a();
                    do {
                        throw var2_2;
                        break;
                    } while (true);
                }
                this.l();
                this.g.clear();
                this.f.b = null;
                this.w = null;
                this.y = 0;
                this.d.a();
                throw var2_2;
            }
            return;
        }
        this.l();
        this.g.clear();
        this.f.b = null;
        this.w = null;
        this.y = 0;
        this.d.a();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long d() {
        int n2 = 1;
        int n3 = this.m == 2 ? 1 : 0;
        if (n3 == 0) {
            throw new IllegalStateException();
        }
        n3 = this.x > 0 ? 1 : 0;
        if (n3 == 0) {
            throw new IllegalStateException();
        }
        n3 = this.p != Long.MIN_VALUE ? n2 : 0;
        if (n3 != 0) {
            return this.p;
        }
        if (this.v) {
            return -3;
        }
        n3 = 0;
        long l2 = Long.MIN_VALUE;
        while (n3 < this.i.size()) {
            l2 = Math.max(l2, ((a)this.i.valueAt((int)n3)).e);
            ++n3;
        }
        return this.n;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void e() {
        int n2 = this.c > 0 ? 1 : 0;
        if (n2 == 0) {
            throw new IllegalStateException();
        }
        this.c = n2 = this.c - 1;
        if (n2 == 0) {
            if (this.u != null) {
                this.u.b();
                this.u = null;
            }
            this.m = 0;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final com.d.a.a.w f() {
        boolean bl2 = this.m == 0 || this.c > 0 && this.m == 1;
        if (!bl2) {
            throw new IllegalStateException();
        }
        ++this.c;
        this.m = 1;
        return this;
    }

    @Override
    public final void j() {
        this.c(this.f.b.c());
        this.f.b = null;
        this.w = null;
        this.y = 0;
        if (this.x > 0) {
            this.b(this.p);
            return;
        }
        this.l();
        this.g.clear();
        this.f.b = null;
        this.w = null;
        this.y = 0;
        this.d.a();
    }
}

