/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.e;

import com.d.a.a.a.i;
import com.d.a.a.d.ah;
import com.d.a.a.d.b;
import com.d.a.a.e.c;
import com.d.a.a.e.d;
import com.d.a.a.e.f;
import com.d.a.a.e.g;
import com.d.a.a.e.h;
import com.d.a.a.f.a;
import com.d.a.a.f.j;
import com.d.a.a.f.m;
import com.d.a.a.q;
import java.util.List;

public final class z
extends d
implements g {
    private final h n;
    private final long o;
    private final int p;
    private final int q;
    private q r;
    private com.d.a.a.b.d s;
    private volatile int t;
    private volatile boolean u;

    public z(com.d.a.a.a.h h2, i i2, int n2, c c2, long l2, long l3, int n3, long l4, h h3, q q2, int n4, int n5, com.d.a.a.b.d d2, boolean bl2, int n6) {
        super(h2, i2, n2, c2, l2, l3, n3, bl2, n6);
        this.n = h3;
        this.o = l4;
        this.p = n4;
        this.q = n5;
        this.r = z.a(q2, l4, n4, n5);
        this.s = d2;
    }

    private static q a(q q2, long l2, int n2, int n3) {
        if (q2 == null) {
            return null;
        }
        if (l2 != 0 && q2.s != Long.MAX_VALUE) {
            long l3 = q2.s;
            q2 = new q(q2.a, q2.b, q2.c, q2.d, q2.e, q2.h, q2.i, q2.l, q2.m, q2.n, q2.o, q2.r, l3 + l2, q2.f, q2.g, q2.j, q2.k, q2.p, q2.q);
        }
        if (n2 != -1 || n3 != -1) {
            return new q(q2.a, q2.b, q2.c, q2.d, q2.e, q2.h, q2.i, q2.l, q2.m, q2.n, q2.o, q2.r, q2.s, q2.f, q2.g, n2, n3, q2.p, q2.q);
        }
        return q2;
    }

    @Override
    public final int a(m m2, int n2, boolean bl2) {
        return this.b.a(m2, n2, bl2);
    }

    @Override
    public final q a() {
        return this.r;
    }

    @Override
    public final void a(long l2, int n2, int n3, int n4, byte[] arrby) {
        this.b.a(this.o + l2, n2, n3, n4, arrby);
    }

    @Override
    public final void a(com.d.a.a.b.d d2) {
        this.s = d2;
    }

    @Override
    public final void a(b b2, int n2) {
        this.b.a(b2, n2);
    }

    @Override
    public final void a(j j2) {
    }

    @Override
    public final void a(q q2) {
        this.r = z.a(q2, this.o, this.p, this.q);
    }

    @Override
    public final com.d.a.a.b.d b() {
        return this.s;
    }

    @Override
    public final long c() {
        return this.t;
    }

    @Override
    public final void g() {
        this.u = true;
    }

    @Override
    public final boolean h() {
        return this.u;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final void i() {
        Object object = ah.a(this.k, this.t);
        object = new m(this.m, object.c, this.m.a((i)object));
        if (this.t == 0) {
            this.n.a(this, this.c);
        }
        int n2 = 0;
        while (n2 == 0) {
            if (this.u) break;
            n2 = this.n.a((m)object);
            continue;
        }
        this.t = (int)(object.d - this.k.c);
        return;
        catch (Throwable throwable) {
            this.t = (int)(object.d - this.k.c);
            throw throwable;
        }
        finally {
            this.m.a();
        }
    }
}

