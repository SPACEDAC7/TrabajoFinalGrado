/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.media.MediaCodec
 *  android.media.MediaCodec$CryptoInfo
 */
package com.d.a.a.f;

import android.media.MediaCodec;
import com.d.a.a.a.aa;
import com.d.a.a.d;
import com.d.a.a.d.ah;
import com.d.a.a.f.b;
import com.d.a.a.f.c;
import com.d.a.a.f.e;
import com.d.a.a.f.m;
import com.d.a.a.q;
import com.d.a.a.z;
import java.io.EOFException;
import java.nio.ByteBuffer;
import java.util.concurrent.LinkedBlockingDeque;

public class a
implements b {
    public final e a;
    final z b;
    boolean c;
    long d;
    public volatile long e;
    public volatile q f;
    private long g;

    public a(aa aa2) {
        this.a = new e(aa2);
        this.b = new z(0);
        this.c = true;
        this.d = Long.MIN_VALUE;
        this.g = Long.MIN_VALUE;
        this.e = Long.MIN_VALUE;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean c() {
        boolean bl2;
        e e2 = this.a;
        z z2 = this.b;
        boolean bl3 = bl2 = e2.c.a(z2, e2.e);
        if (this.c) {
            do {
                bl3 = bl2;
                if (!bl2) break;
                boolean bl4 = (this.b.d & 1) != 0;
                bl3 = bl2;
                if (bl4) break;
                e2 = this.a;
                e2.a(e2.c.a());
                e2 = this.a;
                z2 = this.b;
                bl2 = e2.c.a(z2, e2.e);
            } while (true);
        }
        if (!bl3 || this.g != Long.MIN_VALUE && this.b.e >= this.g) {
            return false;
        }
        return true;
    }

    @Override
    public final int a(m m2, int n2, boolean bl2) {
        e e2 = this.a;
        n2 = e2.a(n2);
        byte[] arrby = e2.i.a;
        com.d.a.a.a.b b2 = e2.i;
        int n3 = e2.j;
        if ((n2 = m2.a(arrby, b2.b + n3, n2)) == -1) {
            if (bl2) {
                return -1;
            }
            throw new EOFException();
        }
        e2.j += n2;
        e2.h += (long)n2;
        return n2;
    }

    public final void a() {
        e e2 = this.a;
        c c2 = e2.c;
        c2.e = 0;
        c2.f = 0;
        c2.g = 0;
        c2.d = 0;
        while (!e2.d.isEmpty()) {
            e2.a.a(e2.d.remove());
        }
        e2.g = 0;
        e2.h = 0;
        e2.i = null;
        e2.j = e2.b;
        this.c = true;
        this.d = Long.MIN_VALUE;
        this.g = Long.MIN_VALUE;
        this.e = Long.MIN_VALUE;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2) {
        long l2;
        int n3 = 0;
        e e2 = this.a;
        Object object = e2.c;
        int n4 = object.e + object.d - n2;
        n2 = n4 >= 0 && n4 <= object.d ? 1 : 0;
        if (n2 == 0) {
            throw new IllegalArgumentException();
        }
        if (n4 == 0) {
            if (object.e == 0) {
                l2 = 0;
            } else {
                n2 = object.g == 0 ? object.a : object.g;
                l2 = object.b[--n2];
                l2 = (long)object.c[n2] + l2;
            }
        } else {
            object.d -= n4;
            object.g = (object.g + object.a - n4) % object.a;
            l2 = object.b[object.g];
        }
        e2.h = l2;
        n4 = (int)(e2.h - e2.g);
        n2 = n4 / e2.b;
        n2 = e2.d.size() - n2 - 1;
        if ((n4 %= e2.b) == 0) {
            ++n2;
        }
        while (n3 < n2) {
            e2.a.a(e2.d.removeLast());
            ++n3;
        }
        e2.i = e2.d.peekLast();
        n2 = n4 == 0 ? e2.b : n4;
        e2.j = n2;
        e2 = this.a;
        object = this.b;
        l2 = e2.c.a((z)object, e2.e) ? this.b.e : Long.MIN_VALUE;
        this.e = l2;
    }

    @Override
    public void a(long l2, int n2, int n3, int n4, byte[] arrby) {
        this.e = Math.max(this.e, l2);
        e e2 = this.a;
        long l3 = this.a.h;
        long l4 = n3;
        long l5 = n4;
        e2.c.a(l2, n2, l3 - l4 - l5, n3, arrby);
    }

    @Override
    public final void a(com.d.a.a.d.b b2, int n2) {
        e e2 = this.a;
        while (n2 > 0) {
            int n3 = e2.a(n2);
            byte[] arrby = e2.i.a;
            com.d.a.a.a.b b3 = e2.i;
            int n4 = e2.j;
            b2.a(arrby, b3.b + n4, n3);
            e2.j += n3;
            e2.h += (long)n3;
            n2 -= n3;
        }
    }

    @Override
    public final void a(q q2) {
        this.f = q2;
    }

    public final boolean a(long l2) {
        e e2 = this.a;
        if ((l2 = e2.c.a(l2)) == -1) {
            return false;
        }
        e2.a(l2);
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean a(z z2) {
        if (!this.c()) {
            return false;
        }
        e e2 = this.a;
        if (e2.c.a(z2, e2.e)) {
            int[] arrn;
            int[] arrn2;
            long l2;
            int n2;
            int n3;
            int n4 = (z2.d & 2) != 0 ? 1 : 0;
            if (n4 != 0) {
                Object object;
                block17 : {
                    block16 : {
                        com.d.a.a.f.d d2 = e2.e;
                        l2 = d2.a;
                        e2.a(l2, e2.f.a, 1);
                        l2 = 1 + l2;
                        n2 = e2.f.a[0];
                        n4 = (n2 & 128) != 0 ? 1 : 0;
                        n2 &= 127;
                        if (z2.a.a == null) {
                            z2.a.a = new byte[16];
                        }
                        e2.a(l2, z2.a.a, n2);
                        l2 += (long)n2;
                        if (n4 != 0) {
                            e2.a(l2, e2.f.a, 2);
                            l2 += 2;
                            e2.f.b(0);
                            n2 = e2.f.b();
                        } else {
                            n2 = 1;
                        }
                        if ((arrn2 = z2.a.d) != null) {
                            arrn = arrn2;
                            if (arrn2.length >= n2) break block16;
                        }
                        arrn = new int[n2];
                    }
                    if ((object = z2.a.e) != null) {
                        arrn2 = object;
                        if (object.length >= n2) break block17;
                    }
                    arrn2 = new int[n2];
                }
                if (n4 != 0) {
                    n4 = n2 * 6;
                    object = e2.f;
                    if (object.c < n4) {
                        object.a = new byte[n4];
                        object.c = n4;
                        object.b = 0;
                    }
                    e2.a(l2, e2.f.a, n4);
                    long l3 = n4;
                    e2.f.b(0);
                    for (n4 = 0; n4 < n2; ++n4) {
                        arrn[n4] = e2.f.b();
                        arrn2[n4] = e2.f.k();
                    }
                    l2 += l3;
                } else {
                    arrn[0] = 0;
                    arrn2[0] = z2.c - (int)(l2 - d2.a);
                }
                object = z2.a;
                byte[] arrby = d2.b;
                byte[] arrby2 = z2.a.a;
                object.f = n2;
                object.d = arrn;
                object.e = arrn2;
                object.b = arrby;
                object.a = arrby2;
                object.c = 1;
                if (ah.a >= 16) {
                    object.g.set(object.f, object.d, object.e, object.b, object.a, object.c);
                }
                n4 = (int)(l2 - d2.a);
                d2.a += (long)n4;
                z2.c -= n4;
            }
            z2.a(z2.c);
            l2 = e2.e.a;
            arrn = z2.b;
            for (n4 = z2.c; n4 > 0; l2 += (long)n3, n4 -= n3) {
                e2.a(l2);
                n2 = (int)(l2 - e2.g);
                n3 = Math.min(n4, e2.b - n2);
                arrn2 = e2.d.peek();
                arrn.put(arrn2.a, arrn2.b + n2, n3);
            }
            e2.a(e2.c.a());
        }
        this.c = false;
        this.d = z2.e;
        return true;
    }

    public final boolean b() {
        if (!this.c()) {
            return true;
        }
        return false;
    }
}

