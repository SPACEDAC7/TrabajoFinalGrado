/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 */
package com.d.a.a.f.a;

import android.util.Pair;
import com.d.a.a.d.z;
import com.d.a.a.f.a.c;
import com.d.a.a.f.b;
import com.d.a.a.q;
import java.util.Collections;

final class a
extends c {
    private static final int[] c = new int[]{5500, 11000, 22000, 44000};
    private boolean d;
    private boolean e;

    public a(b b2) {
        super(b2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(com.d.a.a.d.b object, long l2) {
        int n2 = object.a();
        if (n2 == 0 && !this.e) {
            byte[] arrby = new byte[object.c - object.b];
            object.a(arrby, 0, arrby.length);
            object = z.a(arrby);
            object = q.a(null, "audio/mp4a-latm", -1, -1, this.b, (Integer)object.second, (Integer)object.first, Collections.singletonList(arrby), null);
            this.a.a((q)object);
            this.e = true;
            return;
        } else {
            if (n2 != 1) return;
            {
                n2 = object.c - object.b;
                this.a.a((com.d.a.a.d.b)object, n2);
                this.a.a(l2, 1, n2, 0, null);
                return;
            }
        }
    }

    @Override
    protected final boolean a(com.d.a.a.d.b b2) {
        if (!this.d) {
            int n2 = b2.a();
            int n3 = n2 >> 4 & 15;
            if ((n2 = n2 >> 2 & 3) < 0 || n2 >= c.length) {
                throw new com.d.a.a.f.a.b("Invalid sample rate index: " + n2);
            }
            if (n3 != 10) {
                throw new com.d.a.a.f.a.b("Audio format not supported: " + n3);
            }
            this.d = true;
            return true;
        }
        b2.b(b2.b + 1);
        return true;
    }
}

