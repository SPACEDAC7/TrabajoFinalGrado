/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.a;

import com.d.a.a.bb;

public final class b
extends bb {
    public b(String string) {
        super(string);
    }
}

