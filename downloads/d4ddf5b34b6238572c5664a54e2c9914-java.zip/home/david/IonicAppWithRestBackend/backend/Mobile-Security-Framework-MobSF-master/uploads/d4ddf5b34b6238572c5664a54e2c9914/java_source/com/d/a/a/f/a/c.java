/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.a;

import com.d.a.a.f.b;

public abstract class c {
    protected final b a;
    long b;

    protected c(b b2) {
        this.a = b2;
        this.b = -1;
    }

    protected abstract void a(com.d.a.a.d.b var1, long var2);

    protected abstract boolean a(com.d.a.a.d.b var1);

    public final void b(com.d.a.a.d.b b2, long l2) {
        if (this.a(b2)) {
            this.a(b2, l2);
        }
    }
}

