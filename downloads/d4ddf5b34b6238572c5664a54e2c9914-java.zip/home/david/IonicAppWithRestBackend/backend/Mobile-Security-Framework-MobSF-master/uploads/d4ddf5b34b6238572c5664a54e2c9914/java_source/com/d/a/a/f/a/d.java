/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.a;

import com.d.a.a.d.ah;
import com.d.a.a.f.a.a;
import com.d.a.a.f.a.c;
import com.d.a.a.f.a.f;
import com.d.a.a.f.b;
import com.d.a.a.f.g;
import com.d.a.a.f.h;
import com.d.a.a.f.j;
import com.d.a.a.f.k;
import com.d.a.a.f.m;

public final class d
implements h,
j {
    private static final int e = ah.e("FLV");
    public int b;
    public int c;
    public long d;
    private final com.d.a.a.d.b f = new com.d.a.a.d.b(4);
    private final com.d.a.a.d.b g = new com.d.a.a.d.b(9);
    private final com.d.a.a.d.b h = new com.d.a.a.d.b(11);
    private final com.d.a.a.d.b i = new com.d.a.a.d.b();
    private g j;
    private int k = 1;
    private int l;
    private a m;
    private f n;
    private com.d.a.a.f.a.g o;

    /*
     * Enabled aggressive block sorting
     */
    private com.d.a.a.d.b b(m m2) {
        int n2 = this.c;
        com.d.a.a.d.b b2 = this.i;
        int n3 = b2.a == null ? 0 : b2.a.length;
        if (n2 > n3) {
            b2 = this.i;
            com.d.a.a.d.b b3 = this.i;
            n3 = b3.a == null ? 0 : b3.a.length;
            b2.a = new byte[Math.max(n3 * 2, this.c)];
            b2.c = 0;
            b2.b = 0;
        } else {
            this.i.b(0);
        }
        this.i.a(this.c);
        m2.b(this.i.a, 0, this.c);
        return this.i;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(m var1_1, k var2_2) {
        block6 : do {
            switch (this.k) {
                default: {
                    continue block6;
                }
                case 1: {
                    if (!var1_1.a(this.g.a, 0, 9, true)) {
                        return -1;
                    }
                    this.g.b(0);
                    var2_2 = this.g;
                    var2_2.b(var2_2.b + 4);
                    var4_4 = this.g.a();
                    var3_3 = (var4_4 & 4) != 0;
                    var4_4 = (var4_4 & 1) != 0 ? 1 : 0;
                    if (!var3_3) ** GOTO lbl-1000
                    if (this.m == null) {
                        this.m = new a(this.j.a_(8));
                    }
                    if (var4_4 != 0) lbl-1000: // 2 sources:
                    {
                        if (this.n == null) {
                            this.n = new f(this.j.a_(9));
                        }
                    }
                    if (this.o == null) {
                        this.o = new com.d.a.a.f.a.g();
                    }
                    this.j.a();
                    this.j.a(this);
                    this.l = this.g.g() - 9 + 4;
                    this.k = 2;
                    var3_3 = true;
                    if (var3_3) continue block6;
                    return -1;
                }
                case 2: {
                    var1_1.b(this.l);
                    this.l = 0;
                    this.k = 3;
                    continue block6;
                }
                case 3: {
                    if (!var1_1.a(this.h.a, 0, 11, true)) {
                        return -1;
                    }
                    this.h.b(0);
                    this.b = this.h.a();
                    this.c = this.h.d();
                    this.d = this.h.d();
                    this.d = ((long)(this.h.a() << 24) | this.d) * 1000;
                    var2_2 = this.h;
                    var2_2.b(var2_2.b + 3);
                    this.k = 4;
                    var3_3 = true;
                    if (var3_3) continue block6;
                    return -1;
                }
                case 4: 
            }
            if (this.b != 8 || this.m == null) ** GOTO lbl53
            this.m.b(this.b(var1_1), this.d);
            var3_3 = true;
            ** GOTO lbl70
lbl53: // 1 sources:
            if (this.b != 9 || this.n == null) ** GOTO lbl57
            this.n.b(this.b(var1_1), this.d);
            var3_3 = true;
            ** GOTO lbl70
lbl57: // 1 sources:
            if (this.b != 18 || this.o == null) ** GOTO lbl66
            this.o.b(this.b(var1_1), this.d);
            if (this.o.b == -1) ** GOTO lbl69
            if (this.m != null) {
                this.m.b = this.o.b;
            }
            if (this.n == null) ** GOTO lbl69
            this.n.b = this.o.b;
            var3_3 = true;
            ** GOTO lbl70
lbl66: // 1 sources:
            var1_1.b(this.c);
            var3_3 = false;
            ** GOTO lbl70
lbl69: // 2 sources:
            var3_3 = true;
lbl70: // 5 sources:
            this.l = 4;
            this.k = 2;
            if (var3_3) return 0;
        } while (true);
    }

    @Override
    public final long a(long l2) {
        return 0;
    }

    @Override
    public final void a(g g2) {
        this.j = g2;
    }

    @Override
    public final boolean a() {
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final boolean a(m m2) {
        m2.c(this.f.a, 0, 3);
        this.f.b(0);
        if (this.f.d() != e) {
            return false;
        }
        m2.c(this.f.a, 0, 2);
        this.f.b(0);
        if ((this.f.b() & 250) != 0) return false;
        m2.c(this.f.a, 0, 4);
        this.f.b(0);
        int n2 = this.f.g();
        m2.a();
        m2.c(n2);
        m2.c(this.f.a, 0, 4);
        this.f.b(0);
        if (this.f.g() != 0) return false;
        return true;
    }

    @Override
    public final void c_() {
        this.k = 1;
        this.l = 0;
    }
}

