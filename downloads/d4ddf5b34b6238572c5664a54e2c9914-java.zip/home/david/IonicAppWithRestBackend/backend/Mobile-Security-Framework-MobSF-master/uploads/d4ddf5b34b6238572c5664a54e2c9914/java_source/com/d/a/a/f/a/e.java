/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.a;

import java.util.List;

final class e {
    public final List<byte[]> a;
    public final int b;
    public final float c;
    public final int d;
    public final int e;

    public e(List<byte[]> list, int n2, int n3, int n4, float f2) {
        this.a = list;
        this.b = n2;
        this.c = f2;
        this.d = n3;
        this.e = n4;
    }
}

