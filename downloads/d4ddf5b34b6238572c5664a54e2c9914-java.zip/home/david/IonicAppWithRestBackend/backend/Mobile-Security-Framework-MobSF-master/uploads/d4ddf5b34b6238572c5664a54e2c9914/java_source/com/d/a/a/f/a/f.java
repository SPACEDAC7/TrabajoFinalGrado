/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.a;

import com.d.a.a.d.o;
import com.d.a.a.f.a.b;
import com.d.a.a.f.a.c;
import com.d.a.a.f.a.e;
import com.d.a.a.q;
import java.util.ArrayList;
import java.util.List;

final class f
extends c {
    private final com.d.a.a.d.b c = new com.d.a.a.d.b(com.d.a.a.d.q.a);
    private final com.d.a.a.d.b d = new com.d.a.a.d.b(4);
    private int e;
    private boolean f;
    private int g;

    public f(com.d.a.a.f.b b2) {
        super(b2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void a(com.d.a.a.d.b object, long l2) {
        int n2;
        int n3 = object.a();
        long l3 = object.d();
        if (n3 == 0 && !this.f) {
            Object object2 = new com.d.a.a.d.b(new byte[object.c - object.b]);
            object.a(object2.a, 0, object.c - object.b);
            object2.b(4);
            int n4 = (object2.a() & 3) + 1;
            n3 = n4 != 3 ? 1 : 0;
            if (n3 == 0) {
                throw new IllegalStateException();
            }
            object = new ArrayList<byte[]>();
            int n5 = object2.a() & 31;
            for (n3 = 0; n3 < n5; ++n3) {
                object.add((byte[])com.d.a.a.d.q.a((com.d.a.a.d.b)object2));
            }
            int n6 = object2.a();
            for (n3 = 0; n3 < n6; ++n3) {
                object.add((byte[])com.d.a.a.d.q.a((com.d.a.a.d.b)object2));
            }
            float f2 = 1.0f;
            n3 = -1;
            n6 = -1;
            if (n5 > 0) {
                object2 = new com.d.a.a.d.c((byte[])object.get(0));
                object2.a((n4 + 1) * 8);
                object2 = com.d.a.a.d.q.a((com.d.a.a.d.c)object2);
                n3 = object2.b;
                n6 = object2.c;
                f2 = object2.d;
            }
            object = new e((List<byte[]>)object, n4, n3, n6, f2);
            this.e = object.b;
            object = q.a(null, "video/avc", -1, -1, this.b, object.d, object.e, object.a, -1, object.c);
            this.a.a((q)object);
            this.f = true;
            return;
        }
        if (n3 != 1) return;
        {
            byte[] arrby = this.d.a;
            arrby[0] = 0;
            arrby[1] = 0;
            arrby[2] = 0;
            n2 = this.e;
            n3 = 0;
            while (object.c - object.b > 0) {
                object.a(this.d.a, 4 - n2, this.e);
                this.d.b(0);
                int n7 = this.d.k();
                this.c.b(0);
                this.a.a(this.c, 4);
                this.a.a((com.d.a.a.d.b)object, n7);
                n3 = n3 + 4 + n7;
            }
        }
        object = this.a;
        n2 = this.g == 1 ? 1 : 0;
        object.a(l3 * 1000 + l2, n2, n3, 0, null);
    }

    @Override
    protected final boolean a(com.d.a.a.d.b b2) {
        int n2 = b2.a();
        int n3 = n2 >> 4 & 15;
        if ((n2 &= 15) != 7) {
            throw new b("Video format not supported: " + n2);
        }
        this.g = n3;
        if (n3 != 5) {
            return true;
        }
        return false;
    }
}

