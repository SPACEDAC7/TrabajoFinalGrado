/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.a;

import com.d.a.a.bb;
import com.d.a.a.f.a.c;
import com.d.a.a.f.b;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public final class g
extends c {
    public g() {
        super(null);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object a(com.d.a.a.d.b b2, int n2) {
        boolean bl2 = true;
        switch (n2) {
            default: {
                return null;
            }
            case 0: {
                return Double.longBitsToDouble(b2.i());
            }
            case 1: {
                if (b2.a() == 1) {
                    do {
                        return bl2;
                        break;
                    } while (true);
                }
                bl2 = false;
                return bl2;
            }
            case 2: {
                return g.b(b2);
            }
            case 3: {
                HashMap<String, Object> hashMap = new HashMap<String, Object>();
                do {
                    String string = g.b(b2);
                    n2 = b2.a();
                    HashMap<String, Object> hashMap2 = hashMap;
                    if (n2 == 9) return hashMap2;
                    hashMap.put(string, g.a(b2, n2));
                } while (true);
            }
            case 8: {
                return g.d(b2);
            }
            case 10: {
                int n3 = b2.k();
                ArrayList<Object> arrayList = new ArrayList<Object>(n3);
                n2 = 0;
                while (n2 < n3) {
                    arrayList.add(g.a(b2, b2.a()));
                    ++n2;
                }
                return arrayList;
            }
            case 11: 
        }
        Date date = new Date((long)Double.valueOf(Double.longBitsToDouble(b2.i())).doubleValue());
        b2.b(b2.b + 2);
        return date;
    }

    private static String b(com.d.a.a.d.b b2) {
        int n2 = b2.b();
        int n3 = b2.b;
        b2.b(b2.b + n2);
        return new String(b2.a, n3, n2);
    }

    private static HashMap<String, Object> d(com.d.a.a.d.b b2) {
        int n2 = b2.k();
        HashMap<String, Object> hashMap = new HashMap<String, Object>(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            hashMap.put(g.b(b2), g.a(b2, b2.a()));
        }
        return hashMap;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final void a(com.d.a.a.d.b hashMap, long l2) {
        if (hashMap.a() != 2) {
            throw new bb();
        }
        if (!"onMetaData".equals(g.b(hashMap))) {
            return;
        }
        if (hashMap.a() != 8) {
            throw new bb();
        }
        if (!(hashMap = g.d(hashMap)).containsKey("duration")) return;
        double d2 = (Double)hashMap.get("duration");
        if (d2 <= 0.0) return;
        this.b = (long)(d2 * 1000000.0);
    }

    @Override
    protected final boolean a(com.d.a.a.d.b b2) {
        return true;
    }
}

