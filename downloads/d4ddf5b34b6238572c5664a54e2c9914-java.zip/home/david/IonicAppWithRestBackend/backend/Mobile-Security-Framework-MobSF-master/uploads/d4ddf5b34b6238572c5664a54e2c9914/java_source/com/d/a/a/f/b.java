/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.f.m;
import com.d.a.a.q;

public interface b {
    public int a(m var1, int var2, boolean var3);

    public void a(long var1, int var3, int var4, int var5, byte[] var6);

    public void a(com.d.a.a.d.b var1, int var2);

    public void a(q var1);
}

