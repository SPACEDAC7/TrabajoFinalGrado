/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.b;

import com.d.a.a.f.b.b;

final class a
implements b {
    private final long b;
    private final int c;
    private final long d;

    /*
     * Enabled aggressive block sorting
     */
    public a(long l2, int n2, long l3) {
        long l4 = -1;
        this.b = l2;
        this.c = n2;
        l2 = l3 == -1 ? l4 : this.b(l3);
        this.d = l2;
    }

    @Override
    public final long a(long l2) {
        if (this.d == -1) {
            return 0;
        }
        return this.b + (long)this.c * l2 / 8000000;
    }

    @Override
    public final boolean a() {
        if (this.d != -1) {
            return true;
        }
        return false;
    }

    @Override
    public final long b() {
        return this.d;
    }

    @Override
    public final long b(long l2) {
        return Math.max(0, l2 - this.b) * 1000000 * 8 / (long)this.c;
    }
}

