/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.b;

import com.d.a.a.f.j;

interface b
extends j {
    public long b();

    public long b(long var1);
}

