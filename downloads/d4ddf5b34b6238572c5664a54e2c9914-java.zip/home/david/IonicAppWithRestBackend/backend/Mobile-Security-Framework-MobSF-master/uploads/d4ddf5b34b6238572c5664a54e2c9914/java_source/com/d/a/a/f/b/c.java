/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.b;

import com.d.a.a.bb;
import com.d.a.a.d.ah;
import com.d.a.a.d.n;
import com.d.a.a.f.b.a;
import com.d.a.a.f.b.b;
import com.d.a.a.f.b.d;
import com.d.a.a.f.b.e;
import com.d.a.a.f.b.f;
import com.d.a.a.f.g;
import com.d.a.a.f.h;
import com.d.a.a.f.j;
import com.d.a.a.f.k;
import com.d.a.a.f.m;
import com.d.a.a.f.v;
import com.d.a.a.q;
import java.io.EOFException;

public final class c
implements h {
    private static final int a = ah.e("Xing");
    private static final int b = ah.e("Info");
    private static final int c = ah.e("VBRI");
    private final long d = -1;
    private final com.d.a.a.d.b e = new com.d.a.a.d.b(4);
    private final n f = new n();
    private g g;
    private com.d.a.a.f.b h;
    private int i;
    private v j;
    private b k;
    private long l = -1;
    private int m;
    private int n;

    public c() {
        this(0);
    }

    private c(byte by2) {
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean a(m m2, boolean bl2) {
        int n2;
        int n3;
        int n4;
        int n5;
        m2.a();
        if (m2.d == 0) {
            this.j = d.a(m2);
            n4 = (int)m2.b();
            if (!bl2) {
                m2.b(n4);
            }
            n5 = 0;
            n3 = 0;
            n2 = 0;
        } else {
            n4 = 0;
            n5 = 0;
            n3 = 0;
            n2 = 0;
        }
        do {
            int n6;
            if (bl2 && n2 == 4096) {
                return false;
            }
            if (!bl2 && n2 == 131072) {
                throw new bb("Searched too many bytes.");
            }
            if (!m2.b(this.e.a, 0, 4, true)) {
                return false;
            }
            this.e.b(0);
            int n7 = this.e.g();
            if (n5 != 0 && (n7 & -128000) != (n5 & -128000) || (n6 = n.a(n7)) == -1) {
                n5 = n2 + 1;
                if (bl2) {
                    m2.a();
                    m2.c(n4 + n5);
                    n7 = 0;
                    n3 = 0;
                    n2 = n5;
                    n5 = n7;
                    continue;
                }
                m2.b(1);
                n7 = 0;
                n3 = 0;
                n2 = n5;
                n5 = n7;
                continue;
            }
            if (++n3 == 1) {
                n.a(n7, this.f);
                n5 = n7;
            } else if (n3 == 4) break;
            m2.c(n6 - 4);
        } while (true);
        if (bl2) {
            m2.b(n4 + n2);
        } else {
            m2.a();
        }
        this.i = n5;
        return true;
    }

    private boolean b(m m2) {
        try {
            boolean bl2 = this.a(m2, false);
            return bl2;
        }
        catch (EOFException var1_2) {
            return false;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int a(m m2, k object) {
        long l2;
        long l3;
        int n2;
        if (this.i == 0 && !this.b(m2)) {
            return -1;
        }
        if (this.k == null) {
            q q2;
            object = new com.d.a.a.d.b(this.f.c);
            m2.c(object.a, 0, this.f.c);
            l2 = m2.d;
            l3 = m2.c;
            n2 = (this.f.a & 1) != 0 ? (this.f.e != 1 ? 36 : 21) : (this.f.e != 1 ? 21 : 13);
            object.b(n2);
            int n3 = object.g();
            if (n3 == a || n3 == b) {
                this.k = f.a(this.f, (com.d.a.a.d.b)object, l2, l3);
                if (this.k != null && this.j == null) {
                    m2.a();
                    m2.c(n2 + 141);
                    m2.c(this.e.a, 0, 3);
                    this.e.b(0);
                    n3 = this.e.d();
                    n2 = n3 >> 12;
                    object = n2 == 0 && n3 == 0 ? null : new v(n2, n3 &= 4095);
                    this.j = object;
                }
                m2.b(this.f.c);
            } else {
                object.b(36);
                if (object.g() == c) {
                    this.k = e.a(this.f, (com.d.a.a.d.b)object, l2, l3);
                    m2.b(this.f.c);
                }
            }
            if (this.k == null) {
                m2.a();
                m2.c(this.e.a, 0, 4);
                this.e.b(0);
                n.a(this.e.g(), this.f);
                this.k = new a(m2.d, this.f.f, l3);
            }
            this.g.a(this.k);
            object = q2 = q.a(null, this.f.b, -1, 4096, this.k.b(), this.f.e, this.f.d, null, null);
            if (this.j != null) {
                object = q2.a(this.j.a, this.j.b);
            }
            this.h.a((q)object);
        }
        if (this.n == 0) {
            boolean bl2;
            m2.a();
            if (!m2.b(this.e.a, 0, 4, true)) {
                return -1;
            }
            this.e.b(0);
            n2 = this.e.g();
            if ((-128000 & n2) == (this.i & -128000) && n.a(n2) != -1) {
                n.a(n2, this.f);
                bl2 = true;
            } else {
                this.i = 0;
                m2.b(1);
                bl2 = this.b(m2);
            }
            if (!bl2) {
                return -1;
            }
            if (this.l == -1) {
                this.l = this.k.b(m2.d);
                if (this.d != -1) {
                    l2 = this.k.b(0);
                    l3 = this.l;
                    this.l = this.d - l2 + l3;
                }
            }
            this.n = this.f.c;
        }
        if ((n2 = this.h.a(m2, this.n, true)) == -1) {
            return -1;
        }
        this.n -= n2;
        if (this.n > 0) {
            return 0;
        }
        l2 = this.l;
        l3 = (long)this.m * 1000000 / (long)this.f.d;
        this.h.a(l3 + l2, 1, this.f.c, 0, null);
        this.m += this.f.g;
        this.n = 0;
        return 0;
    }

    @Override
    public final void a(g g2) {
        this.g = g2;
        this.h = g2.a_(0);
        g2.a();
    }

    @Override
    public final boolean a(m m2) {
        return this.a(m2, true);
    }

    @Override
    public final void c_() {
        this.i = 0;
        this.m = 0;
        this.l = -1;
        this.n = 0;
    }
}

