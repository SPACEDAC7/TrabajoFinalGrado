/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 */
package com.d.a.a.f.b;

import android.util.Pair;
import com.d.a.a.d.ah;
import com.d.a.a.d.b;
import com.d.a.a.f.m;
import com.d.a.a.f.v;
import java.nio.charset.Charset;

final class d {
    private static final int a = ah.e("ID3");
    private static final Charset[] b = new Charset[]{Charset.forName("ISO-8859-1"), Charset.forName("UTF-16LE"), Charset.forName("UTF-16BE"), Charset.forName("UTF-8")};

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static v a(m var0) {
        var9_1 = new b(10);
        var2_2 = 0;
        var8_3 = null;
        do {
            block17 : {
                var0.c(var9_1.a, 0, 10);
                var9_1.b(0);
                if (var9_1.d() != d.a) {
                    var0.a();
                    var0.c(var2_2);
                    return var8_3;
                }
                var5_7 = var9_1.a();
                var1_4 = var9_1.a();
                var7_9 = var9_1.a();
                var6_8 = var9_1.j();
                if (var8_3 != null) ** GOTO lbl62
                var1_4 = !(var1_4 == 255 || var5_7 < 2 || var5_7 > 4 || var6_8 > 3145728 || var5_7 == 2 && ((var7_9 & 63) != 0 || (var7_9 & 64) != 0) || var5_7 == 3 && (var7_9 & 31) != 0 || var5_7 == 4 && (var7_9 & 15) != 0) ? 1 : 0;
                if (var1_4 == 0) ** GOTO lbl62
                var8_3 = new byte[var6_8];
                var0.c((byte[])var8_3, 0, var6_8);
                var10_10 = new b((byte[])var8_3);
                if (var5_7 != 4) {
                    if ((var7_9 & 128) != 0) {
                        var8_3 = var10_10.a;
                        var3_5 = var8_3.length;
                        var1_4 = 0;
                        while (var1_4 + 1 < var3_5) {
                            var4_6 = var3_5;
                            if ((var8_3[var1_4] & 255) == 255) {
                                var4_6 = var3_5;
                                if (var8_3[var1_4 + 1] == 0) {
                                    System.arraycopy((Object)var8_3, var1_4 + 2, (Object)var8_3, var1_4 + 1, var3_5 - var1_4 - 2);
                                    var4_6 = var3_5 - 1;
                                }
                            }
                            ++var1_4;
                            var3_5 = var4_6;
                        }
                        var10_10.a(var3_5);
                    }
                } else if (d.a(var10_10, false)) {
                    d.b(var10_10, false);
                } else if (d.a(var10_10, true)) {
                    d.b(var10_10, true);
                }
                var10_10.b(0);
                if (var5_7 != 3 || (var7_9 & 64) == 0) ** GOTO lbl54
                if (var10_10.c - var10_10.b < 4 || (var1_4 = var10_10.k()) > var10_10.c - var10_10.b) ** GOTO lbl99
                if (var1_4 < 6) ** GOTO lbl52
                var10_10.b(var10_10.b + 2);
                var3_5 = var10_10.k();
                var10_10.b(4);
                var10_10.a(var10_10.c - var3_5);
                if (var10_10.c - var10_10.b < var1_4) ** GOTO lbl99
lbl52: // 2 sources:
                var10_10.b(var1_4 + var10_10.b);
                ** GOTO lbl64
lbl54: // 1 sources:
                if (var5_7 != 4 || (var7_9 & 64) == 0) ** GOTO lbl64
                if (var10_10.c - var10_10.b < 4) ** GOTO lbl99
                var1_4 = var10_10.j();
                if (var1_4 >= 6 && var1_4 <= var10_10.c - var10_10.b + 4) ** GOTO lbl60
                var8_3 = null;
                ** GOTO lbl101
lbl60: // 1 sources:
                var10_10.b(var1_4);
                ** GOTO lbl64
lbl62: // 2 sources:
                var0.c(var6_8);
                ** GOTO lbl101
lbl64: // 3 sources:
                do {
                    if (var5_7 != 2) ** GOTO lbl74
                    if (var10_10.c - var10_10.b < 6 || (var8_3 = var10_10.a(3, Charset.forName("US-ASCII"))).equals("\u0000\u0000\u0000")) ** GOTO lbl-1000
                    var3_5 = var10_10.d();
                    if (var3_5 != 0 && var3_5 <= var10_10.c - var10_10.b) ** GOTO lbl71
                    var8_3 = null;
                    ** GOTO lbl95
lbl71: // 1 sources:
                    var1_4 = var3_5;
                    if (var8_3.equals("COM")) ** GOTO lbl87
                    ** GOTO lbl-1000
lbl74: // 1 sources:
                    if (var10_10.c - var10_10.b < 10 || (var8_3 = var10_10.a(4, Charset.forName("US-ASCII"))).equals("\u0000\u0000\u0000\u0000")) ** GOTO lbl-1000
                    var1_4 = var5_7 == 4 ? var10_10.j() : var10_10.k();
                    if (var1_4 != 0 && var1_4 <= var10_10.c - var10_10.b - 2) ** GOTO lbl79
                    var8_3 = null;
                    ** GOTO lbl95
lbl79: // 1 sources:
                    var3_5 = var10_10.b();
                    var4_6 = var5_7 == 4 && (var3_5 & 12) != 0 || var5_7 == 3 && (var3_5 & 192) != 0 ? 1 : 0;
                    var3_5 = var1_4;
                    if (var4_6 != 0) ** GOTO lbl-1000
                    var3_5 = var1_4;
                    if (!var8_3.equals("COMM")) lbl-1000: // 3 sources:
                    {
                        var10_10.b(var3_5 + var10_10.b);
                        continue;
                    }
lbl87: // 3 sources:
                    if ((var3_5 = var10_10.a()) < 0 || var3_5 >= d.b.length) {
                        var8_3 = null;
                    } else {
                        var8_3 = var10_10.a(var1_4 - 1, d.b[var3_5]).split("\u0000");
                        if (var8_3.length == 2) {
                            var8_3 = Pair.create((Object)var8_3[0], (Object)var8_3[1]);
                        } else lbl-1000: // 3 sources:
                        {
                            var8_3 = null;
                        }
                    }
lbl95: // 5 sources:
                    if (var8_3 == null) break block17;
                    if (((String)var8_3.first).length() > 3 && (var8_3 = v.a(((String)var8_3.first).substring(3), (String)var8_3.second)) != null) break;
                } while (true);
                ** GOTO lbl101
            }
            var8_3 = null;
lbl101: // 4 sources:
            var2_2 += var6_8 + 10;
        } while (true);
    }

    private static boolean a(b b2, boolean bl2) {
        b2.b(0);
        while (b2.c - b2.b >= 10) {
            long l2;
            if (b2.g() == 0) {
                return true;
            }
            long l3 = l2 = b2.e();
            if (!bl2) {
                if ((0x808080 & l2) != 0) {
                    return false;
                }
                l3 = (l2 >> 24 & 127) << 21 | (l2 & 127 | (l2 >> 8 & 127) << 7 | (l2 >> 16 & 127) << 14);
            }
            if (l3 > (long)(b2.c - b2.b - 2)) {
                return false;
            }
            if ((b2.b() & 1) != 0 && b2.c - b2.b < 4) {
                return false;
            }
            b2.b((int)l3 + b2.b);
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void b(b b2, boolean bl2) {
        b2.b(0);
        byte[] arrby = b2.a;
        while (b2.c - b2.b >= 10 && b2.g() != 0) {
            int n2;
            int n3;
            int n4 = bl2 ? b2.k() : b2.j();
            int n5 = b2.b();
            if ((n5 & 1) != 0) {
                n3 = b2.b;
                System.arraycopy(arrby, n3 + 4, arrby, n3, b2.c - b2.b - 4);
                n4 -= 4;
                n3 = n5 & -2;
                b2.a(b2.c - 4);
            } else {
                n3 = n5;
            }
            if ((n3 & 2) != 0) {
                n2 = b2.b + 1;
                int n6 = 0;
                int n7 = n2;
                while (n6 + 1 < n4) {
                    int n8 = n2;
                    int n9 = n4;
                    if ((arrby[n2 - 1] & 255) == 255) {
                        n8 = n2;
                        n9 = n4;
                        if (arrby[n2] == 0) {
                            n8 = n2 + 1;
                            n9 = n4 - 1;
                        }
                    }
                    arrby[n7] = arrby[n8];
                    ++n6;
                    ++n7;
                    n2 = n8 + 1;
                    n4 = n9;
                }
                b2.a(b2.c - (n2 - n7));
                System.arraycopy(arrby, n2, arrby, n7, b2.c - b2.b - n2);
                n3 &= -3;
            }
            if (n3 != n5 || bl2) {
                n2 = b2.b - 6;
                arrby[n2] = (byte)(n4 >> 21 & 127);
                arrby[n2 + 1] = (byte)(n4 >> 14 & 127);
                arrby[n2 + 2] = (byte)(n4 >> 7 & 127);
                arrby[n2 + 3] = (byte)(n4 & 127);
                arrby[n2 + 4] = (byte)(n3 >> 8);
                arrby[n2 + 5] = (byte)(n3 & 255);
            }
            b2.b(b2.b + n4);
        }
        return;
    }
}

