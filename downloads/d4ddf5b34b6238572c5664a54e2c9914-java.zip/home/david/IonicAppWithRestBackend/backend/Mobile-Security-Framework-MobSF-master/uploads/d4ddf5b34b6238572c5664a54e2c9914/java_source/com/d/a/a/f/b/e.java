/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.b;

import com.d.a.a.d.ah;
import com.d.a.a.d.n;
import com.d.a.a.f.b.b;

final class e
implements b {
    private final long[] b;
    private final long[] c;
    private final long d;

    private e(long[] arrl, long[] arrl2, long l2) {
        this.b = arrl;
        this.c = arrl2;
        this.d = l2;
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static e a(n var0, com.d.a.a.d.b var1_1, long var2_2, long var4_3) {
        var1_1.b(var1_1.b + 10);
        var6_4 = var1_1.g();
        if (var6_4 <= 0) {
            return null;
        }
        var7_5 = var0.d;
        var11_6 = var6_4;
        if (var7_5 < 32000) ** GOTO lbl24
        var6_4 = 1152;
        block6 : do {
            var13_7 = ah.a(var11_6, (long)var6_4 * 1000000, var7_5);
            var8_8 = var1_1.b();
            var9_9 = var1_1.b();
            var10_10 = var1_1.b();
            var1_1.b(var1_1.b + 2);
            var0 = new long[var8_8 + 1];
            var15_11 = new long[var8_8 + 1];
            var0[0] = 0;
            var15_11[0] = var2_2 += (long)var0.c;
            var7_5 = 1;
lbl20: // 2 sources:
            if (var7_5 >= var0.length) return new e(var0, var15_11, var13_7);
            switch (var10_10) {
                default: {
                    return null;
                }
lbl24: // 1 sources:
                var6_4 = 576;
                continue block6;
                case 1: {
                    var6_4 = var1_1.a();
lbl28: // 4 sources:
                    do {
                        var2_2 += (long)(var6_4 * var9_9);
                        var0[var7_5] = (long)var7_5 * var13_7 / (long)var8_8;
                        if (var4_3 != -1) break block6;
                        var11_6 = var2_2;
lbl33: // 2 sources:
                        do {
                            var15_11[var7_5] = var11_6;
                            ++var7_5;
                            ** GOTO lbl20
                            break;
                        } while (true);
                        break;
                    } while (true);
                }
                case 2: {
                    var6_4 = var1_1.b();
                    ** GOTO lbl28
                }
                case 3: {
                    var6_4 = var1_1.d();
                    ** GOTO lbl28
                }
                case 4: {
                    var6_4 = var1_1.k();
                    ** continue;
                }
            }
            break;
        } while (true);
        var11_6 = Math.min(var4_3, var2_2);
        ** while (true)
    }

    @Override
    public final long a(long l2) {
        return this.c[ah.a(this.b, l2, true)];
    }

    @Override
    public final boolean a() {
        return true;
    }

    @Override
    public final long b() {
        return this.d;
    }

    @Override
    public final long b(long l2) {
        return this.b[ah.a(this.c, l2, true)];
    }
}

