/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.b;

import com.d.a.a.d.ah;
import com.d.a.a.d.n;
import com.d.a.a.f.b.b;

final class f
implements b {
    private final long b;
    private final long c;
    private final long d;
    private final long[] e;
    private final long f;
    private final int g;

    private f(long l2, long l3, long l4) {
        this(l2, l3, l4, null, 0, 0);
    }

    private f(long l2, long l3, long l4, long[] arrl, long l5, int n2) {
        this.b = l2;
        this.c = l3;
        this.d = l4;
        this.e = arrl;
        this.f = l5;
        this.g = n2;
    }

    public static f a(n n2, com.d.a.a.d.b b2, long l2, long l3) {
        int n3;
        int n4 = n2.g;
        int n5 = n2.d;
        l2 += (long)n2.c;
        int n6 = b2.g();
        if ((n6 & 1) != 1 || (n3 = b2.k()) == 0) {
            return null;
        }
        long l4 = ah.a(n3, (long)n4 * 1000000, n5);
        if ((n6 & 6) != 6) {
            return new f(l2, l4, l3);
        }
        long l5 = b2.k();
        b2.b(b2.b + 1);
        long[] arrl = new long[99];
        for (n4 = 0; n4 < 99; ++n4) {
            arrl[n4] = b2.a();
        }
        return new f(l2, l4, l3, arrl, l5, n2.c);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a(long l2) {
        float f2;
        float f3 = 256.0f;
        float f4 = 0.0f;
        if (this.e == null) return this.b;
        int n2 = 1;
        if (n2 == 0) {
            return this.b;
        }
        float f5 = (float)l2 * 100.0f / (float)this.c;
        if (f5 <= 0.0f) {
            f2 = 0.0f;
        } else {
            f2 = f3;
            if (f5 < 100.0f) {
                n2 = (int)f5;
                f2 = n2 == 0 ? f4 : (float)this.e[n2 - 1];
                if (n2 < 99) {
                    f3 = this.e[n2];
                }
                f2 = (f3 - f2) * (f5 - (float)n2) + f2;
            }
        }
        long l3 = Math.round((double)f2 * 0.00390625 * (double)this.f);
        long l4 = this.b;
        if (this.d != -1) {
            l2 = this.d - 1;
            return Math.min(l4 + l3, l2);
        }
        l2 = this.b - (long)this.g + this.f - 1;
        return Math.min(l4 + l3, l2);
    }

    @Override
    public final boolean a() {
        if (this.e != null) {
            return true;
        }
        return false;
    }

    @Override
    public final long b() {
        return this.c;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long b(long l2) {
        if (this.e == null) return 0;
        int n2 = 1;
        if (n2 == 0) return 0;
        if (l2 < this.b) {
            return 0;
        }
        double d2 = 256.0 * (double)(l2 - this.b) / (double)this.f;
        n2 = ah.a(this.e, (long)d2, false) + 1;
        long l3 = this.c * (long)n2 / 100;
        l2 = n2 == 0 ? 0 : this.e[n2 - 1];
        long l4 = n2 == 99 ? 256 : this.e[n2];
        long l5 = this.c;
        l5 = (long)(n2 + 1) * l5 / 100;
        if (l4 == l2) {
            l2 = 0;
            return l2 + l3;
        }
        double d3 = l5 - l3;
        l2 = (long)((d2 - (double)l2) * d3 / (double)(l4 - l2));
        return l2 + l3;
    }
}

