/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.f.d;
import com.d.a.a.z;

public final class c {
    int a = 1000;
    long[] b = new long[this.a];
    int[] c = new int[this.a];
    public int d;
    public int e;
    int f;
    int g;
    private int[] h = new int[this.a];
    private long[] i = new long[this.a];
    private byte[][] j = new byte[this.a][];

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final long a() {
        synchronized (this) {
            int n2;
            block5 : {
                --this.d;
                n2 = this.f;
                this.f = n2 + 1;
                ++this.e;
                if (this.f == this.a) {
                    this.f = 0;
                }
                if (this.d <= 0) break block5;
                return this.b[this.f];
            }
            long l2 = this.c[n2];
            long l3 = this.b[n2];
            return l3 + l2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final long a(long l2) {
        long l3 = -1;
        synchronized (this) {
            long l4 = l3;
            if (this.d == 0) return l4;
            l4 = this.i[this.f];
            if (l2 < l4) {
                return l3;
            }
            int n2 = this.g == 0 ? this.a : this.g;
            l4 = l3;
            if (l2 > this.i[n2 - 1]) return l4;
            n2 = 0;
            int n3 = this.f;
            int n4 = -1;
            while (n3 != this.g && this.i[n3] <= l2) {
                if ((this.h[n3] & 1) != 0) {
                    n4 = n2;
                }
                n3 = (n3 + 1) % this.a;
                ++n2;
            }
            l4 = l3;
            if (n4 == -1) return l4;
            this.d -= n4;
            this.f = (this.f + n4) % this.a;
            this.e += n4;
            return this.b[this.f];
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(long l2, int n2, long l3, int n3, byte[] arrby) {
        synchronized (this) {
            this.i[this.g] = l2;
            this.b[this.g] = l3;
            this.c[this.g] = n3;
            this.h[this.g] = n2;
            this.j[this.g] = arrby;
            ++this.d;
            if (this.d == this.a) {
                n2 = this.a + 1000;
                arrby = new long[n2];
                long[] arrl = new long[n2];
                int[] arrn = new int[n2];
                int[] arrn2 = new int[n2];
                byte[][] arrarrby = new byte[n2][];
                n3 = this.a - this.f;
                System.arraycopy(this.b, this.f, arrby, 0, n3);
                System.arraycopy(this.i, this.f, arrl, 0, n3);
                System.arraycopy(this.h, this.f, arrn, 0, n3);
                System.arraycopy(this.c, this.f, arrn2, 0, n3);
                System.arraycopy(this.j, this.f, arrarrby, 0, n3);
                int n4 = this.f;
                System.arraycopy(this.b, 0, arrby, n3, n4);
                System.arraycopy(this.i, 0, arrl, n3, n4);
                System.arraycopy(this.h, 0, arrn, n3, n4);
                System.arraycopy(this.c, 0, arrn2, n3, n4);
                System.arraycopy(this.j, 0, arrarrby, n3, n4);
                this.b = arrby;
                this.i = arrl;
                this.h = arrn;
                this.c = arrn2;
                this.j = arrarrby;
                this.f = 0;
                this.g = this.a;
                this.d = this.a;
                this.a = n2;
            } else {
                ++this.g;
                if (this.g == this.a) {
                    this.g = 0;
                }
            }
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean a(z z2, d d2) {
        synchronized (this) {
            block4 : {
                int n2 = this.d;
                if (n2 != 0) break block4;
                return false;
            }
            z2.e = this.i[this.f];
            z2.c = this.c[this.f];
            z2.d = this.h[this.f];
            d2.a = this.b[this.f];
            d2.b = this.j[this.f];
            return true;
        }
    }
}

