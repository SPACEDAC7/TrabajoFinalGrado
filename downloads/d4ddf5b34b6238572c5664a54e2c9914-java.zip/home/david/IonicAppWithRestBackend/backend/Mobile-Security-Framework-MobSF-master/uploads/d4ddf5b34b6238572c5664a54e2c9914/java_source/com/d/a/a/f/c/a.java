/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import com.d.a.a.d.b;
import com.d.a.a.f.c.c;

final class a
extends c {
    public final b a;

    public a(int n2, b b2) {
        super(n2);
        this.a = b2;
    }
}

