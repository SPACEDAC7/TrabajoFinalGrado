/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import com.d.a.a.f.c.a;
import com.d.a.a.f.c.c;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class b
extends c {
    public final long a;
    public final List<a> b;
    public final List<b> c;

    public b(int n2, long l2) {
        super(n2);
        this.a = l2;
        this.b = new ArrayList<a>();
        this.c = new ArrayList<b>();
    }

    public final a a(int n2) {
        int n3 = this.b.size();
        for (int i2 = 0; i2 < n3; ++i2) {
            a a2 = this.b.get(i2);
            if (a2.aD != n2) continue;
            return a2;
        }
        return null;
    }

    public final b b(int n2) {
        int n3 = this.c.size();
        for (int i2 = 0; i2 < n3; ++i2) {
            b b2 = this.c.get(i2);
            if (b2.aD != n2) continue;
            return b2;
        }
        return null;
    }

    @Override
    public final String toString() {
        return c.e(this.aD) + " leaves: " + Arrays.toString(this.b.toArray(new a[0])) + " containers: " + Arrays.toString(this.c.toArray(new b[0]));
    }
}

