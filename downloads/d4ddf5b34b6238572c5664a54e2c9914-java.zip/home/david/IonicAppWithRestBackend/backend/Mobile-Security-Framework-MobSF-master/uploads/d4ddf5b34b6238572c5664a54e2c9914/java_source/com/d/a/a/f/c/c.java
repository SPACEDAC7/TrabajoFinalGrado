/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import com.d.a.a.d.ah;

public abstract class c {
    public static final int A;
    public static final int B;
    public static final int C;
    public static final int D;
    public static final int E;
    public static final int F;
    public static final int G;
    public static final int H;
    public static final int I;
    public static final int J;
    public static final int K;
    public static final int L;
    public static final int M;
    public static final int N;
    public static final int O;
    public static final int P;
    public static final int Q;
    public static final int R;
    public static final int S;
    public static final int T;
    public static final int U;
    public static final int V;
    public static final int W;
    public static final int X;
    public static final int Y;
    public static final int Z;
    public static final int aA;
    public static final int aB;
    public static final int aC;
    public static final int aa;
    public static final int ab;
    public static final int ac;
    public static final int ad;
    public static final int ae;
    public static final int af;
    public static final int ag;
    public static final int ah;
    public static final int ai;
    public static final int aj;
    public static final int ak;
    public static final int al;
    public static final int am;
    public static final int an;
    public static final int ao;
    public static final int ap;
    public static final int aq;
    public static final int ar;
    public static final int as;
    public static final int at;
    public static final int au;
    public static final int av;
    public static final int aw;
    public static final int ax;
    public static final int ay;
    public static final int az;
    public static final int d;
    public static final int e;
    public static final int f;
    public static final int g;
    public static final int h;
    public static final int i;
    public static final int j;
    public static final int k;
    public static final int l;
    public static final int m;
    public static final int n;
    public static final int o;
    public static final int p;
    public static final int q;
    public static final int r;
    public static final int s;
    public static final int t;
    public static final int u;
    public static final int v;
    public static final int w;
    public static final int x;
    public static final int y;
    public static final int z;
    public final int aD;

    static {
        d = ah.e("ftyp");
        e = ah.e("avc1");
        f = ah.e("avc3");
        g = ah.e("hvc1");
        h = ah.e("hev1");
        i = ah.e("s263");
        j = ah.e("d263");
        k = ah.e("mdat");
        l = ah.e("mp4a");
        m = ah.e("wave");
        n = ah.e("ac-3");
        o = ah.e("dac3");
        p = ah.e("ec-3");
        q = ah.e("dec3");
        r = ah.e("dtsc");
        s = ah.e("dtsh");
        t = ah.e("dtsl");
        u = ah.e("dtse");
        v = ah.e("ddts");
        w = ah.e("tfdt");
        x = ah.e("tfhd");
        y = ah.e("trex");
        z = ah.e("trun");
        A = ah.e("sidx");
        B = ah.e("moov");
        C = ah.e("mvhd");
        D = ah.e("trak");
        E = ah.e("mdia");
        F = ah.e("minf");
        G = ah.e("stbl");
        H = ah.e("avcC");
        I = ah.e("hvcC");
        J = ah.e("esds");
        K = ah.e("moof");
        L = ah.e("traf");
        M = ah.e("mvex");
        N = ah.e("mehd");
        O = ah.e("tkhd");
        P = ah.e("edts");
        Q = ah.e("elst");
        R = ah.e("mdhd");
        S = ah.e("hdlr");
        T = ah.e("stsd");
        U = ah.e("pssh");
        V = ah.e("sinf");
        W = ah.e("schm");
        X = ah.e("schi");
        Y = ah.e("tenc");
        Z = ah.e("encv");
        aa = ah.e("enca");
        ab = ah.e("frma");
        ac = ah.e("saiz");
        ad = ah.e("saio");
        ae = ah.e("uuid");
        af = ah.e("senc");
        ag = ah.e("pasp");
        ah = ah.e("TTML");
        ai = ah.e("vmhd");
        aj = ah.e("mp4v");
        ak = ah.e("stts");
        al = ah.e("stss");
        am = ah.e("ctts");
        an = ah.e("stsc");
        ao = ah.e("stsz");
        ap = ah.e("stco");
        aq = ah.e("co64");
        ar = ah.e("tx3g");
        as = ah.e("wvtt");
        at = ah.e("stpp");
        au = ah.e("samr");
        av = ah.e("sawb");
        aw = ah.e("udta");
        ax = ah.e("meta");
        ay = ah.e("ilst");
        az = ah.e("mean");
        aA = ah.e("name");
        aB = ah.e("data");
        aC = ah.e("----");
    }

    public c(int n2) {
        this.aD = n2;
    }

    public static int c(int n2) {
        return n2 >> 24 & 255;
    }

    public static int d(int n2) {
        return 16777215 & n2;
    }

    public static String e(int n2) {
        return "" + (char)(n2 >> 24) + (char)(n2 >> 16 & 255) + (char)(n2 >> 8 & 255) + (char)(n2 & 255);
    }

    public String toString() {
        return c.e(this.aD);
    }
}

