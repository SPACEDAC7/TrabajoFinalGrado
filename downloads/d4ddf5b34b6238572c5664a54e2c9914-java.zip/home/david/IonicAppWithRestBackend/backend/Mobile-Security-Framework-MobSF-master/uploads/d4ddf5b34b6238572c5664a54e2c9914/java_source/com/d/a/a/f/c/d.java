/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

final class d {
    final int a;
    final long b;
    final int c;

    public d(int n2, long l2, int n3) {
        this.a = n2;
        this.b = l2;
        this.c = n3;
    }
}

