/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import com.d.a.a.f.c.j;
import com.d.a.a.q;

final class e {
    public final j[] a;
    public q b;
    public int c;

    public e(int n2) {
        this.a = new j[n2];
        this.c = -1;
    }
}

