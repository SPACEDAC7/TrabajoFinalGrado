/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import java.util.List;

final class f {
    public final List<byte[]> a;
    public final int b;
    public final float c;

    public f(List<byte[]> list, int n2, float f2) {
        this.a = list;
        this.b = n2;
        this.c = f2;
    }
}

