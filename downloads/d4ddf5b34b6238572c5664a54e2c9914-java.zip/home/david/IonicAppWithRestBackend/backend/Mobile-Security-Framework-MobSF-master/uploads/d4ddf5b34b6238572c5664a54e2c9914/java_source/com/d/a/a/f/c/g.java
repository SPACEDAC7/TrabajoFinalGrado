/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 */
package com.d.a.a.f.c;

import android.util.Pair;
import com.d.a.a.bb;
import com.d.a.a.d.ah;
import com.d.a.a.d.o;
import com.d.a.a.d.x;
import com.d.a.a.d.y;
import com.d.a.a.d.z;
import com.d.a.a.f.c.a;
import com.d.a.a.f.c.b;
import com.d.a.a.f.c.c;
import com.d.a.a.f.c.d;
import com.d.a.a.f.c.e;
import com.d.a.a.f.c.f;
import com.d.a.a.f.c.h;
import com.d.a.a.f.c.i;
import com.d.a.a.f.c.j;
import com.d.a.a.f.v;
import com.d.a.a.q;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class g {
    private static int a(com.d.a.a.d.b b2) {
        int n2 = b2.a();
        int n3 = n2 & 127;
        while ((n2 & 128) == 128) {
            n2 = b2.a();
            n3 = n3 << 7 | n2 & 127;
        }
        return n3;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Pair<List<byte[]>, Integer> a(com.d.a.a.d.b list, int n2) {
        int n3;
        int n4;
        int n5;
        int n6;
        list.b(n2 + 8 + 21);
        int n7 = list.a();
        int n8 = list.a();
        int n9 = list.b;
        n2 = 0;
        for (n4 = 0; n4 < n8; ++n4) {
            list.b(list.b + 1);
            n6 = list.b();
            for (n3 = 0; n3 < n6; ++n3) {
                n5 = list.b();
                n2 += n5 + 4;
                list.b(n5 + list.b);
            }
        }
        list.b(n9);
        byte[] arrby = new byte[n2];
        n4 = 0;
        for (n3 = 0; n3 < n8; ++n3) {
            list.b(list.b + 1);
            n6 = list.b();
            for (n9 = 0; n9 < n6; ++n9) {
                n5 = list.b();
                System.arraycopy(com.d.a.a.d.q.a, 0, arrby, n4, com.d.a.a.d.q.a.length);
                System.arraycopy(list.a, list.b, arrby, n4 += com.d.a.a.d.q.a.length, n5);
                n4 += n5;
                list.b(n5 + list.b);
            }
        }
        if (n2 == 0) {
            list = null;
            do {
                return Pair.create(list, (Object)((n7 & 3) + 1));
                break;
            } while (true);
        }
        list = Collections.singletonList(arrby);
        return Pair.create(list, (Object)((n7 & 3) + 1));
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Pair<long[], long[]> a(b object) {
        if (object == null || (object = object.a(c.Q)) == null) {
            return Pair.create((Object)null, (Object)null);
        }
        object = object.a;
        object.b(8);
        int n2 = c.c(object.g());
        int n3 = object.k();
        long[] arrl = new long[n3];
        long[] arrl2 = new long[n3];
        int n4 = 0;
        while (n4 < n3) {
            long l2 = n2 == 1 ? object.m() : object.e();
            arrl[n4] = l2;
            l2 = n2 == 1 ? object.i() : (long)object.g();
            arrl2[n4] = l2;
            byte[] arrby = object.a;
            int n5 = object.b;
            object.b = n5 + 1;
            n5 = arrby[n5];
            arrby = object.a;
            int n6 = object.b;
            object.b = n6 + 1;
            if ((short)((n5 & 255) << 8 | arrby[n6] & 255) != 1) {
                throw new IllegalArgumentException("Unsupported media rate.");
            }
            object.b(object.b + 2);
            ++n4;
        }
        return Pair.create((Object)arrl, (Object)arrl2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static e a(com.d.a.a.d.b var0, int var1_1, long var2_2, int var4_3, String var5_4, boolean var6_5) {
        var0.b(12);
        var13_6 = var0.g();
        var25_7 = new e(var13_6);
        var10_8 = 0;
        while (var10_8 < var13_6) {
            var14_14 = var0.b;
            var15_15 = var0.g();
            var22_22 = var15_15 > 0;
            y.a(var22_22, "childAtomSize should be positive");
            var9_11 = var0.g();
            if (var9_11 != c.e && var9_11 != c.f && var9_11 != c.Z && var9_11 != c.aj && var9_11 != c.g && var9_11 != c.h && var9_11 != c.i) ** GOTO lbl23
            var0.b(var14_14 + 8);
            var0.b(var0.b + 24);
            var16_16 = var0.b();
            var17_17 = var0.b();
            var9_11 = 0;
            var7_9 = 1.0f;
            var0.b(var0.b + 50);
            var24_25 = null;
            var11_12 = var0.b;
            var23_23 = null;
            ** GOTO lbl38
lbl23: // 1 sources:
            if (var9_11 != c.l && var9_11 != c.aa && var9_11 != c.n && var9_11 != c.p && var9_11 != c.r && var9_11 != c.u && var9_11 != c.s && var9_11 != c.t && var9_11 != c.au && var9_11 != c.av) ** GOTO lbl26
            g.a(var0, var9_11, var14_14, var15_15, var1_1, var2_2, var5_4, var6_5, var25_7, var10_8);
            ** GOTO lbl112
lbl26: // 1 sources:
            if (var9_11 != c.ah) ** GOTO lbl29
            var25_7.b = q.a(Integer.toString(var1_1), "application/ttml+xml", -1, var2_2, var5_4, Long.MAX_VALUE);
            ** GOTO lbl112
lbl29: // 1 sources:
            if (var9_11 != c.ar) ** GOTO lbl32
            var25_7.b = q.a(Integer.toString(var1_1), "application/x-quicktime-tx3g", -1, var2_2, var5_4, Long.MAX_VALUE);
            ** GOTO lbl112
lbl32: // 1 sources:
            if (var9_11 != c.as) ** GOTO lbl35
            var25_7.b = q.a(Integer.toString(var1_1), "application/x-mp4vtt", -1, var2_2, var5_4, Long.MAX_VALUE);
            ** GOTO lbl112
lbl35: // 1 sources:
            if (var9_11 != c.at) ** GOTO lbl112
            var25_7.b = q.a(Integer.toString(var1_1), "application/ttml+xml", -1, var2_2, var5_4, 0);
            ** GOTO lbl112
lbl38: // 2 sources:
            while (var11_12 - var14_14 < var15_15) {
                var0.b(var11_12);
                var19_19 = var0.b;
                var18_18 = var0.g();
                if (var18_18 != 0 || var0.b - var14_14 != var15_15) {
                    var22_22 = var18_18 > 0;
                    y.a(var22_22, "childAtomSize should be positive");
                    var12_13 = var0.g();
                    if (var12_13 == c.H) {
                        var12_13 = var23_23 == null ? 1 : 0;
                        if (var12_13 == 0) {
                            throw new IllegalStateException();
                        }
                        var23_23 = "video/avc";
                        var0.b(var19_19 + 8 + 4);
                        var19_19 = (var0.a() & 3) + 1;
                        if (var19_19 == 3) {
                            throw new IllegalStateException();
                        }
                        var24_26 = new ArrayList<byte[]>();
                        var8_10 = 1.0f;
                        var20_20 = var0.a() & 31;
                        for (var12_13 = 0; var12_13 < var20_20; ++var12_13) {
                            var24_26.add(com.d.a.a.d.q.a(var0));
                        }
                        var21_21 = var0.a();
                        for (var12_13 = 0; var12_13 < var21_21; ++var12_13) {
                            var24_26.add(com.d.a.a.d.q.a(var0));
                        }
                        if (var20_20 > 0) {
                            var26_31 = new com.d.a.a.d.c((byte[])var24_26.get(0));
                            var26_31.a((var19_19 + 1) * 8);
                            var8_10 = com.d.a.a.d.q.a((com.d.a.a.d.c)var26_31).d;
                        }
                        var26_31 = new f(var24_26, var19_19, var8_10);
                        var24_27 = var26_31.a;
                        var25_7.c = var26_31.b;
                        if (var9_11 == 0) {
                            var7_9 = var26_31.c;
                        }
                    } else if (var12_13 == c.I) {
                        var12_13 = var23_23 == null ? 1 : 0;
                        if (var12_13 == 0) {
                            throw new IllegalStateException();
                        }
                        var23_23 = g.a(var0, var19_19);
                        var24_28 = (List)var23_23.first;
                        var25_7.c = (Integer)var23_23.second;
                        var23_23 = "video/hevc";
                    } else if (var12_13 == c.j) {
                        var12_13 = var23_23 == null ? 1 : 0;
                        if (var12_13 == 0) {
                            throw new IllegalStateException();
                        }
                        var23_23 = "video/3gpp";
                    } else if (var12_13 == c.J) {
                        var12_13 = var23_23 == null ? 1 : 0;
                        if (var12_13 == 0) {
                            throw new IllegalStateException();
                        }
                        var24_29 = g.b(var0, var19_19);
                        var23_23 = (String)var24_29.first;
                        var24_30 = Collections.singletonList(var24_29.second);
                    } else if (var12_13 == c.V) {
                        var25_7.a[var10_8] = g.a(var0, var19_19, var18_18);
                    } else if (var12_13 == c.ag) {
                        var0.b(var19_19 + 8);
                        var9_11 = var0.k();
                        var12_13 = var0.k();
                        var7_9 = (float)var9_11 / (float)var12_13;
                        var9_11 = 1;
                    }
                    var11_12 += var18_18;
                    continue;
                }
                if (var23_23 == null) break;
                var25_7.b = q.a(Integer.toString(var1_1), (String)var23_23, -1, -1, var2_2, var16_16, var17_17, var24_24, var4_3, var7_9);
                break;
            }
lbl112: // 9 sources:
            var0.b(var14_14 + var15_15);
            ++var10_8;
        }
        return var25_7;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static h a(b var0, a var1_1, long var2_2, boolean var4_3) {
        block5 : {
            var18_4 = var0.b(c.E);
            var17_5 = var18_4.a((int)c.S).a;
            var17_5.b(16);
            var9_6 = var17_5.g();
            if (var9_6 != h.b && var9_6 != h.a && var9_6 != h.c && var9_6 != h.d && var9_6 != h.e) {
                return null;
            }
            var17_5 = var0.a((int)c.O).a;
            var17_5.b(8);
            var11_7 = c.c(var17_5.g());
            var5_8 = var11_7 == 0 ? 8 : 16;
            var17_5.b(var5_8 + var17_5.b);
            var10_9 = var17_5.g();
            var17_5.b(var17_5.b + 4);
            var8_10 = 1;
            var12_11 = var17_5.b;
            var5_8 = var11_7 == 0 ? 4 : 8;
            var6_12 = 0;
            do {
                var7_13 = var8_10;
                if (var6_12 >= var5_8) ** GOTO lbl23
                if (var17_5.a[var12_11 + var6_12] != -1) {
                    var7_13 = 0;
lbl23: // 2 sources:
                    if (var7_13 == 0) break;
                    var17_5.b(var5_8 + var17_5.b);
                    var13_14 = -1;
                    break block5;
                }
                ++var6_12;
            } while (true);
            var15_15 = var11_7 == 0 ? var17_5.e() : var17_5.m();
            var13_14 = var15_15;
            if (var15_15 == 0) {
                var13_14 = -1;
            }
        }
        var17_5.b(var17_5.b + 16);
        var5_8 = var17_5.g();
        var6_12 = var17_5.g();
        var17_5.b(var17_5.b + 4);
        var7_13 = var17_5.g();
        var8_10 = var17_5.g();
        var5_8 = var5_8 == 0 && var6_12 == 65536 && var7_13 == -65536 && var8_10 == 0 ? 90 : (var5_8 == 0 && var6_12 == -65536 && var7_13 == 65536 && var8_10 == 0 ? 270 : (var5_8 == -65536 && var6_12 == 0 && var7_13 == 0 && var8_10 == -65536 ? 180 : 0));
        var17_5 = new d(var10_9, var13_14, var5_8);
        if (var2_2 == -1) {
            var2_2 = var17_5.b;
        }
        var1_1 = var1_1.a;
        var1_1.b(8);
        var5_8 = c.c(var1_1.g()) == 0 ? 8 : 16;
        var1_1.b(var5_8 + var1_1.b);
        var13_14 = var1_1.e();
        var2_2 = var2_2 == -1 ? -1 : ah.a(var2_2, 1000000, var13_14);
        var1_1 = var18_4.b(c.F).b(c.G);
        var18_4 = var18_4.a((int)c.R).a;
        var18_4.b(8);
        var6_12 = c.c(var18_4.g());
        var5_8 = var6_12 == 0 ? 8 : 16;
        var18_4.b(var5_8 + var18_4.b);
        var15_15 = var18_4.e();
        var5_8 = var6_12 == 0 ? 4 : 8;
        var18_4.b(var5_8 + var18_4.b);
        var5_8 = var18_4.b();
        var18_4 = Pair.create((Object)var15_15, (Object)("" + (char)((var5_8 >> 10 & 31) + 96) + (char)((var5_8 >> 5 & 31) + 96) + (char)((var5_8 & 31) + 96)));
        var1_1 = g.a(var1_1.a((int)c.T).a, var17_5.a, var2_2, var17_5.c, (String)var18_4.second, var4_3);
        var0 = g.a(var0.b(c.P));
        if (var1_1.b != null) return new h(var17_5.a, var9_6, (Long)var18_4.first, var13_14, var2_2, var1_1.b, var1_1.a, var1_1.c, (long[])var0.first, (long[])var0.second);
        return null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static i a(h var0, b var1_1) {
        var39_2 = var1_1.a((int)c.ao).a;
        var33_4 = var34_3 = var1_1.a(c.ap);
        if (var34_3 == null) {
            var33_4 = var1_1.a(c.aq);
        }
        var40_5 = var33_4.a;
        var41_6 = var1_1.a((int)c.an).a;
        var42_7 = var1_1.a((int)c.ak).a;
        var34_3 = var1_1.a(c.al);
        var34_3 = var34_3 != null ? var34_3.a : null;
        var1_1 = (var1_1 = var1_1.a(c.am)) != null ? var1_1.a : null;
        var39_2.b(12);
        var20_8 = var39_2.k();
        var22_9 = var39_2.k();
        var35_10 = new long[var22_9];
        var36_11 = new int[var22_9];
        var38_12 = new long[var22_9];
        var37_13 = new int[var22_9];
        if (var22_9 == 0) {
            return new i(var35_10, var36_11, 0, var38_12, var37_13);
        }
        var40_5.b(12);
        var23_14 = var40_5.k();
        var41_6.b(12);
        var7_15 = var41_6.k() - 1;
        var24_16 = var41_6.g() == 1;
        y.b(var24_16, "stsc first chunk must be 1");
        var6_17 = var41_6.k();
        var41_6.b(var41_6.b + 4);
        var2_18 = -1;
        if (var7_15 > 0) {
            var2_18 = var41_6.k() - 1;
        }
        var42_7.b(12);
        var8_19 = var42_7.k();
        var19_20 = var42_7.k();
        var9_21 = var42_7.k();
        var3_22 = 0;
        if (var1_1 != null) {
            var1_1.b(12);
            var3_22 = var1_1.k();
        }
        var4_23 = -1;
        var5_24 = 0;
        if (var34_3 != null) {
            var34_3.b(12);
            var5_24 = var34_3.k();
            var4_23 = var34_3.k() - 1;
        }
        var25_25 = var33_4.aD == c.ap ? var40_5.e() : var40_5.m();
        var27_26 = 0;
        var18_27 = var6_17;
        var10_28 = var5_24;
        var12_29 = 0;
        var13_30 = 0;
        var15_31 = 0;
        var11_32 = var3_22;
        var3_22 = var2_18;
        var16_33 = 0;
        var14_34 = 0;
        --var8_19;
        var5_24 = var4_23;
        var2_18 = var7_15;
        var4_23 = var6_17;
        var7_15 = var15_31;
        var6_17 = var16_33;
        do {
            if (var14_34 >= var22_9) ** GOTO lbl92
            var17_35 = var12_29;
            var16_33 = var11_32;
            var15_31 = var13_30;
            if (var1_1 != null) {
                while (var13_30 == 0 && var11_32 > 0) {
                    var13_30 = var1_1.k();
                    var12_29 = var1_1.g();
                    --var11_32;
                }
                var15_31 = var13_30 - 1;
                var16_33 = var11_32;
                var17_35 = var12_29;
            }
            var35_10[var14_34] = var25_25;
            var11_32 = var20_8 == 0 ? var39_2.k() : var20_8;
            var36_11[var14_34] = var11_32;
            var12_29 = var6_17;
            if (var36_11[var14_34] > var6_17) {
                var12_29 = var36_11[var14_34];
            }
            var38_12[var14_34] = (long)var17_35 + var27_26;
            var6_17 = var34_3 == null ? 1 : 0;
            var37_13[var14_34] = var6_17;
            if (var14_34 != var5_24) ** GOTO lbl118
            var37_13[var14_34] = 1;
            var6_17 = var10_28 - 1;
            if (var6_17 > 0) {
                var5_24 = var34_3.k();
                --var5_24;
            }
            ** GOTO lbl119
lbl92: // 1 sources:
            var2_18 = var10_28 == 0 ? 1 : 0;
            if (var2_18 == 0) {
                throw new IllegalArgumentException();
            }
            var2_18 = var19_20 == 0 ? 1 : 0;
            if (var2_18 == 0) {
                throw new IllegalArgumentException();
            }
            var2_18 = var18_27 == 0 ? 1 : 0;
            if (var2_18 == 0) {
                throw new IllegalArgumentException();
            }
            var2_18 = var8_19 == 0 ? 1 : 0;
            if (var2_18 == 0) {
                throw new IllegalArgumentException();
            }
            var2_18 = var11_32 == 0 ? 1 : 0;
            if (var2_18 == 0) {
                throw new IllegalArgumentException();
            }
            if (var0.m == null) {
                ah.a(var38_12, var0.h);
                return new i(var35_10, var36_11, var6_17, var38_12, var37_13);
            }
            if (var0.m.length == 1 && var0.m[0] == 0) {
                var2_18 = 0;
                while (var2_18 < var38_12.length) {
                    var38_12[var2_18] = ah.a(var38_12[var2_18] - var0.n[0], 1000000, var0.h);
                    ++var2_18;
                }
                return new i(var35_10, var36_11, var6_17, var38_12, var37_13);
            }
            break;
lbl118: // 1 sources:
            var6_17 = var10_28;
lbl119: // 2 sources:
            var27_26 += (long)var9_21;
            var10_28 = var19_20 - 1;
            if (var10_28 == 0 && var8_19 > 0) {
                var10_28 = var42_7.k();
                var9_21 = var42_7.k();
                --var8_19;
            }
            if ((var13_30 = var18_27 - 1) != 0) ** GOTO lbl139
            if (++var7_15 < var23_14) {
                var25_25 = var33_4.aD == c.ap ? var40_5.e() : var40_5.m();
            }
            if (var7_15 != var3_22) ** GOTO lbl149
            var4_23 = var41_6.k();
            var41_6.b(var41_6.b + 4);
            var18_27 = var2_18 - 1;
            var2_18 = var4_23;
            var11_32 = var18_27;
            if (var18_27 > 0) {
                var3_22 = var41_6.k() - 1;
                var11_32 = var18_27;
                var2_18 = var4_23;
            }
            ** GOTO lbl151
lbl139: // 1 sources:
            var25_25 += (long)var36_11[var14_34];
            var11_32 = var3_22;
            var18_27 = var4_23;
            var19_20 = var2_18;
            var2_18 = var13_30;
            var3_22 = var7_15;
            var4_23 = var11_32;
            var7_15 = var18_27;
            var11_32 = var19_20;
            ** GOTO lbl162
lbl149: // 1 sources:
            var11_32 = var2_18;
            var2_18 = var4_23;
lbl151: // 2 sources:
            if (var7_15 < var23_14) {
                var13_30 = var7_15;
                var7_15 = var2_18;
                var4_23 = var3_22;
                var3_22 = var13_30;
            } else {
                var4_23 = var3_22;
                var18_27 = var2_18;
                var2_18 = var13_30;
                var3_22 = var7_15;
                var7_15 = var18_27;
            }
lbl162: // 3 sources:
            var21_36 = var14_34 + 1;
            var19_20 = var10_28;
            var18_27 = var2_18;
            var10_28 = var6_17;
            var2_18 = var11_32;
            var14_34 = var7_15;
            var6_17 = var12_29;
            var12_29 = var17_35;
            var11_32 = var16_33;
            var13_30 = var15_31;
            var7_15 = var3_22;
            var3_22 = var4_23;
            var4_23 = var14_34;
            var14_34 = var21_36;
        } while (true);
        var5_24 = 0;
        var3_22 = 0;
        var4_23 = 0;
        var2_18 = 0;
        do {
            if (var5_24 >= var0.m.length) ** GOTO lbl194
            var25_25 = var0.n[var5_24];
            if (var25_25 == -1) ** GOTO lbl206
            var27_26 = ah.a(var0.m[var5_24], var0.h, var0.i);
            var9_21 = ah.a(var38_12, var25_25, true, true);
            var7_15 = ah.a(var38_12, var27_26 + var25_25, true, false);
            var8_19 = var2_18 + (var7_15 - var9_21);
            var2_18 = var4_23 != var9_21 ? 1 : 0;
            var4_23 = var2_18 | var3_22;
            var2_18 = var8_19;
            var3_22 = var7_15;
            ** GOTO lbl209
lbl194: // 1 sources:
            var4_23 = var2_18 != var22_9 ? 1 : 0;
            var7_15 = var3_22 | var4_23;
            var1_1 = var7_15 != 0 ? new long[var2_18] : var35_10;
            var33_4 = var7_15 != 0 ? new int[var2_18] : var36_11;
            var3_22 = var7_15 != 0 ? 0 : var6_17;
            var34_3 = var7_15 != 0 ? new int[var2_18] : var37_13;
            var39_2 = new long[var2_18];
            var5_24 = 0;
            var25_25 = 0;
            var2_18 = var3_22;
            var3_22 = var5_24;
            break;
lbl206: // 1 sources:
            var7_15 = var4_23;
            var4_23 = var3_22;
            var3_22 = var7_15;
lbl209: // 2 sources:
            ++var5_24;
            var7_15 = var3_22;
            var3_22 = var4_23;
            var4_23 = var7_15;
        } while (true);
        for (var4_23 = 0; var4_23 < var0.m.length; ++var4_23) {
            var27_26 = var0.n[var4_23];
            var29_37 = var0.m[var4_23];
            if (var27_26 != -1) {
                var31_38 = ah.a(var29_37, var0.h, var0.i);
                var5_24 = ah.a(var38_12, var27_26, true, true);
                var8_19 = ah.a(var38_12, var27_26 + var31_38, true, false);
                if (var7_15 != 0) {
                    var6_17 = var8_19 - var5_24;
                    System.arraycopy(var35_10, var5_24, var1_1, var3_22, var6_17);
                    System.arraycopy(var36_11, var5_24, var33_4, var3_22, var6_17);
                    System.arraycopy(var37_13, var5_24, var34_3, var3_22, var6_17);
                }
                while (var5_24 < var8_19) {
                    var31_38 = ah.a(var25_25, 1000000, var0.i);
                    var39_2[var3_22] = ah.a(var38_12[var5_24] - var27_26, 1000000, var0.h) + var31_38;
                    var6_17 = var2_18;
                    if (var7_15 != 0) {
                        var6_17 = var2_18;
                        if (var33_4[var3_22] > var2_18) {
                            var6_17 = var36_11[var5_24];
                        }
                    }
                    ++var3_22;
                    ++var5_24;
                    var2_18 = var6_17;
                }
            }
            var25_25 = var29_37 + var25_25;
        }
        var4_23 = 0;
        for (var3_22 = 0; var3_22 < var34_3.length && var4_23 == 0; var4_23 |= var5_24, ++var3_22) {
            var5_24 = (var34_3[var3_22] & 1) != 0 ? 1 : 0;
        }
        if (var4_23 != 0) return new i(var1_1, var33_4, var2_18, var39_2, (int[])var34_3);
        throw new bb("The edited sample sequence does not contain a sync sample.");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static j a(com.d.a.a.d.b var0, int var1_1, int var2_2) {
        block8 : {
            var3_3 = var1_1 + 8;
            var8_4 = null;
            block0 : while (var3_3 - var1_1 < var2_2) {
                var0.b(var3_3);
                var5_6 = var0.g();
                var4_5 = var0.g();
                if (var4_5 == c.ab) {
                    var0.g();
                } else if (var4_5 == c.W) {
                    var0.b(var0.b + 4);
                    var0.g();
                    var0.g();
                } else if (var4_5 == c.X) {
                    var4_5 = var3_3 + 8;
                    break block8;
                }
lbl18: // 6 sources:
                do {
                    var3_3 += var5_6;
                    continue block0;
                    break;
                } while (true);
            }
            return var8_4;
        }
        while (var4_5 - var3_3 < var5_6) {
            var0.b(var4_5);
            var6_7 = var0.g();
            if (var0.g() != c.Y) ** GOTO lbl34
            var0.b(var0.b + 4);
            var4_5 = var0.g();
            var7_8 = var4_5 >> 8 == 1;
            var8_4 = new byte[16];
            var0.a((byte[])var8_4, 0, 16);
            var8_4 = new j(var7_8, var4_5 & 255, (byte[])var8_4);
            ** GOTO lbl18
lbl34: // 1 sources:
            var4_5 += var6_7;
        }
        var8_4 = null;
        ** while (true)
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static v a(a var0, boolean var1_1) {
        if (var1_1) lbl-1000: // 3 sources:
        {
            do {
                return null;
                break;
            } while (true);
        }
        var8_2 = var0.a;
        var8_2.b(8);
        do {
            if (var8_2.c - var8_2.b < 8) ** GOTO lbl-1000
            var2_3 = var8_2.g();
            if (var8_2.g() != c.ax) ** GOTO lbl56
            var8_2.b(var8_2.b - 8);
            var8_2.a(var2_3 + var8_2.b);
            var8_2.b(var8_2.b + 12);
            var9_4 = new com.d.a.a.d.b();
            do {
                if (var8_2.c - var8_2.b < 8) ** continue;
                var2_3 = var8_2.g() - 8;
                if (var8_2.g() != c.ay) ** GOTO lbl54
                var0 = var8_2.a;
                var3_5 = var8_2.b;
                var9_4.a = var0;
                var9_4.c = var3_5 + var2_3;
                var9_4.b = 0;
                var9_4.b(var8_2.b);
lbl24: // 3 sources:
                if (var9_4.c - var9_4.b <= 0) ** GOTO lbl52
                var3_5 = var9_4.b + var9_4.g();
                if (var9_4.g() != c.aC) ** GOTO lbl50
                var7_9 = null;
                var6_8 = null;
                var0 = null;
                do {
                    if (var9_4.b >= var3_5) ** GOTO lbl24
                    var4_6 = var9_4.g() - 12;
                    var5_7 = var9_4.g();
                    var9_4.b(var9_4.b + 4);
                    if (var5_7 == c.az) {
                        var0 = var9_4.a(var4_6, Charset.defaultCharset());
                        continue;
                    }
                    if (var5_7 == c.aA) {
                        var6_8 = var9_4.a(var4_6, Charset.defaultCharset());
                        continue;
                    }
                    if (var5_7 == c.aB) {
                        var9_4.b(var9_4.b + 4);
                        var7_9 = var9_4.a(var4_6 - 4, Charset.defaultCharset());
                        continue;
                    }
                    var9_4.b(var4_6 + var9_4.b);
                } while (true);
lbl47: // 1 sources:
                while (var0 != null) {
                    return var0;
                }
                ** GOTO lbl54
lbl50: // 1 sources:
                var9_4.b(var3_5);
                ** GOTO lbl24
lbl52: // 1 sources:
                var0 = null;
                ** GOTO lbl47
lbl54: // 2 sources:
                var8_2.b(var8_2.b + var2_3);
            } while (true);
lbl56: // 1 sources:
            var8_2.b(var2_3 - 8 + var8_2.b);
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void a(com.d.a.a.d.b var0, int var1_1, int var2_2, int var3_3, int var4_4, long var5_5, String var7_6, boolean var8_7, e var9_8, int var10_9) {
        var0.b(var2_2 + 8);
        var11_10 = 0;
        if (var8_7) {
            var0.b(var0.b + 8);
            var11_10 = var0.b();
            var0.b(var0.b + 6);
        } else {
            var0.b(var0.b + 16);
        }
        var14_11 = var0.b();
        var16_12 = var0.b();
        var0.b(var0.b + 4);
        var20_13 = var0.a;
        var12_14 = var0.b;
        var0.b = var12_14 + 1;
        var12_14 = var20_13[var12_14];
        var20_13 = var0.a;
        var13_15 = var0.b;
        var0.b = var13_15 + 1;
        var13_15 = (var12_14 & 255) << 8 | var20_13[var13_15] & 255;
        var0.b += 2;
        if (var11_10 > 0) {
            var0.b(var0.b + 16);
            if (var11_10 == 2) {
                var0.b(var0.b + 20);
            }
        }
        var20_13 = null;
        if (var1_1 == c.n) {
            var20_13 = "audio/ac3";
        } else if (var1_1 == c.p) {
            var20_13 = "audio/eac3";
        } else if (var1_1 == c.r) {
            var20_13 = "audio/vnd.dts";
        } else if (var1_1 == c.s || var1_1 == c.t) {
            var20_13 = "audio/vnd.dts.hd";
        } else if (var1_1 == c.u) {
            var20_13 = "audio/vnd.dts.hd;profile=lbr";
        } else if (var1_1 == c.au) {
            var20_13 = "audio/3gpp";
        } else if (var1_1 == c.av) {
            var20_13 = "audio/amr-wb";
        }
        var22_16 = null;
        var12_14 = var0.b;
        var21_17 = var20_13;
        var20_13 = var22_16;
        block0 : do {
            if (var12_14 - var2_2 >= var3_3) ** GOTO lbl81
            var0.b(var12_14);
            var17_19 = var0.g();
            var19_21 = var17_19 > 0;
            y.a(var19_21, "childAtomSize should be positive");
            var18_20 = var0.g();
            if (var1_1 != c.l && var1_1 != c.aa) ** GOTO lbl69
            var15_18 = -1;
            if (var18_20 == c.J) {
                var11_10 = var12_14;
            } else {
                var11_10 = var15_18;
                if (var8_7) {
                    var11_10 = var15_18;
                    if (var18_20 == c.m) {
                        var11_10 = var0.b;
                        break;
                    }
                }
            }
            ** GOTO lbl86
lbl69: // 1 sources:
            if (var1_1 == c.n && var18_20 == c.o) {
                var0.b(var12_14 + 8);
                var9_8.b = x.a(var0, Integer.toString(var4_4), var5_5, var7_6);
                return;
            }
            if (var1_1 == c.p && var18_20 == c.q) {
                var0.b(var12_14 + 8);
                var9_8.b = x.b(var0, Integer.toString(var4_4), var5_5, var7_6);
                return;
            }
            if ((var1_1 == c.r || var1_1 == c.u || var1_1 == c.s || var1_1 == c.t) && var18_20 == c.v) {
                var9_8.b = q.a(Integer.toString(var4_4), (String)var21_17, -1, -1, var5_5, var14_11, var13_15, null, var7_6);
                return;
            }
            ** GOTO lbl102
lbl81: // 1 sources:
            if (var21_17 == null) return;
            var22_16 = Integer.toString(var4_4);
            var0 = var20_13 == null ? null : Collections.singletonList(var20_13);
            var9_8.b = q.a(var22_16, (String)var21_17, -1, var16_12, var5_5, var14_11, var13_15, var0, var7_6);
            return;
lbl86: // 4 sources:
            do {
                if (var11_10 != -1) {
                    var20_13 = g.b(var0, var11_10);
                    var22_16 = (String)var20_13.first;
                    var23_22 = (Pair<Integer, Integer>)var20_13.second;
                    var21_17 = var22_16;
                    var20_13 = var23_22;
                    if ("audio/mp4a-latm".equals(var22_16)) {
                        var20_13 = z.a((byte[])var23_22);
                        var13_15 = (Integer)var20_13.first;
                        var14_11 = (Integer)var20_13.second;
                        var20_13 = var23_22;
                        var21_17 = var22_16;
                    }
                } else if (var18_20 == c.V) {
                    var9_8.a[var10_9] = g.a(var0, var12_14, var17_19);
                }
lbl102: // 5 sources:
                var12_14 += var17_19;
                continue block0;
                break;
            } while (true);
            break;
        } while (true);
        while (var11_10 - var12_14 < var17_19) {
            var0.b(var11_10);
            var15_18 = var0.g();
            var19_21 = var15_18 > 0;
            y.a(var19_21, "childAtomSize should be positive");
            if (var0.g() == c.J) ** GOTO lbl86
            var11_10 += var15_18;
        }
        var11_10 = -1;
        ** while (true)
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static Pair<String, byte[]> b(com.d.a.a.d.b var0, int var1_1) {
        var2_2 = null;
        var0.b(var1_1 + 8 + 4);
        var0.b(var0.b + 1);
        g.a(var0);
        var0.b(var0.b + 2);
        var1_1 = var0.a();
        if ((var1_1 & 128) != 0) {
            var0.b(var0.b + 2);
        }
        if ((var1_1 & 64) != 0) {
            var0.b(var0.b() + var0.b);
        }
        if ((var1_1 & 32) != 0) {
            var0.b(var0.b + 2);
        }
        var0.b(var0.b + 1);
        g.a(var0);
        switch (var0.a()) {
            case 107: {
                return Pair.create((Object)"audio/mpeg", (Object)null);
            }
            case 32: {
                var2_2 = "video/mp4v-es";
                ** break;
            }
            case 33: {
                var2_2 = "video/avc";
                ** break;
            }
            case 35: {
                var2_2 = "video/hevc";
                ** break;
            }
            case 64: 
            case 102: 
            case 103: 
            case 104: {
                var2_2 = "audio/mp4a-latm";
                ** break;
            }
            case 165: {
                var2_2 = "audio/ac3";
                ** break;
            }
            case 166: {
                var2_2 = "audio/eac3";
            }
lbl35: // 7 sources:
            default: {
                var0.b(var0.b + 12);
                var0.b(var0.b + 1);
                var1_1 = g.a(var0);
                var3_3 = new byte[var1_1];
                var0.a(var3_3, 0, var1_1);
                return Pair.create((Object)var2_2, (Object)var3_3);
            }
            case 169: 
            case 172: {
                return Pair.create((Object)"audio/vnd.dts", (Object)null);
            }
            case 170: 
            case 171: 
        }
        return Pair.create((Object)"audio/vnd.dts.hd", (Object)null);
    }
}

