/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import com.d.a.a.d.ah;
import com.d.a.a.f.c.j;
import com.d.a.a.q;

public final class h {
    public static final int a = ah.e("vide");
    public static final int b = ah.e("soun");
    public static final int c = ah.e("text");
    public static final int d = ah.e("sbtl");
    public static final int e = ah.e("subt");
    public final int f;
    public final int g;
    public final long h;
    public final long i;
    public final long j;
    public final q k;
    public final j[] l;
    public final long[] m;
    public final long[] n;
    public final int o;

    public h(int n2, int n3, long l2, long l3, long l4, q q2, j[] arrj, int n4, long[] arrl, long[] arrl2) {
        this.f = n2;
        this.g = n3;
        this.h = l2;
        this.i = l3;
        this.j = l4;
        this.k = q2;
        this.l = arrj;
        this.o = n4;
        this.m = arrl;
        this.n = arrl2;
    }
}

