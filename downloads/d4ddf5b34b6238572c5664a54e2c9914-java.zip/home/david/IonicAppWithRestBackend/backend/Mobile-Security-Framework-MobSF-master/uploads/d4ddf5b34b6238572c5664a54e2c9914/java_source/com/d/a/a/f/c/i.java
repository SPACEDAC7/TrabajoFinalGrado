/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

final class i {
    public final int a;
    public final long[] b;
    public final int[] c;
    public final int d;
    public final long[] e;
    public final int[] f;

    /*
     * Enabled aggressive block sorting
     */
    i(long[] arrl, int[] arrn, int n2, long[] arrl2, int[] arrn2) {
        boolean bl2 = true;
        boolean bl3 = arrn.length == arrl2.length;
        if (!bl3) {
            throw new IllegalArgumentException();
        }
        bl3 = arrl.length == arrl2.length;
        if (!bl3) {
            throw new IllegalArgumentException();
        }
        bl3 = arrn2.length == arrl2.length ? bl2 : false;
        if (!bl3) {
            throw new IllegalArgumentException();
        }
        this.b = arrl;
        this.c = arrn;
        this.d = n2;
        this.e = arrl2;
        this.f = arrn2;
        this.a = arrl.length;
    }
}

