/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

final class k {
    public final int a;
    public final int b;
    public final int c;
    public final int d;

    public k(int n2, int n3, int n4, int n5) {
        this.a = n2;
        this.b = n3;
        this.c = n4;
        this.d = n5;
    }
}

