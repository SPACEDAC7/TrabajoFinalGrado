/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import com.d.a.a.f.b;
import com.d.a.a.f.c.h;
import com.d.a.a.f.c.k;
import com.d.a.a.f.c.n;
import com.d.a.a.q;

final class l {
    public final n a = new n();
    public final b b;
    public h c;
    public k d;
    public int e;

    public l(b b2) {
        this.b = b2;
    }

    public final void a() {
        n n2 = this.a;
        n2.d = 0;
        n2.n = 0;
        n2.i = false;
        n2.m = false;
        this.e = 0;
    }

    public final void a(h h2, k k2) {
        if (h2 == null) {
            throw new NullPointerException();
        }
        this.c = h2;
        if (k2 == null) {
            throw new NullPointerException();
        }
        this.d = k2;
        this.b.a(h2.k);
        this.a();
    }
}

