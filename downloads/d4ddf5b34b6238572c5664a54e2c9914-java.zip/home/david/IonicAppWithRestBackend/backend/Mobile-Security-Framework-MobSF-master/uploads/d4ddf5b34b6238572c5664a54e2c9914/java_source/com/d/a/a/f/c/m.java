/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  android.util.Pair
 *  android.util.SparseArray
 */
package com.d.a.a.f.c;

import android.util.Log;
import android.util.Pair;
import android.util.SparseArray;
import com.d.a.a.bb;
import com.d.a.a.d.ah;
import com.d.a.a.d.y;
import com.d.a.a.f.c.a;
import com.d.a.a.f.c.b;
import com.d.a.a.f.c.c;
import com.d.a.a.f.c.n;
import com.d.a.a.f.c.q;
import com.d.a.a.f.c.r;
import com.d.a.a.f.g;
import com.d.a.a.f.h;
import com.d.a.a.f.j;
import com.d.a.a.f.k;
import com.d.a.a.f.l;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.UUID;

public final class m
implements h {
    private static final byte[] a = new byte[]{-94, 57, 79, 82, 90, -101, 79, 20, -94, 68, 108, 66, 124, 100, -115, -12};
    private final int b;
    private final com.d.a.a.f.c.h c = null;
    private final SparseArray<com.d.a.a.f.c.l> d;
    private final com.d.a.a.d.b e;
    private final com.d.a.a.d.b f;
    private final com.d.a.a.d.b g;
    private final com.d.a.a.d.b h;
    private final com.d.a.a.d.b i;
    private final byte[] j;
    private final Stack<b> k;
    private int l;
    private int m;
    private long n;
    private int o;
    private com.d.a.a.d.b p;
    private long q;
    private com.d.a.a.f.c.l r;
    private int s;
    private int t;
    private int u;
    private g v;
    private com.d.a.a.f.d.a w;
    private boolean x;

    public m() {
        this(0);
    }

    public m(int n2) {
        this(n2, 0);
    }

    private m(int n2, byte by2) {
        this.b = n2 | 0;
        this.i = new com.d.a.a.d.b(16);
        this.e = new com.d.a.a.d.b(com.d.a.a.d.q.a);
        this.f = new com.d.a.a.d.b(4);
        this.g = new com.d.a.a.d.b(1);
        this.h = new com.d.a.a.d.b(1);
        this.j = new byte[16];
        this.k = new Stack();
        this.d = new SparseArray();
        this.l = 0;
        this.o = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(long l2) {
        while (!this.k.isEmpty() && this.k.peek().a == l2) {
            Object object;
            int n2;
            Object object2;
            Object object3;
            int n3;
            Object object4 = this.k.pop();
            if (object4.aD == c.B) {
                boolean bl2 = this.c == null;
                y.b(bl2, "Unexpected moov box.");
                object3 = object4.b;
                n3 = object3.size();
                object2 = null;
            } else {
                if (object4.aD == c.K) {
                    m.a((b)object4, this.d, this.b, this.j);
                    continue;
                }
                if (this.k.isEmpty()) continue;
                this.k.peek().c.add((b)object4);
                continue;
            }
            for (n2 = 0; n2 < n3; ++n2) {
                Object object5 = object3.get(n2);
                object = object2;
                if (object5.aD == c.U) {
                    object = object2;
                    if (object2 == null) {
                        object = new com.d.a.a.b.a();
                    }
                    if (q.a((byte[])(object5 = object5.a.a)) == null) {
                        Log.w((String)"FragmentedMp4Extractor", (String)"Skipped pssh atom (failed to extract uuid)");
                    } else {
                        object2 = q.a((byte[])object5);
                        object5 = new com.d.a.a.b.c("video/mp4", (byte[])object5);
                        object.a.put((UUID)object2, (com.d.a.a.b.c)object5);
                    }
                }
                object2 = object;
            }
            object2 = object4.b(c.M);
            object = new SparseArray();
            long l3 = -1;
            n3 = object2.b.size();
            for (n2 = 0; n2 < n3; ++n2) {
                object3 = object2.b.get(n2);
                if (object3.aD == c.y) {
                    object3 = object3.a;
                    object3.b(12);
                    object3 = Pair.create((Object)object3.g(), (Object)new com.d.a.a.f.c.k(object3.k() - 1, object3.k(), object3.k(), object3.g()));
                    object.put(((Integer)object3.first).intValue(), object3.second);
                    continue;
                }
                if (object3.aD != c.N) continue;
                object3 = object3.a;
                object3.b(8);
                l3 = c.c(object3.g()) == 0 ? object3.e() : object3.m();
            }
            object2 = new SparseArray();
            n3 = object4.c.size();
            for (n2 = 0; n2 < n3; ++n2) {
                object3 = object4.c.get(n2);
                if (object3.aD != c.D || (object3 = com.d.a.a.f.c.g.a((b)object3, object4.a(c.C), l3, false)) == null) continue;
                object2.put(object3.f, object3);
            }
            n3 = object2.size();
            if (this.d.size() == 0) {
                for (n2 = 0; n2 < n3; ++n2) {
                    this.d.put(((com.d.a.a.f.c.h)object2.valueAt((int)n2)).f, (Object)new com.d.a.a.f.c.l(this.v.a_(n2)));
                }
                this.b();
                this.v.a();
            } else {
                n2 = this.d.size() == n3 ? 1 : 0;
                if (n2 == 0) {
                    throw new IllegalStateException();
                }
            }
            for (n2 = 0; n2 < n3; ++n2) {
                object4 = (com.d.a.a.f.c.h)object2.valueAt(n2);
                ((com.d.a.a.f.c.l)this.d.get(object4.f)).a((com.d.a.a.f.c.h)object4, (com.d.a.a.f.c.k)object.get(object4.f));
            }
        }
        this.l = 0;
        this.o = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(com.d.a.a.d.b b2, int n2, n n3) {
        b2.b(n2 + 8);
        n2 = c.d(b2.g());
        if ((n2 & 1) != 0) {
            throw new bb("Overriding TrackEncryptionBox parameters is unsupported.");
        }
        boolean bl2 = (n2 & 2) != 0;
        n2 = b2.k();
        if (n2 != n3.d) {
            throw new bb("Length mismatch: " + n2 + ", " + n3.d);
        }
        Arrays.fill(n3.j, 0, n2, bl2);
        n3.a(b2.c - b2.b);
        b2.a(n3.l.a, 0, n3.k);
        n3.l.b(0);
        n3.m = false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(b b2, SparseArray<com.d.a.a.f.c.l> sparseArray, int n2, byte[] arrby) {
        int n3 = b2.c.size();
        int n4 = 0;
        while (n4 < n3) {
            b b3 = b2.c.get(n4);
            if (b3.aD == c.L) {
                long l2;
                int n5;
                boolean[] arrbl;
                Object object;
                int n6 = c.z;
                int n7 = 0;
                int n8 = b3.b.size();
                for (n5 = 0; n5 < n8; ++n5) {
                    if (b3.b.get((int)n5).aD != n6) continue;
                    ++n7;
                }
                n8 = b3.c.size();
                for (n5 = 0; n5 < n8; ++n5) {
                    if (b3.c.get((int)n5).aD != n6) continue;
                    ++n7;
                }
                if (n7 != 1) {
                    throw new bb("Trun count in traf != 1 (unsupported).");
                }
                Object object2 = b3.a((int)c.x).a;
                object2.b(8);
                n8 = c.d(object2.g());
                n7 = object2.g();
                if ((n2 & 16) != 0) {
                    n7 = 0;
                }
                if ((arrbl = (com.d.a.a.f.c.l)sparseArray.get(n7)) == null) {
                    arrbl = null;
                } else {
                    if ((n8 & 1) != 0) {
                        arrbl.a.b = l2 = object2.m();
                        arrbl.a.c = l2;
                    }
                    object = arrbl.d;
                    n7 = (n8 & 2) != 0 ? object2.k() - 1 : object.a;
                    n5 = (n8 & 8) != 0 ? object2.k() : object.b;
                    n6 = (n8 & 16) != 0 ? object2.k() : object.c;
                    n8 = (n8 & 32) != 0 ? object2.k() : object.d;
                    arrbl.a.a = new com.d.a.a.f.c.k(n7, n5, n6, n8);
                }
                if (arrbl != null) {
                    long l3;
                    boolean bl2;
                    object2 = arrbl.a;
                    l2 = object2.n;
                    arrbl.a();
                    if (b3.a(c.w) != null && (n2 & 2) == 0) {
                        object = b3.a((int)c.w).a;
                        object.b(8);
                        l2 = c.c(object.g()) == 1 ? object.m() : object.e();
                    }
                    object = b3.a((int)c.z).a;
                    object.b(8);
                    n5 = c.d(object.g());
                    com.d.a.a.f.c.h h2 = arrbl.c;
                    n n9 = arrbl.a;
                    com.d.a.a.f.c.k k2 = n9.a;
                    int n10 = object.k();
                    if ((n5 & 1) != 0) {
                        n9.b += (long)object.g();
                    }
                    n6 = (n5 & 4) != 0 ? 1 : 0;
                    n7 = k2.d;
                    if (n6 != 0) {
                        n7 = object.k();
                    }
                    n8 = (n5 & 256) != 0 ? 1 : 0;
                    int n11 = (n5 & 512) != 0 ? 1 : 0;
                    boolean bl3 = (n5 & 1024) != 0;
                    boolean bl4 = (n5 & 2048) != 0;
                    long l4 = h2.m != null && h2.m.length == 1 && h2.m[0] == 0 ? ah.a(h2.n[0], 1000, h2.h) : 0;
                    n9.d = n10;
                    if (n9.e == null || n9.e.length < n9.d) {
                        n5 = n10 * 125 / 100;
                        n9.e = new int[n5];
                        n9.f = new int[n5];
                        n9.g = new long[n5];
                        n9.h = new boolean[n5];
                        n9.j = new boolean[n5];
                    }
                    int[] arrn = n9.e;
                    int[] arrn2 = n9.f;
                    long[] arrl = n9.g;
                    boolean[] arrbl2 = n9.h;
                    long l5 = h2.h;
                    boolean bl5 = h2.g == com.d.a.a.f.c.h.a && (n2 & 1) != 0;
                    for (int i2 = 0; i2 < n10; ++i2, l2 += l3) {
                        int n12 = n8 != 0 ? object.k() : k2.b;
                        int n13 = n11 != 0 ? object.k() : k2.c;
                        n5 = i2 == 0 && n6 != 0 ? n7 : (bl3 ? object.g() : k2.d);
                        arrn2[i2] = bl4 ? (int)((long)(object.g() * 1000) / l5) : 0;
                        arrl[i2] = ah.a(l2, 1000, l5) - l4;
                        arrn[i2] = n13;
                        bl2 = (n5 >> 16 & 1) == 0 && (!bl5 || i2 == 0);
                        arrbl2[i2] = bl2;
                        l3 = n12;
                    }
                    n9.n = l2;
                    object = b3.a(c.ac);
                    if (object != null) {
                        arrbl = arrbl.c.l[object2.a.a];
                        object = object.a;
                        n8 = arrbl.b;
                        object.b(8);
                        if ((c.d(object.g()) & 1) == 1) {
                            object.b(object.b + 8);
                        }
                        n7 = object.a();
                        n11 = object.k();
                        if (n11 != object2.d) {
                            throw new bb("Length mismatch: " + n11 + ", " + object2.d);
                        }
                        if (n7 != 0) {
                            bl2 = n7 > n8;
                            Arrays.fill(object2.j, 0, n11, bl2);
                            n6 = n7 * n11 + 0;
                        } else {
                            arrbl = object2.j;
                            n7 = 0;
                            n5 = 0;
                            do {
                                n6 = n7;
                                if (n5 >= n11) break;
                                n6 = object.a();
                                bl2 = n6 > n8;
                                arrbl[n5] = bl2;
                                ++n5;
                                n7 += n6;
                            } while (true);
                        }
                        object2.a(n6);
                    }
                    if ((arrbl = b3.a(c.ad)) != null) {
                        arrbl = arrbl.a;
                        arrbl.b(8);
                        n7 = arrbl.g();
                        if ((c.d(n7) & 1) == 1) {
                            arrbl.b(arrbl.b + 8);
                        }
                        if ((n5 = arrbl.k()) != 1) {
                            throw new bb("Unexpected saio entry count: " + n5);
                        }
                        n7 = c.c(n7);
                        l4 = object2.c;
                        l2 = n7 == 0 ? arrbl.e() : arrbl.m();
                        object2.c = l2 + l4;
                    }
                    if ((arrbl = b3.a(c.af)) != null) {
                        m.a(arrbl.a, 0, (n)object2);
                    }
                    n5 = b3.b.size();
                    for (n7 = 0; n7 < n5; ++n7) {
                        arrbl = b3.b.get(n7);
                        if (arrbl.aD != c.ae) continue;
                        arrbl = arrbl.a;
                        arrbl.b(8);
                        arrbl.a(arrby, 0, 16);
                        if (!Arrays.equals(arrby, a)) continue;
                        m.a((com.d.a.a.d.b)arrbl, 16, (n)object2);
                    }
                }
            }
            ++n4;
        }
    }

    private void b() {
        com.d.a.a.f.b b2;
        if ((this.b & 8) != 0 && this.w == null && (b2 = this.v.a_(this.d.size())) != null) {
            this.w = new com.d.a.a.f.d.a(b2);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(com.d.a.a.f.m var1_1, k var2_2) {
        block50 : {
            block48 : {
                block49 : {
                    block5 : do {
                        switch (this.l) {
                            default: {
                                if (this.l != 3) break block48;
                                if (this.r == null) {
                                    var20_15 = this.d;
                                    var2_2 = null;
                                    var8_8 = Long.MAX_VALUE;
                                    var4_4 = var20_15.size();
                                    for (var3_3 = 0; var3_3 < var4_4; ++var3_3) {
                                        var19_14 = (com.d.a.a.f.c.l)var20_15.valueAt(var3_3);
                                        if (var19_14.e == var19_14.a.d || (var10_9 = var19_14.a.b) >= var8_8) continue;
                                        var2_2 = var19_14;
                                        var8_8 = var10_9;
                                    }
                                    break;
                                }
                                break block49;
                            }
                            case 0: {
                                if (this.o == 0) {
                                    if (!var1_1.a(this.i.a, 0, 8, true)) {
                                        return -1;
                                    }
                                    this.o = 8;
                                    this.i.b(0);
                                    this.n = this.i.e();
                                    this.m = this.i.g();
                                }
                                if (this.n == 1) {
                                    var1_1.b(this.i.a, 8, 8);
                                    this.o += 8;
                                    this.n = this.i.m();
                                }
                                var8_8 = var1_1.c() - (long)this.o;
                                if (this.m == c.K) {
                                    var4_4 = this.d.size();
                                    for (var3_3 = 0; var3_3 < var4_4; ++var3_3) {
                                        var2_2 = ((com.d.a.a.f.c.l)this.d.valueAt((int)var3_3)).a;
                                        var2_2.c = var8_8;
                                        var2_2.b = var8_8;
                                    }
                                }
                                if (this.m == c.k) {
                                    this.r = null;
                                    this.q = this.n + var8_8;
                                    if (!this.x) {
                                        this.v.a(j.a);
                                        this.x = true;
                                    }
                                    this.l = 2;
                                } else {
                                    var3_3 = this.m;
                                    var3_3 = var3_3 == c.B || var3_3 == c.D || var3_3 == c.E || var3_3 == c.F || var3_3 == c.G || var3_3 == c.K || var3_3 == c.L || var3_3 == c.M || var3_3 == c.P ? 1 : 0;
                                    if (var3_3 != 0) {
                                        var8_8 = var1_1.c() + this.n - 8;
                                        this.k.add(new b(this.m, var8_8));
                                        if (this.n == (long)this.o) {
                                            this.a(var8_8);
                                        } else {
                                            this.l = 0;
                                            this.o = 0;
                                        }
                                    } else {
                                        var3_3 = this.m;
                                        var3_3 = var3_3 == c.S || var3_3 == c.R || var3_3 == c.C || var3_3 == c.A || var3_3 == c.T || var3_3 == c.w || var3_3 == c.x || var3_3 == c.O || var3_3 == c.y || var3_3 == c.z || var3_3 == c.U || var3_3 == c.ac || var3_3 == c.ad || var3_3 == c.af || var3_3 == c.ae || var3_3 == c.Q || var3_3 == c.N ? 1 : 0;
                                        if (var3_3 != 0) {
                                            if (this.o != 8) {
                                                throw new bb("Leaf atom defines extended atom size (unsupported).");
                                            }
                                            if (this.n > Integer.MAX_VALUE) {
                                                throw new bb("Leaf atom with length > 2147483647 (unsupported).");
                                            }
                                            this.p = new com.d.a.a.d.b((int)this.n);
                                            System.arraycopy(this.i.a, 0, this.p.a, 0, 8);
                                            this.l = 1;
                                        } else {
                                            if (this.n > Integer.MAX_VALUE) {
                                                throw new bb("Skipping atom with length > 2147483647 (unsupported).");
                                            }
                                            this.p = null;
                                            this.l = 1;
                                        }
                                    }
                                }
                                if ((var3_3 = 1) != 0) continue block5;
                                return -1;
                            }
                            case 1: {
                                var3_3 = (int)this.n - this.o;
                                if (this.p != null) {
                                    var1_1.b(this.p.a, 8, var3_3);
                                    var2_2 = new a(this.m, this.p);
                                    var10_9 = var1_1.c();
                                    if (!this.k.isEmpty()) {
                                        this.k.peek().b.add((a)var2_2);
                                    } else if (var2_2.aD == c.A) {
                                        var2_2 = var2_2.a;
                                        var2_2.b(8);
                                        var3_3 = c.c(var2_2.g());
                                        var2_2.b(var2_2.b + 4);
                                        var16_12 = var2_2.e();
                                        if (var3_3 == 0) {
                                            var8_8 = var2_2.e();
                                            var10_9 = var2_2.e() + var10_9;
                                        } else {
                                            var8_8 = var2_2.m();
                                            var10_9 = var2_2.m() + var10_9;
                                        }
                                        var2_2.b(var2_2.b + 2);
                                        var4_4 = var2_2.b();
                                        var19_14 = new int[var4_4];
                                        var20_15 = new long[var4_4];
                                        var21_16 = new long[var4_4];
                                        var22_17 = new long[var4_4];
                                        var14_11 = ah.a(var8_8, 1000000, var16_12);
                                        var12_10 = var8_8;
                                        var8_8 = var10_9;
                                        var10_9 = var14_11;
                                        break block50;
                                    }
                                } else {
                                    var1_1.b(var3_3);
                                }
lbl108: // 4 sources:
                                do {
                                    this.a(var1_1.c());
                                    continue block5;
                                    break;
                                } while (true);
                            }
                            case 2: {
                                var2_2 = null;
                                var8_8 = Long.MAX_VALUE;
                                var4_4 = this.d.size();
                                for (var3_3 = 0; var3_3 < var4_4; ++var3_3) {
                                    var19_14 = ((com.d.a.a.f.c.l)this.d.valueAt((int)var3_3)).a;
                                    if (!var19_14.m || var19_14.c >= var8_8) continue;
                                    var8_8 = var19_14.c;
                                    var2_2 = (com.d.a.a.f.c.l)this.d.valueAt(var3_3);
                                }
                                if (var2_2 == null) {
                                    this.l = 3;
                                    continue block5;
                                }
                                var3_3 = (int)(var8_8 - var1_1.c());
                                if (var3_3 < 0) {
                                    throw new bb("Offset to encryption data was negative.");
                                }
                                var1_1.b(var3_3);
                                var2_2 = var2_2.a;
                                var1_1.b(var2_2.l.a, 0, var2_2.k);
                                var2_2.l.b(0);
                                var2_2.m = false;
                                continue block5;
                            }
                        }
                        this.r = var2_2;
                        if (this.r != null) break;
                        var3_3 = (int)(this.q - var1_1.c());
                        if (var3_3 < 0) {
                            throw new bb("Offset to end of mdat was negative.");
                        }
                        var1_1.b(var3_3);
                        this.l = 0;
                        this.o = 0;
                        var3_3 = 0;
                        if (var3_3 != 0) return 0;
                    } while (true);
                    var3_3 = (int)(this.r.a.b - var1_1.c());
                    if (var3_3 < 0) {
                        throw new bb("Offset to sample data was negative.");
                    }
                    var1_1.b(var3_3);
                }
                this.s = this.r.a.e[this.r.e];
                if (this.r.a.i) {
                    var19_14 = this.r;
                    var20_15 = var19_14.a;
                    var2_2 = var20_15.l;
                    var3_3 = var20_15.a.a;
                    var4_4 = var19_14.c.l[var3_3].b;
                    var18_13 = var20_15.j[var19_14.e];
                    var20_15 = this.h.a;
                    var3_3 = var18_13 != false ? 128 : 0;
                    var20_15[0] = (byte)(var3_3 | var4_4);
                    this.h.b(0);
                    var19_14 = var19_14.b;
                    var19_14.a(this.h, 1);
                    var19_14.a((com.d.a.a.d.b)var2_2, var4_4);
                    if (!var18_13) {
                        var3_3 = var4_4 + 1;
                    } else {
                        var3_3 = var2_2.b();
                        var2_2.b(var2_2.b - 2);
                        var3_3 = var3_3 * 6 + 2;
                        var19_14.a((com.d.a.a.d.b)var2_2, var3_3);
                        var3_3 = var4_4 + 1 + var3_3;
                    }
                    this.t = var3_3;
                    this.s += this.t;
                } else {
                    this.t = 0;
                }
                this.l = 4;
                this.u = 0;
            }
            var19_14 = this.r.a;
            var21_16 = this.r.c;
            var20_15 = this.r.b;
            var4_4 = this.r.e;
            if (var21_16.o == -1) ** GOTO lbl191
            var2_2 = this.f.a;
            var2_2[0] = 0;
            var2_2[1] = false;
            var2_2[2] = false;
            var5_5 = var21_16.o;
            var6_6 = 4 - var21_16.o;
            ** GOTO lbl212
lbl191: // 2 sources:
            while (this.t < this.s) {
                this.t = var20_15.a(var1_1, this.s - this.t, false) + this.t;
            }
            ** GOTO lbl244
        }
        for (var3_3 = 0; var3_3 < var4_4; var8_8 += (long)var19_14[var3_3], ++var3_3) {
            var5_5 = var2_2.g();
            if ((Integer.MIN_VALUE & var5_5) != 0) {
                throw new bb("Unhandled indirect reference");
            }
            var14_11 = var2_2.e();
            var19_14[var3_3] = var5_5 & Integer.MAX_VALUE;
            var20_15[var3_3] = (byte)var8_8;
            var22_17[var3_3] = var10_9;
            var10_9 = ah.a(var12_10 += var14_11, 1000000, var16_12);
            var21_16[var3_3] = var10_9 - var22_17[var3_3];
            var2_2.b(var2_2.b + 4);
        }
        var2_2 = new l(var19_14, var20_15, var21_16, (long[])var22_17);
        this.v.a((j)var2_2);
        this.x = true;
        ** while (true)
lbl212: // 5 sources:
        while (this.t < this.s) {
            if (this.u == 0) {
                var1_1.b(this.f.a, var6_6, var5_5);
                this.f.b(0);
                this.u = this.f.k();
                this.e.b(0);
                var20_15.a(this.e, 4);
                this.t += 4;
                this.s += var6_6;
                if (this.w == null) continue;
                var1_1.c(this.g.a, 0, 1);
                if ((this.g.a[0] & 31) != 6) continue;
                var22_17 = this.g;
                var7_7 = this.u;
                var3_3 = var22_17.a == null ? 0 : var22_17.a.length;
                var2_2 = var3_3 < var7_7 ? new byte[var7_7] : var22_17.a;
                var22_17.a = var2_2;
                var22_17.c = var7_7;
                var22_17.b = 0;
                var1_1.b(this.g.a, 0, this.u);
                var20_15.a(this.g, this.u);
                this.t += this.u;
                this.u = 0;
                var3_3 = com.d.a.a.d.q.a(this.g.a, this.g.c);
                this.g.b(1);
                this.g.a(var3_3);
                this.w.a((var19_14.g[var4_4] + (long)var19_14.f[var4_4]) * 1000, this.g);
                continue;
            }
            var3_3 = var20_15.a(var1_1, this.u, false);
            this.t += var3_3;
            this.u -= var3_3;
        }
lbl244: // 2 sources:
        var8_8 = var19_14.g[var4_4];
        var10_9 = var19_14.f[var4_4];
        var3_3 = var19_14.i != false ? 2 : 0;
        var4_4 = var19_14.h[var4_4] != false ? 1 : 0;
        var5_5 = var19_14.a.a;
        var2_2 = var19_14.i != false ? var21_16.l[var5_5].c : null;
        var20_15.a((var8_8 + var10_9) * 1000, var4_4 | var3_3, this.s, 0, var2_2);
        var2_2 = this.r;
        ++var2_2.e;
        if (this.r.e == var19_14.d) {
            this.r = null;
        }
        this.l = 3;
        return 0;
    }

    @Override
    public final void a(g object) {
        this.v = object;
        if (this.c != null) {
            object = new com.d.a.a.f.c.l(object.a_(0));
            object.a(this.c, new com.d.a.a.f.c.k(0, 0, 0, 0));
            this.d.put(0, object);
            this.b();
            this.v.a();
        }
    }

    @Override
    public final boolean a(com.d.a.a.f.m m2) {
        return r.a(m2, 4096, true);
    }

    @Override
    public final void c_() {
        int n2 = this.d.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            ((com.d.a.a.f.c.l)this.d.valueAt(i2)).a();
        }
        this.k.clear();
        this.l = 0;
        this.o = 0;
    }
}

