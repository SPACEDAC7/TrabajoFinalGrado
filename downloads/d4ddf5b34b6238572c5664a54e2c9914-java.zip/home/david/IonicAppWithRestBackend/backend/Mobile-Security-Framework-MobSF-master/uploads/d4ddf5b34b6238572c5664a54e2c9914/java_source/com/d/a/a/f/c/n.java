/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import com.d.a.a.d.b;
import com.d.a.a.f.c.k;

final class n {
    public k a;
    public long b;
    public long c;
    public int d;
    public int[] e;
    public int[] f;
    public long[] g;
    public boolean[] h;
    public boolean i;
    public boolean[] j;
    public int k;
    public b l;
    public boolean m;
    public long n;

    n() {
    }

    public final void a(int n2) {
        if (this.l == null || this.l.c < n2) {
            this.l = new b(n2);
        }
        this.k = n2;
        this.i = true;
        this.m = true;
    }
}

