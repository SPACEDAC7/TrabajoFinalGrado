/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import com.d.a.a.f.b;
import com.d.a.a.f.c.h;
import com.d.a.a.f.c.i;

final class o {
    public final h a;
    public final i b;
    public final b c;
    public int d;

    public o(h h2, i i2, b b2) {
        this.a = h2;
        this.b = i2;
        this.c = b2;
    }
}

