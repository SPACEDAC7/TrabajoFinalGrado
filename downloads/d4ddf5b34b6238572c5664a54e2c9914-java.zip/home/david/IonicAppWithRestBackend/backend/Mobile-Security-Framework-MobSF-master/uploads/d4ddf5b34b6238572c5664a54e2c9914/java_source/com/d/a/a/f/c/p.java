/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import com.d.a.a.d.ah;
import com.d.a.a.f.c.a;
import com.d.a.a.f.c.b;
import com.d.a.a.f.c.c;
import com.d.a.a.f.c.i;
import com.d.a.a.f.c.o;
import com.d.a.a.f.c.r;
import com.d.a.a.f.g;
import com.d.a.a.f.h;
import com.d.a.a.f.j;
import com.d.a.a.f.k;
import com.d.a.a.f.m;
import com.d.a.a.f.v;
import com.d.a.a.q;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public final class p
implements h,
j {
    private static final int b = ah.e("qt  ");
    private final com.d.a.a.d.b c = new com.d.a.a.d.b(com.d.a.a.d.q.a);
    private final com.d.a.a.d.b d = new com.d.a.a.d.b(4);
    private final com.d.a.a.d.b e = new com.d.a.a.d.b(16);
    private final Stack<b> f = new Stack();
    private int g;
    private int h;
    private long i;
    private int j;
    private com.d.a.a.d.b k;
    private int l;
    private int m;
    private int n;
    private g o;
    private o[] p;
    private boolean q;
    private final boolean r;
    private int s;

    public p() {
        this(true);
    }

    public p(boolean bl2) {
        this.r = bl2;
        this.g = 1;
        this.j = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(long l2) {
        while (!this.f.isEmpty() && this.f.peek().a == l2) {
            b b2 = this.f.pop();
            if (b2.aD == c.B) {
                ArrayList<o> arrayList = new ArrayList<o>();
                Object object = b2.a(c.aw);
                object = object != null ? com.d.a.a.f.c.g.a((a)object, this.q) : null;
                for (int i2 = 0; i2 < b2.c.size(); ++i2) {
                    Object object2;
                    Object object3 = b2.c.get(i2);
                    if (object3.aD != c.D || (object2 = com.d.a.a.f.c.g.a((b)object3, b2.a(c.C), -1, this.q)) == null) continue;
                    object3 = com.d.a.a.f.c.g.a((com.d.a.a.f.c.h)object2, object3.b(c.E).b(c.F).b(c.G));
                    if (object3.a == 0) continue;
                    o o2 = new o((com.d.a.a.f.c.h)object2, (i)object3, this.o.a_(i2));
                    int n2 = object3.d;
                    object2 = object2.k;
                    object2 = object3 = new q(object2.a, object2.b, object2.c, n2 + 30, object2.e, object2.h, object2.i, object2.l, object2.m, object2.n, object2.o, object2.r, object2.s, object2.f, object2.g, object2.j, object2.k, object2.p, object2.q);
                    if (object != null) {
                        object2 = object3.a(object.a, object.b);
                    }
                    o2.c.a((q)object2);
                    arrayList.add(o2);
                }
                this.p = arrayList.toArray(new o[0]);
                this.o.a();
                this.o.a(this);
                this.f.clear();
                this.g = 3;
                continue;
            }
            if (this.f.isEmpty()) continue;
            this.f.peek().c.add(b2);
        }
        if (this.g != 3) {
            this.g = 1;
            this.j = 0;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(m var1_1, k var2_2) {
        block45 : {
            block44 : {
                block43 : {
                    block5 : do {
                        switch (this.g) {
                            default: {
                                if (!this.r) break;
                                var5_9 = -1;
                                var7_7 = Long.MAX_VALUE;
                                var4_10 = 0;
                                do {
                                    var3_3 = var5_9;
                                    if (var4_10 >= this.p.length) return -1;
                                    var20_5 = this.p[var4_10];
                                    var6_11 = var20_5.d;
                                    var3_3 = var5_9;
                                    var9_8 = var7_7;
                                    if (var6_11 != var20_5.b.a) {
                                        var11_12 = var20_5.b.b[var6_11];
                                        var3_3 = var5_9;
                                        var9_8 = var7_7;
                                        if (var11_12 < var7_7) {
                                            var9_8 = var11_12;
                                            var3_3 = var4_10;
                                        }
                                    }
                                    ++var4_10;
                                    var5_9 = var3_3;
                                    var7_7 = var9_8;
                                } while (true);
                            }
                            case 0: {
                                if (var1_1.d == 0) {
                                    this.g = 1;
                                    this.j = 0;
                                    continue block5;
                                }
                                this.g = 3;
                                continue block5;
                            }
                            case 1: {
                                if (this.j == 0) {
                                    if (!var1_1.a(this.e.a, 0, 8, true)) {
                                        return -1;
                                    }
                                    this.j = 8;
                                    this.e.b(0);
                                    this.i = this.e.e();
                                    this.h = this.e.g();
                                }
                                if (this.i == 1) {
                                    var1_1.b(this.e.a, 8, 8);
                                    this.j += 8;
                                    this.i = this.e.m();
                                }
                                var3_3 = (var3_3 = this.h) == c.B || var3_3 == c.D || var3_3 == c.E || var3_3 == c.F || var3_3 == c.G || var3_3 == c.P ? 1 : 0;
                                if (var3_3 != 0) {
                                    var7_7 = var1_1.d + this.i - (long)this.j;
                                    this.f.add(new b(this.h, var7_7));
                                    if (this.i == (long)this.j) {
                                        this.b(var7_7);
                                    } else {
                                        this.g = 1;
                                        this.j = 0;
                                    }
                                } else {
                                    var3_3 = this.h;
                                    var3_3 = var3_3 == c.R || var3_3 == c.C || var3_3 == c.S || var3_3 == c.T || var3_3 == c.ak || var3_3 == c.al || var3_3 == c.am || var3_3 == c.Q || var3_3 == c.an || var3_3 == c.ao || var3_3 == c.ap || var3_3 == c.aq || var3_3 == c.O || var3_3 == c.d || var3_3 == c.aw ? 1 : 0;
                                    if (var3_3 != 0) {
                                        var3_3 = this.j == 8 ? 1 : 0;
                                        if (var3_3 == 0) {
                                            throw new IllegalStateException();
                                        }
                                        var3_3 = this.i <= Integer.MAX_VALUE ? 1 : 0;
                                        if (var3_3 == 0) {
                                            throw new IllegalStateException();
                                        }
                                        this.k = new com.d.a.a.d.b((int)this.i);
                                        System.arraycopy(this.e.a, 0, this.k.a, 0, 8);
                                        this.g = 2;
                                    } else {
                                        this.k = null;
                                        this.g = 2;
                                    }
                                }
                                if ((var3_3 = 1) != 0) continue block5;
                                return -1;
                            }
                            case 2: {
                                var7_7 = this.i - (long)this.j;
                                var9_8 = var1_1.d;
                                if (this.k == null) ** GOTO lbl98
                                var1_1.b(this.k.a, this.j, (int)var7_7);
                                if (this.h != c.d) ** GOTO lbl92
                                var20_5 = this.k;
                                var20_5.b(8);
                                if (var20_5.g() != p.b) ** GOTO lbl83
                                var19_4 = true;
                                ** GOTO lbl89
lbl83: // 1 sources:
                                var20_5.b(var20_5.b + 4);
                                while (var20_5.c - var20_5.b > 0) {
                                    if (var20_5.g() != p.b) continue;
                                    var19_4 = true;
                                    ** GOTO lbl89
                                }
                                var19_4 = false;
lbl89: // 3 sources:
                                this.q = var19_4;
                                var3_3 = 0;
                                ** GOTO lbl116
lbl92: // 1 sources:
                                if (this.f.isEmpty()) ** GOTO lbl115
                                var20_5 = this.f.peek();
                                var21_6 = new a(this.h, this.k);
                                var20_5.b.add((a)var21_6);
                                var3_3 = 0;
                                ** GOTO lbl116
lbl98: // 1 sources:
                                if (var7_7 < 262144) {
                                    var1_1.b((int)var7_7);
                                    var3_3 = 0;
                                } else {
                                    var2_2.a = var1_1.d + var7_7;
                                    var3_3 = 1;
                                }
                                ** GOTO lbl116
                            }
                        }
                        if (this.p.length == 1) {
                            var20_5 = this.p[0];
                            if (var20_5.d == var20_5.b.a) {
                                return -1;
                            }
                            var3_3 = 0;
                            break;
                        }
                        var11_12 = Long.MAX_VALUE;
                        var4_10 = -1;
                        var9_8 = Long.MAX_VALUE;
                        break block43;
lbl115: // 1 sources:
                        var3_3 = 0;
lbl116: // 5 sources:
                        this.b(var9_8 + var7_7);
                        if (var3_3 != 0 && this.g != 3) {
                            return 1;
                        }
                        var3_3 = 0;
                        if (var3_3 != 0) return 1;
                    } while (true);
lbl122: // 2 sources:
                    do {
                        if (var3_3 == -1) {
                            return -1;
                        }
                        var20_5 = this.p[var3_3];
                        var21_6 = var20_5.c;
                        var3_3 = var20_5.d;
                        var7_7 = var20_5.b.b[var3_3];
                        var9_8 = var7_7 - var1_1.d + (long)this.m;
                        if (var9_8 < 0 || var9_8 >= 262144) {
                            var2_2.a = var7_7;
                            return 1;
                        }
                        var1_1.b((int)var9_8);
                        this.l = var20_5.b.c[var3_3];
                        if (var20_5.a.o != -1) {
                            var2_2 = this.d.a;
                            var2_2[0] = 0;
                            var2_2[1] = 0;
                            var2_2[2] = 0;
                            var4_10 = var20_5.a.o;
                            var5_9 = 4 - var20_5.a.o;
                            break block44;
                        }
                        while (this.m < this.l) {
                            var4_10 = var21_6.a(var1_1, this.l - this.m, false);
                            this.m += var4_10;
                            this.n -= var4_10;
                        }
                        break block45;
                        break;
                    } while (true);
                }
                for (var3_3 = 0; var3_3 < this.p.length; ++var3_3) {
                    var20_5 = this.p[var3_3];
                    var5_9 = var20_5.d;
                    if (var5_9 == var20_5.b.a) {
                        var5_9 = var4_10;
                        var13_13 = var9_8;
                        var17_15 = var11_12;
                        if (var3_3 == this.s) {
                            this.s = -1;
                            var17_15 = var11_12;
                            var13_13 = var9_8;
                            var5_9 = var4_10;
                        }
                    } else {
                        var15_14 = var20_5.b.e[var5_9];
                        var7_7 = var9_8;
                        if (var15_14 < var9_8) {
                            var7_7 = var15_14;
                            var4_10 = var3_3;
                        }
                        var5_9 = var4_10;
                        var13_13 = var7_7;
                        var17_15 = var11_12;
                        if (var3_3 == this.s) {
                            var5_9 = var4_10;
                            var13_13 = var7_7;
                            var17_15 = var15_14;
                        }
                    }
                    var4_10 = var5_9;
                    var9_8 = var13_13;
                    var11_12 = var17_15;
                }
                if (this.s == -1) {
                    this.s = var4_10;
                } else if (var11_12 - var9_8 > 3000000) {
                    this.s = var4_10;
                }
                var3_3 = this.s;
                ** while (true)
            }
            while (this.m < this.l) {
                if (this.n == 0) {
                    var1_1.b(this.d.a, var5_9, var4_10);
                    this.d.b(0);
                    this.n = this.d.k();
                    this.c.b(0);
                    var21_6.a(this.c, 4);
                    this.m += 4;
                    this.l += var5_9;
                    continue;
                }
                var6_11 = var21_6.a(var1_1, this.n, false);
                this.m += var6_11;
                this.n -= var6_11;
            }
        }
        var21_6.a(var20_5.b.e[var3_3], var20_5.b.f[var3_3], this.l, 0, null);
        ++var20_5.d;
        this.m = 0;
        this.n = 0;
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a(long l2) {
        long l3 = Long.MAX_VALUE;
        int n2 = 0;
        while (n2 < this.p.length) {
            int n3;
            block8 : {
                int n4;
                block7 : {
                    i i2 = this.p[n2].b;
                    for (n4 = ah.a((long[])i2.e, (long)l2, (boolean)false); n4 >= 0; --n4) {
                        if ((i2.f[n4] & 1) == 0) {
                            continue;
                        }
                        break block7;
                    }
                    n4 = -1;
                }
                n3 = n4;
                if (n4 == -1) {
                    for (n3 = ah.a((long[])i2.e, (long)l2, (boolean)true, (boolean)false); n3 < i2.e.length; ++n3) {
                        if ((i2.f[n3] & 1) == 0) {
                            continue;
                        }
                        break block8;
                    }
                    n3 = -1;
                }
            }
            this.p[n2].d = n3;
            long l4 = i2.b[n3];
            long l5 = l3;
            if (l4 < l3) {
                l5 = l4;
            }
            ++n2;
            l3 = l5;
        }
        return l3;
    }

    @Override
    public final void a(g g2) {
        this.o = g2;
    }

    @Override
    public final boolean a() {
        return true;
    }

    @Override
    public final boolean a(m m2) {
        return r.a(m2, 128, false);
    }

    @Override
    public final void c_() {
        this.f.clear();
        this.j = 0;
        this.m = 0;
        this.n = 0;
        this.g = 0;
    }
}

