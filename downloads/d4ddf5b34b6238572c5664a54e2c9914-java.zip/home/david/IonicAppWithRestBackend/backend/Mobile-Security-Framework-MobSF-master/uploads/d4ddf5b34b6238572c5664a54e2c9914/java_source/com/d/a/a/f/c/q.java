/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  android.util.Pair
 */
package com.d.a.a.f.c;

import android.util.Log;
import android.util.Pair;
import com.d.a.a.d.b;
import com.d.a.a.f.c.c;
import java.util.UUID;

public final class q {
    /*
     * Enabled aggressive block sorting
     */
    public static UUID a(byte[] object) {
        object = new b((byte[])object);
        if (object.c < 32) {
            return null;
        }
        object.b(0);
        if (object.g() != object.c - object.b + 4) {
            return null;
        }
        if (object.g() != c.U) {
            return null;
        }
        int n2 = c.c(object.g());
        if (n2 > 1) {
            Log.w((String)"PsshAtomUtil", (String)("Unsupported pssh version: " + n2));
            return null;
        }
        UUID uUID = new UUID(object.i(), object.i());
        if (n2 == 1) {
            object.b(object.k() * 16 + object.b);
        }
        if ((n2 = object.k()) != object.c - object.b) {
            return null;
        }
        byte[] arrby = new byte[n2];
        object.a(arrby, 0, n2);
        object = Pair.create((Object)uUID, (Object)arrby);
        if (object == null) {
            return null;
        }
        return (UUID)object.first;
    }
}

