/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.c;

import com.d.a.a.d.ah;
import com.d.a.a.d.b;
import com.d.a.a.f.c.c;
import com.d.a.a.f.m;

public final class r {
    private static final int[] a = new int[]{ah.e("isom"), ah.e("iso2"), ah.e("iso3"), ah.e("iso4"), ah.e("iso5"), ah.e("iso6"), ah.e("avc1"), ah.e("hvc1"), ah.e("hev1"), ah.e("mp41"), ah.e("mp42"), ah.e("3g2a"), ah.e("3g2b"), ah.e("3gr6"), ah.e("3gs6"), ah.e("3ge6"), ah.e("3gg6"), ah.e("M4V "), ah.e("M4A "), ah.e("f4v "), ah.e("kddi"), ah.e("M4VP"), ah.e("qt  "), ah.e("MSNV")};

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean a(m var0, int var1_1, boolean var2_2) {
        block13 : {
            var14_3 = var0.d();
            if (var14_3 != -1) {
                var12_4 = var14_3;
                if (var14_3 <= (long)var1_1) break block13;
            }
            var12_4 = var1_1;
        }
        var6_5 = (int)var12_4;
        var16_6 = new b(64);
        var1_1 = 0;
        var11_7 = false;
        var4_8 = 0;
        block0 : do {
            var10_14 = var11_7;
            if (var4_8 >= var6_5) return false;
            var0.c(var16_6.a, 0, 8);
            var16_6.b(0);
            var12_4 = var16_6.e();
            var5_10 = var16_6.g();
            if (var12_4 != 1) break;
            var0.c(var16_6.a, 8, 8);
            var12_4 = var16_6.i();
            var3_9 = 16;
lbl23: // 2 sources:
            do {
                block14 : {
                    if (var12_4 < (long)var3_9) {
                        return false;
                    }
                    var3_9 = (int)var12_4 - var3_9;
                    if (var5_10 != c.d) ** GOTO lbl57
                    if (var3_9 < 8) {
                        return false;
                    }
                    var7_11 = (var3_9 - 8) / 4;
                    var0.c(var16_6.a, 0, (var7_11 + 2) * 4);
                    var5_10 = 0;
                    do {
                        var3_9 = var1_1;
                        if (var5_10 >= var7_11 + 2) ** GOTO lbl42
                        if (var5_10 == 1) ** GOTO lbl55
                        var8_12 = var16_6.g();
                        if (var8_12 >>> 8 != ah.e("3gp")) ** GOTO lbl47
                        var3_9 = 1;
lbl40: // 3 sources:
                        while (var3_9 != 0) {
                            var3_9 = 1;
lbl42: // 2 sources:
                            var5_10 = var3_9;
                            if (var3_9 == 0) {
                                return false;
                            }
                            break block14;
                        }
                        ** GOTO lbl55
lbl47: // 1 sources:
                        var17_15 = r.a;
                        var9_13 = var17_15.length;
                        for (var3_9 = 0; var3_9 < var9_13; ++var3_9) {
                            if (var17_15[var3_9] != var8_12) continue;
                            var3_9 = 1;
                            ** GOTO lbl40
                        }
                        var3_9 = 0;
                        ** GOTO lbl40
lbl55: // 2 sources:
                        ++var5_10;
                    } while (true);
lbl57: // 1 sources:
                    if (var5_10 == c.K) {
                        var10_14 = true;
                        do {
                            if (var1_1 == 0) return false;
                            if (var2_2 != var10_14) return false;
                            return true;
                            break;
                        } while (true);
                    }
                    var5_10 = var1_1;
                    if (var3_9 != 0) {
                        var10_14 = var11_7;
                        if ((long)var4_8 + var12_4 >= (long)var6_5) ** continue;
                        var0.c(var3_9);
                        var5_10 = var1_1;
                    }
                }
                var4_8 = (int)((long)var4_8 + var12_4);
                var1_1 = var5_10;
                continue block0;
                break;
            } while (true);
            break;
        } while (true);
        var3_9 = 8;
        ** while (true)
    }
}

