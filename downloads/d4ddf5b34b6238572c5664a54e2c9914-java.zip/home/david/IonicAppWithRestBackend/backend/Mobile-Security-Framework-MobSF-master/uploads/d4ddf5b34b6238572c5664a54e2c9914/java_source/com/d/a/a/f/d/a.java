/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.f.b;
import com.d.a.a.q;

public final class a {
    private final b a;

    public a(b b2) {
        this.a = b2;
        b2.a(q.a(null, "application/eia-608", -1, -1, null, Long.MAX_VALUE));
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(long l2, com.d.a.a.d.b b2) {
        while (b2.c - b2.b > 1) {
            int n2;
            int n3;
            int n4;
            int n5 = 0;
            do {
                n2 = b2.a();
                n5 = n3 = n5 + n2;
            } while (n2 == 255);
            n5 = 0;
            do {
                n4 = b2.a();
                n5 = n2 = n5 + n4;
            } while (n4 == 255);
            n5 = n4 = 0;
            if (n3 == 4) {
                if (n2 < 8) {
                    n5 = n4;
                } else {
                    n5 = b2.b;
                    n3 = b2.a();
                    int n6 = b2.b();
                    int n7 = b2.g();
                    int n8 = b2.a();
                    b2.b(n5);
                    n5 = n4;
                    if (n3 == 181) {
                        n5 = n4;
                        if (n6 == 49) {
                            n5 = n4;
                            if (n7 == 1195456820) {
                                n5 = n4;
                                if (n8 == 3) {
                                    n5 = 1;
                                }
                            }
                        }
                    }
                }
                if (n5 != 0) {
                    this.a.a(b2, n2);
                    this.a.a(l2, 1, n2, 0, null);
                    continue;
                }
            }
            b2.b(b2.b + n2);
        }
        return;
    }
}

