/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.d.x;
import com.d.a.a.f.d.c;
import com.d.a.a.q;

final class b
extends c {
    private final boolean b;
    private final com.d.a.a.d.c c;
    private final com.d.a.a.d.b d;
    private int e;
    private int f;
    private boolean g;
    private long h;
    private q i;
    private int j;
    private long k;

    public b(com.d.a.a.f.b b2, boolean bl2) {
        super(b2);
        this.b = bl2;
        this.c = new com.d.a.a.d.c(new byte[8]);
        this.d = new com.d.a.a.d.b(this.c.a);
        this.e = 0;
    }

    @Override
    public final void a() {
        this.e = 0;
        this.f = 0;
        this.g = false;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.k = l2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(com.d.a.a.d.b var1_1) {
        block5 : while (var1_1.c - var1_1.b > 0) {
            block14 : {
                switch (this.e) {
                    default: {
                        ** break;
                    }
                    case 0: {
                        ** GOTO lbl52
                    }
                    case 1: {
                        var5_5 = this.d.a;
                        var2_2 = Math.min(var1_1.c - var1_1.b, 8 - this.f);
                        var1_1.a(var5_5, this.f, var2_2);
                        this.f += var2_2;
                        var2_2 = this.f == 8 ? 1 : 0;
                        if (var2_2 == 0) continue block5;
                        if (this.i == null) {
                            var5_5 = this.b != false ? x.b(this.c) : x.a(this.c);
                            this.i = var5_5;
                            this.a.a(this.i);
                        }
                        if (this.b) {
                            var5_5 = this.c.a;
                            var2_2 = (((var5_5[2] & 7) << 8) + (var5_5[3] & 255) + 1) * 2;
                        } else {
                            var5_5 = this.c.a;
                            var3_3 = var5_5[4];
                            var2_2 = var5_5[4] & 63;
                            if ((var3_3 = x.b[(var3_3 & 192) >> 6]) != 44100) break;
                            var2_2 = (x.f[var2_2 / 2] + var2_2 % 2) * 2;
                        }
                        ** GOTO lbl39
                    }
                    case 2: {
                        var2_2 = Math.min(var1_1.c - var1_1.b, this.j - this.f);
                        this.a.a(var1_1, var2_2);
                        this.f = var2_2 + this.f;
                        if (this.f != this.j) continue block5;
                        this.a.a(this.k, 1, this.j, 0, null);
                        this.k += this.h;
                        this.e = 0;
                        ** break;
                    }
                }
                var2_2 = x.e[var2_2 / 2];
                var2_2 = var3_3 == 32000 ? (var2_2 *= 6) : (var2_2 *= 4);
lbl39: // 3 sources:
                this.j = var2_2;
                if (this.b) {
                    var5_5 = this.c.a;
                    var2_2 = (var5_5[4] & 192) >> 6 == 3 ? 6 : x.a[(var5_5[4] & 48) >> 4];
                }
                var2_2 = 1536;
lbl44: // 2 sources:
                do {
                    this.h = (int)((long)var2_2 * 1000000 / (long)this.i.o);
                    this.d.b(0);
                    this.a.a(this.d, 8);
                    this.e = 2;
                    ** break;
                    break;
                } while (true);
                var2_2 *= 256;
                ** continue;
lbl52: // 3 sources:
                while (var1_1.c - var1_1.b > 0) {
                    if (!this.g) {
                        var4_4 = var1_1.a() == 11;
                        this.g = var4_4;
                        continue;
                    }
                    var2_2 = var1_1.a();
                    if (var2_2 == 119) {
                        this.g = false;
                        var2_2 = 1;
                        break block14;
                    }
                    var4_4 = var2_2 == 11;
                    this.g = var4_4;
                }
                var2_2 = 0;
            }
            if (var2_2 == 0) continue;
            this.e = 1;
            this.d.a[0] = 11;
            this.d.a[1] = 119;
            this.f = 2;
            ** break;
lbl73: // 4 sources:
        }
    }

    @Override
    public final void b() {
    }
}

