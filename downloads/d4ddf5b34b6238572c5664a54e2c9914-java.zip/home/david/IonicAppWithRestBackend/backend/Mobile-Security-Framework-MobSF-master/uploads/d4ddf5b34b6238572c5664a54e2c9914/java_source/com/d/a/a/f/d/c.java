/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.f.b;

public abstract class c {
    protected final b a;

    protected c(b b2) {
        this.a = b2;
    }

    public abstract void a();

    public abstract void a(long var1, boolean var3);

    public abstract void a(com.d.a.a.d.b var1);

    public abstract void b();
}

