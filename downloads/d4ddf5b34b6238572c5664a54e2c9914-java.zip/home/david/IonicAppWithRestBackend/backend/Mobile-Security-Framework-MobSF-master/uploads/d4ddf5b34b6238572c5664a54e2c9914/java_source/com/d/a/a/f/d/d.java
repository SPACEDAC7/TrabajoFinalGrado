/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.d.ah;
import com.d.a.a.d.c;
import com.d.a.a.f.b;
import com.d.a.a.f.d.e;
import com.d.a.a.f.g;
import com.d.a.a.f.h;
import com.d.a.a.f.j;
import com.d.a.a.f.k;
import com.d.a.a.f.m;

public final class d
implements h {
    private static final int a = ah.e("ID3");
    private final long b = 0;
    private final com.d.a.a.d.b c = new com.d.a.a.d.b(200);
    private e d;
    private boolean e;

    public d() {
        this(0);
    }

    private d(byte by2) {
    }

    @Override
    public final int a(m m2, k k2) {
        int n2 = m2.a(this.c.a, 0, 200);
        if (n2 == -1) {
            return -1;
        }
        this.c.b(0);
        this.c.a(n2);
        if (!this.e) {
            this.d.b = this.b;
            this.e = true;
        }
        this.d.a(this.c);
        return 0;
    }

    @Override
    public final void a(g g2) {
        this.d = new e(g2.a_(0), g2.a_(1));
        g2.a();
        g2.a(j.a);
    }

    @Override
    public final boolean a(m m2) {
        int n2;
        com.d.a.a.d.b b2 = new com.d.a.a.d.b(10);
        c c2 = new c(b2.a);
        int n3 = 0;
        do {
            m2.c(b2.a, 0, 10);
            b2.b(0);
            if (b2.d() != a) break;
            n2 = (b2.a[6] & 127) << 21 | (b2.a[7] & 127) << 14 | (b2.a[8] & 127) << 7 | b2.a[9] & 127;
            n3 += n2 + 10;
            m2.c(n2);
        } while (true);
        m2.a();
        m2.c(n3);
        int n4 = 0;
        n2 = 0;
        int n5 = n3;
        do {
            m2.c(b2.a, 0, 2);
            b2.b(0);
            if ((b2.b() & 65526) != 65520) {
                m2.a();
                if (++n5 - n3 >= 8192) {
                    return false;
                }
                m2.c(n5);
                n2 = 0;
                n4 = 0;
                continue;
            }
            if (++n4 >= 4 && n2 > 188) {
                return true;
            }
            m2.c(b2.a, 0, 4);
            c2.a(14);
            int n6 = c2.c(13);
            m2.c(n6 - 6);
            n2 += n6;
        } while (true);
    }

    @Override
    public final void c_() {
        this.e = false;
        this.d.c();
    }
}

