/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  android.util.Pair
 */
package com.d.a.a.f.d;

import android.util.Log;
import android.util.Pair;
import com.d.a.a.d.z;
import com.d.a.a.f.b;
import com.d.a.a.f.d.c;
import com.d.a.a.q;
import java.util.Arrays;
import java.util.Collections;

final class e
extends c {
    private static final byte[] c = new byte[]{73, 68, 51};
    long b;
    private final com.d.a.a.d.c d;
    private final com.d.a.a.d.b e;
    private final b f;
    private int g;
    private int h;
    private int i;
    private boolean j;
    private boolean k;
    private long l;
    private int m;
    private b n;
    private long o;

    public e(b b2, b b3) {
        super(b2);
        this.f = b3;
        b3.a(q.a());
        this.d = new com.d.a.a.d.c(new byte[7]);
        this.e = new com.d.a.a.d.b(Arrays.copyOf(c, 10));
        this.c();
    }

    private void a(b b2, long l2, int n2, int n3) {
        this.g = 3;
        this.h = n2;
        this.n = b2;
        this.o = l2;
        this.m = n3;
    }

    private boolean a(com.d.a.a.d.b b2, byte[] arrby, int n2) {
        int n3 = Math.min(b2.c - b2.b, n2 - this.h);
        b2.a(arrby, this.h, n3);
        this.h = n3 + this.h;
        if (this.h == n2) {
            return true;
        }
        return false;
    }

    @Override
    public final void a() {
        this.c();
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.b = l2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(com.d.a.a.d.b var1_1) {
        block12 : while (var1_1.c - var1_1.b > 0) {
            block19 : {
                switch (this.g) {
                    default: {
                        ** break;
                    }
                    case 0: {
                        var6_6 = var1_1.a;
                        var2_2 = var1_1.b;
                        var4_4 = var1_1.c;
                        break;
                    }
                    case 1: {
                        if (!this.a(var1_1, this.e.a, 10)) continue block12;
                        this.f.a(this.e, 10);
                        this.e.b(6);
                        this.a(this.f, 0, 10, this.e.j() + 10);
                        ** break;
                    }
                    case 2: {
                        var2_2 = this.j != false ? 7 : 5;
                        if (!this.a(var1_1, this.d.a, var2_2)) continue block12;
                        this.d.a(0);
                        if (!this.k) {
                            var2_2 = var3_3 = this.d.c(2) + 1;
                            if (var3_3 == 1) {
                                Log.w((String)"AdtsReader", (String)"Detected AAC Main audio, but assuming AAC LC.");
                                var2_2 = 2;
                            }
                            var3_3 = this.d.c(4);
                            this.d.b(1);
                            var4_4 = this.d.c(3);
                            var6_6 = new byte[]{(byte)(var2_2 << 3 & 248 | var3_3 >> 1 & 7), (byte)(var3_3 << 7 & 128 | var4_4 << 3 & 120)};
                            var7_7 = z.a((byte[])var6_6);
                            var6_6 = q.a(null, "audio/mp4a-latm", -1, -1, -1, (Integer)var7_7.second, (Integer)var7_7.first, Collections.singletonList(var6_6), null);
                            this.l = 1024000000 / (long)var6_6.o;
                            this.a.a((q)var6_6);
                            this.k = true;
                        } else {
                            this.d.b(10);
                        }
                        this.d.b(4);
                        var2_2 = var3_3 = this.d.c(13) - 2 - 5;
                        if (this.j) {
                            var2_2 = var3_3 - 2;
                        }
                        this.a(this.a, this.l, 0, var2_2);
                        ** break;
                    }
                    case 3: {
                        var2_2 = Math.min(var1_1.c - var1_1.b, this.m - this.h);
                        this.n.a(var1_1, var2_2);
                        this.h = var2_2 + this.h;
                        if (this.h != this.m) continue block12;
                        this.n.a(this.b, 1, this.m, 0, null);
                        this.b += this.o;
                        this.c();
                        ** break;
                    }
                }
                block13 : while (var2_2 < var4_4) {
                    var3_3 = var2_2 + 1;
                    var2_2 = var6_6[var2_2] & 255;
                    if (this.i == 512 && var2_2 >= 240 && var2_2 != 255) {
                        var5_5 = (var2_2 & 1) == 0;
                        this.j = var5_5;
                        this.g = 2;
                        this.h = 0;
                        break block19;
                    }
                    switch (var2_2 | this.i) {
                        default: {
                            if (this.i == 256) break;
                            this.i = 256;
                            var2_2 = var3_3 - 1;
                            continue block13;
                        }
                        case 511: {
                            this.i = 512;
                            var2_2 = var3_3;
                            continue block13;
                        }
                        case 329: {
                            this.i = 768;
                            var2_2 = var3_3;
                            continue block13;
                        }
                        case 836: {
                            this.i = 1024;
                            var2_2 = var3_3;
                            continue block13;
                        }
                        case 1075: {
                            this.g = 1;
                            this.h = e.c.length;
                            this.m = 0;
                            this.e.b(0);
                            ** break;
lbl84: // 1 sources:
                            break block19;
                        }
                    }
                    var2_2 = var3_3;
                }
                var3_3 = var2_2;
            }
            var1_1.b(var3_3);
            ** break;
lbl91: // 5 sources:
        }
    }

    @Override
    public final void b() {
    }

    final void c() {
        this.g = 0;
        this.h = 0;
        this.i = 256;
    }
}

