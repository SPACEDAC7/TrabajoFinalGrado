/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.d.aa;
import com.d.a.a.f.b;
import com.d.a.a.f.d.c;
import com.d.a.a.q;

final class f
extends c {
    private final com.d.a.a.d.b b = new com.d.a.a.d.b(new byte[15]);
    private int c;
    private int d;
    private int e;
    private long f;
    private q g;
    private int h;
    private long i;

    public f(b b2) {
        super(b2);
        this.b.a[0] = 127;
        this.b.a[1] = -2;
        this.b.a[2] = -128;
        this.b.a[3] = 1;
        this.c = 0;
    }

    @Override
    public final void a() {
        this.c = 0;
        this.d = 0;
        this.e = 0;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.i = l2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(com.d.a.a.d.b var1_1) {
        block5 : while (var1_1.c - var1_1.b > 0) {
            switch (this.c) {
                default: {
                    continue block5;
                }
                case 0: {
                    while (var1_1.c - var1_1.b > 0) {
                        this.e <<= 8;
                        this.e |= var1_1.a();
                        if (this.e != 2147385345) continue;
                        this.e = 0;
                        var2_2 = 1;
                        ** GOTO lbl14
                    }
                    var2_2 = 0;
lbl14: // 2 sources:
                    if (var2_2 == 0) continue block5;
                    this.d = 4;
                    this.c = 1;
                    continue block5;
                }
                case 1: {
                    var3_3 = this.b.a;
                    var2_2 = Math.min(var1_1.c - var1_1.b, 15 - this.d);
                    var1_1.a(var3_3, this.d, var2_2);
                    this.d += var2_2;
                    var2_2 = this.d == 15 ? 1 : 0;
                    if (var2_2 == 0) continue block5;
                    var3_3 = this.b.a;
                    if (this.g == null) {
                        this.g = aa.a(var3_3);
                        this.a.a(this.g);
                    }
                    this.h = ((var3_3[5] & 2) << 12 | (var3_3[6] & 255) << 4 | (var3_3[7] & 240) >> 4) + 1;
                    this.f = (int)((long)((((var3_3[4] & 1) << 6 | (var3_3[5] & 252) >> 2) + 1) * 32) * 1000000 / (long)this.g.o);
                    this.b.b(0);
                    this.a.a(this.b, 15);
                    this.c = 2;
                    continue block5;
                }
                case 2: 
            }
            var2_2 = Math.min(var1_1.c - var1_1.b, this.h - this.d);
            this.a.a(var1_1, var2_2);
            this.d = var2_2 + this.d;
            if (this.d != this.h) continue;
            this.a.a(this.i, 1, this.h, 0, null);
            this.i += this.f;
            this.c = 0;
        }
    }

    @Override
    public final void b() {
    }
}

