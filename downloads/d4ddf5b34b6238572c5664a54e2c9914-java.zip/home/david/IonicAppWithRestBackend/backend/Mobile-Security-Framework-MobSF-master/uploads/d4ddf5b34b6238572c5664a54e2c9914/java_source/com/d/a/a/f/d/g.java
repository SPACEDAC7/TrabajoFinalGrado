/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import java.util.Arrays;

final class g {
    boolean a;
    public int b;
    public int c;
    public byte[] d = new byte[128];

    public final void a(byte[] arrby, int n2, int n3) {
        if (!this.a) {
            return;
        }
        if (this.d.length < this.b + (n3 -= n2)) {
            this.d = Arrays.copyOf(this.d, (this.b + n3) * 2);
        }
        System.arraycopy(arrby, n2, this.d, this.b, n3);
        this.b = n3 + this.b;
    }
}

