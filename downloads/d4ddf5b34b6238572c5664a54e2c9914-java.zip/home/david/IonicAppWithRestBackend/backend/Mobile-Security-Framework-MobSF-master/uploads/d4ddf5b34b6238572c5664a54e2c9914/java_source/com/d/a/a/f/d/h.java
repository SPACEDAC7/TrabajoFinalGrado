/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 */
package com.d.a.a.f.d;

import android.util.Pair;
import com.d.a.a.f.b;
import com.d.a.a.f.d.c;
import com.d.a.a.f.d.g;
import com.d.a.a.q;
import java.util.Arrays;
import java.util.Collections;

final class h
extends c {
    private static final double[] b = new double[]{23.976023976023978, 24.0, 25.0, 29.97002997002997, 30.0, 50.0, 59.94005994005994, 60.0};
    private boolean c;
    private long d;
    private final boolean[] e = new boolean[4];
    private final g f = new g();
    private boolean g;
    private long h;
    private long i;
    private boolean j;
    private boolean k;
    private long l;
    private long m;

    public h(b b2) {
        super(b2);
    }

    @Override
    public final void a() {
        com.d.a.a.d.q.a(this.e);
        g g2 = this.f;
        g2.a = false;
        g2.b = 0;
        g2.c = 0;
        this.j = false;
        this.g = false;
        this.h = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(long l2, boolean bl2) {
        bl2 = l2 != -1;
        this.j = bl2;
        if (this.j) {
            this.i = l2;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(com.d.a.a.d.b var1_1) {
        if (var1_1.c - var1_1.b <= 0) return;
        var8_2 = var1_1.b;
        var10_3 = var1_1.c;
        var17_4 = var1_1.a;
        this.h += (long)(var1_1.c - var1_1.b);
        this.a.a(var1_1, var1_1.c - var1_1.b);
        var7_5 = var8_2;
        do {
            if ((var8_2 = com.d.a.a.d.q.a(var17_4, var8_2, var10_3, this.e)) == var10_3) {
                if (this.c != false) return;
                this.f.a(var17_4, var7_5, var10_3);
                return;
            }
            var9_9 = var1_1.a[var8_2 + 3] & 255;
            if (this.c) ** GOTO lbl68
            var11_10 = var8_2 - var7_5;
            if (var11_10 > 0) {
                this.f.a(var17_4, var7_5, var8_2);
            }
            var7_5 = var11_10 < 0 ? - var11_10 : 0;
            var18_14 = this.f;
            if (!var18_14.a) ** GOTO lbl28
            if (var18_14.c != 0 || var9_9 != 181) ** GOTO lbl24
            var18_14.c = var18_14.b;
            ** GOTO lbl30
lbl24: // 1 sources:
            var18_14.b -= var7_5;
            var18_14.a = false;
            var7_5 = 1;
            ** GOTO lbl31
lbl28: // 1 sources:
            if (var9_9 == 179) {
                var18_14.a = true;
            }
lbl30: // 4 sources:
            var7_5 = 0;
lbl31: // 2 sources:
            if (var7_5 != 0) {
                var18_14 = this.f;
                var19_15 = Arrays.copyOf(var18_14.d, var18_14.b);
                var12_11 = var19_15[4];
                var7_5 = var19_15[5] & 255;
                var11_10 = var19_15[6];
                var12_11 = (var12_11 & 255) << 4 | var7_5 >> 4;
                var7_5 = (var7_5 & 15) << 8 | var11_10 & 255;
                var6_8 = 1.0f;
                switch ((var19_15[7] & 240) >> 4) {
                    case 2: {
                        var6_8 = (float)(var7_5 * 4) / (float)(var12_11 * 3);
                        break;
                    }
                    case 3: {
                        var6_8 = (float)(var7_5 * 16) / (float)(var12_11 * 9);
                        break;
                    }
                    case 4: {
                        var6_8 = (float)(var7_5 * 121) / (float)(var12_11 * 100);
                    }
                }
                var20_16 = q.a(null, "video/mpeg2", -1, -1, -1, var12_11, var7_5, Collections.singletonList(var19_15), -1, var6_8);
                var15_13 = 0;
                var7_5 = (var19_15[7] & 15) - 1;
                var13_12 = var15_13;
                if (var7_5 >= 0) {
                    var13_12 = var15_13;
                    if (var7_5 < h.b.length) {
                        var4_7 = h.b[var7_5];
                        var11_10 = var18_14.c;
                        var7_5 = (var19_15[var11_10 + 9] & 96) >> 5;
                        var11_10 = var19_15[var11_10 + 9] & 31;
                        var2_6 = var4_7;
                        if (var7_5 != var11_10) {
                            var2_6 = var4_7 * (((double)var7_5 + 1.0) / (double)(var11_10 + 1));
                        }
                        var13_12 = (long)(1000000.0 / var2_6);
                    }
                }
                var18_14 = Pair.create((Object)var20_16, (Object)var13_12);
                this.a.a((q)var18_14.first);
                this.d = (Long)var18_14.second;
                this.c = true;
            }
lbl68: // 4 sources:
            if (this.c && (var9_9 == 184 || var9_9 == 0)) {
                var11_10 = var10_3 - var8_2;
                if (this.g) {
                    var7_5 = this.k != false ? 1 : 0;
                    var12_11 = (int)(this.h - this.l);
                    this.a.a(this.m, var7_5, var12_11 - var11_10, var11_10, null);
                    this.k = false;
                }
                if (var9_9 == 184) {
                    this.g = false;
                    this.k = true;
                } else {
                    var13_12 = this.j != false ? this.i : this.m + this.d;
                    this.m = var13_12;
                    this.l = this.h - (long)var11_10;
                    this.j = false;
                    this.g = true;
                }
            }
            var9_9 = var8_2 + 3;
            var7_5 = var8_2;
            var8_2 = var9_9;
        } while (true);
    }

    @Override
    public final void b() {
    }
}

