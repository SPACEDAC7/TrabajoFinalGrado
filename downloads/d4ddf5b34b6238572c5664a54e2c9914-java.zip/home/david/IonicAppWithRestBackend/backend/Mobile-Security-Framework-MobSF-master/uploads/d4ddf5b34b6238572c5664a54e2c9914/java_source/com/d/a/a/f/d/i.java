/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.d.o;

final class i {
    boolean a;
    boolean b;
    o c;
    int d;
    int e;
    int f;
    int g;
    boolean h;
    boolean i;
    boolean j;
    boolean k;
    int l;
    int m;
    int n;
    int o;
    int p;
}

