/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 */
package com.d.a.a.f.d;

import android.util.SparseArray;
import com.d.a.a.d.c;
import com.d.a.a.d.o;
import com.d.a.a.d.p;
import com.d.a.a.f.b;
import com.d.a.a.f.d.i;

final class j {
    final b a;
    final boolean b;
    final boolean c;
    final c d;
    final SparseArray<o> e;
    final SparseArray<p> f;
    byte[] g;
    int h;
    int i;
    long j;
    boolean k;
    long l;
    i m;
    i n;
    boolean o;
    long p;
    long q;
    boolean r;

    public j(b b2, boolean bl2, boolean bl3) {
        this.a = b2;
        this.b = bl2;
        this.c = bl3;
        this.e = new SparseArray();
        this.f = new SparseArray();
        this.m = new i();
        this.n = new i();
        this.d = new c();
        this.g = new byte[128];
        this.a();
    }

    public final void a() {
        this.k = false;
        this.o = false;
        i i2 = this.n;
        i2.b = false;
        i2.a = false;
    }
}

