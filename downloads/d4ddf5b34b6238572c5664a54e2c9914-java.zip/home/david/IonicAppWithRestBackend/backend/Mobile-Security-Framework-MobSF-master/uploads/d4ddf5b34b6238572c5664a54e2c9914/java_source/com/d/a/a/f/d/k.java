/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 */
package com.d.a.a.f.d;

import android.util.SparseArray;
import com.d.a.a.d.o;
import com.d.a.a.d.p;
import com.d.a.a.f.b;
import com.d.a.a.f.d.a;
import com.d.a.a.f.d.c;
import com.d.a.a.f.d.i;
import com.d.a.a.f.d.j;
import com.d.a.a.f.d.l;
import com.d.a.a.q;
import java.util.ArrayList;
import java.util.Arrays;

final class k
extends c {
    private boolean b;
    private final a c;
    private final boolean[] d;
    private final j e;
    private final l f;
    private final l g;
    private final l h;
    private long i;
    private long j;
    private final com.d.a.a.d.b k;

    public k(b b2, a a2, boolean bl2, boolean bl3) {
        super(b2);
        this.c = a2;
        this.d = new boolean[3];
        this.e = new j(b2, bl2, bl3);
        this.f = new l(7);
        this.g = new l(8);
        this.h = new l(6);
        this.k = new com.d.a.a.d.b();
    }

    private static com.d.a.a.d.c a(l object) {
        int n2 = com.d.a.a.d.q.a(object.c, object.d);
        object = new com.d.a.a.d.c(object.c, n2);
        object.b(32);
        return object;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(byte[] var1_1, int var2_2, int var3_3) {
        if (!this.b || this.e.c) {
            this.f.a((byte[])var1_1, var2_2, var3_3);
            this.g.a((byte[])var1_1, var2_2, var3_3);
        }
        this.h.a((byte[])var1_1, var2_2, var3_3);
        var18_4 = this.e;
        if (var18_4.k == false) return;
        if (var18_4.g.length < var18_4.h + (var3_3 -= var2_2)) {
            var18_4.g = Arrays.copyOf(var18_4.g, (var18_4.h + var3_3) * 2);
        }
        System.arraycopy(var1_1, var2_2, var18_4.g, var18_4.h, var3_3);
        var18_4.h = var3_3 + var18_4.h;
        var18_4.d.a(var18_4.g, var18_4.h);
        if (var18_4.d.a() < 8) return;
        var18_4.d.b(1);
        var8_5 = var18_4.d.c(2);
        var18_4.d.b(5);
        if (var18_4.d.c() == false) return;
        var18_4.d.e();
        if (var18_4.d.c() == false) return;
        var9_6 = var18_4.d.e();
        if (!var18_4.c) {
            var18_4.k = false;
            var1_1 = var18_4.n;
            var1_1.e = var9_6;
            var1_1.b = true;
            return;
        }
        if (var18_4.d.c() == false) return;
        var10_7 = var18_4.d.e();
        if (var18_4.f.indexOfKey(var10_7) < 0) {
            var18_4.k = false;
            return;
        }
        var19_8 = (p)var18_4.f.get(var10_7);
        var1_1 = (o)var18_4.e.get(var19_8.b);
        if (var1_1.e) {
            if (var18_4.d.a() < 2) return;
            var18_4.d.b(2);
        }
        if (var18_4.d.a() < var1_1.g) return;
        var15_9 = false;
        var16_10 = false;
        var17_11 = false;
        var11_12 = var18_4.d.c(var1_1.g);
        var13_13 = var17_11;
        var14_14 = var16_10;
        if (!var1_1.f) {
            if (var18_4.d.a() <= 0) return;
            var12_15 = var18_4.d.c(1) == 1;
            var13_13 = var17_11;
            var14_14 = var16_10;
            var15_9 = var12_15;
            if (var12_15) {
                if (var18_4.d.a() <= 0) return;
                var13_13 = var18_4.d.c(1) == 1;
                var14_14 = true;
                var15_9 = var12_15;
            }
        }
        var12_15 = var18_4.i == 5;
        var6_16 = 0;
        if (var12_15) {
            if (var18_4.d.c() == false) return;
            var6_16 = var18_4.d.e();
        }
        var5_17 = 0;
        var7_18 = 0;
        if (var1_1.h != 0) ** GOTO lbl78
        if (var18_4.d.a() < var1_1.i) return;
        var4_19 = var18_4.d.c(var1_1.i);
        var3_3 = var7_18;
        var2_2 = var4_19;
        if (!var19_8.c) ** GOTO lbl-1000
        var3_3 = var7_18;
        var2_2 = var4_19;
        if (var15_9) ** GOTO lbl-1000
        if (var18_4.d.c() == false) return;
        var2_2 = var18_4.d.d();
        var7_18 = 0;
        var3_3 = 0;
        var5_17 = var4_19;
        var4_19 = var2_2;
        var2_2 = var7_18;
        ** GOTO lbl101
lbl78: // 1 sources:
        var3_3 = var7_18;
        var2_2 = var5_17;
        if (var1_1.h != 1) ** GOTO lbl-1000
        var3_3 = var7_18;
        var2_2 = var5_17;
        if (var1_1.j) ** GOTO lbl-1000
        if (var18_4.d.c() == false) return;
        var3_3 = var4_19 = var18_4.d.d();
        var2_2 = var5_17;
        if (!var19_8.c) ** GOTO lbl-1000
        var3_3 = var4_19;
        var2_2 = var5_17;
        if (!var15_9) {
            if (var18_4.d.c() == false) return;
            var2_2 = var18_4.d.d();
            var3_3 = var4_19;
            var4_19 = 0;
            var5_17 = 0;
        } else lbl-1000: // 6 sources:
        {
            var7_18 = 0;
            var4_19 = 0;
            var5_17 = var2_2;
            var2_2 = var7_18;
        }
lbl101: // 3 sources:
        var19_8 = var18_4.n;
        var19_8.c = var1_1;
        var19_8.d = var8_5;
        var19_8.e = var9_6;
        var19_8.f = var11_12;
        var19_8.g = var10_7;
        var19_8.h = var15_9;
        var19_8.i = var14_14;
        var19_8.j = var13_13;
        var19_8.k = var12_15;
        var19_8.l = var6_16;
        var19_8.m = var5_17;
        var19_8.n = var4_19;
        var19_8.o = var3_3;
        var19_8.p = var2_2;
        var19_8.a = true;
        var19_8.b = true;
        var18_4.k = false;
    }

    @Override
    public final void a() {
        com.d.a.a.d.q.a(this.d);
        l l2 = this.f;
        l2.a = false;
        l2.b = false;
        l2 = this.g;
        l2.a = false;
        l2.b = false;
        l2 = this.h;
        l2.a = false;
        l2.b = false;
        this.e.a();
        this.i = 0;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.j = l2;
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void a(com.d.a.a.d.b var1_1) {
        block17 : {
            block18 : {
                block16 : {
                    block15 : {
                        block14 : {
                            if (var1_1.c - var1_1.b <= 0) return;
                            var2_2 = var1_1.b;
                            var3_3 = var1_1.c;
                            var14_4 = var1_1.a;
                            this.i += (long)(var1_1.c - var1_1.b);
                            this.a.a((com.d.a.a.d.b)var1_1, var1_1.c - var1_1.b);
                            block0 : do {
                                if ((var4_5 = com.d.a.a.d.q.a(var14_4, var2_2, var3_3, this.d)) == var3_3) {
                                    this.a(var14_4, var2_2, var3_3);
                                    return;
                                }
                                var5_6 = com.d.a.a.d.q.b(var14_4, var4_5);
                                var7_8 = var4_5 - var2_2;
                                if (var7_8 > 0) {
                                    this.a(var14_4, var2_2, var4_5);
                                }
                                var6_7 = var3_3 - var4_5;
                                var9_10 = this.i - (long)var6_7;
                                if (var7_8 >= 0) break;
                                var2_2 = - var7_8;
lbl19: // 2 sources:
                                do {
                                    var11_11 = this.j;
                                    if (!this.b || this.e.c) {
                                        this.f.b(var2_2);
                                        this.g.b(var2_2);
                                        if (this.b) break block14;
                                        if (this.f.b && this.g.b) {
                                            var1_1 = new ArrayList<byte[]>();
                                            var1_1.add((byte[])Arrays.copyOf(this.f.c, this.f.d));
                                            var1_1.add(Arrays.copyOf(this.g.c, this.g.d));
                                            var15_13 = com.d.a.a.d.q.a(k.a(this.f));
                                            var16_14 = com.d.a.a.d.q.b(k.a(this.g));
                                            this.a.a(q.a(null, "video/avc", -1, -1, -1, var15_13.b, var15_13.c, var1_1, -1, var15_13.d));
                                            this.b = true;
                                            this.e.e.append(var15_13.a, var15_13);
                                            this.e.f.append(var16_14.a, var16_14);
                                            var1_1 = this.f;
                                            var1_1.a = false;
                                            var1_1.b = false;
                                            var1_1 = this.g;
                                            var1_1.a = false;
                                            var1_1.b = false;
                                        }
                                    }
lbl41: // 8 sources:
                                    do {
                                        if (this.h.b(var2_2)) {
                                            var2_2 = com.d.a.a.d.q.a(this.h.c, this.h.d);
                                            var1_1 = this.k;
                                            var1_1.a = this.h.c;
                                            var1_1.c = var2_2;
                                            var1_1.b = 0;
                                            this.k.b(4);
                                            this.c.a(var11_11, this.k);
                                        }
                                        var1_1 = this.e;
                                        if (var1_1.i == 9) ** GOTO lbl59
                                        if (!var1_1.c) ** GOTO lbl70
                                        var15_13 = var1_1.n;
                                        var16_14 = var1_1.m;
                                        if (!var15_13.a || var16_14.a && var15_13.f == var16_14.f && var15_13.g == var16_14.g && var15_13.h == var16_14.h && (!var15_13.i || !var16_14.i || var15_13.j == var16_14.j) && (var15_13.d == var16_14.d || var15_13.d != 0 && var16_14.d != 0) && (var15_13.c.h != 0 || var16_14.c.h != 0 || var15_13.m == var16_14.m && var15_13.n == var16_14.n) && (var15_13.c.h != 1 || var16_14.c.h != 1 || var15_13.o == var16_14.o && var15_13.p == var16_14.p) && var15_13.k == var16_14.k && (!var15_13.k || !var16_14.k || var15_13.l == var16_14.l)) break block15;
                                        var2_2 = 1;
lbl57: // 2 sources:
                                        do {
                                            if (var2_2 == 0) ** GOTO lbl70
lbl59: // 2 sources:
                                            if (!var1_1.o) ** GOTO lbl66
                                            var7_8 = (int)(var9_10 - var1_1.j);
                                            if (!var1_1.r) break block16;
                                            var2_2 = 1;
lbl63: // 2 sources:
                                            do {
                                                var8_9 = (int)(var1_1.j - var1_1.p);
                                                var1_1.a.a(var1_1.q, var2_2, var8_9, var6_7 + var7_8, null);
lbl66: // 2 sources:
                                                var1_1.p = var1_1.j;
                                                var1_1.q = var1_1.l;
                                                var1_1.r = false;
                                                var1_1.o = true;
lbl70: // 3 sources:
                                                var13_12 = var1_1.r;
                                                if (var1_1.i == 5) ** GOTO lbl-1000
                                                if (!var1_1.b || var1_1.i != 1) break block17;
                                                var15_13 = var1_1.n;
                                                if (!var15_13.b || var15_13.e != 7 && var15_13.e != 2) break block18;
                                                var2_2 = 1;
lbl76: // 2 sources:
                                                while (var2_2 != 0) lbl-1000: // 2 sources:
                                                {
                                                    var2_2 = 1;
lbl78: // 2 sources:
                                                    do {
                                                        var1_1.r = var2_2 | var13_12;
                                                        var11_11 = this.j;
                                                        if (!this.b || this.e.c) {
                                                            this.f.a(var5_6);
                                                            this.g.a(var5_6);
                                                        }
                                                        this.h.a(var5_6);
                                                        var1_1 = this.e;
                                                        var1_1.i = var5_6;
                                                        var1_1.l = var11_11;
                                                        var1_1.j = var9_10;
                                                        if (var1_1.b && var1_1.i == 1 || var1_1.c && (var1_1.i == 5 || var1_1.i == 1 || var1_1.i == 2)) {
                                                            var15_13 = var1_1.m;
                                                            var1_1.m = var1_1.n;
                                                            var15_13 = var1_1.n = var15_13;
                                                            var15_13.b = false;
                                                            var15_13.a = false;
                                                            var1_1.h = 0;
                                                            var1_1.k = true;
                                                        }
                                                        var2_2 = var4_5 + 3;
                                                        continue block0;
                                                        break;
                                                    } while (true);
                                                    continue block0;
                                                }
                                                break block17;
                                                break;
                                            } while (true);
                                            break;
                                        } while (true);
                                        break;
                                    } while (true);
                                    break;
                                } while (true);
                                break;
                            } while (true);
                            var2_2 = 0;
                            ** while (true)
                        }
                        if (!this.f.b) ** GOTO lbl111
                        var1_1 = com.d.a.a.d.q.a(k.a(this.f));
                        this.e.e.append(var1_1.a, var1_1);
                        var1_1 = this.f;
                        var1_1.a = false;
                        var1_1.b = false;
                        ** GOTO lbl41
lbl111: // 1 sources:
                        if (!this.g.b) ** GOTO lbl41
                        var1_1 = com.d.a.a.d.q.b(k.a(this.g));
                        this.e.f.append(var1_1.a, var1_1);
                        var1_1 = this.g;
                        var1_1.a = false;
                        var1_1.b = false;
                        ** while (true)
                    }
                    var2_2 = 0;
                    ** while (true)
                }
                var2_2 = 0;
                ** while (true)
            }
            var2_2 = 0;
            ** GOTO lbl76
        }
        var2_2 = 0;
        ** while (true)
    }

    @Override
    public final void b() {
    }
}

