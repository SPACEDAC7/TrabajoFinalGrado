/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import java.util.Arrays;

final class l {
    boolean a;
    boolean b;
    public byte[] c;
    public int d;
    private final int e;

    public l(int n2) {
        this.e = n2;
        this.c = new byte[131];
        this.c[2] = 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2) {
        boolean bl2 = true;
        boolean bl3 = !this.a;
        if (!bl3) {
            throw new IllegalStateException();
        }
        if (n2 != this.e) {
            bl2 = false;
        }
        this.a = bl2;
        if (this.a) {
            this.d = 3;
            this.b = false;
        }
    }

    public final void a(byte[] arrby, int n2, int n3) {
        if (!this.a) {
            return;
        }
        if (this.c.length < this.d + (n3 -= n2)) {
            this.c = Arrays.copyOf(this.c, (this.d + n3) * 2);
        }
        System.arraycopy(arrby, n2, this.c, this.d, n3);
        this.d = n3 + this.d;
    }

    public final boolean b(int n2) {
        if (!this.a) {
            return false;
        }
        this.d -= n2;
        this.a = false;
        this.b = true;
        return true;
    }
}

