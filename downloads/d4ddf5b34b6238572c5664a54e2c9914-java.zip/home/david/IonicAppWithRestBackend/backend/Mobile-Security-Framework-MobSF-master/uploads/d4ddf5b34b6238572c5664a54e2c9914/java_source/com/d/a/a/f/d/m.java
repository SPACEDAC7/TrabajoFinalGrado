/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.f.b;

final class m {
    long a;
    boolean b;
    int c;
    long d;
    boolean e;
    boolean f;
    boolean g;
    long h;
    long i;
    boolean j;
    private final b k;

    public m(b b2) {
        this.k = b2;
    }

    /*
     * Enabled aggressive block sorting
     */
    final void a(int n2) {
        int n3 = this.j ? 1 : 0;
        int n4 = (int)(this.a - this.h);
        this.k.a(this.i, n3, n4, n2, null);
    }
}

