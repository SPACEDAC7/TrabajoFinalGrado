/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.d.a.a.f.d;

import android.util.Log;
import com.d.a.a.f.b;
import com.d.a.a.f.d.a;
import com.d.a.a.f.d.c;
import com.d.a.a.f.d.l;
import com.d.a.a.f.d.m;
import com.d.a.a.q;
import java.util.Collections;

final class n
extends c {
    private boolean b;
    private final a c;
    private final boolean[] d;
    private final l e;
    private final l f;
    private final l g;
    private final l h;
    private final l i;
    private final m j;
    private long k;
    private long l;
    private final com.d.a.a.d.b m;

    public n(b b2, a a2) {
        super(b2);
        this.c = a2;
        this.d = new boolean[3];
        this.e = new l(32);
        this.f = new l(33);
        this.g = new l(34);
        this.h = new l(39);
        this.i = new l(40);
        this.j = new m(b2);
        this.m = new com.d.a.a.d.b();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(byte[] arrby, int n2, int n3) {
        if (this.b) {
            m m2 = this.j;
            if (m2.e) {
                int n4 = n2 + 2 - m2.c;
                if (n4 < n3) {
                    boolean bl2 = (arrby[n4] & 128) != 0;
                    m2.f = bl2;
                    m2.e = false;
                } else {
                    m2.c += n3 - n2;
                }
            }
        } else {
            this.e.a(arrby, n2, n3);
            this.f.a(arrby, n2, n3);
            this.g.a(arrby, n2, n3);
        }
        this.h.a(arrby, n2, n3);
        this.i.a(arrby, n2, n3);
    }

    @Override
    public final void a() {
        com.d.a.a.d.q.a(this.d);
        Object object = this.e;
        object.a = false;
        object.b = false;
        object = this.f;
        object.a = false;
        object.b = false;
        object = this.g;
        object.a = false;
        object.b = false;
        object = this.h;
        object.a = false;
        object.b = false;
        object = this.i;
        object.a = false;
        object.b = false;
        object = this.j;
        object.e = false;
        object.f = false;
        object.g = false;
        this.k = 0;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.l = l2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(com.d.a.a.d.b var1_1) {
        block0 : do {
            if (var1_1.c - var1_1.b <= 0) return;
            var4_4 = var1_1.b;
            var12_12 = var1_1.c;
            var24_22 = var1_1.a;
            this.k += (long)(var1_1.c - var1_1.b);
            this.a.a(var1_1, var1_1.c - var1_1.b);
            block1 : do {
                if (var4_4 >= var12_12) continue block0;
                var13_13 = com.d.a.a.d.q.a(var24_22, var4_4, var12_12, this.d);
                if (var13_13 == var12_12) {
                    this.a(var24_22, var4_4, var12_12);
                    return;
                }
                var14_14 = com.d.a.a.d.q.c(var24_22, var13_13);
                var5_5 = var13_13 - var4_4;
                if (var5_5 > 0) {
                    this.a(var24_22, var4_4, var13_13);
                }
                var15_15 = var12_12 - var13_13;
                var19_19 = this.k - (long)var15_15;
                var6_6 = var5_5 < 0 ? - var5_5 : 0;
                var21_20 = this.l;
                if (this.b) {
                    var25_23 = this.j;
                    if (var25_23.f) {
                        if (var25_23.g) {
                            var25_23.a((int)(var19_19 - var25_23.a) + var15_15);
                        }
                        var25_23.h = var25_23.a;
                        var25_23.i = var25_23.d;
                        var25_23.g = true;
                        var25_23.j = var25_23.b;
                    }
                } else {
                    this.e.b(var6_6);
                    this.f.b(var6_6);
                    this.g.b(var6_6);
                    if (this.e.b && this.f.b && this.g.b) {
                        var25_23 = this.a;
                        var27_25 = this.e;
                        var28_26 = this.f;
                        var29_27 = this.g;
                        var26_24 = new byte[var27_25.d + var28_26.d + var29_27.d];
                        System.arraycopy(var27_25.c, 0, var26_24, 0, var27_25.d);
                        System.arraycopy(var28_26.c, 0, var26_24, var27_25.d, var28_26.d);
                        System.arraycopy(var29_27.c, 0, var26_24, var27_25.d + var28_26.d, var29_27.d);
                        com.d.a.a.d.q.a(var28_26.c, var28_26.d);
                        var27_25 = new com.d.a.a.d.c(var28_26.c);
                        var27_25.b(44);
                        var9_9 = var27_25.c(3);
                        var27_25.b(1);
                        var27_25.b(88);
                        var27_25.b(8);
                        var5_5 = 0;
                        break block0;
                    }
                }
lbl53: // 4 sources:
                do {
                    if (this.h.b(var6_6)) {
                        var4_4 = com.d.a.a.d.q.a(this.h.c, this.h.d);
                        var25_23 = this.m;
                        var25_23.a = this.h.c;
                        var25_23.c = var4_4;
                        var25_23.b = 0;
                        var25_23 = this.m;
                        var25_23.b(var25_23.b + 5);
                        this.c.a(var21_20, this.m);
                    }
                    if (this.i.b(var6_6)) {
                        var4_4 = com.d.a.a.d.q.a(this.i.c, this.i.d);
                        var25_23 = this.m;
                        var25_23.a = this.i.c;
                        var25_23.c = var4_4;
                        var25_23.b = 0;
                        var25_23 = this.m;
                        var25_23.b(var25_23.b + 5);
                        this.c.a(var21_20, this.m);
                    }
                    var21_20 = this.l;
                    if (!this.b) {
                        this.e.a(var14_14);
                        this.f.a(var14_14);
                        this.g.a(var14_14);
                    }
                    this.h.a(var14_14);
                    this.i.a(var14_14);
                    var25_23 = this.j;
                    var25_23.f = false;
                    var25_23.d = var21_20;
                    var25_23.c = 0;
                    var25_23.a = var19_19;
                    if (var14_14 >= 32 && var25_23.g) {
                        var25_23.a(var15_15);
                        var25_23.g = false;
                    }
                    var23_21 = var14_14 >= 16 && var14_14 <= 21;
                    var25_23.b = var23_21;
                    var23_21 = var25_23.b != false || var14_14 <= 9;
                    var25_23.e = var23_21;
                    var4_4 = var13_13 + 3;
                    continue block1;
                    break;
                } while (true);
                break;
            } while (true);
            break;
        } while (true);
        for (var7_7 = 0; var7_7 < var9_9; ++var7_7) {
            var8_8 = var27_25.c(1) == 1 ? 1 : 0;
            var4_4 = var5_5;
            if (var8_8 != 0) {
                var4_4 = var5_5 + 89;
            }
            var8_8 = var27_25.c(1) == 1 ? 1 : 0;
            var5_5 = var4_4;
            if (var8_8 == 0) continue;
            var5_5 = var4_4 + 8;
        }
        var27_25.b(var5_5);
        if (var9_9 > 0) {
            var27_25.b((8 - var9_9) * 2);
        }
        var27_25.e();
        var5_5 = var27_25.e();
        if (var5_5 == 3) {
            var27_25.b(1);
        }
        var11_11 = var27_25.e();
        var10_10 = var27_25.e();
        var4_4 = var27_25.c(1) == 1 ? 1 : 0;
        var8_8 = var11_11;
        var7_7 = var10_10;
        if (var4_4 != 0) {
            var8_8 = var27_25.e();
            var17_17 = var27_25.e();
            var7_7 = var27_25.e();
            var16_16 = var27_25.e();
            var4_4 = var5_5 == 1 || var5_5 == 2 ? 2 : 1;
            var5_5 = var5_5 == 1 ? 2 : 1;
            var8_8 = var11_11 - var4_4 * (var8_8 + var17_17);
            var7_7 = var10_10 - var5_5 * (var7_7 + var16_16);
        }
        var27_25.e();
        var27_25.e();
        var16_16 = var27_25.e();
        var4_4 = var27_25.c(1) == 1 ? 1 : 0;
        var4_4 = var4_4 != 0 ? 0 : var9_9;
        while (var4_4 <= var9_9) {
            var27_25.e();
            var27_25.e();
            var27_25.e();
            ++var4_4;
        }
        var27_25.e();
        var27_25.e();
        var27_25.e();
        var27_25.e();
        var27_25.e();
        var27_25.e();
        var4_4 = var27_25.c(1) == 1 ? 1 : 0;
        if (var4_4 != 0) {
            var4_4 = var27_25.c(1) == 1 ? 1 : 0;
            if (var4_4 != 0) {
                for (var4_4 = 0; var4_4 < 4; ++var4_4) {
                    var5_5 = 0;
                    while (var5_5 < 6) {
                        var9_9 = var27_25.c(1) == 1 ? 1 : 0;
                        if (var9_9 == 0) {
                            var27_25.e();
                        } else {
                            var10_10 = Math.min(64, 1 << (var4_4 << 1) + 4);
                            if (var4_4 > 1) {
                                var27_25.d();
                            }
                            for (var9_9 = 0; var9_9 < var10_10; ++var9_9) {
                                var27_25.d();
                            }
                        }
                        var9_9 = var4_4 == 3 ? 3 : 1;
                        var5_5 = var9_9 + var5_5;
                    }
                }
            }
        }
        var27_25.b(2);
        var4_4 = var27_25.c(1) == 1 ? 1 : 0;
        if (var4_4 != 0) {
            var27_25.b(8);
            var27_25.e();
            var27_25.e();
            var27_25.b(1);
        }
        var17_17 = var27_25.e();
        var5_5 = 0;
        var9_9 = 0;
        var4_4 = 0;
        do {
            block43 : {
                if (var9_9 >= var17_17) ** GOTO lbl197
                if (var9_9 != 0) {
                    var4_4 = var27_25.c(1) == 1 ? 1 : 0;
                }
                if (var4_4 == 0) ** GOTO lbl181
                var27_25.b(1);
                var27_25.e();
                ** GOTO lbl226
lbl181: // 1 sources:
                var10_10 = var27_25.e();
                var18_18 = var27_25.e();
                var11_11 = var10_10 + var18_18;
                for (var5_5 = 0; var5_5 < var10_10; ++var5_5) {
                    var27_25.e();
                    var27_25.b(1);
                }
                var10_10 = 0;
                do {
                    var5_5 = var11_11;
                    if (var10_10 < var18_18) {
                        var27_25.e();
                        var27_25.b(1);
                        ++var10_10;
                        continue;
                    }
                    break block43;
                    break;
                } while (true);
lbl197: // 1 sources:
                var4_4 = var27_25.c(1) == 1 ? 1 : 0;
                if (var4_4 != 0) {
                    for (var4_4 = 0; var4_4 < var27_25.e(); ++var4_4) {
                        var27_25.b(var16_16 + 4 + 1);
                    }
                }
                var27_25.b(2);
                var3_3 = 1.0f;
                var4_4 = var27_25.c(1) == 1 ? 1 : 0;
                if (var4_4 == 0) ** GOTO lbl222
                var4_4 = var27_25.c(1) == 1 ? 1 : 0;
                if (var4_4 == 0) ** GOTO lbl222
                var4_4 = var27_25.c(8);
                if (var4_4 == 255) {
                    var4_4 = var27_25.c(16);
                    var5_5 = var27_25.c(16);
                    var2_2 = var3_3;
                    if (var4_4 != 0) {
                        var2_2 = var3_3;
                        if (var5_5 != 0) {
                            var2_2 = (float)var4_4 / (float)var5_5;
                        }
                    }
                } else if (var4_4 < com.d.a.a.d.q.b.length) {
                    var2_2 = com.d.a.a.d.q.b[var4_4];
                } else {
                    Log.w((String)"H265Reader", (String)("Unexpected aspect_ratio_idc value: " + var4_4));
lbl222: // 3 sources:
                    var2_2 = 1.0f;
                }
                var25_23.a(q.a(null, "video/hevc", -1, -1, -1, var8_8, var7_7, Collections.singletonList(var26_24), -1, var2_2));
                this.b = true;
                ** continue;
lbl226: // 3 sources:
                for (var10_10 = 0; var10_10 <= var5_5; ++var10_10) {
                    var11_11 = var27_25.c(1) == 1 ? 1 : 0;
                    if (var11_11 == 0) continue;
                    var27_25.b(1);
                }
            }
            ++var9_9;
        } while (true);
    }

    @Override
    public final void b() {
    }
}

