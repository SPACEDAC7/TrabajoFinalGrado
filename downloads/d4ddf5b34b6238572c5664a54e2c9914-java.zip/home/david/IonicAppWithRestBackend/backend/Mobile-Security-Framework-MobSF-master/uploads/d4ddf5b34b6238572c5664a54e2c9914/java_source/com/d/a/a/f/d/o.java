/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.f.b;
import com.d.a.a.f.d.c;
import com.d.a.a.q;

final class o
extends c {
    private final com.d.a.a.d.b b;
    private boolean c;
    private long d;
    private int e;
    private int f;

    public o(b b2) {
        super(b2);
        b2.a(q.a());
        this.b = new com.d.a.a.d.b(10);
    }

    @Override
    public final void a() {
        this.c = false;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        if (!bl2) {
            return;
        }
        this.c = true;
        this.d = l2;
        this.e = 0;
        this.f = 0;
    }

    @Override
    public final void a(com.d.a.a.d.b b2) {
        if (!this.c) {
            return;
        }
        int n2 = b2.c - b2.b;
        if (this.f < 10) {
            int n3 = Math.min(n2, 10 - this.f);
            System.arraycopy(b2.a, b2.b, this.b.a, this.f, n3);
            if (n3 + this.f == 10) {
                this.b.b(6);
                this.e = this.b.j() + 10;
            }
        }
        this.a.a(b2, n2);
        this.f = n2 + this.f;
    }

    @Override
    public final void b() {
        if (!this.c || this.e == 0 || this.f != this.e) {
            return;
        }
        this.a.a(this.d, 1, this.e, 0, null);
        this.c = false;
    }
}

