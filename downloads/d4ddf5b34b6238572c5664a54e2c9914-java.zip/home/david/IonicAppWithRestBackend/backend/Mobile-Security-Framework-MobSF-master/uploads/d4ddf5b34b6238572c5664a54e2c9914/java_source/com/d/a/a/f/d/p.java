/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.d.n;
import com.d.a.a.f.b;
import com.d.a.a.f.d.c;
import com.d.a.a.q;

final class p
extends c {
    private final com.d.a.a.d.b b = new com.d.a.a.d.b(4);
    private final n c;
    private int d = 0;
    private int e;
    private boolean f;
    private boolean g;
    private long h;
    private int i;
    private long j;

    public p(b b2) {
        super(b2);
        this.b.a[0] = -1;
        this.c = new n();
    }

    @Override
    public final void a() {
        this.d = 0;
        this.e = 0;
        this.g = false;
    }

    @Override
    public final void a(long l2, boolean bl2) {
        this.j = l2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(com.d.a.a.d.b b2) {
        block5 : while (b2.c - b2.b > 0) {
            int n2;
            switch (this.d) {
                Object object;
                default: {
                    continue block5;
                }
                case 0: {
                    object = b2.a;
                    int n3 = b2.c;
                    for (n2 = b2.b; n2 < n3; ++n2) {
                        boolean bl2 = (object[n2] & 255) == 255;
                        boolean bl3 = this.g && (object[n2] & 224) == 224;
                        this.g = bl2;
                        if (!bl3) continue;
                        b2.b(n2 + 1);
                        this.g = false;
                        this.b.a[1] = object[n2];
                        this.e = 2;
                        this.d = 1;
                        continue block5;
                    }
                    b2.b(n3);
                    continue block5;
                }
                case 1: {
                    n2 = Math.min(b2.c - b2.b, 4 - this.e);
                    b2.a(this.b.a, this.e, n2);
                    this.e = n2 + this.e;
                    if (this.e < 4) continue block5;
                    this.b.b(0);
                    if (!n.a(this.b.g(), this.c)) {
                        this.e = 0;
                        this.d = 1;
                        continue block5;
                    }
                    this.i = this.c.c;
                    if (!this.f) {
                        this.h = 1000000 * (long)this.c.g / (long)this.c.d;
                        object = q.a(null, this.c.b, -1, 4096, -1, this.c.e, this.c.d, null, null);
                        this.a.a((q)object);
                        this.f = true;
                    }
                    this.b.b(0);
                    this.a.a(this.b, 4);
                    this.d = 2;
                    continue block5;
                }
                case 2: 
            }
            n2 = Math.min(b2.c - b2.b, this.i - this.e);
            this.a.a(b2, n2);
            this.e = n2 + this.e;
            if (this.e < this.i) continue;
            this.a.a(this.j, 1, this.i, 0, null);
            this.j += this.h;
            this.e = 0;
            this.d = 0;
        }
        return;
    }

    @Override
    public final void b() {
    }
}

