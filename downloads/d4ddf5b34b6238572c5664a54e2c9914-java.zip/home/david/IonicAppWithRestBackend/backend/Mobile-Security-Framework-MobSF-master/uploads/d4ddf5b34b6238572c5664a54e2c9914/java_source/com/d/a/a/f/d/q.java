/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.f.d.c;
import com.d.a.a.f.d.s;

final class q {
    final c a;
    final s b;
    final com.d.a.a.d.c c;
    boolean d;
    boolean e;
    boolean f;
    int g;
    long h;

    public q(c c2, s s2) {
        this.a = c2;
        this.b = s2;
        this.c = new com.d.a.a.d.c(new byte[64]);
    }
}

