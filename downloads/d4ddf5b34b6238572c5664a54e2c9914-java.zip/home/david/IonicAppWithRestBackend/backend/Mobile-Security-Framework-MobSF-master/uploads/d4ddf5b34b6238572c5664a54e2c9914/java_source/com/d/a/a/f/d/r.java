/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 */
package com.d.a.a.f.d;

import android.util.SparseArray;
import com.d.a.a.f.d.b;
import com.d.a.a.f.d.c;
import com.d.a.a.f.d.p;
import com.d.a.a.f.d.q;
import com.d.a.a.f.d.s;
import com.d.a.a.f.g;
import com.d.a.a.f.h;
import com.d.a.a.f.j;
import com.d.a.a.f.k;
import com.d.a.a.f.m;

public final class r
implements h {
    private final s a;
    private final SparseArray<q> b;
    private final com.d.a.a.d.b c;
    private boolean d;
    private boolean e;
    private boolean f;
    private g g;

    public r() {
        this(new s());
    }

    private r(s s2) {
        this.a = s2;
        this.c = new com.d.a.a.d.b(4096);
        this.b = new SparseArray();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(m var1_1, k var2_2) {
        if (!var1_1.b(this.c.a, 0, 4, true)) {
            return -1;
        }
        this.c.b(0);
        var3_3 = this.c.g();
        if (var3_3 == 441) {
            return -1;
        }
        if (var3_3 == 442) {
            var1_1.c(this.c.a, 0, 10);
            this.c.b(0);
            var2_2 = this.c;
            var2_2.b(var2_2.b + 9);
            var1_1.b((this.c.a() & 7) + 14);
            return 0;
        }
        if (var3_3 == 443) {
            var1_1.c(this.c.a, 0, 2);
            this.c.b(0);
            var1_1.b(this.c.b() + 6);
            return 0;
        }
        if ((var3_3 & -256) >> 8 != 1) {
            var1_1.b(1);
            return 0;
        }
        var2_2 = var19_4 = (q)this.b.get(var3_3 &= 255);
        if (this.d) ** GOTO lbl51
        var18_5 = var19_4;
        if (var19_4 == null) {
            var18_5 = null;
            if (!this.e && var3_3 == 189) {
                var2_2 = new b(this.g.a_(var3_3), false);
                this.e = true;
            } else if (!this.e && (var3_3 & 224) == 192) {
                var2_2 = new p(this.g.a_(var3_3));
                this.e = true;
            } else {
                var2_2 = var18_5;
                if (!this.f) {
                    var2_2 = var18_5;
                    if ((var3_3 & 240) == 224) {
                        var2_2 = new com.d.a.a.f.d.h(this.g.a_(var3_3));
                        this.f = true;
                    }
                }
            }
            var18_5 = var19_4;
            if (var2_2 != null) {
                var18_5 = new q((c)var2_2, this.a);
                this.b.put(var3_3, var18_5);
            }
        }
        if (this.e && this.f) ** GOTO lbl-1000
        var2_2 = var18_5;
        if (var1_1.c() > 0x100000) lbl-1000: // 2 sources:
        {
            this.d = true;
            this.g.a();
            var2_2 = var18_5;
        }
lbl51: // 4 sources:
        var1_1.c(this.c.a, 0, 2);
        this.c.b(0);
        var4_6 = this.c.b() + 6;
        if (var2_2 == null) {
            var1_1.b(var4_6);
            return 0;
        }
        var18_5 = this.c;
        var3_3 = var18_5.a == null ? 0 : var18_5.a.length;
        if (var3_3 < var4_6) {
            var18_5 = this.c;
            var18_5.a = new byte[var4_6];
            var18_5.c = var4_6;
            var18_5.b = 0;
        }
        var1_1.b(this.c.a, 0, var4_6);
        this.c.b(6);
        this.c.a(var4_6);
        var1_1 = this.c;
        var1_1.a(var2_2.c.a, 0, 3);
        var2_2.c.a(0);
        var2_2.c.b(8);
        var5_7 = var2_2.c.c(1) == 1;
        var2_2.d = var5_7;
        var5_7 = var2_2.c.c(1) == 1;
        var2_2.e = var5_7;
        var2_2.c.b(6);
        var2_2.g = var2_2.c.c(8);
        var1_1.a(var2_2.c.a, 0, var2_2.g);
        var2_2.c.a(0);
        var2_2.h = 0;
        if (var2_2.d) {
            var2_2.c.b(4);
            var6_8 = var2_2.c.c(3);
            var2_2.c.b(1);
            var8_9 = var2_2.c.c(15) << 15;
            var2_2.c.b(1);
            var10_10 = var2_2.c.c(15);
            var2_2.c.b(1);
            if (!var2_2.f && var2_2.e) {
                var2_2.c.b(4);
                var12_11 = var2_2.c.c(3);
                var2_2.c.b(1);
                var14_12 = var2_2.c.c(15) << 15;
                var2_2.c.b(1);
                var16_13 = var2_2.c.c(15);
                var2_2.c.b(1);
                var2_2.b.a(var12_11 << 30 | var14_12 | var16_13);
                var2_2.f = true;
            }
            var2_2.h = var2_2.b.a(var6_8 << 30 | var8_9 | var10_10);
        }
        var2_2.a.a(var2_2.h, true);
        var2_2.a.a((com.d.a.a.d.b)var1_1);
        var2_2.a.b();
        var1_1 = this.c;
        var2_2 = this.c;
        var3_3 = var2_2.a == null ? 0 : var2_2.a.length;
        var1_1.a(var3_3);
        return 0;
    }

    @Override
    public final void a(g g2) {
        this.g = g2;
        g2.a(j.a);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final boolean a(m m2) {
        byte[] arrby = new byte[14];
        m2.c(arrby, 0, 14);
        if (442 != ((arrby[0] & 255) << 24 | (arrby[1] & 255) << 16 | (arrby[2] & 255) << 8 | arrby[3] & 255)) {
            return false;
        }
        if ((arrby[4] & 196) != 68) return false;
        if ((arrby[6] & 4) != 4) return false;
        if ((arrby[8] & 4) != 4) return false;
        if ((arrby[9] & 1) != 1) return false;
        if ((arrby[12] & 3) != 3) return false;
        m2.c(arrby[13] & 7);
        m2.c(arrby, 0, 3);
        byte by2 = arrby[0];
        byte by3 = arrby[1];
        if (1 != (arrby[2] & 255 | ((by2 & 255) << 16 | (by3 & 255) << 8))) return false;
        return true;
    }

    @Override
    public final void c_() {
        this.a.a = Long.MIN_VALUE;
        for (int i2 = 0; i2 < this.b.size(); ++i2) {
            q q2 = (q)this.b.valueAt(i2);
            q2.f = false;
            q2.a.a();
        }
    }
}

