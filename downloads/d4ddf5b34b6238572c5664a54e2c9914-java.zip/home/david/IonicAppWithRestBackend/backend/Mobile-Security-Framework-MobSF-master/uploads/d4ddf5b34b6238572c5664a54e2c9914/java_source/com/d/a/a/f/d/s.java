/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

public final class s {
    volatile long a = Long.MIN_VALUE;
    private final long b = 0;
    private long c;

    public final long a(long l2) {
        long l3;
        if (this.a != Long.MIN_VALUE) {
            long l4 = (this.a + 0x100000000L) / 0x200000000L;
            l3 = (l4 - 1) * 0x200000000L + l2;
            l2 = l4 * 0x200000000L + l2;
            if (Math.abs(l3 - this.a) < Math.abs(l2 - this.a)) {
                l2 = l3;
            }
        }
        l3 = 1000000 * l2 / 90000;
        if (this.b != Long.MAX_VALUE && this.a == Long.MIN_VALUE) {
            this.c = this.b - l3;
        }
        this.a = l2;
        return this.c + l3;
    }
}

