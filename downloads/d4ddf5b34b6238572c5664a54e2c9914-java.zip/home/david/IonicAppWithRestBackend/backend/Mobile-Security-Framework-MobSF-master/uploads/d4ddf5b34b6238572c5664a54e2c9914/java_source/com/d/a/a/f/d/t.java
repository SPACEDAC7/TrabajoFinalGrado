/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.d.b;
import com.d.a.a.f.g;

abstract class t {
    public abstract void a();

    public abstract void a(b var1, boolean var2, g var3);
}

