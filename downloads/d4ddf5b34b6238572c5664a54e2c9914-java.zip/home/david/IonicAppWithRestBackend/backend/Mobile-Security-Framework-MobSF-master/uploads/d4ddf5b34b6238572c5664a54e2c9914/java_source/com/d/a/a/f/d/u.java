/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 */
package com.d.a.a.f.d;

import android.util.SparseArray;
import com.d.a.a.d.b;
import com.d.a.a.d.c;
import com.d.a.a.f.d.t;
import com.d.a.a.f.d.v;
import com.d.a.a.f.d.x;
import com.d.a.a.f.g;

final class u
extends t {
    final /* synthetic */ x a;
    private final c b;

    public u(x x2) {
        this.a = x2;
        this.b = new c(new byte[4]);
    }

    @Override
    public final void a() {
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(b b2, boolean bl2, g object) {
        if (bl2) {
            b2.b(b2.a() + b2.b);
        }
        object = this.b;
        b2.a(object.a, 0, 3);
        object.a(0);
        this.b.b(12);
        int n2 = this.b.c(12);
        b2.b(b2.b + 5);
        int n3 = (n2 - 9) / 4;
        n2 = 0;
        while (n2 < n3) {
            object = this.b;
            b2.a(object.a, 0, 4);
            object.a(0);
            int n4 = this.b.c(16);
            this.b.b(3);
            if (n4 == 0) {
                this.b.b(13);
            } else {
                n4 = this.b.c(13);
                this.a.a.put(n4, (Object)new v(this.a));
            }
            ++n2;
        }
    }
}

