/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 *  android.util.SparseBooleanArray
 */
package com.d.a.a.f.d;

import android.util.SparseArray;
import android.util.SparseBooleanArray;
import com.d.a.a.f.d.a;
import com.d.a.a.f.d.b;
import com.d.a.a.f.d.c;
import com.d.a.a.f.d.e;
import com.d.a.a.f.d.f;
import com.d.a.a.f.d.h;
import com.d.a.a.f.d.k;
import com.d.a.a.f.d.o;
import com.d.a.a.f.d.p;
import com.d.a.a.f.d.s;
import com.d.a.a.f.d.t;
import com.d.a.a.f.d.w;
import com.d.a.a.f.d.x;
import com.d.a.a.f.g;
import com.d.a.a.f.n;

final class v
extends t {
    final /* synthetic */ x a;
    private final com.d.a.a.d.c b;
    private final com.d.a.a.d.b c;
    private int d;
    private int e;

    public v(x x2) {
        this.a = x2;
        this.b = new com.d.a.a.d.c(new byte[5]);
        this.c = new com.d.a.a.d.b();
    }

    @Override
    public final void a() {
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void a(com.d.a.a.d.b var1_1, boolean var2_2, g var3_3) {
        block26 : {
            if (!var2_2) ** GOTO lbl18
            var1_1.b(var1_1.a() + var1_1.b);
            var15_4 = this.b;
            var1_1.a(var15_4.a, 0, 3);
            var15_4.a(0);
            this.b.b(12);
            this.d = this.b.c(12);
            var15_4 = this.c;
            if (var15_4.a != null) ** GOTO lbl26
            var4_5 = 0;
lbl11: // 2 sources:
            while (var4_5 < this.d) {
                var15_4 = this.c;
                var16_6 = new byte[this.d];
                var4_5 = this.d;
                var15_4.a = var16_6;
                var15_4.c = var4_5;
                var15_4.b = 0;
lbl18: // 3 sources:
                do {
                    var4_5 = Math.min(var1_1.c - var1_1.b, this.d - this.e);
                    var1_1.a(this.c.a, this.e, var4_5);
                    this.e = var4_5 + this.e;
                    if (this.e < this.d) {
                        return;
                    }
                    break block26;
                    break;
                } while (true);
            }
            ** GOTO lbl28
lbl26: // 1 sources:
            var4_5 = var15_4.a.length;
            ** GOTO lbl11
lbl28: // 1 sources:
            var15_4 = this.c;
            var15_4.b = 0;
            var15_4.c = 0;
            this.c.a(this.d);
            ** while (true)
        }
        var1_1 = this.c;
        var1_1.b(var1_1.b + 7);
        var1_1 = this.c;
        var15_4 = this.b;
        var1_1.a(var15_4.a, 0, 2);
        var15_4.a(0);
        this.b.b(4);
        var4_5 = this.b.c(12);
        var1_1 = this.c;
        var1_1.b(var1_1.b + var4_5);
        if (this.a.c == null) {
            this.a.c = new o(var3_3.a_(21));
        }
        var5_7 = this.d - 9 - var4_5 - 4;
        block14 : while (var5_7 > 0) {
            var1_1 = this.c;
            var15_4 = this.b;
            var1_1.a(var15_4.a, 0, 5);
            var15_4.a(0);
            var4_5 = this.b.c(8);
            this.b.b(3);
            var7_9 = this.b.c(13);
            this.b.b(4);
            var8_10 = this.b.c(12);
            if (var4_5 != 6) ** GOTO lbl103
            var1_1 = this.c;
            var6_8 = -1;
            var9_11 = var1_1.b + var8_10;
            block15 : do {
                var4_5 = var6_8;
                if (var1_1.b >= var9_11) ** GOTO lbl70
                var11_13 = var1_1.a();
                var10_12 = var1_1.a();
                if (var11_13 != 5) ** GOTO lbl90
                var13_15 = var1_1.e();
                if (var13_15 != x.d) ** GOTO lbl83
                var4_5 = 129;
lbl70: // 2 sources:
                block16 : do {
                    var1_1.b(var9_11);
                    block17 : do {
                        var5_7 -= var8_10 + 5;
                        if (this.a.b.get(var4_5)) continue block14;
                        switch (var4_5) {
                            default: {
                                var1_1 = null;
lbl78: // 13 sources:
                                while (var1_1 != null) {
                                    this.a.b.put(var4_5, true);
                                    this.a.a.put(var7_9, (Object)new w((c)var1_1, this.a.g));
                                    continue block14;
                                }
                                continue block14;
                            }
lbl83: // 1 sources:
                            if (var13_15 == x.e) {
                                var4_5 = 135;
                                continue block16;
                            }
                            var4_5 = var6_8;
                            if (var13_15 != x.f) continue block16;
                            var4_5 = 36;
                            continue block16;
lbl90: // 1 sources:
                            if (var11_13 == 106) {
                                var4_5 = 129;
lbl92: // 4 sources:
                                do {
                                    var1_1.b(var1_1.b + var10_12);
                                    var6_8 = var4_5;
                                    continue block15;
                                    break;
                                } while (true);
                            }
                            if (var11_13 != 122) ** GOTO lbl99
                            var4_5 = 135;
                            ** GOTO lbl92
lbl99: // 1 sources:
                            var4_5 = var6_8;
                            if (var11_13 != 123) ** GOTO lbl92
                            var4_5 = 138;
                            ** continue;
lbl103: // 1 sources:
                            var1_1 = this.c;
                            var1_1.b(var1_1.b + var8_10);
                            continue block17;
                            case 3: {
                                var1_1 = new p(var3_3.a_(3));
                                ** GOTO lbl78
                            }
                            case 4: {
                                var1_1 = new p(var3_3.a_(4));
                                ** GOTO lbl78
                            }
                            case 15: {
                                if ((this.a.h & 2) == 0) ** GOTO lbl116
                                var1_1 = null;
                                ** GOTO lbl78
lbl116: // 1 sources:
                                var1_1 = new e(var3_3.a_(15), new n());
                                ** GOTO lbl78
                            }
                            case 129: {
                                var1_1 = new b(var3_3.a_(129), false);
                                ** GOTO lbl78
                            }
                            case 135: {
                                var1_1 = new b(var3_3.a_(135), true);
                                ** GOTO lbl78
                            }
                            case 130: 
                            case 138: {
                                var1_1 = new f(var3_3.a_(138));
                                ** GOTO lbl78
                            }
                            case 2: {
                                var1_1 = new h(var3_3.a_(2));
                                ** GOTO lbl78
                            }
                            case 27: {
                                if ((this.a.h & 4) == 0) ** GOTO lbl134
                                var1_1 = null;
                                ** GOTO lbl78
lbl134: // 1 sources:
                                var1_1 = var3_3.a_(27);
                                var15_4 = new a(var3_3.a_(256));
                                if ((this.a.h & 1) == 0) ** GOTO lbl144
                                var2_2 = true;
lbl138: // 2 sources:
                                while ((this.a.h & 8) != 0) {
                                    var12_14 = true;
lbl140: // 2 sources:
                                    do {
                                        var1_1 = new k((com.d.a.a.f.b)var1_1, (a)var15_4, var2_2, var12_14);
                                        ** GOTO lbl78
                                        break;
                                    } while (true);
                                }
                                ** GOTO lbl146
lbl144: // 1 sources:
                                var2_2 = false;
                                ** GOTO lbl138
lbl146: // 1 sources:
                                var12_14 = false;
                                ** continue;
                            }
                            case 36: {
                                var1_1 = new com.d.a.a.f.d.n(var3_3.a_(36), new a(var3_3.a_(256)));
                                ** GOTO lbl78
                            }
                            case 21: 
                        }
                        break;
                    } while (true);
                    break;
                } while (true);
                break;
            } while (true);
            var1_1 = this.a.c;
            ** GOTO lbl78
        }
        var3_3.a();
    }
}

