/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.d;

import com.d.a.a.d.b;
import com.d.a.a.f.d.c;
import com.d.a.a.f.d.s;
import com.d.a.a.f.d.t;
import com.d.a.a.f.g;

final class w
extends t {
    private final c a;
    private final s b;
    private final com.d.a.a.d.c c;
    private int d;
    private int e;
    private boolean f;
    private boolean g;
    private boolean h;
    private int i;
    private int j;
    private boolean k;
    private long l;

    public w(c c2, s s2) {
        this.a = c2;
        this.b = s2;
        this.c = new com.d.a.a.d.c(new byte[10]);
        this.d = 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private boolean a(b b2, byte[] arrby, int n2) {
        int n3 = Math.min(b2.c - b2.b, n2 - this.e);
        if (n3 <= 0) {
            return true;
        }
        if (arrby == null) {
            b2.b(b2.b + n3);
        } else {
            b2.a(arrby, this.e, n3);
        }
        this.e = n3 + this.e;
        if (this.e == n2) return true;
        return false;
    }

    @Override
    public final void a() {
        this.d = 0;
        this.e = 0;
        this.h = false;
        this.a.a();
    }

    /*
     * Exception decompiling
     */
    @Override
    public final void a(b var1_1, boolean var2_2, g var3_3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }
}

