/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 *  android.util.SparseBooleanArray
 */
package com.d.a.a.f.d;

import android.util.SparseArray;
import android.util.SparseBooleanArray;
import com.d.a.a.d.ah;
import com.d.a.a.d.b;
import com.d.a.a.d.c;
import com.d.a.a.f.d.o;
import com.d.a.a.f.d.s;
import com.d.a.a.f.d.t;
import com.d.a.a.f.d.u;
import com.d.a.a.f.g;
import com.d.a.a.f.h;
import com.d.a.a.f.j;
import com.d.a.a.f.k;
import com.d.a.a.f.m;

public final class x
implements h {
    public static final long d = ah.e("AC-3");
    public static final long e = ah.e("EAC3");
    public static final long f = ah.e("HEVC");
    final SparseArray<t> a;
    final SparseBooleanArray b;
    o c;
    public final s g;
    public final int h;
    private final b i;
    private final c j;
    private g k;

    public x() {
        this(new s());
    }

    private x(s s2) {
        this(s2, 0);
    }

    private x(s s2, byte by2) {
        this.g = s2;
        this.h = 0;
        this.i = new b(188);
        this.j = new c(new byte[3]);
        this.a = new SparseArray();
        this.a.put(0, (Object)new u(this));
        this.b = new SparseBooleanArray();
    }

    static /* synthetic */ int a(x x2) {
        return x2.h;
    }

    static /* synthetic */ long b() {
        return d;
    }

    static /* synthetic */ s b(x x2) {
        return x2.g;
    }

    static /* synthetic */ long c() {
        return e;
    }

    static /* synthetic */ long d() {
        return f;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int a(m object, k object2) {
        int n2 = 0;
        boolean bl2 = true;
        if (!object.a(this.i.a, 0, 188, true)) {
            return -1;
        }
        this.i.b(0);
        this.i.a(188);
        int n3 = n2;
        if (this.i.a() != 71) return n3;
        object = this.i;
        object2 = this.j;
        object.a(object2.a, 0, 3);
        object2.a(0);
        this.j.b(1);
        boolean bl3 = this.j.c(1) == 1;
        this.j.b(1);
        int n4 = this.j.c(13);
        this.j.b(2);
        n3 = this.j.c(1) == 1 ? 1 : 0;
        if (this.j.c(1) != 1) {
            bl2 = false;
        }
        if (n3 != 0) {
            n3 = this.i.a();
            object = this.i;
            object.b(n3 + object.b);
        }
        n3 = n2;
        if (!bl2) return n3;
        object = (t)this.a.get(n4);
        n3 = n2;
        if (object == null) return n3;
        object.a(this.i, bl3, this.k);
        return 0;
    }

    @Override
    public final void a(g g2) {
        this.k = g2;
        g2.a(j.a);
    }

    @Override
    public final boolean a(m m2) {
        byte[] arrby = new byte[1];
        for (int i2 = 0; i2 < 5; ++i2) {
            m2.c(arrby, 0, 1);
            if ((arrby[0] & 255) != 71) {
                return false;
            }
            m2.c(187);
        }
        return true;
    }

    @Override
    public final void c_() {
        this.g.a = Long.MIN_VALUE;
        for (int i2 = 0; i2 < this.a.size(); ++i2) {
            ((t)this.a.valueAt(i2)).a();
        }
    }
}

