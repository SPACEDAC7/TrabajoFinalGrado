/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.a.aa;
import com.d.a.a.d.b;
import com.d.a.a.f.c;
import com.d.a.a.f.d;
import java.util.concurrent.LinkedBlockingDeque;

public final class e {
    final aa a;
    final int b;
    public final c c;
    final LinkedBlockingDeque<com.d.a.a.a.b> d;
    final d e;
    final b f;
    long g;
    public long h;
    public com.d.a.a.a.b i;
    public int j;

    public e(aa aa2) {
        this.a = aa2;
        this.b = aa2.a;
        this.c = new c();
        this.d = new LinkedBlockingDeque();
        this.e = new d();
        this.f = new b(32);
        this.j = this.b;
    }

    public final int a(int n2) {
        if (this.j == this.b) {
            this.j = 0;
            this.i = this.a.a();
            this.d.add(this.i);
        }
        return Math.min(n2, this.b - this.j);
    }

    public final void a() {
        this.a(this.c.a());
    }

    final void a(long l2) {
        int n2 = (int)(l2 - this.g) / this.b;
        for (int i2 = 0; i2 < n2; ++i2) {
            this.a.a(this.d.remove());
            this.g += (long)this.b;
        }
    }

    final void a(long l2, byte[] arrby, int n2) {
        int n3;
        for (int i2 = 0; i2 < n2; i2 += n3) {
            this.a(l2);
            int n4 = (int)(l2 - this.g);
            n3 = Math.min(n2 - i2, this.b - n4);
            com.d.a.a.a.b b2 = this.d.peek();
            System.arraycopy(b2.a, b2.b + n4, arrby, i2, n3);
            l2 += (long)n3;
        }
    }
}

