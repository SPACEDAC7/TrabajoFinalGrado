/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.e;

public final class b {
    public int a;
    public int b;
}

