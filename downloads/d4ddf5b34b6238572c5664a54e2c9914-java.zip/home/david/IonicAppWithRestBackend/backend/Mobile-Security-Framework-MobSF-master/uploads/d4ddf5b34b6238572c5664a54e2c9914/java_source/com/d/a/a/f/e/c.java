/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.e;

import com.d.a.a.bb;
import com.d.a.a.d.ah;
import com.d.a.a.f.e.a;
import com.d.a.a.f.e.b;
import com.d.a.a.f.m;
import java.io.EOFException;

final class c {
    private static final int a = ah.e("OggS");

    public static int a(byte by2, int n2) {
        return by2 >> 1 & 255 >>> 8 - n2;
    }

    public static void a(a a2, int n2, b b2) {
        b2.b = 0;
        b2.a = 0;
        while (b2.b + n2 < a2.g) {
            int[] arrn = a2.j;
            int n3 = b2.b;
            b2.b = n3 + 1;
            n3 = arrn[n3 + n2];
            b2.a += n3;
            if (n3 == 255) continue;
        }
    }

    public static void a(m m2) {
        int n2 = 2048;
        byte[] arrby = new byte[2048];
        do {
            int n3 = n2;
            if (m2.c != -1) {
                n3 = n2;
                if (m2.d + (long)n2 > m2.c) {
                    n3 = n2 = (int)(m2.c - m2.d);
                    if (n2 < 4) {
                        throw new EOFException();
                    }
                }
            }
            m2.b(arrby, 0, n3, false);
            for (n2 = 0; n2 < n3 - 3; ++n2) {
                if (arrby[n2] != 79 || arrby[n2 + 1] != 103 || arrby[n2 + 2] != 103 || arrby[n2 + 3] != 83) continue;
                m2.b(n2);
                return;
            }
            m2.b(n3 - 3);
            n2 = n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static boolean a(m m2, a a2, com.d.a.a.d.b b2, boolean bl2) {
        int n2 = 0;
        b2.b = 0;
        b2.c = 0;
        a2.a();
        int n3 = m2.c == -1 || m2.c - m2.b() >= 27 ? 1 : 0;
        if (n3 == 0 || !m2.b(b2.a, 0, 27, true)) {
            if (!bl2) throw new EOFException();
            return false;
        }
        if (b2.e() != (long)a) {
            if (bl2) return false;
            throw new bb("expected OggS capture pattern at begin of page");
        }
        a2.a = b2.a();
        if (a2.a != 0) {
            if (bl2) return false;
            throw new bb("unsupported bit stream revision");
        }
        a2.b = b2.a();
        byte[] arrby = b2.a;
        n3 = b2.b;
        b2.b = n3 + 1;
        long l2 = arrby[n3];
        arrby = b2.a;
        n3 = b2.b;
        b2.b = n3 + 1;
        long l3 = arrby[n3];
        arrby = b2.a;
        n3 = b2.b;
        b2.b = n3 + 1;
        long l4 = arrby[n3];
        arrby = b2.a;
        n3 = b2.b;
        b2.b = n3 + 1;
        long l5 = arrby[n3];
        arrby = b2.a;
        n3 = b2.b;
        b2.b = n3 + 1;
        long l6 = arrby[n3];
        arrby = b2.a;
        n3 = b2.b;
        b2.b = n3 + 1;
        long l7 = arrby[n3];
        arrby = b2.a;
        n3 = b2.b;
        b2.b = n3 + 1;
        long l8 = arrby[n3];
        arrby = b2.a;
        n3 = b2.b;
        b2.b = n3 + 1;
        a2.c = l2 & 255 | (l3 & 255) << 8 | (l4 & 255) << 16 | (l5 & 255) << 24 | (l6 & 255) << 32 | (l7 & 255) << 40 | (l8 & 255) << 48 | ((long)arrby[n3] & 255) << 56;
        a2.d = b2.f();
        a2.e = b2.f();
        a2.f = b2.f();
        a2.g = b2.a();
        b2.b = 0;
        b2.c = 0;
        a2.h = a2.g + 27;
        m2.c(b2.a, 0, a2.g);
        n3 = n2;
        while (n3 < a2.g) {
            a2.j[n3] = b2.a();
            a2.i += a2.j[n3];
            ++n3;
        }
        return true;
    }
}

