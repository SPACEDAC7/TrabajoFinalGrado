/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.e;

import com.d.a.a.bb;
import com.d.a.a.f.e.a;
import com.d.a.a.f.e.b;
import com.d.a.a.f.e.c;
import com.d.a.a.f.m;

final class d {
    final a a = new a();
    final com.d.a.a.d.b b = new com.d.a.a.d.b(282);
    int c = -1;
    private final b d = new b();
    private long e;

    d() {
    }

    /*
     * Enabled aggressive block sorting
     */
    public final long a(m m2) {
        boolean bl2 = m2.c != -1;
        if (!bl2) {
            throw new IllegalArgumentException();
        }
        c.a(m2);
        this.a.a();
        while ((this.a.b & 4) != 4) {
            if (this.a.i > 0) {
                m2.b(this.a.i);
            }
            c.a(m2, this.a, this.b, false);
            m2.b(this.a.h);
        }
        return this.a.c;
    }

    public final long a(m m2, long l2) {
        c.a(m2);
        c.a(m2, this.a, this.b, false);
        while (this.a.c < l2) {
            m2.b(this.a.h + this.a.i);
            this.e = this.a.c;
            c.a(m2, this.a, this.b, false);
        }
        if (this.e == 0) {
            throw new bb();
        }
        m2.a();
        l2 = this.e;
        this.e = 0;
        this.c = -1;
        return l2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean a(m m2, com.d.a.a.d.b b2) {
        boolean bl2 = m2 != null && b2 != null;
        if (!bl2) {
            throw new IllegalStateException();
        }
        bl2 = false;
        while (!bl2) {
            int n2;
            int n3;
            if (this.c < 0) {
                if (!c.a(m2, this.a, this.b, true)) {
                    return false;
                }
                n3 = this.a.h;
                if ((this.a.b & 1) == 1 && b2.c == 0) {
                    c.a(this.a, 0, this.d);
                    n2 = this.d.b + 0;
                    n3 += this.d.a;
                } else {
                    n2 = 0;
                }
                m2.b(n3);
                this.c = n2;
            }
            c.a(this.a, this.c, this.d);
            n3 = this.c;
            n2 = this.d.b + n3;
            if (this.d.a > 0) {
                m2.b(b2.a, b2.c, this.d.a);
                b2.a(b2.c + this.d.a);
                bl2 = this.a.j[n2 - 1] != 255;
            }
            n3 = n2;
            if (n2 == this.a.g) {
                n3 = -1;
            }
            this.c = n3;
        }
        return true;
    }
}

