/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.e;

import com.d.a.a.d.b;
import com.d.a.a.f.e.a;

final class e {
    final a a = new a();
    final b b = new b(282);
    long c = -1;
    long d;

    e() {
    }
}

