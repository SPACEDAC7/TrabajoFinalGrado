/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.e;

public final class f {
    public final int a;
    public final int b;
    public final long[] c;
    public final int d;
    public final boolean e;

    public f(int n2, int n3, long[] arrl, int n4, boolean bl2) {
        this.a = n2;
        this.b = n3;
        this.c = arrl;
        this.d = n4;
        this.e = bl2;
    }
}

