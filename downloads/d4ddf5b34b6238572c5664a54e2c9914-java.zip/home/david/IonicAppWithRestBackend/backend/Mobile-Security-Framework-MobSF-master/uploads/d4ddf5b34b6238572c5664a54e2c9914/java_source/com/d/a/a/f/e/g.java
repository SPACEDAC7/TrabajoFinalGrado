/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.e;

public final class g {
    public final String a;
    public final String[] b;
    public final int c;

    public g(String string, String[] arrstring, int n2) {
        this.a = string;
        this.b = arrstring;
        this.c = n2;
    }
}

