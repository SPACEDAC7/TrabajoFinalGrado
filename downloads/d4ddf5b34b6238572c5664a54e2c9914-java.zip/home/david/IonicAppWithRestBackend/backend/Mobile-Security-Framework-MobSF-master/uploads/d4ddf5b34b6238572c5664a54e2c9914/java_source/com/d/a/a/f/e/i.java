/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.e;

public final class i {
    public final boolean a;
    public final int b;
    public final int c;
    public final int d;

    public i(boolean bl2, int n2, int n3, int n4) {
        this.a = bl2;
        this.b = n2;
        this.c = n3;
        this.d = n4;
    }
}

