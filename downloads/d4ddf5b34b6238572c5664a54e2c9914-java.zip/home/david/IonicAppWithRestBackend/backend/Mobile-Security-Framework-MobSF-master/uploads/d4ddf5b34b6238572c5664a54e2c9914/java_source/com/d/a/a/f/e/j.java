/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.d.a.a.f.e;

import android.util.Log;
import com.d.a.a.bb;
import com.d.a.a.d.b;
import com.d.a.a.f.e.i;
import com.d.a.a.f.e.m;

final class j {
    public static int a(int n2) {
        int n3 = 0;
        while (n2 > 0) {
            ++n3;
            n2 >>>= 1;
        }
        return n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    static void a(int n2, m m2) {
        int n3 = m2.a(6);
        int n4 = 0;
        while (n4 < n3 + 1) {
            int n5 = m2.a(16);
            switch (n5) {
                default: {
                    Log.e((String)"VorbisUtil", (String)("mapping type other than 0 not supported: " + n5));
                    break;
                }
                case 0: {
                    n5 = m2.a(1) == 1 ? 1 : 0;
                    n5 = n5 != 0 ? m2.a(4) + 1 : 1;
                    int n6 = m2.a(1) == 1 ? 1 : 0;
                    if (n6 != 0) {
                        int n7 = m2.a(8);
                        for (n6 = 0; n6 < n7 + 1; ++n6) {
                            m2.b(j.a(n2 - 1));
                            m2.b(j.a(n2 - 1));
                        }
                    }
                    if (m2.a(2) != 0) {
                        throw new bb("to reserved bits must be zero after mapping coupling steps");
                    }
                    if (n5 > 1) {
                        for (n6 = 0; n6 < n2; ++n6) {
                            m2.b(4);
                        }
                    }
                    for (n6 = 0; n6 < n5; ++n6) {
                        m2.b(8);
                        m2.b(8);
                        m2.b(8);
                    }
                }
            }
            ++n4;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean a(int n2, b b2, boolean bl2) {
        if (b2.a() != n2) {
            if (bl2) return false;
            {
                throw new bb("expected header type " + Integer.toHexString(n2));
            }
        }
        if (b2.a() == 118 && b2.a() == 111 && b2.a() == 114 && b2.a() == 98 && b2.a() == 105 && b2.a() == 115) {
            return true;
        }
        if (!bl2) throw new bb("expected characters 'vorbis'");
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    static i[] a(m m2) {
        int n2 = m2.a(6) + 1;
        i[] arri = new i[n2];
        int n3 = 0;
        while (n3 < n2) {
            boolean bl2 = m2.a(1) == 1;
            arri[n3] = new i(bl2, m2.a(16), m2.a(16), m2.a(8));
            ++n3;
        }
        return arri;
    }

    /*
     * Enabled aggressive block sorting
     */
    static void b(m m2) {
        int n2 = m2.a(6);
        int n3 = 0;
        while (n3 < n2 + 1) {
            int n4;
            int n5;
            if (m2.a(16) > 2) {
                throw new bb("residueType greater than 2 is not decodable");
            }
            m2.b(24);
            m2.b(24);
            m2.b(24);
            int n6 = m2.a(6) + 1;
            m2.b(8);
            int[] arrn = new int[n6];
            for (n4 = 0; n4 < n6; ++n4) {
                int n7 = m2.a(3);
                n5 = m2.a(1) == 1 ? 1 : 0;
                n5 = n5 != 0 ? m2.a(5) : 0;
                arrn[n4] = n5 * 8 + n7;
            }
            for (n4 = 0; n4 < n6; ++n4) {
                for (n5 = 0; n5 < 8; ++n5) {
                    if ((arrn[n4] & 1 << n5) == 0) continue;
                    m2.b(8);
                }
            }
            ++n3;
        }
    }

    static void c(m m2) {
        int n2 = m2.a(6);
        block4 : for (int i2 = 0; i2 < n2 + 1; ++i2) {
            int n3 = m2.a(16);
            switch (n3) {
                int n4;
                default: {
                    throw new bb("floor type greater than 1 not decodable: " + n3);
                }
                case 0: {
                    m2.b(8);
                    m2.b(16);
                    m2.b(16);
                    m2.b(6);
                    m2.b(8);
                    n4 = m2.a(4);
                    for (n3 = 0; n3 < n4 + 1; ++n3) {
                        m2.b(8);
                    }
                    continue block4;
                }
                case 1: {
                    int n5;
                    int n6 = m2.a(5);
                    n4 = -1;
                    int[] arrn = new int[n6];
                    for (n3 = 0; n3 < n6; ++n3) {
                        arrn[n3] = m2.a(4);
                        n5 = n4;
                        if (arrn[n3] > n4) {
                            n5 = arrn[n3];
                        }
                        n4 = n5;
                    }
                    int[] arrn2 = new int[n4 + 1];
                    for (n3 = 0; n3 < arrn2.length; ++n3) {
                        arrn2[n3] = m2.a(3) + 1;
                        n5 = m2.a(2);
                        if (n5 > 0) {
                            m2.b(8);
                        }
                        for (n4 = 0; n4 < 1 << n5; ++n4) {
                            m2.b(8);
                        }
                    }
                    m2.b(2);
                    int n7 = m2.a(4);
                    n4 = 0;
                    n5 = 0;
                    for (n3 = 0; n3 < n6; ++n3) {
                        while (n4 < (n5 += arrn2[arrn[n3]])) {
                            m2.b(n7);
                            ++n4;
                        }
                    }
                }
            }
        }
    }
}

