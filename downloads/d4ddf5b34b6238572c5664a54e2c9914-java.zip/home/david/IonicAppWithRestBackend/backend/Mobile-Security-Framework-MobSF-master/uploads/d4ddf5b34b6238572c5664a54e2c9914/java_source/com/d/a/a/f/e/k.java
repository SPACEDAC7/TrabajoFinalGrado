/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.e;

import com.d.a.a.f.e.g;
import com.d.a.a.f.e.h;
import com.d.a.a.f.e.i;

final class k {
    public final h a;
    public final g b;
    public final byte[] c;
    public final i[] d;
    public final int e;

    public k(h h2, g g2, byte[] arrby, i[] arri, int n2) {
        this.a = h2;
        this.b = g2;
        this.c = arrby;
        this.d = arri;
        this.e = n2;
    }
}

