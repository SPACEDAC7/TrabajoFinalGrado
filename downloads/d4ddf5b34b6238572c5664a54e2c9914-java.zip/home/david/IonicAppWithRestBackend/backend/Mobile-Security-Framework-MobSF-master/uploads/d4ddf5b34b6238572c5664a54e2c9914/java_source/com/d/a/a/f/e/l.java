/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.e;

import com.d.a.a.bb;
import com.d.a.a.f.b;
import com.d.a.a.f.e.a;
import com.d.a.a.f.e.c;
import com.d.a.a.f.e.d;
import com.d.a.a.f.e.e;
import com.d.a.a.f.e.f;
import com.d.a.a.f.e.g;
import com.d.a.a.f.e.i;
import com.d.a.a.f.h;
import com.d.a.a.f.j;
import com.d.a.a.f.k;
import com.d.a.a.f.m;
import com.d.a.a.q;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;

public final class l
implements h,
j {
    private final com.d.a.a.d.b b = new com.d.a.a.d.b(new byte[65025], 0);
    private final d c = new d();
    private b d;
    private com.d.a.a.f.e.k e;
    private int f;
    private long g;
    private boolean h;
    private final e i = new e();
    private long j = -1;
    private com.d.a.a.f.g k;
    private com.d.a.a.f.e.h l;
    private g m;
    private long n;
    private long o;
    private long p;
    private long q;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(m var1_1, k var2_2) {
        if (this.p != 0) ** GOTO lbl133
        if (this.e != null) ** GOTO lbl114
        this.n = var1_1.d();
        var21_3 = this.b;
        if (this.l == null) {
            this.c.a((m)var1_1, (com.d.a.a.d.b)var21_3);
            com.d.a.a.f.e.j.a(1, var21_3, false);
            var13_4 = var21_3.f();
            var4_5 = var21_3.a();
            var15_6 = var21_3.f();
            var5_7 = var21_3.h();
            var6_8 = var21_3.h();
            var7_9 = var21_3.h();
            var9_10 = var21_3.a();
            var8_11 = (int)Math.pow(2.0, var9_10 & 15);
            var9_10 = (int)Math.pow(2.0, (var9_10 & 240) >> 4);
            var19_12 = (var21_3.a() & 1) > 0;
            this.l = new com.d.a.a.f.e.h(var13_4, var4_5, var15_6, var5_7, var6_8, var7_9, var8_11, var9_10, var19_12, Arrays.copyOf(var21_3.a, var21_3.c));
            var21_3.b = 0;
            var21_3.c = 0;
        }
        if (this.m == null) {
            this.c.a((m)var1_1, (com.d.a.a.d.b)var21_3);
            com.d.a.a.f.e.j.a(3, var21_3, false);
            var22_13 = var21_3.a((int)var21_3.f(), Charset.defaultCharset());
            var4_5 = var22_13.length();
            var13_4 = var21_3.f();
            var23_14 = new String[(int)var13_4];
            var5_7 = var4_5 + 11 + 4;
            var4_5 = 0;
            while ((long)var4_5 < var13_4) {
                var23_14[var4_5] = var21_3.a((int)var21_3.f(), Charset.defaultCharset());
                var5_7 = var5_7 + 4 + var23_14[var4_5].length();
                ++var4_5;
            }
            if ((var21_3.a() & 1) == 0) {
                throw new bb("framing bit expected to be set");
            }
            this.m = new g((String)var22_13, (String[])var23_14, var5_7 + 1);
            var21_3.b = 0;
            var21_3.c = 0;
        }
        this.c.a((m)var1_1, (com.d.a.a.d.b)var21_3);
        var22_13 = new byte[var21_3.c];
        System.arraycopy(var21_3.a, 0, var22_13, 0, var21_3.c);
        var8_11 = this.l.b;
        com.d.a.a.f.e.j.a(5, var21_3, false);
        var9_10 = var21_3.a();
        var23_14 = new com.d.a.a.f.e.m(var21_3.a);
        var23_14.b(var21_3.b * 8);
        var4_5 = 0;
        do {
            if (var4_5 >= var9_10 + 1) ** GOTO lbl63
            if (var23_14.a(24) != 5653314) {
                throw new bb("expected code book to start with [0x56, 0x43, 0x42] at " + (var23_14.b * 8 + var23_14.c));
            }
            var10_15 = var23_14.a(16);
            var11_16 = var23_14.a(24);
            var24_19 = new long[var11_16];
            var19_12 = var23_14.a();
            if (var19_12) ** GOTO lbl60
            var20_18 = var23_14.a();
            ** GOTO lbl65
lbl60: // 1 sources:
            var5_7 = var23_14.a(5) + 1;
            var6_8 = 0;
            ** GOTO lbl69
lbl63: // 1 sources:
            var5_7 = var23_14.a(6);
            break;
lbl65: // 2 sources:
            for (var5_7 = 0; var5_7 < var24_19.length; ++var5_7) {
                var24_19[var5_7] = var20_18 != false && var23_14.a() == false ? 0 : (long)(var23_14.a(5) + 1);
            }
            ** GOTO lbl76
lbl69: // 2 sources:
            while (var6_8 < var24_19.length) {
                var12_17 = var23_14.a(com.d.a.a.f.e.j.a(var11_16 - var6_8));
                for (var7_9 = 0; var7_9 < var12_17 && var6_8 < var24_19.length; ++var7_9, ++var6_8) {
                    var24_19[var6_8] = var5_7;
                }
                ++var5_7;
            }
lbl76: // 2 sources:
            if ((var5_7 = var23_14.a(4)) > 2) {
                throw new bb("lookup type greater than 2 not decodable: " + var5_7);
            }
            if (var5_7 == 1 || var5_7 == 2) {
                var23_14.b(32);
                var23_14.b(32);
                var6_8 = var23_14.a(4);
                var23_14.b(1);
                if (var5_7 == 1) {
                    if (var10_15 != 0) {
                        var13_4 = var11_16;
                        var15_6 = var10_15;
                        var13_4 = (long)Math.floor(Math.pow(var13_4, 1.0 / (double)var15_6));
                    } else {
                        var13_4 = 0;
                    }
                } else {
                    var13_4 = var11_16 * var10_15;
                }
                var23_14.b((int)(var13_4 * (long)(var6_8 + 1)));
            }
            new f(var10_15, var11_16, var24_19, var5_7, var19_12);
            ++var4_5;
        } while (true);
        for (var4_5 = 0; var4_5 < var5_7 + 1; ++var4_5) {
            if (var23_14.a(16) == 0) continue;
            throw new bb("placeholder of time domain transforms not zeroed out");
        }
        com.d.a.a.f.e.j.c((com.d.a.a.f.e.m)var23_14);
        com.d.a.a.f.e.j.b((com.d.a.a.f.e.m)var23_14);
        com.d.a.a.f.e.j.a(var8_11, (com.d.a.a.f.e.m)var23_14);
        var24_19 = com.d.a.a.f.e.j.a((com.d.a.a.f.e.m)var23_14);
        if (!var23_14.a()) {
            throw new bb("framing bit after modes not set as expected");
        }
        var4_5 = com.d.a.a.f.e.j.a(var24_19.length - 1);
        var21_3.b = 0;
        var21_3.c = 0;
        this.e = new com.d.a.a.f.e.k(this.l, this.m, (byte[])var22_13, (i[])var24_19, var4_5);
        this.o = var1_1.c();
        this.k.a(this);
        if (this.n != -1) {
            var2_2.a = var1_1.d() - 8000;
            return 1;
        }
lbl114: // 3 sources:
        var13_4 = this.n == -1 ? -1 : this.c.a((m)var1_1);
        this.p = var13_4;
        var21_3 = new ArrayList<byte[]>();
        var21_3.add(this.e.a.j);
        var21_3.add(this.e.c);
        var13_4 = this.n == -1 ? -1 : this.p * 1000000 / this.e.a.c;
        this.q = var13_4;
        this.d.a(q.a(null, "audio/vorbis", this.e.a.e, 65025, this.q, this.e.a.b, (int)this.e.a.c, var21_3, null));
        if (this.n != -1) {
            var1_1 = this.i;
            var13_4 = this.n - this.o;
            var15_6 = this.p;
            var4_5 = var13_4 > 0 && var15_6 > 0 ? 1 : 0;
            if (var4_5 == 0) {
                throw new IllegalArgumentException();
            }
            var1_1.c = var13_4;
            var1_1.d = var15_6;
            var2_2.a = this.o;
            return 1;
        }
lbl133: // 3 sources:
        if (!this.h && this.j > -1) {
            c.a((m)var1_1);
            var21_3 = this.i;
            var13_4 = this.j;
            var4_5 = var21_3.c != -1 && var21_3.d != 0 ? 1 : 0;
            if (var4_5 == 0) {
                throw new IllegalStateException();
            }
            c.a((m)var1_1, var21_3.a, var21_3.b, false);
            if ((var13_4 -= var21_3.a.c) <= 0 || var13_4 > 72000) {
                var5_7 = var21_3.a.i;
                var6_8 = var21_3.a.h;
                var4_5 = var13_4 <= 0 ? 2 : 1;
                var15_6 = var4_5 * (var6_8 + var5_7);
                var17_20 = var1_1.c();
                var13_4 = var13_4 * var21_3.c / var21_3.d + (var17_20 - var15_6);
            } else {
                var1_1.a();
                var13_4 = -1;
            }
            if (var13_4 != -1) {
                var2_2.a = var13_4;
                return 1;
            }
            this.g = this.c.a((m)var1_1, this.j);
            this.f = this.l.g;
            this.h = true;
            var2_2 = this.i;
            var2_2.a.a();
            var2_2 = var2_2.b;
            var2_2.b = 0;
            var2_2.c = 0;
        }
        if (this.c.a((m)var1_1, this.b) == false) return -1;
        if ((this.b.a[0] & 1) != 1) {
            var3_21 = this.b.a[0];
            var1_1 = this.e;
            var4_5 = c.a(var3_21, var1_1.e);
            var4_5 = var1_1.d[var4_5].a == false ? var1_1.a.g : var1_1.a.h;
            var5_7 = this.h != false ? (this.f + var4_5) / 4 : 0;
            if (this.g + (long)var5_7 >= this.j) {
                var1_1 = this.b;
                var13_4 = var5_7;
                var1_1.a(var1_1.c + 4);
                var1_1.a[var1_1.c - 4] = (byte)(255 & var13_4);
                var1_1.a[var1_1.c - 3] = (byte)(var13_4 >>> 8 & 255);
                var1_1.a[var1_1.c - 2] = (byte)(var13_4 >>> 16 & 255);
                var1_1.a[var1_1.c - 1] = (byte)(var13_4 >>> 24 & 255);
                var13_4 = this.g * 1000000 / this.e.a.c;
                this.d.a(this.b, this.b.c);
                this.d.a(var13_4, 1, this.b.c, 0, null);
                this.j = -1;
            }
            this.h = true;
            this.g += (long)var5_7;
            this.f = var4_5;
        }
        var1_1 = this.b;
        var1_1.b = 0;
        var1_1.c = 0;
        return 0;
    }

    @Override
    public final long a(long l2) {
        if (l2 == 0) {
            this.j = -1;
            return this.o;
        }
        this.j = this.e.a.c * l2 / 1000000;
        return Math.max(this.o, (this.n - this.o) * l2 / this.q - 4000);
    }

    @Override
    public final void a(com.d.a.a.f.g g2) {
        this.d = g2.a_(0);
        g2.a();
        this.k = g2;
    }

    @Override
    public final boolean a() {
        if (this.e != null && this.n != -1) {
            return true;
        }
        return false;
    }

    @Override
    public final boolean a(m object) {
        Object object2;
        block4 : {
            int n2;
            object2 = new a();
            if (c.a((m)object, (a)object2, this.b, true) && (object2.b & 2) == 2 && (n2 = object2.i) >= 7) break block4;
            object = this.b;
            object.b = 0;
            object.c = 0;
            return false;
        }
        try {
            object2 = this.b;
            object2.b = 0;
            object2.c = 0;
            object.c(this.b.a, 0, 7);
            boolean bl2 = com.d.a.a.f.e.j.a(1, this.b, true);
            object = this.b;
            object.b = 0;
            object.c = 0;
            return bl2;
        }
        catch (bb var1_2) {
            com.d.a.a.d.b b2 = this.b;
            b2.b = 0;
            b2.c = 0;
            return false;
        }
        catch (Throwable var1_4) {
            object2 = this.b;
            object2.b = 0;
            object2.c = 0;
            throw var1_4;
        }
    }

    @Override
    public final void c_() {
        Object object = this.c;
        object.a.a();
        com.d.a.a.d.b b2 = object.b;
        b2.b = 0;
        b2.c = 0;
        object.c = -1;
        this.f = 0;
        this.g = 0;
        this.h = false;
        object = this.b;
        object.b = 0;
        object.c = 0;
    }
}

