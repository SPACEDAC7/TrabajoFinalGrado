/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.e;

final class m {
    public final byte[] a;
    int b;
    int c;
    private int d;

    public m(byte[] arrby) {
        this(arrby, arrby.length);
    }

    private m(byte[] arrby, int n2) {
        this.a = arrby;
        this.d = n2 * 8;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final int a(int n2) {
        int n3;
        int n4;
        int n5 = 0;
        int n6 = this.b * 8 + this.c + n2 <= this.d ? 1 : 0;
        if (n6 == 0) {
            throw new IllegalStateException();
        }
        if (n2 == 0) {
            return n5;
        }
        if (this.c != 0) {
            n5 = Math.min(n2, 8 - this.c);
            n3 = 255 >>> 8 - n5 & this.a[this.b] >>> this.c;
            this.c += n5;
            n6 = n5;
            n4 = n3;
            if (this.c == 8) {
                ++this.b;
                this.c = 0;
                n4 = n3;
                n6 = n5;
            }
        } else {
            n6 = 0;
            n4 = 0;
        }
        if (n2 - n6 > 7) {
            n3 = (n2 - n6) / 8;
            for (n5 = 0; n5 < n3; ++n5, n6 += 8) {
                long l2 = n4;
                byte[] arrby = this.a;
                n4 = this.b;
                this.b = n4 + 1;
                n4 = (int)(l2 | ((long)arrby[n4] & 255) << n6);
            }
        }
        n5 = n4;
        if (n2 <= n6) return n5;
        n5 = this.a[this.b];
        this.c += (n2 -= n6);
        return n4 | (255 >>> 8 - n2 & n5) << n6;
    }

    public final boolean a() {
        if (this.a(1) == 1) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void b(int n2) {
        boolean bl2 = this.b * 8 + this.c + n2 <= this.d;
        if (!bl2) {
            throw new IllegalStateException();
        }
        this.b += n2 / 8;
        this.c += n2 % 8;
        if (this.c > 7) {
            ++this.b;
            this.c -= 8;
        }
    }
}

