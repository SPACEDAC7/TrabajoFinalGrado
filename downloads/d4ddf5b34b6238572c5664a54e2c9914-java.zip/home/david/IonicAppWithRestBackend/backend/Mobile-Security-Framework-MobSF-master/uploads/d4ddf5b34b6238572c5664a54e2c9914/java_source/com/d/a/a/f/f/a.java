/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.d.a.a.f.f;

import android.util.Log;
import com.d.a.a.bb;
import com.d.a.a.d.ah;
import com.d.a.a.f.f.b;
import com.d.a.a.f.f.c;
import com.d.a.a.f.f.d;
import com.d.a.a.f.g;
import com.d.a.a.f.h;
import com.d.a.a.f.j;
import com.d.a.a.f.k;
import com.d.a.a.f.m;
import com.d.a.a.q;

public final class a
implements h,
j {
    private g b;
    private com.d.a.a.f.b c;
    private b d;
    private int e;
    private int f;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int a(m m2, k object) {
        long l2;
        int n2;
        long l3;
        if (this.d == null) {
            this.d = d.a(m2);
            if (this.d == null) {
                throw new bb("Error initializing WavHeader. Did you sniff first?");
            }
            this.e = this.d.d;
        }
        object = this.d;
        int n3 = object.f != 0 && object.g != 0 ? 1 : 0;
        if (n3 == 0) {
            b b2 = this.d;
            if (m2 == null) {
                throw new NullPointerException();
            }
            if (b2 == null) {
                throw new NullPointerException();
            }
            com.d.a.a.d.b b3 = new com.d.a.a.d.b(8);
            object = c.a(m2, b3);
            while (object.a != ah.e("data")) {
                Log.w((String)"WavHeaderReader", (String)("Ignoring unknown WAV chunk: " + object.a));
                l2 = 8 + object.b;
                if (object.a == ah.e("RIFF")) {
                    l2 = 12;
                }
                if (l2 > Integer.MAX_VALUE) {
                    throw new bb("Chunk is too large (~2GB+) to skip; id: " + object.a);
                }
                m2.b((int)l2);
                object = c.a(m2, b3);
            }
            m2.b(8);
            l2 = m2.d;
            l3 = object.b;
            b2.f = l2;
            b2.g = l3;
            object = this.c;
            b2 = this.d;
            n3 = b2.b;
            n2 = b2.e;
            int n4 = b2.a;
            b2 = this.d;
            object.a(q.a(null, "audio/raw", n4 * (n3 * n2), 32768, b2.g / (long)(b2.d / b2.a) / (long)b2.a * 1000000 / (long)b2.b, this.d.a, this.d.b, null, null));
            this.b.a(this);
        }
        if ((n3 = this.c.a(m2, 32768 - this.f, true)) != -1) {
            this.f += n3;
        }
        if ((n2 = this.f / this.e * this.e) > 0) {
            l2 = m2.d;
            l3 = this.f;
            this.f -= n2;
            this.c.a((l2 - l3) * 1000000 / (long)this.d.c, 1, n2, this.f, null);
        }
        if (n3 == -1) {
            return -1;
        }
        return 0;
    }

    @Override
    public final long a(long l2) {
        b b2 = this.d;
        l2 = (long)b2.c * l2 / 1000000 / (long)b2.a;
        long l3 = b2.a;
        return b2.f + l2 * l3;
    }

    @Override
    public final void a(g g2) {
        this.b = g2;
        this.c = g2.a_(0);
        this.d = null;
        g2.a();
    }

    @Override
    public final boolean a() {
        return true;
    }

    @Override
    public final boolean a(m m2) {
        if (d.a(m2) != null) {
            return true;
        }
        return false;
    }

    @Override
    public final void c_() {
        this.f = 0;
    }
}

