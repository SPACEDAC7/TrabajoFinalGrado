/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.f;

final class b {
    final int a;
    final int b;
    final int c;
    final int d;
    final int e;
    long f;
    long g;

    public b(int n2, int n3, int n4, int n5, int n6) {
        this.a = n2;
        this.b = n3;
        this.c = n4;
        this.d = n5;
        this.e = n6;
    }
}

