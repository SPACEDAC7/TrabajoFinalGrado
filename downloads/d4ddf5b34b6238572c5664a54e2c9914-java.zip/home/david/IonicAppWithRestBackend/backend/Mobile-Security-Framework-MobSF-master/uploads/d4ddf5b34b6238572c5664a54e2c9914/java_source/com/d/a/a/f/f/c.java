/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.f;

import com.d.a.a.d.b;
import com.d.a.a.f.m;

final class c {
    public final int a;
    public final long b;

    private c(int n2, long l2) {
        this.a = n2;
        this.b = l2;
    }

    public static c a(m m2, b b2) {
        m2.c(b2.a, 0, 8);
        b2.b(0);
        return new c(b2.g(), b2.f());
    }
}

