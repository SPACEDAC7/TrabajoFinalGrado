/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.d.a.a.f.f;

import android.util.Log;
import com.d.a.a.bb;
import com.d.a.a.d.ah;
import com.d.a.a.f.f.b;
import com.d.a.a.f.f.c;
import com.d.a.a.f.m;

final class d {
    /*
     * Enabled aggressive block sorting
     */
    public static b a(m m2) {
        if (m2 == null) {
            throw new NullPointerException();
        }
        com.d.a.a.d.b b2 = new com.d.a.a.d.b(16);
        if (c.a((m)m2, (com.d.a.a.d.b)b2).a != ah.e("RIFF")) {
            return null;
        }
        m2.c(b2.a, 0, 4);
        b2.b(0);
        int n2 = b2.g();
        if (n2 != ah.e("WAVE")) {
            Log.e((String)"WavHeaderReader", (String)("Unsupported RIFF format: " + n2));
            return null;
        }
        c c2 = c.a(m2, b2);
        if (c2.a != ah.e("fmt ")) {
            throw new bb("Second chunk in RIFF WAV should be format; got: " + c2.a);
        }
        n2 = c2.b >= 16 ? 1 : 0;
        if (n2 == 0) {
            throw new IllegalStateException();
        }
        m2.c(b2.a, 0, 16);
        b2.b(0);
        n2 = b2.c();
        int n3 = b2.c();
        int n4 = b2.l();
        int n5 = b2.l();
        int n6 = b2.c();
        int n7 = b2.c();
        int n8 = n3 * n7 / 8;
        if (n6 != n8) {
            throw new bb("Expected WAV block alignment of: " + n8 + "; got: " + n6);
        }
        if (n7 != 16) {
            Log.e((String)"WavHeaderReader", (String)("Only 16-bit WAVs are supported; got: " + n7));
            return null;
        }
        if (n2 != 1 && n2 != 65534) {
            Log.e((String)"WavHeaderReader", (String)("Unsupported WAV format type: " + n2));
            return null;
        }
        m2.c((int)c2.b - 16);
        return new b(n3, n4, n5, n6, n7);
    }
}

