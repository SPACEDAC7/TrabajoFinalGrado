/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.b.d;
import com.d.a.a.f.b;
import com.d.a.a.f.j;

public interface g {
    public void a();

    public void a(d var1);

    public void a(j var1);

    public b a_(int var1);
}

