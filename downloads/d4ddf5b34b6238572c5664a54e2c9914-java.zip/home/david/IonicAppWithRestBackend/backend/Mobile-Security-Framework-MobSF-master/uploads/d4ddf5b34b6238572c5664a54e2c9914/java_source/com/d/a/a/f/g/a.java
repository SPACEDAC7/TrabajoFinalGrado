/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.g;

final class a {
    final int a;
    final long b;

    public a(int n2, long l2) {
        this.a = n2;
        this.b = l2;
    }
}

