/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.g;

import com.d.a.a.f.g.a;
import com.d.a.a.f.g.d;
import com.d.a.a.f.g.g;
import com.d.a.a.f.m;
import java.util.Stack;

public final class b {
    private final byte[] a = new byte[8];
    public final Stack<a> b = new Stack();
    public final d c = new d();
    public g d;
    public int e;
    private int f;
    private long g;

    b() {
    }

    private long a(m m2, int n2) {
        m2.b(this.a, 0, n2);
        long l2 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            l2 = l2 << 8 | (long)(this.a[i2] & 255);
        }
        return l2;
    }

    /*
     * Exception decompiling
     */
    public final boolean a(m var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }
}

