/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.g;

import com.d.a.a.f.m;

public final class d {
    private static final long[] c = new long[]{128, 64, 32, 16, 8, 4, 2, 1};
    public int a;
    public int b;
    private final byte[] d = new byte[8];

    public static int a(int n2) {
        for (int i2 = 0; i2 < c.length; ++i2) {
            if ((c[i2] & (long)n2) == 0) continue;
            return i2 + 1;
        }
        return -1;
    }

    public static long a(byte[] arrby, int n2, boolean bl2) {
        long l2;
        long l3 = l2 = (long)arrby[0] & 255;
        if (bl2) {
            l3 = l2 & (c[n2 - 1] ^ -1);
        }
        for (int i2 = 1; i2 < n2; ++i2) {
            l3 = l3 << 8 | (long)arrby[i2] & 255;
        }
        return l3;
    }

    public final long a(m m2, boolean bl2, boolean bl3, int n2) {
        if (this.a == 0) {
            if (!m2.a(this.d, 0, 1, bl2)) {
                return -1;
            }
            this.b = d.a(this.d[0] & 255);
            if (this.b == -1) {
                throw new IllegalStateException("No valid varint length mask found");
            }
            this.a = 1;
        }
        if (this.b > n2) {
            this.a = 0;
            return -2;
        }
        if (this.b != 1) {
            m2.b(this.d, 1, this.b - 1);
        }
        this.a = 0;
        return d.a(this.d, this.b, bl3);
    }
}

