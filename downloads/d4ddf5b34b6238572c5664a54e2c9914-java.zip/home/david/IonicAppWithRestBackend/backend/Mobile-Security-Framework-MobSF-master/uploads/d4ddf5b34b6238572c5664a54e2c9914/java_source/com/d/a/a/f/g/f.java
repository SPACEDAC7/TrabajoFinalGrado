/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f.g;

import com.d.a.a.d.b;
import com.d.a.a.f.m;

final class f {
    final b a = new b(8);
    int b;

    final long a(m m2) {
        int n2 = 0;
        m2.c(this.a.a, 0, 1);
        int n3 = this.a.a[0] & 255;
        if (n3 == 0) {
            return Long.MIN_VALUE;
        }
        int n4 = 128;
        int n5 = 0;
        while ((n3 & n4) == 0) {
            ++n5;
            n4 >>= 1;
        }
        n3 = ~ n4 & n3;
        m2.c(this.a.a, 1, n5);
        for (n4 = n2; n4 < n5; ++n4) {
            n3 = (n3 << 8) + (this.a.a[n4 + 1] & 255);
        }
        this.b += n5 + 1;
        return n3;
    }
}

