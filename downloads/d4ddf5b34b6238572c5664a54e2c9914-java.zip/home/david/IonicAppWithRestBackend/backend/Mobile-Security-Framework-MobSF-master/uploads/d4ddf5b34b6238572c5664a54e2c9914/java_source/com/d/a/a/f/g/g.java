/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 *  android.util.SparseArray
 */
package com.d.a.a.f.g;

import android.util.Pair;
import android.util.SparseArray;
import com.d.a.a.b.c;
import com.d.a.a.bb;
import com.d.a.a.d.ab;
import com.d.a.a.d.r;
import com.d.a.a.f.b;
import com.d.a.a.f.g.d;
import com.d.a.a.f.g.h;
import com.d.a.a.f.g.i;
import com.d.a.a.f.j;
import com.d.a.a.f.l;
import com.d.a.a.f.m;
import com.d.a.a.q;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class g {
    public final /* synthetic */ i a;

    public g(i i2) {
        this.a = i2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(int var1_1, int var2_2, m var3_3) {
        var14_4 = this.a;
        switch (var1_1) {
            default: {
                throw new bb("Unexpected id: " + var1_1);
            }
            case 21419: {
                Arrays.fill(var14_4.d.a, 0);
                var3_3.b(var14_4.d.a, 4 - var2_2, var2_2);
                var14_4.d.b(0);
                var14_4.m = (int)var14_4.d.e();
                return;
            }
            case 25506: {
                var14_4.j.h = new byte[var2_2];
                var3_3.b(var14_4.j.h, 0, var2_2);
                return;
            }
            case 16981: {
                var14_4.j.f = new byte[var2_2];
                var3_3.b(var14_4.j.f, 0, var2_2);
                return;
            }
            case 18402: {
                var14_4.j.g = new byte[var2_2];
                var3_3.b(var14_4.j.g, 0, var2_2);
                return;
            }
            case 161: 
            case 163: 
        }
        if (var14_4.u == 0) {
            var14_4.A = (int)var14_4.a.a(var3_3, false, true, 8);
            var14_4.B = var14_4.a.b;
            var14_4.w = -1;
            var14_4.u = 1;
            var15_5 = var14_4.c;
            var15_5.b = 0;
            var15_5.c = 0;
        }
        if ((var15_5 = (h)var14_4.b.get(var14_4.A)) == null) {
            var3_3.b(var2_2 - var14_4.B);
            var14_4.u = 0;
            return;
        }
        if (var14_4.u != 1) ** GOTO lbl81
        var14_4.a(var3_3, 3);
        var4_6 = (var14_4.c.a[2] & 6) >> 1;
        if (var4_6 != 0) ** GOTO lbl44
        var14_4.y = 1;
        var14_4.z = i.a(var14_4.z, 1);
        var14_4.z[0] = var2_2 - var14_4.B - 3;
        ** GOTO lbl70
lbl44: // 1 sources:
        if (var1_1 != 163) {
            throw new bb("Lacing only supported in SimpleBlocks.");
        }
        var14_4.a(var3_3, 4);
        var14_4.y = (var14_4.c.a[3] & 255) + 1;
        var14_4.z = i.a(var14_4.z, var14_4.y);
        if (var4_6 != 2) ** GOTO lbl53
        var2_2 = (var2_2 - var14_4.B - 4) / var14_4.y;
        Arrays.fill(var14_4.z, 0, var14_4.y, var2_2);
        ** GOTO lbl70
lbl53: // 1 sources:
        if (var4_6 == 1) {
            var5_7 = 0;
            var4_6 = 4;
            for (var6_8 = 0; var6_8 < var14_4.y - 1; var5_7 += var14_4.z[var6_8], ++var6_8) {
                var14_4.z[var6_8] = 0;
                var7_9 = var4_6;
                do {
                    var4_6 = var7_9 + 1;
                    var14_4.a(var3_3, var4_6);
                    var8_10 = var14_4.c.a[var4_6 - 1] & 255;
                    var16_14 = var14_4.z;
                    var16_14[var6_8] = var16_14[var6_8] + var8_10;
                    var7_9 = var4_6;
                } while (var8_10 == 255);
            }
            var14_4.z[var14_4.y - 1] = var2_2 - var14_4.B - var4_6 - var5_7;
        }
        ** GOTO lbl92
lbl70: // 4 sources:
        do {
            var2_2 = var14_4.c.a[0];
            var4_6 = var14_4.c.a[1];
            var14_4.v = var14_4.q + var14_4.a(var2_2 << 8 | var4_6 & 255);
            var2_2 = (var14_4.c.a[2] & 8) == 8 ? 1 : 0;
            var4_6 = var15_5.c == 2 || var1_1 == 163 && (var14_4.c.a[2] & 128) == 128 ? 1 : 0;
            var4_6 = var4_6 != 0 ? 1 : 0;
            var2_2 = var2_2 != 0 ? 134217728 : 0;
            var14_4.C = var2_2 | var4_6;
            var14_4.u = 2;
            var14_4.x = 0;
lbl81: // 2 sources:
            if (var1_1 != 163) {
                var14_4.a(var3_3, (h)var15_5, var14_4.z[0]);
                return;
            }
            do {
                if (var14_4.x >= var14_4.y) {
                    var14_4.u = 0;
                    return;
                }
                var14_4.a(var3_3, (h)var15_5, var14_4.z[var14_4.x]);
                var14_4.a((h)var15_5, var14_4.v + (long)(var14_4.x * var15_5.d / 1000));
                ++var14_4.x;
            } while (true);
            break;
        } while (true);
lbl92: // 1 sources:
        if (var4_6 != 3) throw new bb("Unexpected lacing value: " + var4_6);
        var5_7 = 0;
        var4_6 = 4;
        var6_8 = 0;
        do {
            if (var6_8 < var14_4.y - 1) {
                var14_4.z[var6_8] = 0;
                var8_10 = var4_6 + 1;
                var14_4.a(var3_3, var8_10);
                if (var14_4.c.a[var8_10 - 1] == 0) {
                    throw new bb("No valid varint length mask found");
                }
            } else {
                var14_4.z[var14_4.y - 1] = var2_2 - var14_4.B - var4_6 - var5_7;
                ** continue;
            }
            var12_13 = 0;
            var7_9 = 0;
            do {
                var4_6 = var8_10;
                var10_12 = var12_13;
                if (var7_9 >= 8) ** GOTO lbl125
                var4_6 = 1 << 7 - var7_9;
                if ((var14_4.c.a[var8_10 - 1] & var4_6) != 0) {
                    var9_11 = var8_10 - 1;
                    var14_4.a(var3_3, var8_10 += var7_9);
                    var12_13 = var14_4.c.a[var9_11] & 255 & ~ var4_6;
                    for (var4_6 = var9_11 + 1; var4_6 < var8_10; ++var4_6) {
                        var12_13 = (long)(var14_4.c.a[var4_6] & 255) | var12_13 << 8;
                    }
                    var4_6 = var8_10;
                    var10_12 = var12_13;
                    if (var6_8 > 0) {
                        var10_12 = var12_13 - ((1 << var7_9 * 7 + 6) - 1);
                        var4_6 = var8_10;
                    }
lbl125: // 4 sources:
                    if (var10_12 < Integer.MIN_VALUE) throw new bb("EBML lacing sample size out of range.");
                    if (var10_12 <= Integer.MAX_VALUE) break;
                    throw new bb("EBML lacing sample size out of range.");
                }
                ++var7_9;
            } while (true);
            var7_9 = (int)var10_12;
            var16_14 = var14_4.z;
            if (var6_8 != 0) {
                var7_9 += var14_4.z[var6_8 - 1];
            }
            var16_14[var6_8] = var7_9;
            var5_7 += var14_4.z[var6_8];
            ++var6_8;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(int n2, long l2) {
        i i2 = this.a;
        switch (n2) {
            default: {
                return;
            }
            case 17143: {
                if (l2 == 1) return;
                throw new bb("EBMLReadVersion " + l2 + " not supported");
            }
            case 17029: {
                if (l2 < 1) throw new bb("DocTypeReadVersion " + l2 + " not supported");
                if (l2 <= 2) return;
                throw new bb("DocTypeReadVersion " + l2 + " not supported");
            }
            case 21420: {
                i2.n = i2.e + l2;
                return;
            }
            case 2807729: {
                i2.g = l2;
                return;
            }
            case 176: {
                i2.j.i = (int)l2;
                return;
            }
            case 186: {
                i2.j.j = (int)l2;
                return;
            }
            case 21680: {
                i2.j.k = (int)l2;
                return;
            }
            case 21690: {
                i2.j.l = (int)l2;
                return;
            }
            case 21682: {
                i2.j.m = (int)l2;
                return;
            }
            case 215: {
                i2.j.b = (int)l2;
                return;
            }
            case 131: {
                i2.j.c = (int)l2;
                return;
            }
            case 2352003: {
                i2.j.d = (int)l2;
                return;
            }
            case 22186: {
                i2.j.q = l2;
                return;
            }
            case 22203: {
                i2.j.r = l2;
                return;
            }
            case 159: {
                i2.j.n = (int)l2;
                return;
            }
            case 25188: {
                i2.j.o = (int)l2;
                return;
            }
            case 251: {
                i2.D = true;
                return;
            }
            case 20529: {
                if (l2 == 0) return;
                throw new bb("ContentEncodingOrder " + l2 + " not supported");
            }
            case 20530: {
                if (l2 == 1) return;
                throw new bb("ContentEncodingScope " + l2 + " not supported");
            }
            case 16980: {
                if (l2 == 3) return;
                throw new bb("ContentCompAlgo " + l2 + " not supported");
            }
            case 18401: {
                if (l2 == 5) return;
                throw new bb("ContentEncAlgo " + l2 + " not supported");
            }
            case 18408: {
                if (l2 == 1) return;
                throw new bb("AESSettingsCipherMode " + l2 + " not supported");
            }
            case 179: {
                i2.r.a(i2.a(l2));
                return;
            }
            case 241: {
                if (i2.t) return;
                i2.s.a(l2);
                i2.t = true;
                return;
            }
            case 231: {
                i2.q = i2.a(l2);
                return;
            }
            case 155: 
        }
        i2.w = i2.a(l2);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(int n2, long l2, long l3) {
        i i2 = this.a;
        switch (n2) {
            default: {
                return;
            }
            case 408125543: {
                if (i2.e != -1 && i2.e != l2) {
                    throw new bb("Multiple Segment elements not supported");
                }
                i2.e = l2;
                i2.f = l3;
                return;
            }
            case 19899: {
                i2.m = -1;
                i2.n = -1;
                return;
            }
            case 475249515: {
                i2.r = new r();
                i2.s = new r();
                return;
            }
            case 187: {
                i2.t = false;
                return;
            }
            case 524531317: {
                if (i2.l) return;
                if (i2.p != -1) {
                    i2.o = true;
                    return;
                }
                i2.E.a(j.a);
                i2.l = true;
                return;
            }
            case 160: {
                i2.D = false;
                return;
            }
            case 20533: {
                i2.j.e = true;
                return;
            }
            case 174: 
        }
        i2.j = new h();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2, String string) {
        i i2 = this.a;
        switch (n2) {
            case 17026: {
                if (!"webm".equals(string) && !"matroska".equals(string)) {
                    throw new bb("DocType " + string + " not supported");
                }
            }
            default: {
                return;
            }
            case 134: {
                i2.j.a = string;
                return;
            }
            case 2274716: 
        }
        i2.j.s = string;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void c(int var1_1) {
        var11_2 = this.a;
        block0 : switch (var1_1) {
            default: {
                return;
            }
            case 357149030: {
                if (var11_2.g == -1) {
                    var11_2.g = 1000000;
                }
                if (var11_2.h == -1) return;
                var11_2.i = var11_2.a(var11_2.h);
                return;
            }
            case 19899: {
                if (var11_2.m == -1) throw new bb("Mandatory element SeekID or SeekPosition not found");
                if (var11_2.n == -1) {
                    throw new bb("Mandatory element SeekID or SeekPosition not found");
                }
                if (var11_2.m != 475249515) return;
                var11_2.p = var11_2.n;
                return;
            }
            case 475249515: {
                if (var11_2.l != false) return;
                var9_3 = var11_2.E;
                if (var11_2.e == -1 || var11_2.i == -1 || var11_2.r == null || var11_2.r.a == 0 || var11_2.s == null || var11_2.s.a != var11_2.r.a) {
                    var11_2.r = null;
                    var11_2.s = null;
                    var8_5 = j.a;
                } else {
                    var4_7 = var11_2.r.a;
                    var8_5 = new int[var4_7];
                    var10_9 = new long[var4_7];
                    var12_11 = new long[var4_7];
                    var13_13 = new long[var4_7];
                    for (var1_1 = 0; var1_1 < var4_7; ++var1_1) {
                        var13_13[var1_1] = var11_2.r.a(var1_1);
                        var10_9[var1_1] = var11_2.e + var11_2.s.a(var1_1);
                    }
                    for (var1_1 = 0; var1_1 < var4_7 - 1; ++var1_1) {
                        var8_5[var1_1] = (int)(var10_9[var1_1 + 1] - var10_9[var1_1]);
                        var12_11[var1_1] = var13_13[var1_1 + 1] - var13_13[var1_1];
                    }
                    var8_5[var4_7 - 1] = (int)(var11_2.e + var11_2.f - var10_9[var4_7 - 1]);
                    var12_11[var4_7 - 1] = var11_2.i - var13_13[var4_7 - 1];
                    var11_2.r = null;
                    var11_2.s = null;
                    var8_5 = new l((int[])var8_5, var10_9, var12_11, var13_13);
                }
                var9_3.a((j)var8_5);
                var11_2.l = true;
                return;
            }
            case 160: {
                if (var11_2.u != 2) return;
                if (!var11_2.D) {
                    var11_2.C |= 1;
                }
                var11_2.a((h)var11_2.b.get(var11_2.A), var11_2.v);
                var11_2.u = 0;
                return;
            }
            case 25152: {
                if (var11_2.j.e == false) return;
                if (var11_2.j.g == null) {
                    throw new bb("Encrypted Track found but ContentEncKeyID was not found");
                }
                if (var11_2.k != false) return;
                var11_2.E.a(new com.d.a.a.b.b(new c("video/webm", var11_2.j.g)));
                var11_2.k = true;
                return;
            }
            case 28032: {
                if (var11_2.j.e == false) return;
                if (var11_2.j.f == null) return;
                throw new bb("Combining encryption and compression is not supported");
            }
            case 174: {
                if (var11_2.b.get(var11_2.j.b) != null || !i.a(var11_2.j.a)) ** GOTO lbl353
                var12_12 = var11_2.j;
                var13_14 = var11_2.E;
                var5_15 = var11_2.j.b;
                var6_16 = var11_2.i;
                var4_8 = -1;
                var8_6 = var12_12.a;
                var1_1 = -1;
                switch (var8_6.hashCode()) {
                    case 82338133: {
                        if (var8_6.equals("V_VP8")) {
                            var1_1 = 0;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 82338134: {
                        if (var8_6.equals("V_VP9")) {
                            var1_1 = 1;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 1809237540: {
                        if (var8_6.equals("V_MPEG2")) {
                            var1_1 = 2;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -2095575984: {
                        if (var8_6.equals("V_MPEG4/ISO/SP")) {
                            var1_1 = 3;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -538363189: {
                        if (var8_6.equals("V_MPEG4/ISO/ASP")) {
                            var1_1 = 4;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -2095576542: {
                        if (var8_6.equals("V_MPEG4/ISO/AP")) {
                            var1_1 = 5;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -538363109: {
                        if (var8_6.equals("V_MPEG4/ISO/AVC")) {
                            var1_1 = 6;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 855502857: {
                        if (var8_6.equals("V_MPEGH/ISO/HEVC")) {
                            var1_1 = 7;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -1373388978: {
                        if (var8_6.equals("V_MS/VFW/FOURCC")) {
                            var1_1 = 8;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -1730367663: {
                        if (var8_6.equals("A_VORBIS")) {
                            var1_1 = 9;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 1951062397: {
                        if (var8_6.equals("A_OPUS")) {
                            var1_1 = 10;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 62923557: {
                        if (var8_6.equals("A_AAC")) {
                            var1_1 = 11;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -1482641357: {
                        if (var8_6.equals("A_MPEG/L3")) {
                            var1_1 = 12;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 62923603: {
                        if (var8_6.equals("A_AC3")) {
                            var1_1 = 13;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 1950749482: {
                        if (var8_6.equals("A_EAC3")) {
                            var1_1 = 14;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -1784763192: {
                        if (var8_6.equals("A_TRUEHD")) {
                            var1_1 = 15;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 62927045: {
                        if (var8_6.equals("A_DTS")) {
                            var1_1 = 16;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 542569478: {
                        if (var8_6.equals("A_DTS/EXPRESS")) {
                            var1_1 = 17;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -356037306: {
                        if (var8_6.equals("A_DTS/LOSSLESS")) {
                            var1_1 = 18;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 1950789798: {
                        if (var8_6.equals("A_FLAC")) {
                            var1_1 = 19;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -1985379776: {
                        if (var8_6.equals("A_MS/ACM")) {
                            var1_1 = 20;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 725957860: {
                        if (var8_6.equals("A_PCM/INT/LIT")) {
                            var1_1 = 21;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case 1422270023: {
                        if (var8_6.equals("S_TEXT/UTF8")) {
                            var1_1 = 22;
                            ** break;
                        }
                        ** GOTO lbl194
                    }
                    case -425012669: {
                        if (var8_6.equals("S_VOBSUB")) {
                            var1_1 = 23;
                        }
                    }
lbl194: // 50 sources:
                    default: {
                        ** GOTO lbl199
                    }
                    case 99146302: 
                }
                if (var8_6.equals("S_HDMV/PGS")) {
                    var1_1 = 24;
                }
lbl199: // 4 sources:
                switch (var1_1) {
                    default: {
                        throw new bb("Unrecognized codec identifier.");
                    }
                    case 0: {
                        var8_6 = "video/x-vnd.on2.vp8";
                        var9_4 = null;
                        var1_1 = var4_8;
                        break;
                    }
                    case 1: {
                        var8_6 = "video/x-vnd.on2.vp9";
                        var9_4 = null;
                        var1_1 = var4_8;
                        break;
                    }
                    case 2: {
                        var8_6 = "video/mpeg2";
                        var9_4 = null;
                        var1_1 = var4_8;
                        break;
                    }
                    case 3: 
                    case 4: 
                    case 5: {
                        var10_10 = "video/mp4v-es";
                        var8_6 = var12_12.h == null ? null : Collections.singletonList(var12_12.h);
                        var9_4 = var8_6;
                        var8_6 = var10_10;
                        var1_1 = var4_8;
                        break;
                    }
                    case 6: {
                        var8_6 = h.b(new com.d.a.a.d.b(var12_12.h));
                        var9_4 = (List)var8_6.first;
                        var12_12.u = (Integer)var8_6.second;
                        var8_6 = "video/avc";
                        var1_1 = var4_8;
                        break;
                    }
                    case 7: {
                        var8_6 = h.c(new com.d.a.a.d.b(var12_12.h));
                        var9_4 = (List)var8_6.first;
                        var12_12.u = (Integer)var8_6.second;
                        var8_6 = "video/hevc";
                        var1_1 = var4_8;
                        break;
                    }
                    case 8: {
                        var8_6 = "video/wvc1";
                        var9_4 = h.a(new com.d.a.a.d.b(var12_12.h));
                        var1_1 = var4_8;
                        break;
                    }
                    case 9: {
                        var8_6 = "audio/vorbis";
                        var1_1 = 8192;
                        var9_4 = h.a(var12_12.h);
                        break;
                    }
                    case 10: {
                        var8_6 = "audio/opus";
                        var1_1 = 5760;
                        var9_4 = new ArrayList<byte[]>(3);
                        var9_4.add(var12_12.h);
                        var9_4.add(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(var12_12.q).array());
                        var9_4.add(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(var12_12.r).array());
                        break;
                    }
                    case 11: {
                        var8_6 = "audio/mp4a-latm";
                        var9_4 = Collections.singletonList(var12_12.h);
                        var1_1 = var4_8;
                        break;
                    }
                    case 12: {
                        var8_6 = "audio/mpeg";
                        var1_1 = 4096;
                        var9_4 = null;
                        break;
                    }
                    case 13: {
                        var8_6 = "audio/ac3";
                        var9_4 = null;
                        var1_1 = var4_8;
                        break;
                    }
                    case 14: {
                        var8_6 = "audio/eac3";
                        var9_4 = null;
                        var1_1 = var4_8;
                        break;
                    }
                    case 15: {
                        var8_6 = "audio/true-hd";
                        var9_4 = null;
                        var1_1 = var4_8;
                        break;
                    }
                    case 16: 
                    case 17: {
                        var8_6 = "audio/vnd.dts";
                        var9_4 = null;
                        var1_1 = var4_8;
                        break;
                    }
                    case 18: {
                        var8_6 = "audio/vnd.dts.hd";
                        var9_4 = null;
                        var1_1 = var4_8;
                        break;
                    }
                    case 19: {
                        var8_6 = "audio/x-flac";
                        var9_4 = Collections.singletonList(var12_12.h);
                        var1_1 = var4_8;
                        break;
                    }
                    case 20: {
                        if (!h.d(new com.d.a.a.d.b(var12_12.h))) {
                            throw new bb("Non-PCM MS/ACM is unsupported");
                        }
                        if (var12_12.o == 16) break block0;
                        throw new bb("Unsupported PCM bit depth: " + var12_12.o);
                    }
                    case 21: {
                        if (var12_12.o == 16) break block0;
                        throw new bb("Unsupported PCM bit depth: " + var12_12.o);
                    }
                    case 22: {
                        var8_6 = "application/x-subrip";
                        var9_4 = null;
                        var1_1 = var4_8;
                        break;
                    }
                    case 23: {
                        var8_6 = "application/vobsub";
                        var9_4 = Collections.singletonList(var12_12.h);
                        var1_1 = var4_8;
                        break;
                    }
                    case 24: {
                        var8_6 = "application/pgs";
                        var9_4 = null;
                        var1_1 = var4_8;
                        break;
                    }
                }
                ** GOTO lbl328
            }
            case 374648427: {
                if (var11_2.b.size() == 0) {
                    throw new bb("No valid tracks were found");
                }
                var11_2.E.a();
                return;
            }
        }
        var8_6 = "audio/raw";
        var9_4 = null;
        var1_1 = var4_8;
lbl328: // 2 sources:
        if (ab.a(var8_6).equals("audio")) {
            var8_6 = q.a(Integer.toString(var5_15), (String)var8_6, -1, var1_1, var6_16, var12_12.n, var12_12.p, var9_4, var12_12.s);
        } else if (ab.a((String)var8_6).equals("video")) {
            if (var12_12.m == 0) {
                var4_8 = var12_12.k == -1 ? var12_12.i : var12_12.k;
                var12_12.k = var4_8;
                var4_8 = var12_12.l == -1 ? var12_12.j : var12_12.l;
                var12_12.l = var4_8;
            }
            var2_18 = var3_17 = -1.0f;
            if (var12_12.k != -1) {
                var2_18 = var3_17;
                if (var12_12.l != -1) {
                    var2_18 = (float)(var12_12.j * var12_12.k) / (float)(var12_12.i * var12_12.l);
                }
            }
            var8_6 = q.a(Integer.toString(var5_15), (String)var8_6, -1, var1_1, var6_16, var12_12.i, var12_12.j, var9_4, -1, var2_18);
        } else if ("application/x-subrip".equals(var8_6)) {
            var8_6 = q.a(Integer.toString(var5_15), (String)var8_6, -1, var6_16, var12_12.s, Long.MAX_VALUE);
        } else {
            if (!"application/vobsub".equals(var8_6)) {
                if ("application/pgs".equals(var8_6) == false) throw new bb("Unexpected MIME type.");
            }
            var8_6 = new q(Integer.toString(var5_15), (String)var8_6, -1, -1, var6_16, -1, -1, -1, -1.0f, -1, -1, var12_12.s, Long.MAX_VALUE, var9_4, false, -1, -1, -1, -1);
        }
        var12_12.t = var13_14.a_(var12_12.b);
        var12_12.t.a((q)var8_6);
        var11_2.b.put(var11_2.j.b, (Object)var11_2.j);
lbl353: // 2 sources:
        var11_2.j = null;
    }
}

