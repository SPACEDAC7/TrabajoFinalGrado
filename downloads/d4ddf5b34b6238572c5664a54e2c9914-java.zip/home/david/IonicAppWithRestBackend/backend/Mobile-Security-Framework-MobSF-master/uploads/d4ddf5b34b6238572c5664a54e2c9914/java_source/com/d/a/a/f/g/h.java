/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 */
package com.d.a.a.f.g;

import android.util.Pair;
import com.d.a.a.bb;
import com.d.a.a.f.b;
import com.d.a.a.f.g.i;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class h {
    public String a;
    public int b;
    public int c;
    public int d;
    public boolean e;
    public byte[] f;
    public byte[] g;
    public byte[] h;
    public int i = -1;
    public int j = -1;
    public int k = -1;
    public int l = -1;
    public int m = 0;
    public int n = 1;
    public int o = -1;
    public int p = 8000;
    public long q = 0;
    public long r = 0;
    String s = "eng";
    public b t;
    public int u;

    /*
     * Exception decompiling
     */
    static List<byte[]> a(com.d.a.a.d.b var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:371)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:449)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static List<byte[]> a(byte[] var0) {
        var3_2 = 0;
        if (var0[0] != 2) {
            throw new bb("Error parsing vorbis codec private");
        }
        var1_3 = 0;
        var2_4 = 1;
        while (var0[var2_4] == -1) {
            ++var2_4;
            var1_3 += 255;
        }
        var4_8 = var2_4 + 1;
        var5_5 = var1_3 + var0[var2_4];
        var2_4 = var4_8;
        var1_3 = var3_2;
        while (var0[var2_4] == -1) {
            var1_3 += 255;
            ++var2_4;
        }
        var3_2 = var2_4 + 1;
        var2_4 = var0[var2_4];
        if (var0[var3_2] == true) ** GOTO lbl24
        try {
            throw new bb("Error parsing vorbis codec private");
lbl24: // 1 sources:
            var6_6 = new byte[var5_5];
            System.arraycopy(var0, var3_2, var6_6, 0, var5_5);
            var3_2 = var5_5 + var3_2;
        }
        catch (ArrayIndexOutOfBoundsException var0_1) {
            throw new bb("Error parsing vorbis codec private");
        }
        if (var0[var3_2] != 3) {
            throw new bb("Error parsing vorbis codec private");
        }
        if (var0[var1_3 = var1_3 + var2_4 + var3_2] != 5) {
            throw new bb("Error parsing vorbis codec private");
        }
        var7_7 = new byte[var0.length - var1_3];
        System.arraycopy(var0, var1_3, var7_7, 0, var0.length - var1_3);
        var0 = new ArrayList<E>(2);
        var0.add(var6_6);
        var0.add(var7_7);
        return var0;
    }

    /*
     * Exception decompiling
     */
    static Pair<List<byte[]>, Integer> b(com.d.a.a.d.b var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:371)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:449)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    static Pair<List<byte[]>, Integer> c(com.d.a.a.d.b var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 9[FORLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    static boolean d(com.d.a.a.d.b b2) {
        block5 : {
            long l2;
            long l3;
            try {
                int n2 = b2.c();
                if (n2 == 1) {
                    return true;
                }
                if (n2 != 65534) break block5;
            }
            catch (ArrayIndexOutOfBoundsException var0_1) {
                throw new bb("Error parsing MS/ACM codec private");
            }
            b2.b(24);
            if (b2.i() != i.H.getMostSignificantBits() || (l3 = b2.i()) != (l2 = i.H.getLeastSignificantBits())) {
                return false;
            }
        }
        return false;
        return true;
    }
}

