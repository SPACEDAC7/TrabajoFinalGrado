/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 */
package com.d.a.a.f.g;

import android.util.SparseArray;
import com.d.a.a.bb;
import com.d.a.a.d.ah;
import com.d.a.a.d.q;
import com.d.a.a.d.r;
import com.d.a.a.f.g;
import com.d.a.a.f.g.a;
import com.d.a.a.f.g.b;
import com.d.a.a.f.g.d;
import com.d.a.a.f.g.f;
import com.d.a.a.f.h;
import com.d.a.a.f.k;
import com.d.a.a.f.m;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Locale;
import java.util.Stack;
import java.util.UUID;

public final class i
implements h {
    private static final byte[] F = new byte[]{49, 10, 48, 48, 58, 48, 48, 58, 48, 48, 44, 48, 48, 48, 32, 45, 45, 62, 32, 48, 48, 58, 48, 48, 58, 48, 48, 44, 48, 48, 48, 10};
    private static final byte[] G = new byte[]{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32};
    public static final UUID H = new UUID(0x100000000001000L, -9223371306706625679L);
    int A;
    int B;
    int C;
    boolean D;
    g E;
    private final b I;
    private final com.d.a.a.d.b J;
    private final com.d.a.a.d.b K;
    private final com.d.a.a.d.b L;
    private final com.d.a.a.d.b M;
    private final com.d.a.a.d.b N;
    private long O = -1;
    private int P;
    private boolean Q;
    private int R;
    private int S;
    private boolean T;
    final d a;
    final SparseArray<com.d.a.a.f.g.h> b;
    final com.d.a.a.d.b c;
    final com.d.a.a.d.b d;
    long e = -1;
    long f = -1;
    long g = -1;
    public long h = -1;
    long i = -1;
    public com.d.a.a.f.g.h j;
    boolean k;
    boolean l;
    int m;
    long n;
    boolean o;
    long p = -1;
    long q = -1;
    r r;
    r s;
    boolean t;
    int u;
    long v;
    long w;
    int x;
    int y;
    int[] z;

    public i() {
        this(new b());
    }

    private i(b b2) {
        this.I = b2;
        this.I.d = new com.d.a.a.f.g.g(this);
        this.a = new d();
        this.b = new SparseArray();
        this.c = new com.d.a.a.d.b(4);
        this.L = new com.d.a.a.d.b(ByteBuffer.allocate(4).putInt(-1).array());
        this.d = new com.d.a.a.d.b(4);
        this.J = new com.d.a.a.d.b(q.a);
        this.K = new com.d.a.a.d.b(4);
        this.M = new com.d.a.a.d.b();
        this.N = new com.d.a.a.d.b();
    }

    public static int a(int n2) {
        switch (n2) {
            default: {
                return 0;
            }
            case 160: 
            case 174: 
            case 183: 
            case 187: 
            case 224: 
            case 225: 
            case 18407: 
            case 19899: 
            case 20532: 
            case 20533: 
            case 25152: 
            case 28032: 
            case 290298740: 
            case 357149030: 
            case 374648427: 
            case 408125543: 
            case 440786851: 
            case 475249515: 
            case 524531317: {
                return 1;
            }
            case 131: 
            case 155: 
            case 159: 
            case 176: 
            case 179: 
            case 186: 
            case 215: 
            case 231: 
            case 241: 
            case 251: 
            case 16980: 
            case 17029: 
            case 17143: 
            case 18401: 
            case 18408: 
            case 20529: 
            case 20530: 
            case 21420: 
            case 21680: 
            case 21682: 
            case 21690: 
            case 22186: 
            case 22203: 
            case 25188: 
            case 2352003: 
            case 2807729: {
                return 2;
            }
            case 134: 
            case 17026: 
            case 2274716: {
                return 3;
            }
            case 161: 
            case 163: 
            case 16981: 
            case 18402: 
            case 21419: 
            case 25506: {
                return 4;
            }
            case 181: 
            case 17545: 
        }
        return 5;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int a(m m2, com.d.a.a.f.b b2, int n2) {
        com.d.a.a.d.b b3 = this.M;
        int n3 = b3.c - b3.b;
        if (n3 > 0) {
            n2 = Math.min(n2, n3);
            b2.a(this.M, n2);
        } else {
            n2 = b2.a(m2, n2, false);
        }
        this.P += n2;
        this.S += n2;
        return n2;
    }

    static boolean a(String string) {
        if ("V_VP8".equals(string) || "V_VP9".equals(string) || "V_MPEG2".equals(string) || "V_MPEG4/ISO/SP".equals(string) || "V_MPEG4/ISO/ASP".equals(string) || "V_MPEG4/ISO/AP".equals(string) || "V_MPEG4/ISO/AVC".equals(string) || "V_MPEGH/ISO/HEVC".equals(string) || "V_MS/VFW/FOURCC".equals(string) || "A_OPUS".equals(string) || "A_VORBIS".equals(string) || "A_AAC".equals(string) || "A_MPEG/L3".equals(string) || "A_AC3".equals(string) || "A_EAC3".equals(string) || "A_TRUEHD".equals(string) || "A_DTS".equals(string) || "A_DTS/EXPRESS".equals(string) || "A_DTS/LOSSLESS".equals(string) || "A_FLAC".equals(string) || "A_MS/ACM".equals(string) || "A_PCM/INT/LIT".equals(string) || "S_TEXT/UTF8".equals(string) || "S_VOBSUB".equals(string) || "S_HDMV/PGS".equals(string)) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static int[] a(int[] arrn, int n2) {
        if (arrn == null) {
            return new int[n2];
        }
        int[] arrn2 = arrn;
        if (arrn.length >= n2) return arrn2;
        return new int[Math.max(arrn.length * 2, n2)];
    }

    static /* synthetic */ UUID b() {
        return H;
    }

    public static boolean b(int n2) {
        if (n2 == 357149030 || n2 == 524531317 || n2 == 475249515 || n2 == 374648427) {
            return true;
        }
        return false;
    }

    private void c() {
        this.P = 0;
        this.S = 0;
        this.R = 0;
        this.Q = false;
        com.d.a.a.d.b b2 = this.M;
        b2.b = 0;
        b2.c = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int a(m m2, k k2) {
        this.T = false;
        boolean bl2 = true;
        while (bl2) {
            if (this.T) return 0;
            bl2 = this.I.a(m2);
            if (!bl2) continue;
            long l2 = m2.d;
            if (this.o) {
                this.O = l2;
                k2.a = this.p;
                this.o = false;
                return 1;
            }
            if (this.l && this.O != -1) {
                k2.a = this.O;
                this.O = -1;
                return 1;
            }
            boolean bl3 = false;
            if (!bl3) continue;
            return 1;
        }
        if (bl2) {
            return 0;
        }
        return -1;
    }

    final long a(long l2) {
        if (this.g == -1) {
            throw new bb("Can't scale timecode prior to timecodeScale being set.");
        }
        return ah.a(l2, this.g, 1000);
    }

    /*
     * Enabled aggressive block sorting
     */
    final void a(com.d.a.a.f.g.h h2, long l2) {
        if ("S_TEXT/UTF8".equals(h2.a)) {
            byte[] arrby;
            byte[] arrby2 = this.N.a;
            long l3 = this.w;
            if (l3 == -1) {
                arrby = G;
            } else {
                int n2 = (int)(l3 / 3600000000L);
                int n3 = (int)((l3 -= (long)n2 * 3600000000L) / 60000000);
                int n4 = (int)((l3 -= (long)(60000000 * n3)) / 1000000);
                int n5 = (int)((l3 - (long)(1000000 * n4)) / 1000);
                arrby = String.format(Locale.US, "%02d:%02d:%02d,%03d", n2, n3, n4, n5).getBytes();
            }
            System.arraycopy(arrby, 0, arrby2, 19, 12);
            h2.t.a(this.N, this.N.c);
            this.S += this.N.c;
        }
        h2.t.a(l2, this.C, this.S, 0, h2.g);
        this.T = true;
        this.c();
    }

    @Override
    public final void a(g g2) {
        this.E = g2;
    }

    /*
     * Enabled aggressive block sorting
     */
    final void a(m m2, int n2) {
        if (this.c.c >= n2) {
            return;
        }
        com.d.a.a.d.b b2 = this.c;
        int n3 = b2.a == null ? 0 : b2.a.length;
        if (n3 < n2) {
            b2 = this.c;
            byte[] arrby = Arrays.copyOf(this.c.a, Math.max(this.c.a.length * 2, n2));
            n3 = this.c.c;
            b2.a = arrby;
            b2.c = n3;
            b2.b = 0;
        }
        m2.b(this.c.a, this.c.c, n2 - this.c.c);
        this.c.a(n2);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final void a(m m2, com.d.a.a.f.g.h object, int n2) {
        int n3;
        byte[] arrby;
        Object object2;
        if ("S_TEXT/UTF8".equals(object.a)) {
            int n4 = F.length + n2;
            object = this.N;
            int n5 = object.a == null ? 0 : object.a.length;
            if (n5 < n4) {
                this.N.a = Arrays.copyOf(F, n4 + n2);
            }
            m2.b(this.N.a, F.length, n2);
            this.N.b(0);
            this.N.a(n4);
            return;
        }
        com.d.a.a.f.b b2 = object.t;
        if (!this.Q) {
            if (object.e) {
                this.C &= -3;
                m2.b(this.c.a, 0, 1);
                ++this.P;
                if ((this.c.a[0] & 128) == 128) {
                    throw new bb("Extension bit is set in signal byte");
                }
                if ((this.c.a[0] & 1) == 1) {
                    this.c.a[0] = 8;
                    this.c.b(0);
                    b2.a(this.c, 1);
                    ++this.S;
                    this.C |= 2;
                }
            } else if (object.f != null) {
                arrby = this.M;
                object2 = object.f;
                n3 = object.f.length;
                arrby.a = object2;
                arrby.c = n3;
                arrby.b = 0;
            }
            this.Q = true;
        }
        n2 = this.M.c + n2;
        if (!"V_MPEG4/ISO/AVC".equals(object.a) && !"V_MPEGH/ISO/HEVC".equals(object.a)) {
            while (this.P < n2) {
                this.a(m2, b2, n2 - this.P);
            }
        } else {
            arrby = this.K.a;
            arrby[0] = 0;
            arrby[1] = 0;
            arrby[2] = 0;
            n3 = object.u;
            int n6 = 4 - object.u;
            while (this.P < n2) {
                if (this.R == 0) {
                    object2 = this.M;
                    int n7 = Math.min(n3, object2.c - object2.b);
                    m2.b(arrby, n6 + n7, n3 - n7);
                    if (n7 > 0) {
                        this.M.a(arrby, n6, n7);
                    }
                    this.P += n3;
                    this.K.b(0);
                    this.R = this.K.k();
                    this.J.b(0);
                    b2.a(this.J, 4);
                    this.S += 4;
                    continue;
                }
                this.R -= this.a(m2, b2, this.R);
            }
        }
        if (!"A_VORBIS".equals(object.a)) return;
        this.L.b(0);
        b2.a(this.L, 4);
        this.S += 4;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final boolean a(m var1_1) {
        var10_2 = new f();
        var6_3 = var1_1.d();
        var4_4 = var6_3 == -1 || var6_3 > 1024 ? 1024 : var6_3;
        var2_5 = (int)var4_4;
        var1_1.c(var10_2.a.a, 0, 4);
        var4_4 = var10_2.a.e();
        var10_2.b = 4;
        while (var4_4 != 440786851) {
            var10_2.b = var3_6 = var10_2.b + 1;
            if (var3_6 == var2_5) return false;
            var1_1.c(var10_2.a.a, 0, 1);
            var4_4 = var4_4 << 8 & -256 | (long)(var10_2.a.a[0] & 255);
        }
        var4_4 = var10_2.a(var1_1);
        var8_7 = var10_2.b;
        if (var4_4 == Long.MIN_VALUE) return false;
        if (var6_3 == -1 || var8_7 + var4_4 < var6_3) ** GOTO lbl22
        return false;
lbl-1000: // 1 sources:
        {
            if (var6_3 != 0) {
                var1_1.c((int)var6_3);
                var10_2.b = (int)(var6_3 + (long)var10_2.b);
            }
lbl22: // 4 sources:
            if ((long)var10_2.b >= var8_7 + var4_4) {
                if ((long)var10_2.b != var4_4 + var8_7) return false;
                return true;
            }
            if (var10_2.a(var1_1) == Long.MIN_VALUE) return false;
            var6_3 = var10_2.a(var1_1);
            if (var6_3 < 0) return false;
            ** while (var6_3 <= Integer.MAX_VALUE)
        }
lbl29: // 1 sources:
        return false;
    }

    @Override
    public final void c_() {
        this.q = -1;
        this.u = 0;
        Object object = this.I;
        object.e = 0;
        object.b.clear();
        object = object.c;
        object.a = 0;
        object.b = 0;
        object = this.a;
        object.a = 0;
        object.b = 0;
        this.c();
    }
}

