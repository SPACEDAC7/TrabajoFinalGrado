/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.f.g;
import com.d.a.a.f.k;
import com.d.a.a.f.m;

public interface h {
    public int a(m var1, k var2);

    public void a(g var1);

    public boolean a(m var1);

    public void c_();
}

