/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.f.j;

final class i
implements j {
    i() {
    }

    @Override
    public final long a(long l2) {
        return 0;
    }

    @Override
    public final boolean a() {
        return false;
    }
}

