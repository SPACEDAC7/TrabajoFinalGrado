/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.f.i;

public interface j {
    public static final j a = new i();

    public long a(long var1);

    public boolean a();
}

