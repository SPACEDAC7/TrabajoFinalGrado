/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

public final class k {
    public long a;
}

