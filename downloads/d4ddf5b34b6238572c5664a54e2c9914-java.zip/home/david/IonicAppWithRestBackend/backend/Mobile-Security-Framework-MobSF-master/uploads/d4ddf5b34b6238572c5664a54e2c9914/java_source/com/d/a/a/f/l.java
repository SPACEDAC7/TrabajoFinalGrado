/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.d.ah;
import com.d.a.a.f.j;

public final class l
implements j {
    public final int b;
    public final int[] c;
    public final long[] d;
    public final long[] e;
    public final long[] f;

    public l(int[] arrn, long[] arrl, long[] arrl2, long[] arrl3) {
        this.b = arrn.length;
        this.c = arrn;
        this.d = arrl;
        this.e = arrl2;
        this.f = arrl3;
    }

    @Override
    public final long a(long l2) {
        return this.d[ah.a(this.f, l2, true)];
    }

    @Override
    public final boolean a() {
        return true;
    }
}

