/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.a.h;
import java.io.EOFException;
import java.util.Arrays;

public final class m {
    public static final byte[] a = new byte[4096];
    private final h b;
    public final long c;
    public long d;
    private byte[] e;
    private int f;
    public int g;

    public m(h h2, long l2, long l3) {
        this.b = h2;
        this.d = l2;
        this.c = l3;
        this.e = new byte[8192];
    }

    public static int a(m m2, byte[] arrby, int n2, int n3, int n4, boolean bl2) {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        if ((n2 = m2.b.a(arrby, n2 + n4, n3 - n4)) == -1) {
            if (n4 == 0 && bl2) {
                return -1;
            }
            throw new EOFException();
        }
        return n4 + n2;
    }

    private boolean a(int n2, boolean bl2) {
        int n3 = this.f + n2;
        if (n3 > this.e.length) {
            this.e = Arrays.copyOf(this.e, Math.max(this.e.length * 2, n3));
        }
        n3 = Math.min(this.g - this.f, n2);
        this.g += n2 - n3;
        while (n3 < n2) {
            int n4;
            n3 = n4 = m.a(this, this.e, this.f, n2, n3, bl2);
            if (n4 != -1) continue;
            return false;
        }
        this.f += n2;
        return true;
    }

    private int d(byte[] arrby, int n2, int n3) {
        if (this.g == 0) {
            return 0;
        }
        n3 = Math.min(this.g, n3);
        System.arraycopy(this.e, 0, arrby, n2, n3);
        m.d(this, n3);
        return n3;
    }

    public static void d(m m2, int n2) {
        m2.g -= n2;
        m2.f = 0;
        System.arraycopy(m2.e, n2, m2.e, 0, m2.g);
    }

    public static void e(m m2, int n2) {
        if (n2 != -1) {
            m2.d += (long)n2;
        }
    }

    public final int a(byte[] arrby, int n2, int n3) {
        int n4;
        int n5 = n4 = this.d(arrby, n2, n3);
        if (n4 == 0) {
            n5 = m.a(this, arrby, n2, n3, 0, true);
        }
        m.e(this, n5);
        return n5;
    }

    public final void a() {
        this.f = 0;
    }

    public final boolean a(byte[] arrby, int n2, int n3, boolean bl2) {
        int n4 = this.d(arrby, n2, n3);
        while (n4 < n3 && n4 != -1) {
            n4 = m.a(this, arrby, n2, n3, n4, bl2);
        }
        m.e(this, n4);
        if (n4 != -1) {
            return true;
        }
        return false;
    }

    public final long b() {
        return this.d + (long)this.f;
    }

    public final void b(int n2) {
        int n3 = Math.min(this.g, n2);
        m.d(this, n3);
        while (n3 < n2 && n3 != -1) {
            n3 = m.a(this, a, - n3, Math.min(n2, a.length + n3), n3, false);
        }
        m.e(this, n3);
    }

    public final void b(byte[] arrby, int n2, int n3) {
        this.a(arrby, n2, n3, false);
    }

    public final boolean b(byte[] arrby, int n2, int n3, boolean bl2) {
        if (!this.a(n3, bl2)) {
            return false;
        }
        System.arraycopy(this.e, this.f - n3, arrby, n2, n3);
        return true;
    }

    public final long c() {
        return this.d;
    }

    public final void c(int n2) {
        this.a(n2, false);
    }

    public final void c(byte[] arrby, int n2, int n3) {
        this.b(arrby, n2, n3, false);
    }

    public final long d() {
        return this.c;
    }
}

