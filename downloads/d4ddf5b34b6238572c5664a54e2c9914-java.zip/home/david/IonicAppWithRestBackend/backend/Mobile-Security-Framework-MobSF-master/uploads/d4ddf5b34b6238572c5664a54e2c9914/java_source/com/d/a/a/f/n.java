/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.f.b;
import com.d.a.a.f.m;
import com.d.a.a.q;

public final class n
implements b {
    @Override
    public final int a(m m2, int n2, boolean bl2) {
        int n3 = Math.min(m2.g, n2);
        m.d(m2, n3);
        int n4 = n3;
        if (n3 == 0) {
            n4 = m.a(m2, m.a, 0, Math.min(n2, m.a.length), 0, true);
        }
        m.e(m2, n4);
        return n4;
    }

    @Override
    public final void a(long l2, int n2, int n3, int n4, byte[] arrby) {
    }

    @Override
    public final void a(com.d.a.a.d.b b2, int n2) {
        b2.b(b2.b + n2);
    }

    @Override
    public final void a(q q2) {
    }
}

