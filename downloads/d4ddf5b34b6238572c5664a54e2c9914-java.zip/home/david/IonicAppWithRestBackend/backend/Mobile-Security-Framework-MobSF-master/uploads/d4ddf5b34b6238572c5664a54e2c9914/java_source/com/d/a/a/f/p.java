/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.bb;
import com.d.a.a.f.h;

public final class p
extends bb {
    public p(h[] arrh) {
        StringBuilder stringBuilder = new StringBuilder("None of the available extractors (");
        StringBuilder stringBuilder2 = new StringBuilder();
        for (int i2 = 0; i2 < arrh.length; ++i2) {
            stringBuilder2.append(arrh[i2].getClass().getSimpleName());
            if (i2 >= arrh.length - 1) continue;
            stringBuilder2.append(", ");
        }
        super(stringBuilder.append(stringBuilder2.toString()).append(") could read the stream.").toString());
    }
}

