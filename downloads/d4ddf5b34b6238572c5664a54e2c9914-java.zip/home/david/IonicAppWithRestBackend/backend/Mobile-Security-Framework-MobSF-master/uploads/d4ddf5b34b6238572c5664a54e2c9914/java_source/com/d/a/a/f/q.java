/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.f.o;
import com.d.a.a.f.u;
import java.io.IOException;

final class q
implements Runnable {
    final /* synthetic */ IOException a;
    final /* synthetic */ u b;

    q(u u2, IOException iOException) {
        this.b = u2;
        this.a = iOException;
    }

    @Override
    public final void run() {
        o o2 = this.b.j;
        int n2 = this.b.k;
    }
}

