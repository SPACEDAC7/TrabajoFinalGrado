/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.a.aa;
import com.d.a.a.f.a;
import com.d.a.a.f.u;

final class r
extends a {
    final /* synthetic */ u g;

    public r(u u2, aa aa2) {
        this.g = u2;
        super(aa2);
    }

    @Override
    public final void a(long l2, int n2, int n3, int n4, byte[] object) {
        super.a(l2, n2, n3, n4, (byte[])object);
        object = this.g;
        ++object.I;
    }
}

