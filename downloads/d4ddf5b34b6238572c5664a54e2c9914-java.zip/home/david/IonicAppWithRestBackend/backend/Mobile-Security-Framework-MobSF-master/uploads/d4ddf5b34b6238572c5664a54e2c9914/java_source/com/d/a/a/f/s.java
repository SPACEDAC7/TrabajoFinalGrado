/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.d.a.a.f;

import android.net.Uri;
import com.d.a.a.a.aa;
import com.d.a.a.a.d;
import com.d.a.a.a.i;
import com.d.a.a.f.h;
import com.d.a.a.f.k;
import com.d.a.a.f.m;
import com.d.a.a.f.t;

final class s
implements d {
    private final Uri a;
    private final com.d.a.a.a.h b;
    private final t c;
    private final aa d;
    private final int e;
    private final k f;
    private volatile boolean g;
    private boolean h;

    public s(Uri uri, com.d.a.a.a.h h2, t t2, aa aa2, int n2, long l2) {
        if (uri == null) {
            throw new NullPointerException();
        }
        this.a = uri;
        if (h2 == null) {
            throw new NullPointerException();
        }
        this.b = h2;
        if (t2 == null) {
            throw new NullPointerException();
        }
        this.c = t2;
        if (aa2 == null) {
            throw new NullPointerException();
        }
        this.d = aa2;
        this.e = n2;
        this.f = new k();
        this.f.a = l2;
        this.h = true;
    }

    @Override
    public final void g() {
        this.g = true;
    }

    @Override
    public final boolean h() {
        return this.g;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void i() {
        var1_1 = 0;
        block6 : while (var1_1 == 0 && !this.g) {
            block13 : {
                var7_5 = this.f.a;
                var3_3 = var5_4 = this.b.a(new i(this.a, var7_5, -1, null));
                if (var5_4 != -1) {
                    var3_3 = var5_4 + var7_5;
                }
                var9_6 = new m(this.b, var7_5, var3_3);
                var10_8 = this.c.a((m)var9_6);
                if (!this.h) break block13;
                var10_8.c_();
                this.h = false;
            }
            while (var1_1 == 0) {
                if (this.g) break;
                this.d.b(this.e);
                var1_1 = var2_2 = var10_8.a((m)var9_6, this.f);
                continue;
            }
            if (var1_1 == 1) {
                var1_1 = 0;
lbl23: // 2 sources:
                do {
                    this.b.a();
                    continue block6;
                    break;
                } while (true);
            }
            this.f.a = var9_6.c();
            ** continue;
            catch (Throwable var9_7) {
                var10_8 = null;
lbl30: // 3 sources:
                do {
                    if (var1_1 != 1 && var10_8 != null) {
                        this.f.a = var10_8.c();
                    }
                    this.b.a();
                    throw var9_6;
                    break;
                } while (true);
            }
        }
        return;
        catch (Throwable var10_9) {
            var11_10 = var9_6;
            var9_6 = var10_9;
            var10_8 = var11_10;
            ** GOTO lbl30
        }
        catch (Throwable var11_11) {
            var10_8 = var9_6;
            var9_6 = var11_11;
            ** continue;
        }
    }
}

