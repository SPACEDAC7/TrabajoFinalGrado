/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import com.d.a.a.f.g;
import com.d.a.a.f.h;
import com.d.a.a.f.m;
import com.d.a.a.f.p;
import java.io.EOFException;

final class t {
    h a;
    private final h[] b;
    private final g c;

    public t(h[] arrh, g g2) {
        this.b = arrh;
        this.c = g2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final h a(m m2) {
        if (this.a != null) {
            return this.a;
        }
        for (h h2 : this.b) {
            try {
                if (!h2.a(m2)) continue;
                this.a = h2;
                break;
            }
            catch (EOFException var5_7) {}
            continue;
            finally {
                m2.a();
            }
        }
        if (this.a == null) {
            throw new p(this.b);
        }
        this.a.a(this.c);
        return this.a;
    }
}

