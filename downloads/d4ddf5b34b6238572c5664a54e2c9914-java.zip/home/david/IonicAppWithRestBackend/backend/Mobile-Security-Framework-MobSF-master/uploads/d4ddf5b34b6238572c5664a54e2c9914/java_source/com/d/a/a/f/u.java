/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.util.SparseArray
 */
package com.d.a.a.f;

import android.net.Uri;
import android.os.Handler;
import android.os.SystemClock;
import android.util.SparseArray;
import com.d.a.a.a.aa;
import com.d.a.a.f.a;
import com.d.a.a.f.b;
import com.d.a.a.f.c;
import com.d.a.a.f.d;
import com.d.a.a.f.e;
import com.d.a.a.f.g;
import com.d.a.a.f.h;
import com.d.a.a.f.j;
import com.d.a.a.f.o;
import com.d.a.a.f.p;
import com.d.a.a.f.r;
import com.d.a.a.f.s;
import com.d.a.a.f.t;
import com.d.a.a.q;
import com.d.a.a.w;
import com.d.a.a.x;
import com.d.a.a.y;
import com.d.a.a.z;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class u
implements com.d.a.a.a.e,
g,
w,
x {
    private static final List<Class<? extends h>> a;
    private long A;
    private long B;
    private com.d.a.a.a.g C;
    private s D;
    private IOException E;
    private int F;
    private long G;
    private boolean H;
    public int I;
    private int J;
    private final t b;
    private final aa c;
    private final int d;
    private final SparseArray<r> e;
    private final int f;
    private final Uri g;
    private final com.d.a.a.a.h h;
    private final Handler i;
    public final o j;
    public final int k;
    private volatile boolean l;
    private volatile j m;
    private volatile com.d.a.a.b.d n;
    private boolean o;
    private int p;
    private q[] q;
    private long r;
    private boolean[] s;
    private boolean[] t;
    private boolean[] u;
    private int v;
    private long w;
    private long x;
    private long y;
    private boolean z;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        a = new ArrayList<Class<? extends h>>();
        try {
            a.add(Class.forName("com.d.a.a.f.g.i").asSubclass(h.class));
        }
        catch (ClassNotFoundException var0_10) {}
        try {
            a.add(Class.forName("com.d.a.a.f.c.m").asSubclass(h.class));
        }
        catch (ClassNotFoundException var0_9) {}
        try {
            a.add(Class.forName("com.d.a.a.f.c.p").asSubclass(h.class));
        }
        catch (ClassNotFoundException var0_8) {}
        try {
            a.add(Class.forName("com.d.a.a.f.b.c").asSubclass(h.class));
        }
        catch (ClassNotFoundException var0_7) {}
        try {
            a.add(Class.forName("com.d.a.a.f.d.d").asSubclass(h.class));
        }
        catch (ClassNotFoundException var0_6) {}
        try {
            a.add(Class.forName("com.d.a.a.f.d.x").asSubclass(h.class));
        }
        catch (ClassNotFoundException var0_5) {}
        try {
            a.add(Class.forName("com.d.a.a.f.a.d").asSubclass(h.class));
        }
        catch (ClassNotFoundException var0_4) {}
        try {
            a.add(Class.forName("com.d.a.a.f.e.l").asSubclass(h.class));
        }
        catch (ClassNotFoundException var0_3) {}
        try {
            a.add(Class.forName("com.d.a.a.f.d.r").asSubclass(h.class));
        }
        catch (ClassNotFoundException var0_2) {}
        try {
            a.add(Class.forName("com.d.a.a.f.f.a").asSubclass(h.class));
        }
        catch (ClassNotFoundException var0_1) {}
        try {
            a.add(Class.forName("com.google.android.exoplayer.ext.flac.FlacExtractor").asSubclass(h.class));
            return;
        }
        catch (ClassNotFoundException var0) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private /* varargs */ u(Uri var1_1, com.d.a.a.a.h var2_4, aa var3_5, int var4_6, int var5_7, h ... var6_8) {
        super();
        this.g = var1_1;
        this.h = var2_4;
        this.j = null;
        this.i = null;
        this.k = 0;
        this.c = var3_5;
        this.d = var4_6;
        this.f = -1;
        if (var6_8 == null) ** GOTO lbl-1000
        var1_1 = var6_8;
        if (var6_8.length == 0) lbl-1000: // 2 sources:
        {
            var2_4 = new h[u.a.size()];
            var4_6 = 0;
            do {
                var1_1 = var2_4;
                if (var4_6 >= var2_4.length) break;
                try {
                    var2_4[var4_6] = u.a.get(var4_6).newInstance();
                    ++var4_6;
                    continue;
                }
                catch (InstantiationException var1_2) {
                    throw new IllegalStateException("Unexpected error creating default extractor", var1_2);
                }
                catch (IllegalAccessException var1_3) {
                    throw new IllegalStateException("Unexpected error creating default extractor", var1_3);
                }
            } while (true);
        }
        this.b = new t(var1_1, this);
        this.e = new SparseArray();
        this.y = Long.MIN_VALUE;
    }

    private /* varargs */ u(Uri uri, com.d.a.a.a.h h2, aa aa2, int n2, h ... arrh) {
        this(uri, h2, aa2, 2097152, -1, arrh);
    }

    public /* varargs */ u(Uri uri, com.d.a.a.a.h h2, aa aa2, h ... arrh) {
        this(uri, h2, aa2, 2097152, arrh);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void b(long l2) {
        this.y = l2;
        if (!this.C.b) {
            if (this.y == Long.MIN_VALUE) return;
            boolean bl2 = true;
            if (!bl2) {
                return;
            }
        }
        this.H = false;
        if (this.C.b) {
            this.C.a();
            return;
        }
        this.i();
        this.g();
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void g() {
        int n2 = 0;
        if (this.H) return;
        if (this.C.b) {
            return;
        }
        if (this.E != null) {
            if (this.E instanceof p) return;
            n2 = this.D != null ? 1 : 0;
            if (n2 == 0) {
                throw new IllegalStateException();
            }
            if (SystemClock.elapsedRealtime() - this.G < Math.min(((long)this.F - 1) * 1000, 5000)) return;
            this.E = null;
            if (!this.o) {
                for (n2 = 0; n2 < this.e.size(); ++n2) {
                    ((r)this.e.valueAt(n2)).a();
                }
                this.D = this.h();
            } else if (!this.m.a() && this.r == -1) {
                for (n2 = 0; n2 < this.e.size(); ++n2) {
                    ((r)this.e.valueAt(n2)).a();
                }
                this.D = this.h();
                this.A = this.w;
                this.z = true;
            }
            this.J = this.I;
            this.C.a(this.D, this);
            return;
        }
        this.B = 0;
        this.z = false;
        if (!this.o) {
            this.D = this.h();
        } else {
            if (this.y != Long.MIN_VALUE) {
                n2 = 1;
            }
            if (n2 == 0) {
                throw new IllegalStateException();
            }
            if (this.r != -1 && this.y >= this.r) {
                this.H = true;
                this.y = Long.MIN_VALUE;
                return;
            }
            long l2 = this.y;
            this.D = new s(this.g, this.h, this.b, this.c, this.d, this.m.a(l2));
            this.y = Long.MIN_VALUE;
        }
        this.J = this.I;
        this.C.a(this.D, this);
    }

    private s h() {
        return new s(this.g, this.h, this.b, this.c, this.d, 0);
    }

    private void i() {
        for (int i2 = 0; i2 < this.e.size(); ++i2) {
            ((r)this.e.valueAt(i2)).a();
        }
        this.D = null;
        this.E = null;
        this.F = 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final int a(int n2, long l2, y y2, z z2) {
        this.w = l2;
        if (this.t[n2]) return -2;
        if (this.y != Long.MIN_VALUE) {
            return -2;
        }
        int n3 = 0;
        if (n3 != 0) {
            return -2;
        }
        r r2 = (r)this.e.valueAt(n2);
        if (this.s[n2]) {
            y2.a = r2.f;
            y2.b = this.n;
            this.s[n2] = false;
            return -4;
        }
        if (!r2.a(z2)) {
            if (!this.H) return -2;
            return -1;
        }
        n2 = z2.e < this.x ? 1 : 0;
        n3 = z2.d;
        n2 = n2 != 0 ? 134217728 : 0;
        z2.d = n2 | n3;
        if (this.z) {
            this.B = this.A - z2.e;
            this.z = false;
        }
        z2.e += this.B;
        return -3;
    }

    @Override
    public final q a(int n2) {
        if (!this.o) {
            throw new IllegalStateException();
        }
        return this.q[n2];
    }

    @Override
    public final void a() {
        this.l = true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(int n2, long l2) {
        if (!this.o) {
            throw new IllegalStateException();
        }
        boolean bl2 = !this.u[n2];
        if (!bl2) {
            throw new IllegalStateException();
        }
        ++this.p;
        this.u[n2] = true;
        this.s[n2] = true;
        this.t[n2] = false;
        if (this.p == 1) {
            if (!this.m.a()) {
                l2 = 0;
            }
            this.w = l2;
            this.x = l2;
            this.b(l2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(long l2) {
        int n2 = 0;
        if (!this.o) {
            throw new IllegalStateException();
        }
        boolean bl2 = this.p > 0;
        if (!bl2) {
            throw new IllegalStateException();
        }
        if (!this.m.a()) {
            l2 = 0;
        }
        bl2 = this.y != Long.MIN_VALUE;
        long l3 = bl2 ? this.y : this.w;
        this.w = l2;
        this.x = l2;
        if (l3 != l2) {
            int n3;
            bl2 = this.y != Long.MIN_VALUE;
            bl2 = !bl2;
            for (n3 = 0; bl2 && n3 < this.e.size(); bl2 &= ((r)this.e.valueAt((int)n3)).a((long)l2), ++n3) {
            }
            n3 = n2;
            if (!bl2) {
                this.b(l2);
                n3 = n2;
            }
            while (n3 < this.t.length) {
                this.t[n3] = true;
                ++n3;
            }
        }
    }

    @Override
    public final void a(com.d.a.a.a.d d2) {
        this.H = true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(com.d.a.a.a.d d2, IOException iOException) {
        this.E = iOException;
        int n2 = this.I > this.J ? 1 : this.F + 1;
        this.F = n2;
        this.G = SystemClock.elapsedRealtime();
        if (this.i != null && this.j != null) {
            this.i.post((Runnable)new com.d.a.a.f.q(this, iOException));
        }
        this.g();
    }

    @Override
    public final void a(com.d.a.a.b.d d2) {
        this.n = d2;
    }

    @Override
    public final void a(j j2) {
        this.m = j2;
    }

    @Override
    public final b a_(int n2) {
        r r2;
        r r3 = r2 = (r)this.e.get(n2);
        if (r2 == null) {
            r3 = new r(this, this.c);
            this.e.put(n2, (Object)r3);
        }
        return r3;
    }

    @Override
    public final long b(int n2) {
        if (this.t[n2]) {
            this.t[n2] = false;
            return this.x;
        }
        return Long.MIN_VALUE;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean b() {
        int n2;
        boolean bl2;
        boolean bl3;
        int n3;
        int n4;
        block6 : {
            n4 = 0;
            bl2 = false;
            if (this.o) {
                return true;
            }
            if (this.C == null) {
                this.C = new com.d.a.a.a.g("Loader:ExtractorSampleSource");
            }
            this.g();
            bl3 = bl2;
            if (this.m == null) return bl3;
            bl3 = bl2;
            if (!this.l) return bl3;
            for (n3 = 0; n3 < this.e.size(); ++n3) {
                n2 = ((r)this.e.valueAt((int)n3)).f != null ? 1 : 0;
                if (n2 != 0) continue;
                n3 = 0;
                break block6;
            }
            n3 = 1;
        }
        bl3 = bl2;
        if (n3 == 0) return bl3;
        n2 = this.e.size();
        this.u = new boolean[n2];
        this.t = new boolean[n2];
        this.s = new boolean[n2];
        this.q = new q[n2];
        this.r = -1;
        n3 = n4;
        do {
            q q2;
            if (n3 >= n2) {
                this.o = true;
                return true;
            }
            this.q[n3] = q2 = ((r)this.e.valueAt((int)n3)).f;
            if (q2.e != -1 && q2.e > this.r) {
                this.r = q2.e;
            }
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean b(int n2, long l2) {
        int n3;
        boolean bl2 = false;
        if (!this.o) {
            throw new IllegalStateException();
        }
        if (!this.u[n2]) {
            throw new IllegalStateException();
        }
        l2 = this.w = l2;
        for (n3 = 0; n3 < this.u.length; ++n3) {
            if (this.u[n3]) continue;
            r r2 = (r)this.e.valueAt(n3);
            do {
                e e2 = r2.a;
                z z2 = r2.b;
                if (!e2.c.a(z2, e2.e) || r2.b.e >= l2) break;
                r2.a.a();
                r2.c = true;
            } while (true);
            r2.d = Long.MIN_VALUE;
        }
        if (this.H) {
            return true;
        }
        this.g();
        n3 = this.y != Long.MIN_VALUE ? 1 : 0;
        boolean bl3 = bl2;
        if (n3 != 0) return bl3;
        bl3 = bl2;
        if (((r)this.e.valueAt(n2)).b()) return bl3;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void b_() {
        if (this.E == null) {
            return;
        }
        if (this.E instanceof p) {
            throw this.E;
        }
        int n2 = this.f != -1 ? this.f : (this.m != null && !this.m.a() ? 6 : 3);
        if (this.F <= n2) return;
        throw this.E;
    }

    @Override
    public final int c() {
        return this.e.size();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void c(int n2) {
        if (!this.o) {
            throw new IllegalStateException();
        }
        if (!this.u[n2]) {
            throw new IllegalStateException();
        }
        --this.p;
        this.u[n2] = false;
        if (this.p != 0) return;
        this.w = Long.MIN_VALUE;
        if (this.C.b) {
            this.C.a();
            return;
        }
        this.i();
        this.c.a(0);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long d() {
        if (this.H) {
            return -3;
        }
        if (this.y != Long.MIN_VALUE) {
            return this.y;
        }
        int n2 = 0;
        if (n2 != 0) {
            return this.y;
        }
        n2 = 0;
        long l2 = Long.MIN_VALUE;
        while (n2 < this.e.size()) {
            l2 = Math.max(l2, ((r)this.e.valueAt((int)n2)).e);
            ++n2;
        }
        return this.w;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void e() {
        int n2 = this.v > 0 ? 1 : 0;
        if (n2 == 0) {
            throw new IllegalStateException();
        }
        this.v = n2 = this.v - 1;
        if (n2 == 0) {
            if (this.C != null) {
                this.C.b();
                this.C = null;
            }
            if (this.b.a != null) {
                this.b.a = null;
            }
        }
    }

    @Override
    public final w f() {
        ++this.v;
        return this;
    }

    @Override
    public final void j() {
        if (this.p > 0) {
            this.b(this.y);
            return;
        }
        this.i();
        this.c.a(0);
    }
}

