/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.f;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class v {
    private static final Pattern c = Pattern.compile("^ [0-9a-fA-F]{8} ([0-9a-fA-F]{8}) ([0-9a-fA-F]{8})");
    public final int a;
    public final int b;

    public v(int n2, int n3) {
        this.a = n2;
        this.b = n3;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static v a(String object, String string) {
        int n2;
        int n3;
        block4 : {
            if (!"iTunSMPB".equals(object)) {
                return null;
            }
            object = c.matcher(string);
            if (!object.find()) return null;
            try {
                n2 = Integer.parseInt(object.group(1), 16);
                n3 = Integer.parseInt(object.group(2), 16);
                if (n2 != 0) break block4;
                if (n3 == 0) return null;
            }
            catch (NumberFormatException var0_1) {
                return null;
            }
        }
        return new v(n2, n3);
    }
}

