/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.i;

final class g
implements Runnable {
    final /* synthetic */ boolean a;
    final /* synthetic */ i b;

    g(i i2, boolean bl2) {
        this.b = i2;
        this.a = bl2;
    }

    @Override
    public final void run() {
    }
}

