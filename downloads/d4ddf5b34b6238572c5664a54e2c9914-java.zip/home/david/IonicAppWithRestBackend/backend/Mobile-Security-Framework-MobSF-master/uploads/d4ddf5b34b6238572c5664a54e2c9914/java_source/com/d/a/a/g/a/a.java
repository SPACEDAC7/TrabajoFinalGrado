/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.g.a.m;
import com.d.a.a.g.a.n;
import java.util.List;

public final class a {
    public final long a;
    public final long b;
    public final long c;
    public final long d;
    public final boolean e;
    public final long f;
    public final long g;
    public final m h;
    public final String i;
    public final long j;
    public final List<n> k;

    public a(long l2, long l3, long l4, long l5, boolean bl2, long l6, long l7, m m2, String string, long l8, List<n> list) {
        this.a = l2;
        this.b = l3;
        this.c = l4;
        this.d = l5;
        this.e = bl2;
        this.f = l6;
        this.g = l7;
        this.h = m2;
        this.i = string;
        this.j = l8;
        this.k = list;
    }

    public final long a(int n2) {
        if (n2 == this.k.size() - 1) {
            if (this.c == -1) {
                return -1;
            }
            return this.c - this.k.get((int)n2).b;
        }
        return this.k.get((int)(n2 + 1)).b - this.k.get((int)n2).b;
    }
}

