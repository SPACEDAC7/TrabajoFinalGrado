/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.g.a.g;
import com.d.a.a.g.a.k;

public final class b
extends g {
    public final String a;
    final long b;
    final long c;

    public b(k k2, long l2, long l3, String string, long l4, long l5) {
        super(k2, l2, l3);
        this.a = string;
        this.b = l4;
        this.c = l5;
    }

    public b(String string) {
        this(null, 1, 0, string, 0, -1);
    }
}

