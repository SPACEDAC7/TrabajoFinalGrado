/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.d.ah;
import com.d.a.a.g.a.f;
import com.d.a.a.g.a.g;
import com.d.a.a.g.a.j;
import com.d.a.a.g.a.k;
import java.util.List;

public abstract class c
extends g {
    public final int a;
    final long b;
    final List<f> c;

    public c(k k2, long l2, long l3, int n2, long l4, List<f> list) {
        super(k2, l2, l3);
        this.a = n2;
        this.b = l4;
        this.c = list;
    }

    public abstract int a(long var1);

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final long a(int n2) {
        long l2;
        if (this.c != null) {
            l2 = this.c.get((int)(n2 - this.a)).a - this.h;
            do {
                return ah.a(l2, 1000000, this.g);
                break;
            } while (true);
        }
        l2 = (long)(n2 - this.a) * this.b;
        return ah.a(l2, 1000000, this.g);
    }

    public abstract k a(j var1, int var2);

    public boolean a() {
        if (this.c != null) {
            return true;
        }
        return false;
    }

    public String b(int n2) {
        return null;
    }

    public String toString() {
        return null;
    }
}

