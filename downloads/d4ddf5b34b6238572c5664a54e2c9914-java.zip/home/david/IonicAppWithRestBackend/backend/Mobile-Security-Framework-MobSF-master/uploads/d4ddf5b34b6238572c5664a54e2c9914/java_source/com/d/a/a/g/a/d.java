/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.g.a.c;
import com.d.a.a.g.a.f;
import com.d.a.a.g.a.j;
import com.d.a.a.g.a.k;
import java.util.List;

public final class d
extends c {
    final List<k> d;

    public d(k k2, long l2, long l3, int n2, long l4, List<f> list, List<k> list2) {
        super(k2, l2, l3, n2, l4, list);
        this.d = list2;
    }

    @Override
    public final int a(long l2) {
        return this.a + this.d.size() - 1;
    }

    @Override
    public final k a(j j2, int n2) {
        return this.d.get(n2 - this.a);
    }

    @Override
    public final boolean a() {
        return true;
    }
}

