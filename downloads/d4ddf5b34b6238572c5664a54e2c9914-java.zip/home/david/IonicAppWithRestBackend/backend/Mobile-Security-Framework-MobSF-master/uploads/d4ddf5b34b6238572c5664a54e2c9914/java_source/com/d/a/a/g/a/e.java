/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.g.a.c;
import com.d.a.a.g.a.f;
import com.d.a.a.g.a.g;
import com.d.a.a.g.a.j;
import com.d.a.a.g.a.k;
import com.d.a.a.g.a.t;
import java.util.Iterator;
import java.util.List;

public final class e
extends c {
    final t d;
    final t e;
    private final String i;

    public e(k k2, long l2, long l3, int n2, long l4, List<f> list, t t2, t t3, String string) {
        super(k2, l2, l3, n2, l4, list);
        this.d = t2;
        this.e = t3;
        this.i = string;
    }

    @Override
    public final int a(long l2) {
        if (this.c != null) {
            return this.c.size() + this.a - 1;
        }
        if (l2 == -1) {
            return -1;
        }
        long l3 = this.b * 1000000 / this.g;
        int n2 = this.a;
        return (int)((l2 + l3 - 1) / l3) + n2 - 1;
    }

    @Override
    public final k a(j object) {
        if (this.d != null) {
            object = this.d.a(object.e.a, 0, object.e.c, 0);
            return new k(this.i, (String)object, 0, -1);
        }
        return super.a((j)object);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final k a(j object, int n2) {
        long l2 = this.c != null ? this.c.get((int)(n2 - this.a)).a : (long)(n2 - this.a) * this.b;
        object = this.e.a(object.e.a, n2, object.e.c, l2);
        return new k(this.i, (String)object, 0, -1);
    }

    @Override
    public final String b(int n2) {
        if (this.c == null) {
            return null;
        }
        return this.c.get((int)(n2 - this.a)).c;
    }

    @Override
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<SegmentTimeline>");
        if (this.c != null) {
            Iterator<f> iterator = this.c.iterator();
            while (iterator.hasNext()) {
                stringBuilder.append(iterator.next().toString());
            }
        }
        stringBuilder.append("</SegmentTimeline>");
        return stringBuilder.toString();
    }
}

