/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

public final class f {
    long a;
    long b;
    String c;

    public f(long l2, long l3, String string) {
        this.a = l2;
        this.b = l3;
        this.c = string;
    }

    public final String toString() {
        return String.format("<S t=\"%d\" d=\"%d\"/>", this.a, this.b);
    }
}

