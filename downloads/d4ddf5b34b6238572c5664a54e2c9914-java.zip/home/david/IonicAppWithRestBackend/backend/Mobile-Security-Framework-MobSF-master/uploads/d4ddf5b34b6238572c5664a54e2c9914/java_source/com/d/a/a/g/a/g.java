/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.g.a.j;
import com.d.a.a.g.a.k;

public abstract class g {
    final k f;
    final long g;
    final long h;

    public g(k k2, long l2, long l3) {
        this.f = k2;
        this.g = l2;
        this.h = l3;
    }

    public k a(j j2) {
        return this.f;
    }
}

