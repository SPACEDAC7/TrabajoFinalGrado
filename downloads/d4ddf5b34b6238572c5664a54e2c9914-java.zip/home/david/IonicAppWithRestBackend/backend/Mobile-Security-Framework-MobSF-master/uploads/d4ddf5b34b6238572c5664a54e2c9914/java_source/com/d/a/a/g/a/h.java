/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.d.a.a.g.a;

import android.net.Uri;
import com.d.a.a.e.c;
import com.d.a.a.g.a.b;
import com.d.a.a.g.a.g;
import com.d.a.a.g.a.j;
import com.d.a.a.g.a.k;
import com.d.a.a.g.a.q;
import com.d.a.a.g.m;

public final class h
extends j {
    public final Uri a;
    public final long b;
    private final k j;
    private final q k;

    /*
     * Enabled aggressive block sorting
     */
    public h(String object, long l2, c c2, b b2, String string, String string2) {
        super((String)object, -1, c2, b2, null, string2, 0);
        this.a = Uri.parse((String)b2.a);
        object = b2.c <= 0 ? null : new k(b2.a, null, b2.b, b2.c);
        this.j = object;
        this.b = -1;
        object = this.j != null ? null : new q(new k(b2.a, null, 0, -1));
        this.k = object;
    }

    @Override
    public final k a() {
        return this.j;
    }

    @Override
    public final m b() {
        return this.k;
    }
}

