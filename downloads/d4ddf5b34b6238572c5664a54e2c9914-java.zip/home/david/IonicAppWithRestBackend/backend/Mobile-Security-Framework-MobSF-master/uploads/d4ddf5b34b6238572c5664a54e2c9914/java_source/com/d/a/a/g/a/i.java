/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.g.a.c;
import com.d.a.a.g.a.f;
import com.d.a.a.g.a.g;
import com.d.a.a.g.a.j;
import com.d.a.a.g.a.k;
import com.d.a.a.g.m;
import java.util.List;

public final class i
extends j
implements m {
    public final c a;

    public i(String string, long l2, com.d.a.a.e.c c2, c c3, String string2, String string3) {
        super(string, -1, c2, c3, null, string3, 0);
        this.a = c3;
    }

    @Override
    public final int a(long l2) {
        return this.a.a(l2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final int a(long l2, long l3) {
        int n2;
        c c2 = this.a;
        int n3 = c2.a;
        int n4 = c2.a(l3);
        if (c2.c == null) {
            l3 = c2.b * 1000000 / c2.g;
            n2 = c2.a;
            int n5 = (int)(l2 / l3) + n2;
            if (n5 < n3) {
                return n3;
            }
            if (n4 == -1) return n5;
            n2 = n4;
            if (n5 > n4) return n2;
            return n5;
        }
        int n6 = n3;
        n2 = n4;
        n4 = n6;
        while (n4 <= n2) {
            n6 = (n4 + n2) / 2;
            l3 = c2.a(n6);
            if (l3 < l2) {
                n4 = n6 + 1;
                continue;
            }
            if (l3 <= l2) {
                return n6;
            }
            n2 = n6 - 1;
        }
        if (n4 != n3) return n2;
        return n4;
    }

    @Override
    public final long a(int n2, long l2) {
        c c2 = this.a;
        if (c2.c != null) {
            return c2.c.get((int)(n2 - c2.a)).b * 1000000 / c2.g;
        }
        if (n2 == c2.a(l2)) {
            return l2 - c2.a(n2);
        }
        return c2.b * 1000000 / c2.g;
    }

    @Override
    public final k a() {
        return null;
    }

    @Override
    public final k a(int n2) {
        return this.a.a(this, n2);
    }

    @Override
    public final m b() {
        return this;
    }

    @Override
    public final String b(int n2) {
        return this.a.b(n2);
    }

    @Override
    public final int c() {
        return this.a.a;
    }

    @Override
    public final long c(int n2) {
        return this.a.a(n2);
    }

    @Override
    public final boolean d() {
        return this.a.a();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("format:" + this.e.a + "\n");
        stringBuilder.append("segments:" + this.a.toString());
        return stringBuilder.toString();
    }
}

