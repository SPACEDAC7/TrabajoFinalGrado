/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.d.ah;
import com.d.a.a.e.c;
import com.d.a.a.g.a.g;
import com.d.a.a.g.a.k;
import com.d.a.a.g.m;

public abstract class j {
    public final String c;
    public final long d;
    public final c e;
    public final long f;
    public final String g;
    public final k h;
    public final String i;

    /*
     * Enabled aggressive block sorting
     */
    private j(String string, long l2, c c2, g g2, String string2, String string3) {
        this.c = string;
        this.d = l2;
        this.e = c2;
        if (string2 == null) {
            string2 = string + "." + c2.a + "." + l2;
        }
        this.g = string2;
        this.h = g2.a(this);
        this.f = ah.a(g2.h, 1000000, g2.g);
        this.i = string3;
    }

    /* synthetic */ j(String string, long l2, c c2, g g2, String string2, String string3, byte by2) {
        this(string, l2, c2, g2, string2, string3);
    }

    public abstract k a();

    public abstract m b();

    public final c e() {
        return this.e;
    }
}

