/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.d.a.a.g.a;

import android.net.Uri;
import com.d.a.a.d.af;

public final class k {
    public final long a;
    public final long b;
    public final String c;
    public final String d;
    private int e;

    /*
     * Enabled aggressive block sorting
     */
    public k(String string, String string2, long l2, long l3) {
        boolean bl2 = string != null || string2 != null;
        if (!bl2) {
            throw new IllegalArgumentException();
        }
        this.c = string;
        this.d = string2;
        this.a = l2;
        this.b = l3;
    }

    public final Uri a() {
        return Uri.parse((String)af.a(this.c, this.d));
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (k)object;
        if (this.a != object.a) return false;
        if (this.b != object.b) return false;
        if (af.a(this.c, this.d).equals(af.a(object.c, object.d))) return true;
        return false;
    }

    public final int hashCode() {
        if (this.e == 0) {
            this.e = (((int)this.a + 527) * 31 + (int)this.b) * 31 + af.a(this.c, this.d).hashCode();
        }
        return this.e;
    }
}

