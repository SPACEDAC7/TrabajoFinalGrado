/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.g.a.j;
import com.d.a.a.g.a.o;
import com.d.a.a.g.a.p;
import java.util.Collections;
import java.util.List;

public final class l {
    public final int a;
    public final int b;
    public final List<j> c;
    public final List<o> d;
    public final p e;

    /*
     * Enabled aggressive block sorting
     */
    public l(int n2, int n3, List<j> list, List<o> list2, p p2) {
        this.a = n2;
        this.b = n3;
        this.c = Collections.unmodifiableList(list);
        this.d = list2 == null ? Collections.emptyList() : Collections.unmodifiableList(list2);
        this.e = p2;
    }
}

