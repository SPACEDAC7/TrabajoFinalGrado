/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

public final class m {
    public final String a;
    public final String b;

    public m(String string, String string2) {
        this.a = string;
        this.b = string2;
    }

    public final String toString() {
        return this.a + ", " + this.b;
    }
}

