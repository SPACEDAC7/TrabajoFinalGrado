/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.g.a.l;
import java.util.Collections;
import java.util.List;

public final class n {
    public final String a;
    public final long b;
    public final List<l> c;

    public n(String string, long l2, List<l> list) {
        this.a = string;
        this.b = l2;
        this.c = Collections.unmodifiableList(list);
    }

    public final int a(int n2) {
        int n3 = this.c.size();
        for (int i2 = 0; i2 < n3; ++i2) {
            if (this.c.get((int)i2).b != n2) continue;
            return i2;
        }
        return -1;
    }
}

