/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.b.c;
import com.d.a.a.d.ah;
import java.util.UUID;

public final class o {
    public final String a;
    public final UUID b;
    public final c c;

    public o(String string, UUID uUID, c c2) {
        if (string == null) {
            throw new NullPointerException();
        }
        this.a = string;
        this.b = uUID;
        this.c = c2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (!(object instanceof o)) {
            return false;
        }
        if (object == this) {
            return true;
        }
        object = (o)object;
        if (!this.a.equals(object.a)) return false;
        if (!ah.a(this.b, object.b)) return false;
        if (!ah.a(this.c, object.c)) return false;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int hashCode() {
        int n2 = 0;
        int n3 = this.a.hashCode();
        int n4 = this.b != null ? this.b.hashCode() : 0;
        if (this.c != null) {
            n2 = this.c.hashCode();
        }
        return (n4 + n3 * 37) * 37 + n2;
    }
}

