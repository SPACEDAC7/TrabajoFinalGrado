/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.g.a.k;
import com.d.a.a.g.m;

final class q
implements m {
    private final k a;

    public q(k k2) {
        this.a = k2;
    }

    @Override
    public final int a(long l2) {
        return 0;
    }

    @Override
    public final int a(long l2, long l3) {
        return 0;
    }

    @Override
    public final long a(int n2, long l2) {
        return l2;
    }

    @Override
    public final k a(int n2) {
        return this.a;
    }

    @Override
    public final String b(int n2) {
        return null;
    }

    @Override
    public final int c() {
        return 0;
    }

    @Override
    public final long c(int n2) {
        return 0;
    }

    @Override
    public final boolean d() {
        return true;
    }
}

