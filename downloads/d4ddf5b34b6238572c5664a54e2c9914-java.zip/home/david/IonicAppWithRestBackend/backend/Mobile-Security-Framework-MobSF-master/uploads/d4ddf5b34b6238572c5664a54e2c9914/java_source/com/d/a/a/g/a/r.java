/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import com.d.a.a.g.a.o;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class r
implements Comparator<o> {
    ArrayList<o> a;
    ArrayList<o> b;
    boolean c;
    private ArrayList<o> d;

    protected r() {
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(List<o> list, o o2) {
        if (!list.contains(o2)) {
            for (int i2 = 0; i2 < list.size(); ++i2) {
                boolean bl2 = !list.get((int)i2).a.equals(o2.a);
                if (bl2) continue;
                throw new IllegalStateException();
            }
            list.add(o2);
        }
    }

    public final ArrayList<o> a() {
        if (this.d == null) {
            return this.a;
        }
        if (this.a == null) {
            return this.d;
        }
        for (int i2 = 0; i2 < this.a.size(); ++i2) {
            r.a(this.d, this.a.get(i2));
        }
        return this.d;
    }

    public final void a(o o2) {
        if (this.d == null) {
            this.d = new ArrayList();
        }
        r.a(this.d, o2);
    }

    @Override
    public final /* synthetic */ int compare(Object object, Object object2) {
        object = (o)object;
        object2 = (o)object2;
        return object.a.compareTo(object2.a);
    }
}

