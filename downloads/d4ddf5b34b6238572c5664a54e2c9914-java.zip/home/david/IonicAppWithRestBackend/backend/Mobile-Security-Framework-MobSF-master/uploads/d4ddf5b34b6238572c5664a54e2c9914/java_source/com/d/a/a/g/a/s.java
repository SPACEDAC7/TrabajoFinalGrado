/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  android.util.Base64
 *  android.util.Log
 *  android.util.Pair
 *  org.xmlpull.v1.XmlPullParser
 *  org.xmlpull.v1.XmlPullParserException
 *  org.xmlpull.v1.XmlPullParserFactory
 */
package com.d.a.a.g.a;

import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.util.Pair;
import com.d.a.a.bb;
import com.d.a.a.d.ab;
import com.d.a.a.d.ac;
import com.d.a.a.d.af;
import com.d.a.a.d.ah;
import com.d.a.a.f.c.q;
import com.d.a.a.g.a.a;
import com.d.a.a.g.a.b;
import com.d.a.a.g.a.c;
import com.d.a.a.g.a.d;
import com.d.a.a.g.a.e;
import com.d.a.a.g.a.f;
import com.d.a.a.g.a.g;
import com.d.a.a.g.a.h;
import com.d.a.a.g.a.i;
import com.d.a.a.g.a.j;
import com.d.a.a.g.a.k;
import com.d.a.a.g.a.l;
import com.d.a.a.g.a.m;
import com.d.a.a.g.a.n;
import com.d.a.a.g.a.o;
import com.d.a.a.g.a.p;
import com.d.a.a.g.a.r;
import com.d.a.a.g.a.t;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public final class s
extends DefaultHandler
implements com.d.a.a.a.j<a> {
    private static final Pattern a = Pattern.compile("(\\d+)(?:/(\\d+))?");
    private final String b = null;
    private final XmlPullParserFactory c;

    public s() {
        this(0);
    }

    private s(byte by2) {
        try {
            this.c = XmlPullParserFactory.newInstance();
            return;
        }
        catch (XmlPullParserException var2_2) {
            throw new RuntimeException("Couldn't create XmlPullParserFactory instance", (Throwable)var2_2);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static float a(XmlPullParser object, float f2) {
        object = object.getAttributeValue(null, "frameRate");
        float f3 = f2;
        if (object == null) return f3;
        object = a.matcher((CharSequence)object);
        f3 = f2;
        if (!object.matches()) return f3;
        int n2 = Integer.parseInt(object.group(1));
        if (TextUtils.isEmpty((CharSequence)(object = object.group(2)))) return n2;
        return (float)n2 / (float)Integer.parseInt((String)object);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int a(int n2, int n3) {
        if (n2 == -1) {
            return n3;
        }
        int n4 = n2;
        if (n3 == -1) return n4;
        n3 = n2 == n3 ? 1 : 0;
        n4 = n2;
        if (n3 != 0) return n4;
        throw new IllegalStateException();
    }

    private static int a(XmlPullParser object) {
        if (!TextUtils.isEmpty((CharSequence)(object = object.getAttributeValue(null, "contentType")))) {
            if ("audio".equals(object)) {
                return 1;
            }
            if ("video".equals(object)) {
                return 0;
            }
            if ("text".equals(object)) {
                return 2;
            }
        }
        return -1;
    }

    private static int a(XmlPullParser object, String string, int n2) {
        if ((object = object.getAttributeValue(null, string)) == null) {
            return n2;
        }
        return Integer.parseInt((String)object);
    }

    private static long a(XmlPullParser object, String string) {
        if ((object = object.getAttributeValue(null, string)) == null) {
            return -1;
        }
        return ah.d((String)object);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Pair<n, Long> a(XmlPullParser xmlPullParser, String object, long l2) {
        String string = xmlPullParser.getAttributeValue(null, "id");
        l2 = s.b(xmlPullParser, "start", l2);
        long l3 = s.b(xmlPullParser, "duration", -1);
        ArrayList<l> arrayList = new ArrayList<l>();
        boolean bl2 = false;
        Object object2 = null;
        Object object3 = object;
        do {
            boolean bl3;
            Object object4;
            xmlPullParser.next();
            if (ac.b(xmlPullParser, "BaseURL")) {
                bl3 = bl2;
                object = object2;
                object4 = object3;
                if (!bl2) {
                    object4 = s.b(xmlPullParser, (String)object3);
                    bl3 = true;
                    object = object2;
                }
            } else if (ac.b(xmlPullParser, "AdaptationSet")) {
                arrayList.add(s.a(this, xmlPullParser, (String)object3, (g)object2));
                bl3 = bl2;
                object = object2;
                object4 = object3;
            } else if (ac.b(xmlPullParser, "SegmentBase")) {
                object = s.a(this, xmlPullParser, (String)object3, null);
                bl3 = bl2;
                object4 = object3;
            } else if (ac.b(xmlPullParser, "SegmentList")) {
                object = s.a(this, xmlPullParser, (String)object3, null);
                bl3 = bl2;
                object4 = object3;
            } else {
                bl3 = bl2;
                object = object2;
                object4 = object3;
                if (ac.b(xmlPullParser, "SegmentTemplate")) {
                    object = s.a(this, xmlPullParser, (String)object3, null);
                    bl3 = bl2;
                    object4 = object3;
                }
            }
            bl2 = bl3;
            object2 = object;
            object3 = object4;
        } while (!ac.a(xmlPullParser, "Period"));
        return Pair.create((Object)new n(string, l2, arrayList), (Object)l3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static b a(s object, XmlPullParser xmlPullParser, String string, b b2) {
        long l2 = b2 != null ? b2.g : 1;
        long l3 = s.c(xmlPullParser, "timescale", l2);
        l2 = b2 != null ? b2.h : 0;
        long l4 = s.c(xmlPullParser, "presentationTimeOffset", l2);
        l2 = b2 != null ? b2.b : 0;
        long l5 = b2 != null ? b2.c : -1;
        object = xmlPullParser.getAttributeValue(null, "indexRange");
        if (object != null) {
            object = object.split("-");
            l2 = Long.parseLong(object[0]);
            l5 = Long.parseLong((String)object[1]) - l2 + 1;
        }
        object = b2 != null ? b2.f : null;
        do {
            xmlPullParser.next();
            if (!ac.b(xmlPullParser, "Initialization")) continue;
            object = s.a(xmlPullParser, string, "sourceURL", "range");
        } while (!ac.a(xmlPullParser, "SegmentBase"));
        return new b((k)object, l3, l4, string, l2, l5);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static d a(s list, XmlPullParser object, String list2, d d2) {
        List<f> list3;
        k k2;
        long l2 = d2 != null ? d2.g : 1;
        long l3 = s.c((XmlPullParser)object, "timescale", l2);
        l2 = d2 != null ? d2.h : 0;
        long l4 = s.c((XmlPullParser)object, "presentationTimeOffset", l2);
        l2 = d2 != null ? d2.b : -1;
        l2 = s.c((XmlPullParser)object, "duration", l2);
        int n2 = d2 != null ? d2.a : 1;
        n2 = s.a((XmlPullParser)object, "startNumber", n2);
        k k3 = null;
        List<f> list4 = null;
        List<k> list5 = null;
        do {
            object.next();
            if (ac.b((XmlPullParser)object, "Initialization")) {
                k2 = s.a((XmlPullParser)object, list2, "sourceURL", "range");
                list3 = list4;
                list = list5;
            } else if (ac.b((XmlPullParser)object, "SegmentTimeline")) {
                list3 = s.c((XmlPullParser)object);
                list = list5;
                k2 = k3;
            } else {
                list = list5;
                list3 = list4;
                k2 = k3;
                if (ac.b((XmlPullParser)object, "SegmentURL")) {
                    list = list5;
                    if (list5 == null) {
                        list = new ArrayList<k>();
                    }
                    list.add(s.a((XmlPullParser)object, list2, "media", "mediaRange"));
                    list3 = list4;
                    k2 = k3;
                }
            }
            list5 = list;
            list4 = list3;
            k3 = k2;
        } while (!ac.a((XmlPullParser)object, "SegmentList"));
        if (d2 == null) {
            object = k2;
            list2 = list3;
            return new d((k)object, l3, l4, n2, l2, list2, list);
        }
        object = k2 != null ? k2 : d2.f;
        list2 = list3 != null ? list3 : d2.c;
        if (list != null) {
            return new d((k)object, l3, l4, n2, l2, list2, list);
        }
        list = d2.d;
        return new d((k)object, l3, l4, n2, l2, list2, list);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static e a(s object, XmlPullParser xmlPullParser, String string, e e2) {
        k k2;
        long l2 = e2 != null ? e2.g : 1;
        long l3 = s.c(xmlPullParser, "timescale", l2);
        l2 = e2 != null ? e2.h : 0;
        long l4 = s.c(xmlPullParser, "presentationTimeOffset", l2);
        l2 = e2 != null ? e2.b : -1;
        l2 = s.c(xmlPullParser, "duration", l2);
        int n2 = e2 != null ? e2.a : 1;
        n2 = s.a(xmlPullParser, "startNumber", n2);
        object = e2 != null ? e2.e : null;
        t t2 = s.a(xmlPullParser, "media", (t)object);
        object = e2 != null ? e2.d : null;
        t t3 = s.a(xmlPullParser, "initialization", (t)object);
        k k3 = null;
        List<f> list = null;
        do {
            xmlPullParser.next();
            if (ac.b(xmlPullParser, "Initialization")) {
                k2 = s.a(xmlPullParser, string, "sourceURL", "range");
                object = list;
            } else {
                object = list;
                k2 = k3;
                if (ac.b(xmlPullParser, "SegmentTimeline")) {
                    object = s.c(xmlPullParser);
                    k2 = k3;
                }
            }
            list = object;
            k3 = k2;
        } while (!ac.a(xmlPullParser, "SegmentTemplate"));
        if (e2 == null) return new e(k2, l3, l4, n2, l2, (List<f>)object, t3, t2, string);
        if (k2 == null) {
            k2 = e2.f;
        }
        if (object != null) {
            return new e(k2, l3, l4, n2, l2, (List<f>)object, t3, t2, string);
        }
        object = e2.c;
        return new e(k2, l3, l4, n2, l2, (List<f>)object, t3, t2, string);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private j a(XmlPullParser var1_1, String var2_2, String var3_3, String var4_4, int var5_5, int var6_6, float var7_7, int var8_8, int var9_9, String var10_10, g var11_11, r var12_12) {
        var18_13 = var1_1.getAttributeValue(null, "id");
        var13_14 = s.a((XmlPullParser)var1_1, "bandwidth", -1);
        var19_15 = s.a((XmlPullParser)var1_1, "mimeType", (String)var3_3);
        var20_16 = s.a((XmlPullParser)var1_1, "codecs", (String)var4_4);
        var14_17 = s.a((XmlPullParser)var1_1, "width", var5_5);
        var15_18 = s.a((XmlPullParser)var1_1, "height", var6_6);
        var7_7 = s.a((XmlPullParser)var1_1, var7_7);
        var9_9 = s.a((XmlPullParser)var1_1, "audioSamplingRate", var9_9);
        var21_19 = s.a((XmlPullParser)var1_1, "FBQualityLabel", null);
        var16_20 = s.a((XmlPullParser)var1_1, "FBDefaultQuality", 0) == 1;
        var17_21 = null;
        var6_6 = 0;
        var5_5 = var8_8;
        var4_4 = var11_11;
        var3_3 = var2_2;
        var2_2 = var17_21;
        do {
            var1_1.next();
            if (!ac.b((XmlPullParser)var1_1, "BaseURL")) ** GOTO lbl31
            if (var6_6 != 0) ** GOTO lbl-1000
            var17_21 = s.b((XmlPullParser)var1_1, (String)var3_3);
            var3_3 = var4_4;
            var8_8 = 1;
            var11_11 = var2_2;
            var4_4 = var17_21;
            var2_2 = var3_3;
            var3_3 = var11_11;
            var6_6 = var5_5;
            var5_5 = var8_8;
            ** GOTO lbl96
lbl31: // 1 sources:
            if (ac.b((XmlPullParser)var1_1, "AudioChannelConfiguration")) {
                var8_8 = s.d((XmlPullParser)var1_1);
                var11_11 = var3_3;
                var5_5 = var6_6;
                var6_6 = var8_8;
                var3_3 = var2_2;
                var2_2 = var4_4;
                var4_4 = var11_11;
            } else if (ac.b((XmlPullParser)var1_1, "SegmentBase")) {
                var11_11 = s.a(this, (XmlPullParser)var1_1, (String)var3_3, (b)var4_4);
                var4_4 = var3_3;
                var8_8 = var5_5;
                var5_5 = var6_6;
                var6_6 = var8_8;
                var3_3 = var2_2;
                var2_2 = var11_11;
            } else if (ac.b((XmlPullParser)var1_1, "SegmentList")) {
                var11_11 = s.a(this, (XmlPullParser)var1_1, (String)var3_3, (d)var4_4);
                var4_4 = var3_3;
                var8_8 = var5_5;
                var5_5 = var6_6;
                var6_6 = var8_8;
                var3_3 = var2_2;
                var2_2 = var11_11;
            } else if (ac.b((XmlPullParser)var1_1, "SegmentTemplate")) {
                var11_11 = s.a(this, (XmlPullParser)var1_1, (String)var3_3, (e)var4_4);
                var4_4 = var3_3;
                var8_8 = var5_5;
                var5_5 = var6_6;
                var6_6 = var8_8;
                var3_3 = var2_2;
                var2_2 = var11_11;
            } else if (ac.b((XmlPullParser)var1_1, "ContentProtection")) {
                var11_11 = s.b((XmlPullParser)var1_1);
                if (var11_11 != null) {
                    var12_12.a((o)var11_11);
                }
                var11_11 = var3_3;
                var8_8 = var5_5;
                var5_5 = var6_6;
                var6_6 = var8_8;
                var3_3 = var2_2;
                var2_2 = var4_4;
                var4_4 = var11_11;
            } else if (ac.b((XmlPullParser)var1_1, "FBInitializationBinary")) {
                var17_21 = var1_1.nextText();
                var11_11 = var3_3;
                var2_2 = var4_4;
                var8_8 = var5_5;
                var3_3 = var17_21;
                var5_5 = var6_6;
                var6_6 = var8_8;
                var4_4 = var11_11;
            } else lbl-1000: // 2 sources:
            {
                var11_11 = var3_3;
                var8_8 = var5_5;
                var5_5 = var6_6;
                var6_6 = var8_8;
                var3_3 = var2_2;
                var2_2 = var4_4;
                var4_4 = var11_11;
            }
lbl96: // 8 sources:
            if (ac.a((XmlPullParser)var1_1, "Representation")) {
                var1_1 = new com.d.a.a.e.c(var18_13, var19_15, var14_17, var15_18, var7_7, var6_6, var9_9, var13_14, var10_10, var20_16, var21_19, var16_20);
                var10_10 = this.b;
                if (var2_2 == null) {
                    var2_2 = new b((String)var4_4);
                }
                if (var2_2 instanceof b) {
                    return new h(var10_10, -1, (com.d.a.a.e.c)var1_1, (b)var2_2, null, (String)var3_3);
                }
                if (var2_2 instanceof c == false) throw new IllegalArgumentException("segmentBase must be of type SingleSegmentBase or MultiSegmentBase");
                return new i(var10_10, -1, (com.d.a.a.e.c)var1_1, (c)var2_2, null, (String)var3_3);
            }
            var8_8 = var6_6;
            var11_11 = var4_4;
            var4_4 = var2_2;
            var6_6 = var5_5;
            var2_2 = var3_3;
            var5_5 = var8_8;
            var3_3 = var11_11;
        } while (true);
    }

    private static k a(XmlPullParser arrstring, String string, String string2, String string3) {
        string2 = arrstring.getAttributeValue(null, string2);
        long l2 = 0;
        long l3 = -1;
        arrstring = arrstring.getAttributeValue(null, string3);
        long l4 = l3;
        if (arrstring != null) {
            long l5;
            arrstring = arrstring.split("-");
            l2 = l5 = Long.parseLong(arrstring[0]);
            l4 = l3;
            if (arrstring.length == 2) {
                l4 = 1 + (Long.parseLong(arrstring[1]) - l5);
                l2 = l5;
            }
        }
        return new k(string, string2, l2, l4);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static l a(s var0, XmlPullParser var1_1, String var2_2, g var3_3) {
        var9_4 = s.a(var1_1, "id", -1);
        var7_5 = s.a(var1_1);
        var17_6 = var1_1.getAttributeValue(null, "mimeType");
        var18_7 = var1_1.getAttributeValue(null, "codecs");
        var10_8 = s.a(var1_1, "width", -1);
        var11_9 = s.a(var1_1, "height", -1);
        var4_10 = s.a(var1_1, -1.0f);
        var6_11 = -1;
        var12_12 = s.a(var1_1, "audioSamplingRate", -1);
        var14_13 = var1_1.getAttributeValue(null, "lang");
        var19_14 = new r();
        var20_15 = new ArrayList<j>();
        var5_16 = false;
        var13_17 = null;
        var15_18 = var3_3;
        var3_3 = var13_17;
        do {
            var1_1.next();
            if (!ac.b(var1_1, "BaseURL")) ** GOTO lbl27
            if (var5_16) ** GOTO lbl127
            var13_17 = s.b(var1_1, (String)var2_2);
            var5_16 = true;
            var2_2 = var3_3;
            var3_3 = var13_17;
            var13_17 = var15_18;
            ** GOTO lbl131
lbl27: // 1 sources:
            if (!ac.b(var1_1, "ContentProtection")) ** GOTO lbl36
            var13_17 = s.b(var1_1);
            if (var13_17 != null) {
                var19_14.a((o)var13_17);
            }
            var13_17 = var3_3;
            var3_3 = var2_2;
            var2_2 = var13_17;
            var13_17 = var15_18;
            ** GOTO lbl131
lbl36: // 1 sources:
            if (!ac.b(var1_1, "Accessibility")) ** GOTO lbl42
            var13_17 = new p(var1_1.getAttributeValue(null, "schemeIdUri"), var1_1.getAttributeValue(null, "value"));
            var3_3 = var2_2;
            var2_2 = var13_17;
            var13_17 = var15_18;
            ** GOTO lbl131
lbl42: // 1 sources:
            if (!ac.b(var1_1, "ContentComponent")) ** GOTO lbl59
            var16_20 = var1_1.getAttributeValue(null, "lang");
            if (var14_13 == null) {
                var13_17 = var16_20;
            } else {
                var13_17 = var14_13;
                if (var16_20 != null) {
                    var13_17 = var14_13;
                    if (!var14_13.equals(var16_20)) {
                        throw new IllegalStateException();
                    }
                }
            }
            var7_5 = s.a(var7_5, s.a(var1_1));
            var14_13 = var3_3;
            var3_3 = var2_2;
            var2_2 = var14_13;
            var14_13 = var13_17;
            var13_17 = var15_18;
            ** GOTO lbl131
lbl59: // 1 sources:
            if (!ac.b(var1_1, "Representation")) ** GOTO lbl98
            var13_17 = var0.a(var1_1, (String)var2_2, var17_6, var18_7, var10_8, var11_9, var4_10, var6_11, var12_12, (String)var14_13, (g)var15_18, var19_14);
            if (!var19_14.c) {
                if (var19_14.b != null) {
                    Collections.sort(var19_14.b, var19_14);
                }
                var19_14.a = var19_14.b;
                var19_14.c = true;
            } else if (var19_14.b == null) {
                var8_19 = var19_14.a == null ? 1 : 0;
                if (var8_19 == 0) {
                    throw new IllegalStateException();
                }
            } else {
                Collections.sort(var19_14.b, var19_14);
                if (!var19_14.b.equals(var19_14.a)) {
                    throw new IllegalStateException();
                }
            }
            var19_14.b = null;
            var16_20 = var13_17.e.b;
            if (TextUtils.isEmpty((CharSequence)var16_20)) ** GOTO lbl-1000
            if (ab.a(var16_20).equals("video")) {
                var8_19 = 0;
            } else if (ab.a(var16_20).equals("audio")) {
                var8_19 = 1;
            } else if (ab.a(var16_20).equals("text") || "application/ttml+xml".equals(var16_20)) {
                var8_19 = 2;
            } else if ("application/mp4".equals(var16_20) && ("stpp".equals(var16_20 = var13_17.e.k) || "wvtt".equals(var16_20))) {
                var8_19 = 2;
            } else lbl-1000: // 2 sources:
            {
                var8_19 = -1;
            }
            var7_5 = s.a(var7_5, var8_19);
            var20_15.add((j)var13_17);
            var13_17 = var3_3;
            var3_3 = var2_2;
            var2_2 = var13_17;
            var13_17 = var15_18;
            ** GOTO lbl131
lbl98: // 1 sources:
            if (ac.b(var1_1, "AudioChannelConfiguration")) {
                var6_11 = s.d(var1_1);
                var13_17 = var3_3;
                var3_3 = var2_2;
                var2_2 = var13_17;
                var13_17 = var15_18;
            } else if (ac.b(var1_1, "SegmentBase")) {
                var15_18 = s.a(var0, var1_1, (String)var2_2, (b)var15_18);
                var13_17 = var3_3;
                var3_3 = var2_2;
                var2_2 = var13_17;
                var13_17 = var15_18;
            } else if (ac.b(var1_1, "SegmentList")) {
                var15_18 = s.a(var0, var1_1, (String)var2_2, (d)var15_18);
                var13_17 = var3_3;
                var3_3 = var2_2;
                var2_2 = var13_17;
                var13_17 = var15_18;
            } else if (ac.b(var1_1, "SegmentTemplate")) {
                var15_18 = s.a(var0, var1_1, (String)var2_2, (e)var15_18);
                var13_17 = var3_3;
                var3_3 = var2_2;
                var2_2 = var13_17;
                var13_17 = var15_18;
            } else {
                var1_1.getEventType();
lbl127: // 2 sources:
                var13_17 = var3_3;
                var3_3 = var2_2;
                var2_2 = var13_17;
                var13_17 = var15_18;
            }
lbl131: // 10 sources:
            if (ac.a(var1_1, "AdaptationSet")) {
                return new l(var9_4, var7_5, var20_15, var19_14.a(), (p)var2_2);
            }
            var15_18 = var3_3;
            var3_3 = var2_2;
            var2_2 = var15_18;
            var15_18 = var13_17;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static t a(XmlPullParser object, String object2, t object3) {
        String string = object.getAttributeValue(null, (String)object2);
        if (string == null) return object3;
        String[] arrstring = new String[5];
        int[] arrn = new int[4];
        String[] arrstring2 = new String[4];
        arrstring[0] = "";
        int n2 = 0;
        int n3 = 0;
        while (n3 < string.length()) {
            int n4 = string.indexOf("$", n3);
            if (n4 == -1) {
                arrstring[n2] = arrstring[n2] + string.substring(n3);
                n3 = string.length();
                continue;
            }
            if (n4 != n3) {
                arrstring[n2] = arrstring[n2] + string.substring(n3, n4);
                n3 = n4;
                continue;
            }
            if (string.startsWith("$$", n3)) {
                arrstring[n2] = arrstring[n2] + "$";
                n3 += 2;
                continue;
            }
            n4 = string.indexOf("$", n3 + 1);
            object3 = string.substring(n3 + 1, n4);
            if (object3.equals("RepresentationID")) {
                arrn[n2] = 1;
            } else {
                n3 = object3.indexOf("%0");
                object = "%01d";
                object2 = object3;
                if (n3 != -1) {
                    object = object2 = object3.substring(n3);
                    if (!object2.endsWith("d")) {
                        object = (String)object2 + "d";
                    }
                    object2 = object3.substring(0, n3);
                }
                if (object2.equals("Number")) {
                    arrn[n2] = 2;
                } else if (object2.equals("Bandwidth")) {
                    arrn[n2] = 3;
                } else {
                    if (!object2.equals("Time")) {
                        throw new IllegalArgumentException("Invalid template: " + string);
                    }
                    arrn[n2] = 4;
                }
                arrstring2[n2] = object;
            }
            arrstring[++n2] = "";
            n3 = n4 + 1;
        }
        return new t(arrstring, arrn, arrstring2, n2);
    }

    private static String a(XmlPullParser object, String string, String string2) {
        if ((object = object.getAttributeValue(null, string)) == null) {
            return string2;
        }
        return object;
    }

    private static long b(XmlPullParser object, String string, long l2) {
        if ((object = object.getAttributeValue(null, string)) == null) {
            return l2;
        }
        return ah.c((String)object);
    }

    private static o b(XmlPullParser xmlPullParser) {
        UUID uUID;
        com.d.a.a.b.c c2;
        boolean bl2;
        String string = xmlPullParser.getAttributeValue(null, "schemeIdUri");
        boolean bl3 = false;
        com.d.a.a.b.c c3 = null;
        UUID uUID2 = null;
        do {
            xmlPullParser.next();
            bl2 = bl3;
            c2 = c3;
            uUID = uUID2;
            if (ac.b(xmlPullParser, "cenc:pssh")) {
                bl2 = bl3;
                c2 = c3;
                uUID = uUID2;
                if (xmlPullParser.next() == 4) {
                    bl2 = true;
                    c2 = new com.d.a.a.b.c("video/mp4", Base64.decode((String)xmlPullParser.getText(), (int)0));
                    uUID = q.a(c2.b);
                }
            }
            bl3 = bl2;
            c3 = c2;
            uUID2 = uUID;
        } while (!ac.a(xmlPullParser, "ContentProtection"));
        if (bl2 && uUID == null) {
            Log.w((String)"MediaPresentationDescriptionParser", (String)"Skipped unsupported ContentProtection element");
            return null;
        }
        return new o(string, uUID, c2);
    }

    private static String b(XmlPullParser xmlPullParser, String string) {
        xmlPullParser.next();
        return af.a(string, xmlPullParser.getText());
    }

    private static long c(XmlPullParser object, String string, long l2) {
        if ((object = object.getAttributeValue(null, string)) == null) {
            return l2;
        }
        return Long.parseLong((String)object);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static List<f> c(XmlPullParser xmlPullParser) {
        ArrayList<f> arrayList = new ArrayList<f>();
        long l2 = 0;
        do {
            xmlPullParser.next();
            long l3 = l2;
            if (ac.b(xmlPullParser, "S")) {
                l3 = s.c(xmlPullParser, "t", l2);
                l2 = s.c(xmlPullParser, "d", -1);
                int n2 = s.a(xmlPullParser, "r", 0) + 1;
                if (n2 == 1) {
                    arrayList.add(new f(l3, l2, s.a(xmlPullParser, "FBMediaBinary", null)));
                } else {
                    for (int i2 = 0; i2 < n2; l3 += l2, ++i2) {
                        arrayList.add(new f(l3, l2, null));
                    }
                }
            }
            l2 = l3;
        } while (!ac.a(xmlPullParser, "SegmentTimeline"));
        if (arrayList.isEmpty()) {
            return null;
        }
        return arrayList;
    }

    private static int d(XmlPullParser xmlPullParser) {
        int n2 = -1;
        if ("urn:mpeg:dash:23003:3:audio_channel_configuration:2011".equals(s.a(xmlPullParser, "schemeIdUri", null))) {
            n2 = s.a(xmlPullParser, "value", -1);
        }
        do {
            xmlPullParser.next();
        } while (!ac.a(xmlPullParser, "AudioChannelConfiguration"));
        return n2;
    }

    @Override
    public final /* synthetic */ Object a(String string, InputStream inputStream) {
        return this.b(string, inputStream);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final a b(String var1_1, InputStream var2_4) {
        try {
            var27_5 = this.c.newPullParser();
            var27_5.setInput((InputStream)var2_4, null);
            if (var27_5.next() != 2) throw new bb("inputStream does not contain a valid media presentation description");
            if (!"MPD".equals(var27_5.getName())) {
                throw new bb("inputStream does not contain a valid media presentation description");
            }
        }
        catch (XmlPullParserException var1_2) {
            throw new bb((Throwable)var1_2);
        }
        var16_6 = s.a(var27_5, "availabilityStartTime");
        var18_7 = s.a(var27_5, "availabilityEndTime");
        var14_8 = s.b(var27_5, "mediaPresentationDuration", -1);
        var20_9 = s.b(var27_5, "minBufferTime", -1);
        var2_4 = var27_5.getAttributeValue(null, "type");
        var24_10 = var2_4 != null ? var2_4.equals("dynamic") : false;
        var10_11 = var24_10 != false ? s.b(var27_5, "minimumUpdatePeriod", -1) : -1;
        var12_12 = var24_10 != false ? s.b(var27_5, "timeShiftBufferDepth", -1) : -1;
        var22_13 = s.c(var27_5, "publishFrameTime", 0);
        var28_14 = new ArrayList<n>();
        var6_15 = var24_10 != false ? -1 : 0;
        var25_20 = null;
        var2_4 = null;
        var4_17 = false;
        var3_16 = false;
        var26_21 = var1_1;
        do {
            block12 : {
                block11 : {
                    var27_5.next();
                    if (!ac.b(var27_5, "BaseURL")) ** GOTO lbl38
                    var8_19 = var6_15;
                    if (var4_17) ** GOTO lbl73
                    var26_21 = s.b(var27_5, (String)var26_21);
                    var5_18 = true;
                    var1_1 = var2_4;
                    var2_4 = var25_20;
                    var4_17 = var3_16;
                    var3_16 = var5_18;
                    ** GOTO lbl79
lbl38: // 1 sources:
                    try {
                        if (!ac.b(var27_5, "UTCTiming")) break block11;
                        var1_1 = new m(var27_5.getAttributeValue(null, "schemeIdUri"), var27_5.getAttributeValue(null, "value"));
                        var5_18 = var3_16;
                        var2_4 = var25_20;
                        var3_16 = var4_17;
                        var4_17 = var5_18;
                        break block12;
                    }
                    catch (ParseException var1_3) {
                        throw new bb(var1_3);
                    }
                }
                if (!ac.b(var27_5, "Location")) ** GOTO lbl57
                var25_20 = var27_5.nextText();
                var5_18 = var3_16;
                var1_1 = var2_4;
                var3_16 = var4_17;
                var4_17 = var5_18;
                var2_4 = var25_20;
                ** GOTO lbl79
lbl57: // 1 sources:
                var8_19 = var6_15;
                if (!ac.b(var27_5, "Period")) ** GOTO lbl73
                var8_19 = var6_15;
                if (var3_16) ** GOTO lbl73
                var1_1 = this.a(var27_5, (String)var26_21, var6_15);
                var29_22 = (n)var1_1.first;
                if (var29_22.b == -1) {
                    if (var24_10 == false) throw new bb("Unable to determine start of period " + var28_14.size());
                    var3_16 = var4_17;
                    var4_17 = true;
                    var1_1 = var2_4;
                    var2_4 = var25_20;
                } else {
                    var6_15 = (Long)var1_1.second;
                    var8_19 = var6_15 == -1 ? -1 : var6_15 + var29_22.b;
                    var28_14.add(var29_22);
lbl73: // 4 sources:
                    var5_18 = var3_16;
                    var1_1 = var2_4;
                    var3_16 = var4_17;
                    var4_17 = var5_18;
                    var6_15 = var8_19;
                    var2_4 = var25_20;
                }
            }
            if (ac.a(var27_5, "MPD")) {
                if (var14_8 != -1 || var6_15 == -1) {
                    var6_15 = var14_8;
                }
                if (var28_14.isEmpty() == false) return new a(var16_6, var18_7, var6_15, var20_9, var24_10, var10_11, var12_12, (m)var1_1, (String)var2_4, var22_13, (List<n>)var28_14);
                throw new bb("No periods found.");
            }
            var5_18 = var4_17;
            var4_17 = var3_16;
            var3_16 = var5_18;
            var25_20 = var2_4;
            var2_4 = var1_1;
        } while (true);
    }
}

