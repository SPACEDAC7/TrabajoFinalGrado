/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g.a;

import java.util.Locale;

public final class t {
    private final String[] a;
    private final int[] b;
    private final String[] c;
    private final int d;

    t(String[] arrstring, int[] arrn, String[] arrstring2, int n2) {
        this.a = arrstring;
        this.b = arrn;
        this.c = arrstring2;
        this.d = n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String a(String string, int n2, int n3, long l2) {
        StringBuilder stringBuilder = new StringBuilder();
        int n4 = 0;
        do {
            if (n4 >= this.d) {
                stringBuilder.append(this.a[this.d]);
                return stringBuilder.toString();
            }
            stringBuilder.append(this.a[n4]);
            if (this.b[n4] == 1) {
                stringBuilder.append(string);
            } else if (this.b[n4] == 2) {
                stringBuilder.append(String.format(Locale.US, this.c[n4], n2));
            } else if (this.b[n4] == 3) {
                stringBuilder.append(String.format(Locale.US, this.c[n4], n3));
            } else if (this.b[n4] == 4) {
                stringBuilder.append(String.format(Locale.US, this.c[n4], l2));
            }
            ++n4;
        } while (true);
    }
}

