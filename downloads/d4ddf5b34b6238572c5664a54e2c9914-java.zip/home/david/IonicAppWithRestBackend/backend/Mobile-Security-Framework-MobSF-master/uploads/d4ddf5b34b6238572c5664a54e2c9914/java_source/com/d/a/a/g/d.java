/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g;

import java.io.IOException;

public final class d
extends IOException {
    public d(String string) {
        super(string);
    }
}

