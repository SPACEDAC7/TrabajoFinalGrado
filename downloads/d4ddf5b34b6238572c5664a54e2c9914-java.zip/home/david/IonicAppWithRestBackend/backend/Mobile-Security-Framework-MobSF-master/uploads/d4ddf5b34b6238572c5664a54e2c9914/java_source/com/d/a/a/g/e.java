/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g;

public enum e {
    a(0),
    b(1),
    c(2);
    
    public final int d;

    private e(int n3) {
        this.d = n3;
    }

    public static e a(int n2) {
        for (e e2 : e.values()) {
            if (e2.d != n2) continue;
            return e2;
        }
        return a;
    }
}

