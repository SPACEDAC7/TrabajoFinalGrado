/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g;

import com.d.a.a.bh;
import com.d.a.a.g.l;
import com.instagram.exoplayer.service.p;
import com.instagram.exoplayer.service.q;

final class f
implements Runnable {
    final /* synthetic */ bh a;
    final /* synthetic */ l b;

    f(l l2, bh bh2) {
        this.b = l2;
        this.a = bh2;
    }

    @Override
    public final void run() {
        p p2 = this.b.a;
        int n2 = this.b.b;
        bh bh2 = this.a;
        p2.a.p = 0;
        if (bh2 == null) {
            return;
        }
        bh2.a(p2.a.o);
        long l2 = p2.a.o[0];
        l2 = p2.a.o[1];
    }
}

