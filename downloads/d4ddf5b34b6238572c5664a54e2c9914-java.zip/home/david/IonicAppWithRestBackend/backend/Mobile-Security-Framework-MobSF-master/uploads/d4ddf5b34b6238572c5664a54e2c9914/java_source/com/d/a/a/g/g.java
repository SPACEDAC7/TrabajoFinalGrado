/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.RemoteException
 */
package com.d.a.a.g;

import android.os.RemoteException;
import com.d.a.a.bh;
import com.d.a.a.g.l;
import com.instagram.exoplayer.ipc.f;
import com.instagram.exoplayer.service.p;
import com.instagram.exoplayer.service.q;

final class g
implements Runnable {
    final /* synthetic */ bh a;
    final /* synthetic */ l b;

    g(l l2, bh bh2) {
        this.b = l2;
        this.a = bh2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final void run() {
        Object object = this.b.a;
        int n2 = this.b.b;
        Object object2 = this.a;
        q q2 = object.a;
        ++q2.p;
        if (object2 == null) {
            return;
        }
        if (object.a.p < 3) return;
        object2.a(object.a.o);
        long l2 = object.a.o[0];
        l2 = object.a.o[1];
        object2 = object.a;
        object = String.format(null, "%d-%d", object.a.o[0], object.a.o[1]);
        if (object2.d == null) return;
        try {
            object2.d.b("stale_mpd_warning", (String)object);
            return;
        }
        catch (RemoteException var4_2) {
            return;
        }
    }
}

