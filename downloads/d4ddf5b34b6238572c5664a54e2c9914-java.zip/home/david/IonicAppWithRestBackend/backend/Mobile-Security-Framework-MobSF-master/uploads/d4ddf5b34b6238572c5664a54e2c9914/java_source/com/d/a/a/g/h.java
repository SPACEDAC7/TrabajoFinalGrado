/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g;

import com.d.a.a.e.c;
import com.d.a.a.q;

public final class h {
    public final q a;
    public final int b;
    public final int c;
    final int d;
    final c e;
    final c[] f;

    public h(q q2, int n2, c c2) {
        this.a = q2;
        this.d = n2;
        this.e = c2;
        this.f = null;
        this.b = -1;
        this.c = -1;
    }

    public h(q q2, int n2, c[] arrc, int n3, int n4) {
        this.a = q2;
        this.d = n2;
        this.f = arrc;
        this.b = n3;
        this.c = n4;
        this.e = null;
    }
}

