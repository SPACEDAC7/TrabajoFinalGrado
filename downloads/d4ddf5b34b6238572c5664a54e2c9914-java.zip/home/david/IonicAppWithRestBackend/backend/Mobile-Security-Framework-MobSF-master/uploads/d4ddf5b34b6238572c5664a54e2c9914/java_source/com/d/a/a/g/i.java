/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g;

import com.d.a.a.a;
import com.d.a.a.e.c;
import com.d.a.a.f.h;
import com.d.a.a.g.a.j;
import com.d.a.a.g.a.k;
import com.d.a.a.g.d;
import com.d.a.a.g.l;
import com.d.a.a.g.m;
import com.d.a.a.q;

public final class i {
    public final boolean a;
    public final com.d.a.a.e.h b;
    public j c;
    public m d;
    public q e;
    final long f;
    long g;
    protected int h;
    private final boolean i;
    private final boolean j;

    /*
     * Enabled aggressive block sorting
     */
    public i(long l2, long l3, j j2, boolean bl2, boolean bl3, boolean bl4) {
        int n2 = 0;
        this.f = l2;
        this.g = l3;
        this.c = j2;
        this.i = bl2;
        Object object = j2.e.b;
        this.a = l.a((String)object);
        if (this.a) {
            object = null;
        } else {
            int n3 = object.startsWith("video/webm") || object.startsWith("audio/webm") || object.startsWith("application/webm") ? 1 : 0;
            if (n3 != 0) {
                object = new com.d.a.a.f.g.i();
            } else {
                n3 = n2;
                if (bl4) {
                    n3 = 8;
                }
                object = new com.d.a.a.f.c.m(n3);
            }
            object = new com.d.a.a.e.h((h)object);
        }
        this.b = object;
        this.d = j2.b();
        this.j = bl3;
    }

    private static int f(i i2, int n2) {
        int n3 = n2 - i2.h;
        if (n3 < i2.d.c()) {
            throw new d("Segment number without shift number is behind, segmentNum=" + n2 + ", segmentNumShift=" + i2.h + ",firstSegmentNum=" + i2.d.c());
        }
        return n3;
    }

    public final int a() {
        return this.d.c() + this.h;
    }

    public final int a(long l2) {
        return this.d.a(l2 - this.f, this.g) + this.h;
    }

    public final long a(int n2) {
        return this.d.c(i.f(this, n2)) + this.f;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(long l2, j j2) {
        m m2 = this.c.b();
        m m3 = j2.b();
        this.g = l2;
        this.c = j2;
        if (m2 == null) {
            return;
        }
        this.d = m3;
        if (!m2.d()) return;
        int n2 = m2.a(this.g);
        l2 = m2.c(n2);
        l2 = m2.a(n2, this.g) + l2;
        n2 = m3.c();
        long l3 = m3.c(n2);
        if (l2 == l3) {
            int n3 = this.h;
            this.h = m2.a(this.g) + 1 - n2 + n3;
            return;
        }
        if (l2 < l3) {
            if (!this.i) throw new a();
            int n4 = this.h;
            this.h = m2.a(this.g) + 1 - n2 + n4;
            new StringBuilder("Discontinuity detected for live, oldIndexEndTimeUs is ").append(l2).append(", newIndexStartTimeUs is ").append(l3).append(", segmentNumberShift is ").append(this.h).append(", representation id is ").append(this.c.e.a);
            return;
        }
        int n5 = this.h;
        this.h = m2.a(l3, this.g) - n2 + n5;
    }

    public final int b() {
        return this.d.a(this.g) + this.h;
    }

    public final long b(int n2) {
        return this.a(n2) + this.d.a(i.f(this, n2), this.g);
    }

    public final boolean b(long l2) {
        int n2 = this.d.a(this.g);
        long l3 = this.f;
        long l4 = this.d.c(n2);
        if (l2 >= this.d.a(n2, this.g) + (l3 + l4)) {
            return true;
        }
        return false;
    }

    public final boolean c(int n2) {
        int n3 = this.d.a(this.g);
        if (n3 != -1 && n2 > n3 + this.h) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final int d(int n2) {
        if (!this.j) {
            return n2;
        }
        if (n2 < this.d.c() + this.h) {
            return this.d.c() + this.h;
        }
        if (n2 <= this.b()) return n2;
        return this.b();
    }

    public final k e(int n2) {
        return this.d.a(i.f(this, n2));
    }
}

