/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g;

import com.d.a.a.b.d;
import com.d.a.a.e.c;
import com.d.a.a.g.a.a;
import com.d.a.a.g.a.l;
import com.d.a.a.g.a.n;
import com.d.a.a.g.a.o;
import com.d.a.a.g.h;
import com.d.a.a.g.i;
import com.d.a.a.g.m;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class j {
    public final int a;
    public final long b;
    public final HashMap<String, i> c;
    d d;
    boolean e;
    boolean f;
    long g;
    private final int[] h;
    private long i;

    /*
     * Enabled aggressive block sorting
     */
    public j(int n2, a list, int n3, h object, boolean bl2, boolean bl3, boolean bl4) {
        this.a = n2;
        Object object2 = list.k.get(n3);
        long l2 = j.a(list, n3);
        l l3 = object2.c.get(object.d);
        list = l3.c;
        this.b = object2.b * 1000;
        this.d = j.a(l3);
        n2 = object.f != null ? 1 : 0;
        if (n2 == 0) {
            this.h = new int[]{j.a(list, object.e.a)};
        } else {
            this.h = new int[object.f.length];
            for (n2 = 0; n2 < object.f.length; ++n2) {
                this.h[n2] = j.a(list, object.f[n2].a);
            }
        }
        this.c = new HashMap();
        n2 = 0;
        do {
            if (n2 >= this.h.length) {
                this.a(l2, list.get(this.h[0]));
                return;
            }
            object = list.get(this.h[n2]);
            object2 = new i(this.b, l2, (com.d.a.a.g.a.j)object, bl2, bl3, bl4);
            this.c.put(object.e.a, (i)object2);
            ++n2;
        } while (true);
    }

    private static int a(List<com.d.a.a.g.a.j> list, String string) {
        for (int i2 = 0; i2 < list.size(); ++i2) {
            if (!string.equals(list.get((int)i2).e.a)) continue;
            return i2;
        }
        throw new IllegalStateException("Missing format id: " + string);
    }

    private static long a(a a2, int n2) {
        long l2 = a2.a(n2);
        if (l2 == -1) {
            return -1;
        }
        return 1000 * l2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static d a(l l2) {
        UUID uUID = null;
        Object object = null;
        if (!l2.d.isEmpty()) {
            int n2 = 0;
            do {
                object = uUID;
                if (n2 >= l2.d.size()) break;
                Object object2 = l2.d.get(n2);
                object = uUID;
                if (object2.b != null) {
                    object = uUID;
                    if (object2.c != null) {
                        object = uUID;
                        if (uUID == null) {
                            object = new com.d.a.a.b.a();
                        }
                        uUID = object2.b;
                        object2 = object2.c;
                        object.a.put(uUID, (com.d.a.a.b.c)object2);
                    }
                }
                ++n2;
                uUID = object;
            } while (true);
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(long l2, com.d.a.a.g.a.j object) {
        boolean bl2 = true;
        if ((object = object.b()) == null) {
            this.e = false;
            this.f = true;
            this.g = this.b;
            this.i = this.b + l2;
            return;
        }
        int n2 = object.c();
        int n3 = object.a(l2);
        if (n3 != -1) {
            bl2 = false;
        }
        this.e = bl2;
        this.f = object.d();
        this.g = this.b + object.c(n2);
        if (!this.e) {
            this.i = this.b + object.c(n3) + object.a(n3, l2);
        }
    }

    public final long a() {
        if (this.e) {
            throw new IllegalStateException("Period has unbounded index");
        }
        return this.i;
    }

    public final void a(a object, int n2, h object2) {
        n n3 = object.k.get(n2);
        long l2 = j.a((a)object, n2);
        object = n3.c.get((int)object2.d).c;
        for (n2 = 0; n2 < this.h.length; ++n2) {
            object2 = (com.d.a.a.g.a.j)object.get(this.h[n2]);
            this.c.get(object2.e.a).a(l2, (com.d.a.a.g.a.j)object2);
        }
        this.a(l2, (com.d.a.a.g.a.j)object.get(this.h[0]));
    }
}

