/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g;

import com.d.a.a.g.e;

final class k {
    static final /* synthetic */ int[] a;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        a = new int[e.values().length];
        try {
            k.a[e.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError var0_1) {}
        try {
            k.a[e.c.ordinal()] = 2;
            return;
        }
        catch (NoSuchFieldError var0) {
            return;
        }
    }
}

