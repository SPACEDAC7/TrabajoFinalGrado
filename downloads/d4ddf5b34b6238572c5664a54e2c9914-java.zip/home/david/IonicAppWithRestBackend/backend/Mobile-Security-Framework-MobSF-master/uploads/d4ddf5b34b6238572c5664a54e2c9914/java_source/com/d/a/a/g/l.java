/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.util.Log
 *  android.util.SparseArray
 *  com.d.a.a.d.a
 *  com.d.a.a.g.b
 *  com.d.a.a.g.c
 */
package com.d.a.a.g;

import android.net.Uri;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.util.SparseArray;
import com.d.a.a.a;
import com.d.a.a.bf;
import com.d.a.a.bg;
import com.d.a.a.bh;
import com.d.a.a.d.ab;
import com.d.a.a.d.ae;
import com.d.a.a.d.af;
import com.d.a.a.e.aa;
import com.d.a.a.e.ad;
import com.d.a.a.e.ag;
import com.d.a.a.e.z;
import com.d.a.a.g.b;
import com.d.a.a.g.c;
import com.d.a.a.g.d;
import com.d.a.a.g.e;
import com.d.a.a.g.f;
import com.d.a.a.g.g;
import com.d.a.a.g.h;
import com.d.a.a.g.i;
import com.d.a.a.g.j;
import com.d.a.a.g.k;
import com.d.a.a.g.m;
import com.d.a.a.g.n;
import com.d.a.a.g.o;
import com.d.a.a.q;
import com.instagram.exoplayer.service.p;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public final class l {
    private final boolean A;
    private final boolean B;
    private boolean C = false;
    private com.d.a.a.g.a.a D;
    private com.d.a.a.g.a.a E;
    private h F;
    private int G;
    private bh H;
    private boolean I;
    private boolean J;
    private boolean K;
    private boolean L;
    private boolean M;
    private IOException N;
    private long O;
    private long P;
    final p a;
    final int b;
    private final Handler c;
    private final com.d.a.a.a.h d;
    private final ad e;
    private final aa f;
    private final com.d.a.a.d.m<com.d.a.a.g.a.a> g;
    private final o h;
    private final ArrayList<h> i;
    private final SparseArray<j> j;
    private final ae k;
    private final long l;
    private final long m;
    private final long[] n;
    private final boolean o;
    private final boolean p;
    private final boolean q;
    private final int r;
    private final int s;
    private final long t;
    private final e u;
    private final long v;
    private final boolean w;
    private final boolean x;
    private final boolean y;
    private final boolean z;

    private l(com.d.a.a.d.m<com.d.a.a.g.a.a> m2, com.d.a.a.g.a.a a2, b b2, com.d.a.a.a.h h2, ad ad2, com.d.a.a.d.a a3, long l2, long l3, boolean bl2, Handler handler, c c2, int n2, boolean bl3, boolean bl4, int n3, int n4, long l4, e e2, long l5, boolean bl5, boolean bl6, boolean bl7, boolean bl8, boolean bl9, boolean bl10) {
        this.g = m2;
        this.D = a2;
        this.h = b2;
        this.d = h2;
        this.e = ad2;
        this.k = a3;
        this.l = l2;
        this.m = 0;
        this.J = bl2;
        this.c = handler;
        this.a = c2;
        this.b = 0;
        this.f = new aa();
        this.n = new long[2];
        this.p = bl3;
        this.q = bl4;
        this.r = n3 * 1000;
        this.s = n4 * 1000;
        this.t = l4;
        this.u = e2;
        this.v = l5;
        this.j = new SparseArray();
        this.i = new ArrayList();
        this.o = a2.e;
        this.w = bl5;
        this.x = bl6;
        this.y = bl7;
        this.z = bl8;
        this.A = bl9;
        this.B = bl10;
    }

    public l(com.d.a.a.d.m<com.d.a.a.g.a.a> m2, b b2, com.d.a.a.a.h h2, ad ad2, long l2, Handler handler, c c2, boolean bl2, int n2, int n3, long l3, e e2, long l4, boolean bl3, boolean bl4, boolean bl5, boolean bl6, boolean bl7, boolean bl8) {
        this(m2, (com.d.a.a.g.a.a)m2.m, (o)b2, h2, ad2, new ae(), l2 * 1000, 0, true, handler, (p)c2, 0, true, bl2, n2, n3, l3, e2, l4, bl3, bl4, bl5, bl6, bl7, bl8);
    }

    public l(com.d.a.a.g.a.a a2, o o2, com.d.a.a.a.h h2, ad ad2) {
        this(a2, o2, h2, ad2, new ae(), false);
    }

    private l(com.d.a.a.g.a.a a2, b b2, com.d.a.a.a.h h2, ad ad2, com.d.a.a.d.a a3, boolean bl2) {
        this(null, a2, (o)b2, h2, ad2, (ae)a3, 0, 0, false, null, null, 0, false, false, 0, 0, 0, e.a, 0, false, false, false, false, false, false);
    }

    private static q a(int n2, com.d.a.a.e.c c2, String string, long l2) {
        switch (n2) {
            default: {
                return null;
            }
            case 0: {
                return q.a(c2.a, string, c2.c, -1, l2, c2.f, c2.g, null, -1, -1.0f);
            }
            case 1: {
                return q.a(c2.a, string, c2.c, -1, l2, c2.i, c2.j, null, c2.l);
            }
            case 2: 
        }
        return q.a(c2.a, string, c2.c, l2, c2.l, Long.MAX_VALUE);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static String a(com.d.a.a.e.c object) {
        String string;
        String string2 = object.b;
        if (ab.a(string2).equals("audio")) {
            object = object.k;
            if (object == null) return "audio/x-unknown";
            object = object.split(",");
            int n2 = object.length;
            int n3 = 0;
            while (n3 < n2) {
                string = object[n3].trim();
                if (string.startsWith("mp4a")) {
                    return "audio/mp4a-latm";
                }
                if (string.startsWith("ac-3")) return "audio/ac3";
                if (string.startsWith("dac3")) {
                    return "audio/ac3";
                }
                if (string.startsWith("ec-3")) return "audio/eac3";
                if (string.startsWith("dec3")) {
                    return "audio/eac3";
                }
                if (string.startsWith("dtsc")) {
                    return "audio/vnd.dts";
                }
                if (string.startsWith("dtsh")) return "audio/vnd.dts.hd";
                if (string.startsWith("dtsl")) {
                    return "audio/vnd.dts.hd";
                }
                if (string.startsWith("dtse")) {
                    return "audio/vnd.dts.hd;profile=lbr";
                }
                if (string.startsWith("opus")) {
                    return "audio/opus";
                }
                if (string.startsWith("vorbis")) {
                    return "audio/vorbis";
                }
                ++n3;
            }
            return "audio/x-unknown";
        }
        if (ab.a(string2).equals("video")) {
            return ab.b(object.k);
        }
        string = string2;
        if (l.a(string2)) return string;
        if (!"application/mp4".equals(string2)) return null;
        if ("stpp".equals(object.k)) {
            return "application/ttml+xml";
        }
        if (!"wvtt".equals(object.k)) return null;
        return "application/x-mp4vtt";
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void a(com.d.a.a.g.a.a var1_1) {
        block22 : {
            block21 : {
                if (!this.x || this.C) ** GOTO lbl55
                var18_3 = var1_1.k.get(0);
                var2_4 = var18_3.a(0);
                var19_5 = var2_4 != -1 ? var18_3.c.get(var2_4) : null;
                if (var19_5 == null) ** GOTO lbl-1000
                var21_6 = new HashSet<String>();
                var22_7 = var19_5.c.iterator();
                var7_8 = -1;
                var5_9 = -1;
                var2_4 = 0;
                var18_3 = null;
                while (var22_7.hasNext()) {
                    var20_15 = var22_7.next();
                    if (var20_15 instanceof com.d.a.a.g.a.i) {
                        var21_6.add(var20_15.e.a);
                        var20_15 = (com.d.a.a.g.a.i)var20_15;
                        if (var7_8 == -1) {
                            var2_4 = var20_15.a.a;
                            var3_10 = var20_15.a.a(-1);
                            var7_8 = var20_15.a.a(var2_4);
                            var5_9 = var20_15.a.a(var3_10);
                            var9_12 = var20_15.a(var3_10, -1);
                            var5_9 = var9_12 + var5_9;
                            var2_4 = var3_10 - var2_4 + 1;
                            var18_3 = var20_15;
                            continue;
                        }
                        var3_10 = var20_15.a.a;
                        var4_11 = var20_15.a.a(-1);
                        var9_12 = var20_15.a.a(var3_10);
                        var11_13 = var20_15.a.a(var4_11);
                        var13_14 = var20_15.a(var4_11, -1);
                        if (var4_11 - var3_10 + 1 == var2_4 && var9_12 == var7_8 && var11_13 + var13_14 == var5_9) continue;
                        this.g.a(var18_3.toString(), var20_15.toString());
                        var17_16 = true;
                        break block21;
                    }
                    ** GOTO lbl-1000
                }
                if (!this.y || this.D == null) ** GOTO lbl-1000
                var2_4 = this.D.k.get(0).a(0);
                var20_15 = null;
                if (var2_4 != -1) {
                    var20_15 = this.D.k.get((int)0).c.get(var2_4);
                }
                if (var20_15 != null && var19_5.c.size() < var20_15.c.size()) {
                    var20_15 = var20_15.c.iterator();
                    while (var20_15.hasNext()) {
                        var19_5 = var20_15.next();
                        if (var21_6.contains(var19_5.e.a)) continue;
                        var20_15 = this.g;
                        var18_3 = var18_3 != null ? var18_3.toString() : null;
                        var20_15.a((String)var18_3, "Missing representation:" + var19_5.e.a);
                        var17_16 = true;
                        break;
                    }
                } else lbl-1000: // 5 sources:
                {
                    var17_16 = false;
                }
            }
            this.C = var17_16;
lbl55: // 2 sources:
            var18_3 = var1_1.k.get(0);
            while (this.j.size() > 0 && ((j)this.j.valueAt((int)0)).b < var18_3.b * 1000) {
                var19_5 = (j)this.j.valueAt(0);
                this.j.remove(var19_5.a);
            }
            if (this.j.size() > var1_1.k.size()) {
                return;
            }
            try {
                var2_4 = this.j.size();
                if (var2_4 > 0) {
                    ((j)this.j.valueAt(0)).a(var1_1, 0, this.F);
                    if (var2_4 > 1) {
                        ((j)this.j.valueAt(var2_4)).a(var1_1, --var2_4, this.F);
                    }
                }
                if (!this.x || this.C || !this.y || !this.e()) break block22;
                this.C = true;
            }
            catch (a var1_2) {
                this.N = var1_2;
                return;
            }
        }
        for (var2_4 = this.j.size(); var2_4 < var1_1.k.size(); ++this.G, ++var2_4) {
            var18_3 = new j(this.G, var1_1, var2_4, this.F, this.p, this.w, this.A);
            this.j.put(this.G, var18_3);
        }
        var5_9 = this.m != 0 ? this.k.a() * 1000 + this.m : System.currentTimeMillis() * 1000;
        var18_3 = (j)this.j.valueAt(0);
        var19_5 = (j)this.j.valueAt(this.j.size() - 1);
        if (!this.D.e || var19_5.f) {
            var18_3 = new bf(var18_3.g, var19_5.a());
        } else {
            var11_13 = var18_3.g;
            var7_8 = var19_5.e != false ? Long.MAX_VALUE : var19_5.a();
            var13_14 = this.k.a();
            var15_17 = this.D.a;
            var9_12 = this.D.g == -1 ? -1 : 1000 * this.D.g;
            var18_3 = new bg(var11_13, var7_8, var13_14 * 1000 - (var5_9 - var15_17 * 1000), var9_12, this.k);
        }
        if (this.H == null || !this.H.equals(var18_3)) {
            var18_3 = this.H = var18_3;
            if (this.c != null && this.a != null) {
                this.c.post((Runnable)new f(this, (bh)var18_3));
            }
        } else if (this.c != null && this.a != null) {
            this.c.post((Runnable)new g(this, (bh)var18_3));
        }
        this.L = false;
        this.D = var1_1;
    }

    static boolean a(String string) {
        if ("text/vtt".equals(string) || "application/ttml+xml".equals(string)) {
            return true;
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private j b(long var1_1) {
        var3_2 = 0;
        if (var1_1 >= ((j)this.j.valueAt((int)0)).g) ** GOTO lbl5
        return (j)this.j.valueAt(0);
lbl-1000: // 1 sources:
        {
            ++var3_2;
lbl5: // 2 sources:
            if (var3_2 >= this.j.size() - 1) return (j)this.j.valueAt(this.j.size() - 1);
            ** while (var1_1 >= (var4_3 = (j)this.j.valueAt((int)var3_2)).a())
        }
lbl7: // 1 sources:
        return var4_3;
    }

    private boolean e() {
        if (this.j.size() > 0) {
            j j2 = (j)this.j.valueAt(0);
            int n2 = -1;
            for (i i2 : j2.c.values()) {
                if (n2 < 0) {
                    n2 = i2.h;
                    continue;
                }
                if (n2 == i2.h) continue;
                return true;
            }
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final int a(i var1_1, long var2_3, boolean var4_4, List<? extends com.d.a.a.e.e> var5_5, int var6_6) {
        block15 : {
            if (var5_5.isEmpty()) {
                var8_7 = 0;
            } else {
                var8_7 = var6_6;
                if (!this.B) {
                    var8_7 = var5_5.size();
                }
            }
            if (var5_5.isEmpty()) {
                var6_6 = var1_1.a(var2_3);
            } else if (var4_4) {
                var6_6 = var1_1.a();
            } else {
                var16_8 = (com.d.a.a.e.e)var5_5.get(var8_7 - 1);
                var6_6 = this.C && this.y && !var16_8.j.a.equals(var1_1.c.e.a) ? (var1_1.b(var16_8.f) ? var1_1.b() + 1 : var1_1.a(var16_8.f)) : var1_1.d(var16_8.g + 1);
            }
            var9_9 = var6_6;
            if (this.o == false) return var9_9;
            var9_9 = var6_6;
            if (this.q == false) return var9_9;
            var9_9 = var6_6;
            if (var5_5.isEmpty() != false) return var9_9;
            var9_9 = var6_6;
            if (var6_6 >= var1_1.b()) return var9_9;
            var12_10 = this.t;
            var2_3 = 0;
            var5_5 = var5_5.iterator();
            while (var5_5.hasNext()) {
                var16_8 = (com.d.a.a.e.e)var5_5.next();
                var14_12 = var16_8.f - var16_8.e;
                var10_11 = var2_3;
                if (var14_12 >= 0) {
                    var10_11 = var2_3 + var14_12;
                }
                var2_3 = var10_11;
                if (var10_11 < var12_10) continue;
                var7_13 = 1;
                break block15;
            }
            var7_13 = 0;
        }
        var9_9 = var6_6;
        if (var7_13 == 0) return var9_9;
        var7_13 = this.s > 0 ? var1_1.a(Math.max(this.n[0], this.n[1] - (long)this.s)) : var1_1.b();
        if (var7_13 == var6_6) ** GOTO lbl-1000
        ** try [egrp 0[TRYBLOCK] [0 : 211->239)] { 
lbl-1000: // 2 sources:
        {
            catch (d var1_2) {}
        }
lbl44: // 1 sources:
        if (this.r > 0 && (var2_3 = var1_1.a(var7_13)) - (var10_11 = var1_1.a(var6_6)) > (long)(var9_9 = this.r)) {
            var6_6 = var7_13;
        } else lbl-1000: // 2 sources:
        {
            var9_9 = this.r;
            if (var9_9 == 0) {
                var6_6 = var7_13;
            }
        }
        new StringBuilder("Buffered duration is greater than ").append(this.t).append(", jumping to ").append(var6_6).append(", queue size is ").append(var8_7);
        return var6_6;
    }

    public final q a(int n2) {
        return this.i.get((int)n2).a;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void a() {
        if (this.N != null) {
            throw this.N;
        }
        if (this.g == null) return;
        com.d.a.a.d.m<com.d.a.a.g.a.a> m2 = this.g;
        if (m2.l != null && m2.j > 1) throw m2.l;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(long l2) {
        long l3;
        if (this.g == null) return;
        if (!this.D.e) return;
        if (this.N != null) {
            return;
        }
        Object object = (com.d.a.a.g.a.a)this.g.m;
        if (object != null && object != this.E) {
            this.a((com.d.a.a.g.a.a)object);
            this.E = object;
        }
        long l4 = l3 = this.D.f;
        if (l3 == 0) {
            l4 = 5000;
        }
        l3 = SystemClock.elapsedRealtime();
        if (l2 != this.O) {
            this.O = l2;
            this.P = l3;
        }
        boolean bl2 = true;
        switch (k.a[this.u.ordinal()]) {
            case 1: {
                bl2 = this.M;
            }
            default: {
                break;
            }
            case 2: {
                bl2 = this.L;
            }
        }
        boolean bl3 = bl2;
        if (bl2) {
            bl3 = bl2;
            if (this.v > 0) {
                bl3 = bl2;
                if (l3 > this.v + this.P) {
                    return;
                }
            }
        }
        if (!bl3) return;
        if (l3 <= l4 + this.g.n) return;
        object = this.g;
        if (object.l != null) {
            l2 = SystemClock.elapsedRealtime();
            l4 = object.k;
            if (l2 < Math.min(((long)object.j - 1) * 1000, 5000) + l4) return;
        }
        if (object.g == null) {
            object.g = new com.d.a.a.a.g("manifestLoader");
        }
        if (object.g.b) return;
        object.h = new com.d.a.a.a.k(object.e, object.b, object.a);
        object.i = SystemClock.elapsedRealtime();
        object.g.a(object.h, (com.d.a.a.a.e)object);
        if (object.c == null) return;
        if (object.d == null) return;
        object.c.post((Runnable)new com.d.a.a.d.i((com.d.a.a.d.m)object));
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(com.d.a.a.e.f f2) {
        if (!(f2 instanceof com.d.a.a.e.af)) return;
        f2 = (com.d.a.a.e.af)f2;
        Object object = f2.j.a;
        j j2 = (j)this.j.get(f2.l);
        if (j2 == null) {
            return;
        }
        object = j2.c.get(object);
        boolean bl2 = f2.a != null;
        if (bl2) {
            object.e = f2.a;
        }
        if (object.d == null) {
            bl2 = f2.c != null;
            if (bl2) {
                object.d = new n((com.d.a.a.f.l)f2.c, f2.k.a.toString());
            }
        }
        if (j2.d != null) return;
        if (f2.b == null) return;
        bl2 = true;
        if (!bl2) return;
        j2.d = f2.b;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(com.d.a.a.g.a.a object, int n2, int n3, int n4) {
        com.d.a.a.g.a.l l2 = object.k.get((int)0).c.get(n3);
        com.d.a.a.e.c c2 = l2.c.get((int)n4).e;
        String string = l.a(c2);
        if (string == null) {
            Log.w((String)"DashChunkSource", (String)("Skipped track " + c2.a + " (unknown media mime type)"));
            return;
        }
        n2 = l2.b;
        long l3 = object.e ? -1 : object.c * 1000;
        object = l.a(n2, c2, string, l3);
        if (object == null) {
            Log.w((String)"DashChunkSource", (String)("Skipped track " + c2.a + " (unknown media format)"));
            return;
        }
        this.i.add(new h((q)object, n3, c2));
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(com.d.a.a.g.a.a object, int n2, int n3, int[] arrn) {
        if (this.e == null) {
            Log.w((String)"DashChunkSource", (String)"Skipping adaptive track (missing format evaluator)");
            return;
        }
        com.d.a.a.g.a.l l2 = object.k.get((int)0).c.get(n3);
        com.d.a.a.e.c c2 = null;
        com.d.a.a.e.c[] arrc = new com.d.a.a.e.c[arrn.length];
        int n4 = 0;
        int n5 = 0;
        for (n2 = 0; n2 < arrc.length; ++n2) {
            com.d.a.a.e.c c3 = l2.c.get((int)arrn[n2]).e;
            if (c2 == null || c3.g > n4) {
                c2 = c3;
            }
            n5 = Math.max(n5, c3.f);
            n4 = Math.max(n4, c3.g);
            arrc[n2] = c3;
        }
        Arrays.sort(arrc, new com.d.a.a.e.b());
        long l3 = this.o ? -1 : object.c * 1000;
        object = l.a(c2);
        if (object == null) {
            Log.w((String)"DashChunkSource", (String)"Skipped adaptive track (unknown media mime type)");
            return;
        }
        if ((object = l.a(l2.b, c2, (String)object, l3)) == null) {
            Log.w((String)"DashChunkSource", (String)"Skipped adaptive track (unknown media format)");
            return;
        }
        this.i.add(new h(new q(null, object.b, -1, -1, object.e, -1, -1, -1, -1.0f, -1, -1, null, Long.MAX_VALUE, null, true, object.j, object.k, -1, -1), n3, arrc, n5, n4));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    public final void a(List<? extends com.d.a.a.e.e> var1_1, long var2_3, com.d.a.a.e.i var4_4) {
        block47 : {
            block52 : {
                block49 : {
                    block50 : {
                        block51 : {
                            block48 : {
                                block45 : {
                                    block46 : {
                                        block43 : {
                                            block44 : {
                                                block42 : {
                                                    block41 : {
                                                        if (this.N != null) {
                                                            var4_4.b = null;
lbl3: // 5 sources:
                                                            do {
                                                                return;
                                                                break;
                                                            } while (true);
                                                        }
                                                        this.f.a = var1_1.size();
                                                        if (this.f.c != null && this.K) ** GOTO lbl25
                                                        if (this.F.f == null) ** GOTO lbl21
                                                        var5_5 = 1;
lbl9: // 2 sources:
                                                        while (var5_5 != 0) {
                                                            if (this.f.c != null && this.C && !this.z) break block41;
                                                            this.e.a((List<? extends com.d.a.a.e.e>)var1_1, var2_3, this.F.f, this.f);
                                                            var5_5 = 1;
lbl13: // 2 sources:
                                                            do {
                                                                var18_6 = this.f.c;
                                                                var4_4.a = this.f.a;
                                                                if (var18_6 == null) {
                                                                    var4_4.b = null;
                                                                    return;
                                                                }
                                                                break block42;
                                                                break;
                                                            } while (true);
                                                        }
                                                        ** GOTO lbl23
lbl21: // 1 sources:
                                                        var5_5 = 0;
                                                        ** GOTO lbl9
lbl23: // 1 sources:
                                                        this.f.c = this.F.e;
                                                        this.f.b = 2;
                                                    }
                                                    var5_5 = 0;
                                                    ** while (true)
                                                }
                                                if (var4_4.a == var1_1.size() && var4_4.b != null && var4_4.b.j.equals(var18_6)) ** GOTO lbl3
                                                var4_4.b = null;
                                                var16_7 = false;
                                                if (!this.C || !this.y) ** GOTO lbl96
                                                var6_8 = 1;
lbl34: // 2 sources:
                                                do {
                                                    if (var6_8 == 0) break block43;
                                                    if (!var1_1.isEmpty()) break block44;
                                                    var19_9 = null;
lbl38: // 2 sources:
                                                    do {
                                                        if (var19_9 != null && !var19_9.j.a.equals(var18_6.a)) {
                                                            var20_10 = (j)this.j.valueAt(this.j.size() - 1);
                                                            var21_12 = var20_10.c.get(var19_9.j.a);
                                                            if (var20_10.c.get(var18_6.a).b(var19_9.f) && !var21_12.c(var19_9.g + 1)) {
                                                                var18_6 = var19_9.j;
                                                            }
                                                        }
                                                        var20_10 = var18_6.a;
                                                        var19_9 = this.n;
                                                        var20_10 = ((j)this.j.valueAt((int)0)).c.get(var20_10);
                                                        var7_13 = var20_10.d.c();
                                                        var19_9[0] = var20_10.f + var20_10.d.c(var7_13);
                                                        var7_13 = var20_10.d.a(var20_10.g);
                                                        var19_9[1] = var20_10.f + var20_10.d.c(var7_13) + var20_10.d.a(var7_13, var20_10.g);
                                                        var19_9 = var18_6;
lbl52: // 2 sources:
                                                        do {
                                                            if (!var1_1.isEmpty()) break block45;
                                                            var8_14 = var2_3;
                                                            if (this.o) {
                                                                if (!this.J) break block46;
                                                                var8_14 = Math.max(this.n[0], this.n[1] - this.l);
                                                            }
lbl58: // 4 sources:
                                                            do {
                                                                var18_6 = this.b(var8_14);
                                                                var16_7 = true;
                                                                var2_3 = var8_14;
lbl62: // 6 sources:
                                                                do {
                                                                    if (var5_5 != 0) ** GOTO lbl69
                                                                    if (!this.K) break block47;
                                                                    if (this.F.f == null) break block48;
                                                                    var5_5 = 1;
lbl67: // 2 sources:
                                                                    do {
                                                                        if (var5_5 == 0) break block47;
lbl69: // 2 sources:
                                                                        if ((var20_10 = this.e.a((List<? extends com.d.a.a.e.e>)var1_1, var4_4.a, var2_3, this.F.f, (j)var18_6, var16_7, this)) == null) break block47;
lbl70: // 2 sources:
                                                                        var23_16 = var18_6.c.get(var20_10.a);
                                                                        var22_17 = var23_16.c;
                                                                        var20_10 = null;
                                                                        var21_12 = null;
                                                                        var24_18 = var23_16.e;
                                                                        if (var24_18 == null) {
                                                                            var20_10 = var22_17.h;
                                                                        }
                                                                        if (var23_16.d == null) {
                                                                            var21_12 = var22_17.a();
                                                                        }
                                                                        if (var20_10 == null && var21_12 == null) break block49;
                                                                        var19_9 = var23_16.b;
                                                                        var23_16 = this.d;
                                                                        var5_5 = var18_6.a;
                                                                        var6_8 = this.f.b;
                                                                        if (var20_10 == null) break block50;
                                                                        if (var21_12 == null || !af.a(var20_10.c, var20_10.d).equals(af.a(var21_12.c, var21_12.d))) {
                                                                            var1_1 = null;
lbl87: // 4 sources:
                                                                            do {
                                                                                if (var1_1 == null) {
                                                                                    var1_1 = var20_10;
                                                                                }
lbl90: // 4 sources:
                                                                                do {
                                                                                    var1_1 = new com.d.a.a.e.af((com.d.a.a.a.h)var23_16, new com.d.a.a.a.i(var1_1.a(), var1_1.a, var1_1.b, var22_17.g), var6_8, var22_17.e, (com.d.a.a.e.h)var19_9, var5_5);
                                                                                    this.K = true;
                                                                                    var4_4.b = var1_1;
                                                                                    return;
                                                                                    break;
                                                                                } while (true);
                                                                                break;
                                                                            } while (true);
                                                                        }
                                                                        break block51;
                                                                        break;
                                                                    } while (true);
                                                                    break;
                                                                } while (true);
                                                                break;
                                                            } while (true);
                                                            break;
                                                        } while (true);
                                                        break;
                                                    } while (true);
                                                    break;
                                                } while (true);
lbl96: // 1 sources:
                                                var6_8 = 0;
                                                ** while (true)
                                            }
                                            var19_9 = (com.d.a.a.e.e)var1_1.get(var4_4.a - 1);
                                            ** while (true)
                                        }
                                        this.H.b(this.n);
                                        var19_9 = var18_6;
                                        ** while (true)
                                    }
                                    var8_14 = Math.max(Math.min(var2_3, this.n[1] - 1), this.n[0]);
                                    ** while (true)
                                }
                                if (this.J) {
                                    this.J = false;
                                }
                                var21_12 = (com.d.a.a.e.e)var1_1.get(var4_4.a - 1);
                                var8_14 = var21_12.f;
                                if (!this.o || var8_14 >= this.n[0]) ** GOTO lbl129
                                if (!this.p) ** GOTO lbl127
                                new StringBuilder("Discontinuity detected for live: nextSegmentStartTimeUs is ").append(var8_14).append(", availableRangeStartTimeUs is ").append(this.n[0]).append(", representation id is ").append(var19_9.a);
                                var2_3 = Math.max(Math.min(var2_3, this.n[1] - 1), this.n[0]);
                                var18_6 = this.b(var2_3);
                                var16_7 = true;
                                var6_8 = 1;
lbl120: // 2 sources:
                                if (var6_8 != 0) ** GOTO lbl62
                                var17_15 = false;
                                var20_10 = (j)this.j.get(var21_12.l);
                                if (var20_10 != null) ** GOTO lbl144
                                var18_6 = (j)this.j.valueAt(0);
                                var16_7 = true;
                                ** GOTO lbl62
lbl127: // 1 sources:
                                this.N = new a();
                                return;
lbl129: // 1 sources:
                                if (!this.D.e || var8_14 < this.n[1]) ** GOTO lbl134
                                this.L = true;
                                if (this.M) ** GOTO lbl3
                                this.M = true;
                                return;
lbl134: // 1 sources:
                                var18_6 = (j)this.j.valueAt(this.j.size() - 1);
                                if (var21_12.l != var18_6.a || !var18_6.c.get(var21_12.j.a).c(var21_12.g + 1)) ** GOTO lbl139
                                if (this.D.e) ** GOTO lbl3
                                var4_4.c = true;
                                return;
lbl139: // 1 sources:
                                if (var6_8 != 0 && !var19_9.a.equals(var21_12.j.a) && var18_6.c.get(var19_9.a).b(var21_12.f)) {
                                    if (this.D.e) ** continue;
                                    var4_4.c = true;
                                    return;
                                }
                                ** GOTO lbl258
lbl144: // 1 sources:
                                var18_6 = var20_10;
                                var16_7 = var17_15;
                                if (var20_10.e) ** GOTO lbl62
                                var18_6 = var20_10;
                                var16_7 = var17_15;
                                if (!var20_10.c.get(var21_12.j.a).c(var21_12.g + 1)) ** GOTO lbl62
                                var18_6 = (j)this.j.get(var21_12.l + 1);
                                var16_7 = true;
                                ** while (true)
                            }
                            var5_5 = 0;
                            ** while (true)
                        }
                        if (var20_10.b == -1 || var20_10.a + var20_10.b != var21_12.a) ** GOTO lbl169
                        var1_1 = var20_10.c;
                        var18_6 = var20_10.d;
                        var8_14 = var20_10.a;
                        if (var21_12.b != -1) ** GOTO lbl166
                        var2_3 = -1;
lbl163: // 2 sources:
                        do {
                            var1_1 = new com.d.a.a.g.a.k((String)var1_1, (String)var18_6, var8_14, var2_3);
                            ** GOTO lbl87
                            break;
                        } while (true);
lbl166: // 1 sources:
                        var2_3 = var20_10.b;
                        var2_3 = var21_12.b + var2_3;
                        ** while (true)
lbl169: // 1 sources:
                        if (var21_12.b == -1 || var21_12.a + var21_12.b != var20_10.a) ** GOTO lbl180
                        var1_1 = var20_10.c;
                        var18_6 = var20_10.d;
                        var8_14 = var21_12.a;
                        if (var20_10.b != -1) ** GOTO lbl178
                        var2_3 = -1;
lbl175: // 2 sources:
                        do {
                            var1_1 = new com.d.a.a.g.a.k((String)var1_1, (String)var18_6, var8_14, var2_3);
                            ** GOTO lbl87
                            break;
                        } while (true);
lbl178: // 1 sources:
                        var2_3 = var21_12.b + var20_10.b;
                        ** while (true)
lbl180: // 1 sources:
                        var1_1 = null;
                        ** while (true)
                    }
                    var1_1 = var21_12;
                    ** while (true)
                }
                var5_5 = this.a((i)var23_16, var2_3, var16_7, (List<? extends com.d.a.a.e.e>)var1_1, var4_4.a);
                if (this.o && var5_5 == var23_16.b()) {
                    this.L = true;
                    if (!this.M) {
                        this.M = true;
                    }
                }
                try {
                    var20_10 = this.d;
                    var21_12 = this.F;
                    var6_8 = this.f.b;
                    var7_13 = var4_4.a;
                    var22_17 = var23_16.c;
                    var25_19 = var22_17.e;
                    var8_14 = var23_16.a(var5_5);
                    var10_20 = var23_16.b(var5_5);
                    var26_21 = var23_16.e(var5_5);
                    var26_21 = new com.d.a.a.a.i(var26_21.a(), var26_21.a, var26_21.a, var26_21.b, var22_17.g, 0, var7_13, (int)(var10_20 - var8_14) / 1000);
                    var12_22 = var18_6.b;
                    var14_23 = var22_17.f;
                    if (!l.a(var25_19.b)) break block52;
                    var1_1 = var20_10 = new ag((com.d.a.a.a.h)var20_10, (com.d.a.a.a.i)var26_21, var25_19, var8_14, var10_20, var5_5, var21_12.a, var18_6.a);
                }
                catch (d var1_2) {
                    this.N = var1_2;
                    return;
                }
                catch (IndexOutOfBoundsException var20_11) {
                    var21_12 = new StringBuilder();
                    var21_12.append("useSegmentShift=" + this.w);
                    var21_12.append(", segmentShift=" + var23_16.h);
                    var21_12.append(", segmentNum=" + var5_5);
                    var21_12.append(", firstAvaiable=" + var23_16.a());
                    var21_12.append(", lastAvaiable=" + var23_16.b());
                    if (var23_16.c instanceof com.d.a.a.g.a.i) {
                        var21_12.append(", " + ((com.d.a.a.g.a.i)var23_16.c).toString());
                    }
                    var21_12.append(", numPeriodHolders=" + this.j.size());
                    var21_12.append(", periodStartTimeUs=" + var23_16.f);
                    var21_12.append(", periodDurationUs=" + var23_16.g);
                    var21_12.append(", availableRangeStart=" + this.n[0]);
                    var21_12.append(", availableRangeEnd=" + this.n[1]);
                    if (!var1_1.isEmpty()) {
                        var22_17 = (com.d.a.a.e.e)var1_1.get(var4_4.a - 1);
                        var24_18 = var22_17.j.a;
                        var21_12.append(", queueSize=" + var1_1.size());
                        var21_12.append(", effectiveQueueSize=" + var4_4.a);
                        var21_12.append(", nextChunkIndex=" + (var22_17.g + 1));
                        var21_12.append(", previousFormatId=" + (String)var24_18);
                        var21_12.append(", previousEndTimeMs=" + var22_17.f);
                        var21_12.append(", isBeyondLastSegement=" + var23_16.b(var22_17.f));
                        if (!var24_18.equals(var23_16.c.e.a)) {
                            var1_1 = var18_6.c.get(var24_18);
                            var21_12.append(", segmentShiftForPrevFormat=" + var1_1.h);
                        }
                    }
                    var21_12.append(", playbackPositionUs=" + var2_3);
                    var21_12.append(", startingNewPeriod=" + var16_7);
                    var21_12.append(", orginalSelectedFormat=" + var19_9.a);
                    var21_12.append(", segmentMisalignmentDetected=" + this.C);
                    var21_12.append(", handleManifestMisalign=" + this.y);
                    var21_12.append(", innerMessage=" + var20_11.getMessage());
                    throw new IndexOutOfBoundsException(var21_12.toString());
                }
lbl206: // 2 sources:
                do {
                    this.K = false;
                    var4_4.b = var1_1;
                    return;
                    break;
                } while (true);
            }
            if (var24_18 != null) {
                var17_15 = true;
lbl213: // 2 sources:
                do {
                    var1_1 = var20_10 = new z((com.d.a.a.a.h)var20_10, (com.d.a.a.a.i)var26_21, var6_8, var25_19, var8_14, var10_20, var5_5, var12_22 - var14_23, var23_16.b, (q)var24_18, var21_12.b, var21_12.c, var18_6.d, var17_15, var18_6.a);
                    ** continue;
                    break;
                } while (true);
            }
            var17_15 = false;
            ** while (true)
        }
        var20_10 = var19_9;
        ** GOTO lbl70
lbl258: // 1 sources:
        var6_8 = 0;
        var18_6 = null;
        ** GOTO lbl120
    }

    public final void b(int n2) {
        this.F = this.i.get(n2);
        if (this.g != null) {
            com.d.a.a.d.m<com.d.a.a.g.a.a> m2 = this.g;
            n2 = m2.f;
            m2.f = n2 + 1;
            if (n2 == 0) {
                m2.j = 0;
                m2.l = null;
            }
            this.a((com.d.a.a.g.a.a)this.g.m);
            return;
        }
        this.a(this.D);
    }

    /*
     * Exception decompiling
     */
    public final boolean b() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 4[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    public final int c() {
        return this.i.size();
    }

    public final void d() {
        if (this.g != null) {
            int n2;
            com.d.a.a.d.m<com.d.a.a.g.a.a> m2 = this.g;
            m2.f = n2 = m2.f - 1;
            if (n2 == 0 && m2.g != null) {
                m2.g.b();
                m2.g = null;
            }
        }
        this.j.clear();
        this.f.c = null;
        this.H = null;
        this.N = null;
        this.F = null;
    }
}

