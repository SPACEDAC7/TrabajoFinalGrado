/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g;

import com.d.a.a.g.a.k;

public interface m {
    public int a(long var1);

    public int a(long var1, long var3);

    public long a(int var1, long var2);

    public k a(int var1);

    public String b(int var1);

    public int c();

    public long c(int var1);

    public boolean d();
}

