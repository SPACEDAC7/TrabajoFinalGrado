/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.g;

import com.d.a.a.d.ah;
import com.d.a.a.f.l;
import com.d.a.a.g.a.k;
import com.d.a.a.g.m;

final class n
implements m {
    private final l a;
    private final String b;

    public n(l l2, String string) {
        this.a = l2;
        this.b = string;
    }

    @Override
    public final int a(long l2) {
        return this.a.b - 1;
    }

    @Override
    public final int a(long l2, long l3) {
        return ah.a(this.a.f, l2, true);
    }

    @Override
    public final long a(int n2, long l2) {
        return this.a.e[n2];
    }

    @Override
    public final k a(int n2) {
        return new k(this.b, null, this.a.d[n2], this.a.c[n2]);
    }

    @Override
    public final String b(int n2) {
        return null;
    }

    @Override
    public final int c() {
        return 0;
    }

    @Override
    public final long c(int n2) {
        return this.a.f[n2];
    }

    @Override
    public final boolean d() {
        return true;
    }
}

