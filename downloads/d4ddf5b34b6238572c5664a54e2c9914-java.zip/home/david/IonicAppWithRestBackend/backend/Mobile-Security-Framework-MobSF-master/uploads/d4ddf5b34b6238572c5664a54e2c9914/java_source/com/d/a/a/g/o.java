/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.d.a.a.g;

import android.content.Context;

public final class o {
    public final int a;
    public final Context b;
    public final boolean c;
    public final boolean d;

    public o(int n2, Context context, boolean bl2, boolean bl3) {
        this.a = n2;
        this.b = context;
        this.c = false;
        this.d = false;
    }
}

