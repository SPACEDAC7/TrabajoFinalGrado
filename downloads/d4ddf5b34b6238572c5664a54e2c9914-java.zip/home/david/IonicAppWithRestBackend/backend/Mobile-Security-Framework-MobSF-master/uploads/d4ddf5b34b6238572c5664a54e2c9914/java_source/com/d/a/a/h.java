/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

final class h {
    public final int a;
    public int b;
    public boolean c;
    public long d;

    public h(int n2) {
        this.a = n2;
        this.b = 0;
        this.c = false;
        this.d = -1;
    }
}

