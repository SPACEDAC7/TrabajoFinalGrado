/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 */
package com.d.a.a.h;

import android.text.Layout;

public class a {
    public final CharSequence a;
    public final Layout.Alignment b;
    public final float c;
    public final int d;
    public final int e;
    public final float f;
    public final int g;
    public final float h;

    public a() {
        this(null);
    }

    public a(CharSequence charSequence) {
        this(charSequence, null, Float.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE);
    }

    public a(CharSequence charSequence, Layout.Alignment alignment, float f2, int n2, int n3, float f3, int n4, float f4) {
        this.a = charSequence;
        this.b = alignment;
        this.c = f2;
        this.d = n2;
        this.e = n3;
        this.f = f3;
        this.g = n4;
        this.h = f4;
    }
}

