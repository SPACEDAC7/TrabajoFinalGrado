/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.a;

abstract class a {
    public final int a;

    protected a(int n2) {
        this.a = n2;
    }
}

