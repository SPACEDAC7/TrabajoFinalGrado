/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.a;

import com.d.a.a.h.a.a;

final class b
extends a {
    public final byte b;
    public final byte c;

    protected b(byte by2, byte by3) {
        super(0);
        this.b = by2;
        this.c = by3;
    }
}

