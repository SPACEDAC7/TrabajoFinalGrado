/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.a;

import com.d.a.a.h.a.a;

final class c
implements Comparable<c> {
    public final long a;
    public final boolean b;
    public final a[] c;

    public c(long l2, boolean bl2, a[] arra) {
        this.a = l2;
        this.b = bl2;
        this.c = arra;
    }
}

