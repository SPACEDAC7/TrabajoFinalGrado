/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.a;

import com.d.a.a.h.a.a;

final class d
extends a {
    public final String b;

    public d(String string) {
        super(1);
        this.b = string;
    }
}

