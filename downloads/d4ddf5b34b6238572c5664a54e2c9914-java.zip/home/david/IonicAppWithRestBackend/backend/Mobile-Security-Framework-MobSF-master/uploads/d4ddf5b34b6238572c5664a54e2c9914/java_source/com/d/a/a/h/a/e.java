/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.a;

import com.d.a.a.h.a.a;
import com.d.a.a.h.a.b;
import com.d.a.a.h.a.c;
import com.d.a.a.h.a.d;
import com.d.a.a.z;
import java.nio.ByteBuffer;
import java.util.ArrayList;

public final class e {
    private static final int[] a = new int[]{32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 225, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 233, 93, 237, 243, 250, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 231, 247, 209, 241, 9632};
    private static final int[] b = new int[]{174, 176, 189, 191, 8482, 162, 163, 9834, 224, 32, 232, 226, 234, 238, 244, 251};
    private static final int[] c = new int[]{193, 201, 211, 218, 220, 252, 8216, 161, 42, 39, 8212, 169, 8480, 8226, 8220, 8221, 192, 194, 199, 200, 202, 203, 235, 206, 207, 239, 212, 217, 249, 219, 171, 187};
    private static final int[] d = new int[]{195, 227, 205, 204, 236, 210, 242, 213, 245, 123, 125, 92, 94, 95, 124, 126, 196, 228, 214, 246, 223, 165, 164, 9474, 197, 229, 216, 248, 9484, 9488, 9492, 9496};
    private final com.d.a.a.d.c e = new com.d.a.a.d.c();
    private final StringBuilder f = new StringBuilder();
    private final ArrayList<a> g = new ArrayList();

    e() {
    }

    private static void a(e e2) {
        if (e2.f.length() > 0) {
            e2.g.add(new d(e2.f.toString()));
            e2.f.setLength(0);
        }
    }

    private static void a(e e2, byte by2, byte by3) {
        e.a(e2);
        e2.g.add(new b(by2, by3));
    }

    /*
     * Enabled aggressive block sorting
     */
    final c a(z z2) {
        boolean bl2 = true;
        if (z2.c < 10) {
            return null;
        }
        this.g.clear();
        this.f.setLength(0);
        a[] arra = this.e;
        byte[] arrby = z2.b.array();
        arra.a(arrby, arrby.length);
        this.e.b(67);
        int n2 = this.e.c(5);
        this.e.b(8);
        for (int i2 = 0; i2 < n2; ++i2) {
            this.e.b(5);
            boolean bl3 = this.e.c(1) == 1;
            if (!bl3) {
                this.e.b(18);
                continue;
            }
            if (this.e.c(2) != 0) {
                this.e.b(16);
                continue;
            }
            this.e.b(1);
            byte by2 = (byte)this.e.c(7);
            this.e.b(1);
            byte by3 = (byte)this.e.c(7);
            if (by2 == 0 && by3 == 0) continue;
            if ((by2 == 17 || by2 == 25) && (by3 & 112) == 48) {
                this.f.append((char)b[by3 & 15]);
                continue;
            }
            if ((by2 == 18 || by2 == 26) && (by3 & 96) == 32) {
                e.a(this, 20, 33);
                this.f.append((char)c[by3 & 31]);
                continue;
            }
            if ((by2 == 19 || by2 == 27) && (by3 & 96) == 32) {
                e.a(this, 20, 33);
                this.f.append((char)d[by3 & 31]);
                continue;
            }
            if (by2 < 32) {
                e.a(this, by2, by3);
                continue;
            }
            this.f.append((char)a[(by2 & 127) - 32]);
            if (by3 < 32) continue;
            this.f.append((char)a[(by3 & 127) - 32]);
        }
        e.a(this);
        if (this.g.isEmpty()) {
            return null;
        }
        arra = new a[this.g.size()];
        this.g.toArray(arra);
        long l2 = z2.e;
        if ((z2.d & 134217728) != 0) {
            return new c(l2, bl2, arra);
        }
        bl2 = false;
        return new c(l2, bl2, arra);
    }
}

