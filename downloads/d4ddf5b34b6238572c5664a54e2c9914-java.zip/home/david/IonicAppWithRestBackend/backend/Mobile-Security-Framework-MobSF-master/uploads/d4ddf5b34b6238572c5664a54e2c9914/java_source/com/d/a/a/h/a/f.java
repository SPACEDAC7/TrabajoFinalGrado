/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.Looper
 *  android.os.Message
 */
package com.d.a.a.h.a;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.d.a.a.ar;
import com.d.a.a.d.ah;
import com.d.a.a.h.a;
import com.d.a.a.h.a.b;
import com.d.a.a.h.a.c;
import com.d.a.a.h.a.e;
import com.d.a.a.q;
import com.d.a.a.x;
import com.d.a.a.y;
import com.d.a.a.z;
import com.instagram.exoplayer.service.l;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

public final class f
extends ar
implements Handler.Callback {
    private final e b;
    private final l c;
    private final Handler d;
    private final y e;
    private final z f;
    private final StringBuilder g;
    private final TreeSet<c> h;
    private boolean i;
    private int j;
    private int k;
    private String l;
    private String m;
    private b n;

    /*
     * Enabled aggressive block sorting
     */
    public f(x x2, l l2, Looper looper) {
        super(x2);
        if (l2 == null) {
            throw new NullPointerException();
        }
        this.c = l2;
        x2 = looper == null ? null : new Handler(looper, (Handler.Callback)this);
        this.d = x2;
        this.b = new e();
        this.e = new y();
        this.f = new z(1);
        this.g = new StringBuilder();
        this.h = new TreeSet();
    }

    private void a(String string) {
        if (ah.a(this.m, (Object)string)) {
            return;
        }
        this.m = string;
        if (this.d != null) {
            this.d.obtainMessage(0, (Object)string).sendToTarget();
            return;
        }
        this.b(string);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void b(int n2) {
        if (this.j == n2) {
            return;
        }
        this.j = n2;
        this.g.setLength(0);
        if (n2 != 1) {
            if (n2 != 0) return;
        }
        this.l = null;
    }

    private void b(String string) {
        if (string == null) {
            this.c.a(Collections.<a>emptyList());
            return;
        }
        this.c.a(Collections.singletonList(new a(string)));
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void d(long l2) {
        if (this.f.e > 5000000 + l2) {
            return;
        }
        c c2 = this.b.a(this.f);
        this.r();
        if (c2 == null) return;
        this.h.add(c2);
    }

    private void p() {
        int n2 = this.g.length();
        if (n2 > 0 && this.g.charAt(n2 - 1) != '\n') {
            this.g.append('\n');
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private String q() {
        int n2 = this.g.length();
        if (n2 == 0) {
            return null;
        }
        int n3 = this.g.charAt(n2 - 1) == '\n' ? 1 : 0;
        if (n2 == 1 && n3 != 0) {
            return null;
        }
        int n4 = n2;
        if (n3 != 0) {
            n4 = n2 - 1;
        }
        if (this.j != 1) {
            return this.g.substring(0, n4);
        }
        n2 = n4;
        for (n3 = 0; n3 < this.k && n2 != -1; ++n3) {
            n2 = this.g.lastIndexOf("\n", n2 - 1);
        }
        n3 = n2 != -1 ? n2 + 1 : 0;
        this.g.delete(0, n3);
        return this.g.substring(0, n4 - n3);
    }

    private void r() {
        this.f.e = -1;
        z z2 = this.f;
        if (z2.b != null) {
            z2.b.clear();
        }
    }

    private boolean s() {
        if (this.f.e != -1) {
            return true;
        }
        return false;
    }

    /*
     * Exception decompiling
     */
    @Override
    protected final void a(long var1_1, long var3_2, boolean var5_3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[SWITCH]], but top level block is 7[SWITCH]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    protected final boolean a(q q2) {
        return q2.b.equals("application/eia-608");
    }

    @Override
    protected final void c(long l2) {
        this.i = false;
        this.n = null;
        this.h.clear();
        this.r();
        this.k = 4;
        this.b(0);
        this.a((String)null);
    }

    @Override
    protected final boolean c() {
        return this.i;
    }

    @Override
    protected final boolean d() {
        return true;
    }

    @Override
    protected final long g() {
        return -3;
    }

    public final boolean handleMessage(Message message) {
        switch (message.what) {
            default: {
                return false;
            }
            case 0: 
        }
        this.b((String)message.obj);
        return true;
    }
}

