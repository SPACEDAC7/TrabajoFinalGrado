/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h;

import com.d.a.a.h.a;
import com.d.a.a.h.c;
import java.util.List;

final class b
implements c {
    public final long a;
    final c b;
    final long c;

    /*
     * Enabled aggressive block sorting
     */
    public b(c c2, boolean bl2, long l2, long l3) {
        this.b = c2;
        this.a = l2;
        if (!bl2) {
            l2 = 0;
        }
        this.c = l2 + l3;
    }

    @Override
    public final int a() {
        return this.b.a();
    }

    @Override
    public final int a(long l2) {
        return this.b.a(l2 - this.c);
    }

    @Override
    public final long a(int n2) {
        return this.b.a(n2) + this.c;
    }

    @Override
    public final List<a> b(long l2) {
        return this.b.b(l2 - this.c);
    }
}

