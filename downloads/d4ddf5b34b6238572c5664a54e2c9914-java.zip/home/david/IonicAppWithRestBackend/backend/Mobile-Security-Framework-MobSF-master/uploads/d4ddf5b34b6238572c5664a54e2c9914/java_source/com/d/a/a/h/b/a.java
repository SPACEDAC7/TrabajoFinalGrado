/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Html
 *  android.text.TextUtils
 *  android.util.Log
 */
package com.d.a.a.h.b;

import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import com.d.a.a.d.r;
import com.d.a.a.h.b.b;
import com.d.a.a.h.c;
import com.d.a.a.h.d;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class a
implements d {
    private static final Pattern a = Pattern.compile("(\\S*)\\s*-->\\s*(\\S*)");
    private static final Pattern b = Pattern.compile("(?:(\\d+):)?(\\d+):(\\d+),(\\d+)");
    private final StringBuilder c = new StringBuilder();

    private static long b(String object) {
        if (!(object = b.matcher((CharSequence)object)).matches()) {
            throw new NumberFormatException("has invalid format");
        }
        long l2 = Long.parseLong(object.group(1));
        long l3 = Long.parseLong(object.group(2));
        long l4 = Long.parseLong(object.group(3));
        return (Long.parseLong(object.group(4)) + (l2 * 60 * 60 * 1000 + l3 * 60 * 1000 + l4 * 1000)) * 1000;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final b a(byte[] var1_1, int var2_2, int var3_3) {
        var4_4 = new ArrayList<com.d.a.a.h.a>();
        var5_5 = new r();
        var1_1 = new com.d.a.a.d.b((byte[])var1_1, var3_3 + 0);
        var1_1.b(0);
        do {
            if ((var6_6 = var1_1.n()) == null) {
                var1_1 = new com.d.a.a.h.a[var4_4.size()];
                var4_4.toArray(var1_1);
                return new b(var1_1, Arrays.copyOf(var5_5.b, var5_5.a));
            }
            if (var6_6.length() == 0) continue;
            try {
                Integer.parseInt(var6_6);
            }
            catch (NumberFormatException var7_8) {
                Log.w((String)"SubripParser", (String)("Skipping invalid index: " + var6_6));
                continue;
            }
            var6_6 = var1_1.n();
            var7_7 = a.a.matcher(var6_6);
            if (!var7_7.find()) ** GOTO lbl32
            var5_5.a(a.b(var7_7.group(1)));
            if (!TextUtils.isEmpty((CharSequence)var7_7.group(2))) {
                var5_5.a(a.b(var7_7.group(2)));
                var2_2 = 1;
            } else {
                var2_2 = 0;
            }
            this.c.setLength(0);
            while (!TextUtils.isEmpty((CharSequence)(var6_6 = var1_1.n()))) {
                if (this.c.length() > 0) {
                    this.c.append("<br>");
                }
                this.c.append(var6_6.trim());
            }
            ** GOTO lbl34
lbl32: // 1 sources:
            Log.w((String)"SubripParser", (String)("Skipping invalid timing: " + var6_6));
            continue;
lbl34: // 1 sources:
            var4_4.add(new com.d.a.a.h.a((CharSequence)Html.fromHtml((String)this.c.toString())));
            if (var2_2 == 0) continue;
            var4_4.add(null);
        } while (true);
    }

    @Override
    public final boolean a(String string) {
        return "application/x-subrip".equals(string);
    }
}

