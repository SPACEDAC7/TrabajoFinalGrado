/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.b;

import com.d.a.a.d.ah;
import com.d.a.a.h.a;
import com.d.a.a.h.c;
import java.util.Collections;
import java.util.List;

public final class b
implements c {
    private final a[] a;
    private final long[] b;

    public b(a[] arra, long[] arrl) {
        this.a = arra;
        this.b = arrl;
    }

    @Override
    public final int a() {
        return this.b.length;
    }

    @Override
    public final int a(long l2) {
        int n2 = ah.a(this.b, l2, false, false);
        if (n2 < this.b.length) {
            return n2;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a(int n2) {
        boolean bl2 = true;
        boolean bl3 = n2 >= 0;
        if (!bl3) {
            throw new IllegalArgumentException();
        }
        bl3 = n2 < this.b.length ? bl2 : false;
        if (!bl3) {
            throw new IllegalArgumentException();
        }
        return this.b[n2];
    }

    @Override
    public final List<a> b(long l2) {
        int n2 = ah.a(this.b, l2, false);
        if (n2 == -1 || this.a[n2] == null) {
            return Collections.emptyList();
        }
        return Collections.singletonList(this.a[n2]);
    }
}

