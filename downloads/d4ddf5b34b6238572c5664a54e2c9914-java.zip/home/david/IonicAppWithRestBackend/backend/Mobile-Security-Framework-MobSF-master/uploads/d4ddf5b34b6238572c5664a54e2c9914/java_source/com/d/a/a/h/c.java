/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h;

import com.d.a.a.h.a;
import java.util.List;

public interface c {
    public int a();

    public int a(long var1);

    public long a(int var1);

    public List<a> b(long var1);
}

