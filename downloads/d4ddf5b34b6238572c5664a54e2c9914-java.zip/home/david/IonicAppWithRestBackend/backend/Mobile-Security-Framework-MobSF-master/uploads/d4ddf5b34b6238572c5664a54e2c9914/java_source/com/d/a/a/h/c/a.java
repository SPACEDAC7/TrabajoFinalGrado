/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 */
package com.d.a.a.h.c;

import android.text.TextUtils;
import com.d.a.a.d.ah;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class a {
    private static final Pattern a;
    private static final Pattern b;
    private static final Map<String, Integer> c;

    static {
        HashMap<String, Integer> hashMap;
        a = Pattern.compile("^rgb\\((\\d{1,3}),(\\d{1,3}),(\\d{1,3})\\)$");
        b = Pattern.compile("^rgba\\((\\d{1,3}),(\\d{1,3}),(\\d{1,3}),(\\d{1,3})\\)$");
        c = hashMap = new HashMap<String, Integer>();
        hashMap.put("transparent", 0);
        c.put("black", -16777216);
        c.put("silver", -4144960);
        c.put("gray", -8355712);
        c.put("white", -1);
        c.put("maroon", -8388608);
        c.put("red", -65536);
        c.put("purple", -8388480);
        c.put("fuchsia", -65281);
        c.put("magenta", -65281);
        c.put("green", -16744448);
        c.put("lime", -16711936);
        c.put("olive", -8355840);
        c.put("yellow", -256);
        c.put("navy", -16777088);
        c.put("blue", -16776961);
        c.put("teal", -16744320);
        c.put("aqua", 16777215);
        c.put("cyan", -16711681);
    }

    private static int a(int n2, int n3, int n4, int n5) {
        return n2 << 24 | n3 << 16 | n4 << 8 | n5;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static int a(String object) {
        int n2 = !TextUtils.isEmpty((CharSequence)object) ? 1 : 0;
        if (n2 == 0) {
            throw new IllegalArgumentException();
        }
        if ((object = object.replace(" ", "")).charAt(0) == '#') {
            n2 = (int)Long.parseLong(object.substring(1), 16);
            if (object.length() == 7) {
                return -16777216 | n2;
            }
            if (object.length() != 9) throw new IllegalArgumentException();
            return (n2 & 255) << 24 | n2 >>> 8;
        }
        if (object.startsWith("rgba")) {
            if (!(object = b.matcher((CharSequence)object)).matches()) throw new IllegalArgumentException();
            return a.a(255 - Integer.parseInt(object.group(4), 10), Integer.parseInt(object.group(1), 10), Integer.parseInt(object.group(2), 10), Integer.parseInt(object.group(3), 10));
        } else if (object.startsWith("rgb")) {
            if (!(object = a.matcher((CharSequence)object)).matches()) throw new IllegalArgumentException();
            return a.a(255, Integer.parseInt(object.group(1), 10), Integer.parseInt(object.group(2), 10), Integer.parseInt(object.group(3), 10));
        } else {
            if ((object = c.get(ah.b((String)object))) == null) throw new IllegalArgumentException();
            return object.intValue();
        }
    }
}

