/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.SpannableStringBuilder
 */
package com.d.a.a.h.c;

import android.text.SpannableStringBuilder;
import com.d.a.a.h.c.c;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

public final class b {
    public final String a;
    public final String b;
    public final boolean c;
    public final long d;
    public final long e;
    public final c f;
    private String[] g;
    private List<b> h;
    private int i;
    private int j;

    /*
     * Enabled aggressive block sorting
     */
    b(String string, String string2, long l2, long l3, c c2, String[] arrstring) {
        this.a = string;
        this.b = string2;
        this.f = c2;
        this.g = arrstring;
        boolean bl2 = string2 != null;
        this.c = bl2;
        this.d = l2;
        this.e = l3;
    }

    private b a(int n2) {
        if (this.h == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.h.get(n2);
    }

    /*
     * Exception decompiling
     */
    public static void a(TreeSet<Long> var0, boolean var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Invisible function parameters on a non-constructor
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.assignSSAIdentifiers(Op02WithProcessedDataAndRefs.java:1505)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.discoverStorageLiveness(Op02WithProcessedDataAndRefs.java:1728)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:384)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private int b() {
        if (this.h == null) {
            return 0;
        }
        return this.h.size();
    }

    /*
     * Enabled aggressive block sorting
     */
    final SpannableStringBuilder a(long l2, SpannableStringBuilder spannableStringBuilder, boolean bl2) {
        int n2;
        boolean bl3;
        this.j = this.i = spannableStringBuilder.length();
        if (this.c && bl2) {
            spannableStringBuilder.append((CharSequence)this.b);
            return spannableStringBuilder;
        }
        if ("br".equals(this.a) && bl2) {
            spannableStringBuilder.append('\n');
            return spannableStringBuilder;
        }
        if ("metadata".equals(this.a)) return spannableStringBuilder;
        if (!(this.d == -1 && this.e == -1 || this.d <= l2 && this.e == -1 || this.d == -1 && l2 < this.e) && (this.d > l2 || l2 >= this.e)) return spannableStringBuilder;
        {
            n2 = 1;
            if (n2 == 0) return spannableStringBuilder;
            {
                bl3 = "p".equals(this.a);
            }
        }
        for (n2 = 0; n2 < this.b(); ++n2) {
            b b2 = this.a(n2);
            boolean bl4 = bl2 || bl3;
            b2.a(l2, spannableStringBuilder, bl4);
        }
        if (bl3) {
            for (n2 = spannableStringBuilder.length() - 1; n2 >= 0 && spannableStringBuilder.charAt(n2) == ' '; --n2) {
            }
            if (n2 >= 0 && spannableStringBuilder.charAt(n2) != '\n') {
                spannableStringBuilder.append('\n');
            }
        }
        this.j = spannableStringBuilder.length();
        return spannableStringBuilder;
    }

    /*
     * Exception decompiling
     */
    final void a(SpannableStringBuilder var1_1, Map<String, c> var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    public final void a(b b2) {
        if (this.h == null) {
            this.h = new ArrayList<b>();
        }
        this.h.add(b2);
    }
}

