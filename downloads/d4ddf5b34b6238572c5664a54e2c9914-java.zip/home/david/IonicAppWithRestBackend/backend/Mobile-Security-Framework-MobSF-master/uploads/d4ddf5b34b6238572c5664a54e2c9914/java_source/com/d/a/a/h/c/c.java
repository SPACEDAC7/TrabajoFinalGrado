/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 */
package com.d.a.a.h.c;

import android.text.Layout;

final class c {
    String a;
    int b;
    boolean c;
    int d;
    boolean e;
    short f = -1;
    short g = -1;
    short h = -1;
    short i = -1;
    short j = -1;
    float k;
    String l;
    c m;
    Layout.Alignment n;

    c() {
    }

    /*
     * Enabled aggressive block sorting
     */
    public final c a(int n2) {
        boolean bl2 = this.m == null;
        if (!bl2) {
            throw new IllegalStateException();
        }
        this.b = n2;
        this.c = true;
        return this;
    }

    public final c a(c c2) {
        if (c2 != null) {
            if (!this.c && c2.c) {
                this.a(c2.b);
            }
            if (this.h == -1) {
                this.h = c2.h;
            }
            if (this.i == -1) {
                this.i = c2.i;
            }
            if (this.a == null) {
                this.a = c2.a;
            }
            if (this.f == -1) {
                this.f = c2.f;
            }
            if (this.g == -1) {
                this.g = c2.g;
            }
            if (this.n == null) {
                this.n = c2.n;
            }
            if (this.j == -1) {
                this.j = c2.j;
                this.k = c2.k;
            }
            if (!this.e && c2.e) {
                this.d = c2.d;
                this.e = true;
            }
        }
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final c a(boolean bl2) {
        short s2 = 1;
        boolean bl3 = this.m == null;
        if (!bl3) {
            throw new IllegalStateException();
        }
        if (!bl2) {
            s2 = 0;
        }
        this.f = s2;
        return this;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final short a() {
        if (this.h == -1 && this.i == -1) {
            return -1;
        }
        short s2 = 0;
        if (this.h != -1) {
            s2 = (short)(this.h + 0);
        }
        short s3 = s2;
        if (this.i == -1) return s3;
        return (short)(s2 + this.i);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final c b(boolean bl2) {
        short s2 = 1;
        boolean bl3 = this.m == null;
        if (!bl3) {
            throw new IllegalStateException();
        }
        if (!bl2) {
            s2 = 0;
        }
        this.g = s2;
        return this;
    }
}

