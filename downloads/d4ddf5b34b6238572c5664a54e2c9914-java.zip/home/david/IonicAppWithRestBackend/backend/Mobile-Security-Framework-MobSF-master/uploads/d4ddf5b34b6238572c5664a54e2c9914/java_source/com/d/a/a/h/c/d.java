/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.xmlpull.v1.XmlPullParser
 *  org.xmlpull.v1.XmlPullParserException
 *  org.xmlpull.v1.XmlPullParserFactory
 */
package com.d.a.a.h.c;

import com.d.a.a.bb;
import com.d.a.a.d.ac;
import com.d.a.a.h.c.b;
import com.d.a.a.h.c.c;
import com.d.a.a.h.c.e;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public final class d
implements com.d.a.a.h.d {
    private static final Pattern a = Pattern.compile("^([0-9][0-9]+):([0-9][0-9]):([0-9][0-9])(?:(\\.[0-9]+)|:([0-9][0-9])(?:\\.([0-9]+))?)?$");
    private static final Pattern b = Pattern.compile("^([0-9]+(?:\\.[0-9]+)?)(h|m|s|ms|f|t)$");
    private static final Pattern c = Pattern.compile("^(([0-9]*.)?[0-9]+)(px|em|%)$");
    private final XmlPullParserFactory d;

    public d() {
        try {
            this.d = XmlPullParserFactory.newInstance();
            return;
        }
        catch (XmlPullParserException var1_1) {
            throw new RuntimeException("Couldn't create XmlPullParserFactory instance", (Throwable)var1_1);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private b a(XmlPullParser var1_1, b var2_2) {
        var9_3 = 0;
        var5_4 = -1;
        var7_5 = -1;
        var15_6 = null;
        var4_7 = var1_1.getAttributeCount();
        var17_8 = d.a(var1_1, null);
        var3_9 = 0;
        do {
            if (var3_9 >= var4_7) ** GOTO lbl35
            var16_11 = var1_1.getAttributeName(var3_9).replaceFirst("^.*:", "");
            var18_12 = var1_1.getAttributeValue(var3_9);
            if (!var16_11.equals("begin")) ** GOTO lbl17
            var11_10 = d.b(var18_12);
            var5_4 = var7_5;
            var7_5 = var11_10;
            ** GOTO lbl59
lbl17: // 1 sources:
            if (!var16_11.equals("end")) ** GOTO lbl22
            var11_10 = d.b(var18_12);
            var7_5 = var5_4;
            var5_4 = var11_10;
            ** GOTO lbl59
lbl22: // 1 sources:
            if (!var16_11.equals("dur")) ** GOTO lbl29
            var11_10 = d.b(var18_12);
            var9_3 = var5_4;
            var5_4 = var7_5;
            var7_5 = var9_3;
            var9_3 = var11_10;
            ** GOTO lbl59
lbl29: // 1 sources:
            if (!var16_11.equals("style") || (var16_11 = var18_12.split("\\s+")).length <= 0) ** GOTO lbl56
            var15_6 = var16_11;
            var11_10 = var5_4;
            var5_4 = var7_5;
            var7_5 = var11_10;
            ** GOTO lbl59
lbl35: // 1 sources:
            var13_13 = var5_4;
            if (var2_2 == null) ** GOTO lbl-1000
            var13_13 = var5_4;
            if (var2_2.d == -1) ** GOTO lbl-1000
            var11_10 = var5_4;
            if (var5_4 != -1) {
                var11_10 = var5_4 + var2_2.d;
            }
            var13_13 = var11_10;
            if (var7_5 != -1) {
                var5_4 = var7_5 + var2_2.d;
            } else lbl-1000: // 3 sources:
            {
                var5_4 = var7_5;
                var11_10 = var13_13;
            }
            if (var5_4 != -1) return new b(var1_1.getName(), null, var11_10, var5_4, var17_8, var15_6);
            if (var9_3 > 0) {
                var5_4 = var9_3 + var11_10;
                return new b(var1_1.getName(), null, var11_10, var5_4, var17_8, var15_6);
            }
            if (var2_2 == null) return new b(var1_1.getName(), null, var11_10, var5_4, var17_8, var15_6);
            if (var2_2.e == -1) return new b(var1_1.getName(), null, var11_10, var5_4, var17_8, var15_6);
            var5_4 = var2_2.e;
            return new b(var1_1.getName(), null, var11_10, var5_4, var17_8, var15_6);
lbl56: // 1 sources:
            var11_10 = var5_4;
            var5_4 = var7_5;
            var7_5 = var11_10;
lbl59: // 5 sources:
            ++var3_9;
            var11_10 = var7_5;
            var7_5 = var5_4;
            var5_4 = var11_10;
        } while (true);
    }

    /*
     * Exception decompiling
     */
    private static c a(XmlPullParser var0, c var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private e a(byte[] var1_1, int var2_4, int var3_5) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 7[WHILELOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private Map<String, c> a(XmlPullParser xmlPullParser, Map<String, c> map) {
        do {
            xmlPullParser.next();
            if (!ac.b(xmlPullParser, "style")) continue;
            String[] arrstring = xmlPullParser.getAttributeValue(null, "style");
            c c2 = d.a(xmlPullParser, new c());
            if (arrstring != null) {
                arrstring = arrstring.split("\\s+");
                for (int i2 = 0; i2 < arrstring.length; ++i2) {
                    c2.a(map.get(arrstring[i2]));
                }
            }
            if (c2.l == null) continue;
            map.put(c2.l, c2);
        } while (!ac.a(xmlPullParser, "head"));
        return map;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static long b(String string) {
        double d2;
        Matcher matcher = a.matcher(string);
        if (matcher.matches()) {
            double d3;
            double d4 = Long.parseLong(matcher.group(1)) * 3600;
            double d5 = Long.parseLong(matcher.group(2)) * 60;
            double d6 = Long.parseLong(matcher.group(3));
            string = matcher.group(4);
            double d7 = string != null ? Double.parseDouble(string) : 0.0;
            string = matcher.group(5);
            double d8 = string != null ? (double)Long.parseLong(string) / 30.0 : 0.0;
            string = matcher.group(6);
            if (string != null) {
                d3 = (double)Long.parseLong(string) / 1.0 / 30.0;
                return (long)((d3 + (d6 + (d4 + d5) + d7 + d8)) * 1000000.0);
            }
            d3 = 0.0;
            return (long)((d3 + (d6 + (d4 + d5) + d7 + d8)) * 1000000.0);
        }
        matcher = b.matcher(string);
        if (!matcher.matches()) throw new bb("Malformed time expression: " + string);
        double d9 = Double.parseDouble(matcher.group(1));
        string = matcher.group(2);
        if (string.equals("h")) {
            d2 = d9 * 3600.0;
            return (long)(d2 * 1000000.0);
        }
        if (string.equals("m")) {
            d2 = d9 * 60.0;
            return (long)(d2 * 1000000.0);
        }
        d2 = d9;
        if (string.equals("s")) return (long)(d2 * 1000000.0);
        if (string.equals("ms")) {
            d2 = d9 / 1000.0;
            return (long)(d2 * 1000000.0);
        }
        if (string.equals("f")) {
            d2 = d9 / 30.0;
            return (long)(d2 * 1000000.0);
        }
        d2 = d9;
        if (!string.equals("t")) return (long)(d2 * 1000000.0);
        d2 = d9 / 1.0;
        return (long)(d2 * 1000000.0);
    }

    @Override
    public final boolean a(String string) {
        return "application/ttml+xml".equals(string);
    }
}

