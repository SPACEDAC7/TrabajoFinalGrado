/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.SpannableStringBuilder
 */
package com.d.a.a.h.c;

import android.text.SpannableStringBuilder;
import com.d.a.a.d.ah;
import com.d.a.a.h.a;
import com.d.a.a.h.c.b;
import com.d.a.a.h.c.c;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

public final class e
implements com.d.a.a.h.c {
    private final b a;
    private final long[] b;
    private final Map<String, c> c;

    public e(b arrl, Map<String, c> iterator) {
        this.a = arrl;
        this.c = Collections.unmodifiableMap(iterator);
        iterator = new TreeSet();
        b.a((b)arrl, (TreeSet)((Object)iterator), (boolean)false);
        arrl = new long[iterator.size()];
        iterator = iterator.iterator();
        int n2 = 0;
        while (iterator.hasNext()) {
            arrl[n2] = (Long)iterator.next();
            ++n2;
        }
        this.b = arrl;
    }

    @Override
    public final int a() {
        return this.b.length;
    }

    @Override
    public final int a(long l2) {
        int n2 = ah.a(this.b, l2, false, false);
        if (n2 < this.b.length) {
            return n2;
        }
        return -1;
    }

    @Override
    public final long a(int n2) {
        return this.b[n2];
    }

    @Override
    public final List<a> b(long l2) {
        int n2;
        int n3;
        b b2 = this.a;
        Map<String, c> map = this.c;
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        b2.a(l2, spannableStringBuilder, false);
        b2.a(spannableStringBuilder, map);
        int n4 = spannableStringBuilder.length();
        for (n2 = 0; n2 < n4; ++n2) {
            if (spannableStringBuilder.charAt(n2) != ' ') continue;
            for (n3 = n2 + 1; n3 < spannableStringBuilder.length() && spannableStringBuilder.charAt(n3) == ' '; ++n3) {
            }
            if ((n3 -= n2 + 1) <= 0) continue;
            spannableStringBuilder.delete(n2, n2 + n3);
            n4 -= n3;
        }
        n2 = n4;
        if (n4 > 0) {
            n2 = n4;
            if (spannableStringBuilder.charAt(0) == ' ') {
                spannableStringBuilder.delete(0, 1);
                n2 = n4 - 1;
            }
        }
        n4 = n2;
        for (n2 = 0; n2 < n4 - 1; ++n2) {
            n3 = n4;
            if (spannableStringBuilder.charAt(n2) == '\n') {
                n3 = n4;
                if (spannableStringBuilder.charAt(n2 + 1) == ' ') {
                    spannableStringBuilder.delete(n2 + 1, n2 + 2);
                    n3 = n4 - 1;
                }
            }
            n4 = n3;
        }
        n2 = n4;
        if (n4 > 0) {
            n2 = n4;
            if (spannableStringBuilder.charAt(n4 - 1) == ' ') {
                spannableStringBuilder.delete(n4 - 1, n4);
                n2 = n4 - 1;
            }
        }
        for (n4 = 0; n4 < n2 - 1; ++n4) {
            n3 = n2;
            if (spannableStringBuilder.charAt(n4) == ' ') {
                n3 = n2;
                if (spannableStringBuilder.charAt(n4 + 1) == '\n') {
                    spannableStringBuilder.delete(n4, n4 + 1);
                    n3 = n2 - 1;
                }
            }
            n2 = n3;
        }
        if (n2 > 0 && spannableStringBuilder.charAt(n2 - 1) == '\n') {
            spannableStringBuilder.delete(n2 - 1, n2);
        }
        return Collections.singletonList(new a((CharSequence)spannableStringBuilder));
    }
}

