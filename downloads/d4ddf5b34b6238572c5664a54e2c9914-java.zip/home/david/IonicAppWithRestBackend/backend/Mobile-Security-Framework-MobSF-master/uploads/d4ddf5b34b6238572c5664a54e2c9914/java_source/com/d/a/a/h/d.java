/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h;

import com.d.a.a.h.c;

public interface d {
    public c a(byte[] var1, int var2);

    public boolean a(String var1);
}

