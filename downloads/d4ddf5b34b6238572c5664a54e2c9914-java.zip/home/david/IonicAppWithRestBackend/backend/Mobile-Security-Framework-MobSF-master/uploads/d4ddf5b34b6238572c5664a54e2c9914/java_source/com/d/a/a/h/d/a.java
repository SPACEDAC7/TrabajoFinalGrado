/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.d;

import com.d.a.a.h.c;
import com.d.a.a.h.d;
import com.d.a.a.h.d.b;

public final class a
implements d {
    @Override
    public final c a(byte[] arrby, int n2) {
        return new b(new com.d.a.a.h.a(new String(arrby, 0, n2)));
    }

    @Override
    public final boolean a(String string) {
        return "application/x-quicktime-tx3g".equals(string);
    }
}

