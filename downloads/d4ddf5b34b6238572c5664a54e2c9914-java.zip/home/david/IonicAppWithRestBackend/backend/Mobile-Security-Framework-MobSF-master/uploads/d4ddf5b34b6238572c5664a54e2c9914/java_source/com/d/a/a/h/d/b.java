/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.d;

import com.d.a.a.h.a;
import com.d.a.a.h.c;
import java.util.Collections;
import java.util.List;

final class b
implements c {
    private final List<a> a;

    public b(a a2) {
        this.a = Collections.singletonList(a2);
    }

    @Override
    public final int a() {
        return 1;
    }

    @Override
    public final int a(long l2) {
        if (l2 < 0) {
            return 0;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a(int n2) {
        if (n2 == 0) {
            return 0;
        }
        n2 = 0;
        if (n2 == 0) {
            throw new IllegalArgumentException();
        }
        return 0;
    }

    @Override
    public final List<a> b(long l2) {
        if (l2 >= 0) {
            return this.a;
        }
        return Collections.emptyList();
    }
}

