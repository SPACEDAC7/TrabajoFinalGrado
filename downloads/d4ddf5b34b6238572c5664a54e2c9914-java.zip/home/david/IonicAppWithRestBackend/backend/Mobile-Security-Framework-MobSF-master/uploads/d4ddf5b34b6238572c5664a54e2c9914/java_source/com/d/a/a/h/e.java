/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.Looper
 *  android.os.Message
 */
package com.d.a.a.h;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.d.a.a.bb;
import com.d.a.a.d.ah;
import com.d.a.a.h.b;
import com.d.a.a.h.c;
import com.d.a.a.h.d;
import com.d.a.a.q;
import com.d.a.a.z;
import java.io.IOException;
import java.nio.ByteBuffer;

final class e
implements Handler.Callback {
    final Handler a;
    private final d b;
    private z c;
    private boolean d;
    private b e;
    private IOException f;
    private RuntimeException g;
    private boolean h;
    private long i;

    public e(Looper looper, d d2) {
        this.a = new Handler(looper, (Handler.Callback)this);
        this.b = d2;
        this.a();
    }

    public final void a() {
        synchronized (this) {
            this.c = new z(1);
            this.d = false;
            this.e = null;
            this.f = null;
            this.g = null;
            return;
        }
    }

    public final boolean b() {
        synchronized (this) {
            boolean bl2 = this.d;
            return bl2;
        }
    }

    public final z c() {
        synchronized (this) {
            z z2 = this.c;
            return z2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void d() {
        boolean bl2 = true;
        synchronized (this) {
            if (this.d) {
                bl2 = false;
            }
            if (!bl2) {
                throw new IllegalStateException();
            }
            this.d = true;
            this.e = null;
            this.f = null;
            this.g = null;
            this.a.obtainMessage(1, ah.a(this.c.e), (int)this.c.e, (Object)this.c).sendToTarget();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final b e() {
        synchronized (this) {
            b b2;
            try {
                if (this.f != null) {
                    throw this.f;
                }
                if (this.g != null) {
                    throw this.g;
                }
                b2 = this.e;
            }
            finally {
                this.e = null;
                this.f = null;
                this.g = null;
            }
            return b2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final boolean handleMessage(Message object) {
        c c2;
        boolean bl2 = false;
        c c3 = null;
        switch (object.what) {
            default: {
                return true;
            }
            case 0: {
                object = (q)object.obj;
                if (object.s == Long.MAX_VALUE) {
                    bl2 = true;
                }
                this.h = bl2;
                long l2 = this.h ? 0 : object.s;
                this.i = l2;
                return true;
            }
            case 1: 
        }
        long l3 = ah.b(object.arg1, object.arg2);
        z z2 = (z)object.obj;
        try {
            c2 = this.b.a(z2.b.array(), z2.c);
            object = null;
            Object var7_10 = null;
            c3 = c2;
            c2 = var7_10;
        }
        catch (bb var5_9) {
            object = null;
        }
        catch (RuntimeException var1_2) {
            c2 = null;
        }
        synchronized (this) {
            if (this.c == z2) {
                this.e = new b(c3, this.h, l3, this.i);
                this.f = c2;
                this.g = object;
                this.d = false;
            }
            return true;
        }
    }
}

