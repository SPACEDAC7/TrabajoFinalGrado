/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.e;

import com.d.a.a.bb;
import com.d.a.a.d.ah;
import com.d.a.a.h.c;
import com.d.a.a.h.d;
import com.d.a.a.h.e.b;
import com.d.a.a.h.e.e;
import com.d.a.a.h.e.g;
import java.util.ArrayList;
import java.util.List;

public final class a
implements d {
    private static final int a = ah.e("payl");
    private static final int b = ah.e("sttg");
    private static final int c = ah.e("vttc");
    private final com.d.a.a.d.b d = new com.d.a.a.d.b();
    private final b e = new b();

    private static com.d.a.a.h.a a(com.d.a.a.d.b b2, b b3, int n2) {
        b3.a();
        while (n2 > 0) {
            if (n2 < 8) {
                throw new bb("Incomplete vtt cue box header found.");
            }
            int n3 = b2.g();
            int n4 = b2.g();
            String string = new String(b2.a, b2.b, n3 -= 8);
            b2.b(b2.b + n3);
            n3 = n2 - 8 - n3;
            if (n4 == b) {
                g.a(string, b3);
                n2 = n3;
                continue;
            }
            n2 = n3;
            if (n4 != a) continue;
            g.b(string.trim(), b3);
            n2 = n3;
        }
        return b3.b();
    }

    @Override
    public final /* synthetic */ c a(byte[] object, int n2) {
        com.d.a.a.d.b b2 = this.d;
        b2.a = object;
        b2.c = n2 + 0;
        b2.b = 0;
        this.d.b(0);
        object = new ArrayList();
        do {
            b2 = this.d;
            if (b2.c - b2.b <= 0) break;
            b2 = this.d;
            if (b2.c - b2.b < 8) {
                throw new bb("Incomplete Mp4Webvtt Top Level box header found.");
            }
            n2 = this.d.g();
            if (this.d.g() == c) {
                object.add(a.a(this.d, this.e, n2 - 8));
                continue;
            }
            b2 = this.d;
            b2.b(n2 - 8 + b2.b);
        } while (true);
        return new e((List<com.d.a.a.h.a>)object);
    }

    @Override
    public final boolean a(String string) {
        return "application/x-mp4vtt".equals(string);
    }
}

