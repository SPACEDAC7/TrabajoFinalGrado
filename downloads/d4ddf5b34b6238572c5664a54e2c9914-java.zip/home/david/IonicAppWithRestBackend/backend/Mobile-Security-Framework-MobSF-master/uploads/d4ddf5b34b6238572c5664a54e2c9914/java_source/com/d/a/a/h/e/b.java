/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.util.Log
 */
package com.d.a.a.h.e;

import android.text.Layout;
import android.util.Log;
import com.d.a.a.h.e.c;
import com.d.a.a.h.e.d;

public final class b {
    public long a;
    public long b;
    CharSequence c;
    Layout.Alignment d;
    float e;
    int f;
    int g;
    float h;
    int i;
    float j;

    public b() {
        this.a();
    }

    public final void a() {
        this.a = 0;
        this.b = 0;
        this.c = null;
        this.d = null;
        this.e = Float.MIN_VALUE;
        this.f = Integer.MIN_VALUE;
        this.g = Integer.MIN_VALUE;
        this.h = Float.MIN_VALUE;
        this.i = Integer.MIN_VALUE;
        this.j = Float.MIN_VALUE;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final d b() {
        if (this.h == Float.MIN_VALUE) return new d(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
        if (this.i != Integer.MIN_VALUE) return new d(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
        if (this.d == null) {
            this.i = Integer.MIN_VALUE;
            return new d(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
        }
        switch (c.a[this.d.ordinal()]) {
            default: {
                Log.w((String)"WebvttCueBuilder", (String)("Unrecognized alignment: " + (Object)this.d));
                this.i = 0;
                return new d(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
            }
            case 1: {
                this.i = 0;
                return new d(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
            }
            case 2: {
                this.i = 1;
                return new d(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
            }
            case 3: 
        }
        this.i = 2;
        return new d(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
    }
}

