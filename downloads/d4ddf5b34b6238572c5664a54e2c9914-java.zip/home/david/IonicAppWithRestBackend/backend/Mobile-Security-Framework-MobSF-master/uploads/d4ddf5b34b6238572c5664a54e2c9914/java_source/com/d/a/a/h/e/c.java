/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 */
package com.d.a.a.h.e;

import android.text.Layout;

final class c {
    static final /* synthetic */ int[] a;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        a = new int[Layout.Alignment.values().length];
        try {
            c.a[Layout.Alignment.ALIGN_NORMAL.ordinal()] = 1;
        }
        catch (NoSuchFieldError var0_2) {}
        try {
            c.a[Layout.Alignment.ALIGN_CENTER.ordinal()] = 2;
        }
        catch (NoSuchFieldError var0_1) {}
        try {
            c.a[Layout.Alignment.ALIGN_OPPOSITE.ordinal()] = 3;
            return;
        }
        catch (NoSuchFieldError var0) {
            return;
        }
    }
}

