/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Layout
 *  android.text.Layout$Alignment
 */
package com.d.a.a.h.e;

import android.text.Layout;
import com.d.a.a.h.a;

final class d
extends a {
    public final long i;
    public final long j;

    public d(long l2, long l3, CharSequence charSequence, Layout.Alignment alignment, float f2, int n2, int n3, float f3, int n4, float f4) {
        super(charSequence, alignment, f2, n2, n3, f3, n4, f4);
        this.i = l2;
        this.j = l3;
    }

    public d(CharSequence charSequence) {
        this(charSequence, 0);
    }

    private d(CharSequence charSequence, byte by2) {
        this(0, 0, charSequence, null, Float.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE);
    }
}

