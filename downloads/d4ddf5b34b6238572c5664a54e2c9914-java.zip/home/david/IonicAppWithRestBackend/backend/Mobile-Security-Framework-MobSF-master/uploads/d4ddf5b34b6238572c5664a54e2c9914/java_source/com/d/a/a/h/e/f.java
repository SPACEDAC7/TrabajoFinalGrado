/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.e;

final class f {
    public final String a;
    public final int b;

    public f(String string, int n2) {
        this.b = n2;
        this.a = string;
    }
}

