/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.SpannableStringBuilder
 *  android.text.style.StyleSpan
 *  android.text.style.UnderlineSpan
 *  android.util.Log
 */
package com.d.a.a.h.e;

import android.text.SpannableStringBuilder;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import com.d.a.a.h.e.b;
import com.d.a.a.h.e.f;
import java.util.Stack;
import java.util.regex.Pattern;

public final class g {
    public static final Pattern a = Pattern.compile("^(\\S+)\\s+-->\\s+(\\S+)(.*)?$");
    public static final Pattern b = Pattern.compile("^NOTE(( |\t).*)?$");
    private static final Pattern c = Pattern.compile("(\\S+?):(\\S+)");
    public final StringBuilder d = new StringBuilder();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int a(String var0) {
        var2_1 = 0;
        var1_2 = -1;
        switch (var0.hashCode()) {
            case 109757538: {
                if (var0.equals("start")) {
                    var1_2 = 0;
                    ** break;
                }
                ** GOTO lbl17
            }
            case -1364013995: {
                if (var0.equals("center")) {
                    var1_2 = 1;
                    ** break;
                }
                ** GOTO lbl17
            }
            case -1074341483: {
                if (var0.equals("middle")) {
                    var1_2 = 2;
                }
            }
lbl17: // 8 sources:
            default: {
                ** GOTO lbl22
            }
            case 100571: 
        }
        if (var0.equals("end")) {
            var1_2 = 3;
        }
lbl22: // 4 sources:
        switch (var1_2) {
            default: {
                Log.w((String)"WebvttCueParser", (String)("Invalid anchor value: " + var0));
                var2_1 = Integer.MIN_VALUE;
            }
            case 0: {
                return var2_1;
            }
            case 1: 
            case 2: {
                return 1;
            }
            case 3: 
        }
        return 2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void a(f var0, SpannableStringBuilder var1_1) {
        var3_2 = var0.a;
        var2_3 = -1;
        switch (var3_2.hashCode()) {
            case 98: {
                if (var3_2.equals("b")) {
                    var2_3 = 0;
                    ** break;
                }
                ** GOTO lbl12
            }
            case 105: {
                if (var3_2.equals("i")) {
                    var2_3 = 1;
                }
            }
lbl12: // 6 sources:
            default: {
                ** GOTO lbl17
            }
            case 117: 
        }
        if (var3_2.equals("u")) {
            var2_3 = 2;
        }
lbl17: // 4 sources:
        switch (var2_3) {
            default: {
                return;
            }
            case 0: {
                var1_1.setSpan((Object)new StyleSpan(1), var0.b, var1_1.length(), 33);
                return;
            }
            case 1: {
                var1_1.setSpan((Object)new StyleSpan(2), var0.b, var1_1.length(), 33);
                return;
            }
            case 2: 
        }
        var1_1.setSpan((Object)new UnderlineSpan(), var0.b, var1_1.length(), 33);
    }

    /*
     * Exception decompiling
     */
    public static void a(String var0, b var1_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static void b(String var0, b var1_1) {
        var11_2 = new SpannableStringBuilder();
        var12_3 = new Stack<f>();
        var3_4 = 0;
        do {
            if (var3_4 >= var0.length()) ** GOTO lbl132
            var2_5 = var0.charAt(var3_4);
            switch (var2_5) {
                default: {
                    var11_2.append(var2_5);
                    ++var3_4;
                    ** break;
                }
                case '<': {
                    if (var3_4 + 1 >= var0.length()) {
                        ++var3_4;
                        ** break;
                    }
                    var5_7 = var0.charAt(var3_4 + 1) == '/' ? 1 : 0;
                    var4_6 = var0.indexOf(62, var3_4 + 1);
                    var4_6 = var4_6 == -1 ? var0.length() : ++var4_6;
                    var6_8 = var0.charAt(var4_6 - 2) == '/' ? 1 : 0;
                    var7_9 = var5_7 != 0 ? 2 : 1;
                    var8_10 = var6_8 != 0 ? var4_6 - 2 : var4_6 - 1;
                    var10_12 = var0.substring(var7_9 + var3_4, var8_10).replace("\\s+", " ").trim();
                    if (var10_12.length() == 0) {
                        var9_11 = null;
                    } else {
                        var9_11 = var10_12;
                        if (var10_12.contains(" ")) {
                            var9_11 = var10_12.substring(0, var10_12.indexOf(" "));
                        }
                        var9_11 = var9_11.split("\\.");
                    }
                    if (var9_11 != null) {
                        var10_12 = var9_11[0];
                        switch (var10_12.hashCode()) {
                            case 98: {
                                if (!var10_12.equals("b")) break;
                                var3_4 = 0;
                                ** break;
                            }
                            case 99: {
                                if (!var10_12.equals("c")) break;
                                var3_4 = 1;
                                ** break;
                            }
                            case 105: {
                                if (!var10_12.equals("i")) break;
                                var3_4 = 2;
                                ** break;
                            }
                            case 3314158: {
                                if (!var10_12.equals("lang")) break;
                                var3_4 = 3;
                                ** break;
                            }
                            case 117: {
                                if (!var10_12.equals("u")) break;
                                var3_4 = 4;
                                ** break;
                            }
                            case 118: {
                                if (!var10_12.equals("v")) break;
                                var3_4 = 5;
                                ** break;
                            }
                        }
                        var3_4 = -1;
lbl58: // 7 sources:
                        switch (var3_4) {
                            default: {
                                var3_4 = 0;
                                break;
                            }
                            case 0: 
                            case 1: 
                            case 2: 
                            case 3: 
                            case 4: 
                            case 5: {
                                var3_4 = 1;
                            }
                        }
                        if (var3_4 != 0) {
                            if (var5_7 != 0) {
                                while (!var12_3.isEmpty()) {
                                    var10_12 = (f)var12_3.pop();
                                    g.a((f)var10_12, var11_2);
                                    if (!var10_12.a.equals(var9_11[0])) continue;
                                }
                                var3_4 = var4_6;
                                ** break;
                            }
                            if (var6_8 == 0) {
                                var12_3.push(new f((String)var9_11[0], var11_2.length()));
                                var3_4 = var4_6;
                                ** break;
                            }
                        }
                    }
                    ** GOTO lbl138
                }
                case '&': {
                    var6_8 = var0.indexOf(59, var3_4 + 1);
                    var5_7 = var0.indexOf(32, var3_4 + 1);
                    if (var6_8 == -1) {
                        var4_6 = var5_7;
                    } else {
                        var4_6 = var6_8;
                        if (var5_7 != -1) {
                            var4_6 = Math.min(var6_8, var5_7);
                        }
                    }
                    if (var4_6 == -1) ** GOTO lbl127
                    var9_11 = var0.substring(var3_4 + 1, var4_6);
                    switch (var9_11.hashCode()) {
                        case 3464: {
                            if (!var9_11.equals("lt")) ** GOTO lbl101
                            var3_4 = 0;
                            ** GOTO lbl108
                        }
                        case 3309: {
                            if (!var9_11.equals("gt")) ** GOTO lbl101
                            var3_4 = 1;
                            ** GOTO lbl108
                        }
                        case 3374865: {
                            if (!var9_11.equals("nbsp")) ** GOTO lbl101
                            var3_4 = 2;
                            ** GOTO lbl108
                        }
lbl101: // 4 sources:
                        default: {
                            ** GOTO lbl-1000
                        }
                        case 96708: 
                    }
                    if (var9_11.equals("amp")) {
                        var3_4 = 3;
                    } else lbl-1000: // 2 sources:
                    {
                        var3_4 = -1;
                    }
lbl108: // 5 sources:
                    switch (var3_4) {
                        default: {
                            Log.w((String)"WebvttCueParser", (String)("ignoring unsupported entity: '&" + (String)var9_11 + ";'"));
                            break;
                        }
                        case 0: {
                            var11_2.append('<');
                            break;
                        }
                        case 1: {
                            var11_2.append('>');
                            break;
                        }
                        case 2: {
                            var11_2.append(' ');
                            break;
                        }
                        case 3: {
                            var11_2.append('&');
                        }
                    }
                    if (var4_6 == var5_7) {
                        var11_2.append((CharSequence)" ");
                    }
                    var3_4 = var4_6 + 1;
                    ** break;
lbl127: // 1 sources:
                    var11_2.append(var2_5);
                    ++var3_4;
                    ** break;
lbl130: // 6 sources:
                    break;
                }
            }
            continue;
lbl132: // 1 sources:
            do {
                if (var12_3.isEmpty()) {
                    var1_1.c = var11_2;
                    return;
                }
                g.a((f)var12_3.pop(), var11_2);
            } while (true);
lbl138: // 1 sources:
            var3_4 = var4_6;
        } while (true);
    }
}

