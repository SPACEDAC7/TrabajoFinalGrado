/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  android.util.Log
 */
package com.d.a.a.h.e;

import android.text.TextUtils;
import android.util.Log;
import com.d.a.a.h.c;
import com.d.a.a.h.d;
import com.d.a.a.h.e.b;
import com.d.a.a.h.e.g;
import com.d.a.a.h.e.i;
import com.d.a.a.h.e.j;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class h
implements d {
    private final g a = new g();
    private final com.d.a.a.d.b b = new com.d.a.a.d.b();
    private final b c = new b();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final /* synthetic */ c a(byte[] var1_1, int var2_2) {
        var3_3 = this.b;
        var3_3.a = var1_1;
        var3_3.c = var2_2 + 0;
        var3_3.b = 0;
        this.b.b(0);
        this.c.a();
        j.a(this.b);
        while (!TextUtils.isEmpty((CharSequence)this.b.n())) {
        }
        var3_3 = new ArrayList<E>();
        block3 : do {
            var4_4 = this.a;
            var5_5 = this.b;
            var6_6 = this.c;
            do lbl-1000: // 4 sources:
            {
                if ((var1_1 = var5_5.n()) == null) return new i((List<com.d.a.a.h.e.d>)var3_3);
                if (!g.b.matcher((CharSequence)var1_1).matches()) ** GOTO lbl21
                do {
                    if ((var1_1 = var5_5.n()) == null || var1_1.isEmpty()) ** GOTO lbl-1000
                } while (true);
lbl21: // 1 sources:
                if (!(var1_1 = g.a.matcher((CharSequence)var1_1)).matches()) ** GOTO lbl-1000
                if (var1_1 == null) return new i((List<com.d.a.a.h.e.d>)var3_3);
                var7_7 = var4_4.d;
                var2_2 = 1;
                try {
                    var6_6.a = j.a(var1_1.group(1));
                    var6_6.b = j.a(var1_1.group(2));
                }
                catch (NumberFormatException var7_8) {
                    Log.w((String)"WebvttCueParser", (String)("Skipping cue with bad header: " + var1_1.group()));
                    var2_2 = 0;
                    continue;
lbl40: // 1 sources:
                    g.b(var7_7.toString(), var6_6);
                    if (var2_2 == 0) continue;
                    var2_2 = 1;
                    if (var2_2 == 0) return new i((List<com.d.a.a.h.e.d>)var3_3);
                    var3_3.add(this.c.b());
                    this.c.a();
                    continue block3;
                }
                g.a(var1_1.group(3), var6_6);
                var7_7.setLength(0);
                while ((var1_1 = var5_5.n()) != null && !var1_1.isEmpty()) {
                    if (var7_7.length() > 0) {
                        var7_7.append("\n");
                    }
                    var7_7.append(var1_1.trim());
                }
                ** GOTO lbl40
                break;
            } while (true);
            break;
        } while (true);
    }

    @Override
    public final boolean a(String string) {
        return "text/vtt".equals(string);
    }
}

