/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.SpannableStringBuilder
 */
package com.d.a.a.h.e;

import android.text.SpannableStringBuilder;
import com.d.a.a.d.ah;
import com.d.a.a.h.a;
import com.d.a.a.h.c;
import com.d.a.a.h.e.d;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class i
implements c {
    private final List<d> a;
    private final int b;
    private final long[] c;
    private final long[] d;

    public i(List<d> list) {
        this.a = list;
        this.b = list.size();
        this.c = new long[this.b * 2];
        for (int i2 = 0; i2 < this.b; ++i2) {
            d d2 = list.get(i2);
            int n2 = i2 * 2;
            this.c[n2] = d2.i;
            this.c[n2 + 1] = d2.j;
        }
        this.d = Arrays.copyOf(this.c, this.c.length);
        Arrays.sort(this.d);
    }

    @Override
    public final int a() {
        return this.d.length;
    }

    @Override
    public final int a(long l2) {
        int n2 = ah.a(this.d, l2, false, false);
        if (n2 < this.d.length) {
            return n2;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final long a(int n2) {
        boolean bl2 = true;
        boolean bl3 = n2 >= 0;
        if (!bl3) {
            throw new IllegalArgumentException();
        }
        bl3 = n2 < this.d.length ? bl2 : false;
        if (!bl3) {
            throw new IllegalArgumentException();
        }
        return this.d[n2];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final List<a> b(long l2) {
        d d2 = null;
        int n2 = 0;
        d d3 = null;
        ArrayList<d> arrayList = null;
        while (n2 < this.b) {
            d d4;
            if (this.c[n2 * 2] <= l2 && l2 < this.c[n2 * 2 + 1]) {
                if (arrayList == null) {
                    arrayList = new ArrayList<d>();
                }
                d4 = this.a.get(n2);
                boolean bl2 = d4.c == Float.MIN_VALUE && d4.f == Float.MIN_VALUE;
                if (bl2) {
                    if (d3 == null) {
                        d3 = d2;
                        d2 = d4;
                    } else if (d2 == null) {
                        d2 = new SpannableStringBuilder();
                        d2.append(d3.a).append((CharSequence)"\n").append(d4.a);
                        d4 = d3;
                        d3 = d2;
                        d2 = d4;
                    } else {
                        d2.append((CharSequence)"\n").append(d4.a);
                        d4 = d3;
                        d3 = d2;
                        d2 = d4;
                    }
                } else {
                    arrayList.add(d4);
                    d4 = d3;
                    d3 = d2;
                    d2 = d4;
                }
            } else {
                d4 = d3;
                d3 = d2;
                d2 = d4;
            }
            ++n2;
            d4 = d2;
            d2 = d3;
            d3 = d4;
        }
        return Collections.emptyList();
    }
}

