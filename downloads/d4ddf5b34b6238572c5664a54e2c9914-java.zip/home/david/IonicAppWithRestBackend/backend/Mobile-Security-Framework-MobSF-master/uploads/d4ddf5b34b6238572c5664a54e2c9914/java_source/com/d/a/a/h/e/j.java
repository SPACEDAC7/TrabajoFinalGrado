/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a.h.e;

import com.d.a.a.bb;
import com.d.a.a.d.b;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class j {
    private static final Pattern a = Pattern.compile("^\ufeff?WEBVTT(( |\t).*)?$");

    public static long a(String arrstring) {
        long l2 = 0;
        arrstring = arrstring.split("\\.", 2);
        String[] arrstring2 = arrstring[0].split(":");
        for (int i2 = 0; i2 < arrstring2.length; ++i2) {
            l2 = l2 * 60 + Long.parseLong(arrstring2[i2]);
        }
        return (Long.parseLong(arrstring[1]) + l2 * 1000) * 1000;
    }

    public static void a(b object) {
        if ((object = object.n()) == null || !a.matcher((CharSequence)object).matches()) {
            throw new bb("Expected WEBVTT. Got " + (String)object);
        }
    }

    public static float b(String string) {
        if (!string.endsWith("%")) {
            throw new NumberFormatException("Percentages must end with %");
        }
        return Float.parseFloat(string.substring(0, string.length() - 1)) / 100.0f;
    }
}

