/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.os.Message
 */
package com.d.a.a.h;

import android.annotation.TargetApi;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import com.d.a.a.ar;
import com.d.a.a.h.a;
import com.d.a.a.h.b;
import com.d.a.a.h.c;
import com.d.a.a.h.d;
import com.d.a.a.h.e;
import com.d.a.a.o;
import com.d.a.a.p;
import com.d.a.a.q;
import com.d.a.a.x;
import com.d.a.a.y;
import com.d.a.a.z;
import com.instagram.exoplayer.service.l;
import java.io.IOException;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@TargetApi(value=16)
public final class g
extends ar
implements Handler.Callback {
    private static final List<Class<? extends d>> b;
    private final Handler c;
    private final l d;
    private final y e;
    private final d[] f;
    private int g;
    private boolean h;
    private b i;
    private b j;
    private e k;
    private HandlerThread l;
    private int m;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        b = new ArrayList<Class<? extends d>>();
        try {
            b.add(Class.forName("com.d.a.a.h.e.h").asSubclass(d.class));
        }
        catch (ClassNotFoundException var0_4) {}
        try {
            b.add(Class.forName("com.d.a.a.h.c.d").asSubclass(d.class));
        }
        catch (ClassNotFoundException var0_3) {}
        try {
            b.add(Class.forName("com.d.a.a.h.e.a").asSubclass(d.class));
        }
        catch (ClassNotFoundException var0_2) {}
        try {
            b.add(Class.forName("com.d.a.a.h.b.a").asSubclass(d.class));
        }
        catch (ClassNotFoundException var0_1) {}
        try {
            b.add(Class.forName("com.d.a.a.h.d.a").asSubclass(d.class));
            return;
        }
        catch (ClassNotFoundException var0) {
            return;
        }
    }

    public /* varargs */ g(x x2, l l2, Looper looper, d ... arrd) {
        this(new x[]{x2}, l2, looper, arrd);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private /* varargs */ g(x[] var1_1, l var2_4, Looper var3_5, d ... var4_6) {
        super((x[])var1_1);
        if (var2_4 == null) {
            throw new NullPointerException();
        }
        this.d = (l)var2_4;
        var1_1 = var3_5 == null ? null : new d[](var3_5, (Handler.Callback)this);
        this.c = var1_1;
        if (var4_6 == null) ** GOTO lbl-1000
        var1_1 = var4_6;
        if (var4_6.length == 0) lbl-1000: // 2 sources:
        {
            var2_4 = new d[g.b.size()];
            var5_7 = 0;
            do {
                var1_1 = var2_4;
                if (var5_7 >= var2_4.length) break;
                try {
                    var2_4[var5_7] = g.b.get(var5_7).newInstance();
                    ++var5_7;
                    continue;
                }
                catch (InstantiationException var1_2) {
                    throw new IllegalStateException("Unexpected error creating default parser", var1_2);
                }
                catch (IllegalAccessException var1_3) {
                    throw new IllegalStateException("Unexpected error creating default parser", var1_3);
                }
            } while (true);
        }
        this.f = var1_1;
        this.e = new y();
    }

    private void a(List<a> list) {
        if (this.c != null) {
            this.c.obtainMessage(0, list).sendToTarget();
            return;
        }
        this.d.a(list);
    }

    private int b(q q2) {
        for (int i2 = 0; i2 < this.f.length; ++i2) {
            if (!this.f[i2].a(q2.b)) continue;
            return i2;
        }
        return -1;
    }

    private long p() {
        if (this.m == -1 || this.m >= this.i.b.a()) {
            return Long.MAX_VALUE;
        }
        b b2 = this.i;
        int n2 = this.m;
        long l2 = b2.b.a(n2);
        return b2.c + l2;
    }

    @Override
    protected final void a(int n2, long l2, boolean bl2) {
        super.a(n2, l2, bl2);
        this.g = this.b(this.a(n2));
        this.l = new HandlerThread("textParser");
        this.l.start();
        this.k = new e(this.l.getLooper(), this.f[this.g]);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected final void a(long var1_1, long var3_2, boolean var5_3) {
        if (this.j == null) {
            this.j = this.k.e();
        }
        if (this.a != 3) {
            return;
        }
        ** GOTO lbl9
        catch (IOException var8_4) {
            throw new p(var8_4);
        }
lbl9: // 1 sources:
        if (this.i != null) {
            var3_2 = this.p();
            var6_6 = 0;
            while (var3_2 <= var1_1) {
                ++this.m;
                var3_2 = this.p();
                var6_6 = 1;
            }
        } else {
            var6_6 = 0;
        }
        var7_7 = var6_6;
        if (this.j != null) {
            var7_7 = var6_6;
            if (this.j.a <= var1_1) {
                this.i = this.j;
                this.j = null;
                var8_5 = this.i;
                this.m = var8_5.b.a(var1_1 - var8_5.c);
                var7_7 = 1;
            }
            if (var7_7 != 0) {
                var8_5 = this.i;
                this.a(var8_5.b.b(var1_1 - var8_5.c));
            }
        }
        if (this.h != false) return;
        if (this.j != null) return;
        if (this.k.b() != false) return;
        var8_5 = this.k.c();
        if (var8_5.b != null) {
            var8_5.b.clear();
        }
        if ((var6_6 = this.a(var1_1, this.e, (z)var8_5)) == -4) {
            var8_5 = this.k;
            var9_8 = this.e.a;
            var8_5.a.obtainMessage(0, (Object)var9_8).sendToTarget();
            return;
        }
        if (var6_6 == -3) {
            this.k.d();
            return;
        }
        if (var6_6 != -1) return;
        this.h = true;
    }

    @Override
    protected final boolean a(q q2) {
        if (this.b(q2) != -1) {
            return true;
        }
        return false;
    }

    @Override
    protected final void c(long l2) {
        this.h = false;
        this.i = null;
        this.j = null;
        this.a(Collections.<a>emptyList());
        if (this.k != null) {
            this.k.a();
        }
    }

    @Override
    protected final boolean c() {
        if (this.h && (this.i == null || this.p() == Long.MAX_VALUE)) {
            return true;
        }
        return false;
    }

    @Override
    protected final boolean d() {
        return true;
    }

    @Override
    protected final long g() {
        return -3;
    }

    public final boolean handleMessage(Message object) {
        switch (object.what) {
            default: {
                return false;
            }
            case 0: 
        }
        object = (List)object.obj;
        this.d.a((List<a>)object);
        return true;
    }

    @Override
    protected final void m() {
        this.i = null;
        this.j = null;
        this.l.quit();
        this.l = null;
        this.k = null;
        this.a(Collections.<a>emptyList());
        super.m();
    }
}

