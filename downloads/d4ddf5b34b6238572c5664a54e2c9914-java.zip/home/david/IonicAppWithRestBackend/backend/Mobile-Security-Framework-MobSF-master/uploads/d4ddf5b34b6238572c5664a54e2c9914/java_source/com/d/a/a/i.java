/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.d.a.a;

import android.os.Handler;
import com.d.a.a.a.aa;
import com.d.a.a.a.ah;
import com.d.a.a.f;
import com.d.a.a.g;
import com.d.a.a.h;
import com.d.a.a.j;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public final class i
implements j {
    private final aa a;
    private final List<Object> b;
    private final HashMap<Object, h> c;
    private final Handler d;
    private final f e;
    private final long f;
    private final long g;
    private final float h;
    private final float i;
    private int j;
    private long k;
    private int l;
    private boolean m;
    private boolean n;

    public i(aa aa2, int n2, int n3, float f2, float f3) {
        this.a = aa2;
        this.d = null;
        this.e = null;
        this.b = new ArrayList<Object>();
        this.c = new HashMap();
        this.f = (long)n2 * 1000;
        this.g = (long)n3 * 1000;
        this.h = f2;
        this.i = f3;
    }

    private void a(boolean bl2) {
        if (this.d != null && this.e != null) {
            this.d.post((Runnable)new g(this, bl2));
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void c() {
        int n2;
        Object object;
        int n3 = 0;
        int n4 = this.l;
        boolean bl2 = false;
        boolean bl3 = false;
        for (n2 = 0; n2 < this.b.size(); bl2 |= bl3, ++n2) {
            object = this.c.get(this.b.get(n2));
            boolean bl4 = bl3 | object.c;
            bl3 = object.d != -1;
            n4 = Math.max(n4, object.b);
            bl3 = bl4;
        }
        boolean bl5 = !this.b.isEmpty() && (bl3 || bl2) && (n4 == 2 || n4 == 1 && this.m);
        this.m = bl5;
        if (this.m && !this.n) {
            ah.a.a();
            this.n = true;
            this.a(true);
        } else if (!this.m && this.n && !bl3) {
            ah.a.b();
            this.n = false;
            this.a(false);
        }
        this.k = -1;
        if (this.m) {
            for (n2 = n3; n2 < this.b.size(); ++n2) {
                object = this.b.get(n2);
                long l2 = this.c.get((Object)object).d;
                if (l2 == -1 || this.k != -1 && l2 >= this.k) continue;
                this.k = l2;
            }
        }
    }

    @Override
    public final void a() {
        this.a.a(this.j);
    }

    @Override
    public final void a(Object object) {
        this.b.remove(object);
        object = this.c.remove(object);
        this.j -= object.a;
        this.c();
    }

    @Override
    public final void a(Object object, int n2) {
        this.b.add(object);
        this.c.put(object, new h(n2));
        this.j += n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean a(Object object, long l2, long l3, boolean bl2) {
        float f2;
        int n2;
        int n3 = l3 == -1 ? 0 : ((l2 = l3 - l2) > this.g ? 0 : (l2 < this.f ? 2 : 1));
        object = this.c.get(object);
        boolean bl3 = object.b != n3 || object.d != l3 || object.c != bl2;
        if (bl3) {
            object.b = n3;
            object.d = l3;
            object.c = bl2;
        }
        n3 = (f2 = (float)(n2 = this.a.b()) / (float)this.j) > this.i ? 0 : (f2 < this.h ? 2 : 1);
        boolean bl4 = this.l != n3;
        if (bl4) {
            this.l = n3;
        }
        if (bl3 || bl4) {
            this.c();
        }
        if (n2 < this.j && l3 != -1 && l3 <= this.k) {
            return true;
        }
        return false;
    }

    @Override
    public final aa b() {
        return this.a;
    }
}

