/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.a.aa;

public interface j {
    public void a();

    public void a(Object var1);

    public void a(Object var1, int var2);

    public boolean a(Object var1, long var2, long var4, boolean var6);

    public aa b();
}

