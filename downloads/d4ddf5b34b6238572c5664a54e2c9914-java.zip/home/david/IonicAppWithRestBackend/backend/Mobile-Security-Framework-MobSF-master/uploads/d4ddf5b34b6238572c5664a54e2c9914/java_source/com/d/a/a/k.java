/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.o;
import com.d.a.a.q;

public final class k
extends o {
    @Override
    protected final q a(int n2) {
        throw new IllegalStateException();
    }

    @Override
    protected final void a(long l2) {
        throw new IllegalStateException();
    }

    @Override
    protected final void a(long l2, long l3) {
        throw new IllegalStateException();
    }

    @Override
    protected final boolean a() {
        return true;
    }

    @Override
    protected final int b() {
        return 0;
    }

    @Override
    protected final boolean c() {
        throw new IllegalStateException();
    }

    @Override
    protected final boolean d() {
        throw new IllegalStateException();
    }

    @Override
    protected final void e() {
        throw new IllegalStateException();
    }

    @Override
    protected final long f() {
        throw new IllegalStateException();
    }

    @Override
    protected final long g() {
        throw new IllegalStateException();
    }
}

