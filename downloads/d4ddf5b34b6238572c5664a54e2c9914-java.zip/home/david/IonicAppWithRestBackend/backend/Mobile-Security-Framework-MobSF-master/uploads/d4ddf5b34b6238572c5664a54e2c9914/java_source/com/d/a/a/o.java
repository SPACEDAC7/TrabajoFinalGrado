/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.q;
import com.d.a.a.r;

public abstract class o {
    public int a;

    protected abstract q a(int var1);

    public void a(int n2, long l2, boolean bl2) {
    }

    public void a(int n2, Object object) {
    }

    protected abstract void a(long var1);

    protected abstract void a(long var1, long var3);

    protected abstract boolean a();

    protected abstract int b();

    /*
     * Enabled aggressive block sorting
     */
    final int b(long l2) {
        int n2 = 1;
        int n3 = this.a == 0 ? 1 : 0;
        if (n3 == 0) {
            throw new IllegalStateException();
        }
        n3 = this.a() ? n2 : 0;
        this.a = n3;
        return this.a;
    }

    public abstract boolean c();

    public abstract boolean d();

    protected abstract void e();

    protected abstract long f();

    public abstract long g();

    public r h() {
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    final void i() {
        boolean bl2 = this.a == 2;
        if (!bl2) {
            throw new IllegalStateException();
        }
        this.a = 3;
        this.j();
    }

    protected void j() {
    }

    /*
     * Enabled aggressive block sorting
     */
    final void k() {
        boolean bl2 = this.a == 3;
        if (!bl2) {
            throw new IllegalStateException();
        }
        this.a = 2;
        this.l();
    }

    protected void l() {
    }

    public void m() {
    }

    /*
     * Enabled aggressive block sorting
     */
    final void n() {
        boolean bl2 = this.a != 2 && this.a != 3 && this.a != -1;
        if (!bl2) {
            throw new IllegalStateException();
        }
        this.a = -1;
        this.o();
    }

    protected void o() {
    }
}

