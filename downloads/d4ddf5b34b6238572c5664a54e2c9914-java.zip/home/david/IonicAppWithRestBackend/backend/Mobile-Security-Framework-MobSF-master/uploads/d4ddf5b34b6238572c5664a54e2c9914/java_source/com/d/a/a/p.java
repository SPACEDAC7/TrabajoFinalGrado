/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

public final class p
extends Exception {
    public final boolean a;

    public p(String string) {
        super(string);
        this.a = false;
    }

    public p(Throwable throwable) {
        super(throwable);
        this.a = false;
    }

    p(Throwable throwable, byte by2) {
        super(throwable);
        this.a = true;
    }
}

