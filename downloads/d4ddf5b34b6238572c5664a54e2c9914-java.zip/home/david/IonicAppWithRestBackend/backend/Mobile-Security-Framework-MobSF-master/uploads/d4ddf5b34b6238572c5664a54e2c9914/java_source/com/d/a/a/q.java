/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.annotation.TargetApi
 *  android.media.MediaFormat
 */
package com.d.a.a;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.media.MediaFormat;
import com.d.a.a.d.ah;
import com.d.a.a.d.y;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class q {
    public final String a;
    public final String b;
    public final int c;
    public final int d;
    public final long e;
    public final List<byte[]> f;
    public final boolean g;
    public final int h;
    public final int i;
    public final int j;
    public final int k;
    public final int l;
    public final float m;
    public final int n;
    public final int o;
    public final int p;
    public final int q;
    public final String r;
    public final long s;
    MediaFormat t;
    boolean u = false;
    private int v;

    public q(String list, String string, int n2, int n3, long l2, int n4, int n5, int n6, float f2, int n7, int n8, String string2, long l3, List<byte[]> list2, boolean bl2, int n9, int n10, int n11, int n12) {
        this.a = list;
        this.b = y.a(string);
        this.c = n2;
        this.d = n3;
        this.e = l2;
        this.h = n4;
        this.i = n5;
        this.l = n6;
        this.m = f2;
        this.n = n7;
        this.o = n8;
        this.r = string2;
        this.s = l3;
        list = list2;
        if (list2 == null) {
            list = Collections.emptyList();
        }
        this.f = list;
        this.g = bl2;
        this.j = n9;
        this.k = n10;
        this.p = n11;
        this.q = n12;
    }

    public static q a() {
        return new q(null, "application/id3", -1, -1, -1, -1, -1, -1, -1.0f, -1, -1, null, Long.MAX_VALUE, null, false, -1, -1, -1, -1);
    }

    public static q a(String string, String string2, int n2, int n3, long l2, int n4, int n5, List<byte[]> list, int n6, float f2) {
        return new q(string, string2, n2, n3, l2, n4, n5, n6, f2, -1, -1, null, Long.MAX_VALUE, list, false, -1, -1, -1, -1);
    }

    public static q a(String string, String string2, int n2, int n3, long l2, int n4, int n5, List<byte[]> list, String string3) {
        return new q(string, string2, n2, n3, l2, -1, -1, -1, -1.0f, n4, n5, string3, Long.MAX_VALUE, list, false, -1, -1, -1, -1);
    }

    public static q a(String string, String string2, int n2, long l2, String string3, long l3) {
        return new q(string, string2, n2, -1, l2, -1, -1, -1, -1.0f, -1, -1, string3, l3, null, false, -1, -1, -1, -1);
    }

    public final q a(int n2, int n3) {
        return new q(this.a, this.b, this.c, this.d, this.e, this.h, this.i, this.l, this.m, this.n, this.o, this.r, this.s, this.f, this.g, this.j, this.k, n2, n3);
    }

    @SuppressLint(value={"InlinedApi"})
    @TargetApi(value=16)
    public final MediaFormat b() {
        if (this.t == null) {
            int n2;
            MediaFormat mediaFormat = new MediaFormat();
            mediaFormat.setString("mime", this.b);
            String string = this.r;
            if (string != null) {
                mediaFormat.setString("language", string);
            }
            if ((n2 = this.d) != -1) {
                mediaFormat.setInteger("max-input-size", n2);
            }
            if ((n2 = this.h) != -1) {
                mediaFormat.setInteger("width", n2);
            }
            if ((n2 = this.i) != -1) {
                mediaFormat.setInteger("height", n2);
            }
            if ((n2 = this.l) != -1) {
                mediaFormat.setInteger("rotation-degrees", n2);
            }
            if ((n2 = this.j) != -1) {
                mediaFormat.setInteger("max-width", n2);
            }
            if ((n2 = this.k) != -1) {
                mediaFormat.setInteger("max-height", n2);
            }
            if ((n2 = this.n) != -1) {
                mediaFormat.setInteger("channel-count", n2);
            }
            if ((n2 = this.o) != -1) {
                mediaFormat.setInteger("sample-rate", n2);
            }
            if ((n2 = this.p) != -1) {
                mediaFormat.setInteger("encoder-delay", n2);
            }
            if ((n2 = this.q) != -1) {
                mediaFormat.setInteger("encoder-padding", n2);
            }
            if (this.u) {
                mediaFormat.setInteger("is-adts", 1);
            }
            for (n2 = 0; n2 < this.f.size(); ++n2) {
                mediaFormat.setByteBuffer("csd-" + n2, ByteBuffer.wrap(this.f.get(n2)));
            }
            if (this.e != -1) {
                mediaFormat.setLong("durationUs", this.e);
            }
            this.t = mediaFormat;
        }
        return this.t;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        boolean bl2 = false;
        if (this == object) {
            return true;
        }
        boolean bl3 = bl2;
        if (object == null) return bl3;
        bl3 = bl2;
        if (this.getClass() != object.getClass()) return bl3;
        object = (q)object;
        bl3 = bl2;
        if (this.g != object.g) return bl3;
        bl3 = bl2;
        if (this.c != object.c) return bl3;
        bl3 = bl2;
        if (this.d != object.d) return bl3;
        bl3 = bl2;
        if (this.h != object.h) return bl3;
        bl3 = bl2;
        if (this.i != object.i) return bl3;
        bl3 = bl2;
        if (this.l != object.l) return bl3;
        bl3 = bl2;
        if (this.m != object.m) return bl3;
        bl3 = bl2;
        if (this.j != object.j) return bl3;
        bl3 = bl2;
        if (this.k != object.k) return bl3;
        bl3 = bl2;
        if (this.p != object.p) return bl3;
        bl3 = bl2;
        if (this.q != object.q) return bl3;
        bl3 = bl2;
        if (this.n != object.n) return bl3;
        bl3 = bl2;
        if (this.o != object.o) return bl3;
        bl3 = bl2;
        if (!ah.a(this.a, (Object)object.a)) return bl3;
        bl3 = bl2;
        if (!ah.a(this.r, (Object)object.r)) return bl3;
        bl3 = bl2;
        if (!ah.a(this.b, (Object)object.b)) return bl3;
        bl3 = bl2;
        if (this.f.size() != object.f.size()) return bl3;
        int n2 = 0;
        while (n2 < this.f.size()) {
            bl3 = bl2;
            if (!Arrays.equals(this.f.get(n2), object.f.get(n2))) return bl3;
            ++n2;
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int hashCode() {
        int n2 = 0;
        if (this.v != 0) return this.v;
        int n3 = this.a == null ? 0 : this.a.hashCode();
        int n4 = this.b == null ? 0 : this.b.hashCode();
        int n5 = this.c;
        int n6 = this.d;
        int n7 = this.h;
        int n8 = this.i;
        int n9 = this.l;
        int n10 = Float.floatToRawIntBits(this.m);
        int n11 = (int)this.e;
        int n12 = this.g ? 1231 : 1237;
        int n13 = this.j;
        int n14 = this.k;
        int n15 = this.p;
        int n16 = this.q;
        int n17 = this.n;
        int n18 = this.o;
        int n19 = this.r == null ? 0 : this.r.hashCode();
        n4 = n19 + (((((((n12 + ((((((((n4 + (n3 + 527) * 31) * 31 + n5) * 31 + n6) * 31 + n7) * 31 + n8) * 31 + n9) * 31 + n10) * 31 + n11) * 31) * 31 + n13) * 31 + n14) * 31 + n15) * 31 + n16) * 31 + n17) * 31 + n18) * 31;
        n3 = n2;
        do {
            if (n3 >= this.f.size()) {
                this.v = n4;
                return this.v;
            }
            n4 = Arrays.hashCode(this.f.get(n3)) + n4 * 31;
            ++n3;
        } while (true);
    }

    public final String toString() {
        return "MediaFormat(" + this.a + ", " + this.b + ", " + this.c + ", " + this.d + ", " + this.h + ", " + this.i + ", " + this.l + ", " + this.m + ", " + this.n + ", " + this.o + ", " + this.r + ", " + this.e + ", " + this.g + ", " + this.j + ", " + this.k + ", " + this.p + ", " + this.q + ")";
    }
}

