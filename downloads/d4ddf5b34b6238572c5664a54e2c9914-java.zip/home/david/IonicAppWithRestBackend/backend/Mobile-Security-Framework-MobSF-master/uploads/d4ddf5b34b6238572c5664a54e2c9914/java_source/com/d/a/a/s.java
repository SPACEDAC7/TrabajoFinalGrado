/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  com.d.a.a.l
 */
package com.d.a.a;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.d.a.a.l;
import com.d.a.a.p;
import com.d.a.a.q;
import com.d.a.a.t;
import com.facebook.b.a.a;
import com.instagram.common.f.c;
import com.instagram.exoplayer.service.k;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

final class s
extends Handler {
    final /* synthetic */ t a;

    s(t t2, Looper looper) {
        this.a = t2;
        super(looper);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void handleMessage(Message iterator) {
        Object object = this.a;
        switch (iterator.what) {
            default: {
                return;
            }
            case 1: {
                System.arraycopy(iterator.obj, 0, object.b, 0, object.b.length);
                object.c = iterator.arg1;
                iterator = object.a.iterator();
                while (iterator.hasNext()) {
                    ((k)iterator.next()).a(object.c);
                }
                return;
            }
            case 2: {
                object.c = iterator.arg1;
                iterator = object.a.iterator();
                while (iterator.hasNext()) {
                    ((k)iterator.next()).a(object.c);
                }
                return;
            }
            case 3: {
                --object.d;
                if (object.d != 0) return;
                iterator = object.a.iterator();
                while (iterator.hasNext()) {
                    iterator.next();
                }
                return;
            }
            case 4: 
        }
        iterator = (p)iterator.obj;
        object = object.a.iterator();
        while (object.hasNext()) {
            k k2 = (k)object.next();
            a.b("IgExoPlayer", "onPlayerError()", iterator);
            String string = iterator.getMessage();
            c.a().a("ig_exo_player_error", string, (Throwable)((Object)iterator), false);
            com.instagram.exoplayer.service.q.a(k2.a, "unknown_error", iterator.getMessage());
        }
    }
}

