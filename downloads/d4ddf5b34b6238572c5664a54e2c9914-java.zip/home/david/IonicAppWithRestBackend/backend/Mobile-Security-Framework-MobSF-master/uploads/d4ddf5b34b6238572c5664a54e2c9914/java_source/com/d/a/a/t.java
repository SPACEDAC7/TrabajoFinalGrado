/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  android.util.Pair
 *  com.d.a.a.l
 */
package com.d.a.a;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Pair;
import com.d.a.a.d.ah;
import com.d.a.a.l;
import com.d.a.a.o;
import com.d.a.a.q;
import com.d.a.a.s;
import com.d.a.a.u;
import com.instagram.exoplayer.service.k;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

public final class t {
    public final CopyOnWriteArraySet<l> a = new CopyOnWriteArraySet();
    public final q[][] b = new q[3][];
    int c = 1;
    int d;
    private final Handler e;
    public final u f;
    public final int[] g = new int[3];
    public boolean h = false;

    @SuppressLint(value={"HandlerLeak"})
    public t(int n2, int n3, int n4) {
        this.e = new s(this, Looper.getMainLooper());
        this.f = new u(this.e, this.h, this.g, 500, 2000);
    }

    public final void a(int n2) {
        if (this.g[0] != n2) {
            this.g[0] = n2;
            this.f.a.obtainMessage(8, 0, n2).sendToTarget();
        }
    }

    public final void a(long l2) {
        u u2 = this.f;
        u2.d = l2;
        u2.b.incrementAndGet();
        u2.a.obtainMessage(6, ah.a(l2), (int)l2).sendToTarget();
    }

    public final void a(o o2, Object object) {
        u u2 = this.f;
        ++u2.c;
        u2.a.obtainMessage(9, 1, 0, (Object)Pair.create((Object)o2, (Object)object)).sendToTarget();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(boolean bl2) {
        if (this.h != bl2) {
            this.h = bl2;
            ++this.d;
            Object object = this.f.a;
            int n2 = bl2 ? 1 : 0;
            object.obtainMessage(3, n2, 0).sendToTarget();
            object = this.a.iterator();
            while (object.hasNext()) {
                ((k)object.next()).a(this.c);
            }
        }
    }

    public final void d() {
        this.f.a();
        this.e.removeCallbacksAndMessages((Object)null);
    }

    public final long f() {
        u u2 = this.f;
        if (u2.b.get() > 0) {
            return u2.d;
        }
        return u2.f / 1000;
    }
}

