/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.os.Message
 *  android.os.SystemClock
 *  android.util.Log
 *  android.util.Pair
 */
package com.d.a.a;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.util.Pair;
import com.d.a.a.d.ad;
import com.d.a.a.o;
import com.d.a.a.p;
import com.d.a.a.q;
import com.d.a.a.r;
import com.d.a.a.v;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public final class u
implements Handler.Callback {
    public final Handler a;
    final AtomicInteger b;
    int c = 0;
    long d;
    public volatile long e;
    volatile long f;
    private final HandlerThread g;
    private final Handler h;
    private final v i;
    private final v j;
    private final List<o> k;
    private final q[][] l;
    private final int[] m;
    private final long n;
    private final long o;
    private o[] p;
    private o q;
    private r r;
    private boolean s;
    private boolean t;
    private boolean u;
    private int v;
    private int w = 0;
    private long x;
    private volatile long y;

    public u(Handler handler, boolean bl2, int[] arrn, int n2, int n3) {
        this.h = handler;
        this.t = bl2;
        this.n = (long)n2 * 1000;
        this.o = (long)n3 * 1000;
        this.m = Arrays.copyOf(arrn, arrn.length);
        this.v = 1;
        this.e = -1;
        this.y = -1;
        this.i = new v();
        this.j = new v();
        this.b = new AtomicInteger();
        this.k = new ArrayList<o>(arrn.length);
        this.l = new q[arrn.length][];
        this.g = new ad("ExoPlayerImplInternal:Handler");
        this.g.start();
        this.a = new Handler(this.g.getLooper(), (Handler.Callback)this);
    }

    private void a(int n2) {
        if (this.v != n2) {
            this.v = n2;
            this.h.obtainMessage(2, n2, 0).sendToTarget();
        }
    }

    private void a(int n2, long l2, long l3) {
        if ((l2 = l2 + l3 - SystemClock.elapsedRealtime()) <= 0) {
            this.a.sendEmptyMessage(n2);
            return;
        }
        this.a.sendEmptyMessageDelayed(n2, l2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(o o2, int n2, boolean bl2) {
        int n3 = 1;
        long l2 = this.f;
        boolean bl3 = o2.a == 1;
        if (!bl3) {
            throw new IllegalStateException();
        }
        o2.a = 2;
        o2.a(n2, l2, bl2);
        this.k.add(o2);
        r r2 = o2.h();
        if (r2 != null) {
            n2 = this.r == null ? n3 : 0;
            if (n2 == 0) {
                throw new IllegalStateException();
            }
            this.r = r2;
            this.q = o2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private boolean a(o o2) {
        if (o2.c()) {
            return true;
        }
        if (!o2.d()) {
            return false;
        }
        if (this.v == 4) return true;
        long l2 = o2.f();
        long l3 = o2.g();
        long l4 = this.u ? this.o : this.n;
        if (l4 <= 0) return true;
        if (l3 == -1) return true;
        if (l3 == -3) return true;
        if (l3 >= l4 + this.f) return true;
        if (l2 == -1) return false;
        if (l2 == -2) return false;
        if (l3 >= l2) return true;
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b() {
        int n2;
        o o2;
        int n3;
        long l2 = SystemClock.elapsedRealtime();
        int n4 = 1;
        for (n2 = 0; n2 < this.p.length; ++n2) {
            o2 = this.p[n2];
            n3 = n4;
            if (o2.a == 0) {
                n3 = n4;
                if (o2.b(this.f) == 0) {
                    o2.e();
                    n3 = 0;
                }
            }
            n4 = n3;
        }
        if (n4 == 0) {
            this.a(2, l2, 10);
            return;
        }
        long l3 = 0;
        n4 = 1;
        int n5 = 1;
        for (n3 = 0; n3 < this.p.length; ++n3) {
            o2 = this.p[n3];
            int n6 = o2.b();
            q[] arrq = new q[n6];
            for (n2 = 0; n2 < n6; ++n2) {
                arrq[n2] = o2.a(n2);
            }
            this.l[n3] = arrq;
            n2 = n5;
            int n7 = n4;
            long l4 = l3;
            if (n6 > 0) {
                l2 = l3;
                if (l3 != -1) {
                    l4 = o2.f();
                    if (l4 == -1) {
                        l2 = -1;
                    } else {
                        l2 = l3;
                        if (l4 != -2) {
                            l2 = Math.max(l3, l4);
                        }
                    }
                }
                n6 = this.m[n3];
                n2 = n5;
                n7 = n4;
                l4 = l2;
                if (n6 >= 0) {
                    n2 = n5;
                    n7 = n4;
                    l4 = l2;
                    if (n6 < arrq.length) {
                        this.a(o2, n6, false);
                        n4 = n4 != 0 && o2.c() ? 1 : 0;
                        if (n5 != 0 && this.a(o2)) {
                            n2 = 1;
                            l4 = l2;
                            n7 = n4;
                        } else {
                            n2 = 0;
                            n7 = n4;
                            l4 = l2;
                        }
                    }
                }
            }
            n5 = n2;
            n4 = n7;
            l3 = l4;
        }
        this.e = l3;
        n2 = n4 != 0 && (l3 == -1 || l3 <= this.f) ? 5 : (n5 != 0 ? 4 : 3);
        this.v = n2;
        this.h.obtainMessage(1, this.v, 0, (Object)this.l).sendToTarget();
        if (this.t && this.v == 4) {
            this.c();
        }
        this.a.sendEmptyMessage(7);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(o o2) {
        if (o2.a == 3) {
            o2.k();
        }
        if (o2.a == 2) {
            boolean bl2 = o2.a == 2;
            if (!bl2) {
                throw new IllegalStateException();
            }
            o2.a = 1;
            o2.m();
            if (o2 == this.q) {
                this.r = null;
                this.q = null;
            }
        }
    }

    private void c() {
        this.u = false;
        this.i.b();
        this.j.b();
        for (int i2 = 0; i2 < this.k.size(); ++i2) {
            this.k.get(i2).i();
        }
    }

    private void d() {
        this.i.c();
        this.j.c();
        for (int i2 = 0; i2 < this.k.size(); ++i2) {
            o o2 = this.k.get(i2);
            if (o2.a != 3) continue;
            o2.k();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void e() {
        if (this.r != null && this.k.contains(this.q) && !this.q.c()) {
            long l2;
            this.f = this.r.a_();
            v v2 = this.i;
            v2.a = l2 = this.f;
            v2.b = SystemClock.elapsedRealtime() * 1000 - l2;
        } else {
            this.f = this.i.a_();
        }
        this.x = SystemClock.elapsedRealtime() * 1000;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void f() {
        int n2 = 0;
        this.a.removeMessages(7);
        this.a.removeMessages(2);
        this.u = false;
        this.i.c();
        this.j.c();
        if (this.p == null) {
            return;
        }
        do {
            if (n2 >= this.p.length) {
                this.p = null;
                this.r = null;
                this.q = null;
                this.k.clear();
                return;
            }
            o o2 = this.p[n2];
            try {
                this.b(o2);
            }
            catch (p var3_6) {
                Log.e((String)"ExoPlayerImplInternal", (String)"Stop failed.", (Throwable)var3_6);
            }
            catch (RuntimeException var3_7) {
                Log.e((String)"ExoPlayerImplInternal", (String)"Stop failed.", (Throwable)var3_7);
            }
            try {
                o2.n();
            }
            catch (p var2_3) {
                Log.e((String)"ExoPlayerImplInternal", (String)"Release failed.", (Throwable)var2_3);
            }
            catch (RuntimeException var2_4) {
                Log.e((String)"ExoPlayerImplInternal", (String)"Release failed.", (Throwable)var2_4);
            }
            ++n2;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a() {
        synchronized (this) {
            boolean bl2 = this.s;
            if (!bl2) {
                this.a.sendEmptyMessage(5);
                while (!(bl2 = this.s)) {
                    try {
                        this.wait();
                    }
                    catch (InterruptedException var2_2) {
                        Thread.currentThread().interrupt();
                    }
                }
                this.g.quit();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final void a(o o2, int n2, Object object) {
        void var3_4;
        // MONITORENTER : this
        if (this.s) {
            Log.w((String)"ExoPlayerImplInternal", (String)("Sent message(1" + ") after release. Message ignored."));
            return;
        }
        int n3 = this.c;
        this.c = n3 + 1;
        this.a.obtainMessage(9, 1, 0, (Object)Pair.create((Object)o2, (Object)var3_4)).sendToTarget();
        do {
            int n4;
            if ((n4 = this.w) > n3) {
                // MONITOREXIT : this
                return;
            }
            try {
                this.wait();
                continue;
            }
            catch (InterruptedException var1_2) {
                Thread.currentThread().interrupt();
                continue;
            }
            break;
        } while (true);
    }

    /*
     * Exception decompiling
     */
    public final boolean handleMessage(Message var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }
}

