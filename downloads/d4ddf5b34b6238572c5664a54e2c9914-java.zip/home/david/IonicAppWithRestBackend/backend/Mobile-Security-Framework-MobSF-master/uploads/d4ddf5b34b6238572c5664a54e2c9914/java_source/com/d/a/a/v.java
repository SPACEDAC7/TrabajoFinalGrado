/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.SystemClock
 */
package com.d.a.a;

import android.os.SystemClock;
import com.d.a.a.r;

final class v
implements r {
    long a;
    long b;
    private boolean c;

    v() {
    }

    @Override
    public final long a_() {
        if (this.c) {
            long l2 = this.b;
            return SystemClock.elapsedRealtime() * 1000 - l2;
        }
        return this.a;
    }

    public final void b() {
        if (!this.c) {
            this.c = true;
            long l2 = this.a;
            this.b = SystemClock.elapsedRealtime() * 1000 - l2;
        }
    }

    public final void c() {
        if (this.c) {
            long l2 = this.b;
            this.a = SystemClock.elapsedRealtime() * 1000 - l2;
            this.c = false;
        }
    }
}

