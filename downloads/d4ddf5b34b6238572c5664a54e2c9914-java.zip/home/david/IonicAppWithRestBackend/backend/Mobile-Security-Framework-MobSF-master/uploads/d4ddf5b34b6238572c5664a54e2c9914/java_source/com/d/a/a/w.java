/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.q;
import com.d.a.a.y;
import com.d.a.a.z;

public interface w {
    public int a(int var1, long var2, y var4, z var5);

    public q a(int var1);

    public void a(int var1, long var2);

    public void a(long var1);

    public long b(int var1);

    public boolean b();

    public boolean b(int var1, long var2);

    public void b_();

    public int c();

    public void c(int var1);

    public long d();

    public void e();
}

