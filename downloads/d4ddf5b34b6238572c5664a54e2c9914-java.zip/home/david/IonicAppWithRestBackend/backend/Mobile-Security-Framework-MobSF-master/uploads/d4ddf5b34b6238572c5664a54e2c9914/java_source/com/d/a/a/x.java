/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.w;

public interface x {
    public w f();
}

