/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.b.d;
import com.d.a.a.q;

public final class y {
    public q a;
    public d b;
}

