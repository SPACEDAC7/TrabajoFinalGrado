/*
 * Decompiled with CFR 0_115.
 */
package com.d.a.a;

import com.d.a.a.d;
import java.nio.Buffer;
import java.nio.ByteBuffer;

public final class z {
    public final d a = new d();
    public ByteBuffer b;
    public int c;
    public int d;
    public long e;
    private final int f;

    public z(int n2) {
        this.f = n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private ByteBuffer b(int n2) {
        int n3;
        if (this.f == 1) {
            return ByteBuffer.allocate(n2);
        }
        if (this.f == 2) {
            return ByteBuffer.allocateDirect(n2);
        }
        if (this.b == null) {
            n3 = 0;
            do {
                throw new IllegalStateException("Buffer too small (" + n3 + " < " + n2 + ")");
                break;
            } while (true);
        }
        n3 = this.b.capacity();
        throw new IllegalStateException("Buffer too small (" + n3 + " < " + n2 + ")");
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2) {
        if (this.b == null) {
            this.b = this.b(n2);
            return;
        } else {
            int n3;
            int n4 = this.b.capacity();
            if (n4 >= (n2 = (n3 = this.b.position()) + n2)) return;
            {
                ByteBuffer byteBuffer = this.b(n2);
                if (n3 > 0) {
                    this.b.position(0);
                    this.b.limit(n3);
                    byteBuffer.put(this.b);
                }
                this.b = byteBuffer;
                return;
            }
        }
    }
}

