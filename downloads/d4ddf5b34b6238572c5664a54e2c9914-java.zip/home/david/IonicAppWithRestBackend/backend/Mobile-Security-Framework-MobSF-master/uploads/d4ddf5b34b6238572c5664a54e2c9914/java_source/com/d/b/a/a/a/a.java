/*
 * Decompiled with CFR 0_115.
 */
package com.d.b.a.a.a;

import com.d.b.a.a.a.c;

public final class a
extends c {
    private static final char[] a = new char[]{'+'};
    private static final char[] b = "0123456789ABCDEF".toCharArray();
    private final boolean c;
    private final boolean[] d;

    public a(String arrc) {
        int n2;
        if (arrc.matches(".*[0-9A-Za-z].*")) {
            throw new IllegalArgumentException("Alphanumeric characters are always 'safe' and should not be explicitly specified");
        }
        if (arrc.contains("%")) {
            throw new IllegalArgumentException("The '%' character cannot be specified as 'safe'");
        }
        this.c = false;
        int n3 = 0;
        arrc = arrc.toCharArray();
        int n4 = arrc.length;
        int n5 = 122;
        for (n2 = 0; n2 < n4; ++n2) {
            n5 = Math.max(arrc[n2], n5);
        }
        boolean[] arrbl = new boolean[n5 + 1];
        for (n2 = 48; n2 <= 57; ++n2) {
            arrbl[n2] = true;
        }
        for (n2 = 65; n2 <= 90; ++n2) {
            arrbl[n2] = true;
        }
        for (n2 = 97; n2 <= 122; ++n2) {
            arrbl[n2] = true;
        }
        n5 = arrc.length;
        for (n2 = n3; n2 < n5; ++n2) {
            arrbl[arrc[n2]] = true;
        }
        this.d = arrbl;
    }

    @Override
    protected final int a(CharSequence charSequence, int n2, int n3) {
        char c2;
        while (n2 < n3 && (c2 = charSequence.charAt(n2)) < this.d.length && this.d[c2]) {
            ++n2;
        }
        return n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final String a(String string) {
        int n2 = string.length();
        int n3 = 0;
        do {
            String string2 = string;
            if (n3 >= n2) return string2;
            char c2 = string.charAt(n3);
            if (c2 >= this.d.length) return this.a(string, n3);
            if (!this.d[c2]) {
                return this.a(string, n3);
            }
            ++n3;
        } while (true);
    }

    @Override
    protected final char[] a(int n2) {
        if (n2 < this.d.length && this.d[n2]) {
            return null;
        }
        if (n2 == 32 && this.c) {
            return a;
        }
        if (n2 <= 127) {
            char c2 = b[n2 & 15];
            return new char[]{'%', b[n2 >>> 4], c2};
        }
        if (n2 <= 2047) {
            char c3 = b[n2 & 15];
            char c4 = b[(n2 >>>= 4) & 3 | 8];
            char c5 = b[(n2 >>>= 2) & 15];
            return new char[]{'%', b[n2 >>> 4 | 12], c5, '%', c4, c3};
        }
        if (n2 <= 65535) {
            char c6 = b[n2 & 15];
            char c7 = b[(n2 >>>= 4) & 3 | 8];
            char c8 = b[(n2 >>>= 2) & 15];
            char c9 = b[(n2 >>>= 4) & 3 | 8];
            return new char[]{'%', 'E', b[n2 >>> 2], '%', c9, c8, '%', c7, c6};
        }
        if (n2 <= 1114111) {
            char c10 = b[n2 & 15];
            char c11 = b[(n2 >>>= 4) & 3 | 8];
            char c12 = b[(n2 >>>= 2) & 15];
            char c13 = b[(n2 >>>= 4) & 3 | 8];
            char c14 = b[(n2 >>>= 2) & 15];
            char c15 = b[(n2 >>>= 4) & 3 | 8];
            return new char[]{'%', 'F', b[n2 >>> 2 & 7], '%', c15, c14, '%', c13, c12, '%', c11, c10};
        }
        throw new IllegalArgumentException("Invalid unicode character value " + n2);
    }
}

