/*
 * Decompiled with CFR 0_115.
 */
package com.d.b.a.a.a;

final class b
extends ThreadLocal<char[]> {
    b() {
    }
}

