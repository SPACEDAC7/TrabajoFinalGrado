/*
 * Decompiled with CFR 0_115.
 */
package com.d.b.a.a.a;

import com.d.b.a.a.a.b;

public abstract class c {
    private static final ThreadLocal<char[]> a = new b();

    private static final char[] a(char[] arrc, int n2, int n3) {
        char[] arrc2 = new char[n3];
        if (n2 > 0) {
            System.arraycopy(arrc, 0, arrc2, 0, n2);
        }
        return arrc2;
    }

    private static int b(CharSequence charSequence, int n2, int n3) {
        if (n2 < n3) {
            int n4 = n2 + 1;
            char c2 = charSequence.charAt(n2);
            if (c2 < '\ud800' || c2 > '\udfff') {
                return c2;
            }
            if (c2 <= '\udbff') {
                if (n4 == n3) {
                    return - c2;
                }
                char c3 = charSequence.charAt(n4);
                if (Character.isLowSurrogate(c3)) {
                    return Character.toCodePoint(c2, c3);
                }
                throw new IllegalArgumentException("Expected low surrogate but got char '" + c3 + "' with value " + c3 + " at index " + n4);
            }
            throw new IllegalArgumentException("Unexpected low surrogate character '" + c2 + "' with value " + c2 + " at index " + (n4 - 1));
        }
        throw new IndexOutOfBoundsException("Index exceeds specified range");
    }

    /*
     * Enabled aggressive block sorting
     */
    protected int a(CharSequence charSequence, int n2, int n3) {
        int n4;
        while (n2 < n3 && (n4 = c.b(charSequence, n2, n3)) >= 0 && this.a(n4) == null) {
            n4 = Character.isSupplementaryCodePoint(n4) ? 2 : 1;
            n2 += n4;
        }
        return n2;
    }

    public String a(String string) {
        int n2 = string.length();
        int n3 = this.a(string, 0, n2);
        if (n3 == n2) {
            return string;
        }
        return this.a(string, n3);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final String a(String string, int n2) {
        int n3;
        char[] arrc;
        int n4 = string.length();
        char[] arrc2 = a.get();
        int n5 = 0;
        int n6 = 0;
        int n7 = n2;
        n2 = n6;
        while (n7 < n4) {
            int n8 = c.b(string, n7, n4);
            if (n8 < 0) {
                throw new IllegalArgumentException("Trailing high surrogate at end of input");
            }
            char[] arrc3 = this.a(n8);
            n6 = n2;
            char[] arrc4 = arrc2;
            if (arrc3 != null) {
                n6 = n7 - n5;
                n3 = n2 + n6 + arrc3.length;
                arrc = arrc2;
                if (arrc2.length < n3) {
                    arrc = c.a(arrc2, n2, n3 + (n4 - n7) + 32);
                }
                n3 = n2;
                if (n6 > 0) {
                    string.getChars(n5, n7, arrc, n2);
                    n3 = n2 + n6;
                }
                n6 = n3;
                arrc4 = arrc;
                if (arrc3.length > 0) {
                    System.arraycopy(arrc3, 0, arrc, n3, arrc3.length);
                    n6 = n3 + arrc3.length;
                    arrc4 = arrc;
                }
            }
            n2 = Character.isSupplementaryCodePoint(n8) ? 2 : 1;
            n5 = n2 + n7;
            n7 = this.a(string, n5, n4);
            n2 = n6;
            arrc2 = arrc4;
        }
        n3 = n4 - n5;
        n6 = n2;
        arrc = arrc2;
        if (n3 > 0) {
            n6 = n3 + n2;
            arrc = arrc2;
            if (arrc2.length < n6) {
                arrc = c.a(arrc2, n2, n6);
            }
            string.getChars(n5, n4, arrc, n2);
        }
        return new String(arrc, 0, n6);
    }

    protected abstract char[] a(int var1);
}

