/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 */
package com.facebook;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.facebook.a;
import com.facebook.b;
import com.facebook.n;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class AccessToken
implements Parcelable {
    public static final Parcelable.Creator CREATOR;
    private static final Date i;
    private static final Date j;
    private static final Date k;
    private static final b l;
    public final Date a;
    public final Set<String> b;
    public final Set<String> c;
    public final String d;
    public final b e;
    public final Date f;
    public final String g;
    public final String h;

    static {
        Date date;
        i = date = new Date(Long.MAX_VALUE);
        j = date;
        k = new Date();
        l = b.b;
        CREATOR = new a();
    }

    AccessToken(Parcel parcel) {
        this.a = new Date(parcel.readLong());
        ArrayList arrayList = new ArrayList();
        parcel.readStringList(arrayList);
        this.b = Collections.unmodifiableSet(new HashSet(arrayList));
        arrayList.clear();
        parcel.readStringList(arrayList);
        this.c = Collections.unmodifiableSet(new HashSet(arrayList));
        this.d = parcel.readString();
        this.e = b.valueOf(parcel.readString());
        this.f = new Date(parcel.readLong());
        this.g = parcel.readString();
        this.h = parcel.readString();
    }

    public AccessToken(String string, String string2) {
        this(string, n.a, string2, null, null, b.g, null, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public AccessToken(String string, String string2, String string3, Collection<String> collection, Collection<String> collection2, b b2, Date date, Date date2) {
        if (date == null) {
            date = j;
        }
        this.a = date;
        collection = collection != null ? new HashSet<String>(collection) : new HashSet<String>();
        this.b = Collections.unmodifiableSet(collection);
        collection = collection2 != null ? new HashSet<String>(collection2) : new HashSet<String>();
        this.c = Collections.unmodifiableSet(collection);
        this.d = string;
        if (b2 == null) {
            b2 = l;
        }
        this.e = b2;
        if (date2 == null) {
            date2 = k;
        }
        this.f = date2;
        this.g = string2;
        this.h = string3;
    }

    public final int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof AccessToken)) {
            return false;
        }
        object = (AccessToken)object;
        if (!this.a.equals(object.a)) return false;
        if (!this.b.equals(object.b)) return false;
        if (!this.c.equals(object.c)) return false;
        if (!this.d.equals(object.d)) return false;
        if (this.e != object.e) return false;
        if (!this.f.equals(object.f)) return false;
        if (this.g == null) {
            if (object.g != null) return false;
        } else if (!this.g.equals(object.g)) return false;
        if (this.h.equals(object.h)) return true;
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final int hashCode() {
        int n2;
        int n3 = this.a.hashCode();
        int n4 = this.b.hashCode();
        int n5 = this.c.hashCode();
        int n6 = this.d.hashCode();
        int n7 = this.e.hashCode();
        int n8 = this.f.hashCode();
        if (this.g == null) {
            n2 = 0;
            do {
                return (n2 + ((((((n3 + 527) * 31 + n4) * 31 + n5) * 31 + n6) * 31 + n7) * 31 + n8) * 31) * 31 + this.h.hashCode();
                break;
            } while (true);
        }
        n2 = this.g.hashCode();
        return (n2 + ((((((n3 + 527) * 31 + n4) * 31 + n5) * 31 + n6) * 31 + n7) * 31 + n8) * 31) * 31 + this.h.hashCode();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("{AccessToken");
        StringBuilder stringBuilder2 = stringBuilder.append(" token:");
        String string = this.d == null ? "null" : "ACCESS_TOKEN_REMOVED";
        stringBuilder2.append(string);
        stringBuilder.append(" permissions:");
        if (this.b == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append("[");
            stringBuilder.append(TextUtils.join((CharSequence)", ", this.b));
            stringBuilder.append("]");
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public final void writeToParcel(Parcel parcel, int n2) {
        parcel.writeLong(this.a.getTime());
        parcel.writeStringList(new ArrayList<String>(this.b));
        parcel.writeStringList(new ArrayList<String>(this.c));
        parcel.writeString(this.d);
        parcel.writeString(this.e.name());
        parcel.writeLong(this.f.getTime());
        parcel.writeString(this.g);
        parcel.writeString(this.h);
    }
}

