/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.res.Configuration
 *  android.os.Bundle
 */
package com.facebook;

import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.ad;
import android.support.v4.app.af;
import android.support.v4.app.an;
import android.support.v4.app.m;
import android.support.v4.app.z;
import com.facebook.login.j;

public class FacebookActivity
extends an {
    private static String l = "SingleFragment";
    private Fragment m;

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.m != null) {
            this.m.onConfigurationChanged(configuration);
        }
    }

    @Override
    public void onCreate(Bundle object) {
        Fragment fragment;
        super.onCreate((Bundle)object);
        this.setContentView(2130968676);
        z z2 = this.b.a.d;
        object = fragment = z2.a(l);
        if (fragment == null) {
            object = new j();
            object.setRetainInstance(true);
            z2.a().a(2131493204, (Fragment)object, l).a();
        }
        this.m = object;
    }
}

