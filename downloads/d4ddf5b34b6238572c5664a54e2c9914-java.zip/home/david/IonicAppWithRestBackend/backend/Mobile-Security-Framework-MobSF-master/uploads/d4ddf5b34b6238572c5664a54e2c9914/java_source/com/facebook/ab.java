/*
 * Decompiled with CFR 0_115.
 */
package com.facebook;

public final class ab {
    public static final int[] AlertDialog = new int[]{2130772278, 2130772279, 2130772280, 2130772281, 2130772282, 2130772283, 2130772284, 2130772285, 2130772286, 2130772287, 2130772288, 2130772289, 2130772290, 2130772291, 2130772292, 2130772293};
    public static final int[] AudioBarView = new int[]{2130772096};
    public static final int[] AvatarBar = new int[]{2130772270};
    public static final int[] BoundedView = new int[]{2130772315, 2130772316};
    public static final int[] BubbleView = new int[]{2130772233, 2130772234, 2130772235};
    public static final int[] BugReporterDrawingView = new int[]{2130772313, 2130772314};
    public static final int[] BulletAwareTextView = new int[]{2130772097};
    public static final int[] CameraButton = new int[]{2130772104, 2130772105, 2130772106, 2130772107, 2130772108, 2130772109, 2130772110, 2130772111, 2130772112, 2130772113};
    public static final int[] CheckRadioButtonWhite = new int[]{2130772018};
    public static final int[] CirclePageIndicator = new int[]{2130772227, 2130772228, 2130772229, 2130772230, 2130772231, 2130772232};
    public static final int[] CircularImageView = new int[]{2130772007, 2130772008};
    public static final int[] ClipStackView = new int[]{2130772264, 2130772265};
    public static final int[] ColorFilterAwareImageView = new int[]{2130772012, 2130772013, 2130772014, 2130772015, 2130772016};
    public static final int[] ColourIndicator = new int[]{2130772196};
    public static final int[] ColourPalette = new int[]{2130772221, 2130772222, 2130772223, 2130772224, 2130772225};
    public static final int[] ColourPicker = new int[]{2130772201, 2130772202, 2130772203, 2130772204};
    public static final int[] ConstrainedImageView = new int[]{2130772010};
    public static final int[] DoubleSelectableAvatar = new int[]{2130772080, 2130772084};
    public static final int[] DraggableContainer = new int[]{2130772133};
    public static final int[] DrawingView = new int[]{2130772197, 2130772198, 2130772199, 2130772200};
    public static final int[] EditPhoneNumberView = new int[]{2130772304, 2130772305, 2130772306, 2130772307, 2130772308, 2130772309, 2130772310, 2130772311};
    public static final int[] EmptyStateView = new int[]{2130772021, 2130772022, 2130772023, 2130772024, 2130772025, 2130772026, 2130772027, 2130772028, 2130772029, 2130772030, 2130772031, 2130772032, 2130772033, 2130772034};
    public static final int[] FindPeopleButton = new int[]{2130772298, 2130772299, 2130772300, 2130772301, 2130772302, 2130772303};
    public static final int[] FloatingIndicator = new int[]{2130772226};
    public static final int[] FollowButton = new int[]{2130772069, 2130772070, 2130772071, 2130772072, 2130772073};
    public static final int[] FramedRoundedCornerImageView = new int[]{2130772007, 2130772008, 2130772011};
    public static final int[] GalleryMediaGridView = new int[]{2130772256, 2130772257};
    public static final int[] GradientSpinner = new int[]{2130772123, 2130772124, 2130772125, 2130772126, 2130772127, 2130772128, 2130772129, 2130772130, 2130772131, 2130772132};
    public static final int[] GridLinesView = new int[]{2130772178};
    public static final int[] IgImageView = new int[]{2130772009};
    public static final int[] IgProgressImageView = new int[]{2130772075, 2130772076, 2130772077};
    public static final int[] IgSwitch = new int[]{2130772038, 2130772039, 2130772040};
    public static final int[] ImageWithTextView = new int[]{2130772067, 2130772068};
    public static final int[] InlineErrorMessageView = new int[]{2130772085, 2130772086};
    public static final int[] LoadMoreButton = new int[]{2130772035};
    public static final int[] MediaFrameLayout = new int[]{2130772074};
    public static final int[] MediaPickerItemView = new int[]{2130772186, 2130772187, 2130772188, 2130772189};
    public static final int[] ReboundViewPager = new int[]{2130772191};
    public static final int[] RecyclerView = new int[]{16842948, 2130772339, 2130772340, 2130772341, 2130772342};
    public static final int[] RefreshSpinner = new int[]{2130772017};
    public static final int[] RoundedCornerCheckMarkSelectableImageView = new int[]{2130772081, 2130772082, 2130772083};
    public static final int[] RoundedCornerFrameLayout = new int[]{2130772266, 2130772267, 2130772268};
    public static final int[] SearchEditText = new int[]{2130772041};
    public static final int[] SegmentedProgressBar = new int[]{2130772321, 2130772322, 2130772323, 2130772324, 2130772325};
    public static final int[] ShareTableButton = new int[]{2130772179, 2130772180, 2130772181};
    public static final int[] SingleSelectableAvatar = new int[]{2130772084};
    public static final int[] SlideOutIconView = new int[]{2130772087, 2130772088, 2130772089, 2130772090, 2130772091, 2130772092, 2130772093, 2130772094, 2130772095};
    public static final int[] StrokeWidthTool = new int[]{2130772205, 2130772206, 2130772207, 2130772208, 2130772209, 2130772210, 2130772211, 2130772212, 2130772213, 2130772214, 2130772215, 2130772216, 2130772217, 2130772218, 2130772219, 2130772220};
    public static final int[] TitleTextView = new int[]{2130772019, 2130772020};
    public static final int[] TouchInterceptorFrameLayout = new int[]{2130772263};
    public static final int[] TriangleShape = new int[]{2130772271, 2130772272, 2130772273};
    public static final int[] TriangleSpinner = new int[]{2130772259, 2130772260, 2130772261, 2130772262};
    public static final int[] ViewShareTableStyle = new int[]{2130772182};
    public static final int[] WheelView = new int[]{16842901, 16842904, 2130772348, 2130772349, 2130772350, 2130772351, 2130772352};
}

