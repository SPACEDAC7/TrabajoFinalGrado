/*
 * Decompiled with CFR 0_115.
 */
package com.facebook;

public enum b {
    a(false),
    b(true),
    c(true),
    d(true),
    e(false),
    f(true),
    g(true);
    
    public final boolean h;

    private b(boolean bl2) {
        this.h = bl2;
    }
}

