/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.facebook;

import com.facebook.AccessToken;
import com.facebook.b;
import com.facebook.o.w;
import java.util.Collection;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class c {
    c() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static AccessToken a() {
        Object object = null;
        String string = com.instagram.c.b.a.b.a("facebookPreferences").getString("com.facebook.AccessTokenManager.CachedAccessToken", null);
        if (string == null) return object;
        try {
            object = new JSONObject(string);
            if (object.getInt("version") > 1) {
                return null;
            }
        }
        catch (JSONException var0_1) {
            return null;
        }
        string = object.getString("token");
        Date date = new Date(object.getLong("expires_at"));
        JSONArray jSONArray = object.getJSONArray("permissions");
        JSONArray jSONArray2 = object.getJSONArray("declined_permissions");
        Date date2 = new Date(object.getLong("last_refresh"));
        b b2 = b.valueOf(object.getString("source"));
        return new AccessToken(string, object.getString("application_id"), object.getString("user_id"), w.a(jSONArray), w.a(jSONArray2), b2, date, date2);
    }
}

