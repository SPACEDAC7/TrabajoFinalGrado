/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.facebook.cameracore.mediapipeline.c;

import android.os.Handler;
import com.facebook.cameracore.b.m;
import com.facebook.cameracore.mediapipeline.c.e;

final class c
implements Runnable {
    final /* synthetic */ m a;
    final /* synthetic */ Handler b;
    final /* synthetic */ e c;

    c(e e2, m m2, Handler handler) {
        this.c = e2;
        this.a = m2;
        this.b = handler;
    }

    @Override
    public final void run() {
        this.c.b(this.a, this.b);
    }
}

