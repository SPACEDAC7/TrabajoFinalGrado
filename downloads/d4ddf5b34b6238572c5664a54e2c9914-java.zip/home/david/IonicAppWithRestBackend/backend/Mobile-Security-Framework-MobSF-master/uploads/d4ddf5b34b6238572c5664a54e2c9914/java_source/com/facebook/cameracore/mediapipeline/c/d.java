/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.cameracore.mediapipeline.c;

import com.facebook.cameracore.mediapipeline.c.e;

public final class d {
    final /* synthetic */ e a;

    public d(e e2) {
        this.a = e2;
    }
}

