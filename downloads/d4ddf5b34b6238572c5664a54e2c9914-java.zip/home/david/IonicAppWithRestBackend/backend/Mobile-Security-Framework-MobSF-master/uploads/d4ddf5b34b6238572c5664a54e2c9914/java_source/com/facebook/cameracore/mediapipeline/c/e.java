/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.os.Handler
 *  android.os.Looper
 */
package com.facebook.cameracore.mediapipeline.c;

import android.annotation.TargetApi;
import android.os.Handler;
import android.os.Looper;
import com.facebook.cameracore.b.m;
import com.facebook.cameracore.b.p;
import com.facebook.cameracore.mediapipeline.c.a;
import com.facebook.cameracore.mediapipeline.c.c;
import com.facebook.cameracore.mediapipeline.d.as;

@TargetApi(value=18)
public final class e {
    public int a;
    public a b;
    private final as c;
    private byte[] d;
    private Handler e;
    private int f;

    public e(Handler handler, int n2, int n3, as as2) {
        this.c = as2;
        this.f = n3;
        this.e = handler;
        this.a = n2;
        this.d = new byte[this.f];
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(m m2, Handler handler) {
        synchronized (this) {
            if (handler == null) {
                throw new IllegalArgumentException("The handler cannot be null");
            }
            if (this.e.getLooper() == handler.getLooper()) {
                throw new IllegalStateException("The handler must be on a separate thread then the processing one");
            }
            this.e.post((Runnable)new c(this, m2, handler));
            return;
        }
    }

    final void b(m m2, Handler handler) {
        synchronized (this) {
            if (this.b != null) {
                this.b = null;
            }
            p.a(m2, handler);
            return;
        }
    }
}

