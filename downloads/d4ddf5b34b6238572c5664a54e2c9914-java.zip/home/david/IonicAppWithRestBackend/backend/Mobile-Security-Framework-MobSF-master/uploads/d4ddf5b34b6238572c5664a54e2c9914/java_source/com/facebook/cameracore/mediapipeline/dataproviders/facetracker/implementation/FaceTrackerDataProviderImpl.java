/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.cameracore.mediapipeline.dataproviders.facetracker.implementation;

import com.facebook.a.a.a;
import com.facebook.cameracore.mediapipeline.dataproviders.facetracker.interfaces.FaceTrackerDataProvider;
import com.facebook.jni.HybridData;
import java.nio.ByteBuffer;

@a
public class FaceTrackerDataProviderImpl
extends FaceTrackerDataProvider {
    public FaceTrackerDataProviderImpl() {
        super(FaceTrackerDataProviderImpl.initHybrid());
    }

    private static native HybridData initHybrid();

    @a
    @Override
    public native void init(int var1, int var2, int var3);

    @a
    @Override
    public native boolean isFaceTrackerReady();

    @a
    @Override
    public native void loadModels(String var1, String var2, String var3);

    @a
    @Override
    public native void releaseModels();

    @a
    @Override
    public native void setupImageSourceFacet(int var1, int var2, int var3, int var4, boolean var5);

    @a
    @Override
    public native void writeImageArray(byte[] var1);

    @a
    @Override
    public native void writeImageByteBuffer(ByteBuffer var1, int var2);
}

