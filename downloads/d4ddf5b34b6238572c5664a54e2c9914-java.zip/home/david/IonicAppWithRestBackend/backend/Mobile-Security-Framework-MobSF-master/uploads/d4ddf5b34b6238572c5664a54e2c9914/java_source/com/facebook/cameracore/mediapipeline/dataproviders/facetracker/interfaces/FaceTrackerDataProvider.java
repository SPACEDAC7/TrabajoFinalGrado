/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.cameracore.mediapipeline.dataproviders.facetracker.interfaces;

import com.facebook.a.a.a;
import com.facebook.jni.HybridData;
import java.nio.ByteBuffer;

public abstract class FaceTrackerDataProvider {
    @a
    private final HybridData mHybridData;

    public FaceTrackerDataProvider(HybridData hybridData) {
        this.mHybridData = hybridData;
    }

    @a
    public abstract void init(int var1, int var2, int var3);

    @a
    public abstract boolean isFaceTrackerReady();

    @a
    public abstract void loadModels(String var1, String var2, String var3);

    @a
    public abstract void releaseModels();

    @a
    public abstract void setupImageSourceFacet(int var1, int var2, int var3, int var4, boolean var5);

    @a
    public abstract void writeImageArray(byte[] var1);

    @a
    public abstract void writeImageByteBuffer(ByteBuffer var1, int var2);
}

