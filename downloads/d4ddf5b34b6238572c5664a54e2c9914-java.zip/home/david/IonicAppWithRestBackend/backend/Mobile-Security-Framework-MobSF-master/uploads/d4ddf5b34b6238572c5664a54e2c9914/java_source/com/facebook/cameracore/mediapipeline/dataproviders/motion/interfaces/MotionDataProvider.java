/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.cameracore.mediapipeline.dataproviders.motion.interfaces;

import com.facebook.a.a.a;
import com.facebook.jni.HybridData;

public abstract class MotionDataProvider {
    @a
    protected HybridData mHybridData;
}

