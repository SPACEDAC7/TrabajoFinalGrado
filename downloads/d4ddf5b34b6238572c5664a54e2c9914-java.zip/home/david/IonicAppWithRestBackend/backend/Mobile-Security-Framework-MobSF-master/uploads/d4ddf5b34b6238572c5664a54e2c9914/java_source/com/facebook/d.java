/*
 * Decompiled with CFR 0_115.
 */
package com.facebook;

public interface d {
    public void a();
}

