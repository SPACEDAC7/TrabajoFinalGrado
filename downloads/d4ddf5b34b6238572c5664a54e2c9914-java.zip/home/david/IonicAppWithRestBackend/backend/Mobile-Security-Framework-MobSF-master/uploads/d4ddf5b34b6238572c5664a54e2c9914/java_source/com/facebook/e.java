/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.content.pm.PackageItemInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Message
 *  android.os.Messenger
 *  android.os.RemoteException
 */
package com.facebook;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import com.facebook.AccessToken;
import com.facebook.d;
import com.facebook.f;
import com.facebook.h;
import com.facebook.n;
import com.facebook.o.q;
import com.facebook.o.u;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public final class e
implements ServiceConnection {
    final Messenger a;
    Messenger b;
    final /* synthetic */ h c;
    public d d;

    public e(h h2, AccessToken accessToken, d d2) {
        this.c = h2;
        this.b = null;
        this.d = d2;
        this.a = new Messenger((Handler)new f(accessToken, this));
    }

    public static void b$redex0(e e2) {
        if (e2.c.b == e2) {
            e2.c.b = null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a() {
        q q2;
        Context context;
        block7 : {
            context = n.c;
            Iterator<q> iterator = u.c.iterator();
            while (iterator.hasNext()) {
                q2 = iterator.next();
                if ((q2 = new Intent().setClassName(q2.a(), "com.facebook.katana.platform.TokenRefreshService")) == null) {
                    q2 = null;
                } else {
                    ResolveInfo resolveInfo = context.getPackageManager().resolveService((Intent)q2, 0);
                    if (resolveInfo == null) {
                        q2 = null;
                    } else if (!q.a(context, resolveInfo.serviceInfo.packageName)) {
                        q2 = null;
                    }
                }
                if (q2 == null) continue;
                break block7;
            }
            q2 = null;
        }
        if (q2 != null && context.bindService((Intent)q2, (ServiceConnection)this, 1)) {
            this.c.c = new Date();
            return;
        }
        e.b$redex0(this);
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        this.b = new Messenger(iBinder);
        componentName = new Bundle();
        componentName.putString("access_token", this.c.a.d);
        iBinder = Message.obtain();
        iBinder.setData((Bundle)componentName);
        iBinder.replyTo = this.a;
        try {
            this.b.send((Message)iBinder);
            return;
        }
        catch (RemoteException var1_2) {
            e.b$redex0(this);
            return;
        }
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        e.b$redex0(this);
        try {
            n.c.unbindService((ServiceConnection)this);
            return;
        }
        catch (IllegalArgumentException var1_2) {
            return;
        }
    }
}

