/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.ServiceConnection
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 */
package com.facebook;

import android.content.Context;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.facebook.AccessToken;
import com.facebook.b;
import com.facebook.d;
import com.facebook.e;
import com.facebook.h;
import com.facebook.n;
import com.facebook.o.w;
import java.util.Collection;
import java.util.Date;
import java.util.Set;

final class f
extends Handler {
    private AccessToken a;
    private e b;

    f(AccessToken accessToken, e e2) {
        super(Looper.getMainLooper());
        this.a = accessToken;
        this.b = e2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void handleMessage(Message var1_1) {
        var3_2 = h.a().a;
        if (var3_2 == null || !var3_2.equals(this.a) || var1_1.getData().getString("access_token") == null) ** GOTO lbl8
        var3_2 = this.a;
        var5_3 = var1_1.getData();
        var1_1 = null;
        if (var3_2.e == b.b || var3_2.e == b.c || var3_2.e == b.d) ** GOTO lbl10
        ** GOTO lbl14
lbl8: // 1 sources:
        this.b.d.a();
        ** GOTO lbl15
lbl10: // 1 sources:
        var4_4 = w.a((Bundle)var5_3, "expires_in", new Date(0));
        var2_5 = (var5_3 = var5_3.getString("access_token")) == null || var5_3.length() == 0;
        if (!var2_5) {
            var1_1 = new AccessToken((String)var5_3, var3_2.g, var3_2.h, var3_2.b, var3_2.c, var3_2.e, var4_4, new Date());
        }
lbl14: // 4 sources:
        h.a().a((AccessToken)var1_1, true);
lbl15: // 2 sources:
        n.c.unbindService((ServiceConnection)this.b);
        e.b$redex0(this.b);
    }
}

