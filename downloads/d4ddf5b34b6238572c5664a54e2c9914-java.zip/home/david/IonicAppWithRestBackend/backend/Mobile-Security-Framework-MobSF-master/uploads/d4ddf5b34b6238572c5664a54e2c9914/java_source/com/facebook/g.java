/*
 * Decompiled with CFR 0_115.
 */
package com.facebook;

import com.facebook.d;
import com.facebook.h;

final class g
implements d {
    final /* synthetic */ h a;

    g(h h2) {
        this.a = h2;
    }

    @Override
    public final void a() {
    }
}

