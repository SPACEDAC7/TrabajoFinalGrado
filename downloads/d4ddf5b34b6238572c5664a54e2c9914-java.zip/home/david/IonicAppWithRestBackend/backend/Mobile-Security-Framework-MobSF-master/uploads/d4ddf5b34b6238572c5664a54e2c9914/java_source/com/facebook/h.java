/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Parcelable
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.facebook;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Parcelable;
import android.support.v4.content.z;
import com.facebook.AccessToken;
import com.facebook.b;
import com.facebook.c;
import com.facebook.d;
import com.facebook.e;
import com.facebook.g;
import com.facebook.n;
import java.util.Collection;
import java.util.Date;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class h {
    private static volatile h e;
    public AccessToken a;
    public e b;
    public Date c = new Date(0);
    public final d d;
    private final z f;
    private final c g;

    private h(z z2, c c2) {
        this.d = new g(this);
        this.f = z2;
        this.g = c2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static h a() {
        synchronized (h.class) {
            Object object;
            h h2;
            if (e != null) return e;
            e = h2 = new h(z.a(n.c), new c());
            if (!com.instagram.c.b.a.b.a("facebookPreferences").contains("com.facebook.AccessTokenManager.CachedAccessToken") && (object = com.instagram.c.b.a.b.a("facebookPreferences").getString("access_token", null)) != null) {
                String string = com.instagram.c.b.a.b.a("facebookPreferences").getString("user_id", null);
                h.a().a(new AccessToken((String)object, string), true);
                com.instagram.c.b.a.b.a("facebookPreferences").edit().remove("access_token").remove("access_expires").remove("last_access_update").apply();
            }
            if ((object = c.a()) == null) return e;
            h2.a((AccessToken)object, false);
            return e;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void b() {
        if (e != null) {
            synchronized (h.class) {
                e = null;
                return;
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void a(AccessToken var1_1, boolean var2_2) {
        block5 : {
            var3_3 = true;
            var4_4 = this.a;
            this.a = var1_1;
            this.b = null;
            this.c = new Date(0);
            if (var2_2) {
                if (var1_1 != null) {
                    var5_5 = new JSONObject();
                    var5_5.put("version", 1);
                    var5_5.put("token", (Object)var1_1.d);
                    var5_5.put("expires_at", var1_1.a.getTime());
                    var5_5.put("permissions", (Object)new JSONArray(var1_1.b));
                    var5_5.put("declined_permissions", (Object)new JSONArray(var1_1.c));
                    var5_5.put("last_refresh", var1_1.f.getTime());
                    var5_5.put("source", (Object)var1_1.e.name());
                    var5_5.put("application_id", (Object)var1_1.g);
                    var5_5.put("user_id", (Object)var1_1.h);
                    var5_5 = var5_5.toString();
                    com.instagram.c.b.a.b.a("facebookPreferences").edit().putString("com.facebook.AccessTokenManager.CachedAccessToken", (String)var5_5).apply();
                    ** GOTO lbl25
                } else {
                    com.instagram.c.b.a.b.a("facebookPreferences").edit().remove("com.facebook.AccessTokenManager.CachedAccessToken").apply();
                }
                break block5;
                catch (JSONException var5_6) {}
            }
        }
        var2_2 = var4_4 == null ? (var1_1 == null ? var3_3 : false) : var4_4.equals(var1_1);
        if (var2_2 != false) return;
        var5_5 = new Intent("com.facebook.sdk.ACTION_CURRENT_ACCESS_TOKEN_CHANGED");
        var5_5.putExtra("com.facebook.sdk.EXTRA_OLD_ACCESS_TOKEN", (Parcelable)var4_4);
        var5_5.putExtra("com.facebook.sdk.EXTRA_NEW_ACCESS_TOKEN", (Parcelable)var1_1);
        this.f.a((Intent)var5_5);
    }
}

