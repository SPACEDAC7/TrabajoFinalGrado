/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.facebook;

import android.content.Context;
import android.content.SharedPreferences;
import com.facebook.n;
import com.facebook.o.e;
import com.facebook.o.w;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class i {
    private static final Object a = new Object();
    private static String b;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String a(Context context) {
        if (b == null) {
            Object object = a;
            synchronized (object) {
                if (b == null) {
                    String string;
                    b = string = context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).getString("anonymousAppDeviceGUID", null);
                    if (string == null) {
                        b = "XZ" + UUID.randomUUID().toString();
                        context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).edit().putString("anonymousAppDeviceGUID", b).apply();
                    }
                }
            }
        }
        return b;
    }

    public static Map<String, String> b() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        Context context = n.c;
        hashMap.put("event", "CUSTOM_APP_EVENTS");
        w.a(hashMap, e.a(context), i.a(n.c));
        hashMap.put("application_package_name", context.getPackageName());
        hashMap.put("format", "json");
        try {
            context = new JSONArray();
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("_appVersion", (Object)n.b);
            jSONObject.put("_logTime", System.currentTimeMillis() / 1000);
            jSONObject.put("_eventName", (Object)"fb_mobile_activate_app");
            context.put((Object)jSONObject);
            hashMap.put("custom_events_file", context.toString());
            return hashMap;
        }
        catch (JSONException var1_2) {
            return hashMap;
        }
    }
}

