/*
 * Decompiled with CFR 0_115.
 */
package com.facebook;

import com.facebook.k;

public final class l {
    public final int a;
    public String b;
    public int c;
    public String d;

    public l(int n2) {
        this.a = n2;
    }

    public static l a(String string, int n2, String string2) {
        l l2 = new l(k.c);
        l2.b = string;
        l2.c = n2;
        l2.d = string2;
        return l2;
    }
}

