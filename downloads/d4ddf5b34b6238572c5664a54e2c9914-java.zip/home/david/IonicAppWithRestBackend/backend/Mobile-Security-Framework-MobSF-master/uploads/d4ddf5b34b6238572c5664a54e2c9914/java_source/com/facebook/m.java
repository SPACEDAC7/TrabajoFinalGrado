/*
 * Decompiled with CFR 0_115.
 */
package com.facebook;

public final class m
extends RuntimeException {
    public m(String string) {
        super(string);
    }

    @Override
    public final String toString() {
        return this.getMessage();
    }
}

