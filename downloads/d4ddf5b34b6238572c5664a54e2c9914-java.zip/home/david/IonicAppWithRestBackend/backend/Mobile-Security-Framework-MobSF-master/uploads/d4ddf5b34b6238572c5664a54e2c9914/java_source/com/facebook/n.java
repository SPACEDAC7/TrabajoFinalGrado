/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.facebook;

import android.content.Context;

public final class n {
    public static volatile String a;
    public static volatile String b;
    public static Context c;
    private static Boolean d;

    static {
        d = false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void a(Context context, String string, String string2) {
        synchronized (n.class) {
            block6 : {
                boolean bl2 = d;
                if (!bl2) break block6;
                do {
                    return;
                    break;
                } while (true);
            }
            c = context.getApplicationContext();
            a = string;
            b = string2;
            d = true;
            return;
        }
    }
}

