/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.soloader.ab;

class TraceDirect {
    private static final String a;
    private static final boolean b;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        boolean bl2;
        boolean bl3 = true;
        a = TraceDirect.class.getSimpleName();
        try {
            ab.c("fbsystrace");
            bl2 = true;
        }
        catch (UnsatisfiedLinkError var2_2) {
            bl2 = false;
        }
        if (bl2) {
            bl3 = false;
        }
        b = bl3;
    }

    TraceDirect() {
    }

    public static void a() {
        if (b) {
            return;
        }
        TraceDirect.nativeEndSection();
    }

    public static void a(long l2) {
        if (b) {
            return;
        }
        TraceDirect.nativeSetEnabledTags(l2);
    }

    public static void a(String string) {
        if (b) {
            return;
        }
        TraceDirect.nativeBeginSection(string);
    }

    public static void a(String string, int n2) {
        if (b) {
            return;
        }
        TraceDirect.nativeTraceCounter(string, n2);
    }

    public static void a(String string, String string2, int n2) {
        if (b) {
            return;
        }
        TraceDirect.nativeTraceMetadata(string, string2, n2);
    }

    static void a(StringBuilder stringBuilder) {
        if (b) {
            return;
        }
        TraceDirect.nativeBeginSectionWithArgs(stringBuilder);
    }

    public static void b(String string, int n2) {
        if (b) {
            return;
        }
        TraceDirect.nativeStartAsyncFlow(string, n2);
    }

    static void b(StringBuilder stringBuilder) {
        if (b) {
            return;
        }
        TraceDirect.nativeEndSectionWithArgs(stringBuilder);
    }

    public static void c(String string, int n2) {
        if (b) {
            return;
        }
        TraceDirect.nativeEndAsyncFlow(string, n2);
    }

    private static native void nativeAsyncTraceBegin(String var0, int var1, long var2);

    private static native void nativeAsyncTraceCancel(String var0, int var1);

    private static native void nativeAsyncTraceEnd(String var0, int var1, long var2);

    private static native void nativeAsyncTraceRename(String var0, String var1, int var2);

    private static native void nativeAsyncTraceStageBegin(String var0, int var1, String var2);

    private static native void nativeBeginSection(String var0);

    private static native void nativeBeginSectionWithArgs(StringBuilder var0);

    private static native void nativeEndAsyncFlow(String var0, int var1);

    private static native void nativeEndSection();

    private static native void nativeEndSectionWithArgs(StringBuilder var0);

    private static native void nativeSetEnabledTags(long var0);

    private static native void nativeStartAsyncFlow(String var0, int var1);

    private static native void nativeStepAsyncFlow(String var0, int var1);

    private static native void nativeTraceCounter(String var0, int var1);

    private static native void nativeTraceInstant(String var0, String var1, char var2);

    private static native void nativeTraceMetadata(String var0, String var1, int var2);
}

