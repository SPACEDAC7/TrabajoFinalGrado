/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.n.a.a.d;
import com.facebook.systrace.TraceDirect;
import com.facebook.systrace.o;
import java.lang.reflect.Method;

public final class a {
    /*
     * Enabled aggressive block sorting
     */
    static {
        if (d.e) {
            d.a(d.d, true);
        }
        o.a(false);
    }

    public static void a(long l2) {
        if (!o.a(l2)) {
            return;
        }
        TraceDirect.a();
    }

    public static void a(long l2, String string) {
        if (!o.a(l2)) {
            return;
        }
        TraceDirect.a(string);
    }

    public static void a(long l2, String string, int n2) {
        if (!o.a(l2)) {
            return;
        }
        TraceDirect.b(string, n2);
    }

    public static void a(String string, int n2) {
        if (!o.a(8192)) {
            return;
        }
        TraceDirect.a(string, n2);
    }

    public static void a(String string, String string2, int n2) {
        if (!o.a(64)) {
            return;
        }
        TraceDirect.a(string, string2, n2);
    }

    public static void b(long l2, String string, int n2) {
        if (!o.a(l2)) {
            return;
        }
        TraceDirect.c(string, n2);
    }
}

