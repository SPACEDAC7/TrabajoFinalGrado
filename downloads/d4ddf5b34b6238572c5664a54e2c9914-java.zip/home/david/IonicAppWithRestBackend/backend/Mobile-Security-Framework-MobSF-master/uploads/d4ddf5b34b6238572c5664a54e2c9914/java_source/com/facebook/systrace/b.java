/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

public interface b {
    public void a();

    public void b();
}

