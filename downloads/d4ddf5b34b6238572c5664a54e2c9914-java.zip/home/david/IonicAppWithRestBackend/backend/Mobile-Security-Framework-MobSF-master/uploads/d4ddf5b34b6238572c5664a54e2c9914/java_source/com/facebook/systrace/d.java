/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.systrace.h;

final class d
extends ThreadLocal<h> {
    d() {
    }

    @Override
    protected final /* synthetic */ Object initialValue() {
        return new h();
    }
}

