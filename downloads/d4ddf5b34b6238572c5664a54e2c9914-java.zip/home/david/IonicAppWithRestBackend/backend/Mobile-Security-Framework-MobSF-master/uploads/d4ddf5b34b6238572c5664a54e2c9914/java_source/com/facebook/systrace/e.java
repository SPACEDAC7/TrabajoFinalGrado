/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

public abstract class e {
    public abstract e a(String var1, int var2);

    public abstract e a(String var1, Object var2);

    public abstract void a();
}

