/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

interface f {
    public void a(StringBuilder var1);
}

