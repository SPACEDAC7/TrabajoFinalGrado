/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.systrace.e;

final class g
extends e {
    @Override
    public final e a(String string, int n2) {
        return this;
    }

    @Override
    public final e a(String string, Object object) {
        return this;
    }

    @Override
    public final void a() {
    }
}

