/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.systrace.e;
import com.facebook.systrace.f;

final class h
extends e {
    f a;
    StringBuilder b = new StringBuilder();
    char c;

    private void b() {
        this.b.append(this.c);
        this.c = 59;
    }

    @Override
    public final e a(String string, int n2) {
        this.b();
        this.b.append(string);
        this.b.append('=');
        this.b.append(n2);
        return this;
    }

    @Override
    public final e a(String string, Object object) {
        this.b();
        this.b.append(string);
        this.b.append('=');
        this.b.append(object);
        return this;
    }

    @Override
    public final void a() {
        this.a.a(this.b);
    }
}

