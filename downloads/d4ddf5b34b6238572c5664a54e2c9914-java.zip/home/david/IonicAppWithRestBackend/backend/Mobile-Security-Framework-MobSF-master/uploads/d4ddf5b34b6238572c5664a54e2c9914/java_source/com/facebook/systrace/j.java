/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.systrace.TraceDirect;
import com.facebook.systrace.f;

final class j
implements f {
    @Override
    public final void a(StringBuilder stringBuilder) {
        TraceDirect.b(stringBuilder);
    }
}

