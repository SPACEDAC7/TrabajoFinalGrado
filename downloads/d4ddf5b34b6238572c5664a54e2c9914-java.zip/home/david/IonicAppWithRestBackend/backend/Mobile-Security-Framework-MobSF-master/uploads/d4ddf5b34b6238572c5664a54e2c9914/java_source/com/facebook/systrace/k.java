/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.systrace.d;
import com.facebook.systrace.e;
import com.facebook.systrace.f;
import com.facebook.systrace.g;
import com.facebook.systrace.h;
import com.facebook.systrace.i;
import com.facebook.systrace.j;
import com.facebook.systrace.o;

public final class k {
    private static final e a = new g();
    private static final ThreadLocal<h> b = new d();
    private static final f c = new i();
    private static final f d = new j();

    public static e a(long l2, String string) {
        f f2 = c;
        if (!o.a(l2)) {
            return a;
        }
        h h2 = b.get();
        h2.a = f2;
        h2.b.delete(0, h2.b.length());
        h2.b.append(string);
        h2.c = 124;
        return h2;
    }
}

