/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Process
 */
package com.facebook.systrace;

import android.os.Build;
import android.os.Process;
import com.facebook.systrace.a;
import com.facebook.systrace.b;
import com.facebook.systrace.c;
import com.facebook.systrace.m;
import com.facebook.systrace.o;
import java.util.WeakHashMap;

final class l
implements b {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void a() {
        Object object;
        boolean bl2 = true;
        if (o.a(64)) {
            int n2 = Process.myTid();
            object = Thread.currentThread();
            a.a("thread_name", object.getName(), n2);
            if (m.a != null) {
                m.a.put((Thread)object, n2);
            }
        }
        if (o.a(1)) {
            object = new StringBuilder(127);
            object.append("Android trace tags: ");
            object.append(com.facebook.n.a.a.b.b("debug.atrace.tags.enableflags"));
            object.append(", Facebook trace tags: ");
            object.append(o.b);
            a.a("process_labels", object.toString(), 0);
        }
        if (o.a(64)) {
            a.a("process_name", c.a(), 0);
            object = com.facebook.n.a.a.b.a("dalvik.vm.heapgrowthlimit");
            String string = com.facebook.n.a.a.b.a("dalvik.vm.heapmaxfree");
            String string2 = com.facebook.n.a.a.b.a("dalvik.vm.heapminfree");
            String string3 = com.facebook.n.a.a.b.a("dalvik.vm.heapstartsize");
            String string4 = com.facebook.n.a.a.b.a("dalvik.vm.heaptargetutilization");
            a.a("process_labels", String.format("device=%s,heapgrowthlimit=%s,heapstartsize=%s,heapminfree=%s,heapmaxfree=%s,heaptargetutilization=%s", Build.MODEL, object, string3, string, string2, string4), 0);
        }
        if (m.a == null) return;
        if (!bl2) return;
        m.d();
    }

    @Override
    public final void b() {
    }
}

