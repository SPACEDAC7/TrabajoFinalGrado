/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.systrace.a;
import com.facebook.systrace.l;
import com.facebook.systrace.o;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

public final class m {
    public static volatile WeakHashMap<Thread, Integer> a;

    static {
        o.a(new l());
    }

    public static void d() {
        if (!o.a(64)) {
            return;
        }
        a.a(64, "TraceExistingThreadsMetadata");
        try {
            for (Map.Entry<Thread, Integer> entry : a.entrySet()) {
                a.a("thread_name", entry.getKey().getName(), (int)entry.getValue());
            }
        }
        finally {
            a.a(64);
        }
    }
}

