/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.systrace.o;

final class n
implements Runnable {
    n() {
    }

    @Override
    public final void run() {
        o.a(true);
    }
}

