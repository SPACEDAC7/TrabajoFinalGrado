/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package com.facebook.systrace;

import android.os.Build;
import com.facebook.n.a.a.d;
import com.facebook.systrace.TraceDirect;
import com.facebook.systrace.b;
import com.facebook.systrace.n;
import com.facebook.systrace.p;
import com.facebook.systrace.q;
import com.facebook.systrace.s;
import java.io.File;
import java.lang.reflect.Method;
import java.util.List;

public final class o {
    private static final q a = new q();
    public static volatile long b = 0;

    static {
        o.a(false);
        com.facebook.n.a.a.b.a(new n());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(b b2) {
        q q2 = a;
        Object object = q2.b;
        synchronized (object) {
            q2.c.add(b2);
            if (q2.d) {
                b2.a();
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static void a(boolean var0) {
        var2_1 = true;
        if (Build.VERSION.SDK_INT >= 18) {
            var4_2 = d.b;
            var3_3 = d.e == false ? false : ((var6_4 = (Boolean)d.a(d.c, new Object[]{var4_2})) == null ? false : var6_4.booleanValue());
        }
        if (Build.VERSION.SDK_INT >= 16) {
            if (s.a == null) {
                s.c();
            }
            var3_3 = s.a;
        } else {
            var3_3 = false;
        }
        var4_2 = com.facebook.n.a.a.b.b("debug.fbsystrace.tags");
        var4_2 = !var3_3 || var4_2 == 0 ? 0 : (var4_2 |= 1);
        if (o.b != 0) ** GOTO lbl-1000
        if (var4_2 == 0) {
            ** if (var4_2 != 0) goto lbl18
        }
        ** GOTO lbl-1000
lbl-1000: // 2 sources:
        {
            ** if (o.b == 0) goto lbl-1000
        }
lbl18: // 1 sources:
        ** GOTO lbl-1000
lbl-1000: // 2 sources:
        {
            var1_5 = true;
            ** GOTO lbl22
        }
lbl-1000: // 2 sources:
        {
            var1_5 = false;
        }
lbl22: // 2 sources:
        o.b = var4_2;
        if (var1_5 == false) return;
        TraceDirect.a(var4_2);
        var1_5 = var4_2 > 0 ? var2_1 : false;
        if (!var1_5) {
            var7_7 = o.a;
            var6_4 = var7_7.b;
            // MONITORENTER : var6_4
            var7_7.a(false);
            // MONITOREXIT : var6_4
            return;
        }
        if (!var0) {
            o.a.a();
            return;
        }
        var7_6 = o.a;
        var6_4 = var7_6.b;
        // MONITORENTER : var6_4
        var7_6 = new Thread((Runnable)new p((q)var7_6, q.a.lastModified()), "fbsystrace notification thread");
        var7_6.setPriority(10);
        var7_6.start();
        // MONITOREXIT : var6_4
    }

    public static boolean a(long l2) {
        if ((b & l2) != 0) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void b(b b2) {
        q q2 = a;
        Object object = q2.b;
        synchronized (object) {
            q2.c.remove(b2);
            if (q2.d) {
                b2.b();
            }
            return;
        }
    }
}

