/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package com.facebook.systrace;

import android.os.Build;
import com.facebook.systrace.q;
import java.io.File;

final class p
implements Runnable {
    final /* synthetic */ long a;
    final /* synthetic */ q b;

    p(q q2, long l2) {
        this.b = q2;
        this.a = l2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void run() {
        Object object = this.b.b;
        synchronized (object) {
            if (Build.VERSION.SDK_INT < 23) {
                while (q.a.lastModified() == this.a) {
                }
            } else {
                try {
                    Thread.sleep(100);
                }
                catch (InterruptedException var2_2) {
                    Thread.currentThread().interrupt();
                }
            }
            this.b.a();
            return;
        }
    }
}

