/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 */
package com.facebook.systrace;

import android.annotation.SuppressLint;
import com.facebook.systrace.a;
import com.facebook.systrace.b;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

final class q {
    public static final File a = new File("/sys/kernel/debug/tracing/trace");
    public final Object b = new Object[0];
    @SuppressLint(value={"BadMethodUse-java.util.ArrayList._Constructor"})
    final List<b> c = new ArrayList<b>();
    boolean d;

    q() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a() {
        Object object = this.b;
        synchronized (object) {
            a.a(1, "Run Trace Listeners");
            try {
                this.a(true);
                return;
            }
            finally {
                a.a(1);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    final void a(boolean bl2) {
        this.d = bl2;
        int n2 = 0;
        while (n2 < this.c.size()) {
            b b2 = this.c.get(n2);
            if (bl2) {
                b2.a();
            } else {
                b2.b();
            }
            ++n2;
        }
    }
}

