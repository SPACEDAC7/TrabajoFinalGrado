/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.systrace.s;

final class r
implements Runnable {
    r() {
    }

    @Override
    public final void run() {
        s.c();
    }
}

