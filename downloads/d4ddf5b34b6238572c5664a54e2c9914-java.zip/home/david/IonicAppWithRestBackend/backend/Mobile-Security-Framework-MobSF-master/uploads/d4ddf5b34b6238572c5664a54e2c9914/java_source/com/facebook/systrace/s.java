/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.systrace;

import com.facebook.n.a.a.b;
import com.facebook.systrace.c;
import com.facebook.systrace.r;

public final class s {
    public static volatile Boolean a;

    static {
        b.a(new r());
        a = null;
    }

    public static void c() {
        String[] arrstring = b.a("debug.atrace.app_cmdlines");
        if (arrstring.length() == 0) {
            a = false;
            return;
        }
        arrstring = arrstring.split(",");
        String string = c.a();
        for (int i2 = 0; i2 < arrstring.length; ++i2) {
            if (!string.equals(arrstring[i2])) continue;
            a = true;
            return;
        }
        a = false;
    }
}

