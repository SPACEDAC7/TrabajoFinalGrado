/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.xanalytics;

import com.facebook.a.a.a;
import com.facebook.jni.HybridData;

@a
public abstract class XAnalyticsHolder {
    @a
    protected final HybridData mHybridData;

    protected XAnalyticsHolder(HybridData hybridData) {
        this.mHybridData = hybridData;
    }
}

