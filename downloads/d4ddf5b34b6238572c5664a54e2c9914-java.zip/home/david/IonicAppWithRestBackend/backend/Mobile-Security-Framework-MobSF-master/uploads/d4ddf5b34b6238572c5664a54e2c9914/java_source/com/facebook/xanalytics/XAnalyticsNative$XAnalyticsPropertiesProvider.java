/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.xanalytics;

import com.facebook.a.a.a;

@a
public interface XAnalyticsNative$XAnalyticsPropertiesProvider {
    @a
    public String[] get();
}

