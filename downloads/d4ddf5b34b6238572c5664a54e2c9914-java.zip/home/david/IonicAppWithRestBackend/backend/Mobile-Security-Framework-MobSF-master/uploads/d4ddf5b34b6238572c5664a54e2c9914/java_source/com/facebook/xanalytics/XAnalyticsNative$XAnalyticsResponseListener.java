/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.xanalytics;

import com.facebook.a.a.a;

@a
public interface XAnalyticsNative$XAnalyticsResponseListener {
    @a
    public void onResponse(String var1);
}

