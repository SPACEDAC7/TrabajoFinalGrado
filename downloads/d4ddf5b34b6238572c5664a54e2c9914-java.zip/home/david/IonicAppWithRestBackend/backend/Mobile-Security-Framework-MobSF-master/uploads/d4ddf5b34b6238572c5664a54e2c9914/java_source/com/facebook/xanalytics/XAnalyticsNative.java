/*
 * Decompiled with CFR 0_115.
 */
package com.facebook.xanalytics;

import com.facebook.a.a.a;
import com.facebook.jni.HybridData;
import com.facebook.soloader.ab;
import com.facebook.tigon.iface.TigonServiceHolder;
import com.facebook.xanalytics.XAnalyticsHolder;
import com.facebook.xanalytics.XAnalyticsNative$XAnalyticsPropertiesProvider;
import com.facebook.xanalytics.XAnalyticsNative$XAnalyticsResponseListener;
import java.util.concurrent.Executor;

@a
public class XAnalyticsNative
extends XAnalyticsHolder {
    protected static String a;
    protected long b = 0;
    protected TigonServiceHolder c = null;

    static {
        ab.c("fbacore-jni");
        a = "graph.facebook.com";
    }

    public XAnalyticsNative() {
        super(XAnalyticsNative.initHybrid());
    }

    private static native HybridData initHybrid();

    public native void cleanup();

    public native void cleanupNetworkRequest();

    protected native int countFlushed();

    public native void flush();

    protected native String[] getFlushed();

    public native long init(String[] var1, XAnalyticsNative$XAnalyticsPropertiesProvider var2, TigonServiceHolder var3, Executor var4, int var5, int var6, int var7);

    public native boolean isInitialized();

    public native void kickOffUpload();

    public native void logCounter(String var1, long var2);

    public native void logEvent(String var1, String var2, String var3);

    public native void logRealtimeEvent(String var1, String var2, String var3);

    public native void logSampledEvent(String var1, String var2, int var3, String var4);

    public native void onSwitchUserId();

    public native void resumeUploading(String var1);

    public native void saveCounters();

    public native void setResponseListener(XAnalyticsNative$XAnalyticsResponseListener var1);

    public native void updateMultibatchSize(int var1);

    public native long updateTigonInstance(String var1, String var2, TigonServiceHolder var3);
}

