/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.annotation.SuppressLint
 */
package com.github.mikephil.charting.a;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;

@SuppressLint(value={"NewApi"})
public final class a {
    public ValueAnimator.AnimatorUpdateListener a;
    public float b = 1.0f;
    public float c = 1.0f;

    public a() {
    }

    public a(ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.a = animatorUpdateListener;
    }

    public final float a() {
        return this.b;
    }

    public final float b() {
        return this.c;
    }
}

