/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.b;

public abstract class a<T> {
    protected int a = 0;
    public final float[] b;
    protected float c = 1.0f;
    protected float d = 1.0f;
    protected int e = 0;
    protected int f = 0;

    public a(int n2) {
        this.b = new float[n2];
    }

    public final void a() {
        this.a = 0;
    }

    public final void a(float f2, float f3) {
        this.c = f2;
        this.d = f3;
    }
}

