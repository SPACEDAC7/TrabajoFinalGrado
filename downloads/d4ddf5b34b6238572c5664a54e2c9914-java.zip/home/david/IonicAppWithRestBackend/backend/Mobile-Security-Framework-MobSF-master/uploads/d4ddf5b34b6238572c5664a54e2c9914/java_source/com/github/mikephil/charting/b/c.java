/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.b;

import com.github.mikephil.charting.b.a;
import com.github.mikephil.charting.b.b;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import java.util.List;

public final class c
extends b {
    public c(int n2, float f2, int n3, boolean bl2) {
        super(n2, f2, n3, bl2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(List<BarEntry> var1_1) {
        var8_2 = var1_1.size();
        var9_3 = this.c;
        var15_4 = this.j;
        var10_5 = this.g / 2.0f;
        var11_6 = this.h / 2.0f;
        var13_7 = 0;
        block0 : do {
            if ((float)var13_7 >= var8_2 * var9_3) {
                this.a();
                return;
            }
            var16_16 = var1_1.get(var13_7);
            var12_14 = (float)(var16_16.e + var16_16.e * (var15_4 - 1) + this.i) + this.h * (float)var16_16.e + var11_6;
            var2_8 = var16_16.a();
            var17_17 = var16_16.a;
            if (this.k && var17_17 != null) ** GOTO lbl32
            if (this.l) {
                var3_9 = var2_8 >= 0.0f ? var2_8 : 0.0f;
                var4_10 = var2_8 <= 0.0f ? var2_8 : 0.0f;
            } else {
                var5_11 = var2_8 >= 0.0f ? var2_8 : 0.0f;
                var4_10 = var5_11;
                var3_9 = var2_8;
                if (var2_8 > 0.0f) {
                    var3_9 = 0.0f;
                    var4_10 = var5_11;
                }
            }
            if (var4_10 > 0.0f) {
                var4_10 *= this.d;
            } else {
                var3_9 *= this.d;
            }
            this.a(var3_9, 0.5f + var12_14 - var10_5, var4_10, var12_14 - 0.5f + var10_5);
            ** GOTO lbl-1000
lbl32: // 1 sources:
            var2_8 = 0.0f;
            var4_10 = - var16_16.b;
            var14_15 = 0;
            do {
                if (var14_15 >= var17_17.length) lbl-1000: // 2 sources:
                {
                    ++var13_7;
                    continue block0;
                }
                var3_9 = var17_17[var14_15];
                if (var3_9 >= 0.0f) {
                    var6_12 = var5_11 = var2_8 + var3_9;
                    var3_9 = var2_8;
                    var2_8 = var5_11;
                    var5_11 = var4_10;
                } else {
                    var7_13 = Math.abs(var3_9) + var4_10;
                    var5_11 = Math.abs(var3_9);
                    var3_9 = var4_10;
                    var5_11 += var4_10;
                    var6_12 = var2_8;
                    var2_8 = var7_13;
                }
                if (this.l) {
                    var4_10 = var3_9 >= var2_8 ? var3_9 : var2_8;
                    if (var3_9 > var2_8) {
                        var3_9 = var2_8;
                    }
                    var2_8 = var4_10;
                } else {
                    var4_10 = var3_9 >= var2_8 ? var3_9 : var2_8;
                    if (var3_9 > var2_8) {
                        var3_9 = var2_8;
                    }
                    var2_8 = var3_9;
                    var3_9 = var4_10;
                }
                var4_10 = this.d;
                this.a(var2_8 * this.d, 0.5f + var12_14 - var10_5, var3_9 * var4_10, var12_14 - 0.5f + var10_5);
                ++var14_15;
                var4_10 = var5_11;
                var2_8 = var6_12;
            } while (true);
            break;
        } while (true);
    }
}

