/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.c;

public final class b
extends Enum<b> {
    public static final /* enum */ int a = 1;
    public static final /* enum */ int b = 2;
    private static final /* synthetic */ int[] c;

    static {
        c = new int[]{a, b};
    }
}

