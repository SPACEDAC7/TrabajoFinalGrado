/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 */
package com.github.mikephil.charting.c;

import android.graphics.Paint;
import com.github.mikephil.charting.c.a;
import com.github.mikephil.charting.c.b;
import com.github.mikephil.charting.c.d;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.f.f;
import com.github.mikephil.charting.i.h;

public final class c
extends d {
    protected com.github.mikephil.charting.f.a a;
    public float[] b = new float[0];
    public int c;
    public int d;
    public int e = 6;
    public boolean f = true;
    public boolean g = false;
    public boolean h = false;
    public boolean i = true;
    public boolean j = false;
    public float k = Float.NaN;
    public float l = Float.NaN;
    public float m = 10.0f;
    public float n = 10.0f;
    public float o = 0.0f;
    public float p = 0.0f;
    public float q = 0.0f;
    public int r = a.a;
    public int s;

    public c() {
        this.s = b.a;
        this.F = 0.0f;
    }

    public c(int n2) {
        this.s = n2;
        this.F = 0.0f;
    }

    private String y() {
        String string = "";
        for (int i2 = 0; i2 < this.b.length; ++i2) {
            String string2 = this.a(i2);
            if (string.length() >= string2.length()) continue;
            string = string2;
        }
        return string;
    }

    public final float a(Paint paint) {
        paint.setTextSize(this.H);
        return (float)h.a(paint, this.y()) + this.E * 2.0f;
    }

    public final String a(int n2) {
        if (n2 < 0 || n2 >= this.b.length) {
            return "";
        }
        if (this.a == null) {
            this.a = new f(this.d);
        }
        return this.a.a(this.b[n2]);
    }

    public final float b(Paint paint) {
        paint.setTextSize(this.H);
        return (float)h.b(paint, this.y()) + h.a(2.5f) * 2.0f + this.F;
    }

    public final boolean i() {
        if (this.D && this.z && this.r == a.a) {
            return true;
        }
        return false;
    }
}

