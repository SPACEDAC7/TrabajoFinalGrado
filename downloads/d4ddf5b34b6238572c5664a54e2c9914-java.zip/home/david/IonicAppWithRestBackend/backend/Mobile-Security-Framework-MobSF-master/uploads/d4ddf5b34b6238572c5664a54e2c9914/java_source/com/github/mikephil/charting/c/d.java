/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.DashPathEffect
 */
package com.github.mikephil.charting.c;

import android.graphics.DashPathEffect;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.c.m;
import com.github.mikephil.charting.i.h;
import java.util.ArrayList;
import java.util.List;

public abstract class d
extends e {
    public DashPathEffect A = null;
    public List<m> B;
    public boolean C = false;
    public int t = -7829368;
    public float u = 1.0f;
    public int v = -7829368;
    public float w = 1.0f;
    public boolean x = true;
    public boolean y = true;
    public boolean z = true;

    public d() {
        this.H = h.a(10.0f);
        this.E = h.a(5.0f);
        this.F = h.a(5.0f);
        this.B = new ArrayList<m>();
    }

    public final void j() {
        this.x = false;
    }

    public final void l() {
        this.y = false;
    }
}

