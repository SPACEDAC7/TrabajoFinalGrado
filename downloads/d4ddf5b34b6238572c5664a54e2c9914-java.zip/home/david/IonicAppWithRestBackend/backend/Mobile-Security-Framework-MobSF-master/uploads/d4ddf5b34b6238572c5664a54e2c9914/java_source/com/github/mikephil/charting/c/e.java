/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Typeface
 */
package com.github.mikephil.charting.c;

import android.graphics.Typeface;

public abstract class e {
    public boolean D = true;
    public float E = 5.0f;
    public float F = 5.0f;
    public Typeface G = null;
    public float H = 10.0f;
    public int I = -16777216;

    public final float r() {
        return this.E;
    }

    public final float s() {
        return this.F;
    }

    public final Typeface t() {
        return this.G;
    }

    public final float u() {
        return this.H;
    }

    public final int v() {
        return this.I;
    }

    public final void w() {
        this.D = false;
    }

    public final boolean x() {
        return this.D;
    }
}

