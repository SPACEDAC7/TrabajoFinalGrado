/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.c;

public final class f
extends Enum<f> {
    public static final /* enum */ int a = 1;
    public static final /* enum */ int b = 2;
    public static final /* enum */ int c = 3;
    public static final /* enum */ int d = 4;
    public static final /* enum */ int e = 5;
    public static final /* enum */ int f = 6;
    public static final /* enum */ int g = 7;
    public static final /* enum */ int h = 8;
    public static final /* enum */ int i = 9;
    public static final /* enum */ int j = 10;
    public static final /* enum */ int k = 11;
    public static final /* enum */ int l = 12;
    public static final /* enum */ int m = 13;
    private static final /* synthetic */ int[] n;

    static {
        n = new int[]{a, b, c, d, e, f, g, h, i, j, k, l, m};
    }

    public static int[] a() {
        return (int[])n.clone();
    }
}

