/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.c;

public final class g
extends Enum<g> {
    public static final /* enum */ int a = 1;
    public static final /* enum */ int b = 2;
    public static final /* enum */ int c = 3;
    private static final /* synthetic */ int[] d;

    static {
        d = new int[]{a, b, c};
    }

    public static int[] a() {
        return (int[])d.clone();
    }
}

