/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 */
package com.github.mikephil.charting.c;

import android.graphics.Paint;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.c.f;
import com.github.mikephil.charting.c.g;
import com.github.mikephil.charting.c.h;
import com.github.mikephil.charting.i.c;
import com.github.mikephil.charting.i.d;
import java.util.ArrayList;

public final class i
extends e {
    public int[] a;
    public String[] b;
    public int[] c;
    public String[] d;
    public boolean e = false;
    public int f = f.g;
    public int g = h.a;
    public int h = g.a;
    public float i = com.github.mikephil.charting.i.h.a(8.0f);
    public float j = com.github.mikephil.charting.i.h.a(6.0f);
    public float k = com.github.mikephil.charting.i.h.a(0.0f);
    public float l = com.github.mikephil.charting.i.h.a(5.0f);
    public float m = 3.0f;
    public float n = 0.95f;
    public float o = 0.0f;
    public float p = 0.0f;
    public float q = 0.0f;
    public float r = 0.0f;
    public c[] s = new c[0];
    public Boolean[] t = new Boolean[0];
    public c[] u = new c[0];
    private boolean v = false;

    public i() {
        this.H = com.github.mikephil.charting.i.h.a(10.0f);
        this.m = com.github.mikephil.charting.i.h.a(3.0f);
        this.E = com.github.mikephil.charting.i.h.a(5.0f);
        this.F = com.github.mikephil.charting.i.h.a(7.0f);
    }

    private static float a(i i2, Paint paint) {
        float f2 = 0.0f;
        for (int i3 = 0; i3 < i2.b.length; ++i3) {
            float f3 = f2;
            if (i2.b[i3] != null) {
                float f4 = com.github.mikephil.charting.i.h.a(paint, i2.b[i3]);
                f3 = f2;
                if (f4 > f2) {
                    f3 = f4;
                }
            }
            f2 = f3;
        }
        return i2.i + f2 + i2.l;
    }

    private static float b(i i2, Paint paint) {
        float f2 = 0.0f;
        for (int i3 = 0; i3 < i2.b.length; ++i3) {
            float f3 = f2;
            if (i2.b[i3] != null) {
                float f4 = com.github.mikephil.charting.i.h.b(paint, i2.b[i3]);
                f3 = f2;
                if (f4 > f2) {
                    f3 = f4;
                }
            }
            f2 = f3;
        }
        return f2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static float c(i i2, Paint paint) {
        float f2 = 0.0f;
        int n2 = 0;
        while (n2 < i2.b.length) {
            float f3;
            if (i2.b[n2] != null) {
                f3 = f2;
                if (i2.a[n2] != -2) {
                    f3 = f2 + (i2.i + i2.l);
                }
                f2 = f3 += (float)com.github.mikephil.charting.i.h.a(paint, i2.b[n2]);
                if (n2 < i2.b.length - 1) {
                    f2 = f3 + i2.j;
                }
            } else {
                f2 = f3 = f2 + i2.i;
                if (n2 < i2.b.length - 1) {
                    f2 = f3 + i2.m;
                }
            }
            ++n2;
        }
        return f2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(Paint var1_1, d var2_2) {
        if (this.f == f.a || this.f == f.b || this.f == f.d || this.f == f.e || this.f == f.m) {
            this.o = i.a(this, var1_1);
            var4_3 = 0.0f;
            var12_5 = 0;
            do {
                if (var12_5 >= this.b.length) {
                    this.p = var4_3;
                    this.r = this.o;
                    this.q = i.b(this, var1_1);
                    return;
                }
                var3_7 = var4_3;
                if (this.b[var12_5] != null) {
                    var3_7 = var4_3 += (float)com.github.mikephil.charting.i.h.b(var1_1, this.b[var12_5]);
                    if (var12_5 < this.b.length - 1) {
                        var3_7 = var4_3 + this.k;
                    }
                }
                ++var12_5;
                var4_3 = var3_7;
            } while (true);
        }
        if (this.f != f.g && this.f != f.h && this.f != f.i && this.f != f.j && this.f != f.k && this.f != f.l) {
            this.o = i.c(this, var1_1);
            this.p = i.b(this, var1_1);
            this.r = i.a(this, var1_1);
            this.q = this.p;
            return;
        }
        var15_9 = this.b.length;
        var8_10 = com.github.mikephil.charting.i.h.a(var1_1);
        var9_11 = com.github.mikephil.charting.i.h.b(var1_1);
        var10_12 = this.k;
        var11_13 = var2_2.i();
        var2_2 = new ArrayList<E>(var15_9);
        var16_14 = new ArrayList<Boolean>(var15_9);
        var17_15 = new ArrayList<c>();
        var4_4 = 0.0f;
        var5_16 = 0.0f;
        var3_8 = 0.0f;
        var12_6 = -1;
        var13_17 = 0;
        do {
            if (var13_17 >= var15_9) ** GOTO lbl71
            var14_20 = this.a[var13_17] != -2 ? 1 : 0;
            var16_14.add(false);
            var3_8 = var12_6 == -1 ? 0.0f : (var3_8 += this.m);
            if (this.b[var13_17] != null) {
                var2_2.add(com.github.mikephil.charting.i.h.c(var1_1, this.b[var13_17]));
                var6_18 = var14_20 != 0 ? this.l + this.i : 0.0f;
                var3_8 = ((c)var2_2.get((int)var13_17)).a + (var3_8 + var6_18);
            } else {
                var2_2.add(new c(0.0f, 0.0f));
                var6_18 = var14_20 != 0 ? this.i : 0.0f;
                var3_8 = var6_18 + var3_8;
                if (var12_6 == -1) {
                    var12_6 = var13_17;
                }
            }
            if (this.b[var13_17] == null && var13_17 != var15_9 - 1) ** GOTO lbl81
            var6_18 = var5_16 == 0.0f ? 0.0f : this.j;
            if (!this.v || var5_16 == 0.0f || var11_13 - var5_16 >= var6_18 + var3_8) {
                var5_16 = var6_18 + var3_8 + var5_16;
                var7_19 = var4_4;
            } else {
                var17_15.add(new c(var5_16, var8_10));
                var7_19 = Math.max(var4_4, var5_16);
                var14_20 = var12_6 >= 0 ? var12_6 : var13_17;
                var16_14.set(var14_20, true);
                var5_16 = var3_8;
            }
            var6_18 = var5_16;
            var4_4 = var7_19;
            if (var13_17 == var15_9 - 1) {
                var17_15.add(new c(var5_16, var8_10));
                var4_4 = Math.max(var7_19, var5_16);
                var6_18 = var5_16;
            }
            ** GOTO lbl82
lbl71: // 1 sources:
            this.s = var2_2.toArray(new c[var2_2.size()]);
            this.t = var16_14.toArray(new Boolean[var16_14.size()]);
            this.u = var17_15.toArray(new c[var17_15.size()]);
            this.r = i.a(this, var1_1);
            this.q = i.b(this, var1_1);
            this.o = var4_4;
            var3_8 = this.u.length;
            var12_6 = this.u.length == 0 ? 0 : this.u.length - 1;
            this.p = (float)var12_6 * (var9_11 + var10_12) + var8_10 * var3_8;
            return;
lbl81: // 1 sources:
            var6_18 = var5_16;
lbl82: // 2 sources:
            if (this.b[var13_17] != null) {
                var12_6 = -1;
            }
            ++var13_17;
            var5_16 = var6_18;
        } while (true);
    }
}

