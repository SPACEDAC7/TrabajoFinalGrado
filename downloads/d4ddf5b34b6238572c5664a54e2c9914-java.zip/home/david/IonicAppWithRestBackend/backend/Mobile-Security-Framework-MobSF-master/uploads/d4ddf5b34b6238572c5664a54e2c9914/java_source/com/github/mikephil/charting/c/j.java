/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.c;

public final class j
extends Enum<j> {
    public static final /* enum */ int a = 1;
    public static final /* enum */ int b = 2;
    public static final /* enum */ int c = 3;
    public static final /* enum */ int d = 4;
    public static final /* enum */ int e = 5;
    private static final /* synthetic */ int[] f;

    static {
        f = new int[]{a, b, c, d, e};
    }
}

