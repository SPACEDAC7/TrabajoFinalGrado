/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.c;

import com.github.mikephil.charting.c.d;
import com.github.mikephil.charting.c.j;
import com.github.mikephil.charting.f.e;
import com.github.mikephil.charting.i.h;
import java.util.ArrayList;
import java.util.List;

public final class k
extends d {
    public List<String> a = new ArrayList<String>();
    public int b = 1;
    public int c = 1;
    public int d = 1;
    public int e = 1;
    public float f = 0.0f;
    public int g = 4;
    public int h = 1;
    public boolean i = false;
    public int j = 1;
    public boolean k = false;
    public e l = new e();
    public int m = j.a;

    public k() {
        this.F = h.a(4.0f);
    }
}

