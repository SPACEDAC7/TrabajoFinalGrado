/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.c;

public final class l
extends Enum<l> {
    public static final /* enum */ int a = 1;
    public static final /* enum */ int b = 2;
    public static final /* enum */ int c = 3;
    public static final /* enum */ int d = 4;
    private static final /* synthetic */ int[] e;

    static {
        e = new int[]{a, b, c, d};
    }
}

