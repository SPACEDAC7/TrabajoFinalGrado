/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.DashPathEffect
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 */
package com.github.mikephil.charting.c;

import android.graphics.DashPathEffect;
import android.graphics.Paint;
import com.github.mikephil.charting.c.e;

public final class m
extends e {
    public float a;
    public float b;
    public int c;
    public Paint.Style d;
    public String e;
    public DashPathEffect f;
    public int g;
}

