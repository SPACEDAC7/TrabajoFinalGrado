/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 */
package com.github.mikephil.charting.c;

import android.content.Context;
import android.graphics.Canvas;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

public abstract class n
extends RelativeLayout {
    private void setupLayoutResource(int n2) {
        View view = LayoutInflater.from((Context)this.getContext()).inflate(n2, (ViewGroup)this);
        view.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-2, -2));
        view.measure(View.MeasureSpec.makeMeasureSpec((int)0, (int)0), View.MeasureSpec.makeMeasureSpec((int)0, (int)0));
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
    }

    public final void a(Canvas canvas, float f2, float f3) {
        f2 = (float)this.getXOffset$133ade() + f2;
        f3 = (float)this.getYOffset$133ade() + f3;
        canvas.translate(f2, f3);
        this.draw(canvas);
        canvas.translate(- f2, - f3);
    }

    public abstract int getXOffset$133ade();

    public abstract int getYOffset$133ade();
}

