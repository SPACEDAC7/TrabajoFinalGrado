/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.util.Log
 */
package com.github.mikephil.charting.charts;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import com.github.mikephil.charting.c.b;
import com.github.mikephil.charting.c.k;
import com.github.mikephil.charting.charts.d;
import com.github.mikephil.charting.d.c;
import com.github.mikephil.charting.h.g;
import com.github.mikephil.charting.h.j;
import com.github.mikephil.charting.h.o;
import com.github.mikephil.charting.i.a;

public class BarChart
extends com.github.mikephil.charting.charts.b<com.github.mikephil.charting.data.g>
implements c {
    private boolean aa = false;
    private boolean ab = true;
    private boolean ac = false;

    public BarChart(Context context) {
        super(context);
    }

    public BarChart(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public BarChart(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
    }

    @Override
    public com.github.mikephil.charting.e.a a(float f2, float f3) {
        if (this.F || this.y == null) {
            Log.e((String)"MPAndroidChart", (String)"Can't select by touch. No data set.");
            return null;
        }
        return this.P.a(f2, f3);
    }

    @Override
    protected void a() {
        super.a();
        this.O = new j(this, this.R, this.Q);
        this.v = new o(this.Q, this.q, this.t, this);
        this.P = new com.github.mikephil.charting.e.d(this);
        this.H = -0.5f;
    }

    @Override
    protected final void b() {
        super.b();
        this.G = this.G + 0.5f;
        float f2 = this.G;
        this.G = (float)((com.github.mikephil.charting.data.g)this.y).a() * f2;
        f2 = ((com.github.mikephil.charting.data.g)this.y).h();
        float f3 = this.G;
        this.G = (float)((com.github.mikephil.charting.data.g)this.y).f() * f2 + f3;
        this.I = this.G - this.H;
    }

    @Override
    public final boolean c() {
        return this.aa;
    }

    @Override
    public final boolean d() {
        return this.ab;
    }

    @Override
    public final boolean e() {
        return this.ac;
    }

    @Override
    public com.github.mikephil.charting.data.g getBarData() {
        return (com.github.mikephil.charting.data.g)this.y;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int getHighestVisibleXIndex() {
        float f2 = ((com.github.mikephil.charting.data.g)this.y).a();
        f2 = f2 <= 1.0f ? 1.0f : ((com.github.mikephil.charting.data.g)this.y).h() + f2;
        float[] arrf = new float[]{this.Q.g(), this.Q.h()};
        this.a(b.a).b(arrf);
        if (arrf[0] >= this.getXChartMax()) {
            f2 = this.getXChartMax() / f2;
            return (int)f2;
        }
        f2 = arrf[0] / f2;
        return (int)f2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int getLowestVisibleXIndex() {
        float f2 = ((com.github.mikephil.charting.data.g)this.y).a();
        f2 = f2 <= 1.0f ? 1.0f : ((com.github.mikephil.charting.data.g)this.y).h() + f2;
        float[] arrf = new float[]{this.Q.f(), this.Q.h()};
        this.a(b.a).b(arrf);
        if (arrf[0] <= this.H) {
            f2 = 0.0f;
            return (int)f2;
        }
        f2 = arrf[0] / f2 + 1.0f;
        return (int)f2;
    }

    public void setDrawBarShadow(boolean bl2) {
        this.ac = bl2;
    }

    public void setDrawHighlightArrow(boolean bl2) {
        this.aa = bl2;
    }

    public void setDrawValueAboveBar(boolean bl2) {
        this.ab = bl2;
    }
}

