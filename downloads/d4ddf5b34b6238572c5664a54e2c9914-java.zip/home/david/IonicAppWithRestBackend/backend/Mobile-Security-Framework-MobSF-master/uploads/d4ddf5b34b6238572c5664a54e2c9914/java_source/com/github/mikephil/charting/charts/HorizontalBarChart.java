/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  android.util.AttributeSet
 *  android.util.Log
 */
package com.github.mikephil.charting.charts;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import com.github.mikephil.charting.c.c;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.c.f;
import com.github.mikephil.charting.c.i;
import com.github.mikephil.charting.c.j;
import com.github.mikephil.charting.c.k;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.b;
import com.github.mikephil.charting.charts.d;
import com.github.mikephil.charting.h.g;
import com.github.mikephil.charting.h.l;
import com.github.mikephil.charting.h.p;
import com.github.mikephil.charting.h.q;
import com.github.mikephil.charting.i.a;
import com.github.mikephil.charting.i.h;

public class HorizontalBarChart
extends BarChart {
    public HorizontalBarChart(Context context) {
        super(context);
    }

    public HorizontalBarChart(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public HorizontalBarChart(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
    }

    @Override
    public final com.github.mikephil.charting.e.a a(float f2, float f3) {
        if (this.F || this.y == null) {
            Log.e((String)"MPAndroidChart", (String)"Can't select by touch. No data set.");
            return null;
        }
        return this.P.a(f3, f2);
    }

    @Override
    protected final void a() {
        super.a();
        this.t = new com.github.mikephil.charting.i.g(this.Q);
        this.u = new com.github.mikephil.charting.i.g(this.Q);
        this.O = new l(this, this.R, this.Q);
        this.P = new com.github.mikephil.charting.e.e(this);
        this.r = new q(this.Q, this.o, this.t);
        this.s = new q(this.Q, this.p, this.u);
        this.v = new p(this.Q, this.q, this.t, this);
    }

    @Override
    protected final void f() {
        this.u.a(this.p.p, this.p.q, this.G, this.H);
        this.t.a(this.o.p, this.o.q, this.G, this.H);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int getHighestVisibleXIndex() {
        float f2 = ((com.github.mikephil.charting.data.g)this.y).a();
        f2 = f2 <= 1.0f ? 1.0f : ((com.github.mikephil.charting.data.g)this.y).h() + f2;
        float[] arrf = new float[]{this.Q.f(), this.Q.e()};
        this.a(com.github.mikephil.charting.c.b.a).b(arrf);
        if (arrf[1] >= this.getXChartMax()) {
            f2 = this.getXChartMax() / f2;
            return (int)f2;
        }
        f2 = arrf[1] / f2;
        return (int)f2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int getLowestVisibleXIndex() {
        float f2 = ((com.github.mikephil.charting.data.g)this.y).a();
        f2 = f2 <= 1.0f ? 1.0f : ((com.github.mikephil.charting.data.g)this.y).h() + f2;
        float[] arrf = new float[]{this.Q.f(), this.Q.h()};
        this.a(com.github.mikephil.charting.c.b.a).b(arrf);
        if (arrf[1] <= 0.0f) {
            f2 = 0.0f;
            return (int)(f2 + 1.0f);
        }
        f2 = arrf[1] / f2;
        return (int)(f2 + 1.0f);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void i() {
        var4_1 = 0.0f;
        if (this.w) ** GOTO lbl62
        if (this.K == null || !this.K.D) ** GOTO lbl-1000
        if (this.K.f == f.a || this.K.f == f.b) {
            var1_2 = Math.min(this.K.o, this.Q.c * this.K.n) + this.K.E * 2.0f + 0.0f;
            var2_3 = 0.0f;
            var3_4 = 0.0f;
        } else if (this.K.f == f.d || this.K.f == f.e) {
            var2_3 = Math.min(this.K.o, this.Q.c * this.K.n);
            var3_4 = this.K.E;
            var1_2 = 0.0f;
            var2_3 = var2_3 + var3_4 * 2.0f + 0.0f;
            var3_4 = 0.0f;
        } else if (this.K.f == f.g || this.K.f == f.h || this.K.f == f.i) {
            var4_1 = Math.min(this.K.q * 2.0f + this.K.p, this.Q.d * this.K.n);
            var1_2 = 0.0f;
            var2_3 = 0.0f;
            var3_4 = 0.0f;
            var4_1 += 0.0f;
        } else if (this.K.f == f.j || this.K.f == f.k || this.K.f == f.l) {
            var3_4 = Math.min(this.K.q * 2.0f + this.K.p, this.Q.d * this.K.n) + 0.0f;
            var1_2 = 0.0f;
            var2_3 = 0.0f;
        } else lbl-1000: // 2 sources:
        {
            var3_4 = 0.0f;
            var1_2 = 0.0f;
            var2_3 = 0.0f;
        }
        var5_5 = var3_4;
        if (this.o.i()) {
            var5_5 = var3_4 + this.o.b(this.r.d);
        }
        var6_6 = var4_1;
        if (this.p.i()) {
            var6_6 = var4_1 + this.p.b(this.s.d);
        }
        var7_7 = this.q.d;
        var4_1 = var1_2;
        var3_4 = var2_3;
        if (this.q.D) {
            if (this.q.m == j.b) {
                var3_4 = var2_3 + var7_7;
                var4_1 = var1_2;
            } else if (this.q.m == j.a) {
                var4_1 = var1_2 + var7_7;
                var3_4 = var2_3;
            } else {
                var4_1 = var1_2;
                var3_4 = var2_3;
                if (this.q.m == j.c) {
                    var3_4 = var2_3 + var7_7;
                    var4_1 = var1_2 + var7_7;
                }
            }
        }
        var1_2 = var5_5 + this.e;
        var2_3 = var4_1 + this.f;
        var4_1 = var6_6 + this.g;
        var5_5 = h.a(this.m);
        this.Q.a(Math.max(var5_5, var3_4 += this.h), Math.max(var5_5, var1_2), Math.max(var5_5, var2_3), Math.max(var5_5, var4_1));
        if (this.x) {
            new StringBuilder("offsetLeft: ").append(var3_4).append(", offsetTop: ").append(var1_2).append(", offsetRight: ").append(var2_3).append(", offsetBottom: ").append(var4_1);
            new StringBuilder("Content: ").append(this.Q.b.toString());
        }
lbl62: // 4 sources:
        this.g();
        this.f();
    }

    @Override
    protected final void j() {
        float[] arrf = new float[9];
        this.Q.a.getValues(arrf);
        k k2 = this.q;
        float f2 = ((com.github.mikephil.charting.data.g)this.y).f() * this.q.e;
        float f3 = this.Q.j();
        k2.h = (int)Math.ceil(f2 / (arrf[4] * f3));
        if (this.q.h <= 0) {
            this.q.h = 1;
        }
    }
}

