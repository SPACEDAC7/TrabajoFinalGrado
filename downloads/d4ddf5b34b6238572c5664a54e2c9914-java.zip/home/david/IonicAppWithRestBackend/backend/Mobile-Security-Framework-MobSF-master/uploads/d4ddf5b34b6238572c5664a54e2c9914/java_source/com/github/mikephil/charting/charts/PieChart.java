/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.PointF
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.PorterDuffXfermode
 *  android.graphics.RectF
 *  android.graphics.Typeface
 *  android.graphics.Xfermode
 *  android.text.SpannableString
 *  android.text.TextPaint
 *  android.util.AttributeSet
 */
package com.github.mikephil.charting.charts;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.Xfermode;
import android.text.SpannableString;
import android.text.TextPaint;
import android.util.AttributeSet;
import com.github.mikephil.charting.charts.d;
import com.github.mikephil.charting.charts.e;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.b;
import com.github.mikephil.charting.data.l;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.h.f;
import com.github.mikephil.charting.h.g;
import com.github.mikephil.charting.h.m;
import com.github.mikephil.charting.i.h;
import java.util.List;

public class PieChart
extends e<l> {
    public boolean a = true;
    public boolean b = true;
    public boolean c = false;
    public float d = 55.0f;
    public boolean e = true;
    protected float f = 360.0f;
    public RectF i = new RectF();
    public float[] j;
    private float[] k;
    private boolean l = false;
    public SpannableString m = new SpannableString((CharSequence)"");
    public float n = 50.0f;
    public float o = 1.0f;
    public boolean p = false;

    public PieChart(Context context) {
        super(context);
    }

    public PieChart(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public PieChart(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
    }

    @Override
    public final int a(float f2) {
        f2 = h.c(f2 - this.a);
        for (int i2 = 0; i2 < this.k.length; ++i2) {
            if (this.k[i2] <= f2) continue;
            return i2;
        }
        return -1;
    }

    @Override
    protected final void a() {
        super.a();
        this.O = new m(this, this.R, this.Q);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean a(int n2, int n3) {
        if (!this.r() || n3 < 0) {
            return false;
        }
        int n4 = 0;
        while (n4 < this.T.length) {
            if (this.T[n4].a == n2 && this.T[n4].b == n3) {
                return true;
            }
            ++n4;
        }
        return false;
    }

    @Override
    protected final float[] a(Entry entry, a a2) {
        a2 = this.getCenterCircleBox();
        float f2 = this.getRadius();
        float f3 = f2 / 10.0f * 3.6f;
        if (this.b) {
            f3 = (f2 - f2 / 100.0f * this.n) / 2.0f;
        }
        f3 = f2 - f3;
        f2 = this.a;
        int n2 = entry.e;
        float f4 = this.j[n2] / 2.0f;
        float f5 = (float)((double)f3 * Math.cos(Math.toRadians((this.k[n2] + f2 - f4) * this.R.b)) + (double)a2.x);
        double d2 = f3;
        double d3 = Math.sin(Math.toRadians((this.k[n2] + f2 - f4) * this.R.b));
        return new float[]{f5, (float)((double)a2.y + d3 * d2)};
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void b() {
        super.b();
        this.j = new float[((l)this.y).h];
        this.k = new float[((l)this.y).h];
        List list = ((l)this.y).m;
        int n2 = 0;
        int n3 = 0;
        while (n2 < ((l)this.y).a()) {
            List list2 = ((com.github.mikephil.charting.data.m)list.get((int)n2)).b;
            for (int i2 = 0; i2 < list2.size(); ++n3, ++i2) {
                this.j[n3] = Math.abs(((Entry)list2.get((int)i2)).d) / ((l)this.y).g * this.f;
                this.k[n3] = n3 == 0 ? this.j[n3] : this.k[n3 - 1] + this.j[n3];
            }
            ++n2;
        }
    }

    public final boolean c() {
        if (((m)this.O).j.getXfermode() != null) {
            return true;
        }
        return false;
    }

    public float[] getAbsoluteAngles() {
        return this.k;
    }

    public boolean getAntiClockwiseEnabled() {
        return this.p;
    }

    public PointF getCenterCircleBox() {
        return new PointF(this.i.centerX(), this.i.centerY());
    }

    public SpannableString getCenterText() {
        return this.m;
    }

    public float getCenterTextRadiusPercent() {
        return this.o;
    }

    public RectF getCircleBox() {
        return this.i;
    }

    public float[] getDrawAngles() {
        return this.j;
    }

    public float getHoleRadius() {
        return this.n;
    }

    public float getMaxAngle() {
        return this.f;
    }

    @Override
    public float getRadius() {
        if (this.i == null) {
            return 0.0f;
        }
        return Math.min(this.i.width() / 2.0f, this.i.height() / 2.0f);
    }

    @Override
    protected float getRequiredBaseOffset() {
        return 0.0f;
    }

    @Override
    protected float getRequiredLegendOffset() {
        return this.N.a.getTextSize() * 2.0f;
    }

    public float getTransparentCircleRadius() {
        return this.d;
    }

    @Override
    public final void i() {
        super.i();
        if (this.F) {
            return;
        }
        float f2 = this.getDiameter() / 2.0f;
        PointF pointF = this.getCenterOffsets();
        float f3 = ((l)this.y).h().r;
        this.i.set(pointF.x - f2 + f3, pointF.y - f2 + f3, pointF.x + f2 - f3, f2 + pointF.y - f3);
    }

    protected void onDetachedFromWindow() {
        if (this.O != null && this.O instanceof m) {
            m m2 = (m)this.O;
            if (m2.n != null) {
                m2.n.recycle();
                m2.n = null;
            }
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.F) {
            return;
        }
        this.O.a(canvas);
        if (this.r()) {
            this.O.a(canvas, this.T);
        }
        this.O.c(canvas);
        this.O.b(canvas);
        this.N.a(canvas);
        this.a(canvas);
        this.b(canvas);
    }

    public void setAntiClockwiseEnabled(boolean bl2) {
        this.p = bl2;
    }

    public void setCenterText(SpannableString spannableString) {
        if (spannableString == null) {
            this.m = new SpannableString((CharSequence)"");
            return;
        }
        this.m = spannableString;
    }

    public void setCenterText(String string) {
        this.setCenterText(new SpannableString((CharSequence)string));
    }

    public void setCenterTextColor(int n2) {
        ((m)this.O).m.setColor(n2);
    }

    public void setCenterTextRadiusPercent(float f2) {
        this.o = f2;
    }

    public void setCenterTextSize(float f2) {
        ((m)this.O).m.setTextSize(h.a(f2));
    }

    public void setCenterTextSizePixels(float f2) {
        ((m)this.O).m.setTextSize(f2);
    }

    public void setCenterTextTypeface(Typeface typeface) {
        ((m)this.O).m.setTypeface(typeface);
    }

    public void setDrawCenterText(boolean bl2) {
        this.e = bl2;
    }

    public void setDrawHoleEnabled(boolean bl2) {
        this.b = bl2;
    }

    public void setDrawSliceText(boolean bl2) {
        this.a = bl2;
    }

    public void setHoleColor(int n2) {
        ((m)this.O).j.setXfermode(null);
        ((m)this.O).j.setColor(n2);
    }

    public void setHoleColorTransparent(boolean bl2) {
        if (bl2) {
            ((m)this.O).j.setColor(-1);
            ((m)this.O).j.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            return;
        }
        ((m)this.O).j.setXfermode(null);
    }

    public void setHoleRadius(float f2) {
        this.n = f2;
    }

    public void setMaxAngle(float f2) {
        float f3 = 360.0f;
        float f4 = 90.0f;
        if (f2 > 360.0f) {
            f2 = f3;
        }
        if (f2 < 90.0f) {
            f2 = f4;
        }
        this.f = f2;
    }

    public void setTransparentCircleAlpha(int n2) {
        ((m)this.O).k.setAlpha(n2);
    }

    public void setTransparentCircleColor(int n2) {
        Paint paint = ((m)this.O).k;
        int n3 = paint.getAlpha();
        paint.setColor(n2);
        paint.setAlpha(n3);
    }

    public void setTransparentCircleRadius(float f2) {
        this.d = f2;
    }

    public void setUsePercentValues(boolean bl2) {
        this.c = bl2;
    }
}

