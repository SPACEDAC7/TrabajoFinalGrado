/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.charts;

import com.github.mikephil.charting.charts.b;
import com.github.mikephil.charting.charts.d;

final class a
implements Runnable {
    final /* synthetic */ float a;
    final /* synthetic */ float b;
    final /* synthetic */ float c;
    final /* synthetic */ float d;
    final /* synthetic */ b e;

    a(b b2, float f2, float f3, float f4, float f5) {
        this.e = b2;
        this.a = f2;
        this.b = f3;
        this.c = f4;
        this.d = f5;
    }

    @Override
    public final void run() {
        this.e.Q.a(this.a, this.b, this.c, this.d);
        this.e.g();
        this.e.f();
    }
}

