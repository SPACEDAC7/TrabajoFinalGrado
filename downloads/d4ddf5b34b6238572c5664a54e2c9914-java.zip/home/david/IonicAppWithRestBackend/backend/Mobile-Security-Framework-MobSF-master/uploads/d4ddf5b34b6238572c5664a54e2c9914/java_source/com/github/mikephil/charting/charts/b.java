/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.PointF
 *  android.graphics.RectF
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.animation.AnimationUtils
 */
package com.github.mikephil.charting.charts;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AnimationUtils;
import com.github.mikephil.charting.c.c;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.c.f;
import com.github.mikephil.charting.c.i;
import com.github.mikephil.charting.c.j;
import com.github.mikephil.charting.c.k;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.HorizontalBarChart;
import com.github.mikephil.charting.charts.a;
import com.github.mikephil.charting.charts.d;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.g;
import com.github.mikephil.charting.i.h;
import java.util.List;

@SuppressLint(value={"RtlHardcoded"})
public abstract class b<T extends com.github.mikephil.charting.data.e<? extends com.github.mikephil.charting.data.f<? extends Entry>>>
extends d<T>
implements com.github.mikephil.charting.d.b {
    protected int a = 100;
    private boolean aa = false;
    private Integer ab = null;
    private Integer ac = null;
    private long ad = 0;
    private long ae = 0;
    public boolean b = false;
    public boolean c = true;
    public boolean d = true;
    public boolean e = true;
    public boolean f = true;
    public boolean g = true;
    protected boolean h = false;
    protected Paint i;
    protected Paint j;
    public boolean k = true;
    protected boolean l = false;
    protected float m = 15.0f;
    protected com.github.mikephil.charting.g.a n;
    public c o;
    public c p;
    public k q;
    protected com.github.mikephil.charting.h.a r;
    protected com.github.mikephil.charting.h.a s;
    protected com.github.mikephil.charting.i.a t;
    protected com.github.mikephil.charting.i.a u;
    protected com.github.mikephil.charting.h.d v;
    protected boolean w = false;

    public b(Context context) {
        super(context);
    }

    public b(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public b(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
    }

    public com.github.mikephil.charting.e.a a(float f2, float f3) {
        if (this.F || this.y == null) {
            Log.e((String)"MPAndroidChart", (String)"Can't select by touch. No data set.");
            return null;
        }
        return this.P.a(f2, f3);
    }

    @Override
    public final com.github.mikephil.charting.i.a a(int n2) {
        if (n2 == com.github.mikephil.charting.c.b.a) {
            return this.t;
        }
        return this.u;
    }

    @Override
    protected void a() {
        super.a();
        this.o = new c(com.github.mikephil.charting.c.b.a);
        this.p = new c(com.github.mikephil.charting.c.b.b);
        this.q = new k();
        this.t = new com.github.mikephil.charting.i.a(this.Q);
        this.u = new com.github.mikephil.charting.i.a(this.Q);
        this.r = new com.github.mikephil.charting.h.a(this.Q, this.o, this.t);
        this.s = new com.github.mikephil.charting.h.a(this.Q, this.p, this.u);
        this.v = new com.github.mikephil.charting.h.d(this.Q, this.q, this.t);
        this.P = new com.github.mikephil.charting.e.b<b>(this);
        this.M = new com.github.mikephil.charting.g.f(this, this.Q.a);
        this.i = new Paint();
        this.i.setStyle(Paint.Style.FILL);
        this.i.setColor(Color.rgb((int)240, (int)240, (int)240));
        this.j = new Paint();
        this.j.setStyle(Paint.Style.STROKE);
        this.j.setColor(-16777216);
        this.j.setStrokeWidth(h.a(1.0f));
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final float[] a(Entry arrf, com.github.mikephil.charting.e.a a2) {
        int n2 = a2.b;
        float f2 = arrf.e;
        float f3 = arrf.d;
        if (this instanceof BarChart) {
            float f4 = ((g)this.y).h();
            int n3 = ((com.github.mikephil.charting.data.e)this.y).a();
            int n4 = arrf.e;
            if (this instanceof HorizontalBarChart) {
                float f5 = (n3 - 1) * n4 + n4 + n2;
                float f6 = n4;
                float f7 = f4 / 2.0f;
                f3 = ((BarEntry)arrf).a != null ? a2.d.b : arrf.d;
                f2 = f3 * this.R.b;
                f3 = f7 + (f5 + f6 * f4);
            } else {
                f3 = (n3 - 1) * n4 + n4 + n2;
                f2 = n4;
                f2 = f4 / 2.0f + (f3 + f2 * f4);
                f3 = ((BarEntry)arrf).a != null ? a2.d.b : arrf.d;
                f3 *= this.R.b;
            }
        } else {
            f3 *= this.R.b;
        }
        arrf = new float[]{f2, f3};
        this.a(((com.github.mikephil.charting.data.f)((com.github.mikephil.charting.data.e)this.y).c((int)n2)).o).a(arrf);
        return arrf;
    }

    public final c b(int n2) {
        if (n2 == com.github.mikephil.charting.c.b.a) {
            return this.o;
        }
        return this.p;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void b() {
        c c2;
        float f2;
        if (this.aa) {
            ((com.github.mikephil.charting.data.e)this.y).a(this.getLowestVisibleXIndex(), this.getHighestVisibleXIndex());
        }
        float f3 = ((com.github.mikephil.charting.data.e)this.y).a(com.github.mikephil.charting.c.b.a);
        float f4 = ((com.github.mikephil.charting.data.e)this.y).b(com.github.mikephil.charting.c.b.a);
        float f5 = ((com.github.mikephil.charting.data.e)this.y).a(com.github.mikephil.charting.c.b.b);
        float f6 = ((com.github.mikephil.charting.data.e)this.y).b(com.github.mikephil.charting.c.b.b);
        float f7 = this.o.i ? 0.0f : f3;
        float f8 = Math.abs(f4 - f7);
        f7 = this.p.i ? 0.0f : f5;
        float f9 = Math.abs(f6 - f7);
        if (f8 == 0.0f) {
            f7 = 1.0f + f4;
            if (!this.o.i) {
                f2 = f3 - 1.0f;
                f3 = f7;
            } else {
                f2 = f3;
                f3 = f7;
            }
        } else {
            f2 = f3;
            f3 = f4;
        }
        if (f9 == 0.0f) {
            f7 = 1.0f + f6;
            if (!this.p.i) {
                f5 -= 1.0f;
            }
        } else {
            f7 = f6;
        }
        float f10 = f8 / 100.0f * this.o.m;
        f6 = f9 / 100.0f * this.p.m;
        f4 = f8 / 100.0f;
        f8 = this.o.n * f4;
        f4 = f9 / 100.0f;
        f4 = this.p.n * f4;
        this.I = ((com.github.mikephil.charting.data.e)this.y).l.size() - 1;
        this.G = Math.abs(this.I - this.H);
        if (this.o.i) {
            if (f2 < 0.0f && f3 < 0.0f) {
                c2 = this.o;
                f3 = !Float.isNaN(this.o.k) ? this.o.k : f2 - f8;
                c2.p = Math.min(0.0f, f3);
                c2 = this.o;
                f3 = 0.0f;
            } else if ((double)f2 >= 0.0) {
                this.o.p = 0.0f;
                c2 = this.o;
                f3 = !Float.isNaN(this.o.l) ? this.o.l : (f3 += f10);
                f3 = Math.max(0.0f, f3);
            } else {
                c2 = this.o;
                f2 = !Float.isNaN(this.o.k) ? this.o.k : (f2 -= f8);
                c2.p = Math.min(0.0f, f2);
                c2 = this.o;
                f3 = !Float.isNaN(this.o.l) ? this.o.l : (f3 += f10);
                f3 = Math.max(0.0f, f3);
            }
        } else {
            c2 = this.o;
            f2 = !Float.isNaN(this.o.k) ? this.o.k : (f2 -= f8);
            c2.p = f2;
            c2 = this.o;
            f3 = !Float.isNaN(this.o.l) ? this.o.l : (f3 += f10);
        }
        c2.o = f3;
        if (this.p.i) {
            if (f5 < 0.0f && f7 < 0.0f) {
                c2 = this.p;
                f3 = !Float.isNaN(this.p.k) ? this.p.k : f5 - f4;
                c2.p = Math.min(0.0f, f3);
                c2 = this.p;
                f3 = 0.0f;
            } else if (f5 >= 0.0f) {
                this.p.p = 0.0f;
                c2 = this.p;
                f3 = !Float.isNaN(this.p.l) ? this.p.l : f7 + f6;
                f3 = Math.max(0.0f, f3);
            } else {
                c2 = this.p;
                f3 = !Float.isNaN(this.p.k) ? this.p.k : f5 - f4;
                c2.p = Math.min(0.0f, f3);
                c2 = this.p;
                f3 = !Float.isNaN(this.p.l) ? this.p.l : f7 + f6;
                f3 = Math.max(0.0f, f3);
            }
        } else {
            c2 = this.p;
            f3 = !Float.isNaN(this.p.k) ? this.p.k : f5 - f4;
            c2.p = f3;
            c2 = this.p;
            f3 = !Float.isNaN(this.p.l) ? this.p.l : f7 + f6;
        }
        c2.o = f3;
        this.o.q = Math.abs(this.o.o - this.o.p);
        this.p.q = Math.abs(this.p.o - this.p.p);
    }

    public final void b(float f2, float f3, float f4, float f5) {
        this.w = true;
        this.post((Runnable)new a(this, f2, f3, f4, f5));
    }

    @Override
    public final boolean c(int n2) {
        return this.b((int)n2).h;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void computeScroll() {
        if (!(this.M instanceof com.github.mikephil.charting.g.f)) return;
        com.github.mikephil.charting.g.f f2 = (com.github.mikephil.charting.g.f)this.M;
        if (f2.q.x == 0.0f && f2.q.y == 0.0f) {
            return;
        }
        long l2 = AnimationUtils.currentAnimationTimeMillis();
        PointF pointF = f2.q;
        float f3 = pointF.x;
        pointF.x = ((b)f2.e).a * f3;
        pointF = f2.q;
        f3 = pointF.y;
        pointF.y = ((b)f2.e).a * f3;
        f3 = (float)(l2 - f2.o) / 1000.0f;
        float f4 = f2.q.x;
        float f5 = f2.q.y;
        pointF = f2.p;
        pointF.x = f4 * f3 + pointF.x;
        pointF = f2.p;
        pointF.y = f3 * f5 + pointF.y;
        pointF = MotionEvent.obtain((long)l2, (long)l2, (int)2, (float)f2.p.x, (float)f2.p.y, (int)0);
        com.github.mikephil.charting.g.f.b(f2, (MotionEvent)pointF);
        pointF.recycle();
        f2.f = ((b)f2.e).Q.a(f2.f, (View)f2.e, false);
        f2.o = l2;
        if ((double)Math.abs(f2.q.x) >= 0.01 || (double)Math.abs(f2.q.y) >= 0.01) {
            h.a(f2.e);
            return;
        }
        ((b)f2.e).i();
        ((b)f2.e).postInvalidate();
        f2.q = new PointF(0.0f, 0.0f);
    }

    protected void f() {
        if (this.x) {
            new StringBuilder("Preparing Value-Px Matrix, xmin: ").append(this.H).append(", xmax: ").append(this.I).append(", xdelta: ").append(this.G);
        }
        this.u.a(this.H, this.G, this.p.q, this.p.p);
        this.t.a(this.H, this.G, this.o.q, this.o.p);
    }

    protected final void g() {
        this.u.a(this.p.h);
        this.t.a(this.o.h);
    }

    public c getAxisLeft() {
        return this.o;
    }

    public c getAxisRight() {
        return this.p;
    }

    public com.github.mikephil.charting.g.a getDrawListener() {
        return this.n;
    }

    @Override
    public int getHighestVisibleXIndex() {
        float[] arrf = new float[]{this.Q.g(), this.Q.h()};
        this.a(com.github.mikephil.charting.c.b.a).b(arrf);
        if (Math.round(arrf[0]) >= ((com.github.mikephil.charting.data.e)this.y).f()) {
            return ((com.github.mikephil.charting.data.e)this.y).f() - 1;
        }
        return Math.round(arrf[0]);
    }

    @Override
    public int getLowestVisibleXIndex() {
        float[] arrf = new float[]{this.Q.f(), this.Q.h()};
        this.a(com.github.mikephil.charting.c.b.a).b(arrf);
        if (arrf[0] <= 0.0f) {
            return 0;
        }
        return Math.round(arrf[0] + 1.0f);
    }

    @Override
    public int getMaxVisibleCount() {
        return this.a;
    }

    public float getMinOffset() {
        return this.m;
    }

    public com.github.mikephil.charting.h.a getRendererLeftYAxis() {
        return this.r;
    }

    public com.github.mikephil.charting.h.a getRendererRightYAxis() {
        return this.s;
    }

    public com.github.mikephil.charting.h.d getRendererXAxis() {
        return this.v;
    }

    public float getScaleX() {
        if (this.Q == null) {
            return 1.0f;
        }
        return this.Q.g;
    }

    public float getScaleY() {
        if (this.Q == null) {
            return 1.0f;
        }
        return this.Q.h;
    }

    public k getXAxis() {
        return this.q;
    }

    public float getYChartMax() {
        return Math.max(this.o.o, this.p.o);
    }

    public float getYChartMin() {
        return Math.min(this.o.p, this.p.p);
    }

    @Override
    public final void h() {
        if (this.F) {
            return;
        }
        if (this.O != null) {
            this.O.a();
        }
        this.b();
        this.r.a(this.o.p, this.o.o);
        this.s.a(this.p.p, this.p.o);
        this.v.a(((com.github.mikephil.charting.data.e)this.y).k, ((com.github.mikephil.charting.data.e)this.y).l);
        if (this.K != null) {
            this.N.a(this.y);
        }
        this.i();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public void i() {
        var4_1 = 0.0f;
        if (this.w) ** GOTO lbl65
        if (this.K == null || !this.K.D) ** GOTO lbl-1000
        if (this.K.f == f.a || this.K.f == f.b) {
            var2_2 = Math.min(this.K.o, this.Q.c * this.K.n) + this.K.E * 2.0f + 0.0f;
            var3_3 = 0.0f;
            var1_4 = 0.0f;
        } else if (this.K.f == f.d || this.K.f == f.e) {
            var1_4 = Math.min(this.K.o, this.Q.c * this.K.n);
            var3_3 = this.K.E;
            var2_2 = 0.0f;
            var3_3 = var1_4 + var3_3 * 2.0f + 0.0f;
            var1_4 = 0.0f;
        } else if (this.K.f == f.g || this.K.f == f.h || this.K.f == f.i) {
            var4_1 = Math.min(this.K.q + this.K.p, this.Q.d * this.K.n);
            var2_2 = 0.0f;
            var3_3 = 0.0f;
            var1_4 = 0.0f;
            var4_1 += 0.0f;
        } else if (this.K.f == f.j || this.K.f == f.k || this.K.f == f.l) {
            var1_4 = Math.min(this.K.q + this.K.p, this.Q.d * this.K.n) + 0.0f;
            var2_2 = 0.0f;
            var3_3 = 0.0f;
        } else lbl-1000: // 2 sources:
        {
            var1_4 = 0.0f;
            var2_2 = 0.0f;
            var3_3 = 0.0f;
        }
        var5_5 = var3_3;
        if (this.o.i()) {
            var5_5 = var3_3 + this.o.a(this.r.d);
        }
        var6_6 = var2_2;
        if (this.p.i()) {
            var6_6 = var2_2 + this.p.a(this.s.d);
        }
        var2_2 = var4_1;
        var3_3 = var1_4;
        if (this.q.D) {
            var2_2 = var4_1;
            var3_3 = var1_4;
            if (this.q.z) {
                var7_7 = (float)this.q.e + this.q.F;
                if (this.q.m == j.b) {
                    var2_2 = var4_1 + var7_7;
                    var3_3 = var1_4;
                } else if (this.q.m == j.a) {
                    var3_3 = var1_4 + var7_7;
                    var2_2 = var4_1;
                } else {
                    var2_2 = var4_1;
                    var3_3 = var1_4;
                    if (this.q.m == j.c) {
                        var2_2 = var4_1 + var7_7;
                        var3_3 = var1_4 + var7_7;
                    }
                }
            }
        }
        var1_4 = var3_3 + this.e;
        var3_3 = var6_6 + this.f;
        var4_1 = var5_5 + this.h;
        var5_5 = h.a(this.m);
        this.Q.a(Math.max(var5_5, var4_1), Math.max(var5_5, var1_4), Math.max(var5_5, var3_3), Math.max(var5_5, var2_2 += this.g));
        if (this.x) {
            new StringBuilder("offsetLeft: ").append(var4_1).append(", offsetTop: ").append(var1_4).append(", offsetRight: ").append(var3_3).append(", offsetBottom: ").append(var2_2);
            new StringBuilder("Content: ").append(this.Q.b.toString());
        }
lbl65: // 4 sources:
        this.g();
        this.f();
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void j() {
        if (this.q == null) return;
        if (!this.q.D) {
            return;
        }
        if (!this.q.i) {
            float[] arrf = new float[9];
            this.Q.a.getValues(arrf);
            k k2 = this.q;
            float f2 = ((com.github.mikephil.charting.data.e)this.y).f() * this.q.d;
            float f3 = this.Q.i();
            k2.h = (int)Math.ceil(f2 / (arrf[0] * f3));
        }
        if (this.x) {
            new StringBuilder("X-Axis modulus: ").append(this.q.h).append(", x-axis label width: ").append(this.q.b).append(", x-axis label rotated width: ").append(this.q.d).append(", content width: ").append(this.Q.i());
        }
        if (this.q.h > 0) return;
        this.q.h = 1;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected void onDraw(Canvas canvas) {
        int n2;
        super.onDraw(canvas);
        if (this.F) {
            return;
        }
        long l2 = System.currentTimeMillis();
        this.j();
        this.v.a(this, this.q.h);
        this.O.a(this, this.q.h);
        if (this.k) {
            canvas.drawRect(this.Q.b, this.i);
        }
        if (this.l) {
            canvas.drawRect(this.Q.b, this.j);
        }
        if (this.o.D) {
            this.r.a(this.o.p, this.o.o);
        }
        if (this.p.D) {
            this.s.a(this.p.p, this.p.o);
        }
        this.v.b(canvas);
        this.r.b(canvas);
        this.s.b(canvas);
        if (this.aa) {
            n2 = this.getLowestVisibleXIndex();
            int n3 = this.getHighestVisibleXIndex();
            if (this.ab == null || this.ab != n2 || this.ac == null || this.ac != n3) {
                this.b();
                this.i();
                this.ab = n2;
                this.ac = n3;
            }
        }
        n2 = canvas.save();
        canvas.clipRect(this.Q.b);
        this.v.c(canvas);
        this.r.c(canvas);
        this.s.c(canvas);
        if (this.q.C) {
            this.v.d(canvas);
        }
        if (this.o.C) {
            this.r.d(canvas);
        }
        if (this.p.C) {
            this.s.d(canvas);
        }
        this.O.a(canvas);
        if (!this.q.C) {
            this.v.d(canvas);
        }
        if (!this.o.C) {
            this.r.d(canvas);
        }
        if (!this.p.C) {
            this.s.d(canvas);
        }
        if (this.r()) {
            this.O.a(canvas, this.T);
        }
        canvas.restoreToCount(n2);
        this.O.c(canvas);
        this.v.a(canvas);
        this.r.a(canvas);
        this.s.a(canvas);
        this.O.b(canvas);
        this.N.a(canvas);
        this.b(canvas);
        this.a(canvas);
        if (!this.x) return;
        l2 = System.currentTimeMillis() - l2;
        this.ad += l2;
        ++this.ae;
        long l3 = this.ad / this.ae;
        new StringBuilder("Drawtime: ").append(l2).append(" ms, average: ").append(l3).append(" ms, cycles: ").append(this.ae);
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        if (this.M == null || this.F || !this.J) {
            return false;
        }
        return this.M.onTouch((View)this, motionEvent);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean p() {
        if (this.o.h || this.p.h) {
            return true;
        }
        return false;
    }

    public void setAutoScaleMinMaxEnabled(boolean bl2) {
        this.aa = bl2;
    }

    public void setBorderColor(int n2) {
        this.j.setColor(n2);
    }

    public void setBorderWidth(float f2) {
        this.j.setStrokeWidth(h.a(f2));
    }

    public void setDoubleTapToZoomEnabled(boolean bl2) {
        this.c = bl2;
    }

    public void setDragEnabled(boolean bl2) {
        this.e = bl2;
    }

    public void setDragOffsetX(float f2) {
        this.Q.i = h.a(f2);
    }

    public void setDragOffsetY(float f2) {
        this.Q.j = h.a(f2);
    }

    public void setDrawBorders(boolean bl2) {
        this.l = bl2;
    }

    public void setDrawGridBackground(boolean bl2) {
        this.k = bl2;
    }

    public void setGridBackgroundColor(int n2) {
        this.i.setColor(n2);
    }

    public void setHighlightPerDragEnabled(boolean bl2) {
        this.d = bl2;
    }

    public void setMaxVisibleValueCount(int n2) {
        this.a = n2;
    }

    public void setMinOffset(float f2) {
        this.m = f2;
    }

    public void setOnDrawListener(com.github.mikephil.charting.g.a a2) {
        this.n = a2;
    }

    public void setPinchZoom(boolean bl2) {
        this.b = bl2;
    }

    public void setRendererLeftYAxis(com.github.mikephil.charting.h.a a2) {
        this.r = a2;
    }

    public void setRendererRightYAxis(com.github.mikephil.charting.h.a a2) {
        this.s = a2;
    }

    public void setScaleEnabled(boolean bl2) {
        this.f = bl2;
        this.g = bl2;
    }

    public void setScaleXEnabled(boolean bl2) {
        this.f = bl2;
    }

    public void setScaleYEnabled(boolean bl2) {
        this.g = bl2;
    }

    public void setVisibleXRangeMaximum(float f2) {
        float f3 = this.G / f2;
        com.github.mikephil.charting.i.d d2 = this.Q;
        f2 = f3;
        if (f3 < 1.0f) {
            f2 = 1.0f;
        }
        d2.e = f2;
        com.github.mikephil.charting.i.d.a(d2, d2.a, d2.b);
    }

    public void setVisibleXRangeMinimum(float f2) {
        f2 = this.G / f2;
        com.github.mikephil.charting.i.d d2 = this.Q;
        d2.f = f2;
        com.github.mikephil.charting.i.d.a(d2, d2.a, d2.b);
    }

    public void setXAxisRenderer(com.github.mikephil.charting.h.d d2) {
        this.v = d2;
    }
}

