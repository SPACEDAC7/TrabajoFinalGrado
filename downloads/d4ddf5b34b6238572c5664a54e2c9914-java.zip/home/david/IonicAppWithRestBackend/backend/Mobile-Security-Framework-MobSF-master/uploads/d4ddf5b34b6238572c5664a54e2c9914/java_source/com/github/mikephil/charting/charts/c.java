/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 */
package com.github.mikephil.charting.charts;

import android.animation.ValueAnimator;
import com.github.mikephil.charting.charts.d;

final class c
implements ValueAnimator.AnimatorUpdateListener {
    final /* synthetic */ d a;

    c(d d2) {
        this.a = d2;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.a.postInvalidate();
    }
}

