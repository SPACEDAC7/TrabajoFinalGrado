/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.animation.ObjectAnimator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.PointF
 *  android.graphics.RectF
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewConfiguration
 *  android.view.ViewGroup
 *  android.view.ViewParent
 */
package com.github.mikephil.charting.charts;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.github.mikephil.charting.c.i;
import com.github.mikephil.charting.c.n;
import com.github.mikephil.charting.charts.c;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.e.b;
import com.github.mikephil.charting.g.e;
import com.github.mikephil.charting.h.f;
import com.github.mikephil.charting.h.g;
import com.github.mikephil.charting.i.h;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@SuppressLint(value={"NewApi"})
public abstract class d<T extends com.github.mikephil.charting.data.b<? extends com.github.mikephil.charting.data.d<? extends Entry>>>
extends ViewGroup
implements com.github.mikephil.charting.d.a {
    public boolean A = true;
    protected com.github.mikephil.charting.f.c B;
    protected Paint C;
    protected Paint D;
    protected String E = "Description";
    protected boolean F = true;
    protected float G = 1.0f;
    public float H = 0.0f;
    protected float I = 0.0f;
    public boolean J = true;
    public i K;
    protected com.github.mikephil.charting.g.b L;
    protected com.github.mikephil.charting.g.d M;
    protected f N;
    protected g O;
    protected b P;
    public com.github.mikephil.charting.i.d Q;
    public com.github.mikephil.charting.a.a R;
    protected Paint S;
    protected a[] T;
    protected boolean U = true;
    protected n V;
    protected ArrayList<Runnable> W = new ArrayList();
    public float a = 0.9f;
    private String b = "No chart data available.";
    public e c;
    private String d;
    public float e = 0.0f;
    public float f = 0.0f;
    public float g = 0.0f;
    public float h = 0.0f;
    private boolean i = false;
    private PointF j;
    public boolean x = false;
    public T y = null;
    public boolean z = true;

    public d(Context context) {
        super(context);
        this.a();
    }

    public d(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a();
    }

    public d(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        this.a();
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a() {
        this.setWillNotDraw(false);
        this.R = Build.VERSION.SDK_INT < 11 ? new com.github.mikephil.charting.a.a() : new com.github.mikephil.charting.a.a(new c(this));
        Context context = this.getContext();
        if (context == null) {
            h.b = ViewConfiguration.getMinimumFlingVelocity();
            h.c = ViewConfiguration.getMaximumFlingVelocity();
            Log.e((String)"MPChartLib-Utils", (String)"Utils.init(...) PROVIDED CONTEXT OBJECT IS NULL");
        } else {
            ViewConfiguration viewConfiguration = ViewConfiguration.get((Context)context);
            h.b = viewConfiguration.getScaledMinimumFlingVelocity();
            h.c = viewConfiguration.getScaledMaximumFlingVelocity();
            h.a = context.getResources().getDisplayMetrics();
        }
        this.B = new com.github.mikephil.charting.f.d(1);
        this.Q = new com.github.mikephil.charting.i.d();
        this.K = new i();
        this.N = new f(this.Q, this.K);
        this.C = new Paint(1);
        this.C.setColor(-16777216);
        this.C.setTextAlign(Paint.Align.RIGHT);
        this.C.setTextSize(h.a(9.0f));
        this.D = new Paint(1);
        this.D.setColor(Color.rgb((int)247, (int)189, (int)51));
        this.D.setTextAlign(Paint.Align.CENTER);
        this.D.setTextSize(h.a(12.0f));
        this.S = new Paint(4);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void a(Canvas canvas) {
        if (this.E.equals("")) return;
        if (this.j == null) {
            canvas.drawText(this.E, (float)this.getWidth() - this.Q.b() - 10.0f, (float)this.getHeight() - this.Q.d() - 10.0f, this.C);
            return;
        }
        canvas.drawText(this.E, this.j.x, this.j.y, this.C);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Deprecated
    public final void a(a a2) {
        if (a2 == null) {
            this.T = null;
        } else {
            Entry entry;
            if (this.x) {
                new StringBuilder("Highlighted: ").append(a2.toString());
            }
            this.T = (entry = this.y.a(a2)) == null || entry.e != a2.a ? null : new a[]{a2};
        }
        this.invalidate();
    }

    protected abstract float[] a(Entry var1, a var2);

    protected abstract void b();

    /*
     * Enabled aggressive block sorting
     */
    protected final void b(Canvas canvas) {
        if (this.V == null || !this.U || !this.r()) {
            return;
        }
        int n2 = 0;
        while (n2 < this.T.length) {
            Object object;
            float[] arrf = this.T[n2];
            int n3 = arrf.a;
            if ((float)n3 <= this.G && (float)n3 <= this.G * this.R.c && (object = this.y.a(this.T[n2])) != null && object.e == this.T[n2].a) {
                arrf = this.a((Entry)object, (a)arrf);
                object = this.Q;
                float f2 = arrf[0];
                float f3 = arrf[1];
                n3 = object.c(f2) && object.d(f3) ? 1 : 0;
                if (n3 != 0) {
                    this.V.measure(View.MeasureSpec.makeMeasureSpec((int)0, (int)0), View.MeasureSpec.makeMeasureSpec((int)0, (int)0));
                    this.V.layout(0, 0, this.V.getMeasuredWidth(), this.V.getMeasuredHeight());
                    if (arrf[1] - (float)this.V.getHeight() <= 0.0f) {
                        f2 = this.V.getHeight();
                        f3 = arrf[1];
                        this.V.a(canvas, arrf[0], f2 - f3 + arrf[1]);
                    } else {
                        this.V.a(canvas, arrf[0], arrf[1]);
                    }
                }
            }
            ++n2;
        }
    }

    public com.github.mikephil.charting.a.a getAnimator() {
        return this.R;
    }

    public PointF getCenter() {
        return new PointF((float)this.getWidth() / 2.0f, (float)this.getHeight() / 2.0f);
    }

    public PointF getCenterOfView() {
        return this.getCenter();
    }

    public PointF getCenterOffsets() {
        com.github.mikephil.charting.i.d d2 = this.Q;
        return new PointF(d2.b.centerX(), d2.b.centerY());
    }

    /*
     * Enabled aggressive block sorting
     */
    public Bitmap getChartBitmap() {
        Bitmap bitmap = Bitmap.createBitmap((int)this.getWidth(), (int)this.getHeight(), (Bitmap.Config)Bitmap.Config.RGB_565);
        Canvas canvas = new Canvas(bitmap);
        Drawable drawable = this.getBackground();
        if (drawable != null) {
            drawable.draw(canvas);
        } else {
            canvas.drawColor(-1);
        }
        this.draw(canvas);
        return bitmap;
    }

    public RectF getContentRect() {
        return this.Q.b;
    }

    public T getData() {
        return this.y;
    }

    public com.github.mikephil.charting.f.c getDefaultValueFormatter() {
        return this.B;
    }

    public float getDragDecelerationFrictionCoef() {
        return this.a;
    }

    public float getExtraBottomOffset() {
        return this.g;
    }

    public float getExtraLeftOffset() {
        return this.h;
    }

    public float getExtraRightOffset() {
        return this.f;
    }

    public float getExtraTopOffset() {
        return this.e;
    }

    public a[] getHighlighted() {
        return this.T;
    }

    public ArrayList<Runnable> getJobs() {
        return this.W;
    }

    public i getLegend() {
        return this.K;
    }

    public f getLegendRenderer() {
        return this.N;
    }

    public n getMarkerView() {
        return this.V;
    }

    public e getOnChartGestureListener() {
        return this.c;
    }

    public g getRenderer() {
        return this.O;
    }

    public int getValueCount() {
        return this.y.h;
    }

    public com.github.mikephil.charting.i.d getViewPortHandler() {
        return this.Q;
    }

    @Override
    public float getXChartMax() {
        return this.I;
    }

    public float getXChartMin() {
        return this.H;
    }

    public int getXValCount() {
        return this.y.f();
    }

    public float getYMax() {
        return this.y.a;
    }

    public float getYMin() {
        return this.y.b;
    }

    public abstract void h();

    protected abstract void i();

    /*
     * Enabled aggressive block sorting
     */
    protected void onDraw(Canvas canvas) {
        if (this.F || this.y == null || this.y.h <= 0) {
            canvas.drawText(this.b, (float)(this.getWidth() / 2), (float)(this.getHeight() / 2), this.D);
            if (TextUtils.isEmpty((CharSequence)this.d)) return;
            {
                float f2 = - this.D.ascent();
                float f3 = this.D.descent();
                canvas.drawText(this.d, (float)(this.getWidth() / 2), f2 + f3 + (float)(this.getHeight() / 2), this.D);
                return;
            }
        } else {
            if (this.i) return;
            {
                this.i();
                this.i = true;
                return;
            }
        }
    }

    protected void onLayout(boolean bl2, int n2, int n3, int n4, int n5) {
        for (int i2 = 0; i2 < this.getChildCount(); ++i2) {
            this.getChildAt(i2).layout(n2, n3, n4, n5);
        }
    }

    protected void onMeasure(int n2, int n3) {
        super.onMeasure(n2, n3);
        int n4 = (int)h.a(50.0f);
        this.setMeasuredDimension(Math.max(this.getSuggestedMinimumWidth(), d.resolveSize((int)n4, (int)n2)), Math.max(this.getSuggestedMinimumHeight(), d.resolveSize((int)n4, (int)n3)));
    }

    protected void onSizeChanged(int n2, int n3, int n4, int n5) {
        if (n2 > 0 && n3 > 0 && n2 < 10000 && n3 < 10000) {
            Object object = this.Q;
            float f2 = n2;
            float f3 = n3;
            float f4 = object.b.left;
            float f5 = object.b.top;
            float f6 = object.c;
            float f7 = object.b.right;
            float f8 = object.d;
            float f9 = object.b.bottom;
            object.d = f3;
            object.c = f2;
            object.a(f4, f5, f6 - f7, f8 - f9);
            if (this.x) {
                new StringBuilder("Setting chart dimens, width: ").append(n2).append(", height: ").append(n3);
            }
            object = this.W.iterator();
            while (object.hasNext()) {
                this.post((Runnable)object.next());
            }
            this.W.clear();
        }
        this.h();
        super.onSizeChanged(n2, n3, n4, n5);
    }

    public final boolean r() {
        if (this.T == null || this.T.length <= 0 || this.T[0] == null) {
            return false;
        }
        return true;
    }

    public final void s() {
        this.T = null;
        this.M.c = null;
        this.invalidate();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setData(T iterator) {
        if (iterator == null) {
            Log.e((String)"MPAndroidChart", (String)"Cannot set data for chart. Provided data object is null.");
            return;
        }
        this.F = false;
        this.i = false;
        this.y = iterator;
        float f2 = iterator.b;
        float f3 = iterator.a;
        f2 = this.y == null || this.y.f() < 2 ? Math.max(Math.abs(f2), Math.abs(f3)) : Math.abs(f3 - f2);
        this.B = new com.github.mikephil.charting.f.d((int)Math.ceil(- Math.log10(h.a((double)f2))) + 2);
        iterator = this.y.m.iterator();
        do {
            if (!iterator.hasNext()) {
                this.h();
                return;
            }
            com.github.mikephil.charting.data.d d2 = (com.github.mikephil.charting.data.d)iterator.next();
            boolean bl2 = true;
            if (d2.n != null && !(d2.n instanceof com.github.mikephil.charting.f.d)) {
                bl2 = false;
            }
            if (!bl2) continue;
            d2.a(this.B);
        } while (true);
    }

    public void setDescription(String string) {
        String string2 = string;
        if (string == null) {
            string2 = "";
        }
        this.E = string2;
    }

    public void setDescriptionColor(int n2) {
        this.C.setColor(n2);
    }

    public void setDescriptionTextSize(float f2) {
        float f3 = 16.0f;
        float f4 = 6.0f;
        if (f2 > 16.0f) {
            f2 = f3;
        }
        if (f2 < 6.0f) {
            f2 = f4;
        }
        this.C.setTextSize(h.a(f2));
    }

    public void setDescriptionTypeface(Typeface typeface) {
        this.C.setTypeface(typeface);
    }

    public void setDragDecelerationEnabled(boolean bl2) {
        this.A = bl2;
    }

    public void setDragDecelerationFrictionCoef(float f2) {
        float f3 = 0.0f;
        if (f2 < 0.0f) {
            f2 = f3;
        }
        f3 = f2;
        if (f2 >= 1.0f) {
            f3 = 0.999f;
        }
        this.a = f3;
    }

    public void setDrawMarkerViews(boolean bl2) {
        this.U = bl2;
    }

    public void setExtraBottomOffset(float f2) {
        this.g = h.a(f2);
    }

    public void setExtraLeftOffset(float f2) {
        this.h = h.a(f2);
    }

    public void setExtraRightOffset(float f2) {
        this.f = h.a(f2);
    }

    public void setExtraTopOffset(float f2) {
        this.e = h.a(f2);
    }

    public void setHardwareAccelerationEnabled(boolean bl2) {
        if (Build.VERSION.SDK_INT >= 11) {
            if (bl2) {
                this.setLayerType(2, null);
                return;
            }
            this.setLayerType(1, null);
            return;
        }
        Log.e((String)"MPAndroidChart", (String)"Cannot enable/disable hardware acceleration for devices below API level 11.");
    }

    public void setHighlightPerTapEnabled(boolean bl2) {
        this.z = bl2;
    }

    public void setLogEnabled(boolean bl2) {
        this.x = bl2;
    }

    public void setMarkerView(n n2) {
        this.V = n2;
    }

    public void setNoDataText(String string) {
        this.b = string;
    }

    public void setNoDataTextDescription(String string) {
        this.d = string;
    }

    public void setOnChartGestureListener(e e2) {
        this.c = e2;
    }

    public void setOnChartValueSelectedListener(com.github.mikephil.charting.g.b b2) {
        this.L = b2;
    }

    public void setOnTouchListener(com.github.mikephil.charting.g.d d2) {
        this.M = d2;
    }

    public void setRenderer(g g2) {
        if (g2 != null) {
            this.O = g2;
        }
    }

    public void setTouchEnabled(boolean bl2) {
        this.J = bl2;
    }

    public final void t() {
        com.github.mikephil.charting.a.a a2 = this.R;
        if (Build.VERSION.SDK_INT >= 11) {
            ObjectAnimator objectAnimator = ObjectAnimator.ofFloat((Object)a2, (String)"phaseY", (float[])new float[]{0.0f, 1.0f});
            objectAnimator.setDuration(750);
            objectAnimator.addUpdateListener(a2.a);
            objectAnimator.start();
        }
    }

    public final void v() {
        ViewParent viewParent = this.getParent();
        if (viewParent != null) {
            viewParent.requestDisallowInterceptTouchEvent(true);
        }
    }

    public final void w() {
        ViewParent viewParent = this.getParent();
        if (viewParent != null) {
            viewParent.requestDisallowInterceptTouchEvent(false);
        }
    }
}

