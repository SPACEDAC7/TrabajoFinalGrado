/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.PointF
 *  android.graphics.RectF
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.animation.AnimationUtils
 */
package com.github.mikephil.charting.charts;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AnimationUtils;
import com.github.mikephil.charting.c.i;
import com.github.mikephil.charting.c.k;
import com.github.mikephil.charting.charts.d;
import com.github.mikephil.charting.charts.f;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.b;
import com.github.mikephil.charting.g.h;
import java.util.List;

public abstract class e<T extends b<? extends com.github.mikephil.charting.data.d<? extends Entry>>>
extends d<T> {
    public float a = 270.0f;
    public float b = 270.0f;
    public boolean g = true;
    protected float h = 0.0f;

    public e(Context context) {
        super(context);
    }

    public e(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public e(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
    }

    private static PointF a(PointF pointF, float f2, float f3) {
        return new PointF((float)((double)pointF.x + (double)f2 * Math.cos(Math.toRadians(f3))), (float)((double)pointF.y + (double)f2 * Math.sin(Math.toRadians(f3))));
    }

    public final float a(float f2, float f3) {
        float f4;
        PointF pointF = this.getCenterOffsets();
        double d2 = f2 - pointF.x;
        double d3 = f3 - pointF.y;
        f3 = f4 = (float)Math.toDegrees(Math.acos(d3 / Math.sqrt(d2 * d2 + d3 * d3)));
        if (f2 > pointF.x) {
            f3 = 360.0f - f4;
        }
        f2 = f3 += 90.0f;
        if (f3 > 360.0f) {
            f2 = f3 - 360.0f;
        }
        return f2;
    }

    public abstract int a(float var1);

    @Override
    protected void a() {
        super.a();
        this.M = new h(this);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final float b(float f2, float f3) {
        PointF pointF = this.getCenterOffsets();
        f2 = f2 > pointF.x ? (f2 -= pointF.x) : pointF.x - f2;
        f3 = f3 > pointF.y ? (f3 -= pointF.y) : pointF.y - f3;
        double d2 = Math.pow(f2, 2.0);
        return (float)Math.sqrt(Math.pow(f3, 2.0) + d2);
    }

    @Override
    protected void b() {
        this.G = this.y.l.size() - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void computeScroll() {
        if (!(this.M instanceof h)) return;
        h h2 = (h)this.M;
        if (h2.j == 0.0f) {
            return;
        }
        long l2 = AnimationUtils.currentAnimationTimeMillis();
        float f2 = h2.j;
        h2.j = ((e)h2.e).a * f2;
        f2 = (float)(l2 - h2.i) / 1000.0f;
        ((e)h2.e).setRotationAngle(((e)h2.e).a + f2 * h2.j);
        h2.i = l2;
        if ((double)Math.abs(h2.j) >= 0.001) {
            com.github.mikephil.charting.i.h.a(h2.e);
            return;
        }
        h2.j = 0.0f;
    }

    public float getDiameter() {
        RectF rectF = this.Q.b;
        return Math.min(rectF.width(), rectF.height());
    }

    public float getMinOffset() {
        return this.h;
    }

    public abstract float getRadius();

    public float getRawRotationAngle() {
        return this.b;
    }

    protected abstract float getRequiredBaseOffset();

    protected abstract float getRequiredLegendOffset();

    public float getRotationAngle() {
        return this.a;
    }

    public float getYChartMax() {
        return 0.0f;
    }

    public float getYChartMin() {
        return 0.0f;
    }

    @Override
    public void h() {
        if (this.F) {
            return;
        }
        this.b();
        if (this.K != null) {
            this.N.a(this.y);
        }
        this.i();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void i() {
        k k2;
        float f2;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7 = 0.0f;
        float f8 = 0.0f;
        if (this.K != null && this.K.D) {
            f5 = Math.min(this.K.o, this.Q.c * this.K.n) + this.K.i + this.K.l;
            if (this.K.f == com.github.mikephil.charting.c.f.b) {
                f6 = f5 + com.github.mikephil.charting.i.h.a(13.0f);
                f7 = 0.0f;
                f5 = 0.0f;
            } else if (this.K.f == com.github.mikephil.charting.c.f.a) {
                f7 = com.github.mikephil.charting.i.h.a(8.0f) + f5;
                f5 = this.K.p;
                f6 = this.K.q;
                k2 = this.getCenter();
                PointF pointF = new PointF((float)this.getWidth() - f7 + 15.0f, f5 + f6 + 15.0f);
                f5 = this.b(pointF.x, pointF.y);
                PointF pointF2 = e.a((PointF)k2, this.getRadius(), this.a(pointF.x, pointF.y));
                f6 = this.b(pointF2.x, pointF2.y);
                f4 = com.github.mikephil.charting.i.h.a(5.0f);
                f5 = f5 < f6 ? f6 - f5 + f4 : 0.0f;
                f6 = f5;
                if (pointF.y >= k2.y) {
                    f6 = f5;
                    if ((float)this.getHeight() - f7 > (float)this.getWidth()) {
                        f6 = f7;
                    }
                }
                f7 = 0.0f;
                f5 = 0.0f;
            } else if (this.K.f == com.github.mikephil.charting.c.f.e) {
                f7 = com.github.mikephil.charting.i.h.a(13.0f);
                f6 = 0.0f;
                f7 = f5 + f7;
                f5 = 0.0f;
            } else if (this.K.f == com.github.mikephil.charting.c.f.d) {
                f7 = com.github.mikephil.charting.i.h.a(8.0f) + f5;
                f5 = this.K.p;
                f6 = this.K.q;
                k2 = this.getCenter();
                PointF pointF = new PointF(f7 - 15.0f, f5 + f6 + 15.0f);
                f5 = this.b(pointF.x, pointF.y);
                PointF pointF3 = e.a((PointF)k2, this.getRadius(), this.a(pointF.x, pointF.y));
                f6 = this.b(pointF3.x, pointF3.y);
                f4 = com.github.mikephil.charting.i.h.a(5.0f);
                f6 = f5 < f6 ? f6 - f5 + f4 : 0.0f;
                f5 = f6;
                if (pointF.y >= k2.y) {
                    f5 = f6;
                    if ((float)this.getHeight() - f7 > (float)this.getWidth()) {
                        f5 = f7;
                    }
                }
                f6 = 0.0f;
                f7 = f5;
                f5 = 0.0f;
            } else if (this.K.f == com.github.mikephil.charting.c.f.g || this.K.f == com.github.mikephil.charting.c.f.h || this.K.f == com.github.mikephil.charting.c.f.i) {
                f5 = Math.min(this.getRequiredLegendOffset() + this.K.p, this.Q.d * this.K.n);
                f6 = 0.0f;
                f7 = 0.0f;
            } else if (this.K.f == com.github.mikephil.charting.c.f.j || this.K.f == com.github.mikephil.charting.c.f.k || this.K.f == com.github.mikephil.charting.c.f.l) {
                f8 = Math.min(this.getRequiredLegendOffset() + this.K.p, this.Q.d * this.K.n);
                f6 = 0.0f;
                f7 = 0.0f;
                f5 = 0.0f;
            } else {
                f5 = 0.0f;
                f6 = 0.0f;
                f7 = 0.0f;
            }
            f3 = this.getRequiredBaseOffset();
            f2 = this.getRequiredBaseOffset();
            f4 = f8 + this.getRequiredBaseOffset();
            f8 = f7 + f3;
            f6 += f2;
            f7 = f4;
        } else {
            f5 = 0.0f;
            f6 = 0.0f;
            f8 = 0.0f;
        }
        f4 = com.github.mikephil.charting.i.h.a(this.h);
        if (this instanceof f) {
            k2 = ((f)this).m;
            if (k2.D && k2.z) {
                f4 = Math.max(f4, (float)k2.d);
            }
        }
        float f9 = this.e;
        f3 = this.f;
        f2 = this.g;
        f8 = Math.max(f4, f8 + this.h);
        f7 = Math.max(f4, f7 + f9);
        f6 = Math.max(f4, f6 + f3);
        f5 = Math.max(f4, Math.max(this.getRequiredBaseOffset(), f5 + f2));
        this.Q.a(f8, f7, f6, f5);
        if (this.x) {
            new StringBuilder("offsetLeft: ").append(f8).append(", offsetTop: ").append(f7).append(", offsetRight: ").append(f6).append(", offsetBottom: ").append(f5);
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.J && this.M != null) {
            return this.M.onTouch((View)this, motionEvent);
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setMinOffset(float f2) {
        this.h = f2;
    }

    public void setRotationAngle(float f2) {
        this.b = f2;
        this.a = com.github.mikephil.charting.i.h.c(this.b);
    }

    public void setRotationEnabled(boolean bl2) {
        this.g = bl2;
    }
}

