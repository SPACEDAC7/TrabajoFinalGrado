/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.PointF
 *  android.graphics.RectF
 */
package com.github.mikephil.charting.charts;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import com.github.mikephil.charting.c.b;
import com.github.mikephil.charting.c.c;
import com.github.mikephil.charting.c.i;
import com.github.mikephil.charting.c.k;
import com.github.mikephil.charting.charts.d;
import com.github.mikephil.charting.charts.e;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.h.g;
import com.github.mikephil.charting.h.h;
import com.github.mikephil.charting.h.n;
import java.util.List;

public final class f
extends e<com.github.mikephil.charting.data.n> {
    protected h a;
    protected com.github.mikephil.charting.h.i b;
    public float c;
    public float d;
    public int e;
    public int f;
    public int i;
    private boolean j;
    public int k;
    public c l;
    public k m;

    @Override
    public final int a(float f2) {
        f2 = com.github.mikephil.charting.i.h.c(f2 - this.a);
        float f3 = this.getSliceAngle();
        for (int i2 = 0; i2 < ((com.github.mikephil.charting.data.n)this.y).f(); ++i2) {
            if ((float)(i2 + 1) * f3 - f3 / 2.0f <= f2) continue;
            return i2;
        }
        return 0;
    }

    @Override
    protected final void a() {
        super.a();
        this.l = new c(b.a);
        this.m = new k();
        this.m.g = 0;
        this.c = com.github.mikephil.charting.i.h.a(1.5f);
        this.d = com.github.mikephil.charting.i.h.a(0.75f);
        this.O = new n(this, this.R, this.Q);
        this.a = new h(this.Q, this.l, this);
        this.b = new com.github.mikephil.charting.h.i(this.Q, this.m, this);
    }

    @Override
    protected final float[] a(Entry entry, a a2) {
        float f2 = this.getSliceAngle() * (float)entry.e + this.a;
        float f3 = entry.d * this.getFactor();
        entry = this.getCenterOffsets();
        float f4 = (float)((double)entry.x + (double)f3 * Math.cos(Math.toRadians(f2)));
        double d2 = entry.y;
        double d3 = f3;
        entry = new PointF(f4, (float)(Math.sin(Math.toRadians(f2)) * d3 + d2));
        return new float[]{entry.x, entry.y};
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void b() {
        c c2;
        float f2 = 0.0f;
        super.b();
        float f3 = ((com.github.mikephil.charting.data.n)this.y).a(b.a);
        float f4 = ((com.github.mikephil.charting.data.n)this.y).b(b.a);
        this.I = ((com.github.mikephil.charting.data.n)this.y).l.size() - 1;
        this.G = Math.abs(this.I - this.H);
        float f5 = this.l.i ? 0.0f : f3;
        f5 = Math.abs(f4 - f5);
        float f6 = f5 / 100.0f * this.l.m;
        f5 /= 100.0f;
        f5 = this.l.n * f5;
        this.I = ((com.github.mikephil.charting.data.n)this.y).l.size() - 1;
        this.G = Math.abs(this.I - this.H);
        if (this.l.i) {
            if (f3 < 0.0f && f4 < 0.0f) {
                c2 = this.l;
                f5 = !Float.isNaN(this.l.k) ? this.l.k : f3 - f5;
                c2.p = Math.min(0.0f, f5);
                c2 = this.l;
                f5 = f2;
            } else if ((double)f3 >= 0.0) {
                this.l.p = 0.0f;
                c2 = this.l;
                f5 = !Float.isNaN(this.l.l) ? this.l.l : f4 + f6;
                f5 = Math.max(0.0f, f5);
            } else {
                c2 = this.l;
                f5 = !Float.isNaN(this.l.k) ? this.l.k : f3 - f5;
                c2.p = Math.min(0.0f, f5);
                c2 = this.l;
                f5 = !Float.isNaN(this.l.l) ? this.l.l : f4 + f6;
                f5 = Math.max(0.0f, f5);
            }
        } else {
            c2 = this.l;
            f5 = !Float.isNaN(this.l.k) ? this.l.k : f3 - f5;
            c2.p = f5;
            c2 = this.l;
            f5 = !Float.isNaN(this.l.l) ? this.l.l : f4 + f6;
        }
        c2.o = f5;
        this.l.q = Math.abs(this.l.o - this.l.p);
    }

    public final float getFactor() {
        RectF rectF = this.Q.b;
        return Math.min(rectF.width() / 2.0f, rectF.height() / 2.0f) / this.l.q;
    }

    @Override
    public final float getRadius() {
        RectF rectF = this.Q.b;
        return Math.min(rectF.width() / 2.0f, rectF.height() / 2.0f);
    }

    @Override
    protected final float getRequiredBaseOffset() {
        if (this.m.D && this.m.z) {
            return this.m.d;
        }
        return com.github.mikephil.charting.i.h.a(10.0f);
    }

    @Override
    protected final float getRequiredLegendOffset() {
        return this.N.a.getTextSize() * 4.0f;
    }

    public final int getSkipWebLineCount() {
        return this.k;
    }

    public final float getSliceAngle() {
        return 360.0f / (float)((com.github.mikephil.charting.data.n)this.y).f();
    }

    public final int getWebAlpha() {
        return this.i;
    }

    public final int getWebColor() {
        return this.e;
    }

    public final int getWebColorInner() {
        return this.f;
    }

    public final float getWebLineWidth() {
        return this.c;
    }

    public final float getWebLineWidthInner() {
        return this.d;
    }

    public final k getXAxis() {
        return this.m;
    }

    public final c getYAxis() {
        return this.l;
    }

    @Override
    public final float getYChartMax() {
        return this.l.o;
    }

    @Override
    public final float getYChartMin() {
        return this.l.p;
    }

    public final float getYRange() {
        return this.l.q;
    }

    @Override
    public final void h() {
        if (this.F) {
            return;
        }
        this.b();
        this.a.a(this.l.p, this.l.o);
        this.b.a(((com.github.mikephil.charting.data.n)this.y).k, ((com.github.mikephil.charting.data.n)this.y).l);
        if (this.K != null && !this.K.e) {
            this.N.a(this.y);
        }
        this.i();
    }

    @Override
    protected final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.F) {
            return;
        }
        this.b.a(canvas);
        if (this.j) {
            this.O.c(canvas);
        }
        this.a.d(canvas);
        this.O.a(canvas);
        if (this.r()) {
            this.O.a(canvas, this.T);
        }
        this.a.a(canvas);
        this.O.b(canvas);
        this.N.a(canvas);
        this.a(canvas);
        this.b(canvas);
    }

    public final void setDrawWeb(boolean bl2) {
        this.j = bl2;
    }

    public final void setSkipWebLineCount(int n2) {
        this.k = Math.max(0, n2);
    }

    public final void setWebAlpha(int n2) {
        this.i = n2;
    }

    public final void setWebColor(int n2) {
        this.e = n2;
    }

    public final void setWebColorInner(int n2) {
        this.f = n2;
    }

    public final void setWebLineWidth(float f2) {
        this.c = com.github.mikephil.charting.i.h.a(f2);
    }

    public final void setWebLineWidthInner(float f2) {
        this.d = com.github.mikephil.charting.i.h.a(f2);
    }
}

