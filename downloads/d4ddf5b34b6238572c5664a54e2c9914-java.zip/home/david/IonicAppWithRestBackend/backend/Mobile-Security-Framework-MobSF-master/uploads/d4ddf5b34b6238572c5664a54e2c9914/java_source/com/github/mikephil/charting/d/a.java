/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.d;

public interface a {
    public float getXChartMax();
}

