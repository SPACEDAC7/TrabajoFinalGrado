/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.d;

import com.github.mikephil.charting.d.a;
import com.github.mikephil.charting.data.e;

public interface b
extends a {
    public com.github.mikephil.charting.i.a a(int var1);

    public boolean c(int var1);

    public e getData();

    public int getHighestVisibleXIndex();

    public int getLowestVisibleXIndex();

    public int getMaxVisibleCount();
}

