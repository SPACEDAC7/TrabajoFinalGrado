/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.d;

import com.github.mikephil.charting.d.b;
import com.github.mikephil.charting.data.g;

public interface c
extends b {
    public boolean c();

    public boolean d();

    public boolean e();

    public g getBarData();
}

