/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.data;

import com.github.mikephil.charting.data.Entry;

public class BarEntry
extends Entry {
    public float[] a;
    public float b;
    float c;

    public BarEntry(float f2, int n2) {
        super(f2, n2);
    }
}

