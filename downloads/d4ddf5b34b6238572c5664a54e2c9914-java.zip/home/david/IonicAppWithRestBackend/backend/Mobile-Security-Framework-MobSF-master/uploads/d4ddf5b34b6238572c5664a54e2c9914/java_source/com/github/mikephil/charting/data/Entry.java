/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.ParcelFormatException
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.github.mikephil.charting.data;

import android.os.Parcel;
import android.os.ParcelFormatException;
import android.os.Parcelable;
import com.github.mikephil.charting.data.a;

public class Entry
implements Parcelable {
    public static final Parcelable.Creator<Entry> CREATOR = new a();
    public float d = 0.0f;
    public int e = 0;
    public Object f = null;

    public Entry(float f2, int n2) {
        this.d = f2;
        this.e = n2;
    }

    protected Entry(Parcel parcel) {
        this.d = parcel.readFloat();
        this.e = parcel.readInt();
        if (parcel.readInt() == 1) {
            this.f = parcel.readParcelable(Object.class.getClassLoader());
        }
    }

    public float a() {
        return this.d;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "Entry, xIndex: " + this.e + " val (sum): " + this.d;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeFloat(this.d);
        parcel.writeInt(this.e);
        if (this.f != null) {
            if (this.f instanceof Parcelable) {
                parcel.writeInt(1);
                parcel.writeParcelable((Parcelable)this.f, n2);
                return;
            }
            throw new ParcelFormatException("Cannot parcel an Entry with non-parcelable data");
        }
        parcel.writeInt(0);
    }
}

