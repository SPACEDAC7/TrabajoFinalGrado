/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.github.mikephil.charting.data;

import android.os.Parcel;
import android.os.Parcelable;
import com.github.mikephil.charting.data.Entry;

final class a
implements Parcelable.Creator<Entry> {
    a() {
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return new Entry(parcel);
    }
}

