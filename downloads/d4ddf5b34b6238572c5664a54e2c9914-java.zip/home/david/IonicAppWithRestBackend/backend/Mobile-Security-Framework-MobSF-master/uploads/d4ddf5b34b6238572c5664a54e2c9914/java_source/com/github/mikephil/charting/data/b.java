/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.data;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.d;
import com.github.mikephil.charting.data.k;
import com.github.mikephil.charting.e.a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class b<T extends d<? extends Entry>> {
    public float a = 0.0f;
    public float b = 0.0f;
    protected float c = 0.0f;
    protected float d = 0.0f;
    protected float e = 0.0f;
    protected float f = 0.0f;
    public float g = 0.0f;
    public int h = 0;
    protected int i = 0;
    protected int j = 0;
    public float k = 0.0f;
    public List<String> l;
    public List<T> m;

    public b() {
        this.l = new ArrayList<String>();
        this.m = new ArrayList<T>();
    }

    /*
     * Enabled aggressive block sorting
     */
    public b(List<String> list, List<T> list2) {
        float f2;
        int n2;
        this.l = list;
        this.m = list2;
        this.i();
        this.a(this.i, this.j);
        this.g = 0.0f;
        if (this.m != null) {
            for (n2 = 0; n2 < this.m.size(); ++n2) {
                f2 = this.g;
                this.g = Math.abs(((d)this.m.get((int)n2)).e) + f2;
            }
        }
        this.h = 0;
        if (this.m != null) {
            int n3 = 0;
            for (n2 = 0; n2 < this.m.size(); n3 += ((d)this.m.get((int)n2)).a(), ++n2) {
            }
            this.h = n3;
        }
        if (this.l.size() <= 0) {
            this.k = 1.0f;
            return;
        }
        f2 = 1.0f;
        n2 = 0;
        do {
            if (n2 >= this.l.size()) {
                this.k = f2 / (float)this.l.size();
                return;
            }
            f2 += (float)this.l.get(n2).length();
            ++n2;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void i() {
        if (this.m == null || this instanceof k) {
            return;
        }
        int n2 = 0;
        while (n2 < this.m.size()) {
            if (((d)this.m.get((int)n2)).b.size() > this.l.size()) {
                throw new IllegalArgumentException("One or more of the DataSet Entry arrays are longer than the x-values array of this ChartData object.");
            }
            ++n2;
        }
    }

    public final float a(int n2) {
        if (n2 == com.github.mikephil.charting.c.b.a) {
            return this.d;
        }
        return this.f;
    }

    public final int a() {
        if (this.m == null) {
            return 0;
        }
        return this.m.size();
    }

    public final Entry a(a a2) {
        if (a2.b >= this.m.size()) {
            return null;
        }
        return ((d)this.m.get(a2.b)).b(a2.a);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2, int n3) {
        Iterator<T> iterator3;
        d d22;
        block14 : {
            block13 : {
                if (this.m == null || this.m.size() <= 0) {
                    this.a = 0.0f;
                    this.b = 0.0f;
                    return;
                }
                this.i = n2;
                this.j = n3;
                this.b = Float.MAX_VALUE;
                this.a = -3.4028235E38f;
                for (int i2 = 0; i2 < this.m.size(); ++i2) {
                    ((d)this.m.get(i2)).a(n2, n3);
                    if (((d)this.m.get((int)i2)).d < this.b) {
                        this.b = ((d)this.m.get((int)i2)).d;
                    }
                    if (((d)this.m.get((int)i2)).c <= this.a) continue;
                    this.a = ((d)this.m.get((int)i2)).c;
                }
                if (this.b == Float.MAX_VALUE) {
                    this.b = 0.0f;
                    this.a = 0.0f;
                }
                for (d d22 : this.m) {
                    if (d22.o != com.github.mikephil.charting.c.b.a) continue;
                    break block13;
                }
                d22 = null;
            }
            if (d22 != null) {
                this.c = d22.c;
                this.d = d22.d;
                for (Iterator<T> iterator2 : this.m) {
                    if (iterator2.o != com.github.mikephil.charting.c.b.a) continue;
                    if (iterator2.d < this.d) {
                        this.d = iterator2.d;
                    }
                    if (iterator2.c <= this.c) continue;
                    this.c = iterator2.c;
                }
            }
            for (Iterator<T> iterator3 : this.m) {
                if (iterator3.o != com.github.mikephil.charting.c.b.b) continue;
                break block14;
            }
            iterator3 = null;
        }
        if (iterator3 != null) {
            this.e = iterator3.c;
            this.f = iterator3.d;
            for (d d3 : this.m) {
                if (d3.o != com.github.mikephil.charting.c.b.b) continue;
                if (d3.d < this.f) {
                    this.f = d3.d;
                }
                if (d3.c <= this.e) continue;
                this.e = d3.c;
            }
        }
        if (d22 == null) {
            this.c = this.e;
            this.d = this.f;
            return;
        }
        this.e = this.c;
        this.f = this.d;
    }

    public final float b(int n2) {
        if (n2 == com.github.mikephil.charting.c.b.a) {
            return this.c;
        }
        return this.e;
    }

    public T c(int n2) {
        if (this.m == null || n2 < 0 || n2 >= this.m.size()) {
            return null;
        }
        return (T)((d)this.m.get(n2));
    }

    public final List<String> d() {
        return this.l;
    }

    public final List<T> e() {
        return this.m;
    }

    public final int f() {
        return this.l.size();
    }
}

