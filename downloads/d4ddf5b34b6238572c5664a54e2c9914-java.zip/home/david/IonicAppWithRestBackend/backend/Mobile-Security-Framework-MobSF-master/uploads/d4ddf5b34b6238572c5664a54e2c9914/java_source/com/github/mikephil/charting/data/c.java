/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.data;

public final class c
extends Enum<c> {
    public static final /* enum */ int a = 1;
    public static final /* enum */ int b = 2;
    public static final /* enum */ int c = 3;
    private static final /* synthetic */ int[] d;

    static {
        d = new int[]{a, b, c};
    }
}

