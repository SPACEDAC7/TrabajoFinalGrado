/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  android.graphics.Typeface
 */
package com.github.mikephil.charting.data;

import android.graphics.Color;
import android.graphics.Typeface;
import com.github.mikephil.charting.c.b;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.c;
import java.util.ArrayList;
import java.util.List;

public abstract class d<T extends Entry> {
    public List<Integer> a = null;
    public List<T> b = null;
    public float c = 0.0f;
    public float d = 0.0f;
    public float e = 0.0f;
    protected int f = 0;
    protected int g = 0;
    public String h = "DataSet";
    public boolean i = true;
    public boolean j = true;
    public int k = -16777216;
    public float l = 17.0f;
    public Typeface m;
    public transient com.github.mikephil.charting.f.c n;
    public int o = b.a;
    public boolean p = true;

    public d(List<T> object, String string) {
        this.h = string;
        this.b = object;
        if (this.b == null) {
            this.b = new ArrayList<T>();
        }
        this.a = new ArrayList<Integer>();
        this.a.add(Color.rgb((int)140, (int)234, (int)255));
        this.a(this.f, this.g);
        this.e = 0.0f;
        for (int i2 = 0; i2 < this.b.size(); ++i2) {
            object = (Entry)this.b.get(i2);
            if (object == null) continue;
            float f2 = this.e;
            this.e = Math.abs(object.d) + f2;
        }
    }

    public final float a(int n2) {
        T t2 = this.b(n2);
        if (t2 != null && t2.e == n2) {
            return t2.d;
        }
        return Float.NaN;
    }

    public final int a() {
        return this.b.size();
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void a(int n2, int n3) {
        int n4;
        block8 : {
            int n5 = this.b.size();
            if (n5 == 0) {
                return;
            }
            if (n3 != 0) {
                n4 = n3;
                if (n3 < n5) break block8;
            }
            n4 = n5 - 1;
        }
        this.f = n2;
        this.g = n4;
        this.d = Float.MAX_VALUE;
        this.c = -3.4028235E38f;
        do {
            if (n2 > n4) {
                if (this.d != Float.MAX_VALUE) return;
                this.d = 0.0f;
                this.c = 0.0f;
                return;
            }
            Entry entry = (Entry)this.b.get(n2);
            if (entry != null && !Float.isNaN(entry.d)) {
                if (entry.d < this.d) {
                    this.d = entry.d;
                }
                if (entry.d > this.c) {
                    this.c = entry.d;
                }
            }
            ++n2;
        } while (true);
    }

    public final void a(com.github.mikephil.charting.f.c c2) {
        if (c2 == null) {
            return;
        }
        this.n = c2;
    }

    public final void a(int[] arrn) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        int n2 = arrn.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add(arrn[i2]);
        }
        this.a = arrayList;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final T b(int var1_1) {
        block6 : {
            var5_2 = c.c;
            var3_3 = 0;
            var2_4 = this.b.size() - 1;
            var4_5 = -1;
            while (var3_3 <= var2_4) {
                var4_5 = (var2_4 + var3_3) / 2;
                if (var1_1 == ((Entry)this.b.get((int)var4_5)).e) {
                    for (var2_4 = var4_5; var2_4 > 0 && ((Entry)this.b.get((int)(var2_4 - 1))).e == var1_1; --var2_4) {
                    }
                    var1_1 = var2_4;
                    break block6;
                }
                if (var1_1 > ((Entry)this.b.get((int)var4_5)).e) {
                    var3_3 = var4_5 + 1;
                    continue;
                }
                var2_4 = var4_5 - 1;
            }
            if (var4_5 == -1) ** GOTO lbl-1000
            var2_4 = ((Entry)this.b.get((int)var4_5)).e;
            if (var5_2 != c.a) ** GOTO lbl23
            if (var2_4 >= var1_1 || var4_5 >= this.b.size() - 1) ** GOTO lbl-1000
            var1_1 = var4_5 + 1;
            ** GOTO lbl27
lbl23: // 1 sources:
            if (var5_2 == c.b && var2_4 > var1_1 && var4_5 > 0) {
                var1_1 = var4_5 - 1;
            } else lbl-1000: // 3 sources:
            {
                var1_1 = var4_5;
            }
        }
        if (var1_1 < 0) return null;
        return (T)((Entry)this.b.get(var1_1));
    }

    public final List<T> b() {
        return this.b;
    }

    public final int c(int n2) {
        return this.a.get(n2 % this.a.size());
    }

    public final int e() {
        return this.b.size();
    }

    public final int f() {
        return this.o;
    }

    public final boolean g() {
        return this.j;
    }

    public final List<Integer> h() {
        return this.a;
    }

    public final boolean j() {
        return this.p;
    }

    public final com.github.mikephil.charting.f.c k() {
        if (this.n == null) {
            return new com.github.mikephil.charting.f.d(1);
        }
        return this.n;
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        StringBuffer stringBuffer2 = new StringBuffer();
        StringBuilder stringBuilder = new StringBuilder("DataSet, label: ");
        String string = this.h == null ? "" : this.h;
        stringBuffer2.append(stringBuilder.append(string).append(", entries: ").append(this.b.size()).append("\n").toString());
        stringBuffer.append(stringBuffer2.toString());
        int n2 = 0;
        while (n2 < this.b.size()) {
            stringBuffer.append(((Entry)this.b.get(n2)).toString() + " ");
            ++n2;
        }
        return stringBuffer.toString();
    }
}

