/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.data;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.b;
import com.github.mikephil.charting.data.f;
import java.util.List;

public abstract class e<T extends f<? extends Entry>>
extends b<T> {
    public e() {
    }

    public e(List<String> list, List<T> list2) {
        super(list, list2);
    }
}

