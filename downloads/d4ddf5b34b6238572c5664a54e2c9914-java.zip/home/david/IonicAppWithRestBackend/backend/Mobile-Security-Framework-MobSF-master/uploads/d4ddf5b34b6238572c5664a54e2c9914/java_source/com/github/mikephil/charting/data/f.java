/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 */
package com.github.mikephil.charting.data;

import android.graphics.Color;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.d;
import java.util.List;

public abstract class f<T extends Entry>
extends d<T> {
    public int q = Color.rgb((int)255, (int)187, (int)115);

    public f(List<T> list, String string) {
        super(list, string);
    }
}

