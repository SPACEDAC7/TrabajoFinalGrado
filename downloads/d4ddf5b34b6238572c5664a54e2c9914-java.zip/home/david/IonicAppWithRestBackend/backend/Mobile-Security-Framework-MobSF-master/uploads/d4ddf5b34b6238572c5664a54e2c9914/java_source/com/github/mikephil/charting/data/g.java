/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.data;

import com.github.mikephil.charting.data.b;
import com.github.mikephil.charting.data.e;
import com.github.mikephil.charting.data.h;
import java.util.ArrayList;
import java.util.List;

public final class g
extends e<h> {
    private float n;

    public g() {
        this.n = 0.8f;
    }

    public g(List<String> list, h h2) {
        ArrayList<h> arrayList = new ArrayList<h>();
        arrayList.add(h2);
        super(list, arrayList);
        this.n = 0.8f;
    }

    public final float h() {
        if (this.m.size() <= 1) {
            return 0.0f;
        }
        return this.n;
    }

    public final boolean i() {
        if (this.m.size() > 1) {
            return true;
        }
        return false;
    }
}

