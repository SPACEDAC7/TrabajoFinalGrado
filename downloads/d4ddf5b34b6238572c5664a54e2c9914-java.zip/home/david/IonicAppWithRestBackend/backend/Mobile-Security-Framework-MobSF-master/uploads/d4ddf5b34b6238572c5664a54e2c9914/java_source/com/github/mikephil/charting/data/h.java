/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 */
package com.github.mikephil.charting.data;

import android.graphics.Color;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.d;
import com.github.mikephil.charting.data.f;
import java.util.List;

public final class h
extends f<BarEntry> {
    public float r;
    public int s;
    public int t;
    public int u;
    public boolean v;
    public String[] w;
    private int x;

    /*
     * Enabled aggressive block sorting
     */
    public h(List<BarEntry> list, String arrf) {
        int n2;
        int n3 = 0;
        super(list, (String)arrf);
        this.r = 0.15f;
        this.s = 1;
        this.t = Color.rgb((int)215, (int)215, (int)215);
        this.u = 120;
        this.x = 0;
        this.w = new String[]{"Stack"};
        this.q = Color.rgb((int)0, (int)0, (int)0);
        for (n2 = 0; n2 < list.size(); ++n2) {
            arrf = list.get((int)n2).a;
            if (arrf == null || arrf.length <= this.s) continue;
            this.s = arrf.length;
        }
        this.x = 0;
        n2 = n3;
        while (n2 < list.size()) {
            arrf = list.get((int)n2).a;
            if (arrf == null) {
                ++this.x;
            } else {
                n3 = this.x;
                this.x = arrf.length + n3;
            }
            ++n2;
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final void a(int n2, int n3) {
        int n4;
        block12 : {
            int n5 = this.b.size();
            if (n5 == 0) {
                return;
            }
            if (n3 != 0) {
                n4 = n3;
                if (n3 < n5) break block12;
            }
            n4 = n5 - 1;
        }
        this.f = n2;
        this.g = n4;
        this.d = Float.MAX_VALUE;
        this.c = -3.4028235E38f;
        do {
            if (n2 > n4) {
                if (this.d != Float.MAX_VALUE) return;
                this.d = 0.0f;
                this.c = 0.0f;
                return;
            }
            BarEntry barEntry = (BarEntry)this.b.get(n2);
            if (barEntry != null && !Float.isNaN(barEntry.d)) {
                if (barEntry.a == null) {
                    if (barEntry.d < this.d) {
                        this.d = barEntry.d;
                    }
                    if (barEntry.d > this.c) {
                        this.c = barEntry.d;
                    }
                } else {
                    if (- barEntry.b < this.d) {
                        this.d = - barEntry.b;
                    }
                    if (barEntry.c > this.c) {
                        this.c = barEntry.c;
                    }
                }
            }
            ++n2;
        } while (true);
    }
}

