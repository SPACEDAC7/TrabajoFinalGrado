/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.DashPathEffect
 */
package com.github.mikephil.charting.data;

import android.graphics.DashPathEffect;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.f;

public abstract class i<T extends Entry>
extends f<T> {
    public boolean r;
    public boolean s;
    public float t;
    public DashPathEffect u;
}

