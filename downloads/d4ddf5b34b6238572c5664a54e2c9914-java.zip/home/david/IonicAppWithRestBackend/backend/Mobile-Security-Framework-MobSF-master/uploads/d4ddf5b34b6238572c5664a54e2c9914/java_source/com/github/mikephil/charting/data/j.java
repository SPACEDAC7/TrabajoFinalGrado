/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.data;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.i;

public abstract class j<T extends Entry>
extends i<T> {
    public int v;
    public float w;
    public boolean x;
}

