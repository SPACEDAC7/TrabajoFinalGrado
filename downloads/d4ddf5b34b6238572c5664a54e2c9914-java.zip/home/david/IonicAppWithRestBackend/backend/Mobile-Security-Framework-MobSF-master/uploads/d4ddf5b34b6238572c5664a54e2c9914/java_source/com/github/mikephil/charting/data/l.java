/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.data;

import com.github.mikephil.charting.data.b;
import com.github.mikephil.charting.data.d;
import com.github.mikephil.charting.data.m;
import java.util.ArrayList;
import java.util.List;

public final class l
extends b<m> {
    public l() {
    }

    public l(List<String> list, m m2) {
        ArrayList<m> arrayList = new ArrayList<m>();
        arrayList.add(m2);
        super(list, arrayList);
    }

    @Override
    public final /* synthetic */ d c(int n2) {
        return this.d(n2);
    }

    public final m d(int n2) {
        if (n2 == 0) {
            return (m)this.m.get(0);
        }
        return null;
    }

    public final m h() {
        return (m)this.m.get(0);
    }
}

