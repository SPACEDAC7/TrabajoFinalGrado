/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.data;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.d;
import java.util.List;

public final class m
extends d<Entry> {
    public float q = 0.0f;
    public float r = 18.0f;

    public m(List<Entry> list, String string) {
        super(list, string);
    }
}

