/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.data;

import com.github.mikephil.charting.data.b;
import com.github.mikephil.charting.data.o;

public final class n
extends b<o> {
}

