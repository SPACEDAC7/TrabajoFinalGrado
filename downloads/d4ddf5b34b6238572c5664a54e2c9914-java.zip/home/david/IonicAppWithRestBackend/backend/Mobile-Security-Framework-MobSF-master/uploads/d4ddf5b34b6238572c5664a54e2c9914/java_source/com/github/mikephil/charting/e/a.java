/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.e;

import com.github.mikephil.charting.e.c;

public final class a {
    public int a;
    public int b;
    public int c = -1;
    public c d;

    public a(int n2, int n3) {
        this.a = n2;
        this.b = n3;
    }

    private a(int n2, int n3, int n4) {
        this(n2, n3);
        this.c = n4;
    }

    public a(int n2, int n3, int n4, c c2) {
        this(n2, n3, n4);
        this.d = c2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean a(a a2) {
        if (a2 == null || this.b != a2.b || this.a != a2.a || this.c != a2.c) {
            return false;
        }
        return true;
    }

    public final String toString() {
        return "Highlight, xIndex: " + this.a + ", dataSetIndex: " + this.b + ", stackIndex (only stacked barentry): " + this.c;
    }
}

