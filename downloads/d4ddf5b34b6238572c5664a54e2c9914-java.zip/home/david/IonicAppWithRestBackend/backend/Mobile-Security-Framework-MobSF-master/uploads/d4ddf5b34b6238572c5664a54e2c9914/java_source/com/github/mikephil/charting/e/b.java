/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.e;

import com.github.mikephil.charting.data.d;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.i.e;
import com.github.mikephil.charting.i.h;
import java.util.ArrayList;

public class b<T extends com.github.mikephil.charting.d.b> {
    protected T a;

    public b(T t2) {
        this.a = t2;
    }

    protected int a(float f2) {
        float[] arrf = new float[2];
        arrf[0] = f2;
        this.a.a(com.github.mikephil.charting.c.b.a).b(arrf);
        return Math.round(arrf[0]);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected int a(int n2, float f2, float f3) {
        ArrayList<e> arrayList = new ArrayList<e>();
        float[] arrf = new float[2];
        for (int i2 = 0; i2 < this.a.getData().a(); ++i2) {
            Object t2 = this.a.getData().c(i2);
            if (!t2.p || (f2 = t2.a(n2)) == Float.NaN) continue;
            arrf[1] = f2;
            this.a.a(t2.o).a(arrf);
            if (Float.isNaN(arrf[1])) continue;
            arrayList.add(new e(arrf[1], i2, t2));
        }
        if (h.b(arrayList, f3, com.github.mikephil.charting.c.b.a) < h.b(arrayList, f3, com.github.mikephil.charting.c.b.b)) {
            n2 = com.github.mikephil.charting.c.b.a;
            do {
                return h.a(arrayList, f3, n2);
                break;
            } while (true);
        }
        n2 = com.github.mikephil.charting.c.b.b;
        return h.a(arrayList, f3, n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public a a(float f2, float f3) {
        int n2;
        int n3 = this.a(f2);
        if (n3 == -2147483647 || (n2 = this.a(n3, f2, f3)) == -2147483647) {
            return null;
        }
        return new a(n3, n2);
    }
}

