/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.e;

public final class c {
    public float a;
    public float b;

    public c(float f2, float f3) {
        this.a = f2;
        this.b = f3;
    }
}

