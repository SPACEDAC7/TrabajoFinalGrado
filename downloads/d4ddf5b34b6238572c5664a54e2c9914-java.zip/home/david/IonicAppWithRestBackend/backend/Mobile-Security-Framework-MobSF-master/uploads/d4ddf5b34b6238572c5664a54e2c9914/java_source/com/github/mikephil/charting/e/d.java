/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.e;

import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.e;
import com.github.mikephil.charting.data.g;
import com.github.mikephil.charting.data.h;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.e.b;
import com.github.mikephil.charting.e.c;

public class d
extends b<com.github.mikephil.charting.d.c> {
    public d(com.github.mikephil.charting.d.c c2) {
        super(c2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected static a a(a var0, h var1_1, int var2_2, int var3_3, double var4_4) {
        var12_5 = 0;
        if ((var1_1 = (BarEntry)var1_1.b(var2_2)) == null) return var0;
        if (var1_1.a == null) {
            return var0;
        }
        var14_6 = var1_1.a;
        if (var14_6 != null && var14_6.length != 0) ** GOTO lbl9
        var0 = null;
        ** GOTO lbl-1000
lbl9: // 1 sources:
        var6_7 = - var1_1.b;
        var0 = new c[var14_6.length];
        var7_8 = 0.0f;
        var9_10 = 0;
        do {
            if (var9_10 >= var0.length) lbl-1000: // 2 sources:
            {
                var6_7 = (float)var4_4;
                var9_10 = var12_5;
                if (var0 == null) return new a(var2_2, var3_3, var9_10, var0[var9_10]);
                if (var0.length == 0) {
                    var9_10 = var12_5;
                    return new a(var2_2, var3_3, var9_10, var0[var9_10]);
                }
                break;
            }
            var8_9 = var14_6[var9_10];
            if (var8_9 < 0.0f) {
                var0[var9_10] = new c(var6_7, Math.abs(var8_9) + var6_7);
                var6_7 += Math.abs(var8_9);
            } else {
                var0[var9_10] = new c(var7_8, var7_8 + var8_9);
                var7_8 += var8_9;
            }
            ++var9_10;
        } while (true);
        var13_11 = var0.length;
        var10_12 = 0;
        var9_10 = 0;
        do {
            if (var10_12 >= var13_11) {
                var10_12 = Math.max(var0.length - 1, 0);
                var9_10 = var12_5;
                if (var6_7 <= var0[var10_12].b) return new a(var2_2, var3_3, var9_10, var0[var9_10]);
                var9_10 = var10_12;
                return new a(var2_2, var3_3, var9_10, var0[var9_10]);
            }
            var1_1 = var0[var10_12];
            if (var6_7 > var1_1.a && var6_7 <= var1_1.b) {
                return new a(var2_2, var3_3, var9_10, var0[var9_10]);
            }
            var11_13 = false;
            if (var11_13) {
                return new a(var2_2, var3_3, var9_10, var0[var9_10]);
            }
            ++var10_12;
            ++var9_10;
        } while (true);
    }

    @Override
    protected int a(float f2) {
        if (!((com.github.mikephil.charting.d.c)this.a).getBarData().i()) {
            return super.a(f2);
        }
        f2 = this.b(f2);
        int n2 = ((com.github.mikephil.charting.d.c)this.a).getBarData().a();
        n2 = (int)f2 / n2;
        int n3 = ((com.github.mikephil.charting.d.c)this.a).getData().f();
        if (n2 < 0) {
            return 0;
        }
        if (n2 >= n3) {
            return n3 - 1;
        }
        return n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected final int a(int n2, float f2, float f3) {
        int n3;
        if (!((com.github.mikephil.charting.d.c)this.a).getBarData().i()) {
            return 0;
        }
        int n4 = (int)(f2 = this.b(f2)) % (n3 = ((com.github.mikephil.charting.d.c)this.a).getBarData().a());
        if (n4 < 0) {
            return 0;
        }
        n2 = n4;
        if (n4 < n3) return n2;
        return n3 - 1;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public a a(float f2, float f3) {
        a a2 = super.a(f2, f3);
        if (a2 == null) {
            return a2;
        }
        h h2 = (h)((com.github.mikephil.charting.d.c)this.a).getBarData().c(a2.b);
        if (h2.s <= 1) return a2;
        boolean bl2 = true;
        if (!bl2) return a2;
        float[] arrf = new float[2];
        arrf[1] = f3;
        ((com.github.mikephil.charting.d.c)this.a).a(h2.o).b(arrf);
        return d.a(a2, h2, a2.a, a2.b, arrf[1]);
    }

    protected float b(float f2) {
        float[] arrf = new float[2];
        arrf[0] = f2;
        ((com.github.mikephil.charting.d.c)this.a).a(com.github.mikephil.charting.c.b.a).b(arrf);
        f2 = arrf[0];
        float f3 = ((com.github.mikephil.charting.d.c)this.a).getBarData().a();
        int n2 = (int)(f2 / (((com.github.mikephil.charting.d.c)this.a).getBarData().h() + f3));
        return f2 - ((com.github.mikephil.charting.d.c)this.a).getBarData().h() * (float)n2;
    }
}

