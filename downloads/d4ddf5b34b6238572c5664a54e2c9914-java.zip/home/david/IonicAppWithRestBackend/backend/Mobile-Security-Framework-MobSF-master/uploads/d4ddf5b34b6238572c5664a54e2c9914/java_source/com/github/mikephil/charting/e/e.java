/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.e;

import com.github.mikephil.charting.d.c;
import com.github.mikephil.charting.data.g;
import com.github.mikephil.charting.data.h;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.e.b;
import com.github.mikephil.charting.e.d;

public final class e
extends d {
    public e(c c2) {
        super(c2);
    }

    @Override
    protected final int a(float f2) {
        if (!((c)this.a).getBarData().i()) {
            float[] arrf = new float[2];
            arrf[1] = f2;
            ((c)this.a).a(com.github.mikephil.charting.c.b.a).b(arrf);
            return Math.round(arrf[1]);
        }
        f2 = this.b(f2);
        int n2 = ((c)this.a).getBarData().a();
        n2 = (int)f2 / n2;
        int n3 = ((c)this.a).getData().f();
        if (n2 < 0) {
            return 0;
        }
        if (n2 >= n3) {
            return n3 - 1;
        }
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final a a(float f2, float f3) {
        boolean bl2 = true;
        a a2 = super.a(f2, f3);
        if (a2 == null) {
            return a2;
        }
        h h2 = (h)((c)this.a).getBarData().c(a2.b);
        if (h2.s <= 1) return a2;
        if (!bl2) return a2;
        float[] arrf = new float[2];
        arrf[0] = f3;
        ((c)this.a).a(h2.o).b(arrf);
        return d.a(a2, h2, a2.a, a2.b, arrf[0]);
    }

    @Override
    protected final float b(float f2) {
        float[] arrf = new float[2];
        arrf[1] = f2;
        ((c)this.a).a(com.github.mikephil.charting.c.b.a).b(arrf);
        f2 = arrf[1];
        float f3 = ((c)this.a).getBarData().a();
        int n2 = (int)(f2 / (((c)this.a).getBarData().h() + f3));
        return f2 - ((c)this.a).getBarData().h() * (float)n2;
    }
}

