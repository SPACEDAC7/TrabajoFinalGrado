/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.f;

public interface a {
    public String a(float var1);
}

