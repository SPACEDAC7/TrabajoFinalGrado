/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.f;

public interface c {
    public String b(float var1);
}

