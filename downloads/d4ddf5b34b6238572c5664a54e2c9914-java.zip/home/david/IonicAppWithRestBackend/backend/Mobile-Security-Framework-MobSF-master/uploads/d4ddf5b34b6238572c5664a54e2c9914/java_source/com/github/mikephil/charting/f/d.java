/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.f;

import com.github.mikephil.charting.f.c;
import java.text.DecimalFormat;

public final class d
implements c {
    private DecimalFormat a;

    public d(int n2) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i2 = 0; i2 < n2; ++i2) {
            if (i2 == 0) {
                stringBuffer.append(".");
            }
            stringBuffer.append("0");
        }
        this.a = new DecimalFormat("###,###,###,##0" + stringBuffer.toString());
    }

    @Override
    public final String b(float f2) {
        return this.a.format(f2);
    }
}

