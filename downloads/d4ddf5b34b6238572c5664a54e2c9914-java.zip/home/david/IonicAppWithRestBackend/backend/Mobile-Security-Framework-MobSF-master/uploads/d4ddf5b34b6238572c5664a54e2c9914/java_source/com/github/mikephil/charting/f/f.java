/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.f;

import com.github.mikephil.charting.f.a;
import java.text.DecimalFormat;

public final class f
implements a {
    private DecimalFormat a;

    public f(int n2) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i2 = 0; i2 < n2; ++i2) {
            if (i2 == 0) {
                stringBuffer.append(".");
            }
            stringBuffer.append("0");
        }
        this.a = new DecimalFormat("###,###,###,##0" + stringBuffer.toString());
    }

    @Override
    public final String a(float f2) {
        return this.a.format(f2);
    }
}

