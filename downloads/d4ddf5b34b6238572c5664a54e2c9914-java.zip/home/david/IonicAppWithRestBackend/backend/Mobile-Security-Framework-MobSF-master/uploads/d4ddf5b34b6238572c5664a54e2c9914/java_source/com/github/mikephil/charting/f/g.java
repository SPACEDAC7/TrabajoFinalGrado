/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.f;

import com.github.mikephil.charting.f.a;
import com.github.mikephil.charting.f.c;
import java.text.DecimalFormat;

public final class g
implements a,
c {
    protected DecimalFormat a = new DecimalFormat("###,###,##0.0");

    @Override
    public final String a(float f2) {
        return this.a.format(f2) + " %";
    }

    @Override
    public final String b(float f2) {
        return this.a.format(f2) + " %";
    }
}

