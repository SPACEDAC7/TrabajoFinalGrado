/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.g;

public interface a {
}

