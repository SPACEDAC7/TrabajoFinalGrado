/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.g;

public final class c
extends Enum<c> {
    public static final /* enum */ int a = 1;
    public static final /* enum */ int b = 2;
    public static final /* enum */ int c = 3;
    public static final /* enum */ int d = 4;
    public static final /* enum */ int e = 5;
    public static final /* enum */ int f = 6;
    public static final /* enum */ int g = 7;
    public static final /* enum */ int h = 8;
    public static final /* enum */ int i = 9;
    public static final /* enum */ int j = 10;
    private static final /* synthetic */ int[] k;

    static {
        k = new int[]{a, b, c, d, e, f, g, h, i, j};
    }
}

