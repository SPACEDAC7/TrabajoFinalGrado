/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.GestureDetector
 *  android.view.GestureDetector$OnGestureListener
 *  android.view.GestureDetector$SimpleOnGestureListener
 *  android.view.View
 *  android.view.View$OnTouchListener
 */
package com.github.mikephil.charting.g;

import android.content.Context;
import android.view.GestureDetector;
import android.view.View;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.g.c;
import com.github.mikephil.charting.g.e;

public abstract class d<T extends com.github.mikephil.charting.charts.d<?>>
extends GestureDetector.SimpleOnGestureListener
implements View.OnTouchListener {
    protected int a = c.a;
    protected int b = 0;
    public a c;
    protected GestureDetector d;
    public T e;

    public d(T t2) {
        this.e = t2;
        this.d = new GestureDetector(t2.getContext(), (GestureDetector.OnGestureListener)this);
    }

    protected static float a(float f2, float f3, float f4, float f5) {
        f3 = f4 - f5;
        return (float)Math.sqrt(f2 * (f2 -= f3) + f3 * f3);
    }

    public final void a() {
        e e2 = this.e.c;
    }

    public final void b() {
        e e2 = this.e.c;
    }

    protected final void b(a a2) {
        if (a2 == null || a2.a(this.c)) {
            this.e.a((a)null);
            this.c = null;
            return;
        }
        this.c = a2;
        this.e.a(a2);
    }
}

