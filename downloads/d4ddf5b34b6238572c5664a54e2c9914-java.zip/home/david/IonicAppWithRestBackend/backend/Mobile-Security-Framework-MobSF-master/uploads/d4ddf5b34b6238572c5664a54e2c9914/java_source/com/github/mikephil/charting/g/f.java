/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.graphics.Matrix
 *  android.graphics.PointF
 *  android.view.GestureDetector
 *  android.view.MotionEvent
 *  android.view.VelocityTracker
 *  android.view.View
 *  android.view.animation.AnimationUtils
 */
package com.github.mikephil.charting.g;

import android.annotation.SuppressLint;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.animation.AnimationUtils;
import com.github.mikephil.charting.charts.HorizontalBarChart;
import com.github.mikephil.charting.charts.b;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.g.c;
import com.github.mikephil.charting.g.d;
import com.github.mikephil.charting.g.e;
import com.github.mikephil.charting.i.h;

public final class f
extends d<b<? extends com.github.mikephil.charting.data.e<? extends com.github.mikephil.charting.data.f<? extends Entry>>>> {
    public Matrix f = new Matrix();
    private Matrix g = new Matrix();
    private PointF h = new PointF();
    private PointF i = new PointF();
    private float j = 1.0f;
    private float k = 1.0f;
    private float l = 1.0f;
    private com.github.mikephil.charting.data.d<?> m;
    private VelocityTracker n;
    public long o = 0;
    public PointF p = new PointF();
    public PointF q = new PointF();

    public f(b<? extends com.github.mikephil.charting.data.e<? extends com.github.mikephil.charting.data.f<? extends Entry>>> b2, Matrix matrix) {
        super(b2);
        this.f = matrix;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private PointF a(float f2, float f3) {
        com.github.mikephil.charting.i.d d2 = ((b)this.e).Q;
        float f4 = d2.a();
        if (((b)this.e).p() && this.m != null && ((b)this.e).c(this.m.o)) {
            f3 = - f3 - d2.c();
            do {
                return new PointF(f2 - f4, f3);
                break;
            } while (true);
        }
        f3 = - (float)((b)this.e).getMeasuredHeight() - f3 - d2.d();
        return new PointF(f2 - f4, f3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(MotionEvent object) {
        this.g.set(this.f);
        this.h.set(object.getX(), object.getY());
        b b2 = (b)this.e;
        object = b2.a(object.getX(), object.getY());
        object = object != null ? (com.github.mikephil.charting.data.f)((com.github.mikephil.charting.data.e)b2.y).c(object.b) : null;
        this.m = object;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void b(f f2, MotionEvent motionEvent) {
        float f3;
        float f4;
        f2.a = c.b;
        f2.f.set(f2.g);
        e e2 = ((b)f2.e).c;
        if (((b)f2.e).p() && f2.m != null && ((b)f2.e).b((int)f2.m.o).h) {
            if (f2.e instanceof HorizontalBarChart) {
                f4 = - motionEvent.getX() - f2.h.x;
                f3 = motionEvent.getY() - f2.h.y;
            } else {
                f4 = motionEvent.getX() - f2.h.x;
                f3 = - motionEvent.getY() - f2.h.y;
            }
        } else {
            f4 = motionEvent.getX() - f2.h.x;
            f3 = motionEvent.getY() - f2.h.y;
        }
        f2.f.postTranslate(f4, f3);
    }

    private static float c(MotionEvent motionEvent) {
        float f2 = motionEvent.getX(0) - motionEvent.getX(1);
        float f3 = motionEvent.getY(0) - motionEvent.getY(1);
        return (float)Math.sqrt(f2 * f2 + f3 * f3);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean onDoubleTap(MotionEvent motionEvent) {
        float f2 = 1.4f;
        this.a = c.h;
        if (((b)this.e).c != null) {
            return super.onDoubleTap(motionEvent);
        }
        if (((b)this.e).c) {
            PointF pointF = this.a(motionEvent.getX(), motionEvent.getY());
            b b2 = (b)this.e;
            float f3 = ((b)this.e).f ? 1.4f : 1.0f;
            if (!((b)this.e).g) {
                f2 = 1.0f;
            }
            float f4 = pointF.x;
            float f5 = pointF.y;
            com.github.mikephil.charting.i.d d2 = b2.Q;
            f5 = - f5;
            Matrix matrix = new Matrix();
            matrix.set(d2.a);
            matrix.postScale(f3, f2, f4, f5);
            b2.Q.a(matrix, (View)b2, true);
            b2.i();
            b2.postInvalidate();
            if (((b)this.e).x) {
                new StringBuilder("Double-Tap, Zooming In, x: ").append(pointF.x).append(", y: ").append(pointF.y);
            }
        }
        return super.onDoubleTap(motionEvent);
    }

    public final boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3) {
        this.a = c.j;
        e e2 = ((b)this.e).c;
        return super.onFling(motionEvent, motionEvent2, f2, f3);
    }

    public final void onLongPress(MotionEvent object) {
        this.a = c.i;
        object = ((b)this.e).c;
    }

    public final boolean onSingleTapUp(MotionEvent motionEvent) {
        this.a = c.g;
        e e2 = ((b)this.e).c;
        if (!((b)this.e).z) {
            return false;
        }
        this.b(((b)this.e).a(motionEvent.getX(), motionEvent.getY()));
        return super.onSingleTapUp(motionEvent);
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @SuppressLint(value={"ClickableViewAccessibility"})
    public final boolean onTouch(View var1_1, MotionEvent var2_2) {
        block29 : {
            var9_3 = 0;
            var8_4 = 0;
            if (this.n == null) {
                this.n = VelocityTracker.obtain();
            }
            this.n.addMovement((MotionEvent)var2_2);
            if (var2_2.getActionMasked() == 3 && this.n != null) {
                this.n.recycle();
                this.n = null;
            }
            if (this.b == 0) {
                this.d.onTouchEvent((MotionEvent)var2_2);
            }
            if (!(((b)this.e).e || ((b)this.e).f || ((b)this.e).g)) {
                return true;
            }
            switch (var2_2.getAction() & 255) lbl-1000: // 21 sources:
            {
                do {
                    default: {
                        do {
                            this.f = ((b)this.e).Q.a(this.f, (View)this.e, true);
                            return true;
                            break;
                        } while (true);
                    }
                    break;
                } while (true);
                case 0: {
                    this.a();
                    this.q = new PointF(0.0f, 0.0f);
                    this.a((MotionEvent)var2_2);
                    ** GOTO lbl-1000
                }
                case 5: {
                    if (var2_2.getPointerCount() < 2) ** GOTO lbl-1000
                    ((b)this.e).v();
                    this.a((MotionEvent)var2_2);
                    this.j = Math.abs(var2_2.getX(0) - var2_2.getX(1));
                    this.k = Math.abs(var2_2.getY(0) - var2_2.getY(1));
                    this.l = f.c((MotionEvent)var2_2);
                    if (this.l <= 10.0f) ** GOTO lbl34
                    if (!((b)this.e).b) ** GOTO lbl42
                    this.b = 4;
lbl34: // 4 sources:
                    do {
                        var1_1 = this.i;
                        var3_5 = var2_2.getX(0);
                        var4_9 = var2_2.getX(1);
                        var5_13 = var2_2.getY(0);
                        var6_15 = var2_2.getY(1);
                        var1_1.set((var3_5 + var4_9) / 2.0f, (var5_13 + var6_15) / 2.0f);
                        ** GOTO lbl-1000
                        break;
                    } while (true);
lbl42: // 1 sources:
                    if (this.j <= this.k) ** GOTO lbl45
                    this.b = 2;
                    ** GOTO lbl34
lbl45: // 1 sources:
                    this.b = 3;
                    ** continue;
                }
                case 2: {
                    if (this.b != 1) ** GOTO lbl52
                    ((b)this.e).v();
                    f.b(this, (MotionEvent)var2_2);
                    ** GOTO lbl-1000
lbl52: // 1 sources:
                    if (this.b != 2 && this.b != 3 && this.b != 4) ** GOTO lbl119
                    ((b)this.e).v();
                    if (!((b)this.e).f && !((b)this.e).g || var2_2.getPointerCount() < 2) ** GOTO lbl-1000
                    var1_1 = ((b)this.e).c;
                    var3_6 = f.c((MotionEvent)var2_2);
                    if (var3_6 <= 10.0f) ** GOTO lbl-1000
                    var1_1 = this.a(this.i.x, this.i.y);
                    if (this.b != 4) ** GOTO lbl90
                    this.a = c.e;
                    if ((var3_6 /= this.l) >= 1.0f) ** GOTO lbl79
                    var7_16 = 1;
lbl63: // 2 sources:
                    while (var7_16 != 0) {
                        var2_2 = ((b)this.e).Q;
                        var7_16 = var8_4;
                        if (var2_2.g > var2_2.e) {
                            var7_16 = 1;
                        }
lbl68: // 5 sources:
                        while (((b)this.e).f) {
                            var4_10 = var3_6;
lbl70: // 2 sources:
                            while (((b)this.e).g) lbl-1000: // 2 sources:
                            {
                                do {
                                    if (!((b)this.e).g && var7_16 == 0) ** GOTO lbl-1000
                                    this.f.set(this.g);
                                    this.f.postScale(var4_10, var3_6, var1_1.x, var1_1.y);
                                    ** GOTO lbl-1000
                                    break;
                                } while (true);
                            }
                            ** GOTO lbl88
                        }
                        ** GOTO lbl86
                    }
                    ** GOTO lbl81
lbl79: // 1 sources:
                    var7_16 = 0;
                    ** GOTO lbl63
lbl81: // 1 sources:
                    var2_2 = ((b)this.e).Q;
                    var7_16 = var8_4;
                    if (var2_2.g >= var2_2.f) ** GOTO lbl68
                    var7_16 = 1;
                    ** GOTO lbl68
lbl86: // 1 sources:
                    var4_10 = 1.0f;
                    ** GOTO lbl70
lbl88: // 1 sources:
                    var3_6 = 1.0f;
                    ** continue;
lbl90: // 1 sources:
                    if (this.b != 2 || !((b)this.e).f) ** GOTO lbl113
                    this.a = c.c;
                    var3_6 = Math.abs(var2_2.getX(0) - var2_2.getX(1)) / this.j;
                    if (var3_6 >= 1.0f) ** GOTO lbl106
                    var7_17 = 1;
lbl95: // 2 sources:
                    while (var7_17 != 0) {
                        var2_2 = ((b)this.e).Q;
                        var7_17 = var9_3;
                        if (var2_2.g > var2_2.e) {
                            var7_17 = 1;
                        }
lbl100: // 5 sources:
                        do {
                            if (var7_17 == 0) ** GOTO lbl-1000
                            this.f.set(this.g);
                            this.f.postScale(var3_6, 1.0f, var1_1.x, var1_1.y);
                            ** GOTO lbl-1000
                            break;
                        } while (true);
                    }
                    ** GOTO lbl108
lbl106: // 1 sources:
                    var7_17 = 0;
                    ** GOTO lbl95
lbl108: // 1 sources:
                    var2_2 = ((b)this.e).Q;
                    var7_17 = var9_3;
                    if (var2_2.g >= var2_2.f) ** GOTO lbl100
                    var7_17 = 1;
                    ** continue;
lbl113: // 1 sources:
                    if (this.b != 3 || !((b)this.e).g) ** GOTO lbl-1000
                    this.a = c.d;
                    var3_6 = Math.abs(var2_2.getY(0) - var2_2.getY(1)) / this.k;
                    this.f.set(this.g);
                    this.f.postScale(1.0f, var3_6, var1_1.x, var1_1.y);
                    ** GOTO lbl-1000
lbl119: // 1 sources:
                    if (this.b != 0 || Math.abs(d.a(var2_2.getX(), this.h.x, var2_2.getY(), this.h.y)) <= 5.0f) ** GOTO lbl-1000
                    var1_1 = ((b)this.e).Q;
                    if (var1_1.i > 0.0f || var1_1.j > 0.0f) break;
                    var7_18 = true;
lbl123: // 2 sources:
                    do {
                        if (!var7_18) ** GOTO lbl137
                        var1_1 = ((b)this.e).Q;
                        if (!var1_1.q() || !var1_1.p()) break block29;
                        var7_18 = true;
lbl128: // 2 sources:
                        do {
                            if (var7_18 || !((b)this.e).e) ** GOTO lbl132
                            this.b = 1;
                            ** GOTO lbl-1000
lbl132: // 1 sources:
                            this.a = c.b;
                            if (!((b)this.e).d || (var1_1 = ((b)this.e).a(var2_2.getX(), var2_2.getY())) == null || var1_1.a(this.c)) ** GOTO lbl-1000
                            this.c = var1_1;
                            ((b)this.e).a((a)var1_1);
                            ** GOTO lbl-1000
                            break;
                        } while (true);
lbl137: // 1 sources:
                        if (!((b)this.e).e) ** continue;
                        this.a = c.b;
                        this.b = 1;
                        ** GOTO lbl-1000
                        break;
                    } while (true);
                }
                case 1: {
                    var1_1 = this.n;
                    var7_19 = var2_2.getPointerId(0);
                    var1_1.computeCurrentVelocity(1000, (float)h.c);
                    var3_7 = var1_1.getYVelocity(var7_19);
                    var4_11 = var1_1.getXVelocity(var7_19);
                    if ((Math.abs(var4_11) > (float)h.b || Math.abs(var3_7) > (float)h.b) && this.b == 1 && ((b)this.e).A) {
                        this.q = new PointF(0.0f, 0.0f);
                        this.o = AnimationUtils.currentAnimationTimeMillis();
                        this.p = new PointF(var2_2.getX(), var2_2.getY());
                        this.q = new PointF(var4_11, var3_7);
                        h.a(this.e);
                    }
                    if (this.b == 2 || this.b == 3 || this.b == 4 || this.b == 5) {
                        ((b)this.e).i();
                        ((b)this.e).postInvalidate();
                    }
                    this.b = 0;
                    ((b)this.e).w();
                    if (this.n != null) {
                        this.n.recycle();
                        this.n = null;
                    }
                    this.b();
                    ** GOTO lbl-1000
                }
                case 6: {
                    var1_1 = this.n;
                    var1_1.computeCurrentVelocity(1000, (float)h.c);
                    var8_4 = var2_2.getActionIndex();
                    var7_20 = var2_2.getPointerId(var8_4);
                    var3_8 = var1_1.getXVelocity(var7_20);
                    var4_12 = var1_1.getYVelocity(var7_20);
                    var7_20 = 0;
                    var9_3 = var2_2.getPointerCount();
lbl172: // 2 sources:
                    if (var7_20 >= var9_3) ** GOTO lbl178
                    if (var7_20 == var8_4) ** GOTO lbl189
                    var10_21 = var2_2.getPointerId(var7_20);
                    var5_14 = var1_1.getXVelocity(var10_21);
                    if (var1_1.getYVelocity(var10_21) * var4_12 + var5_14 * var3_8 >= 0.0f) ** GOTO lbl189
                    var1_1.clear();
lbl178: // 2 sources:
                    this.b = 5;
                    ** GOTO lbl-1000
                }
                case 3: {
                    this.b = 0;
                    this.b();
                    ** continue;
                }
            }
            var7_18 = false;
            ** while (true)
        }
        var7_18 = false;
        ** while (true)
lbl189: // 2 sources:
        ++var7_20;
        ** GOTO lbl172
    }
}

