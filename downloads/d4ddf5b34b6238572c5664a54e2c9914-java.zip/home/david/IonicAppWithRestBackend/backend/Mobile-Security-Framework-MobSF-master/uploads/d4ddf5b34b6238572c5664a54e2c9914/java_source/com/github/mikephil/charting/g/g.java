/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.g;

import com.github.mikephil.charting.g.h;

final class g {
    public long a;
    public float b;
    final /* synthetic */ h c;

    public g(h h2, long l2, float f2) {
        this.c = h2;
        this.a = l2;
        this.b = f2;
    }
}

