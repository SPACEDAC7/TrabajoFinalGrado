/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.graphics.PointF
 *  android.view.GestureDetector
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.animation.AnimationUtils
 */
package com.github.mikephil.charting.g;

import android.annotation.SuppressLint;
import android.graphics.PointF;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AnimationUtils;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.charts.f;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.g.c;
import com.github.mikephil.charting.g.d;
import com.github.mikephil.charting.g.e;
import com.github.mikephil.charting.g.g;
import java.util.ArrayList;

public final class h
extends d<com.github.mikephil.charting.charts.e<?>> {
    private PointF f = new PointF();
    private float g = 0.0f;
    private ArrayList<g> h = new ArrayList();
    public long i = 0;
    public float j = 0.0f;

    public h(com.github.mikephil.charting.charts.e<?> e2) {
        super(e2);
    }

    private void a(float f2, float f3) {
        long l2 = AnimationUtils.currentAnimationTimeMillis();
        this.h.add(new g(this, l2, ((com.github.mikephil.charting.charts.e)this.e).a(f2, f3)));
        int n2 = this.h.size();
        while (n2 - 2 > 0 && l2 - this.h.get((int)0).a > 1000) {
            this.h.remove(0);
            --n2;
        }
    }

    public final void onLongPress(MotionEvent object) {
        this.a = c.i;
        object = ((com.github.mikephil.charting.charts.e)this.e).c;
    }

    public final boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean onSingleTapUp(MotionEvent object) {
        float f2;
        int n2;
        int n3;
        int n4 = 0;
        this.a = c.g;
        Object object2 = ((com.github.mikephil.charting.charts.e)this.e).c;
        if (!((com.github.mikephil.charting.charts.e)this.e).z) {
            return false;
        }
        float f3 = ((com.github.mikephil.charting.charts.e)this.e).b(object.getX(), object.getY());
        if (f3 > ((com.github.mikephil.charting.charts.e)this.e).getRadius()) {
            if (this.c == null) {
                ((com.github.mikephil.charting.charts.e)this.e).s();
            } else {
                ((com.github.mikephil.charting.charts.e)this.e).a((a)null);
            }
            this.c = null;
            return true;
        }
        float f4 = f2 = ((com.github.mikephil.charting.charts.e)this.e).a(object.getX(), object.getY());
        if (this.e instanceof PieChart) {
            f4 = f2 / ((com.github.mikephil.charting.charts.e)this.e).R.b;
        }
        if ((n3 = ((com.github.mikephil.charting.charts.e)this.e).a(f4)) < 0) {
            ((com.github.mikephil.charting.charts.e)this.e).s();
            this.c = null;
            return true;
        }
        object = (com.github.mikephil.charting.charts.e)this.e;
        object2 = new ArrayList();
        for (n2 = 0; n2 < object.y.a(); ++n2) {
            Object t2 = object.y.c(n2);
            f4 = t2.a(n3);
            if (f4 == Float.NaN) continue;
            object2.add(new com.github.mikephil.charting.i.e(f4, n2, t2));
        }
        n2 = n4;
        if (this.e instanceof f) {
            n2 = com.github.mikephil.charting.i.h.a(object2, f3 / ((f)this.e).getFactor(), 0);
        }
        if (n2 < 0) {
            ((com.github.mikephil.charting.charts.e)this.e).s();
            this.c = null;
            return true;
        }
        this.b(new a(n3, n2));
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @SuppressLint(value={"ClickableViewAccessibility"})
    public final boolean onTouch(View var1_1, MotionEvent var2_2) {
        if (this.d.onTouchEvent((MotionEvent)var2_2)) {
            return true;
        }
        if (((com.github.mikephil.charting.charts.e)this.e).g == false) return true;
        var3_3 = var2_2.getX();
        var4_4 = var2_2.getY();
        switch (var2_2.getAction()) {
            case 0: {
                this.a();
                this.j = 0.0f;
                this.h.clear();
                if (((com.github.mikephil.charting.charts.e)this.e).A) {
                    this.a(var3_3, var4_4);
                }
                this.g = ((com.github.mikephil.charting.charts.e)this.e).a(var3_3, var4_4) - ((com.github.mikephil.charting.charts.e)this.e).b;
                this.f.x = var3_3;
                this.f.y = var4_4;
                ** break;
            }
            case 2: {
                if (((com.github.mikephil.charting.charts.e)this.e).A) {
                    this.a(var3_3, var4_4);
                }
                if (this.b == 0 && d.a(var3_3, this.f.x, var4_4, this.f.y) > com.github.mikephil.charting.i.h.a(8.0f)) {
                    this.a = c.f;
                    this.b = 6;
                    ((com.github.mikephil.charting.charts.e)this.e).v();
                } else if (this.b == 6) {
                    ((com.github.mikephil.charting.charts.e)this.e).setRotationAngle(((com.github.mikephil.charting.charts.e)this.e).a(var3_3, var4_4) - this.g);
                    ((com.github.mikephil.charting.charts.e)this.e).invalidate();
                }
                this.b();
            }
lbl29: // 3 sources:
            default: {
                return true;
            }
            case 1: 
        }
        if (((com.github.mikephil.charting.charts.e)this.e).A) {
            this.j = 0.0f;
            this.a(var3_3, var4_4);
            if (this.h.isEmpty()) {
                var3_3 = 0.0f;
            } else {
                var6_5 = this.h.get(0);
                var7_6 = this.h.get(this.h.size() - 1);
                var5_7 = this.h.size() - 1;
                var1_1 = var6_5;
                do {
                    var2_2 = var1_1;
                    if (var5_7 < 0) break;
                    var2_2 = var1_1 = this.h.get(var5_7);
                    if (var1_1.b != var7_6.b) break;
                    --var5_7;
                } while (true);
                var3_3 = var4_4 = (float)(var7_6.a - var6_5.a) / 1000.0f;
                if (var4_4 == 0.0f) {
                    var3_3 = 0.1f;
                }
                var5_7 = var7_6.b >= var2_2.b ? 1 : 0;
                if ((double)Math.abs(var7_6.b - var2_2.b) > 270.0) {
                    var5_7 = var5_7 == 0 ? 1 : 0;
                }
                if ((double)(var7_6.b - var6_5.b) > 180.0) {
                    var6_5.b = (float)((double)var6_5.b + 360.0);
                } else if ((double)(var6_5.b - var7_6.b) > 180.0) {
                    var7_6.b = (float)((double)var7_6.b + 360.0);
                }
                var3_3 = var4_4 = Math.abs((var7_6.b - var6_5.b) / var3_3);
                if (var5_7 == 0) {
                    var3_3 = - var4_4;
                }
            }
            this.j = var3_3;
            if (this.j != 0.0f) {
                this.i = AnimationUtils.currentAnimationTimeMillis();
                com.github.mikephil.charting.i.h.a(this.e);
            }
        }
        ((com.github.mikephil.charting.charts.e)this.e).w();
        this.b = 0;
        this.b();
        return true;
    }
}

