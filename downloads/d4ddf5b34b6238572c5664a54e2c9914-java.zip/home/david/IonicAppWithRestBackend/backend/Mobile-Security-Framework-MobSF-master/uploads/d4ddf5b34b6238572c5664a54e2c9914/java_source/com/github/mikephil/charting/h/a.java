/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.DashPathEffect
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.PathEffect
 *  android.graphics.Typeface
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.Typeface;
import com.github.mikephil.charting.c.d;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.c.l;
import com.github.mikephil.charting.c.m;
import com.github.mikephil.charting.h.b;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.i.h;
import java.util.List;

public class a
extends b {
    protected com.github.mikephil.charting.c.c a;

    public a(com.github.mikephil.charting.i.d d2, com.github.mikephil.charting.c.c c2, com.github.mikephil.charting.i.a a2) {
        super(d2, a2);
        this.a = c2;
        this.d.setColor(-16777216);
        this.d.setTextSize(h.a(10.0f));
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(float f2, float f3) {
        float f4 = f2;
        float f5 = f3;
        if (this.g.i() > 10.0f) {
            f4 = f2;
            f5 = f3;
            if (!this.g.p()) {
                com.github.mikephil.charting.i.b b2 = this.b.a(this.g.f(), this.g.e());
                com.github.mikephil.charting.i.b b3 = this.b.a(this.g.f(), this.g.h());
                if (!this.a.h) {
                    f4 = (float)b3.b;
                    f5 = (float)b2.b;
                } else {
                    f4 = (float)b2.b;
                    f5 = (float)b3.b;
                }
            }
        }
        this.b(f4, f5);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(Canvas canvas) {
        int n2;
        if (!this.a.D || !this.a.z) {
            return;
        }
        float[] arrf = new float[this.a.c * 2];
        for (n2 = 0; n2 < arrf.length; n2 += 2) {
            arrf[n2 + 1] = this.a.b[n2 / 2];
        }
        this.b.a(arrf);
        this.d.setTypeface(this.a.G);
        this.d.setTextSize(this.a.H);
        this.d.setColor(this.a.I);
        float f2 = this.a.E;
        float f3 = (float)h.b(this.d, "A") / 2.5f;
        float f4 = this.a.F;
        n2 = this.a.s;
        int n3 = this.a.r;
        if (n2 == com.github.mikephil.charting.c.b.a) {
            if (n3 == com.github.mikephil.charting.c.a.a) {
                this.d.setTextAlign(Paint.Align.RIGHT);
                f2 = this.g.a() - f2;
            } else {
                this.d.setTextAlign(Paint.Align.LEFT);
                f2 += this.g.a();
            }
        } else if (n3 == com.github.mikephil.charting.c.a.a) {
            this.d.setTextAlign(Paint.Align.LEFT);
            f2 += this.g.g();
        } else {
            this.d.setTextAlign(Paint.Align.RIGHT);
            f2 = this.g.g() - f2;
        }
        this.a(canvas, f2, arrf, f3 + f4);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected void a(Canvas canvas, float f2, float[] arrf, float f3) {
        int n2 = 0;
        while (n2 < this.a.c) {
            String string = this.a.a(n2);
            if (!this.a.f && n2 >= this.a.c - 1) {
                return;
            }
            canvas.drawText(string, f2, arrf[n2 * 2 + 1] + f3, this.d);
            ++n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void b(float f2, float f3) {
        int n2 = this.a.e;
        double d2 = Math.abs(f3 - f2);
        if (n2 == 0 || d2 <= 0.0) {
            this.a.b = new float[0];
            this.a.c = 0;
            return;
        }
        double d3 = h.a(d2 / (double)n2);
        double d4 = Math.pow(10.0, (int)Math.log10(d3));
        double d5 = d3;
        if ((int)(d3 / d4) > 5) {
            d5 = Math.floor(10.0 * d4);
        }
        if (this.a.j) {
            f3 = (float)d2 / (float)(n2 - 1);
            this.a.c = n2;
            if (this.a.b.length < n2) {
                this.a.b = new float[n2];
            }
            for (int i2 = 0; i2 < n2; f2 += f3, ++i2) {
                this.a.b[i2] = f2;
            }
        } else if (this.a.g) {
            this.a.c = 2;
            this.a.b = new float[2];
            this.a.b[0] = f2;
            this.a.b[1] = f3;
        } else {
            d3 = Math.ceil((double)f2 / d5) * d5;
            d4 = h.b(Math.floor((double)f3 / d5) * d5);
            int n3 = 0;
            for (d2 = d3; d2 <= d4; d2 += d5, ++n3) {
            }
            this.a.c = n3;
            if (this.a.b.length < n3) {
                this.a.b = new float[n3];
            }
            for (n2 = 0; n2 < n3; d3 += d5, ++n2) {
                this.a.b[n2] = (float)d3;
            }
        }
        if (d5 < 1.0) {
            this.a.d = (int)Math.ceil(- Math.log10(d5));
            return;
        }
        this.a.d = 0;
    }

    public void b(Canvas canvas) {
        if (!this.a.D || !this.a.y) {
            return;
        }
        this.e.setColor(this.a.v);
        this.e.setStrokeWidth(this.a.w);
        if (this.a.s == com.github.mikephil.charting.c.b.a) {
            canvas.drawLine(this.g.f(), this.g.e(), this.g.f(), this.g.h(), this.e);
            return;
        }
        canvas.drawLine(this.g.g(), this.g.e(), this.g.g(), this.g.h(), this.e);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void c(Canvas canvas) {
        if (!this.a.x || !this.a.D) {
            return;
        }
        float[] arrf = new float[2];
        this.c.setColor(this.a.t);
        this.c.setStrokeWidth(this.a.u);
        this.c.setPathEffect((PathEffect)this.a.A);
        Path path = new Path();
        int n2 = 0;
        while (n2 < this.a.c) {
            arrf[1] = this.a.b[n2];
            this.b.a(arrf);
            path.moveTo(this.g.a(), arrf[1]);
            path.lineTo(this.g.g(), arrf[1]);
            canvas.drawPath(path, this.c);
            path.reset();
            ++n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void d(Canvas canvas) {
        List<m> list = this.a.B;
        if (list == null || list.size() <= 0) {
            return;
        }
        float[] arrf = new float[2];
        Path path = new Path();
        int n2 = 0;
        while (n2 < list.size()) {
            m m2 = list.get(n2);
            if (m2.D) {
                this.f.setStyle(Paint.Style.STROKE);
                this.f.setColor(m2.c);
                this.f.setStrokeWidth(m2.b);
                this.f.setPathEffect((PathEffect)m2.f);
                arrf[1] = m2.a;
                this.b.a(arrf);
                path.moveTo(this.g.f(), arrf[1]);
                path.lineTo(this.g.g(), arrf[1]);
                canvas.drawPath(path, this.f);
                path.reset();
                String string = m2.e;
                if (string != null && !string.equals("")) {
                    this.f.setStyle(m2.d);
                    this.f.setPathEffect(null);
                    this.f.setColor(m2.I);
                    this.f.setTypeface(m2.G);
                    this.f.setStrokeWidth(0.5f);
                    this.f.setTextSize(m2.H);
                    float f2 = h.b(this.f, string);
                    float f3 = h.a(4.0f) + m2.E;
                    float f4 = m2.b + f2 + m2.F;
                    int n3 = m2.g;
                    if (n3 == l.c) {
                        this.f.setTextAlign(Paint.Align.RIGHT);
                        canvas.drawText(string, this.g.g() - f3, f2 + (arrf[1] - f4), this.f);
                    } else if (n3 == l.d) {
                        this.f.setTextAlign(Paint.Align.RIGHT);
                        canvas.drawText(string, this.g.g() - f3, arrf[1] + f4, this.f);
                    } else if (n3 == l.a) {
                        this.f.setTextAlign(Paint.Align.LEFT);
                        canvas.drawText(string, this.g.f() + f3, f2 + (arrf[1] - f4), this.f);
                    } else {
                        this.f.setTextAlign(Paint.Align.LEFT);
                        canvas.drawText(string, this.g.a() + f3, arrf[1] + f4, this.f);
                    }
                }
            }
            ++n2;
        }
    }
}

