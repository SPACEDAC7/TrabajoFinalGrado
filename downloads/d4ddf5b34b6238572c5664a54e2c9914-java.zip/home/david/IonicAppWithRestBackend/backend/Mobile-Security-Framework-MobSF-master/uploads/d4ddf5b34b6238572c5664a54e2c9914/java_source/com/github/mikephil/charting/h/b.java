/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 */
package com.github.mikephil.charting.h;

import android.graphics.Paint;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.i.a;
import com.github.mikephil.charting.i.d;

public abstract class b
extends c {
    protected a b;
    protected Paint c;
    public Paint d;
    protected Paint e;
    protected Paint f;

    public b(d d2, a a2) {
        super(d2);
        this.b = a2;
        this.d = new Paint(1);
        this.c = new Paint();
        this.c.setColor(-7829368);
        this.c.setStrokeWidth(1.0f);
        this.c.setStyle(Paint.Style.STROKE);
        this.c.setAlpha(90);
        this.e = new Paint();
        this.e.setColor(-16777216);
        this.e.setStrokeWidth(1.0f);
        this.e.setStyle(Paint.Style.STROKE);
        this.f = new Paint(1);
        this.f.setStyle(Paint.Style.STROKE);
    }
}

