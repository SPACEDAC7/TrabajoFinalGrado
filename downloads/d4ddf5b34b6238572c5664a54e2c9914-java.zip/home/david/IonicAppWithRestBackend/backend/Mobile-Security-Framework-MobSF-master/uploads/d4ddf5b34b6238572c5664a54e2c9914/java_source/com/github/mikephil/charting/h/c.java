/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.h;

import com.github.mikephil.charting.d.b;
import com.github.mikephil.charting.i.d;

public abstract class c {
    public d g;
    protected int h = 0;
    protected int i = 0;

    public c(d d2) {
        this.g = d2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(b b2, int n2) {
        int n3 = b2.getLowestVisibleXIndex();
        int n4 = b2.getHighestVisibleXIndex();
        int n5 = n3 % n2 == 0 ? n2 : 0;
        this.h = Math.max(n3 / n2 * n2 - n5, 0);
        this.i = Math.min(n4 / n2 * n2 + n2, (int)b2.getXChartMax());
    }
}

