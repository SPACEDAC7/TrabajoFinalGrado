/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.DashPathEffect
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.PathEffect
 *  android.graphics.PointF
 *  android.graphics.Rect
 *  android.graphics.Typeface
 *  android.text.TextPaint
 *  android.text.TextUtils
 *  android.text.TextUtils$TruncateAt
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.TextUtils;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.c.j;
import com.github.mikephil.charting.c.k;
import com.github.mikephil.charting.c.l;
import com.github.mikephil.charting.c.m;
import com.github.mikephil.charting.h.b;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.i.a;
import com.github.mikephil.charting.i.h;
import java.util.List;

public class d
extends b {
    protected k a;
    float[] j = new float[4];
    private Path k = new Path();

    public d(com.github.mikephil.charting.i.d d2, k k2, a a2) {
        super(d2, a2);
        this.a = k2;
        this.d.setColor(-16777216);
        this.d.setTextAlign(Paint.Align.CENTER);
        this.d.setTextSize(h.a(10.0f));
    }

    public void a(float f2, List<String> list) {
        this.d.setTypeface(this.a.G);
        this.d.setTextSize(this.a.H);
        Object object = new StringBuilder();
        int n2 = Math.round((float)this.a.g + f2);
        for (int i2 = 0; i2 < n2; ++i2) {
            object.append('h');
        }
        f2 = h.c((Paint)this.d, (String)object.toString()).a;
        float f3 = h.b(this.d, "Q");
        object = h.a(f2, f3, this.a.f);
        this.a.b = Math.round(f2);
        this.a.c = Math.round(f3);
        this.a.d = Math.round(object.a);
        this.a.e = Math.round(object.b);
        this.a.a = list;
    }

    public void a(Canvas canvas) {
        if (!this.a.D || !this.a.z) {
            return;
        }
        float f2 = this.a.F;
        this.d.setTypeface(this.a.G);
        this.d.setTextSize(this.a.H);
        this.d.setColor(this.a.I);
        if (this.a.m == j.a) {
            this.a(canvas, this.g.e() - f2, new PointF(0.5f, 1.0f));
            return;
        }
        if (this.a.m == j.d) {
            this.a(canvas, f2 + this.g.e() + (float)this.a.e, new PointF(0.5f, 1.0f));
            return;
        }
        if (this.a.m == j.b) {
            this.a(canvas, f2 + this.g.h(), new PointF(0.5f, 0.0f));
            return;
        }
        if (this.a.m == j.e) {
            this.a(canvas, this.g.h() - f2 - (float)this.a.e, new PointF(0.5f, 0.0f));
            return;
        }
        this.a(canvas, this.g.e() - f2, new PointF(0.5f, 1.0f));
        this.a(canvas, f2 + this.g.h(), new PointF(0.5f, 0.0f));
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a(Canvas canvas, float f2, PointF pointF) {
        float[] arrf;
        float f3 = this.a.f;
        float[] arrf2 = arrf = new float[2];
        arrf2[0] = 0.0f;
        arrf2[1] = 0.0f;
        int n2 = this.h;
        while (n2 <= this.i) {
            arrf[0] = n2;
            this.b.a(arrf);
            if (this.g.c(arrf[0])) {
                String string = this.a.a.get(n2);
                if (this.a.k) {
                    float f4;
                    if (n2 == this.a.a.size() - 1 && this.a.a.size() > 1) {
                        f4 = h.a(this.d, string);
                        if (f4 > this.g.b() * 2.0f && arrf[0] + f4 > this.g.c) {
                            arrf[0] = arrf[0] - f4 / 2.0f;
                        }
                    } else if (n2 == 0) {
                        f4 = h.a(this.d, string);
                        float f5 = arrf[0];
                        arrf[0] = f4 / 2.0f + f5;
                    }
                }
                this.a(canvas, string, arrf[0], f2, pointF, f3);
            }
            n2 = this.a.h + n2;
        }
        return;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final void a(Canvas var1_1, String var2_2, float var3_3, float var4_4, PointF var5_5, float var6_6) {
        var13_7 = this.a.l;
        var13_7 = this.d;
        var8_8 = 0.0f;
        var13_7.getTextBounds(var2_2, 0, var2_2.length(), h.e);
        var10_9 = 0.0f - (float)h.e.left;
        var9_10 = 0.0f - (float)h.e.top;
        var14_11 = var13_7.getTextAlign();
        var13_7.setTextAlign(Paint.Align.LEFT);
        if (var6_6 == 0.0f) ** GOTO lbl25
        var11_12 = h.e.width();
        var12_14 = h.e.height();
        if (var5_5.x != 0.5f) ** GOTO lbl-1000
        var8_8 = var3_3;
        var7_16 = var4_4;
        if (var5_5.y != 0.5f) lbl-1000: // 2 sources:
        {
            var15_18 = h.a(h.e.width(), (float)h.e.height(), var6_6);
            var8_8 = var3_3 - var15_18.a * (var5_5.x - 0.5f);
            var7_16 = var4_4 - var15_18.b * (var5_5.y - 0.5f);
        }
        var1_1.save();
        var1_1.translate(var8_8, var7_16);
        var1_1.rotate(var6_6);
        var1_1.drawText(var2_2, var10_9 - var11_12 * 0.5f, var9_10 - var12_14 * 0.5f, (Paint)var13_7);
        var1_1.restore();
        ** GOTO lbl39
lbl25: // 1 sources:
        if (var5_5.x != 0.0f || var5_5.y != 0.0f) {
            var7_17 = h.e.width();
            var12_15 = var5_5.x;
            var6_6 = h.e.height();
            var11_13 = var5_5.y;
            var7_17 = var10_9 - var7_17 * var12_15;
            var6_6 = var9_10 - var6_6 * var11_13;
        } else {
            var7_17 = var10_9;
            var6_6 = var9_10;
        }
        if ((var3_3 = var7_17 + var3_3) < 0.0f) {
            var2_2 = TextUtils.ellipsize((CharSequence)var2_2, (TextPaint)new TextPaint((Paint)var13_7), (float)(var3_3 + (float)h.e.width()), (TextUtils.TruncateAt)TextUtils.TruncateAt.END).toString();
            var3_3 = var8_8;
        }
        var1_1.drawText(var2_2, var3_3, var6_6 + var4_4, (Paint)var13_7);
lbl39: // 2 sources:
        var13_7.setTextAlign(var14_11);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void b(Canvas canvas) {
        if (!this.a.y) return;
        if (!this.a.D) {
            return;
        }
        this.e.setColor(this.a.v);
        this.e.setStrokeWidth(this.a.w);
        if (this.a.m == j.a || this.a.m == j.d || this.a.m == j.c) {
            canvas.drawLine(this.g.f(), this.g.e(), this.g.g(), this.g.e(), this.e);
        }
        if (this.a.m != j.b && this.a.m != j.e) {
            if (this.a.m != j.c) return;
        }
        canvas.drawLine(this.g.f(), this.g.h(), this.g.g(), this.g.h(), this.e);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void c(Canvas canvas) {
        if (this.a.x && this.a.D) {
            float[] arrf;
            float[] arrf2 = arrf = new float[2];
            arrf2[0] = 0.0f;
            arrf2[1] = 0.0f;
            this.c.setColor(this.a.t);
            this.c.setStrokeWidth(this.a.u);
            this.c.setPathEffect((PathEffect)this.a.A);
            Path path = new Path();
            for (int i2 = this.h; i2 <= this.i; i2 += this.a.h) {
                arrf[0] = i2;
                this.b.a(arrf);
                if (arrf[0] >= this.g.a() && arrf[0] <= this.g.c) {
                    path.moveTo(arrf[0], this.g.h());
                    path.lineTo(arrf[0], this.g.e());
                    canvas.drawPath(path, this.c);
                }
                path.reset();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void d(Canvas canvas) {
        List<m> list = this.a.B;
        if (list == null || list.size() <= 0) {
            return;
        }
        float[] arrf = new float[2];
        int n2 = 0;
        while (n2 < list.size()) {
            m m2 = list.get(n2);
            if (m2.D) {
                arrf[0] = m2.a;
                arrf[1] = 0.0f;
                this.b.a(arrf);
                this.j[0] = arrf[0];
                this.j[1] = this.g.e();
                this.j[2] = arrf[0];
                this.j[3] = this.g.h();
                this.k.reset();
                this.k.moveTo(this.j[0], this.j[1]);
                this.k.lineTo(this.j[2], this.j[3]);
                this.f.setStyle(Paint.Style.STROKE);
                this.f.setColor(m2.c);
                this.f.setStrokeWidth(m2.b);
                this.f.setPathEffect((PathEffect)m2.f);
                canvas.drawPath(this.k, this.f);
                float f2 = 2.0f + m2.F;
                String string = m2.e;
                if (string != null && !string.equals("")) {
                    float f3;
                    this.f.setStyle(m2.d);
                    this.f.setPathEffect(null);
                    this.f.setColor(m2.I);
                    this.f.setStrokeWidth(0.5f);
                    this.f.setTextSize(m2.H);
                    float f4 = m2.b + m2.E;
                    int n3 = m2.g;
                    if (n3 == l.c) {
                        f3 = h.b(this.f, string);
                        this.f.setTextAlign(Paint.Align.LEFT);
                        canvas.drawText(string, f4 + arrf[0], f3 + (f2 + this.g.e()), this.f);
                    } else if (n3 == l.d) {
                        this.f.setTextAlign(Paint.Align.LEFT);
                        canvas.drawText(string, arrf[0] + f4, this.g.h() - f2, this.f);
                    } else if (n3 == l.a) {
                        this.f.setTextAlign(Paint.Align.RIGHT);
                        f3 = h.b(this.f, string);
                        canvas.drawText(string, arrf[0] - f4, f3 + (f2 + this.g.e()), this.f);
                    } else {
                        this.f.setTextAlign(Paint.Align.RIGHT);
                        canvas.drawText(string, arrf[0] - f4, this.g.h() - f2, this.f);
                    }
                }
            }
            ++n2;
        }
    }
}

