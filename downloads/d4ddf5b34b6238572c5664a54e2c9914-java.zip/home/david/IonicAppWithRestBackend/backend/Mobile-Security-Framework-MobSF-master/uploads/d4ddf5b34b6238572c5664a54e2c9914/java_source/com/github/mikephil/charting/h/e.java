/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.h;

import com.github.mikephil.charting.c.f;
import com.github.mikephil.charting.c.g;

final class e {
    static final /* synthetic */ int[] a;
    static final /* synthetic */ int[] b;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        b = new int[g.a().length];
        try {
            e.b[g.b - 1] = 1;
        }
        catch (NoSuchFieldError var0_15) {}
        try {
            e.b[g.a - 1] = 2;
        }
        catch (NoSuchFieldError var0_14) {}
        try {
            e.b[g.c - 1] = 3;
        }
        catch (NoSuchFieldError var0_13) {}
        a = new int[f.a().length];
        try {
            e.a[f.g - 1] = 1;
        }
        catch (NoSuchFieldError var0_12) {}
        try {
            e.a[f.h - 1] = 2;
        }
        catch (NoSuchFieldError var0_11) {}
        try {
            e.a[f.i - 1] = 3;
        }
        catch (NoSuchFieldError var0_10) {}
        try {
            e.a[f.j - 1] = 4;
        }
        catch (NoSuchFieldError var0_9) {}
        try {
            e.a[f.k - 1] = 5;
        }
        catch (NoSuchFieldError var0_8) {}
        try {
            e.a[f.l - 1] = 6;
        }
        catch (NoSuchFieldError var0_7) {}
        try {
            e.a[f.m - 1] = 7;
        }
        catch (NoSuchFieldError var0_6) {}
        try {
            e.a[f.a - 1] = 8;
        }
        catch (NoSuchFieldError var0_5) {}
        try {
            e.a[f.b - 1] = 9;
        }
        catch (NoSuchFieldError var0_4) {}
        try {
            e.a[f.c - 1] = 10;
        }
        catch (NoSuchFieldError var0_3) {}
        try {
            e.a[f.d - 1] = 11;
        }
        catch (NoSuchFieldError var0_2) {}
        try {
            e.a[f.e - 1] = 12;
        }
        catch (NoSuchFieldError var0_1) {}
        try {
            e.a[f.f - 1] = 13;
            return;
        }
        catch (NoSuchFieldError var0) {
            return;
        }
    }
}

