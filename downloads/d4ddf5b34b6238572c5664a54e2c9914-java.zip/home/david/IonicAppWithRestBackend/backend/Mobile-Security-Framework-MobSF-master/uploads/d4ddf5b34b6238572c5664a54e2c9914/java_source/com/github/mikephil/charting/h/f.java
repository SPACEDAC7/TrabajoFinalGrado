/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.Paint$Style
 *  android.graphics.Typeface
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import com.github.mikephil.charting.c.i;
import com.github.mikephil.charting.data.b;
import com.github.mikephil.charting.data.m;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.h.e;
import com.github.mikephil.charting.i.d;
import com.github.mikephil.charting.i.h;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class f
extends c {
    public Paint a;
    protected Paint b;
    protected i c;

    public f(d d2, i i2) {
        super(d2);
        this.c = i2;
        this.a = new Paint(1);
        this.a.setTextSize(h.a(9.0f));
        this.a.setTextAlign(Paint.Align.LEFT);
        this.b = new Paint(1);
        this.b.setStyle(Paint.Style.FILL);
        this.b.setStrokeWidth(3.0f);
    }

    private void a(Canvas canvas, float f2, float f3, int n2, i i2) {
        if (i2.a[n2] == -2) {
            return;
        }
        this.b.setColor(i2.a[n2]);
        float f4 = i2.i;
        float f5 = f4 / 2.0f;
        switch (e.b[i2.h - 1]) {
            default: {
                return;
            }
            case 1: {
                canvas.drawCircle(f2 + f5, f3, f5, this.b);
                return;
            }
            case 2: {
                canvas.drawRect(f2, f3 - f5, f2 + f4, f3 + f5, this.b);
                return;
            }
            case 3: 
        }
        canvas.drawLine(f2, f3, f2 + f4, f3, this.b);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(Canvas var1_1) {
        block44 : {
            if (!this.c.x()) {
                return;
            }
            var21_2 = this.c.t();
            if (var21_2 != null) {
                this.a.setTypeface((Typeface)var21_2);
            }
            this.a.setTextSize(this.c.u());
            this.a.setColor(this.c.v());
            var9_3 = h.a(this.a);
            var10_4 = h.b(this.a) + this.c.k;
            var11_5 = var9_3 - (float)h.b(this.a, "ABC") / 2.0f;
            var21_2 = this.c.b;
            var22_6 = this.c.a;
            var6_7 = this.c.l;
            var7_8 = this.c.j;
            var17_9 = this.c.g;
            var12_10 = this.c.i;
            var8_11 = this.c.m;
            var4_12 = this.c.s();
            var3_13 = this.c.r();
            var18_14 = this.c.f;
            block0 : switch (e.a[var18_14 - 1]) {
                default: {
                    return;
                }
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: 
                case 6: {
                    var2_15 = this.g.i();
                    if (var18_14 == com.github.mikephil.charting.c.f.g || var18_14 == com.github.mikephil.charting.c.f.j) {
                        var2_15 = var3_13 += this.g.f();
                        if (var17_9 == com.github.mikephil.charting.c.h.b) {
                            var2_15 = var3_13 + this.c.o;
                        }
                    } else if (var18_14 == com.github.mikephil.charting.c.f.h || var18_14 == com.github.mikephil.charting.c.f.k) {
                        var2_15 = var3_13 = this.g.g() - var3_13;
                        if (var17_9 == com.github.mikephil.charting.c.h.a) {
                            var2_15 = var3_13 - this.c.o;
                        }
                    } else {
                        var2_15 = this.g.f() + var2_15 / 2.0f;
                    }
                    var23_17 = this.c.u;
                    var24_19 = this.c.s;
                    var25_20 = this.c.t;
                    var4_12 = var18_14 == com.github.mikephil.charting.c.f.j || var18_14 == com.github.mikephil.charting.c.f.k || var18_14 == com.github.mikephil.charting.c.f.l ? 0.0f : this.g.m() - var4_12 - this.c.p;
                    var13_21 = 0;
                    var14_23 = 0;
                    var19_25 = var21_2.length;
                    var3_13 = var2_15;
                    block4 : while (var14_23 < var19_25) {
                        if (var14_23 < var25_20.length && var25_20[var14_23].booleanValue()) {
                            var4_12 += var9_3 + var10_4;
                            var3_13 = var2_15;
                        }
                        if (var3_13 == var2_15 && var18_14 == com.github.mikephil.charting.c.f.i && var13_21 < var23_17.length) {
                            var5_26 = var17_9 == com.github.mikephil.charting.c.h.b ? var23_17[var13_21].a : - var23_17[var13_21].a;
                            ++var13_21;
                            var3_13 += (var5_26 /= 2.0f);
                        }
                        var15_28 = var22_6[var14_23] != -2;
                        var16_29 = var21_2[var14_23] == null;
                        if (var15_28) {
                            if (var17_9 == com.github.mikephil.charting.c.h.b) {
                                var3_13 -= var12_10;
                            }
                            this.a(var1_1, var3_13, var4_12 + var11_5, var14_23, this.c);
                            if (var17_9 == com.github.mikephil.charting.c.h.a) {
                                var3_13 += var12_10;
                            }
                            if (!var16_29) {
                                if (!var15_28) break block0;
                                var5_26 = var17_9 == com.github.mikephil.charting.c.h.b ? - var6_7 : var6_7;
                                var5_26 += var3_13;
                                break block44;
                            }
                        }
                        var5_26 = var17_9 == com.github.mikephil.charting.c.h.b ? - var8_11 : var8_11;
                        var3_13 = var5_26 + var3_13;
lbl68: // 2 sources:
                        do {
                            ++var14_23;
                            continue block4;
                            break;
                        } while (true);
                    }
                    return;
                }
                case 7: 
                case 8: 
                case 9: 
                case 10: 
                case 11: 
                case 12: 
                case 13: {
                    if (var18_14 == com.github.mikephil.charting.c.f.m) {
                        var4_12 = this.g.n() / 2.0f;
                        var2_16 = var17_9 == com.github.mikephil.charting.c.h.a ? (- this.c.r) / 2.0f : this.c.r / 2.0f;
                        var3_13 = this.g.m() / 2.0f - this.c.p / 2.0f + this.c.s();
                        var2_16 = var4_12 + var2_16;
                    } else {
                        var13_22 = var18_14 == com.github.mikephil.charting.c.f.a || var18_14 == com.github.mikephil.charting.c.f.b || var18_14 == com.github.mikephil.charting.c.f.c;
                        if (var13_22) {
                            var2_16 = var3_13 = this.g.n() - var3_13;
                            if (var17_9 == com.github.mikephil.charting.c.h.a) {
                                var2_16 = var3_13 - this.c.r;
                            }
                        } else {
                            var2_16 = var3_13;
                            if (var17_9 == com.github.mikephil.charting.c.h.b) {
                                var2_16 = var3_13 + this.c.r;
                            }
                        }
                        if (var18_14 == com.github.mikephil.charting.c.f.a || var18_14 == com.github.mikephil.charting.c.f.d) {
                            var3_13 = this.g.e();
                            var3_13 += var4_12;
                        } else if (var18_14 == com.github.mikephil.charting.c.f.b || var18_14 == com.github.mikephil.charting.c.f.e) {
                            var3_13 = this.g.m() / 2.0f;
                            var4_12 = this.c.p / 2.0f;
                            var3_13 -= var4_12;
                        } else {
                            var3_13 = this.g.e();
                            var3_13 += var4_12;
                        }
                    }
                    var14_24 = 0;
                    var13_22 = false;
                    var7_8 = 0.0f;
                    while (var14_24 < var21_2.length) {
                        var20_30 = var22_6[var14_24] != -2;
                        var23_18 = var20_30;
                        if (var23_18.booleanValue()) {
                            var5_27 = var17_9 == com.github.mikephil.charting.c.h.a ? var2_16 + var7_8 : var2_16 - (var12_10 - var7_8);
                            this.a(var1_1, var5_27, var3_13 + var11_5, var14_24, this.c);
                            var4_12 = var5_27;
                            if (var17_9 == com.github.mikephil.charting.c.h.a) {
                                var4_12 = var5_27 + var12_10;
                            }
                        } else {
                            var4_12 = var2_16;
                        }
                        if (var21_2[var14_24] != null) {
                            if (var23_18.booleanValue() && !var13_22) {
                                var5_27 = var17_9 == com.github.mikephil.charting.c.h.a ? var6_7 : - var6_7;
                                var4_12 += var5_27;
                            } else if (var13_22) {
                                var4_12 = var2_16;
                            }
                            var5_27 = var4_12;
                            if (var17_9 == com.github.mikephil.charting.c.h.b) {
                                var5_27 = var4_12 - (float)h.a(this.a, var21_2[var14_24]);
                            }
                            if (!var13_22) {
                                var1_1.drawText(var21_2[var14_24], var5_27, var3_13 + var9_3, this.a);
                            } else {
                                var1_1.drawText(var21_2[var14_24], var5_27, (var3_13 += var9_3 + var10_4) + var9_3, this.a);
                            }
                            var3_13 += var9_3 + var10_4;
                            var4_12 = 0.0f;
                        } else {
                            var4_12 = var7_8 + (var12_10 + var8_11);
                            var13_22 = true;
                        }
                        ++var14_24;
                        var7_8 = var4_12;
                    }
                    return;
                }
            }
            var5_26 = var3_13;
        }
        var3_13 = var5_26;
        if (var17_9 == com.github.mikephil.charting.c.h.b) {
            var3_13 = var5_26 - var24_19[var14_23].a;
        }
        var1_1.drawText(var21_2[var14_23], var3_13, var4_12 + var9_3, this.a);
        var5_26 = var3_13;
        if (var17_9 == com.github.mikephil.charting.c.h.a) {
            var5_26 = var3_13 + var24_19[var14_23].a;
        }
        var3_13 = var17_9 == com.github.mikephil.charting.c.h.b ? - var7_8 : var7_8;
        var3_13 = var5_26 + var3_13;
        ** while (true)
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void a(b<?> var1_1) {
        var4_2 = 0;
        if (this.c.e) ** GOTO lbl56
        var6_3 = new ArrayList<String>();
        var7_4 = new String[]();
        var2_5 = 0;
        block0 : do {
            if (var2_5 >= var1_1.a()) ** GOTO lbl37
            var10_10 = var1_1.c(var2_5);
            var8_8 = var10_10.a;
            var5_7 = var10_10.a();
            if (!(var10_10 instanceof com.github.mikephil.charting.data.h)) ** GOTO lbl-1000
            var3_6 = ((com.github.mikephil.charting.data.h)var10_10).s > 1 ? 1 : 0;
            if (var3_6 != 0) {
                var9_9 = (com.github.mikephil.charting.data.h)var10_10;
                var10_10 = var9_9.w;
                for (var3_6 = 0; var3_6 < var8_8.size() && var3_6 < var9_9.s; ++var3_6) {
                    var6_3.add(var10_10[var3_6 % var10_10.length]);
                    var7_4.add(var8_8.get(var3_6));
                }
                if (var9_9.h != null) {
                    var7_4.add(-2);
                    var6_3.add(var9_9.h);
                }
            } else if (var10_10 instanceof m) {
                var9_9 = var1_1.l;
                var10_10 = (m)var10_10;
                for (var3_6 = 0; var3_6 < var8_8.size() && var3_6 < var5_7 && var3_6 < var9_9.size(); ++var3_6) {
                    var6_3.add((String)var9_9.get(var3_6));
                    var7_4.add(var8_8.get(var3_6));
                }
                if (var10_10.h != null) {
                    var7_4.add(-2);
                    var6_3.add(var10_10.h);
                }
            } else {
                var3_6 = 0;
                break;
lbl37: // 1 sources:
                if (this.c.c != null && this.c.d != null) {
                    var1_1 = this.c.c;
                    var3_6 = var1_1.length;
                    for (var2_5 = var4_2; var2_5 < var3_6; ++var2_5) {
                        var7_4.add(var1_1[var2_5]);
                    }
                    Collections.addAll(var6_3, this.c.d);
                }
                var1_1 = this.c;
                var8_8 = new int[var7_4.size()];
                for (var2_5 = 0; var2_5 < var8_8.length; ++var2_5) {
                    var8_8[var2_5] = (Integer)var7_4.get(var2_5);
                }
                var1_1.a = var8_8;
                var1_1 = this.c;
                var7_4 = new String[var6_3.size()];
                for (var2_5 = 0; var2_5 < var7_4.length; ++var2_5) {
                    var7_4[var2_5] = (String)var6_3.get(var2_5);
                }
                var1_1.b = var7_4;
lbl56: // 2 sources:
                if ((var1_1 = this.c.G) != null) {
                    this.a.setTypeface((Typeface)var1_1);
                }
                this.a.setTextSize(this.c.H);
                this.a.setColor(this.c.I);
                this.c.a(this.a, this.g);
                return;
            }
            do {
                ++var2_5;
                continue block0;
                break;
            } while (true);
            break;
        } while (true);
        do {
            if (var3_6 >= var8_8.size() || var3_6 >= var5_7) ** continue;
            if (var3_6 < var8_8.size() - 1 && var3_6 < var5_7 - 1) {
                var6_3.add(null);
            } else {
                var6_3.add(var1_1.c((int)var2_5).h);
            }
            var7_4.add(var8_8.get(var3_6));
            ++var3_6;
        } while (true);
    }
}

