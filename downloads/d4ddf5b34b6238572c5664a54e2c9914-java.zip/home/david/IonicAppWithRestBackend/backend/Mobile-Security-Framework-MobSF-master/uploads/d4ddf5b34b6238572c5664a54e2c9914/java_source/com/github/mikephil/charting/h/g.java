/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.Paint$Style
 *  android.graphics.Typeface
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.i.d;
import com.github.mikephil.charting.i.h;

public abstract class g
extends c {
    protected com.github.mikephil.charting.a.a a;
    protected Paint b;
    public Paint c;
    protected Paint d;
    protected Paint e;

    public g(com.github.mikephil.charting.a.a a2, d d2) {
        super(d2);
        this.a = a2;
        this.b = new Paint(1);
        this.b.setStyle(Paint.Style.FILL);
        this.d = new Paint(4);
        this.e = new Paint(1);
        this.e.setColor(Color.rgb((int)63, (int)63, (int)63));
        this.e.setTextAlign(Paint.Align.CENTER);
        this.e.setTextSize(h.a(9.0f));
        this.c = new Paint(1);
        this.c.setStyle(Paint.Style.STROKE);
        this.c.setStrokeWidth(2.0f);
        this.c.setColor(Color.rgb((int)255, (int)187, (int)115));
    }

    public abstract void a();

    public abstract void a(Canvas var1);

    public final void a(Canvas canvas, com.github.mikephil.charting.f.c c2, float f2, float f3, float f4) {
        canvas.drawText(c2.b(f2), f3, f4, this.e);
    }

    public abstract void a(Canvas var1, a[] var2);

    protected final void a(com.github.mikephil.charting.data.d<?> d2) {
        this.e.setColor(d2.k);
        this.e.setTypeface(d2.m);
        this.e.setTextSize(d2.l);
    }

    public abstract void b(Canvas var1);

    public abstract void c(Canvas var1);
}

