/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.DashPathEffect
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.PathEffect
 *  android.graphics.PointF
 *  android.graphics.Typeface
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PointF;
import android.graphics.Typeface;
import com.github.mikephil.charting.c.c;
import com.github.mikephil.charting.c.m;
import com.github.mikephil.charting.charts.d;
import com.github.mikephil.charting.charts.e;
import com.github.mikephil.charting.charts.f;
import com.github.mikephil.charting.data.n;
import com.github.mikephil.charting.h.a;
import com.github.mikephil.charting.h.b;
import java.util.List;

public final class h
extends a {
    private f j;

    public h(com.github.mikephil.charting.i.d d2, c c2, f f2) {
        super(d2, c2, null);
        this.j = f2;
    }

    @Override
    public final void a(float f2, float f3) {
        this.b(f2, f3);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a(Canvas canvas) {
        if (!this.a.D) return;
        if (!this.a.z) {
            return;
        }
        this.d.setTypeface(this.a.G);
        this.d.setTextSize(this.a.H);
        this.d.setColor(this.a.I);
        PointF pointF = this.j.getCenterOffsets();
        float f2 = this.j.getFactor();
        int n2 = this.a.c;
        int n3 = 0;
        while (n3 < n2) {
            if (n3 == n2 - 1) {
                if (!this.a.f) return;
            }
            PointF pointF2 = com.github.mikephil.charting.i.h.a(pointF, (this.a.b[n3] - this.a.p) * f2, this.j.a);
            canvas.drawText(this.a.a(n3), pointF2.x + 10.0f, pointF2.y, this.d);
            ++n3;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected final void b(float f2, float f3) {
        int n2 = this.a.e;
        double d2 = Math.abs(f3 - f2);
        if (n2 == 0 || d2 <= 0.0) {
            this.a.b = new float[0];
            this.a.c = 0;
            return;
        }
        double d3 = com.github.mikephil.charting.i.h.a(d2 / (double)n2);
        double d4 = Math.pow(10.0, (int)Math.log10(d3));
        double d5 = d3;
        if ((int)(d3 / d4) > 5) {
            d5 = Math.floor(10.0 * d4);
        }
        if (this.a.j) {
            float f4 = (float)d2 / (float)(n2 - 1);
            this.a.c = n2;
            if (this.a.b.length < n2) {
                this.a.b = new float[n2];
            }
            f3 = f2;
            for (int i2 = 0; i2 < n2; f3 += f4, ++i2) {
                this.a.b[i2] = f3;
            }
        } else if (this.a.g) {
            this.a.c = 2;
            this.a.b = new float[2];
            this.a.b[0] = f2;
            this.a.b[1] = f3;
        } else {
            d3 = (double)f2 / d5;
            d3 = d3 < 0.0 ? Math.floor(d3) * d5 : Math.ceil(d3) * d5;
            d2 = d3;
            if (d3 < (double)f2) {
                d2 = d3;
                if (this.a.i) {
                    d2 = f2;
                }
            }
            d3 = d2;
            if (d2 == 0.0) {
                d3 = 0.0;
            }
            d4 = com.github.mikephil.charting.i.h.b(Math.floor((double)f3 / d5) * d5);
            int n3 = 0;
            for (d2 = d3; d2 <= d4; ++n3, d2 += d5) {
            }
            n2 = n3;
            if (Float.isNaN(this.a.l)) {
                n2 = n3 + 1;
            }
            this.a.c = n2;
            if (this.a.b.length < n2) {
                this.a.b = new float[n2];
            }
            for (n3 = 0; n3 < n2; d3 += d5, ++n3) {
                this.a.b[n3] = (float)d3;
            }
        }
        this.a.d = d5 < 1.0 ? (int)Math.ceil(- Math.log10(d5)) : 0;
        if (!this.a.i && this.a.b[0] < f2) {
            this.a.p = this.a.b[0];
        }
        this.a.o = this.a.b[this.a.c - 1];
        this.a.q = Math.abs(this.a.o - this.a.p);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void d(Canvas canvas) {
        List<m> list = this.a.B;
        if (list == null) {
            return;
        }
        float f2 = this.j.getSliceAngle();
        float f3 = this.j.getFactor();
        PointF pointF = this.j.getCenterOffsets();
        int n2 = 0;
        while (n2 < list.size()) {
            m m2 = list.get(n2);
            if (m2.D) {
                this.f.setColor(m2.c);
                this.f.setPathEffect((PathEffect)m2.f);
                this.f.setStrokeWidth(m2.b);
                float f4 = m2.a;
                float f5 = this.j.getYChartMin();
                m2 = new Path();
                for (int i2 = 0; i2 < ((n)this.j.y).f(); ++i2) {
                    PointF pointF2 = com.github.mikephil.charting.i.h.a(pointF, (f4 - f5) * f3, (float)i2 * f2 + this.j.a);
                    if (i2 == 0) {
                        m2.moveTo(pointF2.x, pointF2.y);
                        continue;
                    }
                    m2.lineTo(pointF2.x, pointF2.y);
                }
                m2.close();
                canvas.drawPath((Path)m2, this.f);
            }
            ++n2;
        }
    }
}

