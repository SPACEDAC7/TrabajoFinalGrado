/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.PointF
 *  android.graphics.Typeface
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Typeface;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.c.k;
import com.github.mikephil.charting.charts.f;
import com.github.mikephil.charting.h.b;
import com.github.mikephil.charting.h.d;
import com.github.mikephil.charting.i.a;
import com.github.mikephil.charting.i.h;
import java.util.List;

public final class i
extends d {
    private f k;

    public i(com.github.mikephil.charting.i.d d2, k k2, f f2) {
        super(d2, k2, null);
        this.k = f2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void a(Canvas canvas) {
        if (!this.a.D || !this.a.z) {
            return;
        }
        float f2 = this.a.f;
        PointF pointF = new PointF(0.5f, 0.0f);
        this.d.setTypeface(this.a.G);
        this.d.setTextSize(this.a.H);
        this.d.setColor(this.a.I);
        float f3 = this.k.getSliceAngle();
        float f4 = this.k.getFactor();
        PointF pointF2 = this.k.getCenterOffsets();
        int n2 = this.a.h;
        int n3 = 0;
        while (n3 < this.a.a.size()) {
            String string = this.a.a.get(n3);
            float f5 = n3;
            float f6 = this.k.a;
            PointF pointF3 = h.a(pointF2, this.k.getYRange() * f4 + (float)this.a.d / 2.0f, (f5 * f3 + f6) % 360.0f);
            this.a(canvas, string, pointF3.x, pointF3.y - (float)this.a.e / 2.0f, pointF, f2);
            n3 += n2;
        }
    }

    @Override
    public final void d(Canvas canvas) {
    }
}

