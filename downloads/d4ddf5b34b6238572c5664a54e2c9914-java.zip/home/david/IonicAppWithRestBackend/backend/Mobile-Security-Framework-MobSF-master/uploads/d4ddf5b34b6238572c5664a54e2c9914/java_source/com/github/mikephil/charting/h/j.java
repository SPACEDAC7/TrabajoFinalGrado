/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.RectF
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import com.github.mikephil.charting.b.b;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.f;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.h.g;
import com.github.mikephil.charting.i.a;
import com.github.mikephil.charting.i.d;
import com.github.mikephil.charting.i.h;
import java.util.List;

public class j
extends g {
    protected com.github.mikephil.charting.d.c f;
    protected RectF j = new RectF();
    protected b[] k;
    protected Paint l;
    protected boolean m;

    public j(com.github.mikephil.charting.d.c c2, com.github.mikephil.charting.a.a a2, d d2) {
        super(a2, d2);
        this.f = c2;
        this.c = new Paint(1);
        this.c.setStyle(Paint.Style.FILL);
        this.c.setColor(Color.rgb((int)0, (int)0, (int)0));
        this.c.setAlpha(120);
        this.l = new Paint(1);
        this.l.setStyle(Paint.Style.FILL);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a() {
        com.github.mikephil.charting.data.g g2 = this.f.getBarData();
        this.k = new b[g2.a()];
        int n2 = 0;
        while (n2 < this.k.length) {
            com.github.mikephil.charting.data.h h2 = (com.github.mikephil.charting.data.h)g2.c(n2);
            b[] arrb = this.k;
            int n3 = h2.e();
            int n4 = h2.s;
            float f2 = g2.h();
            int n5 = g2.a();
            boolean bl2 = h2.s > 1;
            arrb[n2] = new b(n3 * 4 * n4, f2, n5, bl2);
            ++n2;
        }
    }

    protected void a(float f2, float f3, float f4, float f5, a a2) {
        this.j.set(f2 - 0.5f + f5, f3, 0.5f + f2 - f5, f4);
        RectF rectF = this.j;
        f2 = this.a.b;
        rectF.top *= f2;
        rectF.bottom *= f2;
        a2.a.mapRect(rectF);
        a2.c.a.mapRect(rectF);
        a2.b.mapRect(rectF);
    }

    @Override
    public final void a(Canvas canvas) {
        com.github.mikephil.charting.data.g g2 = this.f.getBarData();
        for (int i2 = 0; i2 < g2.a(); ++i2) {
            com.github.mikephil.charting.data.h h2 = (com.github.mikephil.charting.data.h)g2.c(i2);
            this.m = h2.v;
            if (!h2.i || h2.a() <= 0) continue;
            this.a(canvas, h2, i2);
        }
    }

    protected void a(Canvas canvas, com.github.mikephil.charting.data.h h2, int n2) {
        a a2 = this.f.a(h2.o);
        this.l.setColor(h2.t);
        float f2 = this.a.c;
        float f3 = this.a.b;
        List<BarEntry> list = h2.b;
        b b2 = this.k[n2];
        b2.a(f2, f3);
        b2.g = h2.r;
        b2.i = n2;
        b2.l = this.f.c(h2.o);
        b2.a(list);
        a2.a(b2.b);
        if (h2.a.size() > 1) {
            for (n2 = 0; n2 < b2.b.length; n2 += 4) {
                if (!this.g.e(b2.b[n2 + 2])) continue;
                if (this.g.f(b2.b[n2])) {
                    if (this.f.e()) {
                        canvas.drawRect(b2.b[n2], this.g.e(), b2.b[n2 + 2], this.g.h(), this.l);
                    }
                    this.b.setColor(h2.c(n2 / 4));
                    canvas.drawRect(b2.b[n2], b2.b[n2 + 1], b2.b[n2 + 2], b2.b[n2 + 3], this.b);
                    continue;
                }
                break;
            }
        } else {
            this.b.setColor(h2.a.get(0).intValue());
            for (n2 = 0; n2 < b2.b.length; n2 += 4) {
                if (!this.g.e(b2.b[n2 + 2])) continue;
                if (this.g.f(b2.b[n2])) {
                    if (this.f.e()) {
                        canvas.drawRect(b2.b[n2], this.g.e(), b2.b[n2 + 2], this.g.h(), this.l);
                    }
                    canvas.drawRect(b2.b[n2], b2.b[n2 + 1], b2.b[n2 + 2], b2.b[n2 + 3], this.b);
                    continue;
                }
                break;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(Canvas canvas, com.github.mikephil.charting.e.a[] arra) {
        int n2 = this.f.getBarData().a();
        int n3 = 0;
        while (n3 < arra.length) {
            float[] arrf = arra[n3];
            int n4 = arrf.a;
            int n5 = arrf.b;
            com.github.mikephil.charting.data.h h2 = (com.github.mikephil.charting.data.h)this.f.getBarData().c(n5);
            if (h2 != null && h2.p) {
                BarEntry barEntry;
                float f2 = h2.r / 2.0f;
                a a2 = this.f.a(h2.o);
                this.c.setColor(h2.q);
                this.c.setAlpha(h2.u);
                if (n4 >= 0 && (float)n4 < this.f.getXChartMax() * this.a.c / (float)n2 && (barEntry = (BarEntry)h2.b(n4)) != null && barEntry.e == n4) {
                    float f3;
                    float f4 = this.f.getBarData().h();
                    boolean bl2 = arrf.c >= 0;
                    float f5 = (float)(n4 * n2 + n5) + f4 / 2.0f + (float)n4 * f4;
                    if (bl2) {
                        f4 = arrf.d.a;
                        f3 = arrf.d.b;
                    } else {
                        f4 = barEntry.d;
                        f3 = 0.0f;
                    }
                    this.a(f5, f4, f3, f2, a2);
                    canvas.drawRect(this.j, this.c);
                    if (this.f.c()) {
                        this.c.setAlpha(255);
                        f3 = this.a.b * 0.07f;
                        arrf = new float[9];
                        a.b(a2).invert(a2.e);
                        a2.e.getValues(arrf);
                        float f6 = Math.abs(arrf[4] / arrf[0]);
                        f2 = h2.r / 2.0f;
                        h2 = new Path();
                        h2.moveTo(0.4f + f5, (f4 *= this.a.b) + f3);
                        h2.lineTo(0.4f + f5 + f2, f4 + f3 - (f6 *= f2));
                        h2.lineTo(f5 + 0.4f + f2, f3 + f4 + f6);
                        h2.transform(a2.a);
                        h2.transform(a2.c.a);
                        h2.transform(a2.b);
                        canvas.drawPath((Path)h2, this.c);
                    }
                }
            }
            ++n3;
        }
    }

    public float[] a(a a2, List<BarEntry> list, int n2) {
        Object object = this.f.getBarData();
        float f2 = this.a.b;
        float[] arrf = new float[list.size() * 2];
        int n3 = object.a();
        float f3 = object.h();
        for (int i2 = 0; i2 < arrf.length; i2 += 2) {
            object = list.get(i2 / 2);
            int n4 = object.e;
            float f4 = object.e + (n3 - 1) * n4 + n2;
            float f5 = n4;
            float f6 = f3 / 2.0f;
            float f7 = object.d;
            arrf[i2] = f5 * f3 + f4 + f6;
            arrf[i2 + 1] = f7 * f2;
        }
        a.b(a2).mapPoints(arrf);
        return arrf;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public void b(Canvas var1_1) {
        if (this.b() == false) return;
        var15_2 = this.f.getBarData().e();
        var8_3 = h.a(4.5f);
        var13_4 = this.f.d();
        var9_5 = 0;
        while (var9_5 < this.f.getBarData().a()) {
            var16_16 = (com.github.mikephil.charting.data.h)var15_2.get(var9_5);
            if (!var16_16.g() || var16_16.a() == 0) ** GOTO lbl84
            this.a(var16_16);
            var14_15 = this.f.c(var16_16.f());
            var4_8 = h.b(this.e, "8");
            var2_6 = var13_4 != false ? - var8_3 : var4_8 + var8_3;
            var3_7 = var13_4 != false ? var4_8 + var8_3 : - var8_3;
            if (var14_15) {
                var5_9 = - var2_6;
                var2_6 = - var3_7 - var4_8;
                var3_7 = var5_9 - var4_8;
            } else {
                var4_8 = var2_6;
                var2_6 = var3_7;
                var3_7 = var4_8;
            }
            var19_19 = this.f.a(var16_16.f());
            var17_17 = var16_16.b();
            var18_18 = this.a((a)var19_19, var17_17, var9_5);
            var10_12 = var16_16.s > 1 ? 1 : 0;
            if (var10_12 != 0) ** GOTO lbl39
            var10_12 = 0;
            while ((float)var10_12 < (float)var18_18.length * this.a.b() && this.g.f(var18_18[var10_12])) {
                if (this.g.d(var18_18[var10_12 + 1]) && this.g.e(var18_18[var10_12])) {
                    var5_9 = var17_17.get(var10_12 / 2).a();
                    var19_19 = var16_16.k();
                    var6_10 = var18_18[var10_12];
                    var7_11 = var18_18[var10_12 + 1];
                    var4_8 = var5_9 >= 0.0f ? var3_7 : var2_6;
                    this.a(var1_1, (com.github.mikephil.charting.f.c)var19_19, var5_9, var6_10, var7_11 + var4_8);
                }
                var10_12 += 2;
            }
            ** GOTO lbl84
lbl39: // 1 sources:
            var10_12 = 0;
            block2 : while ((float)var10_12 < (float)(var18_18.length - 1) * this.a.b()) {
                var20_20 = var17_17.get(var10_12 / 2);
                var21_21 = var20_20.a;
                if (var21_21 != null) ** GOTO lbl53
                if (!this.g.f(var18_18[var10_12])) break;
                if (this.g.d(var18_18[var10_12 + 1]) && this.g.e(var18_18[var10_12])) {
                    var21_21 = var16_16.k();
                    var5_9 = var20_20.a();
                    var6_10 = var18_18[var10_12];
                    var7_11 = var18_18[var10_12 + 1];
                    var4_8 = var20_20.a() >= 0.0f ? var3_7 : var2_6;
                    this.a(var1_1, (com.github.mikephil.charting.f.c)var21_21, var5_9, var6_10, var7_11 + var4_8);
                }
                ** GOTO lbl58
lbl53: // 1 sources:
                var22_22 = new float[var21_21.length * 2];
                var5_9 = 0.0f;
                var4_8 = - var20_20.b;
                var11_13 = 0;
                ** GOTO lbl61
lbl58: // 3 sources:
                do {
                    var10_12 += 2;
                    continue block2;
                    break;
                } while (true);
lbl61: // 2 sources:
                for (var12_14 = 0; var12_14 < var22_22.length; var12_14 += 2, ++var11_13) {
                    var6_10 = var21_21[var11_13];
                    if (var6_10 >= 0.0f) {
                        var6_10 = var5_9 += var6_10;
                    } else {
                        var7_11 = var4_8 - var6_10;
                        var6_10 = var4_8;
                        var4_8 = var7_11;
                    }
                    var22_22[var12_14 + 1] = var6_10 * this.a.a();
                }
                var19_19.a(var22_22);
                var11_13 = 0;
                do {
                    if (var11_13 >= var22_22.length) ** GOTO lbl58
                    var5_9 = var18_18[var10_12];
                    var6_10 = var22_22[var11_13 + 1];
                    var4_8 = var21_21[var11_13 / 2] >= 0.0f ? var3_7 : var2_6;
                    var4_8 = var6_10 + var4_8;
                    if (!this.g.f(var5_9)) ** continue;
                    if (this.g.d(var4_8) && this.g.e(var5_9)) {
                        this.a(var1_1, var16_16.k(), (float)var21_21[var11_13 / 2], var5_9, var4_8);
                    }
                    var11_13 += 2;
                } while (true);
            }
            ++var9_5;
        }
    }

    protected boolean b() {
        if ((float)this.f.getBarData().h < (float)this.f.getMaxVisibleCount() * this.g.g) {
            return true;
        }
        return false;
    }

    @Override
    public final void c(Canvas canvas) {
    }
}

