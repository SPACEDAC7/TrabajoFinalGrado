/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Path
 */
package com.github.mikephil.charting.h;

import android.graphics.Path;
import com.github.mikephil.charting.a.a;
import com.github.mikephil.charting.h.g;
import com.github.mikephil.charting.i.d;

public abstract class k
extends g {
    public Path f = new Path();

    public k(a a2, d d2) {
        super(a2, d2);
    }
}

