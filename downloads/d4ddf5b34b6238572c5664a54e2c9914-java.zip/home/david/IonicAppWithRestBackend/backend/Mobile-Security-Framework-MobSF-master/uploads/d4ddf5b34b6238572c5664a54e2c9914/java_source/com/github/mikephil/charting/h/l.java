/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.RectF
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import com.github.mikephil.charting.b.b;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.h.g;
import com.github.mikephil.charting.h.j;
import com.github.mikephil.charting.i.a;
import com.github.mikephil.charting.i.d;
import com.github.mikephil.charting.i.h;
import java.util.List;

public final class l
extends j {
    public l(com.github.mikephil.charting.d.c c2, com.github.mikephil.charting.a.a a2, d d2) {
        super(c2, a2, d2);
        this.e.setTextAlign(Paint.Align.LEFT);
    }

    private void a(Canvas canvas, String string, float f2, float f3, int n2) {
        if (this.m) {
            this.e.setColor(n2);
        }
        canvas.drawText(string, f2, f3, this.e);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a() {
        com.github.mikephil.charting.data.g g2 = this.f.getBarData();
        this.k = new com.github.mikephil.charting.b.c[g2.a()];
        int n2 = 0;
        while (n2 < this.k.length) {
            com.github.mikephil.charting.data.h h2 = (com.github.mikephil.charting.data.h)g2.c(n2);
            b[] arrb = this.k;
            int n3 = h2.e();
            int n4 = h2.s;
            float f2 = g2.h();
            int n5 = g2.a();
            boolean bl2 = h2.s > 1;
            arrb[n2] = new com.github.mikephil.charting.b.c(n3 * 4 * n4, f2, n5, bl2);
            ++n2;
        }
    }

    @Override
    protected final void a(float f2, float f3, float f4, float f5, a a2) {
        this.j.set(f3, f2 - 0.5f + f5, f4, 0.5f + f2 - f5);
        RectF rectF = this.j;
        f2 = this.a.b;
        rectF.left *= f2;
        rectF.right *= f2;
        a2.a.mapRect(rectF);
        a2.c.a.mapRect(rectF);
        a2.b.mapRect(rectF);
    }

    @Override
    protected final void a(Canvas canvas, com.github.mikephil.charting.data.h h2, int n2) {
        a a2 = this.f.a(h2.o);
        this.l.setColor(h2.t);
        float f2 = this.a.c;
        float f3 = this.a.b;
        List<BarEntry> list = h2.b;
        b b2 = this.k[n2];
        b2.a(f2, f3);
        b2.g = h2.r;
        b2.i = n2;
        b2.l = this.f.c(h2.o);
        b2.a(list);
        a2.a(b2.b);
        for (n2 = 0; n2 < b2.b.length && this.g.g(b2.b[n2 + 3]); n2 += 4) {
            if (!this.g.h(b2.b[n2 + 1])) continue;
            if (this.f.e()) {
                canvas.drawRect(this.g.f(), b2.b[n2 + 1], this.g.g(), b2.b[n2 + 3], this.l);
            }
            this.b.setColor(h2.c(n2 / 4));
            canvas.drawRect(b2.b[n2], b2.b[n2 + 1], b2.b[n2 + 2], b2.b[n2 + 3], this.b);
        }
    }

    @Override
    public final float[] a(a a2, List<BarEntry> list, int n2) {
        Object object = this.f.getBarData();
        float f2 = this.a.b;
        float[] arrf = new float[list.size() * 2];
        int n3 = object.a();
        float f3 = object.h();
        for (int i2 = 0; i2 < arrf.length; i2 += 2) {
            object = list.get(i2 / 2);
            int n4 = object.e;
            float f4 = (n3 - 1) * n4 + n4 + n2;
            float f5 = n4;
            float f6 = f3 / 2.0f;
            arrf[i2] = object.d * f2;
            arrf[i2 + 1] = f5 * f3 + f4 + f6;
        }
        a.b(a2).mapPoints(arrf);
        return arrf;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void b(Canvas var1_1) {
        if (this.b() == false) return;
        var16_2 = this.f.getBarData().e();
        var2_3 = h.a(5.0f);
        var14_4 = this.f.d();
        var10_5 = 0;
        while (var10_5 < this.f.getBarData().a()) {
            var17_17 = (com.github.mikephil.charting.data.h)var16_2.get(var10_5);
            if (!var17_17.g() || var17_17.a() == 0) ** GOTO lbl100
            var15_16 = this.f.c(var17_17.f());
            this.a(var17_17);
            var7_10 = (float)h.b(this.e, "10") / 2.0f;
            var18_18 = var17_17.k();
            var21_21 = this.f.a(var17_17.f());
            var19_19 = var17_17.b();
            var20_20 = this.a((a)var21_21, var19_19, var10_5);
            var11_13 = var17_17.s > 1 ? 1 : 0;
            if (var11_13 != 0) ** GOTO lbl38
            var11_13 = 0;
            while ((float)var11_13 < (float)var20_20.length * this.a.b() && this.g.g(var20_20[var11_13 + 1])) {
                if (this.g.c(var20_20[var11_13]) && this.g.h(var20_20[var11_13 + 1])) {
                    var8_11 = var19_19.get(var11_13 / 2).a();
                    var21_21 = var18_18.b((float)var8_11);
                    var9_12 = h.a(this.e, (String)var21_21);
                    var3_6 = var14_4 != false ? var2_3 : - var9_12 + var2_3;
                    var5_8 = var14_4 != false ? - var9_12 + var2_3 : var2_3;
                    var6_9 = var5_8;
                    var4_7 = var3_6;
                    if (var15_16) {
                        var4_7 = - var3_6 - var9_12;
                        var6_9 = - var5_8 - var9_12;
                    }
                    var3_6 = var20_20[var11_13];
                    if (var8_11 < 0.0f) {
                        var4_7 = var6_9;
                    }
                    this.a(var1_1, (String)var21_21, (float)(var3_6 + var4_7), var20_20[var11_13 + 1] + var7_10, var17_17.h().get(var11_13 / 2));
                }
                var11_13 += 2;
            }
            ** GOTO lbl100
lbl38: // 1 sources:
            var11_13 = 0;
            block2 : while ((float)var11_13 < (float)(var20_20.length - 1) * this.a.b()) {
                var22_22 = var19_19.get(var11_13 / 2);
                var23_23 = var22_22.a;
                if (var23_23 != null) ** GOTO lbl59
                if (!this.g.g(var20_20[var11_13 + 1])) break;
                if (this.g.c(var20_20[var11_13]) && this.g.h(var20_20[var11_13 + 1])) {
                    var23_23 = var18_18.b(var22_22.a());
                    var8_11 = h.a(this.e, (String)var23_23);
                    var3_6 = var14_4 != false ? var2_3 : (Object)(- var8_11 + var2_3);
                    var5_8 = var14_4 != false ? (Object)(- var8_11 + var2_3) : var2_3;
                    var6_9 = var5_8;
                    var4_7 = var3_6;
                    if (var15_16) {
                        var4_7 = - var3_6 - var8_11;
                        var6_9 = - var5_8 - var8_11;
                    }
                    var3_6 = var20_20[var11_13];
                    if (var22_22.a() < 0.0f) {
                        var4_7 = var6_9;
                    }
                    this.a(var1_1, (String)var23_23, (float)(var4_7 + var3_6), var20_20[var11_13 + 1] + var7_10, var17_17.h().get(var11_13 / 2));
                }
                ** GOTO lbl64
lbl59: // 1 sources:
                var24_24 = new float[var23_23.length * 2];
                var4_7 = 0.0f;
                var3_6 = - var22_22.b;
                var12_14 = 0;
                ** GOTO lbl67
lbl64: // 3 sources:
                do {
                    var11_13 += 2;
                    continue block2;
                    break;
                } while (true);
lbl67: // 2 sources:
                for (var13_15 = 0; var13_15 < var24_24.length; var13_15 += 2, ++var12_14) {
                    var5_8 = var23_23[var12_14];
                    if (var5_8 >= 0.0f) {
                        var5_8 = var4_7 += var5_8;
                    } else {
                        var6_9 = var3_6 - var5_8;
                        var5_8 = var3_6;
                        var3_6 = var6_9;
                    }
                    var24_24[var13_15] = var5_8 * this.a.a();
                }
                var21_21.a(var24_24);
                var12_14 = 0;
                do {
                    if (var12_14 >= var24_24.length) ** GOTO lbl64
                    var8_11 = var23_23[var12_14 / 2];
                    var22_22 = var18_18.b((float)var8_11);
                    var9_12 = h.a(this.e, (String)var22_22);
                    var3_6 = var14_4 != false ? (Object)var2_3 : (Object)(- var9_12 + var2_3);
                    var5_8 = var14_4 != false ? (Object)(- var9_12 + var2_3) : (Object)var2_3;
                    var6_9 = var5_8;
                    var4_7 = var3_6;
                    if (var15_16) {
                        var4_7 = - var3_6 - var9_12;
                        var6_9 = - var5_8 - var9_12;
                    }
                    var3_6 = var24_24[var12_14];
                    if (var8_11 < 0.0f) {
                        var4_7 = var6_9;
                    }
                    var3_6 += var4_7;
                    if (!this.g.g((float)(var4_7 = (Object)var20_20[var11_13 + 1]))) ** continue;
                    if (this.g.c((float)var3_6) && this.g.h((float)var4_7)) {
                        this.a(var1_1, (String)var22_22, (float)var3_6, (float)(var4_7 + var7_10), var17_17.h().get(var11_13 / 2));
                    }
                    var12_14 += 2;
                } while (true);
            }
            ++var10_5;
        }
    }

    @Override
    protected final boolean b() {
        if ((float)this.f.getBarData().h < (float)this.f.getMaxVisibleCount() * this.g.h) {
            return true;
        }
        return false;
    }
}

