/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.Paint$Style
 *  android.graphics.PointF
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.PorterDuffXfermode
 *  android.graphics.RectF
 *  android.graphics.Xfermode
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.SpannableString
 *  android.text.StaticLayout
 *  android.text.TextPaint
 */
package com.github.mikephil.charting.h;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Xfermode;
import android.text.Layout;
import android.text.SpannableString;
import android.text.StaticLayout;
import android.text.TextPaint;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.charts.d;
import com.github.mikephil.charting.charts.e;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.b;
import com.github.mikephil.charting.data.l;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.h.g;
import com.github.mikephil.charting.i.h;
import java.util.List;

public final class m
extends g {
    protected PieChart f;
    public Paint j;
    public Paint k;
    protected Paint l;
    public TextPaint m;
    public Bitmap n;
    protected Canvas o;
    private StaticLayout p;
    private SpannableString q;
    private RectF r = new RectF();
    private RectF[] s = new RectF[]{new RectF(), new RectF(), new RectF()};

    public m(PieChart pieChart, com.github.mikephil.charting.a.a a2, com.github.mikephil.charting.i.d d2) {
        super(a2, d2);
        this.f = pieChart;
        this.j = new Paint(1);
        this.j.setColor(-1);
        this.j.setStyle(Paint.Style.FILL);
        this.k = new Paint(1);
        this.k.setColor(-1);
        this.k.setStyle(Paint.Style.FILL);
        this.k.setAlpha(105);
        this.m = new TextPaint(1);
        this.m.setColor(-16777216);
        this.m.setTextSize(h.a(12.0f));
        this.e.setTextSize(h.a(13.0f));
        this.e.setColor(-1);
        this.e.setTextAlign(Paint.Align.CENTER);
        this.l = new Paint(1);
        this.l.setStyle(Paint.Style.STROKE);
        this.l.setColor(-1);
        this.l.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(com.github.mikephil.charting.data.m m2) {
        float f2;
        float f3;
        float f4 = m2.q;
        this.l.setStrokeWidth(f4);
        PointF pointF = this.f.getCenterOffsets();
        float f5 = this.f.a;
        List list = m2.b;
        float[] arrf = this.f.j;
        for (int i2 = 0; i2 < list.size(); ++i2, f5 += f3 * f2) {
            PieChart pieChart;
            f2 = this.f.p ? - arrf[i2] : arrf[i2];
            Object object = (Entry)list.get(i2);
            if ((double)Math.abs(object.d) > 1.0E-6) {
                int n2;
                int n3;
                block7 : {
                    pieChart = this.f;
                    n2 = object.e;
                    object = (l)this.f.y;
                    for (n3 = 0; n3 < object.m.size(); ++n3) {
                        if (object.m.get(n3) != m2) {
                            continue;
                        }
                        break block7;
                    }
                    n3 = -1;
                }
                if (!pieChart.a(n2, n3)) {
                    this.b.setColor(m2.c(i2));
                    this.o.drawArc(this.f.i, this.a.b * f5, this.a.b * f2, true, this.b);
                }
            }
            if (f4 > 0.0f && m2.a() > 1) {
                pieChart = h.a(pointF, this.f.getRadius(), this.a.b * f5);
                this.o.drawLine(pointF.x, pointF.y, pieChart.x, pieChart.y, this.l);
            }
            f3 = this.a.c;
        }
        if (f4 > 0.0f && m2.a() > 1) {
            m2 = h.a(pointF, this.f.getRadius(), this.a.b * f5);
            this.o.drawLine(pointF.x, pointF.y, m2.x, m2.y, this.l);
        }
    }

    @Override
    public final void a() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void a(Canvas iterator) {
        int n2 = (int)this.g.c;
        int n3 = (int)this.g.d;
        if (this.n == null || this.n.getWidth() != n2 || this.n.getHeight() != n3) {
            if (n2 <= 0 || n3 <= 0) return;
            this.n = Bitmap.createBitmap((int)n2, (int)n3, (Bitmap.Config)Bitmap.Config.ARGB_4444);
            this.o = new Canvas(this.n);
        }
        this.n.eraseColor(0);
        for (com.github.mikephil.charting.data.m m2 : ((l)this.f.y).m) {
            if (!m2.i || m2.a() <= 0) continue;
            this.a(m2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(Canvas arrf, a[] arra) {
        float f2 = this.f.getRotationAngle();
        arrf = this.f.getDrawAngles();
        float[] arrf2 = this.f.getAbsoluteAngles();
        int n2 = 0;
        while (n2 < arra.length) {
            com.github.mikephil.charting.data.m m2;
            int n3 = arra[n2].a;
            if (n3 < arrf.length && (m2 = ((l)this.f.getData()).d(arra[n2].b)) != null && m2.j()) {
                float f3 = n3 == 0 ? f2 : arrf2[n3 - 1] + f2;
                float f4 = this.a.a();
                float f5 = arrf[n3];
                float f6 = m2.r;
                RectF rectF = this.f.getCircleBox();
                rectF = new RectF(rectF.left - f6, rectF.top - f6, rectF.right + f6, f6 + rectF.bottom);
                this.b.setColor(m2.c(n3));
                this.o.drawArc(rectF, f3 * f4, this.a.a() * f5, true, this.b);
            }
            ++n2;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void b(Canvas var1_1) {
        var14_2 = this.f.getCenterCircleBox();
        var4_3 = this.f.getRadius();
        var3_4 = this.f.getRotationAngle();
        var15_5 = this.f.getDrawAngles();
        var16_6 = this.f.getAbsoluteAngles();
        var2_7 = var4_3 / 10.0f * 3.6f;
        if (this.f.b) {
            var2_7 = (var4_3 - var4_3 / 100.0f * this.f.getHoleRadius()) / 2.0f;
        }
        var4_3 -= var2_7;
        var17_8 = (l)this.f.getData();
        var18_9 = var17_8.e();
        var12_10 = this.f.a;
        var8_11 = 0;
        var9_12 = 0;
        while (var9_12 < var18_9.size()) {
            var19_19 = (com.github.mikephil.charting.data.m)var18_9.get(var9_12);
            if (var19_19.g()) ** GOTO lbl-1000
            var10_16 = var8_11;
            if (var12_10) lbl-1000: // 2 sources:
            {
                this.a(var19_19);
                var5_13 = (float)h.b(this.e, "Q") + h.a(4.0f);
                var20_20 = var19_19.b();
                var11_17 = Math.min((int)Math.ceil((float)var20_20.size() * this.a.b()), var20_20.size());
                for (var10_16 = 0; var10_16 < var11_17; ++var8_11, ++var10_16) {
                    var21_21 = (Entry)var20_20.get(var10_16);
                    var2_7 = var15_5[var8_11] / 2.0f;
                    var6_14 = (float)((double)var4_3 * Math.cos(Math.toRadians((var16_6[var8_11] + var3_4 - var2_7) * this.a.a())) + (double)var14_2.x);
                    var7_15 = (float)((double)var4_3 * Math.sin(Math.toRadians((var16_6[var8_11] + var3_4 - var2_7) * this.a.a())) + (double)var14_2.y);
                    var2_7 = this.f.c != false ? var21_21.a() / var17_8.g * 100.0f : var21_21.a();
                    var21_21 = var19_19.k();
                    var13_18 = var19_19.g();
                    if (var12_10 && var13_18) {
                        this.a(var1_1, (com.github.mikephil.charting.f.c)var21_21, var2_7, var6_14, var7_15);
                        if (var10_16 >= var17_8.f()) continue;
                        var1_1.drawText(var17_8.d().get(var10_16), var6_14, var7_15 + var5_13, this.e);
                        continue;
                    }
                    if (var12_10 && !var13_18) {
                        if (var10_16 >= var17_8.f()) continue;
                        var1_1.drawText(var17_8.d().get(var10_16), var6_14, var5_13 / 2.0f + var7_15, this.e);
                        continue;
                    }
                    if (var12_10 || !var13_18) continue;
                    this.a(var1_1, (com.github.mikephil.charting.f.c)var21_21, var2_7, var6_14, var7_15 + var5_13 / 2.0f);
                }
                var10_16 = var8_11;
            }
            ++var9_12;
            var8_11 = var10_16;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void c(Canvas canvas) {
        SpannableString spannableString;
        float f2;
        float f3;
        float f4;
        if (this.f.b) {
            f2 = this.f.d;
            f4 = this.f.n;
            f3 = this.f.getRadius();
            spannableString = this.f.getCenterCircleBox();
            if (f2 > f4) {
                int n2 = this.k.getAlpha();
                this.k.setAlpha((int)((float)n2 * this.a.c * this.a.b));
                this.o.drawCircle(spannableString.x, spannableString.y, f2 * (f3 / 100.0f), this.k);
                this.k.setAlpha(n2);
            }
            this.o.drawCircle(spannableString.x, spannableString.y, f4 * (f3 / 100.0f), this.j);
        }
        canvas.drawBitmap(this.n, 0.0f, 0.0f, this.b);
        spannableString = this.f.m;
        if (this.f.e && spannableString != null) {
            PointF pointF = this.f.getCenterCircleBox();
            f2 = this.f.b && this.f.c() ? this.f.getRadius() * (this.f.n / 100.0f) : this.f.getRadius();
            RectF rectF = this.s[0];
            rectF.left = pointF.x - f2;
            rectF.top = pointF.y - f2;
            rectF.right = pointF.x + f2;
            rectF.bottom = f2 + pointF.y;
            pointF = this.s[1];
            pointF.set(rectF);
            f2 = this.f.o;
            if ((double)f2 > 0.0) {
                pointF.inset((pointF.width() - pointF.width() * f2) / 2.0f, (pointF.height() - f2 * pointF.height()) / 2.0f);
            }
            if (!spannableString.equals((Object)this.q) || !pointF.equals((Object)this.r)) {
                this.r.set((RectF)pointF);
                this.q = spannableString;
                f2 = this.r.width();
                this.p = new StaticLayout((CharSequence)spannableString, 0, spannableString.length(), this.m, (int)Math.max(Math.ceil(f2), 1.0), Layout.Alignment.ALIGN_CENTER, 1.0f, 0.0f, false);
            }
            f2 = this.p.getHeight();
            canvas.save();
            f4 = pointF.left;
            f3 = pointF.top;
            canvas.translate(f4, (pointF.height() - f2) / 2.0f + f3);
            this.p.draw(canvas);
            canvas.restore();
        }
    }
}

