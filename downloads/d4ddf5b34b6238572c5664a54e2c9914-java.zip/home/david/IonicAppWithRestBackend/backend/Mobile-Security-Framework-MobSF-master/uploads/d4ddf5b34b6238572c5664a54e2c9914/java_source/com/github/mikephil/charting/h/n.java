/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.DashPathEffect
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.PathEffect
 *  android.graphics.PointF
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PointF;
import com.github.mikephil.charting.charts.d;
import com.github.mikephil.charting.charts.e;
import com.github.mikephil.charting.charts.f;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.b;
import com.github.mikephil.charting.data.i;
import com.github.mikephil.charting.data.j;
import com.github.mikephil.charting.data.o;
import com.github.mikephil.charting.e.a;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.h.g;
import com.github.mikephil.charting.h.k;
import com.github.mikephil.charting.i.h;
import java.util.Iterator;
import java.util.List;

public final class n
extends k {
    protected f f;
    protected Paint j;

    public n(f f2, com.github.mikephil.charting.a.a a2, com.github.mikephil.charting.i.d d2) {
        super(a2, d2);
        this.f = f2;
        this.c = new Paint(1);
        this.c.setStyle(Paint.Style.STROKE);
        this.c.setStrokeWidth(2.0f);
        this.c.setColor(Color.rgb((int)255, (int)187, (int)115));
        this.j = new Paint(1);
        this.j.setStyle(Paint.Style.STROKE);
    }

    @Override
    public final void a() {
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(Canvas canvas) {
        Iterator iterator = ((com.github.mikephil.charting.data.n)this.f.y).m.iterator();
        while (iterator.hasNext()) {
            o o2 = (o)iterator.next();
            if (!o2.i || o2.a() <= 0) continue;
            float f2 = this.f.getSliceAngle();
            float f3 = this.f.getFactor();
            PointF pointF = this.f.getCenterOffsets();
            List list = o2.b;
            Path path = new Path();
            boolean bl2 = false;
            for (int i2 = 0; i2 < list.size(); ++i2) {
                this.b.setColor(o2.c(i2));
                PointF pointF2 = h.a(pointF, (((Entry)list.get((int)i2)).d - this.f.getYChartMin()) * f3, (float)i2 * f2 + this.f.getRotationAngle());
                boolean bl3 = bl2;
                if (!Float.isNaN(pointF2.x)) {
                    if (!bl2) {
                        path.moveTo(pointF2.x, pointF2.y);
                        bl3 = true;
                    } else {
                        path.lineTo(pointF2.x, pointF2.y);
                        bl3 = bl2;
                    }
                }
                bl2 = bl3;
            }
            path.close();
            if (o2.x) {
                this.b.setStyle(Paint.Style.FILL);
                this.b.setAlpha(o2.v);
                canvas.drawPath(path, this.b);
                this.b.setAlpha(255);
            }
            this.b.setStrokeWidth(o2.w);
            this.b.setStyle(Paint.Style.STROKE);
            if (o2.x && o2.v >= 255) continue;
            canvas.drawPath(path, this.b);
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(Canvas canvas, a[] arra) {
        float f2 = this.f.getSliceAngle();
        float f3 = this.f.getFactor();
        PointF pointF = this.f.getCenterOffsets();
        int n2 = 0;
        while (n2 < arra.length) {
            int n3;
            Object object;
            o o2 = (o)((com.github.mikephil.charting.data.n)this.f.y).c(arra[n2].b);
            if (o2 != null && o2.p && (object = o2.b(n3 = arra[n2].a)) != null && object.e == n3) {
                int n4;
                float f4;
                float[] arrf;
                block7 : {
                    for (n4 = 0; n4 < o2.b.size(); ++n4) {
                        arrf = (float[])o2.b.get(n4);
                        n3 = arrf == null ? 0 : (arrf.f != object.f ? 0 : (arrf.e != object.e ? 0 : (Math.abs(arrf.d - object.d) > 1.0E-5f ? 0 : 1)));
                        if (n3 == 0) {
                            continue;
                        }
                        break block7;
                    }
                    n4 = -1;
                }
                if (!Float.isNaN(f4 = object.d - this.f.getYChartMin())) {
                    object = h.a(pointF, f4 * f3, (float)n4 * f2 + this.f.a);
                    arrf = new float[]{object.x, object.y};
                    this.c.setColor(o2.q);
                    this.c.setStrokeWidth(o2.t);
                    this.c.setPathEffect((PathEffect)o2.u);
                    if (o2.r) {
                        this.f.reset();
                        this.f.moveTo(arrf[0], this.g.e());
                        this.f.lineTo(arrf[0], this.g.h());
                        canvas.drawPath(this.f, this.c);
                    }
                    if (o2.s) {
                        this.f.reset();
                        this.f.moveTo(this.g.f(), arrf[1]);
                        this.f.lineTo(this.g.g(), arrf[1]);
                        canvas.drawPath(this.f, this.c);
                    }
                }
            }
            ++n2;
        }
    }

    @Override
    public final void b(Canvas canvas) {
        float f2 = this.f.getSliceAngle();
        float f3 = this.f.getFactor();
        PointF pointF = this.f.getCenterOffsets();
        float f4 = h.a(5.0f);
        for (int i2 = 0; i2 < ((com.github.mikephil.charting.data.n)this.f.y).a(); ++i2) {
            o o2 = (o)((com.github.mikephil.charting.data.n)this.f.y).c(i2);
            if (!o2.j || o2.a() == 0) continue;
            this.a(o2);
            List list = o2.b;
            for (int i3 = 0; i3 < list.size(); ++i3) {
                Entry entry = (Entry)list.get(i3);
                PointF pointF2 = h.a(pointF, (entry.d - this.f.getYChartMin()) * f3, (float)i3 * f2 + this.f.a);
                this.a(canvas, o2.k(), entry.d, pointF2.x, pointF2.y - f4);
            }
        }
    }

    @Override
    public final void c(Canvas canvas) {
        PointF pointF;
        int n2;
        float f2 = this.f.getSliceAngle();
        float f3 = this.f.getFactor();
        float f4 = this.f.a;
        PointF pointF2 = this.f.getCenterOffsets();
        this.j.setStrokeWidth(this.f.c);
        this.j.setColor(this.f.e);
        this.j.setAlpha(this.f.i);
        int n3 = this.f.k;
        for (n2 = 0; n2 < ((com.github.mikephil.charting.data.n)this.f.y).f(); n2 += n3 + 1) {
            pointF = h.a(pointF2, this.f.getYRange() * f3, (float)n2 * f2 + f4);
            canvas.drawLine(pointF2.x, pointF2.y, pointF.x, pointF.y, this.j);
        }
        this.j.setStrokeWidth(this.f.d);
        this.j.setColor(this.f.f);
        this.j.setAlpha(this.f.i);
        int n4 = this.f.l.c;
        for (n2 = 0; n2 < n4; ++n2) {
            for (n3 = 0; n3 < ((com.github.mikephil.charting.data.n)this.f.y).f(); ++n3) {
                float f5 = (this.f.l.b[n2] - this.f.getYChartMin()) * f3;
                pointF = h.a(pointF2, f5, (float)n3 * f2 + f4);
                PointF pointF3 = h.a(pointF2, f5, (float)(n3 + 1) * f2 + f4);
                canvas.drawLine(pointF.x, pointF.y, pointF3.x, pointF3.y, this.j);
            }
        }
    }
}

