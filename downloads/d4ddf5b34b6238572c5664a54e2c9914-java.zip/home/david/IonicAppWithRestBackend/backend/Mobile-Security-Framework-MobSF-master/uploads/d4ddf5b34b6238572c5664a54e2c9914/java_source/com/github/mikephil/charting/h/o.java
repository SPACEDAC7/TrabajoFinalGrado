/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.PointF
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.c.k;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.g;
import com.github.mikephil.charting.h.b;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.h.d;
import com.github.mikephil.charting.i.a;
import com.github.mikephil.charting.i.h;
import java.util.List;

public class o
extends d {
    protected BarChart k;

    public o(com.github.mikephil.charting.i.d d2, k k2, a a2, BarChart barChart) {
        super(d2, k2, a2);
        this.k = barChart;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void a(Canvas canvas, float f2, PointF pointF) {
        float[] arrf;
        float f3 = this.a.f;
        float[] arrf2 = arrf = new float[2];
        arrf2[0] = 0.0f;
        arrf2[1] = 0.0f;
        g g2 = (g)this.k.y;
        int n2 = g2.a();
        int n3 = this.h;
        while (n3 <= this.i) {
            arrf[0] = (float)(n3 * n2) + (float)n3 * g2.h() + g2.h() / 2.0f;
            if (n2 > 1) {
                arrf[0] = arrf[0] + ((float)n2 - 1.0f) / 2.0f;
            }
            this.b.a(arrf);
            if (this.g.c(arrf[0]) && n3 >= 0 && n3 < this.a.a.size()) {
                String string = this.a.a.get(n3);
                if (this.a.k) {
                    float f4;
                    if (n3 == this.a.a.size() - 1) {
                        f4 = h.a(this.d, string);
                        if (arrf[0] + f4 / 2.0f > this.g.g()) {
                            arrf[0] = this.g.g() - f4 / 2.0f;
                        }
                    } else if (n3 == 0 && arrf[0] - (f4 = (float)h.a(this.d, string)) / 2.0f < this.g.f()) {
                        float f5 = this.g.f();
                        arrf[0] = f4 / 2.0f + f5;
                    }
                }
                this.a(canvas, string, arrf[0], f2, pointF, f3);
            }
            n3 = this.a.h + n3;
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void c(Canvas canvas) {
        if (this.a.x && this.a.D) {
            float[] arrf;
            float[] arrf2 = arrf = new float[2];
            arrf2[0] = 0.0f;
            arrf2[1] = 0.0f;
            this.c.setColor(this.a.t);
            this.c.setStrokeWidth(this.a.u);
            g g2 = (g)this.k.y;
            int n2 = g2.a();
            int n3 = this.h;
            while (n3 < this.i) {
                arrf[0] = (float)(n3 * n2) + (float)n3 * g2.h() - 0.5f;
                this.b.a(arrf);
                if (this.g.c(arrf[0])) {
                    canvas.drawLine(arrf[0], this.g.c(), arrf[0], this.g.h(), this.c);
                }
                n3 = this.a.h + n3;
            }
        }
    }
}

