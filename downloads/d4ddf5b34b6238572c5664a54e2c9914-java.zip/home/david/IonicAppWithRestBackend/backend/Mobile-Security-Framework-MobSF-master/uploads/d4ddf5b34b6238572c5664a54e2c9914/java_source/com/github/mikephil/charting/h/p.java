/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.DashPathEffect
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.PathEffect
 *  android.graphics.PointF
 *  android.graphics.Typeface
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PointF;
import android.graphics.Typeface;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.c.j;
import com.github.mikephil.charting.c.k;
import com.github.mikephil.charting.c.l;
import com.github.mikephil.charting.c.m;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.g;
import com.github.mikephil.charting.h.b;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.h.d;
import com.github.mikephil.charting.h.o;
import com.github.mikephil.charting.i.a;
import com.github.mikephil.charting.i.h;
import java.util.List;

public final class p
extends o {
    public p(com.github.mikephil.charting.i.d d2, k k2, a a2, BarChart barChart) {
        super(d2, k2, a2, barChart);
    }

    @Override
    public final void a(float f2, List<String> object) {
        this.d.setTypeface(this.a.G);
        this.d.setTextSize(this.a.H);
        this.a.a = object;
        k k2 = this.a;
        object = "";
        for (int i2 = 0; i2 < k2.a.size(); ++i2) {
            String string = k2.a.get(i2);
            if (object.length() >= string.length()) continue;
            object = string;
        }
        object = h.c(this.d, (String)object);
        f2 = (int)(object.a + this.a.E * 3.5f);
        float f3 = object.b;
        object = h.a(object.a, f3, this.a.f);
        this.a.b = Math.round(f2);
        this.a.c = Math.round(f3);
        this.a.d = (int)(object.a + this.a.E * 3.5f);
        this.a.e = Math.round(object.b);
    }

    @Override
    public final void a(Canvas canvas) {
        if (!this.a.D || !this.a.z) {
            return;
        }
        float f2 = this.a.E;
        this.d.setTypeface(this.a.G);
        this.d.setTextSize(this.a.H);
        this.d.setColor(this.a.I);
        if (this.a.m == j.a) {
            this.a(canvas, f2 + this.g.g(), new PointF(0.0f, 0.5f));
            return;
        }
        if (this.a.m == j.d) {
            this.a(canvas, this.g.g() - f2, new PointF(1.0f, 0.5f));
            return;
        }
        if (this.a.m == j.b) {
            this.a(canvas, this.g.f() - f2, new PointF(1.0f, 0.5f));
            return;
        }
        if (this.a.m == j.e) {
            this.a(canvas, f2 + this.g.f(), new PointF(0.0f, 0.5f));
            return;
        }
        this.a(canvas, this.g.g() + f2, new PointF(0.0f, 0.5f));
        this.a(canvas, this.g.f() - f2, new PointF(1.0f, 0.5f));
    }

    @Override
    protected final void a(Canvas canvas, float f2, PointF pointF) {
        float[] arrf;
        float f3 = this.a.f;
        float[] arrf2 = arrf = new float[2];
        arrf2[0] = 0.0f;
        arrf2[1] = 0.0f;
        g g2 = (g)this.k.y;
        int n2 = g2.a();
        int n3 = this.h;
        while (n3 <= this.i) {
            arrf[1] = (float)(n3 * n2) + (float)n3 * g2.h() + g2.h() / 2.0f;
            if (n2 > 1) {
                arrf[1] = arrf[1] + ((float)n2 - 1.0f) / 2.0f;
            }
            this.b.a(arrf);
            if (this.g.d(arrf[1])) {
                this.a(canvas, this.a.a.get(n3), f2, arrf[1], pointF, f3);
            }
            n3 = this.a.h + n3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void b(Canvas canvas) {
        if (!this.a.y) return;
        if (!this.a.D) {
            return;
        }
        this.e.setColor(this.a.v);
        this.e.setStrokeWidth(this.a.w);
        if (this.a.m == j.a || this.a.m == j.d || this.a.m == j.c) {
            canvas.drawLine(this.g.g(), this.g.e(), this.g.g(), this.g.h(), this.e);
        }
        if (this.a.m != j.b && this.a.m != j.e) {
            if (this.a.m != j.c) return;
        }
        canvas.drawLine(this.g.f(), this.g.e(), this.g.f(), this.g.h(), this.e);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void c(Canvas canvas) {
        if (this.a.x && this.a.D) {
            float[] arrf;
            float[] arrf2 = arrf = new float[2];
            arrf2[0] = 0.0f;
            arrf2[1] = 0.0f;
            this.c.setColor(this.a.t);
            this.c.setStrokeWidth(this.a.u);
            g g2 = (g)this.k.y;
            int n2 = g2.a();
            int n3 = this.h;
            while (n3 <= this.i) {
                arrf[1] = (float)(n3 * n2) + (float)n3 * g2.h() - 0.5f;
                this.b.a(arrf);
                if (this.g.d(arrf[1])) {
                    canvas.drawLine(this.g.f(), arrf[1], this.g.g(), arrf[1], this.c);
                }
                n3 = this.a.h + n3;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void d(Canvas canvas) {
        List<m> list = this.a.B;
        if (list == null || list.size() <= 0) {
            return;
        }
        float[] arrf = new float[2];
        Path path = new Path();
        int n2 = 0;
        while (n2 < list.size()) {
            m m2 = list.get(n2);
            if (m2.D) {
                this.f.setStyle(Paint.Style.STROKE);
                this.f.setColor(m2.c);
                this.f.setStrokeWidth(m2.b);
                this.f.setPathEffect((PathEffect)m2.f);
                arrf[1] = m2.a;
                this.b.a(arrf);
                path.moveTo(this.g.f(), arrf[1]);
                path.lineTo(this.g.g(), arrf[1]);
                canvas.drawPath(path, this.f);
                path.reset();
                String string = m2.e;
                if (string != null && !string.equals("")) {
                    this.f.setStyle(m2.d);
                    this.f.setPathEffect(null);
                    this.f.setColor(m2.I);
                    this.f.setStrokeWidth(0.5f);
                    this.f.setTextSize(m2.H);
                    float f2 = h.b(this.f, string);
                    float f3 = h.a(4.0f) + m2.E;
                    float f4 = m2.b + f2 + m2.F;
                    int n3 = m2.g;
                    if (n3 == l.c) {
                        this.f.setTextAlign(Paint.Align.RIGHT);
                        canvas.drawText(string, this.g.g() - f3, f2 + (arrf[1] - f4), this.f);
                    } else if (n3 == l.d) {
                        this.f.setTextAlign(Paint.Align.RIGHT);
                        canvas.drawText(string, this.g.g() - f3, arrf[1] + f4, this.f);
                    } else if (n3 == l.a) {
                        this.f.setTextAlign(Paint.Align.LEFT);
                        canvas.drawText(string, this.g.f() + f3, f2 + (arrf[1] - f4), this.f);
                    } else {
                        this.f.setTextAlign(Paint.Align.LEFT);
                        canvas.drawText(string, this.g.a() + f3, arrf[1] + f4, this.f);
                    }
                }
            }
            ++n2;
        }
    }
}

