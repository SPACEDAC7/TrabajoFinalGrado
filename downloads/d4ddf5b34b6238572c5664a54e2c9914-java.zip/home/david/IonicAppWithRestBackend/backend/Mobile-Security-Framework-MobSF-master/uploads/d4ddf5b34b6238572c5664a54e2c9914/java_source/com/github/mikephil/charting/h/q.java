/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.DashPathEffect
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.PathEffect
 *  android.graphics.Typeface
 */
package com.github.mikephil.charting.h;

import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.Typeface;
import com.github.mikephil.charting.c.d;
import com.github.mikephil.charting.c.e;
import com.github.mikephil.charting.c.l;
import com.github.mikephil.charting.c.m;
import com.github.mikephil.charting.h.a;
import com.github.mikephil.charting.h.b;
import com.github.mikephil.charting.h.c;
import com.github.mikephil.charting.i.h;
import java.util.List;

public final class q
extends a {
    public q(com.github.mikephil.charting.i.d d2, com.github.mikephil.charting.c.c c2, com.github.mikephil.charting.i.a a2) {
        super(d2, c2, a2);
        this.f.setTextAlign(Paint.Align.LEFT);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(float f2, float f3) {
        float f4 = f2;
        float f5 = f3;
        if (this.g.j() > 10.0f) {
            f4 = f2;
            f5 = f3;
            if (!this.g.q()) {
                com.github.mikephil.charting.i.b b2 = this.b.a(this.g.f(), this.g.e());
                com.github.mikephil.charting.i.b b3 = this.b.a(this.g.g(), this.g.e());
                if (!this.a.h) {
                    f4 = (float)b2.a;
                    f5 = (float)b3.a;
                } else {
                    f4 = (float)b3.a;
                    f5 = (float)b2.a;
                }
            }
        }
        this.b(f4, f5);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void a(Canvas canvas) {
        int n2;
        if (!this.a.D || !this.a.z) {
            return;
        }
        float[] arrf = new float[this.a.c * 2];
        for (n2 = 0; n2 < arrf.length; n2 += 2) {
            arrf[n2] = this.a.b[n2 / 2];
        }
        this.b.a(arrf);
        this.d.setTypeface(this.a.G);
        this.d.setTextSize(this.a.H);
        this.d.setColor(this.a.I);
        this.d.setTextAlign(Paint.Align.CENTER);
        float f2 = h.a(2.5f);
        float f3 = h.b(this.d, "Q");
        n2 = this.a.s;
        int n3 = this.a.r;
        if (n2 == com.github.mikephil.charting.c.b.a) {
            f2 = n3 == com.github.mikephil.charting.c.a.a ? this.g.e() - f2 : this.g.e() - f2;
        } else {
            n2 = com.github.mikephil.charting.c.a.a;
            f2 += f3 + this.g.h();
        }
        this.a(canvas, f2, arrf, this.a.F);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected final void a(Canvas canvas, float f2, float[] arrf, float f3) {
        this.d.setTypeface(this.a.G);
        this.d.setTextSize(this.a.H);
        this.d.setColor(this.a.I);
        int n2 = 0;
        while (n2 < this.a.c) {
            String string = this.a.a(n2);
            if (!this.a.f && n2 >= this.a.c - 1) {
                return;
            }
            canvas.drawText(string, arrf[n2 * 2], f2 - f3, this.d);
            ++n2;
        }
    }

    @Override
    public final void b(Canvas canvas) {
        if (!this.a.D || !this.a.y) {
            return;
        }
        this.e.setColor(this.a.v);
        this.e.setStrokeWidth(this.a.w);
        if (this.a.s == com.github.mikephil.charting.c.b.a) {
            canvas.drawLine(this.g.f(), this.g.e(), this.g.g(), this.g.e(), this.e);
            return;
        }
        canvas.drawLine(this.g.f(), this.g.h(), this.g.g(), this.g.h(), this.e);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void c(Canvas canvas) {
        if (!this.a.x || !this.a.D) {
            return;
        }
        float[] arrf = new float[2];
        this.c.setColor(this.a.t);
        this.c.setStrokeWidth(this.a.u);
        int n2 = 0;
        while (n2 < this.a.c) {
            arrf[0] = this.a.b[n2];
            this.b.a(arrf);
            canvas.drawLine(arrf[0], this.g.e(), arrf[0], this.g.h(), this.c);
            ++n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void d(Canvas canvas) {
        List<m> list = this.a.B;
        if (list == null || list.size() <= 0) {
            return;
        }
        float[] arrf = new float[4];
        Path path = new Path();
        int n2 = 0;
        while (n2 < list.size()) {
            m m2 = list.get(n2);
            if (m2.D) {
                arrf[0] = m2.a;
                arrf[2] = m2.a;
                this.b.a(arrf);
                arrf[1] = this.g.e();
                arrf[3] = this.g.h();
                path.moveTo(arrf[0], arrf[1]);
                path.lineTo(arrf[2], arrf[3]);
                this.f.setStyle(Paint.Style.STROKE);
                this.f.setColor(m2.c);
                this.f.setPathEffect((PathEffect)m2.f);
                this.f.setStrokeWidth(m2.b);
                canvas.drawPath(path, this.f);
                path.reset();
                String string = m2.e;
                if (string != null && !string.equals("")) {
                    float f2;
                    this.f.setStyle(m2.d);
                    this.f.setPathEffect(null);
                    this.f.setColor(m2.I);
                    this.f.setTypeface(m2.G);
                    this.f.setStrokeWidth(0.5f);
                    this.f.setTextSize(m2.H);
                    float f3 = m2.b + m2.E;
                    float f4 = h.a(2.0f) + m2.F;
                    int n3 = m2.g;
                    if (n3 == l.c) {
                        f2 = h.b(this.f, string);
                        this.f.setTextAlign(Paint.Align.LEFT);
                        canvas.drawText(string, f3 + arrf[0], f2 + (f4 + this.g.e()), this.f);
                    } else if (n3 == l.d) {
                        this.f.setTextAlign(Paint.Align.LEFT);
                        canvas.drawText(string, arrf[0] + f3, this.g.h() - f4, this.f);
                    } else if (n3 == l.a) {
                        this.f.setTextAlign(Paint.Align.RIGHT);
                        f2 = h.b(this.f, string);
                        canvas.drawText(string, arrf[0] - f3, f2 + (f4 + this.g.e()), this.f);
                    } else {
                        this.f.setTextAlign(Paint.Align.RIGHT);
                        canvas.drawText(string, arrf[0] - f3, this.g.h() - f4, this.f);
                    }
                }
            }
            ++n2;
        }
    }
}

