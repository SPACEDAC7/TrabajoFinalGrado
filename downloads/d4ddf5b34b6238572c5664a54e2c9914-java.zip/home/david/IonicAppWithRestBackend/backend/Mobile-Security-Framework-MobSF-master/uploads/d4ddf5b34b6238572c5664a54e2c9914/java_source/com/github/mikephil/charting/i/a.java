/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 */
package com.github.mikephil.charting.i;

import android.graphics.Matrix;
import com.github.mikephil.charting.i.b;
import com.github.mikephil.charting.i.d;

public class a {
    public Matrix a = new Matrix();
    public Matrix b = new Matrix();
    public d c;
    private Matrix d = new Matrix();
    public Matrix e = new Matrix();

    public a(d d2) {
        this.c = d2;
    }

    public static Matrix b(a a2) {
        a2.d.set(a2.a);
        a2.d.postConcat(a2.c.a);
        a2.d.postConcat(a2.b);
        return a2.d;
    }

    public final b a(float f2, float f3) {
        float[] arrf = new float[]{f2, f3};
        this.b(arrf);
        return new b(arrf[0], arrf[1]);
    }

    public final void a(float f2, float f3, float f4, float f5) {
        f3 = this.c.i() / f3;
        f4 = this.c.j() / f4;
        this.a.reset();
        this.a.postTranslate(- f2, - f5);
        this.a.postScale(f3, - f4);
    }

    public void a(boolean bl2) {
        this.b.reset();
        if (!bl2) {
            this.b.postTranslate(this.c.a(), this.c.d - this.c.d());
            return;
        }
        this.b.setTranslate(this.c.a(), - this.c.c());
        this.b.postScale(1.0f, -1.0f);
    }

    public final void a(float[] arrf) {
        this.a.mapPoints(arrf);
        this.c.a.mapPoints(arrf);
        this.b.mapPoints(arrf);
    }

    public final void b(float[] arrf) {
        Matrix matrix = new Matrix();
        this.b.invert(matrix);
        matrix.mapPoints(arrf);
        this.c.a.invert(matrix);
        matrix.mapPoints(arrf);
        this.a.invert(matrix);
        matrix.mapPoints(arrf);
    }
}

