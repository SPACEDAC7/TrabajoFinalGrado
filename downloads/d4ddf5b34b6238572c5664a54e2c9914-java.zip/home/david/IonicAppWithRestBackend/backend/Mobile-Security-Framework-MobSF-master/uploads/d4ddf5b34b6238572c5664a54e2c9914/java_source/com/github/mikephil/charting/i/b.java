/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.i;

public final class b {
    public double a;
    public double b;

    public b(double d2, double d3) {
        this.a = d2;
        this.b = d3;
    }

    public final String toString() {
        return "PointD, x: " + this.a + ", y: " + this.b;
    }
}

