/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.i;

public final class c {
    public final float a;
    public final float b;

    public c(float f2, float f3) {
        this.a = f2;
        this.b = f3;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        if (this == object) {
            return true;
        }
        if (!(object instanceof c)) return false;
        object = (c)object;
        if (this.a != object.a) return false;
        if (this.b != object.b) return false;
        return true;
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.a) ^ Float.floatToIntBits(this.b);
    }

    public final String toString() {
        return "" + this.a + "x" + this.b;
    }
}

