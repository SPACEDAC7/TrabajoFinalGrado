/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.RectF
 *  android.view.View
 */
package com.github.mikephil.charting.i;

import android.graphics.Matrix;
import android.graphics.RectF;
import android.view.View;

public final class d {
    public final Matrix a = new Matrix();
    public RectF b = new RectF();
    public float c = 0.0f;
    public float d = 0.0f;
    public float e = 1.0f;
    public float f = Float.MAX_VALUE;
    public float g = 1.0f;
    public float h = 1.0f;
    public float i = 0.0f;
    public float j = 0.0f;
    private float k = 1.0f;
    private float l = Float.MAX_VALUE;
    private float m = 0.0f;
    private float n = 0.0f;

    /*
     * Enabled aggressive block sorting
     */
    public static void a(d d2, Matrix matrix, RectF rectF) {
        float f2 = 0.0f;
        float[] arrf = new float[9];
        matrix.getValues(arrf);
        float f3 = arrf[2];
        float f4 = arrf[0];
        float f5 = arrf[5];
        float f6 = arrf[4];
        d2.g = Math.min(Math.max(d2.e, f4), d2.f);
        d2.h = Math.min(Math.max(d2.k, f6), d2.l);
        if (rectF != null) {
            f4 = rectF.width();
            f2 = rectF.height();
        } else {
            f4 = 0.0f;
        }
        d2.m = Math.min(Math.max(f3, (- f4) * (d2.g - 1.0f) - d2.i), d2.i);
        d2.n = Math.max(Math.min(f5, f2 * (d2.h - 1.0f) + d2.j), - d2.j);
        arrf[2] = d2.m;
        arrf[0] = d2.g;
        arrf[5] = d2.n;
        arrf[4] = d2.h;
        matrix.setValues(arrf);
    }

    public final float a() {
        return this.b.left;
    }

    public final Matrix a(Matrix matrix, View view, boolean bl2) {
        this.a.set(matrix);
        d.a(this, this.a, this.b);
        if (bl2) {
            view.invalidate();
        }
        matrix.set(this.a);
        return matrix;
    }

    public final void a(float f2, float f3, float f4, float f5) {
        this.b.set(f2, f3, this.c - f4, this.d - f5);
    }

    public final float b() {
        return this.c - this.b.right;
    }

    public final float c() {
        return this.b.top;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean c(float f2) {
        if (this.b.left > f2) return false;
        boolean bl2 = true;
        if (!bl2) return false;
        if (!this.f(f2)) return false;
        return true;
    }

    public final float d() {
        return this.d - this.b.bottom;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean d(float f2) {
        if (this.b.top > f2) return false;
        boolean bl2 = true;
        if (!bl2) return false;
        if (!this.h(f2)) return false;
        return true;
    }

    public final float e() {
        return this.b.top;
    }

    public final boolean e(float f2) {
        if (this.b.left <= f2) {
            return true;
        }
        return false;
    }

    public final float f() {
        return this.b.left;
    }

    public final boolean f(float f2) {
        if (this.b.right >= (f2 = (float)((int)(f2 * 100.0f)) / 100.0f)) {
            return true;
        }
        return false;
    }

    public final float g() {
        return this.b.right;
    }

    public final boolean g(float f2) {
        if (this.b.top <= f2) {
            return true;
        }
        return false;
    }

    public final float h() {
        return this.b.bottom;
    }

    public final boolean h(float f2) {
        if (this.b.bottom >= (f2 = (float)((int)(f2 * 100.0f)) / 100.0f)) {
            return true;
        }
        return false;
    }

    public final float i() {
        return this.b.width();
    }

    public final float j() {
        return this.b.height();
    }

    public final float m() {
        return this.d;
    }

    public final float n() {
        return this.c;
    }

    public final boolean p() {
        if (this.h > this.k || this.k > 1.0f) {
            return false;
        }
        return true;
    }

    public final boolean q() {
        if (this.g > this.e || this.e > 1.0f) {
            return false;
        }
        return true;
    }
}

