/*
 * Decompiled with CFR 0_115.
 */
package com.github.mikephil.charting.i;

import com.github.mikephil.charting.data.d;

public final class e {
    public float a;
    public int b;
    public d<?> c;

    public e(float f2, int n2, d<?> d2) {
        this.a = f2;
        this.b = n2;
        this.c = d2;
    }
}

