/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 */
package com.github.mikephil.charting.i;

import android.graphics.Color;

public final class f {
    public static final int[] a = new int[]{Color.rgb((int)207, (int)248, (int)246), Color.rgb((int)148, (int)212, (int)212), Color.rgb((int)136, (int)180, (int)187), Color.rgb((int)118, (int)174, (int)175), Color.rgb((int)42, (int)109, (int)130)};
    public static final int[] b = new int[]{Color.rgb((int)217, (int)80, (int)138), Color.rgb((int)254, (int)149, (int)7), Color.rgb((int)254, (int)247, (int)120), Color.rgb((int)106, (int)167, (int)134), Color.rgb((int)53, (int)194, (int)209)};
    public static final int[] c = new int[]{Color.rgb((int)64, (int)89, (int)128), Color.rgb((int)149, (int)165, (int)124), Color.rgb((int)217, (int)184, (int)162), Color.rgb((int)191, (int)134, (int)134), Color.rgb((int)179, (int)48, (int)80)};
    public static final int[] d = new int[]{Color.rgb((int)193, (int)37, (int)82), Color.rgb((int)255, (int)102, (int)0), Color.rgb((int)245, (int)199, (int)0), Color.rgb((int)106, (int)150, (int)31), Color.rgb((int)179, (int)100, (int)53)};
    public static final int[] e = new int[]{Color.rgb((int)192, (int)255, (int)140), Color.rgb((int)255, (int)247, (int)140), Color.rgb((int)255, (int)208, (int)140), Color.rgb((int)140, (int)234, (int)255), Color.rgb((int)255, (int)140, (int)157)};
}

