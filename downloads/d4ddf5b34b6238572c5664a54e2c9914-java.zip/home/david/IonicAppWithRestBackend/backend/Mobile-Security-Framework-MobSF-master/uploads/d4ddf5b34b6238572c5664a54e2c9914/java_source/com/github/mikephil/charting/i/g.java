/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 */
package com.github.mikephil.charting.i;

import android.graphics.Matrix;
import com.github.mikephil.charting.i.a;
import com.github.mikephil.charting.i.d;

public final class g
extends a {
    public g(d d2) {
        super(d2);
    }

    @Override
    public final void a(boolean bl2) {
        this.b.reset();
        if (!bl2) {
            this.b.postTranslate(this.c.a(), this.c.d - this.c.d());
            return;
        }
        this.b.setTranslate(- this.c.c - this.c.b(), this.c.d - this.c.d());
        this.b.postScale(-1.0f, 1.0f);
    }
}

