/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.graphics.Paint
 *  android.graphics.Paint$FontMetrics
 *  android.graphics.PointF
 *  android.graphics.Rect
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.view.View
 */
package com.github.mikephil.charting.i;

import android.annotation.SuppressLint;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import com.github.mikephil.charting.data.d;
import com.github.mikephil.charting.i.c;
import com.github.mikephil.charting.i.e;
import java.util.List;

public abstract class h {
    public static DisplayMetrics a;
    public static int b;
    public static int c;
    private static final int[] d;
    public static Rect e;

    static {
        b = 50;
        c = 8000;
        d = new int[]{1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000};
        e = new Rect();
    }

    /*
     * Enabled aggressive block sorting
     */
    public static float a(double d2) {
        double d3 = d2 < 0.0 ? - d2 : d2;
        float f2 = (float)Math.pow(10.0, 1 - (int)Math.ceil((float)Math.log10(d3)));
        return (float)Math.round((double)f2 * d2) / f2;
    }

    public static float a(float f2) {
        if (a == null) {
            Log.e((String)"MPChartLib-Utils", (String)"Utils NOT INITIALIZED. You need to call Utils.init(...) at least once before calling Utils.convertDpToPixel(...). Otherwise conversion does not take place.");
            return f2;
        }
        return f2 * ((float)h.a.densityDpi / 160.0f);
    }

    public static float a(Paint paint) {
        paint = paint.getFontMetrics();
        return paint.descent - paint.ascent;
    }

    public static int a(Paint paint, String string) {
        return (int)paint.measureText(string);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static int a(List<e> var0, float var1_1, int var2_2) {
        var7_3 = -2147483647;
        var3_4 = Float.MAX_VALUE;
        var6_5 = 0;
        while (var6_5 < var0.size()) {
            var9_9 = var0.get(var6_5);
            if (var2_2 == 0) ** GOTO lbl-1000
            var4_6 = var3_4;
            var8_8 = var7_3;
            if (var9_9.c.o == var2_2) lbl-1000: // 2 sources:
            {
                var5_7 = Math.abs(var9_9.a - var1_1);
                var4_6 = var3_4;
                var8_8 = var7_3;
                if (var5_7 < var3_4) {
                    var8_8 = var0.get((int)var6_5).b;
                    var4_6 = var5_7;
                }
            }
            ++var6_5;
            var3_4 = var4_6;
            var7_3 = var8_8;
        }
        return var7_3;
    }

    public static PointF a(PointF pointF, float f2, float f3) {
        return new PointF((float)((double)pointF.x + (double)f2 * Math.cos(Math.toRadians(f3))), (float)((double)pointF.y + (double)f2 * Math.sin(Math.toRadians(f3))));
    }

    public static c a(float f2, float f3, float f4) {
        f4 = 0.017453292f * f4;
        float f5 = Math.abs((float)Math.cos(f4) * f2);
        float f6 = Math.abs((float)Math.sin(f4) * f3);
        f2 = Math.abs((float)Math.sin(f4) * f2);
        return new c(f5 + f6, Math.abs((float)Math.cos(f4) * f3) + f2);
    }

    @SuppressLint(value={"NewApi"})
    public static void a(View view) {
        if (Build.VERSION.SDK_INT >= 16) {
            view.postInvalidateOnAnimation();
            return;
        }
        view.postInvalidateDelayed(10);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static double b(double d2) {
        long l2;
        if (d2 == Double.POSITIVE_INFINITY) {
            return d2;
        }
        long l3 = Double.doubleToRawLongBits(d2 += 0.0);
        if (d2 >= 0.0) {
            l2 = 1;
            do {
                return Double.longBitsToDouble(l2 + l3);
                break;
            } while (true);
        }
        l2 = -1;
        return Double.longBitsToDouble(l2 + l3);
    }

    public static float b(Paint paint) {
        paint = paint.getFontMetrics();
        float f2 = paint.ascent;
        float f3 = paint.top;
        return paint.bottom + (f2 - f3);
    }

    public static float b(List<e> list, float f2, int n2) {
        float f3 = Float.MAX_VALUE;
        for (int i2 = 0; i2 < list.size(); ++i2) {
            e e2 = list.get(i2);
            float f4 = f3;
            if (e2.c.o == n2) {
                float f5 = Math.abs(e2.a - f2);
                f4 = f3;
                if (f5 < f3) {
                    f4 = f5;
                }
            }
            f3 = f4;
        }
        return f3;
    }

    public static int b(Paint paint, String string) {
        Rect rect = new Rect();
        paint.getTextBounds(string, 0, string.length(), rect);
        return rect.height();
    }

    public static float c(float f2) {
        while (f2 < 0.0f) {
            f2 += 360.0f;
        }
        return f2 % 360.0f;
    }

    public static c c(Paint paint, String string) {
        Rect rect = new Rect();
        paint.getTextBounds(string, 0, string.length(), rect);
        return new c(rect.width(), rect.height());
    }
}

