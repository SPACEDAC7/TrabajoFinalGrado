/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.pm.PackageManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.Looper
 */
package android.support.v4.b;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.b.b;
import android.support.v4.b.d;

public class a
extends android.support.v4.c.d {
    public static void a(Activity activity) {
        if (Build.VERSION.SDK_INT >= 16) {
            d.a(activity);
            return;
        }
        activity.finish();
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(final Activity activity, final String[] arrstring, final int n2) {
        if (Build.VERSION.SDK_INT >= 23) {
            b.a(activity, arrstring, n2);
            return;
        } else {
            if (!(activity instanceof a)) return;
            {
                new Handler(Looper.getMainLooper()).post(new Runnable(){

                    @Override
                    public void run() {
                        int[] arrn = new int[arrstring.length];
                        PackageManager packageManager = activity.getPackageManager();
                        String string = activity.getPackageName();
                        int n22 = arrstring.length;
                        for (int i2 = 0; i2 < n22; ++i2) {
                            arrn[i2] = packageManager.checkPermission(arrstring[i2], string);
                        }
                        ((a)activity).onRequestPermissionsResult(n2, arrstring, arrn);
                    }
                });
                return;
            }
        }
    }

    public static boolean a(Activity activity, String string) {
        if (Build.VERSION.SDK_INT >= 23) {
            return b.a(activity, string);
        }
        return false;
    }

    public static interface a {
        public void onRequestPermissionsResult(int var1, String[] var2, int[] var3);
    }

}

