/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 */
package android.support.v4.b;

import android.os.Bundle;
import android.support.v4.c.l;

public abstract class aa {
    public abstract <D> l<D> a(int var1, Bundle var2, a<D> var3);

    public boolean a() {
        return false;
    }

    public abstract <D> l<D> b(int var1, Bundle var2, a<D> var3);

    public static interface a<D> {
        public l<D> a(int var1, Bundle var2);

        public void a(l<D> var1);

        public void a(l<D> var1, D var2);
    }

}

