/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.util.Log
 */
package android.support.v4.b;

import android.os.Bundle;
import android.support.v4.b.aa;
import android.support.v4.b.q;
import android.support.v4.b.s;
import android.support.v4.c.l;
import android.support.v4.j.d;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;

class ab
extends aa {
    static boolean a = false;
    final android.support.v4.j.l<a> b = new android.support.v4.j.l();
    final android.support.v4.j.l<a> c = new android.support.v4.j.l();
    final String d;
    boolean e;
    boolean f;
    boolean g;
    q h;

    ab(String string, q q2, boolean bl2) {
        this.d = string;
        this.h = q2;
        this.e = bl2;
    }

    private a c(int n2, Bundle bundle, aa.a<Object> a2) {
        a a3 = new a(n2, bundle, a2);
        a3.d = a2.a(n2, bundle);
        return a3;
    }

    private a d(int n2, Bundle object, aa.a<Object> a2) {
        try {
            this.g = true;
            object = this.c(n2, (Bundle)object, a2);
            this.a((a)object);
            return object;
        }
        finally {
            this.g = false;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public <D> l<D> a(int n2, Bundle object, aa.a<D> object2) {
        if (this.g) {
            throw new IllegalStateException("Called while creating a loader");
        }
        a a2 = this.b.a(n2);
        if (a) {
            Log.v((String)"LoaderManager", (String)("initLoader in " + this + ": args=" + object));
        }
        if (a2 == null) {
            object = object2 = this.d(n2, (Bundle)object, (aa.a<Object>)object2);
            if (a) {
                Log.v((String)"LoaderManager", (String)("  Created new loader " + object2));
                object = object2;
            }
        } else {
            if (a) {
                Log.v((String)"LoaderManager", (String)("  Re-using existing loader " + a2));
            }
            a2.c = object2;
            object = a2;
        }
        if (object.e && this.e) {
            object.b(object.d, object.g);
        }
        return object.d;
    }

    void a(a a2) {
        this.b.b(a2.a, a2);
        if (this.e) {
            a2.a();
        }
    }

    void a(q q2) {
        this.h = q2;
    }

    public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        String string2;
        a a2;
        int n2;
        int n3 = 0;
        if (this.b.b() > 0) {
            printWriter.print(string);
            printWriter.println("Active Loaders:");
            string2 = string + "    ";
            for (n2 = 0; n2 < this.b.b(); ++n2) {
                a2 = this.b.e(n2);
                printWriter.print(string);
                printWriter.print("  #");
                printWriter.print(this.b.d(n2));
                printWriter.print(": ");
                printWriter.println(a2.toString());
                a2.a(string2, fileDescriptor, printWriter, arrstring);
            }
        }
        if (this.c.b() > 0) {
            printWriter.print(string);
            printWriter.println("Inactive Loaders:");
            string2 = string + "    ";
            for (n2 = n3; n2 < this.c.b(); ++n2) {
                a2 = this.c.e(n2);
                printWriter.print(string);
                printWriter.print("  #");
                printWriter.print(this.c.d(n2));
                printWriter.print(": ");
                printWriter.println(a2.toString());
                a2.a(string2, fileDescriptor, printWriter, arrstring);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean a() {
        int n2 = this.b.b();
        int n3 = 0;
        boolean bl2 = false;
        while (n3 < n2) {
            a a2 = this.b.e(n3);
            boolean bl3 = a2.h && !a2.f;
            bl2 |= bl3;
            ++n3;
        }
        return bl2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public <D> l<D> b(int n2, Bundle bundle, aa.a<D> a2) {
        if (this.g) {
            throw new IllegalStateException("Called while creating a loader");
        }
        a a3 = this.b.a(n2);
        if (a) {
            Log.v((String)"LoaderManager", (String)("restartLoader in " + this + ": args=" + (Object)bundle));
        }
        if (a3 == null) return this.d((int)n2, (Bundle)bundle, a2).d;
        a a4 = this.c.a(n2);
        if (a4 != null) {
            if (a3.e) {
                if (a) {
                    Log.v((String)"LoaderManager", (String)("  Removing last inactive loader: " + a3));
                }
                a4.f = false;
                a4.g();
                a3.d.v();
                this.c.b(n2, a3);
                return this.d((int)n2, (Bundle)bundle, a2).d;
            }
            if (!a3.f()) {
                if (a) {
                    Log.v((String)"LoaderManager", (String)"  Current loader is stopped; replacing");
                }
                this.b.b(n2, null);
                a3.g();
                return this.d((int)n2, (Bundle)bundle, a2).d;
            }
            if (a) {
                Log.v((String)"LoaderManager", (String)"  Current loader is running; configuring pending loader");
            }
            if (a3.n != null) {
                if (a) {
                    Log.v((String)"LoaderManager", (String)("  Removing pending loader: " + a3.n));
                }
                a3.n.g();
                a3.n = null;
            }
            if (a) {
                Log.v((String)"LoaderManager", (String)"  Enqueuing as new pending loader");
            }
            a3.n = this.c(n2, bundle, a2);
            return a3.n.d;
        }
        if (a) {
            Log.v((String)"LoaderManager", (String)("  Making last loader inactive: " + a3));
        }
        a3.d.v();
        this.c.b(n2, a3);
        return this.d((int)n2, (Bundle)bundle, a2).d;
    }

    /*
     * Enabled aggressive block sorting
     */
    void b() {
        if (a) {
            Log.v((String)"LoaderManager", (String)("Starting in " + this));
        }
        if (this.e) {
            RuntimeException runtimeException = new RuntimeException("here");
            runtimeException.fillInStackTrace();
            Log.w((String)"LoaderManager", (String)("Called doStart when already started: " + this), (Throwable)runtimeException);
            return;
        } else {
            this.e = true;
            for (int i2 = this.b.b() - 1; i2 >= 0; --i2) {
                this.b.e(i2).a();
            }
        }
    }

    void c() {
        if (a) {
            Log.v((String)"LoaderManager", (String)("Stopping in " + this));
        }
        if (!this.e) {
            RuntimeException runtimeException = new RuntimeException("here");
            runtimeException.fillInStackTrace();
            Log.w((String)"LoaderManager", (String)("Called doStop when not started: " + this), (Throwable)runtimeException);
            return;
        }
        for (int i2 = this.b.b() - 1; i2 >= 0; --i2) {
            this.b.e(i2).e();
        }
        this.e = false;
    }

    /*
     * Enabled aggressive block sorting
     */
    void d() {
        if (a) {
            Log.v((String)"LoaderManager", (String)("Retaining in " + this));
        }
        if (!this.e) {
            RuntimeException runtimeException = new RuntimeException("here");
            runtimeException.fillInStackTrace();
            Log.w((String)"LoaderManager", (String)("Called doRetain when not started: " + this), (Throwable)runtimeException);
            return;
        } else {
            this.f = true;
            this.e = false;
            for (int i2 = this.b.b() - 1; i2 >= 0; --i2) {
                this.b.e(i2).b();
            }
        }
    }

    void e() {
        if (this.f) {
            if (a) {
                Log.v((String)"LoaderManager", (String)("Finished Retaining in " + this));
            }
            this.f = false;
            for (int i2 = this.b.b() - 1; i2 >= 0; --i2) {
                this.b.e(i2).c();
            }
        }
    }

    void f() {
        for (int i2 = this.b.b() - 1; i2 >= 0; --i2) {
            this.b.e((int)i2).k = true;
        }
    }

    void g() {
        for (int i2 = this.b.b() - 1; i2 >= 0; --i2) {
            this.b.e(i2).d();
        }
    }

    void h() {
        int n2;
        if (!this.f) {
            if (a) {
                Log.v((String)"LoaderManager", (String)("Destroying Active in " + this));
            }
            for (n2 = this.b.b() - 1; n2 >= 0; --n2) {
                this.b.e(n2).g();
            }
            this.b.c();
        }
        if (a) {
            Log.v((String)"LoaderManager", (String)("Destroying Inactive in " + this));
        }
        for (n2 = this.c.b() - 1; n2 >= 0; --n2) {
            this.c.e(n2).g();
        }
        this.c.c();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("LoaderManager{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append(" in ");
        d.a(this.h, stringBuilder);
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }

    final class a
    implements l.b<Object>,
    l.c<Object> {
        final int a;
        final Bundle b;
        aa.a<Object> c;
        l<Object> d;
        boolean e;
        boolean f;
        Object g;
        boolean h;
        boolean i;
        boolean j;
        boolean k;
        boolean l;
        boolean m;
        a n;

        public a(int n2, Bundle bundle, aa.a<Object> a2) {
            this.a = n2;
            this.b = bundle;
            this.c = a2;
        }

        /*
         * Enabled aggressive block sorting
         */
        void a() {
            if (this.i && this.j) {
                this.h = true;
                return;
            }
            if (this.h) return;
            this.h = true;
            if (ab.a) {
                Log.v((String)"LoaderManager", (String)("  Starting: " + this));
            }
            if (this.d == null && this.c != null) {
                this.d = this.c.a(this.a, this.b);
            }
            if (this.d == null) return;
            {
                if (this.d.getClass().isMemberClass() && !Modifier.isStatic(this.d.getClass().getModifiers())) {
                    throw new IllegalArgumentException("Object returned from onCreateLoader must not be a non-static inner member class: " + this.d);
                }
            }
            if (!this.m) {
                this.d.a(this.a, this);
                this.d.a(this);
                this.m = true;
            }
            this.d.r();
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void a(l<Object> object) {
            if (ab.a) {
                Log.v((String)"LoaderManager", (String)("onLoadCanceled: " + this));
            }
            if (this.l) {
                if (!ab.a) return;
                {
                    Log.v((String)"LoaderManager", (String)"  Ignoring load canceled -- destroyed");
                    return;
                }
            } else if (ab.this.b.a(this.a) != this) {
                if (!ab.a) return;
                {
                    Log.v((String)"LoaderManager", (String)"  Ignoring load canceled -- not active");
                    return;
                }
            } else {
                object = this.n;
                if (object == null) return;
                {
                    if (ab.a) {
                        Log.v((String)"LoaderManager", (String)("  Switching to pending loader: " + object));
                    }
                    this.n = null;
                    ab.this.b.b(this.a, null);
                    this.g();
                    ab.this.a((a)object);
                    return;
                }
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void a(l<Object> object, Object object2) {
            if (ab.a) {
                Log.v((String)"LoaderManager", (String)("onLoadComplete: " + this));
            }
            if (this.l) {
                if (!ab.a) return;
                {
                    Log.v((String)"LoaderManager", (String)"  Ignoring load complete -- destroyed");
                    return;
                }
            } else if (ab.this.b.a(this.a) != this) {
                if (!ab.a) return;
                {
                    Log.v((String)"LoaderManager", (String)"  Ignoring load complete -- not active");
                    return;
                }
            } else {
                a a2 = this.n;
                if (a2 != null) {
                    if (ab.a) {
                        Log.v((String)"LoaderManager", (String)("  Switching to pending loader: " + a2));
                    }
                    this.n = null;
                    ab.this.b.b(this.a, null);
                    this.g();
                    ab.this.a(a2);
                    return;
                }
                if (this.g != object2 || !this.e) {
                    this.g = object2;
                    this.e = true;
                    if (this.h) {
                        this.b((l<Object>)object, object2);
                    }
                }
                if ((object = ab.this.c.a(this.a)) != null && object != this) {
                    object.f = false;
                    object.g();
                    ab.this.c.c(this.a);
                }
                if (ab.this.h == null || ab.this.a()) return;
                {
                    ab.this.h.d.d();
                    return;
                }
            }
        }

        public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
            printWriter.print(string);
            printWriter.print("mId=");
            printWriter.print(this.a);
            printWriter.print(" mArgs=");
            printWriter.println((Object)this.b);
            printWriter.print(string);
            printWriter.print("mCallbacks=");
            printWriter.println(this.c);
            printWriter.print(string);
            printWriter.print("mLoader=");
            printWriter.println(this.d);
            if (this.d != null) {
                this.d.a(string + "  ", fileDescriptor, printWriter, arrstring);
            }
            if (this.e || this.f) {
                printWriter.print(string);
                printWriter.print("mHaveData=");
                printWriter.print(this.e);
                printWriter.print("  mDeliveredData=");
                printWriter.println(this.f);
                printWriter.print(string);
                printWriter.print("mData=");
                printWriter.println(this.g);
            }
            printWriter.print(string);
            printWriter.print("mStarted=");
            printWriter.print(this.h);
            printWriter.print(" mReportNextStart=");
            printWriter.print(this.k);
            printWriter.print(" mDestroyed=");
            printWriter.println(this.l);
            printWriter.print(string);
            printWriter.print("mRetaining=");
            printWriter.print(this.i);
            printWriter.print(" mRetainingStarted=");
            printWriter.print(this.j);
            printWriter.print(" mListenerRegistered=");
            printWriter.println(this.m);
            if (this.n != null) {
                printWriter.print(string);
                printWriter.println("Pending Loader ");
                printWriter.print(this.n);
                printWriter.println(":");
                this.n.a(string + "  ", fileDescriptor, printWriter, arrstring);
            }
        }

        void b() {
            if (ab.a) {
                Log.v((String)"LoaderManager", (String)("  Retaining: " + this));
            }
            this.i = true;
            this.j = this.h;
            this.h = false;
            this.c = null;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        void b(l<Object> l2, Object object) {
            String string;
            if (this.c != null) {
                if (ab.this.h != null) {
                    string = ab.this.h.d.u;
                    ab.this.h.d.u = "onLoadFinished";
                } else {
                    string = null;
                }
                if (ab.a) {
                    Log.v((String)"LoaderManager", (String)("  onLoadFinished in " + l2 + ": " + l2.c(object)));
                }
                this.c.a(l2, object);
                this.f = true;
            }
            return;
            finally {
                if (ab.this.h != null) {
                    ab.this.h.d.u = string;
                }
            }
        }

        void c() {
            if (this.i) {
                if (ab.a) {
                    Log.v((String)"LoaderManager", (String)("  Finished Retaining: " + this));
                }
                this.i = false;
                if (this.h != this.j && !this.h) {
                    this.e();
                }
            }
            if (this.h && this.e && !this.k) {
                this.b(this.d, this.g);
            }
        }

        void d() {
            if (this.h && this.k) {
                this.k = false;
                if (this.e && !this.i) {
                    this.b(this.d, this.g);
                }
            }
        }

        void e() {
            if (ab.a) {
                Log.v((String)"LoaderManager", (String)("  Stopping: " + this));
            }
            this.h = false;
            if (!this.i && this.d != null && this.m) {
                this.m = false;
                this.d.a(this);
                this.d.b((Object)this);
                this.d.u();
            }
        }

        boolean f() {
            if (ab.a) {
                Log.v((String)"LoaderManager", (String)("  Canceling: " + this));
            }
            if (this.h && this.d != null && this.m) {
                boolean bl2 = this.d.s();
                if (!bl2) {
                    this.a(this.d);
                }
                return bl2;
            }
            return false;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        void g() {
            String string;
            if (ab.a) {
                Log.v((String)"LoaderManager", (String)("  Destroying: " + this));
            }
            this.l = true;
            boolean bl2 = this.f;
            this.f = false;
            if (this.c != null && this.d != null && this.e && bl2) {
                if (ab.a) {
                    Log.v((String)"LoaderManager", (String)("  Resetting: " + this));
                }
                if (ab.this.h != null) {
                    string = ab.this.h.d.u;
                    ab.this.h.d.u = "onLoaderReset";
                } else {
                    string = null;
                }
                this.c.a(this.d);
            }
            this.c = null;
            this.g = null;
            this.e = false;
            if (this.d != null) {
                if (this.m) {
                    this.m = false;
                    this.d.a(this);
                    this.d.b((Object)this);
                }
                this.d.x();
            }
            if (this.n != null) {
                this.n.g();
            }
            return;
            finally {
                if (ab.this.h != null) {
                    ab.this.h.d.u = string;
                }
            }
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder(64);
            stringBuilder.append("LoaderInfo{");
            stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
            stringBuilder.append(" #");
            stringBuilder.append(this.a);
            stringBuilder.append(" : ");
            d.a(this.d, stringBuilder);
            stringBuilder.append("}}");
            return stringBuilder.toString();
        }
    }

}

