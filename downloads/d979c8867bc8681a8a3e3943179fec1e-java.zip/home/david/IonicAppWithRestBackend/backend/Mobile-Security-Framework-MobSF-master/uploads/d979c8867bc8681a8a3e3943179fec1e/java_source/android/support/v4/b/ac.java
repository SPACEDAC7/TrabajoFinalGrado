/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.util.Log
 */
package android.support.v4.b;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.b.ad;
import android.support.v4.c.j;
import android.util.Log;

public final class ac {
    private static final a a = Build.VERSION.SDK_INT >= 16 ? new c() : new b();

    public static Intent a(Activity activity) {
        return a.a(activity);
    }

    public static Intent a(Context context, ComponentName componentName) {
        String string = ac.b(context, componentName);
        if (string == null) {
            return null;
        }
        if (ac.b(context, componentName = new ComponentName(componentName.getPackageName(), string)) == null) {
            return j.a(componentName);
        }
        return new Intent().setComponent(componentName);
    }

    public static boolean a(Activity activity, Intent intent) {
        return a.a(activity, intent);
    }

    public static String b(Activity object) {
        try {
            object = ac.b((Context)object, object.getComponentName());
            return object;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            throw new IllegalArgumentException((Throwable)var0_1);
        }
    }

    public static String b(Context context, ComponentName componentName) {
        componentName = context.getPackageManager().getActivityInfo(componentName, 128);
        return a.a(context, (ActivityInfo)componentName);
    }

    public static void b(Activity activity, Intent intent) {
        a.b(activity, intent);
    }

    static interface a {
        public Intent a(Activity var1);

        public String a(Context var1, ActivityInfo var2);

        public boolean a(Activity var1, Intent var2);

        public void b(Activity var1, Intent var2);
    }

    static class b
    implements a {
        b() {
        }

        @Override
        public Intent a(Activity activity) {
            String string = ac.b(activity);
            if (string == null) {
                return null;
            }
            ComponentName componentName = new ComponentName((Context)activity, string);
            try {
                if (ac.b((Context)activity, componentName) == null) {
                    return j.a(componentName);
                }
                activity = new Intent().setComponent(componentName);
                return activity;
            }
            catch (PackageManager.NameNotFoundException var1_2) {
                Log.e((String)"NavUtils", (String)("getParentActivityIntent: bad parentActivityName '" + string + "' in manifest"));
                return null;
            }
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        public String a(Context context, ActivityInfo object) {
            if (object.metaData == null) {
                return null;
            }
            String string = object.metaData.getString("android.support.PARENT_ACTIVITY");
            if (string == null) {
                return null;
            }
            object = string;
            if (string.charAt(0) != '.') return object;
            return context.getPackageName() + string;
        }

        @Override
        public boolean a(Activity object, Intent intent) {
            if ((object = object.getIntent().getAction()) != null && !object.equals("android.intent.action.MAIN")) {
                return true;
            }
            return false;
        }

        @Override
        public void b(Activity activity, Intent intent) {
            intent.addFlags(67108864);
            activity.startActivity(intent);
            activity.finish();
        }
    }

    static class c
    extends b {
        c() {
        }

        @Override
        public Intent a(Activity activity) {
            Intent intent;
            Intent intent2 = intent = ad.a(activity);
            if (intent == null) {
                intent2 = this.b(activity);
            }
            return intent2;
        }

        @Override
        public String a(Context context, ActivityInfo activityInfo) {
            String string;
            String string2 = string = ad.a(activityInfo);
            if (string == null) {
                string2 = super.a(context, activityInfo);
            }
            return string2;
        }

        @Override
        public boolean a(Activity activity, Intent intent) {
            return ad.a(activity, intent);
        }

        Intent b(Activity activity) {
            return super.a(activity);
        }

        @Override
        public void b(Activity activity, Intent intent) {
            ad.b(activity, intent);
        }
    }

}

