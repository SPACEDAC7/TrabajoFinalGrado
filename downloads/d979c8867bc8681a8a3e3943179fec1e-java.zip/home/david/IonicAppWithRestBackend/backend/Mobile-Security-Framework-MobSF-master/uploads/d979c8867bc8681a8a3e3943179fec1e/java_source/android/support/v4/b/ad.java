/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Activity
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;

@TargetApi(value=16)
class ad {
    public static Intent a(Activity activity) {
        return activity.getParentActivityIntent();
    }

    public static String a(ActivityInfo activityInfo) {
        return activityInfo.parentActivityName;
    }

    public static boolean a(Activity activity, Intent intent) {
        return activity.shouldUpRecreateTask(intent);
    }

    public static void b(Activity activity, Intent intent) {
        activity.navigateUpTo(intent);
    }
}

