/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.b;

import android.support.v4.b.al;

interface af {
    public void a(al.a var1);
}

