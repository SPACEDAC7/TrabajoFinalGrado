/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Notification
 *  android.app.Notification$Builder
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.Notification;

@TargetApi(value=11)
public interface ag {
    public Notification.Builder a();

    public Notification b();
}

