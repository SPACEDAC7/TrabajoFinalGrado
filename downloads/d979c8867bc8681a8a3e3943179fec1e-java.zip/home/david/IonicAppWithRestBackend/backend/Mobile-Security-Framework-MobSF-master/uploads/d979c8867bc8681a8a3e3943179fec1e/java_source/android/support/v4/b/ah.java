/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.widget.RemoteViews
 */
package android.support.v4.b;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.b.af;
import android.support.v4.b.ag;
import android.support.v4.b.ai;
import android.support.v4.b.aj;
import android.support.v4.b.ak;
import android.support.v4.b.al;
import android.support.v4.b.am;
import android.support.v4.b.an;
import android.support.v4.b.ao;
import android.support.v4.b.ap;
import android.support.v4.b.ar;
import android.support.v4.b.at;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ah {
    static final h a = android.support.v4.f.c.a() ? new k() : (Build.VERSION.SDK_INT >= 21 ? new j() : (Build.VERSION.SDK_INT >= 20 ? new i() : (Build.VERSION.SDK_INT >= 19 ? new p() : (Build.VERSION.SDK_INT >= 16 ? new o() : (Build.VERSION.SDK_INT >= 14 ? new n() : (Build.VERSION.SDK_INT >= 11 ? new m() : new l()))))));

    static void a(af af2, ArrayList<a> object) {
        object = object.iterator();
        while (object.hasNext()) {
            af2.a((a)object.next());
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static void a(ag ag2, q q2) {
        if (q2 == null) return;
        {
            if (q2 instanceof c) {
                q2 = (c)q2;
                ao.a(ag2, q2.d, q2.f, q2.e, q2.a);
                return;
            } else {
                if (q2 instanceof f) {
                    q2 = (f)q2;
                    ao.a(ag2, q2.d, q2.f, q2.e, q2.a);
                    return;
                }
                if (!(q2 instanceof b)) return;
                {
                    q2 = (b)q2;
                    ao.a(ag2, q2.d, q2.f, q2.e, q2.a, q2.b, q2.c);
                    return;
                }
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static void b(ag ag2, q q2) {
        if (q2 == null) return;
        if (q2 instanceof g) {
            q2 = (g)q2;
            ArrayList<CharSequence> arrayList = new ArrayList<CharSequence>();
            ArrayList<Long> arrayList2 = new ArrayList<Long>();
            ArrayList<CharSequence> arrayList3 = new ArrayList<CharSequence>();
            ArrayList<String> arrayList4 = new ArrayList<String>();
            ArrayList<Uri> arrayList5 = new ArrayList<Uri>();
            for (g.a a2 : q2.c) {
                arrayList.add(a2.a());
                arrayList2.add(a2.b());
                arrayList3.add(a2.c());
                arrayList4.add(a2.d());
                arrayList5.add(a2.e());
            }
            ak.a(ag2, q2.a, q2.b, arrayList, arrayList2, arrayList3, arrayList4, arrayList5);
            return;
        }
        ah.a(ag2, q2);
    }

    public static class a
    extends al.a {
        public static final al.a.a e = new al.a.a(){};
        final Bundle a;
        public int b;
        public CharSequence c;
        public PendingIntent d;
        private final ar[] f;
        private boolean g;

        @Override
        public int a() {
            return this.b;
        }

        @Override
        public CharSequence b() {
            return this.c;
        }

        @Override
        public PendingIntent c() {
            return this.d;
        }

        @Override
        public Bundle d() {
            return this.a;
        }

        @Override
        public boolean e() {
            return this.g;
        }

        public ar[] f() {
            return this.f;
        }

        @Override
        public /* synthetic */ at.a[] g() {
            return this.f();
        }

    }

    public static class b
    extends q {
        Bitmap a;
        Bitmap b;
        boolean c;
    }

    public static class c
    extends q {
        CharSequence a;
    }

    public static class d {
        int A = 0;
        Notification B;
        RemoteViews C;
        RemoteViews D;
        RemoteViews E;
        public Notification F = new Notification();
        public ArrayList<String> G;
        public Context a;
        public CharSequence b;
        public CharSequence c;
        PendingIntent d;
        PendingIntent e;
        RemoteViews f;
        public Bitmap g;
        public CharSequence h;
        public int i;
        int j;
        boolean k = true;
        public boolean l;
        public q m;
        public CharSequence n;
        public CharSequence[] o;
        int p;
        int q;
        boolean r;
        String s;
        boolean t;
        String u;
        public ArrayList<a> v = new ArrayList();
        boolean w = false;
        String x;
        Bundle y;
        int z = 0;

        public d(Context context) {
            this.a = context;
            this.F.when = System.currentTimeMillis();
            this.F.audioStreamType = -1;
            this.j = 0;
            this.G = new ArrayList();
        }

        private void a(int n2, boolean bl2) {
            if (bl2) {
                Notification notification = this.F;
                notification.flags |= n2;
                return;
            }
            Notification notification = this.F;
            notification.flags &= ~ n2;
        }

        /*
         * Enabled aggressive block sorting
         */
        protected static CharSequence b(CharSequence charSequence) {
            if (charSequence == null || charSequence.length() <= 5120) {
                return charSequence;
            }
            return charSequence.subSequence(0, 5120);
        }

        public Notification a() {
            return ah.a.a(this, this.b());
        }

        public d a(int n2) {
            this.F.icon = n2;
            return this;
        }

        public d a(PendingIntent pendingIntent) {
            this.d = pendingIntent;
            return this;
        }

        public d a(CharSequence charSequence) {
            this.b = d.b(charSequence);
            return this;
        }

        public d a(boolean bl2) {
            this.a(2, bl2);
            return this;
        }

        public d b(int n2) {
            this.j = n2;
            return this;
        }

        protected e b() {
            return new e();
        }

        protected CharSequence c() {
            return this.c;
        }

        protected CharSequence d() {
            return this.b;
        }
    }

    protected static class e {
        protected e() {
        }

        public Notification a(d d2, ag ag2) {
            ag2 = ag2.b();
            if (d2.C != null) {
                ag2.contentView = d2.C;
            }
            return ag2;
        }
    }

    public static class f
    extends q {
        ArrayList<CharSequence> a = new ArrayList();
    }

    public static class g
    extends q {
        CharSequence a;
        CharSequence b;
        List<a> c = new ArrayList<a>();

        g() {
        }

        @Override
        public void a(Bundle bundle) {
            super.a(bundle);
            if (this.a != null) {
                bundle.putCharSequence("android.selfDisplayName", this.a);
            }
            if (this.b != null) {
                bundle.putCharSequence("android.conversationTitle", this.b);
            }
            if (!this.c.isEmpty()) {
                bundle.putParcelableArray("android.messages", (Parcelable[])a.a(this.c));
            }
        }

        public static final class a {
            private final CharSequence a;
            private final long b;
            private final CharSequence c;
            private String d;
            private Uri e;

            static Bundle[] a(List<a> list) {
                Bundle[] arrbundle = new Bundle[list.size()];
                int n2 = list.size();
                for (int i2 = 0; i2 < n2; ++i2) {
                    arrbundle[i2] = list.get(i2).f();
                }
                return arrbundle;
            }

            private Bundle f() {
                Bundle bundle = new Bundle();
                if (this.a != null) {
                    bundle.putCharSequence("text", this.a);
                }
                bundle.putLong("time", this.b);
                if (this.c != null) {
                    bundle.putCharSequence("sender", this.c);
                }
                if (this.d != null) {
                    bundle.putString("type", this.d);
                }
                if (this.e != null) {
                    bundle.putParcelable("uri", (Parcelable)this.e);
                }
                return bundle;
            }

            public CharSequence a() {
                return this.a;
            }

            public long b() {
                return this.b;
            }

            public CharSequence c() {
                return this.c;
            }

            public String d() {
                return this.d;
            }

            public Uri e() {
                return this.e;
            }
        }

    }

    static interface h {
        public Notification a(d var1, e var2);
    }

    static class i
    extends p {
        i() {
        }

        @Override
        public Notification a(d d2, e e2) {
            ai.a a2 = new ai.a(d2.a, d2.F, d2.d(), d2.c(), d2.h, d2.f, d2.i, d2.d, d2.e, d2.g, d2.p, d2.q, d2.r, d2.k, d2.l, d2.j, d2.n, d2.w, d2.G, d2.y, d2.s, d2.t, d2.u, d2.C, d2.D);
            ah.a(a2, d2.v);
            ah.a(a2, d2.m);
            e2 = e2.a(d2, a2);
            if (d2.m != null) {
                d2.m.a(this.a((Notification)e2));
            }
            return e2;
        }
    }

    static class j
    extends i {
        j() {
        }

        @Override
        public Notification a(d d2, e e2) {
            aj.a a2 = new aj.a(d2.a, d2.F, d2.d(), d2.c(), d2.h, d2.f, d2.i, d2.d, d2.e, d2.g, d2.p, d2.q, d2.r, d2.k, d2.l, d2.j, d2.n, d2.w, d2.x, d2.G, d2.y, d2.z, d2.A, d2.B, d2.s, d2.t, d2.u, d2.C, d2.D, d2.E);
            ah.a(a2, d2.v);
            ah.a(a2, d2.m);
            e2 = e2.a(d2, a2);
            if (d2.m != null) {
                d2.m.a(this.a((Notification)e2));
            }
            return e2;
        }
    }

    static class k
    extends j {
        k() {
        }

        @Override
        public Notification a(d d2, e e2) {
            ak.a a2 = new ak.a(d2.a, d2.F, d2.b, d2.c, d2.h, d2.f, d2.i, d2.d, d2.e, d2.g, d2.p, d2.q, d2.r, d2.k, d2.l, d2.j, d2.n, d2.w, d2.x, d2.G, d2.y, d2.z, d2.A, d2.B, d2.s, d2.t, d2.u, d2.o, d2.C, d2.D, d2.E);
            ah.a(a2, d2.v);
            ah.b(a2, d2.m);
            e2 = e2.a(d2, a2);
            if (d2.m != null) {
                d2.m.a(this.a((Notification)e2));
            }
            return e2;
        }
    }

    static class l
    implements h {
        l() {
        }

        @Override
        public Notification a(d d2, e e2) {
            e2 = al.a(d2.F, d2.a, d2.d(), d2.c(), d2.d, d2.e);
            if (d2.j > 0) {
                e2.flags |= 128;
            }
            if (d2.C != null) {
                e2.contentView = d2.C;
            }
            return e2;
        }

        public Bundle a(Notification notification) {
            return null;
        }
    }

    static class m
    extends l {
        m() {
        }

        @Override
        public Notification a(d d2, e e2) {
            e2 = am.a(d2.a, d2.F, d2.d(), d2.c(), d2.h, d2.f, d2.i, d2.d, d2.e, d2.g);
            if (d2.C != null) {
                e2.contentView = d2.C;
            }
            return e2;
        }
    }

    static class n
    extends l {
        n() {
        }

        @Override
        public Notification a(d d2, e e2) {
            return e2.a(d2, new an.a(d2.a, d2.F, d2.d(), d2.c(), d2.h, d2.f, d2.i, d2.d, d2.e, d2.g, d2.p, d2.q, d2.r));
        }
    }

    static class o
    extends l {
        o() {
        }

        @Override
        public Notification a(d d2, e e2) {
            ao.a a2 = new ao.a(d2.a, d2.F, d2.d(), d2.c(), d2.h, d2.f, d2.i, d2.d, d2.e, d2.g, d2.p, d2.q, d2.r, d2.l, d2.j, d2.n, d2.w, d2.y, d2.s, d2.t, d2.u, d2.C, d2.D);
            ah.a(a2, d2.v);
            ah.a(a2, d2.m);
            e2 = e2.a(d2, a2);
            if (d2.m != null && (a2 = this.a((Notification)e2)) != null) {
                d2.m.a((Bundle)a2);
            }
            return e2;
        }

        @Override
        public Bundle a(Notification notification) {
            return ao.a(notification);
        }
    }

    static class p
    extends o {
        p() {
        }

        @Override
        public Notification a(d d2, e e2) {
            ap.a a2 = new ap.a(d2.a, d2.F, d2.d(), d2.c(), d2.h, d2.f, d2.i, d2.d, d2.e, d2.g, d2.p, d2.q, d2.r, d2.k, d2.l, d2.j, d2.n, d2.w, d2.G, d2.y, d2.s, d2.t, d2.u, d2.C, d2.D);
            ah.a(a2, d2.v);
            ah.a(a2, d2.m);
            return e2.a(d2, a2);
        }

        @Override
        public Bundle a(Notification notification) {
            return ap.a(notification);
        }
    }

    public static abstract class q {
        CharSequence d;
        CharSequence e;
        boolean f = false;

        public void a(Bundle bundle) {
        }
    }

}

