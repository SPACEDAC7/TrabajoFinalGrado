/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Notification
 *  android.app.Notification$Action
 *  android.app.Notification$Action$Builder
 *  android.app.Notification$Builder
 *  android.app.PendingIntent
 *  android.app.RemoteInput
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.net.Uri
 *  android.os.Bundle
 *  android.widget.RemoteViews
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.b.af;
import android.support.v4.b.ag;
import android.support.v4.b.al;
import android.support.v4.b.as;
import android.support.v4.b.at;
import android.widget.RemoteViews;
import java.util.ArrayList;

@TargetApi(value=20)
class ai {
    /*
     * Enabled aggressive block sorting
     */
    public static void a(Notification.Builder builder, al.a a2) {
        Bundle bundle;
        Notification.Action.Builder builder2 = new Notification.Action.Builder(a2.a(), a2.b(), a2.c());
        if (a2.g() != null) {
            bundle = as.a(a2.g());
            int n2 = bundle.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                builder2.addRemoteInput((RemoteInput)bundle[i2]);
            }
        }
        bundle = a2.d() != null ? new Bundle(a2.d()) : new Bundle();
        bundle.putBoolean("android.support.allowGeneratedReplies", a2.e());
        builder2.addExtras(bundle);
        builder.addAction(builder2.build());
    }

    public static class a
    implements af,
    ag {
        private Notification.Builder a;
        private Bundle b;
        private RemoteViews c;
        private RemoteViews d;

        /*
         * Enabled aggressive block sorting
         */
        public a(Context context, Notification notification, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, RemoteViews remoteViews, int n2, PendingIntent pendingIntent, PendingIntent pendingIntent2, Bitmap bitmap, int n3, int n4, boolean bl2, boolean bl3, boolean bl4, int n5, CharSequence charSequence4, boolean bl5, ArrayList<String> arrayList, Bundle bundle, String string, boolean bl6, String string2, RemoteViews remoteViews2, RemoteViews remoteViews3) {
            context = new Notification.Builder(context).setWhen(notification.when).setShowWhen(bl3).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
            bl3 = (notification.flags & 2) != 0;
            context = context.setOngoing(bl3);
            bl3 = (notification.flags & 8) != 0;
            context = context.setOnlyAlertOnce(bl3);
            bl3 = (notification.flags & 16) != 0;
            context = context.setAutoCancel(bl3).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setSubText(charSequence4).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent);
            bl3 = (notification.flags & 128) != 0;
            this.a = context.setFullScreenIntent(pendingIntent2, bl3).setLargeIcon(bitmap).setNumber(n2).setUsesChronometer(bl4).setPriority(n5).setProgress(n3, n4, bl2).setLocalOnly(bl5).setGroup(string).setGroupSummary(bl6).setSortKey(string2);
            this.b = new Bundle();
            if (bundle != null) {
                this.b.putAll(bundle);
            }
            if (arrayList != null && !arrayList.isEmpty()) {
                this.b.putStringArray("android.people", arrayList.toArray(new String[arrayList.size()]));
            }
            this.c = remoteViews2;
            this.d = remoteViews3;
        }

        @Override
        public Notification.Builder a() {
            return this.a;
        }

        @Override
        public void a(al.a a2) {
            ai.a(this.a, a2);
        }

        @Override
        public Notification b() {
            this.a.setExtras(this.b);
            Notification notification = this.a.build();
            if (this.c != null) {
                notification.contentView = this.c;
            }
            if (this.d != null) {
                notification.bigContentView = this.d;
            }
            return notification;
        }
    }

}

