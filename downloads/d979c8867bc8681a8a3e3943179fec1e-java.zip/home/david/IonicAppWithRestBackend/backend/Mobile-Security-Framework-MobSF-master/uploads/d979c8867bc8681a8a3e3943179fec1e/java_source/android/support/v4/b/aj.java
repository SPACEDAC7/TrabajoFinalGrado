/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Notification
 *  android.app.Notification$Builder
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.net.Uri
 *  android.os.Bundle
 *  android.widget.RemoteViews
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.b.af;
import android.support.v4.b.ag;
import android.support.v4.b.ai;
import android.support.v4.b.al;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;

@TargetApi(value=21)
class aj {

    public static class a
    implements af,
    ag {
        private Notification.Builder a;
        private Bundle b;
        private RemoteViews c;
        private RemoteViews d;
        private RemoteViews e;

        /*
         * Enabled aggressive block sorting
         */
        public a(Context iterator, Notification object, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, RemoteViews remoteViews, int n2, PendingIntent pendingIntent, PendingIntent pendingIntent2, Bitmap bitmap, int n3, int n4, boolean bl2, boolean bl3, boolean bl4, int n5, CharSequence charSequence4, boolean bl5, String string, ArrayList<String> arrayList, Bundle bundle, int n6, int n7, Notification notification, String string2, boolean bl6, String string3, RemoteViews remoteViews2, RemoteViews remoteViews3, RemoteViews remoteViews4) {
            void var27_29;
            void var5_7;
            void var19_21;
            void var22_24;
            boolean bl7;
            void var13_15;
            void var4_6;
            void var10_12;
            void var15_17;
            void var20_22;
            void var7_9;
            void var25_27;
            void var8_10;
            void var18_20;
            void var23_25;
            void var17_19;
            void var12_14;
            void var3_5;
            void var6_8;
            void var21_23;
            void var9_11;
            void var24_26;
            void var26_28;
            void var11_13;
            void var16_18;
            iterator = new Notification.Builder((Context)iterator).setWhen(object.when).setShowWhen(bl7).setSmallIcon(object.icon, object.iconLevel).setContent(object.contentView).setTicker(object.tickerText, (RemoteViews)var6_8).setSound(object.sound, object.audioStreamType).setVibrate(object.vibrate).setLights(object.ledARGB, object.ledOnMS, object.ledOffMS);
            bl7 = (object.flags & 2) != 0;
            iterator = iterator.setOngoing(bl7);
            bl7 = (object.flags & 8) != 0;
            iterator = iterator.setOnlyAlertOnce(bl7);
            bl7 = (object.flags & 16) != 0;
            iterator = iterator.setAutoCancel(bl7).setDefaults(object.defaults).setContentTitle((CharSequence)var3_5).setContentText((CharSequence)var4_6).setSubText((CharSequence)var17_19).setContentInfo((CharSequence)var5_7).setContentIntent((PendingIntent)var8_10).setDeleteIntent(object.deleteIntent);
            bl7 = (object.flags & 128) != 0;
            this.a = iterator.setFullScreenIntent((PendingIntent)var9_11, bl7).setLargeIcon((Bitmap)var10_12).setNumber((int)var7_9).setUsesChronometer((boolean)var15_17).setPriority((int)var16_18).setProgress((int)var11_13, (int)var12_14, (boolean)var13_15).setLocalOnly((boolean)var18_20).setGroup((String)var25_27).setGroupSummary((boolean)var26_28).setSortKey((String)var27_29).setCategory((String)var19_21).setColor((int)var22_24).setVisibility((int)var23_25).setPublicVersion((Notification)var24_26);
            this.b = new Bundle();
            if (var21_23 != null) {
                this.b.putAll((Bundle)var21_23);
            }
            iterator = var20_22.iterator();
            do {
                if (!iterator.hasNext()) {
                    void var30_32;
                    void var28_30;
                    void var29_31;
                    this.c = var28_30;
                    this.d = var29_31;
                    this.e = var30_32;
                    return;
                }
                String string4 = (String)iterator.next();
                this.a.addPerson(string4);
            } while (true);
        }

        @Override
        public Notification.Builder a() {
            return this.a;
        }

        @Override
        public void a(al.a a2) {
            ai.a(this.a, a2);
        }

        @Override
        public Notification b() {
            this.a.setExtras(this.b);
            Notification notification = this.a.build();
            if (this.c != null) {
                notification.contentView = this.c;
            }
            if (this.d != null) {
                notification.bigContentView = this.d;
            }
            if (this.e != null) {
                notification.headsUpContentView = this.e;
            }
            return notification;
        }
    }

}

