/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Notification
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.os.Bundle
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.b.at;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@TargetApi(value=9)
public class al {
    private static Method a;

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static Notification a(Notification notification, Context context, CharSequence charSequence, CharSequence charSequence2, PendingIntent pendingIntent, PendingIntent pendingIntent2) {
        void var0_3;
        if (a == null) {
            a = Notification.class.getMethod("setLatestEventInfo", Context.class, CharSequence.class, CharSequence.class, PendingIntent.class);
        }
        a.invoke((Object)notification, new Object[]{context, charSequence, charSequence2, pendingIntent});
        notification.fullScreenIntent = pendingIntent2;
        return notification;
        catch (NoSuchMethodException noSuchMethodException) {
            throw new RuntimeException(noSuchMethodException);
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new RuntimeException((Throwable)var0_3);
        }
        catch (InvocationTargetException invocationTargetException) {
            throw new RuntimeException((Throwable)var0_3);
        }
    }

    public static abstract class android.support.v4.b.al$a {
        public abstract int a();

        public abstract CharSequence b();

        public abstract PendingIntent c();

        public abstract Bundle d();

        public abstract boolean e();

        public abstract at.a[] g();

        public static interface a {
        }

    }

}

