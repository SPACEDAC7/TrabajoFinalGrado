/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Notification
 *  android.app.Notification$BigPictureStyle
 *  android.app.Notification$BigTextStyle
 *  android.app.Notification$Builder
 *  android.app.Notification$InboxStyle
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.util.Log
 *  android.util.SparseArray
 *  android.widget.RemoteViews
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.b.af;
import android.support.v4.b.ag;
import android.support.v4.b.al;
import android.support.v4.b.at;
import android.support.v4.b.au;
import android.util.Log;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

@TargetApi(value=16)
class ao {
    private static final Object a = new Object();
    private static Field b;
    private static boolean c;
    private static final Object d;

    static {
        d = new Object();
    }

    public static Bundle a(Notification.Builder builder, al.a a2) {
        builder.addAction(a2.a(), a2.b(), a2.c());
        builder = new Bundle(a2.d());
        if (a2.g() != null) {
            builder.putParcelableArray("android.support.remoteInputs", (Parcelable[])au.a(a2.g()));
        }
        builder.putBoolean("android.support.allowGeneratedReplies", a2.e());
        return builder;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static Bundle a(Notification var0) {
        var3_3 = ao.a;
        // MONITORENTER : var3_3
        if (ao.c) {
            // MONITOREXIT : var3_3
            return null;
        }
        try {
            if (ao.b == null) {
                var1_4 = Notification.class.getDeclaredField("extras");
                if (!Bundle.class.isAssignableFrom(var1_4.getType())) {
                    Log.e((String)"NotificationCompat", (String)"Notification.extras field is not of type Bundle");
                    ao.c = true;
                    // MONITOREXIT : var3_3
                    return null;
                }
                var1_4.setAccessible(true);
                ao.b = var1_4;
            }
            var1_4 = var2_5 = (Bundle)ao.b.get((Object)var0);
            if (var2_5 == null) {
                var1_4 = new Bundle();
                ao.b.set((Object)var0, var1_4);
            }
            // MONITOREXIT : var3_3
            return var1_4;
        }
        catch (IllegalAccessException var0_1) {
            Log.e((String)"NotificationCompat", (String)"Unable to access notification extras", (Throwable)var0_1);
            ** GOTO lbl27
            catch (NoSuchFieldException var0_2) {
                Log.e((String)"NotificationCompat", (String)"Unable to access notification extras", (Throwable)var0_2);
            }
lbl27: // 2 sources:
            ao.c = true;
            // MONITOREXIT : var3_3
            return null;
        }
    }

    public static SparseArray<Bundle> a(List<Bundle> list) {
        SparseArray sparseArray = null;
        int n2 = list.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            Bundle bundle = list.get(i2);
            SparseArray sparseArray2 = sparseArray;
            if (bundle != null) {
                sparseArray2 = sparseArray;
                if (sparseArray == null) {
                    sparseArray2 = new SparseArray();
                }
                sparseArray2.put(i2, (Object)bundle);
            }
            sparseArray = sparseArray2;
        }
        return sparseArray;
    }

    public static void a(ag ag2, CharSequence charSequence, boolean bl2, CharSequence charSequence2, Bitmap bitmap, Bitmap bitmap2, boolean bl3) {
        ag2 = new Notification.BigPictureStyle(ag2.a()).setBigContentTitle(charSequence).bigPicture(bitmap);
        if (bl3) {
            ag2.bigLargeIcon(bitmap2);
        }
        if (bl2) {
            ag2.setSummaryText(charSequence2);
        }
    }

    public static void a(ag ag2, CharSequence charSequence, boolean bl2, CharSequence charSequence2, CharSequence charSequence3) {
        ag2 = new Notification.BigTextStyle(ag2.a()).setBigContentTitle(charSequence).bigText(charSequence3);
        if (bl2) {
            ag2.setSummaryText(charSequence2);
        }
    }

    public static void a(ag ag2, CharSequence object, boolean bl2, CharSequence charSequence, ArrayList<CharSequence> arrayList) {
        ag2 = new Notification.InboxStyle(ag2.a()).setBigContentTitle((CharSequence)object);
        if (bl2) {
            ag2.setSummaryText(charSequence);
        }
        object = arrayList.iterator();
        while (object.hasNext()) {
            ag2.addLine((CharSequence)object.next());
        }
    }

    public static class a
    implements af,
    ag {
        private Notification.Builder a;
        private final Bundle b;
        private List<Bundle> c = new ArrayList<Bundle>();
        private RemoteViews d;
        private RemoteViews e;

        /*
         * Enabled aggressive block sorting
         */
        public a(Context context, Notification notification, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, RemoteViews remoteViews, int n2, PendingIntent pendingIntent, PendingIntent pendingIntent2, Bitmap bitmap, int n3, int n4, boolean bl2, boolean bl3, int n5, CharSequence charSequence4, boolean bl4, Bundle bundle, String string, boolean bl5, String string2, RemoteViews remoteViews2, RemoteViews remoteViews3) {
            context = new Notification.Builder(context).setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
            boolean bl6 = (notification.flags & 2) != 0;
            context = context.setOngoing(bl6);
            bl6 = (notification.flags & 8) != 0;
            context = context.setOnlyAlertOnce(bl6);
            bl6 = (notification.flags & 16) != 0;
            context = context.setAutoCancel(bl6).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setSubText(charSequence4).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent);
            bl6 = (notification.flags & 128) != 0;
            this.a = context.setFullScreenIntent(pendingIntent2, bl6).setLargeIcon(bitmap).setNumber(n2).setUsesChronometer(bl3).setPriority(n5).setProgress(n3, n4, bl2);
            this.b = new Bundle();
            if (bundle != null) {
                this.b.putAll(bundle);
            }
            if (bl4) {
                this.b.putBoolean("android.support.localOnly", true);
            }
            if (string != null) {
                this.b.putString("android.support.groupKey", string);
                if (bl5) {
                    this.b.putBoolean("android.support.isGroupSummary", true);
                } else {
                    this.b.putBoolean("android.support.useSideChannel", true);
                }
            }
            if (string2 != null) {
                this.b.putString("android.support.sortKey", string2);
            }
            this.d = remoteViews2;
            this.e = remoteViews3;
        }

        @Override
        public Notification.Builder a() {
            return this.a;
        }

        @Override
        public void a(al.a a2) {
            this.c.add(ao.a(this.a, a2));
        }

        @Override
        public Notification b() {
            Notification notification = this.a.build();
            SparseArray<Bundle> sparseArray = ao.a(notification);
            Bundle bundle = new Bundle(this.b);
            for (String string : this.b.keySet()) {
                if (!sparseArray.containsKey(string)) continue;
                bundle.remove(string);
            }
            sparseArray.putAll(bundle);
            sparseArray = ao.a(this.c);
            if (sparseArray != null) {
                ao.a(notification).putSparseParcelableArray("android.support.actionExtras", sparseArray);
            }
            if (this.d != null) {
                notification.contentView = this.d;
            }
            if (this.e != null) {
                notification.bigContentView = this.e;
            }
            return notification;
        }
    }

}

