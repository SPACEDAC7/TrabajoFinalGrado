/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Notification
 *  android.app.Notification$Builder
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.net.Uri
 *  android.os.Bundle
 *  android.util.SparseArray
 *  android.widget.RemoteViews
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.b.af;
import android.support.v4.b.ag;
import android.support.v4.b.al;
import android.support.v4.b.ao;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.List;

@TargetApi(value=19)
class ap {
    public static Bundle a(Notification notification) {
        return notification.extras;
    }

    public static class a
    implements af,
    ag {
        private Notification.Builder a;
        private Bundle b;
        private List<Bundle> c = new ArrayList<Bundle>();
        private RemoteViews d;
        private RemoteViews e;

        /*
         * Enabled aggressive block sorting
         */
        public a(Context context, Notification notification, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, RemoteViews remoteViews, int n2, PendingIntent pendingIntent, PendingIntent pendingIntent2, Bitmap bitmap, int n3, int n4, boolean bl2, boolean bl3, boolean bl4, int n5, CharSequence charSequence4, boolean bl5, ArrayList<String> arrayList, Bundle bundle, String string, boolean bl6, String string2, RemoteViews remoteViews2, RemoteViews remoteViews3) {
            context = new Notification.Builder(context).setWhen(notification.when).setShowWhen(bl3).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
            bl3 = (notification.flags & 2) != 0;
            context = context.setOngoing(bl3);
            bl3 = (notification.flags & 8) != 0;
            context = context.setOnlyAlertOnce(bl3);
            bl3 = (notification.flags & 16) != 0;
            context = context.setAutoCancel(bl3).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setSubText(charSequence4).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent);
            bl3 = (notification.flags & 128) != 0;
            this.a = context.setFullScreenIntent(pendingIntent2, bl3).setLargeIcon(bitmap).setNumber(n2).setUsesChronometer(bl4).setPriority(n5).setProgress(n3, n4, bl2);
            this.b = new Bundle();
            if (bundle != null) {
                this.b.putAll(bundle);
            }
            if (arrayList != null && !arrayList.isEmpty()) {
                this.b.putStringArray("android.people", arrayList.toArray(new String[arrayList.size()]));
            }
            if (bl5) {
                this.b.putBoolean("android.support.localOnly", true);
            }
            if (string != null) {
                this.b.putString("android.support.groupKey", string);
                if (bl6) {
                    this.b.putBoolean("android.support.isGroupSummary", true);
                } else {
                    this.b.putBoolean("android.support.useSideChannel", true);
                }
            }
            if (string2 != null) {
                this.b.putString("android.support.sortKey", string2);
            }
            this.d = remoteViews2;
            this.e = remoteViews3;
        }

        @Override
        public Notification.Builder a() {
            return this.a;
        }

        @Override
        public void a(al.a a2) {
            this.c.add(ao.a(this.a, a2));
        }

        @Override
        public Notification b() {
            Notification notification = ao.a(this.c);
            if (notification != null) {
                this.b.putSparseParcelableArray("android.support.actionExtras", notification);
            }
            this.a.setExtras(this.b);
            notification = this.a.build();
            if (this.d != null) {
                notification.contentView = this.d;
            }
            if (this.e != null) {
                notification.bigContentView = this.e;
            }
            return notification;
        }
    }

}

