/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 */
package android.support.v4.b;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.b.at;

public final class ar
extends at.a {
    public static final at.a.a a;
    private static final a g;
    private final String b;
    private final CharSequence c;
    private final CharSequence[] d;
    private final boolean e;
    private final Bundle f;

    /*
     * Enabled aggressive block sorting
     */
    static {
        g = Build.VERSION.SDK_INT >= 20 ? new b() : (Build.VERSION.SDK_INT >= 16 ? new d() : new c());
        a = new at.a.a(){};
    }

    @Override
    public String a() {
        return this.b;
    }

    @Override
    public CharSequence b() {
        return this.c;
    }

    @Override
    public CharSequence[] c() {
        return this.d;
    }

    @Override
    public boolean d() {
        return this.e;
    }

    @Override
    public Bundle e() {
        return this.f;
    }

    static interface a {
    }

    static class b
    implements a {
        b() {
        }
    }

    static class c
    implements a {
        c() {
        }
    }

    static class d
    implements a {
        d() {
        }
    }

}

