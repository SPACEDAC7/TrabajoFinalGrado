/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.RemoteInput
 *  android.app.RemoteInput$Builder
 *  android.os.Bundle
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.RemoteInput;
import android.os.Bundle;
import android.support.v4.b.at;

@TargetApi(value=20)
class as {
    static RemoteInput[] a(at.a[] arra) {
        if (arra == null) {
            return null;
        }
        RemoteInput[] arrremoteInput = new RemoteInput[arra.length];
        for (int i2 = 0; i2 < arra.length; ++i2) {
            at.a a2 = arra[i2];
            arrremoteInput[i2] = new RemoteInput.Builder(a2.a()).setLabel(a2.b()).setChoices(a2.c()).setAllowFreeFormInput(a2.d()).addExtras(a2.e()).build();
        }
        return arrremoteInput;
    }
}

