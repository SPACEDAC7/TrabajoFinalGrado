/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.os.Bundle
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.os.Bundle;
import android.support.v4.b.at;

@TargetApi(value=16)
class au {
    static Bundle a(at.a a2) {
        Bundle bundle = new Bundle();
        bundle.putString("resultKey", a2.a());
        bundle.putCharSequence("label", a2.b());
        bundle.putCharSequenceArray("choices", a2.c());
        bundle.putBoolean("allowFreeFormInput", a2.d());
        bundle.putBundle("extras", a2.e());
        return bundle;
    }

    static Bundle[] a(at.a[] arra) {
        if (arra == null) {
            return null;
        }
        Bundle[] arrbundle = new Bundle[arra.length];
        for (int i2 = 0; i2 < arra.length; ++i2) {
            arrbundle[i2] = au.a(arra[i2]);
        }
        return arrbundle;
    }
}

