/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package android.support.v4.b;

import android.view.View;
import java.util.List;
import java.util.Map;

public abstract class av {
    private static int a = 1048576;

    public void a(List<String> list, List<View> list2, List<View> list3) {
    }

    public void a(List<String> list, Map<String, View> map) {
    }

    public void b(List<String> list, List<View> list2, List<View> list3) {
    }
}

