/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.AndroidRuntimeException
 */
package android.support.v4.b;

import android.util.AndroidRuntimeException;

final class aw
extends AndroidRuntimeException {
    public aw(String string) {
        super(string);
    }
}

