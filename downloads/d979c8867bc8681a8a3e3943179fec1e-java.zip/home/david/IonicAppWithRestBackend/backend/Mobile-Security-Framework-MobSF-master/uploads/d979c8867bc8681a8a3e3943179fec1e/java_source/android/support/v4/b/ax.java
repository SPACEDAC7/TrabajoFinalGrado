/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 */
package android.support.v4.b;

import android.app.Activity;
import android.support.v4.j.k;

public class ax
extends Activity {
    private k<Class<? extends Object>, Object> a = new k();
}

