/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.util.Log
 */
package android.support.v4.b;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.b.ac;
import android.support.v4.b.az;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

public final class ay
implements Iterable<Intent> {
    private static final b a = Build.VERSION.SDK_INT >= 11 ? new d() : new c();
    private final ArrayList<Intent> b = new ArrayList();
    private final Context c;

    private ay(Context context) {
        this.c = context;
    }

    public static ay a(Context context) {
        return new ay(context);
    }

    public PendingIntent a(int n2, int n3) {
        return this.a(n2, n3, null);
    }

    public PendingIntent a(int n2, int n3, Bundle bundle) {
        if (this.b.isEmpty()) {
            throw new IllegalStateException("No intents added to TaskStackBuilder; cannot getPendingIntent");
        }
        Intent[] arrintent = this.b.toArray((T[])new Intent[this.b.size()]);
        arrintent[0] = new Intent(arrintent[0]).addFlags(268484608);
        return a.a(this.c, arrintent, n2, n3, bundle);
    }

    /*
     * Enabled aggressive block sorting
     */
    public ay a(Activity activity) {
        Intent intent = null;
        activity = !(activity instanceof a) || (intent = ((a)activity).d_()) == null ? ac.a(activity) : intent;
        if (activity != null) {
            ComponentName componentName;
            intent = componentName = activity.getComponent();
            if (componentName == null) {
                intent = activity.resolveActivity(this.c.getPackageManager());
            }
            this.a((ComponentName)intent);
            this.a((Intent)activity);
        }
        return this;
    }

    public ay a(ComponentName componentName) {
        int n2 = this.b.size();
        componentName = ac.a(this.c, componentName);
        while (componentName != null) {
            try {
                this.b.add(n2, (Intent)componentName);
                componentName = ac.a(this.c, componentName.getComponent());
                continue;
            }
            catch (PackageManager.NameNotFoundException var1_2) {
                Log.e((String)"TaskStackBuilder", (String)"Bad ComponentName while traversing activity parent metadata");
                throw new IllegalArgumentException((Throwable)var1_2);
            }
        }
        return this;
    }

    public ay a(Intent intent) {
        this.b.add(intent);
        return this;
    }

    public ay a(Class<?> class_) {
        return this.a(new ComponentName(this.c, class_));
    }

    public void a() {
        this.a((Bundle)null);
    }

    public void a(Bundle bundle) {
        if (this.b.isEmpty()) {
            throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
        }
        Intent[] arrintent = this.b.toArray((T[])new Intent[this.b.size()]);
        arrintent[0] = new Intent(arrintent[0]).addFlags(268484608);
        if (!android.support.v4.c.d.a(this.c, arrintent, bundle)) {
            bundle = new Intent(arrintent[arrintent.length - 1]);
            bundle.addFlags(268435456);
            this.c.startActivity((Intent)bundle);
        }
    }

    @Deprecated
    @Override
    public Iterator<Intent> iterator() {
        return this.b.iterator();
    }

    public static interface a {
        public Intent d_();
    }

    static interface b {
        public PendingIntent a(Context var1, Intent[] var2, int var3, int var4, Bundle var5);
    }

    static class c
    implements b {
        c() {
        }

        @Override
        public PendingIntent a(Context context, Intent[] intent, int n2, int n3, Bundle bundle) {
            intent = new Intent(intent[intent.length - 1]);
            intent.addFlags(268435456);
            return PendingIntent.getActivity((Context)context, (int)n2, (Intent)intent, (int)n3);
        }
    }

    static class d
    implements b {
        d() {
        }

        @Override
        public PendingIntent a(Context context, Intent[] arrintent, int n2, int n3, Bundle bundle) {
            arrintent[0] = new Intent(arrintent[0]).addFlags(268484608);
            return az.a(context, n2, arrintent, n3);
        }
    }

}

