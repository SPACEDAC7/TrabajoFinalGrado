/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Activity
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.Activity;

@TargetApi(value=23)
class b {
    public static void a(Activity activity, String[] arrstring, int n2) {
        if (activity instanceof a) {
            ((a)activity).a(n2);
        }
        activity.requestPermissions(arrstring, n2);
    }

    public static boolean a(Activity activity, String string) {
        return activity.shouldShowRequestPermissionRationale(string);
    }

    public static interface a {
        public void a(int var1);
    }

}

