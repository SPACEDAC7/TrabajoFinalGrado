/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Activity
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.Activity;

@TargetApi(value=11)
class c {
    static void a(Activity activity) {
        activity.invalidateOptionsMenu();
    }
}

