/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package android.support.v4.b;

import android.content.Context;
import android.os.Build;
import android.support.v4.b.f;

public final class e {
    private static final b a = Build.VERSION.SDK_INT >= 23 ? new a() : new b();

    public static int a(Context context, String string, String string2) {
        return a.a(context, string, string2);
    }

    public static String a(String string) {
        return a.a(string);
    }

    private static class a
    extends b {
        a() {
        }

        @Override
        public int a(Context context, String string, String string2) {
            return f.a(context, string, string2);
        }

        @Override
        public String a(String string) {
            return f.a(string);
        }
    }

    private static class b {
        b() {
        }

        public int a(Context context, String string, String string2) {
            return 1;
        }

        public String a(String string) {
            return null;
        }
    }

}

