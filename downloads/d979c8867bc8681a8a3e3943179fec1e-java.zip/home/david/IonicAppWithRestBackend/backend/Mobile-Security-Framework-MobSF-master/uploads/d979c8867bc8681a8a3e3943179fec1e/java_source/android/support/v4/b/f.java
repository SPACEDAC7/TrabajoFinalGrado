/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.AppOpsManager
 *  android.content.Context
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.app.AppOpsManager;
import android.content.Context;

@TargetApi(value=23)
class f {
    public static int a(Context context, String string, String string2) {
        return ((AppOpsManager)context.getSystemService((Class)AppOpsManager.class)).noteProxyOp(string, string2);
    }

    public static String a(String string) {
        return AppOpsManager.permissionToOp((String)string);
    }
}

