/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 *  android.view.View
 */
package android.support.v4.b;

import android.os.Build;
import android.support.v4.b.m;
import android.support.v4.b.s;
import android.support.v4.b.w;
import android.support.v4.j.e;
import android.util.Log;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

final class g
extends w
implements s.c {
    static final boolean a;
    final s b;
    ArrayList<a> c = new ArrayList();
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    boolean j;
    boolean k = true;
    String l;
    boolean m;
    int n = -1;
    int o;
    CharSequence p;
    int q;
    CharSequence r;
    ArrayList<String> s;
    ArrayList<String> t;
    boolean u = false;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl2 = Build.VERSION.SDK_INT >= 21;
        a = bl2;
    }

    public g(s s2) {
        this.b = s2;
    }

    private void a(int n2, m m2, String object, int n3) {
        Class class_ = m2.getClass();
        int n4 = class_.getModifiers();
        if (class_.isAnonymousClass() || !Modifier.isPublic(n4) || class_.isMemberClass() && !Modifier.isStatic(n4)) {
            throw new IllegalStateException("Fragment " + class_.getCanonicalName() + " must be a public static class to be  properly recreated from" + " instance state.");
        }
        m2.z = this.b;
        if (object != null) {
            if (m2.G != null && !object.equals(m2.G)) {
                throw new IllegalStateException("Can't change tag of fragment " + m2 + ": was " + m2.G + " now " + (String)object);
            }
            m2.G = object;
        }
        if (n2 != 0) {
            if (n2 == -1) {
                throw new IllegalArgumentException("Can't add fragment " + m2 + " with tag " + (String)object + " to container view with no id");
            }
            if (m2.E != 0 && m2.E != n2) {
                throw new IllegalStateException("Can't change container ID of fragment " + m2 + ": was " + m2.E + " now " + n2);
            }
            m2.E = n2;
            m2.F = n2;
        }
        object = new a();
        object.a = n3;
        object.b = m2;
        this.a((a)object);
    }

    private static boolean b(a object) {
        object = object.b;
        if (object.t && object.P != null && !object.I && !object.H && object.W()) {
            return true;
        }
        return false;
    }

    @Override
    public int a() {
        return this.a(false);
    }

    /*
     * Enabled aggressive block sorting
     */
    int a(boolean bl2) {
        if (this.m) {
            throw new IllegalStateException("commit already called");
        }
        if (s.a) {
            Log.v((String)"FragmentManager", (String)("Commit: " + this));
            this.a("  ", null, new PrintWriter(new e("FragmentManager")), null);
        }
        this.m = true;
        this.n = this.j ? this.b.a(this) : -1;
        this.b.a(this, bl2);
        return this.n;
    }

    @Override
    public w a(int n2) {
        this.h = n2;
        return this;
    }

    @Override
    public w a(int n2, m m2, String string) {
        if (n2 == 0) {
            throw new IllegalArgumentException("Must use non-zero containerViewId");
        }
        this.a(n2, m2, string, 2);
        return this;
    }

    @Override
    public w a(m m2) {
        a a2 = new a();
        a2.a = 3;
        a2.b = m2;
        this.a(a2);
        return this;
    }

    @Override
    public w a(m m2, String string) {
        this.a(0, m2, string, 1);
        return this;
    }

    @Override
    public w a(String string) {
        if (!this.k) {
            throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
        }
        this.j = true;
        this.l = string;
        return this;
    }

    void a(a a2) {
        this.c.add(a2);
        a2.c = this.d;
        a2.d = this.e;
        a2.e = this.f;
        a2.f = this.g;
    }

    void a(m.c c2) {
        for (int i2 = 0; i2 < this.c.size(); ++i2) {
            a a2 = this.c.get(i2);
            if (!g.b(a2)) continue;
            a2.b.a(c2);
        }
    }

    public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        this.a(string, printWriter, true);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(String string, PrintWriter printWriter, boolean bl2) {
        if (bl2) {
            printWriter.print(string);
            printWriter.print("mName=");
            printWriter.print(this.l);
            printWriter.print(" mIndex=");
            printWriter.print(this.n);
            printWriter.print(" mCommitted=");
            printWriter.println(this.m);
            if (this.h != 0) {
                printWriter.print(string);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.h));
                printWriter.print(" mTransitionStyle=#");
                printWriter.println(Integer.toHexString(this.i));
            }
            if (this.d != 0 || this.e != 0) {
                printWriter.print(string);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.d));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.e));
            }
            if (this.f != 0 || this.g != 0) {
                printWriter.print(string);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.g));
            }
            if (this.o != 0 || this.p != null) {
                printWriter.print(string);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.o));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.p);
            }
            if (this.q != 0 || this.r != null) {
                printWriter.print(string);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.q));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.r);
            }
        }
        if (this.c.isEmpty()) {
            return;
        }
        printWriter.print(string);
        printWriter.println("Operations:");
        string + "    ";
        int n2 = this.c.size();
        int n3 = 0;
        while (n3 < n2) {
            String string2;
            a a2 = this.c.get(n3);
            switch (a2.a) {
                default: {
                    string2 = "cmd=" + a2.a;
                    break;
                }
                case 0: {
                    string2 = "NULL";
                    break;
                }
                case 1: {
                    string2 = "ADD";
                    break;
                }
                case 2: {
                    string2 = "REPLACE";
                    break;
                }
                case 3: {
                    string2 = "REMOVE";
                    break;
                }
                case 4: {
                    string2 = "HIDE";
                    break;
                }
                case 5: {
                    string2 = "SHOW";
                    break;
                }
                case 6: {
                    string2 = "DETACH";
                    break;
                }
                case 7: {
                    string2 = "ATTACH";
                }
            }
            printWriter.print(string);
            printWriter.print("  Op #");
            printWriter.print(n3);
            printWriter.print(": ");
            printWriter.print(string2);
            printWriter.print(" ");
            printWriter.println(a2.b);
            if (bl2) {
                if (a2.c != 0 || a2.d != 0) {
                    printWriter.print(string);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(a2.c));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(a2.d));
                }
                if (a2.e != 0 || a2.f != 0) {
                    printWriter.print(string);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(a2.e));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(a2.f));
                }
            }
            ++n3;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    void a(ArrayList<m> var1_1) {
        block11 : {
            var2_2 = 0;
            block6 : while (var2_2 < this.c.size()) {
                var7_7 = this.c.get(var2_2);
                var3_3 = var2_2;
                switch (var7_7.a) {
                    default: {
                        var3_3 = var2_2;
                        break;
                    }
                    case 1: 
                    case 7: {
                        var1_1.add(var7_7.b);
                        var3_3 = var2_2;
                        break;
                    }
                    case 3: 
                    case 6: {
                        var1_1.remove(var7_7.b);
                        var3_3 = var2_2;
                    }
                    case 4: 
                    case 5: {
                        break;
                    }
                    case 2: {
                        var8_8 = var7_7.b;
                        var6_6 = var8_8.F;
                        var4_4 = var1_1.size() - 1;
                        var3_3 = 0;
                        break block11;
                    }
                }
lbl24: // 4 sources:
                do {
                    var2_2 = var3_3 + 1;
                    continue block6;
                    break;
                } while (true);
            }
            return;
        }
        do {
            if (var4_4 < 0) ** GOTO lbl51
            var9_9 = var1_1.get(var4_4);
            if (var9_9.F != var6_6) ** GOTO lbl55
            if (var9_9 == var8_8) {
                var5_5 = 1;
                var3_3 = var2_2;
                var2_2 = var5_5;
            } else {
                var10_10 = new a();
                var10_10.a = 3;
                var10_10.b = var9_9;
                var10_10.c = var7_7.c;
                var10_10.e = var7_7.e;
                var10_10.d = var7_7.d;
                var10_10.f = var7_7.f;
                this.c.add(var2_2, var10_10);
                var1_1.remove(var9_9);
                var5_5 = var2_2 + 1;
                var2_2 = var3_3;
                var3_3 = var5_5;
            }
            ** GOTO lbl58
lbl51: // 1 sources:
            var7_7.a = 1;
            var1_1.add(var8_8);
            var3_3 = var2_2;
            ** continue;
lbl55: // 1 sources:
            var5_5 = var2_2;
            var2_2 = var3_3;
            var3_3 = var5_5;
lbl58: // 3 sources:
            var5_5 = var4_4 - 1;
            var4_4 = var3_3;
            var3_3 = var2_2;
            var2_2 = var4_4;
            var4_4 = var5_5;
        } while (true);
    }

    boolean a(ArrayList<g> arrayList, int n2, int n3) {
        if (n3 == n2) {
            return false;
        }
        int n4 = this.c.size();
        int n5 = -1;
        for (int i2 = 0; i2 < n4; ++i2) {
            int n6 = this.c.get((int)i2).b.F;
            if (n6 == 0 || n6 == n5) continue;
            for (n5 = n2; n5 < n3; ++n5) {
                g g2 = arrayList.get(n5);
                int n7 = g2.c.size();
                for (int i3 = 0; i3 < n7; ++i3) {
                    if (g2.c.get((int)i3).b.F != n6) continue;
                    return true;
                }
            }
            n5 = n6;
        }
        return false;
    }

    @Override
    public boolean a(ArrayList<g> arrayList, ArrayList<Boolean> arrayList2) {
        if (s.a) {
            Log.v((String)"FragmentManager", (String)("Run: " + this));
        }
        arrayList.add(this);
        arrayList2.add(false);
        if (this.j) {
            this.b.b(this);
        }
        return true;
    }

    @Override
    public int b() {
        return this.a(true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    void b(int n2) {
        if (!this.j) {
            return;
        }
        if (s.a) {
            Log.v((String)"FragmentManager", (String)("Bump nesting in " + this + " by " + n2));
        }
        int n3 = this.c.size();
        int n4 = 0;
        while (n4 < n3) {
            a a2 = this.c.get(n4);
            if (a2.b != null) {
                m m2 = a2.b;
                m2.y += n2;
                if (s.a) {
                    Log.v((String)"FragmentManager", (String)("Bump nesting of " + a2.b + " to " + a2.b.y));
                }
            }
            ++n4;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void b(ArrayList<m> arrayList) {
        int n2 = 0;
        while (n2 < this.c.size()) {
            a a2 = this.c.get(n2);
            switch (a2.a) {
                case 1: 
                case 7: {
                    arrayList.remove(a2.b);
                }
                default: {
                    break;
                }
                case 3: 
                case 6: {
                    arrayList.add(a2.b);
                }
            }
            ++n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void c() {
        int n2 = this.c.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            a a2 = this.c.get(i2);
            m m2 = a2.b;
            m2.a(this.h, this.i);
            switch (a2.a) {
                default: {
                    throw new IllegalArgumentException("Unknown cmd: " + a2.a);
                }
                case 1: {
                    m2.b(a2.c);
                    this.b.a(m2, false);
                    break;
                }
                case 3: {
                    m2.b(a2.d);
                    this.b.g(m2);
                    break;
                }
                case 4: {
                    m2.b(a2.d);
                    this.b.h(m2);
                    break;
                }
                case 5: {
                    m2.b(a2.c);
                    this.b.i(m2);
                    break;
                }
                case 6: {
                    m2.b(a2.d);
                    this.b.j(m2);
                    break;
                }
                case 7: {
                    m2.b(a2.c);
                    this.b.k(m2);
                }
            }
            if (this.u || a2.a == 1) continue;
            this.b.d(m2);
        }
        if (!this.u) {
            this.b.a(this.b.m, true);
        }
    }

    boolean c(int n2) {
        int n3 = this.c.size();
        for (int i2 = 0; i2 < n3; ++i2) {
            if (this.c.get((int)i2).b.F != n2) continue;
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    void d() {
        for (int i2 = this.c.size() - 1; i2 >= 0; --i2) {
            a a2 = this.c.get(i2);
            m m2 = a2.b;
            m2.a(s.d(this.h), this.i);
            switch (a2.a) {
                default: {
                    throw new IllegalArgumentException("Unknown cmd: " + a2.a);
                }
                case 1: {
                    m2.b(a2.f);
                    this.b.g(m2);
                    break;
                }
                case 3: {
                    m2.b(a2.e);
                    this.b.a(m2, false);
                    break;
                }
                case 4: {
                    m2.b(a2.e);
                    this.b.i(m2);
                    break;
                }
                case 5: {
                    m2.b(a2.f);
                    this.b.h(m2);
                    break;
                }
                case 6: {
                    m2.b(a2.e);
                    this.b.k(m2);
                    break;
                }
                case 7: {
                    m2.b(a2.f);
                    this.b.j(m2);
                }
            }
            if (this.u || a2.a == 3) continue;
            this.b.d(m2);
        }
        if (!this.u) {
            this.b.a(this.b.m, true);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    boolean e() {
        boolean bl2 = false;
        int n2 = 0;
        do {
            boolean bl3 = bl2;
            if (n2 >= this.c.size()) return bl3;
            if (g.b(this.c.get(n2))) {
                return true;
            }
            ++n2;
        } while (true);
    }

    public String f() {
        return this.l;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("BackStackEntry{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.n >= 0) {
            stringBuilder.append(" #");
            stringBuilder.append(this.n);
        }
        if (this.l != null) {
            stringBuilder.append(" ");
            stringBuilder.append(this.l);
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    static final class a {
        int a;
        m b;
        int c;
        int d;
        int e;
        int f;

        a() {
        }
    }

}

