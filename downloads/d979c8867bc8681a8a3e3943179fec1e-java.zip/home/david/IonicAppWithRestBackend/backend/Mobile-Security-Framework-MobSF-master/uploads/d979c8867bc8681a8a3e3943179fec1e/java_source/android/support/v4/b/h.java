/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 *  android.util.Log
 */
package android.support.v4.b;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.b.g;
import android.support.v4.b.m;
import android.support.v4.b.s;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

final class h
implements Parcelable {
    public static final Parcelable.Creator<h> CREATOR = new Parcelable.Creator<h>(){

        public h a(Parcel parcel) {
            return new h(parcel);
        }

        public h[] a(int n2) {
            return new h[n2];
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return this.a(parcel);
        }

        public /* synthetic */ Object[] newArray(int n2) {
            return this.a(n2);
        }
    };
    final int[] a;
    final int b;
    final int c;
    final String d;
    final int e;
    final int f;
    final CharSequence g;
    final int h;
    final CharSequence i;
    final ArrayList<String> j;
    final ArrayList<String> k;
    final boolean l;

    /*
     * Enabled aggressive block sorting
     */
    public h(Parcel parcel) {
        this.a = parcel.createIntArray();
        this.b = parcel.readInt();
        this.c = parcel.readInt();
        this.d = parcel.readString();
        this.e = parcel.readInt();
        this.f = parcel.readInt();
        this.g = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.h = parcel.readInt();
        this.i = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.j = parcel.createStringArrayList();
        this.k = parcel.createStringArrayList();
        boolean bl2 = parcel.readInt() != 0;
        this.l = bl2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public h(g g2) {
        int n2 = g2.c.size();
        this.a = new int[n2 * 6];
        if (!g2.j) {
            throw new IllegalStateException("Not on back stack");
        }
        int n3 = 0;
        int n4 = 0;
        do {
            if (n3 >= n2) {
                this.b = g2.h;
                this.c = g2.i;
                this.d = g2.l;
                this.e = g2.n;
                this.f = g2.o;
                this.g = g2.p;
                this.h = g2.q;
                this.i = g2.r;
                this.j = g2.s;
                this.k = g2.t;
                this.l = g2.u;
                return;
            }
            g.a a2 = g2.c.get(n3);
            int[] arrn = this.a;
            int n5 = n4 + 1;
            arrn[n4] = a2.a;
            arrn = this.a;
            int n6 = n5 + 1;
            n4 = a2.b != null ? a2.b.n : -1;
            arrn[n5] = n4;
            arrn = this.a;
            n4 = n6 + 1;
            arrn[n6] = a2.c;
            arrn = this.a;
            n5 = n4 + 1;
            arrn[n4] = a2.d;
            arrn = this.a;
            n6 = n5 + 1;
            arrn[n5] = a2.e;
            arrn = this.a;
            n4 = n6 + 1;
            arrn[n6] = a2.f;
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    public g a(s s2) {
        int n2 = 0;
        g g2 = new g(s2);
        int n3 = 0;
        do {
            if (n2 >= this.a.length) {
                g2.h = this.b;
                g2.i = this.c;
                g2.l = this.d;
                g2.n = this.e;
                g2.j = true;
                g2.o = this.f;
                g2.p = this.g;
                g2.q = this.h;
                g2.r = this.i;
                g2.s = this.j;
                g2.t = this.k;
                g2.u = this.l;
                g2.b(1);
                return g2;
            }
            g.a a2 = new g.a();
            int[] arrn = this.a;
            int n4 = n2 + 1;
            a2.a = arrn[n2];
            if (s.a) {
                Log.v((String)"FragmentManager", (String)("Instantiate " + g2 + " op #" + n3 + " base fragment #" + this.a[n4]));
            }
            arrn = this.a;
            n2 = n4 + 1;
            a2.b = (n4 = arrn[n4]) >= 0 ? s2.e.get(n4) : null;
            arrn = this.a;
            n4 = n2 + 1;
            a2.c = arrn[n2];
            arrn = this.a;
            n2 = n4 + 1;
            a2.d = arrn[n4];
            arrn = this.a;
            n4 = n2 + 1;
            a2.e = arrn[n2];
            a2.f = this.a[n4];
            g2.d = a2.c;
            g2.e = a2.d;
            g2.f = a2.e;
            g2.g = a2.f;
            g2.a(a2);
            ++n3;
            n2 = n4 + 1;
        } while (true);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        n2 = 0;
        parcel.writeIntArray(this.a);
        parcel.writeInt(this.b);
        parcel.writeInt(this.c);
        parcel.writeString(this.d);
        parcel.writeInt(this.e);
        parcel.writeInt(this.f);
        TextUtils.writeToParcel((CharSequence)this.g, (Parcel)parcel, (int)0);
        parcel.writeInt(this.h);
        TextUtils.writeToParcel((CharSequence)this.i, (Parcel)parcel, (int)0);
        parcel.writeStringList(this.j);
        parcel.writeStringList(this.k);
        if (this.l) {
            n2 = 1;
        }
        parcel.writeInt(n2);
    }

}

