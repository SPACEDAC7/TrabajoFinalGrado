/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentSender
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.util.AttributeSet
 *  android.view.LayoutInflater
 *  android.view.LayoutInflater$Factory
 *  android.view.View
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.b.ax;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;

@TargetApi(value=9)
abstract class i
extends ax {
    boolean a;

    i() {
    }

    static void b(int n2) {
        if ((-65536 & n2) != 0) {
            throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
        }
    }

    abstract View a(View var1, String var2, Context var3, AttributeSet var4);

    protected void onCreate(Bundle bundle) {
        if (Build.VERSION.SDK_INT < 11 && this.getLayoutInflater().getFactory() == null) {
            this.getLayoutInflater().setFactory((LayoutInflater.Factory)this);
        }
        super.onCreate(bundle);
    }

    public View onCreateView(String string, Context context, AttributeSet attributeSet) {
        View view;
        View view2 = view = this.a(null, string, context, attributeSet);
        if (view == null) {
            view2 = super.onCreateView(string, context, attributeSet);
        }
        return view2;
    }

    public void startIntentSenderForResult(IntentSender intentSender, int n2, Intent intent, int n3, int n4, int n5) {
        if (!this.a && n2 != -1) {
            i.b(n2);
        }
        super.startIntentSenderForResult(intentSender, n2, intent, n3, n4, n5);
    }
}

