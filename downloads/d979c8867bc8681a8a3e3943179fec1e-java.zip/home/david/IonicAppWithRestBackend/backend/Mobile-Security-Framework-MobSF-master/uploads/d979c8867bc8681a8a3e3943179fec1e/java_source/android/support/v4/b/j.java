/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.AttributeSet
 *  android.view.View
 */
package android.support.v4.b;

import android.content.Context;
import android.os.Build;
import android.support.v4.b.i;
import android.util.AttributeSet;
import android.view.View;

abstract class j
extends i {
    j() {
    }

    public View onCreateView(View view, String string, Context context, AttributeSet attributeSet) {
        View view2;
        View view3 = view2 = this.a(view, string, context, attributeSet);
        if (view2 == null) {
            view3 = view2;
            if (Build.VERSION.SDK_INT >= 11) {
                view3 = super.onCreateView(view, string, context, attributeSet);
            }
        }
        return view3;
    }
}

