/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.IntentSender
 *  android.os.Bundle
 */
package android.support.v4.b;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.support.v4.b.j;

abstract class k
extends j {
    boolean b;

    k() {
    }

    public void startActivityForResult(Intent intent, int n2, Bundle bundle) {
        if (!this.b && n2 != -1) {
            k.b(n2);
        }
        super.startActivityForResult(intent, n2, bundle);
    }

    public void startIntentSenderForResult(IntentSender intentSender, int n2, Intent intent, int n3, int n4, int n5, Bundle bundle) {
        if (!this.a && n2 != -1) {
            k.b(n2);
        }
        super.startIntentSenderForResult(intentSender, n2, intent, n3, n4, n5, bundle);
    }
}

