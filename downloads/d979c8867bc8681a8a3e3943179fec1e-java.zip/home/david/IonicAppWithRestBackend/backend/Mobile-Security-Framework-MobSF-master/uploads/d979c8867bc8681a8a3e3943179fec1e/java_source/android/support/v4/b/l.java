/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.DialogInterface$OnDismissListener
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewParent
 *  android.view.Window
 */
package android.support.v4.b;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.b.m;
import android.support.v4.b.n;
import android.support.v4.b.q;
import android.support.v4.b.r;
import android.support.v4.b.w;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewParent;
import android.view.Window;

public class l
extends m
implements DialogInterface.OnCancelListener,
DialogInterface.OnDismissListener {
    int a = 0;
    int b = 0;
    boolean c = true;
    boolean d = true;
    int e = -1;
    Dialog f;
    boolean g;
    boolean h;
    boolean i;

    public int a() {
        return this.b;
    }

    public void a(Dialog dialog, int n2) {
        switch (n2) {
            default: {
                return;
            }
            case 3: {
                dialog.getWindow().addFlags(24);
            }
            case 1: 
            case 2: 
        }
        dialog.requestWindowFeature(1);
    }

    @Override
    public void a(Context context) {
        super.a(context);
        if (!this.i) {
            this.h = false;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        boolean bl2 = this.F == 0;
        this.d = bl2;
        if (bundle != null) {
            this.a = bundle.getInt("android:style", 0);
            this.b = bundle.getInt("android:theme", 0);
            this.c = bundle.getBoolean("android:cancelable", true);
            this.d = bundle.getBoolean("android:showsDialog", this.d);
            this.e = bundle.getInt("android:backStackId", -1);
        }
    }

    public void a(r object, String string) {
        this.h = false;
        this.i = true;
        object = object.a();
        object.a(this, string);
        object.a();
    }

    void a(boolean bl2) {
        if (this.h) {
            return;
        }
        this.h = true;
        this.i = false;
        if (this.f != null) {
            this.f.dismiss();
            this.f = null;
        }
        this.g = true;
        if (this.e >= 0) {
            this.l().a(this.e, 1);
            this.e = -1;
            return;
        }
        w w2 = this.l().a();
        w2.a(this);
        if (bl2) {
            w2.b();
            return;
        }
        w2.a();
    }

    @Override
    public LayoutInflater b(Bundle bundle) {
        if (!this.d) {
            return super.b(bundle);
        }
        this.f = this.c(bundle);
        if (this.f != null) {
            this.a(this.f, this.a);
            return (LayoutInflater)this.f.getContext().getSystemService("layout_inflater");
        }
        return (LayoutInflater)this.A.g().getSystemService("layout_inflater");
    }

    @Override
    public void b() {
        super.b();
        if (!this.i && !this.h) {
            this.h = true;
        }
    }

    public Dialog c(Bundle bundle) {
        return new Dialog((Context)this.j(), this.a());
    }

    @Override
    public void c() {
        super.c();
        if (this.f != null) {
            this.g = false;
            this.f.show();
        }
    }

    @Override
    public void d() {
        super.d();
        if (this.f != null) {
            this.f.hide();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public void d(Bundle bundle) {
        super.d(bundle);
        if (!this.d) {
            return;
        }
        Object object = this.q();
        if (object != null) {
            if (object.getParent() != null) {
                throw new IllegalStateException("DialogFragment can not be attached to a container view");
            }
            this.f.setContentView((View)object);
        }
        if ((object = this.j()) != null) {
            this.f.setOwnerActivity((Activity)object);
        }
        this.f.setCancelable(this.c);
        this.f.setOnCancelListener((DialogInterface.OnCancelListener)this);
        this.f.setOnDismissListener((DialogInterface.OnDismissListener)this);
        if (bundle == null) return;
        if ((bundle = bundle.getBundle("android:savedDialogState")) == null) return;
        this.f.onRestoreInstanceState(bundle);
    }

    @Override
    public void e() {
        super.e();
        if (this.f != null) {
            this.g = true;
            this.f.dismiss();
            this.f = null;
        }
    }

    @Override
    public void e(Bundle bundle) {
        Bundle bundle2;
        super.e(bundle);
        if (this.f != null && (bundle2 = this.f.onSaveInstanceState()) != null) {
            bundle.putBundle("android:savedDialogState", bundle2);
        }
        if (this.a != 0) {
            bundle.putInt("android:style", this.a);
        }
        if (this.b != 0) {
            bundle.putInt("android:theme", this.b);
        }
        if (!this.c) {
            bundle.putBoolean("android:cancelable", this.c);
        }
        if (!this.d) {
            bundle.putBoolean("android:showsDialog", this.d);
        }
        if (this.e != -1) {
            bundle.putInt("android:backStackId", this.e);
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
    }

    public void onDismiss(DialogInterface dialogInterface) {
        if (!this.g) {
            this.a(true);
        }
    }
}

