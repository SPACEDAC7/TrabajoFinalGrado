/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ComponentCallbacks
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.Parcelable
 *  android.util.AttributeSet
 *  android.util.SparseArray
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnCreateContextMenuListener
 *  android.view.ViewGroup
 *  android.view.animation.Animation
 */
package android.support.v4.b;

import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.support.v4.b.ab;
import android.support.v4.b.av;
import android.support.v4.b.aw;
import android.support.v4.b.n;
import android.support.v4.b.o;
import android.support.v4.b.q;
import android.support.v4.b.r;
import android.support.v4.b.s;
import android.support.v4.b.t;
import android.support.v4.j.d;
import android.support.v4.j.k;
import android.support.v4.k.j;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class m
implements ComponentCallbacks,
View.OnCreateContextMenuListener {
    private static final k<String, Class<?>> a = new k();
    static final Object j = new Object();
    q A;
    s B;
    t C;
    m D;
    int E;
    int F;
    String G;
    boolean H;
    boolean I;
    boolean J;
    boolean K;
    boolean L;
    boolean M = true;
    boolean N;
    ViewGroup O;
    View P;
    View Q;
    boolean R;
    boolean S = true;
    ab T;
    boolean U;
    boolean V;
    a W;
    boolean X;
    boolean Y;
    float Z;
    int k = 0;
    Bundle l;
    SparseArray<Parcelable> m;
    int n = -1;
    String o;
    Bundle p;
    m q;
    int r = -1;
    int s;
    boolean t;
    boolean u;
    boolean v;
    boolean w;
    boolean x;
    int y;
    s z;

    private a Y() {
        if (this.W == null) {
            this.W = new a();
        }
        return this.W;
    }

    public static m a(Context context, String string) {
        return m.a(context, string, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static m a(Context object, String string, Bundle bundle) {
        try {
            Class class_;
            Class class_2 = class_ = a.get(string);
            if (class_ == null) {
                class_2 = object.getClassLoader().loadClass(string);
                a.put(string, class_2);
            }
            object = (m)class_2.newInstance();
            if (bundle != null) {
                bundle.setClassLoader(object.getClass().getClassLoader());
                object.p = bundle;
            }
            return object;
        }
        catch (ClassNotFoundException var0_1) {
            throw new b("Unable to instantiate fragment " + string + ": make sure class name exists, is public, and has an" + " empty constructor that is public", var0_1);
        }
        catch (InstantiationException var0_2) {
            throw new b("Unable to instantiate fragment " + string + ": make sure class name exists, is public, and has an" + " empty constructor that is public", var0_2);
        }
        catch (IllegalAccessException var0_3) {
            throw new b("Unable to instantiate fragment " + string + ": make sure class name exists, is public, and has an" + " empty constructor that is public", var0_3);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a() {
        c c2 = null;
        if (this.W != null) {
            this.W.h = false;
            c2 = this.W.i;
            this.W.i = null;
        }
        if (c2 != null) {
            c2.a();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static boolean b(Context context, String string) {
        Class class_;
        try {
            Class class_2;
            class_ = class_2 = a.get(string);
            if (class_2 != null) return m.class.isAssignableFrom(class_);
        }
        catch (ClassNotFoundException var0_1) {
            return false;
        }
        class_ = context.getClassLoader().loadClass(string);
        a.put(string, class_);
        return m.class.isAssignableFrom(class_);
    }

    public Object A() {
        if (this.W == null) {
            return null;
        }
        return this.W.o;
    }

    public Object B() {
        if (this.W == null) {
            return null;
        }
        if (this.W.p == j) {
            return this.A();
        }
        return this.W.p;
    }

    public boolean C() {
        if (this.W == null || this.W.r == null) {
            return true;
        }
        return this.W.r;
    }

    public boolean D() {
        if (this.W == null || this.W.q == null) {
            return true;
        }
        return this.W.q;
    }

    public void E() {
        if (this.z == null || this.z.n == null) {
            this.Y().h = false;
            return;
        }
        if (Looper.myLooper() != this.z.n.h().getLooper()) {
            this.z.n.h().postAtFrontOfQueue(new Runnable(){

                @Override
                public void run() {
                    m.this.a();
                }
            });
            return;
        }
        this.a();
    }

    void F() {
        this.B = new s();
        this.B.a(this.A, new o(){

            @Override
            public View a(int n2) {
                if (m.this.P == null) {
                    throw new IllegalStateException("Fragment does not have a view");
                }
                return m.this.P.findViewById(n2);
            }

            @Override
            public boolean a() {
                if (m.this.P != null) {
                    return true;
                }
                return false;
            }
        }, this);
    }

    void G() {
        if (this.B != null) {
            this.B.j();
            this.B.e();
        }
        this.k = 4;
        this.N = false;
        this.c();
        if (!this.N) {
            throw new aw("Fragment " + this + " did not call through to super.onStart()");
        }
        if (this.B != null) {
            this.B.m();
        }
        if (this.T != null) {
            this.T.g();
        }
    }

    void H() {
        if (this.B != null) {
            this.B.j();
            this.B.e();
        }
        this.k = 5;
        this.N = false;
        this.r();
        if (!this.N) {
            throw new aw("Fragment " + this + " did not call through to super.onResume()");
        }
        if (this.B != null) {
            this.B.n();
            this.B.e();
        }
    }

    void I() {
        this.onLowMemory();
        if (this.B != null) {
            this.B.t();
        }
    }

    void J() {
        if (this.B != null) {
            this.B.o();
        }
        this.k = 4;
        this.N = false;
        this.s();
        if (!this.N) {
            throw new aw("Fragment " + this + " did not call through to super.onPause()");
        }
    }

    void K() {
        if (this.B != null) {
            this.B.p();
        }
        this.k = 3;
        this.N = false;
        this.d();
        if (!this.N) {
            throw new aw("Fragment " + this + " did not call through to super.onStop()");
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    void L() {
        if (this.B != null) {
            this.B.q();
        }
        this.k = 2;
        if (!this.U) return;
        this.U = false;
        if (!this.V) {
            this.V = true;
            this.T = this.A.a(this.o, this.U, false);
        }
        if (this.T == null) return;
        if (this.A.k()) {
            this.T.d();
            return;
        }
        this.T.c();
    }

    void M() {
        if (this.B != null) {
            this.B.r();
        }
        this.k = 1;
        this.N = false;
        this.e();
        if (!this.N) {
            throw new aw("Fragment " + this + " did not call through to super.onDestroyView()");
        }
        if (this.T != null) {
            this.T.f();
        }
    }

    void N() {
        if (this.B != null) {
            this.B.s();
        }
        this.k = 0;
        this.N = false;
        this.t();
        if (!this.N) {
            throw new aw("Fragment " + this + " did not call through to super.onDestroy()");
        }
        this.B = null;
    }

    void O() {
        this.N = false;
        this.b();
        if (!this.N) {
            throw new aw("Fragment " + this + " did not call through to super.onDetach()");
        }
        if (this.B != null) {
            if (!this.K) {
                throw new IllegalStateException("Child FragmentManager of " + this + " was not " + " destroyed and this fragment is not retaining instance");
            }
            this.B.s();
            this.B = null;
        }
    }

    int P() {
        if (this.W == null) {
            return 0;
        }
        return this.W.c;
    }

    int Q() {
        if (this.W == null) {
            return 0;
        }
        return this.W.d;
    }

    int R() {
        if (this.W == null) {
            return 0;
        }
        return this.W.e;
    }

    av S() {
        if (this.W == null) {
            return null;
        }
        return this.W.f;
    }

    av T() {
        if (this.W == null) {
            return null;
        }
        return this.W.g;
    }

    View U() {
        if (this.W == null) {
            return null;
        }
        return this.W.a;
    }

    int V() {
        if (this.W == null) {
            return 0;
        }
        return this.W.b;
    }

    boolean W() {
        if (this.W == null) {
            return false;
        }
        return this.W.h;
    }

    boolean X() {
        if (this.W == null) {
            return false;
        }
        return this.W.j;
    }

    m a(String string) {
        if (string.equals(this.o)) {
            return this;
        }
        if (this.B != null) {
            return this.B.b(string);
        }
        return null;
    }

    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return null;
    }

    public Animation a(int n2, boolean bl2, int n3) {
        return null;
    }

    public final String a(int n2) {
        return this.k().getString(n2);
    }

    public final /* varargs */ String a(int n2, Object ... arrobject) {
        return this.k().getString(n2, arrobject);
    }

    void a(int n2, int n3) {
        if (this.W == null && n2 == 0 && n3 == 0) {
            return;
        }
        this.Y();
        this.W.d = n2;
        this.W.e = n3;
    }

    public void a(int n2, int n3, Intent intent) {
    }

    final void a(int n2, m m2) {
        this.n = n2;
        if (m2 != null) {
            this.o = m2.o + ":" + this.n;
            return;
        }
        this.o = "android:fragment:" + this.n;
    }

    public void a(int n2, String[] arrstring, int[] arrn) {
    }

    @Deprecated
    public void a(Activity activity) {
        this.N = true;
    }

    @Deprecated
    public void a(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        this.N = true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(Context context) {
        this.N = true;
        if (this.A == null) {
            return;
        }
        context = this.A.f();
        if (context != null) {
            this.N = false;
            this.a((Activity)context);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.N = true;
        if (this.A == null) {
            return;
        }
        context = this.A.f();
        if (context != null) {
            this.N = false;
            this.a((Activity)context, attributeSet, bundle);
        }
    }

    void a(Configuration configuration) {
        this.onConfigurationChanged(configuration);
        if (this.B != null) {
            this.B.a(configuration);
        }
    }

    public void a(Bundle bundle) {
        this.N = true;
        this.h(bundle);
        if (this.B != null && !this.B.a(1)) {
            this.B.k();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    void a(c c2) {
        this.Y();
        if (c2 == this.W.i) {
            return;
        }
        if (c2 != null && this.W.i != null) {
            throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
        }
        if (this.W.h) {
            this.W.i = c2;
        }
        if (c2 == null) return;
        c2.b();
    }

    public void a(m m2) {
    }

    public void a(m m2, int n2) {
        this.q = m2;
        this.s = n2;
    }

    public void a(Menu menu) {
    }

    public void a(Menu menu, MenuInflater menuInflater) {
    }

    public void a(View view) {
        view.setOnCreateContextMenuListener((View.OnCreateContextMenuListener)this);
    }

    public void a(View view, Bundle bundle) {
    }

    public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        printWriter.print(string);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.E));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.F));
        printWriter.print(" mTag=");
        printWriter.println(this.G);
        printWriter.print(string);
        printWriter.print("mState=");
        printWriter.print(this.k);
        printWriter.print(" mIndex=");
        printWriter.print(this.n);
        printWriter.print(" mWho=");
        printWriter.print(this.o);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.y);
        printWriter.print(string);
        printWriter.print("mAdded=");
        printWriter.print(this.t);
        printWriter.print(" mRemoving=");
        printWriter.print(this.u);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.v);
        printWriter.print(" mInLayout=");
        printWriter.println(this.w);
        printWriter.print(string);
        printWriter.print("mHidden=");
        printWriter.print(this.H);
        printWriter.print(" mDetached=");
        printWriter.print(this.I);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.M);
        printWriter.print(" mHasMenu=");
        printWriter.println(this.L);
        printWriter.print(string);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.J);
        printWriter.print(" mRetaining=");
        printWriter.print(this.K);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.S);
        if (this.z != null) {
            printWriter.print(string);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.z);
        }
        if (this.A != null) {
            printWriter.print(string);
            printWriter.print("mHost=");
            printWriter.println(this.A);
        }
        if (this.D != null) {
            printWriter.print(string);
            printWriter.print("mParentFragment=");
            printWriter.println(this.D);
        }
        if (this.p != null) {
            printWriter.print(string);
            printWriter.print("mArguments=");
            printWriter.println((Object)this.p);
        }
        if (this.l != null) {
            printWriter.print(string);
            printWriter.print("mSavedFragmentState=");
            printWriter.println((Object)this.l);
        }
        if (this.m != null) {
            printWriter.print(string);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.m);
        }
        if (this.q != null) {
            printWriter.print(string);
            printWriter.print("mTarget=");
            printWriter.print(this.q);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.s);
        }
        if (this.P() != 0) {
            printWriter.print(string);
            printWriter.print("mNextAnim=");
            printWriter.println(this.P());
        }
        if (this.O != null) {
            printWriter.print(string);
            printWriter.print("mContainer=");
            printWriter.println((Object)this.O);
        }
        if (this.P != null) {
            printWriter.print(string);
            printWriter.print("mView=");
            printWriter.println((Object)this.P);
        }
        if (this.Q != null) {
            printWriter.print(string);
            printWriter.print("mInnerView=");
            printWriter.println((Object)this.P);
        }
        if (this.U() != null) {
            printWriter.print(string);
            printWriter.print("mAnimatingAway=");
            printWriter.println((Object)this.U());
            printWriter.print(string);
            printWriter.print("mStateAfterAnimating=");
            printWriter.println(this.V());
        }
        if (this.T != null) {
            printWriter.print(string);
            printWriter.println("Loader Manager:");
            this.T.a(string + "  ", fileDescriptor, printWriter, arrstring);
        }
        if (this.B != null) {
            printWriter.print(string);
            printWriter.println("Child " + this.B + ":");
            this.B.a(string + "  ", fileDescriptor, printWriter, arrstring);
        }
    }

    public boolean a(MenuItem menuItem) {
        return false;
    }

    public LayoutInflater b(Bundle bundle) {
        bundle = this.A.b();
        this.m();
        j.a((LayoutInflater)bundle, this.B.u());
        return bundle;
    }

    View b(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        if (this.B != null) {
            this.B.j();
        }
        return this.a(layoutInflater, viewGroup, bundle);
    }

    public void b() {
        this.N = true;
    }

    void b(int n2) {
        if (this.W == null && n2 == 0) {
            return;
        }
        this.Y().c = n2;
    }

    public void b(Menu menu) {
    }

    void b(View view) {
        this.Y().a = view;
    }

    public void b(boolean bl2) {
    }

    boolean b(Menu menu, MenuInflater menuInflater) {
        boolean bl2 = false;
        boolean bl3 = false;
        if (!this.H) {
            boolean bl4 = bl3;
            if (this.L) {
                bl4 = bl3;
                if (this.M) {
                    bl4 = true;
                    this.a(menu, menuInflater);
                }
            }
            bl2 = bl4;
            if (this.B != null) {
                bl2 = bl4 | this.B.a(menu, menuInflater);
            }
        }
        return bl2;
    }

    public boolean b(MenuItem menuItem) {
        return false;
    }

    public void c() {
        this.N = true;
        if (!this.U) {
            this.U = true;
            if (!this.V) {
                this.V = true;
                this.T = this.A.a(this.o, this.U, false);
            }
            if (this.T != null) {
                this.T.b();
            }
        }
    }

    void c(int n2) {
        this.Y().b = n2;
    }

    public void c(boolean bl2) {
        this.J = bl2;
    }

    boolean c(Menu menu) {
        boolean bl2 = false;
        boolean bl3 = false;
        if (!this.H) {
            boolean bl4 = bl3;
            if (this.L) {
                bl4 = bl3;
                if (this.M) {
                    bl4 = true;
                    this.a(menu);
                }
            }
            bl2 = bl4;
            if (this.B != null) {
                bl2 = bl4 | this.B.a(menu);
            }
        }
        return bl2;
    }

    /*
     * Enabled aggressive block sorting
     */
    boolean c(MenuItem menuItem) {
        if (!this.H && (this.L && this.M && this.a(menuItem) || this.B != null && this.B.a(menuItem))) {
            return true;
        }
        return false;
    }

    public void d() {
        this.N = true;
    }

    public void d(Bundle bundle) {
        this.N = true;
    }

    void d(Menu menu) {
        if (!this.H) {
            if (this.L && this.M) {
                this.b(menu);
            }
            if (this.B != null) {
                this.B.b(menu);
            }
        }
    }

    public void d(boolean bl2) {
        if (this.L != bl2) {
            this.L = bl2;
            if (this.n() && !this.p()) {
                this.A.c();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    boolean d(MenuItem menuItem) {
        if (!this.H && (this.b(menuItem) || this.B != null && this.B.b(menuItem))) {
            return true;
        }
        return false;
    }

    public void e() {
        this.N = true;
    }

    public void e(Bundle bundle) {
    }

    public void e(boolean bl2) {
    }

    public final boolean equals(Object object) {
        return super.equals(object);
    }

    final void f(Bundle bundle) {
        if (this.m != null) {
            this.Q.restoreHierarchyState(this.m);
            this.m = null;
        }
        this.N = false;
        this.i(bundle);
        if (!this.N) {
            throw new aw("Fragment " + this + " did not call through to super.onViewStateRestored()");
        }
    }

    public void f(boolean bl2) {
    }

    final boolean f() {
        if (this.y > 0) {
            return true;
        }
        return false;
    }

    public final Bundle g() {
        return this.p;
    }

    public void g(Bundle bundle) {
        if (this.n >= 0) {
            throw new IllegalStateException("Fragment already active");
        }
        this.p = bundle;
    }

    void g(boolean bl2) {
        this.e(bl2);
        if (this.B != null) {
            this.B.a(bl2);
        }
    }

    public final m h() {
        return this.q;
    }

    void h(Bundle bundle) {
        if (bundle != null && (bundle = bundle.getParcelable("android:support:fragments")) != null) {
            if (this.B == null) {
                this.F();
            }
            this.B.a((Parcelable)bundle, this.C);
            this.C = null;
            this.B.k();
        }
    }

    void h(boolean bl2) {
        this.f(bl2);
        if (this.B != null) {
            this.B.b(bl2);
        }
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public Context i() {
        if (this.A == null) {
            return null;
        }
        return this.A.g();
    }

    public void i(Bundle bundle) {
        this.N = true;
    }

    void i(boolean bl2) {
        this.Y().j = bl2;
    }

    public final n j() {
        if (this.A == null) {
            return null;
        }
        return (n)this.A.f();
    }

    void j(Bundle bundle) {
        if (this.B != null) {
            this.B.j();
        }
        this.k = 1;
        this.N = false;
        this.a(bundle);
        if (!this.N) {
            throw new aw("Fragment " + this + " did not call through to super.onCreate()");
        }
    }

    public final Resources k() {
        if (this.A == null) {
            throw new IllegalStateException("Fragment " + this + " not attached to Activity");
        }
        return this.A.g().getResources();
    }

    void k(Bundle bundle) {
        if (this.B != null) {
            this.B.j();
        }
        this.k = 2;
        this.N = false;
        this.d(bundle);
        if (!this.N) {
            throw new aw("Fragment " + this + " did not call through to super.onActivityCreated()");
        }
        if (this.B != null) {
            this.B.l();
        }
    }

    public final r l() {
        return this.z;
    }

    void l(Bundle bundle) {
        Parcelable parcelable;
        this.e(bundle);
        if (this.B != null && (parcelable = this.B.i()) != null) {
            bundle.putParcelable("android:support:fragments", parcelable);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final r m() {
        if (this.B != null) return this.B;
        this.F();
        if (this.k >= 5) {
            this.B.n();
            return this.B;
        }
        if (this.k >= 4) {
            this.B.m();
            return this.B;
        }
        if (this.k >= 2) {
            this.B.l();
            return this.B;
        }
        if (this.k < 1) return this.B;
        this.B.k();
        return this.B;
    }

    public final boolean n() {
        if (this.A != null && this.t) {
            return true;
        }
        return false;
    }

    public final boolean o() {
        if (this.n() && !this.p() && this.P != null && this.P.getWindowToken() != null && this.P.getVisibility() == 0) {
            return true;
        }
        return false;
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.N = true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.j().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    public void onLowMemory() {
        this.N = true;
    }

    public final boolean p() {
        return this.H;
    }

    public View q() {
        return this.P;
    }

    public void r() {
        this.N = true;
    }

    public void s() {
        this.N = true;
    }

    public void t() {
        this.N = true;
        if (!this.V) {
            this.V = true;
            this.T = this.A.a(this.o, this.U, false);
        }
        if (this.T != null) {
            this.T.h();
        }
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        d.a(this, stringBuilder);
        if (this.n >= 0) {
            stringBuilder.append(" #");
            stringBuilder.append(this.n);
        }
        if (this.E != 0) {
            stringBuilder.append(" id=0x");
            stringBuilder.append(Integer.toHexString(this.E));
        }
        if (this.G != null) {
            stringBuilder.append(" ");
            stringBuilder.append(this.G);
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    void u() {
        this.n = -1;
        this.o = null;
        this.t = false;
        this.u = false;
        this.v = false;
        this.w = false;
        this.x = false;
        this.y = 0;
        this.z = null;
        this.B = null;
        this.A = null;
        this.E = 0;
        this.F = 0;
        this.G = null;
        this.H = false;
        this.I = false;
        this.K = false;
        this.T = null;
        this.U = false;
        this.V = false;
    }

    public void v() {
    }

    public Object w() {
        if (this.W == null) {
            return null;
        }
        return this.W.k;
    }

    public Object x() {
        if (this.W == null) {
            return null;
        }
        if (this.W.l == j) {
            return this.w();
        }
        return this.W.l;
    }

    public Object y() {
        if (this.W == null) {
            return null;
        }
        return this.W.m;
    }

    public Object z() {
        if (this.W == null) {
            return null;
        }
        if (this.W.n == j) {
            return this.y();
        }
        return this.W.n;
    }

    static class a {
        View a;
        int b;
        int c;
        int d;
        int e;
        av f = null;
        av g = null;
        boolean h;
        c i;
        boolean j;
        private Object k = null;
        private Object l = m.j;
        private Object m = null;
        private Object n = m.j;
        private Object o = null;
        private Object p = m.j;
        private Boolean q;
        private Boolean r;

        a() {
        }
    }

    public static class b
    extends RuntimeException {
        public b(String string, Exception exception) {
            super(string, exception);
        }
    }

    static interface c {
        public void a();

        public void b();
    }

}

