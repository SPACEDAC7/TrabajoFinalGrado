/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentSender
 *  android.content.res.Configuration
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Message
 *  android.os.Parcelable
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 */
package android.support.v4.b;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.b.a;
import android.support.v4.b.aa;
import android.support.v4.b.b;
import android.support.v4.b.c;
import android.support.v4.b.k;
import android.support.v4.b.m;
import android.support.v4.b.p;
import android.support.v4.b.q;
import android.support.v4.b.r;
import android.support.v4.b.t;
import android.support.v4.j.l;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class n
extends k
implements a.a,
b.a {
    final Handler c;
    final p d;
    boolean e;
    boolean f;
    boolean g;
    boolean h;
    boolean i;
    boolean j;
    boolean k;
    int l;
    l<String> m;

    public n() {
        this.c = new Handler(){

            /*
             * Enabled aggressive block sorting
             */
            public void handleMessage(Message message) {
                switch (message.what) {
                    default: {
                        super.handleMessage(message);
                        return;
                    }
                    case 1: {
                        if (!n.this.g) return;
                        {
                            n.this.a(false);
                            return;
                        }
                    }
                    case 2: 
                }
                n.this.a();
                n.this.d.o();
            }
        };
        this.d = p.a(new a());
    }

    /*
     * Exception decompiling
     */
    private static String a(View var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [7[CASE]], but top level block is 0[TRYBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(String string, PrintWriter printWriter, View view) {
        printWriter.print(string);
        if (view == null) {
            printWriter.println("null");
            return;
        } else {
            int n2;
            printWriter.println(n.a(view));
            if (!(view instanceof ViewGroup) || (n2 = (view = (ViewGroup)view).getChildCount()) <= 0) return;
            {
                string = string + "  ";
                int n3 = 0;
                while (n3 < n2) {
                    this.a(string, printWriter, view.getChildAt(n3));
                    ++n3;
                }
                return;
            }
        }
    }

    @Override
    final View a(View view, String string, Context context, AttributeSet attributeSet) {
        return this.d.a(view, string, context, attributeSet);
    }

    protected void a() {
        this.d.i();
    }

    @Override
    public final void a(int n2) {
        if (!this.k && n2 != -1) {
            n.b(n2);
        }
    }

    public void a(m m2) {
    }

    /*
     * Enabled aggressive block sorting
     */
    void a(boolean bl2) {
        if (!this.h) {
            this.h = true;
            this.i = bl2;
            this.c.removeMessages(1);
            this.b_();
            return;
        } else {
            if (!bl2) return;
            {
                this.d.p();
                this.d.c(true);
                return;
            }
        }
    }

    protected boolean a(View view, Menu menu) {
        return super.onPreparePanel(0, view, menu);
    }

    public Object a_() {
        return null;
    }

    void b_() {
        this.d.c(this.i);
        this.d.l();
    }

    public void c_() {
        if (Build.VERSION.SDK_INT >= 11) {
            c.a(this);
            return;
        }
        this.j = true;
    }

    public void dump(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        if (Build.VERSION.SDK_INT >= 11) {
            // empty if block
        }
        printWriter.print(string);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String string2 = string + "  ";
        printWriter.print(string2);
        printWriter.print("mCreated=");
        printWriter.print(this.e);
        printWriter.print("mResumed=");
        printWriter.print(this.f);
        printWriter.print(" mStopped=");
        printWriter.print(this.g);
        printWriter.print(" mReallyStopped=");
        printWriter.println(this.h);
        this.d.a(string2, fileDescriptor, printWriter, arrstring);
        this.d.a().a(string, fileDescriptor, printWriter, arrstring);
        printWriter.print(string);
        printWriter.println("View Hierarchy:");
        this.a(string + "  ", printWriter, this.getWindow().getDecorView());
    }

    public r e() {
        return this.d.a();
    }

    public aa f() {
        return this.d.b();
    }

    protected void onActivityResult(int n2, int n3, Intent intent) {
        this.d.c();
        int n4 = n2 >> 16;
        if (n4 != 0) {
            String string = this.m.a(--n4);
            this.m.c(n4);
            if (string == null) {
                Log.w((String)"FragmentActivity", (String)"Activity result delivered for unknown Fragment.");
                return;
            }
            m m2 = this.d.a(string);
            if (m2 == null) {
                Log.w((String)"FragmentActivity", (String)("Activity result no fragment exists for who: " + string));
                return;
            }
            m2.a(65535 & n2, n3, intent);
            return;
        }
        super.onActivityResult(n2, n3, intent);
    }

    public void onBackPressed() {
        if (!this.d.a().c()) {
            super.onBackPressed();
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.d.a(configuration);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void onCreate(Bundle arrstring) {
        this.d.a((m)null);
        super.onCreate((Bundle)arrstring);
        Object object = (b)this.getLastNonConfigurationInstance();
        if (object != null) {
            this.d.a(object.c);
        }
        if (arrstring != null) {
            Parcelable parcelable = arrstring.getParcelable("android:support:fragments");
            p p2 = this.d;
            object = object != null ? object.b : null;
            p2.a(parcelable, (t)object);
            if (arrstring.containsKey("android:support:next_request_index")) {
                this.l = arrstring.getInt("android:support:next_request_index");
                object = arrstring.getIntArray("android:support:request_indicies");
                arrstring = arrstring.getStringArray("android:support:request_fragment_who");
                if (object == null || arrstring == null || object.length != arrstring.length) {
                    Log.w((String)"FragmentActivity", (String)"Invalid requestCode mapping in savedInstanceState.");
                } else {
                    this.m = new l(object.length);
                    for (int i2 = 0; i2 < object.length; ++i2) {
                        this.m.b(object[i2], arrstring[i2]);
                    }
                }
            }
        }
        if (this.m == null) {
            this.m = new l();
            this.l = 0;
        }
        this.d.f();
    }

    public boolean onCreatePanelMenu(int n2, Menu menu) {
        if (n2 == 0) {
            boolean bl2 = super.onCreatePanelMenu(n2, menu);
            boolean bl3 = this.d.a(menu, this.getMenuInflater());
            if (Build.VERSION.SDK_INT >= 11) {
                return bl2 | bl3;
            }
            return true;
        }
        return super.onCreatePanelMenu(n2, menu);
    }

    protected void onDestroy() {
        super.onDestroy();
        this.a(false);
        this.d.m();
        this.d.q();
    }

    public void onLowMemory() {
        super.onLowMemory();
        this.d.n();
    }

    public boolean onMenuItemSelected(int n2, MenuItem menuItem) {
        if (super.onMenuItemSelected(n2, menuItem)) {
            return true;
        }
        switch (n2) {
            default: {
                return false;
            }
            case 0: {
                return this.d.a(menuItem);
            }
            case 6: 
        }
        return this.d.b(menuItem);
    }

    public void onMultiWindowModeChanged(boolean bl2) {
        this.d.a(bl2);
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.d.c();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onPanelClosed(int n2, Menu menu) {
        switch (n2) {
            default: {
                break;
            }
            case 0: {
                this.d.b(menu);
            }
        }
        super.onPanelClosed(n2, menu);
    }

    protected void onPause() {
        super.onPause();
        this.f = false;
        if (this.c.hasMessages(2)) {
            this.c.removeMessages(2);
            this.a();
        }
        this.d.j();
    }

    public void onPictureInPictureModeChanged(boolean bl2) {
        this.d.b(bl2);
    }

    protected void onPostResume() {
        super.onPostResume();
        this.c.removeMessages(2);
        this.a();
        this.d.o();
    }

    public boolean onPreparePanel(int n2, View view, Menu menu) {
        if (n2 == 0 && menu != null) {
            if (this.j) {
                this.j = false;
                menu.clear();
                this.onCreatePanelMenu(n2, menu);
            }
            return this.a(view, menu) | this.d.a(menu);
        }
        return super.onPreparePanel(n2, view, menu);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void onRequestPermissionsResult(int n2, String[] arrstring, int[] arrn) {
        int n3 = n2 >> 16 & 65535;
        if (n3 == 0) return;
        String string = this.m.a(--n3);
        this.m.c(n3);
        if (string == null) {
            Log.w((String)"FragmentActivity", (String)"Activity result delivered for unknown Fragment.");
            return;
        }
        m m2 = this.d.a(string);
        if (m2 == null) {
            Log.w((String)"FragmentActivity", (String)("Activity result no fragment exists for who: " + string));
            return;
        }
        m2.a(n2 & 65535, arrstring, arrn);
    }

    protected void onResume() {
        super.onResume();
        this.c.sendEmptyMessage(2);
        this.f = true;
        this.d.o();
    }

    public final Object onRetainNonConfigurationInstance() {
        if (this.g) {
            this.a(true);
        }
        Object object = this.a_();
        t t2 = this.d.e();
        android.support.v4.j.k<String, aa> k2 = this.d.s();
        if (t2 == null && k2 == null && object == null) {
            return null;
        }
        b b2 = new b();
        b2.a = object;
        b2.b = t2;
        b2.c = k2;
        return b2;
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        int[] arrn = this.d.d();
        if (arrn != null) {
            bundle.putParcelable("android:support:fragments", (Parcelable)arrn);
        }
        if (this.m.b() > 0) {
            bundle.putInt("android:support:next_request_index", this.l);
            arrn = new int[this.m.b()];
            String[] arrstring = new String[this.m.b()];
            for (int i2 = 0; i2 < this.m.b(); ++i2) {
                arrn[i2] = this.m.d(i2);
                arrstring[i2] = this.m.e(i2);
            }
            bundle.putIntArray("android:support:request_indicies", arrn);
            bundle.putStringArray("android:support:request_fragment_who", arrstring);
        }
    }

    protected void onStart() {
        super.onStart();
        this.g = false;
        this.h = false;
        this.c.removeMessages(1);
        if (!this.e) {
            this.e = true;
            this.d.g();
        }
        this.d.c();
        this.d.o();
        this.d.p();
        this.d.h();
        this.d.r();
    }

    public void onStateNotSaved() {
        this.d.c();
    }

    protected void onStop() {
        super.onStop();
        this.g = true;
        this.c.sendEmptyMessage(1);
        this.d.k();
    }

    public void startActivityForResult(Intent intent, int n2) {
        if (!this.b && n2 != -1) {
            n.b(n2);
        }
        super.startActivityForResult(intent, n2);
    }

    class a
    extends q<n> {
        public a() {
            super(n.this);
        }

        @Override
        public View a(int n2) {
            return n.this.findViewById(n2);
        }

        @SuppressLint(value={"NewApi"})
        @Override
        public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
            n.this.dump(string, fileDescriptor, printWriter, arrstring);
        }

        @Override
        public boolean a() {
            Window window = n.this.getWindow();
            if (window != null && window.peekDecorView() != null) {
                return true;
            }
            return false;
        }

        @Override
        public boolean a(m m2) {
            if (!n.this.isFinishing()) {
                return true;
            }
            return false;
        }

        @Override
        public LayoutInflater b() {
            return n.this.getLayoutInflater().cloneInContext((Context)n.this);
        }

        @Override
        public void b(m m2) {
            n.this.a(m2);
        }

        @Override
        public void c() {
            n.this.c_();
        }

        @Override
        public boolean d() {
            if (n.this.getWindow() != null) {
                return true;
            }
            return false;
        }

        @Override
        public int e() {
            Window window = n.this.getWindow();
            if (window == null) {
                return 0;
            }
            return window.getAttributes().windowAnimations;
        }
    }

    static final class b {
        Object a;
        t b;
        android.support.v4.j.k<String, aa> c;

        b() {
        }
    }

}

