/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package android.support.v4.b;

import android.view.View;

public abstract class o {
    public abstract View a(int var1);

    public abstract boolean a();
}

