/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Parcelable
 *  android.util.AttributeSet
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 */
package android.support.v4.b;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.support.v4.b.aa;
import android.support.v4.b.ab;
import android.support.v4.b.m;
import android.support.v4.b.o;
import android.support.v4.b.q;
import android.support.v4.b.r;
import android.support.v4.b.s;
import android.support.v4.b.t;
import android.support.v4.j.k;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class p {
    private final q<?> a;

    private p(q<?> q2) {
        this.a = q2;
    }

    public static final p a(q<?> q2) {
        return new p(q2);
    }

    public m a(String string) {
        return this.a.d.b(string);
    }

    public r a() {
        return this.a.i();
    }

    public View a(View view, String string, Context context, AttributeSet attributeSet) {
        return this.a.d.a(view, string, context, attributeSet);
    }

    public void a(Configuration configuration) {
        this.a.d.a(configuration);
    }

    public void a(Parcelable parcelable, t t2) {
        this.a.d.a(parcelable, t2);
    }

    public void a(m m2) {
        this.a.d.a(this.a, this.a, m2);
    }

    public void a(k<String, aa> k2) {
        this.a.a(k2);
    }

    public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        this.a.b(string, fileDescriptor, printWriter, arrstring);
    }

    public void a(boolean bl2) {
        this.a.d.a(bl2);
    }

    public boolean a(Menu menu) {
        return this.a.d.a(menu);
    }

    public boolean a(Menu menu, MenuInflater menuInflater) {
        return this.a.d.a(menu, menuInflater);
    }

    public boolean a(MenuItem menuItem) {
        return this.a.d.a(menuItem);
    }

    public aa b() {
        return this.a.j();
    }

    public void b(Menu menu) {
        this.a.d.b(menu);
    }

    public void b(boolean bl2) {
        this.a.d.b(bl2);
    }

    public boolean b(MenuItem menuItem) {
        return this.a.d.b(menuItem);
    }

    public void c() {
        this.a.d.j();
    }

    public void c(boolean bl2) {
        this.a.a(bl2);
    }

    public Parcelable d() {
        return this.a.d.i();
    }

    public t e() {
        return this.a.d.h();
    }

    public void f() {
        this.a.d.k();
    }

    public void g() {
        this.a.d.l();
    }

    public void h() {
        this.a.d.m();
    }

    public void i() {
        this.a.d.n();
    }

    public void j() {
        this.a.d.o();
    }

    public void k() {
        this.a.d.p();
    }

    public void l() {
        this.a.d.q();
    }

    public void m() {
        this.a.d.s();
    }

    public void n() {
        this.a.d.t();
    }

    public boolean o() {
        return this.a.d.e();
    }

    public void p() {
        this.a.l();
    }

    public void q() {
        this.a.m();
    }

    public void r() {
        this.a.n();
    }

    public k<String, aa> s() {
        return this.a.o();
    }
}

