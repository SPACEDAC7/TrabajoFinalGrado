/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Handler
 *  android.view.LayoutInflater
 *  android.view.View
 */
package android.support.v4.b;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.support.v4.b.aa;
import android.support.v4.b.ab;
import android.support.v4.b.m;
import android.support.v4.b.n;
import android.support.v4.b.o;
import android.support.v4.b.s;
import android.support.v4.j.k;
import android.view.LayoutInflater;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class q<E>
extends o {
    private final Activity a;
    final Context b;
    final int c;
    final s d = new s();
    private final Handler e;
    private k<String, aa> f;
    private boolean g;
    private ab h;
    private boolean i;
    private boolean j;

    q(Activity activity, Context context, Handler handler, int n2) {
        this.a = activity;
        this.b = context;
        this.e = handler;
        this.c = n2;
    }

    q(n n2) {
        this(n2, (Context)n2, n2.c, 0);
    }

    ab a(String string, boolean bl2, boolean bl3) {
        ab ab2;
        if (this.f == null) {
            this.f = new k();
        }
        if ((ab2 = (ab)this.f.get(string)) == null) {
            if (bl3) {
                ab2 = new ab(string, this, bl2);
                this.f.put(string, ab2);
            }
            return ab2;
        }
        ab2.a(this);
        return ab2;
    }

    @Override
    public View a(int n2) {
        return null;
    }

    void a(k<String, aa> k2) {
        this.f = k2;
    }

    void a(String string) {
        ab ab2;
        if (this.f != null && (ab2 = (ab)this.f.get(string)) != null && !ab2.f) {
            ab2.h();
            this.f.remove(string);
        }
    }

    public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
    }

    /*
     * Enabled aggressive block sorting
     */
    void a(boolean bl2) {
        this.g = bl2;
        if (this.h == null || !this.j) {
            return;
        }
        this.j = false;
        if (bl2) {
            this.h.d();
            return;
        }
        this.h.c();
    }

    @Override
    public boolean a() {
        return true;
    }

    public boolean a(m m2) {
        return true;
    }

    public LayoutInflater b() {
        return (LayoutInflater)this.b.getSystemService("layout_inflater");
    }

    void b(m m2) {
    }

    void b(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        printWriter.print(string);
        printWriter.print("mLoadersStarted=");
        printWriter.println(this.j);
        if (this.h != null) {
            printWriter.print(string);
            printWriter.print("Loader Manager ");
            printWriter.print(Integer.toHexString(System.identityHashCode(this.h)));
            printWriter.println(":");
            this.h.a(string + "  ", fileDescriptor, printWriter, arrstring);
        }
    }

    public void c() {
    }

    public boolean d() {
        return true;
    }

    public int e() {
        return this.c;
    }

    Activity f() {
        return this.a;
    }

    Context g() {
        return this.b;
    }

    Handler h() {
        return this.e;
    }

    s i() {
        return this.d;
    }

    ab j() {
        if (this.h != null) {
            return this.h;
        }
        this.i = true;
        this.h = this.a("(root)", this.j, true);
        return this.h;
    }

    boolean k() {
        return this.g;
    }

    /*
     * Enabled aggressive block sorting
     */
    void l() {
        if (this.j) {
            return;
        }
        this.j = true;
        if (this.h != null) {
            this.h.b();
        } else if (!this.i) {
            this.h = this.a("(root)", this.j, false);
            if (this.h != null && !this.h.e) {
                this.h.b();
            }
        }
        this.i = true;
    }

    void m() {
        if (this.h == null) {
            return;
        }
        this.h.h();
    }

    void n() {
        if (this.f != null) {
            int n2;
            int n3 = this.f.size();
            ab[] arrab = new ab[n3];
            for (n2 = n3 - 1; n2 >= 0; --n2) {
                arrab[n2] = (ab)this.f.c(n2);
            }
            for (n2 = 0; n2 < n3; ++n2) {
                ab ab2 = arrab[n2];
                ab2.e();
                ab2.g();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    k<String, aa> o() {
        int n2;
        int n3 = 0;
        if (this.f == null) return null;
        int n4 = this.f.size();
        ab[] arrab = new ab[n4];
        for (n2 = n4 - 1; n2 >= 0; --n2) {
            arrab[n2] = (ab)this.f.c(n2);
        }
        boolean bl2 = this.k();
        n2 = 0;
        do {
            int n5 = n2;
            if (n3 >= n4) return null;
            ab ab2 = arrab[n3];
            if (!ab2.f && bl2) {
                if (!ab2.e) {
                    ab2.b();
                }
                ab2.d();
            }
            if (ab2.f) {
                n2 = 1;
            } else {
                ab2.h();
                this.f.remove(ab2.d);
            }
            ++n3;
        } while (true);
    }
}

