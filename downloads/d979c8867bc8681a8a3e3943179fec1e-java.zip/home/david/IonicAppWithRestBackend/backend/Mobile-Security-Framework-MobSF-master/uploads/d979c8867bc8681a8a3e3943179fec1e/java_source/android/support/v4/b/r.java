/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.view.View
 */
package android.support.v4.b;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.b.m;
import android.support.v4.b.w;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class r {
    public abstract m a(String var1);

    public abstract w a();

    public abstract void a(int var1, int var2);

    public abstract void a(String var1, int var2);

    public abstract void a(String var1, FileDescriptor var2, PrintWriter var3, String[] var4);

    public abstract void b();

    public abstract boolean c();

    public abstract class a {
        public void a(r r2, m m2) {
        }

        public void a(r r2, m m2, Context context) {
        }

        public void a(r r2, m m2, Bundle bundle) {
        }

        public void a(r r2, m m2, View view, Bundle bundle) {
        }

        public void b(r r2, m m2) {
        }

        public void b(r r2, m m2, Context context) {
        }

        public void b(r r2, m m2, Bundle bundle) {
        }

        public void c(r r2, m m2) {
        }

        public void c(r r2, m m2, Bundle bundle) {
        }

        public void d(r r2, m m2) {
        }

        public void e(r r2, m m2) {
        }

        public void f(r r2, m m2) {
        }

        public void g(r r2, m m2) {
        }
    }

    public static interface b {
        public void a();
    }

}

