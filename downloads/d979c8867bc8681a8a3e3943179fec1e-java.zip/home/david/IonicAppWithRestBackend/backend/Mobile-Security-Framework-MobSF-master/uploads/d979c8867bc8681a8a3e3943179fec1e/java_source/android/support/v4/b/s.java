/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.TypedArray
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Parcelable
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.util.SparseArray
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.animation.AccelerateInterpolator
 *  android.view.animation.AlphaAnimation
 *  android.view.animation.Animation
 *  android.view.animation.Animation$AnimationListener
 *  android.view.animation.AnimationSet
 *  android.view.animation.AnimationUtils
 *  android.view.animation.DecelerateInterpolator
 *  android.view.animation.Interpolator
 *  android.view.animation.ScaleAnimation
 */
package android.support.v4.b;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.support.v4.b.ab;
import android.support.v4.b.g;
import android.support.v4.b.h;
import android.support.v4.b.m;
import android.support.v4.b.o;
import android.support.v4.b.q;
import android.support.v4.b.r;
import android.support.v4.b.t;
import android.support.v4.b.u;
import android.support.v4.b.v;
import android.support.v4.b.w;
import android.support.v4.b.x;
import android.support.v4.j.i;
import android.support.v4.k.ae;
import android.support.v4.k.n;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class s
extends r
implements n {
    static final Interpolator D;
    static final Interpolator E;
    static final Interpolator F;
    static final Interpolator G;
    static boolean a;
    static final boolean b;
    static Field q;
    SparseArray<Parcelable> A = null;
    ArrayList<e> B;
    Runnable C;
    private CopyOnWriteArrayList<i<r.a, Boolean>> H;
    ArrayList<c> c;
    boolean d;
    ArrayList<m> e;
    ArrayList<m> f;
    ArrayList<Integer> g;
    ArrayList<g> h;
    ArrayList<m> i;
    ArrayList<g> j;
    ArrayList<Integer> k;
    ArrayList<r.b> l;
    int m = 0;
    q n;
    o o;
    m p;
    boolean r;
    boolean s;
    boolean t;
    String u;
    boolean v;
    ArrayList<g> w;
    ArrayList<Boolean> x;
    ArrayList<m> y;
    Bundle z = null;

    static {
        boolean bl2 = false;
        a = false;
        if (Build.VERSION.SDK_INT >= 11) {
            bl2 = true;
        }
        b = bl2;
        q = null;
        D = new DecelerateInterpolator(2.5f);
        E = new DecelerateInterpolator(1.5f);
        F = new AccelerateInterpolator(2.5f);
        G = new AccelerateInterpolator(1.5f);
    }

    s() {
        this.C = new Runnable(){

            @Override
            public void run() {
                s.this.e();
            }
        };
    }

    /*
     * Enabled aggressive block sorting
     */
    private int a(ArrayList<g> arrayList, ArrayList<Boolean> arrayList2, int n2, int n3, android.support.v4.j.b<m> b2) {
        int n4 = n3 - 1;
        int n5 = n3;
        while (n4 >= n2) {
            g g2 = arrayList.get(n4);
            boolean bl2 = arrayList2.get(n4);
            boolean bl3 = g2.e() && !g2.a(arrayList, n4 + 1, n3);
            if (bl3) {
                if (this.B == null) {
                    this.B = new ArrayList();
                }
                e e2 = new e(g2, bl2);
                this.B.add(e2);
                g2.a(e2);
                if (bl2) {
                    g2.c();
                } else {
                    g2.d();
                }
                if (n4 != --n5) {
                    arrayList.remove(n4);
                    arrayList.add(n5, g2);
                }
                this.b(b2);
            }
            --n4;
        }
        return n5;
    }

    static Animation a(Context context, float f2, float f3) {
        context = new AlphaAnimation(f2, f3);
        context.setInterpolator(E);
        context.setDuration(220);
        return context;
    }

    static Animation a(Context context, float f2, float f3, float f4, float f5) {
        context = new AnimationSet(false);
        ScaleAnimation scaleAnimation = new ScaleAnimation(f2, f3, f2, f3, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setInterpolator(D);
        scaleAnimation.setDuration(220);
        context.addAnimation((Animation)scaleAnimation);
        scaleAnimation = new AlphaAnimation(f4, f5);
        scaleAnimation.setInterpolator(E);
        scaleAnimation.setDuration(220);
        context.addAnimation((Animation)scaleAnimation);
        return context;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(g g2, boolean bl2, boolean bl3, boolean bl4) {
        Object object = new ArrayList<g>(1);
        ArrayList<Boolean> arrayList = new ArrayList<Boolean>(1);
        object.add((g)g2);
        arrayList.add(bl2);
        s.b(object, arrayList, 0, 1);
        if (bl3) {
            x.a(this, object, arrayList, 0, 1, true);
        }
        if (bl4) {
            this.a(this.m, true);
        }
        if (this.e == null) {
            return;
        }
        int n2 = this.e.size();
        int n3 = 0;
        while (n3 < n2) {
            object = this.e.get(n3);
            if (object != null && object.P != null && object.X && g2.c(object.F)) {
                if (Build.VERSION.SDK_INT >= 11 && object.Z > 0.0f) {
                    object.P.setAlpha(object.Z);
                }
                if (bl4) {
                    object.Z = 0.0f;
                } else {
                    object.Z = -1.0f;
                    object.X = false;
                }
            }
            ++n3;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(android.support.v4.j.b<m> b2) {
        int n2 = b2.size();
        int n3 = 0;
        while (n3 < n2) {
            m m2 = b2.b(n3);
            if (!m2.t) {
                View view = m2.q();
                if (Build.VERSION.SDK_INT < 11) {
                    m2.q().setVisibility(4);
                } else {
                    m2.Z = view.getAlpha();
                    view.setAlpha(0.0f);
                }
            }
            ++n3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void a(RuntimeException runtimeException) {
        Log.e((String)"FragmentManager", (String)runtimeException.getMessage());
        Log.e((String)"FragmentManager", (String)"Activity state:");
        PrintWriter printWriter = new PrintWriter(new android.support.v4.j.e("FragmentManager"));
        if (this.n != null) {
            try {
                this.n.a("  ", null, printWriter, new String[0]);
            }
            catch (Exception var2_3) {
                Log.e((String)"FragmentManager", (String)"Failed dumping state", (Throwable)var2_3);
                throw runtimeException;
            }
            do {
                throw runtimeException;
                break;
            } while (true);
        }
        try {
            this.a("  ", null, printWriter, new String[0]);
            throw runtimeException;
        }
        catch (Exception var2_4) {
            Log.e((String)"FragmentManager", (String)"Failed dumping state", (Throwable)var2_4);
            throw runtimeException;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(ArrayList<g> var1_1, ArrayList<Boolean> var2_2) {
        var3_3 = this.B == null ? 0 : this.B.size();
        var4_4 = 0;
        while (var4_4 < var3_3) {
            var7_7 = this.B.get(var4_4);
            if (var1_1 == null || e.a(var7_7) || (var5_5 = var1_1.indexOf(e.b(var7_7))) == -1 || !var2_2.get(var5_5).booleanValue()) ** GOTO lbl8
            var7_7.e();
            ** GOTO lbl26
lbl8: // 1 sources:
            if (var7_7.c()) ** GOTO lbl15
            var6_6 = var4_4;
            var5_5 = var3_3;
            if (var1_1 == null) ** GOTO lbl24
            var6_6 = var4_4;
            var5_5 = var3_3;
            if (!e.b(var7_7).a(var1_1, 0, var1_1.size())) ** GOTO lbl24
lbl15: // 2 sources:
            this.B.remove(var4_4);
            var6_6 = var4_4 - 1;
            var5_5 = var3_3 - 1;
            if (var1_1 != null && !e.a(var7_7) && (var3_3 = var1_1.indexOf(e.b(var7_7))) != -1 && var2_2.get(var3_3).booleanValue()) {
                var7_7.e();
                var4_4 = var6_6;
                var3_3 = var5_5;
            } else {
                var7_7.d();
lbl24: // 3 sources:
                var4_4 = var6_6;
                var3_3 = var5_5;
            }
lbl26: // 3 sources:
            ++var4_4;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(ArrayList<g> arrayList, ArrayList<Boolean> arrayList2, int n2, int n3) {
        Object object;
        int n4;
        int n5;
        boolean bl2 = arrayList.get((int)n2).u;
        if (this.y == null) {
            this.y = new ArrayList();
        } else {
            this.y.clear();
        }
        if (this.f != null) {
            this.y.addAll(this.f);
        }
        boolean bl3 = false;
        for (n5 = n2; n5 < n3; ++n5) {
            object = arrayList.get(n5);
            boolean bl4 = arrayList2.get(n5);
            if (!bl4) {
                object.a(this.y);
            } else {
                object.b(this.y);
            }
            n4 = bl4 ? -1 : 1;
            object.b(n4);
            bl3 = bl3 || object.j;
        }
        this.y.clear();
        if (!bl2) {
            x.a(this, arrayList, arrayList2, n2, n3, false);
        }
        s.b(arrayList, arrayList2, n2, n3);
        if (bl2) {
            object = new android.support.v4.j.b();
            this.b((android.support.v4.j.b<m>)object);
            n5 = this.a(arrayList, arrayList2, n2, n3, (android.support.v4.j.b<m>)object);
            this.a((android.support.v4.j.b<m>)object);
        } else {
            n5 = n3;
        }
        n4 = n2;
        if (n5 != n2) {
            n4 = n2;
            if (bl2) {
                x.a(this, arrayList, arrayList2, n2, n5, true);
                this.a(this.m, true);
                n4 = n2;
            }
        }
        while (n4 < n3) {
            object = arrayList.get(n4);
            if (arrayList2.get(n4).booleanValue() && object.n >= 0) {
                this.c(object.n);
                object.n = -1;
            }
            ++n4;
        }
        if (bl3) {
            this.g();
        }
    }

    static boolean a(View view, Animation animation) {
        if (Build.VERSION.SDK_INT >= 19 && ae.f(view) == 0 && ae.y(view) && s.a(animation)) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static boolean a(Animation object) {
        boolean bl2 = false;
        if (object instanceof AlphaAnimation) {
            return true;
        }
        boolean bl3 = bl2;
        if (!(object instanceof AnimationSet)) return bl3;
        object = ((AnimationSet)object).getAnimations();
        int n2 = 0;
        do {
            bl3 = bl2;
            if (n2 >= object.size()) return bl3;
            if (object.get(n2) instanceof AlphaAnimation) {
                return true;
            }
            ++n2;
        } while (true);
    }

    private boolean a(String string, int n2, int n3) {
        this.e();
        this.c(true);
        boolean bl2 = this.a(this.w, this.x, string, n2, n3);
        if (bl2) {
            this.d = true;
            this.b(this.w, this.x);
        }
        this.f();
        return bl2;
        finally {
            this.x();
        }
    }

    public static int b(int n2, boolean bl2) {
        switch (n2) {
            default: {
                return -1;
            }
            case 4097: {
                if (bl2) {
                    return 1;
                }
                return 2;
            }
            case 8194: {
                if (bl2) {
                    return 3;
                }
                return 4;
            }
            case 4099: 
        }
        if (bl2) {
            return 5;
        }
        return 6;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(android.support.v4.j.b<m> b2) {
        if (this.m < 1) {
            return;
        }
        int n2 = Math.min(this.m, 4);
        int n3 = this.f == null ? 0 : this.f.size();
        int n4 = 0;
        while (n4 < n3) {
            m m2 = this.f.get(n4);
            if (m2.k < n2) {
                this.a(m2, n2, m2.P(), m2.Q(), false);
                if (m2.P != null && !m2.H && m2.X) {
                    b2.add(m2);
                }
            }
            ++n4;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void b(View view, Animation animation) {
        Animation.AnimationListener animationListener;
        if (view == null || animation == null || !s.a(view, animation)) {
            return;
        }
        try {
            if (q == null) {
                q = Animation.class.getDeclaredField("mListener");
                q.setAccessible(true);
            }
            animationListener = (Animation.AnimationListener)q.get((Object)animation);
        }
        catch (NoSuchFieldException var3_4) {
            Log.e((String)"FragmentManager", (String)"No field with the name mListener is found in Animation class", (Throwable)var3_4);
            animationListener = null;
        }
        catch (IllegalAccessException var3_5) {
            Log.e((String)"FragmentManager", (String)"Cannot access Animation's mListener field", (Throwable)var3_5);
            animationListener = null;
        }
        ae.a(view, 2, null);
        animation.setAnimationListener((Animation.AnimationListener)new a(view, animation, animationListener));
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void b(ArrayList<g> arrayList, ArrayList<Boolean> arrayList2) {
        int n2 = 0;
        if (arrayList == null) return;
        if (arrayList.isEmpty()) {
            return;
        }
        if (arrayList2 == null) throw new IllegalStateException("Internal error with the back stack records");
        if (arrayList.size() != arrayList2.size()) {
            throw new IllegalStateException("Internal error with the back stack records");
        }
        this.a(arrayList, arrayList2);
        int n3 = arrayList.size();
        int n4 = 0;
        do {
            if (n2 >= n3) {
                if (n4 == n3) return;
                this.a(arrayList, arrayList2, n4, n3);
                return;
            }
            if (!arrayList.get((int)n2).u) {
                int n5;
                if (n4 != n2) {
                    this.a(arrayList, arrayList2, n4, n2);
                }
                n4 = n5 = n2 + 1;
                if (arrayList2.get(n2).booleanValue()) {
                    do {
                        n4 = n5;
                        if (n5 >= n3) break;
                        n4 = n5;
                        if (!arrayList2.get(n5).booleanValue()) break;
                        n4 = n5++;
                    } while (!arrayList.get((int)n5).u);
                }
                this.a(arrayList, arrayList2, n2, n4);
                n2 = n4;
                n5 = n4 - 1;
                n4 = n2;
                n2 = n5;
            }
            ++n2;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void b(ArrayList<g> arrayList, ArrayList<Boolean> arrayList2, int n2, int n3) {
        while (n2 < n3) {
            g g2 = arrayList.get(n2);
            if (arrayList2.get(n2).booleanValue()) {
                g2.d();
            } else {
                g2.c();
            }
            ++n2;
        }
        return;
    }

    private void c(boolean bl2) {
        if (this.d) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        }
        if (Looper.myLooper() != this.n.h().getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
        if (!bl2) {
            this.v();
        }
        if (this.w == null) {
            this.w = new ArrayList();
            this.x = new ArrayList();
        }
        this.a((ArrayList<g>)null, (ArrayList<Boolean>)null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private boolean c(ArrayList<g> arrayList, ArrayList<Boolean> arrayList2) {
        // MONITORENTER : this
        if (this.c == null || this.c.size() == 0) {
            // MONITOREXIT : this
            return false;
        }
        int n2 = this.c.size();
        int n3 = 0;
        do {
            if (n3 >= n2) {
                this.c.clear();
                this.n.h().removeCallbacks(this.C);
                // MONITOREXIT : this
                if (n2 <= 0) return false;
                return true;
            }
            this.c.get(n3).a(arrayList, arrayList2);
            ++n3;
        } while (true);
    }

    public static int d(int n2) {
        switch (n2) {
            default: {
                return 0;
            }
            case 4097: {
                return 8194;
            }
            case 8194: {
                return 4097;
            }
            case 4099: 
        }
        return 4099;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private m n(m object) {
        ViewGroup viewGroup = object.O;
        Object object2 = object.P;
        if (viewGroup == null) return null;
        if (object2 == null) {
            return null;
        }
        int n2 = this.f.indexOf(object) - 1;
        while (n2 >= 0) {
            object2 = this.f.get(n2);
            if (object2.O == viewGroup) {
                object = object2;
                if (object2.P != null) return object;
            }
            --n2;
        }
        return null;
    }

    private void v() {
        if (this.s) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
        if (this.u != null) {
            throw new IllegalStateException("Can not perform this action inside of " + this.u);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void w() {
        boolean bl2 = true;
        synchronized (this) {
            boolean bl3 = this.B != null && !this.B.isEmpty();
            if (this.c == null) return;
            if (this.c.size() != 1) {
                bl2 = false;
            }
            if (bl3 || bl2) {
                this.n.h().removeCallbacks(this.C);
                this.n.h().post(this.C);
            }
            return;
        }
    }

    private void x() {
        this.d = false;
        this.x.clear();
        this.w.clear();
    }

    private void y() {
        if (this.B != null) {
            while (!this.B.isEmpty()) {
                this.B.remove(0).d();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void z() {
        int n2 = this.e == null ? 0 : this.e.size();
        int n3 = 0;
        while (n3 < n2) {
            m m2 = this.e.get(n3);
            if (m2 != null && m2.U() != null) {
                int n4 = m2.V();
                View view = m2.U();
                m2.b((View)null);
                view = view.getAnimation();
                if (view != null) {
                    view.cancel();
                }
                this.a(m2, n4, 0, 0, false);
            }
            ++n3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int a(g g2) {
        synchronized (this) {
            if (this.k == null || this.k.size() <= 0) {
                if (this.j == null) {
                    this.j = new ArrayList();
                }
                int n2 = this.j.size();
                if (a) {
                    Log.v((String)"FragmentManager", (String)("Setting back stack index " + n2 + " to " + g2));
                }
                this.j.add(g2);
                return n2;
            }
            int n3 = this.k.remove(this.k.size() - 1);
            if (a) {
                Log.v((String)"FragmentManager", (String)("Adding back stack index " + n3 + " with " + g2));
            }
            this.j.set(n3, g2);
            return n3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public m a(Bundle object, String string) {
        m m2;
        int n2 = object.getInt(string, -1);
        if (n2 == -1) {
            return null;
        }
        if (n2 >= this.e.size()) {
            this.a(new IllegalStateException("Fragment no longer exists for key " + string + ": index " + n2));
        }
        object = m2 = this.e.get(n2);
        if (m2 != null) return object;
        this.a(new IllegalStateException("Fragment no longer exists for key " + string + ": index " + n2));
        return m2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public m a(String string) {
        m m2;
        int n2;
        if (this.f != null && string != null) {
            for (n2 = this.f.size() - 1; n2 >= 0; --n2) {
                m2 = this.f.get(n2);
                if (m2 != null && string.equals(m2.G)) return m2;
                {
                    continue;
                }
            }
        } else {
            if (this.e == null || string == null) return null;
            {
                for (n2 = this.e.size() - 1; n2 >= 0; --n2) {
                    m m3 = this.e.get(n2);
                    if (m3 == null) continue;
                    m2 = m3;
                    if (string.equals(m3.G)) return m2;
                    {
                        continue;
                    }
                }
            }
            return null;
        }
    }

    @Override
    public w a() {
        return new g(this);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public View a(View object, String object2, Context context, AttributeSet attributeSet) {
        if (!"fragment".equals(object2)) {
            return null;
        }
        String string = attributeSet.getAttributeValue(null, "class");
        object2 = context.obtainStyledAttributes(attributeSet, b.a);
        if (string == null) {
            string = object2.getString(0);
        }
        int n2 = object2.getResourceId(1, -1);
        String string2 = object2.getString(2);
        object2.recycle();
        if (!m.b(this.n.g(), string)) {
            return null;
        }
        int n3 = object != null ? object.getId() : 0;
        if (n3 == -1 && n2 == -1 && string2 == null) {
            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + string);
        }
        object2 = n2 != -1 ? this.b(n2) : null;
        object = object2;
        if (object2 == null) {
            object = object2;
            if (string2 != null) {
                object = this.a(string2);
            }
        }
        object2 = object;
        if (object == null) {
            object2 = object;
            if (n3 != -1) {
                object2 = this.b(n3);
            }
        }
        if (a) {
            Log.v((String)"FragmentManager", (String)("onCreateView: id=0x" + Integer.toHexString(n2) + " fname=" + string + " existing=" + object2));
        }
        if (object2 == null) {
            object = m.a(context, string);
            object.v = true;
            int n4 = n2 != 0 ? n2 : n3;
            object.E = n4;
            object.F = n3;
            object.G = string2;
            object.w = true;
            object.z = this;
            object.A = this.n;
            object.a(this.n.g(), attributeSet, object.l);
            this.a((m)object, true);
        } else {
            if (object2.w) {
                throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(n2) + ", tag " + string2 + ", or parent id 0x" + Integer.toHexString(n3) + " with another fragment for " + string);
            }
            object2.w = true;
            object2.A = this.n;
            if (!object2.K) {
                object2.a(this.n.g(), attributeSet, object2.l);
            }
            object = object2;
        }
        if (this.m < 1 && object.v) {
            this.a((m)object, 1, 0, 0, false);
        } else {
            this.b((m)object);
        }
        if (object.P == null) {
            throw new IllegalStateException("Fragment " + string + " did not create a view.");
        }
        if (n2 != 0) {
            object.P.setId(n2);
        }
        if (object.P.getTag() == null) {
            object.P.setTag((Object)string2);
        }
        return object.P;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    Animation a(m m2, int n2, boolean bl2, int n3) {
        Animation animation = m2.a(n2, bl2, m2.P());
        if (animation != null) {
            return animation;
        }
        if (m2.P() != 0) {
            m2 = animation = AnimationUtils.loadAnimation((Context)this.n.g(), (int)m2.P());
            if (animation != null) return m2;
        }
        if (n2 == 0) {
            return null;
        }
        if ((n2 = s.b(n2, bl2)) < 0) {
            return null;
        }
        switch (n2) {
            default: {
                n2 = n3;
                if (n3 == 0) {
                    n2 = n3;
                    if (this.n.d()) {
                        n2 = this.n.e();
                    }
                }
                if (n2 != 0) return null;
                return null;
            }
            case 1: {
                return s.a(this.n.g(), 1.125f, 1.0f, 0.0f, 1.0f);
            }
            case 2: {
                return s.a(this.n.g(), 1.0f, 0.975f, 1.0f, 0.0f);
            }
            case 3: {
                return s.a(this.n.g(), 0.975f, 1.0f, 0.0f, 1.0f);
            }
            case 4: {
                return s.a(this.n.g(), 1.0f, 1.075f, 1.0f, 0.0f);
            }
            case 5: {
                return s.a(this.n.g(), 0.0f, 1.0f);
            }
            case 6: {
                return s.a(this.n.g(), 1.0f, 0.0f);
            }
        }
    }

    @Override
    public void a(int n2, int n3) {
        if (n2 < 0) {
            throw new IllegalArgumentException("Bad id: " + n2);
        }
        this.a(new d(null, n2, n3), false);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(int n2, g g2) {
        synchronized (this) {
            int n3;
            if (this.j == null) {
                this.j = new ArrayList();
            }
            if (n2 < n3) {
                if (a) {
                    Log.v((String)"FragmentManager", (String)("Setting back stack index " + n2 + " to " + g2));
                }
                this.j.set(n2, g2);
            } else {
                for (int i2 = n3 = this.j.size(); i2 < n2; ++i2) {
                    this.j.add(null);
                    if (this.k == null) {
                        this.k = new ArrayList();
                    }
                    if (a) {
                        Log.v((String)"FragmentManager", (String)("Adding available back stack index " + i2));
                    }
                    this.k.add(i2);
                }
                if (a) {
                    Log.v((String)"FragmentManager", (String)("Adding back stack index " + n2 + " with " + g2));
                }
                this.j.add(g2);
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    void a(int var1_1, boolean var2_2) {
        if (this.n == null && var1_1 != 0) {
            throw new IllegalStateException("No activity");
        }
        if (!var2_2 && var1_1 == this.m) {
            return;
        }
        this.m = var1_1;
        if (this.e == null) return;
        if (this.f != null) {
            var5_3 = this.f.size();
            var4_4 = 0;
            var1_1 = 0;
            do {
                var3_5 = var1_1;
                if (var4_4 < var5_3) {
                    var6_6 = this.f.get(var4_4);
                    this.d(var6_6);
                    if (var6_6.T != null) {
                        var1_1 = var6_6.T.a() | var1_1;
                    }
                    ++var4_4;
                    continue;
                }
                break;
                break;
            } while (true);
        } else {
            var3_5 = 0;
        }
        var5_3 = this.e.size();
        for (var4_4 = 0; var4_4 < var5_3; ++var4_4) {
            var6_6 = this.e.get(var4_4);
            if (var6_6 == null || !var6_6.u && !var6_6.I || var6_6.X) ** GOTO lbl-1000
            this.d(var6_6);
            if (var6_6.T != null) {
                var1_1 = var6_6.T.a() | var3_5;
            } else lbl-1000: // 2 sources:
            {
                var1_1 = var3_5;
            }
            var3_5 = var1_1;
        }
        if (var3_5 == 0) {
            this.d();
        }
        if (this.r == false) return;
        if (this.n == null) return;
        if (this.m != 5) return;
        this.n.c();
        this.r = false;
    }

    public void a(Configuration configuration) {
        if (this.f != null) {
            for (int i2 = 0; i2 < this.f.size(); ++i2) {
                m m2 = this.f.get(i2);
                if (m2 == null) continue;
                m2.a(configuration);
            }
        }
    }

    public void a(Bundle bundle, String string, m m2) {
        if (m2.n < 0) {
            this.a(new IllegalStateException("Fragment " + m2 + " is not currently in the FragmentManager"));
        }
        bundle.putInt(string, m2.n);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    void a(Parcelable object, t object2) {
        Object object3;
        int n2;
        int n3;
        Object object4;
        if (object == null) {
            return;
        }
        u u2 = (u)object;
        if (u2.a == null) return;
        if (object2 != null) {
            object4 = object2.a();
            object = object2.b();
            n3 = object4 != null ? object4.size() : 0;
            for (n2 = 0; n2 < n3; ++n2) {
                object3 = object4.get(n2);
                if (a) {
                    Log.v((String)"FragmentManager", (String)("restoreAllState: re-attaching retained " + object3));
                }
                v v2 = u2.a[object3.n];
                v2.l = object3;
                object3.m = null;
                object3.y = 0;
                object3.w = false;
                object3.t = false;
                object3.q = null;
                if (v2.k == null) continue;
                v2.k.setClassLoader(this.n.g().getClassLoader());
                object3.m = v2.k.getSparseParcelableArray("android:view_state");
                object3.l = v2.k;
            }
        } else {
            object = null;
        }
        this.e = new ArrayList(u2.a.length);
        if (this.g != null) {
            this.g.clear();
        }
        for (n3 = 0; n3 < u2.a.length; ++n3) {
            object3 = u2.a[n3];
            if (object3 != null) {
                object4 = object != null && n3 < object.size() ? (t)object.get(n3) : null;
                object4 = object3.a(this.n, this.p, (t)object4);
                if (a) {
                    Log.v((String)"FragmentManager", (String)("restoreAllState: active #" + n3 + ": " + object4));
                }
                this.e.add((m)object4);
                object3.l = null;
                continue;
            }
            this.e.add(null);
            if (this.g == null) {
                this.g = new ArrayList();
            }
            if (a) {
                Log.v((String)"FragmentManager", (String)("restoreAllState: avail #" + n3));
            }
            this.g.add(n3);
        }
        if (object2 != null) {
            object = object2.a();
            n3 = object != null ? object.size() : 0;
            for (n2 = 0; n2 < n3; ++n2) {
                object2 = (m)object.get(n2);
                if (object2.r < 0) continue;
                if (object2.r < this.e.size()) {
                    object2.q = this.e.get(object2.r);
                    continue;
                }
                Log.w((String)"FragmentManager", (String)("Re-attaching retained fragment " + object2 + " target no longer exists: " + object2.r));
                object2.q = null;
            }
        }
        if (u2.b == null) {
            this.f = null;
        } else {
            this.f = new ArrayList(u2.b.length);
            for (n3 = 0; n3 < u2.b.length; ++n3) {
                object = this.e.get(u2.b[n3]);
                if (object == null) {
                    this.a(new IllegalStateException("No instantiated fragment for index #" + u2.b[n3]));
                }
                object.t = true;
                if (a) {
                    Log.v((String)"FragmentManager", (String)("restoreAllState: added #" + n3 + ": " + object));
                }
                if (this.f.contains(object)) {
                    throw new IllegalStateException("Already added!");
                }
                this.f.add((m)object);
            }
        }
        if (u2.c == null) {
            this.h = null;
            return;
        }
        this.h = new ArrayList(u2.c.length);
        n3 = 0;
        while (n3 < u2.c.length) {
            object = u2.c[n3].a(this);
            if (a) {
                Log.v((String)"FragmentManager", (String)("restoreAllState: back stack #" + n3 + " (index " + object.n + "): " + object));
                object.a("  ", new PrintWriter(new android.support.v4.j.e("FragmentManager")), false);
            }
            this.h.add((g)object);
            if (object.n >= 0) {
                this.a(object.n, (g)object);
            }
            ++n3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void a(m m2) {
        if (!m2.R) return;
        if (this.d) {
            this.v = true;
            return;
        }
        m2.R = false;
        this.a(m2, this.m, 0, 0, false);
    }

    /*
     * Exception decompiling
     */
    void a(m var1_1, int var2_2, int var3_3, int var4_4, boolean var5_5) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.rebuildSwitches(SwitchReplacer.java:334)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:539)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    void a(m m2, Context context, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).a(m2, context, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).a((r)this, m2, context);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void a(m m2, Bundle bundle, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).a(m2, bundle, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).a((r)this, m2, bundle);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void a(m m2, View view, Bundle bundle, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).a(m2, view, bundle, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).a(this, m2, view, bundle);
            }
        }
    }

    public void a(m m2, boolean bl2) {
        if (this.f == null) {
            this.f = new ArrayList();
        }
        if (a) {
            Log.v((String)"FragmentManager", (String)("add: " + m2));
        }
        this.e(m2);
        if (!m2.I) {
            if (this.f.contains(m2)) {
                throw new IllegalStateException("Fragment already added: " + m2);
            }
            this.f.add(m2);
            m2.t = true;
            m2.u = false;
            if (m2.P == null) {
                m2.Y = false;
            }
            if (m2.L && m2.M) {
                this.r = true;
            }
            if (bl2) {
                this.b(m2);
            }
        }
    }

    public void a(q q2, o o2, m m2) {
        if (this.n != null) {
            throw new IllegalStateException("Already attached");
        }
        this.n = q2;
        this.o = o2;
        this.p = m2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(c c2, boolean bl2) {
        if (!bl2) {
            this.v();
        }
        synchronized (this) {
            if (this.t || this.n == null) {
                throw new IllegalStateException("Activity has been destroyed");
            }
            if (this.c == null) {
                this.c = new ArrayList();
            }
            this.c.add(c2);
            this.w();
            return;
        }
    }

    @Override
    public void a(String string, int n2) {
        this.a(new d(string, -1, n2), false);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void a(String string, FileDescriptor object, PrintWriter printWriter, String[] arrstring) {
        Object object2;
        int n2;
        int n3;
        int n4 = 0;
        String string2 = string + "    ";
        if (this.e != null && (n2 = this.e.size()) > 0) {
            printWriter.print(string);
            printWriter.print("Active Fragments in ");
            printWriter.print(Integer.toHexString(System.identityHashCode(this)));
            printWriter.println(":");
            for (n3 = 0; n3 < n2; ++n3) {
                object2 = this.e.get(n3);
                printWriter.print(string);
                printWriter.print("  #");
                printWriter.print(n3);
                printWriter.print(": ");
                printWriter.println(object2);
                if (object2 == null) continue;
                object2.a(string2, (FileDescriptor)object, printWriter, arrstring);
            }
        }
        if (this.f != null && (n2 = this.f.size()) > 0) {
            printWriter.print(string);
            printWriter.println("Added Fragments:");
            for (n3 = 0; n3 < n2; ++n3) {
                object2 = this.f.get(n3);
                printWriter.print(string);
                printWriter.print("  #");
                printWriter.print(n3);
                printWriter.print(": ");
                printWriter.println(object2.toString());
            }
        }
        if (this.i != null && (n2 = this.i.size()) > 0) {
            printWriter.print(string);
            printWriter.println("Fragments Created Menus:");
            for (n3 = 0; n3 < n2; ++n3) {
                object2 = this.i.get(n3);
                printWriter.print(string);
                printWriter.print("  #");
                printWriter.print(n3);
                printWriter.print(": ");
                printWriter.println(object2.toString());
            }
        }
        if (this.h != null && (n2 = this.h.size()) > 0) {
            printWriter.print(string);
            printWriter.println("Back Stack:");
            for (n3 = 0; n3 < n2; ++n3) {
                object2 = this.h.get(n3);
                printWriter.print(string);
                printWriter.print("  #");
                printWriter.print(n3);
                printWriter.print(": ");
                printWriter.println(object2.toString());
                object2.a(string2, (FileDescriptor)object, printWriter, arrstring);
            }
        }
        // MONITORENTER : this
        if (this.j != null && (n2 = this.j.size()) > 0) {
            printWriter.print(string);
            printWriter.println("Back Stack Indices:");
            for (n3 = 0; n3 < n2; ++n3) {
                object = this.j.get(n3);
                printWriter.print(string);
                printWriter.print("  #");
                printWriter.print(n3);
                printWriter.print(": ");
                printWriter.println(object);
            }
        }
        if (this.k != null && this.k.size() > 0) {
            printWriter.print(string);
            printWriter.print("mAvailBackStackIndices: ");
            printWriter.println(Arrays.toString(this.k.toArray()));
        }
        // MONITOREXIT : this
        if (this.c != null && (n2 = this.c.size()) > 0) {
            printWriter.print(string);
            printWriter.println("Pending Actions:");
            for (n3 = n4; n3 < n2; ++n3) {
                object = this.c.get(n3);
                printWriter.print(string);
                printWriter.print("  #");
                printWriter.print(n3);
                printWriter.print(": ");
                printWriter.println(object);
            }
        }
        printWriter.print(string);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(string);
        printWriter.print("  mHost=");
        printWriter.println(this.n);
        printWriter.print(string);
        printWriter.print("  mContainer=");
        printWriter.println(this.o);
        if (this.p != null) {
            printWriter.print(string);
            printWriter.print("  mParent=");
            printWriter.println(this.p);
        }
        printWriter.print(string);
        printWriter.print("  mCurState=");
        printWriter.print(this.m);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.s);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.t);
        if (this.r) {
            printWriter.print(string);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.r);
        }
        if (this.u != null) {
            printWriter.print(string);
            printWriter.print("  mNoTransactionsBecause=");
            printWriter.println(this.u);
        }
        if (this.g == null) return;
        if (this.g.size() <= 0) return;
        printWriter.print(string);
        printWriter.print("  mAvailIndices: ");
        printWriter.println(Arrays.toString(this.g.toArray()));
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(boolean bl2) {
        if (this.f != null) {
            for (int i2 = this.f.size() - 1; i2 >= 0; --i2) {
                m m2 = this.f.get(i2);
                if (m2 == null) continue;
                m2.g(bl2);
            }
        }
    }

    boolean a(int n2) {
        if (this.m >= n2) {
            return true;
        }
        return false;
    }

    public boolean a(Menu menu) {
        boolean bl2;
        if (this.f != null) {
            int n2 = 0;
            boolean bl3 = false;
            do {
                bl2 = bl3;
                if (n2 < this.f.size()) {
                    m m2 = this.f.get(n2);
                    bl2 = bl3;
                    if (m2 != null) {
                        bl2 = bl3;
                        if (m2.c(menu)) {
                            bl2 = true;
                        }
                    }
                    ++n2;
                    bl3 = bl2;
                    continue;
                }
                break;
                break;
            } while (true);
        } else {
            bl2 = false;
        }
        return bl2;
    }

    public boolean a(Menu object, MenuInflater menuInflater) {
        boolean bl2;
        int n2;
        int n3 = 0;
        ArrayList<m> arrayList = null;
        ArrayList<m> arrayList2 = null;
        if (this.f != null) {
            n2 = 0;
            boolean bl3 = false;
            do {
                arrayList = arrayList2;
                bl2 = bl3;
                if (n2 < this.f.size()) {
                    m m2 = this.f.get(n2);
                    arrayList = arrayList2;
                    bl2 = bl3;
                    if (m2 != null) {
                        arrayList = arrayList2;
                        bl2 = bl3;
                        if (m2.b((Menu)object, menuInflater)) {
                            bl2 = true;
                            arrayList = arrayList2;
                            if (arrayList2 == null) {
                                arrayList = new ArrayList<m>();
                            }
                            arrayList.add(m2);
                        }
                    }
                    ++n2;
                    bl3 = bl2;
                    arrayList2 = arrayList;
                    continue;
                }
                break;
                break;
            } while (true);
        } else {
            bl2 = false;
        }
        if (this.i != null) {
            for (n2 = n3; n2 < this.i.size(); ++n2) {
                object = this.i.get(n2);
                if (arrayList != null && arrayList.contains(object)) continue;
                object.v();
            }
        }
        this.i = arrayList;
        return bl2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean a(MenuItem menuItem) {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (this.f == null) return bl3;
        int n2 = 0;
        do {
            bl3 = bl2;
            if (n2 >= this.f.size()) return bl3;
            m m2 = this.f.get(n2);
            if (m2 != null && m2.c(menuItem)) {
                return true;
            }
            ++n2;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    boolean a(ArrayList<g> arrayList, ArrayList<Boolean> arrayList2, String string, int n2, int n3) {
        if (this.h == null) {
            return false;
        }
        if (string == null && n2 < 0 && (n3 & 1) == 0) {
            n2 = this.h.size() - 1;
            if (n2 < 0) {
                return false;
            }
            arrayList.add(this.h.remove(n2));
            arrayList2.add(true);
            return true;
        }
        int n4 = -1;
        if (string != null || n2 >= 0) {
            g g2;
            int n5;
            for (n5 = this.h.size() - 1; n5 >= 0; --n5) {
                g2 = this.h.get(n5);
                if (string != null && string.equals(g2.f()) || n2 >= 0 && n2 == g2.n) break;
            }
            if (n5 < 0) {
                return false;
            }
            n4 = n5;
            if ((n3 & 1) != 0) {
                n3 = n5 - 1;
                do {
                    n4 = n3;
                    if (n3 < 0) break;
                    g2 = this.h.get(n3);
                    if (string == null || !string.equals(g2.f())) {
                        n4 = n3;
                        if (n2 < 0) break;
                        n4 = n3;
                        if (n2 != g2.n) break;
                    }
                    --n3;
                } while (true);
            }
        }
        if (n4 == this.h.size() - 1) {
            return false;
        }
        n2 = this.h.size() - 1;
        while (n2 > n4) {
            arrayList.add(this.h.remove(n2));
            arrayList2.add(true);
            --n2;
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public m b(int n2) {
        m m2;
        int n3;
        if (this.f != null) {
            for (n3 = this.f.size() - 1; n3 >= 0; --n3) {
                m2 = this.f.get(n3);
                if (m2 != null && m2.E == n2) return m2;
                {
                    continue;
                }
            }
        } else {
            if (this.e == null) return null;
            {
                for (n3 = this.e.size() - 1; n3 >= 0; --n3) {
                    m m3 = this.e.get(n3);
                    if (m3 == null) continue;
                    m2 = m3;
                    if (m3.E == n2) return m2;
                    {
                        continue;
                    }
                }
            }
            return null;
        }
    }

    public m b(String string) {
        if (this.e != null && string != null) {
            for (int i2 = this.e.size() - 1; i2 >= 0; --i2) {
                m m2 = this.e.get(i2);
                if (m2 == null || (m2 = m2.a(string)) == null) continue;
                return m2;
            }
        }
        return null;
    }

    @Override
    public void b() {
        this.a(new d(null, -1, 0), false);
    }

    void b(g g2) {
        if (this.h == null) {
            this.h = new ArrayList();
        }
        this.h.add(g2);
        this.g();
    }

    void b(m m2) {
        this.a(m2, this.m, 0, 0, false);
    }

    /*
     * Enabled aggressive block sorting
     */
    void b(m m2, Context context, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).b(m2, context, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).b((r)this, m2, context);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void b(m m2, Bundle bundle, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).b(m2, bundle, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).b((r)this, m2, bundle);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void b(m m2, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).b(m2, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).a(this, m2);
            }
        }
    }

    public void b(Menu menu) {
        if (this.f != null) {
            for (int i2 = 0; i2 < this.f.size(); ++i2) {
                m m2 = this.f.get(i2);
                if (m2 == null) continue;
                m2.d(menu);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void b(boolean bl2) {
        if (this.f != null) {
            for (int i2 = this.f.size() - 1; i2 >= 0; --i2) {
                m m2 = this.f.get(i2);
                if (m2 == null) continue;
                m2.h(bl2);
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean b(MenuItem menuItem) {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (this.f == null) return bl3;
        int n2 = 0;
        do {
            bl3 = bl2;
            if (n2 >= this.f.size()) return bl3;
            m m2 = this.f.get(n2);
            if (m2 != null && m2.d(menuItem)) {
                return true;
            }
            ++n2;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void c(int n2) {
        synchronized (this) {
            this.j.set(n2, null);
            if (this.k == null) {
                this.k = new ArrayList();
            }
            if (a) {
                Log.v((String)"FragmentManager", (String)("Freeing back stack index " + n2));
            }
            this.k.add(n2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void c(m m2) {
        if (m2.P != null) {
            int n2 = m2.Q();
            boolean bl2 = !m2.H;
            Animation animation = this.a(m2, n2, bl2, m2.R());
            if (animation != null) {
                this.b(m2.P, animation);
                m2.P.startAnimation(animation);
                this.b(m2.P, animation);
                animation.start();
            }
            n2 = m2.H && !m2.X() ? 8 : 0;
            m2.P.setVisibility(n2);
            if (m2.X()) {
                m2.i(false);
            }
        }
        if (m2.t && m2.L && m2.M) {
            this.r = true;
        }
        m2.Y = false;
        m2.b(m2.H);
    }

    /*
     * Enabled aggressive block sorting
     */
    void c(m m2, Bundle bundle, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).c(m2, bundle, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).c(this, m2, bundle);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void c(m m2, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).c(m2, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).b(this, m2);
            }
        }
    }

    @Override
    public boolean c() {
        this.v();
        return this.a(null, -1, 0);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    void d() {
        if (this.e == null) {
            return;
        }
        int n2 = 0;
        while (n2 < this.e.size()) {
            m m2 = this.e.get(n2);
            if (m2 != null) {
                this.a(m2);
            }
            ++n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    void d(m m2) {
        int n2;
        if (m2 == null) {
            return;
        }
        int n3 = n2 = this.m;
        if (m2.u) {
            n3 = m2.f() ? Math.min(n2, 1) : Math.min(n2, 0);
        }
        this.a(m2, n3, m2.Q(), m2.R(), false);
        if (m2.P != null) {
            m m3 = this.n(m2);
            if (m3 != null) {
                m3 = m3.P;
                ViewGroup viewGroup = m2.O;
                n3 = viewGroup.indexOfChild((View)m3);
                n2 = viewGroup.indexOfChild(m2.P);
                if (n2 < n3) {
                    viewGroup.removeViewAt(n2);
                    viewGroup.addView(m2.P, n3);
                }
            }
            if (m2.X && m2.O != null) {
                if (Build.VERSION.SDK_INT < 11) {
                    m2.P.setVisibility(0);
                } else if (m2.Z > 0.0f) {
                    m2.P.setAlpha(m2.Z);
                }
                m2.Z = 0.0f;
                m2.X = false;
                m3 = this.a(m2, m2.Q(), true, m2.R());
                if (m3 != null) {
                    this.b(m2.P, (Animation)m3);
                    m2.P.startAnimation((Animation)m3);
                }
            }
        }
        if (!m2.Y) return;
        this.c(m2);
    }

    /*
     * Enabled aggressive block sorting
     */
    void d(m m2, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).d(m2, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).c(this, m2);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    void e(m m2) {
        if (m2.n >= 0) {
            return;
        }
        if (this.g == null || this.g.size() <= 0) {
            if (this.e == null) {
                this.e = new ArrayList();
            }
            m2.a(this.e.size(), this.p);
            this.e.add(m2);
        } else {
            m2.a((int)this.g.remove(this.g.size() - 1), this.p);
            this.e.set(m2.n, m2);
        }
        if (!a) return;
        Log.v((String)"FragmentManager", (String)("Allocated fragment index " + m2));
    }

    /*
     * Enabled aggressive block sorting
     */
    void e(m m2, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).e(m2, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).d(this, m2);
            }
        }
    }

    public boolean e() {
        this.c(true);
        boolean bl2 = false;
        while (this.c(this.w, this.x)) {
            this.d = true;
            try {
                this.b(this.w, this.x);
                bl2 = true;
                continue;
            }
            finally {
                this.x();
            }
        }
        this.f();
        return bl2;
    }

    void f() {
        if (this.v) {
            boolean bl2 = false;
            for (int i2 = 0; i2 < this.e.size(); ++i2) {
                m m2 = this.e.get(i2);
                boolean bl3 = bl2;
                if (m2 != null) {
                    bl3 = bl2;
                    if (m2.T != null) {
                        bl3 = bl2 | m2.T.a();
                    }
                }
                bl2 = bl3;
            }
            if (!bl2) {
                this.v = false;
                this.d();
            }
        }
    }

    void f(m m2) {
        if (m2.n < 0) {
            return;
        }
        if (a) {
            Log.v((String)"FragmentManager", (String)("Freeing fragment index " + m2));
        }
        this.e.set(m2.n, null);
        if (this.g == null) {
            this.g = new ArrayList();
        }
        this.g.add(m2.n);
        this.n.a(m2.o);
        m2.u();
    }

    /*
     * Enabled aggressive block sorting
     */
    void f(m m2, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).f(m2, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).e(this, m2);
            }
        }
    }

    void g() {
        if (this.l != null) {
            for (int i2 = 0; i2 < this.l.size(); ++i2) {
                this.l.get(i2).a();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void g(m m2) {
        if (a) {
            Log.v((String)"FragmentManager", (String)("remove: " + m2 + " nesting=" + m2.y));
        }
        boolean bl2 = !m2.f();
        if (!m2.I || bl2) {
            if (this.f != null) {
                this.f.remove(m2);
            }
            if (m2.L && m2.M) {
                this.r = true;
            }
            m2.t = false;
            m2.u = true;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void g(m m2, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).g(m2, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).f(this, m2);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    t h() {
        if (this.e == null) {
            return null;
        }
        int n2 = 0;
        ArrayList<ArrayList<m>> arrayList = null;
        ArrayList<ArrayList<m>> arrayList2 = null;
        do {
            ArrayList<ArrayList<m>> arrayList3 = arrayList;
            ArrayList<ArrayList<m>> arrayList4 = arrayList2;
            if (n2 >= this.e.size()) return null;
            m m2 = this.e.get(n2);
            ArrayList<ArrayList<m>> arrayList5 = arrayList;
            arrayList3 = arrayList2;
            if (m2 != null) {
                int n3;
                arrayList4 = arrayList2;
                if (m2.J) {
                    arrayList3 = arrayList2;
                    if (arrayList2 == null) {
                        arrayList3 = new ArrayList<ArrayList<m>>();
                    }
                    arrayList3.add((ArrayList<m>)((Object)m2));
                    m2.K = true;
                    n3 = m2.q != null ? m2.q.n : -1;
                    m2.r = n3;
                    arrayList4 = arrayList3;
                    if (a) {
                        Log.v((String)"FragmentManager", (String)("retainNonConfig: keeping retained " + m2));
                        arrayList4 = arrayList3;
                    }
                }
                if (m2.B != null && (arrayList3 = m2.B.h()) != null) {
                    if (arrayList == null) {
                        arrayList = new ArrayList<ArrayList<m>>();
                        n3 = 0;
                        do {
                            arrayList2 = arrayList;
                            if (n3 < n2) {
                                arrayList.add(null);
                                ++n3;
                                continue;
                            }
                            break;
                            break;
                        } while (true);
                    } else {
                        arrayList2 = arrayList;
                    }
                    arrayList2.add(arrayList3);
                    n3 = 1;
                    arrayList = arrayList2;
                } else {
                    n3 = 0;
                }
                arrayList5 = arrayList;
                arrayList3 = arrayList4;
                if (arrayList != null) {
                    arrayList5 = arrayList;
                    arrayList3 = arrayList4;
                    if (n3 == 0) {
                        arrayList.add(null);
                        arrayList3 = arrayList4;
                        arrayList5 = arrayList;
                    }
                }
            }
            ++n2;
            arrayList2 = arrayList3;
            arrayList = arrayList5;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void h(m m2) {
        boolean bl2 = true;
        if (a) {
            Log.v((String)"FragmentManager", (String)("hide: " + m2));
        }
        if (!m2.H) {
            m2.H = true;
            if (m2.Y) {
                bl2 = false;
            }
            m2.Y = bl2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void h(m m2, boolean bl2) {
        Object object;
        if (this.p != null && (object = this.p.l()) instanceof s) {
            ((s)object).h(m2, true);
        }
        if (this.H != null) {
            for (i i2 : this.H) {
                if (bl2 && !((Boolean)i2.b).booleanValue()) continue;
                ((r.a)i2.a).g(this, m2);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    Parcelable i() {
        h[] arrh = null;
        this.y();
        this.z();
        this.e();
        if (b) {
            this.s = true;
        }
        if (this.e == null) return null;
        if (this.e.size() <= 0) {
            return null;
        }
        int n2 = this.e.size();
        v[] arrv = new v[n2];
        int n3 = 0;
        int n4 = 0;
        do {
            if (n3 >= n2) {
                if (!a) return null;
                Log.v((String)"FragmentManager", (String)"saveAllState: no fragments!");
                return null;
            }
            m m2 = this.e.get(n3);
            if (m2 != null) {
                h[] arrh2;
                if (m2.n < 0) {
                    this.a(new IllegalStateException("Failure saving state: active " + m2 + " has cleared index: " + m2.n));
                }
                arrv[n3] = arrh2 = new v(m2);
                if (m2.k > 0 && arrh2.k == null) {
                    arrh2.k = this.m(m2);
                    if (m2.q != null) {
                        if (m2.q.n < 0) {
                            this.a(new IllegalStateException("Failure saving state: " + m2 + " has target not in fragment manager: " + m2.q));
                        }
                        if (arrh2.k == null) {
                            arrh2.k = new Bundle();
                        }
                        this.a(arrh2.k, "android:target_state", m2.q);
                        if (m2.s != 0) {
                            arrh2.k.putInt("android:target_req_state", m2.s);
                        }
                    }
                } else {
                    arrh2.k = m2.l;
                }
                if (a) {
                    Log.v((String)"FragmentManager", (String)("Saved state of " + m2 + ": " + (Object)arrh2.k));
                }
                n4 = 1;
            }
            ++n3;
        } while (true);
    }

    public void i(m m2) {
        boolean bl2 = false;
        if (a) {
            Log.v((String)"FragmentManager", (String)("show: " + m2));
        }
        if (m2.H) {
            m2.H = false;
            if (!m2.Y) {
                bl2 = true;
            }
            m2.Y = bl2;
        }
    }

    public void j() {
        this.s = false;
    }

    public void j(m m2) {
        if (a) {
            Log.v((String)"FragmentManager", (String)("detach: " + m2));
        }
        if (!m2.I) {
            m2.I = true;
            if (m2.t) {
                if (this.f != null) {
                    if (a) {
                        Log.v((String)"FragmentManager", (String)("remove from detach: " + m2));
                    }
                    this.f.remove(m2);
                }
                if (m2.L && m2.M) {
                    this.r = true;
                }
                m2.t = false;
            }
        }
    }

    public void k() {
        this.s = false;
        this.a(1, false);
    }

    public void k(m m2) {
        if (a) {
            Log.v((String)"FragmentManager", (String)("attach: " + m2));
        }
        if (m2.I) {
            m2.I = false;
            if (!m2.t) {
                if (this.f == null) {
                    this.f = new ArrayList();
                }
                if (this.f.contains(m2)) {
                    throw new IllegalStateException("Fragment already added: " + m2);
                }
                if (a) {
                    Log.v((String)"FragmentManager", (String)("add from attach: " + m2));
                }
                this.f.add(m2);
                m2.t = true;
                if (m2.L && m2.M) {
                    this.r = true;
                }
            }
        }
    }

    public void l() {
        this.s = false;
        this.a(2, false);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    void l(m m2) {
        if (m2.Q == null) {
            return;
        }
        if (this.A == null) {
            this.A = new SparseArray();
        } else {
            this.A.clear();
        }
        m2.Q.saveHierarchyState(this.A);
        if (this.A.size() <= 0) return;
        m2.m = this.A;
        this.A = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    Bundle m(m m2) {
        Bundle bundle;
        if (this.z == null) {
            this.z = new Bundle();
        }
        m2.l(this.z);
        this.c(m2, this.z, false);
        if (!this.z.isEmpty()) {
            bundle = this.z;
            this.z = null;
        } else {
            bundle = null;
        }
        if (m2.P != null) {
            this.l(m2);
        }
        Bundle bundle2 = bundle;
        if (m2.m != null) {
            bundle2 = bundle;
            if (bundle == null) {
                bundle2 = new Bundle();
            }
            bundle2.putSparseParcelableArray("android:view_state", m2.m);
        }
        bundle = bundle2;
        if (!m2.S) {
            bundle = bundle2;
            if (bundle2 == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", m2.S);
        }
        return bundle;
    }

    public void m() {
        this.s = false;
        this.a(4, false);
    }

    public void n() {
        this.s = false;
        this.a(5, false);
    }

    public void o() {
        this.a(4, false);
    }

    public void p() {
        this.s = true;
        this.a(3, false);
    }

    public void q() {
        this.a(2, false);
    }

    public void r() {
        this.a(1, false);
    }

    public void s() {
        this.t = true;
        this.e();
        this.a(0, false);
        this.n = null;
        this.o = null;
        this.p = null;
    }

    public void t() {
        if (this.f != null) {
            for (int i2 = 0; i2 < this.f.size(); ++i2) {
                m m2 = this.f.get(i2);
                if (m2 == null) continue;
                m2.I();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("FragmentManager{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append(" in ");
        if (this.p != null) {
            android.support.v4.j.d.a(this.p, stringBuilder);
        } else {
            android.support.v4.j.d.a(this.n, stringBuilder);
        }
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }

    n u() {
        return this;
    }

    static class a
    implements Animation.AnimationListener {
        private Animation.AnimationListener a;
        private boolean b;
        View c;

        public a(View view, Animation animation) {
            if (view == null || animation == null) {
                return;
            }
            this.c = view;
        }

        public a(View view, Animation animation, Animation.AnimationListener animationListener) {
            if (view == null || animation == null) {
                return;
            }
            this.a = animationListener;
            this.c = view;
            this.b = true;
        }

        /*
         * Enabled aggressive block sorting
         */
        public void onAnimationEnd(Animation animation) {
            if (this.c != null && this.b) {
                if (ae.F(this.c) || android.support.v4.f.c.a()) {
                    this.c.post(new Runnable(){

                        @Override
                        public void run() {
                            ae.a(a.this.c, 0, null);
                        }
                    });
                } else {
                    ae.a(this.c, 0, null);
                }
            }
            if (this.a != null) {
                this.a.onAnimationEnd(animation);
            }
        }

        public void onAnimationRepeat(Animation animation) {
            if (this.a != null) {
                this.a.onAnimationRepeat(animation);
            }
        }

        public void onAnimationStart(Animation animation) {
            if (this.a != null) {
                this.a.onAnimationStart(animation);
            }
        }

    }

    static class b {
        public static final int[] a = new int[]{16842755, 16842960, 16842961};
    }

    static interface c {
        public boolean a(ArrayList<g> var1, ArrayList<Boolean> var2);
    }

    private class d
    implements c {
        final String a;
        final int b;
        final int c;

        d(String string, int n2, int n3) {
            this.a = string;
            this.b = n2;
            this.c = n3;
        }

        @Override
        public boolean a(ArrayList<g> arrayList, ArrayList<Boolean> arrayList2) {
            return s.this.a(arrayList, arrayList2, this.a, this.b, this.c);
        }
    }

    static class e
    implements m.c {
        private final boolean a;
        private final g b;
        private int c;

        e(g g2, boolean bl2) {
            this.a = bl2;
            this.b = g2;
        }

        static /* synthetic */ boolean a(e e2) {
            return e2.a;
        }

        static /* synthetic */ g b(e e2) {
            return e2.b;
        }

        @Override
        public void a() {
            --this.c;
            if (this.c != 0) {
                return;
            }
            this.b.b.w();
        }

        @Override
        public void b() {
            ++this.c;
        }

        public boolean c() {
            if (this.c == 0) {
                return true;
            }
            return false;
        }

        /*
         * Enabled aggressive block sorting
         */
        public void d() {
            Object object;
            boolean bl2 = false;
            boolean bl3 = this.c > 0;
            s s2 = this.b.b;
            int n2 = s2.f.size();
            for (int i2 = 0; i2 < n2; ++i2) {
                object = s2.f.get(i2);
                object.a((m.c)null);
                if (!bl3 || !object.W()) continue;
                object.E();
            }
            s2 = this.b.b;
            object = this.b;
            boolean bl4 = this.a;
            if (!bl3) {
                bl2 = true;
            }
            s2.a((g)object, bl4, bl2, true);
        }

        public void e() {
            this.b.b.a(this.b, this.a, false, false);
        }
    }

}

