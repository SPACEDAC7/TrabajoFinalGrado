/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.b;

import android.support.v4.b.m;
import java.util.List;

public class t {
    private final List<m> a;
    private final List<t> b;

    t(List<m> list, List<t> list2) {
        this.a = list;
        this.b = list2;
    }

    List<m> a() {
        return this.a;
    }

    List<t> b() {
        return this.b;
    }
}

