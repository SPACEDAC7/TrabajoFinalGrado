/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package android.support.v4.b;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.b.h;
import android.support.v4.b.v;

final class u
implements Parcelable {
    public static final Parcelable.Creator<u> CREATOR = new Parcelable.Creator<u>(){

        public u a(Parcel parcel) {
            return new u(parcel);
        }

        public u[] a(int n2) {
            return new u[n2];
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return this.a(parcel);
        }

        public /* synthetic */ Object[] newArray(int n2) {
            return this.a(n2);
        }
    };
    v[] a;
    int[] b;
    h[] c;

    public u() {
    }

    public u(Parcel parcel) {
        this.a = (v[])parcel.createTypedArray(v.CREATOR);
        this.b = parcel.createIntArray();
        this.c = (h[])parcel.createTypedArray(h.CREATOR);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeTypedArray(this.a, n2);
        parcel.writeIntArray(this.b);
        parcel.writeTypedArray(this.c, n2);
    }

}

