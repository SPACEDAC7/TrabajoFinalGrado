/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.util.Log
 */
package android.support.v4.b;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.b.m;
import android.support.v4.b.q;
import android.support.v4.b.s;
import android.support.v4.b.t;
import android.util.Log;

final class v
implements Parcelable {
    public static final Parcelable.Creator<v> CREATOR = new Parcelable.Creator<v>(){

        public v a(Parcel parcel) {
            return new v(parcel);
        }

        public v[] a(int n2) {
            return new v[n2];
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return this.a(parcel);
        }

        public /* synthetic */ Object[] newArray(int n2) {
            return this.a(n2);
        }
    };
    final String a;
    final int b;
    final boolean c;
    final int d;
    final int e;
    final String f;
    final boolean g;
    final boolean h;
    final Bundle i;
    final boolean j;
    Bundle k;
    m l;

    /*
     * Enabled aggressive block sorting
     */
    public v(Parcel parcel) {
        boolean bl2 = true;
        this.a = parcel.readString();
        this.b = parcel.readInt();
        boolean bl3 = parcel.readInt() != 0;
        this.c = bl3;
        this.d = parcel.readInt();
        this.e = parcel.readInt();
        this.f = parcel.readString();
        bl3 = parcel.readInt() != 0;
        this.g = bl3;
        bl3 = parcel.readInt() != 0;
        this.h = bl3;
        this.i = parcel.readBundle();
        bl3 = parcel.readInt() != 0 ? bl2 : false;
        this.j = bl3;
        this.k = parcel.readBundle();
    }

    public v(m m2) {
        this.a = m2.getClass().getName();
        this.b = m2.n;
        this.c = m2.v;
        this.d = m2.E;
        this.e = m2.F;
        this.f = m2.G;
        this.g = m2.J;
        this.h = m2.I;
        this.i = m2.p;
        this.j = m2.H;
    }

    public m a(q q2, m m2, t t2) {
        if (this.l == null) {
            Context context = q2.g();
            if (this.i != null) {
                this.i.setClassLoader(context.getClassLoader());
            }
            this.l = m.a(context, this.a, this.i);
            if (this.k != null) {
                this.k.setClassLoader(context.getClassLoader());
                this.l.l = this.k;
            }
            this.l.a(this.b, m2);
            this.l.v = this.c;
            this.l.x = true;
            this.l.E = this.d;
            this.l.F = this.e;
            this.l.G = this.f;
            this.l.J = this.g;
            this.l.I = this.h;
            this.l.H = this.j;
            this.l.z = q2.d;
            if (s.a) {
                Log.v((String)"FragmentManager", (String)("Instantiated fragment " + this.l));
            }
        }
        this.l.C = t2;
        return this.l;
    }

    public int describeContents() {
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void writeToParcel(Parcel parcel, int n2) {
        int n3 = 1;
        parcel.writeString(this.a);
        parcel.writeInt(this.b);
        n2 = this.c ? 1 : 0;
        parcel.writeInt(n2);
        parcel.writeInt(this.d);
        parcel.writeInt(this.e);
        parcel.writeString(this.f);
        n2 = this.g ? 1 : 0;
        parcel.writeInt(n2);
        n2 = this.h ? 1 : 0;
        parcel.writeInt(n2);
        parcel.writeBundle(this.i);
        n2 = this.j ? n3 : 0;
        parcel.writeInt(n2);
        parcel.writeBundle(this.k);
    }

}

