/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.b;

import android.support.v4.b.m;

public abstract class w {
    public abstract int a();

    public abstract w a(int var1);

    public abstract w a(int var1, m var2, String var3);

    public abstract w a(m var1);

    public abstract w a(m var1, String var2);

    public abstract w a(String var1);

    public abstract int b();
}

