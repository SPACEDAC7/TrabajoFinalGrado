/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Rect
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.SparseArray
 *  android.view.View
 *  android.view.ViewGroup
 */
package android.support.v4.b;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.support.v4.b.aq;
import android.support.v4.b.av;
import android.support.v4.b.g;
import android.support.v4.b.m;
import android.support.v4.b.o;
import android.support.v4.b.q;
import android.support.v4.b.s;
import android.support.v4.b.y;
import android.support.v4.k.ae;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

class x {
    private static final int[] a = new int[]{0, 3, 0, 1, 5, 4, 7, 6};

    private static a a(a a2, SparseArray<a> sparseArray, int n2) {
        a a3 = a2;
        if (a2 == null) {
            a3 = new a();
            sparseArray.put(n2, (Object)a3);
        }
        return a3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static android.support.v4.j.a<String, String> a(int var0, ArrayList<g> var1_1, ArrayList<Boolean> var2_2, int var3_3, int var4_4) {
        var10_5 = new android.support.v4.j.a<String, String>();
        --var4_4;
        block0 : do {
            if (var4_4 < var3_3) return var10_5;
            var11_11 = var1_1.get(var4_4);
            if (!var11_11.c(var0)) ** GOTO lbl-1000
            var7_8 = var2_2.get(var4_4);
            if (var11_11.s == null) ** GOTO lbl-1000
            var6_7 = var11_11.s.size();
            if (var7_8) {
                var8_9 = var11_11.s;
                var9_10 = var11_11.t;
            } else {
                var9_10 = var11_11.s;
                var8_9 = var11_11.t;
            }
            var5_6 = 0;
            do {
                if (var5_6 >= var6_7) lbl-1000: // 3 sources:
                {
                    --var4_4;
                    continue block0;
                }
                var11_11 = var9_10.get(var5_6);
                var12_12 = var8_9.get(var5_6);
                var13_13 = var10_5.remove(var12_12);
                if (var13_13 != null) {
                    var10_5.put((String)var11_11, var13_13);
                } else {
                    var10_5.put((String)var11_11, var12_12);
                }
                ++var5_6;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Object a(m object, m m2, boolean bl2) {
        if (object == null || m2 == null) {
            return null;
        }
        if (bl2) {
            object = m2.B();
            do {
                return y.b(y.a(object));
                break;
            } while (true);
        }
        object = object.A();
        return y.b(y.a(object));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Object a(m object, boolean bl2) {
        if (object == null) {
            return null;
        }
        if (bl2) {
            object = object.z();
            do {
                return y.a(object);
                break;
            } while (true);
        }
        object = object.w();
        return y.a(object);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static Object a(ViewGroup viewGroup, final View view, android.support.v4.j.a<String, String> object, a a2, ArrayList<View> rect, ArrayList<View> view2, Object object2, Object object3) {
        Object var10_8 = null;
        final m m2 = a2.a;
        final m m3 = a2.d;
        if (m2 != null) {
            m2.q().setVisibility(0);
        }
        if (m2 == null) return null;
        if (m3 == null) {
            return null;
        }
        final boolean bl2 = a2.b;
        Object object4 = object.isEmpty() ? null : x.a(m2, m3, bl2);
        android.support.v4.j.a<String, View> a3 = x.b(object, object4, a2);
        final android.support.v4.j.a<String, View> a4 = x.c(object, object4, a2);
        if (object.isEmpty()) {
            if (a3 != null) {
                a3.clear();
            }
            if (a4 != null) {
                a4.clear();
                object = null;
            } else {
                object = null;
            }
        } else {
            x.a(rect, a3, object.keySet());
            x.a(view2, a4, object.values());
            object = object4;
        }
        if (object2 == null && object3 == null) {
            if (object == null) return null;
        }
        x.b(m2, m3, bl2, a3, true);
        if (object != null) {
            view2.add(view);
            y.a(object, view, rect);
            x.a(object, object3, a3, a2.e, a2.f);
            rect = new Rect();
            view = view2 = x.b(a4, a2, object2, bl2);
            a2 = rect;
            if (view2 != null) {
                y.a(object2, rect);
                a2 = rect;
                view = view2;
            }
        } else {
            a2 = null;
            view = var10_8;
        }
        aq.a((View)viewGroup, new Runnable((Rect)a2){
            final /* synthetic */ Rect f;

            @Override
            public void run() {
                x.b(m2, m3, bl2, a4, false);
                if (view != null) {
                    y.a(view, this.f);
                }
            }
        });
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object a(Object object, Object object2, Object object3, m m2, boolean bl2) {
        boolean bl3;
        boolean bl4 = bl3 = true;
        if (object == null) return y.a(object2, object, object3);
        bl4 = bl3;
        if (object2 != null) {
            bl4 = bl3;
            if (m2 != null) {
                bl4 = bl2 ? m2.D() : m2.C();
            }
        }
        if (bl4) {
            return y.a(object2, object, object3);
        }
        return y.b(object2, object, object3);
    }

    private static String a(android.support.v4.j.a<String, String> a2, String string) {
        int n2 = a2.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            if (!string.equals(a2.c(i2))) continue;
            return a2.b(i2);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void a(g object, g.a object2, SparseArray<a> sparseArray, boolean bl2, boolean bl3) {
        int n2;
        boolean bl4;
        boolean bl5;
        m m2 = object2.b;
        int n3 = m2.F;
        if (n3 == 0) {
            return;
        }
        int n4 = bl2 ? a[object2.a] : object2.a;
        switch (n4) {
            default: {
                n4 = 0;
                n2 = 0;
                bl5 = false;
                bl4 = false;
                break;
            }
            case 5: {
                bl4 = bl3 ? m2.Y && !m2.H && m2.t : m2.H;
                n4 = 1;
                n2 = 0;
                bl5 = false;
                break;
            }
            case 1: 
            case 7: {
                bl4 = bl3 ? m2.X : !m2.t && !m2.H;
                n4 = 1;
                n2 = 0;
                bl5 = false;
                break;
            }
            case 4: {
                n4 = bl3 ? (m2.Y && m2.t && m2.H ? 1 : 0) : (m2.t && !m2.H ? 1 : 0);
                int n5 = 0;
                n2 = n4;
                bl5 = true;
                bl4 = false;
                n4 = n5;
                break;
            }
            case 3: 
            case 6: {
                n4 = bl3 ? (!m2.t && m2.P != null && m2.P.getVisibility() == 0 && m2.Z >= 0.0f ? 1 : 0) : (m2.t && !m2.H ? 1 : 0);
                int n6 = 0;
                n2 = n4;
                bl5 = true;
                bl4 = false;
                n4 = n6;
            }
        }
        object2 = (a)sparseArray.get(n3);
        if (bl4) {
            object2 = x.a((a)object2, sparseArray, n3);
            object2.a = m2;
            object2.b = bl2;
            object2.c = object;
        }
        if (!bl3 && n4 != 0) {
            if (object2 != null && object2.d == m2) {
                object2.d = null;
            }
            s s2 = object.b;
            if (m2.k < 1 && s2.m >= 1 && !object.u) {
                s2.e(m2);
                s2.a(m2, 1, 0, 0, false);
            }
        }
        if (n2 != 0 && (object2 == null || object2.d == null)) {
            object2 = x.a((a)object2, sparseArray, n3);
            object2.d = m2;
            object2.e = bl2;
            object2.f = object;
            object = object2;
        } else {
            object = object2;
        }
        if (bl3) return;
        if (!bl5) return;
        if (object == null) return;
        if (object.a != m2) return;
        object.a = null;
    }

    public static void a(g g2, SparseArray<a> sparseArray, boolean bl2) {
        int n2 = g2.c.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            x.a(g2, g2.c.get(i2), sparseArray, false, bl2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void a(s arrayList, int n2, a object, View arrayList2, android.support.v4.j.a<String, String> a2) {
        ViewGroup viewGroup = null;
        if (!arrayList.o.a()) return;
        viewGroup = (ViewGroup)arrayList.o.a(n2);
        if (viewGroup == null) {
            return;
        }
        Object object2 = object.a;
        Object object3 = object.d;
        boolean bl2 = object.b;
        boolean bl3 = object.e;
        arrayList = new ArrayList();
        ArrayList<View> arrayList3 = new ArrayList<View>();
        Object object4 = x.a((m)object2, bl2);
        Object object5 = x.b((m)object3, bl3);
        object = x.a(viewGroup, arrayList2, a2, (a)object, arrayList3, arrayList, object4, object5);
        if (object4 == null && object == null) {
            if (object5 == null) return;
        }
        ArrayList<View> arrayList4 = x.b(object5, (m)object3, arrayList3, arrayList2);
        arrayList2 = x.b(object4, (m)object2, arrayList, arrayList2);
        x.b(arrayList2, 4);
        if ((object2 = x.a(object4, object5, object, (m)object2, bl2)) == null) return;
        x.a(object5, (m)object3, arrayList4);
        object3 = y.a(arrayList);
        y.a(object2, object4, arrayList2, object5, arrayList4, object, arrayList);
        y.a(viewGroup, object2);
        y.a((View)viewGroup, arrayList3, arrayList, object3, a2);
        x.b(arrayList2, 0);
        y.a(object, arrayList3, arrayList);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static void a(s s2, ArrayList<g> arrayList, ArrayList<Boolean> arrayList2, int n2, int n3, boolean bl2) {
        g g2;
        int n4;
        if (s2.m < 1) return;
        if (Build.VERSION.SDK_INT < 21) {
            return;
        }
        SparseArray sparseArray = new SparseArray();
        for (n4 = n2; n4 < n3; ++n4) {
            g2 = arrayList.get(n4);
            if (arrayList2.get(n4).booleanValue()) {
                x.b(g2, sparseArray, bl2);
                continue;
            }
            x.a(g2, sparseArray, bl2);
        }
        if (sparseArray.size() == 0) return;
        g2 = new View(s2.n.g());
        int n5 = sparseArray.size();
        n4 = 0;
        while (n4 < n5) {
            int n6 = sparseArray.keyAt(n4);
            android.support.v4.j.a<String, String> a2 = x.a(n6, arrayList, arrayList2, n2, n3);
            a a3 = (a)sparseArray.valueAt(n4);
            if (bl2) {
                x.a(s2, n6, a3, (View)g2, a2);
            } else {
                x.b(s2, n6, a3, (View)g2, a2);
            }
            ++n4;
        }
    }

    private static void a(android.support.v4.j.a<String, String> a2, android.support.v4.j.a<String, View> a3) {
        for (int i2 = a2.size() - 1; i2 >= 0; --i2) {
            if (a3.containsKey(a2.c(i2))) continue;
            a2.d(i2);
        }
    }

    private static void a(ViewGroup viewGroup, final m m2, final View view, final ArrayList<View> arrayList, final Object object, final ArrayList<View> arrayList2, final Object object2, final ArrayList<View> arrayList3) {
        aq.a((View)viewGroup, new Runnable(){

            @Override
            public void run() {
                ArrayList arrayList4;
                if (object != null) {
                    y.c(object, view);
                    arrayList4 = x.b(object, m2, arrayList, view);
                    arrayList2.addAll(arrayList4);
                }
                if (arrayList3 != null) {
                    if (object2 != null) {
                        arrayList4 = new ArrayList();
                        arrayList4.add((View)view);
                        y.b(object2, arrayList3, arrayList4);
                    }
                    arrayList3.clear();
                    arrayList3.add(view);
                }
            }
        });
    }

    private static void a(Object object, m m2, final ArrayList<View> arrayList) {
        if (m2 != null && object != null && m2.t && m2.H && m2.Y) {
            m2.i(true);
            y.b(object, m2.q(), arrayList);
            aq.a((View)m2.O, new Runnable(){

                @Override
                public void run() {
                    x.b(arrayList, 4);
                }
            });
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(Object object, Object object2, android.support.v4.j.a<String, View> view, boolean bl2, g object3) {
        if (object3.s != null && !object3.s.isEmpty()) {
            object3 = bl2 ? object3.t.get(0) : object3.s.get(0);
            view = (View)view.get(object3);
            y.a(object, view);
            if (object2 != null) {
                y.a(object2, view);
            }
        }
    }

    private static void a(ArrayList<View> arrayList, android.support.v4.j.a<String, View> a2, Collection<String> collection) {
        for (int i2 = a2.size() - 1; i2 >= 0; --i2) {
            View view = a2.c(i2);
            if (!collection.contains(ae.t(view))) continue;
            arrayList.add(view);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static android.support.v4.j.a<String, View> b(android.support.v4.j.a<String, String> a2, Object arrayList, a object) {
        if (a2.isEmpty() || arrayList == null) {
            a2.clear();
            return null;
        }
        Object object2 = object.d;
        android.support.v4.j.a<String, View> a3 = new android.support.v4.j.a<String, View>();
        y.a(a3, object2.q());
        arrayList = object.f;
        if (object.e) {
            object = object2.S();
            arrayList = arrayList.t;
        } else {
            object = object2.T();
            arrayList = arrayList.s;
        }
        a3.a(arrayList);
        if (object == null) {
            a2.a(a3.keySet());
            return a3;
        } else {
            object.a(arrayList, a3);
            for (int i2 = arrayList.size() - 1; i2 >= 0; --i2) {
                object2 = arrayList.get(i2);
                object = a3.get(object2);
                if (object == null) {
                    a2.remove(object2);
                    continue;
                }
                if (object2.equals(ae.t((View)object))) continue;
                object2 = a2.remove(object2);
                a2.put(ae.t((View)object), (String)object2);
            }
        }
        return a3;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static View b(android.support.v4.j.a<String, View> a2, a object, Object object2, boolean bl2) {
        object = object.c;
        if (object2 == null || object.s == null || object.s.isEmpty()) return null;
        if (bl2) {
            object = object.s.get(0);
            do {
                return a2.get(object);
                break;
            } while (true);
        }
        object = object.t.get(0);
        return a2.get(object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Object b(m object, boolean bl2) {
        if (object == null) {
            return null;
        }
        if (bl2) {
            object = object.x();
            do {
                return y.a(object);
                break;
            } while (true);
        }
        object = object.y();
        return y.a(object);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object b(ViewGroup viewGroup, final View view, final android.support.v4.j.a<String, String> a2, final a a3, final ArrayList<View> arrayList, final ArrayList<View> arrayList2, final Object object, Object object2) {
        final m m2 = a3.a;
        final m m3 = a3.d;
        if (m2 == null || m3 == null) {
            return null;
        }
        final boolean bl2 = a3.b;
        final Object object3 = a2.isEmpty() ? null : x.a(m2, m3, bl2);
        android.support.v4.j.a<String, View> a4 = x.b(a2, object3, a3);
        if (a2.isEmpty()) {
            object3 = null;
        } else {
            arrayList.addAll(a4.values());
        }
        if (object == null && object2 == null && object3 == null) {
            return null;
        }
        x.b(m2, m3, bl2, a4, true);
        if (object3 != null) {
            Rect rect = new Rect();
            y.a(object3, view, arrayList);
            x.a(object3, object2, a4, a3.e, a3.f);
            object2 = rect;
            if (object != null) {
                y.a(object, rect);
                object2 = rect;
            }
        } else {
            object2 = null;
        }
        aq.a((View)viewGroup, new Runnable((Rect)object2){
            final /* synthetic */ Rect k;

            @Override
            public void run() {
                android.support.v4.j.a a22 = x.c(a2, object3, a3);
                if (a22 != null) {
                    arrayList2.addAll(a22.values());
                    arrayList2.add(view);
                }
                x.b(m2, m3, bl2, a22, false);
                if (object3 != null) {
                    y.a(object3, arrayList, arrayList2);
                    a22 = x.b(a22, a3, object, bl2);
                    if (a22 != null) {
                        y.a((View)a22, this.k);
                    }
                }
            }
        });
        return object3;
    }

    private static ArrayList<View> b(Object object, m m2, ArrayList<View> arrayList, View view) {
        ArrayList<View> arrayList2 = null;
        if (object != null) {
            ArrayList<View> arrayList3 = new ArrayList<View>();
            y.a(arrayList3, m2.q());
            if (arrayList != null) {
                arrayList3.removeAll(arrayList);
            }
            arrayList2 = arrayList3;
            if (!arrayList3.isEmpty()) {
                arrayList3.add(view);
                y.a(object, arrayList3);
                arrayList2 = arrayList3;
            }
        }
        return arrayList2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void b(g g2, SparseArray<a> sparseArray, boolean bl2) {
        if (g2.b.o.a()) {
            for (int i2 = g2.c.size() - 1; i2 >= 0; --i2) {
                x.a(g2, g2.c.get(i2), sparseArray, true, bl2);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void b(m object, m arrayList, boolean bl2, android.support.v4.j.a<String, View> a2, boolean bl3) {
        object = bl2 ? arrayList.S() : object.S();
        if (object != null) {
            arrayList = new ArrayList();
            ArrayList<String> arrayList2 = new ArrayList<String>();
            int n2 = a2 == null ? 0 : a2.size();
            for (int i2 = 0; i2 < n2; ++i2) {
                arrayList2.add(a2.b(i2));
                arrayList.add(a2.c(i2));
            }
            if (!bl3) {
                object.b(arrayList2, arrayList, null);
                return;
            }
            object.a(arrayList2, arrayList, null);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void b(s object, int n2, a object2, View view, android.support.v4.j.a<String, String> a2) {
        ViewGroup viewGroup = null;
        if (!object.o.a()) return;
        viewGroup = (ViewGroup)object.o.a(n2);
        if (viewGroup == null) {
            return;
        }
        m m2 = object2.a;
        Object object3 = object2.d;
        boolean bl2 = object2.b;
        boolean bl3 = object2.e;
        Object object4 = x.a(m2, bl2);
        object = x.b((m)object3, bl3);
        ArrayList<View> arrayList = new ArrayList<View>();
        ArrayList<View> arrayList2 = new ArrayList<View>();
        Object object5 = x.b(viewGroup, view, a2, (a)object2, arrayList, arrayList2, object4, object);
        if (object4 == null && object5 == null) {
            if (object == null) return;
        }
        if ((object3 = x.b(object, (m)object3, arrayList, view)) == null || object3.isEmpty()) {
            object = null;
        }
        y.b(object4, view);
        object2 = x.a(object4, object, object5, m2, object2.b);
        if (object2 == null) return;
        ArrayList<View> arrayList3 = new ArrayList<View>();
        y.a(object2, object4, arrayList3, object, object3, object5, arrayList2);
        x.a(viewGroup, m2, view, arrayList2, object4, arrayList3, object, object3);
        y.a((View)viewGroup, arrayList2, a2);
        y.a(viewGroup, object2);
        y.a(viewGroup, arrayList2, a2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void b(ArrayList<View> arrayList, int n2) {
        if (arrayList != null) {
            for (int i2 = arrayList.size() - 1; i2 >= 0; --i2) {
                arrayList.get(i2).setVisibility(n2);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static android.support.v4.j.a<String, View> c(android.support.v4.j.a<String, String> a2, Object arrayList, a object) {
        Object object2 = object.a;
        View view = object2.q();
        if (a2.isEmpty() || arrayList == null || view == null) {
            a2.clear();
            return null;
        }
        android.support.v4.j.a<String, View> a3 = new android.support.v4.j.a<String, View>();
        y.a(a3, view);
        arrayList = object.c;
        if (object.b) {
            object = object2.T();
            arrayList = arrayList.s;
        } else {
            object = object2.S();
            arrayList = arrayList.t;
        }
        a3.a(arrayList);
        if (object == null) {
            x.a(a2, a3);
            return a3;
        } else {
            object.a(arrayList, a3);
            for (int i2 = arrayList.size() - 1; i2 >= 0; --i2) {
                object2 = arrayList.get(i2);
                object = a3.get(object2);
                if (object == null) {
                    object = x.a(a2, (String)object2);
                    if (object == null) continue;
                    a2.remove(object);
                    continue;
                }
                if (object2.equals(ae.t((View)object)) || (object2 = x.a(a2, (String)object2)) == null) continue;
                a2.put((String)object2, ae.t((View)object));
            }
        }
        return a3;
    }

    static class a {
        public m a;
        public boolean b;
        public g c;
        public m d;
        public boolean e;
        public g f;

        a() {
        }
    }

}

