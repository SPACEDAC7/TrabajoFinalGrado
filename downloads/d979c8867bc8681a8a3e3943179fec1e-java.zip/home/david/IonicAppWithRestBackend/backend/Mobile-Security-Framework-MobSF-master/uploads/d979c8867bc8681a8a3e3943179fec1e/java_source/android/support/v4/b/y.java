/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.Rect
 *  android.transition.Transition
 *  android.transition.Transition$EpicenterCallback
 *  android.transition.Transition$TransitionListener
 *  android.transition.TransitionManager
 *  android.transition.TransitionSet
 *  android.view.View
 *  android.view.ViewGroup
 */
package android.support.v4.b;

import android.annotation.TargetApi;
import android.graphics.Rect;
import android.support.v4.b.aq;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

@TargetApi(value=21)
class y {
    public static Object a(Object object) {
        Transition transition = null;
        if (object != null) {
            transition = ((Transition)object).clone();
        }
        return transition;
    }

    public static Object a(Object object, Object object2, Object object3) {
        TransitionSet transitionSet = new TransitionSet();
        if (object != null) {
            transitionSet.addTransition((Transition)object);
        }
        if (object2 != null) {
            transitionSet.addTransition((Transition)object2);
        }
        if (object3 != null) {
            transitionSet.addTransition((Transition)object3);
        }
        return transitionSet;
    }

    public static ArrayList<String> a(ArrayList<View> arrayList) {
        ArrayList<String> arrayList2 = new ArrayList<String>();
        int n2 = arrayList.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            View view = arrayList.get(i2);
            arrayList2.add(view.getTransitionName());
            view.setTransitionName(null);
        }
        return arrayList2;
    }

    public static void a(View view, Rect rect) {
        int[] arrn = new int[2];
        view.getLocationOnScreen(arrn);
        rect.set(arrn[0], arrn[1], arrn[0] + view.getWidth(), arrn[1] + view.getHeight());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static void a(View var0, final ArrayList<View> var1_1, final ArrayList<View> var2_2, final ArrayList<String> var3_3, Map<String, String> var4_4) {
        var7_5 = var2_2.size();
        var8_6 = new ArrayList<String>();
        var5_7 = 0;
        block0 : do {
            if (var5_7 >= var7_5) {
                aq.a(var0, new Runnable(){

                    @Override
                    public void run() {
                        for (int i2 = 0; i2 < var7_5; ++i2) {
                            ((View)var2_2.get(i2)).setTransitionName((String)var3_3.get(i2));
                            ((View)var1_1.get(i2)).setTransitionName((String)var8_6.get(i2));
                        }
                    }
                });
                return;
            }
            var10_10 = var1_1.get(var5_7);
            var9_9 = var10_10.getTransitionName();
            var8_6.add(var9_9);
            if (var9_9 == null) ** GOTO lbl-1000
            var10_10.setTransitionName(null);
            var10_10 = var4_4.get(var9_9);
            var6_8 = 0;
            do {
                if (var6_8 >= var7_5) lbl-1000: // 3 sources:
                {
                    do {
                        ++var5_7;
                        continue block0;
                        break;
                    } while (true);
                }
                if (var10_10.equals(var3_3.get(var6_8))) {
                    var2_2.get(var6_8).setTransitionName(var9_9);
                    ** continue;
                }
                ++var6_8;
            } while (true);
            break;
        } while (true);
    }

    public static void a(View view, final ArrayList<View> arrayList, final Map<String, String> map) {
        aq.a(view, new Runnable(){

            @Override
            public void run() {
                int n2 = arrayList.size();
                for (int i2 = 0; i2 < n2; ++i2) {
                    View view = (View)arrayList.get(i2);
                    String string = view.getTransitionName();
                    if (string == null) continue;
                    view.setTransitionName(y.b(map, string));
                }
            }
        });
    }

    public static void a(ViewGroup viewGroup, Object object) {
        TransitionManager.beginDelayedTransition((ViewGroup)viewGroup, (Transition)((Transition)object));
    }

    public static void a(ViewGroup viewGroup, final ArrayList<View> arrayList, final Map<String, String> map) {
        aq.a((View)viewGroup, new Runnable(){

            @Override
            public void run() {
                int n2 = arrayList.size();
                for (int i2 = 0; i2 < n2; ++i2) {
                    View view = (View)arrayList.get(i2);
                    String string = view.getTransitionName();
                    view.setTransitionName((String)map.get(string));
                }
            }
        });
    }

    public static void a(Object object, final Rect rect) {
        if (object != null) {
            ((Transition)object).setEpicenterCallback(new Transition.EpicenterCallback(){

                public Rect onGetEpicenter(Transition transition) {
                    if (rect == null || rect.isEmpty()) {
                        return null;
                    }
                    return rect;
                }
            });
        }
    }

    public static void a(Object object, View view) {
        if (view != null) {
            object = (Transition)object;
            final Rect rect = new Rect();
            y.a(view, rect);
            object.setEpicenterCallback(new Transition.EpicenterCallback(){

                public Rect onGetEpicenter(Transition transition) {
                    return rect;
                }
            });
        }
    }

    public static void a(Object object, View view, ArrayList<View> arrayList) {
        object = (TransitionSet)object;
        List list = object.getTargets();
        list.clear();
        int n2 = arrayList.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            y.a(list, arrayList.get(i2));
        }
        list.add(view);
        arrayList.add(view);
        y.a(object, arrayList);
    }

    public static void a(Object object, final Object object2, final ArrayList<View> arrayList, final Object object3, final ArrayList<View> arrayList2, final Object object4, final ArrayList<View> arrayList3) {
        ((Transition)object).addListener(new Transition.TransitionListener(){

            public void onTransitionCancel(Transition transition) {
            }

            public void onTransitionEnd(Transition transition) {
            }

            public void onTransitionPause(Transition transition) {
            }

            public void onTransitionResume(Transition transition) {
            }

            public void onTransitionStart(Transition transition) {
                if (object2 != null) {
                    y.b(object2, arrayList, null);
                }
                if (object3 != null) {
                    y.b(object3, arrayList2, null);
                }
                if (object4 != null) {
                    y.b(object4, arrayList3, null);
                }
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(Object object, ArrayList<View> arrayList) {
        int n2;
        if ((object = (Transition)object) == null) return;
        if (object instanceof TransitionSet) {
            object = (TransitionSet)object;
            int n3 = object.getTransitionCount();
            for (n2 = 0; n2 < n3; ++n2) {
                y.a((Object)object.getTransitionAt(n2), arrayList);
            }
            return;
        }
        if (y.a((Transition)object) || !y.a(object.getTargets())) {
            return;
        }
        int n4 = arrayList.size();
        n2 = 0;
        while (n2 < n4) {
            object.addTarget(arrayList.get(n2));
            ++n2;
        }
    }

    public static void a(Object object, ArrayList<View> arrayList, ArrayList<View> arrayList2) {
        if ((object = (TransitionSet)object) != null) {
            object.getTargets().clear();
            object.getTargets().addAll(arrayList2);
            y.b(object, arrayList, arrayList2);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void a(ArrayList<View> arrayList, View view) {
        if (view.getVisibility() != 0) return;
        if (view instanceof ViewGroup) {
            if ((view = (ViewGroup)view).isTransitionGroup()) {
                arrayList.add(view);
                return;
            }
            int n2 = view.getChildCount();
            int n3 = 0;
            while (n3 < n2) {
                y.a(arrayList, view.getChildAt(n3));
                ++n3;
            }
            return;
        }
        arrayList.add(view);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(List<View> list, View view) {
        int n2 = list.size();
        if (!y.a(list, view, n2)) {
            list.add(view);
            for (int i2 = n2; i2 < list.size(); ++i2) {
                view = list.get(i2);
                if (!(view instanceof ViewGroup)) continue;
                view = (ViewGroup)view;
                int n3 = view.getChildCount();
                for (int i3 = 0; i3 < n3; ++i3) {
                    View view2 = view.getChildAt(i3);
                    if (y.a(list, view2, n2)) continue;
                    list.add(view2);
                }
            }
        }
    }

    public static void a(Map<String, View> map, View view) {
        if (view.getVisibility() == 0) {
            String string = view.getTransitionName();
            if (string != null) {
                map.put(string, view);
            }
            if (view instanceof ViewGroup) {
                view = (ViewGroup)view;
                int n2 = view.getChildCount();
                for (int i2 = 0; i2 < n2; ++i2) {
                    y.a(map, view.getChildAt(i2));
                }
            }
        }
    }

    private static boolean a(Transition transition) {
        if (!(y.a(transition.getTargetIds()) && y.a(transition.getTargetNames()) && y.a(transition.getTargetTypes()))) {
            return true;
        }
        return false;
    }

    private static boolean a(List list) {
        if (list == null || list.isEmpty()) {
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean a(List<View> list, View view, int n2) {
        boolean bl2 = false;
        int n3 = 0;
        do {
            boolean bl3 = bl2;
            if (n3 >= n2) return bl3;
            if (list.get(n3) == view) {
                return true;
            }
            ++n3;
        } while (true);
    }

    public static Object b(Object object) {
        if (object == null) {
            return null;
        }
        TransitionSet transitionSet = new TransitionSet();
        transitionSet.addTransition((Transition)object);
        return transitionSet;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Object b(Object object, Object object2, Object object3) {
        Object var3_3 = null;
        object = (Transition)object;
        object2 = (Transition)object2;
        object3 = (Transition)object3;
        if (object != null && object2 != null) {
            object = new TransitionSet().addTransition((Transition)object).addTransition((Transition)object2).setOrdering(1);
        } else if (object == null) {
            object = var3_3;
            if (object2 != null) {
                object = object2;
            }
        }
        if (object3 == null) {
            return object;
        }
        object2 = new TransitionSet();
        if (object != null) {
            object2.addTransition((Transition)object);
        }
        object2.addTransition((Transition)object3);
        return object2;
    }

    private static String b(Map<String, String> object, String string) {
        for (Map.Entry entry : object.entrySet()) {
            if (!string.equals(entry.getValue())) continue;
            return (String)entry.getKey();
        }
        return null;
    }

    public static void b(Object object, View view) {
        if (object != null) {
            ((Transition)object).addTarget(view);
        }
    }

    public static void b(Object object, final View view, final ArrayList<View> arrayList) {
        ((Transition)object).addListener(new Transition.TransitionListener(){

            public void onTransitionCancel(Transition transition) {
            }

            public void onTransitionEnd(Transition transition) {
                transition.removeListener((Transition.TransitionListener)this);
                view.setVisibility(8);
                int n2 = arrayList.size();
                for (int i2 = 0; i2 < n2; ++i2) {
                    ((View)arrayList.get(i2)).setVisibility(0);
                }
            }

            public void onTransitionPause(Transition transition) {
            }

            public void onTransitionResume(Transition transition) {
            }

            public void onTransitionStart(Transition transition) {
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void b(Object object, ArrayList<View> arrayList, ArrayList<View> arrayList2) {
        List list;
        int n2;
        if ((object = (Transition)object) instanceof TransitionSet) {
            object = (TransitionSet)object;
            int n3 = object.getTransitionCount();
            for (n2 = 0; n2 < n3; ++n2) {
                y.b((Object)object.getTransitionAt(n2), arrayList, arrayList2);
            }
            return;
        }
        if (y.a((Transition)object) || (list = object.getTargets()) == null || list.size() != arrayList.size() || !list.containsAll(arrayList)) return;
        n2 = arrayList2 == null ? 0 : arrayList2.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            object.addTarget(arrayList2.get(i2));
        }
        for (n2 = arrayList.size() - 1; n2 >= 0; --n2) {
            object.removeTarget(arrayList.get(n2));
        }
    }

    public static void c(Object object, View view) {
        if (object != null) {
            ((Transition)object).removeTarget(view);
        }
    }

}

