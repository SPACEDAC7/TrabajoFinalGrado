/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  android.util.AttributeSet
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.animation.Animation
 *  android.view.animation.AnimationUtils
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.ProgressBar
 *  android.widget.TextView
 */
package android.support.v4.b;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.b.m;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class z
extends m {
    ListAdapter a;
    private final Runnable aa;
    private final AdapterView.OnItemClickListener ab;
    ListView b;
    View c;
    TextView d;
    View e;
    View f;
    CharSequence g;
    boolean h;
    private final Handler i = new Handler();

    public z() {
        this.aa = new Runnable(){

            @Override
            public void run() {
                z.this.b.focusableViewAvailable((View)z.this.b);
            }
        };
        this.ab = new AdapterView.OnItemClickListener(){

            public void onItemClick(AdapterView<?> adapterView, View view, int n2, long l2) {
                z.this.a((ListView)adapterView, view, n2, l2);
            }
        };
    }

    /*
     * Enabled aggressive block sorting
     */
    private void Z() {
        if (this.b != null) {
            return;
        }
        View view = this.q();
        if (view == null) {
            throw new IllegalStateException("Content view not yet created");
        }
        if (view instanceof ListView) {
            this.b = (ListView)view;
        } else {
            this.d = (TextView)view.findViewById(16711681);
            if (this.d == null) {
                this.c = view.findViewById(16908292);
            } else {
                this.d.setVisibility(8);
            }
            this.e = view.findViewById(16711682);
            this.f = view.findViewById(16711683);
            if (!((view = view.findViewById(16908298)) instanceof ListView)) {
                if (view == null) {
                    throw new RuntimeException("Your content must have a ListView whose id attribute is 'android.R.id.list'");
                }
                throw new RuntimeException("Content has view with id attribute 'android.R.id.list' that is not a ListView class");
            }
            this.b = (ListView)view;
            if (this.c != null) {
                this.b.setEmptyView(this.c);
            } else if (this.g != null) {
                this.d.setText(this.g);
                this.b.setEmptyView((View)this.d);
            }
        }
        this.h = true;
        this.b.setOnItemClickListener(this.ab);
        if (this.a != null) {
            view = this.a;
            this.a = null;
            this.a((ListAdapter)view);
        } else if (this.e != null) {
            this.a(false, false);
        }
        this.i.post(this.aa);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(boolean bl2, boolean bl3) {
        this.Z();
        if (this.e == null) {
            throw new IllegalStateException("Can't be used with a custom content view");
        }
        if (this.h == bl2) {
            return;
        }
        this.h = bl2;
        if (bl2) {
            if (bl3) {
                this.e.startAnimation(AnimationUtils.loadAnimation((Context)this.i(), (int)17432577));
                this.f.startAnimation(AnimationUtils.loadAnimation((Context)this.i(), (int)17432576));
            } else {
                this.e.clearAnimation();
                this.f.clearAnimation();
            }
            this.e.setVisibility(8);
            this.f.setVisibility(0);
            return;
        }
        if (bl3) {
            this.e.startAnimation(AnimationUtils.loadAnimation((Context)this.i(), (int)17432576));
            this.f.startAnimation(AnimationUtils.loadAnimation((Context)this.i(), (int)17432577));
        } else {
            this.e.clearAnimation();
            this.f.clearAnimation();
        }
        this.e.setVisibility(0);
        this.f.setVisibility(8);
    }

    public ListAdapter Y() {
        return this.a;
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        viewGroup = this.i();
        layoutInflater = new FrameLayout((Context)viewGroup);
        bundle = new LinearLayout((Context)viewGroup);
        bundle.setId(16711682);
        bundle.setOrientation(1);
        bundle.setVisibility(8);
        bundle.setGravity(17);
        bundle.addView((View)new ProgressBar((Context)viewGroup, null, 16842874), (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -2));
        layoutInflater.addView((View)bundle, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
        bundle = new FrameLayout((Context)viewGroup);
        bundle.setId(16711683);
        TextView textView = new TextView((Context)viewGroup);
        textView.setId(16711681);
        textView.setGravity(17);
        bundle.addView((View)textView, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
        viewGroup = new ListView((Context)viewGroup);
        viewGroup.setId(16908298);
        viewGroup.setDrawSelectorOnTop(false);
        bundle.addView((View)viewGroup, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
        layoutInflater.addView((View)bundle, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
        layoutInflater.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
        return layoutInflater;
    }

    @Override
    public void a(View view, Bundle bundle) {
        super.a(view, bundle);
        this.Z();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(ListAdapter listAdapter) {
        boolean bl2 = false;
        boolean bl3 = this.a != null;
        this.a = listAdapter;
        if (this.b != null) {
            this.b.setAdapter(listAdapter);
            if (!this.h && !bl3) {
                if (this.q().getWindowToken() != null) {
                    bl2 = true;
                }
                this.a(true, bl2);
            }
        }
    }

    public void a(ListView listView, View view, int n2, long l2) {
    }

    @Override
    public void e() {
        this.i.removeCallbacks(this.aa);
        this.b = null;
        this.h = false;
        this.f = null;
        this.e = null;
        this.c = null;
        this.d = null;
        super.e();
    }

    public ListView e_() {
        this.Z();
        return this.b;
    }

}

