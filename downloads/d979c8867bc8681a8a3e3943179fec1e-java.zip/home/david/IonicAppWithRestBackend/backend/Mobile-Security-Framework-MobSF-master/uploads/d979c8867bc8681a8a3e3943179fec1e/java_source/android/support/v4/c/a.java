/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 *  android.os.SystemClock
 */
package android.support.v4.c;

import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.c.l;
import android.support.v4.c.n;
import android.support.v4.f.f;
import android.support.v4.j.m;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;

public abstract class a<D>
extends l<D> {
    volatile a<D> a;
    volatile a<D> b;
    long c;
    long d = -10000;
    Handler e;
    private final Executor f;

    public a(Context context) {
        this(context, n.c);
    }

    private a(Context context, Executor executor) {
        super(context);
        this.f = executor;
    }

    @Override
    protected void a() {
        super.a();
        this.s();
        this.a = new a();
        this.c();
    }

    void a(a<D> a2, D d2) {
        this.a(d2);
        if (this.b == a2) {
            this.A();
            this.d = SystemClock.uptimeMillis();
            this.b = null;
            this.l();
            this.c();
        }
    }

    public void a(D d2) {
    }

    @Override
    public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        super.a(string, fileDescriptor, printWriter, arrstring);
        if (this.a != null) {
            printWriter.print(string);
            printWriter.print("mTask=");
            printWriter.print(this.a);
            printWriter.print(" waiting=");
            printWriter.println(this.a.a);
        }
        if (this.b != null) {
            printWriter.print(string);
            printWriter.print("mCancellingTask=");
            printWriter.print(this.b);
            printWriter.print(" waiting=");
            printWriter.println(this.b.a);
        }
        if (this.c != 0) {
            printWriter.print(string);
            printWriter.print("mUpdateThrottle=");
            m.a(this.c, printWriter);
            printWriter.print(" mLastLoadCompleteTime=");
            m.a(this.d, SystemClock.uptimeMillis(), printWriter);
            printWriter.println();
        }
    }

    void b(a<D> a2, D d2) {
        if (this.a != a2) {
            this.a(a2, d2);
            return;
        }
        if (this.p()) {
            this.a(d2);
            return;
        }
        this.z();
        this.d = SystemClock.uptimeMillis();
        this.a = null;
        this.b(d2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean b() {
        if (this.a == null) return false;
        if (this.b != null) {
            if (this.a.a) {
                this.a.a = false;
                this.e.removeCallbacks(this.a);
            }
            this.a = null;
            return false;
        }
        if (this.a.a) {
            this.a.a = false;
            this.e.removeCallbacks(this.a);
            this.a = null;
            return false;
        }
        boolean bl2 = this.a.a(false);
        if (bl2) {
            this.b = this.a;
            this.f();
        }
        this.a = null;
        return bl2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    void c() {
        if (this.b != null || this.a == null) return;
        if (this.a.a) {
            this.a.a = false;
            this.e.removeCallbacks(this.a);
        }
        if (this.c > 0 && SystemClock.uptimeMillis() < this.d + this.c) {
            this.a.a = true;
            this.e.postAtTime(this.a, this.d + this.c);
            return;
        }
        this.a.a(this.f, (Params[])null);
    }

    public abstract D d();

    protected D e() {
        return this.d();
    }

    public void f() {
    }

    public boolean g() {
        if (this.b != null) {
            return true;
        }
        return false;
    }

    final class a
    extends n<Void, Void, D>
    implements Runnable {
        boolean a;
        private final CountDownLatch d;

        a() {
            this.d = new CountDownLatch(1);
        }

        protected /* varargs */ D a(Void ... object) {
            try {
                object = a.this.e();
            }
            catch (f var1_2) {
                if (!this.c()) {
                    throw var1_2;
                }
                return null;
            }
            return (D)object;
        }

        @Override
        protected void a(D d2) {
            try {
                a.this.b(this, d2);
                return;
            }
            finally {
                this.d.countDown();
            }
        }

        @Override
        protected void b(D d2) {
            try {
                a.this.a(this, d2);
                return;
            }
            finally {
                this.d.countDown();
            }
        }

        @Override
        public void run() {
            this.a = false;
            a.this.c();
        }
    }

}

