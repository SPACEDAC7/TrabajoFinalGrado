/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package android.support.v4.c.a;

import android.content.res.Resources;
import android.os.Build;

public final class a {
    private static final a a;

    static {
        int n2 = Build.VERSION.SDK_INT;
        a = n2 >= 17 ? new d() : (n2 >= 13 ? new c() : new b());
    }

    public static int a(Resources resources) {
        return a.a(resources);
    }

    public static int b(Resources resources) {
        return a.b(resources);
    }

    public static int c(Resources resources) {
        return a.c(resources);
    }

    private static interface a {
        public int a(Resources var1);

        public int b(Resources var1);

        public int c(Resources var1);
    }

    private static class b
    implements a {
        b() {
        }

        @Override
        public int a(Resources resources) {
            return android.support.v4.c.a.b.a(resources);
        }

        @Override
        public int b(Resources resources) {
            return android.support.v4.c.a.b.b(resources);
        }

        @Override
        public int c(Resources resources) {
            return android.support.v4.c.a.b.c(resources);
        }
    }

    private static class c
    extends b {
        c() {
        }

        @Override
        public int a(Resources resources) {
            return android.support.v4.c.a.c.a(resources);
        }

        @Override
        public int b(Resources resources) {
            return android.support.v4.c.a.c.b(resources);
        }

        @Override
        public int c(Resources resources) {
            return android.support.v4.c.a.c.c(resources);
        }
    }

    private static class d
    extends c {
        d() {
        }
    }

}

