/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.res.Resources
 *  android.util.DisplayMetrics
 */
package android.support.v4.c.a;

import android.annotation.TargetApi;
import android.content.res.Resources;
import android.util.DisplayMetrics;

@TargetApi(value=9)
class b {
    static int a(Resources resources) {
        resources = resources.getDisplayMetrics();
        return (int)((float)resources.heightPixels / resources.density);
    }

    static int b(Resources resources) {
        resources = resources.getDisplayMetrics();
        return (int)((float)resources.widthPixels / resources.density);
    }

    static int c(Resources resources) {
        return Math.min(b.b(resources), b.a(resources));
    }
}

