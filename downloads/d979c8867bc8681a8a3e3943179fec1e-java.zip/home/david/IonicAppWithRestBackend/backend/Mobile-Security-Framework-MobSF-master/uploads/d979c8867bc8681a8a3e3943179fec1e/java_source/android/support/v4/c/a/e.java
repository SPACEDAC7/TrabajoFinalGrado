/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.graphics.drawable.Drawable
 */
package android.support.v4.c.a;

import android.annotation.TargetApi;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;

@TargetApi(value=21)
class e {
    public static Drawable a(Resources resources, int n2, Resources.Theme theme) {
        return resources.getDrawable(n2, theme);
    }
}

