/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package android.support.v4.c;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.support.v4.f.d;
import android.support.v4.f.f;

public final class b {
    private static final a a = Build.VERSION.SDK_INT >= 16 ? new c() : new b();

    public static Cursor a(ContentResolver contentResolver, Uri uri, String[] arrstring, String string, String[] arrstring2, String string2, d d2) {
        return a.a(contentResolver, uri, arrstring, string, arrstring2, string2, d2);
    }

    static interface a {
        public Cursor a(ContentResolver var1, Uri var2, String[] var3, String var4, String[] var5, String var6, d var7);
    }

    static class b
    implements a {
        b() {
        }

        @Override
        public Cursor a(ContentResolver contentResolver, Uri uri, String[] arrstring, String string, String[] arrstring2, String string2, d d2) {
            if (d2 != null) {
                d2.b();
            }
            return contentResolver.query(uri, arrstring, string, arrstring2, string2);
        }
    }

    static class c
    extends b {
        c() {
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        @Override
        public Cursor a(ContentResolver contentResolver, Uri uri, String[] arrstring, String string, String[] arrstring2, String string2, d object) {
            if (object == null) ** GOTO lbl5
            try {
                object = object.d();
                return android.support.v4.c.c.a(contentResolver, uri, arrstring, string, arrstring2, string2, object);
lbl5: // 1 sources:
                object = null;
                return android.support.v4.c.c.a(contentResolver, uri, arrstring, string, arrstring2, string2, object);
            }
            catch (Exception exception) {
                if (android.support.v4.c.c.a(exception) == false) throw exception;
                throw new f();
            }
        }
    }

}

