/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.ContentResolver
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.CancellationSignal
 *  android.os.OperationCanceledException
 */
package android.support.v4.c;

import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.OperationCanceledException;

@TargetApi(value=16)
class c {
    public static Cursor a(ContentResolver contentResolver, Uri uri, String[] arrstring, String string, String[] arrstring2, String string2, Object object) {
        return contentResolver.query(uri, arrstring, string, arrstring2, string2, (CancellationSignal)object);
    }

    static boolean a(Exception exception) {
        return exception instanceof OperationCanceledException;
    }
}

