/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Process
 *  android.util.TypedValue
 */
package android.support.v4.c;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.support.v4.c.e;
import android.support.v4.c.f;
import android.support.v4.c.g;
import android.support.v4.c.h;
import android.util.TypedValue;

public class d {
    private static final Object a = new Object();
    private static TypedValue b;

    public static int a(Context context, String string) {
        if (string == null) {
            throw new IllegalArgumentException("permission is null");
        }
        return context.checkPermission(string, Process.myPid(), Process.myUid());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final Drawable a(Context context, int n2) {
        int n3 = Build.VERSION.SDK_INT;
        if (n3 >= 21) {
            return e.a(context, n2);
        }
        if (n3 >= 16) {
            return context.getResources().getDrawable(n2);
        }
        Object object = a;
        synchronized (object) {
            if (b == null) {
                b = new TypedValue();
            }
            context.getResources().getValue(n2, b, true);
            n2 = d.b.resourceId;
            return context.getResources().getDrawable(n2);
        }
    }

    public static boolean a(Context context, Intent[] arrintent, Bundle bundle) {
        int n2 = Build.VERSION.SDK_INT;
        if (n2 >= 16) {
            h.a(context, arrintent, bundle);
            return true;
        }
        if (n2 >= 11) {
            g.a(context, arrintent);
            return true;
        }
        return false;
    }

    public static final ColorStateList b(Context context, int n2) {
        if (Build.VERSION.SDK_INT >= 23) {
            return f.a(context, n2);
        }
        return context.getResources().getColorStateList(n2);
    }

    public static final int c(Context context, int n2) {
        if (Build.VERSION.SDK_INT >= 23) {
            return f.b(context, n2);
        }
        return context.getResources().getColor(n2);
    }
}

