/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 */
package android.support.v4.c;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;

@TargetApi(value=21)
class e {
    public static Drawable a(Context context, int n2) {
        return context.getDrawable(n2);
    }
}

