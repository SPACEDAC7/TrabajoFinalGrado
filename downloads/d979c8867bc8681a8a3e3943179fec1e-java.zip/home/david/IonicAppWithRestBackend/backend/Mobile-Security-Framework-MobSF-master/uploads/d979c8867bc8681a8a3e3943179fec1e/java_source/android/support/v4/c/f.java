/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.res.ColorStateList
 */
package android.support.v4.c;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;

@TargetApi(value=23)
class f {
    public static ColorStateList a(Context context, int n2) {
        return context.getColorStateList(n2);
    }

    public static int b(Context context, int n2) {
        return context.getColor(n2);
    }
}

