/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.Intent
 */
package android.support.v4.c;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;

@TargetApi(value=11)
class g {
    static void a(Context context, Intent[] arrintent) {
        context.startActivities(arrintent);
    }
}

