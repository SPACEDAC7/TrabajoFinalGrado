/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 */
package android.support.v4.c;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.c.a;
import android.support.v4.c.l;
import android.support.v4.f.d;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Arrays;

public class i
extends a<Cursor> {
    final l<Cursor> f;
    Uri g;
    String[] h;
    String i;
    String[] j;
    String k;
    Cursor l;
    d m;

    public i(Context context, Uri uri, String[] arrstring, String string, String[] arrstring2, String string2) {
        super(context);
        this.f = new l.a();
        this.g = uri;
        this.h = arrstring;
        this.i = string;
        this.j = arrstring2;
        this.k = string2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(Cursor cursor) {
        if (this.q()) {
            if (cursor == null) return;
            {
                cursor.close();
                return;
            }
        } else {
            Cursor cursor2 = this.l;
            this.l = cursor;
            if (this.o()) {
                super.b(cursor);
            }
            if (cursor2 == null || cursor2 == cursor || cursor2.isClosed()) return;
            {
                cursor2.close();
                return;
            }
        }
    }

    @Override
    public /* synthetic */ void a(Object object) {
        this.b((Cursor)object);
    }

    @Override
    public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        super.a(string, fileDescriptor, printWriter, arrstring);
        printWriter.print(string);
        printWriter.print("mUri=");
        printWriter.println((Object)this.g);
        printWriter.print(string);
        printWriter.print("mProjection=");
        printWriter.println(Arrays.toString(this.h));
        printWriter.print(string);
        printWriter.print("mSelection=");
        printWriter.println(this.i);
        printWriter.print(string);
        printWriter.print("mSelectionArgs=");
        printWriter.println(Arrays.toString(this.j));
        printWriter.print(string);
        printWriter.print("mSortOrder=");
        printWriter.println(this.k);
        printWriter.print(string);
        printWriter.print("mCursor=");
        printWriter.println((Object)this.l);
        printWriter.print(string);
        printWriter.print("mContentChanged=");
        printWriter.println(this.u);
    }

    @Override
    public void b(Cursor cursor) {
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
    }

    @Override
    public /* synthetic */ void b(Object object) {
        this.a((Cursor)object);
    }

    @Override
    public /* synthetic */ Object d() {
        return this.h();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void f() {
        super.f();
        synchronized (this) {
            if (this.m != null) {
                this.m.c();
            }
            return;
        }
    }

    /*
     * Exception decompiling
     */
    public Cursor h() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 12[CATCHBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    protected void i() {
        if (this.l != null) {
            this.a(this.l);
        }
        if (this.y() || this.l == null) {
            this.t();
        }
    }

    @Override
    protected void j() {
        this.s();
    }

    @Override
    protected void k() {
        super.k();
        this.j();
        if (this.l != null && !this.l.isClosed()) {
            this.l.close();
        }
        this.l = null;
    }
}

