/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.ContentObserver
 *  android.os.Handler
 */
package android.support.v4.c;

import android.content.Context;
import android.database.ContentObserver;
import android.os.Handler;
import android.support.v4.j.d;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class l<D> {
    int n;
    c<D> o;
    b<D> p;
    Context q;
    boolean r = false;
    boolean s = false;
    boolean t = true;
    boolean u = false;
    boolean v = false;

    public l(Context context) {
        this.q = context.getApplicationContext();
    }

    public void A() {
        if (this.v) {
            this.B();
        }
    }

    public void B() {
        if (this.r) {
            this.t();
            return;
        }
        this.u = true;
    }

    protected void a() {
    }

    public void a(int n2, c<D> c2) {
        if (this.o != null) {
            throw new IllegalStateException("There is already a listener registered");
        }
        this.o = c2;
        this.n = n2;
    }

    public void a(b<D> b2) {
        if (this.p != null) {
            throw new IllegalStateException("There is already a listener registered");
        }
        this.p = b2;
    }

    public void a(c<D> c2) {
        if (this.o == null) {
            throw new IllegalStateException("No listener register");
        }
        if (this.o != c2) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        }
        this.o = null;
    }

    public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        printWriter.print(string);
        printWriter.print("mId=");
        printWriter.print(this.n);
        printWriter.print(" mListener=");
        printWriter.println(this.o);
        if (this.r || this.u || this.v) {
            printWriter.print(string);
            printWriter.print("mStarted=");
            printWriter.print(this.r);
            printWriter.print(" mContentChanged=");
            printWriter.print(this.u);
            printWriter.print(" mProcessingChange=");
            printWriter.println(this.v);
        }
        if (this.s || this.t) {
            printWriter.print(string);
            printWriter.print("mAbandoned=");
            printWriter.print(this.s);
            printWriter.print(" mReset=");
            printWriter.println(this.t);
        }
    }

    public void b(b<D> b2) {
        if (this.p == null) {
            throw new IllegalStateException("No listener register");
        }
        if (this.p != b2) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        }
        this.p = null;
    }

    public void b(D d2) {
        if (this.o != null) {
            this.o.a(this, d2);
        }
    }

    protected boolean b() {
        return false;
    }

    public String c(D d2) {
        StringBuilder stringBuilder = new StringBuilder(64);
        d.a(d2, stringBuilder);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    protected void i() {
    }

    protected void j() {
    }

    protected void k() {
    }

    public void l() {
        if (this.p != null) {
            this.p.a(this);
        }
    }

    public Context m() {
        return this.q;
    }

    public int n() {
        return this.n;
    }

    public boolean o() {
        return this.r;
    }

    public boolean p() {
        return this.s;
    }

    public boolean q() {
        return this.t;
    }

    public final void r() {
        this.r = true;
        this.t = false;
        this.s = false;
        this.i();
    }

    public boolean s() {
        return this.b();
    }

    public void t() {
        this.a();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(64);
        d.a(this, stringBuilder);
        stringBuilder.append(" id=");
        stringBuilder.append(this.n);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public void u() {
        this.r = false;
        this.j();
    }

    public void v() {
        this.s = true;
        this.w();
    }

    protected void w() {
    }

    public void x() {
        this.k();
        this.t = true;
        this.r = false;
        this.s = false;
        this.u = false;
        this.v = false;
    }

    public boolean y() {
        boolean bl2 = this.u;
        this.u = false;
        this.v |= bl2;
        return bl2;
    }

    public void z() {
        this.v = false;
    }

    public final class a
    extends ContentObserver {
        public a() {
            super(new Handler());
        }

        public boolean deliverSelfNotifications() {
            return true;
        }

        public void onChange(boolean bl2) {
            l.this.B();
        }
    }

    public static interface b<D> {
        public void a(l<D> var1);
    }

    public static interface c<D> {
        public void a(l<D> var1, D var2);
    }

}

