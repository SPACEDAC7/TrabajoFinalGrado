/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 */
package android.support.v4.c;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.ArrayList;
import java.util.HashMap;

public final class m {
    private static final Object f = new Object();
    private static m g;
    private final Context a;
    private final HashMap<BroadcastReceiver, ArrayList<IntentFilter>> b = new HashMap();
    private final HashMap<String, ArrayList<b>> c = new HashMap();
    private final ArrayList<a> d = new ArrayList();
    private final Handler e;

    private m(Context context) {
        this.a = context;
        this.e = new Handler(context.getMainLooper()){

            public void handleMessage(Message message) {
                switch (message.what) {
                    default: {
                        super.handleMessage(message);
                        return;
                    }
                    case 1: 
                }
                m.this.a();
            }
        };
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static m a(Context object) {
        Object object2 = f;
        synchronized (object2) {
            if (g != null) return g;
            g = new m(object.getApplicationContext());
            return g;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void a() {
        block3 : do {
            int n2;
            a[] arra;
            Object object = this.b;
            synchronized (object) {
                n2 = this.d.size();
                if (n2 <= 0) {
                    return;
                }
                arra = new a[n2];
                this.d.toArray(arra);
                this.d.clear();
            }
            n2 = 0;
            do {
                if (n2 >= arra.length) continue block3;
                object = arra[n2];
                for (int i2 = 0; i2 < object.b.size(); ++i2) {
                    object.b.get((int)i2).b.onReceive(this.a, object.a);
                }
                ++n2;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void a(BroadcastReceiver var1_1) {
        var5_2 = this.b;
        // MONITORENTER : var5_2
        var6_3 = this.b.remove((Object)var1_1);
        if (var6_3 == null) {
            // MONITOREXIT : var5_2
            return;
        }
        var3_5 = 0;
        block3 : do {
            if (var3_5 >= var6_3.size()) {
                // MONITOREXIT : var5_2
                return;
            }
            var7_7 = var6_3.get(var3_5);
            var4_6 = 0;
            do {
                if (var4_6 >= var7_7.countActions()) ** GOTO lbl20
                var8_8 = var7_7.getAction(var4_6);
                var9_9 = this.c.get(var8_8);
                if (var9_9 == null) ** GOTO lbl34
                ** GOTO lbl22
lbl20: // 1 sources:
                ++var3_5;
                continue block3;
lbl22: // 1 sources:
                var2_4 = 0;
                do {
                    if (var2_4 < var9_9.size()) {
                        if (var9_9.get((int)var2_4).b == var1_1) {
                            var9_9.remove(var2_4);
                            --var2_4;
                        }
                    } else {
                        if (var9_9.size() > 0) break;
                        this.c.remove(var8_8);
                        break;
                    }
                    ++var2_4;
                } while (true);
lbl34: // 3 sources:
                ++var4_6;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(BroadcastReceiver object, IntentFilter intentFilter) {
        HashMap<BroadcastReceiver, ArrayList<IntentFilter>> hashMap = this.b;
        synchronized (hashMap) {
            Object object2;
            b b2 = new b(intentFilter, (BroadcastReceiver)object);
            Object object3 = object2 = this.b.get(object);
            if (object2 == null) {
                object3 = new ArrayList(1);
                this.b.put((BroadcastReceiver)object, (ArrayList<IntentFilter>)object3);
            }
            object3.add((IntentFilter)intentFilter);
            int n2 = 0;
            while (n2 < intentFilter.countActions()) {
                object2 = intentFilter.getAction(n2);
                object = object3 = this.c.get(object2);
                if (object3 == null) {
                    object = new ArrayList<b>(1);
                    this.c.put((String)object2, (ArrayList<b>)object);
                }
                object.add(b2);
                ++n2;
            }
            return;
        }
    }

    /*
     * Exception decompiling
     */
    public boolean a(Intent var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private static class a {
        final Intent a;
        final ArrayList<b> b;

        a(Intent intent, ArrayList<b> arrayList) {
            this.a = intent;
            this.b = arrayList;
        }
    }

    private static class b {
        final IntentFilter a;
        final BroadcastReceiver b;
        boolean c;

        b(IntentFilter intentFilter, BroadcastReceiver broadcastReceiver) {
            this.a = intentFilter;
            this.b = broadcastReceiver;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder(128);
            stringBuilder.append("Receiver{");
            stringBuilder.append((Object)this.b);
            stringBuilder.append(" filter=");
            stringBuilder.append((Object)this.a);
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }

}

