/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  android.os.Process
 *  android.util.Log
 */
package android.support.v4.c;

import android.os.Binder;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.util.Log;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

abstract class n<Params, Progress, Result> {
    private static final ThreadFactory a = new ThreadFactory(){
        private final AtomicInteger a = new AtomicInteger(1);

        @Override
        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, "ModernAsyncTask #" + this.a.getAndIncrement());
        }
    };
    private static final BlockingQueue<Runnable> b = new LinkedBlockingQueue<Runnable>(10);
    public static final Executor c;
    private static b d;
    private static volatile Executor e;
    private final d<Params, Result> f;
    private final FutureTask<Result> g;
    private volatile c h = c.a;
    private final AtomicBoolean i = new AtomicBoolean();
    private final AtomicBoolean j = new AtomicBoolean();

    static {
        e = n.c = new ThreadPoolExecutor(5, 128, 1, TimeUnit.SECONDS, b, a);
    }

    public n() {
        this.f = new d<Params, Result>(){

            @Override
            public Result call() {
                Result Result;
                n.this.j.set(true);
                Result Result2 = null;
                Result Result3 = Result = null;
                Result Result4 = Result2;
                Process.setThreadPriority((int)10);
                Result3 = Result;
                Result4 = Result2;
                Result3 = Result = (Result)n.this.a((Params[])this.b);
                Result4 = Result;
                try {
                    Binder.flushPendingCommands();
                    n.this.d(Result);
                }
                catch (Throwable var3_3) {
                    Result4 = Result3;
                    try {
                        n.this.i.set(true);
                        Result4 = Result3;
                    }
                    catch (Throwable var2_5) {
                        n.this.d(Result4);
                        throw var2_5;
                    }
                    throw var3_3;
                }
                return Result;
            }
        };
        this.g = new FutureTask<Result>(this.f){

            @Override
            protected void done() {
                try {
                    Object v2 = this.get();
                    n.this.c(v2);
                    return;
                }
                catch (InterruptedException var1_2) {
                    Log.w((String)"AsyncTask", (Throwable)var1_2);
                    return;
                }
                catch (ExecutionException var1_3) {
                    throw new RuntimeException("An error occurred while executing doInBackground()", var1_3.getCause());
                }
                catch (CancellationException var1_4) {
                    n.this.c(null);
                    return;
                }
                catch (Throwable var1_5) {
                    throw new RuntimeException("An error occurred while executing doInBackground()", var1_5);
                }
            }
        };
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static Handler d() {
        synchronized (n.class) {
            if (d != null) return d;
            d = new b();
            return d;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final /* varargs */ n<Params, Progress, Result> a(Executor var1_1, Params ... var2_2) {
        if (this.h == c.a) ** GOTO lbl-1000
        switch (.a[this.h.ordinal()]) {
            default: lbl-1000: // 2 sources:
            {
                this.h = c.b;
                this.a();
                this.f.b = var2_2;
                var1_1.execute(this.g);
                return this;
            }
            case 1: {
                throw new IllegalStateException("Cannot execute task: the task is already running.");
            }
            case 2: 
        }
        throw new IllegalStateException("Cannot execute task: the task has already been executed (a task can be executed only once)");
    }

    protected /* varargs */ abstract Result a(Params ... var1);

    protected void a() {
    }

    protected void a(Result Result) {
    }

    public final boolean a(boolean bl2) {
        this.i.set(true);
        return this.g.cancel(bl2);
    }

    protected void b() {
    }

    protected void b(Result Result) {
        this.b();
    }

    protected /* varargs */ void b(Progress ... arrProgress) {
    }

    void c(Result Result) {
        if (!this.j.get()) {
            this.d(Result);
        }
    }

    public final boolean c() {
        return this.i.get();
    }

    Result d(Result Result) {
        n.d().obtainMessage(1, new a<Object>(this, Result)).sendToTarget();
        return Result;
    }

    /*
     * Enabled aggressive block sorting
     */
    void e(Result Result) {
        if (this.c()) {
            this.b(Result);
        } else {
            this.a(Result);
        }
        this.h = c.c;
    }

    private static class a<Data> {
        final n a;
        final Data[] b;

        /* varargs */ a(n n2, Data ... arrData) {
            this.a = n2;
            this.b = arrData;
        }
    }

    private static class b
    extends Handler {
        public b() {
            super(Looper.getMainLooper());
        }

        public void handleMessage(Message message) {
            a a2 = (a)message.obj;
            switch (message.what) {
                default: {
                    return;
                }
                case 1: {
                    a2.a.e(a2.b[0]);
                    return;
                }
                case 2: 
            }
            a2.a.b((Progress[])a2.b);
        }
    }

    public static enum c {
        a,
        b,
        c;
        

        private c() {
        }
    }

    private static abstract class d<Params, Result>
    implements Callable<Result> {
        Params[] b;

        d() {
        }
    }

}

