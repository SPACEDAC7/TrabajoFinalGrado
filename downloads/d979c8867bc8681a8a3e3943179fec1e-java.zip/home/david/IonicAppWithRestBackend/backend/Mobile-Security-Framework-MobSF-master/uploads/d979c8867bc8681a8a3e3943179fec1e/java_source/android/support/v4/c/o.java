/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageManager
 *  android.os.Process
 */
package android.support.v4.c;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Process;
import android.support.v4.b.e;

public final class o {
    public static int a(Context context, String string) {
        return o.a(context, string, Process.myPid(), Process.myUid(), context.getPackageName());
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static int a(Context context, String arrstring, int n2, int n3, String string) {
        if (context.checkPermission((String)arrstring, n2, n3) == -1) {
            return -1;
        }
        String string2 = e.a((String)arrstring);
        if (string2 == null) {
            return 0;
        }
        arrstring = string;
        if (string == null) {
            arrstring = context.getPackageManager().getPackagesForUid(n3);
            if (arrstring == null) return -1;
            if (arrstring.length <= 0) return -1;
            arrstring = arrstring[0];
        }
        if (e.a(context, string2, (String)arrstring) == 0) return 0;
        return -2;
    }
}

