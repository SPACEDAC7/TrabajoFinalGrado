/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.drawable.Drawable
 */
package android.support.v4.d.a;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;

@TargetApi(value=23)
class b {
    public static int a(Drawable drawable) {
        return drawable.getLayoutDirection();
    }

    public static boolean a(Drawable drawable, int n2) {
        return drawable.setLayoutDirection(n2);
    }
}

