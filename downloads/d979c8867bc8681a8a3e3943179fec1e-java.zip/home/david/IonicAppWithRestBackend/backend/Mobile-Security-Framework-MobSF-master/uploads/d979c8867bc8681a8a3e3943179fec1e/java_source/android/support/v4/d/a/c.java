/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.Drawable
 *  android.util.AttributeSet
 *  org.xmlpull.v1.XmlPullParser
 */
package android.support.v4.d.a;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.d.a.i;
import android.support.v4.d.a.m;
import android.util.AttributeSet;
import org.xmlpull.v1.XmlPullParser;

@TargetApi(value=9)
class c {
    public static Drawable a(Drawable drawable) {
        Drawable drawable2 = drawable;
        if (!(drawable instanceof m)) {
            drawable2 = new i(drawable);
        }
        return drawable2;
    }

    public static void a(Drawable drawable, int n2) {
        if (drawable instanceof m) {
            ((m)drawable).setTint(n2);
        }
    }

    public static void a(Drawable drawable, ColorStateList colorStateList) {
        if (drawable instanceof m) {
            ((m)drawable).setTintList(colorStateList);
        }
    }

    public static void a(Drawable drawable, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        drawable.inflate(resources, xmlPullParser, attributeSet);
    }

    public static void a(Drawable drawable, PorterDuff.Mode mode) {
        if (drawable instanceof m) {
            ((m)drawable).setTintMode(mode);
        }
    }
}

