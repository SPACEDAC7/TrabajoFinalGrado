/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.drawable.Drawable
 */
package android.support.v4.d.a;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;
import android.support.v4.d.a.j;
import android.support.v4.d.a.m;

@TargetApi(value=11)
class d {
    public static void a(Drawable drawable) {
        drawable.jumpToCurrentState();
    }

    public static Drawable b(Drawable drawable) {
        Drawable drawable2 = drawable;
        if (!(drawable instanceof m)) {
            drawable2 = new j(drawable);
        }
        return drawable2;
    }
}

