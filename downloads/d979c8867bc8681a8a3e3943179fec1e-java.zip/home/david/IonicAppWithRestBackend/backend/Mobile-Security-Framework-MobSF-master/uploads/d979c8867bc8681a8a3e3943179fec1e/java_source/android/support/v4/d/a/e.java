/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.drawable.Drawable
 *  android.util.Log
 */
package android.support.v4.d.a;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;
import android.util.Log;
import java.lang.reflect.Method;

@TargetApi(value=17)
class e {
    private static Method a;
    private static boolean b;
    private static Method c;
    private static boolean d;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static int a(Drawable drawable) {
        if (!d) {
            try {
                c = Drawable.class.getDeclaredMethod("getLayoutDirection", new Class[0]);
                c.setAccessible(true);
            }
            catch (NoSuchMethodException var2_3) {
                Log.i((String)"DrawableCompatJellybeanMr1", (String)"Failed to retrieve getLayoutDirection() method", (Throwable)var2_3);
            }
            d = true;
        }
        if (c == null) return -1;
        try {
            return (Integer)c.invoke((Object)drawable, new Object[0]);
        }
        catch (Exception var0_1) {
            Log.i((String)"DrawableCompatJellybeanMr1", (String)"Failed to invoke getLayoutDirection() via reflection", (Throwable)var0_1);
            c = null;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean a(Drawable drawable, int n2) {
        if (!b) {
            try {
                a = Drawable.class.getDeclaredMethod("setLayoutDirection", Integer.TYPE);
                a.setAccessible(true);
            }
            catch (NoSuchMethodException var2_3) {
                Log.i((String)"DrawableCompatJellybeanMr1", (String)"Failed to retrieve setLayoutDirection(int) method", (Throwable)var2_3);
            }
            b = true;
        }
        if (a != null) {
            try {
                a.invoke((Object)drawable, n2);
                return true;
            }
            catch (Exception var0_1) {
                Log.i((String)"DrawableCompatJellybeanMr1", (String)"Failed to invoke setLayoutDirection(int) via reflection", (Throwable)var0_1);
                a = null;
            }
        }
        return false;
    }
}

