/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.drawable.Drawable
 */
package android.support.v4.d.a;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;
import android.support.v4.d.a.k;
import android.support.v4.d.a.m;

@TargetApi(value=19)
class f {
    public static void a(Drawable drawable, boolean bl2) {
        drawable.setAutoMirrored(bl2);
    }

    public static boolean a(Drawable drawable) {
        return drawable.isAutoMirrored();
    }

    public static Drawable b(Drawable drawable) {
        Drawable drawable2 = drawable;
        if (!(drawable instanceof m)) {
            drawable2 = new k(drawable);
        }
        return drawable2;
    }

    public static int c(Drawable drawable) {
        return drawable.getAlpha();
    }
}

