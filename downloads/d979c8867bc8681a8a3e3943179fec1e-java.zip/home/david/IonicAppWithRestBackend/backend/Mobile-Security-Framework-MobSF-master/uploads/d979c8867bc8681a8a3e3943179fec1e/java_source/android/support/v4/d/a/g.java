/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.graphics.ColorFilter
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$ConstantState
 *  android.graphics.drawable.DrawableContainer
 *  android.graphics.drawable.DrawableContainer$DrawableContainerState
 *  android.graphics.drawable.InsetDrawable
 *  android.util.AttributeSet
 *  org.xmlpull.v1.XmlPullParser
 */
package android.support.v4.d.a;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.InsetDrawable;
import android.support.v4.d.a.h;
import android.support.v4.d.a.l;
import android.support.v4.d.a.m;
import android.util.AttributeSet;
import org.xmlpull.v1.XmlPullParser;

@TargetApi(value=21)
class g {
    public static Drawable a(Drawable drawable) {
        Drawable drawable2 = drawable;
        if (!(drawable instanceof m)) {
            drawable2 = new l(drawable);
        }
        return drawable2;
    }

    public static void a(Drawable drawable, float f2, float f3) {
        drawable.setHotspot(f2, f3);
    }

    public static void a(Drawable drawable, int n2) {
        drawable.setTint(n2);
    }

    public static void a(Drawable drawable, int n2, int n3, int n4, int n5) {
        drawable.setHotspotBounds(n2, n3, n4, n5);
    }

    public static void a(Drawable drawable, ColorStateList colorStateList) {
        drawable.setTintList(colorStateList);
    }

    public static void a(Drawable drawable, Resources.Theme theme) {
        drawable.applyTheme(theme);
    }

    public static void a(Drawable drawable, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        drawable.inflate(resources, xmlPullParser, attributeSet, theme);
    }

    public static void a(Drawable drawable, PorterDuff.Mode mode) {
        drawable.setTintMode(mode);
    }

    public static boolean b(Drawable drawable) {
        return drawable.canApplyTheme();
    }

    public static ColorFilter c(Drawable drawable) {
        return drawable.getColorFilter();
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void d(Drawable drawable) {
        drawable.clearColorFilter();
        if (drawable instanceof InsetDrawable) {
            g.d(((InsetDrawable)drawable).getDrawable());
            return;
        } else {
            if (drawable instanceof h) {
                g.d(((h)drawable).a());
                return;
            }
            if (!(drawable instanceof DrawableContainer) || (drawable = (DrawableContainer.DrawableContainerState)((DrawableContainer)drawable).getConstantState()) == null) return;
            {
                int n2 = drawable.getChildCount();
                for (int i2 = 0; i2 < n2; ++i2) {
                    Drawable drawable2 = drawable.getChild(i2);
                    if (drawable2 == null) continue;
                    g.d(drawable2);
                }
            }
        }
    }
}

