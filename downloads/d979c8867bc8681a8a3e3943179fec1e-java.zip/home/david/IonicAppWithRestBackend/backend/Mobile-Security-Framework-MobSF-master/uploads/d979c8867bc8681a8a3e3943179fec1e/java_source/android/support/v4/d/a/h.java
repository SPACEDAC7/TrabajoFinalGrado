/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 */
package android.support.v4.d.a;

import android.graphics.drawable.Drawable;

public interface h {
    public Drawable a();

    public void a(Drawable var1);
}

