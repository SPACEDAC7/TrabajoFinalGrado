/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 */
package android.support.v4.d.a;

import android.annotation.TargetApi;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v4.d.a.i;

@TargetApi(value=11)
class j
extends i {
    j(Drawable drawable) {
        super(drawable);
    }

    j(i.a a2, Resources resources) {
        super(a2, resources);
    }

    @Override
    i.a b() {
        return new a(this.b, null);
    }

    public void jumpToCurrentState() {
        this.c.jumpToCurrentState();
    }

    private static class a
    extends i.a {
        a(i.a a2, Resources resources) {
            super(a2, resources);
        }

        @Override
        public Drawable newDrawable(Resources resources) {
            return new j(this, resources);
        }
    }

}

