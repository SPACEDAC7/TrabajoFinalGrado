/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 */
package android.support.v4.d.a;

import android.annotation.TargetApi;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v4.d.a.i;
import android.support.v4.d.a.j;

@TargetApi(value=19)
class k
extends j {
    k(Drawable drawable) {
        super(drawable);
    }

    k(i.a a2, Resources resources) {
        super(a2, resources);
    }

    @Override
    i.a b() {
        return new a(this.b, null);
    }

    public boolean isAutoMirrored() {
        return this.c.isAutoMirrored();
    }

    public void setAutoMirrored(boolean bl2) {
        this.c.setAutoMirrored(bl2);
    }

    private static class a
    extends i.a {
        a(i.a a2, Resources resources) {
            super(a2, resources);
        }

        @Override
        public Drawable newDrawable(Resources resources) {
            return new k(this, resources);
        }
    }

}

