/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.Menu
 */
package android.support.v4.e.a;

import android.view.Menu;

public interface a
extends Menu {
}

