/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.MenuItem
 *  android.view.View
 */
package android.support.v4.e.a;

import android.support.v4.k.e;
import android.support.v4.k.q;
import android.view.MenuItem;
import android.view.View;

public interface b
extends MenuItem {
    public b a(e var1);

    public b a(q.e var1);

    public e a();

    public boolean collapseActionView();

    public boolean expandActionView();

    public View getActionView();

    public boolean isActionViewExpanded();

    public MenuItem setActionView(int var1);

    public MenuItem setActionView(View var1);

    public void setShowAsAction(int var1);

    public MenuItem setShowAsActionFlags(int var1);
}

