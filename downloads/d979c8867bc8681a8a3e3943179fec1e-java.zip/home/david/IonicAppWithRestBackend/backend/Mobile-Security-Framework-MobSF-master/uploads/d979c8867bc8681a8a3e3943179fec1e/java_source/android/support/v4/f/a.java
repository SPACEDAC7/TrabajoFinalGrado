/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.AsyncTask
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package android.support.v4.f;

import android.os.AsyncTask;
import android.os.Build;
import android.support.v4.f.b;

public final class a {
    public static /* varargs */ <Params, Progress, Result> AsyncTask<Params, Progress, Result> a(AsyncTask<Params, Progress, Result> asyncTask, Params ... arrParams) {
        if (asyncTask == null) {
            throw new IllegalArgumentException("task can not be null");
        }
        if (Build.VERSION.SDK_INT >= 11) {
            b.a(asyncTask, arrParams);
            return asyncTask;
        }
        asyncTask.execute((Object[])arrParams);
        return asyncTask;
    }
}

