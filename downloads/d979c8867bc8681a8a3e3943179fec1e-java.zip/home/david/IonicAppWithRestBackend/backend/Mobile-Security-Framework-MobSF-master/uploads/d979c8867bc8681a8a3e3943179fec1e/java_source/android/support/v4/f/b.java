/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.os.AsyncTask
 */
package android.support.v4.f;

import android.annotation.TargetApi;
import android.os.AsyncTask;
import java.util.concurrent.Executor;

@TargetApi(value=11)
class b {
    static /* varargs */ <Params, Progress, Result> void a(AsyncTask<Params, Progress, Result> asyncTask, Params ... arrParams) {
        asyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])arrParams);
    }
}

