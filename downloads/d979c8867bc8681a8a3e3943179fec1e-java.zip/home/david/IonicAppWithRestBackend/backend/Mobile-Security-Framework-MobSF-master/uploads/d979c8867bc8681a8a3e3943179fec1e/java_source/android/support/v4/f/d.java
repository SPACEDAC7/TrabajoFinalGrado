/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package android.support.v4.f;

import android.os.Build;
import android.support.v4.f.e;
import android.support.v4.f.f;

public final class d {
    private boolean a;
    private a b;
    private Object c;
    private boolean d;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean a() {
        synchronized (this) {
            return this.a;
        }
    }

    public void b() {
        if (this.a()) {
            throw new f();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void c() {
        // MONITORENTER : this
        if (this.a) {
            // MONITOREXIT : this
            return;
        }
        this.a = true;
        this.d = true;
        var1_1 = this.b;
        var2_3 = this.c;
        // MONITOREXIT : this
        if (var1_1 == null) ** GOTO lbl13
        try {
            var1_1.a();
lbl13: // 2 sources:
            if (var2_3 == null) return;
            e.a(var2_3);
            return;
        }
        finally {
            // MONITORENTER : this
            this.d = false;
            this.notifyAll();
            // MONITOREXIT : this
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Object d() {
        if (Build.VERSION.SDK_INT < 16) {
            return null;
        }
        synchronized (this) {
            if (this.c != null) return this.c;
            this.c = e.a();
            if (!this.a) return this.c;
            e.a(this.c);
            return this.c;
        }
    }

    public static interface a {
        public void a();
    }

}

