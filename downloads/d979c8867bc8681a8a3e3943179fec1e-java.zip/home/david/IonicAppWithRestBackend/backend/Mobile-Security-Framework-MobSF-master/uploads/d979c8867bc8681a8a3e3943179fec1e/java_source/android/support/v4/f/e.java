/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.os.CancellationSignal
 */
package android.support.v4.f;

import android.annotation.TargetApi;
import android.os.CancellationSignal;

@TargetApi(value=16)
class e {
    public static Object a() {
        return new CancellationSignal();
    }

    public static void a(Object object) {
        ((CancellationSignal)object).cancel();
    }
}

