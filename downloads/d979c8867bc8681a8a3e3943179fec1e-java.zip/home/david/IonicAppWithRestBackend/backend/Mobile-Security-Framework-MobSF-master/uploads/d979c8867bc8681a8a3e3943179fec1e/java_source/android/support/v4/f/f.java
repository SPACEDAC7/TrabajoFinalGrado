/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.f;

public class f
extends RuntimeException {
    public f() {
        this(null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public f(String string) {
        if (string == null) {
            string = "The operation has been canceled.";
        }
        super(string);
    }
}

