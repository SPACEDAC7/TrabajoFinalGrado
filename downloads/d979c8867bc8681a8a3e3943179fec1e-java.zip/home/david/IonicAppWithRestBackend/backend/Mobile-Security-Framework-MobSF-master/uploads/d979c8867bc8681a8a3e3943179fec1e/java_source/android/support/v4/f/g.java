/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package android.support.v4.f;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.f.h;
import android.support.v4.f.j;

public final class g {
    public static <T> Parcelable.Creator<T> a(h<T> h2) {
        if (Build.VERSION.SDK_INT >= 13) {
            return j.a(h2);
        }
        return new a<T>(h2);
    }

    static class a<T>
    implements Parcelable.Creator<T> {
        final h<T> a;

        public a(h<T> h2) {
            this.a = h2;
        }

        public T createFromParcel(Parcel parcel) {
            return this.a.b(parcel, null);
        }

        public T[] newArray(int n2) {
            return this.a.b(n2);
        }
    }

}

