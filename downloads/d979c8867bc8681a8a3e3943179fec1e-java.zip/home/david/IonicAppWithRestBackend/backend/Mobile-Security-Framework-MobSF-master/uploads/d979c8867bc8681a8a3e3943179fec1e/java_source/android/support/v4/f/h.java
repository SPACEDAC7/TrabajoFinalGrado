/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package android.support.v4.f;

import android.os.Parcel;

public interface h<T> {
    public T b(Parcel var1, ClassLoader var2);

    public T[] b(int var1);
}

