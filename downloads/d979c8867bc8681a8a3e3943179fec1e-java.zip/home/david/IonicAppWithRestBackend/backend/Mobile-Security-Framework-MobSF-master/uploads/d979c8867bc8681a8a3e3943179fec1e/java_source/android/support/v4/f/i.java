/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$ClassLoaderCreator
 */
package android.support.v4.f;

import android.annotation.TargetApi;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.f.h;

@TargetApi(value=13)
class i<T>
implements Parcelable.ClassLoaderCreator<T> {
    private final h<T> a;

    public i(h<T> h2) {
        this.a = h2;
    }

    public T createFromParcel(Parcel parcel) {
        return this.a.b(parcel, null);
    }

    public T createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return this.a.b(parcel, classLoader);
    }

    public T[] newArray(int n2) {
        return this.a.b(n2);
    }
}

