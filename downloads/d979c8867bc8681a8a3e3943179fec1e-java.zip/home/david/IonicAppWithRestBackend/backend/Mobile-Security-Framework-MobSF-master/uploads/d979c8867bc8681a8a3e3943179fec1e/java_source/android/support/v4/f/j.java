/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package android.support.v4.f;

import android.annotation.TargetApi;
import android.os.Parcelable;
import android.support.v4.f.h;
import android.support.v4.f.i;

@TargetApi(value=13)
class j {
    static <T> Parcelable.Creator<T> a(h<T> h2) {
        return new i<T>(h2);
    }
}

