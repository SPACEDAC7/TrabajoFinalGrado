/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package android.support.v4.f;

import android.os.Build;
import android.support.v4.f.l;

public final class k {
    public static void a() {
        if (Build.VERSION.SDK_INT >= 18) {
            l.a();
        }
    }

    public static void a(String string) {
        if (Build.VERSION.SDK_INT >= 18) {
            l.a(string);
        }
    }
}

