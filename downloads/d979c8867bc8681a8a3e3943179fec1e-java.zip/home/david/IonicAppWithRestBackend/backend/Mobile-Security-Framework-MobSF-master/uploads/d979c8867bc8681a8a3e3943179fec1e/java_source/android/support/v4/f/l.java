/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.os.Trace
 */
package android.support.v4.f;

import android.annotation.TargetApi;
import android.os.Trace;

@TargetApi(value=18)
class l {
    public static void a() {
        Trace.endSection();
    }

    public static void a(String string) {
        Trace.beginSection((String)string);
    }
}

