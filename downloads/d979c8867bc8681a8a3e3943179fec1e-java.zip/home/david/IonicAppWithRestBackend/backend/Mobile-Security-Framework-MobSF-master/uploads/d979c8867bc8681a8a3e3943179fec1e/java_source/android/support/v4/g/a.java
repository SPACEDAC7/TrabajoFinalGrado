/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.g;

public final class a {

    public static final class a {
        public static final int preference_list_fragment = 2130903133;
    }

}

