/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.j;

import android.support.v4.j.c;
import android.support.v4.j.h;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class b<E>
implements Collection<E>,
Set<E> {
    static Object[] a;
    static int b;
    static Object[] c;
    static int d;
    private static final int[] j;
    private static final Object[] k;
    final boolean e;
    int[] f;
    Object[] g;
    int h;
    h<E, E> i;

    static {
        j = new int[0];
        k = new Object[0];
    }

    public b() {
        this(0, false);
    }

    /*
     * Enabled aggressive block sorting
     */
    public b(int n2, boolean bl2) {
        this.e = bl2;
        if (n2 == 0) {
            this.f = j;
            this.g = k;
        } else {
            this.d(n2);
        }
        this.h = 0;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int a() {
        int n2;
        int n3;
        int n4 = this.h;
        if (n4 == 0) {
            return -1;
        }
        int n5 = n2 = c.a(this.f, n4, 0);
        if (n2 < 0) return n5;
        n5 = n2;
        if (this.g[n2] == null) return n5;
        for (n3 = n2 + 1; n3 < n4 && this.f[n3] == 0; ++n3) {
            if (this.g[n3] != null) continue;
            return n3;
        }
        --n2;
        while (n2 >= 0) {
            if (this.f[n2] != 0) return ~ n3;
            n5 = n2;
            if (this.g[n2] == null) return n5;
            --n2;
        }
        return ~ n3;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int a(Object object, int n2) {
        int n3;
        int n4;
        int n5 = this.h;
        if (n5 == 0) {
            return -1;
        }
        int n6 = n4 = c.a(this.f, n5, n2);
        if (n4 < 0) return n6;
        n6 = n4;
        if (object.equals(this.g[n4])) return n6;
        for (n3 = n4 + 1; n3 < n5 && this.f[n3] == n2; ++n3) {
            if (!object.equals(this.g[n3])) continue;
            return n3;
        }
        --n4;
        while (n4 >= 0) {
            if (this.f[n4] != n2) return ~ n3;
            n6 = n4;
            if (object.equals(this.g[n4])) return n6;
            --n4;
        }
        return ~ n3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private static void a(int[] var0, Object[] var1_1, int var2_2) {
        if (var0.length != 8) ** GOTO lbl8
        // MONITORENTER : android.support.v4.j.b.class
        if (b.d >= 10) ** GOTO lbl21
        var1_1[0] = b.c;
        var1_1[1] = var0;
        --var2_2;
        ** GOTO lbl15
lbl8: // 1 sources:
        if (var0.length != 4) return;
        // MONITORENTER : android.support.v4.j.b.class
        if (b.b >= 10) ** GOTO lbl29
        var1_1[0] = b.a;
        var1_1[1] = var0;
        --var2_2;
        ** GOTO lbl23
lbl15: // 2 sources:
        while (var2_2 >= 2) {
            var1_1[var2_2] = null;
            --var2_2;
        }
        b.c = var1_1;
        ++b.d;
lbl21: // 2 sources:
        // MONITOREXIT : android.support.v4.j.b.class
        return;
lbl23: // 2 sources:
        while (var2_2 >= 2) {
            var1_1[var2_2] = null;
            --var2_2;
        }
        b.a = var1_1;
        ++b.b;
lbl29: // 2 sources:
        // MONITOREXIT : android.support.v4.j.b.class
    }

    private h<E, E> b() {
        if (this.i == null) {
            this.i = new h<E, E>(){

                @Override
                protected int a() {
                    return b.this.h;
                }

                @Override
                protected int a(Object object) {
                    return b.this.a(object);
                }

                @Override
                protected Object a(int n2, int n3) {
                    return b.this.g[n2];
                }

                @Override
                protected E a(int n2, E e2) {
                    throw new UnsupportedOperationException("not a map");
                }

                @Override
                protected void a(int n2) {
                    b.this.c(n2);
                }

                @Override
                protected void a(E e2, E e3) {
                    b.this.add(e2);
                }

                @Override
                protected int b(Object object) {
                    return b.this.a(object);
                }

                @Override
                protected Map<E, E> b() {
                    throw new UnsupportedOperationException("not a map");
                }

                @Override
                protected void c() {
                    b.this.clear();
                }
            };
        }
        return this.i;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void d(int n2) {
        if (n2 == 8) {
            synchronized (b.class) {
                if (c != null) {
                    Object[] arrobject;
                    this.g = arrobject = c;
                    c = (Object[])arrobject[0];
                    this.f = (int[])arrobject[1];
                    arrobject[1] = null;
                    arrobject[0] = null;
                    --d;
                    return;
                }
            }
        } else if (n2 == 4) {
            synchronized (b.class) {
                if (a != null) {
                    Object[] arrobject;
                    this.g = arrobject = a;
                    a = (Object[])arrobject[0];
                    this.f = (int[])arrobject[1];
                    arrobject[1] = null;
                    arrobject[0] = null;
                    --b;
                    return;
                }
            }
        }
        this.f = new int[n2];
        this.g = new Object[n2];
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public int a(Object object) {
        int n2;
        if (object == null) {
            return this.a();
        }
        if (this.e) {
            n2 = System.identityHashCode(object);
            do {
                return this.a(object, n2);
                break;
            } while (true);
        }
        n2 = object.hashCode();
        return this.a(object, n2);
    }

    public void a(int n2) {
        if (this.f.length < n2) {
            int[] arrn = this.f;
            Object[] arrobject = this.g;
            this.d(n2);
            if (this.h > 0) {
                System.arraycopy(arrn, 0, this.f, 0, this.h);
                System.arraycopy(arrobject, 0, this.g, 0, this.h);
            }
            b.a(arrn, arrobject, this.h);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean add(E e2) {
        int n2;
        int n3;
        int n4;
        if (e2 == null) {
            n4 = this.a();
            n3 = 0;
        } else {
            n2 = this.e ? System.identityHashCode(e2) : e2.hashCode();
            n4 = this.a(e2, n2);
            n3 = n2;
        }
        if (n4 >= 0) {
            return false;
        }
        n4 ^= -1;
        if (this.h >= this.f.length) {
            n2 = this.h >= 8 ? this.h + (this.h >> 1) : (this.h >= 4 ? 8 : 4);
            int[] arrn = this.f;
            Object[] arrobject = this.g;
            this.d(n2);
            if (this.f.length > 0) {
                System.arraycopy(arrn, 0, this.f, 0, arrn.length);
                System.arraycopy(arrobject, 0, this.g, 0, arrobject.length);
            }
            b.a(arrn, arrobject, this.h);
        }
        if (n4 < this.h) {
            System.arraycopy(this.f, n4, this.f, n4 + 1, this.h - n4);
            System.arraycopy(this.g, n4, this.g, n4 + 1, this.h - n4);
        }
        this.f[n4] = n3;
        this.g[n4] = e2;
        ++this.h;
        return true;
    }

    @Override
    public boolean addAll(Collection<? extends E> object) {
        this.a(this.h + object.size());
        boolean bl2 = false;
        object = object.iterator();
        while (object.hasNext()) {
            bl2 |= this.add(object.next());
        }
        return bl2;
    }

    public E b(int n2) {
        return (E)this.g[n2];
    }

    /*
     * Enabled aggressive block sorting
     */
    public E c(int n2) {
        int n3 = 8;
        Object object = this.g[n2];
        if (this.h <= 1) {
            b.a(this.f, this.g, this.h);
            this.f = j;
            this.g = k;
            this.h = 0;
            return (E)object;
        }
        if (this.f.length > 8 && this.h < this.f.length / 3) {
            if (this.h > 8) {
                n3 = this.h + (this.h >> 1);
            }
            int[] arrn = this.f;
            Object[] arrobject = this.g;
            this.d(n3);
            --this.h;
            if (n2 > 0) {
                System.arraycopy(arrn, 0, this.f, 0, n2);
                System.arraycopy(arrobject, 0, this.g, 0, n2);
            }
            if (n2 >= this.h) return (E)object;
            {
                System.arraycopy(arrn, n2 + 1, this.f, n2, this.h - n2);
                System.arraycopy(arrobject, n2 + 1, this.g, n2, this.h - n2);
                return (E)object;
            }
        }
        --this.h;
        if (n2 < this.h) {
            System.arraycopy(this.f, n2 + 1, this.f, n2, this.h - n2);
            System.arraycopy(this.g, n2 + 1, this.g, n2, this.h - n2);
        }
        this.g[this.h] = null;
        return (E)object;
    }

    @Override
    public void clear() {
        if (this.h != 0) {
            b.a(this.f, this.g, this.h);
            this.f = j;
            this.g = k;
            this.h = 0;
        }
    }

    @Override
    public boolean contains(Object object) {
        if (this.a(object) >= 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean containsAll(Collection<?> object) {
        object = object.iterator();
        while (object.hasNext()) {
            if (this.contains(object.next())) continue;
            return false;
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        {
            if (!(object instanceof Set)) {
                return false;
            }
            object = (Set)object;
            if (this.size() != object.size()) {
                return false;
            }
            try {
                for (int i2 = 0; i2 < this.h; ++i2) {
                    boolean bl2 = object.contains(this.b(i2));
                    if (bl2) continue;
                    return false;
                }
                return true;
            }
            catch (NullPointerException var1_2) {
                return false;
            }
            catch (ClassCastException var1_3) {
                return false;
            }
        }
    }

    @Override
    public int hashCode() {
        int[] arrn = this.f;
        int n2 = this.h;
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            n3 += arrn[i2];
        }
        return n3;
    }

    @Override
    public boolean isEmpty() {
        if (this.h <= 0) {
            return true;
        }
        return false;
    }

    @Override
    public Iterator<E> iterator() {
        return this.b().e().iterator();
    }

    @Override
    public boolean remove(Object object) {
        int n2 = this.a(object);
        if (n2 >= 0) {
            this.c(n2);
            return true;
        }
        return false;
    }

    @Override
    public boolean removeAll(Collection<?> object) {
        boolean bl2 = false;
        object = object.iterator();
        while (object.hasNext()) {
            bl2 |= this.remove(object.next());
        }
        return bl2;
    }

    @Override
    public boolean retainAll(Collection<?> collection) {
        int n2 = this.h;
        boolean bl2 = false;
        --n2;
        while (n2 >= 0) {
            if (!collection.contains(this.g[n2])) {
                this.c(n2);
                bl2 = true;
            }
            --n2;
        }
        return bl2;
    }

    @Override
    public int size() {
        return this.h;
    }

    @Override
    public Object[] toArray() {
        Object[] arrobject = new Object[this.h];
        System.arraycopy(this.g, 0, arrobject, 0, this.h);
        return arrobject;
    }

    @Override
    public <T> T[] toArray(T[] arrT) {
        if (arrT.length < this.h) {
            arrT = (Object[])Array.newInstance(arrT.getClass().getComponentType(), this.h);
        }
        System.arraycopy(this.g, 0, arrT, 0, this.h);
        if (arrT.length > this.h) {
            arrT[this.h] = null;
        }
        return arrT;
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        if (this.isEmpty()) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.h * 14);
        stringBuilder.append('{');
        int n2 = 0;
        do {
            E e2;
            if (n2 >= this.h) {
                stringBuilder.append('}');
                return stringBuilder.toString();
            }
            if (n2 > 0) {
                stringBuilder.append(", ");
            }
            if ((e2 = this.b(n2)) != this) {
                stringBuilder.append(e2);
            } else {
                stringBuilder.append("(this Set)");
            }
            ++n2;
        } while (true);
    }

}

