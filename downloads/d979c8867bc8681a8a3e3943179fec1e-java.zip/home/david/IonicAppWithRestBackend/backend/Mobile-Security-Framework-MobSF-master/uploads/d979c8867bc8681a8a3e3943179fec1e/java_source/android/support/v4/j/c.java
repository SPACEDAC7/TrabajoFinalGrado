/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.j;

class c {
    static final int[] a = new int[0];
    static final long[] b = new long[0];
    static final Object[] c = new Object[0];

    public static int a(int n2) {
        return c.c(n2 * 4) / 4;
    }

    static int a(int[] arrn, int n2, int n3) {
        int n4 = 0;
        int n5 = n2 - 1;
        n2 = n4;
        n4 = n5;
        while (n2 <= n4) {
            n5 = n2 + n4 >>> 1;
            int n6 = arrn[n5];
            if (n6 < n3) {
                n2 = n5 + 1;
                continue;
            }
            if (n6 > n3) {
                n4 = n5 - 1;
                continue;
            }
            return n5;
        }
        return ~ n2;
    }

    static int a(long[] arrl, int n2, long l2) {
        int n3 = 0;
        int n4 = n2 - 1;
        n2 = n3;
        n3 = n4;
        while (n2 <= n3) {
            n4 = n2 + n3 >>> 1;
            long l3 = arrl[n4];
            if (l3 < l2) {
                n2 = n4 + 1;
                continue;
            }
            if (l3 > l2) {
                n3 = n4 - 1;
                continue;
            }
            return n4;
        }
        return ~ n2;
    }

    public static boolean a(Object object, Object object2) {
        if (object == object2 || object != null && object.equals(object2)) {
            return true;
        }
        return false;
    }

    public static int b(int n2) {
        return c.c(n2 * 8) / 8;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int c(int n2) {
        int n3 = 4;
        do {
            int n4 = n2;
            if (n3 >= 32) return n4;
            if (n2 <= (1 << n3) - 12) {
                return (1 << n3) - 12;
            }
            ++n3;
        } while (true);
    }
}

