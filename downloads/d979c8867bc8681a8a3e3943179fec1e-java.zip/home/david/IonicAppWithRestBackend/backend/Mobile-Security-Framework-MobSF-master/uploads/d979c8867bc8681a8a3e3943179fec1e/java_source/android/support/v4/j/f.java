/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.j;

import android.support.v4.j.c;

public class f<E>
implements Cloneable {
    private static final Object a = new Object();
    private boolean b = false;
    private long[] c;
    private Object[] d;
    private int e;

    public f() {
        this(10);
    }

    /*
     * Enabled aggressive block sorting
     */
    public f(int n2) {
        if (n2 == 0) {
            this.c = c.b;
            this.d = c.c;
        } else {
            n2 = c.b(n2);
            this.c = new long[n2];
            this.d = new Object[n2];
        }
        this.e = 0;
    }

    private void d() {
        int n2 = this.e;
        long[] arrl = this.c;
        Object[] arrobject = this.d;
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            Object object = arrobject[i2];
            int n4 = n3;
            if (object != a) {
                if (i2 != n3) {
                    arrl[n3] = arrl[i2];
                    arrobject[n3] = object;
                    arrobject[i2] = null;
                }
                n4 = n3 + 1;
            }
            n3 = n4;
        }
        this.b = false;
        this.e = n3;
    }

    public f<E> a() {
        f f2;
        try {
            f2 = (f)super.clone();
        }
        catch (CloneNotSupportedException var1_2) {
            return null;
        }
        try {
            f2.c = (long[])this.c.clone();
            f2.d = (Object[])this.d.clone();
            return f2;
        }
        catch (CloneNotSupportedException var2_3) {
            return f2;
        }
    }

    public E a(long l2) {
        return this.a(l2, null);
    }

    public E a(long l2, E e2) {
        int n2 = c.a(this.c, this.e, l2);
        if (n2 < 0 || this.d[n2] == a) {
            return e2;
        }
        return (E)this.d[n2];
    }

    public void a(int n2) {
        if (this.d[n2] != a) {
            this.d[n2] = a;
            this.b = true;
        }
    }

    public int b() {
        if (this.b) {
            this.d();
        }
        return this.e;
    }

    public long b(int n2) {
        if (this.b) {
            this.d();
        }
        return this.c[n2];
    }

    public void b(long l2) {
        int n2 = c.a(this.c, this.e, l2);
        if (n2 >= 0 && this.d[n2] != a) {
            this.d[n2] = a;
            this.b = true;
        }
    }

    public void b(long l2, E e2) {
        int n2 = c.a(this.c, this.e, l2);
        if (n2 >= 0) {
            this.d[n2] = e2;
            return;
        }
        int n3 = ~ n2;
        if (n3 < this.e && this.d[n3] == a) {
            this.c[n3] = l2;
            this.d[n3] = e2;
            return;
        }
        n2 = n3;
        if (this.b) {
            n2 = n3;
            if (this.e >= this.c.length) {
                this.d();
                n2 = ~ c.a(this.c, this.e, l2);
            }
        }
        if (this.e >= this.c.length) {
            n3 = c.b(this.e + 1);
            long[] arrl = new long[n3];
            Object[] arrobject = new Object[n3];
            System.arraycopy(this.c, 0, arrl, 0, this.c.length);
            System.arraycopy(this.d, 0, arrobject, 0, this.d.length);
            this.c = arrl;
            this.d = arrobject;
        }
        if (this.e - n2 != 0) {
            System.arraycopy(this.c, n2, this.c, n2 + 1, this.e - n2);
            System.arraycopy(this.d, n2, this.d, n2 + 1, this.e - n2);
        }
        this.c[n2] = l2;
        this.d[n2] = e2;
        ++this.e;
    }

    public E c(int n2) {
        if (this.b) {
            this.d();
        }
        return (E)this.d[n2];
    }

    public void c() {
        int n2 = this.e;
        Object[] arrobject = this.d;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrobject[i2] = null;
        }
        this.e = 0;
        this.b = false;
    }

    public /* synthetic */ Object clone() {
        return this.a();
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        if (this.b() <= 0) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.e * 28);
        stringBuilder.append('{');
        int n2 = 0;
        do {
            if (n2 >= this.e) {
                stringBuilder.append('}');
                return stringBuilder.toString();
            }
            if (n2 > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(this.b(n2));
            stringBuilder.append('=');
            E e2 = this.c(n2);
            if (e2 != this) {
                stringBuilder.append(e2);
            } else {
                stringBuilder.append("(this Map)");
            }
            ++n2;
        } while (true);
    }
}

