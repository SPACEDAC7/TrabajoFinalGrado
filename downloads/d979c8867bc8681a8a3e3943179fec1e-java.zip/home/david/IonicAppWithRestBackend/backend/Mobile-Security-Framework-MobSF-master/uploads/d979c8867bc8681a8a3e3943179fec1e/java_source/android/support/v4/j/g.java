/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.j;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class g<K, V> {
    private final LinkedHashMap<K, V> a;
    private int b;
    private int c;
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;

    public g(int n2) {
        if (n2 <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        this.c = n2;
        this.a = new LinkedHashMap(0, 0.75f, true);
    }

    private int c(K k2, V v2) {
        int n2 = this.b(k2, v2);
        if (n2 < 0) {
            throw new IllegalStateException("Negative size: " + k2 + "=" + v2);
        }
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final V a(K k2) {
        if (k2 == null) {
            throw new NullPointerException("key == null");
        }
        // MONITORENTER : this
        V v2 = this.a.get(k2);
        if (v2 != null) {
            ++this.g;
            // MONITOREXIT : this
            return v2;
        }
        ++this.h;
        // MONITOREXIT : this
        v2 = this.b(k2);
        if (v2 == null) {
            return null;
        }
        // MONITORENTER : this
        ++this.e;
        V v3 = this.a.put(k2, v2);
        if (v3 != null) {
            this.a.put(k2, v3);
        } else {
            this.b += this.c(k2, v2);
        }
        // MONITOREXIT : this
        if (v3 != null) {
            this.a(false, k2, v2, v3);
            return v3;
        }
        this.a(this.c);
        return v2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final V a(K k2, V v2) {
        if (k2 == null) throw new NullPointerException("key == null || value == null");
        if (v2 == null) {
            throw new NullPointerException("key == null || value == null");
        }
        // MONITORENTER : this
        ++this.d;
        this.b += this.c(k2, v2);
        V v3 = this.a.put(k2, v2);
        if (v3 != null) {
            this.b -= this.c(k2, v3);
        }
        // MONITOREXIT : this
        if (v3 != null) {
            this.a(false, k2, v3, v2);
        }
        this.a(this.c);
        return v3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(int n2) {
        do {
            K k2;
            Map.Entry entry2;
            synchronized (this) {
                if (this.b < 0 || this.a.isEmpty() && this.b != 0) {
                    throw new IllegalStateException(this.getClass().getName() + ".sizeOf() is reporting inconsistent results!");
                }
                if (this.b <= n2 || this.a.isEmpty()) {
                    return;
                }
                Map.Entry entry2 = this.a.entrySet().iterator().next();
                k2 = entry2.getKey();
                entry2 = entry2.getValue();
                this.a.remove(k2);
                this.b -= this.c(k2, entry2);
                ++this.f;
            }
            this.a(true, k2, entry2, null);
        } while (true);
    }

    protected void a(boolean bl2, K k2, V v2, V v3) {
    }

    protected int b(K k2, V v2) {
        return 1;
    }

    protected V b(K k2) {
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final String toString() {
        int n2 = 0;
        synchronized (this) {
            int n3 = this.g + this.h;
            if (n3 == 0) return String.format("LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", this.c, this.g, this.h, n2);
            n2 = this.g * 100 / n3;
            return String.format("LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", this.c, this.g, this.h, n2);
        }
    }
}

