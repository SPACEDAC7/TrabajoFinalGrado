/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.j;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

abstract class h<K, V> {
    h<K, V> b;
    h<K, V> c;
    h<K, V> d;

    h() {
    }

    public static <K, V> boolean a(Map<K, V> map, Collection<?> object) {
        object = object.iterator();
        while (object.hasNext()) {
            if (map.containsKey(object.next())) continue;
            return false;
        }
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static <T> boolean a(Set<T> set, Object object) {
        boolean bl2 = true;
        boolean bl3 = false;
        if (set == object) {
            return true;
        }
        if (!(object instanceof Set)) return bl3;
        object = (Set)object;
        try {
            if (set.size() != object.size()) return false;
            bl3 = set.containsAll(object);
            if (!bl3) return false;
            return bl2;
        }
        catch (ClassCastException var0_1) {
            return false;
        }
        catch (NullPointerException var0_2) {
            return false;
        }
    }

    public static <K, V> boolean b(Map<K, V> map, Collection<?> object) {
        int n2 = map.size();
        object = object.iterator();
        while (object.hasNext()) {
            map.remove(object.next());
        }
        if (n2 != map.size()) {
            return true;
        }
        return false;
    }

    public static <K, V> boolean c(Map<K, V> map, Collection<?> collection) {
        int n2 = map.size();
        Iterator<K> iterator = map.keySet().iterator();
        while (iterator.hasNext()) {
            if (collection.contains(iterator.next())) continue;
            iterator.remove();
        }
        if (n2 != map.size()) {
            return true;
        }
        return false;
    }

    protected abstract int a();

    protected abstract int a(Object var1);

    protected abstract Object a(int var1, int var2);

    protected abstract V a(int var1, V var2);

    protected abstract void a(int var1);

    protected abstract void a(K var1, V var2);

    public <T> T[] a(T[] arrT, int n2) {
        int n3 = this.a();
        if (arrT.length < n3) {
            arrT = (Object[])Array.newInstance(arrT.getClass().getComponentType(), n3);
        }
        for (int i2 = 0; i2 < n3; ++i2) {
            arrT[i2] = this.a(i2, n2);
        }
        if (arrT.length > n3) {
            arrT[n3] = null;
        }
        return arrT;
    }

    protected abstract int b(Object var1);

    protected abstract Map<K, V> b();

    public Object[] b(int n2) {
        int n3 = this.a();
        Object[] arrobject = new Object[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            arrobject[i2] = this.a(i2, n2);
        }
        return arrobject;
    }

    protected abstract void c();

    public Set<Map.Entry<K, V>> d() {
        if (this.b == null) {
            this.b = new b();
        }
        return this.b;
    }

    public Set<K> e() {
        if (this.c == null) {
            this.c = new c();
        }
        return this.c;
    }

    public Collection<V> f() {
        if (this.d == null) {
            this.d = new e();
        }
        return this.d;
    }

    final class a<T>
    implements Iterator<T> {
        final int a;
        int b;
        int c;
        boolean d;

        a(int n2) {
            this.d = false;
            this.a = n2;
            this.b = h.this.a();
        }

        @Override
        public boolean hasNext() {
            if (this.c < this.b) {
                return true;
            }
            return false;
        }

        @Override
        public T next() {
            Object object = h.this.a(this.c, this.a);
            ++this.c;
            this.d = true;
            return (T)object;
        }

        @Override
        public void remove() {
            if (!this.d) {
                throw new IllegalStateException();
            }
            --this.c;
            --this.b;
            this.d = false;
            h.this.a(this.c);
        }
    }

    final class b
    implements Set<Map.Entry<K, V>> {
        b() {
        }

        public boolean a(Map.Entry<K, V> entry) {
            throw new UnsupportedOperationException();
        }

        @Override
        public /* synthetic */ boolean add(Object object) {
            return this.a((Map.Entry)object);
        }

        @Override
        public boolean addAll(Collection<? extends Map.Entry<K, V>> object) {
            int n2 = h.this.a();
            object = object.iterator();
            while (object.hasNext()) {
                Map.Entry entry = (Map.Entry)object.next();
                h.this.a(entry.getKey(), entry.getValue());
            }
            if (n2 != h.this.a()) {
                return true;
            }
            return false;
        }

        @Override
        public void clear() {
            h.this.c();
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public boolean contains(Object object) {
            int n2;
            if (!(object instanceof Map.Entry) || (n2 = h.this.a((object = (Map.Entry)object).getKey())) < 0) {
                return false;
            }
            return android.support.v4.j.c.a(h.this.a(n2, 1), object.getValue());
        }

        @Override
        public boolean containsAll(Collection<?> object) {
            object = object.iterator();
            while (object.hasNext()) {
                if (this.contains(object.next())) continue;
                return false;
            }
            return true;
        }

        @Override
        public boolean equals(Object object) {
            return h.a(this, object);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public int hashCode() {
            int n2 = h.this.a() - 1;
            int n3 = 0;
            while (n2 >= 0) {
                Object object = h.this.a(n2, 0);
                Object object2 = h.this.a(n2, 1);
                int n4 = object == null ? 0 : object.hashCode();
                int n5 = object2 == null ? 0 : object2.hashCode();
                --n2;
                n3 += n5 ^ n4;
            }
            return n3;
        }

        @Override
        public boolean isEmpty() {
            if (h.this.a() == 0) {
                return true;
            }
            return false;
        }

        @Override
        public Iterator<Map.Entry<K, V>> iterator() {
            return new d();
        }

        @Override
        public boolean remove(Object object) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean removeAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean retainAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int size() {
            return h.this.a();
        }

        @Override
        public Object[] toArray() {
            throw new UnsupportedOperationException();
        }

        @Override
        public <T> T[] toArray(T[] arrT) {
            throw new UnsupportedOperationException();
        }
    }

    final class c
    implements Set<K> {
        c() {
        }

        @Override
        public boolean add(K k2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean addAll(Collection<? extends K> collection) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void clear() {
            h.this.c();
        }

        @Override
        public boolean contains(Object object) {
            if (h.this.a(object) >= 0) {
                return true;
            }
            return false;
        }

        @Override
        public boolean containsAll(Collection<?> collection) {
            return h.a(h.this.b(), collection);
        }

        @Override
        public boolean equals(Object object) {
            return h.a(this, object);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public int hashCode() {
            int n2 = h.this.a() - 1;
            int n3 = 0;
            while (n2 >= 0) {
                Object object = h.this.a(n2, 0);
                int n4 = object == null ? 0 : object.hashCode();
                n3 += n4;
                --n2;
            }
            return n3;
        }

        @Override
        public boolean isEmpty() {
            if (h.this.a() == 0) {
                return true;
            }
            return false;
        }

        @Override
        public Iterator<K> iterator() {
            return new a(0);
        }

        @Override
        public boolean remove(Object object) {
            int n2 = h.this.a(object);
            if (n2 >= 0) {
                h.this.a(n2);
                return true;
            }
            return false;
        }

        @Override
        public boolean removeAll(Collection<?> collection) {
            return h.b(h.this.b(), collection);
        }

        @Override
        public boolean retainAll(Collection<?> collection) {
            return h.c(h.this.b(), collection);
        }

        @Override
        public int size() {
            return h.this.a();
        }

        @Override
        public Object[] toArray() {
            return h.this.b(0);
        }

        @Override
        public <T> T[] toArray(T[] arrT) {
            return h.this.a(arrT, 0);
        }
    }

    final class d
    implements Iterator<Map.Entry<K, V>>,
    Map.Entry<K, V> {
        int a;
        int b;
        boolean c;

        d() {
            this.c = false;
            this.a = h.this.a() - 1;
            this.b = -1;
        }

        public Map.Entry<K, V> a() {
            ++this.b;
            this.c = true;
            return this;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        public final boolean equals(Object object) {
            boolean bl2 = true;
            if (!this.c) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            if (!(object instanceof Map.Entry)) {
                return false;
            }
            if (!android.support.v4.j.c.a((object = (Map.Entry)object).getKey(), h.this.a(this.b, 0))) return false;
            if (!android.support.v4.j.c.a(object.getValue(), h.this.a(this.b, 1))) return false;
            return bl2;
        }

        @Override
        public K getKey() {
            if (!this.c) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            return (K)h.this.a(this.b, 0);
        }

        @Override
        public V getValue() {
            if (!this.c) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            return (V)h.this.a(this.b, 1);
        }

        @Override
        public boolean hasNext() {
            if (this.b < this.a) {
                return true;
            }
            return false;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int hashCode() {
            int n2 = 0;
            if (!this.c) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            Object object = h.this.a(this.b, 0);
            Object object2 = h.this.a(this.b, 1);
            int n3 = object == null ? 0 : object.hashCode();
            if (object2 == null) {
                return n2 ^ n3;
            }
            n2 = object2.hashCode();
            return n2 ^ n3;
        }

        @Override
        public /* synthetic */ Object next() {
            return this.a();
        }

        @Override
        public void remove() {
            if (!this.c) {
                throw new IllegalStateException();
            }
            h.this.a(this.b);
            --this.b;
            --this.a;
            this.c = false;
        }

        @Override
        public V setValue(V v2) {
            if (!this.c) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            return h.this.a(this.b, v2);
        }

        public final String toString() {
            return this.getKey() + "=" + this.getValue();
        }
    }

    final class e
    implements Collection<V> {
        e() {
        }

        @Override
        public boolean add(V v2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean addAll(Collection<? extends V> collection) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void clear() {
            h.this.c();
        }

        @Override
        public boolean contains(Object object) {
            if (h.this.b(object) >= 0) {
                return true;
            }
            return false;
        }

        @Override
        public boolean containsAll(Collection<?> object) {
            object = object.iterator();
            while (object.hasNext()) {
                if (this.contains(object.next())) continue;
                return false;
            }
            return true;
        }

        @Override
        public boolean isEmpty() {
            if (h.this.a() == 0) {
                return true;
            }
            return false;
        }

        @Override
        public Iterator<V> iterator() {
            return new a(1);
        }

        @Override
        public boolean remove(Object object) {
            int n2 = h.this.b(object);
            if (n2 >= 0) {
                h.this.a(n2);
                return true;
            }
            return false;
        }

        @Override
        public boolean removeAll(Collection<?> collection) {
            int n2 = 0;
            int n3 = h.this.a();
            boolean bl2 = false;
            while (n2 < n3) {
                int n4 = n2;
                int n5 = n3;
                if (collection.contains(h.this.a(n2, 1))) {
                    h.this.a(n2);
                    n4 = n2 - 1;
                    n5 = n3 - 1;
                    bl2 = true;
                }
                n2 = n4 + 1;
                n3 = n5;
            }
            return bl2;
        }

        @Override
        public boolean retainAll(Collection<?> collection) {
            int n2 = 0;
            int n3 = h.this.a();
            boolean bl2 = false;
            while (n2 < n3) {
                int n4 = n2;
                int n5 = n3;
                if (!collection.contains(h.this.a(n2, 1))) {
                    h.this.a(n2);
                    n4 = n2 - 1;
                    n5 = n3 - 1;
                    bl2 = true;
                }
                n2 = n4 + 1;
                n3 = n5;
            }
            return bl2;
        }

        @Override
        public int size() {
            return h.this.a();
        }

        @Override
        public Object[] toArray() {
            return h.this.b(1);
        }

        @Override
        public <T> T[] toArray(T[] arrT) {
            return h.this.a(arrT, 1);
        }
    }

}

