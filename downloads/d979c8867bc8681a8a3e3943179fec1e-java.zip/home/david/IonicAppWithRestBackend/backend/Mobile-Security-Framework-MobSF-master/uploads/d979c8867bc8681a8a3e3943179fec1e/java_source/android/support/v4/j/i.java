/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.j;

public class i<F, S> {
    public final F a;
    public final S b;

    private static boolean a(Object object, Object object2) {
        if (object == object2 || object != null && object.equals(object2)) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (!(object instanceof i)) {
            return false;
        }
        object = (i)object;
        if (!i.a(object.a, this.a)) return false;
        if (!i.a(object.b, this.b)) return false;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public int hashCode() {
        int n2 = 0;
        int n3 = this.a == null ? 0 : this.a.hashCode();
        if (this.b == null) {
            return n3 ^ n2;
        }
        n2 = this.b.hashCode();
        return n3 ^ n2;
    }

    public String toString() {
        return "Pair{" + String.valueOf(this.a) + " " + String.valueOf(this.b) + "}";
    }
}

