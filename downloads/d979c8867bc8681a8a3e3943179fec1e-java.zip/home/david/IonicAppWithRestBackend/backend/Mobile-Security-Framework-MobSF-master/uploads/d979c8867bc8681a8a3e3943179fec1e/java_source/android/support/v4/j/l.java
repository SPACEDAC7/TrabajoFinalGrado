/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.j;

import android.support.v4.j.c;

public class l<E>
implements Cloneable {
    private static final Object a = new Object();
    private boolean b = false;
    private int[] c;
    private Object[] d;
    private int e;

    public l() {
        this(10);
    }

    /*
     * Enabled aggressive block sorting
     */
    public l(int n2) {
        if (n2 == 0) {
            this.c = c.a;
            this.d = c.c;
        } else {
            n2 = c.a(n2);
            this.c = new int[n2];
            this.d = new Object[n2];
        }
        this.e = 0;
    }

    private void d() {
        int n2 = this.e;
        int[] arrn = this.c;
        Object[] arrobject = this.d;
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            Object object = arrobject[i2];
            int n4 = n3;
            if (object != a) {
                if (i2 != n3) {
                    arrn[n3] = arrn[i2];
                    arrobject[n3] = object;
                    arrobject[i2] = null;
                }
                n4 = n3 + 1;
            }
            n3 = n4;
        }
        this.b = false;
        this.e = n3;
    }

    public l<E> a() {
        l l2;
        try {
            l2 = (l)super.clone();
        }
        catch (CloneNotSupportedException var1_2) {
            return null;
        }
        try {
            l2.c = (int[])this.c.clone();
            l2.d = (Object[])this.d.clone();
            return l2;
        }
        catch (CloneNotSupportedException var2_3) {
            return l2;
        }
    }

    public E a(int n2) {
        return this.a(n2, null);
    }

    public E a(int n2, E e2) {
        if ((n2 = c.a(this.c, this.e, n2)) < 0 || this.d[n2] == a) {
            return e2;
        }
        return (E)this.d[n2];
    }

    public int b() {
        if (this.b) {
            this.d();
        }
        return this.e;
    }

    public void b(int n2) {
        if ((n2 = c.a(this.c, this.e, n2)) >= 0 && this.d[n2] != a) {
            this.d[n2] = a;
            this.b = true;
        }
    }

    public void b(int n2, E e2) {
        int n3 = c.a(this.c, this.e, n2);
        if (n3 >= 0) {
            this.d[n3] = e2;
            return;
        }
        int n4 = ~ n3;
        if (n4 < this.e && this.d[n4] == a) {
            this.c[n4] = n2;
            this.d[n4] = e2;
            return;
        }
        n3 = n4;
        if (this.b) {
            n3 = n4;
            if (this.e >= this.c.length) {
                this.d();
                n3 = ~ c.a(this.c, this.e, n2);
            }
        }
        if (this.e >= this.c.length) {
            n4 = c.a(this.e + 1);
            int[] arrn = new int[n4];
            Object[] arrobject = new Object[n4];
            System.arraycopy(this.c, 0, arrn, 0, this.c.length);
            System.arraycopy(this.d, 0, arrobject, 0, this.d.length);
            this.c = arrn;
            this.d = arrobject;
        }
        if (this.e - n3 != 0) {
            System.arraycopy(this.c, n3, this.c, n3 + 1, this.e - n3);
            System.arraycopy(this.d, n3, this.d, n3 + 1, this.e - n3);
        }
        this.c[n3] = n2;
        this.d[n3] = e2;
        ++this.e;
    }

    public void c() {
        int n2 = this.e;
        Object[] arrobject = this.d;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrobject[i2] = null;
        }
        this.e = 0;
        this.b = false;
    }

    public void c(int n2) {
        this.b(n2);
    }

    public /* synthetic */ Object clone() {
        return this.a();
    }

    public int d(int n2) {
        if (this.b) {
            this.d();
        }
        return this.c[n2];
    }

    public E e(int n2) {
        if (this.b) {
            this.d();
        }
        return (E)this.d[n2];
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        if (this.b() <= 0) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.e * 28);
        stringBuilder.append('{');
        int n2 = 0;
        do {
            if (n2 >= this.e) {
                stringBuilder.append('}');
                return stringBuilder.toString();
            }
            if (n2 > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(this.d(n2));
            stringBuilder.append('=');
            E e2 = this.e(n2);
            if (e2 != this) {
                stringBuilder.append(e2);
            } else {
                stringBuilder.append("(this Map)");
            }
            ++n2;
        } while (true);
    }
}

