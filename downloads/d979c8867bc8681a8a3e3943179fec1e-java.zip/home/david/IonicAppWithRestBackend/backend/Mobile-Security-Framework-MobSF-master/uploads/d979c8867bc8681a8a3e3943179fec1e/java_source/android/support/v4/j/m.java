/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.j;

import java.io.PrintWriter;

public final class m {
    private static final Object a = new Object();
    private static char[] b = new char[24];

    private static int a(int n2, int n3, boolean bl2, int n4) {
        if (n2 > 99 || bl2 && n4 >= 3) {
            return n3 + 3;
        }
        if (n2 > 9 || bl2 && n4 >= 2) {
            return n3 + 2;
        }
        if (bl2 || n2 > 0) {
            return n3 + 1;
        }
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int a(long l2, int n2) {
        boolean bl2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        if (b.length < n2) {
            b = new char[n2];
        }
        char[] arrc = b;
        if (l2 == 0) {
            do {
                if (n2 - 1 >= 0) {
                    arrc[0] = 48;
                    return 1;
                }
                arrc[0] = 32;
            } while (true);
        }
        if (l2 > 0) {
            n5 = 43;
        } else {
            l2 = - l2;
            n5 = 45;
        }
        int n8 = (int)(l2 % 1000);
        int n9 = (int)Math.floor(l2 / 1000);
        int n10 = 0;
        int n11 = n9;
        if (n9 > 86400) {
            n10 = n9 / 86400;
            n11 = n9 - 86400 * n10;
        }
        if (n11 > 3600) {
            n4 = n9 = n11 / 3600;
            n11 -= n9 * 3600;
        } else {
            n4 = 0;
        }
        if (n11 > 60) {
            n7 = n9 = n11 / 60;
            n9 = n11 - n9 * 60;
        } else {
            n7 = 0;
            n9 = n11;
        }
        if (n2 != 0) {
            n11 = m.a(n10, 1, false, 0);
            bl2 = n11 > 0;
            bl2 = (n11 += m.a(n4, 1, bl2, 2)) > 0;
            bl2 = (n11 += m.a(n7, 1, bl2, 2)) > 0;
            n6 = n11 + m.a(n9, 1, bl2, 2);
            n11 = n6 > 0 ? 3 : 0;
            n3 = m.a(n8, 2, true, n11);
            n11 = 0;
            n6 = n3 + 1 + n6;
            do {
                n3 = n11++;
                if (n6 < n2) {
                    arrc[n11] = 32;
                    ++n6;
                    continue;
                }
                break;
                break;
            } while (true);
        } else {
            n3 = 0;
        }
        arrc[n3] = n5;
        n6 = n3 + 1;
        n2 = n2 != 0 ? 1 : 0;
        bl2 = (n10 = m.a(arrc, n10, 'd', n6, false, 0)) != n6;
        n11 = n2 != 0 ? 2 : 0;
        bl2 = (n10 = m.a(arrc, n4, 'h', n10, bl2, n11)) != n6;
        n11 = n2 != 0 ? 2 : 0;
        bl2 = (n10 = m.a(arrc, n7, 'm', n10, bl2, n11)) != n6;
        n11 = n2 != 0 ? 2 : 0;
        n11 = m.a(arrc, n9, 's', n10, bl2, n11);
        n2 = n2 != 0 && n11 != n6 ? 3 : 0;
        n2 = m.a(arrc, n8, 'm', n11, true, n2);
        arrc[n2] = 115;
        return n2 + 1;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int a(char[] var0, int var1_1, char var2_2, int var3_3, boolean var4_4, int var5_5) {
        if (!var4_4) {
            var6_6 = var3_3;
            if (var1_1 <= 0) return var6_6;
        }
        if (var4_4 && var5_5 >= 3 || var1_1 > 99) {
            var7_7 = var1_1 / 100;
            var0[var3_3] = (char)(var7_7 + 48);
            var6_6 = var3_3 + 1;
            var1_1 -= var7_7 * 100;
        } else {
            var6_6 = var3_3;
        }
        if (var4_4 && var5_5 >= 2 || var1_1 > 9) ** GOTO lbl-1000
        var7_7 = var6_6;
        var5_5 = var1_1;
        if (var3_3 != var6_6) lbl-1000: // 2 sources:
        {
            var3_3 = var1_1 / 10;
            var0[var6_6] = (char)(var3_3 + 48);
            var7_7 = var6_6 + 1;
            var5_5 = var1_1 - var3_3 * 10;
        }
        var0[var7_7] = (char)(var5_5 + 48);
        var1_1 = var7_7 + 1;
        var0[var1_1] = var2_2;
        return var1_1 + 1;
    }

    public static void a(long l2, long l3, PrintWriter printWriter) {
        if (l2 == 0) {
            printWriter.print("--");
            return;
        }
        m.a(l2 - l3, printWriter, 0);
    }

    public static void a(long l2, PrintWriter printWriter) {
        m.a(l2, printWriter, 0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(long l2, PrintWriter printWriter, int n2) {
        Object object = a;
        synchronized (object) {
            n2 = m.a(l2, n2);
            printWriter.print(new String(b, 0, n2));
            return;
        }
    }
}

