/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package android.support.v4.k;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.f.g;
import android.support.v4.f.h;

public abstract class a
implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR;
    public static final a d;
    private final Parcelable a;

    static {
        d = new a(){};
        CREATOR = g.a(new h<a>(){

            public a a(Parcel parcel, ClassLoader classLoader) {
                if (parcel.readParcelable(classLoader) != null) {
                    throw new IllegalStateException("superState must be null");
                }
                return a.d;
            }

            public a[] a(int n2) {
                return new a[n2];
            }

            @Override
            public /* synthetic */ Object b(Parcel parcel, ClassLoader classLoader) {
                return this.a(parcel, classLoader);
            }

            @Override
            public /* synthetic */ Object[] b(int n2) {
                return this.a(n2);
            }
        });
    }

    private a() {
        this.a = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected a(Parcel object, ClassLoader classLoader) {
        object = object.readParcelable(classLoader);
        if (object == null) {
            object = d;
        }
        this.a = object;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected a(Parcelable parcelable) {
        if (parcelable == null) {
            throw new IllegalArgumentException("superState must not be null");
        }
        if (parcelable == d) {
            parcelable = null;
        }
        this.a = parcelable;
    }

    public final Parcelable a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeParcelable(this.a, n2);
    }

}

