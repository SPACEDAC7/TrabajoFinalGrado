/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.accessibility.AccessibilityEvent
 */
package android.support.v4.k.a;

import android.os.Build;
import android.support.v4.k.a.o;
import android.view.accessibility.AccessibilityEvent;

public final class a {
    private static final e a = Build.VERSION.SDK_INT >= 19 ? new c() : (Build.VERSION.SDK_INT >= 16 ? new b() : (Build.VERSION.SDK_INT >= 14 ? new a() : new d()));

    public static o a(AccessibilityEvent accessibilityEvent) {
        return new o((Object)accessibilityEvent);
    }

    public static void a(AccessibilityEvent accessibilityEvent, int n2) {
        a.a(accessibilityEvent, n2);
    }

    public static int b(AccessibilityEvent accessibilityEvent) {
        return a.a(accessibilityEvent);
    }

    static class a
    extends d {
        a() {
        }
    }

    static class b
    extends a {
        b() {
        }
    }

    static class c
    extends b {
        c() {
        }

        @Override
        public int a(AccessibilityEvent accessibilityEvent) {
            return android.support.v4.k.a.b.a(accessibilityEvent);
        }

        @Override
        public void a(AccessibilityEvent accessibilityEvent, int n2) {
            android.support.v4.k.a.b.a(accessibilityEvent, n2);
        }
    }

    static class d
    implements e {
        d() {
        }

        @Override
        public int a(AccessibilityEvent accessibilityEvent) {
            return 0;
        }

        @Override
        public void a(AccessibilityEvent accessibilityEvent, int n2) {
        }
    }

    static interface e {
        public int a(AccessibilityEvent var1);

        public void a(AccessibilityEvent var1, int var2);
    }

}

