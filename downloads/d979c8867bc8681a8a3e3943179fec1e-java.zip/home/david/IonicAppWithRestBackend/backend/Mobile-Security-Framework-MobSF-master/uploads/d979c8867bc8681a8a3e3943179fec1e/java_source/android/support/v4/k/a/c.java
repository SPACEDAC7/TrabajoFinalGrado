/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Rect
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 */
package android.support.v4.k.a;

import android.graphics.Rect;
import android.os.Build;
import android.view.View;

public class c {
    static final g a = Build.VERSION.SDK_INT >= 24 ? new e() : (Build.VERSION.SDK_INT >= 23 ? new d() : (Build.VERSION.SDK_INT >= 22 ? new c() : (Build.VERSION.SDK_INT >= 21 ? new b() : (Build.VERSION.SDK_INT >= 19 ? new k() : (Build.VERSION.SDK_INT >= 18 ? new j() : (Build.VERSION.SDK_INT >= 17 ? new i() : (Build.VERSION.SDK_INT >= 16 ? new h() : (Build.VERSION.SDK_INT >= 14 ? new f() : new l()))))))));
    public int b = -1;
    private final Object c;

    public c(Object object) {
        this.c = object;
    }

    public static c a(c c2) {
        return c.a(a.a(c2.c));
    }

    static c a(Object object) {
        if (object != null) {
            return new c(object);
        }
        return null;
    }

    private static String b(int n2) {
        switch (n2) {
            default: {
                return "ACTION_UNKNOWN";
            }
            case 1: {
                return "ACTION_FOCUS";
            }
            case 2: {
                return "ACTION_CLEAR_FOCUS";
            }
            case 4: {
                return "ACTION_SELECT";
            }
            case 8: {
                return "ACTION_CLEAR_SELECTION";
            }
            case 16: {
                return "ACTION_CLICK";
            }
            case 32: {
                return "ACTION_LONG_CLICK";
            }
            case 64: {
                return "ACTION_ACCESSIBILITY_FOCUS";
            }
            case 128: {
                return "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
            }
            case 256: {
                return "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
            }
            case 512: {
                return "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
            }
            case 1024: {
                return "ACTION_NEXT_HTML_ELEMENT";
            }
            case 2048: {
                return "ACTION_PREVIOUS_HTML_ELEMENT";
            }
            case 4096: {
                return "ACTION_SCROLL_FORWARD";
            }
            case 8192: {
                return "ACTION_SCROLL_BACKWARD";
            }
            case 65536: {
                return "ACTION_CUT";
            }
            case 16384: {
                return "ACTION_COPY";
            }
            case 32768: {
                return "ACTION_PASTE";
            }
            case 131072: 
        }
        return "ACTION_SET_SELECTION";
    }

    public Object a() {
        return this.c;
    }

    public void a(int n2) {
        a.a(this.c, n2);
    }

    public void a(Rect rect) {
        a.a(this.c, rect);
    }

    public void a(View view) {
        a.c(this.c, view);
    }

    public void a(CharSequence charSequence) {
        a.d(this.c, charSequence);
    }

    public void a(boolean bl2) {
        a.a(this.c, bl2);
    }

    public boolean a(a a2) {
        return a.a(this.c, a2.E);
    }

    public int b() {
        return a.b(this.c);
    }

    public void b(Rect rect) {
        a.c(this.c, rect);
    }

    public void b(View view) {
        a.a(this.c, view);
    }

    public void b(CharSequence charSequence) {
        a.b(this.c, charSequence);
    }

    public void b(Object object) {
        a.b(this.c, ((m)object).a);
    }

    public void b(boolean bl2) {
        a.b(this.c, bl2);
    }

    public void c(Rect rect) {
        a.b(this.c, rect);
    }

    public void c(View view) {
        a.b(this.c, view);
    }

    public void c(CharSequence charSequence) {
        a.e(this.c, charSequence);
    }

    public void c(Object object) {
        a.c(this.c, ((n)object).a);
    }

    public void c(boolean bl2) {
        a.e(this.c, bl2);
    }

    public boolean c() {
        return a.g(this.c);
    }

    public void d(Rect rect) {
        a.d(this.c, rect);
    }

    public void d(View view) {
        a.d(this.c, view);
    }

    public void d(CharSequence charSequence) {
        a.c(this.c, charSequence);
    }

    public void d(boolean bl2) {
        a.f(this.c, bl2);
    }

    public boolean d() {
        return a.h(this.c);
    }

    public void e(CharSequence charSequence) {
        a.a(this.c, charSequence);
    }

    public void e(boolean bl2) {
        a.j(this.c, bl2);
    }

    public boolean e() {
        return a.k(this.c);
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null) {
            return false;
        }
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (c)object;
        if (this.c == null) {
            if (object.c == null) return true;
            return false;
        }
        if (!this.c.equals(object.c)) return false;
        return true;
    }

    public void f(boolean bl2) {
        a.k(this.c, bl2);
    }

    public boolean f() {
        return a.l(this.c);
    }

    public void g(boolean bl2) {
        a.i(this.c, bl2);
    }

    public boolean g() {
        return a.r(this.c);
    }

    public void h(boolean bl2) {
        a.c(this.c, bl2);
    }

    public boolean h() {
        return a.s(this.c);
    }

    public int hashCode() {
        if (this.c == null) {
            return 0;
        }
        return this.c.hashCode();
    }

    public void i(boolean bl2) {
        a.g(this.c, bl2);
    }

    public boolean i() {
        return a.p(this.c);
    }

    public void j(boolean bl2) {
        a.d(this.c, bl2);
    }

    public boolean j() {
        return a.i(this.c);
    }

    public void k(boolean bl2) {
        a.h(this.c, bl2);
    }

    public boolean k() {
        return a.m(this.c);
    }

    public void l(boolean bl2) {
        a.l(this.c, bl2);
    }

    public boolean l() {
        return a.j(this.c);
    }

    public boolean m() {
        return a.n(this.c);
    }

    public boolean n() {
        return a.o(this.c);
    }

    public CharSequence o() {
        return a.e(this.c);
    }

    public CharSequence p() {
        return a.c(this.c);
    }

    public CharSequence q() {
        return a.f(this.c);
    }

    public CharSequence r() {
        return a.d(this.c);
    }

    public void s() {
        a.q(this.c);
    }

    public String t() {
        return a.t(this.c);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(super.toString());
        Rect rect = new Rect();
        this.a(rect);
        stringBuilder.append("; boundsInParent: " + (Object)rect);
        this.c(rect);
        stringBuilder.append("; boundsInScreen: " + (Object)rect);
        stringBuilder.append("; packageName: ").append(this.o());
        stringBuilder.append("; className: ").append(this.p());
        stringBuilder.append("; text: ").append(this.q());
        stringBuilder.append("; contentDescription: ").append(this.r());
        stringBuilder.append("; viewId: ").append(this.t());
        stringBuilder.append("; checkable: ").append(this.c());
        stringBuilder.append("; checked: ").append(this.d());
        stringBuilder.append("; focusable: ").append(this.e());
        stringBuilder.append("; focused: ").append(this.f());
        stringBuilder.append("; selected: ").append(this.i());
        stringBuilder.append("; clickable: ").append(this.j());
        stringBuilder.append("; longClickable: ").append(this.k());
        stringBuilder.append("; enabled: ").append(this.l());
        stringBuilder.append("; password: ").append(this.m());
        stringBuilder.append("; scrollable: " + this.n());
        stringBuilder.append("; [");
        int n2 = this.b();
        while (n2 != 0) {
            int n3 = 1 << Integer.numberOfTrailingZeros(n2);
            int n4 = n2 & ~ n3;
            stringBuilder.append(c.b(n3));
            n2 = n4;
            if (n4 == 0) continue;
            stringBuilder.append(", ");
            n2 = n4;
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public static class a {
        public static final a A;
        public static final a B;
        public static final a C;
        public static final a D;
        public static final a a;
        public static final a b;
        public static final a c;
        public static final a d;
        public static final a e;
        public static final a f;
        public static final a g;
        public static final a h;
        public static final a i;
        public static final a j;
        public static final a k;
        public static final a l;
        public static final a m;
        public static final a n;
        public static final a o;
        public static final a p;
        public static final a q;
        public static final a r;
        public static final a s;
        public static final a t;
        public static final a u;
        public static final a v;
        public static final a w;
        public static final a x;
        public static final a y;
        public static final a z;
        final Object E;

        static {
            a = new a(1, null);
            b = new a(2, null);
            c = new a(4, null);
            d = new a(8, null);
            e = new a(16, null);
            f = new a(32, null);
            g = new a(64, null);
            h = new a(128, null);
            i = new a(256, null);
            j = new a(512, null);
            k = new a(1024, null);
            l = new a(2048, null);
            m = new a(4096, null);
            n = new a(8192, null);
            o = new a(16384, null);
            p = new a(32768, null);
            q = new a(65536, null);
            r = new a(131072, null);
            s = new a(262144, null);
            t = new a(524288, null);
            u = new a(1048576, null);
            v = new a(2097152, null);
            w = new a(c.a.b());
            x = new a(c.a.a());
            y = new a(c.a.c());
            z = new a(c.a.e());
            A = new a(c.a.d());
            B = new a(c.a.f());
            C = new a(c.a.g());
            D = new a(c.a.h());
        }

        public a(int n2, CharSequence charSequence) {
            this(c.a.a(n2, charSequence));
        }

        a(Object object) {
            this.E = object;
        }
    }

    static class b
    extends k {
        b() {
        }

        @Override
        public Object a(int n2, int n3, int n4, int n5, boolean bl2, boolean bl3) {
            return android.support.v4.k.a.d.a(n2, n3, n4, n5, bl2, bl3);
        }

        @Override
        public Object a(int n2, int n3, boolean bl2, int n4) {
            return android.support.v4.k.a.d.a(n2, n3, bl2, n4);
        }

        @Override
        public Object a(int n2, CharSequence charSequence) {
            return android.support.v4.k.a.d.a(n2, charSequence);
        }

        @Override
        public void a(Object object, CharSequence charSequence) {
            android.support.v4.k.a.d.a(object, charSequence);
        }

        @Override
        public boolean a(Object object, Object object2) {
            return android.support.v4.k.a.d.a(object, object2);
        }
    }

    static class c
    extends b {
        c() {
        }
    }

    static class d
    extends c {
        d() {
        }

        @Override
        public Object a() {
            return android.support.v4.k.a.e.a();
        }

        @Override
        public Object b() {
            return android.support.v4.k.a.e.b();
        }

        @Override
        public Object c() {
            return android.support.v4.k.a.e.c();
        }

        @Override
        public Object d() {
            return android.support.v4.k.a.e.d();
        }

        @Override
        public Object e() {
            return android.support.v4.k.a.e.e();
        }

        @Override
        public Object f() {
            return android.support.v4.k.a.e.f();
        }

        @Override
        public Object g() {
            return android.support.v4.k.a.e.g();
        }
    }

    static class e
    extends d {
        e() {
        }

        @Override
        public Object h() {
            return android.support.v4.k.a.f.a();
        }
    }

    static class f
    extends l {
        f() {
        }

        @Override
        public Object a(Object object) {
            return android.support.v4.k.a.g.a(object);
        }

        @Override
        public void a(Object object, int n2) {
            android.support.v4.k.a.g.a(object, n2);
        }

        @Override
        public void a(Object object, Rect rect) {
            android.support.v4.k.a.g.a(object, rect);
        }

        @Override
        public void a(Object object, View view) {
            android.support.v4.k.a.g.a(object, view);
        }

        @Override
        public void a(Object object, boolean bl2) {
            android.support.v4.k.a.g.a(object, bl2);
        }

        @Override
        public int b(Object object) {
            return android.support.v4.k.a.g.b(object);
        }

        @Override
        public void b(Object object, Rect rect) {
            android.support.v4.k.a.g.b(object, rect);
        }

        @Override
        public void b(Object object, View view) {
            android.support.v4.k.a.g.b(object, view);
        }

        @Override
        public void b(Object object, CharSequence charSequence) {
            android.support.v4.k.a.g.a(object, charSequence);
        }

        @Override
        public void b(Object object, boolean bl2) {
            android.support.v4.k.a.g.b(object, bl2);
        }

        @Override
        public CharSequence c(Object object) {
            return android.support.v4.k.a.g.c(object);
        }

        @Override
        public void c(Object object, Rect rect) {
            android.support.v4.k.a.g.c(object, rect);
        }

        @Override
        public void c(Object object, View view) {
            android.support.v4.k.a.g.c(object, view);
        }

        @Override
        public void c(Object object, CharSequence charSequence) {
            android.support.v4.k.a.g.b(object, charSequence);
        }

        @Override
        public void c(Object object, boolean bl2) {
            android.support.v4.k.a.g.c(object, bl2);
        }

        @Override
        public CharSequence d(Object object) {
            return android.support.v4.k.a.g.d(object);
        }

        @Override
        public void d(Object object, Rect rect) {
            android.support.v4.k.a.g.d(object, rect);
        }

        @Override
        public void d(Object object, CharSequence charSequence) {
            android.support.v4.k.a.g.c(object, charSequence);
        }

        @Override
        public void d(Object object, boolean bl2) {
            android.support.v4.k.a.g.d(object, bl2);
        }

        @Override
        public CharSequence e(Object object) {
            return android.support.v4.k.a.g.e(object);
        }

        @Override
        public void e(Object object, CharSequence charSequence) {
            android.support.v4.k.a.g.d(object, charSequence);
        }

        @Override
        public void e(Object object, boolean bl2) {
            android.support.v4.k.a.g.e(object, bl2);
        }

        @Override
        public CharSequence f(Object object) {
            return android.support.v4.k.a.g.f(object);
        }

        @Override
        public void f(Object object, boolean bl2) {
            android.support.v4.k.a.g.f(object, bl2);
        }

        @Override
        public void g(Object object, boolean bl2) {
            android.support.v4.k.a.g.g(object, bl2);
        }

        @Override
        public boolean g(Object object) {
            return android.support.v4.k.a.g.g(object);
        }

        @Override
        public void h(Object object, boolean bl2) {
            android.support.v4.k.a.g.h(object, bl2);
        }

        @Override
        public boolean h(Object object) {
            return android.support.v4.k.a.g.h(object);
        }

        @Override
        public void i(Object object, boolean bl2) {
            android.support.v4.k.a.g.i(object, bl2);
        }

        @Override
        public boolean i(Object object) {
            return android.support.v4.k.a.g.i(object);
        }

        @Override
        public boolean j(Object object) {
            return android.support.v4.k.a.g.j(object);
        }

        @Override
        public boolean k(Object object) {
            return android.support.v4.k.a.g.k(object);
        }

        @Override
        public boolean l(Object object) {
            return android.support.v4.k.a.g.l(object);
        }

        @Override
        public boolean m(Object object) {
            return android.support.v4.k.a.g.m(object);
        }

        @Override
        public boolean n(Object object) {
            return android.support.v4.k.a.g.n(object);
        }

        @Override
        public boolean o(Object object) {
            return android.support.v4.k.a.g.o(object);
        }

        @Override
        public boolean p(Object object) {
            return android.support.v4.k.a.g.p(object);
        }

        @Override
        public void q(Object object) {
            android.support.v4.k.a.g.q(object);
        }
    }

    static interface g {
        public Object a();

        public Object a(int var1, int var2, int var3, int var4, boolean var5, boolean var6);

        public Object a(int var1, int var2, boolean var3, int var4);

        public Object a(int var1, CharSequence var2);

        public Object a(Object var1);

        public void a(Object var1, int var2);

        public void a(Object var1, Rect var2);

        public void a(Object var1, View var2);

        public void a(Object var1, CharSequence var2);

        public void a(Object var1, boolean var2);

        public boolean a(Object var1, Object var2);

        public int b(Object var1);

        public Object b();

        public void b(Object var1, Rect var2);

        public void b(Object var1, View var2);

        public void b(Object var1, CharSequence var2);

        public void b(Object var1, Object var2);

        public void b(Object var1, boolean var2);

        public CharSequence c(Object var1);

        public Object c();

        public void c(Object var1, Rect var2);

        public void c(Object var1, View var2);

        public void c(Object var1, CharSequence var2);

        public void c(Object var1, Object var2);

        public void c(Object var1, boolean var2);

        public CharSequence d(Object var1);

        public Object d();

        public void d(Object var1, Rect var2);

        public void d(Object var1, View var2);

        public void d(Object var1, CharSequence var2);

        public void d(Object var1, boolean var2);

        public CharSequence e(Object var1);

        public Object e();

        public void e(Object var1, CharSequence var2);

        public void e(Object var1, boolean var2);

        public CharSequence f(Object var1);

        public Object f();

        public void f(Object var1, boolean var2);

        public Object g();

        public void g(Object var1, boolean var2);

        public boolean g(Object var1);

        public Object h();

        public void h(Object var1, boolean var2);

        public boolean h(Object var1);

        public void i(Object var1, boolean var2);

        public boolean i(Object var1);

        public void j(Object var1, boolean var2);

        public boolean j(Object var1);

        public void k(Object var1, boolean var2);

        public boolean k(Object var1);

        public void l(Object var1, boolean var2);

        public boolean l(Object var1);

        public boolean m(Object var1);

        public boolean n(Object var1);

        public boolean o(Object var1);

        public boolean p(Object var1);

        public void q(Object var1);

        public boolean r(Object var1);

        public boolean s(Object var1);

        public String t(Object var1);
    }

    static class h
    extends f {
        h() {
        }

        @Override
        public void j(Object object, boolean bl2) {
            android.support.v4.k.a.h.a(object, bl2);
        }

        @Override
        public void k(Object object, boolean bl2) {
            android.support.v4.k.a.h.b(object, bl2);
        }

        @Override
        public boolean r(Object object) {
            return android.support.v4.k.a.h.a(object);
        }

        @Override
        public boolean s(Object object) {
            return android.support.v4.k.a.h.b(object);
        }
    }

    static class i
    extends h {
        i() {
        }

        @Override
        public void d(Object object, View view) {
            android.support.v4.k.a.i.a(object, view);
        }
    }

    static class j
    extends i {
        j() {
        }

        @Override
        public String t(Object object) {
            return android.support.v4.k.a.j.a(object);
        }
    }

    static class k
    extends j {
        k() {
        }

        @Override
        public Object a(int n2, int n3, int n4, int n5, boolean bl2, boolean bl3) {
            return android.support.v4.k.a.k.a(n2, n3, n4, n5, bl2);
        }

        @Override
        public Object a(int n2, int n3, boolean bl2, int n4) {
            return android.support.v4.k.a.k.a(n2, n3, bl2, n4);
        }

        @Override
        public void b(Object object, Object object2) {
            android.support.v4.k.a.k.a(object, object2);
        }

        @Override
        public void c(Object object, Object object2) {
            android.support.v4.k.a.k.b(object, object2);
        }

        @Override
        public void l(Object object, boolean bl2) {
            android.support.v4.k.a.k.a(object, bl2);
        }
    }

    static class l
    implements g {
        l() {
        }

        @Override
        public Object a() {
            return null;
        }

        @Override
        public Object a(int n2, int n3, int n4, int n5, boolean bl2, boolean bl3) {
            return null;
        }

        @Override
        public Object a(int n2, int n3, boolean bl2, int n4) {
            return null;
        }

        @Override
        public Object a(int n2, CharSequence charSequence) {
            return null;
        }

        @Override
        public Object a(Object object) {
            return null;
        }

        @Override
        public void a(Object object, int n2) {
        }

        @Override
        public void a(Object object, Rect rect) {
        }

        @Override
        public void a(Object object, View view) {
        }

        @Override
        public void a(Object object, CharSequence charSequence) {
        }

        @Override
        public void a(Object object, boolean bl2) {
        }

        @Override
        public boolean a(Object object, Object object2) {
            return false;
        }

        @Override
        public int b(Object object) {
            return 0;
        }

        @Override
        public Object b() {
            return null;
        }

        @Override
        public void b(Object object, Rect rect) {
        }

        @Override
        public void b(Object object, View view) {
        }

        @Override
        public void b(Object object, CharSequence charSequence) {
        }

        @Override
        public void b(Object object, Object object2) {
        }

        @Override
        public void b(Object object, boolean bl2) {
        }

        @Override
        public CharSequence c(Object object) {
            return null;
        }

        @Override
        public Object c() {
            return null;
        }

        @Override
        public void c(Object object, Rect rect) {
        }

        @Override
        public void c(Object object, View view) {
        }

        @Override
        public void c(Object object, CharSequence charSequence) {
        }

        @Override
        public void c(Object object, Object object2) {
        }

        @Override
        public void c(Object object, boolean bl2) {
        }

        @Override
        public CharSequence d(Object object) {
            return null;
        }

        @Override
        public Object d() {
            return null;
        }

        @Override
        public void d(Object object, Rect rect) {
        }

        @Override
        public void d(Object object, View view) {
        }

        @Override
        public void d(Object object, CharSequence charSequence) {
        }

        @Override
        public void d(Object object, boolean bl2) {
        }

        @Override
        public CharSequence e(Object object) {
            return null;
        }

        @Override
        public Object e() {
            return null;
        }

        @Override
        public void e(Object object, CharSequence charSequence) {
        }

        @Override
        public void e(Object object, boolean bl2) {
        }

        @Override
        public CharSequence f(Object object) {
            return null;
        }

        @Override
        public Object f() {
            return null;
        }

        @Override
        public void f(Object object, boolean bl2) {
        }

        @Override
        public Object g() {
            return null;
        }

        @Override
        public void g(Object object, boolean bl2) {
        }

        @Override
        public boolean g(Object object) {
            return false;
        }

        @Override
        public Object h() {
            return null;
        }

        @Override
        public void h(Object object, boolean bl2) {
        }

        @Override
        public boolean h(Object object) {
            return false;
        }

        @Override
        public void i(Object object, boolean bl2) {
        }

        @Override
        public boolean i(Object object) {
            return false;
        }

        @Override
        public void j(Object object, boolean bl2) {
        }

        @Override
        public boolean j(Object object) {
            return false;
        }

        @Override
        public void k(Object object, boolean bl2) {
        }

        @Override
        public boolean k(Object object) {
            return false;
        }

        @Override
        public void l(Object object, boolean bl2) {
        }

        @Override
        public boolean l(Object object) {
            return false;
        }

        @Override
        public boolean m(Object object) {
            return false;
        }

        @Override
        public boolean n(Object object) {
            return false;
        }

        @Override
        public boolean o(Object object) {
            return false;
        }

        @Override
        public boolean p(Object object) {
            return false;
        }

        @Override
        public void q(Object object) {
        }

        @Override
        public boolean r(Object object) {
            return false;
        }

        @Override
        public boolean s(Object object) {
            return false;
        }

        @Override
        public String t(Object object) {
            return null;
        }
    }

    public static class m {
        final Object a;

        m(Object object) {
            this.a = object;
        }

        public static m a(int n2, int n3, boolean bl2, int n4) {
            return new m(c.a.a(n2, n3, bl2, n4));
        }
    }

    public static class n {
        final Object a;

        n(Object object) {
            this.a = object;
        }

        public static n a(int n2, int n3, int n4, int n5, boolean bl2, boolean bl3) {
            return new n(c.a.a(n2, n3, n4, n5, bl2, bl3));
        }
    }

}

