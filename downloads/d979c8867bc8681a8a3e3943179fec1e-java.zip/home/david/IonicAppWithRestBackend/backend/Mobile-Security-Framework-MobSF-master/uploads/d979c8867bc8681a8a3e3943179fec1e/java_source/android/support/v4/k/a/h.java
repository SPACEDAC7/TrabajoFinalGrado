/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.accessibility.AccessibilityNodeInfo
 */
package android.support.v4.k.a;

import android.annotation.TargetApi;
import android.view.accessibility.AccessibilityNodeInfo;

@TargetApi(value=16)
class h {
    public static void a(Object object, boolean bl2) {
        ((AccessibilityNodeInfo)object).setVisibleToUser(bl2);
    }

    public static boolean a(Object object) {
        return ((AccessibilityNodeInfo)object).isVisibleToUser();
    }

    public static void b(Object object, boolean bl2) {
        ((AccessibilityNodeInfo)object).setAccessibilityFocused(bl2);
    }

    public static boolean b(Object object) {
        return ((AccessibilityNodeInfo)object).isAccessibilityFocused();
    }
}

