/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 */
package android.support.v4.k.a;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.k.a.m;
import android.support.v4.k.a.n;
import java.util.ArrayList;
import java.util.List;

public class l {
    private static final a a = Build.VERSION.SDK_INT >= 19 ? new c() : (Build.VERSION.SDK_INT >= 16 ? new b() : new d());
    private final Object b;

    public l() {
        this.b = a.a(this);
    }

    public l(Object object) {
        this.b = object;
    }

    public android.support.v4.k.a.c a(int n2) {
        return null;
    }

    public Object a() {
        return this.b;
    }

    public List<android.support.v4.k.a.c> a(String string, int n2) {
        return null;
    }

    public boolean a(int n2, int n3, Bundle bundle) {
        return false;
    }

    public android.support.v4.k.a.c b(int n2) {
        return null;
    }

    static interface a {
        public Object a(l var1);
    }

    private static class b
    extends d {
        b() {
        }

        @Override
        public Object a(final l l2) {
            return m.a(new m.a(){

                @Override
                public Object a(int n2) {
                    android.support.v4.k.a.c c2 = l2.a(n2);
                    if (c2 == null) {
                        return null;
                    }
                    return c2.a();
                }

                @Override
                public List<Object> a(String object, int n2) {
                    if ((object = l2.a((String)object, n2)) == null) {
                        return null;
                    }
                    ArrayList<Object> arrayList = new ArrayList<Object>();
                    int n3 = object.size();
                    for (n2 = 0; n2 < n3; ++n2) {
                        arrayList.add(((android.support.v4.k.a.c)object.get(n2)).a());
                    }
                    return arrayList;
                }

                @Override
                public boolean a(int n2, int n3, Bundle bundle) {
                    return l2.a(n2, n3, bundle);
                }
            });
        }

    }

    private static class c
    extends d {
        c() {
        }

        @Override
        public Object a(final l l2) {
            return n.a(new n.a(){

                @Override
                public Object a(int n2) {
                    android.support.v4.k.a.c c2 = l2.a(n2);
                    if (c2 == null) {
                        return null;
                    }
                    return c2.a();
                }

                @Override
                public List<Object> a(String object, int n2) {
                    if ((object = l2.a((String)object, n2)) == null) {
                        return null;
                    }
                    ArrayList<Object> arrayList = new ArrayList<Object>();
                    int n3 = object.size();
                    for (n2 = 0; n2 < n3; ++n2) {
                        arrayList.add(((android.support.v4.k.a.c)object.get(n2)).a());
                    }
                    return arrayList;
                }

                @Override
                public boolean a(int n2, int n3, Bundle bundle) {
                    return l2.a(n2, n3, bundle);
                }

                @Override
                public Object b(int n2) {
                    android.support.v4.k.a.c c2 = l2.b(n2);
                    if (c2 == null) {
                        return null;
                    }
                    return c2.a();
                }
            });
        }

    }

    static class d
    implements a {
        d() {
        }

        @Override
        public Object a(l l2) {
            return null;
        }
    }

}

