/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package android.support.v4.k.a;

import android.os.Build;
import android.support.v4.k.a.p;
import android.support.v4.k.a.q;

public class o {
    private static final c a = Build.VERSION.SDK_INT >= 16 ? new d() : (Build.VERSION.SDK_INT >= 15 ? new b() : (Build.VERSION.SDK_INT >= 14 ? new a() : new e()));
    private final Object b;

    @Deprecated
    public o(Object object) {
        this.b = object;
    }

    public void a(int n2) {
        a.b(this.b, n2);
    }

    public void a(boolean bl2) {
        a.a(this.b, bl2);
    }

    public void b(int n2) {
        a.a(this.b, n2);
    }

    public void c(int n2) {
        a.e(this.b, n2);
    }

    public void d(int n2) {
        a.c(this.b, n2);
    }

    public void e(int n2) {
        a.d(this.b, n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null) {
            return false;
        }
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (o)object;
        if (this.b == null) {
            if (object.b == null) return true;
            return false;
        }
        if (!this.b.equals(object.b)) return false;
        return true;
    }

    public void f(int n2) {
        a.f(this.b, n2);
    }

    public void g(int n2) {
        a.g(this.b, n2);
    }

    public int hashCode() {
        if (this.b == null) {
            return 0;
        }
        return this.b.hashCode();
    }

    static class a
    extends e {
        a() {
        }

        @Override
        public void a(Object object, int n2) {
            p.a(object, n2);
        }

        @Override
        public void a(Object object, boolean bl2) {
            p.a(object, bl2);
        }

        @Override
        public void b(Object object, int n2) {
            p.b(object, n2);
        }

        @Override
        public void c(Object object, int n2) {
            p.c(object, n2);
        }

        @Override
        public void d(Object object, int n2) {
            p.d(object, n2);
        }

        @Override
        public void e(Object object, int n2) {
            p.e(object, n2);
        }
    }

    static class b
    extends a {
        b() {
        }

        @Override
        public void f(Object object, int n2) {
            q.a(object, n2);
        }

        @Override
        public void g(Object object, int n2) {
            q.b(object, n2);
        }
    }

    static interface c {
        public void a(Object var1, int var2);

        public void a(Object var1, boolean var2);

        public void b(Object var1, int var2);

        public void c(Object var1, int var2);

        public void d(Object var1, int var2);

        public void e(Object var1, int var2);

        public void f(Object var1, int var2);

        public void g(Object var1, int var2);
    }

    static class d
    extends b {
        d() {
        }
    }

    static class e
    implements c {
        e() {
        }

        @Override
        public void a(Object object, int n2) {
        }

        @Override
        public void a(Object object, boolean bl2) {
        }

        @Override
        public void b(Object object, int n2) {
        }

        @Override
        public void c(Object object, int n2) {
        }

        @Override
        public void d(Object object, int n2) {
        }

        @Override
        public void e(Object object, int n2) {
        }

        @Override
        public void f(Object object, int n2) {
        }

        @Override
        public void g(Object object, int n2) {
        }
    }

}

