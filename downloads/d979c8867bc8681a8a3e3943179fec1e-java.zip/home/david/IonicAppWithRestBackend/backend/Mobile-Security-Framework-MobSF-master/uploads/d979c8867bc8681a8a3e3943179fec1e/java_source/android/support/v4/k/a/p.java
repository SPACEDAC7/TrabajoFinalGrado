/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.accessibility.AccessibilityRecord
 */
package android.support.v4.k.a;

import android.annotation.TargetApi;
import android.view.accessibility.AccessibilityRecord;

@TargetApi(value=14)
class p {
    public static void a(Object object, int n2) {
        ((AccessibilityRecord)object).setFromIndex(n2);
    }

    public static void a(Object object, boolean bl2) {
        ((AccessibilityRecord)object).setScrollable(bl2);
    }

    public static void b(Object object, int n2) {
        ((AccessibilityRecord)object).setItemCount(n2);
    }

    public static void c(Object object, int n2) {
        ((AccessibilityRecord)object).setScrollX(n2);
    }

    public static void d(Object object, int n2) {
        ((AccessibilityRecord)object).setScrollY(n2);
    }

    public static void e(Object object, int n2) {
        ((AccessibilityRecord)object).setToIndex(n2);
    }
}

