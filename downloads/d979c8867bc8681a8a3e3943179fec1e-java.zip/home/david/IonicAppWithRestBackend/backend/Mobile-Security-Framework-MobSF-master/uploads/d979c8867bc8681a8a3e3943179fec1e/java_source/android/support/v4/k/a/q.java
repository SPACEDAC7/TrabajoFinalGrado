/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.accessibility.AccessibilityRecord
 */
package android.support.v4.k.a;

import android.annotation.TargetApi;
import android.view.accessibility.AccessibilityRecord;

@TargetApi(value=15)
class q {
    public static void a(Object object, int n2) {
        ((AccessibilityRecord)object).setMaxScrollX(n2);
    }

    public static void b(Object object, int n2) {
        ((AccessibilityRecord)object).setMaxScrollY(n2);
    }
}

