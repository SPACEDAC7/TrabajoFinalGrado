/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.k;

public interface aa {
    public int computeHorizontalScrollExtent();

    public int computeHorizontalScrollOffset();

    public int computeHorizontalScrollRange();

    public int computeVerticalScrollExtent();

    public int computeVerticalScrollOffset();

    public int computeVerticalScrollRange();
}

