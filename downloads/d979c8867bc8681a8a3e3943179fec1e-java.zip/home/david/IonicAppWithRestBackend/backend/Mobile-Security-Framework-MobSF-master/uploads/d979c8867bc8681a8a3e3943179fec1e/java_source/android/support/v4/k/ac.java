/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.VelocityTracker
 */
package android.support.v4.k;

import android.os.Build;
import android.support.v4.k.ad;
import android.view.VelocityTracker;

public final class ac {
    static final c a = Build.VERSION.SDK_INT >= 11 ? new b() : new a();

    public static float a(VelocityTracker velocityTracker, int n2) {
        return a.a(velocityTracker, n2);
    }

    public static float b(VelocityTracker velocityTracker, int n2) {
        return a.b(velocityTracker, n2);
    }

    static class a
    implements c {
        a() {
        }

        @Override
        public float a(VelocityTracker velocityTracker, int n2) {
            return velocityTracker.getXVelocity();
        }

        @Override
        public float b(VelocityTracker velocityTracker, int n2) {
            return velocityTracker.getYVelocity();
        }
    }

    static class b
    implements c {
        b() {
        }

        @Override
        public float a(VelocityTracker velocityTracker, int n2) {
            return ad.a(velocityTracker, n2);
        }

        @Override
        public float b(VelocityTracker velocityTracker, int n2) {
            return ad.b(velocityTracker, n2);
        }
    }

    static interface c {
        public float a(VelocityTracker var1, int var2);

        public float b(VelocityTracker var1, int var2);
    }

}

