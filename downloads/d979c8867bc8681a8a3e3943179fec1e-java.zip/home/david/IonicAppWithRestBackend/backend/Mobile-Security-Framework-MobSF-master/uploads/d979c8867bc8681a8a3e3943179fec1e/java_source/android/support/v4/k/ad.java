/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.VelocityTracker
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.VelocityTracker;

@TargetApi(value=11)
class ad {
    public static float a(VelocityTracker velocityTracker, int n2) {
        return velocityTracker.getXVelocity(n2);
    }

    public static float b(VelocityTracker velocityTracker, int n2) {
        return velocityTracker.getYVelocity(n2);
    }
}

