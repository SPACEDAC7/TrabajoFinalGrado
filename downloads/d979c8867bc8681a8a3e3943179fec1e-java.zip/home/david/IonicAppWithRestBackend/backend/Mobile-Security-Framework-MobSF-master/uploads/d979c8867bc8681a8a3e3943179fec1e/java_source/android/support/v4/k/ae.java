/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.res.ColorStateList
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.Display
 *  android.view.View
 *  android.view.ViewParent
 */
package android.support.v4.k;

import android.content.res.ColorStateList;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.k.aa;
import android.support.v4.k.af;
import android.support.v4.k.ag;
import android.support.v4.k.ah;
import android.support.v4.k.ai;
import android.support.v4.k.aj;
import android.support.v4.k.ak;
import android.support.v4.k.al;
import android.support.v4.k.am;
import android.support.v4.k.an;
import android.support.v4.k.au;
import android.support.v4.k.bb;
import android.support.v4.k.v;
import android.support.v4.k.z;
import android.view.Display;
import android.view.View;
import android.view.ViewParent;
import java.lang.reflect.Field;
import java.util.WeakHashMap;

public class ae {
    static final l a;

    static {
        int n2 = Build.VERSION.SDK_INT;
        a = android.support.v4.f.c.a() ? new a() : (n2 >= 23 ? new k() : (n2 >= 21 ? new j() : (n2 >= 19 ? new i() : (n2 >= 18 ? new h() : (n2 >= 17 ? new g() : (n2 >= 16 ? new f() : (n2 >= 15 ? new d() : (n2 >= 14 ? new e() : (n2 >= 11 ? new c() : new b())))))))));
    }

    public static ColorStateList A(View view) {
        return a.B(view);
    }

    public static PorterDuff.Mode B(View view) {
        return a.C(view);
    }

    public static void C(View view) {
        a.D(view);
    }

    public static boolean D(View view) {
        return a.E(view);
    }

    public static float E(View view) {
        return a.F(view);
    }

    public static boolean F(View view) {
        return a.G(view);
    }

    public static boolean G(View view) {
        return a.H(view);
    }

    public static Display H(View view) {
        return a.I(view);
    }

    public static int a(int n2, int n3) {
        return a.a(n2, n3);
    }

    public static int a(int n2, int n3, int n4) {
        return a.a(n2, n3, n4);
    }

    public static bb a(View view, bb bb2) {
        return a.a(view, bb2);
    }

    public static void a(View view, float f2) {
        a.a(view, f2);
    }

    public static void a(View view, int n2, int n3) {
        a.a(view, n2, n3);
    }

    public static void a(View view, int n2, int n3, int n4, int n5) {
        a.a(view, n2, n3, n4, n5);
    }

    public static void a(View view, int n2, Paint paint) {
        a.a(view, n2, paint);
    }

    public static void a(View view, ColorStateList colorStateList) {
        a.a(view, colorStateList);
    }

    public static void a(View view, PorterDuff.Mode mode) {
        a.a(view, mode);
    }

    public static void a(View view, Drawable drawable) {
        a.a(view, drawable);
    }

    public static void a(View view, android.support.v4.k.b b2) {
        a.a(view, b2);
    }

    public static void a(View view, z z2) {
        a.a(view, z2);
    }

    public static void a(View view, Runnable runnable) {
        a.a(view, runnable);
    }

    public static void a(View view, Runnable runnable, long l2) {
        a.a(view, runnable, l2);
    }

    public static void a(View view, boolean bl2) {
        a.a(view, bl2);
    }

    public static boolean a(View view) {
        return a.a(view);
    }

    public static boolean a(View view, int n2) {
        return a.a(view, n2);
    }

    public static void b(View view, float f2) {
        a.b(view, f2);
    }

    public static void b(View view, boolean bl2) {
        a.b(view, bl2);
    }

    public static boolean b(View view) {
        return a.b(view);
    }

    public static boolean b(View view, int n2) {
        return a.b(view, n2);
    }

    public static void c(View view) {
        a.c(view);
    }

    public static void c(View view, float f2) {
        a.c(view, f2);
    }

    public static void c(View view, int n2) {
        a.c(view, n2);
    }

    public static void c(View view, boolean bl2) {
        a.c(view, bl2);
    }

    public static int d(View view) {
        return a.d(view);
    }

    public static void d(View view, float f2) {
        a.d(view, f2);
    }

    public static void d(View view, int n2) {
        a.d(view, n2);
    }

    public static void d(View view, boolean bl2) {
        a.d(view, bl2);
    }

    public static float e(View view) {
        return a.e(view);
    }

    public static void e(View view, int n2) {
        a.f(view, n2);
    }

    public static int f(View view) {
        return a.f(view);
    }

    public static void f(View view, int n2) {
        a.e(view, n2);
    }

    public static int g(View view) {
        return a.g(view);
    }

    public static ViewParent h(View view) {
        return a.h(view);
    }

    public static int i(View view) {
        return a.i(view);
    }

    public static int j(View view) {
        return a.j(view);
    }

    public static int k(View view) {
        return a.k(view);
    }

    public static int l(View view) {
        return a.l(view);
    }

    public static float m(View view) {
        return a.n(view);
    }

    public static float n(View view) {
        return a.o(view);
    }

    public static Matrix o(View view) {
        return a.p(view);
    }

    public static int p(View view) {
        return a.q(view);
    }

    public static int q(View view) {
        return a.r(view);
    }

    public static au r(View view) {
        return a.s(view);
    }

    public static float s(View view) {
        return a.w(view);
    }

    public static String t(View view) {
        return a.t(view);
    }

    public static int u(View view) {
        return a.u(view);
    }

    public static void v(View view) {
        a.v(view);
    }

    public static boolean w(View view) {
        return a.y(view);
    }

    public static void x(View view) {
        a.z(view);
    }

    public static boolean y(View view) {
        return a.m(view);
    }

    public static boolean z(View view) {
        return a.A(view);
    }

    static class a
    extends k {
        a() {
        }
    }

    static class b
    implements l {
        WeakHashMap<View, au> a = null;

        b() {
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        private boolean a(aa aa2, int n2) {
            boolean bl2 = true;
            int n3 = aa2.computeHorizontalScrollOffset();
            int n4 = aa2.computeHorizontalScrollRange() - aa2.computeHorizontalScrollExtent();
            if (n4 == 0) {
                return false;
            }
            if (n2 < 0) {
                if (n3 > 0) return bl2;
                return false;
            }
            if (n3 < n4 - 1) return bl2;
            return false;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        private boolean b(aa aa2, int n2) {
            boolean bl2 = true;
            int n3 = aa2.computeVerticalScrollOffset();
            int n4 = aa2.computeVerticalScrollRange() - aa2.computeVerticalScrollExtent();
            if (n4 == 0) {
                return false;
            }
            if (n2 < 0) {
                if (n3 > 0) return bl2;
                return false;
            }
            if (n3 < n4 - 1) return bl2;
            return false;
        }

        @Override
        public boolean A(View view) {
            return false;
        }

        @Override
        public ColorStateList B(View view) {
            return af.a(view);
        }

        @Override
        public PorterDuff.Mode C(View view) {
            return af.b(view);
        }

        @Override
        public void D(View view) {
            if (view instanceof v) {
                ((v)view).stopNestedScroll();
            }
        }

        @Override
        public boolean E(View view) {
            return af.c(view);
        }

        @Override
        public float F(View view) {
            return this.x(view) + this.w(view);
        }

        @Override
        public boolean G(View view) {
            return af.f(view);
        }

        @Override
        public boolean H(View view) {
            return false;
        }

        @Override
        public Display I(View view) {
            return af.g(view);
        }

        @Override
        public int a(int n2, int n3) {
            return n2 | n3;
        }

        @Override
        public int a(int n2, int n3, int n4) {
            return View.resolveSize((int)n2, (int)n3);
        }

        long a() {
            return 10;
        }

        @Override
        public bb a(View view, bb bb2) {
            return bb2;
        }

        @Override
        public void a(View view, float f2) {
        }

        @Override
        public void a(View view, int n2, int n3) {
        }

        @Override
        public void a(View view, int n2, int n3, int n4, int n5) {
            view.setPadding(n2, n3, n4, n5);
        }

        @Override
        public void a(View view, int n2, Paint paint) {
        }

        @Override
        public void a(View view, ColorStateList colorStateList) {
            af.a(view, colorStateList);
        }

        @Override
        public void a(View view, PorterDuff.Mode mode) {
            af.a(view, mode);
        }

        @Override
        public void a(View view, Drawable drawable) {
            view.setBackgroundDrawable(drawable);
        }

        @Override
        public void a(View view, android.support.v4.k.b b2) {
        }

        @Override
        public void a(View view, z z2) {
        }

        @Override
        public void a(View view, Runnable runnable) {
            view.postDelayed(runnable, this.a());
        }

        @Override
        public void a(View view, Runnable runnable, long l2) {
            view.postDelayed(runnable, this.a() + l2);
        }

        @Override
        public void a(View view, boolean bl2) {
        }

        @Override
        public boolean a(View view) {
            return false;
        }

        @Override
        public boolean a(View view, int n2) {
            if (view instanceof aa && this.a((aa)view, n2)) {
                return true;
            }
            return false;
        }

        @Override
        public void b(View view, float f2) {
        }

        @Override
        public void b(View view, boolean bl2) {
        }

        @Override
        public boolean b(View view) {
            return false;
        }

        @Override
        public boolean b(View view, int n2) {
            if (view instanceof aa && this.b((aa)view, n2)) {
                return true;
            }
            return false;
        }

        @Override
        public void c(View view) {
            view.invalidate();
        }

        @Override
        public void c(View view, float f2) {
        }

        @Override
        public void c(View view, int n2) {
        }

        @Override
        public void c(View view, boolean bl2) {
        }

        @Override
        public int d(View view) {
            return 0;
        }

        @Override
        public void d(View view, float f2) {
        }

        @Override
        public void d(View view, int n2) {
        }

        @Override
        public void d(View view, boolean bl2) {
        }

        @Override
        public float e(View view) {
            return 1.0f;
        }

        @Override
        public void e(View view, int n2) {
            af.b(view, n2);
        }

        @Override
        public int f(View view) {
            return 0;
        }

        @Override
        public void f(View view, int n2) {
            af.a(view, n2);
        }

        @Override
        public int g(View view) {
            return 0;
        }

        @Override
        public ViewParent h(View view) {
            return view.getParent();
        }

        @Override
        public int i(View view) {
            return view.getMeasuredWidth();
        }

        @Override
        public int j(View view) {
            return 0;
        }

        @Override
        public int k(View view) {
            return view.getPaddingLeft();
        }

        @Override
        public int l(View view) {
            return view.getPaddingRight();
        }

        @Override
        public boolean m(View view) {
            return true;
        }

        @Override
        public float n(View view) {
            return 0.0f;
        }

        @Override
        public float o(View view) {
            return 0.0f;
        }

        @Override
        public Matrix p(View view) {
            return null;
        }

        @Override
        public int q(View view) {
            return af.d(view);
        }

        @Override
        public int r(View view) {
            return af.e(view);
        }

        @Override
        public au s(View view) {
            return new au(view);
        }

        @Override
        public String t(View view) {
            return null;
        }

        @Override
        public int u(View view) {
            return 0;
        }

        @Override
        public void v(View view) {
        }

        @Override
        public float w(View view) {
            return 0.0f;
        }

        public float x(View view) {
            return 0.0f;
        }

        @Override
        public boolean y(View view) {
            return false;
        }

        @Override
        public void z(View view) {
        }
    }

    static class c
    extends b {
        c() {
        }

        @Override
        public int a(int n2, int n3) {
            return ag.a(n2, n3);
        }

        @Override
        public int a(int n2, int n3, int n4) {
            return ag.a(n2, n3, n4);
        }

        @Override
        long a() {
            return ag.a();
        }

        @Override
        public void a(View view, float f2) {
            ag.a(view, f2);
        }

        @Override
        public void a(View view, int n2, Paint paint) {
            ag.a(view, n2, paint);
        }

        @Override
        public void b(View view, float f2) {
            ag.b(view, f2);
        }

        @Override
        public void c(View view, float f2) {
            ag.c(view, f2);
        }

        @Override
        public void c(View view, boolean bl2) {
            ag.a(view, bl2);
        }

        @Override
        public void d(View view, boolean bl2) {
            ag.b(view, bl2);
        }

        @Override
        public float e(View view) {
            return ag.a(view);
        }

        @Override
        public void e(View view, int n2) {
            ag.b(view, n2);
        }

        @Override
        public int f(View view) {
            return ag.b(view);
        }

        @Override
        public void f(View view, int n2) {
            ag.a(view, n2);
        }

        @Override
        public int i(View view) {
            return ag.c(view);
        }

        @Override
        public int j(View view) {
            return ag.d(view);
        }

        @Override
        public float n(View view) {
            return ag.e(view);
        }

        @Override
        public float o(View view) {
            return ag.f(view);
        }

        @Override
        public Matrix p(View view) {
            return ag.g(view);
        }

        @Override
        public void z(View view) {
            ag.h(view);
        }
    }

    static class d
    extends e {
        d() {
        }

        @Override
        public boolean H(View view) {
            return ai.a(view);
        }
    }

    static class e
    extends c {
        static Field b;
        static boolean c;

        static {
            c = false;
        }

        e() {
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void a(View view, android.support.v4.k.b object) {
            object = object == null ? null : object.a();
            ah.a(view, object);
        }

        /*
         * Loose catch block
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        @Override
        public boolean a(View object) {
            boolean bl2 = true;
            if (c) {
                return false;
            }
            if (b == null) {
                b = View.class.getDeclaredField("mAccessibilityDelegate");
                b.setAccessible(true);
            }
            try {
                object = b.get(object);
                if (object == null) return false;
                return bl2;
            }
            catch (Throwable var1_3) {
                c = true;
                return false;
            }
            catch (Throwable throwable) {
                c = true;
                return false;
            }
        }

        @Override
        public boolean a(View view, int n2) {
            return ah.a(view, n2);
        }

        @Override
        public void b(View view, boolean bl2) {
            ah.a(view, bl2);
        }

        @Override
        public boolean b(View view, int n2) {
            return ah.b(view, n2);
        }

        @Override
        public au s(View view) {
            au au2;
            if (this.a == null) {
                this.a = new WeakHashMap();
            }
            au au3 = au2 = (au)this.a.get((Object)view);
            if (au2 == null) {
                au3 = new au(view);
                this.a.put(view, au3);
            }
            return au3;
        }
    }

    static class f
    extends d {
        f() {
        }

        @Override
        public void a(View view, Drawable drawable) {
            aj.a(view, drawable);
        }

        @Override
        public void a(View view, Runnable runnable) {
            aj.a(view, runnable);
        }

        @Override
        public void a(View view, Runnable runnable, long l2) {
            aj.a(view, runnable, l2);
        }

        @Override
        public void a(View view, boolean bl2) {
            aj.a(view, bl2);
        }

        @Override
        public boolean b(View view) {
            return aj.a(view);
        }

        @Override
        public void c(View view) {
            aj.b(view);
        }

        @Override
        public void c(View view, int n2) {
            int n3 = n2;
            if (n2 == 4) {
                n3 = 2;
            }
            aj.a(view, n3);
        }

        @Override
        public int d(View view) {
            return aj.c(view);
        }

        @Override
        public ViewParent h(View view) {
            return aj.d(view);
        }

        @Override
        public boolean m(View view) {
            return aj.i(view);
        }

        @Override
        public int q(View view) {
            return aj.e(view);
        }

        @Override
        public int r(View view) {
            return aj.f(view);
        }

        @Override
        public void v(View view) {
            aj.g(view);
        }

        @Override
        public boolean y(View view) {
            return aj.h(view);
        }
    }

    static class g
    extends f {
        g() {
        }

        @Override
        public boolean A(View view) {
            return ak.e(view);
        }

        @Override
        public Display I(View view) {
            return ak.f(view);
        }

        @Override
        public void a(View view, int n2, int n3, int n4, int n5) {
            ak.a(view, n2, n3, n4, n5);
        }

        @Override
        public int g(View view) {
            return ak.a(view);
        }

        @Override
        public int k(View view) {
            return ak.b(view);
        }

        @Override
        public int l(View view) {
            return ak.c(view);
        }

        @Override
        public int u(View view) {
            return ak.d(view);
        }
    }

    static class h
    extends g {
        h() {
        }
    }

    static class i
    extends h {
        i() {
        }

        @Override
        public boolean E(View view) {
            return al.a(view);
        }

        @Override
        public boolean G(View view) {
            return al.b(view);
        }

        @Override
        public void c(View view, int n2) {
            aj.a(view, n2);
        }

        @Override
        public void d(View view, int n2) {
            al.a(view, n2);
        }
    }

    static class j
    extends i {
        j() {
        }

        @Override
        public ColorStateList B(View view) {
            return am.e(view);
        }

        @Override
        public PorterDuff.Mode C(View view) {
            return am.f(view);
        }

        @Override
        public void D(View view) {
            am.g(view);
        }

        @Override
        public float F(View view) {
            return am.h(view);
        }

        @Override
        public bb a(View view, bb bb2) {
            return bb.a(am.a(view, bb.a(bb2)));
        }

        @Override
        public void a(View view, ColorStateList colorStateList) {
            am.a(view, colorStateList);
        }

        @Override
        public void a(View view, PorterDuff.Mode mode) {
            am.a(view, mode);
        }

        @Override
        public void a(View view, final z z2) {
            if (z2 == null) {
                am.a(view, null);
                return;
            }
            am.a(view, new am.a(){

                @Override
                public Object a(View view, Object object) {
                    object = bb.a(object);
                    return bb.a(z2.a(view, (bb)object));
                }
            });
        }

        @Override
        public void d(View view, float f2) {
            am.a(view, f2);
        }

        @Override
        public void e(View view, int n2) {
            am.b(view, n2);
        }

        @Override
        public void f(View view, int n2) {
            am.a(view, n2);
        }

        @Override
        public String t(View view) {
            return am.a(view);
        }

        @Override
        public void v(View view) {
            am.b(view);
        }

        @Override
        public float w(View view) {
            return am.c(view);
        }

        @Override
        public float x(View view) {
            return am.d(view);
        }

    }

    static class k
    extends j {
        k() {
        }

        @Override
        public void a(View view, int n2, int n3) {
            an.a(view, n2, n3);
        }

        @Override
        public void e(View view, int n2) {
            an.b(view, n2);
        }

        @Override
        public void f(View view, int n2) {
            an.a(view, n2);
        }
    }

    static interface l {
        public boolean A(View var1);

        public ColorStateList B(View var1);

        public PorterDuff.Mode C(View var1);

        public void D(View var1);

        public boolean E(View var1);

        public float F(View var1);

        public boolean G(View var1);

        public boolean H(View var1);

        public Display I(View var1);

        public int a(int var1, int var2);

        public int a(int var1, int var2, int var3);

        public bb a(View var1, bb var2);

        public void a(View var1, float var2);

        public void a(View var1, int var2, int var3);

        public void a(View var1, int var2, int var3, int var4, int var5);

        public void a(View var1, int var2, Paint var3);

        public void a(View var1, ColorStateList var2);

        public void a(View var1, PorterDuff.Mode var2);

        public void a(View var1, Drawable var2);

        public void a(View var1, android.support.v4.k.b var2);

        public void a(View var1, z var2);

        public void a(View var1, Runnable var2);

        public void a(View var1, Runnable var2, long var3);

        public void a(View var1, boolean var2);

        public boolean a(View var1);

        public boolean a(View var1, int var2);

        public void b(View var1, float var2);

        public void b(View var1, boolean var2);

        public boolean b(View var1);

        public boolean b(View var1, int var2);

        public void c(View var1);

        public void c(View var1, float var2);

        public void c(View var1, int var2);

        public void c(View var1, boolean var2);

        public int d(View var1);

        public void d(View var1, float var2);

        public void d(View var1, int var2);

        public void d(View var1, boolean var2);

        public float e(View var1);

        public void e(View var1, int var2);

        public int f(View var1);

        public void f(View var1, int var2);

        public int g(View var1);

        public ViewParent h(View var1);

        public int i(View var1);

        public int j(View var1);

        public int k(View var1);

        public int l(View var1);

        public boolean m(View var1);

        public float n(View var1);

        public float o(View var1);

        public Matrix p(View var1);

        public int q(View var1);

        public int r(View var1);

        public au s(View var1);

        public String t(View var1);

        public int u(View var1);

        public void v(View var1);

        public float w(View var1);

        public boolean y(View var1);

        public void z(View var1);
    }

}

