/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.os.IBinder
 *  android.view.Display
 *  android.view.View
 *  android.view.ViewParent
 *  android.view.WindowManager
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.IBinder;
import android.support.v4.k.ab;
import android.view.Display;
import android.view.View;
import android.view.ViewParent;
import android.view.WindowManager;
import java.lang.reflect.Field;

@TargetApi(value=9)
class af {
    private static Field a;
    private static boolean b;
    private static Field c;
    private static boolean d;

    static ColorStateList a(View view) {
        if (view instanceof ab) {
            return ((ab)view).getSupportBackgroundTintList();
        }
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static void a(View view, int n2) {
        int n3 = view.getTop();
        view.offsetTopAndBottom(n2);
        if (n2 == 0) return;
        ViewParent viewParent = view.getParent();
        if (viewParent instanceof View) {
            n2 = Math.abs(n2);
            ((View)viewParent).invalidate(view.getLeft(), n3 - n2, view.getRight(), n3 + view.getHeight() + n2);
            return;
        }
        view.invalidate();
    }

    static void a(View view, ColorStateList colorStateList) {
        if (view instanceof ab) {
            ((ab)view).setSupportBackgroundTintList(colorStateList);
        }
    }

    static void a(View view, PorterDuff.Mode mode) {
        if (view instanceof ab) {
            ((ab)view).setSupportBackgroundTintMode(mode);
        }
    }

    static PorterDuff.Mode b(View view) {
        if (view instanceof ab) {
            return ((ab)view).getSupportBackgroundTintMode();
        }
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static void b(View view, int n2) {
        int n3 = view.getLeft();
        view.offsetLeftAndRight(n2);
        if (n2 == 0) return;
        ViewParent viewParent = view.getParent();
        if (viewParent instanceof View) {
            n2 = Math.abs(n2);
            ((View)viewParent).invalidate(n3 - n2, view.getTop(), n3 + view.getWidth() + n2, view.getBottom());
            return;
        }
        view.invalidate();
    }

    static boolean c(View view) {
        if (view.getWidth() > 0 && view.getHeight() > 0) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static int d(View view) {
        if (!b) {
            try {
                a = View.class.getDeclaredField("mMinWidth");
                a.setAccessible(true);
            }
            catch (NoSuchFieldException var2_3) {}
            b = true;
        }
        if (a == null) return 0;
        try {
            return (Integer)a.get((Object)view);
        }
        catch (Exception var0_1) {
            // empty catch block
        }
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static int e(View view) {
        if (!d) {
            try {
                c = View.class.getDeclaredField("mMinHeight");
                c.setAccessible(true);
            }
            catch (NoSuchFieldException var2_3) {}
            d = true;
        }
        if (c == null) return 0;
        try {
            return (Integer)c.get((Object)view);
        }
        catch (Exception var0_1) {
            // empty catch block
        }
        return 0;
    }

    static boolean f(View view) {
        if (view.getWindowToken() != null) {
            return true;
        }
        return false;
    }

    static Display g(View view) {
        if (af.f(view)) {
            return ((WindowManager)view.getContext().getSystemService("window")).getDefaultDisplay();
        }
        return null;
    }
}

