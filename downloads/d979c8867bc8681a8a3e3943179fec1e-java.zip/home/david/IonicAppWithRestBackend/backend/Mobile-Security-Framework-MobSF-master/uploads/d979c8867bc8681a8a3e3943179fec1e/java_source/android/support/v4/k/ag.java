/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.annotation.TargetApi
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.view.View
 *  android.view.ViewParent
 */
package android.support.v4.k;

import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.View;
import android.view.ViewParent;

@TargetApi(value=11)
class ag {
    public static float a(View view) {
        return view.getAlpha();
    }

    public static int a(int n2, int n3) {
        return View.combineMeasuredStates((int)n2, (int)n3);
    }

    public static int a(int n2, int n3, int n4) {
        return View.resolveSizeAndState((int)n2, (int)n3, (int)n4);
    }

    static long a() {
        return ValueAnimator.getFrameDelay();
    }

    public static void a(View view, float f2) {
        view.setTranslationX(f2);
    }

    static void a(View view, int n2) {
        view.offsetTopAndBottom(n2);
        if (view.getVisibility() == 0) {
            ag.i(view);
            view = view.getParent();
            if (view instanceof View) {
                ag.i(view);
            }
        }
    }

    public static void a(View view, int n2, Paint paint) {
        view.setLayerType(n2, paint);
    }

    public static void a(View view, boolean bl2) {
        view.setSaveFromParentEnabled(bl2);
    }

    public static int b(View view) {
        return view.getLayerType();
    }

    public static void b(View view, float f2) {
        view.setTranslationY(f2);
    }

    static void b(View view, int n2) {
        view.offsetLeftAndRight(n2);
        if (view.getVisibility() == 0) {
            ag.i(view);
            view = view.getParent();
            if (view instanceof View) {
                ag.i(view);
            }
        }
    }

    public static void b(View view, boolean bl2) {
        view.setActivated(bl2);
    }

    public static int c(View view) {
        return view.getMeasuredWidthAndState();
    }

    public static void c(View view, float f2) {
        view.setAlpha(f2);
    }

    public static int d(View view) {
        return view.getMeasuredState();
    }

    public static float e(View view) {
        return view.getTranslationX();
    }

    public static float f(View view) {
        return view.getTranslationY();
    }

    public static Matrix g(View view) {
        return view.getMatrix();
    }

    public static void h(View view) {
        view.jumpDrawablesToCurrentState();
    }

    private static void i(View view) {
        float f2 = view.getTranslationY();
        view.setTranslationY(1.0f + f2);
        view.setTranslationY(f2);
    }
}

