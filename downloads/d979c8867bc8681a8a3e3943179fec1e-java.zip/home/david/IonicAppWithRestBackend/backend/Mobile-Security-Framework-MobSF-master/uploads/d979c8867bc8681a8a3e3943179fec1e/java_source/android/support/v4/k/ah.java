/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.View
 *  android.view.View$AccessibilityDelegate
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.View;

@TargetApi(value=14)
class ah {
    public static void a(View view, Object object) {
        view.setAccessibilityDelegate((View.AccessibilityDelegate)object);
    }

    public static void a(View view, boolean bl2) {
        view.setFitsSystemWindows(bl2);
    }

    public static boolean a(View view, int n2) {
        return view.canScrollHorizontally(n2);
    }

    public static boolean b(View view, int n2) {
        return view.canScrollVertically(n2);
    }
}

