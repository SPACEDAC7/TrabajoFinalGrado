/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.view.ViewParent
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewParent;

@TargetApi(value=16)
class aj {
    public static void a(View view, int n2) {
        view.setImportantForAccessibility(n2);
    }

    public static void a(View view, Drawable drawable) {
        view.setBackground(drawable);
    }

    public static void a(View view, Runnable runnable) {
        view.postOnAnimation(runnable);
    }

    public static void a(View view, Runnable runnable, long l2) {
        view.postOnAnimationDelayed(runnable, l2);
    }

    public static void a(View view, boolean bl2) {
        view.setHasTransientState(bl2);
    }

    public static boolean a(View view) {
        return view.hasTransientState();
    }

    public static void b(View view) {
        view.postInvalidateOnAnimation();
    }

    public static int c(View view) {
        return view.getImportantForAccessibility();
    }

    public static ViewParent d(View view) {
        return view.getParentForAccessibility();
    }

    public static int e(View view) {
        return view.getMinimumWidth();
    }

    public static int f(View view) {
        return view.getMinimumHeight();
    }

    public static void g(View view) {
        view.requestFitSystemWindows();
    }

    public static boolean h(View view) {
        return view.getFitsSystemWindows();
    }

    public static boolean i(View view) {
        return view.hasOverlappingRendering();
    }
}

