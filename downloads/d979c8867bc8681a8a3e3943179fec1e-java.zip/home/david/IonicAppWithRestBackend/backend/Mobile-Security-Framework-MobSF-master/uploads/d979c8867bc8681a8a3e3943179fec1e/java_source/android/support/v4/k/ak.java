/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.Display
 *  android.view.View
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.Display;
import android.view.View;

@TargetApi(value=17)
class ak {
    public static int a(View view) {
        return view.getLayoutDirection();
    }

    public static void a(View view, int n2, int n3, int n4, int n5) {
        view.setPaddingRelative(n2, n3, n4, n5);
    }

    public static int b(View view) {
        return view.getPaddingStart();
    }

    public static int c(View view) {
        return view.getPaddingEnd();
    }

    public static int d(View view) {
        return view.getWindowSystemUiVisibility();
    }

    public static boolean e(View view) {
        return view.isPaddingRelative();
    }

    public static Display f(View view) {
        return view.getDisplay();
    }
}

