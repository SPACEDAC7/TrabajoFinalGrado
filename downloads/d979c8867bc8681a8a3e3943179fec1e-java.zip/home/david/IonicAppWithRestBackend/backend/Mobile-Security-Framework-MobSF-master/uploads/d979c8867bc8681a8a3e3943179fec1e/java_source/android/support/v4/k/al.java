/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.View
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.View;

@TargetApi(value=19)
class al {
    public static void a(View view, int n2) {
        view.setAccessibilityLiveRegion(n2);
    }

    public static boolean a(View view) {
        return view.isLaidOut();
    }

    public static boolean b(View view) {
        return view.isAttachedToWindow();
    }
}

