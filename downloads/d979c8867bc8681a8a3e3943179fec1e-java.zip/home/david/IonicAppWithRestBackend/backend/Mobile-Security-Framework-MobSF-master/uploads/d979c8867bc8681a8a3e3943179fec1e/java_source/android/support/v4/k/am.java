/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.res.ColorStateList
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.view.View$OnApplyWindowInsetsListener
 *  android.view.ViewParent
 *  android.view.WindowInsets
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.k.ag;
import android.view.View;
import android.view.ViewParent;
import android.view.WindowInsets;

@TargetApi(value=21)
class am {
    private static ThreadLocal<Rect> a;

    private static Rect a() {
        Rect rect;
        if (a == null) {
            a = new ThreadLocal();
        }
        Rect rect2 = rect = a.get();
        if (rect == null) {
            rect2 = new Rect();
            a.set(rect2);
        }
        rect2.setEmpty();
        return rect2;
    }

    public static Object a(View view, Object object) {
        WindowInsets windowInsets = (WindowInsets)object;
        if ((view = view.onApplyWindowInsets(windowInsets)) != windowInsets) {
            object = new WindowInsets((WindowInsets)view);
        }
        return object;
    }

    public static String a(View view) {
        return view.getTransitionName();
    }

    public static void a(View view, float f2) {
        view.setElevation(f2);
    }

    /*
     * Enabled aggressive block sorting
     */
    static void a(View view, int n2) {
        boolean bl2;
        Rect rect = am.a();
        ViewParent viewParent = view.getParent();
        if (viewParent instanceof View) {
            View view2 = (View)viewParent;
            rect.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
            bl2 = !rect.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        } else {
            bl2 = false;
        }
        ag.a(view, n2);
        if (bl2 && rect.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View)viewParent).invalidate(rect);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static void a(View view, ColorStateList colorStateList) {
        view.setBackgroundTintList(colorStateList);
        if (Build.VERSION.SDK_INT == 21) {
            colorStateList = view.getBackground();
            boolean bl2 = view.getBackgroundTintList() != null && view.getBackgroundTintMode() != null;
            if (colorStateList == null) return;
            if (bl2) {
                if (colorStateList.isStateful()) {
                    colorStateList.setState(view.getDrawableState());
                }
                view.setBackground((Drawable)colorStateList);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static void a(View view, PorterDuff.Mode mode) {
        view.setBackgroundTintMode(mode);
        if (Build.VERSION.SDK_INT == 21) {
            mode = view.getBackground();
            boolean bl2 = view.getBackgroundTintList() != null && view.getBackgroundTintMode() != null;
            if (mode == null) return;
            if (bl2) {
                if (mode.isStateful()) {
                    mode.setState(view.getDrawableState());
                }
                view.setBackground((Drawable)mode);
            }
        }
    }

    public static void a(View view, final a a2) {
        if (a2 == null) {
            view.setOnApplyWindowInsetsListener(null);
            return;
        }
        view.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener(){

            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                return (WindowInsets)a2.a(view, (Object)windowInsets);
            }
        });
    }

    public static void b(View view) {
        view.requestApplyInsets();
    }

    /*
     * Enabled aggressive block sorting
     */
    static void b(View view, int n2) {
        boolean bl2;
        Rect rect = am.a();
        ViewParent viewParent = view.getParent();
        if (viewParent instanceof View) {
            View view2 = (View)viewParent;
            rect.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
            bl2 = !rect.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        } else {
            bl2 = false;
        }
        ag.b(view, n2);
        if (bl2 && rect.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View)viewParent).invalidate(rect);
        }
    }

    public static float c(View view) {
        return view.getElevation();
    }

    public static float d(View view) {
        return view.getTranslationZ();
    }

    static ColorStateList e(View view) {
        return view.getBackgroundTintList();
    }

    static PorterDuff.Mode f(View view) {
        return view.getBackgroundTintMode();
    }

    public static void g(View view) {
        view.stopNestedScroll();
    }

    public static float h(View view) {
        return view.getZ();
    }

    public static interface a {
        public Object a(View var1, Object var2);
    }

}

