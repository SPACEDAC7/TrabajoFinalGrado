/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.View
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.View;

@TargetApi(value=23)
class an {
    static void a(View view, int n2) {
        view.offsetTopAndBottom(n2);
    }

    public static void a(View view, int n2, int n3) {
        view.setScrollIndicators(n2, n3);
    }

    static void b(View view, int n2) {
        view.offsetLeftAndRight(n2);
    }
}

