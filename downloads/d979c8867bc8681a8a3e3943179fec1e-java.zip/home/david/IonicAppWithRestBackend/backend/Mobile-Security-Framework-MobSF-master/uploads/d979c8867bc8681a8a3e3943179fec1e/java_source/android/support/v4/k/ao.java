/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.ViewConfiguration
 */
package android.support.v4.k;

import android.os.Build;
import android.support.v4.k.ap;
import android.view.ViewConfiguration;

public final class ao {
    static final d a = Build.VERSION.SDK_INT >= 14 ? new c() : (Build.VERSION.SDK_INT >= 11 ? new b() : new a());

    public static boolean a(ViewConfiguration viewConfiguration) {
        return a.a(viewConfiguration);
    }

    static class a
    implements d {
        a() {
        }

        @Override
        public boolean a(ViewConfiguration viewConfiguration) {
            return true;
        }
    }

    static class b
    extends a {
        b() {
        }

        @Override
        public boolean a(ViewConfiguration viewConfiguration) {
            return false;
        }
    }

    static class c
    extends b {
        c() {
        }

        @Override
        public boolean a(ViewConfiguration viewConfiguration) {
            return ap.a(viewConfiguration);
        }
    }

    static interface d {
        public boolean a(ViewConfiguration var1);
    }

}

