/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.ViewConfiguration
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.ViewConfiguration;

@TargetApi(value=14)
class ap {
    static boolean a(ViewConfiguration viewConfiguration) {
        return viewConfiguration.hasPermanentMenuKey();
    }
}

