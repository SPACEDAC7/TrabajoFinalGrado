/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.ViewGroup
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.ViewGroup;

@TargetApi(value=11)
class ar {
    public static void a(ViewGroup viewGroup, boolean bl2) {
        viewGroup.setMotionEventSplittingEnabled(bl2);
    }
}

