/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.view.animation.Interpolator
 */
package android.support.v4.k;

import android.os.Build;
import android.support.v4.k.ae;
import android.support.v4.k.av;
import android.support.v4.k.aw;
import android.support.v4.k.ax;
import android.support.v4.k.ay;
import android.support.v4.k.ba;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

public final class au {
    static final g d;
    Runnable a = null;
    Runnable b = null;
    int c = -1;
    private WeakReference<View> e;

    static {
        int n2 = Build.VERSION.SDK_INT;
        d = n2 >= 21 ? new f() : (n2 >= 19 ? new e() : (n2 >= 18 ? new c() : (n2 >= 16 ? new d() : (n2 >= 14 ? new b() : new a()))));
    }

    au(View view) {
        this.e = new WeakReference<View>(view);
    }

    public long a() {
        View view = this.e.get();
        if (view != null) {
            return d.a(this, view);
        }
        return 0;
    }

    public au a(float f2) {
        View view = this.e.get();
        if (view != null) {
            d.a(this, view, f2);
        }
        return this;
    }

    public au a(long l2) {
        View view = this.e.get();
        if (view != null) {
            d.a(this, view, l2);
        }
        return this;
    }

    public au a(ay ay2) {
        View view = this.e.get();
        if (view != null) {
            d.a(this, view, ay2);
        }
        return this;
    }

    public au a(ba ba2) {
        View view = this.e.get();
        if (view != null) {
            d.a(this, view, ba2);
        }
        return this;
    }

    public au a(Interpolator interpolator) {
        View view = this.e.get();
        if (view != null) {
            d.a(this, view, interpolator);
        }
        return this;
    }

    public au b(float f2) {
        View view = this.e.get();
        if (view != null) {
            d.b(this, view, f2);
        }
        return this;
    }

    public au b(long l2) {
        View view = this.e.get();
        if (view != null) {
            d.b(this, view, l2);
        }
        return this;
    }

    public void b() {
        View view = this.e.get();
        if (view != null) {
            d.b(this, view);
        }
    }

    public au c(float f2) {
        View view = this.e.get();
        if (view != null) {
            d.c(this, view, f2);
        }
        return this;
    }

    public void c() {
        View view = this.e.get();
        if (view != null) {
            d.c(this, view);
        }
    }

    static class android.support.v4.k.au$a
    implements g {
        WeakHashMap<View, Runnable> a = null;

        android.support.v4.k.au$a() {
        }

        private void a(View view) {
            Runnable runnable;
            if (this.a != null && (runnable = this.a.get((Object)view)) != null) {
                view.removeCallbacks(runnable);
            }
        }

        private void e(au au2, View view) {
            Runnable runnable = null;
            if (this.a != null) {
                runnable = this.a.get((Object)view);
            }
            Runnable runnable2 = runnable;
            if (runnable == null) {
                runnable2 = new a(au2, view);
                if (this.a == null) {
                    this.a = new WeakHashMap();
                }
                this.a.put(view, runnable2);
            }
            view.removeCallbacks(runnable2);
            view.post(runnable2);
        }

        @Override
        public long a(au au2, View view) {
            return 0;
        }

        @Override
        public void a(au au2, View view, float f2) {
            this.e(au2, view);
        }

        @Override
        public void a(au au2, View view, long l2) {
        }

        @Override
        public void a(au au2, View view, ay ay2) {
            view.setTag(2113929216, (Object)ay2);
        }

        @Override
        public void a(au au2, View view, ba ba2) {
        }

        @Override
        public void a(au au2, View view, Interpolator interpolator) {
        }

        @Override
        public void b(au au2, View view) {
            this.e(au2, view);
        }

        @Override
        public void b(au au2, View view, float f2) {
            this.e(au2, view);
        }

        @Override
        public void b(au au2, View view, long l2) {
        }

        @Override
        public void c(au au2, View view) {
            this.a(view);
            this.d(au2, view);
        }

        @Override
        public void c(au au2, View view, float f2) {
            this.e(au2, view);
        }

        /*
         * Enabled aggressive block sorting
         */
        void d(au au2, View view) {
            Object object = view.getTag(2113929216);
            object = object instanceof ay ? (ay)object : null;
            Runnable runnable = au2.a;
            Runnable runnable2 = au2.b;
            au2.a = null;
            au2.b = null;
            if (runnable != null) {
                runnable.run();
            }
            if (object != null) {
                object.a(view);
                object.b(view);
            }
            if (runnable2 != null) {
                runnable2.run();
            }
            if (this.a != null) {
                this.a.remove((Object)view);
            }
        }

        class a
        implements Runnable {
            WeakReference<View> a;
            au b;

            a(au au2, View view) {
                this.a = new WeakReference<View>(view);
                this.b = au2;
            }

            @Override
            public void run() {
                View view = this.a.get();
                if (view != null) {
                    a.this.d(this.b, view);
                }
            }
        }

    }

    static class b
    extends android.support.v4.k.au$a {
        WeakHashMap<View, Integer> b = null;

        b() {
        }

        @Override
        public long a(au au2, View view) {
            return av.a(view);
        }

        @Override
        public void a(au au2, View view, float f2) {
            av.a(view, f2);
        }

        @Override
        public void a(au au2, View view, long l2) {
            av.a(view, l2);
        }

        @Override
        public void a(au au2, View view, ay ay2) {
            view.setTag(2113929216, (Object)ay2);
            av.a(view, new a(au2));
        }

        @Override
        public void a(au au2, View view, Interpolator interpolator) {
            av.a(view, interpolator);
        }

        @Override
        public void b(au au2, View view) {
            av.b(view);
        }

        @Override
        public void b(au au2, View view, float f2) {
            av.b(view, f2);
        }

        @Override
        public void b(au au2, View view, long l2) {
            av.b(view, l2);
        }

        @Override
        public void c(au au2, View view) {
            av.c(view);
        }

        @Override
        public void c(au au2, View view, float f2) {
            av.c(view, f2);
        }

        static class a
        implements ay {
            au a;
            boolean b;

            a(au au2) {
                this.a = au2;
            }

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            @Override
            public void a(View view) {
                Object object;
                this.b = false;
                if (this.a.c >= 0) {
                    ae.a(view, 2, null);
                }
                if (this.a.a != null) {
                    object = this.a.a;
                    this.a.a = null;
                    object.run();
                }
                if (!((object = view.getTag(2113929216)) instanceof ay)) return;
                if ((object = (ay)object) == null) return;
                object.a(view);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public void b(View view) {
                if (this.a.c >= 0) {
                    ae.a(view, this.a.c, null);
                    this.a.c = -1;
                }
                if (Build.VERSION.SDK_INT >= 16 || !this.b) {
                    Object object;
                    if (this.a.b != null) {
                        object = this.a.b;
                        this.a.b = null;
                        object.run();
                    }
                    object = (object = view.getTag(2113929216)) instanceof ay ? (ay)object : null;
                    if (object != null) {
                        object.b(view);
                    }
                    this.b = true;
                }
            }

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            @Override
            public void c(View view) {
                Object object = view.getTag(2113929216);
                if (!(object instanceof ay)) return;
                if ((object = (ay)object) == null) return;
                object.c(view);
            }
        }

    }

    static class c
    extends d {
        c() {
        }
    }

    static class d
    extends b {
        d() {
        }

        @Override
        public void a(au au2, View view, ay ay2) {
            aw.a(view, ay2);
        }
    }

    static class e
    extends c {
        e() {
        }

        @Override
        public void a(au au2, View view, ba ba2) {
            ax.a(view, ba2);
        }
    }

    static class f
    extends e {
        f() {
        }
    }

    static interface g {
        public long a(au var1, View var2);

        public void a(au var1, View var2, float var3);

        public void a(au var1, View var2, long var3);

        public void a(au var1, View var2, ay var3);

        public void a(au var1, View var2, ba var3);

        public void a(au var1, View var2, Interpolator var3);

        public void b(au var1, View var2);

        public void b(au var1, View var2, float var3);

        public void b(au var1, View var2, long var3);

        public void c(au var1, View var2);

        public void c(au var1, View var2, float var3);
    }

}

