/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.AnimatorListenerAdapter
 *  android.animation.TimeInterpolator
 *  android.annotation.TargetApi
 *  android.view.View
 *  android.view.ViewPropertyAnimator
 *  android.view.animation.Interpolator
 */
package android.support.v4.k;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.annotation.TargetApi;
import android.support.v4.k.ay;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.animation.Interpolator;

@TargetApi(value=14)
class av {
    public static long a(View view) {
        return view.animate().getDuration();
    }

    public static void a(View view, float f2) {
        view.animate().alpha(f2);
    }

    public static void a(View view, long l2) {
        view.animate().setDuration(l2);
    }

    public static void a(final View view, final ay ay2) {
        if (ay2 != null) {
            view.animate().setListener((Animator.AnimatorListener)new AnimatorListenerAdapter(){

                public void onAnimationCancel(Animator animator) {
                    ay2.c(view);
                }

                public void onAnimationEnd(Animator animator) {
                    ay2.b(view);
                }

                public void onAnimationStart(Animator animator) {
                    ay2.a(view);
                }
            });
            return;
        }
        view.animate().setListener(null);
    }

    public static void a(View view, Interpolator interpolator) {
        view.animate().setInterpolator((TimeInterpolator)interpolator);
    }

    public static void b(View view) {
        view.animate().cancel();
    }

    public static void b(View view, float f2) {
        view.animate().translationX(f2);
    }

    public static void b(View view, long l2) {
        view.animate().setStartDelay(l2);
    }

    public static void c(View view) {
        view.animate().start();
    }

    public static void c(View view, float f2) {
        view.animate().translationY(f2);
    }

}

