/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.AnimatorListenerAdapter
 *  android.annotation.TargetApi
 *  android.view.View
 *  android.view.ViewPropertyAnimator
 */
package android.support.v4.k;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.support.v4.k.ay;
import android.view.View;
import android.view.ViewPropertyAnimator;

@TargetApi(value=16)
class aw {
    public static void a(final View view, final ay ay2) {
        if (ay2 != null) {
            view.animate().setListener((Animator.AnimatorListener)new AnimatorListenerAdapter(){

                public void onAnimationCancel(Animator animator) {
                    ay2.c(view);
                }

                public void onAnimationEnd(Animator animator) {
                    ay2.b(view);
                }

                public void onAnimationStart(Animator animator) {
                    ay2.a(view);
                }
            });
            return;
        }
        view.animate().setListener(null);
    }

}

