/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.annotation.TargetApi
 *  android.view.View
 *  android.view.ViewPropertyAnimator
 */
package android.support.v4.k;

import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.support.v4.k.ba;
import android.view.View;
import android.view.ViewPropertyAnimator;

@TargetApi(value=19)
class ax {
    public static void a(final View view, final ba ba2) {
        ValueAnimator.AnimatorUpdateListener animatorUpdateListener = null;
        if (ba2 != null) {
            animatorUpdateListener = new ValueAnimator.AnimatorUpdateListener(){

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    ba2.a(view);
                }
            };
        }
        view.animate().setUpdateListener(animatorUpdateListener);
    }

}

