/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package android.support.v4.k;

import android.support.v4.k.ay;
import android.view.View;

public class az
implements ay {
    @Override
    public void a(View view) {
    }

    @Override
    public void b(View view) {
    }

    @Override
    public void c(View view) {
    }
}

