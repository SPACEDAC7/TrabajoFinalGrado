/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.accessibility.AccessibilityEvent
 */
package android.support.v4.k;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.k.a.l;
import android.support.v4.k.c;
import android.support.v4.k.d;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

public class b {
    private static final b a = Build.VERSION.SDK_INT >= 16 ? new c() : (Build.VERSION.SDK_INT >= 14 ? new a() : new d());
    private static final Object c = a.a();
    final Object b;

    public b() {
        this.b = a.a(this);
    }

    public l a(View view) {
        return a.a(c, view);
    }

    Object a() {
        return this.b;
    }

    public void a(View view, int n2) {
        a.a(c, view, n2);
    }

    public void a(View view, android.support.v4.k.a.c c2) {
        a.a(c, view, c2);
    }

    public void a(View view, AccessibilityEvent accessibilityEvent) {
        a.b(c, view, accessibilityEvent);
    }

    public boolean a(View view, int n2, Bundle bundle) {
        return a.a(c, view, n2, bundle);
    }

    public boolean a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return a.a(c, viewGroup, view, accessibilityEvent);
    }

    public void b(View view, AccessibilityEvent accessibilityEvent) {
        a.c(c, view, accessibilityEvent);
    }

    public void c(View view, AccessibilityEvent accessibilityEvent) {
        a.d(c, view, accessibilityEvent);
    }

    public boolean d(View view, AccessibilityEvent accessibilityEvent) {
        return a.a(c, view, accessibilityEvent);
    }

    static class a
    extends d {
        a() {
        }

        @Override
        public Object a() {
            return android.support.v4.k.c.a();
        }

        @Override
        public Object a(final b b2) {
            return android.support.v4.k.c.a(new c.a(){

                @Override
                public void a(View view, int n2) {
                    b2.a(view, n2);
                }

                @Override
                public void a(View view, Object object) {
                    b2.a(view, new android.support.v4.k.a.c(object));
                }

                @Override
                public boolean a(View view, AccessibilityEvent accessibilityEvent) {
                    return b2.d(view, accessibilityEvent);
                }

                @Override
                public boolean a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
                    return b2.a(viewGroup, view, accessibilityEvent);
                }

                @Override
                public void b(View view, AccessibilityEvent accessibilityEvent) {
                    b2.a(view, accessibilityEvent);
                }

                @Override
                public void c(View view, AccessibilityEvent accessibilityEvent) {
                    b2.b(view, accessibilityEvent);
                }

                @Override
                public void d(View view, AccessibilityEvent accessibilityEvent) {
                    b2.c(view, accessibilityEvent);
                }
            });
        }

        @Override
        public void a(Object object, View view, int n2) {
            android.support.v4.k.c.a(object, view, n2);
        }

        @Override
        public void a(Object object, View view, android.support.v4.k.a.c c2) {
            android.support.v4.k.c.a(object, view, c2.a());
        }

        @Override
        public boolean a(Object object, View view, AccessibilityEvent accessibilityEvent) {
            return android.support.v4.k.c.a(object, view, accessibilityEvent);
        }

        @Override
        public boolean a(Object object, ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return android.support.v4.k.c.a(object, viewGroup, view, accessibilityEvent);
        }

        @Override
        public void b(Object object, View view, AccessibilityEvent accessibilityEvent) {
            android.support.v4.k.c.b(object, view, accessibilityEvent);
        }

        @Override
        public void c(Object object, View view, AccessibilityEvent accessibilityEvent) {
            android.support.v4.k.c.c(object, view, accessibilityEvent);
        }

        @Override
        public void d(Object object, View view, AccessibilityEvent accessibilityEvent) {
            android.support.v4.k.c.d(object, view, accessibilityEvent);
        }

    }

    static interface b {
        public l a(Object var1, View var2);

        public Object a();

        public Object a(b var1);

        public void a(Object var1, View var2, int var3);

        public void a(Object var1, View var2, android.support.v4.k.a.c var3);

        public boolean a(Object var1, View var2, int var3, Bundle var4);

        public boolean a(Object var1, View var2, AccessibilityEvent var3);

        public boolean a(Object var1, ViewGroup var2, View var3, AccessibilityEvent var4);

        public void b(Object var1, View var2, AccessibilityEvent var3);

        public void c(Object var1, View var2, AccessibilityEvent var3);

        public void d(Object var1, View var2, AccessibilityEvent var3);
    }

    static class c
    extends a {
        c() {
        }

        @Override
        public l a(Object object, View view) {
            if ((object = android.support.v4.k.d.a(object, view)) != null) {
                return new l(object);
            }
            return null;
        }

        @Override
        public Object a(final b b2) {
            return android.support.v4.k.d.a(new d.a(){

                @Override
                public Object a(View object) {
                    if ((object = b2.a((View)object)) != null) {
                        return object.a();
                    }
                    return null;
                }

                @Override
                public void a(View view, int n2) {
                    b2.a(view, n2);
                }

                @Override
                public void a(View view, Object object) {
                    b2.a(view, new android.support.v4.k.a.c(object));
                }

                @Override
                public boolean a(View view, int n2, Bundle bundle) {
                    return b2.a(view, n2, bundle);
                }

                @Override
                public boolean a(View view, AccessibilityEvent accessibilityEvent) {
                    return b2.d(view, accessibilityEvent);
                }

                @Override
                public boolean a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
                    return b2.a(viewGroup, view, accessibilityEvent);
                }

                @Override
                public void b(View view, AccessibilityEvent accessibilityEvent) {
                    b2.a(view, accessibilityEvent);
                }

                @Override
                public void c(View view, AccessibilityEvent accessibilityEvent) {
                    b2.b(view, accessibilityEvent);
                }

                @Override
                public void d(View view, AccessibilityEvent accessibilityEvent) {
                    b2.c(view, accessibilityEvent);
                }
            });
        }

        @Override
        public boolean a(Object object, View view, int n2, Bundle bundle) {
            return android.support.v4.k.d.a(object, view, n2, bundle);
        }

    }

    static class d
    implements b {
        d() {
        }

        @Override
        public l a(Object object, View view) {
            return null;
        }

        @Override
        public Object a() {
            return null;
        }

        @Override
        public Object a(b b2) {
            return null;
        }

        @Override
        public void a(Object object, View view, int n2) {
        }

        @Override
        public void a(Object object, View view, android.support.v4.k.a.c c2) {
        }

        @Override
        public boolean a(Object object, View view, int n2, Bundle bundle) {
            return false;
        }

        @Override
        public boolean a(Object object, View view, AccessibilityEvent accessibilityEvent) {
            return false;
        }

        @Override
        public boolean a(Object object, ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return true;
        }

        @Override
        public void b(Object object, View view, AccessibilityEvent accessibilityEvent) {
        }

        @Override
        public void c(Object object, View view, AccessibilityEvent accessibilityEvent) {
        }

        @Override
        public void d(Object object, View view, AccessibilityEvent accessibilityEvent) {
        }
    }

}

