/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package android.support.v4.k;

import android.view.View;

public interface ba {
    public void a(View var1);
}

