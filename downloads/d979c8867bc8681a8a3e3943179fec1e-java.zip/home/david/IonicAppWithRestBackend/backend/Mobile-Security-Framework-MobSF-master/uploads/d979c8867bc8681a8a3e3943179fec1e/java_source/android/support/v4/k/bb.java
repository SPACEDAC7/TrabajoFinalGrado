/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package android.support.v4.k;

import android.os.Build;
import android.support.v4.k.bc;
import android.support.v4.k.bd;

public class bb {
    private static final d a;
    private final Object b;

    static {
        int n2 = Build.VERSION.SDK_INT;
        a = n2 >= 21 ? new b() : (n2 >= 20 ? new a() : new c());
    }

    bb(Object object) {
        this.b = object;
    }

    static bb a(Object object) {
        if (object == null) {
            return null;
        }
        return new bb(object);
    }

    static Object a(bb bb2) {
        if (bb2 == null) {
            return null;
        }
        return bb2.b;
    }

    public int a() {
        return a.b(this.b);
    }

    public bb a(int n2, int n3, int n4, int n5) {
        return a.a(this.b, n2, n3, n4, n5);
    }

    public int b() {
        return a.d(this.b);
    }

    public int c() {
        return a.c(this.b);
    }

    public int d() {
        return a.a(this.b);
    }

    public boolean e() {
        return a.e(this.b);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (bb)object;
        if (this.b != null) return this.b.equals(object.b);
        if (object.b == null) return true;
        return false;
    }

    public int hashCode() {
        if (this.b == null) {
            return 0;
        }
        return this.b.hashCode();
    }

    private static class a
    extends c {
        a() {
        }

        @Override
        public int a(Object object) {
            return bc.a(object);
        }

        @Override
        public bb a(Object object, int n2, int n3, int n4, int n5) {
            return new bb(bc.a(object, n2, n3, n4, n5));
        }

        @Override
        public int b(Object object) {
            return bc.b(object);
        }

        @Override
        public int c(Object object) {
            return bc.c(object);
        }

        @Override
        public int d(Object object) {
            return bc.d(object);
        }
    }

    private static class b
    extends a {
        b() {
        }

        @Override
        public boolean e(Object object) {
            return bd.a(object);
        }
    }

    private static class c
    implements d {
        c() {
        }

        @Override
        public int a(Object object) {
            return 0;
        }

        @Override
        public bb a(Object object, int n2, int n3, int n4, int n5) {
            return null;
        }

        @Override
        public int b(Object object) {
            return 0;
        }

        @Override
        public int c(Object object) {
            return 0;
        }

        @Override
        public int d(Object object) {
            return 0;
        }

        @Override
        public boolean e(Object object) {
            return false;
        }
    }

    private static interface d {
        public int a(Object var1);

        public bb a(Object var1, int var2, int var3, int var4, int var5);

        public int b(Object var1);

        public int c(Object var1);

        public int d(Object var1);

        public boolean e(Object var1);
    }

}

