/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.WindowInsets
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.WindowInsets;

@TargetApi(value=20)
class bc {
    public static int a(Object object) {
        return ((WindowInsets)object).getSystemWindowInsetBottom();
    }

    public static Object a(Object object, int n2, int n3, int n4, int n5) {
        return ((WindowInsets)object).replaceSystemWindowInsets(n2, n3, n4, n5);
    }

    public static int b(Object object) {
        return ((WindowInsets)object).getSystemWindowInsetLeft();
    }

    public static int c(Object object) {
        return ((WindowInsets)object).getSystemWindowInsetRight();
    }

    public static int d(Object object) {
        return ((WindowInsets)object).getSystemWindowInsetTop();
    }
}

