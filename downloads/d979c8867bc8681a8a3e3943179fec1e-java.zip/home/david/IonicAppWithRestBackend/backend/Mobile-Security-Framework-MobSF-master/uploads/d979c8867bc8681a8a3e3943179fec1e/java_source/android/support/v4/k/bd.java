/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.WindowInsets
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.WindowInsets;

@TargetApi(value=21)
class bd {
    public static boolean a(Object object) {
        return ((WindowInsets)object).isConsumed();
    }
}

