/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.Rect
 *  android.view.Gravity
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.graphics.Rect;
import android.view.Gravity;

@TargetApi(value=17)
class g {
    public static int a(int n2, int n3) {
        return Gravity.getAbsoluteGravity((int)n2, (int)n3);
    }

    public static void a(int n2, int n3, int n4, Rect rect, Rect rect2, int n5) {
        Gravity.apply((int)n2, (int)n3, (int)n4, (Rect)rect, (Rect)rect2, (int)n5);
    }
}

