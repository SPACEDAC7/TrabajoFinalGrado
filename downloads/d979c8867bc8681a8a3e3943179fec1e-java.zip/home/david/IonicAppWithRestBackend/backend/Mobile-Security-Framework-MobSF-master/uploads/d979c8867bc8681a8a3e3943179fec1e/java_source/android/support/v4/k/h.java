/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.KeyEvent
 */
package android.support.v4.k;

import android.os.Build;
import android.support.v4.k.i;
import android.view.KeyEvent;

public final class h {
    static final c a = Build.VERSION.SDK_INT >= 11 ? new b() : new a();

    public static boolean a(KeyEvent keyEvent) {
        return a.b(keyEvent.getMetaState());
    }

    public static boolean b(KeyEvent keyEvent) {
        return a.a(keyEvent);
    }

    static class a
    implements c {
        a() {
        }

        public int a(int n2) {
            if ((n2 & 192) != 0) {
                n2 |= 1;
            }
            int n3 = n2;
            if ((n2 & 48) != 0) {
                n3 = n2 | 2;
            }
            return n3 & 247;
        }

        @Override
        public boolean a(KeyEvent keyEvent) {
            return false;
        }

        @Override
        public boolean b(int n2) {
            if ((this.a(n2) & 247) == 0) {
                return true;
            }
            return false;
        }
    }

    static class b
    extends a {
        b() {
        }

        @Override
        public int a(int n2) {
            return i.a(n2);
        }

        @Override
        public boolean a(KeyEvent keyEvent) {
            return i.a(keyEvent);
        }

        @Override
        public boolean b(int n2) {
            return i.b(n2);
        }
    }

    static interface c {
        public boolean a(KeyEvent var1);

        public boolean b(int var1);
    }

}

