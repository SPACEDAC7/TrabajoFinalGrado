/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.KeyEvent
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.KeyEvent;

@TargetApi(value=11)
class i {
    public static int a(int n2) {
        return KeyEvent.normalizeMetaState((int)n2);
    }

    public static boolean a(KeyEvent keyEvent) {
        return keyEvent.isCtrlPressed();
    }

    public static boolean b(int n2) {
        return KeyEvent.metaStateHasNoModifiers((int)n2);
    }
}

