/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.LayoutInflater
 */
package android.support.v4.k;

import android.os.Build;
import android.support.v4.k.k;
import android.support.v4.k.l;
import android.support.v4.k.m;
import android.support.v4.k.n;
import android.view.LayoutInflater;

public final class j {
    static final a a;

    static {
        int n2 = Build.VERSION.SDK_INT;
        a = n2 >= 21 ? new d() : (n2 >= 11 ? new c() : new b());
    }

    public static n a(LayoutInflater layoutInflater) {
        return a.a(layoutInflater);
    }

    public static void a(LayoutInflater layoutInflater, n n2) {
        a.a(layoutInflater, n2);
    }

    static interface a {
        public n a(LayoutInflater var1);

        public void a(LayoutInflater var1, n var2);
    }

    static class b
    implements a {
        b() {
        }

        @Override
        public n a(LayoutInflater layoutInflater) {
            return k.a(layoutInflater);
        }

        @Override
        public void a(LayoutInflater layoutInflater, n n2) {
            k.a(layoutInflater, n2);
        }
    }

    static class c
    extends b {
        c() {
        }

        @Override
        public void a(LayoutInflater layoutInflater, n n2) {
            l.a(layoutInflater, n2);
        }
    }

    static class d
    extends c {
        d() {
        }

        @Override
        public void a(LayoutInflater layoutInflater, n n2) {
            m.a(layoutInflater, n2);
        }
    }

}

