/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.LayoutInflater
 *  android.view.LayoutInflater$Factory
 *  android.view.View
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.content.Context;
import android.support.v4.k.n;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;

@TargetApi(value=9)
class k {
    static n a(LayoutInflater layoutInflater) {
        if ((layoutInflater = layoutInflater.getFactory()) instanceof a) {
            return ((a)layoutInflater).a;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    static void a(LayoutInflater layoutInflater, n object) {
        object = object != null ? new a((n)object) : null;
        layoutInflater.setFactory((LayoutInflater.Factory)object);
    }

    static class a
    implements LayoutInflater.Factory {
        final n a;

        a(n n2) {
            this.a = n2;
        }

        public View onCreateView(String string, Context context, AttributeSet attributeSet) {
            return this.a.a(null, string, context, attributeSet);
        }

        public String toString() {
            return this.getClass().getName() + "{" + this.a + "}";
        }
    }

}

