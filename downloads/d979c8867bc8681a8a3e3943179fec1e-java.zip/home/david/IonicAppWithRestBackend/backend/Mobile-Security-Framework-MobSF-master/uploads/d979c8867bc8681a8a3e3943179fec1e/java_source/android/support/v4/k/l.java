/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.LayoutInflater$Factory
 *  android.view.LayoutInflater$Factory2
 *  android.view.View
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.content.Context;
import android.support.v4.k.k;
import android.support.v4.k.n;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import java.lang.reflect.Field;

@TargetApi(value=11)
class l {
    private static Field a;
    private static boolean b;

    /*
     * Enabled aggressive block sorting
     */
    static void a(LayoutInflater layoutInflater, n object) {
        object = object != null ? new a((n)object) : null;
        layoutInflater.setFactory2((LayoutInflater.Factory2)object);
        LayoutInflater.Factory factory = layoutInflater.getFactory();
        if (factory instanceof LayoutInflater.Factory2) {
            l.a(layoutInflater, (LayoutInflater.Factory2)factory);
            return;
        }
        l.a(layoutInflater, (LayoutInflater.Factory2)object);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static void a(LayoutInflater layoutInflater, LayoutInflater.Factory2 factory2) {
        if (!b) {
            try {
                a = LayoutInflater.class.getDeclaredField("mFactory2");
                a.setAccessible(true);
            }
            catch (NoSuchFieldException var2_3) {
                Log.e((String)"LayoutInflaterCompatHC", (String)("forceSetFactory2 Could not find field 'mFactory2' on class " + LayoutInflater.class.getName() + "; inflation may have unexpected results."), (Throwable)var2_3);
            }
            b = true;
        }
        if (a == null) return;
        try {
            a.set((Object)layoutInflater, (Object)factory2);
            return;
        }
        catch (IllegalAccessException var1_2) {
            Log.e((String)"LayoutInflaterCompatHC", (String)("forceSetFactory2 could not set the Factory2 on LayoutInflater " + (Object)layoutInflater + "; inflation may have unexpected results."), (Throwable)var1_2);
            return;
        }
    }

    static class a
    extends k.a
    implements LayoutInflater.Factory2 {
        a(n n2) {
            super(n2);
        }

        public View onCreateView(View view, String string, Context context, AttributeSet attributeSet) {
            return this.a.a(view, string, context, attributeSet);
        }
    }

}

