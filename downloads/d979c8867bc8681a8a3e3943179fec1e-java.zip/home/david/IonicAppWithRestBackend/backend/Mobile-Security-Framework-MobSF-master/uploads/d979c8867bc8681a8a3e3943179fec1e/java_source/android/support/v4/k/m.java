/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.LayoutInflater
 *  android.view.LayoutInflater$Factory2
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.support.v4.k.l;
import android.support.v4.k.n;
import android.view.LayoutInflater;

@TargetApi(value=21)
class m {
    /*
     * Enabled aggressive block sorting
     */
    static void a(LayoutInflater layoutInflater, n object) {
        object = object != null ? new l.a((n)object) : null;
        layoutInflater.setFactory2((LayoutInflater.Factory2)object);
    }
}

