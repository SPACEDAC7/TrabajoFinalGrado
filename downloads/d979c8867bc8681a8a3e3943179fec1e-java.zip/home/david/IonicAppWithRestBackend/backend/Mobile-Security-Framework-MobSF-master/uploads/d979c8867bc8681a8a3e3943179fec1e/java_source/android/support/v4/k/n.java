/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 */
package android.support.v4.k;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public interface n {
    public View a(View var1, String var2, Context var3, AttributeSet var4);
}

