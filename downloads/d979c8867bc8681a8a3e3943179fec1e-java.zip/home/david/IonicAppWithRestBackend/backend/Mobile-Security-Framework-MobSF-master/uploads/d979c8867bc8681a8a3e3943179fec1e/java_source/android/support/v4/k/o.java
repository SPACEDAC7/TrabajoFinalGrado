/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.ViewGroup
 *  android.view.ViewGroup$MarginLayoutParams
 */
package android.support.v4.k;

import android.os.Build;
import android.support.v4.k.p;
import android.view.ViewGroup;

public final class o {
    static final a a = Build.VERSION.SDK_INT >= 17 ? new c() : new b();

    public static int a(ViewGroup.MarginLayoutParams marginLayoutParams) {
        return a.a(marginLayoutParams);
    }

    public static int b(ViewGroup.MarginLayoutParams marginLayoutParams) {
        return a.b(marginLayoutParams);
    }

    static interface a {
        public int a(ViewGroup.MarginLayoutParams var1);

        public int b(ViewGroup.MarginLayoutParams var1);
    }

    static class b
    implements a {
        b() {
        }

        @Override
        public int a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            return marginLayoutParams.leftMargin;
        }

        @Override
        public int b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            return marginLayoutParams.rightMargin;
        }
    }

    static class c
    implements a {
        c() {
        }

        @Override
        public int a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            return p.a(marginLayoutParams);
        }

        @Override
        public int b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            return p.b(marginLayoutParams);
        }
    }

}

