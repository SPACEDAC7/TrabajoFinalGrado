/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.ViewGroup
 *  android.view.ViewGroup$MarginLayoutParams
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.ViewGroup;

@TargetApi(value=17)
class p {
    public static int a(ViewGroup.MarginLayoutParams marginLayoutParams) {
        return marginLayoutParams.getMarginStart();
    }

    public static int b(ViewGroup.MarginLayoutParams marginLayoutParams) {
        return marginLayoutParams.getMarginEnd();
    }
}

