/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 *  android.view.MenuItem
 *  android.view.View
 */
package android.support.v4.k;

import android.os.Build;
import android.support.v4.k.r;
import android.support.v4.k.s;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

public final class q {
    static final d a = Build.VERSION.SDK_INT >= 14 ? new c() : (Build.VERSION.SDK_INT >= 11 ? new b() : new a());

    public static MenuItem a(MenuItem menuItem, android.support.v4.k.e e2) {
        if (menuItem instanceof android.support.v4.e.a.b) {
            return ((android.support.v4.e.a.b)menuItem).a(e2);
        }
        Log.w((String)"MenuItemCompat", (String)"setActionProvider: item does not implement SupportMenuItem; ignoring");
        return menuItem;
    }

    public static MenuItem a(MenuItem menuItem, View view) {
        if (menuItem instanceof android.support.v4.e.a.b) {
            return ((android.support.v4.e.a.b)menuItem).setActionView(view);
        }
        return a.a(menuItem, view);
    }

    public static View a(MenuItem menuItem) {
        if (menuItem instanceof android.support.v4.e.a.b) {
            return ((android.support.v4.e.a.b)menuItem).getActionView();
        }
        return a.a(menuItem);
    }

    public static void a(MenuItem menuItem, int n2) {
        if (menuItem instanceof android.support.v4.e.a.b) {
            ((android.support.v4.e.a.b)menuItem).setShowAsAction(n2);
            return;
        }
        a.a(menuItem, n2);
    }

    public static MenuItem b(MenuItem menuItem, int n2) {
        if (menuItem instanceof android.support.v4.e.a.b) {
            return ((android.support.v4.e.a.b)menuItem).setActionView(n2);
        }
        return a.b(menuItem, n2);
    }

    public static boolean b(MenuItem menuItem) {
        if (menuItem instanceof android.support.v4.e.a.b) {
            return ((android.support.v4.e.a.b)menuItem).expandActionView();
        }
        return a.b(menuItem);
    }

    public static boolean c(MenuItem menuItem) {
        if (menuItem instanceof android.support.v4.e.a.b) {
            return ((android.support.v4.e.a.b)menuItem).collapseActionView();
        }
        return a.c(menuItem);
    }

    public static boolean d(MenuItem menuItem) {
        if (menuItem instanceof android.support.v4.e.a.b) {
            return ((android.support.v4.e.a.b)menuItem).isActionViewExpanded();
        }
        return a.d(menuItem);
    }

    static class a
    implements d {
        a() {
        }

        @Override
        public MenuItem a(MenuItem menuItem, View view) {
            return menuItem;
        }

        @Override
        public View a(MenuItem menuItem) {
            return null;
        }

        @Override
        public void a(MenuItem menuItem, int n2) {
        }

        @Override
        public MenuItem b(MenuItem menuItem, int n2) {
            return menuItem;
        }

        @Override
        public boolean b(MenuItem menuItem) {
            return false;
        }

        @Override
        public boolean c(MenuItem menuItem) {
            return false;
        }

        @Override
        public boolean d(MenuItem menuItem) {
            return false;
        }
    }

    static class b
    implements d {
        b() {
        }

        @Override
        public MenuItem a(MenuItem menuItem, View view) {
            return r.a(menuItem, view);
        }

        @Override
        public View a(MenuItem menuItem) {
            return r.a(menuItem);
        }

        @Override
        public void a(MenuItem menuItem, int n2) {
            r.a(menuItem, n2);
        }

        @Override
        public MenuItem b(MenuItem menuItem, int n2) {
            return r.b(menuItem, n2);
        }

        @Override
        public boolean b(MenuItem menuItem) {
            return false;
        }

        @Override
        public boolean c(MenuItem menuItem) {
            return false;
        }

        @Override
        public boolean d(MenuItem menuItem) {
            return false;
        }
    }

    static class c
    extends b {
        c() {
        }

        @Override
        public boolean b(MenuItem menuItem) {
            return s.a(menuItem);
        }

        @Override
        public boolean c(MenuItem menuItem) {
            return s.b(menuItem);
        }

        @Override
        public boolean d(MenuItem menuItem) {
            return s.c(menuItem);
        }
    }

    static interface d {
        public MenuItem a(MenuItem var1, View var2);

        public View a(MenuItem var1);

        public void a(MenuItem var1, int var2);

        public MenuItem b(MenuItem var1, int var2);

        public boolean b(MenuItem var1);

        public boolean c(MenuItem var1);

        public boolean d(MenuItem var1);
    }

    public static interface e {
        public boolean a(MenuItem var1);

        public boolean b(MenuItem var1);
    }

}

