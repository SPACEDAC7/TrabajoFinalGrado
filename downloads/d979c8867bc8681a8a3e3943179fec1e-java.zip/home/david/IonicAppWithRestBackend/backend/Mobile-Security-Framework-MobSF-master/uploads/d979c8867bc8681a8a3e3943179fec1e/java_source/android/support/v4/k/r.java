/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.MenuItem
 *  android.view.View
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.MenuItem;
import android.view.View;

@TargetApi(value=11)
class r {
    public static MenuItem a(MenuItem menuItem, View view) {
        return menuItem.setActionView(view);
    }

    public static View a(MenuItem menuItem) {
        return menuItem.getActionView();
    }

    public static void a(MenuItem menuItem, int n2) {
        menuItem.setShowAsAction(n2);
    }

    public static MenuItem b(MenuItem menuItem, int n2) {
        return menuItem.setActionView(n2);
    }
}

