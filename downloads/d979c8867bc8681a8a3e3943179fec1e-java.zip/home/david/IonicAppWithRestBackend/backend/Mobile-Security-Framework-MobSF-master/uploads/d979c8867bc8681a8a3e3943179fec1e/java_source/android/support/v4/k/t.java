/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.MotionEvent
 */
package android.support.v4.k;

import android.os.Build;
import android.support.v4.k.u;
import android.view.MotionEvent;

public final class t {
    static final d a = Build.VERSION.SDK_INT >= 14 ? new c() : (Build.VERSION.SDK_INT >= 12 ? new b() : new a());

    public static float a(MotionEvent motionEvent, int n2) {
        return a.a(motionEvent, n2);
    }

    public static int a(MotionEvent motionEvent) {
        return motionEvent.getAction() & 255;
    }

    public static int b(MotionEvent motionEvent) {
        return (motionEvent.getAction() & 65280) >> 8;
    }

    static class a
    implements d {
        a() {
        }

        @Override
        public float a(MotionEvent motionEvent, int n2) {
            return 0.0f;
        }
    }

    static class b
    extends a {
        b() {
        }

        @Override
        public float a(MotionEvent motionEvent, int n2) {
            return u.a(motionEvent, n2);
        }
    }

    private static class c
    extends b {
        c() {
        }
    }

    static interface d {
        public float a(MotionEvent var1, int var2);
    }

}

