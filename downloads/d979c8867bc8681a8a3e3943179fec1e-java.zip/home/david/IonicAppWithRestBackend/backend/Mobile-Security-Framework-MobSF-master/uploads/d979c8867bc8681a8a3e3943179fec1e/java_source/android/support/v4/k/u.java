/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.view.MotionEvent
 */
package android.support.v4.k;

import android.annotation.TargetApi;
import android.view.MotionEvent;

@TargetApi(value=12)
class u {
    static float a(MotionEvent motionEvent, int n2) {
        return motionEvent.getAxisValue(n2);
    }
}

