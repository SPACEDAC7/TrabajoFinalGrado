/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.k;

public interface v {
    public void stopNestedScroll();
}

