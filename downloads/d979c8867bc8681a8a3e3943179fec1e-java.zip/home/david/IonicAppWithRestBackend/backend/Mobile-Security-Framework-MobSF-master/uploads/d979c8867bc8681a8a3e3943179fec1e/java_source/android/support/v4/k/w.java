/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewParent
 */
package android.support.v4.k;

import android.support.v4.k.ae;
import android.support.v4.k.as;
import android.view.View;
import android.view.ViewParent;

public class w {
    private final View a;
    private ViewParent b;
    private boolean c;
    private int[] d;

    public w(View view) {
        this.a = view;
    }

    public void a(boolean bl2) {
        if (this.c) {
            ae.C(this.a);
        }
        this.c = bl2;
    }

    public boolean a() {
        return this.c;
    }

    public boolean a(float f2, float f3) {
        if (this.a() && this.b != null) {
            return as.a(this.b, this.a, f2, f3);
        }
        return false;
    }

    public boolean a(float f2, float f3, boolean bl2) {
        if (this.a() && this.b != null) {
            return as.a(this.b, this.a, f2, f3, bl2);
        }
        return false;
    }

    public boolean a(int n2) {
        if (this.b()) {
            return true;
        }
        if (this.a()) {
            View view = this.a;
            for (ViewParent viewParent = this.a.getParent(); viewParent != null; viewParent = viewParent.getParent()) {
                if (as.a(viewParent, view, this.a, n2)) {
                    this.b = viewParent;
                    as.b(viewParent, view, this.a, n2);
                    return true;
                }
                if (!(viewParent instanceof View)) continue;
                view = (View)viewParent;
            }
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean a(int n2, int n3, int n4, int n5, int[] arrn) {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (!this.a()) return bl3;
        bl3 = bl2;
        if (this.b == null) return bl3;
        if (n2 != 0 || n3 != 0 || n4 != 0 || n5 != 0) {
            int n6;
            int n7;
            if (arrn != null) {
                this.a.getLocationInWindow(arrn);
                n7 = arrn[0];
                n6 = arrn[1];
            } else {
                n6 = 0;
                n7 = 0;
            }
            as.a(this.b, this.a, n2, n3, n4, n5);
            if (arrn == null) return true;
            this.a.getLocationInWindow(arrn);
            arrn[0] = arrn[0] - n7;
            arrn[1] = arrn[1] - n6;
            return true;
        }
        bl3 = bl2;
        if (arrn == null) return bl3;
        arrn[0] = 0;
        arrn[1] = 0;
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean a(int n2, int n3, int[] arrn, int[] arrn2) {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (!this.a()) return bl3;
        bl3 = bl2;
        if (this.b == null) return bl3;
        if (n2 != 0 || n3 != 0) {
            int n4;
            int n5;
            if (arrn2 != null) {
                this.a.getLocationInWindow(arrn2);
                n4 = arrn2[0];
                n5 = arrn2[1];
            } else {
                n5 = 0;
                n4 = 0;
            }
            int[] arrn3 = arrn;
            if (arrn == null) {
                if (this.d == null) {
                    this.d = new int[2];
                }
                arrn3 = this.d;
            }
            arrn3[0] = 0;
            arrn3[1] = 0;
            as.a(this.b, this.a, n2, n3, arrn3);
            if (arrn2 != null) {
                this.a.getLocationInWindow(arrn2);
                arrn2[0] = arrn2[0] - n4;
                arrn2[1] = arrn2[1] - n5;
            }
            if (arrn3[0] != 0) return true;
            bl3 = bl2;
            if (arrn3[1] == 0) return bl3;
            return true;
        }
        bl3 = bl2;
        if (arrn2 == null) return bl3;
        arrn2[0] = 0;
        arrn2[1] = 0;
        return false;
    }

    public boolean b() {
        if (this.b != null) {
            return true;
        }
        return false;
    }

    public void c() {
        if (this.b != null) {
            as.a(this.b, this.a);
            this.b = null;
        }
    }
}

