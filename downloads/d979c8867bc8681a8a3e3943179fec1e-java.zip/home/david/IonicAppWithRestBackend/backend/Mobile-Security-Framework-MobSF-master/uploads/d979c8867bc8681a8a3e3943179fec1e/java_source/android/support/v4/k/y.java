/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewGroup
 */
package android.support.v4.k;

import android.view.View;
import android.view.ViewGroup;

public class y {
    private final ViewGroup a;
    private int b;

    public y(ViewGroup viewGroup) {
        this.a = viewGroup;
    }

    public int a() {
        return this.b;
    }

    public void a(View view) {
        this.b = 0;
    }

    public void a(View view, View view2, int n2) {
        this.b = n2;
    }
}

