/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package android.support.v4.k;

import android.support.v4.k.bb;
import android.view.View;

public interface z {
    public bb a(View var1, bb var2);
}

