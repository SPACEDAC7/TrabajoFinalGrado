/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.view.MotionEvent
 *  android.view.VelocityTracker
 *  android.view.View
 *  android.view.ViewConfiguration
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  android.view.animation.Interpolator
 */
package android.support.v4.widget;

import android.content.Context;
import android.content.res.Resources;
import android.support.v4.k.ac;
import android.support.v4.k.t;
import android.support.v4.widget.v;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.Interpolator;
import java.util.Arrays;

public class ae {
    private static final Interpolator v = new Interpolator(){

        public float getInterpolation(float f2) {
            return f2 * (f2 * f2 * f2 * (f2 -= 1.0f)) + 1.0f;
        }
    };
    private int a;
    private int b;
    private int c = -1;
    private float[] d;
    private float[] e;
    private float[] f;
    private float[] g;
    private int[] h;
    private int[] i;
    private int[] j;
    private int k;
    private VelocityTracker l;
    private float m;
    private float n;
    private int o;
    private int p;
    private v q;
    private final a r;
    private View s;
    private boolean t;
    private final ViewGroup u;
    private final Runnable w;

    private ae(Context context, ViewGroup viewGroup, a a2) {
        this.w = new Runnable(){

            @Override
            public void run() {
                ae.this.c(0);
            }
        };
        if (viewGroup == null) {
            throw new IllegalArgumentException("Parent view may not be null");
        }
        if (a2 == null) {
            throw new IllegalArgumentException("Callback may not be null");
        }
        this.u = viewGroup;
        this.r = a2;
        viewGroup = ViewConfiguration.get((Context)context);
        this.o = (int)(context.getResources().getDisplayMetrics().density * 20.0f + 0.5f);
        this.b = viewGroup.getScaledTouchSlop();
        this.m = viewGroup.getScaledMaximumFlingVelocity();
        this.n = viewGroup.getScaledMinimumFlingVelocity();
        this.q = v.a(context, v);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private float a(float f2, float f3, float f4) {
        float f5 = Math.abs(f2);
        if (f5 < f3) {
            return 0.0f;
        }
        if (f5 <= f4) return f2;
        f3 = f4;
        if (f2 > 0.0f) return f3;
        return - f4;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int a(int n2, int n3, int n4) {
        if (n2 == 0) {
            return 0;
        }
        int n5 = this.u.getWidth();
        int n6 = n5 / 2;
        float f2 = Math.min(1.0f, (float)Math.abs(n2) / (float)n5);
        float f3 = n6;
        float f4 = n6;
        f2 = this.b(f2);
        if ((n3 = Math.abs(n3)) > 0) {
            n2 = Math.round(Math.abs((f2 * f4 + f3) / (float)n3) * 1000.0f) * 4;
            do {
                return Math.min(n2, 600);
                break;
            } while (true);
        }
        n2 = (int)(((float)Math.abs(n2) / (float)n4 + 1.0f) * 256.0f);
        return Math.min(n2, 600);
    }

    /*
     * Enabled aggressive block sorting
     */
    private int a(View view, int n2, int n3, int n4, int n5) {
        n4 = this.b(n4, (int)this.n, (int)this.m);
        n5 = this.b(n5, (int)this.n, (int)this.m);
        int n6 = Math.abs(n2);
        int n7 = Math.abs(n3);
        int n8 = Math.abs(n4);
        int n9 = Math.abs(n5);
        int n10 = n8 + n9;
        int n11 = n6 + n7;
        float f2 = n4 != 0 ? (float)n8 / (float)n10 : (float)n6 / (float)n11;
        float f3 = n5 != 0 ? (float)n9 / (float)n10 : (float)n7 / (float)n11;
        n2 = this.a(n2, n4, this.r.b(view));
        n3 = this.a(n3, n5, this.r.a(view));
        float f4 = n2;
        return (int)(f3 * (float)n3 + f2 * f4);
    }

    public static ae a(ViewGroup object, float f2, a a2) {
        object = ae.a((ViewGroup)object, a2);
        object.b = (int)((float)object.b * (1.0f / f2));
        return object;
    }

    public static ae a(ViewGroup viewGroup, a a2) {
        return new ae(viewGroup.getContext(), viewGroup, a2);
    }

    private void a(float f2, float f3) {
        this.t = true;
        this.r.a(this.s, f2, f3);
        this.t = false;
        if (this.a == 1) {
            this.c(0);
        }
    }

    private void a(float f2, float f3, int n2) {
        this.f(n2);
        float[] arrf = this.d;
        this.f[n2] = f2;
        arrf[n2] = f2;
        arrf = this.e;
        this.g[n2] = f3;
        arrf[n2] = f3;
        this.h[n2] = this.e((int)f2, (int)f3);
        this.k |= 1 << n2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private boolean a(float f2, float f3, int n2, int n3) {
        f2 = Math.abs(f2);
        f3 = Math.abs(f3);
        if ((this.h[n2] & n3) != n3) return false;
        if ((this.p & n3) == 0) return false;
        if ((this.j[n2] & n3) == n3) return false;
        if ((this.i[n2] & n3) == n3) return false;
        if (f2 <= (float)this.b && f3 <= (float)this.b) {
            return false;
        }
        if (f2 < f3 * 0.5f && this.r.b(n3)) {
            int[] arrn = this.j;
            arrn[n2] = arrn[n2] | n3;
            return false;
        }
        if ((this.i[n2] & n3) != 0) return false;
        if (f2 <= (float)this.b) return false;
        return true;
    }

    private boolean a(int n2, int n3, int n4, int n5) {
        int n6 = this.s.getLeft();
        int n7 = this.s.getTop();
        if ((n2 -= n6) == 0 && (n3 -= n7) == 0) {
            this.q.h();
            this.c(0);
            return false;
        }
        n4 = this.a(this.s, n2, n3, n4, n5);
        this.q.a(n6, n7, n2, n3, n4);
        this.c(2);
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean a(View view, float f2, float f3) {
        boolean bl2 = true;
        if (view == null) {
            return false;
        }
        boolean bl3 = this.r.b(view) > 0;
        if (this.r.a(view) <= 0) return false;
        boolean bl4 = true;
        if (bl3 && bl4) {
            if (f2 * f2 + f3 * f3 > (float)(this.b * this.b)) return bl2;
            return false;
        }
        if (bl3) {
            if (Math.abs(f2) > (float)this.b) return bl2;
            return false;
        }
        if (!bl4) {
            return false;
        }
        if (Math.abs(f3) > (float)this.b) return bl2;
        return false;
    }

    private float b(float f2) {
        return (float)Math.sin((float)((double)(f2 - 0.5f) * 0.4712389167638204));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int b(int n2, int n3, int n4) {
        int n5 = Math.abs(n2);
        if (n5 < n3) {
            return 0;
        }
        if (n5 <= n4) return n2;
        n3 = n4;
        if (n2 > 0) return n3;
        return - n4;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(float f2, float f3, int n2) {
        int n3 = 1;
        if (!this.a(f2, f3, n2, 1)) {
            n3 = 0;
        }
        int n4 = n3;
        if (this.a(f3, f2, n2, 4)) {
            n4 = n3 | 4;
        }
        n3 = n4;
        if (this.a(f2, f3, n2, 2)) {
            n3 = n4 | 2;
        }
        n4 = n3;
        if (this.a(f3, f2, n2, 8)) {
            n4 = n3 | 8;
        }
        if (n4 != 0) {
            int[] arrn = this.i;
            arrn[n2] = arrn[n2] | n4;
            this.r.b(n4, n2);
        }
    }

    private void b(int n2, int n3, int n4, int n5) {
        int n6 = this.s.getLeft();
        int n7 = this.s.getTop();
        if (n4 != 0) {
            n2 = this.r.b(this.s, n2, n4);
            android.support.v4.k.ae.f(this.s, n2 - n6);
        }
        if (n5 != 0) {
            n3 = this.r.a(this.s, n3, n5);
            android.support.v4.k.ae.e(this.s, n3 - n7);
        }
        if (n4 != 0 || n5 != 0) {
            this.r.a(this.s, n2, n3, n2 - n6, n3 - n7);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void c(MotionEvent motionEvent) {
        int n2 = motionEvent.getPointerCount();
        int n3 = 0;
        while (n3 < n2) {
            int n4 = motionEvent.getPointerId(n3);
            if (this.g(n4)) {
                float f2 = motionEvent.getX(n3);
                float f3 = motionEvent.getY(n3);
                this.f[n4] = f2;
                this.g[n4] = f3;
            }
            ++n3;
        }
    }

    private int e(int n2, int n3) {
        int n4 = 0;
        if (n2 < this.u.getLeft() + this.o) {
            n4 = 1;
        }
        int n5 = n4;
        if (n3 < this.u.getTop() + this.o) {
            n5 = n4 | 4;
        }
        n4 = n5;
        if (n2 > this.u.getRight() - this.o) {
            n4 = n5 | 2;
        }
        n2 = n4;
        if (n3 > this.u.getBottom() - this.o) {
            n2 = n4 | 8;
        }
        return n2;
    }

    private void e(int n2) {
        if (this.d == null || !this.b(n2)) {
            return;
        }
        this.d[n2] = 0.0f;
        this.e[n2] = 0.0f;
        this.f[n2] = 0.0f;
        this.g[n2] = 0.0f;
        this.h[n2] = 0;
        this.i[n2] = 0;
        this.j[n2] = 0;
        this.k &= ~ (1 << n2);
    }

    private void f() {
        if (this.d == null) {
            return;
        }
        Arrays.fill(this.d, 0.0f);
        Arrays.fill(this.e, 0.0f);
        Arrays.fill(this.f, 0.0f);
        Arrays.fill(this.g, 0.0f);
        Arrays.fill(this.h, 0);
        Arrays.fill(this.i, 0);
        Arrays.fill(this.j, 0);
        this.k = 0;
    }

    private void f(int n2) {
        if (this.d == null || this.d.length <= n2) {
            float[] arrf = new float[n2 + 1];
            float[] arrf2 = new float[n2 + 1];
            float[] arrf3 = new float[n2 + 1];
            float[] arrf4 = new float[n2 + 1];
            int[] arrn = new int[n2 + 1];
            int[] arrn2 = new int[n2 + 1];
            int[] arrn3 = new int[n2 + 1];
            if (this.d != null) {
                System.arraycopy(this.d, 0, arrf, 0, this.d.length);
                System.arraycopy(this.e, 0, arrf2, 0, this.e.length);
                System.arraycopy(this.f, 0, arrf3, 0, this.f.length);
                System.arraycopy(this.g, 0, arrf4, 0, this.g.length);
                System.arraycopy(this.h, 0, arrn, 0, this.h.length);
                System.arraycopy(this.i, 0, arrn2, 0, this.i.length);
                System.arraycopy(this.j, 0, arrn3, 0, this.j.length);
            }
            this.d = arrf;
            this.e = arrf2;
            this.f = arrf3;
            this.g = arrf4;
            this.h = arrn;
            this.i = arrn2;
            this.j = arrn3;
        }
    }

    private void g() {
        this.l.computeCurrentVelocity(1000, this.m);
        this.a(this.a(ac.a(this.l, this.c), this.n, this.m), this.a(ac.b(this.l, this.c), this.n, this.m));
    }

    private boolean g(int n2) {
        if (!this.b(n2)) {
            Log.e((String)"ViewDragHelper", (String)("Ignoring pointerId=" + n2 + " because ACTION_DOWN was not received " + "for this pointer before ACTION_MOVE. It likely happened because " + " ViewDragHelper did not receive all the events in the event stream."));
            return false;
        }
        return true;
    }

    public int a() {
        return this.a;
    }

    public void a(float f2) {
        this.n = f2;
    }

    public void a(int n2) {
        this.p = n2;
    }

    public void a(View view, int n2) {
        if (view.getParent() != this.u) {
            throw new IllegalArgumentException("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (" + (Object)this.u + ")");
        }
        this.s = view;
        this.c = n2;
        this.r.b(view, n2);
        this.c(1);
    }

    public boolean a(int n2, int n3) {
        if (!this.t) {
            throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
        }
        return this.a(n2, n3, (int)ac.a(this.l, this.c), (int)ac.b(this.l, this.c));
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean a(MotionEvent motionEvent) {
        int n2 = t.a(motionEvent);
        int n3 = t.b(motionEvent);
        if (n2 == 0) {
            this.e();
        }
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        this.l.addMovement(motionEvent);
        switch (n2) {
            case 0: {
                float f2 = motionEvent.getX();
                float f3 = motionEvent.getY();
                n3 = motionEvent.getPointerId(0);
                this.a(f2, f3, n3);
                motionEvent = this.d((int)f2, (int)f3);
                if (motionEvent == this.s && this.a == 2) {
                    this.b((View)motionEvent, n3);
                }
                if ((this.p & (n2 = this.h[n3])) == 0) break;
                this.r.a(n2 & this.p, n3);
                break;
            }
            case 5: {
                n2 = motionEvent.getPointerId(n3);
                float f4 = motionEvent.getX(n3);
                float f5 = motionEvent.getY(n3);
                this.a(f4, f5, n2);
                if (this.a == 0) {
                    n3 = this.h[n2];
                    if ((this.p & n3) == 0) break;
                    this.r.a(n3 & this.p, n2);
                    break;
                }
                if (this.a != 2 || (motionEvent = this.d((int)f4, (int)f5)) != this.s) break;
                this.b((View)motionEvent, n2);
                break;
            }
            case 2: {
                if (this.d == null || this.e == null) break;
                int n4 = motionEvent.getPointerCount();
                for (n3 = 0; n3 < n4; ++n3) {
                    int n5 = motionEvent.getPointerId(n3);
                    if (!this.g(n5)) continue;
                    float f6 = motionEvent.getX(n3);
                    float f7 = motionEvent.getY(n3);
                    float f8 = f6 - this.d[n5];
                    float f9 = f7 - this.e[n5];
                    View view = this.d((int)f6, (int)f7);
                    n2 = view != null && this.a(view, f8, f9) ? 1 : 0;
                    if (n2 != 0) {
                        int n6 = view.getLeft();
                        int n7 = (int)f8;
                        n7 = this.r.b(view, n7 + n6, (int)f8);
                        int n8 = view.getTop();
                        int n9 = (int)f9;
                        n9 = this.r.a(view, n9 + n8, (int)f9);
                        int n10 = this.r.b(view);
                        int n11 = this.r.a(view);
                        if ((n10 == 0 || n10 > 0 && n7 == n6) && (n11 == 0 || n11 > 0 && n9 == n8)) break;
                    }
                    this.b(f8, f9, n5);
                    if (this.a == 1 || n2 != 0 && this.b(view, n5)) break;
                }
                this.c(motionEvent);
                break;
            }
            case 6: {
                this.e(motionEvent.getPointerId(n3));
                break;
            }
            case 1: 
            case 3: {
                this.e();
            }
        }
        if (this.a == 1) {
            return true;
        }
        return false;
    }

    public boolean a(View view, int n2, int n3) {
        this.s = view;
        this.c = -1;
        boolean bl2 = this.a(n2, n3, 0, 0);
        if (!bl2 && this.a == 0 && this.s != null) {
            this.s = null;
        }
        return bl2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean a(boolean bl2) {
        if (this.a == 2) {
            boolean bl3 = this.q.g();
            int n2 = this.q.b();
            int n3 = this.q.c();
            int n4 = n2 - this.s.getLeft();
            int n5 = n3 - this.s.getTop();
            if (n4 != 0) {
                android.support.v4.k.ae.f(this.s, n4);
            }
            if (n5 != 0) {
                android.support.v4.k.ae.e(this.s, n5);
            }
            if (n4 != 0 || n5 != 0) {
                this.r.a(this.s, n2, n3, n4, n5);
            }
            if (bl3 && n2 == this.q.d() && n3 == this.q.e()) {
                this.q.h();
                bl3 = false;
            }
            if (!bl3) {
                if (bl2) {
                    this.u.post(this.w);
                } else {
                    this.c(0);
                }
            }
        }
        if (this.a == 2) {
            return true;
        }
        return false;
    }

    public int b() {
        return this.o;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void b(MotionEvent var1_1) {
        block19 : {
            var6_2 = 0;
            var7_3 = 0;
            var9_4 = t.a(var1_1);
            var8_5 = t.b(var1_1);
            if (var9_4 == 0) {
                this.e();
            }
            if (this.l == null) {
                this.l = VelocityTracker.obtain();
            }
            this.l.addMovement(var1_1);
            switch (var9_4) {
                default: {
                    return;
                }
                case 0: {
                    var2_6 = var1_1.getX();
                    var3_11 = var1_1.getY();
                    var6_2 = var1_1.getPointerId(0);
                    var1_1 = this.d((int)var2_6, (int)var3_11);
                    this.a(var2_6, var3_11, var6_2);
                    this.b((View)var1_1, var6_2);
                    var7_3 = this.h[var6_2];
                    if ((this.p & var7_3) == 0) return;
                    this.r.a(var7_3 & this.p, var6_2);
                    return;
                }
                case 5: {
                    var6_2 = var1_1.getPointerId(var8_5);
                    var2_7 = var1_1.getX(var8_5);
                    var3_12 = var1_1.getY(var8_5);
                    this.a(var2_7, var3_12, var6_2);
                    if (this.a == 0) {
                        this.b(this.d((int)var2_7, (int)var3_12), var6_2);
                        var7_3 = this.h[var6_2];
                        if ((this.p & var7_3) == 0) return;
                        this.r.a(var7_3 & this.p, var6_2);
                        return;
                    }
                    if (this.c((int)var2_7, (int)var3_12) == false) return;
                    this.b(this.s, var6_2);
                    return;
                }
                case 2: {
                    if (this.a == 1) {
                        if (this.g(this.c) == false) return;
                        var6_2 = var1_1.findPointerIndex(this.c);
                        var2_8 = var1_1.getX(var6_2);
                        var3_13 = var1_1.getY(var6_2);
                        var6_2 = (int)(var2_8 - this.f[this.c]);
                        var7_3 = (int)(var3_13 - this.g[this.c]);
                        this.b(this.s.getLeft() + var6_2, this.s.getTop() + var7_3, var6_2, var7_3);
                        this.c(var1_1);
                        return;
                    }
                    var8_5 = var1_1.getPointerCount();
                    for (var6_2 = var7_3; var6_2 < var8_5; ++var6_2) {
                        var7_3 = var1_1.getPointerId(var6_2);
                        if (!this.g(var7_3)) continue;
                        var2_9 = var1_1.getX(var6_2);
                        var3_14 = var1_1.getY(var6_2);
                        var4_16 = var2_9 - this.d[var7_3];
                        var5_17 = var3_14 - this.e[var7_3];
                        this.b(var4_16, var5_17, var7_3);
                        if (this.a == 1 || this.a(var10_18 = this.d((int)var2_9, (int)var3_14), var4_16, var5_17) && this.b(var10_18, var7_3)) break;
                    }
                    this.c(var1_1);
                    return;
                }
                case 6: {
                    var7_3 = var1_1.getPointerId(var8_5);
                    if (this.a == 1 && var7_3 == this.c) {
                        var8_5 = var1_1.getPointerCount();
                        while (var6_2 < var8_5) {
                            var9_4 = var1_1.getPointerId(var6_2);
                            if (var9_4 != this.c && this.d((int)(var2_10 = var1_1.getX(var6_2)), (int)(var3_15 = var1_1.getY(var6_2))) == this.s && this.b(this.s, var9_4)) {
                                var6_2 = this.c;
                                break block19;
                            }
                            ++var6_2;
                        }
                        break;
                    }
                    ** GOTO lbl89
                }
                case 1: {
                    if (this.a == 1) {
                        this.g();
                    }
                    this.e();
                    return;
                }
                case 3: {
                    if (this.a == 1) {
                        this.a(0.0f, 0.0f);
                    }
                    this.e();
                    return;
                }
            }
            var6_2 = -1;
        }
        if (var6_2 == -1) {
            this.g();
        }
lbl89: // 4 sources:
        this.e(var7_3);
    }

    public boolean b(int n2) {
        if ((this.k & 1 << n2) != 0) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean b(int n2, int n3) {
        boolean bl2 = true;
        if (!this.b(n3)) {
            return false;
        }
        boolean bl3 = (n2 & 1) == 1;
        n2 = (n2 & 2) == 2 ? 1 : 0;
        float f2 = this.f[n3] - this.d[n3];
        float f3 = this.g[n3] - this.e[n3];
        if (bl3 && n2 != 0) {
            if (f2 * f2 + f3 * f3 > (float)(this.b * this.b)) return bl2;
            return false;
        }
        if (bl3) {
            if (Math.abs(f2) > (float)this.b) return bl2;
            return false;
        }
        if (n2 == 0) {
            return false;
        }
        if (Math.abs(f3) > (float)this.b) return bl2;
        return false;
    }

    boolean b(View view, int n2) {
        if (view == this.s && this.c == n2) {
            return true;
        }
        if (view != null && this.r.a(view, n2)) {
            this.c = n2;
            this.a(view, n2);
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean b(View view, int n2, int n3) {
        if (view == null || n2 < view.getLeft() || n2 >= view.getRight() || n3 < view.getTop() || n3 >= view.getBottom()) {
            return false;
        }
        return true;
    }

    public View c() {
        return this.s;
    }

    void c(int n2) {
        this.u.removeCallbacks(this.w);
        if (this.a != n2) {
            this.a = n2;
            this.r.a(n2);
            if (this.a == 0) {
                this.s = null;
            }
        }
    }

    public boolean c(int n2, int n3) {
        return this.b(this.s, n2, n3);
    }

    public int d() {
        return this.b;
    }

    public View d(int n2, int n3) {
        for (int i2 = this.u.getChildCount() - 1; i2 >= 0; --i2) {
            View view = this.u.getChildAt(this.r.c(i2));
            if (n2 < view.getLeft() || n2 >= view.getRight() || n3 < view.getTop() || n3 >= view.getBottom()) continue;
            return view;
        }
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean d(int n2) {
        boolean bl2 = false;
        int n3 = this.d.length;
        int n4 = 0;
        do {
            boolean bl3 = bl2;
            if (n4 >= n3) return bl3;
            if (this.b(n2, n4)) {
                return true;
            }
            ++n4;
        } while (true);
    }

    public void e() {
        this.c = -1;
        this.f();
        if (this.l != null) {
            this.l.recycle();
            this.l = null;
        }
    }

    public static abstract class a {
        public int a(View view) {
            return 0;
        }

        public int a(View view, int n2, int n3) {
            return 0;
        }

        public void a(int n2) {
        }

        public void a(int n2, int n3) {
        }

        public void a(View view, float f2, float f3) {
        }

        public void a(View view, int n2, int n3, int n4, int n5) {
        }

        public abstract boolean a(View var1, int var2);

        public int b(View view) {
            return 0;
        }

        public int b(View view, int n2, int n3) {
            return 0;
        }

        public void b(int n2, int n3) {
        }

        public void b(View view, int n2) {
        }

        public boolean b(int n2) {
            return false;
        }

        public int c(int n2) {
            return n2;
        }
    }

}

