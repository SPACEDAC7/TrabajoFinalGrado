/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.ListView
 */
package android.support.v4.widget;

import android.support.v4.widget.a;
import android.support.v4.widget.n;
import android.view.View;
import android.widget.ListView;

public class m
extends a {
    private final ListView f;

    public m(ListView listView) {
        super((View)listView);
        this.f = listView;
    }

    @Override
    public void a(int n2, int n3) {
        n.a(this.f, n3);
    }

    @Override
    public boolean e(int n2) {
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean f(int n2) {
        ListView listView = this.f;
        int n3 = listView.getCount();
        if (n3 == 0) return false;
        int n4 = listView.getChildCount();
        int n5 = listView.getFirstVisiblePosition();
        if (n2 > 0) {
            if (n5 + n4 >= n3 && listView.getChildAt(n4 - 1).getBottom() <= listView.getHeight()) return false;
            return true;
        }
        if (n2 >= 0) {
            return false;
        }
        if (n5 <= 0 && listView.getChildAt(0).getTop() >= 0) return false;
        return true;
    }
}

