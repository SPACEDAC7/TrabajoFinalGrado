/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 */
package android.support.v4.widget;

import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.f;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public abstract class u
extends f {
    private int j;
    private int k;
    private LayoutInflater l;

    public u(Context context, int n2, Cursor cursor, int n3) {
        super(context, cursor, n3);
        this.k = n2;
        this.j = n2;
        this.l = (LayoutInflater)context.getSystemService("layout_inflater");
    }

    @Deprecated
    public u(Context context, int n2, Cursor cursor, boolean bl2) {
        super(context, cursor, bl2);
        this.k = n2;
        this.j = n2;
        this.l = (LayoutInflater)context.getSystemService("layout_inflater");
    }

    @Override
    public View a(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.l.inflate(this.j, viewGroup, false);
    }

    @Override
    public View b(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.l.inflate(this.k, viewGroup, false);
    }
}

