/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Message
 *  android.preference.Preference
 *  android.preference.PreferenceManager
 *  android.preference.PreferenceScreen
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnKeyListener
 *  android.view.ViewGroup
 *  android.widget.ListView
 */
package com.a.a.a;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.support.v4.b.m;
import android.support.v4.b.n;
import android.support.v4.g.a;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import com.a.a.a.b;

public abstract class a
extends m
implements b.a {
    private PreferenceManager a;
    private ListView b;
    private boolean c;
    private boolean d;
    private Handler e;
    private final Runnable f;
    private View.OnKeyListener g;

    public a() {
        this.e = new Handler(){

            public void handleMessage(Message message) {
                switch (message.what) {
                    default: {
                        return;
                    }
                    case 1: 
                }
                a.this.ab();
            }
        };
        this.f = new Runnable(){

            @Override
            public void run() {
                a.this.b.focusableViewAvailable((View)a.this.b);
            }
        };
        this.g = new View.OnKeyListener(){

            public boolean onKey(View view, int n2, KeyEvent keyEvent) {
                if (a.this.b.getSelectedItem() instanceof Preference) {
                    a.this.b.getSelectedView();
                }
                return false;
            }
        };
    }

    private void Z() {
        if (this.a == null) {
            throw new RuntimeException("This should be called after super.onCreate.");
        }
    }

    private void aa() {
        if (this.e.hasMessages(1)) {
            return;
        }
        this.e.obtainMessage(1).sendToTarget();
    }

    private void ab() {
        PreferenceScreen preferenceScreen = this.a();
        if (preferenceScreen != null) {
            preferenceScreen.bind(this.Y());
        }
    }

    private void ac() {
        if (this.b != null) {
            return;
        }
        View view = this.q();
        if (view == null) {
            throw new IllegalStateException("Content view not yet created");
        }
        if (!((view = view.findViewById(16908298)) instanceof ListView)) {
            throw new RuntimeException("Content has view with id attribute 'android.R.id.list' that is not a ListView class");
        }
        this.b = (ListView)view;
        if (this.b == null) {
            throw new RuntimeException("Your content must have a ListView whose id attribute is 'android.R.id.list'");
        }
        this.b.setOnKeyListener(this.g);
        this.e.post(this.f);
    }

    public ListView Y() {
        this.ac();
        return this.b;
    }

    public Preference a(CharSequence charSequence) {
        if (this.a == null) {
            return null;
        }
        return this.a.findPreference(charSequence);
    }

    public PreferenceScreen a() {
        return b.a(this.a);
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(a.a.preference_list_fragment, viewGroup, false);
    }

    @Override
    public void a(int n2, int n3, Intent intent) {
        super.a(n2, n3, intent);
        b.a(this.a, n2, n3, intent);
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.a = b.a(this.j(), 100);
        b.a(this.a, this);
    }

    public void a(PreferenceScreen preferenceScreen) {
        if (b.a(this.a, preferenceScreen) && preferenceScreen != null) {
            this.c = true;
            if (this.d) {
                this.aa();
            }
        }
    }

    @Override
    public boolean a(PreferenceScreen preferenceScreen, Preference preference) {
        if (this.j() instanceof a) {
            return ((a)((Object)this.j())).a(this, preference);
        }
        return false;
    }

    @Override
    public void c() {
        super.c();
        b.a(this.a, (b.a)this);
    }

    @Override
    public void d() {
        super.d();
        b.b(this.a);
        b.a(this.a, null);
    }

    public void d(int n2) {
        this.Z();
        this.a(b.a(this.a, this.j(), n2, this.a()));
    }

    @Override
    public void d(Bundle bundle) {
        PreferenceScreen preferenceScreen;
        super.d(bundle);
        if (this.c) {
            this.ab();
        }
        this.d = true;
        if (bundle != null && (bundle = bundle.getBundle("android:preferences")) != null && (preferenceScreen = this.a()) != null) {
            preferenceScreen.restoreHierarchyState(bundle);
        }
    }

    @Override
    public void e() {
        this.b = null;
        this.e.removeCallbacks(this.f);
        this.e.removeMessages(1);
        super.e();
    }

    @Override
    public void e(Bundle bundle) {
        super.e(bundle);
        PreferenceScreen preferenceScreen = this.a();
        if (preferenceScreen != null) {
            Bundle bundle2 = new Bundle();
            preferenceScreen.saveHierarchyState(bundle2);
            bundle.putBundle("android:preferences", bundle2);
        }
    }

    @Override
    public void t() {
        super.t();
        b.c(this.a);
    }

    public static interface a {
        public boolean a(a var1, Preference var2);
    }

}

