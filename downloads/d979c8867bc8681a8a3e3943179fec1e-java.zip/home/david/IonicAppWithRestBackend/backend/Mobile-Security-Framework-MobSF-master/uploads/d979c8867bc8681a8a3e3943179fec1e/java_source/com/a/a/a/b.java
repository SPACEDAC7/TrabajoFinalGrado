/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.preference.Preference
 *  android.preference.PreferenceManager
 *  android.preference.PreferenceScreen
 *  android.util.Log
 */
package com.a.a.a;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.util.Log;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class b {
    private static final String a = b.class.getSimpleName();

    static PreferenceManager a(Activity activity, int n2) {
        try {
            Constructor constructor = PreferenceManager.class.getDeclaredConstructor(Activity.class, Integer.TYPE);
            constructor.setAccessible(true);
            activity = (PreferenceManager)constructor.newInstance(new Object[]{activity, n2});
            return activity;
        }
        catch (Exception var0_1) {
            Log.w((String)a, (String)"Couldn't call constructor PreferenceManager by reflection", (Throwable)var0_1);
            return null;
        }
    }

    static PreferenceScreen a(PreferenceManager preferenceManager) {
        try {
            Method method = PreferenceManager.class.getDeclaredMethod("getPreferenceScreen", new Class[0]);
            method.setAccessible(true);
            preferenceManager = (PreferenceScreen)method.invoke((Object)preferenceManager, new Object[0]);
            return preferenceManager;
        }
        catch (Exception var0_1) {
            Log.w((String)a, (String)"Couldn't call PreferenceManager.getPreferenceScreen by reflection", (Throwable)var0_1);
            return null;
        }
    }

    static PreferenceScreen a(PreferenceManager preferenceManager, Activity activity, int n2, PreferenceScreen preferenceScreen) {
        try {
            Method method = PreferenceManager.class.getDeclaredMethod("inflateFromResource", Context.class, Integer.TYPE, PreferenceScreen.class);
            method.setAccessible(true);
            preferenceManager = (PreferenceScreen)method.invoke((Object)preferenceManager, new Object[]{activity, n2, preferenceScreen});
            return preferenceManager;
        }
        catch (Exception var0_1) {
            Log.w((String)a, (String)"Couldn't call PreferenceManager.inflateFromResource by reflection", (Throwable)var0_1);
            return null;
        }
    }

    static void a(PreferenceManager preferenceManager, int n2, int n3, Intent intent) {
        try {
            Method method = PreferenceManager.class.getDeclaredMethod("dispatchActivityResult", Integer.TYPE, Integer.TYPE, Intent.class);
            method.setAccessible(true);
            method.invoke((Object)preferenceManager, new Object[]{n2, n3, intent});
            return;
        }
        catch (Exception var0_1) {
            Log.w((String)a, (String)"Couldn't call PreferenceManager.dispatchActivityResult by reflection", (Throwable)var0_1);
            return;
        }
    }

    static void a(PreferenceManager preferenceManager, com.a.a.a.a a2) {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void a(PreferenceManager preferenceManager, a object) {
        try {
            Field field = PreferenceManager.class.getDeclaredField("mOnPreferenceTreeClickListener");
            field.setAccessible(true);
            if (object != null) {
                ClassLoader classLoader = field.getType().getClassLoader();
                Class class_ = field.getType();
                object = new InvocationHandler((a)object){
                    final /* synthetic */ a a;

                    @Override
                    public Object invoke(Object object, Method method, Object[] arrobject) {
                        if (method.getName().equals("onPreferenceTreeClick")) {
                            return this.a.a((PreferenceScreen)arrobject[0], (Preference)arrobject[1]);
                        }
                        return null;
                    }
                };
                field.set((Object)preferenceManager, Proxy.newProxyInstance(classLoader, new Class[]{class_}, (InvocationHandler)object));
                return;
            }
            field.set((Object)preferenceManager, null);
            return;
        }
        catch (Exception var0_1) {
            Log.w((String)a, (String)"Couldn't set PreferenceManager.mOnPreferenceTreeClickListener by reflection", (Throwable)var0_1);
            return;
        }
    }

    static boolean a(PreferenceManager preferenceManager, PreferenceScreen preferenceScreen) {
        try {
            Method method = PreferenceManager.class.getDeclaredMethod("setPreferences", PreferenceScreen.class);
            method.setAccessible(true);
            boolean bl2 = (Boolean)method.invoke((Object)preferenceManager, new Object[]{preferenceScreen});
            return bl2;
        }
        catch (Exception var0_1) {
            Log.w((String)a, (String)"Couldn't call PreferenceManager.setPreferences by reflection", (Throwable)var0_1);
            return false;
        }
    }

    static void b(PreferenceManager preferenceManager) {
        try {
            Method method = PreferenceManager.class.getDeclaredMethod("dispatchActivityStop", new Class[0]);
            method.setAccessible(true);
            method.invoke((Object)preferenceManager, new Object[0]);
            return;
        }
        catch (Exception var0_1) {
            Log.w((String)a, (String)"Couldn't call PreferenceManager.dispatchActivityStop by reflection", (Throwable)var0_1);
            return;
        }
    }

    static void c(PreferenceManager preferenceManager) {
        try {
            Method method = PreferenceManager.class.getDeclaredMethod("dispatchActivityDestroy", new Class[0]);
            method.setAccessible(true);
            method.invoke((Object)preferenceManager, new Object[0]);
            return;
        }
        catch (Exception var0_1) {
            Log.w((String)a, (String)"Couldn't call PreferenceManager.dispatchActivityDestroy by reflection", (Throwable)var0_1);
            return;
        }
    }

    static interface a {
        public boolean a(PreferenceScreen var1, Preference var2);
    }

}

