/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.c.b;
import com.dropbox.core.o;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

final class a<T> {
    private final T a;
    private o b;

    public a(T t2, o o2) {
        if (t2 == null) {
            throw new NullPointerException("error");
        }
        this.a = t2;
        this.b = o2;
    }

    public T a() {
        return this.a;
    }

    public o b() {
        return this.b;
    }

    static final class a<T>
    extends b<a<T>> {
        private b<T> a;

        public a(b<T> b2) {
            this.a = b2;
        }

        public a<T> a(JsonParser jsonParser) {
            o o2 = null;
            a.e(jsonParser);
            a a2 = null;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                String string = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("error".equals(string)) {
                    a2 = this.a.b(jsonParser);
                    continue;
                }
                if ("user_message".equals(string)) {
                    o2 = o.a.b(jsonParser);
                    continue;
                }
                a.i(jsonParser);
            }
            if (a2 == null) {
                throw new JsonParseException(jsonParser, "Required field \"error\" missing.");
            }
            a2 = new a<Object>(a2, o2);
            a.f(jsonParser);
            return a2;
        }

        @Override
        public void a(a<T> a2, JsonGenerator jsonGenerator) {
            throw new UnsupportedOperationException("Error wrapper serialization not supported.");
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.a(jsonParser);
        }
    }

}

