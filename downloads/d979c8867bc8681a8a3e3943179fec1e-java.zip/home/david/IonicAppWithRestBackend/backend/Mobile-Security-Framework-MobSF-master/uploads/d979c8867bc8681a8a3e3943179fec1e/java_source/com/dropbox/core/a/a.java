/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.a;

import com.dropbox.core.d.a;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

public abstract class a {
    public static final long a = TimeUnit.SECONDS.toMillis(20);
    public static final long b = TimeUnit.MINUTES.toMillis(2);

    public abstract c a(String var1, Iterable<a> var2);

    public static final class a {
        private final String a;
        private final String b;

        public a(String string, String string2) {
            this.a = string;
            this.b = string2;
        }

        public String a() {
            return this.a;
        }

        public String b() {
            return this.b;
        }
    }

    public static final class b {
        private final int a;
        private final InputStream b;
        private final Map<String, List<String>> c;

        public b(int n2, InputStream inputStream, Map<String, ? extends List<String>> map) {
            this.a = n2;
            this.b = inputStream;
            this.c = b.a(map);
        }

        private static final Map<String, List<String>> a(Map<String, ? extends List<String>> object) {
            TreeMap treeMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
            for (Map.Entry entry : object.entrySet()) {
                if (entry.getKey() == null || ((String)entry.getKey()).trim().length() == 0) continue;
                treeMap.put(entry.getKey(), Collections.unmodifiableList((List)entry.getValue()));
            }
            return Collections.unmodifiableMap(treeMap);
        }

        public int a() {
            return this.a;
        }

        public InputStream b() {
            return this.b;
        }

        public Map<String, List<String>> c() {
            return this.c;
        }
    }

    public static abstract class c {
        public abstract OutputStream a();

        public void a(InputStream inputStream) {
            OutputStream outputStream = this.a();
            try {
                com.dropbox.core.d.a.a(inputStream, outputStream);
                return;
            }
            catch (a.a var1_2) {
                throw var1_2.a();
            }
            finally {
                outputStream.close();
            }
        }

        public void a(byte[] arrby) {
            OutputStream outputStream = this.a();
            try {
                outputStream.write(arrby);
                return;
            }
            finally {
                outputStream.close();
            }
        }

        public abstract void b();

        public abstract b c();
    }

}

