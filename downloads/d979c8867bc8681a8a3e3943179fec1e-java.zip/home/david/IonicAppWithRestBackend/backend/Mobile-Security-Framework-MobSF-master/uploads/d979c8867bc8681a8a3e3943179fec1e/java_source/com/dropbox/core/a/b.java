/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.a;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import javax.security.auth.x500.X500Principal;

public class b {
    private static final X509TrustManager a = b.a();
    private static final SSLSocketFactory b = b.b();
    private static final String[] c = new String[]{"TLSv1.2"};
    private static final String[] d = new String[]{"TLSv1.0"};
    private static final String[] e = new String[]{"TLSv1"};
    private static a f;
    private static final HashSet<String> g;

    static {
        g = new HashSet<String>(Arrays.asList("TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384", "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384", "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA", "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256", "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256", "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA", "TLS_ECDHE_RSA_WITH_RC4_128_SHA", "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384", "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256", "TLS_DHE_RSA_WITH_AES_256_CBC_SHA", "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256", "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256", "TLS_DHE_RSA_WITH_AES_128_CBC_SHA", "TLS_RSA_WITH_AES_256_GCM_SHA384", "TLS_RSA_WITH_AES_256_CBC_SHA256", "TLS_RSA_WITH_AES_256_CBC_SHA", "TLS_RSA_WITH_AES_128_GCM_SHA256", "TLS_RSA_WITH_AES_128_CBC_SHA256", "TLS_RSA_WITH_AES_128_CBC_SHA", "ECDHE-RSA-AES256-GCM-SHA384", "ECDHE-RSA-AES256-SHA384", "ECDHE-RSA-AES256-SHA", "ECDHE-RSA-AES128-GCM-SHA256", "ECDHE-RSA-AES128-SHA256", "ECDHE-RSA-AES128-SHA", "ECDHE-RSA-RC4-SHA", "DHE-RSA-AES256-GCM-SHA384", "DHE-RSA-AES256-SHA256", "DHE-RSA-AES256-SHA", "DHE-RSA-AES128-GCM-SHA256", "DHE-RSA-AES128-SHA256", "DHE-RSA-AES128-SHA", "AES256-GCM-SHA384", "AES256-SHA256", "AES256-SHA", "AES128-GCM-SHA256", "AES128-SHA256", "AES128-SHA"));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static KeyStore a(String string) {
        KeyStore keyStore;
        InputStream inputStream;
        try {
            keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            keyStore.load(null, new char[0]);
            inputStream = b.class.getResourceAsStream(string);
            if (inputStream == null) {
                throw new AssertionError((Object)("Couldn't find resource \"" + string + "\""));
            }
        }
        catch (KeyStoreException var0_1) {
            throw com.dropbox.core.d.b.a("Couldn't initialize KeyStore", var0_1);
        }
        catch (CertificateException var0_2) {
            throw com.dropbox.core.d.b.a("Couldn't initialize KeyStore", var0_2);
        }
        catch (NoSuchAlgorithmException var0_3) {
            throw com.dropbox.core.d.b.a("Couldn't initialize KeyStore", var0_3);
        }
        catch (IOException var0_4) {
            throw com.dropbox.core.d.b.a("Couldn't initialize KeyStore", var0_4);
        }
        try {
            b.a(keyStore, inputStream);
            return keyStore;
        }
        catch (KeyStoreException var2_7) {
            throw com.dropbox.core.d.b.a("Error loading from \"" + string + "\"", var2_7);
        }
        catch (b var2_8) {
            throw com.dropbox.core.d.b.a("Error loading from \"" + string + "\"", var2_8);
        }
        catch (IOException var2_9) {
            throw com.dropbox.core.d.b.a("Error loading from \"" + string + "\"", var2_9);
        }
        finally {
            com.dropbox.core.d.a.b(inputStream);
        }
    }

    private static List<X509Certificate> a(CertificateFactory certificateFactory, InputStream inputStream) {
        ArrayList<X509Certificate> arrayList = new ArrayList<X509Certificate>();
        inputStream = new DataInputStream(inputStream);
        byte[] arrby = new byte[10240];
        do {
            int n2;
            if ((n2 = inputStream.readUnsignedShort()) == 0) {
                if (inputStream.read() < 0) break;
                throw new b("Found data after after zero-length header.", null);
            }
            if (n2 > 10240) {
                throw new b("Invalid length for certificate entry: " + n2, null);
            }
            inputStream.readFully(arrby, 0, n2);
            arrayList.add((X509Certificate)certificateFactory.generateCertificate(new ByteArrayInputStream(arrby, 0, n2)));
        } while (true);
        return arrayList;
    }

    private static SSLContext a(TrustManager[] arrtrustManager) {
        SSLContext sSLContext;
        try {
            sSLContext = SSLContext.getInstance("TLS");
        }
        catch (NoSuchAlgorithmException var0_1) {
            throw com.dropbox.core.d.b.a("Couldn't create SSLContext", var0_1);
        }
        try {
            sSLContext.init(null, arrtrustManager, null);
            return sSLContext;
        }
        catch (KeyManagementException var0_2) {
            throw com.dropbox.core.d.b.a("Couldn't initialize SSLContext", var0_2);
        }
    }

    private static X509TrustManager a() {
        return b.a(b.a("/trusted-certs.raw"));
    }

    private static X509TrustManager a(KeyStore arrtrustManager) {
        TrustManagerFactory trustManagerFactory;
        try {
            trustManagerFactory = TrustManagerFactory.getInstance("X509");
        }
        catch (NoSuchAlgorithmException var0_1) {
            throw com.dropbox.core.d.b.a("Unable to create TrustManagerFactory", var0_1);
        }
        try {
            trustManagerFactory.init((KeyStore)arrtrustManager);
            arrtrustManager = trustManagerFactory.getTrustManagers();
        }
        catch (KeyStoreException var0_2) {
            throw com.dropbox.core.d.b.a("Unable to initialize TrustManagerFactory with key store", var0_2);
        }
        if (arrtrustManager.length != 1) {
            throw new AssertionError((Object)"More than 1 TrustManager created.");
        }
        if (!(arrtrustManager[0] instanceof X509TrustManager)) {
            throw new AssertionError((Object)("TrustManager not of type X509: " + arrtrustManager[0].getClass()));
        }
        return (X509TrustManager)arrtrustManager[0];
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void a(KeyStore keyStore, InputStream iterator) {
        Object object;
        try {
            object = CertificateFactory.getInstance("X.509");
        }
        catch (CertificateException certificateException) {
            throw com.dropbox.core.d.b.a("Couldn't initialize X.509 CertificateFactory", certificateException);
        }
        try {
            iterator = b.a((CertificateFactory)object, iterator);
            iterator = iterator.iterator();
        }
        catch (CertificateException var0_3) {
            throw new b("Error loading certificate: " + var0_3.getMessage(), var0_3);
        }
        while (iterator.hasNext()) {
            object = (X509Certificate)iterator.next();
            String string = object.getSubjectX500Principal().getName();
            try {
                keyStore.setCertificateEntry(string, (Certificate)object);
                continue;
            }
            catch (KeyStoreException var0_1) {}
            throw new b("Error loading certificate: " + var0_1.getMessage(), var0_1);
        }
        return;
    }

    public static void a(HttpsURLConnection httpsURLConnection) {
        httpsURLConnection.setSSLSocketFactory(b);
    }

    private static String[] a(String[] arrstring) {
        Object object = f;
        if (object != null && Arrays.equals(((a)object).a, arrstring)) {
            return ((a)object).b;
        }
        object = new ArrayList(g.size());
        int n2 = arrstring.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            String string = arrstring[i2];
            if (!g.contains(string)) continue;
            object.add(string);
        }
        object = object.toArray(new String[object.size()]);
        f = new a(arrstring, (String[])object);
        return object;
    }

    private static SSLSocketFactory b() {
        return new c(b.a(new TrustManager[]{a}).getSocketFactory());
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void b(SSLSocket sSLSocket) {
        String[] arrstring = sSLSocket.getSupportedProtocols();
        int n2 = arrstring.length;
        int n3 = 0;
        do {
            if (n3 >= n2) {
                throw new SSLException("Socket doesn't support protocols \"TLSv1.2\", \"TLSv1.0\" or \"TLSv1\".");
            }
            String string = arrstring[n3];
            if (string.equals("TLSv1.2")) {
                sSLSocket.setEnabledProtocols(c);
                break;
            }
            if (string.equals("TLSv1.0")) {
                sSLSocket.setEnabledProtocols(d);
                break;
            }
            if (string.equals("TLSv1")) {
                sSLSocket.setEnabledProtocols(e);
                break;
            }
            ++n3;
        } while (true);
        sSLSocket.setEnabledCipherSuites(b.a(sSLSocket.getSupportedCipherSuites()));
    }

    private static final class a {
        private final String[] a;
        private final String[] b;

        public a(String[] arrstring, String[] arrstring2) {
            this.a = arrstring;
            this.b = arrstring2;
        }
    }

    public static final class b
    extends Exception {
        public b(String string, Throwable throwable) {
            super(string, throwable);
        }
    }

    private static final class c
    extends SSLSocketFactory {
        private final SSLSocketFactory a;

        public c(SSLSocketFactory sSLSocketFactory) {
            this.a = sSLSocketFactory;
        }

        @Override
        public Socket createSocket(String object, int n2) {
            object = this.a.createSocket((String)object, n2);
            b.b((SSLSocket)object);
            return object;
        }

        @Override
        public Socket createSocket(String object, int n2, InetAddress inetAddress, int n3) {
            object = this.a.createSocket((String)object, n2, inetAddress, n3);
            b.b((SSLSocket)object);
            return object;
        }

        @Override
        public Socket createSocket(InetAddress object, int n2) {
            object = this.a.createSocket((InetAddress)object, n2);
            b.b((SSLSocket)object);
            return object;
        }

        @Override
        public Socket createSocket(InetAddress object, int n2, InetAddress inetAddress, int n3) {
            object = this.a.createSocket((InetAddress)object, n2, inetAddress, n3);
            b.b((SSLSocket)object);
            return object;
        }

        @Override
        public Socket createSocket(Socket socket, String string, int n2, boolean bl2) {
            socket = this.a.createSocket(socket, string, n2, bl2);
            b.b((SSLSocket)socket);
            return socket;
        }

        @Override
        public String[] getDefaultCipherSuites() {
            return this.a.getDefaultCipherSuites();
        }

        @Override
        public String[] getSupportedCipherSuites() {
            return this.a.getSupportedCipherSuites();
        }
    }

}

