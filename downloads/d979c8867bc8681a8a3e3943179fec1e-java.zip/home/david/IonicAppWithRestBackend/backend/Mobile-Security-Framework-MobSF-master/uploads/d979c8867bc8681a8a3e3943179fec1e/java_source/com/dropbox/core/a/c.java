/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.a;

import com.dropbox.core.a.a;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import javax.net.ssl.HttpsURLConnection;

public class c
extends com.dropbox.core.a.a {
    public static final c c;
    private static final Logger d;
    private static volatile boolean e;
    private final a f;

    static {
        d = Logger.getLogger(c.class.getCanonicalName());
        c = new c(a.a);
        e = false;
    }

    public c(a a2) {
        this.f = a2;
    }

    private static void a() {
        if (!e) {
            e = true;
            d.warning("Certificate pinning disabled for HTTPS connections. This is likely because your JRE does not return javax.net.ssl.HttpsURLConnection objects for https network connections. Be aware your app may be prone to man-in-the-middle attacks without proper SSL certificate validation. If you are using Google App Engine, please configure DbxRequestConfig to use GoogleAppEngineRequestor.");
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private HttpURLConnection c(String object, Iterable<a.a> iterator) {
        object = (HttpURLConnection)new URL((String)object).openConnection(this.f.a());
        object.setConnectTimeout((int)this.f.b());
        object.setReadTimeout((int)this.f.c());
        object.setUseCaches(false);
        object.setAllowUserInteraction(false);
        if (object instanceof HttpsURLConnection) {
            com.dropbox.core.a.b.a((HttpsURLConnection)object);
            this.a((HttpsURLConnection)object);
        } else {
            c.a();
        }
        this.a((HttpURLConnection)object);
        iterator = iterator.iterator();
        while (iterator.hasNext()) {
            a.a a2 = (a.a)iterator.next();
            object.addRequestProperty(a2.a(), a2.b());
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    private a.b d(HttpURLConnection httpURLConnection) {
        int n2 = httpURLConnection.getResponseCode();
        InputStream inputStream = n2 >= 400 || n2 == -1 ? httpURLConnection.getErrorStream() : httpURLConnection.getInputStream();
        this.b(httpURLConnection);
        return new a.b(n2, inputStream, httpURLConnection.getHeaderFields());
    }

    private static OutputStream e(HttpURLConnection httpURLConnection) {
        httpURLConnection.setDoOutput(true);
        return httpURLConnection.getOutputStream();
    }

    public /* synthetic */ a.c a(String string, Iterable iterable) {
        return this.b(string, iterable);
    }

    protected void a(HttpURLConnection httpURLConnection) {
    }

    @Deprecated
    protected void a(HttpsURLConnection httpsURLConnection) {
    }

    public b b(String object, Iterable<a.a> iterable) {
        object = this.c((String)object, iterable);
        object.setRequestMethod("POST");
        return new b((HttpURLConnection)object);
    }

    protected void b(HttpURLConnection httpURLConnection) {
    }

    public static final class com.dropbox.core.a.c$a {
        public static final com.dropbox.core.a.c$a a = com.dropbox.core.a.c$a.d().a();
        private final Proxy b;
        private final long c;
        private final long d;

        private com.dropbox.core.a.c$a(Proxy proxy, long l2, long l3) {
            this.b = proxy;
            this.c = l2;
            this.d = l3;
        }

        public static a d() {
            return new a();
        }

        public Proxy a() {
            return this.b;
        }

        public long b() {
            return this.c;
        }

        public long c() {
            return this.d;
        }

        public static final class a {
            private Proxy a;
            private long b;
            private long c;

            private a() {
                this(Proxy.NO_PROXY, com.dropbox.core.a.a.a, com.dropbox.core.a.a.b);
            }

            private a(Proxy proxy, long l2, long l3) {
                this.a = proxy;
                this.b = l2;
                this.c = l3;
            }

            public com.dropbox.core.a.c$a a() {
                return new com.dropbox.core.a.c$a(this.a, this.b, this.c);
            }
        }

    }

    private class b
    extends a.c {
        private final OutputStream b;
        private HttpURLConnection c;

        public b(HttpURLConnection httpURLConnection) {
            this.c = httpURLConnection;
            this.b = c.e(httpURLConnection);
            httpURLConnection.connect();
        }

        @Override
        public OutputStream a() {
            return this.b;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public void b() {
            if (this.c == null) {
                return;
            }
            if (this.c.getDoOutput()) {
                try {
                    com.dropbox.core.d.a.a(this.c.getOutputStream());
                }
                catch (IOException var1_1) {}
            }
            this.c = null;
        }

        @Override
        public a.b c() {
            if (this.c == null) {
                throw new IllegalStateException("Can't finish().  Uploader already closed.");
            }
            try {
                a.b b2 = c.this.d(this.c);
                return b2;
            }
            finally {
                this.c = null;
            }
        }
    }

}

