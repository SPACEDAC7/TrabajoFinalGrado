/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ResolveInfo
 *  android.content.pm.Signature
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.Log
 */
package com.dropbox.core.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.dropbox.core.android.b;
import com.dropbox.core.j;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class AuthActivity
extends Activity {
    public static Intent a;
    private static final String b;
    private static a c;
    private static final Object d;
    private static String e;
    private static String f;
    private static String g;
    private static String h;
    private static String[] i;
    private static final List<String> q;
    private String j;
    private String k;
    private String l;
    private String m;
    private String[] n;
    private String o = null;
    private boolean p = false;

    static {
        b = AuthActivity.class.getName();
        c = new a(){

            @Override
            public SecureRandom a() {
                return b.a();
            }
        };
        d = new Object();
        a = null;
        f = "www.dropbox.com";
        q = Arrays.asList("308202223082018b02044bd207bd300d06092a864886f70d01010405003058310b3009060355040613025553310b3009060355040813024341311630140603550407130d53616e204672616e636973636f3110300e060355040a130744726f70626f783112301006035504031309546f6d204d65796572301e170d3130303432333230343930315a170d3430303431353230343930315a3058310b3009060355040613025553310b3009060355040813024341311630140603550407130d53616e204672616e636973636f3110300e060355040a130744726f70626f783112301006035504031309546f6d204d6579657230819f300d06092a864886f70d010101050003818d0030818902818100ac1595d0ab278a9577f0ca5a14144f96eccde75f5616f36172c562fab0e98c48ad7d64f1091c6cc11ce084a4313d522f899378d312e112a748827545146a779defa7c31d8c00c2ed73135802f6952f59798579859e0214d4e9c0554b53b26032a4d2dfc2f62540d776df2ea70e2a6152945fb53fef5bac5344251595b729d4810203010001300d06092a864886f70d01010405000381810055c425d94d036153203dc0bbeb3516f94563b102fff39c3d4ed91278db24fc4424a244c2e59f03bbfea59404512b8bf74662f2a32e37eafa2ac904c31f99cfc21c9ff375c977c432d3b6ec22776f28767d0f292144884538c3d5669b568e4254e4ed75d9054f75229ac9d4ccd0b7c3c74a34f07b7657083b2aa76225c0c56ffc", "308201e53082014ea00302010202044e17e115300d06092a864886f70d01010505003037310b30090603550406130255533110300e060355040a1307416e64726f6964311630140603550403130d416e64726f6964204465627567301e170d3131303730393035303331375a170d3431303730313035303331375a3037310b30090603550406130255533110300e060355040a1307416e64726f6964311630140603550403130d416e64726f696420446562756730819f300d06092a864886f70d010101050003818d003081890281810096759fe5abea6a0757039b92adc68d672efa84732c3f959408e12efa264545c61f23141026a6d01eceeeaa13ec7087087e5894a3363da8bf5c69ed93657a6890738a80998e4ca22dc94848f30e2d0e1890000ae2cddf543b20c0c3828deca6c7944b5ecd21a9d18c988b2b3e54517dafbc34b48e801bb1321e0fa49e4d575d7f0203010001300d06092a864886f70d0101050500038181002b6d4b65bcfa6ec7bac97ae6d878064d47b3f9f8da654995b8ef4c385bc4fbfbb7a987f60783ef0348760c0708acd4b7e63f0235c35a4fbcd5ec41b3b4cb295feaa7d5c27fa562a02562b7e1f4776b85147be3e295714986c4a9a07183f48ea09ae4d3ea31b88d0016c65b93526b9c45f2967c3d28dee1aff5a5b29b9c2c8639");
    }

    public static Intent a(Context context, String string, String string2, String string3) {
        if (string == null) {
            throw new IllegalArgumentException("'appKey' can't be null");
        }
        AuthActivity.a(string, null, null, string2, string3);
        return new Intent(context, (Class)AuthActivity.class);
    }

    private void a(Intent intent) {
        a = intent;
        this.o = null;
        AuthActivity.a(null, null, null);
        this.finish();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(String string) {
        Locale locale = Locale.getDefault();
        String string2 = this.n.length > 0 ? this.n[0] : "0";
        String string3 = this.j;
        String string4 = this.l;
        this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)j.a(locale.toString(), this.k, "1/connect", new String[]{"k", string3, "n", string2, "api", string4, "state", string}))));
    }

    static void a(String string, String string2, String[] arrstring) {
        AuthActivity.a(string, string2, arrstring, null, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    static void a(String string, String string2, String[] arrstring, String string3, String string4) {
        e = string;
        h = string2;
        if (arrstring == null) {
            arrstring = new String[]{};
        }
        i = arrstring;
        if (string3 == null) {
            string3 = "www.dropbox.com";
        }
        f = string3;
        g = string4;
    }

    public static boolean a(Context context, String string, boolean bl2) {
        Object object = new Intent("android.intent.action.VIEW");
        string = "db-" + string;
        object.setData(Uri.parse((String)(string + "://" + 1 + "/connect")));
        object = context.getPackageManager().queryIntentActivities((Intent)object, 0);
        if (object == null || object.size() == 0) {
            throw new IllegalStateException("URI scheme in your app's manifest is not set up correctly. You should have a " + AuthActivity.class.getName() + " with the " + "scheme: " + string);
        }
        if (object.size() > 1) {
            if (bl2) {
                context = new AlertDialog.Builder(context);
                context.setTitle((CharSequence)"Security alert");
                context.setMessage((CharSequence)"Another app on your phone may be trying to pose as the app you are currently using. The malicious app can't access your account, but linking to Dropbox has been disabled as a precaution. Please contact support@dropbox.com.");
                context.setPositiveButton((CharSequence)"OK", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n2) {
                        dialogInterface.dismiss();
                    }
                });
                context.show();
                return false;
            }
            Log.w((String)b, (String)("There are multiple apps registered for the AuthActivity URI scheme (" + string + ").  Another app may be trying to " + " impersonate this app, so authentication will be disabled."));
            return false;
        }
        if ((object = (ResolveInfo)object.get(0)) == null || object.activityInfo == null || !context.getPackageName().equals(object.activityInfo.packageName)) {
            throw new IllegalStateException("There must be a " + AuthActivity.class.getName() + " within your app's package " + "registered for your URI scheme (" + string + "). However, " + "it appears that an activity in a different package is " + "registered for that scheme instead. If you have " + "multiple apps that all want to use the same access" + "token pair, designate one of them to do " + "authentication and have the other apps launch it " + "and then retrieve the token pair from it.");
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static a b() {
        Object object = d;
        synchronized (object) {
            return c;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private boolean b(Intent arrsignature) {
        PackageManager packageManager = this.getPackageManager();
        List list = packageManager.queryIntentActivities((Intent)arrsignature, 0);
        if (list == null) return false;
        if (1 != list.size()) {
            return false;
        }
        if ((arrsignature = packageManager.resolveActivity((Intent)arrsignature, 0)) == null) return false;
        try {
            arrsignature = packageManager.getPackageInfo(arrsignature.activityInfo.packageName, 64);
            arrsignature = arrsignature.signatures;
        }
        catch (PackageManager.NameNotFoundException var1_2) {
            return false;
        }
        int n2 = arrsignature.length;
        int n3 = 0;
        while (n3 < n2) {
            Signature signature = arrsignature[n3];
            if (!q.contains(signature.toCharsString())) return false;
            ++n3;
        }
        return true;
    }

    private static SecureRandom c() {
        a a2 = AuthActivity.b();
        if (a2 != null) {
            return a2.a();
        }
        return new SecureRandom();
    }

    private static Intent d() {
        Intent intent = new Intent("com.dropbox.android.AUTHENTICATE_V2");
        intent.setPackage("com.dropbox.android");
        return intent;
    }

    private String e() {
        byte[] arrby = new byte[16];
        AuthActivity.c().nextBytes(arrby);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("oauth2:");
        for (int i2 = 0; i2 < 16; ++i2) {
            stringBuilder.append(String.format("%02x", arrby[i2] & 255));
        }
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onCreate(Bundle bundle) {
        this.j = e;
        this.k = f;
        this.l = g;
        this.m = h;
        this.n = i;
        if (bundle == null) {
            a = null;
            this.o = null;
        } else {
            this.o = bundle.getString("SIS_KEY_AUTH_STATE_NONCE");
        }
        this.setTheme(16973840);
        super.onCreate(bundle);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected void onNewIntent(Intent var1_1) {
        block18 : {
            var6_5 = null;
            if (this.o == null) {
                this.a((Intent)null);
                return;
            }
            if (!var1_1.hasExtra("ACCESS_TOKEN")) ** GOTO lbl11
            var4_6 = var1_1.getStringExtra("ACCESS_TOKEN");
            var3_8 = var1_1.getStringExtra("ACCESS_SECRET");
            var2_9 = var1_1.getStringExtra("UID");
            var1_1 = var1_1.getStringExtra("AUTH_STATE");
            ** GOTO lbl49
lbl11: // 1 sources:
            var4_6 = var1_1.getData();
            if (var4_6 == null || !"/connect".equals(var4_6.getPath())) ** GOTO lbl45
            var3_8 = var4_6.getQueryParameter("oauth_token");
            var2_9 = var4_6.getQueryParameter("oauth_token_secret");
            {
                catch (UnsupportedOperationException var1_3) {
                    var1_1 = null;
                    var2_9 = null;
                    break block19;
                }
            }
            var1_1 = var4_6.getQueryParameter("uid");
            var5_10 = var4_6.getQueryParameter("state");
            var4_6 = var3_8;
            var3_8 = var2_9;
            var2_9 = var1_1;
            var1_1 = var5_10;
            break block18;
            {
                catch (UnsupportedOperationException var4_7) {}
            }
            catch (UnsupportedOperationException var1_2) {
                block19 : {
                    var1_1 = null;
                    var2_9 = null;
                    var3_8 = null;
                    ** GOTO lbl39
                    catch (UnsupportedOperationException var1_4) {
                        var1_1 = null;
                    }
                }
                var4_6 = var3_8;
                var3_8 = var2_9;
                var2_9 = var1_1;
                var1_1 = null;
                break block18;
            }
lbl45: // 1 sources:
            var1_1 = null;
            var2_9 = null;
            var3_8 = null;
            var4_6 = null;
        }
        var5_10 = var6_5;
        if (var4_6 != null) {
            var5_10 = var6_5;
            if (!var4_6.equals("")) {
                var5_10 = var6_5;
                if (var3_8 != null) {
                    var5_10 = var6_5;
                    if (!var3_8.equals("")) {
                        var5_10 = var6_5;
                        if (var2_9 != null) {
                            var5_10 = var6_5;
                            if (!var2_9.equals("")) {
                                var5_10 = var6_5;
                                if (var1_1 != null) {
                                    var5_10 = var6_5;
                                    if (!var1_1.equals("")) {
                                        if (!this.o.equals(var1_1)) {
                                            this.a((Intent)null);
                                            return;
                                        }
                                        var5_10 = new Intent();
                                        var5_10.putExtra("ACCESS_TOKEN", (String)var4_6);
                                        var5_10.putExtra("ACCESS_SECRET", (String)var3_8);
                                        var5_10.putExtra("UID", (String)var2_9);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        this.a((Intent)var5_10);
    }

    protected void onResume() {
        super.onResume();
        if (this.isFinishing()) {
            return;
        }
        if (this.o != null || this.j == null) {
            this.a((Intent)null);
            return;
        }
        a = null;
        if (this.p) {
            Log.w((String)b, (String)"onResume called again before Handler run");
            return;
        }
        final String string = this.e();
        final Intent intent = AuthActivity.d();
        intent.putExtra("CONSUMER_KEY", this.j);
        intent.putExtra("CONSUMER_SIG", "");
        intent.putExtra("DESIRED_UID", this.m);
        intent.putExtra("ALREADY_AUTHED_UIDS", this.n);
        intent.putExtra("CALLING_PACKAGE", this.getPackageName());
        intent.putExtra("CALLING_CLASS", this.getClass().getName());
        intent.putExtra("AUTH_STATE", string);
        new Handler(Looper.getMainLooper()).post(new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void run() {
                block4 : {
                    Log.d((String)b, (String)"running startActivity in handler");
                    try {
                        if (AuthActivity.this.b(intent)) {
                            AuthActivity.this.startActivity(intent);
                            break block4;
                        }
                        AuthActivity.this.a(string);
                    }
                    catch (ActivityNotFoundException var1_1) {
                        Log.e((String)b, (String)"Could not launch intent. User may have restricted profile", (Throwable)var1_1);
                        AuthActivity.this.finish();
                        return;
                    }
                }
                AuthActivity.this.o = string;
                AuthActivity.a(null, null, null);
            }
        });
        this.p = true;
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putString("SIS_KEY_AUTH_STATE_NONCE", this.o);
    }

    public static interface a {
        public SecureRandom a();
    }

}

