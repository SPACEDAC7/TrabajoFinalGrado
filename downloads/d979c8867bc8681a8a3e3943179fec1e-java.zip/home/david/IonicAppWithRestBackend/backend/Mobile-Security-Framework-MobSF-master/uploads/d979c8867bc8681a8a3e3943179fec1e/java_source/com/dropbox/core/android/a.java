/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 */
package com.dropbox.core.android;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.dropbox.core.android.AuthActivity;

public class a {
    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static String a() {
        Object object = AuthActivity.a;
        if (object == null) {
            return null;
        }
        String string = object.getStringExtra("ACCESS_TOKEN");
        String string2 = object.getStringExtra("ACCESS_SECRET");
        object = object.getStringExtra("UID");
        if (string == null) return null;
        if (string.equals("")) return null;
        if (string2 == null) return null;
        if (string2.equals("")) return null;
        if (object == null) return null;
        if (object.equals("")) return null;
        return string2;
    }

    public static void a(Context context, String string) {
        if (!AuthActivity.a(context, string, true)) {
            return;
        }
        string = AuthActivity.a(context, string, "www.dropbox.com", "1");
        if (!(context instanceof Activity)) {
            string.addFlags(268435456);
        }
        context.startActivity((Intent)string);
    }
}

