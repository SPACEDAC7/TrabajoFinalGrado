/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Process
 */
package com.dropbox.core.android;

import android.os.Build;
import android.os.Process;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.SecureRandomSpi;

public final class b
extends SecureRandom {
    private static final byte[] a = b.e();

    private b() {
        super(new b(), new a());
    }

    public static SecureRandom a() {
        if (Build.VERSION.SDK_INT > 18) {
            return new SecureRandom();
        }
        return new b();
    }

    private static byte[] c() {
        try {
            byte[] arrby = new byte[]();
            DataOutputStream dataOutputStream = new DataOutputStream((OutputStream)arrby);
            dataOutputStream.writeLong(System.currentTimeMillis());
            dataOutputStream.writeLong(System.nanoTime());
            dataOutputStream.writeInt(Process.myPid());
            dataOutputStream.writeInt(Process.myUid());
            dataOutputStream.write(a);
            dataOutputStream.close();
            arrby = arrby.toByteArray();
            return arrby;
        }
        catch (IOException var0_1) {
            throw new SecurityException("Failed to generate seed", var0_1);
        }
    }

    private static String d() {
        try {
            String string = (String)Build.class.getField("SERIAL").get(null);
            return string;
        }
        catch (Exception var0_1) {
            return null;
        }
    }

    private static byte[] e() {
        byte[] arrby = new byte[]();
        String string = Build.FINGERPRINT;
        if (string != null) {
            arrby.append(string);
        }
        if ((string = b.d()) != null) {
            arrby.append(string);
        }
        try {
            arrby = arrby.toString().getBytes("UTF-8");
            return arrby;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw new RuntimeException("UTF-8 encoding not supported");
        }
    }

    private static class a
    extends Provider {
        public a() {
            super("LinuxPRNG", 1.0, "A Linux-specific random number provider that uses /dev/urandom");
            this.put("SecureRandom.SHA1PRNG", b.class.getName());
            this.put("SecureRandom.SHA1PRNG ImplementedIn", "Software");
        }
    }

    public static class b
    extends SecureRandomSpi {
        private static final File a = new File("/dev/urandom");
        private static final Object b = new Object();
        private static DataInputStream c;
        private static OutputStream d;
        private boolean e;

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private DataInputStream a() {
            Object object = b;
            synchronized (object) {
                DataInputStream dataInputStream = c;
                if (dataInputStream != null) return c;
                try {
                    c = new DataInputStream(new FileInputStream(a));
                }
                catch (IOException var2_3) {
                    throw new SecurityException("Failed to open " + a + " for reading", var2_3);
                }
                return c;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private OutputStream b() {
            Object object = b;
            synchronized (object) {
                if (d != null) return d;
                d = new FileOutputStream(a);
                return d;
            }
        }

        @Override
        protected byte[] engineGenerateSeed(int n2) {
            byte[] arrby = new byte[n2];
            this.engineNextBytes(arrby);
            return arrby;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Converted monitor instructions to comments
         * Lifted jumps to return sites
         */
        @Override
        protected void engineNextBytes(byte[] arrby) {
            DataInputStream dataInputStream;
            if (!this.e) {
                this.engineSetSeed(b.c());
            }
            try {
                Object object = b;
                // MONITORENTER : object
                dataInputStream = this.a();
            }
            catch (IOException var1_2) {
                throw new SecurityException("Failed to read from " + a, var1_2);
            }
            dataInputStream.readFully(arrby);
            // MONITOREXIT : dataInputStream
        }

        /*
         * Exception decompiling
         */
        @Override
        protected void engineSetSeed(byte[] var1_1) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [4[TRYBLOCK]], but top level block is 7[CATCHBLOCK]
            // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }
    }

}

