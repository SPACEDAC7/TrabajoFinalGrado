/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.q;

public class b
extends q {
    public b(String string, String string2) {
        super(string, string2);
    }
}

