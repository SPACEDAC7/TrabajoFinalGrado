/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.b;

import com.fasterxml.jackson.core.JsonFactory;

public abstract class a<T> {
    public static final a<Long> a;
    public static final a<Long> b;
    public static final a<Integer> c;
    public static final a<Long> d;
    public static final a<Long> e;
    public static final a<Double> f;
    public static final a<Float> g;
    public static final a<String> h;
    public static final a<byte[]> i;
    public static final a<Boolean> j;
    public static final a<Object> k;
    static final JsonFactory l;
    static final /* synthetic */ boolean m;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl2 = !a.class.desiredAssertionStatus();
        m = bl2;
        a = new a<Long>(){};
        b = new a<Long>(){};
        c = new a<Integer>(){};
        d = new a<Long>(){};
        e = new a<Long>(){};
        f = new a<Double>(){};
        g = new a<Float>(){};
        h = new a<String>(){};
        i = new a<byte[]>(){};
        j = new a<Boolean>(){};
        k = new a<Object>(){};
        l = new JsonFactory();
    }

}

