/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.b;

import java.util.TimeZone;

public abstract class b<T> {
    private static final TimeZone a = TimeZone.getTimeZone("UTC");
    private static final String[] b = new String[]{null, "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    private static final String[] c = new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", null};
}

