/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.d;

public class c
extends d {
    private final int a;

    public c(String string, String string2, int n2) {
        super(string, string2);
        this.a = n2;
    }
}

