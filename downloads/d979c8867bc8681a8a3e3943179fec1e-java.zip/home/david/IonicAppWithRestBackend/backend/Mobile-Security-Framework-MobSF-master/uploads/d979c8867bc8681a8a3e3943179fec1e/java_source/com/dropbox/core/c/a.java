/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.c;

import com.dropbox.core.c.b;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

public abstract class a<T>
extends b<T> {
    protected static boolean a(JsonParser jsonParser) {
        if (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME && ".tag".equals(jsonParser.getCurrentName())) {
            return true;
        }
        return false;
    }

    protected static String c(JsonParser jsonParser) {
        if (!a.a(jsonParser)) {
            return null;
        }
        jsonParser.nextToken();
        String string = a.d(jsonParser);
        jsonParser.nextToken();
        return string;
    }

    @Override
    protected void a(String string, JsonGenerator jsonGenerator) {
        if (string != null) {
            jsonGenerator.writeStringField(".tag", string);
        }
    }
}

