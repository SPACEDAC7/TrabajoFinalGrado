/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.c;

import com.dropbox.core.c.f;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;

public abstract class b<T> {
    private static final Charset a = Charset.forName("UTF-8");

    protected static void a(String string, JsonParser jsonParser) {
        if (jsonParser.getCurrentToken() != JsonToken.FIELD_NAME) {
            throw new JsonParseException(jsonParser, "expected field name, but was: " + (Object)((Object)jsonParser.getCurrentToken()));
        }
        if (!string.equals(jsonParser.getCurrentName())) {
            throw new JsonParseException(jsonParser, "expected field '" + string + "', but was: '" + jsonParser.getCurrentName() + "'");
        }
        jsonParser.nextToken();
    }

    protected static String d(JsonParser jsonParser) {
        if (jsonParser.getCurrentToken() != JsonToken.VALUE_STRING) {
            throw new JsonParseException(jsonParser, "expected string value, but was " + (Object)((Object)jsonParser.getCurrentToken()));
        }
        return jsonParser.getText();
    }

    protected static void e(JsonParser jsonParser) {
        if (jsonParser.getCurrentToken() != JsonToken.START_OBJECT) {
            throw new JsonParseException(jsonParser, "expected object value.");
        }
        jsonParser.nextToken();
    }

    protected static void f(JsonParser jsonParser) {
        if (jsonParser.getCurrentToken() != JsonToken.END_OBJECT) {
            throw new JsonParseException(jsonParser, "expected end of object value.");
        }
        jsonParser.nextToken();
    }

    protected static void g(JsonParser jsonParser) {
        if (jsonParser.getCurrentToken() != JsonToken.START_ARRAY) {
            throw new JsonParseException(jsonParser, "expected array value.");
        }
        jsonParser.nextToken();
    }

    protected static void h(JsonParser jsonParser) {
        if (jsonParser.getCurrentToken() != JsonToken.END_ARRAY) {
            throw new JsonParseException(jsonParser, "expected end of array value.");
        }
        jsonParser.nextToken();
    }

    protected static void i(JsonParser jsonParser) {
        if (jsonParser.getCurrentToken().isStructStart()) {
            jsonParser.skipChildren();
            jsonParser.nextToken();
            return;
        }
        if (jsonParser.getCurrentToken().isScalarValue()) {
            jsonParser.nextToken();
            return;
        }
        throw new JsonParseException(jsonParser, "Can't skip JSON value token: " + (Object)((Object)jsonParser.getCurrentToken()));
    }

    protected static void j(JsonParser jsonParser) {
        while (jsonParser.getCurrentToken() != null && !jsonParser.getCurrentToken().isStructEnd()) {
            if (jsonParser.getCurrentToken().isStructStart()) {
                jsonParser.skipChildren();
                continue;
            }
            if (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                jsonParser.nextToken();
                continue;
            }
            if (jsonParser.getCurrentToken().isScalarValue()) {
                jsonParser.nextToken();
                continue;
            }
            throw new JsonParseException(jsonParser, "Can't skip token: " + (Object)((Object)jsonParser.getCurrentToken()));
        }
    }

    public T a(InputStream closeable) {
        closeable = f.a.createParser((InputStream)closeable);
        closeable.nextToken();
        return this.b((JsonParser)closeable);
    }

    public T a(String object) {
        try {
            object = f.a.createParser((String)object);
            object.nextToken();
            object = this.b((JsonParser)object);
        }
        catch (JsonParseException var1_2) {
            throw var1_2;
        }
        catch (IOException var1_3) {
            throw new IllegalStateException("Impossible I/O exception", var1_3);
        }
        return (T)object;
    }

    public String a(T t2, boolean bl2) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            this.a(t2, byteArrayOutputStream, bl2);
            return new String(byteArrayOutputStream.toByteArray(), a);
        }
        catch (JsonGenerationException var1_2) {
            throw new IllegalStateException("Impossible JSON exception", var1_2);
        }
        catch (IOException var1_3) {
            throw new IllegalStateException("Impossible I/O exception", var1_3);
        }
    }

    public abstract void a(T var1, JsonGenerator var2);

    public void a(T t2, OutputStream outputStream) {
        this.a(t2, outputStream, false);
    }

    public void a(T t2, OutputStream closeable, boolean bl2) {
        closeable = f.a.createGenerator((OutputStream)closeable);
        if (bl2) {
            closeable.useDefaultPrettyPrinter();
        }
        try {
            this.a(t2, (JsonGenerator)closeable);
            closeable.flush();
            return;
        }
        catch (JsonGenerationException var1_2) {
            throw new IllegalStateException("Impossible JSON generation exception", var1_2);
        }
    }

    public abstract T b(JsonParser var1);
}

