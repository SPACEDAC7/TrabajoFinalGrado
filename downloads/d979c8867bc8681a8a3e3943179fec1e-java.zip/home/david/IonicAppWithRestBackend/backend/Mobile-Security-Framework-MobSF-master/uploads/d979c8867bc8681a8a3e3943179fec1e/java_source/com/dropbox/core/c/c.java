/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.c;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public final class c {
    public static com.dropbox.core.c.b<Long> a() {
        return e.a;
    }

    public static <T> com.dropbox.core.c.b<T> a(com.dropbox.core.c.b<T> b2) {
        return new f<T>(b2);
    }

    public static com.dropbox.core.c.b<Double> b() {
        return c.a;
    }

    public static <T> com.dropbox.core.c.b<List<T>> b(com.dropbox.core.c.b<T> b2) {
        return new d<T>(b2);
    }

    public static com.dropbox.core.c.b<Boolean> c() {
        return a.a;
    }

    public static com.dropbox.core.c.b<String> d() {
        return g.a;
    }

    public static com.dropbox.core.c.b<Date> e() {
        return b.a;
    }

    private static final class a
    extends com.dropbox.core.c.b<Boolean> {
        public static final a a = new a();

        private a() {
        }

        public Boolean a(JsonParser jsonParser) {
            boolean bl2 = jsonParser.getBooleanValue();
            jsonParser.nextToken();
            return bl2;
        }

        @Override
        public void a(Boolean bl2, JsonGenerator jsonGenerator) {
            jsonGenerator.writeBoolean(bl2);
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.a(jsonParser);
        }
    }

    private static final class b
    extends com.dropbox.core.c.b<Date> {
        public static final b a = new b();

        private b() {
        }

        public Date a(JsonParser jsonParser) {
            String string = b.d(jsonParser);
            jsonParser.nextToken();
            try {
                Date date = com.dropbox.core.c.f.a(string);
                return date;
            }
            catch (ParseException var3_4) {
                throw new JsonParseException(jsonParser, "Malformed timestamp: '" + string + "'", var3_4);
            }
        }

        @Override
        public void a(Date date, JsonGenerator jsonGenerator) {
            jsonGenerator.writeString(com.dropbox.core.c.f.a(date));
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.a(jsonParser);
        }
    }

    private static final class c
    extends com.dropbox.core.c.b<Double> {
        public static final c a = new c();

        private c() {
        }

        public Double a(JsonParser jsonParser) {
            double d2 = jsonParser.getDoubleValue();
            jsonParser.nextToken();
            return d2;
        }

        @Override
        public void a(Double d2, JsonGenerator jsonGenerator) {
            jsonGenerator.writeNumber(d2);
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.a(jsonParser);
        }
    }

    private static final class d<T>
    extends com.dropbox.core.c.b<List<T>> {
        private final com.dropbox.core.c.b<T> a;

        public d(com.dropbox.core.c.b<T> b2) {
            this.a = b2;
        }

        public List<T> a(JsonParser jsonParser) {
            d.g(jsonParser);
            ArrayList<T> arrayList = new ArrayList<T>();
            while (jsonParser.getCurrentToken() != JsonToken.END_ARRAY) {
                arrayList.add(this.a.b(jsonParser));
            }
            d.h(jsonParser);
            return arrayList;
        }

        @Override
        public void a(List<T> object, JsonGenerator jsonGenerator) {
            jsonGenerator.writeStartArray(object.size());
            object = object.iterator();
            while (object.hasNext()) {
                Object e2 = object.next();
                this.a.a(e2, jsonGenerator);
            }
            jsonGenerator.writeEndArray();
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.a(jsonParser);
        }
    }

    private static final class e
    extends com.dropbox.core.c.b<Long> {
        public static final e a = new e();

        private e() {
        }

        public Long a(JsonParser jsonParser) {
            long l2 = jsonParser.getLongValue();
            jsonParser.nextToken();
            return l2;
        }

        @Override
        public void a(Long l2, JsonGenerator jsonGenerator) {
            jsonGenerator.writeNumber(l2);
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.a(jsonParser);
        }
    }

    private static final class f<T>
    extends com.dropbox.core.c.b<T> {
        private final com.dropbox.core.c.b<T> a;

        public f(com.dropbox.core.c.b<T> b2) {
            this.a = b2;
        }

        @Override
        public void a(T t2, JsonGenerator jsonGenerator) {
            if (t2 == null) {
                jsonGenerator.writeNull();
                return;
            }
            this.a.a(t2, jsonGenerator);
        }

        @Override
        public T b(JsonParser jsonParser) {
            if (jsonParser.getCurrentToken() == JsonToken.VALUE_NULL) {
                jsonParser.nextToken();
                return null;
            }
            return this.a.b(jsonParser);
        }
    }

    private static final class g
    extends com.dropbox.core.c.b<String> {
        public static final g a = new g();

        private g() {
        }

        public String a(JsonParser jsonParser) {
            String string = g.d(jsonParser);
            jsonParser.nextToken();
            return string;
        }

        @Override
        public void a(String string, JsonGenerator jsonGenerator) {
            jsonGenerator.writeString(string);
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.a(jsonParser);
        }
    }

}

