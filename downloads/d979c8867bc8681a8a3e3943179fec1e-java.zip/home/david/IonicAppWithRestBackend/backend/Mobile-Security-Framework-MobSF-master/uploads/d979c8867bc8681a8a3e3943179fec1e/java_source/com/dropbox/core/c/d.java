/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.c;

import com.dropbox.core.c.a;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;

public abstract class d<T>
extends a<T> {
    public abstract T a(JsonParser var1, boolean var2);

    @Override
    public void a(T t2, JsonGenerator jsonGenerator) {
        this.a(t2, jsonGenerator, false);
    }

    public abstract void a(T var1, JsonGenerator var2, boolean var3);

    @Override
    public T b(JsonParser jsonParser) {
        return this.a(jsonParser, false);
    }
}

