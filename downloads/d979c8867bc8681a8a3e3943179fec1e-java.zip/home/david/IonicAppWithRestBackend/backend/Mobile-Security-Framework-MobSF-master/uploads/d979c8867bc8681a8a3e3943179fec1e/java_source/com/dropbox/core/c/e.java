/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.c;

import com.dropbox.core.c.a;

public abstract class e<T>
extends a<T> {
}

