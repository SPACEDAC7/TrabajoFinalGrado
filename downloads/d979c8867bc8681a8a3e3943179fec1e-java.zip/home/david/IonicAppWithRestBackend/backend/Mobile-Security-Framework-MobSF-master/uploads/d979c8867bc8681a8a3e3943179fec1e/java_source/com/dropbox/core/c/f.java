/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.c;

import com.fasterxml.jackson.core.JsonFactory;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

final class f {
    public static final JsonFactory a = new JsonFactory();
    private static final TimeZone b = TimeZone.getTimeZone("UTC");
    private static final int c = "yyyy-MM-dd'T'HH:mm:ss'Z'".replace("'", "").length();
    private static final int d = "yyyy-MM-dd".replace("'", "").length();

    public static String a(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        simpleDateFormat.setCalendar(new GregorianCalendar(b));
        return simpleDateFormat.format(date);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Date a(String string) {
        SimpleDateFormat simpleDateFormat;
        int n2 = string.length();
        if (n2 == c) {
            simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        } else {
            if (n2 != d) {
                throw new ParseException("timestamp has unexpected format: '" + string + "'", 0);
            }
            simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        }
        simpleDateFormat.setCalendar(new GregorianCalendar(b));
        return simpleDateFormat.parse(string);
    }
}

