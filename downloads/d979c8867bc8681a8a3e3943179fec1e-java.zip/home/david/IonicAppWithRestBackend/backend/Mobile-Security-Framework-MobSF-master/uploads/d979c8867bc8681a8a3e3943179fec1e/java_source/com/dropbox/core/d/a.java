/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.d;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;

public class a {
    public static final InputStream a = new InputStream(){

        @Override
        public int read() {
            return -1;
        }

        @Override
        public int read(byte[] arrby) {
            return -1;
        }

        @Override
        public int read(byte[] arrby, int n2, int n3) {
            return -1;
        }
    };
    public static final OutputStream b = new OutputStream(){

        @Override
        public void write(int n2) {
        }

        @Override
        public void write(byte[] arrby) {
        }

        @Override
        public void write(byte[] arrby, int n2, int n3) {
        }
    };

    public static Reader a(InputStream inputStream) {
        return new InputStreamReader(inputStream, com.dropbox.core.d.c.a.newDecoder());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void a(Closeable closeable) {
        if (closeable == null) return;
        try {
            closeable.close();
            return;
        }
        catch (IOException var0_1) {
            return;
        }
    }

    public static void a(InputStream inputStream, OutputStream outputStream) {
        a.a(inputStream, outputStream, 16384);
    }

    public static void a(InputStream inputStream, OutputStream outputStream, int n2) {
        a.a(inputStream, outputStream, new byte[n2]);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void a(InputStream inputStream, OutputStream outputStream, byte[] arrby) {
        do {
            int n2;
            try {
                n2 = inputStream.read(arrby);
                if (n2 == -1) {
                    return;
                }
            }
            catch (IOException var0_1) {
                throw new a(var0_1);
            }
            try {
                outputStream.write(arrby, 0, n2);
                continue;
            }
            catch (IOException var0_2) {}
            throw new c(var0_2);
        } while (true);
    }

    public static byte[] a(InputStream inputStream, int n2) {
        return a.a(inputStream, n2, new byte[16384]);
    }

    public static byte[] a(InputStream inputStream, int n2, byte[] arrby) {
        if (n2 < 0) {
            throw new RuntimeException("'byteLimit' must be non-negative: " + n2);
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        a.a(inputStream, (OutputStream)byteArrayOutputStream, arrby);
        return byteArrayOutputStream.toByteArray();
    }

    public static void b(InputStream inputStream) {
        try {
            inputStream.close();
            return;
        }
        catch (IOException var0_1) {
            return;
        }
    }

    public static final class a
    extends b {
        public a(IOException iOException) {
            super(iOException);
        }
    }

    public static abstract class b
    extends IOException {
        public b(IOException iOException) {
            super(iOException);
        }

        public IOException a() {
            return (IOException)super.getCause();
        }

        @Override
        public /* synthetic */ Throwable getCause() {
            return this.a();
        }

        @Override
        public String getMessage() {
            String string;
            String string2 = string = super.getCause().getMessage();
            if (string == null) {
                string2 = "";
            }
            return string2;
        }
    }

    public static final class c
    extends b {
        public c(IOException iOException) {
            super(iOException);
        }
    }

}

