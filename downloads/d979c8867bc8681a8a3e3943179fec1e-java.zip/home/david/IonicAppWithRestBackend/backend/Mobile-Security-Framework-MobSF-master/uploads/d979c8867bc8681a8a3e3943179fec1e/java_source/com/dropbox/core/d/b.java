/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.d;

import java.util.Date;

public class b {
    public static RuntimeException a(String object, Throwable throwable) {
        object = new RuntimeException((String)object + ": " + throwable.getMessage());
        object.initCause(throwable);
        return object;
    }

    public static Date a(Date date) {
        Date date2 = date;
        if (date != null) {
            long l2 = date.getTime();
            date2 = new Date(l2 - l2 % 1000);
        }
        return date2;
    }
}

