/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.d;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;

public class c {
    public static final Charset a;
    static final /* synthetic */ boolean b;
    private static final char[] c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl2 = !c.class.desiredAssertionStatus();
        b = bl2;
        a = Charset.forName("UTF-8");
        c = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        if (!b && "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".length() != 64) {
            throw new AssertionError("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".length());
        }
        if (!b && "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".length() != 64) {
            throw new AssertionError("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".length());
        }
    }

    public static char a(int n2) {
        return c[n2];
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static String a(String var0) {
        var3_1 = new StringBuilder(var0.length() * 2);
        var3_1.append('\"');
        var2_2 = 0;
        do {
            if (var2_2 >= var0.length()) {
                var3_1.append('\"');
                return var3_1.toString();
            }
            var1_3 = var0.charAt(var2_2);
            switch (var1_3) {
                default: {
                    if (var1_3 < ' ' || var1_3 > '~') break;
                    var3_1.append(var1_3);
                    ** GOTO lbl37
                }
                case '\"': {
                    var3_1.append("\\\"");
                    ** GOTO lbl37
                }
                case '\\': {
                    var3_1.append("\\\\");
                    ** GOTO lbl37
                }
                case '\n': {
                    var3_1.append("\\n");
                    ** GOTO lbl37
                }
                case '\r': {
                    var3_1.append("\\t");
                    ** GOTO lbl37
                }
                case '\t': {
                    var3_1.append("\\r");
                    ** GOTO lbl37
                }
                case '\u0000': {
                    var3_1.append("\\000");
                    ** GOTO lbl37
                }
            }
            var3_1.append("\\u");
            var3_1.append(c.a(var1_3 >> 12 & 15));
            var3_1.append(c.a(var1_3 >> 8 & 15));
            var3_1.append(c.a(var1_3 >> 4 & 15));
            var3_1.append(c.a(var1_3 & 15));
lbl37: // 8 sources:
            ++var2_2;
        } while (true);
    }

    public static String a(byte[] arrby) {
        return c.a(arrby, 0, arrby.length);
    }

    public static String a(byte[] arrby, int n2, int n3) {
        return a.newDecoder().decode(ByteBuffer.wrap(arrby, n2, n3)).toString();
    }

    public static String b(String string) {
        return c.a(string);
    }
}

