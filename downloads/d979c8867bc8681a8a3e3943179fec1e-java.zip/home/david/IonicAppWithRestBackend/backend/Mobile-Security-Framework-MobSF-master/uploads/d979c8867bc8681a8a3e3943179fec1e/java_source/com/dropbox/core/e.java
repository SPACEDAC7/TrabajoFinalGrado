/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.g;
import com.dropbox.core.o;

public class e
extends g {
    private final o a;

    public e(String string, o o2, String string2) {
        super(string, string2);
        this.a = o2;
    }

    protected static String a(String string, o o2, Object object) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Exception in ").append(string);
        if (object != null) {
            stringBuilder.append(": ").append(object);
        }
        if (o2 != null) {
            stringBuilder.append(" (user message: ").append(o2).append(")");
        }
        return stringBuilder.toString();
    }
}

