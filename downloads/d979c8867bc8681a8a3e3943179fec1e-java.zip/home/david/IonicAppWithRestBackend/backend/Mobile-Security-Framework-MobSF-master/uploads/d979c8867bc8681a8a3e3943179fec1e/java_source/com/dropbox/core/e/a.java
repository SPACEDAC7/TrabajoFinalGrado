/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e;

import com.dropbox.core.a.a;
import com.dropbox.core.e.b;
import com.dropbox.core.e.c;
import com.dropbox.core.h;
import com.dropbox.core.i;
import com.dropbox.core.j;
import java.util.List;

public class a
extends b {
    public a(i i2, String string) {
        this(i2, string, h.a);
    }

    public a(i i2, String string, h h2) {
        super(new a(i2, string, h2));
    }

    private static final class a
    extends c {
        private final String a;

        public a(i i2, String string, h h2) {
            super(i2, h2);
            if (string == null) {
                throw new NullPointerException("accessToken");
            }
            this.a = string;
        }

        @Override
        protected void a(List<a.a> list) {
            j.a(list, this.a);
        }
    }

}

