/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e;

import com.dropbox.core.e.c;
import com.dropbox.core.e.d.a;

public class b {
    protected final c a;
    private final com.dropbox.core.e.a.a b;
    private final com.dropbox.core.e.b.b c;
    private final a d;
    private final com.dropbox.core.e.e.a e;

    protected b(c c2) {
        this.a = c2;
        this.b = new com.dropbox.core.e.a.a(c2);
        this.c = new com.dropbox.core.e.b.b(c2);
        this.d = new a(c2);
        this.e = new com.dropbox.core.e.e.a(c2);
    }

    public com.dropbox.core.e.b.b a() {
        return this.c;
    }
}

