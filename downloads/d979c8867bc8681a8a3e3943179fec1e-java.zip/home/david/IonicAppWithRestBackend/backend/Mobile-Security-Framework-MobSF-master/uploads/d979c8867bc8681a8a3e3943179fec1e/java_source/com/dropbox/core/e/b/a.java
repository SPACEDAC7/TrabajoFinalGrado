/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.as;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.Date;
import java.util.regex.Pattern;

public class a {
    protected final String a;
    protected final as b;
    protected final boolean c;
    protected final Date d;
    protected final boolean e;

    public a(String string, as as2, boolean bl2, Date date, boolean bl3) {
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'path' is null");
        }
        if (!Pattern.matches("(/(.|[\\r\\n])*)|(ns:[0-9]+(/.*)?)", string)) {
            throw new IllegalArgumentException("String 'path' does not match pattern");
        }
        this.a = string;
        if (as2 == null) {
            throw new IllegalArgumentException("Required value for 'mode' is null");
        }
        this.b = as2;
        this.c = bl2;
        this.d = com.dropbox.core.d.b.a(date);
        this.e = bl3;
    }

    public static a a(String string) {
        return new a(string);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (a)object;
        if (this.a != object.a) {
            if (!this.a.equals(object.a)) return false;
        }
        if (this.b != object.b) {
            if (!this.b.equals(object.b)) return false;
        }
        if (this.c != object.c) return false;
        if (this.d != object.d) {
            if (this.d == null) return false;
            if (!this.d.equals(object.d)) return false;
        }
        if (this.e == object.e) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b, this.c, this.d, this.e});
    }

    public String toString() {
        return b.a.a(this, false);
    }

    public static class a {
        protected final String a;
        protected as b;
        protected boolean c;
        protected Date d;
        protected boolean e;

        protected a(String string) {
            if (string == null) {
                throw new IllegalArgumentException("Required value for 'path' is null");
            }
            if (!Pattern.matches("(/(.|[\\r\\n])*)|(ns:[0-9]+(/.*)?)", string)) {
                throw new IllegalArgumentException("String 'path' does not match pattern");
            }
            this.a = string;
            this.b = as.a;
            this.c = false;
            this.d = null;
            this.e = false;
        }

        public a a(as as2) {
            if (as2 != null) {
                this.b = as2;
                return this;
            }
            this.b = as.a;
            return this;
        }

        public a a() {
            return new a(this.a, this.b, this.c, this.d, this.e);
        }
    }

    static class b
    extends d<a> {
        public static final b a = new b();

        b() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(a a2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("path");
            c.d().a(a2.a, jsonGenerator);
            jsonGenerator.writeFieldName("mode");
            as.a.a.a(a2.b, jsonGenerator);
            jsonGenerator.writeFieldName("autorename");
            c.c().a((Boolean)a2.c, jsonGenerator);
            if (a2.d != null) {
                jsonGenerator.writeFieldName("client_modified");
                c.a(c.e()).a(a2.d, jsonGenerator);
            }
            jsonGenerator.writeFieldName("mute");
            c.c().a((Boolean)a2.e, jsonGenerator);
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public a b(JsonParser jsonParser, boolean bl2) {
            Object object;
            Object object2 = null;
            if (!bl2) {
                b.e(jsonParser);
                object = b.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            Object object3 = as.a;
            object = false;
            Object object4 = false;
            String string = null;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                Object object5 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("path".equals(object5)) {
                    string = c.d().b(jsonParser);
                    object5 = object4;
                    object4 = object;
                    object = object5;
                } else if ("mode".equals(object5)) {
                    object5 = as.a.a.k(jsonParser);
                    object3 = object;
                    object = object4;
                    object4 = object3;
                    object3 = object5;
                } else if ("autorename".equals(object5)) {
                    object5 = c.c().b(jsonParser);
                    object = object4;
                    object4 = object5;
                } else if ("client_modified".equals(object5)) {
                    object5 = c.a(c.e()).b(jsonParser);
                    object2 = object;
                    object = object4;
                    object4 = object2;
                    object2 = object5;
                } else if ("mute".equals(object5)) {
                    object5 = c.c().b(jsonParser);
                    object4 = object;
                    object = object5;
                } else {
                    b.i(jsonParser);
                    object5 = object;
                    object = object4;
                    object4 = object5;
                }
                object5 = object;
                object = object4;
                object4 = object5;
            }
            if (string == null) {
                throw new JsonParseException(jsonParser, "Required field \"path\" missing.");
            }
            object = new a(string, (as)object3, object.booleanValue(), (Date)object2, object4.booleanValue());
            if (!bl2) {
                b.f(jsonParser);
            }
            return object;
        }
    }

}

