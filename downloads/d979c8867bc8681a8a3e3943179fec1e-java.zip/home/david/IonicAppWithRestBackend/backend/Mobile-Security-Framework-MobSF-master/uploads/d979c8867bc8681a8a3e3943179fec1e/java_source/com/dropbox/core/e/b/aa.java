/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.e;
import com.dropbox.core.e.b.ab;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public final class aa {
    public static final aa a = new aa(b.a, null);
    private final b b;
    private final ab c;

    private aa(b b2, ab ab2) {
        this.b = b2;
        this.c = ab2;
    }

    public static aa a(ab ab2) {
        if (ab2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new aa(b.b, ab2);
    }

    public b a() {
        return this.b;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!(object instanceof aa)) return bl3;
        object = (aa)object;
        bl3 = bl2;
        if (this.b != object.b) return bl3;
        switch (.a[this.b.ordinal()]) {
            default: {
                return false;
            }
            case 1: {
                return true;
            }
            case 2: 
        }
        if (this.c == object.c) return true;
        bl3 = bl2;
        if (!this.c.equals(object.c)) return bl3;
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.b, this.c});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends e<aa> {
        public static final a a = new a();

        a() {
        }

        @Override
        public void a(aa aa2, JsonGenerator jsonGenerator) {
            switch (.a[aa2.a().ordinal()]) {
                default: {
                    throw new IllegalArgumentException("Unrecognized tag: " + (Object)((Object)aa2.a()));
                }
                case 1: {
                    jsonGenerator.writeString("pending");
                    return;
                }
                case 2: 
            }
            jsonGenerator.writeStartObject();
            this.a("metadata", jsonGenerator);
            jsonGenerator.writeFieldName("metadata");
            ab.a.a.a(aa2.c, jsonGenerator);
            jsonGenerator.writeEndObject();
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Enabled aggressive block sorting
         */
        public aa k(JsonParser jsonParser) {
            boolean bl2;
            Object object;
            if (jsonParser.getCurrentToken() == JsonToken.VALUE_STRING) {
                bl2 = true;
                object = a.d(jsonParser);
                jsonParser.nextToken();
            } else {
                bl2 = false;
                a.e(jsonParser);
                object = a.c(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field missing: .tag");
            }
            if ("pending".equals(object)) {
                object = aa.a;
            } else {
                if (!"metadata".equals(object)) {
                    throw new JsonParseException(jsonParser, "Unknown tag: " + (String)object);
                }
                a.a("metadata", jsonParser);
                object = aa.a((ab)ab.a.a.b(jsonParser));
            }
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

    public static enum b {
        a,
        b;
        

        private b() {
        }
    }

}

