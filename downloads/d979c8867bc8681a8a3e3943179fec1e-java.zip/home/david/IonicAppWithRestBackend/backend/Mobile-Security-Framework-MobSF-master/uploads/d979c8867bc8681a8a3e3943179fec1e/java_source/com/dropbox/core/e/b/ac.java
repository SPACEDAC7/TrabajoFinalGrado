/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.f;
import com.dropbox.core.e.b.k;
import com.dropbox.core.e.b.m;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.regex.Pattern;

public class ac {
    protected final String j;
    protected final String k;
    protected final String l;
    protected final String m;

    public ac(String string, String string2, String string3, String string4) {
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'name' is null");
        }
        this.j = string;
        this.k = string2;
        this.l = string3;
        if (string4 != null && !Pattern.matches("[-_0-9a-zA-Z:]+", string4)) {
            throw new IllegalArgumentException("String 'parentSharedFolderId' does not match pattern");
        }
        this.m = string4;
    }

    public String a() {
        return this.j;
    }

    public String b() {
        return this.k;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (ac)object;
        if (this.j != object.j) {
            if (!this.j.equals(object.j)) return false;
        }
        if (this.k != object.k) {
            if (this.k == null) return false;
            if (!this.k.equals(object.k)) return false;
        }
        if (this.l != object.l) {
            if (this.l == null) return false;
            if (!this.l.equals(object.l)) return false;
        }
        if (this.m == object.m) return true;
        if (this.m == null) return false;
        if (this.m.equals(object.m)) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.j, this.k, this.l, this.m});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<ac> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void a(ac ac2, JsonGenerator jsonGenerator, boolean bl2) {
            if (ac2 instanceof k) {
                k.a.a.a((k)ac2, jsonGenerator, bl2);
                return;
            } else {
                if (ac2 instanceof m) {
                    m.a.a.a((m)ac2, jsonGenerator, bl2);
                    return;
                }
                if (ac2 instanceof f) {
                    f.a.a.a((f)ac2, jsonGenerator, bl2);
                    return;
                }
                if (!bl2) {
                    jsonGenerator.writeStartObject();
                }
                jsonGenerator.writeFieldName("name");
                c.d().a(ac2.j, jsonGenerator);
                if (ac2.k != null) {
                    jsonGenerator.writeFieldName("path_lower");
                    c.a(c.d()).a(ac2.k, jsonGenerator);
                }
                if (ac2.l != null) {
                    jsonGenerator.writeFieldName("path_display");
                    c.a(c.d()).a(ac2.l, jsonGenerator);
                }
                if (ac2.m != null) {
                    jsonGenerator.writeFieldName("parent_shared_folder_id");
                    c.a(c.d()).a(ac2.m, jsonGenerator);
                }
                if (bl2) return;
                {
                    jsonGenerator.writeEndObject();
                    return;
                }
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public ac b(JsonParser jsonParser, boolean bl2) {
            Object object;
            String string;
            String string2 = null;
            if (!bl2) {
                a.e(jsonParser);
                object = string = a.c(jsonParser);
                if ("".equals(string)) {
                    object = null;
                }
            } else {
                object = null;
            }
            if (object != null) {
                if ("".equals(object)) {
                    object = a.b(jsonParser, true);
                } else if ("file".equals(object)) {
                    object = k.a.a.b(jsonParser, true);
                } else if ("folder".equals(object)) {
                    object = m.a.a.b(jsonParser, true);
                } else {
                    if (!"deleted".equals(object)) {
                        throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
                    }
                    object = f.a.a.b(jsonParser, true);
                }
            } else {
                String string3 = null;
                String string4 = null;
                string = null;
                object = string2;
                while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                    string2 = jsonParser.getCurrentName();
                    jsonParser.nextToken();
                    if ("name".equals(string2)) {
                        string2 = c.d().b(jsonParser);
                        string = string3;
                        string3 = string4;
                        string4 = string2;
                    } else if ("path_lower".equals(string2)) {
                        string2 = c.a(c.d()).b(jsonParser);
                        string4 = string;
                        string = string3;
                        string3 = string2;
                    } else if ("path_display".equals(string2)) {
                        string2 = c.a(c.d()).b(jsonParser);
                        string3 = string4;
                        string4 = string;
                        string = string2;
                    } else if ("parent_shared_folder_id".equals(string2)) {
                        object = c.a(c.d()).b(jsonParser);
                        string2 = string;
                        string = string3;
                        string3 = string4;
                        string4 = string2;
                    } else {
                        a.i(jsonParser);
                        string2 = string;
                        string = string3;
                        string3 = string4;
                        string4 = string2;
                    }
                    string2 = string4;
                    string4 = string3;
                    string3 = string;
                    string = string2;
                }
                if (string == null) {
                    throw new JsonParseException(jsonParser, "Required field \"name\" missing.");
                }
                object = new ac(string, string4, string3, (String)object);
            }
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

