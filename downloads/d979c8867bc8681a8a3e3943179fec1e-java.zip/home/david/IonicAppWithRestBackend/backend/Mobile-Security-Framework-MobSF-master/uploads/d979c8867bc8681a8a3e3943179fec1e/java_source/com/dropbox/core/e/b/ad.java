/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public class ad {
    protected final String a;

    public ad() {
        this(null);
    }

    public ad(String string) {
        this.a = string;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!object.getClass().equals(this.getClass())) return bl3;
        object = (ad)object;
        if (this.a == object.a) return true;
        bl3 = bl2;
        if (this.a == null) return bl3;
        bl3 = bl2;
        if (!this.a.equals(object.a)) return bl3;
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    public static class a
    extends d<ad> {
        public static final a a = new a();

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(ad ad2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            if (ad2.a != null) {
                jsonGenerator.writeFieldName("path_root");
                c.a(c.d()).a(ad2.a, jsonGenerator);
            }
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public ad b(JsonParser jsonParser, boolean bl2) {
            Object object;
            String string = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            object = string;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                string = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("path_root".equals(string)) {
                    object = c.a(c.d()).b(jsonParser);
                    continue;
                }
                a.i(jsonParser);
            }
            object = new ad((String)object);
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

