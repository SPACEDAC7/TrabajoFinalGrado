/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.ab;
import com.dropbox.core.e.b.g;
import com.dropbox.core.e.b.r;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Date;

public class ae
extends ab {
    public ae() {
        this(null, null, null);
    }

    public ae(g g2, r r2, Date date) {
        super(g2, r2, date);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (ae)object;
        if (this.a != object.a) {
            if (this.a == null) return false;
            if (!this.a.equals(object.a)) return false;
        }
        if (this.b != object.b) {
            if (this.b == null) return false;
            if (!this.b.equals(object.b)) return false;
        }
        if (this.c == object.c) return true;
        if (this.c == null) return false;
        if (this.c.equals(object.c)) return true;
        return false;
    }

    @Override
    public int hashCode() {
        return this.getClass().toString().hashCode();
    }

    @Override
    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<ae> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(ae ae2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            this.a("photo", jsonGenerator);
            if (ae2.a != null) {
                jsonGenerator.writeFieldName("dimensions");
                c.a(g.a.a).a(ae2.a, jsonGenerator);
            }
            if (ae2.b != null) {
                jsonGenerator.writeFieldName("location");
                c.a(r.a.a).a(ae2.b, jsonGenerator);
            }
            if (ae2.c != null) {
                jsonGenerator.writeFieldName("time_taken");
                c.a(c.e()).a(ae2.c, jsonGenerator);
            }
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public ae b(JsonParser jsonParser, boolean bl2) {
            Object object;
            Object object2;
            Object object3 = null;
            if (!bl2) {
                a.e(jsonParser);
                object2 = object = a.c(jsonParser);
                if ("photo".equals(object)) {
                    object2 = null;
                }
            } else {
                object2 = null;
            }
            if (object2 != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object2 + "\"");
            }
            Object object4 = null;
            object = null;
            object2 = object3;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                object3 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("dimensions".equals(object3)) {
                    object3 = (g)c.a(g.a.a).b(jsonParser);
                    object = object4;
                    object4 = object3;
                } else if ("location".equals(object3)) {
                    object3 = (r)c.a(r.a.a).b(jsonParser);
                    object4 = object;
                    object = object3;
                } else if ("time_taken".equals(object3)) {
                    object2 = c.a(c.e()).b(jsonParser);
                    object3 = object;
                    object = object4;
                    object4 = object3;
                } else {
                    a.i(jsonParser);
                    object3 = object;
                    object = object4;
                    object4 = object3;
                }
                object3 = object4;
                object4 = object;
                object = object3;
            }
            object2 = new ae((g)object, (r)object4, (Date)object2);
            if (!bl2) {
                a.f(jsonParser);
            }
            return object2;
        }
    }

}

