/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.ai;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

class af
extends ai {
    protected final boolean a;
    protected final boolean b;

    public af(String string, String string2) {
        this(string, string2, false, false);
    }

    public af(String string, String string2, boolean bl2, boolean bl3) {
        super(string, string2);
        this.a = bl2;
        this.b = bl3;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (af)object;
        if (this.c != object.c) {
            if (!this.c.equals(object.c)) return false;
        }
        if (this.d != object.d) {
            if (!this.d.equals(object.d)) return false;
        }
        if (this.a != object.a) return false;
        if (this.b == object.b) return true;
        return false;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b}) + super.hashCode() * 31;
    }

    @Override
    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<af> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(af af2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("from_path");
            c.d().a(af2.c, jsonGenerator);
            jsonGenerator.writeFieldName("to_path");
            c.d().a(af2.d, jsonGenerator);
            jsonGenerator.writeFieldName("allow_shared_folder");
            c.c().a((Boolean)af2.a, jsonGenerator);
            jsonGenerator.writeFieldName("autorename");
            c.c().a((Boolean)af2.b, jsonGenerator);
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public af b(JsonParser jsonParser, boolean bl2) {
            Object object;
            Object object2 = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            Object object3 = false;
            object = false;
            Object object4 = null;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                Object object5 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("from_path".equals(object5)) {
                    object5 = c.d().b(jsonParser);
                    object4 = object3;
                    object3 = object2;
                    object2 = object5;
                } else if ("to_path".equals(object5)) {
                    object5 = c.d().b(jsonParser);
                    object2 = object4;
                    object4 = object3;
                    object3 = object5;
                } else if ("allow_shared_folder".equals(object5)) {
                    object5 = c.c().b(jsonParser);
                    object3 = object2;
                    object2 = object4;
                    object4 = object5;
                } else if ("autorename".equals(object5)) {
                    object = c.c().b(jsonParser);
                    object5 = object4;
                    object4 = object3;
                    object3 = object2;
                    object2 = object5;
                } else {
                    a.i(jsonParser);
                    object5 = object4;
                    object4 = object3;
                    object3 = object2;
                    object2 = object5;
                }
                object5 = object2;
                object2 = object3;
                object3 = object4;
                object4 = object5;
            }
            if (object4 == null) {
                throw new JsonParseException(jsonParser, "Required field \"from_path\" missing.");
            }
            if (object2 == null) {
                throw new JsonParseException(jsonParser, "Required field \"to_path\" missing.");
            }
            object = new af((String)object4, (String)object2, object3.booleanValue(), object.booleanValue());
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

