/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.e;
import com.dropbox.core.e.b.ar;
import com.dropbox.core.e.b.z;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public final class ag {
    public static final ag a = new ag(b.d, null, null, null);
    public static final ag b = new ag(b.e, null, null, null);
    public static final ag c = new ag(b.f, null, null, null);
    public static final ag d = new ag(b.g, null, null, null);
    public static final ag e = new ag(b.h, null, null, null);
    private final b f;
    private final z g;
    private final ar h;
    private final ar i;

    private ag(b b2, z z2, ar ar2, ar ar3) {
        this.f = b2;
        this.g = z2;
        this.h = ar2;
        this.i = ar3;
    }

    public static ag a(ar ar2) {
        if (ar2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new ag(b.b, null, ar2, null);
    }

    public static ag a(z z2) {
        if (z2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new ag(b.a, z2, null, null);
    }

    public static ag b(ar ar2) {
        if (ar2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new ag(b.c, null, null, ar2);
    }

    public b a() {
        return this.f;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        boolean bl3 = false;
        boolean bl4 = false;
        if (object == this) {
            do {
                return true;
                break;
            } while (true);
        }
        if (!(object instanceof ag)) return false;
        object = (ag)object;
        if (this.f != object.f) {
            return false;
        }
        switch (.a[this.f.ordinal()]) {
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: {
                return true;
            }
            default: {
                return false;
            }
            case 1: {
                if (this.g == object.g) return true;
                if (!this.g.equals(object.g)) return bl4;
                return true;
            }
            case 2: {
                if (this.h == object.h) return true;
                bl4 = bl2;
                if (!this.h.equals(object.h)) return bl4;
                return true;
            }
            case 3: 
        }
        if (this.i == object.i) return true;
        bl4 = bl3;
        if (!this.i.equals(object.i)) return bl4;
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f, this.g, this.h, this.i});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends e<ag> {
        public static final a a = new a();

        a() {
        }

        @Override
        public void a(ag ag2, JsonGenerator jsonGenerator) {
            switch (.a[ag2.a().ordinal()]) {
                default: {
                    jsonGenerator.writeString("other");
                    return;
                }
                case 1: {
                    jsonGenerator.writeStartObject();
                    this.a("from_lookup", jsonGenerator);
                    jsonGenerator.writeFieldName("from_lookup");
                    z.a.a.a(ag2.g, jsonGenerator);
                    jsonGenerator.writeEndObject();
                    return;
                }
                case 2: {
                    jsonGenerator.writeStartObject();
                    this.a("from_write", jsonGenerator);
                    jsonGenerator.writeFieldName("from_write");
                    ar.a.a.a(ag2.h, jsonGenerator);
                    jsonGenerator.writeEndObject();
                    return;
                }
                case 3: {
                    jsonGenerator.writeStartObject();
                    this.a("to", jsonGenerator);
                    jsonGenerator.writeFieldName("to");
                    ar.a.a.a(ag2.i, jsonGenerator);
                    jsonGenerator.writeEndObject();
                    return;
                }
                case 4: {
                    jsonGenerator.writeString("cant_copy_shared_folder");
                    return;
                }
                case 5: {
                    jsonGenerator.writeString("cant_nest_shared_folder");
                    return;
                }
                case 6: {
                    jsonGenerator.writeString("cant_move_folder_into_itself");
                    return;
                }
                case 7: 
            }
            jsonGenerator.writeString("too_many_files");
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Enabled aggressive block sorting
         */
        public ag k(JsonParser jsonParser) {
            boolean bl2;
            Object object;
            if (jsonParser.getCurrentToken() == JsonToken.VALUE_STRING) {
                bl2 = true;
                object = a.d(jsonParser);
                jsonParser.nextToken();
            } else {
                bl2 = false;
                a.e(jsonParser);
                object = a.c(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field missing: .tag");
            }
            if ("from_lookup".equals(object)) {
                a.a("from_lookup", jsonParser);
                object = ag.a(z.a.a.k(jsonParser));
            } else if ("from_write".equals(object)) {
                a.a("from_write", jsonParser);
                object = ag.a(ar.a.a.k(jsonParser));
            } else if ("to".equals(object)) {
                a.a("to", jsonParser);
                object = ag.b(ar.a.a.k(jsonParser));
            } else if ("cant_copy_shared_folder".equals(object)) {
                object = ag.a;
            } else if ("cant_nest_shared_folder".equals(object)) {
                object = ag.b;
            } else if ("cant_move_folder_into_itself".equals(object)) {
                object = ag.c;
            } else if ("too_many_files".equals(object)) {
                object = ag.d;
            } else {
                object = ag.e;
                a.j(jsonParser);
            }
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

    public static enum b {
        a,
        b,
        c,
        d,
        e,
        f,
        g,
        h;
        

        private b() {
        }
    }

}

