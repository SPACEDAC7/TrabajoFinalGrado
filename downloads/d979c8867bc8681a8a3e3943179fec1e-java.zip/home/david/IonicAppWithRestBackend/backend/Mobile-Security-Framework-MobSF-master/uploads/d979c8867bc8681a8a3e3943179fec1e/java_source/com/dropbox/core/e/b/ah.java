/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.e;
import com.dropbox.core.e.b.ag;
import com.dropbox.core.o;

public class ah
extends e {
    public final ag a;

    public ah(String string, String string2, o o2, ag ag2) {
        super(string2, o2, ah.a(string, o2, ag2));
        if (ag2 == null) {
            throw new NullPointerException("errorValue");
        }
        this.a = ag2;
    }
}

