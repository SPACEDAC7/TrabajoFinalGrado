/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public class aj {
    protected final boolean e;

    public aj(boolean bl2) {
        this.e = bl2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (aj)object;
        if (this.e == object.e) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.e});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    private static class a
    extends d<aj> {
        public static final a a = new a();

        private a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(aj aj2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("read_only");
            c.c().a((Boolean)aj2.e, jsonGenerator);
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public aj b(JsonParser jsonParser, boolean bl2) {
            Object object;
            String string = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            object = string;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                string = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("read_only".equals(string)) {
                    object = c.c().b(jsonParser);
                    continue;
                }
                a.i(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field \"read_only\" missing.");
            }
            object = new aj(object.booleanValue());
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

