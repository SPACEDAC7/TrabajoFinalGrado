/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.e.b.a;
import com.dropbox.core.e.b.al;
import com.dropbox.core.e.b.am;
import com.dropbox.core.e.b.an;
import com.dropbox.core.e.b.as;
import com.dropbox.core.e.b.b;
import com.dropbox.core.e.b.k;
import com.dropbox.core.e.d;
import com.dropbox.core.l;

public class ak
extends d<k, al, am> {
    private final b a;
    private final a.a b;

    ak(b b2, a.a a2) {
        if (b2 == null) {
            throw new NullPointerException("_client");
        }
        this.a = b2;
        if (a2 == null) {
            throw new NullPointerException("_builder");
        }
        this.b = a2;
    }

    public ak a(as as2) {
        this.b.a(as2);
        return this;
    }

    @Override
    public /* synthetic */ l a() {
        return this.b();
    }

    public an b() {
        a a2 = this.b.a();
        return this.a.a(a2);
    }
}

