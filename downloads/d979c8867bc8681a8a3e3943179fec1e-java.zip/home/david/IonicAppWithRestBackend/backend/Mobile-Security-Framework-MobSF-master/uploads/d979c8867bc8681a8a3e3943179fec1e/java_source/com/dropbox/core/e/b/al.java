/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.e;
import com.dropbox.core.e.b.ao;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public final class al {
    public static final al a = new al(b.b, null);
    private final b b;
    private final ao c;

    private al(b b2, ao ao2) {
        this.b = b2;
        this.c = ao2;
    }

    public static al a(ao ao2) {
        if (ao2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new al(b.a, ao2);
    }

    public b a() {
        return this.b;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!(object instanceof al)) return bl3;
        object = (al)object;
        bl3 = bl2;
        if (this.b != object.b) return bl3;
        switch (.a[this.b.ordinal()]) {
            default: {
                return false;
            }
            case 1: {
                if (this.c == object.c) return true;
                bl3 = bl2;
                if (!this.c.equals(object.c)) return bl3;
                return true;
            }
            case 2: 
        }
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.b, this.c});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends e<al> {
        public static final a a = new a();

        a() {
        }

        @Override
        public void a(al al2, JsonGenerator jsonGenerator) {
            switch (al2.a()) {
                default: {
                    jsonGenerator.writeString("other");
                    return;
                }
                case a: 
            }
            jsonGenerator.writeStartObject();
            this.a("path", jsonGenerator);
            ao.a.a.a(al2.c, jsonGenerator, true);
            jsonGenerator.writeEndObject();
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Enabled aggressive block sorting
         */
        public al k(JsonParser jsonParser) {
            boolean bl2;
            Object object;
            if (jsonParser.getCurrentToken() == JsonToken.VALUE_STRING) {
                object = a.d(jsonParser);
                jsonParser.nextToken();
                bl2 = true;
            } else {
                bl2 = false;
                a.e(jsonParser);
                object = a.c(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field missing: .tag");
            }
            if ("path".equals(object)) {
                object = al.a(ao.a.a.b(jsonParser, true));
            } else {
                object = al.a;
                a.j(jsonParser);
            }
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

    public static enum b {
        a,
        b;
        

        private b() {
        }
    }

}

