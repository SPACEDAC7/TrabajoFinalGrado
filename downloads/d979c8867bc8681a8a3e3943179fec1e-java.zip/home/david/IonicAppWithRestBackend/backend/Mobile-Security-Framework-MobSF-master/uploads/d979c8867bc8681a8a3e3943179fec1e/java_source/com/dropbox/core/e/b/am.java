/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.e;
import com.dropbox.core.e.b.al;
import com.dropbox.core.o;

public class am
extends e {
    public final al a;

    public am(String string, String string2, o o2, al al2) {
        super(string2, o2, am.a(string, o2, al2));
        if (al2 == null) {
            throw new NullPointerException("errorValue");
        }
        this.a = al2;
    }
}

