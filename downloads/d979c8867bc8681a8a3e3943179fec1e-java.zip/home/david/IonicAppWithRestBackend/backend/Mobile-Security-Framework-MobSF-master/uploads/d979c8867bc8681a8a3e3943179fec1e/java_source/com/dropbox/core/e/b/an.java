/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.a.a;
import com.dropbox.core.c.b;
import com.dropbox.core.e;
import com.dropbox.core.e.b.al;
import com.dropbox.core.e.b.am;
import com.dropbox.core.e.b.k;
import com.dropbox.core.l;
import com.dropbox.core.m;
import com.dropbox.core.o;

public class an
extends l<k, al, am> {
    public an(a.c c2) {
        super(c2, k.a.a, al.a.a);
    }

    @Override
    protected /* synthetic */ e a(m m2) {
        return this.b(m2);
    }

    protected am b(m m2) {
        return new am("2/files/upload", m2.b(), m2.c(), (al)m2.a());
    }
}

