/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.ar;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public class ao {
    protected final ar a;
    protected final String b;

    public ao(ar ar2, String string) {
        if (ar2 == null) {
            throw new IllegalArgumentException("Required value for 'reason' is null");
        }
        this.a = ar2;
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'uploadSessionId' is null");
        }
        this.b = string;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (ao)object;
        if (this.a != object.a) {
            if (!this.a.equals(object.a)) return false;
        }
        if (this.b == object.b) return true;
        if (this.b.equals(object.b)) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<ao> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(ao ao2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("reason");
            ar.a.a.a(ao2.a, jsonGenerator);
            jsonGenerator.writeFieldName("upload_session_id");
            c.d().a(ao2.b, jsonGenerator);
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public ao b(JsonParser jsonParser, boolean bl2) {
            Object object;
            String string = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            object = null;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                String string2 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("reason".equals(string2)) {
                    object = ar.a.a.k(jsonParser);
                    continue;
                }
                if ("upload_session_id".equals(string2)) {
                    string = c.d().b(jsonParser);
                    continue;
                }
                a.i(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field \"reason\" missing.");
            }
            if (string == null) {
                throw new JsonParseException(jsonParser, "Required field \"upload_session_id\" missing.");
            }
            object = new ao((ar)object, string);
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

