/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.ab;
import com.dropbox.core.e.b.g;
import com.dropbox.core.e.b.r;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.Date;

public class ap
extends ab {
    protected final Long d;

    public ap() {
        this(null, null, null, null);
    }

    public ap(g g2, r r2, Date date, Long l2) {
        super(g2, r2, date);
        this.d = l2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (ap)object;
        if (this.a != object.a) {
            if (this.a == null) return false;
            if (!this.a.equals(object.a)) return false;
        }
        if (this.b != object.b) {
            if (this.b == null) return false;
            if (!this.b.equals(object.b)) return false;
        }
        if (this.c != object.c) {
            if (this.c == null) return false;
            if (!this.c.equals(object.c)) return false;
        }
        if (this.d == object.d) return true;
        if (this.d == null) return false;
        if (this.d.equals(object.d)) return true;
        return false;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.d}) + super.hashCode() * 31;
    }

    @Override
    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<ap> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(ap ap2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            this.a("video", jsonGenerator);
            if (ap2.a != null) {
                jsonGenerator.writeFieldName("dimensions");
                c.a(g.a.a).a(ap2.a, jsonGenerator);
            }
            if (ap2.b != null) {
                jsonGenerator.writeFieldName("location");
                c.a(r.a.a).a(ap2.b, jsonGenerator);
            }
            if (ap2.c != null) {
                jsonGenerator.writeFieldName("time_taken");
                c.a(c.e()).a(ap2.c, jsonGenerator);
            }
            if (ap2.d != null) {
                jsonGenerator.writeFieldName("duration");
                c.a(c.a()).a(ap2.d, jsonGenerator);
            }
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public ap b(JsonParser jsonParser, boolean bl2) {
            Object object;
            Object object2;
            Object object3 = null;
            if (!bl2) {
                a.e(jsonParser);
                object2 = object = a.c(jsonParser);
                if ("video".equals(object)) {
                    object2 = null;
                }
            } else {
                object2 = null;
            }
            if (object2 != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object2 + "\"");
            }
            Object object4 = null;
            Object object5 = null;
            object = null;
            object2 = object3;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                object3 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("dimensions".equals(object3)) {
                    object3 = (g)c.a(g.a.a).b(jsonParser);
                    object = object4;
                    object4 = object5;
                    object5 = object3;
                } else if ("location".equals(object3)) {
                    object3 = (r)c.a(r.a.a).b(jsonParser);
                    object5 = object;
                    object = object4;
                    object4 = object3;
                } else if ("time_taken".equals(object3)) {
                    object3 = c.a(c.e()).b(jsonParser);
                    object4 = object5;
                    object5 = object;
                    object = object3;
                } else if ("duration".equals(object3)) {
                    object2 = c.a(c.a()).b(jsonParser);
                    object3 = object;
                    object = object4;
                    object4 = object5;
                    object5 = object3;
                } else {
                    a.i(jsonParser);
                    object3 = object;
                    object = object4;
                    object4 = object5;
                    object5 = object3;
                }
                object3 = object5;
                object5 = object4;
                object4 = object;
                object = object3;
            }
            object2 = new ap((g)object, (r)object5, (Date)object4, (Long)object2);
            if (!bl2) {
                a.f(jsonParser);
            }
            return object2;
        }
    }

}

