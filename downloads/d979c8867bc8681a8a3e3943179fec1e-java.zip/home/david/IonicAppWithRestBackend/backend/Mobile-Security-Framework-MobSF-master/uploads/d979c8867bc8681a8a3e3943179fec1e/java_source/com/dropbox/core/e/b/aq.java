/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.e;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

public enum aq {
    a,
    b,
    c,
    d;
    

    private aq() {
    }

    static class a
    extends e<aq> {
        public static final a a = new a();

        a() {
        }

        @Override
        public void a(aq aq2, JsonGenerator jsonGenerator) {
            switch (.a[aq2.ordinal()]) {
                default: {
                    jsonGenerator.writeString("other");
                    return;
                }
                case 1: {
                    jsonGenerator.writeString("file");
                    return;
                }
                case 2: {
                    jsonGenerator.writeString("folder");
                    return;
                }
                case 3: 
            }
            jsonGenerator.writeString("file_ancestor");
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Enabled aggressive block sorting
         */
        public aq k(JsonParser jsonParser) {
            boolean bl2;
            Object object;
            if (jsonParser.getCurrentToken() == JsonToken.VALUE_STRING) {
                bl2 = true;
                object = a.d(jsonParser);
                jsonParser.nextToken();
            } else {
                bl2 = false;
                a.e(jsonParser);
                object = a.c(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field missing: .tag");
            }
            if ("file".equals(object)) {
                object = aq.a;
            } else if ("folder".equals(object)) {
                object = aq.b;
            } else if ("file_ancestor".equals(object)) {
                object = aq.c;
            } else {
                object = aq.d;
                a.j(jsonParser);
            }
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

