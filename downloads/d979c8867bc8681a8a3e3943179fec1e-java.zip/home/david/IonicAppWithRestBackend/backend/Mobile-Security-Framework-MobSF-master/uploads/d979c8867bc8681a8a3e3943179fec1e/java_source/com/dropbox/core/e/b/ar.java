/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.e;
import com.dropbox.core.e.b.aq;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public final class ar {
    public static final ar a = new ar(b.c, null, null);
    public static final ar b = new ar(b.d, null, null);
    public static final ar c = new ar(b.e, null, null);
    public static final ar d = new ar(b.f, null, null);
    private final b e;
    private final String f;
    private final aq g;

    private ar(b b2, String string, aq aq2) {
        this.e = b2;
        this.f = string;
        this.g = aq2;
    }

    public static ar a(aq aq2) {
        if (aq2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new ar(b.b, null, aq2);
    }

    public static ar a(String string) {
        return new ar(b.a, string, null);
    }

    public static ar b() {
        return ar.a(null);
    }

    public b a() {
        return this.e;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        boolean bl3 = false;
        if (object == this) {
            do {
                return true;
                break;
            } while (true);
        }
        if (!(object instanceof ar)) return false;
        object = (ar)object;
        if (this.e != object.e) {
            return false;
        }
        switch (.a[this.e.ordinal()]) {
            case 3: 
            case 4: 
            case 5: 
            case 6: {
                return true;
            }
            default: {
                return false;
            }
            case 1: {
                if (this.f == object.f) return true;
                bl2 = bl3;
                if (this.f == null) return bl2;
                bl2 = bl3;
                if (!this.f.equals(object.f)) return bl2;
                return true;
            }
            case 2: 
        }
        if (this.g == object.g) return true;
        if (!this.g.equals((Object)object.g)) return bl2;
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.e, this.f, this.g});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends e<ar> {
        public static final a a = new a();

        a() {
        }

        @Override
        public void a(ar ar2, JsonGenerator jsonGenerator) {
            switch (.a[ar2.a().ordinal()]) {
                default: {
                    jsonGenerator.writeString("other");
                    return;
                }
                case 1: {
                    jsonGenerator.writeStartObject();
                    this.a("malformed_path", jsonGenerator);
                    jsonGenerator.writeFieldName("malformed_path");
                    c.a(c.d()).a(ar2.f, jsonGenerator);
                    jsonGenerator.writeEndObject();
                    return;
                }
                case 2: {
                    jsonGenerator.writeStartObject();
                    this.a("conflict", jsonGenerator);
                    jsonGenerator.writeFieldName("conflict");
                    aq.a.a.a(ar2.g, jsonGenerator);
                    jsonGenerator.writeEndObject();
                    return;
                }
                case 3: {
                    jsonGenerator.writeString("no_write_permission");
                    return;
                }
                case 4: {
                    jsonGenerator.writeString("insufficient_space");
                    return;
                }
                case 5: 
            }
            jsonGenerator.writeString("disallowed_name");
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public ar k(JsonParser var1_1) {
            if (var1_1.getCurrentToken() == JsonToken.VALUE_STRING) {
                var2_2 = true;
                var3_3 = a.d(var1_1);
                var1_1.nextToken();
            } else {
                var2_2 = false;
                a.e(var1_1);
                var3_3 = a.c(var1_1);
            }
            if (var3_3 == null) {
                throw new JsonParseException(var1_1, "Required field missing: .tag");
            }
            if (!"malformed_path".equals(var3_3)) ** GOTO lbl21
            var3_3 = null;
            if (var1_1.getCurrentToken() == JsonToken.END_OBJECT) ** GOTO lbl-1000
            a.a("malformed_path", var1_1);
            var3_3 = c.a(c.d()).b(var1_1);
            if (var3_3 == null) lbl-1000: // 2 sources:
            {
                var3_3 = ar.b();
            } else {
                var3_3 = ar.a((String)var3_3);
            }
            ** GOTO lbl36
lbl21: // 1 sources:
            if ("conflict".equals(var3_3)) {
                a.a("conflict", var1_1);
                var3_3 = ar.a(aq.a.a.k(var1_1));
            } else if ("no_write_permission".equals(var3_3)) {
                var3_3 = ar.a;
            } else if ("insufficient_space".equals(var3_3)) {
                var3_3 = ar.b;
            } else if ("disallowed_name".equals(var3_3)) {
                var3_3 = ar.c;
            } else {
                var3_3 = ar.d;
                a.j(var1_1);
            }
lbl36: // 7 sources:
            if (var2_2 != false) return var3_3;
            a.f(var1_1);
            return var3_3;
        }
    }

    public static enum b {
        a,
        b,
        c,
        d,
        e,
        f;
        

        private b() {
        }
    }

}

