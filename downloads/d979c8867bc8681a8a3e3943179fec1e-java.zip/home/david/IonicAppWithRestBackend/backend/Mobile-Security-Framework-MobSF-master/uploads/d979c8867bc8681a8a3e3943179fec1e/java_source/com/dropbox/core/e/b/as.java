/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.e;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.regex.Pattern;

public final class as {
    public static final as a = new as(b.a, null);
    public static final as b = new as(b.b, null);
    private final b c;
    private final String d;

    private as(b b2, String string) {
        this.c = b2;
        this.d = string;
    }

    public static as a(String string) {
        if (string == null) {
            throw new IllegalArgumentException("Value is null");
        }
        if (string.length() < 9) {
            throw new IllegalArgumentException("String is shorter than 9");
        }
        if (!Pattern.matches("[0-9a-f]+", string)) {
            throw new IllegalArgumentException("String does not match pattern");
        }
        return new as(b.c, string);
    }

    public b a() {
        return this.c;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!(object instanceof as)) return bl3;
        object = (as)object;
        bl3 = bl2;
        if (this.c != object.c) return bl3;
        switch (.a[this.c.ordinal()]) {
            default: {
                return false;
            }
            case 1: {
                return true;
            }
            case 2: {
                return true;
            }
            case 3: 
        }
        if (this.d == object.d) return true;
        bl3 = bl2;
        if (!this.d.equals(object.d)) return bl3;
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.c, this.d});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends e<as> {
        public static final a a = new a();

        a() {
        }

        @Override
        public void a(as as2, JsonGenerator jsonGenerator) {
            switch (.a[as2.a().ordinal()]) {
                default: {
                    throw new IllegalArgumentException("Unrecognized tag: " + (Object)((Object)as2.a()));
                }
                case 1: {
                    jsonGenerator.writeString("add");
                    return;
                }
                case 2: {
                    jsonGenerator.writeString("overwrite");
                    return;
                }
                case 3: 
            }
            jsonGenerator.writeStartObject();
            this.a("update", jsonGenerator);
            jsonGenerator.writeFieldName("update");
            c.d().a(as2.d, jsonGenerator);
            jsonGenerator.writeEndObject();
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Enabled aggressive block sorting
         */
        public as k(JsonParser jsonParser) {
            boolean bl2;
            Object object;
            if (jsonParser.getCurrentToken() == JsonToken.VALUE_STRING) {
                bl2 = true;
                object = a.d(jsonParser);
                jsonParser.nextToken();
            } else {
                bl2 = false;
                a.e(jsonParser);
                object = a.c(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field missing: .tag");
            }
            if ("add".equals(object)) {
                object = as.a;
            } else if ("overwrite".equals(object)) {
                object = as.b;
            } else {
                if (!"update".equals(object)) {
                    throw new JsonParseException(jsonParser, "Unknown tag: " + (String)object);
                }
                a.a("update", jsonParser);
                object = as.a(c.d().b(jsonParser));
            }
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

    public static enum b {
        a,
        b,
        c;
        

        private b() {
        }
    }

}

