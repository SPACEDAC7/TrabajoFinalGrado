/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.a.a;
import com.dropbox.core.e.b.a;
import com.dropbox.core.e.b.ac;
import com.dropbox.core.e.b.af;
import com.dropbox.core.e.b.ag;
import com.dropbox.core.e.b.ah;
import com.dropbox.core.e.b.ak;
import com.dropbox.core.e.b.an;
import com.dropbox.core.e.b.c;
import com.dropbox.core.e.b.d;
import com.dropbox.core.e.b.e;
import com.dropbox.core.e.b.h;
import com.dropbox.core.e.b.i;
import com.dropbox.core.e.b.j;
import com.dropbox.core.e.b.k;
import com.dropbox.core.e.b.o;
import com.dropbox.core.e.b.p;
import com.dropbox.core.e.b.q;
import com.dropbox.core.e.b.s;
import com.dropbox.core.e.b.t;
import com.dropbox.core.e.b.u;
import com.dropbox.core.e.b.v;
import com.dropbox.core.e.b.w;
import com.dropbox.core.e.b.x;
import com.dropbox.core.e.b.y;
import com.dropbox.core.e.c;
import com.dropbox.core.f;
import com.dropbox.core.h;
import com.dropbox.core.m;
import com.dropbox.core.o;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

public class b {
    private final c a;

    public b(c c2) {
        this.a = c2;
    }

    ac a(af object) {
        try {
            object = (ac)this.a.a(this.a.a().a(), "2/files/move", object, false, af.a.a, ac.a.a, ag.a.a);
            return object;
        }
        catch (m var1_2) {
            throw new ah("2/files/move", var1_2.b(), var1_2.c(), (ag)var1_2.a());
        }
    }

    ac a(com.dropbox.core.e.b.c object) {
        try {
            object = (ac)this.a.a(this.a.a().a(), "2/files/delete", object, false, c.a.a, ac.a.a, d.a.a);
            return object;
        }
        catch (m var1_2) {
            throw new e("2/files/delete", var1_2.b(), var1_2.c(), (d)var1_2.a());
        }
    }

    ac a(com.dropbox.core.e.b.o object) {
        try {
            object = (ac)this.a.a(this.a.a().a(), "2/files/get_metadata", object, false, o.a.a, ac.a.a, p.a.a);
            return object;
        }
        catch (m var1_2) {
            throw new q("2/files/get_metadata", var1_2.b(), var1_2.c(), (p)var1_2.a());
        }
    }

    public ac a(String string) {
        return this.a(new com.dropbox.core.e.b.c(string));
    }

    an a(a a2) {
        return new an(this.a.a(this.a.a().b(), "2/files/upload", a2, false, a.b.a));
    }

    y a(s object) {
        try {
            object = (y)this.a.a(this.a.a().a(), "2/files/list_folder", object, false, s.a.a, y.a.a, w.a.a);
            return object;
        }
        catch (m var1_2) {
            throw new x("2/files/list_folder", var1_2.b(), var1_2.c(), (w)var1_2.a());
        }
    }

    y a(t object) {
        try {
            object = (y)this.a.a(this.a.a().a(), "2/files/list_folder/continue", object, false, t.a.a, y.a.a, u.a.a);
            return object;
        }
        catch (m var1_2) {
            throw new v("2/files/list_folder/continue", var1_2.b(), var1_2.c(), (u)var1_2.a());
        }
    }

    f<k> a(com.dropbox.core.e.b.h object, List<a.a> list) {
        try {
            object = this.a.a(this.a.a().b(), "2/files/download", object, false, list, h.a.a, k.a.a, i.a.a);
            return object;
        }
        catch (m var1_2) {
            throw new j("2/files/download", var1_2.b(), var1_2.c(), (i)var1_2.a());
        }
    }

    public f<k> a(String string, String string2) {
        if (string2 != null) {
            if (string2.length() < 9) {
                throw new IllegalArgumentException("String 'rev' is shorter than 9");
            }
            if (!Pattern.matches("[0-9a-f]+", string2)) {
                throw new IllegalArgumentException("String 'rev' does not match pattern");
            }
        }
        return this.a(new com.dropbox.core.e.b.h(string, string2), Collections.<a.a>emptyList());
    }

    public ac b(String string) {
        return this.a(new com.dropbox.core.e.b.o(string));
    }

    public ac b(String string, String string2) {
        return this.a(new af(string, string2));
    }

    public y c(String string) {
        return this.a(new s(string));
    }

    public y d(String string) {
        return this.a(new t(string));
    }

    public ak e(String string) {
        return new ak(this, a.a(string));
    }
}

