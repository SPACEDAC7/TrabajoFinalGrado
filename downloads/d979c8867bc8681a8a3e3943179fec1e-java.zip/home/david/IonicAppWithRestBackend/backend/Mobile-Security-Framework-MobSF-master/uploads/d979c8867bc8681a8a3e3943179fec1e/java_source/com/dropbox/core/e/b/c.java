/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.d;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.regex.Pattern;

public class c {
    protected final String a;

    public c(String string) {
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'path' is null");
        }
        if (!Pattern.matches("(/(.|[\\r\\n])*)|(ns:[0-9]+(/.*)?)", string)) {
            throw new IllegalArgumentException("String 'path' does not match pattern");
        }
        this.a = string;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!object.getClass().equals(this.getClass())) return bl3;
        object = (c)object;
        if (this.a == object.a) return true;
        bl3 = bl2;
        if (!this.a.equals(object.a)) return bl3;
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<c> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(c c2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("path");
            com.dropbox.core.c.c.d().a(c2.a, jsonGenerator);
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public c b(JsonParser jsonParser, boolean bl2) {
            Object object;
            String string = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            object = string;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                string = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("path".equals(string)) {
                    object = com.dropbox.core.c.c.d().b(jsonParser);
                    continue;
                }
                a.i(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field \"path\" missing.");
            }
            object = new c((String)object);
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

