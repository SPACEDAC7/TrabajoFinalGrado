/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.e;
import com.dropbox.core.e.b.ar;
import com.dropbox.core.e.b.z;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public final class d {
    public static final d a = new d(b.c, null, null);
    private final b b;
    private final z c;
    private final ar d;

    private d(b b2, z z2, ar ar2) {
        this.b = b2;
        this.c = z2;
        this.d = ar2;
    }

    public static d a(ar ar2) {
        if (ar2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new d(b.b, null, ar2);
    }

    public static d a(z z2) {
        if (z2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new d(b.a, z2, null);
    }

    public b a() {
        return this.b;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!(object instanceof d)) return bl3;
        object = (d)object;
        bl3 = bl2;
        if (this.b != object.b) return bl3;
        switch (.a[this.b.ordinal()]) {
            default: {
                return false;
            }
            case 1: {
                if (this.c == object.c) return true;
                bl3 = bl2;
                if (!this.c.equals(object.c)) return bl3;
                return true;
            }
            case 2: {
                if (this.d == object.d) return true;
                bl3 = bl2;
                if (!this.d.equals(object.d)) return bl3;
                return true;
            }
            case 3: 
        }
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.b, this.c, this.d});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends e<d> {
        public static final a a = new a();

        a() {
        }

        @Override
        public void a(d d2, JsonGenerator jsonGenerator) {
            switch (.a[d2.a().ordinal()]) {
                default: {
                    jsonGenerator.writeString("other");
                    return;
                }
                case 1: {
                    jsonGenerator.writeStartObject();
                    this.a("path_lookup", jsonGenerator);
                    jsonGenerator.writeFieldName("path_lookup");
                    z.a.a.a(d2.c, jsonGenerator);
                    jsonGenerator.writeEndObject();
                    return;
                }
                case 2: 
            }
            jsonGenerator.writeStartObject();
            this.a("path_write", jsonGenerator);
            jsonGenerator.writeFieldName("path_write");
            ar.a.a.a(d2.d, jsonGenerator);
            jsonGenerator.writeEndObject();
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Enabled aggressive block sorting
         */
        public d k(JsonParser jsonParser) {
            boolean bl2;
            Object object;
            if (jsonParser.getCurrentToken() == JsonToken.VALUE_STRING) {
                bl2 = true;
                object = a.d(jsonParser);
                jsonParser.nextToken();
            } else {
                bl2 = false;
                a.e(jsonParser);
                object = a.c(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field missing: .tag");
            }
            if ("path_lookup".equals(object)) {
                a.a("path_lookup", jsonParser);
                object = d.a(z.a.a.k(jsonParser));
            } else if ("path_write".equals(object)) {
                a.a("path_write", jsonParser);
                object = d.a(ar.a.a.k(jsonParser));
            } else {
                object = d.a;
                a.j(jsonParser);
            }
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

    public static enum b {
        a,
        b,
        c;
        

        private b() {
        }
    }

}

