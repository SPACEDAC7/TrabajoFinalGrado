/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.e.b.d;
import com.dropbox.core.o;

public class e
extends com.dropbox.core.e {
    public final d a;

    public e(String string, String string2, o o2, d d2) {
        super(string2, o2, e.a(string, o2, d2));
        if (d2 == null) {
            throw new NullPointerException("errorValue");
        }
        this.a = d2;
    }
}

