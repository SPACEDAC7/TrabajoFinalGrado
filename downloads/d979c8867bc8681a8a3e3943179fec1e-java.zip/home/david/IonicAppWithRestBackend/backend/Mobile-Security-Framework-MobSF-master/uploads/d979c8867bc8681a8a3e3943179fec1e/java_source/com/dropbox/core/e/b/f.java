/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.ac;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

public class f
extends ac {
    public f(String string, String string2, String string3, String string4) {
        super(string, string2, string3, string4);
    }

    @Override
    public String a() {
        return this.j;
    }

    @Override
    public String b() {
        return this.k;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (f)object;
        if (this.j != object.j) {
            if (!this.j.equals(object.j)) return false;
        }
        if (this.k != object.k) {
            if (this.k == null) return false;
            if (!this.k.equals(object.k)) return false;
        }
        if (this.l != object.l) {
            if (this.l == null) return false;
            if (!this.l.equals(object.l)) return false;
        }
        if (this.m == object.m) return true;
        if (this.m == null) return false;
        if (this.m.equals(object.m)) return true;
        return false;
    }

    @Override
    public int hashCode() {
        return this.getClass().toString().hashCode();
    }

    @Override
    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<f> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(f f2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            this.a("deleted", jsonGenerator);
            jsonGenerator.writeFieldName("name");
            c.d().a(f2.j, jsonGenerator);
            if (f2.k != null) {
                jsonGenerator.writeFieldName("path_lower");
                c.a(c.d()).a(f2.k, jsonGenerator);
            }
            if (f2.l != null) {
                jsonGenerator.writeFieldName("path_display");
                c.a(c.d()).a(f2.l, jsonGenerator);
            }
            if (f2.m != null) {
                jsonGenerator.writeFieldName("parent_shared_folder_id");
                c.a(c.d()).a(f2.m, jsonGenerator);
            }
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public f b(JsonParser jsonParser, boolean bl2) {
            Object object;
            String string;
            String string2 = null;
            if (!bl2) {
                a.e(jsonParser);
                object = string = a.c(jsonParser);
                if ("deleted".equals(string)) {
                    object = null;
                }
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            String string3 = null;
            String string4 = null;
            string = null;
            object = string2;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                string2 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("name".equals(string2)) {
                    string2 = c.d().b(jsonParser);
                    string = string3;
                    string3 = string4;
                    string4 = string2;
                } else if ("path_lower".equals(string2)) {
                    string2 = c.a(c.d()).b(jsonParser);
                    string4 = string;
                    string = string3;
                    string3 = string2;
                } else if ("path_display".equals(string2)) {
                    string2 = c.a(c.d()).b(jsonParser);
                    string3 = string4;
                    string4 = string;
                    string = string2;
                } else if ("parent_shared_folder_id".equals(string2)) {
                    object = c.a(c.d()).b(jsonParser);
                    string2 = string;
                    string = string3;
                    string3 = string4;
                    string4 = string2;
                } else {
                    a.i(jsonParser);
                    string2 = string;
                    string = string3;
                    string3 = string4;
                    string4 = string2;
                }
                string2 = string4;
                string4 = string3;
                string3 = string;
                string = string2;
            }
            if (string == null) {
                throw new JsonParseException(jsonParser, "Required field \"name\" missing.");
            }
            object = new f(string, string4, string3, (String)object);
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

