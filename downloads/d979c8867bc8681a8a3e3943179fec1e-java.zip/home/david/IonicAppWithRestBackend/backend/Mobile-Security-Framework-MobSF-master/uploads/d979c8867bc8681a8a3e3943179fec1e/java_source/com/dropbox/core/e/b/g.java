/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public class g {
    protected final long a;
    protected final long b;

    public g(long l2, long l3) {
        this.a = l2;
        this.b = l3;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (g)object;
        if (this.a != object.a) return false;
        if (this.b == object.b) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<g> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(g g2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("height");
            c.a().a((Long)g2.a, jsonGenerator);
            jsonGenerator.writeFieldName("width");
            c.a().a((Long)g2.b, jsonGenerator);
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public g b(JsonParser jsonParser, boolean bl2) {
            Object object;
            Object object2 = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            object = null;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                Object object3 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("height".equals(object3)) {
                    object3 = c.a().b(jsonParser);
                    object = object2;
                    object2 = object3;
                } else if ("width".equals(object3)) {
                    object3 = c.a().b(jsonParser);
                    object2 = object;
                    object = object3;
                } else {
                    a.i(jsonParser);
                    object3 = object;
                    object = object2;
                    object2 = object3;
                }
                object3 = object2;
                object2 = object;
                object = object3;
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field \"height\" missing.");
            }
            if (object2 == null) {
                throw new JsonParseException(jsonParser, "Required field \"width\" missing.");
            }
            object = new g(object.longValue(), object2.longValue());
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

