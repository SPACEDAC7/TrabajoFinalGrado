/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.regex.Pattern;

class h {
    protected final String a;
    protected final String b;

    public h(String string, String string2) {
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'path' is null");
        }
        if (!Pattern.matches("(/(.|[\\r\\n])*|id:.*)|(rev:[0-9a-f]{9,})|(ns:[0-9]+(/.*)?)", string)) {
            throw new IllegalArgumentException("String 'path' does not match pattern");
        }
        this.a = string;
        if (string2 != null) {
            if (string2.length() < 9) {
                throw new IllegalArgumentException("String 'rev' is shorter than 9");
            }
            if (!Pattern.matches("[0-9a-f]+", string2)) {
                throw new IllegalArgumentException("String 'rev' does not match pattern");
            }
        }
        this.b = string2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (h)object;
        if (this.a != object.a) {
            if (!this.a.equals(object.a)) return false;
        }
        if (this.b == object.b) return true;
        if (this.b == null) return false;
        if (this.b.equals(object.b)) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<h> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(h h2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("path");
            c.d().a(h2.a, jsonGenerator);
            if (h2.b != null) {
                jsonGenerator.writeFieldName("rev");
                c.a(c.d()).a(h2.b, jsonGenerator);
            }
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public h b(JsonParser jsonParser, boolean bl2) {
            Object object;
            Object object2 = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            object = null;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                Object object3 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("path".equals(object3)) {
                    object3 = c.d().b(jsonParser);
                    object = object2;
                    object2 = object3;
                } else if ("rev".equals(object3)) {
                    object3 = c.a(c.d()).b(jsonParser);
                    object2 = object;
                    object = object3;
                } else {
                    a.i(jsonParser);
                    object3 = object;
                    object = object2;
                    object2 = object3;
                }
                object3 = object2;
                object2 = object;
                object = object3;
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field \"path\" missing.");
            }
            object = new h((String)object, (String)object2);
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

