/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.e;
import com.dropbox.core.e.b.z;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public final class i {
    public static final i a = new i(b.b, null);
    private final b b;
    private final z c;

    private i(b b2, z z2) {
        this.b = b2;
        this.c = z2;
    }

    public static i a(z z2) {
        if (z2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new i(b.a, z2);
    }

    public b a() {
        return this.b;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!(object instanceof i)) return bl3;
        object = (i)object;
        bl3 = bl2;
        if (this.b != object.b) return bl3;
        switch (.a[this.b.ordinal()]) {
            default: {
                return false;
            }
            case 1: {
                if (this.c == object.c) return true;
                bl3 = bl2;
                if (!this.c.equals(object.c)) return bl3;
                return true;
            }
            case 2: 
        }
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.b, this.c});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends e<i> {
        public static final a a = new a();

        a() {
        }

        @Override
        public void a(i i2, JsonGenerator jsonGenerator) {
            switch (i2.a()) {
                default: {
                    jsonGenerator.writeString("other");
                    return;
                }
                case a: 
            }
            jsonGenerator.writeStartObject();
            this.a("path", jsonGenerator);
            jsonGenerator.writeFieldName("path");
            z.a.a.a(i2.c, jsonGenerator);
            jsonGenerator.writeEndObject();
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Enabled aggressive block sorting
         */
        public i k(JsonParser jsonParser) {
            boolean bl2;
            Object object;
            if (jsonParser.getCurrentToken() == JsonToken.VALUE_STRING) {
                bl2 = true;
                object = a.d(jsonParser);
                jsonParser.nextToken();
            } else {
                bl2 = false;
                a.e(jsonParser);
                object = a.c(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field missing: .tag");
            }
            if ("path".equals(object)) {
                a.a("path", jsonParser);
                object = i.a(z.a.a.k(jsonParser));
            } else {
                object = i.a;
                a.j(jsonParser);
            }
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

    public static enum b {
        a,
        b;
        

        private b() {
        }
    }

}

