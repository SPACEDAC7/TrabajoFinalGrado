/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.e;
import com.dropbox.core.e.b.i;
import com.dropbox.core.o;

public class j
extends e {
    public final i a;

    public j(String string, String string2, o o2, i i2) {
        super(string2, o2, j.a(string, o2, i2));
        if (i2 == null) {
            throw new NullPointerException("errorValue");
        }
        this.a = i2;
    }
}

