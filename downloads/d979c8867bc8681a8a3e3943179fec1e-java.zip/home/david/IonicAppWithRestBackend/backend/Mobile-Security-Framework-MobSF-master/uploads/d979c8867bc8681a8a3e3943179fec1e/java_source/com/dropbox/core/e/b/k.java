/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.aa;
import com.dropbox.core.e.b.ac;
import com.dropbox.core.e.b.l;
import com.dropbox.core.e.c.b;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

public class k
extends ac {
    protected final String a;
    protected final Date b;
    protected final Date c;
    protected final String d;
    protected final long e;
    protected final aa f;
    protected final l g;
    protected final List<b> h;
    protected final Boolean i;

    public k(String object, String string, Date date, Date date2, String string2, long l2, String string3, String string4, String string5, aa aa2, l l3, List<b> list, Boolean bl2) {
        super((String)object, string3, string4, string5);
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'id' is null");
        }
        if (string.length() < 1) {
            throw new IllegalArgumentException("String 'id' is shorter than 1");
        }
        this.a = string;
        if (date == null) {
            throw new IllegalArgumentException("Required value for 'clientModified' is null");
        }
        this.b = com.dropbox.core.d.b.a(date);
        if (date2 == null) {
            throw new IllegalArgumentException("Required value for 'serverModified' is null");
        }
        this.c = com.dropbox.core.d.b.a(date2);
        if (string2 == null) {
            throw new IllegalArgumentException("Required value for 'rev' is null");
        }
        if (string2.length() < 9) {
            throw new IllegalArgumentException("String 'rev' is shorter than 9");
        }
        if (!Pattern.matches("[0-9a-f]+", string2)) {
            throw new IllegalArgumentException("String 'rev' does not match pattern");
        }
        this.d = string2;
        this.e = l2;
        this.f = aa2;
        this.g = l3;
        if (list != null) {
            object = list.iterator();
            while (object.hasNext()) {
                if ((b)object.next() != null) continue;
                throw new IllegalArgumentException("An item in list 'propertyGroups' is null");
            }
        }
        this.h = list;
        this.i = bl2;
    }

    @Override
    public String a() {
        return this.j;
    }

    @Override
    public String b() {
        return this.k;
    }

    public Date c() {
        return this.c;
    }

    public String d() {
        return this.d;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (k)object;
        if (this.j != object.j) {
            if (!this.j.equals(object.j)) return false;
        }
        if (this.a != object.a) {
            if (!this.a.equals(object.a)) return false;
        }
        if (this.b != object.b) {
            if (!this.b.equals(object.b)) return false;
        }
        if (this.c != object.c) {
            if (!this.c.equals(object.c)) return false;
        }
        if (this.d != object.d) {
            if (!this.d.equals(object.d)) return false;
        }
        if (this.e != object.e) return false;
        if (this.k != object.k) {
            if (this.k == null) return false;
            if (!this.k.equals(object.k)) return false;
        }
        if (this.l != object.l) {
            if (this.l == null) return false;
            if (!this.l.equals(object.l)) return false;
        }
        if (this.m != object.m) {
            if (this.m == null) return false;
            if (!this.m.equals(object.m)) return false;
        }
        if (this.f != object.f) {
            if (this.f == null) return false;
            if (!this.f.equals(object.f)) return false;
        }
        if (this.g != object.g) {
            if (this.g == null) return false;
            if (!this.g.equals(object.g)) return false;
        }
        if (this.h != object.h) {
            if (this.h == null) return false;
            if (!this.h.equals(object.h)) return false;
        }
        if (this.i == object.i) return true;
        if (this.i == null) return false;
        if (this.i.equals(object.i)) return true;
        return false;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i}) + super.hashCode() * 31;
    }

    @Override
    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<k> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(k k2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            this.a("file", jsonGenerator);
            jsonGenerator.writeFieldName("name");
            c.d().a(k2.j, jsonGenerator);
            jsonGenerator.writeFieldName("id");
            c.d().a(k2.a, jsonGenerator);
            jsonGenerator.writeFieldName("client_modified");
            c.e().a(k2.b, jsonGenerator);
            jsonGenerator.writeFieldName("server_modified");
            c.e().a(k2.c, jsonGenerator);
            jsonGenerator.writeFieldName("rev");
            c.d().a(k2.d, jsonGenerator);
            jsonGenerator.writeFieldName("size");
            c.a().a((Long)k2.e, jsonGenerator);
            if (k2.k != null) {
                jsonGenerator.writeFieldName("path_lower");
                c.a(c.d()).a(k2.k, jsonGenerator);
            }
            if (k2.l != null) {
                jsonGenerator.writeFieldName("path_display");
                c.a(c.d()).a(k2.l, jsonGenerator);
            }
            if (k2.m != null) {
                jsonGenerator.writeFieldName("parent_shared_folder_id");
                c.a(c.d()).a(k2.m, jsonGenerator);
            }
            if (k2.f != null) {
                jsonGenerator.writeFieldName("media_info");
                c.a(aa.a.a).a(k2.f, jsonGenerator);
            }
            if (k2.g != null) {
                jsonGenerator.writeFieldName("sharing_info");
                c.a(l.a.a).a(k2.g, jsonGenerator);
            }
            if (k2.h != null) {
                jsonGenerator.writeFieldName("property_groups");
                c.a(c.b(b.a.a)).a(k2.h, jsonGenerator);
            }
            if (k2.i != null) {
                jsonGenerator.writeFieldName("has_explicit_shared_members");
                c.a(c.c()).a(k2.i, jsonGenerator);
            }
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        public k b(JsonParser jsonParser, boolean bl2) {
            Object object;
            Object object2 = null;
            if (!bl2) {
                a.e(jsonParser);
                object2 = object = a.c(jsonParser);
                if ("file".equals(object)) {
                    object2 = null;
                }
            }
            if (object2 == null) {
                String string = null;
                String string2 = null;
                Date date = null;
                Date date2 = null;
                String string3 = null;
                object2 = null;
                String string4 = null;
                String string5 = null;
                String string6 = null;
                aa aa2 = null;
                l l2 = null;
                List list = null;
                object = null;
                while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                    String string7 = jsonParser.getCurrentName();
                    jsonParser.nextToken();
                    if ("name".equals(string7)) {
                        string = c.d().b(jsonParser);
                        continue;
                    }
                    if ("id".equals(string7)) {
                        string2 = c.d().b(jsonParser);
                        continue;
                    }
                    if ("client_modified".equals(string7)) {
                        date = c.e().b(jsonParser);
                        continue;
                    }
                    if ("server_modified".equals(string7)) {
                        date2 = c.e().b(jsonParser);
                        continue;
                    }
                    if ("rev".equals(string7)) {
                        string3 = c.d().b(jsonParser);
                        continue;
                    }
                    if ("size".equals(string7)) {
                        object2 = c.a().b(jsonParser);
                        continue;
                    }
                    if ("path_lower".equals(string7)) {
                        string4 = c.a(c.d()).b(jsonParser);
                        continue;
                    }
                    if ("path_display".equals(string7)) {
                        string5 = c.a(c.d()).b(jsonParser);
                        continue;
                    }
                    if ("parent_shared_folder_id".equals(string7)) {
                        string6 = c.a(c.d()).b(jsonParser);
                        continue;
                    }
                    if ("media_info".equals(string7)) {
                        aa2 = (aa)c.a(aa.a.a).b(jsonParser);
                        continue;
                    }
                    if ("sharing_info".equals(string7)) {
                        l2 = (l)c.a(l.a.a).b(jsonParser);
                        continue;
                    }
                    if ("property_groups".equals(string7)) {
                        list = c.a(c.b(b.a.a)).b(jsonParser);
                        continue;
                    }
                    if ("has_explicit_shared_members".equals(string7)) {
                        object = c.a(c.c()).b(jsonParser);
                        continue;
                    }
                    a.i(jsonParser);
                }
                if (string == null) {
                    throw new JsonParseException(jsonParser, "Required field \"name\" missing.");
                }
                if (string2 == null) {
                    throw new JsonParseException(jsonParser, "Required field \"id\" missing.");
                }
                if (date == null) {
                    throw new JsonParseException(jsonParser, "Required field \"client_modified\" missing.");
                }
                if (date2 == null) {
                    throw new JsonParseException(jsonParser, "Required field \"server_modified\" missing.");
                }
                if (string3 == null) {
                    throw new JsonParseException(jsonParser, "Required field \"rev\" missing.");
                }
                if (object2 == null) {
                    throw new JsonParseException(jsonParser, "Required field \"size\" missing.");
                }
                object2 = new k(string, string2, date, date2, string3, object2.longValue(), string4, string5, string6, aa2, l2, list, (Boolean)object);
                if (!bl2) {
                    a.f(jsonParser);
                }
                return object2;
            }
            throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object2 + "\"");
        }
    }

}

