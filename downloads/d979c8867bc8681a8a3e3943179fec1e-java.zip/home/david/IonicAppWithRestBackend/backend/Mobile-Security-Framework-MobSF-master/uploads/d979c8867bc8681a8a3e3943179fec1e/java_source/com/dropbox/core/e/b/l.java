/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.aj;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.regex.Pattern;

public class l
extends aj {
    protected final String a;
    protected final String b;

    public l(boolean bl2, String string, String string2) {
        super(bl2);
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'parentSharedFolderId' is null");
        }
        if (!Pattern.matches("[-_0-9a-zA-Z:]+", string)) {
            throw new IllegalArgumentException("String 'parentSharedFolderId' does not match pattern");
        }
        this.a = string;
        if (string2 != null) {
            if (string2.length() < 40) {
                throw new IllegalArgumentException("String 'modifiedBy' is shorter than 40");
            }
            if (string2.length() > 40) {
                throw new IllegalArgumentException("String 'modifiedBy' is longer than 40");
            }
        }
        this.b = string2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (l)object;
        if (this.e != object.e) return false;
        if (this.a != object.a) {
            if (!this.a.equals(object.a)) return false;
        }
        if (this.b == object.b) return true;
        if (this.b == null) return false;
        if (this.b.equals(object.b)) return true;
        return false;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b}) + super.hashCode() * 31;
    }

    @Override
    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<l> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(l l2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("read_only");
            c.c().a((Boolean)l2.e, jsonGenerator);
            jsonGenerator.writeFieldName("parent_shared_folder_id");
            c.d().a(l2.a, jsonGenerator);
            if (l2.b != null) {
                jsonGenerator.writeFieldName("modified_by");
                c.a(c.d()).a(l2.b, jsonGenerator);
            }
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public l b(JsonParser jsonParser, boolean bl2) {
            Object object;
            Object object2 = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            Object object3 = null;
            Object object4 = null;
            object = object2;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                object2 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("read_only".equals(object2)) {
                    object2 = c.c().b(jsonParser);
                    object4 = object3;
                    object3 = object2;
                } else if ("parent_shared_folder_id".equals(object2)) {
                    object2 = c.d().b(jsonParser);
                    object3 = object4;
                    object4 = object2;
                } else if ("modified_by".equals(object2)) {
                    object = c.a(c.d()).b(jsonParser);
                    object2 = object4;
                    object4 = object3;
                    object3 = object2;
                } else {
                    a.i(jsonParser);
                    object2 = object4;
                    object4 = object3;
                    object3 = object2;
                }
                object2 = object3;
                object3 = object4;
                object4 = object2;
            }
            if (object4 == null) {
                throw new JsonParseException(jsonParser, "Required field \"read_only\" missing.");
            }
            if (object3 == null) {
                throw new JsonParseException(jsonParser, "Required field \"parent_shared_folder_id\" missing.");
            }
            object = new l(object4.booleanValue(), (String)object3, (String)object);
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

