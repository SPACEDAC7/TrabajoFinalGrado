/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.ac;
import com.dropbox.core.e.b.n;
import com.dropbox.core.e.c.b;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

public class m
extends ac {
    protected final String a;
    protected final String b;
    protected final n c;
    protected final List<b> d;

    public m(String object, String string, String string2, String string3, String string4, String string5, n n2, List<b> list) {
        super((String)object, string2, string3, string4);
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'id' is null");
        }
        if (string.length() < 1) {
            throw new IllegalArgumentException("String 'id' is shorter than 1");
        }
        this.a = string;
        if (string5 != null && !Pattern.matches("[-_0-9a-zA-Z:]+", string5)) {
            throw new IllegalArgumentException("String 'sharedFolderId' does not match pattern");
        }
        this.b = string5;
        this.c = n2;
        if (list != null) {
            object = list.iterator();
            while (object.hasNext()) {
                if ((b)object.next() != null) continue;
                throw new IllegalArgumentException("An item in list 'propertyGroups' is null");
            }
        }
        this.d = list;
    }

    @Override
    public String a() {
        return this.j;
    }

    @Override
    public String b() {
        return this.k;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (m)object;
        if (this.j != object.j) {
            if (!this.j.equals(object.j)) return false;
        }
        if (this.a != object.a) {
            if (!this.a.equals(object.a)) return false;
        }
        if (this.k != object.k) {
            if (this.k == null) return false;
            if (!this.k.equals(object.k)) return false;
        }
        if (this.l != object.l) {
            if (this.l == null) return false;
            if (!this.l.equals(object.l)) return false;
        }
        if (this.m != object.m) {
            if (this.m == null) return false;
            if (!this.m.equals(object.m)) return false;
        }
        if (this.b != object.b) {
            if (this.b == null) return false;
            if (!this.b.equals(object.b)) return false;
        }
        if (this.c != object.c) {
            if (this.c == null) return false;
            if (!this.c.equals(object.c)) return false;
        }
        if (this.d == object.d) return true;
        if (this.d == null) return false;
        if (this.d.equals(object.d)) return true;
        return false;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b, this.c, this.d}) + super.hashCode() * 31;
    }

    @Override
    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<m> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(m m2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            this.a("folder", jsonGenerator);
            jsonGenerator.writeFieldName("name");
            c.d().a(m2.j, jsonGenerator);
            jsonGenerator.writeFieldName("id");
            c.d().a(m2.a, jsonGenerator);
            if (m2.k != null) {
                jsonGenerator.writeFieldName("path_lower");
                c.a(c.d()).a(m2.k, jsonGenerator);
            }
            if (m2.l != null) {
                jsonGenerator.writeFieldName("path_display");
                c.a(c.d()).a(m2.l, jsonGenerator);
            }
            if (m2.m != null) {
                jsonGenerator.writeFieldName("parent_shared_folder_id");
                c.a(c.d()).a(m2.m, jsonGenerator);
            }
            if (m2.b != null) {
                jsonGenerator.writeFieldName("shared_folder_id");
                c.a(c.d()).a(m2.b, jsonGenerator);
            }
            if (m2.c != null) {
                jsonGenerator.writeFieldName("sharing_info");
                c.a(n.a.a).a(m2.c, jsonGenerator);
            }
            if (m2.d != null) {
                jsonGenerator.writeFieldName("property_groups");
                c.a(c.b(b.a.a)).a(m2.d, jsonGenerator);
            }
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public m b(JsonParser jsonParser, boolean bl2) {
            Object object;
            String string;
            Object object2 = null;
            if (!bl2) {
                a.e(jsonParser);
                object = string = a.c(jsonParser);
                if ("folder".equals(string)) {
                    object = null;
                }
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            String string2 = null;
            string = null;
            String string3 = null;
            String string4 = null;
            String string5 = null;
            String string6 = null;
            String string7 = null;
            object = object2;
            object2 = string2;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                string2 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("name".equals(string2)) {
                    string7 = c.d().b(jsonParser);
                    continue;
                }
                if ("id".equals(string2)) {
                    string6 = c.d().b(jsonParser);
                    continue;
                }
                if ("path_lower".equals(string2)) {
                    string5 = c.a(c.d()).b(jsonParser);
                    continue;
                }
                if ("path_display".equals(string2)) {
                    string4 = c.a(c.d()).b(jsonParser);
                    continue;
                }
                if ("parent_shared_folder_id".equals(string2)) {
                    string3 = c.a(c.d()).b(jsonParser);
                    continue;
                }
                if ("shared_folder_id".equals(string2)) {
                    string = c.a(c.d()).b(jsonParser);
                    continue;
                }
                if ("sharing_info".equals(string2)) {
                    object2 = (n)c.a(n.a.a).b(jsonParser);
                    continue;
                }
                if ("property_groups".equals(string2)) {
                    object = c.a(c.b(b.a.a)).b(jsonParser);
                    continue;
                }
                a.i(jsonParser);
            }
            if (string7 == null) {
                throw new JsonParseException(jsonParser, "Required field \"name\" missing.");
            }
            if (string6 == null) {
                throw new JsonParseException(jsonParser, "Required field \"id\" missing.");
            }
            object = new m(string7, string6, string5, string4, string3, string, (n)object2, (List<b>)object);
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

