/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.aj;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.regex.Pattern;

public class n
extends aj {
    protected final String a;
    protected final String b;
    protected final boolean c;
    protected final boolean d;

    public n(boolean bl2, String string, String string2, boolean bl3, boolean bl4) {
        super(bl2);
        if (string != null && !Pattern.matches("[-_0-9a-zA-Z:]+", string)) {
            throw new IllegalArgumentException("String 'parentSharedFolderId' does not match pattern");
        }
        this.a = string;
        if (string2 != null && !Pattern.matches("[-_0-9a-zA-Z:]+", string2)) {
            throw new IllegalArgumentException("String 'sharedFolderId' does not match pattern");
        }
        this.b = string2;
        this.c = bl3;
        this.d = bl4;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (n)object;
        if (this.e != object.e) return false;
        if (this.a != object.a) {
            if (this.a == null) return false;
            if (!this.a.equals(object.a)) return false;
        }
        if (this.b != object.b) {
            if (this.b == null) return false;
            if (!this.b.equals(object.b)) return false;
        }
        if (this.c != object.c) return false;
        if (this.d == object.d) return true;
        return false;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b, this.c, this.d}) + super.hashCode() * 31;
    }

    @Override
    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<n> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(n n2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("read_only");
            c.c().a((Boolean)n2.e, jsonGenerator);
            if (n2.a != null) {
                jsonGenerator.writeFieldName("parent_shared_folder_id");
                c.a(c.d()).a(n2.a, jsonGenerator);
            }
            if (n2.b != null) {
                jsonGenerator.writeFieldName("shared_folder_id");
                c.a(c.d()).a(n2.b, jsonGenerator);
            }
            jsonGenerator.writeFieldName("traverse_only");
            c.c().a((Boolean)n2.c, jsonGenerator);
            jsonGenerator.writeFieldName("no_access");
            c.c().a((Boolean)n2.d, jsonGenerator);
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public n b(JsonParser jsonParser, boolean bl2) {
            Object object;
            Object object2 = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            object = false;
            Object object3 = false;
            Object object4 = null;
            Boolean bl3 = null;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                Object object5 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("read_only".equals(object5)) {
                    bl3 = c.c().b(jsonParser);
                    object5 = object3;
                    object3 = object;
                    object = object5;
                } else if ("parent_shared_folder_id".equals(object5)) {
                    object5 = c.a(c.d()).b(jsonParser);
                    object4 = object;
                    object = object3;
                    object3 = object4;
                    object4 = object5;
                } else if ("shared_folder_id".equals(object5)) {
                    object5 = c.a(c.d()).b(jsonParser);
                    object2 = object;
                    object = object3;
                    object3 = object2;
                    object2 = object5;
                } else if ("traverse_only".equals(object5)) {
                    object5 = c.c().b(jsonParser);
                    object = object3;
                    object3 = object5;
                } else if ("no_access".equals(object5)) {
                    object5 = c.c().b(jsonParser);
                    object3 = object;
                    object = object5;
                } else {
                    a.i(jsonParser);
                    object5 = object;
                    object = object3;
                    object3 = object5;
                }
                object5 = object;
                object = object3;
                object3 = object5;
            }
            if (bl3 == null) {
                throw new JsonParseException(jsonParser, "Required field \"read_only\" missing.");
            }
            object = new n(bl3, (String)object4, (String)object2, object.booleanValue(), object3.booleanValue());
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

