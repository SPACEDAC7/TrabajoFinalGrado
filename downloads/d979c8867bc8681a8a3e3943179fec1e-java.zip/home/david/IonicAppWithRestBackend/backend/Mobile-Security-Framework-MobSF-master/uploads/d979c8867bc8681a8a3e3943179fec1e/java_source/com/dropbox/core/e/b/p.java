/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.e;
import com.dropbox.core.e.b.z;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public final class p {
    private final b a;
    private final z b;

    private p(b b2, z z2) {
        this.a = b2;
        this.b = z2;
    }

    public static p a(z z2) {
        if (z2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new p(b.a, z2);
    }

    public b a() {
        return this.a;
    }

    public z b() {
        if (this.a != b.a) {
            throw new IllegalStateException("Invalid tag: required Tag.PATH, but was Tag." + this.a.name());
        }
        return this.b;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!(object instanceof p)) return bl3;
        object = (p)object;
        bl3 = bl2;
        if (this.a != object.a) return bl3;
        switch (this.a) {
            default: {
                return false;
            }
            case a: 
        }
        if (this.b == object.b) return true;
        bl3 = bl2;
        if (!this.b.equals(object.b)) return bl3;
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends e<p> {
        public static final a a = new a();

        a() {
        }

        @Override
        public void a(p p2, JsonGenerator jsonGenerator) {
            switch (p2.a()) {
                default: {
                    throw new IllegalArgumentException("Unrecognized tag: " + (Object)((Object)p2.a()));
                }
                case a: 
            }
            jsonGenerator.writeStartObject();
            this.a("path", jsonGenerator);
            jsonGenerator.writeFieldName("path");
            z.a.a.a(p2.b, jsonGenerator);
            jsonGenerator.writeEndObject();
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Enabled aggressive block sorting
         */
        public p k(JsonParser jsonParser) {
            boolean bl2;
            Object object;
            if (jsonParser.getCurrentToken() == JsonToken.VALUE_STRING) {
                bl2 = true;
                object = a.d(jsonParser);
                jsonParser.nextToken();
            } else {
                bl2 = false;
                a.e(jsonParser);
                object = a.c(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field missing: .tag");
            }
            if (!"path".equals(object)) {
                throw new JsonParseException(jsonParser, "Unknown tag: " + (String)object);
            }
            a.a("path", jsonParser);
            object = p.a(z.a.a.k(jsonParser));
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

    public static enum b {
        a;
        

        private b() {
        }
    }

}

