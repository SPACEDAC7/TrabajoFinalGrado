/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.e;
import com.dropbox.core.e.b.p;
import com.dropbox.core.o;

public class q
extends e {
    public final p a;

    public q(String string, String string2, o o2, p p2) {
        super(string2, o2, q.a(string, o2, p2));
        if (p2 == null) {
            throw new NullPointerException("errorValue");
        }
        this.a = p2;
    }
}

