/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.regex.Pattern;

class s {
    protected final String a;
    protected final boolean b;
    protected final boolean c;
    protected final boolean d;
    protected final boolean e;

    public s(String string) {
        this(string, false, false, false, false);
    }

    public s(String string, boolean bl2, boolean bl3, boolean bl4, boolean bl5) {
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'path' is null");
        }
        if (!Pattern.matches("(/(.|[\\r\\n])*)?|(ns:[0-9]+(/.*)?)", string)) {
            throw new IllegalArgumentException("String 'path' does not match pattern");
        }
        this.a = string;
        this.b = bl2;
        this.c = bl3;
        this.d = bl4;
        this.e = bl5;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (s)object;
        if (this.a != object.a) {
            if (!this.a.equals(object.a)) return false;
        }
        if (this.b != object.b) return false;
        if (this.c != object.c) return false;
        if (this.d != object.d) return false;
        if (this.e == object.e) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b, this.c, this.d, this.e});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<s> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(s s2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("path");
            c.d().a(s2.a, jsonGenerator);
            jsonGenerator.writeFieldName("recursive");
            c.c().a((Boolean)s2.b, jsonGenerator);
            jsonGenerator.writeFieldName("include_media_info");
            c.c().a((Boolean)s2.c, jsonGenerator);
            jsonGenerator.writeFieldName("include_deleted");
            c.c().a((Boolean)s2.d, jsonGenerator);
            jsonGenerator.writeFieldName("include_has_explicit_shared_members");
            c.c().a((Boolean)s2.e, jsonGenerator);
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public s b(JsonParser jsonParser, boolean bl2) {
            Object object;
            String string = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            object = false;
            Object object2 = false;
            Object object3 = false;
            Object object4 = false;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                Object object5;
                Object object6 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("path".equals(object6)) {
                    string = c.d().b(jsonParser);
                    object6 = object3;
                    object5 = object4;
                    object4 = object;
                    object3 = object2;
                    object2 = object6;
                    object = object5;
                } else if ("recursive".equals(object6)) {
                    object5 = c.c().b(jsonParser);
                    object6 = object2;
                    object = object4;
                    object2 = object3;
                    object3 = object6;
                    object4 = object5;
                } else if ("include_media_info".equals(object6)) {
                    object5 = c.c().b(jsonParser);
                    object6 = object;
                    object = object4;
                    object2 = object3;
                    object3 = object5;
                    object4 = object6;
                } else if ("include_deleted".equals(object6)) {
                    object3 = c.c().b(jsonParser);
                    object5 = object4;
                    object4 = object2;
                    object6 = object;
                    object = object5;
                    object2 = object3;
                    object3 = object4;
                    object4 = object6;
                } else if ("include_has_explicit_shared_members".equals(object6)) {
                    object5 = c.c().b(jsonParser);
                    object4 = object2;
                    object6 = object;
                    object = object5;
                    object2 = object3;
                    object3 = object4;
                    object4 = object6;
                } else {
                    a.i(jsonParser);
                    object6 = object2;
                    object5 = object;
                    object = object4;
                    object2 = object3;
                    object3 = object6;
                    object4 = object5;
                }
                object6 = object;
                object5 = object2;
                object2 = object3;
                object = object4;
                object3 = object5;
                object4 = object6;
            }
            if (string == null) {
                throw new JsonParseException(jsonParser, "Required field \"path\" missing.");
            }
            object = new s(string, object.booleanValue(), object2.booleanValue(), object3.booleanValue(), object4.booleanValue());
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

