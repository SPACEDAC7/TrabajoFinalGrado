/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

class t {
    protected final String a;

    public t(String string) {
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'cursor' is null");
        }
        if (string.length() < 1) {
            throw new IllegalArgumentException("String 'cursor' is shorter than 1");
        }
        this.a = string;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!object.getClass().equals(this.getClass())) return bl3;
        object = (t)object;
        if (this.a == object.a) return true;
        bl3 = bl2;
        if (!this.a.equals(object.a)) return bl3;
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<t> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(t t2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("cursor");
            c.d().a(t2.a, jsonGenerator);
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public t b(JsonParser jsonParser, boolean bl2) {
            Object object;
            String string = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            object = string;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                string = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("cursor".equals(string)) {
                    object = c.d().b(jsonParser);
                    continue;
                }
                a.i(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field \"cursor\" missing.");
            }
            object = new t((String)object);
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

