/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.e;
import com.dropbox.core.e.b.z;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public final class u {
    public static final u a = new u(b.b, null);
    public static final u b = new u(b.c, null);
    private final b c;
    private final z d;

    private u(b b2, z z2) {
        this.c = b2;
        this.d = z2;
    }

    public static u a(z z2) {
        if (z2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new u(b.a, z2);
    }

    public b a() {
        return this.c;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        if (object == this) {
            return true;
        }
        boolean bl3 = bl2;
        if (!(object instanceof u)) return bl3;
        object = (u)object;
        bl3 = bl2;
        if (this.c != object.c) return bl3;
        switch (.a[this.c.ordinal()]) {
            default: {
                return false;
            }
            case 1: {
                if (this.d == object.d) return true;
                bl3 = bl2;
                if (!this.d.equals(object.d)) return bl3;
                return true;
            }
            case 2: {
                return true;
            }
            case 3: 
        }
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.c, this.d});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends e<u> {
        public static final a a = new a();

        a() {
        }

        @Override
        public void a(u u2, JsonGenerator jsonGenerator) {
            switch (.a[u2.a().ordinal()]) {
                default: {
                    jsonGenerator.writeString("other");
                    return;
                }
                case 1: {
                    jsonGenerator.writeStartObject();
                    this.a("path", jsonGenerator);
                    jsonGenerator.writeFieldName("path");
                    z.a.a.a(u2.d, jsonGenerator);
                    jsonGenerator.writeEndObject();
                    return;
                }
                case 2: 
            }
            jsonGenerator.writeString("reset");
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Enabled aggressive block sorting
         */
        public u k(JsonParser jsonParser) {
            boolean bl2;
            Object object;
            if (jsonParser.getCurrentToken() == JsonToken.VALUE_STRING) {
                bl2 = true;
                object = a.d(jsonParser);
                jsonParser.nextToken();
            } else {
                bl2 = false;
                a.e(jsonParser);
                object = a.c(jsonParser);
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field missing: .tag");
            }
            if ("path".equals(object)) {
                a.a("path", jsonParser);
                object = u.a(z.a.a.k(jsonParser));
            } else if ("reset".equals(object)) {
                object = u.a;
            } else {
                object = u.b;
                a.j(jsonParser);
            }
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

    public static enum b {
        a,
        b,
        c;
        

        private b() {
        }
    }

}

