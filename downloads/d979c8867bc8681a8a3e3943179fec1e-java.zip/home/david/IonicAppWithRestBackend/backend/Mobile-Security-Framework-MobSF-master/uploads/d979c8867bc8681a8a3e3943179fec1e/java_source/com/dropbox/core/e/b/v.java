/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.e;
import com.dropbox.core.e.b.u;
import com.dropbox.core.o;

public class v
extends e {
    public final u a;

    public v(String string, String string2, o o2, u u2) {
        super(string2, o2, v.a(string, o2, u2));
        if (u2 == null) {
            throw new NullPointerException("errorValue");
        }
        this.a = u2;
    }
}

