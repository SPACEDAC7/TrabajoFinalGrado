/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.e;
import com.dropbox.core.e.b.w;
import com.dropbox.core.o;

public class x
extends e {
    public final w a;

    public x(String string, String string2, o o2, w w2) {
        super(string2, o2, x.a(string, o2, w2));
        if (w2 == null) {
            throw new NullPointerException("errorValue");
        }
        this.a = w2;
    }
}

