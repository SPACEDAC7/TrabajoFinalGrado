/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.d;
import com.dropbox.core.e.b.ac;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class y {
    protected final List<ac> a;
    protected final String b;
    protected final boolean c;

    public y(List<ac> list, String string, boolean bl2) {
        if (list == null) {
            throw new IllegalArgumentException("Required value for 'entries' is null");
        }
        Iterator<ac> iterator = list.iterator();
        while (iterator.hasNext()) {
            if (iterator.next() != null) continue;
            throw new IllegalArgumentException("An item in list 'entries' is null");
        }
        this.a = list;
        if (string == null) {
            throw new IllegalArgumentException("Required value for 'cursor' is null");
        }
        if (string.length() < 1) {
            throw new IllegalArgumentException("String 'cursor' is shorter than 1");
        }
        this.b = string;
        this.c = bl2;
    }

    public List<ac> a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public boolean c() {
        return this.c;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!object.getClass().equals(this.getClass())) return false;
        object = (y)object;
        if (this.a != object.a) {
            if (!this.a.equals(object.a)) return false;
        }
        if (this.b != object.b) {
            if (!this.b.equals(object.b)) return false;
        }
        if (this.c == object.c) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.a, this.b, this.c});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    static class a
    extends d<y> {
        public static final a a = new a();

        a() {
        }

        @Override
        public /* synthetic */ Object a(JsonParser jsonParser, boolean bl2) {
            return this.b(jsonParser, bl2);
        }

        @Override
        public void a(y y2, JsonGenerator jsonGenerator, boolean bl2) {
            if (!bl2) {
                jsonGenerator.writeStartObject();
            }
            jsonGenerator.writeFieldName("entries");
            c.b(ac.a.a).a(y2.a, jsonGenerator);
            jsonGenerator.writeFieldName("cursor");
            c.d().a(y2.b, jsonGenerator);
            jsonGenerator.writeFieldName("has_more");
            c.c().a((Boolean)y2.c, jsonGenerator);
            if (!bl2) {
                jsonGenerator.writeEndObject();
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public y b(JsonParser jsonParser, boolean bl2) {
            Object object;
            Object object2 = null;
            if (!bl2) {
                a.e(jsonParser);
                object = a.c(jsonParser);
            } else {
                object = null;
            }
            if (object != null) {
                throw new JsonParseException(jsonParser, "No subtype found that matches tag: \"" + (String)object + "\"");
            }
            Object object3 = null;
            Object object4 = null;
            object = object2;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                object2 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("entries".equals(object2)) {
                    object2 = c.b(ac.a.a).b(jsonParser);
                    object4 = object3;
                    object3 = object2;
                } else if ("cursor".equals(object2)) {
                    object2 = c.d().b(jsonParser);
                    object3 = object4;
                    object4 = object2;
                } else if ("has_more".equals(object2)) {
                    object = c.c().b(jsonParser);
                    object2 = object4;
                    object4 = object3;
                    object3 = object2;
                } else {
                    a.i(jsonParser);
                    object2 = object4;
                    object4 = object3;
                    object3 = object2;
                }
                object2 = object3;
                object3 = object4;
                object4 = object2;
            }
            if (object4 == null) {
                throw new JsonParseException(jsonParser, "Required field \"entries\" missing.");
            }
            if (object3 == null) {
                throw new JsonParseException(jsonParser, "Required field \"cursor\" missing.");
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field \"has_more\" missing.");
            }
            object = new y((List<ac>)object4, (String)object3, object.booleanValue());
            if (!bl2) {
                a.f(jsonParser);
            }
            return object;
        }
    }

}

