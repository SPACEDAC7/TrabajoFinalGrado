/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.b;

import com.dropbox.core.c.c;
import com.dropbox.core.c.e;
import com.dropbox.core.e.b.ad;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import java.util.Arrays;

public final class z {
    public static final z a = new z(b.b, null, null);
    public static final z b = new z(b.c, null, null);
    public static final z c = new z(b.d, null, null);
    public static final z d = new z(b.e, null, null);
    public static final z e = new z(b.g, null, null);
    private final b f;
    private final String g;
    private final ad h;

    private z(b b2, String string, ad ad2) {
        this.f = b2;
        this.g = string;
        this.h = ad2;
    }

    public static z a(ad ad2) {
        if (ad2 == null) {
            throw new IllegalArgumentException("Value is null");
        }
        return new z(b.f, null, ad2);
    }

    public static z a(String string) {
        return new z(b.a, string, null);
    }

    public static z b() {
        return z.a(null);
    }

    public b a() {
        return this.f;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        boolean bl2 = false;
        boolean bl3 = false;
        if (object == this) {
            do {
                return true;
                break;
            } while (true);
        }
        if (!(object instanceof z)) return false;
        object = (z)object;
        if (this.f != object.f) {
            return false;
        }
        switch (.a[this.f.ordinal()]) {
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 7: {
                return true;
            }
            default: {
                return false;
            }
            case 1: {
                if (this.g == object.g) return true;
                bl2 = bl3;
                if (this.g == null) return bl2;
                bl2 = bl3;
                if (!this.g.equals(object.g)) return bl2;
                return true;
            }
            case 6: 
        }
        if (this.h == object.h) return true;
        if (!this.h.equals(object.h)) return bl2;
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f, this.g, this.h});
    }

    public String toString() {
        return a.a.a(this, false);
    }

    public static class a
    extends e<z> {
        public static final a a = new a();

        @Override
        public void a(z z2, JsonGenerator jsonGenerator) {
            switch (.a[z2.a().ordinal()]) {
                default: {
                    jsonGenerator.writeString("other");
                    return;
                }
                case 1: {
                    jsonGenerator.writeStartObject();
                    this.a("malformed_path", jsonGenerator);
                    jsonGenerator.writeFieldName("malformed_path");
                    c.a(c.d()).a(z2.g, jsonGenerator);
                    jsonGenerator.writeEndObject();
                    return;
                }
                case 2: {
                    jsonGenerator.writeString("not_found");
                    return;
                }
                case 3: {
                    jsonGenerator.writeString("not_file");
                    return;
                }
                case 4: {
                    jsonGenerator.writeString("not_folder");
                    return;
                }
                case 5: {
                    jsonGenerator.writeString("restricted_content");
                    return;
                }
                case 6: 
            }
            jsonGenerator.writeStartObject();
            this.a("invalid_path_root", jsonGenerator);
            ad.a.a.a(z2.h, jsonGenerator, true);
            jsonGenerator.writeEndObject();
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.k(jsonParser);
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public z k(JsonParser var1_1) {
            if (var1_1.getCurrentToken() == JsonToken.VALUE_STRING) {
                var3_2 = a.d(var1_1);
                var1_1.nextToken();
                var2_3 = true;
            } else {
                var2_3 = false;
                a.e(var1_1);
                var3_2 = a.c(var1_1);
            }
            if (var3_2 == null) {
                throw new JsonParseException(var1_1, "Required field missing: .tag");
            }
            if (!"malformed_path".equals(var3_2)) ** GOTO lbl21
            var3_2 = null;
            if (var1_1.getCurrentToken() == JsonToken.END_OBJECT) ** GOTO lbl-1000
            a.a("malformed_path", var1_1);
            var3_2 = c.a(c.d()).b(var1_1);
            if (var3_2 == null) lbl-1000: // 2 sources:
            {
                var3_2 = z.b();
            } else {
                var3_2 = z.a((String)var3_2);
            }
            ** GOTO lbl38
lbl21: // 1 sources:
            if ("not_found".equals(var3_2)) {
                var3_2 = z.a;
            } else if ("not_file".equals(var3_2)) {
                var3_2 = z.b;
            } else if ("not_folder".equals(var3_2)) {
                var3_2 = z.c;
            } else if ("restricted_content".equals(var3_2)) {
                var3_2 = z.d;
            } else if ("invalid_path_root".equals(var3_2)) {
                var3_2 = z.a(ad.a.a.b(var1_1, true));
            } else {
                var3_2 = z.e;
                a.j(var1_1);
            }
lbl38: // 8 sources:
            if (var2_3 != false) return var3_2;
            a.f(var1_1);
            return var3_2;
        }
    }

    public static enum b {
        a,
        b,
        c,
        d,
        e,
        f,
        g;
        

        private b() {
        }
    }

}

