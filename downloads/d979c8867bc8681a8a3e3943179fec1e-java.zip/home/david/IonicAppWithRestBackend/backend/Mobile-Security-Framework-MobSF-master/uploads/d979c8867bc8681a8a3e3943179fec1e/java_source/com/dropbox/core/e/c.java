/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e;

import com.dropbox.core.a.a;
import com.dropbox.core.c.b;
import com.dropbox.core.f;
import com.dropbox.core.h;
import com.dropbox.core.i;
import com.dropbox.core.j;
import com.dropbox.core.p;
import com.dropbox.core.s;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

public abstract class c {
    private static final JsonFactory a = new JsonFactory();
    private static final Random b = new Random();
    private final i c;
    private final h d;

    protected c(i i2, h h2) {
        if (i2 == null) {
            throw new NullPointerException("requestConfig");
        }
        if (h2 == null) {
            throw new NullPointerException("host");
        }
        this.c = i2;
        this.d = h2;
    }

    static /* synthetic */ i a(c c2) {
        return c2.c;
    }

    private static <T> T a(int n2, a<T> a2) {
        if (n2 == 0) {
            return a2.a();
        }
        int n3 = 0;
        do {
            T t2;
            try {
                t2 = a2.a();
            }
            catch (s var3_3) {
                if (n3 < n2) {
                    ++n3;
                    c.a(var3_3.a());
                    continue;
                }
                throw var3_3;
            }
            return t2;
            break;
        } while (true);
    }

    private static void a(long l2) {
        l2 = (long)b.nextInt(1000) + l2;
        if (l2 <= 0) {
            return;
        }
        try {
            Thread.sleep(l2);
            return;
        }
        catch (InterruptedException var2_1) {
            Thread.currentThread().interrupt();
            return;
        }
    }

    private static <T> byte[] a(b<T> b2, T t2) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            b2.a(t2, byteArrayOutputStream);
            return byteArrayOutputStream.toByteArray();
        }
        catch (IOException var0_1) {
            throw com.dropbox.core.d.b.a("Impossible", var0_1);
        }
    }

    private static <T> String b(b<T> b2, T t2) {
        StringWriter stringWriter = new StringWriter();
        try {
            JsonGenerator jsonGenerator = a.createGenerator(stringWriter);
            jsonGenerator.setHighestNonEscapedChar(126);
            b2.a(t2, jsonGenerator);
            jsonGenerator.flush();
            return stringWriter.toString();
        }
        catch (IOException var0_1) {
            throw com.dropbox.core.d.b.a("Impossible", var0_1);
        }
    }

    public <ArgT> a.c a(String object, String list, ArgT ArgT, boolean bl2, b<ArgT> b2) {
        object = j.a((String)object, (String)((Object)list));
        list = new ArrayList();
        if (!bl2) {
            this.a(list);
        }
        j.a(list, this.c);
        list.add(new a.a("Content-Type", "application/octet-stream"));
        list = j.a(list, this.c, "OfficialDropboxJavaSDKv2");
        list.add(new a.a("Dropbox-API-Arg", c.b(b2, ArgT)));
        try {
            object = this.c.c().a((String)object, list);
            return object;
        }
        catch (IOException var1_2) {
            throw new p(var1_2);
        }
    }

    public <ArgT, ResT, ErrT> f<ResT> a(final String string, final String string2, ArgT ArgT, boolean bl2, List<a.a> list, b<ArgT> b2, b<ResT> b3, b<ErrT> b4) {
        list = new ArrayList<a.a>(list);
        if (!bl2) {
            this.a(list);
        }
        j.a(list, this.c);
        list.add(new a.a("Dropbox-API-Arg", c.b(b2, ArgT)));
        list.add(new a.a("Content-Type", ""));
        return (f)c.a(this.c.d(), new a<f<ResT>>(new byte[0], list, b3, b4){
            final /* synthetic */ byte[] c;
            final /* synthetic */ List d;
            final /* synthetic */ b e;
            final /* synthetic */ b f;

            @Override
            public /* synthetic */ Object a() {
                return this.b();
            }

            /*
             * Exception decompiling
             */
            public f<ResT> b() {
                // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
                // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
                // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
                // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
                // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
                // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
                // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
                // org.benf.cfr.reader.Main.doJar(Main.java:129)
                // org.benf.cfr.reader.Main.main(Main.java:181)
                throw new IllegalStateException("Decompilation failed");
            }
        });
    }

    public h a() {
        return this.d;
    }

    public <ArgT, ResT, ErrT> ResT a(final String string, final String string2, ArgT object, boolean bl2, b<ArgT> object2, b<ResT> b2, b<ErrT> b3) {
        object = c.a(object2, object);
        object2 = new ArrayList();
        if (!bl2) {
            this.a((List<a.a>)object2);
        }
        if (!this.d.c().equals(string)) {
            j.a(object2, this.c);
        }
        object2.add(new a.a("Content-Type", "application/json; charset=utf-8"));
        return (ResT)c.a(this.c.d(), new a<ResT>((byte[])object, (List)object2, b2, b3){
            final /* synthetic */ byte[] c;
            final /* synthetic */ List d;
            final /* synthetic */ b e;
            final /* synthetic */ b f;

            /*
             * Exception decompiling
             */
            @Override
            public ResT a() {
                // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                // org.benf.cfr.reader.util.ConfusedCFRException: First case is not immediately after switch.
                // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:366)
                // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
                // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
                // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
                // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
                // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
                // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
                // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
                // org.benf.cfr.reader.Main.doJar(Main.java:129)
                // org.benf.cfr.reader.Main.main(Main.java:181)
                throw new IllegalStateException("Decompilation failed");
            }
        });
    }

    protected abstract void a(List<a.a> var1);

    private static interface a<T> {
        public T a();
    }

}

