/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e;

import com.dropbox.core.e;
import com.dropbox.core.l;
import java.io.InputStream;

public abstract class d<R, E, X extends e> {
    public abstract l<R, E, X> a();

    public R a(InputStream inputStream) {
        return this.a().a(inputStream);
    }
}

