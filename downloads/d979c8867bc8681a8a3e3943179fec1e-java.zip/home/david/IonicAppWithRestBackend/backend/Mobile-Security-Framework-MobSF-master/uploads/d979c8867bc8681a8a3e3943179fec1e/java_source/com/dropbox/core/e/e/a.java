/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core.e.e;

import com.dropbox.core.e.c;

public class a {
    private final c a;

    public a(c c2) {
        this.a = c2;
    }
}

