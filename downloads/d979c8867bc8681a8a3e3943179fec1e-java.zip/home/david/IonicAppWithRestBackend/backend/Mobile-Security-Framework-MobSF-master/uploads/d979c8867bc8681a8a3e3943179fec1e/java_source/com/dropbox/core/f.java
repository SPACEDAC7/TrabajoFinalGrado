/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.d.a;
import com.dropbox.core.p;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class f<R>
implements Closeable {
    private final R a;
    private final InputStream b;
    private boolean c;

    public f(R r2, InputStream inputStream) {
        this.a = r2;
        this.b = inputStream;
        this.c = false;
    }

    private void b() {
        if (this.c) {
            throw new IllegalStateException("This downloader is already closed.");
        }
    }

    public InputStream a() {
        this.b();
        return this.b;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public R a(OutputStream outputStream) {
        try {
            a.a(this.a(), outputStream);
            return this.a;
        }
        catch (a.c var1_2) {
            throw var1_2.a();
        }
        catch (IOException var1_4) {
            throw new p(var1_4);
        }
        finally {
            this.close();
        }
    }

    @Override
    public void close() {
        if (!this.c) {
            a.a((Closeable)this.b);
            this.c = true;
        }
    }
}

