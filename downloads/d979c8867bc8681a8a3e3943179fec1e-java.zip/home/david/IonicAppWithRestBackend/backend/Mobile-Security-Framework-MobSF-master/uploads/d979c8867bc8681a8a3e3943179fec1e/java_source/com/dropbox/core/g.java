/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

public class g
extends Exception {
    private final String a;

    public g(String string, String string2) {
        super(string2);
        this.a = string;
    }

    public g(String string, String string2, Throwable throwable) {
        super(string2, throwable);
        this.a = string;
    }

    public g(String string, Throwable throwable) {
        this(null, string, throwable);
    }
}

