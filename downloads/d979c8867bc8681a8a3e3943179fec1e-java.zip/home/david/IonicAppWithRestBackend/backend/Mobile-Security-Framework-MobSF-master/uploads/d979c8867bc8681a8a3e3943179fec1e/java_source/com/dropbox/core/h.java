/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.b.a;
import com.dropbox.core.b.b;
import java.util.Arrays;

public final class h {
    public static final h a = new h("api.dropboxapi.com", "content.dropboxapi.com", "www.dropbox.com", "notify.dropboxapi.com");
    public static final a<h> b = new a<h>(){};
    public static final b<h> c = new b<h>(){};
    private final String d;
    private final String e;
    private final String f;
    private final String g;

    public h(String string, String string2, String string3, String string4) {
        this.d = string;
        this.e = string2;
        this.f = string3;
        this.g = string4;
    }

    public String a() {
        return this.d;
    }

    public String b() {
        return this.e;
    }

    public String c() {
        return this.g;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof h)) return false;
        object = (h)object;
        if (!object.d.equals(this.d)) return false;
        if (!object.e.equals(this.e)) return false;
        if (!object.f.equals(this.f)) return false;
        if (object.g.equals(this.g)) return true;
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(new String[]{this.d, this.e, this.f, this.g});
    }

}

