/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.a.c;
import java.util.Locale;

public class i {
    private final String a;
    private final String b;
    private final com.dropbox.core.a.a c;
    private final int d;

    private i(String string, String string2, com.dropbox.core.a.a a2, int n2) {
        if (string == null) {
            throw new NullPointerException("clientIdentifier");
        }
        if (a2 == null) {
            throw new NullPointerException("httpRequestor");
        }
        if (n2 < 0) {
            throw new IllegalArgumentException("maxRetries");
        }
        this.a = string;
        this.b = i.b(string2);
        this.c = a2;
        this.d = n2;
    }

    public static a a(String string) {
        if (string == null) {
            throw new NullPointerException("clientIdentifier");
        }
        return new a(string);
    }

    private static String a(Locale locale) {
        if (locale == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(locale.getLanguage().toLowerCase());
        if (!locale.getCountry().isEmpty()) {
            stringBuilder.append("-");
            stringBuilder.append(locale.getCountry().toUpperCase());
        }
        return stringBuilder.toString();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static String b(String object) {
        if (object == null) {
            return null;
        }
        Object object2 = object;
        if (!object.contains("_")) return object2;
        object2 = object;
        if (object.startsWith("_")) return object2;
        object = object.split("_", 3);
        object2 = object[0];
        String string = object[1];
        if (object.length == 3) {
            object = object[2];
            do {
                return i.a(new Locale((String)object2, string, (String)object));
                break;
            } while (true);
        }
        object = "";
        return i.a(new Locale((String)object2, string, (String)object));
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public com.dropbox.core.a.a c() {
        return this.c;
    }

    public int d() {
        return this.d;
    }

    public static final class a {
        private final String a;
        private String b;
        private com.dropbox.core.a.a c;
        private int d;

        private a(String string) {
            this.a = string;
            this.b = null;
            this.c = c.c;
            this.d = 0;
        }

        public a a(String string) {
            this.b = string;
            return this;
        }

        public i a() {
            return new i(this.a, this.b, this.c, this.d);
        }
    }

}

