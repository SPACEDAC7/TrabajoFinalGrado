/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.a.a;
import com.dropbox.core.b;
import com.dropbox.core.c;
import com.dropbox.core.d;
import com.dropbox.core.g;
import com.dropbox.core.i;
import com.dropbox.core.k;
import com.dropbox.core.n;
import com.dropbox.core.p;
import com.dropbox.core.r;
import com.dropbox.core.s;
import com.dropbox.core.t;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.CharacterCodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public final class j {
    private static final Random a = new Random();

    public static a.a a(i i2, String string) {
        return new a.a("User-Agent", i2.a() + " " + string + "/" + k.a);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static a.b a(i object, String object2, String string, String string2, byte[] arrby, List<a.a> list) {
        string = j.a(string, string2);
        object2 = j.a(j.a(list), (i)object, (String)object2);
        object2.add((a.a)new a.a("Content-Length", Integer.toString(arrby.length)));
        try {
            object = object.c().a(string, (Iterable<a.a>)object2);
        }
        catch (IOException iOException) {
            throw new p(iOException);
        }
        object.a(arrby);
        object2 = object.c();
        {
            catch (Throwable throwable) {
                object.b();
                throw throwable;
            }
        }
        object.b();
        return object2;
    }

    public static String a(a.b b2, String string) {
        List<String> list = b2.c().get(string);
        if (list == null || list.isEmpty()) {
            throw new d(j.c(b2), "missing HTTP header \"" + string + "\"");
        }
        return list.get(0);
    }

    public static String a(String string) {
        try {
            string = URLEncoder.encode(string, "UTF-8");
            return string;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw com.dropbox.core.d.b.a("UTF-8 should always be supported", var0_1);
        }
    }

    public static String a(String string, int n2, byte[] object) {
        try {
            object = com.dropbox.core.d.c.a((byte[])object);
            return object;
        }
        catch (CharacterCodingException var2_3) {
            throw new d(string, "Got non-UTF8 response body: " + n2 + ": " + var2_3.getMessage());
        }
    }

    public static String a(String string, String string2) {
        try {
            String string3 = new URI("https", string, "/" + string2, null).toASCIIString();
            return string3;
        }
        catch (URISyntaxException var2_3) {
            throw com.dropbox.core.d.b.a("URI creation failed, host=" + com.dropbox.core.d.c.b(string) + ", path=" + com.dropbox.core.d.c.b(string2), var2_3);
        }
    }

    public static String a(String string, String string2, String string3, String[] arrstring) {
        return j.a(string2, string3) + "?" + j.a(string, arrstring);
    }

    private static String a(String string, String[] arrstring) {
        StringBuilder stringBuilder = new StringBuilder();
        String string2 = "";
        if (string != null) {
            stringBuilder.append("locale=").append(string);
            string2 = "&";
        }
        if (arrstring != null) {
            if (arrstring.length % 2 != 0) {
                throw new IllegalArgumentException("'params.length' is " + arrstring.length + "; expecting a multiple of two");
            }
            for (int i2 = 0; i2 < arrstring.length; i2 += 2) {
                String string3 = arrstring[i2];
                String string4 = arrstring[i2 + 1];
                if (string3 == null) {
                    throw new IllegalArgumentException("params[" + i2 + "] is null");
                }
                string = string2;
                if (string4 != null) {
                    stringBuilder.append(string2);
                    string = "&";
                    stringBuilder.append(j.a(string3));
                    stringBuilder.append("=");
                    stringBuilder.append(j.a(string4));
                }
                string2 = string;
            }
        }
        return stringBuilder.toString();
    }

    private static List<a.a> a(List<a.a> list) {
        if (list == null) {
            return new ArrayList<a.a>();
        }
        return new ArrayList<a.a>(list);
    }

    public static List<a.a> a(List<a.a> list, i i2) {
        if (i2.b() == null) {
            return list;
        }
        List<a.a> list2 = list;
        if (list == null) {
            list2 = new ArrayList<a.a>();
        }
        list2.add(new a.a("Dropbox-API-User-Locale", i2.b()));
        return list2;
    }

    public static List<a.a> a(List<a.a> list, i i2, String string) {
        List<a.a> list2 = list;
        if (list == null) {
            list2 = new ArrayList<a.a>();
        }
        list2.add(j.a(i2, string));
        return list2;
    }

    public static List<a.a> a(List<a.a> list, String string) {
        if (string == null) {
            throw new NullPointerException("accessToken");
        }
        List<a.a> list2 = list;
        if (list == null) {
            list2 = new ArrayList<a.a>();
        }
        list2.add(new a.a("Authorization", "Bearer " + string));
        return list2;
    }

    public static byte[] a(a.b arrby) {
        if (arrby.b() == null) {
            return new byte[0];
        }
        try {
            arrby = com.dropbox.core.d.a.a(arrby.b(), 4096);
            return arrby;
        }
        catch (IOException var0_1) {
            throw new p(var0_1);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static g b(a.b object) {
        String string = j.c((a.b)object);
        Object object2 = j.a((a.b)object);
        object2 = j.a(string, object.a(), (byte[])object2);
        switch (object.a()) {
            default: {
                return new c(string, "unexpected HTTP status code: " + object.a() + ": " + (String)object2, object.a());
            }
            case 400: {
                return new b(string, (String)object2);
            }
            case 401: {
                return new n(string, (String)object2);
            }
            case 429: {
                try {
                    return new r(string, (String)object2, Integer.parseInt(j.a((a.b)object, "Retry-After")), TimeUnit.SECONDS);
                }
                catch (NumberFormatException var0_1) {
                    return new d(string, "Invalid value for HTTP header: \"Retry-After\"");
                }
            }
            case 500: {
                return new t(string, (String)object2);
            }
            case 503: 
        }
        object = j.b((a.b)object, "Retry-After");
        if (object == null) return new s(string, (String)object2);
        try {
            if (object.trim().isEmpty()) return new s(string, (String)object2);
            return new s(string, (String)object2, Integer.parseInt((String)object), TimeUnit.SECONDS);
        }
        catch (NumberFormatException var0_2) {
            return new d(string, "Invalid value for HTTP header: \"Retry-After\"");
        }
    }

    public static String b(a.b object, String string) {
        if ((object = object.c().get(string)) == null || object.isEmpty()) {
            return null;
        }
        return (String)object.get(0);
    }

    public static String c(a.b b2) {
        return j.b(b2, "X-Dropbox-Request-Id");
    }
}

