/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.d.c;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class k {
    public static final String a = k.b();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static String a() {
        var0 = k.class.getResourceAsStream("/sdk-version.txt");
        if (var0 == null) {
            throw new a("Not found.");
        }
        {
            catch (IOException var0_1) {
                throw new a(var0_1.getMessage());
            }
        }
        try {
            var2_2 = new BufferedReader(com.dropbox.core.d.a.a(var0));
            var1_3 = var2_2.readLine();
            if (var1_3 == null) {
                throw new a("No lines.");
            }
            if ((var2_2 = var2_2.readLine()) == null) return var1_3;
            throw new a("Found more than one line.  Second line: " + c.b((String)var2_2));
        }
        finally {
            ** try [egrp 2[TRYBLOCK] [4 : 67->73)] { 
lbl17: // 1 sources:
            com.dropbox.core.d.a.b(var0);
        }
    }

    private static String b() {
        String string;
        try {
            string = k.a();
            if (!Pattern.compile("[0-9]+(?:\\.[0-9]+)*(?:-[-_A-Za-z0-9]+)?").matcher(string).matches()) {
                throw new a("Text doesn't follow expected pattern: " + c.b(string));
            }
        }
        catch (a var0_1) {
            throw new RuntimeException("Error loading version from resource \"sdk-version.txt\": " + var0_1.getMessage());
        }
        return string;
    }

    private static final class a
    extends Exception {
        public a(String string) {
            super(string);
        }
    }

}

