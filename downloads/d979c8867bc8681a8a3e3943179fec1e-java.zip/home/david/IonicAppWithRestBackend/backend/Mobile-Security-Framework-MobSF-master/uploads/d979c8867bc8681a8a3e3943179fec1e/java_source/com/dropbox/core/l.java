/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.a.a;
import com.dropbox.core.c.b;
import com.dropbox.core.e;
import com.dropbox.core.m;
import com.dropbox.core.p;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;

public abstract class l<R, E, X extends e>
implements Closeable {
    private final a.c a;
    private final b<R> b;
    private final b<E> c;
    private boolean d;
    private boolean e;

    protected l(a.c c2, b<R> b2, b<E> b3) {
        this.a = c2;
        this.b = b2;
        this.c = b3;
        this.d = false;
        this.e = false;
    }

    private void b() {
        if (this.d) {
            throw new IllegalStateException("This uploader is already closed.");
        }
        if (this.e) {
            throw new IllegalStateException("This uploader is already finished and cannot be used to upload more data.");
        }
    }

    protected abstract X a(m var1);

    /*
     * Exception decompiling
     */
    public R a() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:371)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:449)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    public R a(InputStream inputStream) {
        try {
            try {
                this.a.a(inputStream);
                inputStream = this.a();
            }
            catch (IOException var1_2) {
                throw new p(var1_2);
            }
            return (R)inputStream;
        }
        finally {
            this.close();
        }
    }

    @Override
    public void close() {
        if (!this.d) {
            this.a.b();
            this.d = true;
        }
    }
}

