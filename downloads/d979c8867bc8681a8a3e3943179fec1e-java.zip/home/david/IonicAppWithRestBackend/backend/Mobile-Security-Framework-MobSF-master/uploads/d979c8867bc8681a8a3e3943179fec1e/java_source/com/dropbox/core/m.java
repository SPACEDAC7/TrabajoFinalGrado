/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.a;
import com.dropbox.core.a.a;
import com.dropbox.core.c.b;
import com.dropbox.core.j;
import com.dropbox.core.o;
import java.io.InputStream;

public final class m
extends Exception {
    private final Object a;
    private final String b;
    private final o c;

    public m(Object object, String string, o o2) {
        this.a = object;
        this.b = string;
        this.c = o2;
    }

    public static <T> m a(b<T> object, a.b b2) {
        String string = j.c(b2);
        object = (a)new a.a<T>((b<T>)object).a(b2.b());
        return new m(object.a(), string, object.b());
    }

    public Object a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public o c() {
        return this.c;
    }
}

