/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.g;

public class n
extends g {
    public n(String string, String string2) {
        super(string, string2);
    }
}

