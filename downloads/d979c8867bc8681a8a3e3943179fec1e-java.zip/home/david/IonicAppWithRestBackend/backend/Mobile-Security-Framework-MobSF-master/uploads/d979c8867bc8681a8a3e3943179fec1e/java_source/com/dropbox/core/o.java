/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.c.b;
import com.dropbox.core.c.c;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

public final class o {
    static final b<o> a = new b<o>(){

        /*
         * Enabled aggressive block sorting
         */
        public o a(JsonParser jsonParser) {
            Object object = null;
            .e(jsonParser);
            Object object2 = null;
            while (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
                Object object3 = jsonParser.getCurrentName();
                jsonParser.nextToken();
                if ("text".equals(object3)) {
                    object3 = c.d().b(jsonParser);
                    object2 = object;
                    object = object3;
                } else if ("locale".equals(object3)) {
                    object3 = c.d().b(jsonParser);
                    object = object2;
                    object2 = object3;
                } else {
                    .i(jsonParser);
                    object3 = object2;
                    object2 = object;
                    object = object3;
                }
                object3 = object;
                object = object2;
                object2 = object3;
            }
            if (object2 == null) {
                throw new JsonParseException(jsonParser, "Required field \"text\" missing.");
            }
            if (object == null) {
                throw new JsonParseException(jsonParser, "Required field \"locale\" missing.");
            }
            object2 = new o((String)object2, (String)object);
            .f(jsonParser);
            return object2;
        }

        @Override
        public void a(o o2, JsonGenerator jsonGenerator) {
            throw new UnsupportedOperationException("Error wrapper serialization not supported.");
        }

        @Override
        public /* synthetic */ Object b(JsonParser jsonParser) {
            return this.a(jsonParser);
        }
    };
    private final String b;
    private final String c;

    public o(String string, String string2) {
        if (string == null) {
            throw new NullPointerException("text");
        }
        if (string2 == null) {
            throw new NullPointerException("locale");
        }
        this.b = string;
        this.c = string2;
    }

    public String toString() {
        return this.b;
    }

}

