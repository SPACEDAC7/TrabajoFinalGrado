/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.g;
import java.io.IOException;

public class p
extends g {
    public p(IOException iOException) {
        super(iOException.getMessage(), iOException);
    }

    public IOException a() {
        return (IOException)super.getCause();
    }

    @Override
    public /* synthetic */ Throwable getCause() {
        return this.a();
    }
}

