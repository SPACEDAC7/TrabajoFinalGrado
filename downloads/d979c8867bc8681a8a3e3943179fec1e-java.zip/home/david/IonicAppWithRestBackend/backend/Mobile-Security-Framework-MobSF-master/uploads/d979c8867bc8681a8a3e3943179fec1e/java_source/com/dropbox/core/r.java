/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.s;
import java.util.concurrent.TimeUnit;

public class r
extends s {
    public r(String string, String string2, long l2, TimeUnit timeUnit) {
        super(string, string2, l2, timeUnit);
    }
}

