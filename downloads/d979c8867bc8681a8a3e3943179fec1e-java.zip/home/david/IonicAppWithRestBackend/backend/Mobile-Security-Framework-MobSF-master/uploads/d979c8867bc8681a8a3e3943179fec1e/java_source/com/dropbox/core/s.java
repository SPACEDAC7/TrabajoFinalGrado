/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.g;
import java.util.concurrent.TimeUnit;

public class s
extends g {
    private final long a;

    public s(String string, String string2) {
        this(string, string2, 0, TimeUnit.MILLISECONDS);
    }

    public s(String string, String string2, long l2, TimeUnit timeUnit) {
        super(string, string2);
        this.a = timeUnit.toMillis(l2);
    }

    public long a() {
        return this.a;
    }
}

