/*
 * Decompiled with CFR 0_115.
 */
package com.dropbox.core;

import com.dropbox.core.g;

public class t
extends g {
    public t(String string, String string2) {
        super(string, string2);
    }
}

