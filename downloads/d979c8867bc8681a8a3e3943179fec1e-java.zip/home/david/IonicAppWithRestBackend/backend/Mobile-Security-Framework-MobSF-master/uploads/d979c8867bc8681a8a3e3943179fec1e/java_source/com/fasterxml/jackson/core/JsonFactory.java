/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.SerializableString;
import com.fasterxml.jackson.core.io.CharacterEscapes;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.io.InputDecorator;
import com.fasterxml.jackson.core.io.OutputDecorator;
import com.fasterxml.jackson.core.io.SerializedString;
import com.fasterxml.jackson.core.io.UTF8Writer;
import com.fasterxml.jackson.core.json.ByteSourceJsonBootstrapper;
import com.fasterxml.jackson.core.json.ReaderBasedJsonParser;
import com.fasterxml.jackson.core.json.UTF8JsonGenerator;
import com.fasterxml.jackson.core.json.WriterBasedJsonGenerator;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
import com.fasterxml.jackson.core.util.BufferRecycler;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import java.io.Closeable;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringReader;
import java.io.Writer;
import java.lang.ref.SoftReference;

public class JsonFactory
implements Serializable {
    protected static final int DEFAULT_FACTORY_FEATURE_FLAGS = Feature.collectDefaults();
    protected static final int DEFAULT_GENERATOR_FEATURE_FLAGS;
    protected static final int DEFAULT_PARSER_FEATURE_FLAGS;
    private static final SerializableString DEFAULT_ROOT_VALUE_SEPARATOR;
    protected static final ThreadLocal<SoftReference<BufferRecycler>> _recyclerRef;
    protected final transient ByteQuadsCanonicalizer _byteSymbolCanonicalizer = ByteQuadsCanonicalizer.createRoot();
    protected CharacterEscapes _characterEscapes;
    protected int _factoryFeatures = DEFAULT_FACTORY_FEATURE_FLAGS;
    protected int _generatorFeatures = DEFAULT_GENERATOR_FEATURE_FLAGS;
    protected InputDecorator _inputDecorator;
    protected ObjectCodec _objectCodec;
    protected OutputDecorator _outputDecorator;
    protected int _parserFeatures = DEFAULT_PARSER_FEATURE_FLAGS;
    protected final transient CharsToNameCanonicalizer _rootCharSymbols = CharsToNameCanonicalizer.createRoot();
    protected SerializableString _rootValueSeparator = DEFAULT_ROOT_VALUE_SEPARATOR;

    static {
        DEFAULT_PARSER_FEATURE_FLAGS = JsonParser.Feature.collectDefaults();
        DEFAULT_GENERATOR_FEATURE_FLAGS = JsonGenerator.Feature.collectDefaults();
        DEFAULT_ROOT_VALUE_SEPARATOR = DefaultPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR;
        _recyclerRef = new ThreadLocal();
    }

    public JsonFactory() {
        this(null);
    }

    public JsonFactory(ObjectCodec objectCodec) {
        this._objectCodec = objectCodec;
    }

    protected IOContext _createContext(Object object, boolean bl2) {
        return new IOContext(this._getBufferRecycler(), object, bl2);
    }

    protected JsonGenerator _createGenerator(Writer closeable, IOContext object) {
        closeable = new WriterBasedJsonGenerator((IOContext)object, this._generatorFeatures, this._objectCodec, (Writer)closeable);
        if (this._characterEscapes != null) {
            closeable.setCharacterEscapes(this._characterEscapes);
        }
        if ((object = this._rootValueSeparator) != DEFAULT_ROOT_VALUE_SEPARATOR) {
            closeable.setRootValueSeparator((SerializableString)object);
        }
        return closeable;
    }

    protected JsonParser _createParser(InputStream inputStream, IOContext iOContext) {
        return new ByteSourceJsonBootstrapper(iOContext, inputStream).constructParser(this._parserFeatures, this._objectCodec, this._byteSymbolCanonicalizer, this._rootCharSymbols, this._factoryFeatures);
    }

    protected JsonParser _createParser(Reader reader, IOContext iOContext) {
        return new ReaderBasedJsonParser(iOContext, this._parserFeatures, reader, this._objectCodec, this._rootCharSymbols.makeChild(this._factoryFeatures));
    }

    protected JsonParser _createParser(char[] arrc, int n2, int n3, IOContext iOContext, boolean bl2) {
        return new ReaderBasedJsonParser(iOContext, this._parserFeatures, null, this._objectCodec, this._rootCharSymbols.makeChild(this._factoryFeatures), arrc, n2, n2 + n3, bl2);
    }

    protected JsonGenerator _createUTF8Generator(OutputStream closeable, IOContext object) {
        closeable = new UTF8JsonGenerator((IOContext)object, this._generatorFeatures, this._objectCodec, (OutputStream)closeable);
        if (this._characterEscapes != null) {
            closeable.setCharacterEscapes(this._characterEscapes);
        }
        if ((object = this._rootValueSeparator) != DEFAULT_ROOT_VALUE_SEPARATOR) {
            closeable.setRootValueSeparator((SerializableString)object);
        }
        return closeable;
    }

    protected Writer _createWriter(OutputStream outputStream, JsonEncoding jsonEncoding, IOContext iOContext) {
        if (jsonEncoding == JsonEncoding.UTF8) {
            return new UTF8Writer(iOContext, outputStream);
        }
        return new OutputStreamWriter(outputStream, jsonEncoding.getJavaName());
    }

    protected final InputStream _decorate(InputStream inputStream, IOContext object) {
        Object object2 = inputStream;
        if (this._inputDecorator != null) {
            object = this._inputDecorator.decorate((IOContext)object, inputStream);
            object2 = inputStream;
            if (object != null) {
                object2 = object;
            }
        }
        return object2;
    }

    protected final OutputStream _decorate(OutputStream outputStream, IOContext object) {
        Object object2 = outputStream;
        if (this._outputDecorator != null) {
            object = this._outputDecorator.decorate((IOContext)object, outputStream);
            object2 = outputStream;
            if (object != null) {
                object2 = object;
            }
        }
        return object2;
    }

    protected final Reader _decorate(Reader reader, IOContext object) {
        Object object2 = reader;
        if (this._inputDecorator != null) {
            object = this._inputDecorator.decorate((IOContext)object, reader);
            object2 = reader;
            if (object != null) {
                object2 = object;
            }
        }
        return object2;
    }

    protected final Writer _decorate(Writer writer, IOContext object) {
        Object object2 = writer;
        if (this._outputDecorator != null) {
            object = this._outputDecorator.decorate((IOContext)object, writer);
            object2 = writer;
            if (object != null) {
                object2 = object;
            }
        }
        return object2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public BufferRecycler _getBufferRecycler() {
        if (!this.isEnabled(Feature.USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING)) {
            return new BufferRecycler();
        }
        SoftReference<BufferRecycler> softReference = _recyclerRef.get();
        softReference = softReference == null ? null : softReference.get();
        Object object = softReference;
        if (softReference == null) {
            object = new BufferRecycler();
            _recyclerRef.set(new SoftReference<Object>(object));
        }
        return object;
    }

    public boolean canUseCharArrays() {
        return true;
    }

    public JsonGenerator createGenerator(OutputStream outputStream) {
        return this.createGenerator(outputStream, JsonEncoding.UTF8);
    }

    public JsonGenerator createGenerator(OutputStream outputStream, JsonEncoding jsonEncoding) {
        IOContext iOContext = this._createContext(outputStream, false);
        iOContext.setEncoding(jsonEncoding);
        if (jsonEncoding == JsonEncoding.UTF8) {
            return this._createUTF8Generator(this._decorate(outputStream, iOContext), iOContext);
        }
        return this._createGenerator(this._decorate(this._createWriter(outputStream, jsonEncoding, iOContext), iOContext), iOContext);
    }

    public JsonGenerator createGenerator(Writer writer) {
        IOContext iOContext = this._createContext(writer, false);
        return this._createGenerator(this._decorate(writer, iOContext), iOContext);
    }

    public JsonParser createParser(InputStream inputStream) {
        IOContext iOContext = this._createContext(inputStream, false);
        return this._createParser(this._decorate(inputStream, iOContext), iOContext);
    }

    public JsonParser createParser(Reader reader) {
        IOContext iOContext = this._createContext(reader, false);
        return this._createParser(this._decorate(reader, iOContext), iOContext);
    }

    public JsonParser createParser(String string) {
        int n2 = string.length();
        if (this._inputDecorator != null || n2 > 32768 || !this.canUseCharArrays()) {
            return this.createParser(new StringReader(string));
        }
        IOContext iOContext = this._createContext(string, true);
        char[] arrc = iOContext.allocTokenBuffer(n2);
        string.getChars(0, n2, arrc, 0);
        return this._createParser(arrc, 0, n2, iOContext, true);
    }

    public final boolean isEnabled(Feature feature) {
        if ((this._factoryFeatures & feature.getMask()) != 0) {
            return true;
        }
        return false;
    }

    public static enum Feature {
        INTERN_FIELD_NAMES(true),
        CANONICALIZE_FIELD_NAMES(true),
        FAIL_ON_SYMBOL_HASH_OVERFLOW(true),
        USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING(true);
        
        private final boolean _defaultState;

        private Feature(boolean bl2) {
            this._defaultState = bl2;
        }

        public static int collectDefaults() {
            int n2 = 0;
            for (Feature feature : Feature.values()) {
                int n3 = n2;
                if (feature.enabledByDefault()) {
                    n3 = n2 | feature.getMask();
                }
                n2 = n3;
            }
            return n2;
        }

        public boolean enabledByDefault() {
            return this._defaultState;
        }

        public boolean enabledIn(int n2) {
            if ((this.getMask() & n2) != 0) {
                return true;
            }
            return false;
        }

        public int getMask() {
            return 1 << this.ordinal();
        }
    }

}

