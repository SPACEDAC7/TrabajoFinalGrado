/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonProcessingException;

public class JsonGenerationException
extends JsonProcessingException {
    protected transient JsonGenerator _processor;

    public JsonGenerationException(String string, JsonGenerator jsonGenerator) {
        super(string, null);
        this._processor = jsonGenerator;
    }
}

