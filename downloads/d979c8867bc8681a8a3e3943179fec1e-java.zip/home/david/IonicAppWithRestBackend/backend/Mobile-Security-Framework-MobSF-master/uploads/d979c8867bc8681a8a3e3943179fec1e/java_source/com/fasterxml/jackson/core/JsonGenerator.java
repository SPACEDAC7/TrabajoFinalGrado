/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.PrettyPrinter;
import com.fasterxml.jackson.core.SerializableString;
import com.fasterxml.jackson.core.io.CharacterEscapes;
import com.fasterxml.jackson.core.util.VersionUtil;
import java.io.Closeable;
import java.io.Flushable;

public abstract class JsonGenerator
implements Closeable,
Flushable {
    protected PrettyPrinter _cfgPrettyPrinter;

    protected JsonGenerator() {
    }

    protected void _reportError(String string) {
        throw new JsonGenerationException(string, this);
    }

    protected final void _throwInternal() {
        VersionUtil.throwInternal();
    }

    @Override
    public abstract void flush();

    public PrettyPrinter getPrettyPrinter() {
        return this._cfgPrettyPrinter;
    }

    public JsonGenerator setCharacterEscapes(CharacterEscapes characterEscapes) {
        return this;
    }

    public JsonGenerator setHighestNonEscapedChar(int n2) {
        return this;
    }

    public JsonGenerator setPrettyPrinter(PrettyPrinter prettyPrinter) {
        this._cfgPrettyPrinter = prettyPrinter;
        return this;
    }

    public JsonGenerator setRootValueSeparator(SerializableString serializableString) {
        throw new UnsupportedOperationException();
    }

    public abstract JsonGenerator useDefaultPrettyPrinter();

    public abstract void writeBoolean(boolean var1);

    public abstract void writeEndArray();

    public abstract void writeEndObject();

    public abstract void writeFieldName(String var1);

    public abstract void writeNull();

    public abstract void writeNumber(double var1);

    public abstract void writeNumber(long var1);

    public abstract void writeRaw(char var1);

    public void writeRaw(SerializableString serializableString) {
        this.writeRaw(serializableString.getValue());
    }

    public abstract void writeRaw(String var1);

    public abstract void writeRaw(char[] var1, int var2, int var3);

    public abstract void writeStartArray();

    public void writeStartArray(int n2) {
        this.writeStartArray();
    }

    public abstract void writeStartObject();

    public abstract void writeString(String var1);

    public void writeStringField(String string, String string2) {
        this.writeFieldName(string);
        this.writeString(string2);
    }

    public static enum Feature {
        AUTO_CLOSE_TARGET(true),
        AUTO_CLOSE_JSON_CONTENT(true),
        FLUSH_PASSED_TO_STREAM(true),
        QUOTE_FIELD_NAMES(true),
        QUOTE_NON_NUMERIC_NUMBERS(true),
        WRITE_NUMBERS_AS_STRINGS(false),
        WRITE_BIGDECIMAL_AS_PLAIN(false),
        ESCAPE_NON_ASCII(false),
        STRICT_DUPLICATE_DETECTION(false),
        IGNORE_UNKNOWN(false);
        
        private final boolean _defaultState;
        private final int _mask;

        private Feature(boolean bl2) {
            this._defaultState = bl2;
            this._mask = 1 << this.ordinal();
        }

        public static int collectDefaults() {
            int n2 = 0;
            for (Feature feature : Feature.values()) {
                int n3 = n2;
                if (feature.enabledByDefault()) {
                    n3 = n2 | feature.getMask();
                }
                n2 = n3;
            }
            return n2;
        }

        public boolean enabledByDefault() {
            return this._defaultState;
        }

        public boolean enabledIn(int n2) {
            if ((this._mask & n2) != 0) {
                return true;
            }
            return false;
        }

        public int getMask() {
            return this._mask;
        }
    }

}

