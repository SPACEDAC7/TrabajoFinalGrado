/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;

public class JsonParseException
extends JsonProcessingException {
    protected transient JsonParser _processor;

    /*
     * Enabled aggressive block sorting
     */
    public JsonParseException(JsonParser jsonParser, String string) {
        JsonLocation jsonLocation = jsonParser == null ? null : jsonParser.getCurrentLocation();
        super(string, jsonLocation);
        this._processor = jsonParser;
    }

    /*
     * Enabled aggressive block sorting
     */
    public JsonParseException(JsonParser jsonParser, String string, Throwable throwable) {
        JsonLocation jsonLocation = jsonParser == null ? null : jsonParser.getCurrentLocation();
        super(string, jsonLocation, throwable);
        this._processor = jsonParser;
    }
}

