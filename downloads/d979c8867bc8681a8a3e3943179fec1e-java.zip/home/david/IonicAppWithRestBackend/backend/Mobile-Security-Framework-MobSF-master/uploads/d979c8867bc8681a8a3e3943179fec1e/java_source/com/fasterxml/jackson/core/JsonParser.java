/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import java.io.Closeable;

public abstract class JsonParser
implements Closeable {
    protected int _features;

    protected JsonParser() {
    }

    protected JsonParser(int n2) {
        this._features = n2;
    }

    protected JsonParseException _constructError(String string) {
        return new JsonParseException(this, string);
    }

    public boolean getBooleanValue() {
        JsonToken jsonToken = this.getCurrentToken();
        if (jsonToken == JsonToken.VALUE_TRUE) {
            return true;
        }
        if (jsonToken == JsonToken.VALUE_FALSE) {
            return false;
        }
        throw new JsonParseException(this, String.format("Current token (%s) not of boolean type", new Object[]{jsonToken}));
    }

    public abstract JsonLocation getCurrentLocation();

    public abstract String getCurrentName();

    public abstract JsonToken getCurrentToken();

    public abstract double getDoubleValue();

    public abstract long getLongValue();

    public abstract String getText();

    public boolean isEnabled(Feature feature) {
        return feature.enabledIn(this._features);
    }

    public abstract JsonToken nextToken();

    public abstract JsonParser skipChildren();

    public static enum Feature {
        AUTO_CLOSE_SOURCE(true),
        ALLOW_COMMENTS(false),
        ALLOW_YAML_COMMENTS(false),
        ALLOW_UNQUOTED_FIELD_NAMES(false),
        ALLOW_SINGLE_QUOTES(false),
        ALLOW_UNQUOTED_CONTROL_CHARS(false),
        ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER(false),
        ALLOW_NUMERIC_LEADING_ZEROS(false),
        ALLOW_NON_NUMERIC_NUMBERS(false),
        STRICT_DUPLICATE_DETECTION(false),
        IGNORE_UNDEFINED(false);
        
        private final boolean _defaultState;
        private final int _mask;

        private Feature(boolean bl2) {
            this._mask = 1 << this.ordinal();
            this._defaultState = bl2;
        }

        public static int collectDefaults() {
            int n2 = 0;
            for (Feature feature : Feature.values()) {
                int n3 = n2;
                if (feature.enabledByDefault()) {
                    n3 = n2 | feature.getMask();
                }
                n2 = n3;
            }
            return n2;
        }

        public boolean enabledByDefault() {
            return this._defaultState;
        }

        public boolean enabledIn(int n2) {
            if ((this._mask & n2) != 0) {
                return true;
            }
            return false;
        }

        public int getMask() {
            return this._mask;
        }
    }

}

