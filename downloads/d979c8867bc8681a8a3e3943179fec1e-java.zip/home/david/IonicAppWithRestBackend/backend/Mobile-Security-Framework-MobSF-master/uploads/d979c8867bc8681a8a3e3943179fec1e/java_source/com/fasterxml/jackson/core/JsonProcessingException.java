/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.JsonLocation;
import java.io.IOException;

public class JsonProcessingException
extends IOException {
    protected JsonLocation _location;

    protected JsonProcessingException(String string, JsonLocation jsonLocation) {
        this(string, jsonLocation, null);
    }

    protected JsonProcessingException(String string, JsonLocation jsonLocation, Throwable throwable) {
        super(string);
        if (throwable != null) {
            this.initCause(throwable);
        }
        this._location = jsonLocation;
    }

    public JsonLocation getLocation() {
        return this._location;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String getMessage() {
        String string;
        void var2_6;
        String string2 = string = super.getMessage();
        if (string == null) {
            string2 = "N/A";
        }
        JsonLocation jsonLocation = this.getLocation();
        String string3 = this.getMessageSuffix();
        if (jsonLocation == null) {
            String string4 = string2;
            if (string3 == null) return var2_6;
        }
        StringBuilder stringBuilder = new StringBuilder(100);
        stringBuilder.append(string2);
        if (string3 != null) {
            stringBuilder.append(string3);
        }
        if (jsonLocation != null) {
            stringBuilder.append('\n');
            stringBuilder.append(" at ");
            stringBuilder.append(jsonLocation.toString());
        }
        String string5 = stringBuilder.toString();
        return var2_6;
    }

    protected String getMessageSuffix() {
        return null;
    }

    @Override
    public String toString() {
        return this.getClass().getName() + ": " + this.getMessage();
    }
}

