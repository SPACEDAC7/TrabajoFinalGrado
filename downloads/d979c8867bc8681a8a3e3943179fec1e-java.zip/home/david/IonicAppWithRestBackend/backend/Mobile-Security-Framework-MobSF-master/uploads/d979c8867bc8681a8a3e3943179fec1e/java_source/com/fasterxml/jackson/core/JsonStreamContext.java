/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

public abstract class JsonStreamContext {
    protected int _index;
    protected int _type;

    protected JsonStreamContext() {
    }

    public final int getCurrentIndex() {
        if (this._index < 0) {
            return 0;
        }
        return this._index;
    }

    public final int getEntryCount() {
        return this._index + 1;
    }

    public final String getTypeDesc() {
        switch (this._type) {
            default: {
                return "?";
            }
            case 0: {
                return "ROOT";
            }
            case 1: {
                return "ARRAY";
            }
            case 2: 
        }
        return "OBJECT";
    }

    public final boolean inArray() {
        if (this._type == 1) {
            return true;
        }
        return false;
    }

    public final boolean inObject() {
        if (this._type == 2) {
            return true;
        }
        return false;
    }

    public final boolean inRoot() {
        if (this._type == 0) {
            return true;
        }
        return false;
    }
}

