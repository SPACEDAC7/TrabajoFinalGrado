/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.TreeCodec;

public abstract class ObjectCodec
extends TreeCodec {
}

