/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.JsonGenerator;

public interface PrettyPrinter {
    public void beforeArrayValues(JsonGenerator var1);

    public void beforeObjectEntries(JsonGenerator var1);

    public void writeArrayValueSeparator(JsonGenerator var1);

    public void writeEndArray(JsonGenerator var1, int var2);

    public void writeEndObject(JsonGenerator var1, int var2);

    public void writeObjectEntrySeparator(JsonGenerator var1);

    public void writeObjectFieldValueSeparator(JsonGenerator var1);

    public void writeRootValueSeparator(JsonGenerator var1);

    public void writeStartArray(JsonGenerator var1);

    public void writeStartObject(JsonGenerator var1);
}

