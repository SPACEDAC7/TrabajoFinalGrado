/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

public interface SerializableString {
    public byte[] asUnquotedUTF8();

    public String getValue();
}

