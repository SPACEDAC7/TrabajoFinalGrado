/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core;

public abstract class TreeCodec {
}

