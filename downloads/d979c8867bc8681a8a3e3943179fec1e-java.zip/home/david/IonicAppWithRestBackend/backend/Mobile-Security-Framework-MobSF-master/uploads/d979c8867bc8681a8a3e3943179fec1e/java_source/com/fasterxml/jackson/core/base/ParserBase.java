/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.base;

import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.base.ParserMinimalBase;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.io.NumberInput;
import com.fasterxml.jackson.core.json.DupDetector;
import com.fasterxml.jackson.core.json.JsonReadContext;
import com.fasterxml.jackson.core.util.TextBuffer;
import java.math.BigDecimal;
import java.math.BigInteger;

public abstract class ParserBase
extends ParserMinimalBase {
    static final BigDecimal BD_MAX_INT;
    static final BigDecimal BD_MAX_LONG;
    static final BigDecimal BD_MIN_INT;
    static final BigDecimal BD_MIN_LONG;
    static final BigInteger BI_MAX_INT;
    static final BigInteger BI_MAX_LONG;
    static final BigInteger BI_MIN_INT;
    static final BigInteger BI_MIN_LONG;
    protected byte[] _binaryValue;
    protected boolean _closed;
    protected long _currInputProcessed;
    protected int _currInputRow = 1;
    protected int _currInputRowStart;
    protected int _expLength;
    protected int _fractLength;
    protected int _inputEnd;
    protected int _inputPtr;
    protected int _intLength;
    protected final IOContext _ioContext;
    protected boolean _nameCopied;
    protected char[] _nameCopyBuffer;
    protected JsonToken _nextToken;
    protected int _numTypesValid = 0;
    protected BigDecimal _numberBigDecimal;
    protected BigInteger _numberBigInt;
    protected double _numberDouble;
    protected int _numberInt;
    protected long _numberLong;
    protected boolean _numberNegative;
    protected JsonReadContext _parsingContext;
    protected final TextBuffer _textBuffer;
    protected int _tokenInputCol;
    protected int _tokenInputRow = 1;
    protected long _tokenInputTotal;

    static {
        BI_MIN_INT = BigInteger.valueOf(Integer.MIN_VALUE);
        BI_MAX_INT = BigInteger.valueOf(Integer.MAX_VALUE);
        BI_MIN_LONG = BigInteger.valueOf(Long.MIN_VALUE);
        BI_MAX_LONG = BigInteger.valueOf(Long.MAX_VALUE);
        BD_MIN_LONG = new BigDecimal(BI_MIN_LONG);
        BD_MAX_LONG = new BigDecimal(BI_MAX_LONG);
        BD_MIN_INT = new BigDecimal(BI_MIN_INT);
        BD_MAX_INT = new BigDecimal(BI_MAX_INT);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected ParserBase(IOContext object, int n2) {
        super(n2);
        this._ioContext = object;
        this._textBuffer = object.constructTextBuffer();
        object = JsonParser.Feature.STRICT_DUPLICATE_DETECTION.enabledIn(n2) ? DupDetector.rootDetector(this) : null;
        this._parsingContext = JsonReadContext.createRootContext((DupDetector)object);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void _parseSlowFloat(int var1_1) {
        if (var1_1 != 16) ** GOTO lbl6
        try {
            this._numberBigDecimal = this._textBuffer.contentsAsDecimal();
            this._numTypesValid = 16;
            return;
lbl6: // 1 sources:
            this._numberDouble = this._textBuffer.contentsAsDouble();
            this._numTypesValid = 8;
            return;
        }
        catch (NumberFormatException var2_2) {
            this._wrapError("Malformed numeric value '" + this._textBuffer.contentsAsString() + "'", var2_2);
            return;
        }
    }

    private void _parseSlowInt(int n2, char[] arrc, int n3, int n4) {
        String string = this._textBuffer.contentsAsString();
        try {
            if (NumberInput.inLongRange(arrc, n3, n4, this._numberNegative)) {
                this._numberLong = Long.parseLong(string);
                this._numTypesValid = 2;
                return;
            }
            this._numberBigInt = new BigInteger(string);
            this._numTypesValid = 4;
            return;
        }
        catch (NumberFormatException var2_3) {
            this._wrapError("Malformed numeric value '" + string + "'", var2_3);
            return;
        }
    }

    protected abstract void _closeInput();

    protected char _decodeEscaped() {
        throw new UnsupportedOperationException();
    }

    protected final int _eofAsNextChar() {
        this._handleEOF();
        return -1;
    }

    protected abstract void _finishString();

    @Override
    protected void _handleEOF() {
        if (!this._parsingContext.inRoot()) {
            this._reportInvalidEOF(": expected close marker for " + this._parsingContext.getTypeDesc() + " (from " + this._parsingContext.getStartLocation(this._ioContext.getSourceReference()) + ")");
        }
    }

    protected void _parseNumericValue(int n2) {
        if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
            char[] arrc = this._textBuffer.getTextBuffer();
            int n3 = this._textBuffer.getTextOffset();
            int n4 = this._intLength;
            int n5 = n3;
            if (this._numberNegative) {
                n5 = n3 + 1;
            }
            if (n4 <= 9) {
                n2 = n5 = NumberInput.parseInt(arrc, n5, n4);
                if (this._numberNegative) {
                    n2 = - n5;
                }
                this._numberInt = n2;
                this._numTypesValid = 1;
                return;
            }
            if (n4 <= 18) {
                long l2;
                long l3 = l2 = NumberInput.parseLong(arrc, n5, n4);
                if (this._numberNegative) {
                    l3 = - l2;
                }
                if (n4 == 10) {
                    if (this._numberNegative) {
                        if (l3 >= Integer.MIN_VALUE) {
                            this._numberInt = (int)l3;
                            this._numTypesValid = 1;
                            return;
                        }
                    } else if (l3 <= Integer.MAX_VALUE) {
                        this._numberInt = (int)l3;
                        this._numTypesValid = 1;
                        return;
                    }
                }
                this._numberLong = l3;
                this._numTypesValid = 2;
                return;
            }
            this._parseSlowInt(n2, arrc, n5, n4);
            return;
        }
        if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
            this._parseSlowFloat(n2);
            return;
        }
        this._reportError("Current token (" + (Object)((Object)this._currToken) + ") not numeric, can not use numeric value accessors");
    }

    protected void _releaseBuffers() {
        this._textBuffer.releaseBuffers();
        char[] arrc = this._nameCopyBuffer;
        if (arrc != null) {
            this._nameCopyBuffer = null;
            this._ioContext.releaseNameCopyBuffer(arrc);
        }
    }

    protected void _reportMismatchedEndMarker(int n2, char c2) {
        String string = "" + this._parsingContext.getStartLocation(this._ioContext.getSourceReference());
        this._reportError("Unexpected close marker '" + (char)n2 + "': expected '" + c2 + "' (for " + this._parsingContext.getTypeDesc() + " starting at " + string + ")");
    }

    @Override
    public void close() {
        if (!this._closed) {
            this._closed = true;
            this._closeInput();
        }
        return;
        finally {
            this._releaseBuffers();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void convertNumberToDouble() {
        if ((this._numTypesValid & 16) != 0) {
            this._numberDouble = this._numberBigDecimal.doubleValue();
        } else if ((this._numTypesValid & 4) != 0) {
            this._numberDouble = this._numberBigInt.doubleValue();
        } else if ((this._numTypesValid & 2) != 0) {
            this._numberDouble = this._numberLong;
        } else if ((this._numTypesValid & 1) != 0) {
            this._numberDouble = this._numberInt;
        } else {
            this._throwInternal();
        }
        this._numTypesValid |= 8;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void convertNumberToLong() {
        if ((this._numTypesValid & 1) != 0) {
            this._numberLong = this._numberInt;
        } else if ((this._numTypesValid & 4) != 0) {
            if (BI_MIN_LONG.compareTo(this._numberBigInt) > 0 || BI_MAX_LONG.compareTo(this._numberBigInt) < 0) {
                this.reportOverflowLong();
            }
            this._numberLong = this._numberBigInt.longValue();
        } else if ((this._numTypesValid & 8) != 0) {
            if (this._numberDouble < -9.223372036854776E18 || this._numberDouble > 9.223372036854776E18) {
                this.reportOverflowLong();
            }
            this._numberLong = (long)this._numberDouble;
        } else if ((this._numTypesValid & 16) != 0) {
            if (BD_MIN_LONG.compareTo(this._numberBigDecimal) > 0 || BD_MAX_LONG.compareTo(this._numberBigDecimal) < 0) {
                this.reportOverflowLong();
            }
            this._numberLong = this._numberBigDecimal.longValue();
        } else {
            this._throwInternal();
        }
        this._numTypesValid |= 2;
    }

    @Override
    public JsonLocation getCurrentLocation() {
        int n2 = this._inputPtr;
        int n3 = this._currInputRowStart;
        return new JsonLocation(this._ioContext.getSourceReference(), -1, this._currInputProcessed + (long)this._inputPtr, this._currInputRow, n2 - n3 + 1);
    }

    @Override
    public String getCurrentName() {
        JsonReadContext jsonReadContext;
        if ((this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) && (jsonReadContext = this._parsingContext.getParent()) != null) {
            return jsonReadContext.getCurrentName();
        }
        return this._parsingContext.getCurrentName();
    }

    @Override
    public double getDoubleValue() {
        if ((this._numTypesValid & 8) == 0) {
            if (this._numTypesValid == 0) {
                this._parseNumericValue(8);
            }
            if ((this._numTypesValid & 8) == 0) {
                this.convertNumberToDouble();
            }
        }
        return this._numberDouble;
    }

    @Override
    public long getLongValue() {
        if ((this._numTypesValid & 2) == 0) {
            if (this._numTypesValid == 0) {
                this._parseNumericValue(2);
            }
            if ((this._numTypesValid & 2) == 0) {
                this.convertNumberToLong();
            }
        }
        return this._numberLong;
    }

    protected abstract boolean loadMore();

    protected final void loadMoreGuaranteed() {
        if (!this.loadMore()) {
            this._reportInvalidEOF();
        }
    }

    protected void reportInvalidNumber(String string) {
        this._reportError("Invalid numeric value: " + string);
    }

    protected void reportOverflowLong() {
        this._reportError("Numeric value (" + this.getText() + ") out of range of long (" + Long.MIN_VALUE + " - " + Long.MAX_VALUE + ")");
    }

    protected void reportUnexpectedNumberChar(int n2, String string) {
        String string2;
        String string3 = string2 = "Unexpected character (" + ParserBase._getCharDesc(n2) + ") in numeric value";
        if (string != null) {
            string3 = string2 + ": " + string;
        }
        this._reportError(string3);
    }

    protected final JsonToken reset(boolean bl2, int n2, int n3, int n4) {
        if (n3 < 1 && n4 < 1) {
            return this.resetInt(bl2, n2);
        }
        return this.resetFloat(bl2, n2, n3, n4);
    }

    protected final JsonToken resetAsNaN(String string, double d2) {
        this._textBuffer.resetWithString(string);
        this._numberDouble = d2;
        this._numTypesValid = 8;
        return JsonToken.VALUE_NUMBER_FLOAT;
    }

    protected final JsonToken resetFloat(boolean bl2, int n2, int n3, int n4) {
        this._numberNegative = bl2;
        this._intLength = n2;
        this._fractLength = n3;
        this._expLength = n4;
        this._numTypesValid = 0;
        return JsonToken.VALUE_NUMBER_FLOAT;
    }

    protected final JsonToken resetInt(boolean bl2, int n2) {
        this._numberNegative = bl2;
        this._intLength = n2;
        this._fractLength = 0;
        this._expLength = 0;
        this._numTypesValid = 0;
        return JsonToken.VALUE_NUMBER_INT;
    }
}

