/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.base;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.util.VersionUtil;

public abstract class ParserMinimalBase
extends JsonParser {
    protected JsonToken _currToken;

    protected ParserMinimalBase(int n2) {
        super(n2);
    }

    protected static final String _getCharDesc(int n2) {
        char c2 = (char)n2;
        if (Character.isISOControl(c2)) {
            return "(CTRL-CHAR, code " + n2 + ")";
        }
        if (n2 > 255) {
            return "'" + c2 + "' (code " + n2 + " / 0x" + Integer.toHexString(n2) + ")";
        }
        return "'" + c2 + "' (code " + n2 + ")";
    }

    protected final JsonParseException _constructError(String string, Throwable throwable) {
        return new JsonParseException(this, string, throwable);
    }

    protected abstract void _handleEOF();

    /*
     * Enabled aggressive block sorting
     */
    protected char _handleUnrecognizedCharacterEscape(char c2) {
        if (this.isEnabled(JsonParser.Feature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER) || c2 == '\'' && this.isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
            return c2;
        }
        this._reportError("Unrecognized character escape " + ParserMinimalBase._getCharDesc(c2));
        return c2;
    }

    protected final void _reportError(String string) {
        throw this._constructError(string);
    }

    protected void _reportInvalidEOF() {
        this._reportInvalidEOF(" in " + (Object)((Object)this._currToken));
    }

    protected void _reportInvalidEOF(String string) {
        this._reportError("Unexpected end-of-input" + string);
    }

    protected void _reportInvalidEOFInValue() {
        this._reportInvalidEOF(" in a value");
    }

    protected void _reportMissingRootWS(int n2) {
        this._reportUnexpectedChar(n2, "Expected space separating root-level values");
    }

    protected void _reportUnexpectedChar(int n2, String string) {
        String string2;
        if (n2 < 0) {
            this._reportInvalidEOF();
        }
        String string3 = string2 = "Unexpected character (" + ParserMinimalBase._getCharDesc(n2) + ")";
        if (string != null) {
            string3 = string2 + ": " + string;
        }
        this._reportError(string3);
    }

    protected final void _throwInternal() {
        VersionUtil.throwInternal();
    }

    protected void _throwInvalidSpace(int n2) {
        n2 = (char)n2;
        this._reportError("Illegal character (" + ParserMinimalBase._getCharDesc(n2) + "): only regular white space (\\r, \\n, \\t) is allowed between tokens");
    }

    protected void _throwUnquotedSpace(int n2, String string) {
        if (!this.isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS) || n2 > 32) {
            n2 = (char)n2;
            this._reportError("Illegal unquoted character (" + ParserMinimalBase._getCharDesc(n2) + "): has to be escaped using backslash to be included in " + string);
        }
    }

    protected final void _wrapError(String string, Throwable throwable) {
        throw this._constructError(string, throwable);
    }

    @Override
    public JsonToken getCurrentToken() {
        return this._currToken;
    }

    @Override
    public abstract String getText();

    @Override
    public abstract JsonToken nextToken();

    @Override
    public JsonParser skipChildren() {
        if (this._currToken != JsonToken.START_OBJECT && this._currToken != JsonToken.START_ARRAY) {
            return this;
        }
        int n2 = 1;
        do {
            int n3;
            JsonToken jsonToken;
            if ((jsonToken = this.nextToken()) == null) {
                this._handleEOF();
                return this;
            }
            if (jsonToken.isStructStart()) {
                ++n2;
                continue;
            }
            if (!jsonToken.isStructEnd()) continue;
            n2 = n3 = n2 - 1;
            if (n3 == 0) break;
        } while (true);
        return this;
    }
}

