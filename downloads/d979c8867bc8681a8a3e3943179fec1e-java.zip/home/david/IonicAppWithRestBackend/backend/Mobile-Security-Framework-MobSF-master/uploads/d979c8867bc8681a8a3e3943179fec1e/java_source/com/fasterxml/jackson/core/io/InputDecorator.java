/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.io;

import com.fasterxml.jackson.core.io.IOContext;
import java.io.InputStream;
import java.io.Reader;
import java.io.Serializable;

public abstract class InputDecorator
implements Serializable {
    public abstract InputStream decorate(IOContext var1, InputStream var2);

    public abstract Reader decorate(IOContext var1, Reader var2);
}

