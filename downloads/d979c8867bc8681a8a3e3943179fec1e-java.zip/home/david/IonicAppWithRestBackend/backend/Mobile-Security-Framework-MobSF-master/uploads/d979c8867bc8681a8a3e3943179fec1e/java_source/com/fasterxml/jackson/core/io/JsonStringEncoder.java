/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.io;

import com.fasterxml.jackson.core.io.CharTypes;
import com.fasterxml.jackson.core.io.UTF8Writer;
import com.fasterxml.jackson.core.util.BufferRecycler;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import java.lang.ref.SoftReference;

public final class JsonStringEncoder {
    private static final byte[] HB;
    private static final char[] HC;
    protected static final ThreadLocal<SoftReference<JsonStringEncoder>> _threadEncoder;
    protected ByteArrayBuilder _bytes;
    protected final char[] _qbuf = new char[6];

    static {
        HC = CharTypes.copyHexChars();
        HB = CharTypes.copyHexBytes();
        _threadEncoder = new ThreadLocal();
    }

    public JsonStringEncoder() {
        this._qbuf[0] = 92;
        this._qbuf[2] = 48;
        this._qbuf[3] = 48;
    }

    private static int _convert(int n2, int n3) {
        if (n3 < 56320 || n3 > 57343) {
            throw new IllegalArgumentException("Broken surrogate pair: first char 0x" + Integer.toHexString(n2) + ", second 0x" + Integer.toHexString(n3) + "; illegal combination");
        }
        return 65536 + (n2 - 55296 << 10) + (n3 - 56320);
    }

    private static void _illegal(int n2) {
        throw new IllegalArgumentException(UTF8Writer.illegalSurrogateDesc(n2));
    }

    /*
     * Enabled aggressive block sorting
     */
    public static JsonStringEncoder getInstance() {
        SoftReference<JsonStringEncoder> softReference = _threadEncoder.get();
        softReference = softReference == null ? null : softReference.get();
        Object object = softReference;
        if (softReference == null) {
            object = new JsonStringEncoder();
            _threadEncoder.set(new SoftReference<Object>(object));
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    public byte[] encodeAsUTF8(String string) {
        byte[] arrby;
        byte[] arrby2 = arrby = this._bytes;
        if (arrby == null) {
            this._bytes = arrby2 = new ByteArrayBuilder(null);
        }
        int n2 = string.length();
        arrby = arrby2.resetAndGetFirstSegment();
        int n3 = arrby.length;
        int n4 = 0;
        int n5 = 0;
        while (n5 < n2) {
            int n6 = n5 + 1;
            int n7 = string.charAt(n5);
            int n8 = n3;
            n5 = n6;
            n3 = n7;
            while (n3 <= 127) {
                n6 = n8;
                n7 = n4;
                if (n4 >= n8) {
                    arrby = arrby2.finishCurrentSegment();
                    n6 = arrby.length;
                    n7 = 0;
                }
                n4 = n7 + 1;
                arrby[n7] = (byte)n3;
                if (n5 >= n2) {
                    return this._bytes.completeAndCoalesce(n4);
                }
                n3 = string.charAt(n5);
                ++n5;
                n8 = n6;
            }
            if (n4 >= n8) {
                arrby = arrby2.finishCurrentSegment();
                n4 = arrby.length;
                n8 = 0;
            } else {
                n6 = n4;
                n4 = n8;
                n8 = n6;
            }
            if (n3 < 2048) {
                n6 = n8 + 1;
                arrby[n8] = (byte)(n3 >> 6 | 192);
                n8 = n3;
                n3 = n6;
            } else if (n3 < 55296 || n3 > 57343) {
                n7 = n8 + 1;
                arrby[n8] = (byte)(n3 >> 12 | 224);
                n8 = n4;
                n6 = n7;
                if (n7 >= n4) {
                    arrby = arrby2.finishCurrentSegment();
                    n8 = arrby.length;
                    n6 = 0;
                }
                arrby[n6] = (byte)(n3 >> 6 & 63 | 128);
                n7 = n6 + 1;
                n6 = n3;
                n4 = n8;
                n3 = n7;
                n8 = n6;
            } else {
                if (n3 > 56319) {
                    JsonStringEncoder._illegal(n3);
                }
                if (n5 >= n2) {
                    JsonStringEncoder._illegal(n3);
                }
                if ((n6 = JsonStringEncoder._convert(n3, string.charAt(n5))) > 1114111) {
                    JsonStringEncoder._illegal(n6);
                }
                n7 = n8 + 1;
                arrby[n8] = (byte)(n6 >> 18 | 240);
                n3 = n4;
                n8 = n7;
                if (n7 >= n4) {
                    arrby = arrby2.finishCurrentSegment();
                    n3 = arrby.length;
                    n8 = 0;
                }
                n4 = n8 + 1;
                arrby[n8] = (byte)(n6 >> 12 & 63 | 128);
                if (n4 >= n3) {
                    arrby = arrby2.finishCurrentSegment();
                    n4 = arrby.length;
                    n3 = 0;
                } else {
                    n8 = n4;
                    n4 = n3;
                    n3 = n8;
                }
                arrby[n3] = (byte)(n6 >> 6 & 63 | 128);
                ++n3;
                n8 = n6;
                ++n5;
            }
            n6 = n4;
            n7 = n3;
            if (n3 >= n4) {
                arrby = arrby2.finishCurrentSegment();
                n6 = arrby.length;
                n7 = 0;
            }
            arrby[n7] = (byte)(n8 & 63 | 128);
            n3 = n6;
            n4 = n7 + 1;
        }
        return this._bytes.completeAndCoalesce(n4);
    }
}

