/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.io;

import java.math.BigDecimal;

public final class NumberInput {
    static final String MAX_LONG_STR;
    static final String MIN_LONG_STR_NO_SIGN;

    static {
        MIN_LONG_STR_NO_SIGN = String.valueOf(Long.MIN_VALUE).substring(1);
        MAX_LONG_STR = String.valueOf(Long.MAX_VALUE);
    }

    private static NumberFormatException _badBD(String string) {
        return new NumberFormatException("Value \"" + string + "\" can not be represented as BigDecimal");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean inLongRange(char[] arrc, int n2, int n3, boolean bl2) {
        String string = bl2 ? MIN_LONG_STR_NO_SIGN : MAX_LONG_STR;
        int n4 = string.length();
        if (n3 < n4) {
            return true;
        }
        if (n3 > n4) {
            return false;
        }
        n3 = 0;
        while (n3 < n4) {
            int n5 = arrc[n2 + n3] - string.charAt(n3);
            if (n5 != 0) {
                if (n5 >= 0) return false;
                return true;
            }
            ++n3;
        }
        return true;
    }

    public static BigDecimal parseBigDecimal(char[] arrc) {
        return NumberInput.parseBigDecimal(arrc, 0, arrc.length);
    }

    public static BigDecimal parseBigDecimal(char[] arrc, int n2, int n3) {
        try {
            BigDecimal bigDecimal = new BigDecimal(arrc, n2, n3);
            return bigDecimal;
        }
        catch (NumberFormatException var3_4) {
            throw NumberInput._badBD(new String(arrc, n2, n3));
        }
    }

    public static double parseDouble(String string) {
        if ("2.2250738585072012e-308".equals(string)) {
            return Double.MIN_VALUE;
        }
        return Double.parseDouble(string);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int parseInt(char[] arrc, int n2, int n3) {
        int n4;
        int n5 = n4 = arrc[n2] - 48;
        int n6 = n2;
        int n7 = n3;
        if (n3 > 4) {
            n5 = n2 + 1;
            n2 = arrc[n5];
            n7 = n5 + 1;
            n5 = arrc[n7];
            n6 = n7 + 1;
            n7 = arrc[n6];
            int n8 = n6 + 1;
            n2 = (((n4 * 10 + (n2 - 48)) * 10 + (n5 - 48)) * 10 + (n7 - 48)) * 10 + (arrc[n8] - 48);
            n5 = n2;
            n6 = n8;
            n7 = n3 -= 4;
            if (n3 > 4) {
                n5 = n8 + 1;
                n3 = arrc[n5];
                n7 = n5 + 1;
                n5 = arrc[n7];
                return (((n2 * 10 + (n3 - 48)) * 10 + (n5 - 48)) * 10 + (arrc[n7] - 48)) * 10 + (arrc[++n7 + 1] - 48);
            }
        }
        n2 = n5;
        if (n7 <= 1) return n2;
        n2 = n3 = n5 * 10 + (arrc[++n6] - 48);
        if (n7 <= 2) return n2;
        n5 = n6 + 1;
        n2 = n3 = n3 * 10 + (arrc[n5] - 48);
        if (n7 <= 3) return n2;
        return n3 * 10 + (arrc[n5 + 1] - 48);
    }

    public static long parseLong(char[] arrc, int n2, int n3) {
        long l2 = NumberInput.parseInt(arrc, n2, n3 -= 9);
        return (long)NumberInput.parseInt(arrc, n3 + n2, 9) + l2 * 1000000000;
    }
}

