/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.io;

import com.fasterxml.jackson.core.SerializableString;
import com.fasterxml.jackson.core.io.JsonStringEncoder;
import java.io.Serializable;

public class SerializedString
implements SerializableString,
Serializable {
    protected byte[] _unquotedUTF8Ref;
    protected final String _value;

    public SerializedString(String string) {
        if (string == null) {
            throw new IllegalStateException("Null String illegal for SerializedString");
        }
        this._value = string;
    }

    @Override
    public final byte[] asUnquotedUTF8() {
        byte[] arrby;
        byte[] arrby2 = arrby = this._unquotedUTF8Ref;
        if (arrby == null) {
            this._unquotedUTF8Ref = arrby2 = JsonStringEncoder.getInstance().encodeAsUTF8(this._value);
        }
        return arrby2;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object == null || object.getClass() != this.getClass()) {
            return false;
        }
        object = (SerializedString)object;
        return this._value.equals(object._value);
    }

    @Override
    public final String getValue() {
        return this._value;
    }

    public final int hashCode() {
        return this._value.hashCode();
    }

    public final String toString() {
        return this._value;
    }
}

