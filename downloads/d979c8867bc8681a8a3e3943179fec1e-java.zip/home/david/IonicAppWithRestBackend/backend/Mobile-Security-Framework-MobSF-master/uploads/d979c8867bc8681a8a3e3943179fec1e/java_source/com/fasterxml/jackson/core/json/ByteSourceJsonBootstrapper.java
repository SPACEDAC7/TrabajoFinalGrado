/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.io.MergedStream;
import com.fasterxml.jackson.core.io.UTF32Reader;
import com.fasterxml.jackson.core.json.ReaderBasedJsonParser;
import com.fasterxml.jackson.core.json.UTF8StreamJsonParser;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
import java.io.ByteArrayInputStream;
import java.io.CharConversionException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public final class ByteSourceJsonBootstrapper {
    protected boolean _bigEndian = true;
    private final boolean _bufferRecyclable;
    protected int _bytesPerChar;
    protected final IOContext _context;
    protected final InputStream _in;
    protected final byte[] _inputBuffer;
    private int _inputEnd;
    protected int _inputProcessed;
    private int _inputPtr;

    public ByteSourceJsonBootstrapper(IOContext iOContext, InputStream inputStream) {
        this._context = iOContext;
        this._in = inputStream;
        this._inputBuffer = iOContext.allocReadIOBuffer();
        this._inputPtr = 0;
        this._inputEnd = 0;
        this._inputProcessed = 0;
        this._bufferRecyclable = true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean checkUTF16(int n2) {
        boolean bl2 = false;
        if ((65280 & n2) == 0) {
            this._bigEndian = true;
        } else {
            if ((n2 & 255) != 0) return bl2;
            this._bigEndian = false;
        }
        this._bytesPerChar = 2;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean checkUTF32(int n2) {
        boolean bl2 = false;
        if (n2 >> 8 == 0) {
            this._bigEndian = true;
        } else if ((16777215 & n2) == 0) {
            this._bigEndian = false;
        } else if ((-16711681 & n2) == 0) {
            this.reportWeirdUCS4("3412");
        } else {
            if ((-65281 & n2) != 0) return bl2;
            this.reportWeirdUCS4("2143");
        }
        this._bytesPerChar = 4;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean handleBOM(int n2) {
        switch (n2) {
            case 65279: {
                this._bigEndian = true;
                this._inputPtr += 4;
                this._bytesPerChar = 4;
                return true;
            }
            case -131072: {
                this._inputPtr += 4;
                this._bytesPerChar = 4;
                this._bigEndian = false;
                return true;
            }
            case 65534: {
                this.reportWeirdUCS4("2143");
            }
            case -16842752: {
                this.reportWeirdUCS4("3412");
            }
        }
        int n3 = n2 >>> 16;
        if (n3 == 65279) {
            this._inputPtr += 2;
            this._bytesPerChar = 2;
            this._bigEndian = true;
            return true;
        }
        if (n3 == 65534) {
            this._inputPtr += 2;
            this._bytesPerChar = 2;
            this._bigEndian = false;
            return true;
        }
        if (n2 >>> 8 == 15711167) {
            this._inputPtr += 3;
            this._bytesPerChar = 1;
            this._bigEndian = true;
            return true;
        }
        return false;
    }

    private void reportWeirdUCS4(String string) {
        throw new CharConversionException("Unsupported UCS-4 endianness (" + string + ") detected");
    }

    public JsonParser constructParser(int n2, ObjectCodec objectCodec, ByteQuadsCanonicalizer byteQuadsCanonicalizer, CharsToNameCanonicalizer charsToNameCanonicalizer, int n3) {
        if (this.detectEncoding() == JsonEncoding.UTF8 && JsonFactory.Feature.CANONICALIZE_FIELD_NAMES.enabledIn(n3)) {
            byteQuadsCanonicalizer = byteQuadsCanonicalizer.makeChild(n3);
            return new UTF8StreamJsonParser(this._context, n2, this._in, objectCodec, byteQuadsCanonicalizer, this._inputBuffer, this._inputPtr, this._inputEnd, this._bufferRecyclable);
        }
        return new ReaderBasedJsonParser(this._context, n2, this.constructReader(), objectCodec, charsToNameCanonicalizer.makeChild(n3));
    }

    /*
     * Enabled aggressive block sorting
     */
    public Reader constructReader() {
        JsonEncoding jsonEncoding = this._context.getEncoding();
        switch (jsonEncoding.bits()) {
            default: {
                throw new RuntimeException("Internal error");
            }
            case 8: 
            case 16: {
                InputStream inputStream = this._in;
                if (inputStream == null) {
                    inputStream = new ByteArrayInputStream(this._inputBuffer, this._inputPtr, this._inputEnd);
                    return new InputStreamReader(inputStream, jsonEncoding.getJavaName());
                }
                if (this._inputPtr >= this._inputEnd) return new InputStreamReader(inputStream, jsonEncoding.getJavaName());
                inputStream = new MergedStream(this._context, inputStream, this._inputBuffer, this._inputPtr, this._inputEnd);
                return new InputStreamReader(inputStream, jsonEncoding.getJavaName());
            }
            case 32: 
        }
        return new UTF32Reader(this._context, this._in, this._inputBuffer, this._inputPtr, this._inputEnd, this._context.getEncoding().isBigEndian());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public JsonEncoding detectEncoding() {
        var2_1 = true;
        if (!this.ensureLoaded(4)) ** GOTO lbl12
        var3_2 = this._inputBuffer[this._inputPtr] << 24 | (this._inputBuffer[this._inputPtr + 1] & 255) << 16 | (this._inputBuffer[this._inputPtr + 2] & 255) << 8 | this._inputBuffer[this._inputPtr + 3] & 255;
        if (!this.handleBOM(var3_2)) ** GOTO lbl7
        var1_3 = var2_1;
        ** GOTO lbl16
lbl7: // 1 sources:
        var1_3 = var2_1;
        if (this.checkUTF32(var3_2)) ** GOTO lbl16
        var1_3 = var2_1;
        if (this.checkUTF16(var3_2 >>> 16)) ** GOTO lbl16
        ** GOTO lbl-1000
lbl12: // 1 sources:
        if (this.ensureLoaded(2) && this.checkUTF16((this._inputBuffer[this._inputPtr] & 255) << 8 | this._inputBuffer[this._inputPtr + 1] & 255)) {
            var1_3 = var2_1;
        } else lbl-1000: // 2 sources:
        {
            var1_3 = false;
        }
lbl16: // 5 sources:
        if (!var1_3) {
            var4_4 = JsonEncoding.UTF8;
        } else {
            switch (this._bytesPerChar) {
                default: {
                    throw new RuntimeException("Internal error");
                }
                case 1: {
                    var4_4 = JsonEncoding.UTF8;
                    break;
                }
                case 2: {
                    if (this._bigEndian) {
                        var4_4 = JsonEncoding.UTF16_BE;
                        break;
                    }
                    var4_4 = JsonEncoding.UTF16_LE;
                    break;
                }
                case 4: {
                    var4_4 = this._bigEndian != false ? JsonEncoding.UTF32_BE : JsonEncoding.UTF32_LE;
                }
            }
        }
        this._context.setEncoding(var4_4);
        return var4_4;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected boolean ensureLoaded(int n2) {
        boolean bl2 = true;
        int n3 = this._inputEnd - this._inputPtr;
        do {
            boolean bl3 = bl2;
            if (n3 >= n2) return bl3;
            int n4 = this._in == null ? -1 : this._in.read(this._inputBuffer, this._inputEnd, this._inputBuffer.length - this._inputEnd);
            if (n4 < 1) {
                return false;
            }
            this._inputEnd += n4;
            n3 = n4 + n3;
        } while (true);
    }
}

