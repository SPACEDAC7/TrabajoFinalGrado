/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonStreamContext;
import com.fasterxml.jackson.core.json.DupDetector;

public class JsonWriteContext
extends JsonStreamContext {
    protected JsonWriteContext _child;
    protected String _currentName;
    protected Object _currentValue;
    protected DupDetector _dups;
    protected boolean _gotName;
    protected final JsonWriteContext _parent;

    protected JsonWriteContext(int n2, JsonWriteContext jsonWriteContext, DupDetector dupDetector) {
        this._type = n2;
        this._parent = jsonWriteContext;
        this._dups = dupDetector;
        this._index = -1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final void _checkDup(DupDetector object, String string) {
        if (!object.isDup(string)) return;
        object = object.getSource();
        string = "Duplicate field '" + string + "'";
        if (object instanceof JsonGenerator) {
            object = (JsonGenerator)object;
            do {
                throw new JsonGenerationException(string, (JsonGenerator)object);
                break;
            } while (true);
        }
        object = null;
        throw new JsonGenerationException(string, (JsonGenerator)object);
    }

    public static JsonWriteContext createRootContext(DupDetector dupDetector) {
        return new JsonWriteContext(0, null, dupDetector);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void appendDesc(StringBuilder stringBuilder) {
        if (this._type == 2) {
            stringBuilder.append('{');
            if (this._currentName != null) {
                stringBuilder.append('\"');
                stringBuilder.append(this._currentName);
                stringBuilder.append('\"');
            } else {
                stringBuilder.append('?');
            }
            stringBuilder.append('}');
            return;
        }
        if (this._type == 1) {
            stringBuilder.append('[');
            stringBuilder.append(this.getCurrentIndex());
            stringBuilder.append(']');
            return;
        }
        stringBuilder.append("/");
    }

    public JsonWriteContext clearAndGetParent() {
        this._currentValue = null;
        return this._parent;
    }

    /*
     * Enabled aggressive block sorting
     */
    public JsonWriteContext createChildArrayContext() {
        Object object = this._child;
        if (object != null) {
            return object.reset(1);
        }
        object = this._dups == null ? null : this._dups.child();
        this._child = object = new JsonWriteContext(1, this, (DupDetector)object);
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    public JsonWriteContext createChildObjectContext() {
        Object object = this._child;
        if (object != null) {
            return object.reset(2);
        }
        object = this._dups == null ? null : this._dups.child();
        this._child = object = new JsonWriteContext(2, this, (DupDetector)object);
        return object;
    }

    protected JsonWriteContext reset(int n2) {
        this._type = n2;
        this._index = -1;
        this._currentName = null;
        this._gotName = false;
        this._currentValue = null;
        if (this._dups != null) {
            this._dups.reset();
        }
        return this;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(64);
        this.appendDesc(stringBuilder);
        return stringBuilder.toString();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public int writeFieldName(String string) {
        int n2 = 1;
        if (this._gotName) {
            return 4;
        }
        this._gotName = true;
        this._currentName = string;
        if (this._dups != null) {
            this._checkDup(this._dups, string);
        }
        if (this._index >= 0) return n2;
        return 0;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public int writeValue() {
        int n2 = 0;
        if (this._type == 2) {
            if (!this._gotName) {
                return 5;
            }
            this._gotName = false;
            ++this._index;
            return 2;
        }
        if (this._type == 1) {
            int n3;
            if ((n3 = this._index++) < 0) return n2;
            return 1;
        }
        ++this._index;
        if (this._index == 0) return n2;
        return 3;
    }
}

