/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.PrettyPrinter;
import com.fasterxml.jackson.core.SerializableString;
import com.fasterxml.jackson.core.io.CharTypes;
import com.fasterxml.jackson.core.io.CharacterEscapes;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.io.NumberOutput;
import com.fasterxml.jackson.core.json.JsonGeneratorImpl;
import com.fasterxml.jackson.core.json.JsonWriteContext;
import java.io.OutputStream;

public class UTF8JsonGenerator
extends JsonGeneratorImpl {
    private static final byte[] FALSE_BYTES;
    private static final byte[] HEX_CHARS;
    private static final byte[] NULL_BYTES;
    private static final byte[] TRUE_BYTES;
    protected boolean _bufferRecyclable;
    protected char[] _charBuffer;
    protected final int _charBufferLength;
    protected byte[] _outputBuffer;
    protected final int _outputEnd;
    protected final int _outputMaxContiguous;
    protected final OutputStream _outputStream;
    protected int _outputTail;

    static {
        HEX_CHARS = CharTypes.copyHexBytes();
        NULL_BYTES = new byte[]{110, 117, 108, 108};
        TRUE_BYTES = new byte[]{116, 114, 117, 101};
        FALSE_BYTES = new byte[]{102, 97, 108, 115, 101};
    }

    public UTF8JsonGenerator(IOContext iOContext, int n2, ObjectCodec objectCodec, OutputStream outputStream) {
        super(iOContext, n2, objectCodec);
        this._outputStream = outputStream;
        this._bufferRecyclable = true;
        this._outputBuffer = iOContext.allocWriteEncodingBuffer();
        this._outputEnd = this._outputBuffer.length;
        this._outputMaxContiguous = this._outputEnd >> 3;
        this._charBuffer = iOContext.allocConcatBuffer();
        this._charBufferLength = this._charBuffer.length;
        if (this.isEnabled(JsonGenerator.Feature.ESCAPE_NON_ASCII)) {
            this.setHighestNonEscapedChar(127);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private final int _handleLongCustomEscape(byte[] arrby, int n2, int n3, byte[] arrby2, int n4) {
        int n5;
        int n6 = arrby2.length;
        if (n2 + n6 > n3) {
            this._outputTail = n2;
            this._flushBuffer();
            n5 = this._outputTail;
            if (n6 > arrby.length) {
                this._outputStream.write(arrby2, 0, n6);
                return n5;
            }
            System.arraycopy(arrby2, 0, arrby, n5, n6);
            n2 = n5 + n6;
        }
        n5 = n2;
        if (n4 * 6 + n2 <= n3) return n5;
        this._flushBuffer();
        return this._outputTail;
    }

    private final int _outputMultiByteChar(int n2, int n3) {
        byte[] arrby = this._outputBuffer;
        if (n2 >= 55296 && n2 <= 57343) {
            int n4 = n3 + 1;
            arrby[n3] = 92;
            n3 = n4 + 1;
            arrby[n4] = 117;
            n4 = n3 + 1;
            arrby[n3] = HEX_CHARS[n2 >> 12 & 15];
            n3 = n4 + 1;
            arrby[n4] = HEX_CHARS[n2 >> 8 & 15];
            n4 = n3 + 1;
            arrby[n3] = HEX_CHARS[n2 >> 4 & 15];
            arrby[n4] = HEX_CHARS[n2 & 15];
            return n4 + 1;
        }
        int n5 = n3 + 1;
        arrby[n3] = (byte)(n2 >> 12 | 224);
        n3 = n5 + 1;
        arrby[n5] = (byte)(n2 >> 6 & 63 | 128);
        arrby[n3] = (byte)(n2 & 63 | 128);
        return n3 + 1;
    }

    private final int _outputRawMultiByteChar(int n2, char[] arrc, int n3, int n4) {
        if (n2 >= 55296 && n2 <= 57343) {
            if (n3 >= n4 || arrc == null) {
                this._reportError("Split surrogate on writeRaw() input (last character)");
            }
            this._outputSurrogates(n2, arrc[n3]);
            return n3 + 1;
        }
        arrc = this._outputBuffer;
        n4 = this._outputTail;
        this._outputTail = n4 + 1;
        arrc[n4] = (char)(n2 >> 12 | 224);
        n4 = this._outputTail;
        this._outputTail = n4 + 1;
        arrc[n4] = (char)(n2 >> 6 & 63 | 128);
        n4 = this._outputTail;
        this._outputTail = n4 + 1;
        arrc[n4] = (char)(n2 & 63 | 128);
        return n3;
    }

    private final void _writeBytes(byte[] arrby) {
        int n2 = arrby.length;
        if (this._outputTail + n2 > this._outputEnd) {
            this._flushBuffer();
            if (n2 > 512) {
                this._outputStream.write(arrby, 0, n2);
                return;
            }
        }
        System.arraycopy(arrby, 0, this._outputBuffer, this._outputTail, n2);
        this._outputTail = n2 + this._outputTail;
    }

    private final int _writeCustomEscape(byte[] arrby, int n2, SerializableString arrby2, int n3) {
        int n4 = (arrby2 = arrby2.asUnquotedUTF8()).length;
        if (n4 > 6) {
            return this._handleLongCustomEscape(arrby, n2, this._outputEnd, arrby2, n3);
        }
        System.arraycopy(arrby2, 0, arrby, n2, n4);
        return n4 + n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void _writeCustomStringSegment2(String string, int n2, int n3) {
        if (this._outputTail + (n3 - n2) * 6 > this._outputEnd) {
            this._flushBuffer();
        }
        int n4 = this._outputTail;
        byte[] arrby = this._outputBuffer;
        int[] arrn = this._outputEscapes;
        int n5 = this._maximumNonEscapedChar <= 0 ? 65535 : this._maximumNonEscapedChar;
        CharacterEscapes characterEscapes = this._characterEscapes;
        int n6 = n2;
        n2 = n4;
        do {
            int n7;
            SerializableString serializableString;
            if (n6 >= n3) {
                this._outputTail = n2;
                return;
            }
            n4 = n6 + 1;
            if ((n6 = (int)string.charAt(n6)) <= 127) {
                if (arrn[n6] == 0) {
                    arrby[n2] = (byte)n6;
                    ++n2;
                    n6 = n4;
                    continue;
                }
                n7 = arrn[n6];
                if (n7 > 0) {
                    n6 = n2 + 1;
                    arrby[n2] = 92;
                    n2 = n6 + 1;
                    arrby[n6] = (byte)n7;
                    n6 = n4;
                    continue;
                }
                if (n7 == -2) {
                    serializableString = characterEscapes.getEscapeSequence(n6);
                    if (serializableString == null) {
                        this._reportError("Invalid custom escape definitions; custom escape not found for character code 0x" + Integer.toHexString(n6) + ", although was supposed to have one");
                    }
                    n2 = this._writeCustomEscape(arrby, n2, serializableString, n3 - n4);
                    n6 = n4;
                    continue;
                }
                n2 = this._writeGenericEscape(n6, n2);
                n6 = n4;
                continue;
            }
            if (n6 > n5) {
                n2 = this._writeGenericEscape(n6, n2);
                n6 = n4;
                continue;
            }
            serializableString = characterEscapes.getEscapeSequence(n6);
            if (serializableString != null) {
                n2 = this._writeCustomEscape(arrby, n2, serializableString, n3 - n4);
                n6 = n4;
                continue;
            }
            if (n6 <= 2047) {
                n7 = n2 + 1;
                arrby[n2] = (byte)(n6 >> 6 | 192);
                n2 = n7 + 1;
                arrby[n7] = (byte)(n6 & 63 | 128);
            } else {
                n2 = this._outputMultiByteChar(n6, n2);
            }
            n6 = n4;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void _writeCustomStringSegment2(char[] arrc, int n2, int n3) {
        if (this._outputTail + (n3 - n2) * 6 > this._outputEnd) {
            this._flushBuffer();
        }
        int n4 = this._outputTail;
        byte[] arrby = this._outputBuffer;
        int[] arrn = this._outputEscapes;
        int n5 = this._maximumNonEscapedChar <= 0 ? 65535 : this._maximumNonEscapedChar;
        CharacterEscapes characterEscapes = this._characterEscapes;
        int n6 = n2;
        n2 = n4;
        do {
            int n7;
            SerializableString serializableString;
            if (n6 >= n3) {
                this._outputTail = n2;
                return;
            }
            n4 = n6 + 1;
            if ((n6 = arrc[n6]) <= 127) {
                if (arrn[n6] == 0) {
                    arrby[n2] = (byte)n6;
                    ++n2;
                    n6 = n4;
                    continue;
                }
                n7 = arrn[n6];
                if (n7 > 0) {
                    n6 = n2 + 1;
                    arrby[n2] = 92;
                    n2 = n6 + 1;
                    arrby[n6] = (byte)n7;
                    n6 = n4;
                    continue;
                }
                if (n7 == -2) {
                    serializableString = characterEscapes.getEscapeSequence(n6);
                    if (serializableString == null) {
                        this._reportError("Invalid custom escape definitions; custom escape not found for character code 0x" + Integer.toHexString(n6) + ", although was supposed to have one");
                    }
                    n2 = this._writeCustomEscape(arrby, n2, serializableString, n3 - n4);
                    n6 = n4;
                    continue;
                }
                n2 = this._writeGenericEscape(n6, n2);
                n6 = n4;
                continue;
            }
            if (n6 > n5) {
                n2 = this._writeGenericEscape(n6, n2);
                n6 = n4;
                continue;
            }
            serializableString = characterEscapes.getEscapeSequence(n6);
            if (serializableString != null) {
                n2 = this._writeCustomEscape(arrby, n2, serializableString, n3 - n4);
                n6 = n4;
                continue;
            }
            if (n6 <= 2047) {
                n7 = n2 + 1;
                arrby[n2] = (byte)(n6 >> 6 | 192);
                n2 = n7 + 1;
                arrby[n7] = (byte)(n6 & 63 | 128);
            } else {
                n2 = this._outputMultiByteChar(n6, n2);
            }
            n6 = n4;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private int _writeGenericEscape(int n2, int n3) {
        byte[] arrby = this._outputBuffer;
        int n4 = n3 + 1;
        arrby[n3] = 92;
        n3 = n4 + 1;
        arrby[n4] = 117;
        if (n2 > 255) {
            n4 = n2 >> 8 & 255;
            int n5 = n3 + 1;
            arrby[n3] = HEX_CHARS[n4 >> 4];
            n3 = n5 + 1;
            arrby[n5] = HEX_CHARS[n4 & 15];
            n2 &= 255;
        } else {
            n4 = n3 + 1;
            arrby[n3] = 48;
            n3 = n4 + 1;
            arrby[n4] = 48;
        }
        n4 = n3 + 1;
        arrby[n3] = HEX_CHARS[n2 >> 4];
        arrby[n4] = HEX_CHARS[n2 & 15];
        return n4 + 1;
    }

    private final void _writeNull() {
        if (this._outputTail + 4 >= this._outputEnd) {
            this._flushBuffer();
        }
        System.arraycopy(NULL_BYTES, 0, this._outputBuffer, this._outputTail, 4);
        this._outputTail += 4;
    }

    private final void _writeQuotedLong(long l2) {
        if (this._outputTail + 23 >= this._outputEnd) {
            this._flushBuffer();
        }
        byte[] arrby = this._outputBuffer;
        int n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrby[n2] = 34;
        this._outputTail = NumberOutput.outputLong(l2, this._outputBuffer, this._outputTail);
        arrby = this._outputBuffer;
        n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrby[n2] = 34;
    }

    private final void _writeSegmentedRaw(char[] arrc, int n2, int n3) {
        int n4 = this._outputEnd;
        byte[] arrby = this._outputBuffer;
        block0 : do {
            int n5;
            block7 : {
                if (n2 < n3) {
                    do {
                        int n6;
                        if ((n5 = arrc[n2]) >= 128) {
                            if (this._outputTail + 3 >= this._outputEnd) {
                                this._flushBuffer();
                            }
                            n5 = n2 + 1;
                            if ((n2 = arrc[n2]) < 2048) {
                                n6 = this._outputTail;
                                this._outputTail = n6 + 1;
                                arrby[n6] = (byte)(n2 >> 6 | 192);
                                n6 = this._outputTail;
                                this._outputTail = n6 + 1;
                                arrby[n6] = (byte)(n2 & 63 | 128);
                                n2 = n5;
                                continue block0;
                            }
                            break block7;
                        }
                        if (this._outputTail >= n4) {
                            this._flushBuffer();
                        }
                        n6 = this._outputTail;
                        this._outputTail = n6 + 1;
                        arrby[n6] = (byte)n5;
                        n2 = n5 = n2 + 1;
                    } while (n5 < n3);
                }
                return;
            }
            n2 = this._outputRawMultiByteChar(n2, arrc, n5, n3);
        } while (true);
    }

    private final void _writeStringSegment(String string, int n2, int n3) {
        int n4 = n3 + n2;
        int n5 = this._outputTail;
        byte[] arrby = this._outputBuffer;
        int[] arrn = this._outputEscapes;
        n3 = n2;
        n2 = n5;
        do {
            if (n3 >= n4 || (n5 = (int)string.charAt(n3)) > 127 || arrn[n5] != 0) {
                this._outputTail = n2;
                if (n3 < n4) {
                    if (this._characterEscapes == null) break;
                    this._writeCustomStringSegment2(string, n3, n4);
                }
                return;
            }
            arrby[n2] = (byte)n5;
            ++n3;
            ++n2;
        } while (true);
        if (this._maximumNonEscapedChar == 0) {
            this._writeStringSegment2(string, n3, n4);
            return;
        }
        this._writeStringSegmentASCII2(string, n3, n4);
    }

    private final void _writeStringSegment(char[] arrc, int n2, int n3) {
        int n4 = n3 + n2;
        int n5 = this._outputTail;
        byte[] arrby = this._outputBuffer;
        int[] arrn = this._outputEscapes;
        n3 = n2;
        n2 = n5;
        do {
            if (n3 >= n4 || (n5 = arrc[n3]) > 127 || arrn[n5] != 0) {
                this._outputTail = n2;
                if (n3 < n4) {
                    if (this._characterEscapes == null) break;
                    this._writeCustomStringSegment2(arrc, n3, n4);
                }
                return;
            }
            arrby[n2] = (byte)n5;
            ++n3;
            ++n2;
        } while (true);
        if (this._maximumNonEscapedChar == 0) {
            this._writeStringSegment2(arrc, n3, n4);
            return;
        }
        this._writeStringSegmentASCII2(arrc, n3, n4);
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void _writeStringSegment2(String string, int n2, int n3) {
        if (this._outputTail + (n3 - n2) * 6 > this._outputEnd) {
            this._flushBuffer();
        }
        int n4 = this._outputTail;
        byte[] arrby = this._outputBuffer;
        int[] arrn = this._outputEscapes;
        int n5 = n2;
        n2 = n4;
        do {
            int n6;
            if (n5 >= n3) {
                this._outputTail = n2;
                return;
            }
            n4 = n5 + 1;
            if ((n5 = (int)string.charAt(n5)) <= 127) {
                if (arrn[n5] == 0) {
                    arrby[n2] = (byte)n5;
                    ++n2;
                    n5 = n4;
                    continue;
                }
                n6 = arrn[n5];
                if (n6 > 0) {
                    n5 = n2 + 1;
                    arrby[n2] = 92;
                    n2 = n5 + 1;
                    arrby[n5] = (byte)n6;
                    n5 = n4;
                    continue;
                }
                n2 = this._writeGenericEscape(n5, n2);
                n5 = n4;
                continue;
            }
            if (n5 <= 2047) {
                n6 = n2 + 1;
                arrby[n2] = (byte)(n5 >> 6 | 192);
                n2 = n6 + 1;
                arrby[n6] = (byte)(n5 & 63 | 128);
            } else {
                n2 = this._outputMultiByteChar(n5, n2);
            }
            n5 = n4;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void _writeStringSegment2(char[] arrc, int n2, int n3) {
        if (this._outputTail + (n3 - n2) * 6 > this._outputEnd) {
            this._flushBuffer();
        }
        int n4 = this._outputTail;
        byte[] arrby = this._outputBuffer;
        int[] arrn = this._outputEscapes;
        int n5 = n2;
        n2 = n4;
        do {
            int n6;
            if (n5 >= n3) {
                this._outputTail = n2;
                return;
            }
            n4 = n5 + 1;
            if ((n5 = arrc[n5]) <= 127) {
                if (arrn[n5] == 0) {
                    arrby[n2] = (byte)n5;
                    ++n2;
                    n5 = n4;
                    continue;
                }
                n6 = arrn[n5];
                if (n6 > 0) {
                    n5 = n2 + 1;
                    arrby[n2] = 92;
                    n2 = n5 + 1;
                    arrby[n5] = (byte)n6;
                    n5 = n4;
                    continue;
                }
                n2 = this._writeGenericEscape(n5, n2);
                n5 = n4;
                continue;
            }
            if (n5 <= 2047) {
                n6 = n2 + 1;
                arrby[n2] = (byte)(n5 >> 6 | 192);
                n2 = n6 + 1;
                arrby[n6] = (byte)(n5 & 63 | 128);
            } else {
                n2 = this._outputMultiByteChar(n5, n2);
            }
            n5 = n4;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void _writeStringSegmentASCII2(String string, int n2, int n3) {
        if (this._outputTail + (n3 - n2) * 6 > this._outputEnd) {
            this._flushBuffer();
        }
        int n4 = this._outputTail;
        byte[] arrby = this._outputBuffer;
        int[] arrn = this._outputEscapes;
        int n5 = this._maximumNonEscapedChar;
        int n6 = n2;
        n2 = n4;
        do {
            int n7;
            if (n6 >= n3) {
                this._outputTail = n2;
                return;
            }
            n4 = n6 + 1;
            if ((n6 = (int)string.charAt(n6)) <= 127) {
                if (arrn[n6] == 0) {
                    arrby[n2] = (byte)n6;
                    ++n2;
                    n6 = n4;
                    continue;
                }
                n7 = arrn[n6];
                if (n7 > 0) {
                    n6 = n2 + 1;
                    arrby[n2] = 92;
                    n2 = n6 + 1;
                    arrby[n6] = (byte)n7;
                    n6 = n4;
                    continue;
                }
                n2 = this._writeGenericEscape(n6, n2);
                n6 = n4;
                continue;
            }
            if (n6 > n5) {
                n2 = this._writeGenericEscape(n6, n2);
                n6 = n4;
                continue;
            }
            if (n6 <= 2047) {
                n7 = n2 + 1;
                arrby[n2] = (byte)(n6 >> 6 | 192);
                n2 = n7 + 1;
                arrby[n7] = (byte)(n6 & 63 | 128);
            } else {
                n2 = this._outputMultiByteChar(n6, n2);
            }
            n6 = n4;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void _writeStringSegmentASCII2(char[] arrc, int n2, int n3) {
        if (this._outputTail + (n3 - n2) * 6 > this._outputEnd) {
            this._flushBuffer();
        }
        int n4 = this._outputTail;
        byte[] arrby = this._outputBuffer;
        int[] arrn = this._outputEscapes;
        int n5 = this._maximumNonEscapedChar;
        int n6 = n2;
        n2 = n4;
        do {
            int n7;
            if (n6 >= n3) {
                this._outputTail = n2;
                return;
            }
            n4 = n6 + 1;
            if ((n6 = arrc[n6]) <= 127) {
                if (arrn[n6] == 0) {
                    arrby[n2] = (byte)n6;
                    ++n2;
                    n6 = n4;
                    continue;
                }
                n7 = arrn[n6];
                if (n7 > 0) {
                    n6 = n2 + 1;
                    arrby[n2] = 92;
                    n2 = n6 + 1;
                    arrby[n6] = (byte)n7;
                    n6 = n4;
                    continue;
                }
                n2 = this._writeGenericEscape(n6, n2);
                n6 = n4;
                continue;
            }
            if (n6 > n5) {
                n2 = this._writeGenericEscape(n6, n2);
                n6 = n4;
                continue;
            }
            if (n6 <= 2047) {
                n7 = n2 + 1;
                arrby[n2] = (byte)(n6 >> 6 | 192);
                n2 = n7 + 1;
                arrby[n7] = (byte)(n6 & 63 | 128);
            } else {
                n2 = this._outputMultiByteChar(n6, n2);
            }
            n6 = n4;
        } while (true);
    }

    private final void _writeStringSegments(String string, int n2, int n3) {
        int n4;
        do {
            if (this._outputTail + (n4 = Math.min(this._outputMaxContiguous, n3)) > this._outputEnd) {
                this._flushBuffer();
            }
            this._writeStringSegment(string, n2, n4);
            n2 += n4;
            n3 = n4 = n3 - n4;
        } while (n4 > 0);
    }

    private final void _writeStringSegments(String arrby, boolean bl2) {
        int n2;
        int n3;
        if (bl2) {
            if (this._outputTail >= this._outputEnd) {
                this._flushBuffer();
            }
            byte[] arrby2 = this._outputBuffer;
            n3 = this._outputTail;
            this._outputTail = n3 + 1;
            arrby2[n3] = 34;
        }
        int n4 = 0;
        for (n3 = arrby.length(); n3 > 0; n3 -= n2) {
            n2 = Math.min(this._outputMaxContiguous, n3);
            if (this._outputTail + n2 > this._outputEnd) {
                this._flushBuffer();
            }
            this._writeStringSegment((String)arrby, n4, n2);
            n4 += n2;
        }
        if (bl2) {
            if (this._outputTail >= this._outputEnd) {
                this._flushBuffer();
            }
            arrby = this._outputBuffer;
            n3 = this._outputTail;
            this._outputTail = n3 + 1;
            arrby[n3] = 34;
        }
    }

    private final void _writeStringSegments(char[] arrc, int n2, int n3) {
        int n4;
        do {
            if (this._outputTail + (n4 = Math.min(this._outputMaxContiguous, n3)) > this._outputEnd) {
                this._flushBuffer();
            }
            this._writeStringSegment(arrc, n2, n4);
            n2 += n4;
            n3 = n4 = n3 - n4;
        } while (n4 > 0);
    }

    protected final void _flushBuffer() {
        int n2 = this._outputTail;
        if (n2 > 0) {
            this._outputTail = 0;
            this._outputStream.write(this._outputBuffer, 0, n2);
        }
    }

    protected final void _outputSurrogates(int n2, int n3) {
        n2 = this._decodeSurrogate(n2, n3);
        if (this._outputTail + 4 > this._outputEnd) {
            this._flushBuffer();
        }
        byte[] arrby = this._outputBuffer;
        n3 = this._outputTail;
        this._outputTail = n3 + 1;
        arrby[n3] = (byte)(n2 >> 18 | 240);
        n3 = this._outputTail;
        this._outputTail = n3 + 1;
        arrby[n3] = (byte)(n2 >> 12 & 63 | 128);
        n3 = this._outputTail;
        this._outputTail = n3 + 1;
        arrby[n3] = (byte)(n2 >> 6 & 63 | 128);
        n3 = this._outputTail;
        this._outputTail = n3 + 1;
        arrby[n3] = (byte)(n2 & 63 | 128);
    }

    @Override
    protected void _releaseBuffers() {
        byte[] arrby = this._outputBuffer;
        if (arrby != null && this._bufferRecyclable) {
            this._outputBuffer = null;
            this._ioContext.releaseWriteEncodingBuffer(arrby);
        }
        if ((arrby = this._charBuffer) != null) {
            this._charBuffer = null;
            this._ioContext.releaseConcatBuffer((char[])arrby);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void _verifyPrettyValueWrite(String string, int n2) {
        switch (n2) {
            default: {
                this._throwInternal();
                return;
            }
            case 1: {
                this._cfgPrettyPrinter.writeArrayValueSeparator(this);
                return;
            }
            case 2: {
                this._cfgPrettyPrinter.writeObjectFieldValueSeparator(this);
                return;
            }
            case 3: {
                this._cfgPrettyPrinter.writeRootValueSeparator(this);
                return;
            }
            case 0: {
                if (this._writeContext.inArray()) {
                    this._cfgPrettyPrinter.beforeArrayValues(this);
                    return;
                }
                if (!this._writeContext.inObject()) return;
                this._cfgPrettyPrinter.beforeObjectEntries(this);
                return;
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final void _verifyValueWrite(String var1_1) {
        var3_2 = this._writeContext.writeValue();
        if (var3_2 == 5) {
            this._reportError("Can not " + (String)var1_1 + ", expecting field name");
        }
        if (this._cfgPrettyPrinter != null) {
            this._verifyPrettyValueWrite((String)var1_1, var3_2);
            return;
        }
        switch (var3_2) {
            default: {
                return;
            }
            case 1: {
                var2_3 = 44;
                ** GOTO lbl15
            }
            case 2: {
                var2_3 = 58;
lbl15: // 2 sources:
                if (this._outputTail >= this._outputEnd) {
                    this._flushBuffer();
                }
                this._outputBuffer[this._outputTail] = var2_3;
                ++this._outputTail;
                return;
            }
            case 3: 
        }
        if (this._rootValueSeparator == null) return;
        var1_1 = this._rootValueSeparator.asUnquotedUTF8();
        if (var1_1.length <= 0) return;
        this._writeBytes(var1_1);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void _writePPFieldName(String arrby) {
        int n2 = this._writeContext.writeFieldName((String)arrby);
        if (n2 == 4) {
            this._reportError("Can not write a field name, expecting a value");
        }
        if (n2 == 1) {
            this._cfgPrettyPrinter.writeObjectEntrySeparator(this);
        } else {
            this._cfgPrettyPrinter.beforeObjectEntries(this);
        }
        if (this._cfgUnqNames) {
            this._writeStringSegments((String)arrby, false);
            return;
        }
        n2 = arrby.length();
        if (n2 > this._charBufferLength) {
            this._writeStringSegments((String)arrby, true);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        byte[] arrby2 = this._outputBuffer;
        int n3 = this._outputTail;
        this._outputTail = n3 + 1;
        arrby2[n3] = 34;
        arrby.getChars(0, n2, this._charBuffer, 0);
        if (n2 <= this._outputMaxContiguous) {
            if (this._outputTail + n2 > this._outputEnd) {
                this._flushBuffer();
            }
            this._writeStringSegment(this._charBuffer, 0, n2);
        } else {
            this._writeStringSegments(this._charBuffer, 0, n2);
        }
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        arrby = this._outputBuffer;
        n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrby[n2] = 34;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void close() {
        super.close();
        if (this._outputBuffer != null && this.isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT)) {
            do {
                JsonWriteContext jsonWriteContext;
                if ((jsonWriteContext = this.getOutputContext()).inArray()) {
                    this.writeEndArray();
                    continue;
                }
                if (!jsonWriteContext.inObject()) break;
                this.writeEndObject();
            } while (true);
        }
        this._flushBuffer();
        this._outputTail = 0;
        if (this._outputStream != null) {
            if (this._ioContext.isResourceManaged() || this.isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET)) {
                this._outputStream.close();
            } else if (this.isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
                this._outputStream.flush();
            }
        }
        this._releaseBuffers();
    }

    @Override
    public void flush() {
        this._flushBuffer();
        if (this._outputStream != null && this.isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
            this._outputStream.flush();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void writeBoolean(boolean bl2) {
        this._verifyValueWrite("write a boolean value");
        if (this._outputTail + 5 >= this._outputEnd) {
            this._flushBuffer();
        }
        byte[] arrby = bl2 ? TRUE_BYTES : FALSE_BYTES;
        int n2 = arrby.length;
        System.arraycopy(arrby, 0, this._outputBuffer, this._outputTail, n2);
        this._outputTail += n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void writeEndArray() {
        if (!this._writeContext.inArray()) {
            this._reportError("Current context not an ARRAY but " + this._writeContext.getTypeDesc());
        }
        if (this._cfgPrettyPrinter != null) {
            this._cfgPrettyPrinter.writeEndArray(this, this._writeContext.getEntryCount());
        } else {
            if (this._outputTail >= this._outputEnd) {
                this._flushBuffer();
            }
            byte[] arrby = this._outputBuffer;
            int n2 = this._outputTail;
            this._outputTail = n2 + 1;
            arrby[n2] = 93;
        }
        this._writeContext = this._writeContext.clearAndGetParent();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void writeEndObject() {
        if (!this._writeContext.inObject()) {
            this._reportError("Current context not an object but " + this._writeContext.getTypeDesc());
        }
        if (this._cfgPrettyPrinter != null) {
            this._cfgPrettyPrinter.writeEndObject(this, this._writeContext.getEntryCount());
        } else {
            if (this._outputTail >= this._outputEnd) {
                this._flushBuffer();
            }
            byte[] arrby = this._outputBuffer;
            int n2 = this._outputTail;
            this._outputTail = n2 + 1;
            arrby[n2] = 125;
        }
        this._writeContext = this._writeContext.clearAndGetParent();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void writeFieldName(String arrby) {
        byte[] arrby2;
        if (this._cfgPrettyPrinter != null) {
            this._writePPFieldName((String)arrby);
            return;
        }
        int n2 = this._writeContext.writeFieldName((String)arrby);
        if (n2 == 4) {
            this._reportError("Can not write a field name, expecting a value");
        }
        if (n2 == 1) {
            if (this._outputTail >= this._outputEnd) {
                this._flushBuffer();
            }
            arrby2 = this._outputBuffer;
            n2 = this._outputTail;
            this._outputTail = n2 + 1;
            arrby2[n2] = 44;
        }
        if (this._cfgUnqNames) {
            this._writeStringSegments((String)arrby, false);
            return;
        }
        n2 = arrby.length();
        if (n2 > this._charBufferLength) {
            this._writeStringSegments((String)arrby, true);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        arrby2 = this._outputBuffer;
        int n3 = this._outputTail;
        this._outputTail = n3 + 1;
        arrby2[n3] = 34;
        if (n2 <= this._outputMaxContiguous) {
            if (this._outputTail + n2 > this._outputEnd) {
                this._flushBuffer();
            }
            this._writeStringSegment((String)arrby, 0, n2);
        } else {
            this._writeStringSegments((String)arrby, 0, n2);
        }
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        arrby = this._outputBuffer;
        n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrby[n2] = 34;
    }

    @Override
    public void writeNull() {
        this._verifyValueWrite("write a null");
        this._writeNull();
    }

    @Override
    public void writeNumber(double d2) {
        if (this._cfgNumbersAsStrings || (Double.isNaN(d2) || Double.isInfinite(d2)) && JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS.enabledIn(this._features)) {
            this.writeString(String.valueOf(d2));
            return;
        }
        this._verifyValueWrite("write a number");
        this.writeRaw(String.valueOf(d2));
    }

    @Override
    public void writeNumber(long l2) {
        this._verifyValueWrite("write a number");
        if (this._cfgNumbersAsStrings) {
            this._writeQuotedLong(l2);
            return;
        }
        if (this._outputTail + 21 >= this._outputEnd) {
            this._flushBuffer();
        }
        this._outputTail = NumberOutput.outputLong(l2, this._outputBuffer, this._outputTail);
    }

    @Override
    public void writeRaw(char c2) {
        if (this._outputTail + 3 >= this._outputEnd) {
            this._flushBuffer();
        }
        byte[] arrby = this._outputBuffer;
        if (c2 <= '') {
            int n2 = this._outputTail;
            this._outputTail = n2 + 1;
            arrby[n2] = (byte)c2;
            return;
        }
        if (c2 < '\u0800') {
            int n3 = this._outputTail;
            this._outputTail = n3 + 1;
            arrby[n3] = (byte)(c2 >> 6 | 192);
            n3 = this._outputTail;
            this._outputTail = n3 + 1;
            arrby[n3] = (byte)(c2 & 63 | 128);
            return;
        }
        this._outputRawMultiByteChar(c2, null, 0, 0);
    }

    @Override
    public void writeRaw(SerializableString arrby) {
        if ((arrby = arrby.asUnquotedUTF8()).length > 0) {
            this._writeBytes(arrby);
        }
    }

    @Override
    public void writeRaw(String string) {
        int n2;
        int n3 = 0;
        for (int i2 = string.length(); i2 > 0; i2 -= n2) {
            int n4;
            char[] arrc = this._charBuffer;
            n2 = n4 = arrc.length;
            if (i2 < n4) {
                n2 = i2;
            }
            string.getChars(n3, n3 + n2, arrc, 0);
            this.writeRaw(arrc, 0, n2);
            n3 += n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void writeRaw(char[] arrc, int n2, int n3) {
        int n4 = n3 + n3 + n3;
        if (this._outputTail + n4 > this._outputEnd) {
            if (this._outputEnd < n4) {
                this._writeSegmentedRaw(arrc, n2, n3);
                return;
            }
            this._flushBuffer();
        }
        n4 = n3 + n2;
        block0 : do {
            block7 : {
                if (n2 >= n4) {
                    return;
                }
                do {
                    int n5;
                    byte[] arrby;
                    if ((n3 = arrc[n2]) > 127) {
                        n3 = n2 + 1;
                        if ((n2 = arrc[n2]) < 2048) {
                            arrby = this._outputBuffer;
                            n5 = this._outputTail;
                            this._outputTail = n5 + 1;
                            arrby[n5] = (byte)(n2 >> 6 | 192);
                            arrby = this._outputBuffer;
                            n5 = this._outputTail;
                            this._outputTail = n5 + 1;
                            arrby[n5] = (byte)(n2 & 63 | 128);
                            n2 = n3;
                            continue block0;
                        }
                        break block7;
                    }
                    arrby = this._outputBuffer;
                    n5 = this._outputTail;
                    this._outputTail = n5 + 1;
                    arrby[n5] = (byte)n3;
                    n2 = n3 = n2 + 1;
                } while (n3 < n4);
                return;
            }
            n2 = this._outputRawMultiByteChar(n2, arrc, n3, n4);
        } while (true);
    }

    @Override
    public final void writeStartArray() {
        this._verifyValueWrite("start an array");
        this._writeContext = this._writeContext.createChildArrayContext();
        if (this._cfgPrettyPrinter != null) {
            this._cfgPrettyPrinter.writeStartArray(this);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        byte[] arrby = this._outputBuffer;
        int n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrby[n2] = 91;
    }

    @Override
    public final void writeStartObject() {
        this._verifyValueWrite("start an object");
        this._writeContext = this._writeContext.createChildObjectContext();
        if (this._cfgPrettyPrinter != null) {
            this._cfgPrettyPrinter.writeStartObject(this);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        byte[] arrby = this._outputBuffer;
        int n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrby[n2] = 123;
    }

    @Override
    public void writeString(String arrby) {
        this._verifyValueWrite("write a string");
        if (arrby == null) {
            this._writeNull();
            return;
        }
        int n2 = arrby.length();
        if (n2 > this._outputMaxContiguous) {
            this._writeStringSegments((String)arrby, true);
            return;
        }
        if (this._outputTail + n2 >= this._outputEnd) {
            this._flushBuffer();
        }
        byte[] arrby2 = this._outputBuffer;
        int n3 = this._outputTail;
        this._outputTail = n3 + 1;
        arrby2[n3] = 34;
        this._writeStringSegment((String)arrby, 0, n2);
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        arrby = this._outputBuffer;
        n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrby[n2] = 34;
    }
}

