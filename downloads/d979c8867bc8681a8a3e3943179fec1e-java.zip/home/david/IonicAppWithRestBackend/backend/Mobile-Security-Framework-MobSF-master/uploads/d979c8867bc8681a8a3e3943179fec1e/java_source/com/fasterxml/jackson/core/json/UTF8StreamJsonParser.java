/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.base.ParserBase;
import com.fasterxml.jackson.core.io.CharTypes;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.json.JsonReadContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import com.fasterxml.jackson.core.util.TextBuffer;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

public class UTF8StreamJsonParser
extends ParserBase {
    protected static final int[] _icLatin1;
    private static final int[] _icUTF8;
    protected boolean _bufferRecyclable;
    protected byte[] _inputBuffer;
    protected InputStream _inputStream;
    protected int _nameStartCol;
    protected int _nameStartOffset;
    protected int _nameStartRow;
    protected ObjectCodec _objectCodec;
    private int _quad1;
    protected int[] _quadBuffer = new int[16];
    protected final ByteQuadsCanonicalizer _symbols;
    protected boolean _tokenIncomplete;

    static {
        _icUTF8 = CharTypes.getInputCodeUtf8();
        _icLatin1 = CharTypes.getInputCodeLatin1();
    }

    public UTF8StreamJsonParser(IOContext iOContext, int n2, InputStream inputStream, ObjectCodec objectCodec, ByteQuadsCanonicalizer byteQuadsCanonicalizer, byte[] arrby, int n3, int n4, boolean bl2) {
        super(iOContext, n2);
        this._inputStream = inputStream;
        this._objectCodec = objectCodec;
        this._symbols = byteQuadsCanonicalizer;
        this._inputBuffer = arrby;
        this._inputPtr = n3;
        this._inputEnd = n4;
        this._currInputRowStart = n3;
        this._currInputProcessed = - n3;
        this._bufferRecyclable = bl2;
    }

    private final void _checkMatchEnd(String string, int n2, int n3) {
        if (Character.isJavaIdentifierPart((char)this._decodeCharForError(n3))) {
            this._reportInvalidToken(string.substring(0, n2));
        }
    }

    private final int _decodeUtf8_2(int n2) {
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        byte[] arrby = this._inputBuffer;
        int n3 = this._inputPtr;
        this._inputPtr = n3 + 1;
        if (((n3 = arrby[n3]) & 192) != 128) {
            this._reportInvalidOther(n3 & 255, this._inputPtr);
        }
        return n3 & 63 | (n2 & 31) << 6;
    }

    private final int _decodeUtf8_3(int n2) {
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        byte[] arrby = this._inputBuffer;
        int n3 = this._inputPtr;
        this._inputPtr = n3 + 1;
        if (((n3 = arrby[n3]) & 192) != 128) {
            this._reportInvalidOther(n3 & 255, this._inputPtr);
        }
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        arrby = this._inputBuffer;
        int n4 = this._inputPtr;
        this._inputPtr = n4 + 1;
        if (((n4 = arrby[n4]) & 192) != 128) {
            this._reportInvalidOther(n4 & 255, this._inputPtr);
        }
        return ((n2 & 15) << 6 | n3 & 63) << 6 | n4 & 63;
    }

    private final int _decodeUtf8_3fast(int n2) {
        byte[] arrby = this._inputBuffer;
        int n3 = this._inputPtr;
        this._inputPtr = n3 + 1;
        if (((n3 = arrby[n3]) & 192) != 128) {
            this._reportInvalidOther(n3 & 255, this._inputPtr);
        }
        arrby = this._inputBuffer;
        int n4 = this._inputPtr;
        this._inputPtr = n4 + 1;
        if (((n4 = arrby[n4]) & 192) != 128) {
            this._reportInvalidOther(n4 & 255, this._inputPtr);
        }
        return ((n2 & 15) << 6 | n3 & 63) << 6 | n4 & 63;
    }

    private final int _decodeUtf8_4(int n2) {
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        byte[] arrby = this._inputBuffer;
        int n3 = this._inputPtr;
        this._inputPtr = n3 + 1;
        if (((n3 = arrby[n3]) & 192) != 128) {
            this._reportInvalidOther(n3 & 255, this._inputPtr);
        }
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        arrby = this._inputBuffer;
        int n4 = this._inputPtr;
        this._inputPtr = n4 + 1;
        if (((n4 = arrby[n4]) & 192) != 128) {
            this._reportInvalidOther(n4 & 255, this._inputPtr);
        }
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        arrby = this._inputBuffer;
        int n5 = this._inputPtr;
        this._inputPtr = n5 + 1;
        if (((n5 = arrby[n5]) & 192) != 128) {
            this._reportInvalidOther(n5 & 255, this._inputPtr);
        }
        return (((n3 & 63 | (n2 & 7) << 6) << 6 | n4 & 63) << 6 | n5 & 63) - 65536;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private final void _finishString2(char[] var1_1, int var2_2) {
        var7_3 = UTF8StreamJsonParser._icUTF8;
        var8_4 = this._inputBuffer;
        var6_5 = var1_1;
        do {
            block14 : {
                var4_7 = var3_6 = this._inputPtr;
                if (var3_6 >= this._inputEnd) {
                    this.loadMoreGuaranteed();
                    var4_7 = this._inputPtr;
                }
                var1_1 = var6_5;
                var3_6 = var2_2;
                if (var2_2 >= var6_5.length) {
                    var1_1 = this._textBuffer.finishCurrentSegment();
                    var3_6 = 0;
                }
                var5_8 = Math.min(this._inputEnd, var1_1.length - var3_6 + var4_7);
                while (var4_7 < var5_8) {
                    var2_2 = var4_7 + 1;
                    if (var7_3[var4_7 = var8_4[var4_7] & 255] != 0) {
                        this._inputPtr = var2_2;
                        if (var4_7 == 34) {
                            this._textBuffer.setCurrentLength(var3_6);
                            return;
                        }
                        break block14;
                    }
                    var1_1[var3_6] = (char)var4_7;
                    var4_7 = var2_2;
                    ++var3_6;
                }
                this._inputPtr = var4_7;
                var6_5 = var1_1;
                var2_2 = var3_6;
                continue;
            }
            switch (var7_3[var4_7]) {
                default: {
                    if (var4_7 >= 32) break;
                    this._throwUnquotedSpace(var4_7, "string value");
                    var2_2 = var4_7;
                    ** GOTO lbl62
                }
                case 1: {
                    var2_2 = this._decodeEscaped();
                    ** GOTO lbl62
                }
                case 2: {
                    var2_2 = this._decodeUtf8_2(var4_7);
                    ** GOTO lbl62
                }
                case 3: {
                    var2_2 = this._inputEnd - this._inputPtr >= 2 ? this._decodeUtf8_3fast(var4_7) : this._decodeUtf8_3(var4_7);
                    ** GOTO lbl62
                }
                case 4: {
                    var5_8 = this._decodeUtf8_4(var4_7);
                    var4_7 = var3_6 + 1;
                    var1_1[var3_6] = (char)(55296 | var5_8 >> 10);
                    var2_2 = var4_7;
                    var6_5 = var1_1;
                    if (var4_7 >= var1_1.length) {
                        var6_5 = this._textBuffer.finishCurrentSegment();
                        var2_2 = 0;
                    }
                    var3_6 = var2_2;
                    var2_2 = var5_8 & 1023 | 56320;
                    var1_1 = var6_5;
                    ** GOTO lbl62
                }
            }
            this._reportInvalidChar(var4_7);
            var2_2 = var4_7;
lbl62: // 6 sources:
            if (var3_6 >= var1_1.length) {
                var1_1 = this._textBuffer.finishCurrentSegment();
                var3_6 = 0;
            }
            var4_7 = var3_6 + 1;
            var1_1[var3_6] = (char)var2_2;
            var6_5 = var1_1;
            var2_2 = var4_7;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void _matchToken2(String string, int n2) {
        int n3;
        int n4 = string.length();
        do {
            if (this._inputPtr >= this._inputEnd && !this.loadMore() || this._inputBuffer[this._inputPtr] != string.charAt(n2)) {
                this._reportInvalidToken(string.substring(0, n2));
            }
            ++this._inputPtr;
            n2 = n3 = n2 + 1;
        } while (n3 < n4);
        if (this._inputPtr >= this._inputEnd && !this.loadMore() || (n2 = this._inputBuffer[this._inputPtr] & 255) < 48 || n2 == 93 || n2 == 125) {
            return;
        }
        this._checkMatchEnd(string, n3, n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private final JsonToken _nextAfterName() {
        this._nameCopied = false;
        JsonToken jsonToken = this._nextToken;
        this._nextToken = null;
        if (jsonToken == JsonToken.START_ARRAY) {
            this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
        } else if (jsonToken == JsonToken.START_OBJECT) {
            this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
        }
        this._currToken = jsonToken;
        return jsonToken;
    }

    private final JsonToken _nextTokenNotInObject(int n2) {
        JsonToken jsonToken;
        if (n2 == 34) {
            JsonToken jsonToken2;
            this._tokenIncomplete = true;
            this._currToken = jsonToken2 = JsonToken.VALUE_STRING;
            return jsonToken2;
        }
        switch (n2) {
            default: {
                JsonToken jsonToken3;
                this._currToken = jsonToken3 = this._handleUnexpectedValue(n2);
                return jsonToken3;
            }
            case 91: {
                JsonToken jsonToken4;
                this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
                this._currToken = jsonToken4 = JsonToken.START_ARRAY;
                return jsonToken4;
            }
            case 123: {
                JsonToken jsonToken5;
                this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
                this._currToken = jsonToken5 = JsonToken.START_OBJECT;
                return jsonToken5;
            }
            case 116: {
                JsonToken jsonToken6;
                this._matchToken("true", 1);
                this._currToken = jsonToken6 = JsonToken.VALUE_TRUE;
                return jsonToken6;
            }
            case 102: {
                JsonToken jsonToken7;
                this._matchToken("false", 1);
                this._currToken = jsonToken7 = JsonToken.VALUE_FALSE;
                return jsonToken7;
            }
            case 110: {
                JsonToken jsonToken8;
                this._matchToken("null", 1);
                this._currToken = jsonToken8 = JsonToken.VALUE_NULL;
                return jsonToken8;
            }
            case 45: {
                JsonToken jsonToken9;
                this._currToken = jsonToken9 = this._parseNegNumber();
                return jsonToken9;
            }
            case 48: 
            case 49: 
            case 50: 
            case 51: 
            case 52: 
            case 53: 
            case 54: 
            case 55: 
            case 56: 
            case 57: 
        }
        this._currToken = jsonToken = this._parsePosNumber(n2);
        return jsonToken;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private final JsonToken _parseFloat(char[] var1_1, int var2_2, int var3_3, boolean var4_4, int var5_5) {
        block16 : {
            block15 : {
                block14 : {
                    var6_6 = 0;
                    var9_7 = 0;
                    var7_8 = 0;
                    if (var3_3 == 46) ** GOTO lbl10
                    var8_9 = 0;
                    var6_6 = var3_3;
                    var13_10 = var1_1;
                    var3_3 = var9_7;
                    ** GOTO lbl27
lbl10: // 1 sources:
                    var8_9 = var2_2 + 1;
                    var1_1[var2_2] = (char)var3_3;
                    var2_2 = var8_9;
                    do {
                        if (this._inputPtr < this._inputEnd || this.loadMore()) ** GOTO lbl17
                        var7_8 = 1;
                        ** GOTO lbl-1000
lbl17: // 1 sources:
                        var13_10 = this._inputBuffer;
                        var3_3 = this._inputPtr;
                        this._inputPtr = var3_3 + 1;
                        if ((var3_3 = var13_10[var3_3] & 255) < 48 || var3_3 > 57) lbl-1000: // 2 sources:
                        {
                            if (var6_6 == 0) {
                                this.reportUnexpectedNumberChar(var3_3, "Decimal point not followed by a digit");
                            }
                            var8_9 = var6_6;
                            var6_6 = var3_3;
                            var3_3 = var7_8;
                            var13_10 = var1_1;
lbl27: // 2 sources:
                            var9_7 = 0;
                            if (var6_6 != 101 && var6_6 != 69) break block14;
                            var7_8 = var2_2;
                            var1_1 = var13_10;
                            if (var2_2 >= var13_10.length) {
                                var1_1 = this._textBuffer.finishCurrentSegment();
                                var7_8 = 0;
                            }
                            var2_2 = var7_8 + 1;
                            var1_1[var7_8] = (char)var6_6;
                            if (this._inputPtr >= this._inputEnd) {
                                this.loadMoreGuaranteed();
                            }
                            var13_10 = this._inputBuffer;
                            var6_6 = this._inputPtr;
                            this._inputPtr = var6_6 + 1;
                            if ((var6_6 = var13_10[var6_6] & 255) != 45 && var6_6 != 43) break;
                            if (var2_2 >= var1_1.length) {
                                var1_1 = this._textBuffer.finishCurrentSegment();
                                var2_2 = 0;
                            }
                            var1_1[var2_2] = (char)var6_6;
                            if (this._inputPtr >= this._inputEnd) {
                                this.loadMoreGuaranteed();
                            }
                            var13_10 = this._inputBuffer;
                            var6_6 = this._inputPtr;
                            this._inputPtr = var6_6 + 1;
                            var6_6 = var13_10[var6_6] & 255;
                            ++var2_2;
                            var7_8 = var9_7;
                            break block15;
                        }
                        ++var6_6;
                        if (var2_2 >= var1_1.length) {
                            var1_1 = this._textBuffer.finishCurrentSegment();
                            var2_2 = 0;
                        }
                        var8_9 = var2_2 + 1;
                        var1_1[var2_2] = (char)var3_3;
                        var2_2 = var8_9;
                    } while (true);
                    var7_8 = var9_7;
                    ** GOTO lbl71
                }
                var9_7 = 0;
                var10_11 = var3_3;
                var11_12 = var6_6;
                var12_13 = var2_2;
                ** GOTO lbl107
            }
            while (var6_6 <= 57 && var6_6 >= 48) {
                ++var7_8;
                var9_7 = var2_2;
                var13_10 = var1_1;
                if (var2_2 >= var1_1.length) {
                    var13_10 = this._textBuffer.finishCurrentSegment();
                    var9_7 = 0;
                }
                var2_2 = var9_7 + 1;
                var13_10[var9_7] = (char)var6_6;
                if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
                    var9_7 = var7_8;
                    var3_3 = 1;
                    var7_8 = var2_2;
                    var2_2 = var9_7;
                    break block16;
                }
                var1_1 = this._inputBuffer;
                var6_6 = this._inputPtr;
                this._inputPtr = var6_6 + 1;
                var6_6 = var1_1[var6_6] & 255;
                var1_1 = var13_10;
            }
            var9_7 = var2_2;
            var2_2 = var7_8;
            var7_8 = var9_7;
        }
        var9_7 = var2_2;
        var10_11 = var3_3;
        var11_12 = var6_6;
        var12_13 = var7_8;
        if (var2_2 == 0) {
            this.reportUnexpectedNumberChar(var6_6, "Exponent indicator not followed by a digit");
            var12_13 = var7_8;
            var11_12 = var6_6;
            var10_11 = var3_3;
            var9_7 = var2_2;
        }
lbl107: // 4 sources:
        if (var10_11 == 0) {
            --this._inputPtr;
            if (this._parsingContext.inRoot()) {
                this._verifyRootSpace(var11_12);
            }
        }
        this._textBuffer.setCurrentLength(var12_13);
        return this.resetFloat(var4_4, var5_5, var8_9, var9_7);
    }

    private final JsonToken _parseNumber2(char[] arrc, int n2, boolean bl2, int n3) {
        do {
            if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
                this._textBuffer.setCurrentLength(n2);
                return this.resetInt(bl2, n3);
            }
            byte[] arrby = this._inputBuffer;
            int n4 = this._inputPtr;
            this._inputPtr = n4 + 1;
            int n5 = arrby[n4] & 255;
            if (n5 > 57 || n5 < 48) {
                if (n5 != 46 && n5 != 101 && n5 != 69) break;
                return this._parseFloat(arrc, n2, n5, bl2, n3);
            }
            if (n2 >= arrc.length) {
                arrc = this._textBuffer.finishCurrentSegment();
                n2 = 0;
            }
            n4 = n2 + 1;
            arrc[n2] = (char)n5;
            ++n3;
            n2 = n4;
        } while (true);
        --this._inputPtr;
        this._textBuffer.setCurrentLength(n2);
        if (this._parsingContext.inRoot()) {
            arrc = this._inputBuffer;
            n2 = this._inputPtr;
            this._inputPtr = n2 + 1;
            this._verifyRootSpace(arrc[n2] & 255);
        }
        return this.resetInt(bl2, n3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void _skipCComment() {
        int[] arrn = CharTypes.getInputCodeComment();
        block8 : while (this._inputPtr < this._inputEnd || this.loadMore()) {
            byte[] arrby = this._inputBuffer;
            int n2 = this._inputPtr;
            this._inputPtr = n2 + 1;
            int n3 = arrn[n2 = arrby[n2] & 255];
            if (n3 == 0) continue;
            switch (n3) {
                default: {
                    this._reportInvalidChar(n2);
                    continue block8;
                }
                case 42: {
                    if (this._inputPtr >= this._inputEnd && !this.loadMore()) break block8;
                    if (this._inputBuffer[this._inputPtr] != 47) continue block8;
                    ++this._inputPtr;
                    return;
                }
                case 10: {
                    ++this._currInputRow;
                    this._currInputRowStart = this._inputPtr;
                    continue block8;
                }
                case 13: {
                    this._skipCR();
                    continue block8;
                }
                case 2: {
                    this._skipUtf8_2(n2);
                    continue block8;
                }
                case 3: {
                    this._skipUtf8_3(n2);
                    continue block8;
                }
                case 4: {
                    this._skipUtf8_4(n2);
                    continue block8;
                }
            }
        }
        this._reportInvalidEOF(" in a comment");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private final int _skipColon() {
        if (this._inputPtr + 4 >= this._inputEnd) {
            return this._skipColon2(false);
        }
        var2_1 = this._inputBuffer[this._inputPtr];
        if (var2_1 == 58) {
            var3_2 = this._inputBuffer;
            this._inputPtr = var1_4 = this._inputPtr + 1;
            if ((var1_4 = var3_2[var1_4]) > 32) {
                if (var1_4 == 47) return this._skipColon2(true);
                if (var1_4 == 35) {
                    return this._skipColon2(true);
                }
                ++this._inputPtr;
                return var1_4;
            }
            if (var1_4 != 32) {
                if (var1_4 != 9) return this._skipColon2(true);
            }
            var3_2 = this._inputBuffer;
            this._inputPtr = var1_4 = this._inputPtr + 1;
            if ((var1_4 = var3_2[var1_4]) <= 32) return this._skipColon2(true);
            if (var1_4 == 47) return this._skipColon2(true);
            if (var1_4 == 35) {
                return this._skipColon2(true);
            }
            ++this._inputPtr;
            return var1_4;
        }
        if (var2_1 == 32) ** GOTO lbl-1000
        var1_5 = var2_1;
        if (var2_1 == 9) lbl-1000: // 2 sources:
        {
            var3_3 = this._inputBuffer;
            this._inputPtr = var1_5 = this._inputPtr + 1;
            var1_5 = var3_3[var1_5];
        }
        if (var1_5 != 58) return this._skipColon2(false);
        var3_3 = this._inputBuffer;
        this._inputPtr = var1_5 = this._inputPtr + 1;
        if ((var1_5 = var3_3[var1_5]) > 32) {
            if (var1_5 == 47) return this._skipColon2(true);
            if (var1_5 == 35) {
                return this._skipColon2(true);
            }
            ++this._inputPtr;
            return var1_5;
        }
        if (var1_5 != 32) {
            if (var1_5 != 9) return this._skipColon2(true);
        }
        var3_3 = this._inputBuffer;
        this._inputPtr = var1_5 = this._inputPtr + 1;
        if ((var1_5 = var3_3[var1_5]) <= 32) return this._skipColon2(true);
        if (var1_5 == 47) return this._skipColon2(true);
        if (var1_5 == 35) {
            return this._skipColon2(true);
        }
        ++this._inputPtr;
        return var1_5;
    }

    private final int _skipColon2(boolean bl2) {
        while (this._inputPtr < this._inputEnd || this.loadMore()) {
            byte[] arrby = this._inputBuffer;
            int n2 = this._inputPtr;
            this._inputPtr = n2 + 1;
            if ((n2 = arrby[n2] & 255) > 32) {
                if (n2 == 47) {
                    this._skipComment();
                    continue;
                }
                if (n2 == 35 && this._skipYAMLComment()) continue;
                if (bl2) {
                    return n2;
                }
                if (n2 != 58) {
                    if (n2 < 32) {
                        this._throwInvalidSpace(n2);
                    }
                    this._reportUnexpectedChar(n2, "was expecting a colon to separate field name and value");
                }
                bl2 = true;
                continue;
            }
            if (n2 == 32) continue;
            if (n2 == 10) {
                ++this._currInputRow;
                this._currInputRowStart = this._inputPtr;
                continue;
            }
            if (n2 == 13) {
                this._skipCR();
                continue;
            }
            if (n2 == 9) continue;
            this._throwInvalidSpace(n2);
        }
        throw this._constructError("Unexpected end-of-input within/between " + this._parsingContext.getTypeDesc() + " entries");
    }

    private final void _skipComment() {
        if (!this.isEnabled(JsonParser.Feature.ALLOW_COMMENTS)) {
            this._reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
        }
        if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
            this._reportInvalidEOF(" in a comment");
        }
        byte[] arrby = this._inputBuffer;
        int n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        if ((n2 = arrby[n2] & 255) == 47) {
            this._skipLine();
            return;
        }
        if (n2 == 42) {
            this._skipCComment();
            return;
        }
        this._reportUnexpectedChar(n2, "was expecting either '*' or '/' for a comment");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final void _skipLine() {
        int[] arrn = CharTypes.getInputCodeComment();
        block8 : while (!(this._inputPtr >= this._inputEnd && !this.loadMore())) {
            byte[] arrby = this._inputBuffer;
            int n2 = this._inputPtr;
            this._inputPtr = n2 + 1;
            int n3 = arrn[n2 = arrby[n2] & 255];
            if (n3 == 0) continue;
            switch (n3) {
                case 42: {
                    continue block8;
                }
                default: {
                    if (n3 >= 0) continue block8;
                    this._reportInvalidChar(n2);
                    continue block8;
                }
                case 10: {
                    ++this._currInputRow;
                    this._currInputRowStart = this._inputPtr;
                    return;
                }
                case 13: {
                    this._skipCR();
                    return;
                }
                case 2: {
                    this._skipUtf8_2(n2);
                    continue block8;
                }
                case 3: {
                    this._skipUtf8_3(n2);
                    continue block8;
                }
                case 4: 
            }
            this._skipUtf8_4(n2);
        }
    }

    private final void _skipUtf8_2(int n2) {
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        byte[] arrby = this._inputBuffer;
        n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        if (((n2 = arrby[n2]) & 192) != 128) {
            this._reportInvalidOther(n2 & 255, this._inputPtr);
        }
    }

    private final void _skipUtf8_3(int n2) {
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        byte[] arrby = this._inputBuffer;
        n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        if (((n2 = arrby[n2]) & 192) != 128) {
            this._reportInvalidOther(n2 & 255, this._inputPtr);
        }
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        arrby = this._inputBuffer;
        n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        if (((n2 = arrby[n2]) & 192) != 128) {
            this._reportInvalidOther(n2 & 255, this._inputPtr);
        }
    }

    private final void _skipUtf8_4(int n2) {
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        byte[] arrby = this._inputBuffer;
        n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        if (((n2 = arrby[n2]) & 192) != 128) {
            this._reportInvalidOther(n2 & 255, this._inputPtr);
        }
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        arrby = this._inputBuffer;
        n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        if (((n2 = arrby[n2]) & 192) != 128) {
            this._reportInvalidOther(n2 & 255, this._inputPtr);
        }
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        arrby = this._inputBuffer;
        n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        if (((n2 = arrby[n2]) & 192) != 128) {
            this._reportInvalidOther(n2 & 255, this._inputPtr);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final int _skipWS() {
        while (this._inputPtr < this._inputEnd) {
            byte[] arrby = this._inputBuffer;
            int n2 = this._inputPtr;
            this._inputPtr = n2 + 1;
            int n3 = arrby[n2] & 255;
            if (n3 > 32) {
                if (n3 != 47) {
                    n2 = n3;
                    if (n3 != 35) return n2;
                }
                --this._inputPtr;
                return this._skipWS2();
            }
            if (n3 == 32) continue;
            if (n3 == 10) {
                ++this._currInputRow;
                this._currInputRowStart = this._inputPtr;
                continue;
            }
            if (n3 == 13) {
                this._skipCR();
                continue;
            }
            if (n3 == 9) continue;
            this._throwInvalidSpace(n3);
        }
        return this._skipWS2();
    }

    private final int _skipWS2() {
        while (this._inputPtr < this._inputEnd || this.loadMore()) {
            byte[] arrby = this._inputBuffer;
            int n2 = this._inputPtr;
            this._inputPtr = n2 + 1;
            if ((n2 = arrby[n2] & 255) > 32) {
                if (n2 == 47) {
                    this._skipComment();
                    continue;
                }
                if (n2 == 35 && this._skipYAMLComment()) continue;
                return n2;
            }
            if (n2 == 32) continue;
            if (n2 == 10) {
                ++this._currInputRow;
                this._currInputRowStart = this._inputPtr;
                continue;
            }
            if (n2 == 13) {
                this._skipCR();
                continue;
            }
            if (n2 == 9) continue;
            this._throwInvalidSpace(n2);
        }
        throw this._constructError("Unexpected end-of-input within/between " + this._parsingContext.getTypeDesc() + " entries");
    }

    /*
     * Enabled aggressive block sorting
     */
    private final int _skipWSOrEnd() {
        if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
            return this._eofAsNextChar();
        }
        byte[] arrby = this._inputBuffer;
        int n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        int n3 = arrby[n2] & 255;
        if (n3 > 32) {
            if (n3 != 47) {
                n2 = n3;
                if (n3 != 35) return n2;
            }
            --this._inputPtr;
            return this._skipWSOrEnd2();
        }
        if (n3 != 32) {
            if (n3 == 10) {
                ++this._currInputRow;
                this._currInputRowStart = this._inputPtr;
            } else if (n3 == 13) {
                this._skipCR();
            } else if (n3 != 9) {
                this._throwInvalidSpace(n3);
            }
        }
        while (this._inputPtr < this._inputEnd) {
            arrby = this._inputBuffer;
            n2 = this._inputPtr;
            this._inputPtr = n2 + 1;
            n3 = arrby[n2] & 255;
            if (n3 > 32) {
                if (n3 != 47) {
                    n2 = n3;
                    if (n3 != 35) return n2;
                }
                --this._inputPtr;
                return this._skipWSOrEnd2();
            }
            if (n3 == 32) continue;
            if (n3 == 10) {
                ++this._currInputRow;
                this._currInputRowStart = this._inputPtr;
                continue;
            }
            if (n3 == 13) {
                this._skipCR();
                continue;
            }
            if (n3 == 9) continue;
            this._throwInvalidSpace(n3);
        }
        return this._skipWSOrEnd2();
    }

    private final int _skipWSOrEnd2() {
        while (this._inputPtr < this._inputEnd || this.loadMore()) {
            byte[] arrby = this._inputBuffer;
            int n2 = this._inputPtr;
            this._inputPtr = n2 + 1;
            if ((n2 = arrby[n2] & 255) > 32) {
                if (n2 == 47) {
                    this._skipComment();
                    continue;
                }
                if (n2 == 35 && this._skipYAMLComment()) continue;
                return n2;
            }
            if (n2 == 32) continue;
            if (n2 == 10) {
                ++this._currInputRow;
                this._currInputRowStart = this._inputPtr;
                continue;
            }
            if (n2 == 13) {
                this._skipCR();
                continue;
            }
            if (n2 == 9) continue;
            this._throwInvalidSpace(n2);
        }
        return this._eofAsNextChar();
    }

    private final boolean _skipYAMLComment() {
        if (!this.isEnabled(JsonParser.Feature.ALLOW_YAML_COMMENTS)) {
            return false;
        }
        this._skipLine();
        return true;
    }

    private final void _updateLocation() {
        this._tokenInputRow = this._currInputRow;
        int n2 = this._inputPtr;
        this._tokenInputTotal = this._currInputProcessed + (long)n2;
        this._tokenInputCol = n2 - this._currInputRowStart;
    }

    private final void _updateNameLocation() {
        int n2;
        this._nameStartRow = this._currInputRow;
        this._nameStartOffset = n2 = this._inputPtr;
        this._nameStartCol = n2 - this._currInputRowStart;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final int _verifyNoLeadingZeroes() {
        if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
            return 48;
        }
        int n2 = this._inputBuffer[this._inputPtr] & 255;
        if (n2 < 48) return 48;
        if (n2 > 57) {
            return 48;
        }
        if (!this.isEnabled(JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS)) {
            this.reportInvalidNumber("Leading zeroes not allowed");
        }
        ++this._inputPtr;
        int n3 = n2;
        if (n2 != 48) return n3;
        n3 = n2;
        do {
            if (this._inputPtr >= this._inputEnd) {
                if (!this.loadMore()) return n3;
            }
            if ((n2 = this._inputBuffer[this._inputPtr] & 255) < 48) return 48;
            if (n2 > 57) {
                return 48;
            }
            ++this._inputPtr;
            n3 = n2;
        } while (n2 == 48);
        return n2;
    }

    private final void _verifyRootSpace(int n2) {
        ++this._inputPtr;
        switch (n2) {
            default: {
                this._reportMissingRootWS(n2);
            }
            case 9: 
            case 32: {
                return;
            }
            case 13: {
                this._skipCR();
                return;
            }
            case 10: 
        }
        ++this._currInputRow;
        this._currInputRowStart = this._inputPtr;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private final String addName(int[] var1_1, int var2_2, int var3_3) {
        var11_4 = (var2_2 << 2) - 4 + var3_3;
        if (var3_3 < 4) {
            var10_5 = var1_1[var2_2 - 1];
            var1_1[var2_2 - 1] = var10_5 << (4 - var3_3 << 3);
        } else {
            var10_5 = 0;
        }
        var12_6 = this._textBuffer.emptyAndGetCurrentSegment();
        var7_7 = 0;
        var4_8 = 0;
        do {
            if (var4_8 >= var11_4) {
                var12_6 = new String(var12_6, 0, var7_7);
                if (var3_3 >= 4) return this._symbols.addName((String)var12_6, var1_1, var2_2);
                var1_1[var2_2 - 1] = var10_5;
                return this._symbols.addName((String)var12_6, var1_1, var2_2);
            }
            var5_9 = var1_1[var4_8 >> 2] >> (3 - (var4_8 & 3) << 3) & 255;
            var6_10 = var4_8 + 1;
            var9_12 = var5_9;
            var8_11 = var6_10;
            if (var5_9 <= 127) ** GOTO lbl-1000
            if ((var5_9 & 224) == 192) {
                var4_8 = var5_9 & 31;
                var5_9 = 1;
            } else if ((var5_9 & 240) == 224) {
                var4_8 = var5_9 & 15;
                var5_9 = 2;
            } else if ((var5_9 & 248) == 240) {
                var4_8 = var5_9 & 7;
                var5_9 = 3;
            } else {
                this._reportInvalidInitial(var5_9);
                var4_8 = 1;
                var5_9 = 1;
            }
            if (var6_10 + var5_9 > var11_4) {
                this._reportInvalidEOF(" in field name");
            }
            var9_12 = var1_1[var6_10 >> 2] >> (3 - (var6_10 & 3) << 3);
            var8_11 = var6_10 + 1;
            if ((var9_12 & 192) != 128) {
                this._reportInvalidOther(var9_12);
            }
            var6_10 = var9_12 = var4_8 << 6 | var9_12 & 63;
            var4_8 = var8_11;
            if (var5_9 > 1) {
                var4_8 = var1_1[var8_11 >> 2] >> (3 - (var8_11 & 3) << 3);
                ++var8_11;
                if ((var4_8 & 192) != 128) {
                    this._reportInvalidOther(var4_8);
                }
                var6_10 = var9_12 = var9_12 << 6 | var4_8 & 63;
                var4_8 = var8_11;
                if (var5_9 > 2) {
                    var6_10 = var1_1[var8_11 >> 2] >> (3 - (var8_11 & 3) << 3);
                    var4_8 = var8_11 + 1;
                    if ((var6_10 & 192) != 128) {
                        this._reportInvalidOther(var6_10 & 255);
                    }
                    var6_10 = var9_12 << 6 | var6_10 & 63;
                }
            }
            var9_12 = var6_10;
            var8_11 = var4_8;
            if (var5_9 > 2) {
                var5_9 = var6_10 - 65536;
                var13_13 = var12_6;
                if (var7_7 >= var12_6.length) {
                    var13_13 = this._textBuffer.expandCurrentSegment();
                }
                var13_13[var7_7] = (char)(55296 + (var5_9 >> 10));
                var6_10 = var7_7 + 1;
                var12_6 = var13_13;
                var5_9 = var5_9 & 1023 | 56320;
            } else lbl-1000: // 2 sources:
            {
                var5_9 = var9_12;
                var4_8 = var8_11;
                var6_10 = var7_7;
            }
            var13_13 = var12_6;
            if (var6_10 >= var12_6.length) {
                var13_13 = this._textBuffer.expandCurrentSegment();
            }
            var7_7 = var6_10 + 1;
            var13_13[var6_10] = (char)var5_9;
            var12_6 = var13_13;
        } while (true);
    }

    private final String findName(int n2, int n3) {
        String string = this._symbols.findName(n2 = UTF8StreamJsonParser.pad(n2, n3));
        if (string != null) {
            return string;
        }
        this._quadBuffer[0] = n2;
        return this.addName(this._quadBuffer, 1, n3);
    }

    private final String findName(int n2, int n3, int n4) {
        String string = this._symbols.findName(n2, n3 = UTF8StreamJsonParser.pad(n3, n4));
        if (string != null) {
            return string;
        }
        this._quadBuffer[0] = n2;
        this._quadBuffer[1] = n3;
        return this.addName(this._quadBuffer, 2, n4);
    }

    private final String findName(int n2, int n3, int n4, int n5) {
        int[] arrn = this._symbols.findName(n2, n3, n4 = UTF8StreamJsonParser.pad(n4, n5));
        if (arrn != null) {
            return arrn;
        }
        arrn = this._quadBuffer;
        arrn[0] = n2;
        arrn[1] = n3;
        arrn[2] = UTF8StreamJsonParser.pad(n4, n5);
        return this.addName(arrn, 3, n5);
    }

    private final String findName(int[] object, int n2, int n3, int n4) {
        String string;
        int[] arrn = object;
        if (n2 >= object.length) {
            this._quadBuffer = arrn = UTF8StreamJsonParser.growArrayBy((int[])object, object.length);
        }
        int n5 = n2 + 1;
        arrn[n2] = UTF8StreamJsonParser.pad(n3, n4);
        object = string = this._symbols.findName(arrn, n5);
        if (string == null) {
            object = this.addName(arrn, n5, n4);
        }
        return object;
    }

    public static int[] growArrayBy(int[] arrn, int n2) {
        if (arrn == null) {
            return new int[n2];
        }
        return Arrays.copyOf(arrn, arrn.length + n2);
    }

    private int nextByte() {
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        byte[] arrby = this._inputBuffer;
        int n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        return arrby[n2] & 255;
    }

    private static final int pad(int n2, int n3) {
        if (n3 == 4) {
            return n2;
        }
        return n2 | -1 << (n3 << 3);
    }

    private final String parseName(int n2, int n3, int n4) {
        return this.parseEscapedName(this._quadBuffer, 0, n2, n3, n4);
    }

    private final String parseName(int n2, int n3, int n4, int n5) {
        this._quadBuffer[0] = n2;
        return this.parseEscapedName(this._quadBuffer, 1, n3, n4, n5);
    }

    private final String parseName(int n2, int n3, int n4, int n5, int n6) {
        this._quadBuffer[0] = n2;
        this._quadBuffer[1] = n3;
        return this.parseEscapedName(this._quadBuffer, 2, n4, n5, n6);
    }

    @Override
    protected void _closeInput() {
        if (this._inputStream != null) {
            if (this._ioContext.isResourceManaged() || this.isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE)) {
                this._inputStream.close();
            }
            this._inputStream = null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected int _decodeCharForError(int n2) {
        int n3;
        int n4;
        n2 = n3 = n2 & 255;
        if (n3 <= 127) return n2;
        if ((n3 & 224) == 192) {
            n3 &= 31;
            n2 = 1;
        } else if ((n3 & 240) == 224) {
            n3 &= 15;
            n2 = 2;
        } else if ((n3 & 248) == 240) {
            n3 &= 7;
            n2 = 3;
        } else {
            this._reportInvalidInitial(n3 & 255);
            n2 = 1;
        }
        if (((n4 = this.nextByte()) & 192) != 128) {
            this._reportInvalidOther(n4 & 255);
        }
        n3 = n3 << 6 | n4 & 63;
        if (n2 <= 1) {
            return n3;
        }
        n4 = this.nextByte();
        if ((n4 & 192) != 128) {
            this._reportInvalidOther(n4 & 255);
        }
        n3 = n4 & 63 | n3 << 6;
        if (n2 <= 2) {
            return n3;
        }
        n2 = this.nextByte();
        if ((n2 & 192) == 128) return n2 & 63 | n3 << 6;
        this._reportInvalidOther(n2 & 255);
        return n2 & 63 | n3 << 6;
    }

    @Override
    protected char _decodeEscaped() {
        int n2 = 0;
        if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
            this._reportInvalidEOF(" in character escape sequence");
        }
        byte[] arrby = this._inputBuffer;
        int n3 = this._inputPtr;
        this._inputPtr = n3 + 1;
        n3 = arrby[n3];
        switch (n3) {
            default: {
                return this._handleUnrecognizedCharacterEscape((char)this._decodeCharForError(n3));
            }
            case 98: {
                return '\b';
            }
            case 116: {
                return '\t';
            }
            case 110: {
                return '\n';
            }
            case 102: {
                return '\f';
            }
            case 114: {
                return '\r';
            }
            case 34: 
            case 47: 
            case 92: {
                return (char)n3;
            }
            case 117: 
        }
        n3 = 0;
        while (n2 < 4) {
            if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
                this._reportInvalidEOF(" in character escape sequence");
            }
            arrby = this._inputBuffer;
            int n4 = this._inputPtr;
            this._inputPtr = n4 + 1;
            int n5 = CharTypes.charToHex(n4 = arrby[n4]);
            if (n5 < 0) {
                this._reportUnexpectedChar(n4, "expected a hex-digit for character escape sequence");
            }
            n3 = n3 << 4 | n5;
            ++n2;
        }
        return (char)n3;
    }

    protected String _finishAndReturnString() {
        int n2;
        int n3 = n2 = this._inputPtr;
        if (n2 >= this._inputEnd) {
            this.loadMoreGuaranteed();
            n3 = this._inputPtr;
        }
        char[] arrc = this._textBuffer.emptyAndGetCurrentSegment();
        int[] arrn = _icUTF8;
        int n4 = Math.min(this._inputEnd, arrc.length + n3);
        byte[] arrby = this._inputBuffer;
        n2 = 0;
        while (n3 < n4) {
            int n5 = arrby[n3] & 255;
            if (arrn[n5] != 0) {
                if (n5 != 34) break;
                this._inputPtr = n3 + 1;
                return this._textBuffer.setCurrentAndReturn(n2);
            }
            arrc[n2] = (char)n5;
            ++n2;
            ++n3;
        }
        this._inputPtr = n3;
        this._finishString2(arrc, n2);
        return this._textBuffer.contentsAsString();
    }

    @Override
    protected void _finishString() {
        int n2;
        int n3 = n2 = this._inputPtr;
        if (n2 >= this._inputEnd) {
            this.loadMoreGuaranteed();
            n3 = this._inputPtr;
        }
        char[] arrc = this._textBuffer.emptyAndGetCurrentSegment();
        int[] arrn = _icUTF8;
        int n4 = Math.min(this._inputEnd, arrc.length + n3);
        byte[] arrby = this._inputBuffer;
        n2 = 0;
        while (n3 < n4) {
            int n5 = arrby[n3] & 255;
            if (arrn[n5] != 0) {
                if (n5 != 34) break;
                this._inputPtr = n3 + 1;
                this._textBuffer.setCurrentLength(n2);
                return;
            }
            arrc[n2] = (char)n5;
            ++n2;
            ++n3;
        }
        this._inputPtr = n3;
        this._finishString2(arrc, n2);
    }

    protected final String _getText2(JsonToken jsonToken) {
        if (jsonToken == null) {
            return null;
        }
        switch (jsonToken.id()) {
            default: {
                return jsonToken.asString();
            }
            case 5: {
                return this._parsingContext.getCurrentName();
            }
            case 6: 
            case 7: 
            case 8: 
        }
        return this._textBuffer.contentsAsString();
    }

    /*
     * Enabled aggressive block sorting
     */
    protected JsonToken _handleApos() {
        char[] arrc = this._textBuffer.emptyAndGetCurrentSegment();
        int[] arrn = _icUTF8;
        byte[] arrby = this._inputBuffer;
        int n2 = 0;
        block6 : do {
            int n3;
            if (this._inputPtr >= this._inputEnd) {
                this.loadMoreGuaranteed();
            }
            char[] arrc2 = arrc;
            int n4 = n2;
            if (n2 >= arrc.length) {
                arrc2 = this._textBuffer.finishCurrentSegment();
                n4 = 0;
            }
            if ((n2 = this._inputPtr + (arrc2.length - n4)) < (n3 = this._inputEnd)) {
                n3 = n2;
            }
            do {
                arrc = arrc2;
                n2 = n4;
                if (this._inputPtr >= n3) continue block6;
                n2 = this._inputPtr;
                this._inputPtr = n2 + 1;
                if ((n2 = arrby[n2] & 255) == 39 || arrn[n2] != 0) {
                    if (n2 != 39) break;
                    this._textBuffer.setCurrentLength(n4);
                    return JsonToken.VALUE_STRING;
                }
                arrc2[n4] = (char)n2;
                ++n4;
            } while (true);
            switch (arrn[n2]) {
                default: {
                    if (n2 < 32) {
                        this._throwUnquotedSpace(n2, "string value");
                    }
                    this._reportInvalidChar(n2);
                    break;
                }
                case 1: {
                    if (n2 == 39) break;
                    n2 = this._decodeEscaped();
                    break;
                }
                case 2: {
                    n2 = this._decodeUtf8_2(n2);
                    break;
                }
                case 3: {
                    if (this._inputEnd - this._inputPtr >= 2) {
                        n2 = this._decodeUtf8_3fast(n2);
                        break;
                    }
                    n2 = this._decodeUtf8_3(n2);
                    break;
                }
                case 4: {
                    n3 = this._decodeUtf8_4(n2);
                    n2 = n4 + 1;
                    arrc2[n4] = (char)(55296 | n3 >> 10);
                    if (n2 >= arrc2.length) {
                        arrc2 = this._textBuffer.finishCurrentSegment();
                        n4 = 0;
                    } else {
                        n4 = n2;
                    }
                    n2 = 56320 | n3 & 1023;
                }
            }
            if (n4 >= arrc2.length) {
                arrc2 = this._textBuffer.finishCurrentSegment();
                n4 = 0;
            }
            n3 = n4 + 1;
            arrc2[n4] = (char)n2;
            arrc = arrc2;
            n2 = n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected JsonToken _handleInvalidNumberStart(int n2, boolean bl2) {
        int n3;
        block6 : {
            do {
                n3 = n2;
                if (n2 != 73) break block6;
                if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
                    this._reportInvalidEOFInValue();
                }
                Object object = this._inputBuffer;
                n2 = this._inputPtr;
                this._inputPtr = n2 + 1;
                if ((n2 = object[n2]) == 78) {
                    object = bl2 ? "-INF" : "+INF";
                } else {
                    if (n2 != 110) break;
                    object = bl2 ? "-Infinity" : "+Infinity";
                }
                this._matchToken((String)object, 3);
                if (this.isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
                    double d2;
                    if (bl2) {
                        d2 = Double.NEGATIVE_INFINITY;
                        return this.resetAsNaN((String)object, d2);
                    }
                    d2 = Double.POSITIVE_INFINITY;
                    return this.resetAsNaN((String)object, d2);
                }
                this._reportError("Non-standard token '" + (String)object + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
            } while (true);
            n3 = n2;
        }
        this.reportUnexpectedNumberChar(n3, "expected digit (0-9) to follow minus sign, for valid numeric value");
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected String _handleOddName(int n2) {
        int[] arrn;
        if (n2 == 39 && this.isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
            return this._parseAposName();
        }
        if (!this.isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES)) {
            this._reportUnexpectedChar((char)this._decodeCharForError(n2), "was expecting double-quote to start field name");
        }
        if ((arrn = CharTypes.getInputCodeUtf8JsNames())[n2] != 0) {
            this._reportUnexpectedChar(n2, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
        }
        Object object = this._quadBuffer;
        int n3 = 0;
        int n4 = 0;
        int n5 = n2;
        n2 = 0;
        do {
            int[] arrn2;
            int n6;
            if (n3 < 4) {
                n4 = n5 | n4 << 8;
                n5 = n3 + 1;
            } else {
                arrn2 = object;
                if (n2 >= object.length) {
                    this._quadBuffer = arrn2 = UTF8StreamJsonParser.growArrayBy((int[])object, object.length);
                }
                arrn2[n2] = n4;
                object = arrn2;
                n3 = 1;
                n4 = n5;
                ++n2;
                n5 = n3;
            }
            if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
                this._reportInvalidEOF(" in field name");
            }
            if (arrn[n6 = this._inputBuffer[this._inputPtr] & 255] != 0) {
                n3 = n2;
                arrn2 = object;
                if (n5 > 0) {
                    arrn2 = object;
                    if (n2 >= object.length) {
                        this._quadBuffer = arrn2 = UTF8StreamJsonParser.growArrayBy((int[])object, object.length);
                    }
                    arrn2[n2] = n4;
                    n3 = n2 + 1;
                }
                if ((object = this._symbols.findName(arrn2, n3)) != null) break;
                return this.addName(arrn2, n3, n5);
            }
            ++this._inputPtr;
            n3 = n5;
            n5 = n6;
        } while (true);
        return object;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected JsonToken _handleUnexpectedValue(int var1_1) {
        switch (var1_1) {
            case 93: 
            case 125: {
                this._reportUnexpectedChar(var1_1, "expected a value");
            }
            case 39: {
                if (this.isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
                    return this._handleApos();
                }
                ** GOTO lbl19
            }
            case 78: {
                this._matchToken("NaN", 1);
                if (this.isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
                    return this.resetAsNaN("NaN", Double.NaN);
                }
                this._reportError("Non-standard token 'NaN': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
                ** break;
            }
            case 73: {
                this._matchToken("Infinity", 1);
                if (this.isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
                    return this.resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
                }
                this._reportError("Non-standard token 'Infinity': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
            }
lbl19: // 4 sources:
            default: {
                if (Character.isJavaIdentifierStart(var1_1)) {
                    this._reportInvalidToken("" + (char)var1_1, "('true', 'false' or 'null')");
                }
                this._reportUnexpectedChar(var1_1, "expected a valid value (number, String, array, object, 'true', 'false' or 'null')");
                return null;
            }
            case 43: 
        }
        if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
            this._reportInvalidEOFInValue();
        }
        var2_2 = this._inputBuffer;
        var1_1 = this._inputPtr;
        this._inputPtr = var1_1 + 1;
        return this._handleInvalidNumberStart(var2_2[var1_1] & 255, false);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void _matchToken(String string, int n2) {
        int n3 = string.length();
        int n4 = n2;
        if (this._inputPtr + n3 >= this._inputEnd) {
            this._matchToken2(string, n2);
            return;
        } else {
            do {
                if (this._inputBuffer[this._inputPtr] != string.charAt(n4)) {
                    this._reportInvalidToken(string.substring(0, n4));
                }
                ++this._inputPtr;
                n4 = n2 = n4 + 1;
            } while (n2 < n3);
            n4 = this._inputBuffer[this._inputPtr] & 255;
            if (n4 < 48 || n4 == 93 || n4 == 125) return;
            {
                this._checkMatchEnd(string, n2, n4);
                return;
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected String _parseAposName() {
        if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
            this._reportInvalidEOF(": was expecting closing ''' for name");
        }
        var6_1 = this._inputBuffer;
        var1_2 = this._inputPtr;
        this._inputPtr = var1_2 + 1;
        var4_3 = var6_1[var1_2] & 255;
        if (var4_3 == 39) {
            return "";
        }
        var6_1 = this._quadBuffer;
        var8_4 = UTF8StreamJsonParser._icLatin1;
        var2_5 = 0;
        var3_6 = 0;
        var1_2 = 0;
        do {
            if (var4_3 == 39) {
                if (var2_5 > 0) {
                    var7_8 = var6_1;
                    if (var1_2 >= var6_1.length) {
                        this._quadBuffer = var7_8 = UTF8StreamJsonParser.growArrayBy(var6_1, var6_1.length);
                    }
                    var7_8[var1_2] = UTF8StreamJsonParser.pad(var3_6, var2_5);
                    var6_1 = var7_8;
                    ++var1_2;
                }
                if ((var7_8 = this._symbols.findName(var6_1, var1_2)) != null) return var7_8;
                return this.addName(var6_1, var1_2, var2_5);
            }
            var5_7 = var4_3;
            if (var4_3 == 34) ** GOTO lbl-1000
            var5_7 = var4_3;
            if (var8_4[var4_3] == 0) ** GOTO lbl-1000
            if (var4_3 != 92) {
                this._throwUnquotedSpace(var4_3, "name");
            } else {
                var4_3 = this._decodeEscaped();
            }
            var5_7 = var4_3;
            if (var4_3 > 127) {
                if (var2_5 >= 4) {
                    var7_8 = var6_1;
                    if (var1_2 >= var6_1.length) {
                        this._quadBuffer = var7_8 = UTF8StreamJsonParser.growArrayBy(var6_1, var6_1.length);
                    }
                    var7_8[var1_2] = var3_6;
                    var2_5 = 0;
                    ++var1_2;
                    var3_6 = 0;
                    var6_1 = var7_8;
                }
                if (var4_3 < 2048) {
                    var3_6 = var3_6 << 8 | (var4_3 >> 6 | 192);
                    ++var2_5;
                } else {
                    var3_6 = var3_6 << 8 | (var4_3 >> 12 | 224);
                    if (++var2_5 >= 4) {
                        var7_8 = var6_1;
                        if (var1_2 >= var6_1.length) {
                            this._quadBuffer = var7_8 = UTF8StreamJsonParser.growArrayBy(var6_1, var6_1.length);
                        }
                        var7_8[var1_2] = var3_6;
                        ++var1_2;
                        var6_1 = var7_8;
                        var2_5 = 0;
                        var3_6 = 0;
                    }
                    var3_6 = var3_6 << 8 | (var4_3 >> 6 & 63 | 128);
                    ++var2_5;
                }
                var5_7 = var3_6;
                var3_6 = var2_5;
                var2_5 = var4_3 & 63 | 128;
                var4_3 = var3_6;
            } else lbl-1000: // 3 sources:
            {
                var4_3 = var2_5;
                var2_5 = var5_7;
                var5_7 = var3_6;
            }
            if (var4_3 < 4) {
                var3_6 = var2_5 | var5_7 << 8;
                var2_5 = var1_2;
                var1_2 = ++var4_3;
            } else {
                var7_8 = var6_1;
                if (var1_2 >= var6_1.length) {
                    this._quadBuffer = var7_8 = UTF8StreamJsonParser.growArrayBy(var6_1, var6_1.length);
                }
                var7_8[var1_2] = var5_7;
                var6_1 = var7_8;
                var3_6 = 1;
                var4_3 = var1_2 + 1;
                var1_2 = var3_6;
                var3_6 = var2_5;
                var2_5 = var4_3;
            }
            if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
                this._reportInvalidEOF(" in field name");
            }
            var7_8 = this._inputBuffer;
            var4_3 = this._inputPtr;
            this._inputPtr = var4_3 + 1;
            var5_7 = var7_8[var4_3] & 255;
            var4_3 = var1_2;
            var1_2 = var2_5;
            var2_5 = var4_3;
            var4_3 = var5_7;
        } while (true);
    }

    protected final String _parseName(int n2) {
        if (n2 != 34) {
            return this._handleOddName(n2);
        }
        if (this._inputPtr + 13 > this._inputEnd) {
            return this.slowParseName();
        }
        byte[] arrby = this._inputBuffer;
        int[] arrn = _icLatin1;
        n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        if (arrn[n2 = arrby[n2] & 255] == 0) {
            int n3 = this._inputPtr;
            this._inputPtr = n3 + 1;
            if (arrn[n3 = arrby[n3] & 255] == 0) {
                n2 = n2 << 8 | n3;
                n3 = this._inputPtr;
                this._inputPtr = n3 + 1;
                if (arrn[n3 = arrby[n3] & 255] == 0) {
                    n2 = n2 << 8 | n3;
                    n3 = this._inputPtr;
                    this._inputPtr = n3 + 1;
                    if (arrn[n3 = arrby[n3] & 255] == 0) {
                        n2 = n2 << 8 | n3;
                        n3 = this._inputPtr;
                        this._inputPtr = n3 + 1;
                        if (arrn[n3 = arrby[n3] & 255] == 0) {
                            this._quad1 = n2;
                            return this.parseMediumName(n3);
                        }
                        if (n3 == 34) {
                            return this.findName(n2, 4);
                        }
                        return this.parseName(n2, n3, 4);
                    }
                    if (n3 == 34) {
                        return this.findName(n2, 3);
                    }
                    return this.parseName(n2, n3, 3);
                }
                if (n3 == 34) {
                    return this.findName(n2, 2);
                }
                return this.parseName(n2, n3, 2);
            }
            if (n3 == 34) {
                return this.findName(n2, 1);
            }
            return this.parseName(n2, n3, 1);
        }
        if (n2 == 34) {
            return "";
        }
        return this.parseName(0, n2, 0);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected JsonToken _parseNegNumber() {
        int n2;
        char[] arrc = this._textBuffer.emptyAndGetCurrentSegment();
        arrc[0] = 45;
        if (this._inputPtr >= this._inputEnd) {
            this.loadMoreGuaranteed();
        }
        byte[] arrby = this._inputBuffer;
        int n3 = this._inputPtr;
        this._inputPtr = n3 + 1;
        int n4 = arrby[n3] & 255;
        if (n4 < 48 || n4 > 57) {
            return this._handleInvalidNumberStart(n4, true);
        }
        n3 = n4;
        if (n4 == 48) {
            n3 = this._verifyNoLeadingZeroes();
        }
        int n5 = 2;
        arrc[1] = (char)n3;
        n4 = this._inputPtr + arrc.length - 2;
        if (n4 > this._inputEnd) {
            n4 = this._inputEnd;
            n3 = 1;
        } else {
            n3 = 1;
        }
        do {
            if (this._inputPtr >= n4) {
                return this._parseNumber2(arrc, n5, true, n3);
            }
            arrby = this._inputBuffer;
            n2 = this._inputPtr;
            this._inputPtr = n2 + 1;
            if ((n2 = arrby[n2] & 255) < 48 || n2 > 57) {
                if (n2 != 46 && n2 != 101 && n2 != 69) break;
                return this._parseFloat(arrc, n5, n2, true, n3);
            }
            ++n3;
            arrc[n5] = (char)n2;
            ++n5;
        } while (true);
        --this._inputPtr;
        this._textBuffer.setCurrentLength(n5);
        if (this._parsingContext.inRoot()) {
            this._verifyRootSpace(n2);
        }
        return this.resetInt(true, n3);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected JsonToken _parsePosNumber(int n2) {
        int n3;
        int n4 = 1;
        char[] arrc = this._textBuffer.emptyAndGetCurrentSegment();
        int n5 = n2;
        if (n2 == 48) {
            n5 = this._verifyNoLeadingZeroes();
        }
        arrc[0] = (char)n5;
        n5 = this._inputPtr + arrc.length - 1;
        if (n5 > this._inputEnd) {
            n5 = this._inputEnd;
            n2 = 1;
        } else {
            n2 = 1;
        }
        do {
            if (this._inputPtr >= n5) {
                return this._parseNumber2(arrc, n4, false, n2);
            }
            byte[] arrby = this._inputBuffer;
            n3 = this._inputPtr;
            this._inputPtr = n3 + 1;
            if ((n3 = arrby[n3] & 255) < 48 || n3 > 57) {
                if (n3 != 46 && n3 != 101 && n3 != 69) break;
                return this._parseFloat(arrc, n4, n3, false, n2);
            }
            arrc[n4] = (char)n3;
            ++n4;
            ++n2;
        } while (true);
        --this._inputPtr;
        this._textBuffer.setCurrentLength(n4);
        if (this._parsingContext.inRoot()) {
            this._verifyRootSpace(n3);
        }
        return this.resetInt(false, n2);
    }

    @Override
    protected void _releaseBuffers() {
        byte[] arrby;
        super._releaseBuffers();
        this._symbols.release();
        if (this._bufferRecyclable && (arrby = this._inputBuffer) != null) {
            this._inputBuffer = ByteArrayBuilder.NO_BYTES;
            this._ioContext.releaseReadIOBuffer(arrby);
        }
    }

    protected void _reportInvalidChar(int n2) {
        if (n2 < 32) {
            this._throwInvalidSpace(n2);
        }
        this._reportInvalidInitial(n2);
    }

    protected void _reportInvalidInitial(int n2) {
        this._reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(n2));
    }

    protected void _reportInvalidOther(int n2) {
        this._reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(n2));
    }

    protected void _reportInvalidOther(int n2, int n3) {
        this._inputPtr = n3;
        this._reportInvalidOther(n2);
    }

    protected void _reportInvalidToken(String string) {
        this._reportInvalidToken(string, "'null', 'true', 'false' or NaN");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void _reportInvalidToken(String var1_1, String var2_2) {
        var1_2 = new StringBuilder(var1_1 /* !! */ );
        do {
            if (this._inputPtr >= this._inputEnd && !this.loadMore()) ** GOTO lbl-1000
            var5_6 = this._inputBuffer;
            var4_5 = this._inputPtr;
            this._inputPtr = var4_5 + 1;
            var3_4 = (char)this._decodeCharForError(var5_6[var4_5]);
            if (!Character.isJavaIdentifierPart(var3_4)) lbl-1000: // 2 sources:
            {
                this._reportError("Unrecognized token '" + var1_2.toString() + "': was expecting " + (String)var2_3);
                return;
            }
            var1_2.append(var3_4);
        } while (true);
    }

    protected final void _skipCR() {
        if ((this._inputPtr < this._inputEnd || this.loadMore()) && this._inputBuffer[this._inputPtr] == 10) {
            ++this._inputPtr;
        }
        ++this._currInputRow;
        this._currInputRowStart = this._inputPtr;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void _skipString() {
        this._tokenIncomplete = false;
        var5_1 = UTF8StreamJsonParser._icUTF8;
        var6_2 = this._inputBuffer;
        block6 : do {
            var3_5 = this._inputPtr;
            var2_4 = var4_6 = this._inputEnd;
            var1_3 = var3_5;
            if (var3_5 >= var4_6) {
                this.loadMoreGuaranteed();
                var1_3 = this._inputPtr;
                var2_4 = this._inputEnd;
            }
            do {
                if (var1_3 >= var2_4) ** GOTO lbl20
                var3_5 = var1_3 + 1;
                if (var5_1[var1_3 = var6_2[var1_3] & 255] == 0) ** GOTO lbl41
                this._inputPtr = var3_5;
                if (var1_3 == 34) {
                    return;
                }
                ** GOTO lbl22
lbl20: // 1 sources:
                this._inputPtr = var1_3;
                continue block6;
lbl22: // 1 sources:
                switch (var5_1[var1_3]) {
                    default: {
                        if (var1_3 >= 32) break;
                        this._throwUnquotedSpace(var1_3, "string value");
                        continue block6;
                    }
                    case 1: {
                        this._decodeEscaped();
                        continue block6;
                    }
                    case 2: {
                        this._skipUtf8_2(var1_3);
                        continue block6;
                    }
                    case 3: {
                        this._skipUtf8_3(var1_3);
                        continue block6;
                    }
                    case 4: {
                        this._skipUtf8_4(var1_3);
                        continue block6;
                    }
                }
                this._reportInvalidChar(var1_3);
                continue block6;
lbl41: // 1 sources:
                var1_3 = var3_5;
            } while (true);
            break;
        } while (true);
    }

    @Override
    public JsonLocation getCurrentLocation() {
        int n2 = this._inputPtr;
        int n3 = this._currInputRowStart;
        return new JsonLocation(this._ioContext.getSourceReference(), this._currInputProcessed + (long)this._inputPtr, -1, this._currInputRow, n2 - n3 + 1);
    }

    @Override
    public String getText() {
        if (this._currToken == JsonToken.VALUE_STRING) {
            if (this._tokenIncomplete) {
                this._tokenIncomplete = false;
                return this._finishAndReturnString();
            }
            return this._textBuffer.contentsAsString();
        }
        return this._getText2(this._currToken);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected final boolean loadMore() {
        int n2 = this._inputEnd;
        this._currInputProcessed += (long)this._inputEnd;
        this._currInputRowStart -= this._inputEnd;
        this._nameStartOffset -= n2;
        if (this._inputStream == null) return false;
        n2 = this._inputBuffer.length;
        if (n2 == 0) {
            return false;
        }
        if ((n2 = this._inputStream.read(this._inputBuffer, 0, n2)) > 0) {
            this._inputPtr = 0;
            this._inputEnd = n2;
            return true;
        }
        this._closeInput();
        if (n2 != 0) return false;
        throw new IOException("InputStream.read() returned 0 characters when trying to read " + this._inputBuffer.length + " bytes");
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public JsonToken nextToken() {
        int n2;
        if (this._currToken == JsonToken.FIELD_NAME) {
            return this._nextAfterName();
        }
        this._numTypesValid = 0;
        if (this._tokenIncomplete) {
            this._skipString();
        }
        if ((n2 = this._skipWSOrEnd()) < 0) {
            this.close();
            this._currToken = null;
            return null;
        }
        this._binaryValue = null;
        if (n2 == 93) {
            JsonToken jsonToken;
            this._updateLocation();
            if (!this._parsingContext.inArray()) {
                this._reportMismatchedEndMarker(n2, '}');
            }
            this._parsingContext = this._parsingContext.clearAndGetParent();
            this._currToken = jsonToken = JsonToken.END_ARRAY;
            return jsonToken;
        }
        if (n2 == 125) {
            JsonToken jsonToken;
            this._updateLocation();
            if (!this._parsingContext.inObject()) {
                this._reportMismatchedEndMarker(n2, ']');
            }
            this._parsingContext = this._parsingContext.clearAndGetParent();
            this._currToken = jsonToken = JsonToken.END_OBJECT;
            return jsonToken;
        }
        int n3 = n2;
        if (this._parsingContext.expectComma()) {
            if (n2 != 44) {
                this._reportUnexpectedChar(n2, "was expecting comma to separate " + this._parsingContext.getTypeDesc() + " entries");
            }
            n3 = this._skipWS();
        }
        if (!this._parsingContext.inObject()) {
            this._updateLocation();
            return this._nextTokenNotInObject(n3);
        }
        this._updateNameLocation();
        Object object = this._parseName(n3);
        this._parsingContext.setCurrentName((String)object);
        this._currToken = JsonToken.FIELD_NAME;
        n3 = this._skipColon();
        this._updateLocation();
        if (n3 == 34) {
            this._tokenIncomplete = true;
            this._nextToken = JsonToken.VALUE_STRING;
            return this._currToken;
        }
        switch (n3) {
            default: {
                object = this._handleUnexpectedValue(n3);
                break;
            }
            case 45: {
                object = this._parseNegNumber();
                break;
            }
            case 48: 
            case 49: 
            case 50: 
            case 51: 
            case 52: 
            case 53: 
            case 54: 
            case 55: 
            case 56: 
            case 57: {
                object = this._parsePosNumber(n3);
                break;
            }
            case 102: {
                this._matchToken("false", 1);
                object = JsonToken.VALUE_FALSE;
                break;
            }
            case 110: {
                this._matchToken("null", 1);
                object = JsonToken.VALUE_NULL;
                break;
            }
            case 116: {
                this._matchToken("true", 1);
                object = JsonToken.VALUE_TRUE;
                break;
            }
            case 91: {
                object = JsonToken.START_ARRAY;
                break;
            }
            case 123: {
                object = JsonToken.START_OBJECT;
            }
        }
        this._nextToken = object;
        return this._currToken;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final String parseEscapedName(int[] var1_1, int var2_2, int var3_3, int var4_4, int var5_5) {
        var9_6 = UTF8StreamJsonParser._icLatin1;
        do {
            var6_7 = var4_4;
            if (var9_6[var4_4] == 0) ** GOTO lbl-1000
            if (var4_4 == 34) {
                var8_9 = var1_1;
                var4_4 = var2_2;
                if (var5_5 > 0) {
                    var8_9 = var1_1;
                    if (var2_2 >= var1_1.length) {
                        this._quadBuffer = var8_9 = UTF8StreamJsonParser.growArrayBy((int[])var1_1, var1_1.length);
                    }
                    var8_9[var2_2] = UTF8StreamJsonParser.pad(var3_3, var5_5);
                    var4_4 = var2_2 + 1;
                }
                var1_1 = var9_6 = this._symbols.findName(var8_9, var4_4);
                if (var9_6 != null) return var1_1;
                return this.addName(var8_9, var4_4, var5_5);
            }
            if (var4_4 != 92) {
                this._throwUnquotedSpace(var4_4, "name");
            } else {
                var4_4 = this._decodeEscaped();
            }
            var6_7 = var4_4;
            if (var4_4 > 127) {
                if (var5_5 >= 4) {
                    var8_9 = var1_1;
                    if (var2_2 >= var1_1.length) {
                        this._quadBuffer = var8_9 = UTF8StreamJsonParser.growArrayBy((int[])var1_1, var1_1.length);
                    }
                    var6_7 = var2_2 + 1;
                    var8_9[var2_2] = var3_3;
                    var5_5 = 0;
                    var3_3 = 0;
                    var1_1 = var8_9;
                    var2_2 = var6_7;
                }
                if (var4_4 < 2048) {
                    var6_7 = var4_4 >> 6 | 192 | var3_3 << 8;
                    ++var5_5;
                    var3_3 = var2_2;
                    var2_2 = var6_7;
                } else {
                    var6_7 = var4_4 >> 12 | 224 | var3_3 << 8;
                    var3_3 = var5_5 + 1;
                    if (var3_3 >= 4) {
                        var8_9 = var1_1;
                        if (var2_2 >= var1_1.length) {
                            this._quadBuffer = var8_9 = UTF8StreamJsonParser.growArrayBy((int[])var1_1, var1_1.length);
                        }
                        var8_9[var2_2] = var6_7;
                        ++var2_2;
                        var1_1 = var8_9;
                        var3_3 = 0;
                        var5_5 = 0;
                    } else {
                        var5_5 = var6_7;
                    }
                    var6_7 = var5_5 << 8 | (var4_4 >> 6 & 63 | 128);
                    var5_5 = var3_3 + 1;
                    var3_3 = var2_2;
                    var2_2 = var6_7;
                }
                var7_8 = var4_4 & 63 | 128;
                var6_7 = var5_5;
                var4_4 = var3_3;
                var5_5 = var2_2;
                var3_3 = var7_8;
                var2_2 = var4_4;
                var4_4 = var5_5;
            } else lbl-1000: // 2 sources:
            {
                var4_4 = var3_3;
                var3_3 = var6_7;
                var6_7 = var5_5;
            }
            if (var6_7 < 4) {
                var5_5 = var6_7 + 1;
                var3_3 |= var4_4 << 8;
            } else {
                var8_9 = var1_1;
                if (var2_2 >= var1_1.length) {
                    this._quadBuffer = var8_9 = UTF8StreamJsonParser.growArrayBy((int[])var1_1, var1_1.length);
                }
                var8_9[var2_2] = var4_4;
                var5_5 = 1;
                ++var2_2;
                var1_1 = var8_9;
            }
            if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
                this._reportInvalidEOF(" in field name");
            }
            var8_9 = this._inputBuffer;
            var4_4 = this._inputPtr;
            this._inputPtr = var4_4 + 1;
            var4_4 = var8_9[var4_4] & 255;
        } while (true);
    }

    protected final String parseLongName(int n2, int n3, int n4) {
        this._quadBuffer[0] = this._quad1;
        this._quadBuffer[1] = n3;
        this._quadBuffer[2] = n4;
        byte[] arrby = this._inputBuffer;
        int[] arrn = _icLatin1;
        n4 = 3;
        n3 = n2;
        n2 = n4;
        while (this._inputPtr + 4 <= this._inputEnd) {
            n4 = this._inputPtr;
            this._inputPtr = n4 + 1;
            if (arrn[n4 = arrby[n4] & 255] != 0) {
                if (n4 == 34) {
                    return this.findName(this._quadBuffer, n2, n3, 1);
                }
                return this.parseEscapedName(this._quadBuffer, n2, n3, n4, 1);
            }
            n3 = n3 << 8 | n4;
            n4 = this._inputPtr;
            this._inputPtr = n4 + 1;
            if (arrn[n4 = arrby[n4] & 255] != 0) {
                if (n4 == 34) {
                    return this.findName(this._quadBuffer, n2, n3, 2);
                }
                return this.parseEscapedName(this._quadBuffer, n2, n3, n4, 2);
            }
            n3 = n3 << 8 | n4;
            n4 = this._inputPtr;
            this._inputPtr = n4 + 1;
            if (arrn[n4 = arrby[n4] & 255] != 0) {
                if (n4 == 34) {
                    return this.findName(this._quadBuffer, n2, n3, 3);
                }
                return this.parseEscapedName(this._quadBuffer, n2, n3, n4, 3);
            }
            n4 = n3 << 8 | n4;
            n3 = this._inputPtr;
            this._inputPtr = n3 + 1;
            if (arrn[n3 = arrby[n3] & 255] != 0) {
                if (n3 == 34) {
                    return this.findName(this._quadBuffer, n2, n4, 4);
                }
                return this.parseEscapedName(this._quadBuffer, n2, n4, n3, 4);
            }
            if (n2 >= this._quadBuffer.length) {
                this._quadBuffer = UTF8StreamJsonParser.growArrayBy(this._quadBuffer, n2);
            }
            this._quadBuffer[n2] = n4;
            ++n2;
        }
        return this.parseEscapedName(this._quadBuffer, n2, 0, n3, 0);
    }

    protected final String parseMediumName(int n2) {
        byte[] arrby = this._inputBuffer;
        int[] arrn = _icLatin1;
        int n3 = this._inputPtr;
        this._inputPtr = n3 + 1;
        if (arrn[n3 = arrby[n3] & 255] != 0) {
            if (n3 == 34) {
                return this.findName(this._quad1, n2, 1);
            }
            return this.parseName(this._quad1, n2, n3, 1);
        }
        n2 = n3 | n2 << 8;
        n3 = this._inputPtr;
        this._inputPtr = n3 + 1;
        if (arrn[n3 = arrby[n3] & 255] != 0) {
            if (n3 == 34) {
                return this.findName(this._quad1, n2, 2);
            }
            return this.parseName(this._quad1, n2, n3, 2);
        }
        n2 = n2 << 8 | n3;
        n3 = this._inputPtr;
        this._inputPtr = n3 + 1;
        if (arrn[n3 = arrby[n3] & 255] != 0) {
            if (n3 == 34) {
                return this.findName(this._quad1, n2, 3);
            }
            return this.parseName(this._quad1, n2, n3, 3);
        }
        n2 = n2 << 8 | n3;
        n3 = this._inputPtr;
        this._inputPtr = n3 + 1;
        if (arrn[n3 = arrby[n3] & 255] != 0) {
            if (n3 == 34) {
                return this.findName(this._quad1, n2, 4);
            }
            return this.parseName(this._quad1, n2, n3, 4);
        }
        return this.parseMediumName2(n3, n2);
    }

    protected final String parseMediumName2(int n2, int n3) {
        byte[] arrby = this._inputBuffer;
        int[] arrn = _icLatin1;
        int n4 = this._inputPtr;
        this._inputPtr = n4 + 1;
        if (arrn[n4 = arrby[n4] & 255] != 0) {
            if (n4 == 34) {
                return this.findName(this._quad1, n3, n2, 1);
            }
            return this.parseName(this._quad1, n3, n2, n4, 1);
        }
        n2 = n2 << 8 | n4;
        n4 = this._inputPtr;
        this._inputPtr = n4 + 1;
        if (arrn[n4 = arrby[n4] & 255] != 0) {
            if (n4 == 34) {
                return this.findName(this._quad1, n3, n2, 2);
            }
            return this.parseName(this._quad1, n3, n2, n4, 2);
        }
        n2 = n2 << 8 | n4;
        n4 = this._inputPtr;
        this._inputPtr = n4 + 1;
        if (arrn[n4 = arrby[n4] & 255] != 0) {
            if (n4 == 34) {
                return this.findName(this._quad1, n3, n2, 3);
            }
            return this.parseName(this._quad1, n3, n2, n4, 3);
        }
        n2 = n2 << 8 | n4;
        n4 = this._inputPtr;
        this._inputPtr = n4 + 1;
        if (arrn[n4 = arrby[n4] & 255] != 0) {
            if (n4 == 34) {
                return this.findName(this._quad1, n3, n2, 4);
            }
            return this.parseName(this._quad1, n3, n2, n4, 4);
        }
        return this.parseLongName(n4, n3, n2);
    }

    protected String slowParseName() {
        if (this._inputPtr >= this._inputEnd && !this.loadMore()) {
            this._reportInvalidEOF(": was expecting closing '\"' for name");
        }
        byte[] arrby = this._inputBuffer;
        int n2 = this._inputPtr;
        this._inputPtr = n2 + 1;
        if ((n2 = arrby[n2] & 255) == 34) {
            return "";
        }
        return this.parseEscapedName(this._quadBuffer, 0, 0, n2, 0);
    }
}

