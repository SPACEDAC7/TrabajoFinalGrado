/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.PrettyPrinter;
import com.fasterxml.jackson.core.SerializableString;
import com.fasterxml.jackson.core.io.CharTypes;
import com.fasterxml.jackson.core.io.CharacterEscapes;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.io.NumberOutput;
import com.fasterxml.jackson.core.json.JsonGeneratorImpl;
import com.fasterxml.jackson.core.json.JsonWriteContext;
import java.io.Writer;

public final class WriterBasedJsonGenerator
extends JsonGeneratorImpl {
    protected static final char[] HEX_CHARS = CharTypes.copyHexChars();
    protected SerializableString _currentEscape;
    protected char[] _entityBuffer;
    protected char[] _outputBuffer;
    protected int _outputEnd;
    protected int _outputHead;
    protected int _outputTail;
    protected final Writer _writer;

    public WriterBasedJsonGenerator(IOContext iOContext, int n2, ObjectCodec objectCodec, Writer writer) {
        super(iOContext, n2, objectCodec);
        this._writer = writer;
        this._outputBuffer = iOContext.allocConcatBuffer();
        this._outputEnd = this._outputBuffer.length;
    }

    private char[] _allocateEntityBuffer() {
        char[] arrc = new char[14];
        arrc[0] = 92;
        arrc[2] = 92;
        arrc[3] = 117;
        arrc[4] = 48;
        arrc[5] = 48;
        arrc[8] = 92;
        arrc[9] = 117;
        this._entityBuffer = arrc;
        return arrc;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int _prependOrWriteCharacterEscape(char[] arrc, int n2, int n3, char c2, int n4) {
        String string;
        if (n4 >= 0) {
            char[] arrc2;
            if (n2 > 1 && n2 < n3) {
                arrc[n2 -= 2] = 92;
                arrc[n2 + 1] = (char)n4;
                return n2;
            }
            arrc = arrc2 = this._entityBuffer;
            if (arrc2 == null) {
                arrc = this._allocateEntityBuffer();
            }
            arrc[1] = (char)n4;
            this._writer.write(arrc, 0, 2);
            return n2;
        }
        if (n4 != -2) {
            char[] arrc3;
            if (n2 > 5 && n2 < n3) {
                n3 = (n2 -= 6) + 1;
                arrc[n2] = 92;
                n2 = n3 + 1;
                arrc[n3] = 117;
                if (c2 > '\u00ff') {
                    n3 = c2 >> 8 & 255;
                    n4 = n2 + 1;
                    arrc[n2] = HEX_CHARS[n3 >> 4];
                    n2 = n4 + 1;
                    arrc[n4] = HEX_CHARS[n3 & 15];
                    c2 = (char)(c2 & 255);
                } else {
                    n3 = n2 + 1;
                    arrc[n2] = 48;
                    n2 = n3 + 1;
                    arrc[n3] = 48;
                }
                n3 = n2 + 1;
                arrc[n2] = HEX_CHARS[c2 >> 4];
                arrc[n3] = HEX_CHARS[c2 & 15];
                return n3 - 5;
            }
            arrc = arrc3 = this._entityBuffer;
            if (arrc3 == null) {
                arrc = this._allocateEntityBuffer();
            }
            this._outputHead = this._outputTail;
            if (c2 > '\u00ff') {
                n3 = c2 >> 8 & 255;
                c2 = (char)(c2 & 255);
                arrc[10] = HEX_CHARS[n3 >> 4];
                arrc[11] = HEX_CHARS[n3 & 15];
                arrc[12] = HEX_CHARS[c2 >> 4];
                arrc[13] = HEX_CHARS[c2 & 15];
                this._writer.write(arrc, 8, 6);
                return n2;
            }
            arrc[6] = HEX_CHARS[c2 >> 4];
            arrc[7] = HEX_CHARS[c2 & 15];
            this._writer.write(arrc, 2, 6);
            return n2;
        }
        if (this._currentEscape == null) {
            string = this._characterEscapes.getEscapeSequence(c2).getValue();
        } else {
            string = this._currentEscape.getValue();
            this._currentEscape = null;
        }
        if (n2 >= (c2 = (char)string.length()) && n2 < n3) {
            string.getChars(0, c2, arrc, n2 -= c2);
            return n2;
        }
        this._writer.write(string);
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void _prependOrWriteCharacterEscape(char c2, int n2) {
        String string;
        if (n2 >= 0) {
            char[] arrc;
            if (this._outputTail >= 2) {
                c2 = (char)(this._outputTail - 2);
                this._outputHead = c2;
                this._outputBuffer[c2] = 92;
                this._outputBuffer[c2 + '\u0001'] = (char)n2;
                return;
            }
            char[] arrc2 = arrc = this._entityBuffer;
            if (arrc == null) {
                arrc2 = this._allocateEntityBuffer();
            }
            this._outputHead = this._outputTail;
            arrc2[1] = (char)n2;
            this._writer.write(arrc2, 0, 2);
            return;
        }
        if (n2 != -2) {
            char[] arrc;
            if (this._outputTail >= 6) {
                char[] arrc3 = this._outputBuffer;
                n2 = this._outputTail - 6;
                this._outputHead = n2++;
                arrc3[n2] = 92;
                arrc3[n2] = 117;
                if (c2 > '\u00ff') {
                    int n3 = c2 >> 8 & 255;
                    arrc3[++n2] = HEX_CHARS[n3 >> 4];
                    arrc3[++n2] = HEX_CHARS[n3 & 15];
                    c2 = (char)(c2 & 255);
                } else {
                    arrc3[++n2] = 48;
                    arrc3[++n2] = 48;
                }
                arrc3[++n2] = HEX_CHARS[c2 >> 4];
                arrc3[n2 + 1] = HEX_CHARS[c2 & 15];
                return;
            }
            char[] arrc4 = arrc = this._entityBuffer;
            if (arrc == null) {
                arrc4 = this._allocateEntityBuffer();
            }
            this._outputHead = this._outputTail;
            if (c2 > '\u00ff') {
                n2 = c2 >> 8 & 255;
                c2 = (char)(c2 & 255);
                arrc4[10] = HEX_CHARS[n2 >> 4];
                arrc4[11] = HEX_CHARS[n2 & 15];
                arrc4[12] = HEX_CHARS[c2 >> 4];
                arrc4[13] = HEX_CHARS[c2 & 15];
                this._writer.write(arrc4, 8, 6);
                return;
            }
            arrc4[6] = HEX_CHARS[c2 >> 4];
            arrc4[7] = HEX_CHARS[c2 & 15];
            this._writer.write(arrc4, 2, 6);
            return;
        }
        if (this._currentEscape == null) {
            string = this._characterEscapes.getEscapeSequence(c2).getValue();
        } else {
            string = this._currentEscape.getValue();
            this._currentEscape = null;
        }
        if (this._outputTail >= (c2 = (char)string.length())) {
            this._outputHead = n2 = this._outputTail - c2;
            string.getChars(0, c2, this._outputBuffer, n2);
            return;
        }
        this._outputHead = this._outputTail;
        this._writer.write(string);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void _writeLongString(String string) {
        int n2;
        this._flushBuffer();
        int n3 = string.length();
        int n4 = 0;
        do {
            int n5;
            n2 = n5 = this._outputEnd;
            if (n4 + n5 > n3) {
                n2 = n3 - n4;
            }
            string.getChars(n4, n4 + n2, this._outputBuffer, 0);
            if (this._characterEscapes != null) {
                this._writeSegmentCustom(n2);
            } else if (this._maximumNonEscapedChar != 0) {
                this._writeSegmentASCII(n2, this._maximumNonEscapedChar);
            } else {
                this._writeSegment(n2);
            }
            n4 = n2 = n4 + n2;
        } while (n2 < n3);
    }

    private final void _writeNull() {
        if (this._outputTail + 4 >= this._outputEnd) {
            this._flushBuffer();
        }
        int n2 = this._outputTail;
        char[] arrc = this._outputBuffer;
        arrc[n2] = 110;
        arrc[++n2] = 117;
        arrc[++n2] = 108;
        arrc[++n2] = 108;
        this._outputTail = n2 + 1;
    }

    private void _writeQuotedLong(long l2) {
        if (this._outputTail + 23 >= this._outputEnd) {
            this._flushBuffer();
        }
        char[] arrc = this._outputBuffer;
        int n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc[n2] = 34;
        this._outputTail = NumberOutput.outputLong(l2, this._outputBuffer, this._outputTail);
        arrc = this._outputBuffer;
        n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc[n2] = 34;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void _writeSegment(int n2) {
        int[] arrn = this._outputEscapes;
        int n3 = arrn.length;
        int n4 = 0;
        int n5 = 0;
        while (n4 < n2) {
            char c2;
            int n6;
            while ((c2 = this._outputBuffer[n4]) >= n3 || arrn[c2] == 0) {
                n4 = n6 = n4 + 1;
                if (n6 < n2) continue;
                n4 = n6;
                break;
            }
            if ((n6 = n4 - n5) > 0) {
                this._writer.write(this._outputBuffer, n5, n6);
                if (n4 >= n2) {
                    return;
                }
            }
            n5 = this._prependOrWriteCharacterEscape(this._outputBuffer, ++n4, n2, c2, arrn[c2]);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void _writeSegmentASCII(int n2, int n3) {
        int n4 = 0;
        int[] arrn = this._outputEscapes;
        int n5 = Math.min(arrn.length, n3 + 1);
        int n6 = 0;
        int n7 = 0;
        while (n7 < n2) {
            char c2;
            int n8;
            block8 : {
                int n9 = n4;
                do {
                    if ((c2 = this._outputBuffer[n7]) < n5) {
                        n4 = arrn[c2];
                        if (n4 != 0) {
                            break block8;
                        }
                    } else {
                        n4 = n9;
                        if (c2 > n3) {
                            n4 = -1;
                            break block8;
                        }
                    }
                    n8 = n7 + 1;
                    n9 = n4;
                    n7 = n8;
                } while (n8 < n2);
                n7 = n8;
            }
            if ((n8 = n7 - n6) > 0) {
                this._writer.write(this._outputBuffer, n6, n8);
                if (n7 >= n2) {
                    return;
                }
            }
            n6 = this._prependOrWriteCharacterEscape(this._outputBuffer, ++n7, n2, c2, n4);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void _writeSegmentCustom(int n2) {
        int n3 = 0;
        int[] arrn = this._outputEscapes;
        char c2 = this._maximumNonEscapedChar < 1 ? '\uffff' : this._maximumNonEscapedChar;
        int n4 = Math.min(arrn.length, c2 + 1);
        CharacterEscapes characterEscapes = this._characterEscapes;
        int n5 = 0;
        int n6 = 0;
        while (n3 < n2) {
            int n7;
            char c3;
            block9 : {
                int n8 = n6;
                do {
                    if ((c3 = this._outputBuffer[n3]) < n4) {
                        n6 = arrn[c3];
                        if (n6 != 0) {
                            break block9;
                        }
                    } else {
                        SerializableString serializableString;
                        if (c3 > c2) {
                            n6 = -1;
                            break block9;
                        }
                        this._currentEscape = serializableString = characterEscapes.getEscapeSequence(c3);
                        n6 = n8;
                        if (serializableString != null) {
                            n6 = -2;
                            break block9;
                        }
                    }
                    n7 = n3 + 1;
                    n8 = n6;
                    n3 = n7;
                } while (n7 < n2);
                n3 = n7;
            }
            if ((n7 = n3 - n5) > 0) {
                this._writer.write(this._outputBuffer, n5, n7);
                if (n3 >= n2) {
                    return;
                }
            }
            n5 = this._prependOrWriteCharacterEscape(this._outputBuffer, ++n3, n2, c3, n6);
        }
    }

    private void _writeString(String string) {
        int n2 = string.length();
        if (n2 > this._outputEnd) {
            this._writeLongString(string);
            return;
        }
        if (this._outputTail + n2 > this._outputEnd) {
            this._flushBuffer();
        }
        string.getChars(0, n2, this._outputBuffer, this._outputTail);
        if (this._characterEscapes != null) {
            this._writeStringCustom(n2);
            return;
        }
        if (this._maximumNonEscapedChar != 0) {
            this._writeStringASCII(n2, this._maximumNonEscapedChar);
            return;
        }
        this._writeString2(n2);
    }

    private void _writeString2(int n2) {
        n2 = this._outputTail + n2;
        int[] arrn = this._outputEscapes;
        int n3 = arrn.length;
        block0 : while (this._outputTail < n2) {
            int n4;
            do {
                if ((n4 = this._outputBuffer[this._outputTail]) < n3 && arrn[n4] != 0) {
                    n4 = this._outputTail - this._outputHead;
                    if (n4 > 0) {
                        this._writer.write(this._outputBuffer, this._outputHead, n4);
                    }
                    char[] arrc = this._outputBuffer;
                    n4 = this._outputTail;
                    this._outputTail = n4 + 1;
                    char c2 = arrc[n4];
                    this._prependOrWriteCharacterEscape(c2, arrn[c2]);
                    continue block0;
                }
                this._outputTail = n4 = this._outputTail + 1;
            } while (n4 < n2);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void _writeStringASCII(int var1_1, int var2_2) {
        var4_3 = this._outputTail + var1_1;
        var7_4 = this._outputEscapes;
        var5_5 = Math.min(var7_4.length, var2_2 + 1);
        block0 : do {
            if (this._outputTail >= var4_3) return;
            do {
                if ((var3_6 = this._outputBuffer[this._outputTail]) >= var5_5) ** GOTO lbl11
                var1_1 = var7_4[var3_6];
                if (var1_1 == 0) ** GOTO lbl18
                ** GOTO lbl13
lbl11: // 1 sources:
                if (var3_6 > var2_2) {
                    var1_1 = -1;
lbl13: // 2 sources:
                    if ((var6_7 = this._outputTail - this._outputHead) > 0) {
                        this._writer.write(this._outputBuffer, this._outputHead, var6_7);
                    }
                    ++this._outputTail;
                    this._prependOrWriteCharacterEscape(var3_6, var1_1);
                    continue block0;
                }
lbl18: // 3 sources:
                this._outputTail = var1_1 = this._outputTail + 1;
            } while (var1_1 < var4_3);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void _writeStringCustom(int var1_1) {
        var4_2 = this._outputTail + var1_1;
        var7_3 = this._outputEscapes;
        var3_4 = this._maximumNonEscapedChar < 1 ? '\uffff' : this._maximumNonEscapedChar;
        var5_5 = Math.min(var7_3.length, var3_4 + 1);
        var8_6 = this._characterEscapes;
        block0 : do {
            if (this._outputTail >= var4_2) return;
            do {
                if ((var2_7 = this._outputBuffer[this._outputTail]) >= var5_5) ** GOTO lbl13
                var1_1 = var7_3[var2_7];
                if (var1_1 == 0) ** GOTO lbl24
                ** GOTO lbl19
lbl13: // 1 sources:
                if (var2_7 <= var3_4) ** GOTO lbl16
                var1_1 = -1;
                ** GOTO lbl19
lbl16: // 1 sources:
                this._currentEscape = var9_9 = var8_6.getEscapeSequence(var2_7);
                if (var9_9 != null) {
                    var1_1 = -2;
lbl19: // 3 sources:
                    if ((var6_8 = this._outputTail - this._outputHead) > 0) {
                        this._writer.write(this._outputBuffer, this._outputHead, var6_8);
                    }
                    ++this._outputTail;
                    this._prependOrWriteCharacterEscape(var2_7, var1_1);
                    continue block0;
                }
lbl24: // 3 sources:
                this._outputTail = var1_1 = this._outputTail + 1;
            } while (var1_1 < var4_2);
            break;
        } while (true);
    }

    private void writeRawLong(String string) {
        int n2;
        int n3;
        int n4 = this._outputEnd - this._outputTail;
        string.getChars(0, n4, this._outputBuffer, this._outputTail);
        this._outputTail += n4;
        this._flushBuffer();
        for (n3 = string.length() - n4; n3 > this._outputEnd; n3 -= n2) {
            n2 = this._outputEnd;
            string.getChars(n4, n4 + n2, this._outputBuffer, 0);
            this._outputHead = 0;
            this._outputTail = n2;
            this._flushBuffer();
            n4 += n2;
        }
        string.getChars(n4, n4 + n3, this._outputBuffer, 0);
        this._outputHead = 0;
        this._outputTail = n3;
    }

    protected void _flushBuffer() {
        int n2 = this._outputTail - this._outputHead;
        if (n2 > 0) {
            int n3 = this._outputHead;
            this._outputHead = 0;
            this._outputTail = 0;
            this._writer.write(this._outputBuffer, n3, n2);
        }
    }

    @Override
    protected void _releaseBuffers() {
        char[] arrc = this._outputBuffer;
        if (arrc != null) {
            this._outputBuffer = null;
            this._ioContext.releaseConcatBuffer(arrc);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void _verifyPrettyValueWrite(String string) {
        int n2 = this._writeContext.writeValue();
        if (n2 == 5) {
            this._reportError("Can not " + string + ", expecting field name");
        }
        switch (n2) {
            default: {
                this._throwInternal();
                return;
            }
            case 1: {
                this._cfgPrettyPrinter.writeArrayValueSeparator(this);
                return;
            }
            case 2: {
                this._cfgPrettyPrinter.writeObjectFieldValueSeparator(this);
                return;
            }
            case 3: {
                this._cfgPrettyPrinter.writeRootValueSeparator(this);
                return;
            }
            case 0: {
                if (this._writeContext.inArray()) {
                    this._cfgPrettyPrinter.beforeArrayValues(this);
                    return;
                }
                if (!this._writeContext.inObject()) return;
                this._cfgPrettyPrinter.beforeObjectEntries(this);
                return;
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected void _verifyValueWrite(String var1_1) {
        if (this._cfgPrettyPrinter != null) {
            this._verifyPrettyValueWrite(var1_1);
            return;
        }
        var3_2 = this._writeContext.writeValue();
        if (var3_2 == 5) {
            this._reportError("Can not " + var1_1 + ", expecting field name");
        }
        switch (var3_2) {
            default: {
                return;
            }
            case 1: {
                var2_3 = 44;
                ** GOTO lbl15
            }
            case 2: {
                var2_3 = 58;
lbl15: // 2 sources:
                if (this._outputTail >= this._outputEnd) {
                    this._flushBuffer();
                }
                this._outputBuffer[this._outputTail] = var2_3;
                ++this._outputTail;
                return;
            }
            case 3: 
        }
        if (this._rootValueSeparator == null) return;
        this.writeRaw(this._rootValueSeparator.getValue());
    }

    protected void _writeFieldName(String arrc, boolean bl2) {
        char[] arrc2;
        int n2;
        if (this._cfgPrettyPrinter != null) {
            this._writePPFieldName((String)arrc, bl2);
            return;
        }
        if (this._outputTail + 1 >= this._outputEnd) {
            this._flushBuffer();
        }
        if (bl2) {
            arrc2 = this._outputBuffer;
            n2 = this._outputTail;
            this._outputTail = n2 + 1;
            arrc2[n2] = 44;
        }
        if (this._cfgUnqNames) {
            this._writeString((String)arrc);
            return;
        }
        arrc2 = this._outputBuffer;
        n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc2[n2] = 34;
        this._writeString((String)arrc);
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        arrc = this._outputBuffer;
        n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc[n2] = 34;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void _writePPFieldName(String arrc, boolean bl2) {
        if (bl2) {
            this._cfgPrettyPrinter.writeObjectEntrySeparator(this);
        } else {
            this._cfgPrettyPrinter.beforeObjectEntries(this);
        }
        if (this._cfgUnqNames) {
            this._writeString((String)arrc);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        char[] arrc2 = this._outputBuffer;
        int n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc2[n2] = 34;
        this._writeString((String)arrc);
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        arrc = this._outputBuffer;
        n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc[n2] = 34;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void close() {
        super.close();
        if (this._outputBuffer != null && this.isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT)) {
            do {
                JsonWriteContext jsonWriteContext;
                if ((jsonWriteContext = this.getOutputContext()).inArray()) {
                    this.writeEndArray();
                    continue;
                }
                if (!jsonWriteContext.inObject()) break;
                this.writeEndObject();
            } while (true);
        }
        this._flushBuffer();
        this._outputHead = 0;
        this._outputTail = 0;
        if (this._writer != null) {
            if (this._ioContext.isResourceManaged() || this.isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET)) {
                this._writer.close();
            } else if (this.isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
                this._writer.flush();
            }
        }
        this._releaseBuffers();
    }

    @Override
    public void flush() {
        this._flushBuffer();
        if (this._writer != null && this.isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
            this._writer.flush();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void writeBoolean(boolean bl2) {
        this._verifyValueWrite("write a boolean value");
        if (this._outputTail + 5 >= this._outputEnd) {
            this._flushBuffer();
        }
        int n2 = this._outputTail;
        char[] arrc = this._outputBuffer;
        if (bl2) {
            arrc[n2] = 116;
            arrc[++n2] = 114;
            arrc[++n2] = 117;
            arrc[++n2] = 101;
        } else {
            arrc[n2] = 102;
            arrc[++n2] = 97;
            arrc[++n2] = 108;
            arrc[++n2] = 115;
            arrc[++n2] = 101;
        }
        this._outputTail = n2 + 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void writeEndArray() {
        if (!this._writeContext.inArray()) {
            this._reportError("Current context not an ARRAY but " + this._writeContext.getTypeDesc());
        }
        if (this._cfgPrettyPrinter != null) {
            this._cfgPrettyPrinter.writeEndArray(this, this._writeContext.getEntryCount());
        } else {
            if (this._outputTail >= this._outputEnd) {
                this._flushBuffer();
            }
            char[] arrc = this._outputBuffer;
            int n2 = this._outputTail;
            this._outputTail = n2 + 1;
            arrc[n2] = 93;
        }
        this._writeContext = this._writeContext.clearAndGetParent();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void writeEndObject() {
        if (!this._writeContext.inObject()) {
            this._reportError("Current context not an object but " + this._writeContext.getTypeDesc());
        }
        if (this._cfgPrettyPrinter != null) {
            this._cfgPrettyPrinter.writeEndObject(this, this._writeContext.getEntryCount());
        } else {
            if (this._outputTail >= this._outputEnd) {
                this._flushBuffer();
            }
            char[] arrc = this._outputBuffer;
            int n2 = this._outputTail;
            this._outputTail = n2 + 1;
            arrc[n2] = 125;
        }
        this._writeContext = this._writeContext.clearAndGetParent();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void writeFieldName(String string) {
        boolean bl2 = true;
        int n2 = this._writeContext.writeFieldName(string);
        if (n2 == 4) {
            this._reportError("Can not write a field name, expecting a value");
        }
        if (n2 != 1) {
            bl2 = false;
        }
        this._writeFieldName(string, bl2);
    }

    @Override
    public void writeNull() {
        this._verifyValueWrite("write a null");
        this._writeNull();
    }

    @Override
    public void writeNumber(double d2) {
        if (this._cfgNumbersAsStrings || this.isEnabled(JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS) && (Double.isNaN(d2) || Double.isInfinite(d2))) {
            this.writeString(String.valueOf(d2));
            return;
        }
        this._verifyValueWrite("write a number");
        this.writeRaw(String.valueOf(d2));
    }

    @Override
    public void writeNumber(long l2) {
        this._verifyValueWrite("write a number");
        if (this._cfgNumbersAsStrings) {
            this._writeQuotedLong(l2);
            return;
        }
        if (this._outputTail + 21 >= this._outputEnd) {
            this._flushBuffer();
        }
        this._outputTail = NumberOutput.outputLong(l2, this._outputBuffer, this._outputTail);
    }

    @Override
    public void writeRaw(char c2) {
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        char[] arrc = this._outputBuffer;
        int n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc[n2] = c2;
    }

    @Override
    public void writeRaw(SerializableString serializableString) {
        this.writeRaw(serializableString.getValue());
    }

    @Override
    public void writeRaw(String string) {
        int n2;
        int n3 = string.length();
        int n4 = n2 = this._outputEnd - this._outputTail;
        if (n2 == 0) {
            this._flushBuffer();
            n4 = this._outputEnd - this._outputTail;
        }
        if (n4 >= n3) {
            string.getChars(0, n3, this._outputBuffer, this._outputTail);
            this._outputTail += n3;
            return;
        }
        this.writeRawLong(string);
    }

    @Override
    public void writeRaw(char[] arrc, int n2, int n3) {
        if (n3 < 32) {
            if (n3 > this._outputEnd - this._outputTail) {
                this._flushBuffer();
            }
            System.arraycopy(arrc, n2, this._outputBuffer, this._outputTail, n3);
            this._outputTail += n3;
            return;
        }
        this._flushBuffer();
        this._writer.write(arrc, n2, n3);
    }

    @Override
    public void writeStartArray() {
        this._verifyValueWrite("start an array");
        this._writeContext = this._writeContext.createChildArrayContext();
        if (this._cfgPrettyPrinter != null) {
            this._cfgPrettyPrinter.writeStartArray(this);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        char[] arrc = this._outputBuffer;
        int n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc[n2] = 91;
    }

    @Override
    public void writeStartObject() {
        this._verifyValueWrite("start an object");
        this._writeContext = this._writeContext.createChildObjectContext();
        if (this._cfgPrettyPrinter != null) {
            this._cfgPrettyPrinter.writeStartObject(this);
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        char[] arrc = this._outputBuffer;
        int n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc[n2] = 123;
    }

    @Override
    public void writeString(String arrc) {
        this._verifyValueWrite("write a string");
        if (arrc == null) {
            this._writeNull();
            return;
        }
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        char[] arrc2 = this._outputBuffer;
        int n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc2[n2] = 34;
        this._writeString((String)arrc);
        if (this._outputTail >= this._outputEnd) {
            this._flushBuffer();
        }
        arrc = this._outputBuffer;
        n2 = this._outputTail;
        this._outputTail = n2 + 1;
        arrc[n2] = 34;
    }
}

