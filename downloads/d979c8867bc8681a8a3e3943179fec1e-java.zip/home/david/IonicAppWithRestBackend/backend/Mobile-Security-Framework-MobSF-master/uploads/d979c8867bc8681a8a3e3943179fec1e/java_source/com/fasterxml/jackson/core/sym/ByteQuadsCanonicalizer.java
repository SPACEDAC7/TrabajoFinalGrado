/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.sym;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.util.InternCache;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;

public final class ByteQuadsCanonicalizer {
    protected int _count;
    protected final boolean _failOnDoS;
    protected int[] _hashArea;
    private boolean _hashShared;
    protected int _hashSize;
    protected boolean _intern;
    protected int _longNameOffset;
    protected String[] _names;
    private transient boolean _needRehash;
    protected final ByteQuadsCanonicalizer _parent;
    protected int _secondaryStart;
    private final int _seed;
    protected int _spilloverEnd;
    protected final AtomicReference<TableInfo> _tableInfo;
    protected int _tertiaryShift;
    protected int _tertiaryStart;

    /*
     * Enabled aggressive block sorting
     */
    private ByteQuadsCanonicalizer(int n2, boolean bl2, int n3, boolean bl3) {
        int n4 = 16;
        this._parent = null;
        this._seed = n3;
        this._intern = bl2;
        this._failOnDoS = bl3;
        if (n2 < 16) {
            n3 = 16;
        } else {
            n3 = n2;
            if ((n2 - 1 & n2) != 0) {
                for (n3 = n4; n3 < n2; n3 += n3) {
                }
            }
        }
        this._tableInfo = new AtomicReference<TableInfo>(TableInfo.createInitial(n3));
    }

    private ByteQuadsCanonicalizer(ByteQuadsCanonicalizer byteQuadsCanonicalizer, boolean bl2, int n2, boolean bl3, TableInfo tableInfo) {
        this._parent = byteQuadsCanonicalizer;
        this._seed = n2;
        this._intern = bl2;
        this._failOnDoS = bl3;
        this._tableInfo = null;
        this._count = tableInfo.count;
        this._hashSize = tableInfo.size;
        this._secondaryStart = this._hashSize << 2;
        this._tertiaryStart = this._secondaryStart + (this._secondaryStart >> 1);
        this._tertiaryShift = tableInfo.tertiaryShift;
        this._hashArea = tableInfo.mainHash;
        this._names = tableInfo.names;
        this._spilloverEnd = tableInfo.spilloverEnd;
        this._longNameOffset = tableInfo.longNameOffset;
        this._needRehash = false;
        this._hashShared = true;
    }

    private int _appendLongName(int[] arrn, int n2) {
        int n3 = this._longNameOffset;
        if (n3 + n2 > this._hashArea.length) {
            int n4 = this._hashArea.length;
            int n5 = Math.min(4096, this._hashSize);
            int n6 = this._hashArea.length;
            n4 = Math.max(n3 + n2 - n4, n5);
            this._hashArea = Arrays.copyOf(this._hashArea, n4 + n6);
        }
        System.arraycopy(arrn, 0, this._hashArea, n3, n2);
        this._longNameOffset += n2;
        return n3;
    }

    private final int _calcOffset(int n2) {
        return (this._hashSize - 1 & n2) << 2;
    }

    static int _calcTertiaryShift(int n2) {
        if ((n2 >>= 2) < 64) {
            return 4;
        }
        if (n2 <= 256) {
            return 5;
        }
        if (n2 <= 1024) {
            return 6;
        }
        return 7;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int _findOffsetForAdd(int n2) {
        int[] arrn = this._hashArea;
        if (arrn[(n2 = this._calcOffset(n2)) + 3] == 0) return n2;
        int n3 = this._secondaryStart + (n2 >> 3 << 2);
        if (arrn[n3 + 3] == 0) {
            return n3;
        }
        n3 = this._tertiaryStart;
        int n4 = (n2 >> this._tertiaryShift + 2 << this._tertiaryShift) + n3;
        int n5 = this._tertiaryShift;
        n2 = n4;
        while ((n3 = n2) < (1 << n5) + n4) {
            n2 = n3;
            if (arrn[n3 + 3] == 0) return n2;
            {
                n2 = n3 + 4;
                continue;
            }
        }
        n3 = this._spilloverEnd;
        this._spilloverEnd += 4;
        n4 = this._hashSize;
        n2 = n3;
        if (this._spilloverEnd < n4 << 3) {
            return n2;
        }
        if (this._failOnDoS) {
            this._reportTooManyCollisions();
        }
        this._needRehash = true;
        return n3;
    }

    private String _findSecondary(int n2, int n3) {
        int n4 = this._tertiaryStart + (n2 >> this._tertiaryShift + 2 << this._tertiaryShift);
        int[] arrn = this._hashArea;
        int n5 = this._tertiaryShift;
        for (n2 = n4; n2 < (1 << n5) + n4; n2 += 4) {
            int n6 = arrn[n2 + 3];
            if (n3 == arrn[n2] && 1 == n6) {
                return this._names[n2 >> 2];
            }
            if (n6 != 0) continue;
            return null;
        }
        for (n2 = this._spilloverStart(); n2 < this._spilloverEnd; n2 += 4) {
            if (n3 != arrn[n2] || 1 != arrn[n2 + 3]) continue;
            return this._names[n2 >> 2];
        }
        return null;
    }

    private String _findSecondary(int n2, int n3, int n4) {
        int n5 = this._tertiaryStart + (n2 >> this._tertiaryShift + 2 << this._tertiaryShift);
        int[] arrn = this._hashArea;
        int n6 = this._tertiaryShift;
        for (n2 = n5; n2 < (1 << n6) + n5; n2 += 4) {
            int n7 = arrn[n2 + 3];
            if (n3 == arrn[n2] && n4 == arrn[n2 + 1] && 2 == n7) {
                return this._names[n2 >> 2];
            }
            if (n7 != 0) continue;
            return null;
        }
        for (n2 = this._spilloverStart(); n2 < this._spilloverEnd; n2 += 4) {
            if (n3 != arrn[n2] || n4 != arrn[n2 + 1] || 2 != arrn[n2 + 3]) continue;
            return this._names[n2 >> 2];
        }
        return null;
    }

    private String _findSecondary(int n2, int n3, int n4, int n5) {
        int n6 = this._tertiaryStart + (n2 >> this._tertiaryShift + 2 << this._tertiaryShift);
        int[] arrn = this._hashArea;
        int n7 = this._tertiaryShift;
        for (n2 = n6; n2 < (1 << n7) + n6; n2 += 4) {
            int n8 = arrn[n2 + 3];
            if (n3 == arrn[n2] && n4 == arrn[n2 + 1] && n5 == arrn[n2 + 2] && 3 == n8) {
                return this._names[n2 >> 2];
            }
            if (n8 != 0) continue;
            return null;
        }
        for (n2 = this._spilloverStart(); n2 < this._spilloverEnd; n2 += 4) {
            if (n3 != arrn[n2] || n4 != arrn[n2 + 1] || n5 != arrn[n2 + 2] || 3 != arrn[n2 + 3]) continue;
            return this._names[n2 >> 2];
        }
        return null;
    }

    private String _findSecondary(int n2, int n3, int[] arrn, int n4) {
        int n5 = this._tertiaryStart + (n2 >> this._tertiaryShift + 2 << this._tertiaryShift);
        int[] arrn2 = this._hashArea;
        int n6 = this._tertiaryShift;
        for (n2 = n5; n2 < (1 << n6) + n5; n2 += 4) {
            int n7 = arrn2[n2 + 3];
            if (n3 == arrn2[n2] && n4 == n7 && this._verifyLongName(arrn, n4, arrn2[n2 + 1])) {
                return this._names[n2 >> 2];
            }
            if (n7 != 0) continue;
            return null;
        }
        for (n2 = this._spilloverStart(); n2 < this._spilloverEnd; n2 += 4) {
            if (n3 != arrn2[n2] || n4 != arrn2[n2 + 3] || !this._verifyLongName(arrn, n4, arrn2[n2 + 1])) continue;
            return this._names[n2 >> 2];
        }
        return null;
    }

    private final int _spilloverStart() {
        int n2 = this._hashSize;
        return (n2 << 3) - n2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private boolean _verifyLongName(int[] var1_1, int var2_2, int var3_3) {
        var7_4 = false;
        var8_5 = this._hashArea;
        switch (var2_2) {
            default: {
                return this._verifyLongName2(var1_1, var2_2, var3_3);
            }
            case 8: {
                var6_6 = var7_4;
                if (var1_1[0] != var8_5[var3_3]) return var6_6;
                ++var3_3;
                var2_2 = 1;
                ** GOTO lbl14
            }
            case 7: {
                var2_2 = 0;
lbl14: // 2 sources:
                var6_6 = var7_4;
                if (var1_1[var2_2] != var8_5[var3_3]) return var6_6;
                ++var3_3;
                ++var2_2;
                ** GOTO lbl21
            }
            case 6: {
                var2_2 = 0;
lbl21: // 2 sources:
                var6_6 = var7_4;
                if (var1_1[var2_2] != var8_5[var3_3]) return var6_6;
                ++var3_3;
                ++var2_2;
                ** GOTO lbl28
            }
            case 5: {
                var2_2 = 0;
lbl28: // 2 sources:
                var6_6 = var7_4;
                if (var1_1[var2_2] != var8_5[var3_3]) return var6_6;
                ++var3_3;
                ++var2_2;
                ** GOTO lbl35
            }
            case 4: 
        }
        var2_2 = 0;
lbl35: // 2 sources:
        var4_7 = var2_2 + 1;
        var5_8 = var1_1[var2_2];
        var2_2 = var3_3 + 1;
        var6_6 = var7_4;
        if (var5_8 != var8_5[var3_3]) return var6_6;
        var5_8 = var4_7 + 1;
        var4_7 = var1_1[var4_7];
        var3_3 = var2_2 + 1;
        var6_6 = var7_4;
        if (var4_7 != var8_5[var2_2]) return var6_6;
        var2_2 = var5_8 + 1;
        var4_7 = var1_1[var5_8];
        var5_8 = var3_3 + 1;
        var6_6 = var7_4;
        if (var4_7 != var8_5[var3_3]) return var6_6;
        var6_6 = var7_4;
        if (var1_1[var2_2] != var8_5[var5_8]) return var6_6;
        return true;
    }

    private boolean _verifyLongName2(int[] arrn, int n2, int n3) {
        int n4 = 0;
        int n5 = n3;
        n3 = n4;
        do {
            n4 = n3 + 1;
            if (arrn[n3] != this._hashArea[n5]) {
                return false;
            }
            if (n4 >= n2) {
                return true;
            }
            ++n5;
            n3 = n4;
        } while (true);
    }

    private void _verifyNeedForRehash() {
        if (this._count > this._hashSize >> 1 && (this._spilloverEnd - this._spilloverStart() >> 2 > this._count + 1 >> 7 || (double)this._count > (double)this._hashSize * 0.8)) {
            this._needRehash = true;
        }
    }

    private void _verifySharing() {
        if (this._hashShared) {
            this._hashArea = Arrays.copyOf(this._hashArea, this._hashArea.length);
            this._names = Arrays.copyOf(this._names, this._names.length);
            this._hashShared = false;
            this._verifyNeedForRehash();
        }
        if (this._needRehash) {
            this.rehash();
        }
    }

    public static ByteQuadsCanonicalizer createRoot() {
        long l2 = System.currentTimeMillis();
        int n2 = (int)l2;
        return ByteQuadsCanonicalizer.createRoot((int)(l2 >>> 32) + n2 | 1);
    }

    protected static ByteQuadsCanonicalizer createRoot(int n2) {
        return new ByteQuadsCanonicalizer(64, true, n2, true);
    }

    private void mergeChild(TableInfo tableInfo) {
        int n2 = tableInfo.count;
        TableInfo tableInfo2 = this._tableInfo.get();
        if (n2 == tableInfo2.count) {
            return;
        }
        if (n2 > 6000) {
            tableInfo = TableInfo.createInitial(64);
        }
        this._tableInfo.compareAndSet(tableInfo2, tableInfo);
    }

    private void nukeSymbols(boolean bl2) {
        this._count = 0;
        this._spilloverEnd = this._spilloverStart();
        this._longNameOffset = this._hashSize << 3;
        if (bl2) {
            Arrays.fill(this._hashArea, 0);
            Arrays.fill(this._names, null);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void rehash() {
        this._needRehash = false;
        this._hashShared = false;
        int[] arrn = this._hashArea;
        String[] arrstring = this._names;
        int n2 = this._hashSize;
        int n3 = this._count;
        int n4 = n2 + n2;
        int n5 = this._spilloverEnd;
        if (n4 > 65536) {
            this.nukeSymbols(true);
            return;
        }
        this._hashArea = new int[(n2 << 3) + arrn.length];
        this._hashSize = n4;
        this._secondaryStart = n4 << 2;
        this._tertiaryStart = this._secondaryStart + (this._secondaryStart >> 1);
        this._tertiaryShift = ByteQuadsCanonicalizer._calcTertiaryShift(n4);
        this._names = new String[arrstring.length << 1];
        this.nukeSymbols(false);
        int[] arrn2 = new int[16];
        n2 = 0;
        n4 = 0;
        do {
            if (n2 >= n5) {
                if (n4 == n3) return;
                throw new IllegalStateException("Failed rehash(): old count=" + n3 + ", copyCount=" + n4);
            }
            int n6 = arrn[n2 + 3];
            if (n6 != 0) {
                ++n4;
                String string = arrstring[n2 >> 2];
                switch (n6) {
                    default: {
                        int[] arrn3 = arrn2;
                        if (n6 > arrn2.length) {
                            arrn3 = new int[n6];
                        }
                        System.arraycopy(arrn, arrn[n2 + 1], arrn3, 0, n6);
                        this.addName(string, arrn3, n6);
                        arrn2 = arrn3;
                        break;
                    }
                    case 1: {
                        arrn2[0] = arrn[n2];
                        this.addName(string, arrn2, 1);
                        break;
                    }
                    case 2: {
                        arrn2[0] = arrn[n2];
                        arrn2[1] = arrn[n2 + 1];
                        this.addName(string, arrn2, 2);
                        break;
                    }
                    case 3: {
                        arrn2[0] = arrn[n2];
                        arrn2[1] = arrn[n2 + 1];
                        arrn2[2] = arrn[n2 + 2];
                        this.addName(string, arrn2, 3);
                    }
                }
            }
            n2 += 4;
        } while (true);
    }

    protected void _reportTooManyCollisions() {
        if (this._hashSize <= 1024) {
            return;
        }
        throw new IllegalStateException("Spill-over slots in symbol table with " + this._count + " entries, hash area of " + this._hashSize + " slots is now full (all " + (this._hashSize >> 3) + " slots -- suspect a DoS attack based on hash collisions." + " You can disable the check via `JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW`");
    }

    /*
     * Enabled aggressive block sorting
     */
    public String addName(String string, int[] arrn, int n2) {
        this._verifySharing();
        String string2 = string;
        if (this._intern) {
            string2 = InternCache.instance.intern(string);
        }
        switch (n2) {
            default: {
                int n3 = this.calcHash(arrn, n2);
                int n4 = this._findOffsetForAdd(n3);
                this._hashArea[n4] = n3;
                this._hashArea[n4 + 1] = n3 = this._appendLongName(arrn, n2);
                this._hashArea[n4 + 3] = n2;
                n2 = n4;
                break;
            }
            case 1: {
                n2 = this._findOffsetForAdd(this.calcHash(arrn[0]));
                this._hashArea[n2] = arrn[0];
                this._hashArea[n2 + 3] = 1;
                break;
            }
            case 2: {
                n2 = this._findOffsetForAdd(this.calcHash(arrn[0], arrn[1]));
                this._hashArea[n2] = arrn[0];
                this._hashArea[n2 + 1] = arrn[1];
                this._hashArea[n2 + 3] = 2;
                break;
            }
            case 3: {
                n2 = this._findOffsetForAdd(this.calcHash(arrn[0], arrn[1], arrn[2]));
                this._hashArea[n2] = arrn[0];
                this._hashArea[n2 + 1] = arrn[1];
                this._hashArea[n2 + 2] = arrn[2];
                this._hashArea[n2 + 3] = 3;
            }
        }
        this._names[n2 >> 2] = string2;
        ++this._count;
        this._verifyNeedForRehash();
        return string2;
    }

    public int calcHash(int n2) {
        n2 = this._seed ^ n2;
        n2 += n2 >>> 16;
        n2 ^= n2 << 3;
        return n2 + (n2 >>> 12);
    }

    public int calcHash(int n2, int n3) {
        n2 = (n2 >>> 15) + n2;
        n2 = (n2 ^ n2 >>> 9) + n3 * 33 ^ this._seed;
        n2 += n2 >>> 16;
        n2 ^= n2 >>> 4;
        return n2 + (n2 << 3);
    }

    public int calcHash(int n2, int n3, int n4) {
        n2 = this._seed ^ n2;
        n2 = ((n2 + (n2 >>> 9)) * 31 + n3) * 33;
        n2 = n2 + (n2 >>> 15) ^ n4;
        n2 += n2 >>> 4;
        n2 += n2 >>> 15;
        return n2 ^ n2 << 9;
    }

    public int calcHash(int[] arrn, int n2) {
        if (n2 < 4) {
            throw new IllegalArgumentException();
        }
        int n3 = arrn[0] ^ this._seed;
        n3 = n3 + (n3 >>> 9) + arrn[1];
        n3 = (n3 + (n3 >>> 15)) * 33 ^ arrn[2];
        int n4 = (n3 >>> 4) + n3;
        for (n3 = 3; n3 < n2; ++n3) {
            int n5 = arrn[n3];
            n4 += n5 ^ n5 >> 21;
        }
        n2 = 65599 * n4;
        n2 += n2 >>> 19;
        return n2 ^ n2 << 5;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public String findName(int n2) {
        String string;
        int n3;
        String string2 = null;
        int[] arrn = this._hashArea;
        int n4 = this._calcOffset(this.calcHash(n2));
        int n5 = arrn[n4 + 3];
        if (n5 == 1) {
            if (arrn[n4] == n2) {
                return this._names[n4 >> 2];
            }
        } else {
            string = string2;
            if (n5 == 0) return string;
        }
        if ((n3 = arrn[(n5 = this._secondaryStart + (n4 >> 3 << 2)) + 3]) == 1) {
            if (arrn[n5] != n2) return this._findSecondary(n4, n2);
            return this._names[n5 >> 2];
        }
        string = string2;
        if (n3 == 0) return string;
        return this._findSecondary(n4, n2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public String findName(int n2, int n3) {
        String string;
        int n4;
        String string2 = null;
        int[] arrn = this._hashArea;
        int n5 = this._calcOffset(this.calcHash(n2, n3));
        int n6 = arrn[n5 + 3];
        if (n6 == 2) {
            if (n2 == arrn[n5] && n3 == arrn[n5 + 1]) {
                return this._names[n5 >> 2];
            }
        } else {
            string = string2;
            if (n6 == 0) return string;
        }
        if ((n4 = arrn[(n6 = this._secondaryStart + (n5 >> 3 << 2)) + 3]) == 2) {
            if (n2 != arrn[n6]) return this._findSecondary(n5, n2, n3);
            if (n3 != arrn[n6 + 1]) return this._findSecondary(n5, n2, n3);
            return this._names[n6 >> 2];
        }
        string = string2;
        if (n4 == 0) return string;
        return this._findSecondary(n5, n2, n3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public String findName(int n2, int n3, int n4) {
        int n5;
        String string;
        String string2 = null;
        int[] arrn = this._hashArea;
        int n6 = this._calcOffset(this.calcHash(n2, n3, n4));
        int n7 = arrn[n6 + 3];
        if (n7 == 3) {
            if (n2 == arrn[n6] && arrn[n6 + 1] == n3 && arrn[n6 + 2] == n4) {
                return this._names[n6 >> 2];
            }
        } else {
            string = string2;
            if (n7 == 0) return string;
        }
        if ((n5 = arrn[(n7 = this._secondaryStart + (n6 >> 3 << 2)) + 3]) == 3) {
            if (n2 != arrn[n7]) return this._findSecondary(n6, n2, n3, n4);
            if (arrn[n7 + 1] != n3) return this._findSecondary(n6, n2, n3, n4);
            if (arrn[n7 + 2] != n4) return this._findSecondary(n6, n2, n3, n4);
            return this._names[n7 >> 2];
        }
        string = string2;
        if (n5 == 0) return string;
        return this._findSecondary(n6, n2, n3, n4);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public String findName(int[] arrn, int n2) {
        Object var9_3 = null;
        if (n2 < 4) {
            if (n2 == 3) {
                return this.findName(arrn[0], arrn[1], arrn[2]);
            }
            if (n2 != 2) return this.findName(arrn[0]);
            return this.findName(arrn[0], arrn[1]);
        }
        int n3 = this.calcHash(arrn, n2);
        int n4 = this._calcOffset(n3);
        int[] arrn2 = this._hashArea;
        int n5 = arrn2[n4 + 3];
        if (n3 == arrn2[n4] && n5 == n2 && this._verifyLongName(arrn, n2, arrn2[n4 + 1])) {
            return this._names[n4 >> 2];
        }
        String string = var9_3;
        if (n5 == 0) return string;
        int n6 = this._secondaryStart + (n4 >> 3 << 2);
        int n7 = arrn2[n6 + 3];
        if (n3 == arrn2[n6] && n7 == n2 && this._verifyLongName(arrn, n2, arrn2[n6 + 1])) {
            return this._names[n6 >> 2];
        }
        string = var9_3;
        if (n5 == 0) return string;
        return this._findSecondary(n4, n3, arrn, n2);
    }

    public ByteQuadsCanonicalizer makeChild(int n2) {
        return new ByteQuadsCanonicalizer(this, JsonFactory.Feature.INTERN_FIELD_NAMES.enabledIn(n2), this._seed, JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW.enabledIn(n2), this._tableInfo.get());
    }

    public boolean maybeDirty() {
        if (!this._hashShared) {
            return true;
        }
        return false;
    }

    public int primaryCount() {
        int n2 = this._secondaryStart;
        int n3 = 0;
        for (int i2 = 3; i2 < n2; i2 += 4) {
            int n4 = n3;
            if (this._hashArea[i2] != 0) {
                n4 = n3 + 1;
            }
            n3 = n4;
        }
        return n3;
    }

    public void release() {
        if (this._parent != null && this.maybeDirty()) {
            this._parent.mergeChild(new TableInfo(this));
            this._hashShared = true;
        }
    }

    public int secondaryCount() {
        int n2 = this._secondaryStart;
        int n3 = this._tertiaryStart;
        int n4 = 0;
        n2 += 3;
        while (n2 < n3) {
            int n5 = n4;
            if (this._hashArea[n2] != 0) {
                n5 = n4 + 1;
            }
            n2 += 4;
            n4 = n5;
        }
        return n4;
    }

    public int spilloverCount() {
        return this._spilloverEnd - this._spilloverStart() >> 2;
    }

    public int tertiaryCount() {
        int n2 = this._tertiaryStart + 3;
        int n3 = this._hashSize;
        int n4 = 0;
        for (int i2 = n2; i2 < n3 + n2; i2 += 4) {
            int n5 = n4;
            if (this._hashArea[i2] != 0) {
                n5 = n4 + 1;
            }
            n4 = n5;
        }
        return n4;
    }

    public String toString() {
        int n2 = this.primaryCount();
        int n3 = this.secondaryCount();
        int n4 = this.tertiaryCount();
        int n5 = this.spilloverCount();
        int n6 = this.totalCount();
        return String.format("[%s: size=%d, hashSize=%d, %d/%d/%d/%d pri/sec/ter/spill (=%s), total:%d]", this.getClass().getName(), this._count, this._hashSize, n2, n3, n4, n5, n6, n2 + n3 + n4 + n5, n6);
    }

    public int totalCount() {
        int n2 = this._hashSize;
        int n3 = 0;
        for (int i2 = 3; i2 < n2 << 3; i2 += 4) {
            int n4 = n3;
            if (this._hashArea[i2] != 0) {
                n4 = n3 + 1;
            }
            n3 = n4;
        }
        return n3;
    }

    private static final class TableInfo {
        public final int count;
        public final int longNameOffset;
        public final int[] mainHash;
        public final String[] names;
        public final int size;
        public final int spilloverEnd;
        public final int tertiaryShift;

        public TableInfo(int n2, int n3, int n4, int[] arrn, String[] arrstring, int n5, int n6) {
            this.size = n2;
            this.count = n3;
            this.tertiaryShift = n4;
            this.mainHash = arrn;
            this.names = arrstring;
            this.spilloverEnd = n5;
            this.longNameOffset = n6;
        }

        public TableInfo(ByteQuadsCanonicalizer byteQuadsCanonicalizer) {
            this.size = byteQuadsCanonicalizer._hashSize;
            this.count = byteQuadsCanonicalizer._count;
            this.tertiaryShift = byteQuadsCanonicalizer._tertiaryShift;
            this.mainHash = byteQuadsCanonicalizer._hashArea;
            this.names = byteQuadsCanonicalizer._names;
            this.spilloverEnd = byteQuadsCanonicalizer._spilloverEnd;
            this.longNameOffset = byteQuadsCanonicalizer._longNameOffset;
        }

        public static TableInfo createInitial(int n2) {
            int n3 = n2 << 3;
            return new TableInfo(n2, 0, ByteQuadsCanonicalizer._calcTertiaryShift(n2), new int[n3], new String[n2 << 1], n3 - n2, n3);
        }
    }

}

