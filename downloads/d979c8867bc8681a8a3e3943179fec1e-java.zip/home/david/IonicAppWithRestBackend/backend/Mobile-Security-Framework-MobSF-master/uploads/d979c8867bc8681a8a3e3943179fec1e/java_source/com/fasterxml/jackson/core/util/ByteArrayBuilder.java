/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.util;

import com.fasterxml.jackson.core.util.BufferRecycler;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.LinkedList;

public final class ByteArrayBuilder
extends OutputStream {
    public static final byte[] NO_BYTES = new byte[0];
    private final BufferRecycler _bufferRecycler;
    private byte[] _currBlock;
    private int _currBlockPtr;
    private final LinkedList<byte[]> _pastBlocks = new LinkedList();
    private int _pastLen;

    public ByteArrayBuilder() {
        this(null);
    }

    public ByteArrayBuilder(BufferRecycler bufferRecycler) {
        this(bufferRecycler, 500);
    }

    /*
     * Enabled aggressive block sorting
     */
    public ByteArrayBuilder(BufferRecycler arrby, int n2) {
        this._bufferRecycler = arrby;
        arrby = arrby == null ? new byte[n2] : arrby.allocByteBuffer(2);
        this._currBlock = arrby;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void _allocMore() {
        int n2 = 262144;
        this._pastLen += this._currBlock.length;
        int n3 = Math.max(this._pastLen >> 1, 1000);
        if (n3 <= 262144) {
            n2 = n3;
        }
        this._pastBlocks.add(this._currBlock);
        this._currBlock = new byte[n2];
        this._currBlockPtr = 0;
    }

    public void append(int n2) {
        if (this._currBlockPtr >= this._currBlock.length) {
            this._allocMore();
        }
        byte[] arrby = this._currBlock;
        int n3 = this._currBlockPtr;
        this._currBlockPtr = n3 + 1;
        arrby[n3] = (byte)n2;
    }

    @Override
    public void close() {
    }

    public byte[] completeAndCoalesce(int n2) {
        this._currBlockPtr = n2;
        return this.toByteArray();
    }

    public byte[] finishCurrentSegment() {
        this._allocMore();
        return this._currBlock;
    }

    @Override
    public void flush() {
    }

    public void reset() {
        this._pastLen = 0;
        this._currBlockPtr = 0;
        if (!this._pastBlocks.isEmpty()) {
            this._pastBlocks.clear();
        }
    }

    public byte[] resetAndGetFirstSegment() {
        this.reset();
        return this._currBlock;
    }

    public byte[] toByteArray() {
        int n2 = this._pastLen + this._currBlockPtr;
        if (n2 == 0) {
            return NO_BYTES;
        }
        byte[] arrby = new byte[n2];
        Iterator<byte[]> iterator = this._pastBlocks.iterator();
        int n3 = 0;
        while (iterator.hasNext()) {
            byte[] arrby2 = iterator.next();
            int n4 = arrby2.length;
            System.arraycopy(arrby2, 0, arrby, n3, n4);
            n3 += n4;
        }
        System.arraycopy(this._currBlock, 0, arrby, n3, this._currBlockPtr);
        n3 = this._currBlockPtr + n3;
        if (n3 != n2) {
            throw new RuntimeException("Internal error: total len assumed to be " + n2 + ", copied " + n3 + " bytes");
        }
        if (!this._pastBlocks.isEmpty()) {
            this.reset();
        }
        return arrby;
    }

    @Override
    public void write(int n2) {
        this.append(n2);
    }

    @Override
    public void write(byte[] arrby) {
        this.write(arrby, 0, arrby.length);
    }

    @Override
    public void write(byte[] arrby, int n2, int n3) {
        int n4 = n2;
        do {
            int n5 = Math.min(this._currBlock.length - this._currBlockPtr, n3);
            int n6 = n4;
            n2 = n3;
            if (n5 > 0) {
                System.arraycopy(arrby, n4, this._currBlock, this._currBlockPtr, n5);
                n6 = n4 + n5;
                this._currBlockPtr += n5;
                n2 = n3 - n5;
            }
            if (n2 <= 0) {
                return;
            }
            this._allocMore();
            n4 = n6;
            n3 = n2;
        } while (true);
    }
}

