/*
 * Decompiled with CFR 0_115.
 */
package com.fasterxml.jackson.core.util;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;

public class DefaultIndenter
extends DefaultPrettyPrinter.NopIndenter {
    public static final DefaultIndenter SYSTEM_LINEFEED_INSTANCE;
    public static final String SYS_LF;
    private final int charsPerLevel;
    private final String eol;
    private final char[] indents;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        String string;
        try {
            string = System.getProperty("line.separator");
        }
        catch (Throwable var0_1) {
            string = "\n";
        }
        SYS_LF = string;
        SYSTEM_LINEFEED_INSTANCE = new DefaultIndenter("  ", SYS_LF);
    }

    public DefaultIndenter() {
        this("  ", SYS_LF);
    }

    public DefaultIndenter(String string, String string2) {
        this.charsPerLevel = string.length();
        this.indents = new char[string.length() * 16];
        int n2 = 0;
        for (int i2 = 0; i2 < 16; ++i2) {
            string.getChars(0, string.length(), this.indents, n2);
            n2 += string.length();
        }
        this.eol = string2;
    }

    @Override
    public boolean isInline() {
        return false;
    }

    @Override
    public void writeIndentation(JsonGenerator jsonGenerator, int n2) {
        jsonGenerator.writeRaw(this.eol);
        if (n2 > 0) {
            for (n2 = this.charsPerLevel * n2; n2 > this.indents.length; n2 -= this.indents.length) {
                jsonGenerator.writeRaw(this.indents, 0, this.indents.length);
            }
            jsonGenerator.writeRaw(this.indents, 0, n2);
        }
    }
}

