/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a;

import com.orgzly.a.b;

public class a {
    private b a;
    private String b;

    public b a() {
        if (this.a == null) {
            this.a = new b();
        }
        return this.a;
    }

    public void a(String string) {
        this.b = string;
    }

    public String b() {
        if (this.b != null) {
            return this.b;
        }
        return "";
    }

    public String toString() {
        return a.class.getSimpleName() + "[" + this.b.length() + "]";
    }
}

