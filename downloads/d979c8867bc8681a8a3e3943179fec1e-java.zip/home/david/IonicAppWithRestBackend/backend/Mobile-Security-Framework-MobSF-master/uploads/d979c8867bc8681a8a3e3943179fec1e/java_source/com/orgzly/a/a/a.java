/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.a;

import com.orgzly.a.a.b;
import com.orgzly.a.a.e;
import com.orgzly.a.d;
import com.orgzly.a.g;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class a {
    private static final SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd EEE");
    private static final SimpleDateFormat b = new SimpleDateFormat("HH:mm");
    private boolean c;
    private String d;
    private String e;
    private Calendar f;
    private boolean g;
    private Calendar h;
    private e i;
    private b j;

    private a() {
    }

    public static a a(String string) {
        if (string == null) {
            throw new IllegalArgumentException("OrgDateTime cannot be created from null string");
        }
        if (string.length() == 0) {
            throw new IllegalArgumentException("OrgDateTime cannot be created from null string");
        }
        a a2 = new a();
        a2.d = string;
        return a2;
    }

    public static a a(boolean bl2) {
        a a2 = new a();
        a2.c = bl2;
        a2.f = GregorianCalendar.getInstance();
        a2.f.set(13, 0);
        a2.f.set(14, 0);
        a2.g = true;
        return a2;
    }

    private void a(String string, Pattern pattern) {
        throw new IllegalArgumentException("Failed matching \"" + string + "\" against " + pattern);
    }

    public static a b(String string) {
        if (g.b(string)) {
            return null;
        }
        a a2 = new a();
        a2.d = string;
        return a2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private String b(boolean bl2) {
        char c2;
        StringBuilder stringBuilder = new StringBuilder();
        if (bl2) {
            c2 = this.b() ? '<' : '[';
            stringBuilder.append(c2);
        }
        stringBuilder.append(a.format(this.f.getTime()));
        if (this.g) {
            stringBuilder.append(" ");
            stringBuilder.append(b.format(this.f.getTime()));
            if (this.h != null) {
                stringBuilder.append("-");
                stringBuilder.append(b.format(this.h.getTime()));
            }
        }
        if (this.f()) {
            stringBuilder.append(" ");
            stringBuilder.append(this.i);
        }
        if (this.h()) {
            stringBuilder.append(" ");
            stringBuilder.append(this.j);
        }
        if (bl2) {
            c2 = this.b() ? '>' : ']';
            stringBuilder.append(c2);
        }
        return stringBuilder.toString();
    }

    private void c(String string) {
        Matcher matcher = d.f.matcher(string);
        if (!matcher.find()) {
            this.a(string, d.f);
        }
        this.f.set(11, Integer.valueOf(matcher.group(2)));
        this.f.set(12, Integer.valueOf(matcher.group(3)));
        this.g = true;
        if (!g.b(matcher.group(4))) {
            this.h = Calendar.getInstance();
            this.h.setTime(this.f.getTime());
            this.h.set(11, Integer.valueOf(matcher.group(6)));
            this.h.set(12, Integer.valueOf(matcher.group(7)));
            this.h.set(13, 0);
            this.h.set(14, 0);
        }
    }

    private void k() {
        if (this.f == null) {
            if (this.d == null) {
                throw new IllegalStateException("Missing string");
            }
            this.l();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void l() {
        Matcher matcher;
        this.f = Calendar.getInstance();
        this.h = null;
        switch (this.d.charAt(0)) {
            default: {
                throw new IllegalArgumentException("Timestamp \"" + this.d + "\" must start with < or [");
            }
            case '<': {
                this.c = true;
                break;
            }
            case '[': {
                this.c = false;
            }
        }
        if (!(matcher = d.e.matcher(this.d)).find()) {
            this.a(this.d, d.e);
        }
        this.f.set(1, Integer.valueOf(matcher.group(2)));
        this.f.set(2, Integer.valueOf(matcher.group(3)) - 1);
        this.f.set(5, Integer.valueOf(matcher.group(4)));
        if (!g.b(matcher.group(6))) {
            this.c(this.d.substring(matcher.start(6)));
        } else {
            this.f.set(11, 0);
            this.f.set(12, 0);
            this.g = false;
        }
        this.f.set(13, 0);
        this.f.set(14, 0);
        matcher = d.b.matcher(this.d);
        if (matcher.find()) {
            this.i = e.a(matcher.group(1));
        }
        if ((matcher = d.c.matcher(this.d)).find()) {
            this.j = b.a(matcher.group(0));
        }
    }

    public Calendar a() {
        this.k();
        return this.f;
    }

    public boolean a(Calendar calendar) {
        if (this.f()) {
            this.f = this.a();
            this.h = this.e();
            this.i.a(this.f, calendar);
            if (this.h != null) {
                this.i.a(this.h, calendar);
            }
            this.d = null;
            this.e = null;
        }
        if (this.i != null) {
            return true;
        }
        return false;
    }

    public boolean b() {
        this.k();
        return this.c;
    }

    public boolean c() {
        this.k();
        return this.g;
    }

    public boolean d() {
        this.k();
        if (this.h != null) {
            return true;
        }
        return false;
    }

    public Calendar e() {
        this.k();
        return this.h;
    }

    public boolean f() {
        this.k();
        if (this.i != null) {
            return true;
        }
        return false;
    }

    public e g() {
        this.k();
        return this.i;
    }

    public boolean h() {
        this.k();
        if (this.j != null) {
            return true;
        }
        return false;
    }

    public b i() {
        this.k();
        return this.j;
    }

    public String j() {
        this.k();
        if (this.e == null && this.f != null) {
            this.e = this.b(false);
        }
        return this.e;
    }

    public String toString() {
        if (this.d == null && this.f != null) {
            this.d = this.b(true);
        }
        return this.d;
    }

    public static class a {
        private boolean a;
        private boolean b;
        private boolean c;
        private int d;
        private int e;
        private int f;
        private int g;
        private int h;
        private e i;

        public a a(int n2) {
            this.d = n2;
            return this;
        }

        public a a(e e2) {
            this.i = e2;
            return this;
        }

        public a a(boolean bl2) {
            this.a = bl2;
            return this;
        }

        public a a() {
            a a2 = new a();
            a2.c = this.a;
            a2.g = this.b;
            a2.f = new GregorianCalendar(this.d, this.e, this.f, this.g, this.h);
            if (this.c) {
                a2.i = this.i;
            }
            return a2;
        }

        public a b(int n2) {
            this.e = n2;
            return this;
        }

        public a b(boolean bl2) {
            this.b = bl2;
            return this;
        }

        public a c(int n2) {
            this.f = n2;
            return this;
        }

        public a c(boolean bl2) {
            this.c = bl2;
            return this;
        }

        public a d(int n2) {
            this.g = n2;
            return this;
        }

        public a e(int n2) {
            this.h = n2;
            return this;
        }
    }

}

