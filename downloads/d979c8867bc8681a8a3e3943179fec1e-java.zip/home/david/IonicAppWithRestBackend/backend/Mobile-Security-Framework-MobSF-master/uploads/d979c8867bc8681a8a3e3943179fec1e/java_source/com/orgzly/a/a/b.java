/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.a;

import com.orgzly.a.a.c;
import com.orgzly.a.d;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class b
extends c {
    private a a;

    public b(String string) {
        Matcher matcher = d.c.matcher(string);
        if (matcher.find()) {
            if (matcher.groupCount() == 3) {
                this.d(matcher.group(1));
                this.b(matcher.group(2));
                this.c(matcher.group(3));
                return;
            }
            throw new IllegalArgumentException("Expected 3 groups (got " + matcher.groupCount() + ") when matching time delay " + string + " against " + d.c);
        }
        throw new IllegalArgumentException("Failed matching time delay " + string + " against " + d.c);
    }

    public static b a(String string) {
        return new b(string);
    }

    private void d(String string) {
        if ("-".equals(string)) {
            this.a = a.a;
            return;
        }
        if ("--".equals(string)) {
            this.a = a.b;
            return;
        }
        throw new IllegalArgumentException("Unknown time delay type " + string);
    }

    public a a() {
        return this.a;
    }

    @Override
    public String toString() {
        switch (.a[this.a.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unknown time delay type " + (Object)((Object)this.a));
            }
            case 1: {
                return "-" + super.toString();
            }
            case 2: 
        }
        return "--" + super.toString();
    }

    public static enum a {
        a,
        b;
        

        private a() {
        }
    }

}

