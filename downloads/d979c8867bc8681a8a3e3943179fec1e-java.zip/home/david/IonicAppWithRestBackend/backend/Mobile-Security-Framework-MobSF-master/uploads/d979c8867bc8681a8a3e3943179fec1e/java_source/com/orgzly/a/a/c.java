/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.a;

public class c {
    protected int b;
    protected a c;

    public void a(int n2) {
        this.b = n2;
    }

    public void a(a a2) {
        this.c = a2;
    }

    public int b() {
        return this.b;
    }

    public void b(String string) {
        try {
            this.b = Integer.valueOf(string);
            return;
        }
        catch (NumberFormatException var2_2) {
            throw new IllegalArgumentException("Interval value " + string + " couldn't be parsed as integer", var2_2);
        }
    }

    public a c() {
        return this.c;
    }

    public void c(String string) {
        if ("h".equals(string)) {
            this.c = a.a;
            return;
        }
        if ("d".equals(string)) {
            this.c = a.b;
            return;
        }
        if ("w".equals(string)) {
            this.c = a.c;
            return;
        }
        if ("m".equals(string)) {
            this.c = a.d;
            return;
        }
        if ("y".equals(string)) {
            this.c = a.e;
            return;
        }
        throw new IllegalArgumentException("Unknown unit " + string);
    }

    public String toString() {
        switch (.a[this.c.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unknown unit " + (Object)((Object)this.c));
            }
            case 1: {
                return "" + this.b + "h";
            }
            case 2: {
                return "" + this.b + "d";
            }
            case 3: {
                return "" + this.b + "w";
            }
            case 4: {
                return "" + this.b + "m";
            }
            case 5: 
        }
        return "" + this.b + "y";
    }

    public static enum a {
        a,
        b,
        c,
        d,
        e;
        

        private a() {
        }
    }

}

