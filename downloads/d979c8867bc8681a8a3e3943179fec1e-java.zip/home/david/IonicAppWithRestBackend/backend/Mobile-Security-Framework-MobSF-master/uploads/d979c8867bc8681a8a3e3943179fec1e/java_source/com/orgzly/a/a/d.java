/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.a;

import com.orgzly.a.a.a;
import com.orgzly.a.g;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class d {
    private a a;
    private a b;

    private d() {
    }

    public static d a(a a2) {
        return d.a(a2, null);
    }

    public static d a(a a2, a a3) {
        if (a2 == null) {
            throw new IllegalArgumentException("OrgRange cannot be created from null OrgDateTime");
        }
        d d2 = new d();
        d2.a = a2;
        d2.b = a3;
        return d2;
    }

    public static d a(String string) {
        if (g.b(string)) {
            return null;
        }
        return d.b(string);
    }

    public static d b(String string) {
        if (string == null) {
            throw new IllegalArgumentException("OrgRange cannot be created from null string");
        }
        if (string.length() == 0) {
            throw new IllegalArgumentException("OrgRange cannot be created from null string");
        }
        d d2 = new d();
        Matcher matcher = com.orgzly.a.d.a.matcher(string);
        if (matcher.find()) {
            if (matcher.groupCount() == 6 && matcher.group(6) != null) {
                d2.a = a.a(matcher.group(2));
                d2.b = a.a(matcher.group(5));
                return d2;
            }
            d2.a = a.a(matcher.group(2));
            d2.b = null;
            return d2;
        }
        throw new IllegalArgumentException("String " + string + " cannot be parsed as OrgRange using pattern " + com.orgzly.a.d.a);
    }

    public a a() {
        return this.a;
    }

    public boolean a(Calendar calendar) {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (this.a != null) {
            bl3 = bl2;
            if (this.a.a(calendar)) {
                bl3 = true;
            }
        }
        bl2 = bl3;
        if (this.b != null) {
            bl2 = bl3;
            if (this.b.a(calendar)) {
                bl2 = true;
            }
        }
        return bl2;
    }

    public a b() {
        return this.b;
    }

    public boolean c() {
        if (this.a != null) {
            return true;
        }
        return false;
    }

    public String d() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.a.j());
        if (this.b != null) {
            stringBuilder.append("--");
            stringBuilder.append(this.b.j());
        }
        return stringBuilder.toString();
    }

    public boolean e() {
        return this.a(Calendar.getInstance());
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.a);
        if (this.b != null) {
            stringBuilder.append("--");
            stringBuilder.append(this.b);
        }
        return stringBuilder.toString();
    }
}

