/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.a;

import com.orgzly.a.a.c;
import com.orgzly.a.d;
import com.orgzly.a.g;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class e
extends c {
    private a a;
    private c d;

    private e() {
    }

    private e(String string) {
        Matcher matcher = d.d.matcher(string);
        if (matcher.find()) {
            if (matcher.groupCount() == 7) {
                this.d(matcher.group(2));
                this.b(matcher.group(3));
                this.c(matcher.group(4));
                if (!g.b(matcher.group(6))) {
                    this.d = new c();
                    this.d.b(matcher.group(6));
                    this.d.c(matcher.group(7));
                }
                return;
            }
            throw new IllegalArgumentException("Expected 7 groups (got " + matcher.groupCount() + ") when matching repeater " + string + " against " + d.d);
        }
        throw new IllegalArgumentException("Failed matching repeater " + string + " against " + d.d);
    }

    public static e a(a a2, int n2, c.a a3) {
        e e2 = new e();
        e2.a = a2;
        e2.b = n2;
        e2.c = a3;
        return e2;
    }

    public static e a(String string) {
        return new e(string);
    }

    private void a(Calendar calendar) {
        switch (.b[this.c().ordinal()]) {
            default: {
                return;
            }
            case 1: {
                calendar.add(11, this.b());
                return;
            }
            case 2: {
                calendar.add(5, this.b());
                return;
            }
            case 3: {
                calendar.add(3, this.b());
                return;
            }
            case 4: {
                calendar.add(2, this.b());
                return;
            }
            case 5: 
        }
        calendar.add(1, this.b());
    }

    private void d(String string) {
        if ("+".equals(string)) {
            this.a = a.a;
            return;
        }
        if ("++".equals(string)) {
            this.a = a.b;
            return;
        }
        if (".+".equals(string)) {
            this.a = a.c;
            return;
        }
        throw new IllegalArgumentException("Unknown repeater type " + string);
    }

    public a a() {
        return this.a;
    }

    public void a(Calendar calendar, Calendar calendar2) {
        switch (.a[this.a.ordinal()]) {
            default: {
                return;
            }
            case 1: {
                this.a(calendar);
                return;
            }
            case 2: {
                do {
                    this.a(calendar);
                } while (!calendar.after(calendar2));
                return;
            }
            case 3: 
        }
        calendar.set(1, calendar2.get(1));
        calendar.set(2, calendar2.get(2));
        calendar.set(5, calendar2.get(5));
        if (this.c() == c.a.a) {
            calendar.set(11, calendar2.get(11));
        }
        this.a(calendar);
    }

    public boolean d() {
        if (this.d != null) {
            return true;
        }
        return false;
    }

    public c e() {
        return this.d;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public String toString() {
        var1_1 = new StringBuilder();
        switch (.a[this.a.ordinal()]) {
            case 1: {
                var1_1.append("+");
                ** break;
            }
            case 2: {
                var1_1.append("++");
            }
lbl8: // 3 sources:
            default: {
                ** GOTO lbl12
            }
            case 3: 
        }
        var1_1.append(".+");
lbl12: // 2 sources:
        var1_1.append(super.toString());
        return var1_1.toString();
    }

    public static enum a {
        a,
        b,
        c;
        

        private a() {
        }
    }

}

