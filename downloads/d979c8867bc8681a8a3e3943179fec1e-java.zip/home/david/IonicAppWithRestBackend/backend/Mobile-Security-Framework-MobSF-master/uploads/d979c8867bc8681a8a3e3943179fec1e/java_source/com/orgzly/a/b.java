/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a;

public class b {
    private String a;
    private boolean b;

    public String a() {
        return this.a;
    }

    public void a(String string) {
        this.a = string;
    }

    public void a(boolean bl2) {
        this.b = bl2;
    }

    public boolean b() {
        return this.b;
    }

    public boolean b(String string) {
        boolean bl2 = false;
        if (string.startsWith("#+TITLE:")) {
            if ((string = string.substring("#+TITLE:".length()).trim()).length() > 0) {
                this.a(string);
            }
            bl2 = true;
        }
        return bl2;
    }
}

