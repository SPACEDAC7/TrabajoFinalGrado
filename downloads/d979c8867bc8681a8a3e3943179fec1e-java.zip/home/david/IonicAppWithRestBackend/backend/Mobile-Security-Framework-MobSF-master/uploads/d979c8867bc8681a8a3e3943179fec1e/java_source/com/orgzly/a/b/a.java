/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.b.e;
import com.orgzly.a.b.g;
import com.orgzly.a.b.h;
import com.orgzly.a.b.i;
import com.orgzly.a.b.l;
import java.io.Reader;

class a
extends h {
    private Reader b;

    public a(i i2, Reader reader) {
        this.a = i2;
        this.b = reader;
    }

    @Override
    public g a() {
        final g g2 = new g();
        new h.a(this.a).a(this.b).a(new l(){

            @Override
            public void a(com.orgzly.a.a a2) {
                g2.a(a2);
            }

            @Override
            public void a(e e2) {
                g2.a(e2);
            }
        }).a().a();
        return g2;
    }

}

