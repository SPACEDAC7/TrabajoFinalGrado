/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.a;
import com.orgzly.a.b.c;
import com.orgzly.a.b.e;
import com.orgzly.a.b.f;
import com.orgzly.a.b.g;
import com.orgzly.a.b.h;
import com.orgzly.a.b.i;
import com.orgzly.a.b.l;
import java.io.Reader;
import java.util.Stack;

public class b
extends h {
    private Reader b;
    private c c;

    public b(i i2, Reader reader, c c2) {
        this.a = i2;
        this.b = reader;
        this.c = c2;
    }

    private void a(f f2, int n2) {
        f2.a((int)(f2.d() - f2.c() - (long)n2) / (n2 * 2));
    }

    @Override
    public g a() {
        final Stack<f> stack = new Stack<f>();
        stack.push(new f(0, 1, new com.orgzly.a.c()));
        new h.a(this.a).a(this.b).a(new l(){
            int a;
            long b;

            @Override
            public void a(a a2) {
                while (!stack.empty()) {
                    f f2 = (f)stack.pop();
                    this.b += 5;
                    f2.a(this.b);
                    b.this.a(f2, 5);
                    b.this.c.a(f2);
                }
                b.this.c.a(a2);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public void a(e e2) {
                if (this.a < e2.a()) {
                    this.b += 5;
                    stack.push(new f(e2.a(), this.b, e2.b()));
                } else if (this.a == e2.a()) {
                    f f2 = (f)stack.pop();
                    this.b += 5;
                    f2.a(this.b);
                    b.this.a(f2, 5);
                    b.this.c.a(f2);
                    this.b += 5;
                    stack.push(new f(e2.a(), this.b, e2.b()));
                } else {
                    f f3;
                    while (!stack.empty() && (f3 = (f)stack.peek()).a() >= e2.a()) {
                        stack.pop();
                        this.b += 5;
                        f3.a(this.b);
                        b.this.a(f3, 5);
                        b.this.c.a(f3);
                    }
                    this.b += 5;
                    stack.push(new f(e2.a(), this.b, e2.b()));
                }
                this.a = e2.a();
            }
        }).a().a();
        return null;
    }

}

