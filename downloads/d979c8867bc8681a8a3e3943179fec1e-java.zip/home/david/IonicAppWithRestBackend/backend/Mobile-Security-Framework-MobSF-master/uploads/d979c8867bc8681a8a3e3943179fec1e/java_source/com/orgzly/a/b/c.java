/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.a;
import com.orgzly.a.b.f;

public interface c {
    public void a(a var1);

    public void a(f var1);
}

