/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.c;

public class d {
    protected int a;
    protected c b;

    public int a() {
        return this.a;
    }

    public c b() {
        return this.b;
    }
}

