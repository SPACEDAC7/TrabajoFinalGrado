/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.b.d;
import com.orgzly.a.c;

public class e
extends d {
    private int c;

    public e(int n2, int n3, c c2) {
        this.a = n3;
        this.c = n2;
        this.b = c2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(String.format("%2d ", this.c));
        for (int i2 = 0; i2 < this.a; ++i2) {
            stringBuilder.append("*");
        }
        if (this.a > 0) {
            stringBuilder.append(" ");
        }
        String string = this.b != null ? this.b.a() : "-";
        stringBuilder.append(string);
        return stringBuilder.toString();
    }
}

