/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.b.d;
import com.orgzly.a.c;

public class f
extends d {
    private long c;
    private long d;
    private int e;

    public f(int n2, long l2, c c2) {
        this.a = n2;
        this.c = l2;
        this.b = c2;
    }

    public void a(int n2) {
        this.e = n2;
    }

    public void a(long l2) {
        this.d = l2;
    }

    public long c() {
        return this.c;
    }

    public long d() {
        return this.d;
    }

    public int e() {
        return this.e;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(String.format("%2d %2d ", this.c, this.d));
        for (int i2 = 0; i2 < this.a; ++i2) {
            stringBuilder.append("*");
        }
        if (this.a > 0) {
            stringBuilder.append(" ");
        }
        stringBuilder.append(this.b.a());
        return stringBuilder.toString();
    }
}

