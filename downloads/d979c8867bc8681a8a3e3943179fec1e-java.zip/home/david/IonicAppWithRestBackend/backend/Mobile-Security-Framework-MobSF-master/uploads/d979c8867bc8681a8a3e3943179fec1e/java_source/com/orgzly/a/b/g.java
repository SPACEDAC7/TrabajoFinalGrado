/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.a;
import com.orgzly.a.b;
import com.orgzly.a.b.d;
import com.orgzly.a.b.e;
import com.orgzly.a.b.j;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class g {
    private a a;
    private List<e> b = new ArrayList<e>();

    public List<e> a() {
        return this.b;
    }

    public void a(a a2) {
        this.a = a2;
    }

    public void a(e e2) {
        this.b.add(e2);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        j j2 = new j();
        stringBuilder.append(j2.a(this.a.b()));
        Iterator<e> iterator = this.b.iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(j2.a(iterator.next(), this.a.a().b()));
        }
        return stringBuilder.toString();
    }
}

