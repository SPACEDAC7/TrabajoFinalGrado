/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.b.b;
import com.orgzly.a.b.c;
import com.orgzly.a.b.g;
import com.orgzly.a.b.i;
import com.orgzly.a.b.k;
import com.orgzly.a.b.l;
import java.io.Reader;
import java.io.StringReader;
import java.util.Set;

public abstract class h {
    protected i a;

    public abstract g a();

    public static class a {
        private i a;
        private Reader b;
        private l c;
        private c d;

        public a() {
            this.a = new i();
        }

        public a(i i2) {
            this.a = new i(i2);
        }

        public a a(c c2) {
            this.d = c2;
            return this;
        }

        public a a(l l2) {
            this.c = l2;
            return this;
        }

        public a a(Reader reader) {
            this.b = reader;
            return this;
        }

        public a a(String string) {
            this.b = new StringReader(string);
            return this;
        }

        public a a(Set<String> set) {
            this.a.b = set;
            return this;
        }

        public h a() {
            if (this.b == null) {
                throw new IllegalStateException("Reader not set. Use setInput() before building the parser.");
            }
            if (this.c != null) {
                return new k(this.a, this.b, this.c);
            }
            if (this.d != null) {
                return new b(this.a, this.b, this.d);
            }
            return new com.orgzly.a.b.a(this.a, this.b);
        }

        public a b(Set<String> set) {
            this.a.c = set;
            return this;
        }
    }

}

