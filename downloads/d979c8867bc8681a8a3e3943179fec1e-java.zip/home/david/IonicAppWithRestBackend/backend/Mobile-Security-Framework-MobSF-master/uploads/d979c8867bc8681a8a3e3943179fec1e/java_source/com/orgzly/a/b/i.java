/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class i {
    String a = "%-10s %s";
    Set<String> b = new HashSet<String>();
    Set<String> c = new HashSet<String>();
    public a d = a.b;

    i() {
    }

    i(i i2) {
        this();
        this.a = i2.a;
        this.b.addAll(i2.b);
        this.c.addAll(i2.c);
        this.d = i2.d;
    }

    public static i a() {
        i i2 = new i();
        i2.b.add("TODO");
        i2.c.add("DONE");
        return i2;
    }

    public static enum a {
        a,
        b,
        c;
        

        private a() {
        }
    }

}

