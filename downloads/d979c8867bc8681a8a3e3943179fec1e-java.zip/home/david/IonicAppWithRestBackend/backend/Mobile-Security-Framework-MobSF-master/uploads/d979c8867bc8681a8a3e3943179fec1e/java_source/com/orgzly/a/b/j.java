/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.b.d;
import com.orgzly.a.b.i;
import com.orgzly.a.c;
import com.orgzly.a.e;
import com.orgzly.a.g;
import java.util.List;

public class j {
    private static final String[] a = new String[]{"CLOSING NOTE ", "State ", "Note taken on ", "Rescheduled from ", "Not scheduled, was ", "New deadline from ", "Removed deadline, was ", "Refiled on "};
    private i b;

    public j() {
        this.b = i.a();
    }

    public j(i i2) {
        this.b = i2;
    }

    private void a(StringBuilder stringBuilder, int n2, boolean bl2) {
        if (bl2) {
            for (int i2 = 0; i2 < n2 + 1; ++i2) {
                stringBuilder.append(" ");
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean b(String string) {
        boolean bl2 = false;
        String[] arrstring = a;
        int n2 = arrstring.length;
        int n3 = 0;
        do {
            boolean bl3 = bl2;
            if (n3 >= n2) return bl3;
            String string2 = arrstring[n3];
            if (string.startsWith("- " + string2)) {
                return true;
            }
            ++n3;
        } while (true);
    }

    public String a(d d2, boolean bl2) {
        return this.a(d2.b(), d2.a(), bl2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public String a(c c2, int n2, boolean bl2) {
        int n3;
        int n4;
        int n5 = 1;
        StringBuilder stringBuilder = new StringBuilder();
        for (n3 = 0; n3 < n2; ++n3) {
            stringBuilder.append("*");
        }
        stringBuilder.append(" ");
        if (c2.o() != null) {
            stringBuilder.append(c2.o()).append(" ");
        }
        if (c2.n() != null) {
            stringBuilder.append("[#").append(c2.n()).append("] ");
        }
        stringBuilder.append(c2.a());
        if (c2.c()) {
            stringBuilder.append(" ");
            for (n3 = 0; n3 < c2.b().size(); ++n3) {
                stringBuilder.append(":").append(c2.b().get(n3));
            }
            stringBuilder.append(":");
        }
        if (c2.i()) {
            stringBuilder.append("\n");
            this.a(stringBuilder, n2, bl2);
            stringBuilder.append("CLOSED: ").append(c2.h());
            n4 = 1;
        } else {
            n4 = 0;
        }
        n3 = n4;
        if (c2.k()) {
            if (n4 != 0) {
                stringBuilder.append(" ");
            } else {
                stringBuilder.append("\n");
                this.a(stringBuilder, n2, bl2);
            }
            stringBuilder.append("DEADLINE: ").append(c2.j());
            n3 = 1;
        }
        n4 = n3;
        if (c2.g()) {
            if (n3 != 0) {
                stringBuilder.append(" ");
            } else {
                stringBuilder.append("\n");
                this.a(stringBuilder, n2, bl2);
            }
            stringBuilder.append("SCHEDULED: ").append(c2.f());
            n4 = 1;
        }
        if (c2.m()) {
            stringBuilder.append("\n");
            this.a(stringBuilder, n2, bl2);
            stringBuilder.append("CLOCK: ").append(c2.l());
            n4 = 1;
        }
        if (c2.q()) {
            stringBuilder.append("\n");
            this.a(stringBuilder, n2, bl2);
            stringBuilder.append(":PROPERTIES:");
            for (e e2 : c2.p()) {
                stringBuilder.append("\n");
                this.a(stringBuilder, n2, bl2);
                stringBuilder.append(String.format(this.b.a, ":" + e2.a() + ":", e2.b()));
            }
            stringBuilder.append("\n");
            this.a(stringBuilder, n2, bl2);
            stringBuilder.append(":END:");
            n4 = 1;
        }
        if (c2.t()) {
            stringBuilder.append("\n");
            this.a(stringBuilder, n2, bl2);
            stringBuilder.append(":LOGBOOK:");
            for (String string : c2.s()) {
                stringBuilder.append("\n");
                this.a(stringBuilder, n2, bl2);
                stringBuilder.append(string);
            }
            stringBuilder.append("\n");
            this.a(stringBuilder, n2, bl2);
            stringBuilder.append(":END:");
            n2 = n5;
        } else {
            n2 = n4;
        }
        stringBuilder.append("\n");
        if (c2.e()) {
            String string = c2.d().trim();
            if (!(string.startsWith(":LOGBOOK:") || string.startsWith("CLOCK: ") || this.b(string))) {
                stringBuilder.append("\n");
            }
            stringBuilder.append(c2.d());
            stringBuilder.append("\n");
            if (this.b.d == i.a.b) {
                stringBuilder.append("\n");
            }
        } else if (n2 != 0 && this.b.d == i.a.b) {
            stringBuilder.append("\n");
        }
        if (this.b.d == i.a.a) {
            stringBuilder.append("\n");
        }
        return stringBuilder.toString();
    }

    public String a(String string) {
        if (string == null || string.length() == 0) {
            return "";
        }
        return g.a(string) + "\n\n";
    }
}

