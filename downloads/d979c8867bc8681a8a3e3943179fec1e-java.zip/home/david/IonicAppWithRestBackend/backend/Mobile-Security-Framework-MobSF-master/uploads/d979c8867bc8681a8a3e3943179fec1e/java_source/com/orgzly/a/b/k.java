/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.a;
import com.orgzly.a.b;
import com.orgzly.a.b.h;
import com.orgzly.a.b.i;
import com.orgzly.a.b.l;
import com.orgzly.a.c;
import com.orgzly.a.d;
import com.orgzly.a.e;
import com.orgzly.a.g;
import java.io.BufferedReader;
import java.io.Reader;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class k
extends h {
    private BufferedReader b;
    private l c;
    private Pattern d;

    public k(i i2, Reader reader, l l2) {
        this.a = i2;
        this.b = new BufferedReader(reader);
        this.c = l2;
        this.d = this.a(i2.b, i2.c);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private com.orgzly.a.b.e a(int var1_1, int var2_2, String var3_3) {
        var5_4 = new c();
        var6_5 = new com.orgzly.a.b.e(var1_1, var2_2, var5_4);
        var3_3 = var4_6 = var3_3.trim();
        if (this.d == null) ** GOTO lbl13
        var7_7 = this.d.matcher((CharSequence)var4_6);
        var3_3 = var4_6;
        if (!var7_7.find()) ** GOTO lbl13
        if (var7_7.group(2).length() == 0) ** GOTO lbl-1000
        var3_3 = var4_6;
        if (var7_7.group(2).startsWith(" ")) lbl-1000: // 2 sources:
        {
            var5_4.e(var7_7.group(1));
            var3_3 = var7_7.group(2).trim();
        }
lbl13: // 5 sources:
        if ((var4_6 = d.i.matcher((CharSequence)var3_3)).find()) {
            var5_4.d(var4_6.group(1));
            var3_3 = var4_6.group(2).trim();
        }
        if ((var4_6 = d.j.matcher((CharSequence)var3_3)).find()) {
            var3_3 = var4_6.group(1).trim();
            var5_4.a(var4_6.group(2).split(":"));
        }
        var5_4.a((String)var3_3);
        return var6_5;
    }

    private com.orgzly.a.b.e a(String object, int n2) {
        Object var3_3 = null;
        Matcher matcher = d.h.matcher((CharSequence)object);
        object = var3_3;
        if (matcher.find()) {
            object = this.a(n2, matcher.group(1).length(), matcher.group(2));
        }
        return object;
    }

    private Pattern a(Set<String> iterator, Set<String> set) {
        HashSet<String> hashSet = new HashSet<String>();
        if (iterator != null) {
            iterator = iterator.iterator();
            while (iterator.hasNext()) {
                hashSet.add(Pattern.quote(iterator.next()));
            }
        }
        if (set != null) {
            iterator = set.iterator();
            while (iterator.hasNext()) {
                hashSet.add(Pattern.quote(iterator.next()));
            }
        }
        if (hashSet.size() > 0) {
            return Pattern.compile("^(" + g.a(hashSet, "|") + ")(.*)");
        }
        return null;
    }

    private void a(a a2, String string) {
        a2.a(g.a(string));
    }

    private void a(c c2) {
        c2.b(g.a(c2.d()));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public com.orgzly.a.b.g a() {
        block27 : {
            var11_1 = new a();
            var12_2 = new StringBuilder();
            var9_3 = null;
            var7_4 = 0;
            var2_5 = 0;
            var6_6 = 1;
            var1_7 = 0;
            block10 : do {
                if ((var13_12 = this.b.readLine()) == null) ** GOTO lbl34
                if (var9_3 == null && var11_1.a().b(var13_12)) {
                    var12_2.append(var13_12);
                    var12_2.append('\n');
                    continue;
                }
                var10_11 = this.a(var13_12, var6_6);
                if (var10_11 == null) ** GOTO lbl24
                if (var9_3 != null) {
                    this.a(var9_3.b());
                    this.c.a((com.orgzly.a.b.e)var9_3);
                }
                var3_8 = 1;
                var2_5 = 0;
                ++var6_6;
                var9_3 = var10_11;
                ** GOTO lbl40
lbl24: // 1 sources:
                if (var9_3 != null) {
                    var5_10 = var1_7;
                    var3_8 = var2_5;
                    if (var7_4 == 0) break;
                    var4_9 = false;
                    var10_11 = d.g.matcher(var13_12);
                } else {
                    var12_2.append(var13_12);
                    var12_2.append('\n');
                    break block27;
lbl34: // 1 sources:
                    this.a(var11_1, var12_2.toString());
                    var9_3 = var11_1.a();
                    var8_15 = var1_7 > 0;
                    var9_3.a(var8_15);
                    this.c.a(var11_1);
                    return null;
lbl40: // 2 sources:
                    do {
                        var7_4 = var3_8;
                        continue block10;
                        break;
                    } while (true);
                }
                while (var10_11.find()) {
                    var14_13 = var10_11.group(1);
                    var15_14 = var10_11.group(2);
                    var3_8 = -1;
                    switch (var14_13.hashCode()) {
                        case -201965235: {
                            if (var14_13.equals("SCHEDULED:")) {
                                var3_8 = 0;
                                ** break;
                            }
                            ** GOTO lbl56
                        }
                        case 1584519246: {
                            if (var14_13.equals("CLOSED:")) {
                                var3_8 = 1;
                            }
                        }
lbl56: // 6 sources:
                        default: {
                            ** GOTO lbl61
                        }
                        case 1219395810: 
                    }
                    if (var14_13.equals("DEADLINE:")) {
                        var3_8 = 2;
                    }
lbl61: // 4 sources:
                    switch (var3_8) {
                        default: {
                            throw new IllegalStateException("Unknown time key " + (String)var14_13);
                        }
                        case 0: {
                            var9_3.b().a(com.orgzly.a.a.d.b(var15_14));
                            break;
                        }
                        case 1: {
                            var9_3.b().b(com.orgzly.a.a.d.b(var15_14));
                            break;
                        }
                        case 2: {
                            var9_3.b().c(com.orgzly.a.a.d.b(var15_14));
                        }
                    }
                    var4_9 = true;
                }
                var10_11 = var13_12.trim();
                if (var2_5 == 0 && ":PROPERTIES:".equals(var10_11)) {
                    var3_8 = 1;
                    var4_9 = true;
                } else if (var2_5 != 0 && ":END:".equals(var10_11)) {
                    var3_8 = 0;
                    var4_9 = true;
                } else {
                    var3_8 = var2_5;
                    if (var2_5 != 0) {
                        var14_13 = d.k.matcher((CharSequence)var10_11);
                        if (var14_13.find()) {
                            var14_13 = new e(var14_13.group(1), var14_13.group(2));
                            var9_3.b.a((e)var14_13);
                        }
                        var4_9 = true;
                        var3_8 = var2_5;
                    }
                }
                var2_5 = var13_12.indexOf((String)var10_11);
                var5_10 = var1_7;
                if (var4_9) {
                    var5_10 = var2_5 > 0 ? var1_7 + 1 : var1_7 - 1;
                }
                var1_7 = var5_10;
                var2_5 = var3_8;
                if (!var4_9) break;
            } while (true);
            var9_3.b().c(var13_12);
            var9_3.b().c("\n");
            var2_5 = var3_8;
            var1_7 = var5_10;
        }
        var3_8 = 0;
        ** while (true)
    }
}

