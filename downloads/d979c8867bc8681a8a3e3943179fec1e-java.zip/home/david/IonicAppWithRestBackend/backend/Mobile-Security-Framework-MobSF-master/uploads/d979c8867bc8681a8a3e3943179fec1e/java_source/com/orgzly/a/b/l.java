/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.b;

import com.orgzly.a.a;
import com.orgzly.a.b.e;

public interface l {
    public void a(a var1);

    public void a(e var1);
}

