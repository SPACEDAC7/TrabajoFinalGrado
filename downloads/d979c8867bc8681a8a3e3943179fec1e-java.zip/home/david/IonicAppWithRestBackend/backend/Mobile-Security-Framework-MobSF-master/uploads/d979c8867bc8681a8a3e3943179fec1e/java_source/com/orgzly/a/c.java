/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a;

import com.orgzly.a.a.d;
import com.orgzly.a.e;
import com.orgzly.a.g;
import java.util.ArrayList;
import java.util.List;

public class c {
    private String a;
    private List<String> b;
    private String c;
    private String d;
    private d e;
    private d f;
    private d g;
    private d h;
    private List<e> i;
    private List<String> j;
    private StringBuilder k;

    public c() {
        this("");
    }

    public c(String string) {
        this.a = string;
        this.k = new StringBuilder();
    }

    public String a() {
        if (this.a == null) {
            return "";
        }
        return this.a;
    }

    public void a(d d2) {
        this.e = d2;
    }

    public void a(e e2) {
        if (this.i == null) {
            this.i = new ArrayList<e>();
        }
        this.i.add(e2);
    }

    public void a(String string) {
        this.a = string;
    }

    public void a(List<e> list) {
        this.i = list;
    }

    public void a(String[] arrstring) {
        if (arrstring == null) {
            throw new IllegalArgumentException("Tags passed to setTags cannot be null");
        }
        this.b = new ArrayList<String>();
        for (String string : arrstring) {
            if (g.b(string)) continue;
            this.b.add(string);
        }
    }

    public List<String> b() {
        if (this.b == null) {
            return new ArrayList<String>();
        }
        return this.b;
    }

    public void b(d d2) {
        this.g = d2;
    }

    public void b(String string) {
        if (string != null) {
            this.k = new StringBuilder(string);
            return;
        }
        this.k = new StringBuilder("");
    }

    public void c(d d2) {
        this.f = d2;
    }

    public void c(String string) {
        this.k.append(string);
    }

    public boolean c() {
        if (this.b != null && !this.b.isEmpty()) {
            return true;
        }
        return false;
    }

    public String d() {
        return this.k.toString();
    }

    public void d(d d2) {
        this.h = d2;
    }

    public void d(String string) {
        this.d = string;
    }

    public void e(String string) {
        this.c = string;
    }

    public boolean e() {
        if (this.k.length() > 0) {
            return true;
        }
        return false;
    }

    public d f() {
        if (this.g()) {
            return this.e;
        }
        return null;
    }

    public boolean g() {
        if (this.e != null && this.e.c()) {
            return true;
        }
        return false;
    }

    public d h() {
        if (this.i()) {
            return this.g;
        }
        return null;
    }

    public boolean i() {
        if (this.g != null && this.g.c()) {
            return true;
        }
        return false;
    }

    public d j() {
        if (this.k()) {
            return this.f;
        }
        return null;
    }

    public boolean k() {
        if (this.f != null && this.f.c()) {
            return true;
        }
        return false;
    }

    public d l() {
        if (this.m()) {
            return this.h;
        }
        return null;
    }

    public boolean m() {
        if (this.h != null && this.h.c()) {
            return true;
        }
        return false;
    }

    public String n() {
        return this.d;
    }

    public String o() {
        return this.c;
    }

    public List<e> p() {
        if (this.i == null) {
            return new ArrayList<e>();
        }
        return this.i;
    }

    public boolean q() {
        if (this.i != null && !this.i.isEmpty()) {
            return true;
        }
        return false;
    }

    public void r() {
        this.i = null;
    }

    public List<String> s() {
        if (this.j == null) {
            throw new IllegalArgumentException("Logbook does not exist");
        }
        return this.j;
    }

    public boolean t() {
        if (this.j != null) {
            return true;
        }
        return false;
    }

    public String toString() {
        return this.a;
    }
}

