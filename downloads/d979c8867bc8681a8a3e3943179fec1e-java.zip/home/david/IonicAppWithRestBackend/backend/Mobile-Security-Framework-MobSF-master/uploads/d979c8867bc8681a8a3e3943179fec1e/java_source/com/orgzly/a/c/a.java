/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a.c;

import com.orgzly.a.g;
import java.util.ArrayList;

public class a
extends ArrayList<String> {
    public a() {
    }

    public a(String arrstring) {
        arrstring = arrstring.split(" ");
        int n2 = arrstring.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            String string = arrstring[i2].trim();
            if (string.length() <= 0) continue;
            this.add(string);
        }
    }

    @Override
    public String toString() {
        return g.a(this, " ");
    }
}

