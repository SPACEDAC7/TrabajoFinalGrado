/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a;

import java.util.regex.Pattern;

public class d {
    public static final Pattern a = Pattern.compile("((([\\[<])[0-9]{4,}-[0-9]{2}-[0-9]{2} ?[^]\r\n>]*?[\\]>])(--?-?(([\\[<])[0-9]{4,}-[0-9]{2}-[0-9]{2} ?[^]\r\n>]*?[\\]>]))?)");
    public static final Pattern b = Pattern.compile("[0-9]{4,}-[0-9][0-9]-[0-9][0-9] [^>\n]*?([.+]?\\+[0-9]+[hdwmy](/[0-9]+[hdwmy])?)");
    public static final Pattern c = Pattern.compile("([-]{1,2}+)([0-9]+)([hdwmy])");
    public static final Pattern d = Pattern.compile("(([.+]?\\+)([0-9]+)([hdwmy]))(/([0-9]+)([hdwmy]))?");
    public static final Pattern e = Pattern.compile("(([0-9]{4,})-([0-9]{2})-([0-9]{2})( +[^]+0-9>\r\n -]+)?( +([0-9]{1,2}):([0-9]{2}))?)");
    public static final Pattern f = Pattern.compile("(([012]?[0-9]):([0-5][0-9]))(-(([012]?[0-9]):([0-5][0-9])))?");
    public static final Pattern g = Pattern.compile("(SCHEDULED:|CLOSED:|DEADLINE:) *((([\\[<])[0-9]{4,}-[0-9]{2}-[0-9]{2} ?[^]\r\n>]*?[\\]>])(--?-?(([\\[<])[0-9]{4,}-[0-9]{2}-[0-9]{2} ?[^]\r\n>]*?[\\]>]))?)");
    public static final Pattern h = Pattern.compile("^([\\*]+)\\s+(.*)\\s*$");
    public static final Pattern i = Pattern.compile("^\\s*\\[#([A-Z])\\](.*)");
    public static final Pattern j = Pattern.compile("^(.*)\\s+:(\\S+):\\s*$");
    public static final Pattern k = Pattern.compile("^:([^:\\s]+):\\s+(.*)\\s*$");
}

