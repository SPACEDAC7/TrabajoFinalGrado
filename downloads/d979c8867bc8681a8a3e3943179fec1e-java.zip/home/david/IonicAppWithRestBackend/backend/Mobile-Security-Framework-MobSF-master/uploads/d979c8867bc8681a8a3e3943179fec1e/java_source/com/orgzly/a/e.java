/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a;

public class e {
    private String a;
    private String b;

    public e(String string, String string2) {
        this.a = string;
        this.b = string2;
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }
}

