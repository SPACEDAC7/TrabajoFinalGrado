/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a;

import com.orgzly.a.c.a;

public class f {
    private a a;
    private a b;

    public f(a a2, a a3) {
        this.a = a2;
        this.b = a3;
    }

    public f(String string) {
        string = string.trim();
        if (string.length() == 0) {
            this.a = new a();
            this.b = new a();
            return;
        }
        int n2 = string.indexOf(124);
        if (n2 == -1) {
            this.a = new a(string);
            string = (String)this.a.remove(this.a.size() - 1);
            this.b = new a();
            this.b.add(string);
            return;
        }
        this.a = new a(string.substring(0, n2));
        this.b = new a(string.substring(n2 + 1));
    }

    public a a() {
        return this.a;
    }

    public a b() {
        return this.b;
    }

    public String toString() {
        return this.a.toString() + " | " + this.b.toString();
    }
}

