/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.a;

import java.util.Collection;
import java.util.Iterator;

public class g {
    public static String a(String string) {
        return string.replaceFirst("\n+[\\s]*$", "").replaceFirst("^[\\s]*\n", "");
    }

    public static String a(Collection collection, String string) {
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = 0;
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(iterator.next());
            if (n2 < collection.size() - 1) {
                stringBuilder.append(string);
            }
            ++n2;
        }
        return stringBuilder.toString();
    }

    public static boolean b(String string) {
        if (string == null || string.length() == 0) {
            return true;
        }
        return false;
    }
}

