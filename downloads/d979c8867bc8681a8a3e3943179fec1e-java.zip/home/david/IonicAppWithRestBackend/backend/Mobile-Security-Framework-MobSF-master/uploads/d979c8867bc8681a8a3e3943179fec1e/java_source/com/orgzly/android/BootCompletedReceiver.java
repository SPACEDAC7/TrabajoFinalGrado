/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 */
package com.orgzly.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.orgzly.android.i;
import com.orgzly.android.prefs.a;

public class BootCompletedReceiver
extends BroadcastReceiver {
    public static final String a = BootCompletedReceiver.class.getName();

    public void onReceive(Context context, Intent intent) {
        if (a.k(context)) {
            i.a(context);
        }
    }
}

