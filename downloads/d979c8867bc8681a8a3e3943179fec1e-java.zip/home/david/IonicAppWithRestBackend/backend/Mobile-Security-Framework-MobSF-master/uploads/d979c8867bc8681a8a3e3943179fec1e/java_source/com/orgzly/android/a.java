/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android;

import com.orgzly.android.a.i;
import com.orgzly.android.a.j;
import com.orgzly.android.sync.b;

public class a {
    private long a;
    private boolean b;
    private String c;
    private long d;
    private i e;
    private j f;
    private String g;
    private String h;
    private String i;
    private String j;
    private b k;
    private com.orgzly.android.b l;
    private com.orgzly.a.b m = new com.orgzly.a.b();

    public a(String string) {
        this(string, "", System.currentTimeMillis(), false);
    }

    public a(String string, String string2, long l2, boolean bl2) {
        this.c = string;
        this.j = string2;
        this.d = l2;
        this.b = bl2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String a(a a2) {
        String string = null;
        if (a2 == null) return string;
        if (a2.k().a() == null) return a2.c();
        return a2.k().a();
    }

    public static String b(a a2) {
        String string;
        String string2 = string = null;
        if (a2 != null) {
            string2 = string;
            if (a2.k().a() != null) {
                string2 = a2.c();
            }
        }
        return string2;
    }

    public long a() {
        return this.a;
    }

    public void a(long l2) {
        this.a = l2;
    }

    public void a(i i2) {
        this.e = i2;
    }

    public void a(j j2) {
        this.f = j2;
    }

    public void a(com.orgzly.android.b b2) {
        this.l = b2;
    }

    public void a(String string) {
        this.j = string;
    }

    public String b() {
        return this.j;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void b(String string) {
        this.k = null;
        if (string == null) return;
        try {
            this.k = b.valueOf(string);
            return;
        }
        catch (IllegalArgumentException var1_2) {
            var1_2.printStackTrace();
            return;
        }
    }

    public String c() {
        return this.c;
    }

    public void c(String string) {
        this.g = string;
    }

    public void d(String string) {
        this.h = string;
    }

    public boolean d() {
        if (this.f != null && this.d > this.f.d()) {
            return true;
        }
        return false;
    }

    public long e() {
        return this.d;
    }

    public void e(String string) {
        this.i = string;
    }

    public j f() {
        return this.f;
    }

    public i g() {
        return this.e;
    }

    public boolean h() {
        return this.b;
    }

    public b i() {
        return this.k;
    }

    public com.orgzly.android.b j() {
        return this.l;
    }

    public com.orgzly.a.b k() {
        return this.m;
    }

    public String l() {
        return this.h;
    }

    public String m() {
        return this.g;
    }

    public String n() {
        return this.i;
    }

    public String toString() {
        return a.a(this);
    }
}

