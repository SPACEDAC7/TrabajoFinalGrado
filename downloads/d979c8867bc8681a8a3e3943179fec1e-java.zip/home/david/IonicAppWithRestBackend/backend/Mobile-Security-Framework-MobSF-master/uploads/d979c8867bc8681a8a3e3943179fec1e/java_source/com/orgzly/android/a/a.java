/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.provider.DocumentsContract
 *  android.util.Log
 */
package com.orgzly.android.a;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.util.Log;
import com.orgzly.android.a.g;
import com.orgzly.android.a.j;
import com.orgzly.android.b.e;
import com.orgzly.android.c;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class a
implements g {
    private static final String a = a.class.getName();
    private final Context b;
    private final Uri c;
    private final android.support.v4.h.a d;

    public a(Context context, Uri uri) {
        this.b = context;
        this.c = uri;
        this.d = android.support.v4.h.a.b(context, uri);
    }

    @Override
    public j a(Uri uri, File file) {
        android.support.v4.h.a a2 = android.support.v4.h.a.a(this.b, uri);
        InputStream inputStream = this.b.getContentResolver().openInputStream(uri);
        try {
            e.a(inputStream, file);
            long l2 = a2.c();
            long l3 = a2.c();
            return new j(this.c, uri, String.valueOf(l2), l3);
        }
        finally {
            inputStream.close();
        }
    }

    @Override
    public j a(Uri uri, String string) {
        android.support.v4.h.a a2 = android.support.v4.h.a.a(this.b, uri);
        android.support.v4.h.a a3 = this.d.a(string = c.a(string, c.b(a2.b()).b()));
        if (a3 != null) {
            throw new IOException("File at " + (Object)a3.a() + " already exists");
        }
        if (Build.VERSION.SDK_INT >= 21) {
            uri = DocumentsContract.renameDocument((ContentResolver)this.b.getContentResolver(), (Uri)uri, (String)string);
            long l2 = a2.c();
            return new j(this.b(), uri, String.valueOf(l2), l2);
        }
        throw new IOException("Renaming notebooks is not supported on your device (requires at least Lollipop)");
    }

    @Override
    public j a(File file, String object) {
        if (!file.exists()) {
            throw new FileNotFoundException("File " + file + " does not exist");
        }
        android.support.v4.h.a a2 = this.d.a((String)object);
        if (a2 != null) {
            a2.d();
        }
        if ((a2 = this.d.a("text/*", (String)object)) == null) {
            throw new IOException("Failed creating " + (String)object + " in " + (Object)this.c);
        }
        Uri uri = a2.a();
        object = this.b.getContentResolver().openOutputStream(uri);
        try {
            e.a(file, (OutputStream)object);
            long l2 = a2.c();
            long l3 = a2.c();
            return new j(this.b(), uri, String.valueOf(l2), l3);
        }
        finally {
            if (object != null) {
                object.close();
            }
        }
    }

    @Override
    public void a(Uri uri) {
        android.support.v4.h.a a2 = android.support.v4.h.a.a(this.b, uri);
        if (a2 != null && a2.e() && !a2.d()) {
            throw new IOException("Failed deleting document " + (Object)uri);
        }
    }

    @Override
    public boolean a() {
        return false;
    }

    @Override
    public Uri b() {
        return this.c;
    }

    @Override
    public List<j> c() {
        ArrayList<j> arrayList = new ArrayList<j>();
        android.support.v4.h.a[] arra = this.d.f();
        if (arra != null) {
            for (int i2 = 0; i2 < arra.length; ++i2) {
                android.support.v4.h.a a2 = arra[i2];
                if (!c.a(a2.b())) continue;
                arrayList.add(new j(this.b(), a2.a(), String.valueOf(a2.c()), a2.c()));
            }
        } else {
            Log.e((String)a, (String)("Listing files in " + (Object)this.b() + " returned null."));
        }
        return arrayList;
    }

    @Override
    public String toString() {
        return this.b().toString();
    }
}

