/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.net.Uri$Builder
 *  android.util.Log
 */
package com.orgzly.android.a;

import android.net.Uri;
import android.util.Log;
import com.orgzly.android.a.g;
import com.orgzly.android.a.j;
import com.orgzly.android.c;
import com.orgzly.android.e;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class b
implements g {
    private static final String a = b.class.getName();
    private File b;
    private final Uri c;

    public b(String string, boolean bl2) {
        this.c = Uri.parse((String)string);
        this.b = new File(this.c.getPath());
        if (bl2) {
            e.a(this.b);
        }
        this.a(this.b);
    }

    private void a(File file) {
        if (!file.isDirectory() && !file.mkdirs()) {
            throw new IOException("Failed creating directory " + file);
        }
    }

    @Override
    public j a(Uri uri, File file) {
        File file2 = new File(uri.getPath());
        com.orgzly.android.b.e.a(file2, file);
        long l2 = file2.lastModified();
        long l3 = file2.lastModified();
        return new j(this.c, uri, String.valueOf(l2), l3);
    }

    @Override
    public j a(Uri uri, String object) {
        File file = new File(uri.getPath());
        uri = com.orgzly.android.b.j.a(uri, (String)object);
        object = new File(uri.getPath());
        if (object.exists()) {
            throw new IOException("File " + object + " already exists");
        }
        if (!file.renameTo((File)object)) {
            throw new IOException("Failed renaming " + file + " to " + object);
        }
        long l2 = object.lastModified();
        long l3 = object.lastModified();
        return new j(this.c, uri, String.valueOf(l2), l3);
    }

    @Override
    public j a(File file, String string) {
        if (!file.exists()) {
            throw new FileNotFoundException("File " + file + " does not exist");
        }
        File file2 = new File(this.b, string);
        this.a(file2.getParentFile());
        com.orgzly.android.b.e.a(com.orgzly.android.b.e.a(file), file2);
        long l2 = file2.lastModified();
        long l3 = file2.lastModified();
        file = this.c.buildUpon().appendPath(string).build();
        return new j(this.c, (Uri)file, String.valueOf(l2), l3);
    }

    @Override
    public void a(Uri uri) {
        File file = new File(uri.getPath());
        if (file.exists() && !file.delete()) {
            throw new IOException("Failed deleting file " + uri.getPath());
        }
    }

    @Override
    public boolean a() {
        return false;
    }

    @Override
    public Uri b() {
        return this.c;
    }

    @Override
    public List<j> c() {
        ArrayList<j> arrayList = new ArrayList<j>();
        Object[] arrobject = this.b.listFiles(new FilenameFilter(){

            @Override
            public boolean accept(File file, String string) {
                return c.a(string);
            }
        });
        if (arrobject != null) {
            Arrays.sort(arrobject);
            for (int i2 = 0; i2 < arrobject.length; ++i2) {
                Uri uri = this.c.buildUpon().appendPath(arrobject[i2].getName()).build();
                arrayList.add(new j(this.c, uri, String.valueOf(arrobject[i2].lastModified()), arrobject[i2].lastModified()));
            }
        } else {
            Log.e((String)a, (String)("Listing files in " + this.b + " returned null. No storage permission?"));
        }
        return arrayList;
    }

    @Override
    public String toString() {
        return this.c.toString();
    }

}

