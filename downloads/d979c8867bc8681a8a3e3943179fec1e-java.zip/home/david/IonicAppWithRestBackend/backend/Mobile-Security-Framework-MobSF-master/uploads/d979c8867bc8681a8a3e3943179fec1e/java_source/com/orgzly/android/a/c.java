/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.net.Uri
 *  android.net.Uri$Builder
 */
package com.orgzly.android.a;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import com.dropbox.core.android.a;
import com.dropbox.core.e.b.ac;
import com.dropbox.core.e.b.ak;
import com.dropbox.core.e.b.as;
import com.dropbox.core.e.b.b;
import com.dropbox.core.e.b.k;
import com.dropbox.core.e.b.m;
import com.dropbox.core.e.b.p;
import com.dropbox.core.e.b.q;
import com.dropbox.core.e.b.y;
import com.dropbox.core.e.b.z;
import com.dropbox.core.f;
import com.dropbox.core.g;
import com.dropbox.core.i;
import com.orgzly.android.a.j;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class c {
    private static final String a = c.class.getName();
    private Context b;
    private com.dropbox.core.e.a c;
    private boolean d = false;

    public c(Context object) {
        this.b = object;
        object = this.d();
        if (object != null) {
            this.c = this.b((String)object);
        }
    }

    private com.dropbox.core.e.a b(String string) {
        String string2 = Locale.getDefault().toString();
        return new com.dropbox.core.e.a(i.a(String.format("%s/%s", "com.orgzly", "1.4.11 (fdroid)")).a(string2).a(), string);
    }

    private void c(String string) {
        com.orgzly.android.prefs.a.c(this.b, string);
    }

    private String d() {
        return com.orgzly.android.prefs.a.A(this.b);
    }

    private void e() {
        com.orgzly.android.prefs.a.c(this.b, null);
    }

    public j a(Uri object, Uri uri, Uri uri2) {
        try {
            k k2 = (k)this.c.a().b(uri.getPath(), uri2.getPath());
            object = new j((Uri)object, uri2, k2.d(), k2.c().getTime());
            return object;
        }
        catch (Exception var1_2) {
            var1_2.printStackTrace();
            if (var1_2.getMessage() != null) {
                throw new IOException("Failed moving " + (Object)uri + " to " + (Object)uri2 + ": " + var1_2.getMessage(), var1_2);
            }
            throw new IOException("Failed moving " + (Object)uri + " to " + (Object)uri2 + ": " + var1_2.toString(), var1_2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public j a(Uri object, Uri uri, File object2) {
        g g2;
        block8 : {
            block7 : {
                if (!this.a()) {
                    throw new IOException("Not linked to Dropbox");
                }
                object2 = new BufferedOutputStream(new FileOutputStream((File)object2));
                ac ac2 = this.c.a().b(uri.getPath());
                if (!(ac2 instanceof k)) break block7;
                ac2 = (k)ac2;
                String string = ac2.d();
                long l2 = ac2.c().getTime();
                this.c.a().a(ac2.b(), string).a((OutputStream)object2);
                object = new j((Uri)object, uri, string, l2);
                object2.close();
                return object;
            }
            try {
                try {
                    throw new IOException("Failed downloading Dropbox file " + (Object)uri + ": Not a file");
                }
                catch (g g2) {
                    if (g2.getMessage() == null) break block8;
                    throw new IOException("Failed downloading Dropbox file " + (Object)uri + ": " + g2.getMessage());
                }
            }
            catch (Throwable var1_3) {
                object2.close();
                throw var1_3;
            }
        }
        throw new IOException("Failed downloading Dropbox file " + (Object)uri + ": " + g2.toString());
    }

    public j a(File object, Uri uri, String string) {
        string = uri.buildUpon().appendPath(string).build();
        if (!this.a()) {
            throw new IOException("Not linked to Dropbox");
        }
        if (object.length() > 157286400) {
            throw new IOException("File larger then 150 MB");
        }
        object = new FileInputStream((File)object);
        try {
            object = (k)this.c.a().e(string.getPath()).a(as.b).a((InputStream)object);
            return new j(uri, (Uri)string, object.d(), object.c().getTime());
        }
        catch (g var1_2) {
            if (var1_2.getMessage() != null) {
                throw new IOException("Failed overwriting " + string.getPath() + " on Dropbox: " + var1_2.getMessage());
            }
            throw new IOException("Failed overwriting " + string.getPath() + " on Dropbox: " + var1_2.toString());
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public List<j> a(Uri var1_1) {
        block9 : {
            if (!this.a()) {
                throw new IOException("Not linked to Dropbox");
            }
            var4_3 = new ArrayList<j>();
            try {
                var2_5 = var3_4 = var1_1.getPath();
                if (var3_4 == null) {
                    var2_5 = "/";
                }
                if (this.c.a().b((String)var2_5) instanceof m == false) throw new IOException("Not a directory: " + (Object)var1_1);
                var2_5 = this.c.a().c((String)var2_5);
lbl10: // 4 sources:
                for (ac var5_6 : var2_5.a()) {
                    if (!(var5_6 instanceof k) || !com.orgzly.android.c.a((var5_6 = (k)var5_6).a())) continue;
                    var4_3.add(new j(var1_1, var1_1.buildUpon().appendPath(var5_6.a()).build(), var5_6.d(), var5_6.c().getTime()));
                }
                if (!var2_5.c()) {
                    return var4_3;
                }
            }
            catch (g var1_2) {
                var1_2.printStackTrace();
                if (var1_2 instanceof q && ((q)var1_2).a.b() == z.a) {
                    return var4_3;
                }
                break block9;
            }
            var2_5 = this.c.a().d(var2_5.b());
            ** GOTO lbl10
        }
        if (var1_2.getMessage() == null) throw new IOException("Failed getting the list of Dropbox files: " + var1_2.toString());
        throw new IOException("Failed getting the list of Dropbox files: " + var1_2.getMessage());
    }

    public void a(Activity activity) {
        this.d = true;
        a.a((Context)activity, "");
    }

    public void a(String string) {
        try {
            this.c.a().a(string);
            return;
        }
        catch (g var2_2) {
            var2_2.printStackTrace();
            if (var2_2.getMessage() != null) {
                throw new IOException("Failed deleting " + string + " on Dropbox: " + var2_2.getMessage());
            }
            throw new IOException("Failed deleting " + string + " on Dropbox: " + var2_2.toString());
        }
    }

    public boolean a() {
        if (this.c != null) {
            return true;
        }
        return false;
    }

    public void b() {
        this.c = null;
        this.e();
        this.d = false;
    }

    public boolean c() {
        if (this.c == null && this.d) {
            String string;
            String string2 = string = this.d();
            if (string == null) {
                string2 = string = a.a();
                if (string != null) {
                    this.c(string);
                    string2 = string;
                }
            }
            if (string2 != null) {
                this.c = this.b(string2);
                return true;
            }
        }
        return false;
    }
}

