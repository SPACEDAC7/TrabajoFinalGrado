/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 */
package com.orgzly.android.a;

import android.content.Context;
import android.net.Uri;
import com.orgzly.android.a.c;
import com.orgzly.android.a.g;
import com.orgzly.android.a.j;
import java.io.File;
import java.util.List;

public class d
implements g {
    private final Uri a;
    private final c b;

    public d(Context context, Uri uri) {
        this.a = uri;
        this.b = new c(context);
    }

    @Override
    public j a(Uri uri, File file) {
        return this.b.a(this.a, uri, file);
    }

    @Override
    public j a(Uri uri, String string) {
        string = com.orgzly.android.b.j.a(uri, string);
        return this.b.a(this.a, uri, (Uri)string);
    }

    @Override
    public j a(File file, String string) {
        return this.b.a(file, this.a, string);
    }

    @Override
    public void a(Uri uri) {
        this.b.a(uri.getPath());
    }

    @Override
    public boolean a() {
        return true;
    }

    @Override
    public Uri b() {
        return this.a;
    }

    @Override
    public List<j> c() {
        return this.b.a(this.a);
    }

    @Override
    public String toString() {
        return this.a.toString();
    }
}

