/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.net.Uri$Builder
 */
package com.orgzly.android.a;

import android.content.Context;
import android.net.Uri;
import com.orgzly.android.a.g;
import com.orgzly.android.a.j;
import java.io.File;
import java.util.List;

public class e
implements g {
    private final Uri a;
    private Context b;

    public e(Context context, String string) {
        this.b = context;
        this.a = Uri.parse((String)string);
    }

    @Override
    public j a(Uri uri, File file) {
        return com.orgzly.android.provider.b.e.a(this.b, this.a, uri, file);
    }

    @Override
    public j a(Uri uri, String string) {
        string = com.orgzly.android.b.j.a(uri, string);
        return com.orgzly.android.provider.b.e.a(this.b, uri, (Uri)string);
    }

    @Override
    public j a(File object, String object2) {
        object = com.orgzly.android.b.e.a((File)object);
        String string = "MockedRevision-" + System.currentTimeMillis();
        long l2 = System.currentTimeMillis();
        object2 = this.a.buildUpon().appendPath((String)object2).build();
        object2 = new j(this.a, (Uri)object2, string, l2);
        return com.orgzly.android.provider.b.e.a(this.b, (j)object2, (String)object);
    }

    @Override
    public void a(Uri uri) {
    }

    @Override
    public boolean a() {
        return false;
    }

    @Override
    public Uri b() {
        return this.a;
    }

    @Override
    public List<j> c() {
        return com.orgzly.android.provider.b.e.a(this.b, this.a);
    }

    @Override
    public String toString() {
        return this.a.toString();
    }
}

