/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 */
package com.orgzly.android.a;

import android.content.Context;
import android.net.Uri;
import com.orgzly.android.a.e;
import com.orgzly.android.a.g;
import com.orgzly.android.a.j;
import java.io.File;
import java.util.List;

public class f
implements g {
    private e a;

    public f(Context context, String string) {
        this.a = new e(context, string);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public j a(Uri uri, File file) {
        try {
            Thread.sleep(200);
            do {
                return this.a.a(uri, file);
                break;
            } while (true);
        }
        catch (InterruptedException var3_3) {
            return this.a.a(uri, file);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public j a(Uri uri, String string) {
        try {
            Thread.sleep(200);
            do {
                return this.a.a(uri, string);
                break;
            } while (true);
        }
        catch (InterruptedException var3_3) {
            return this.a.a(uri, string);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public j a(File file, String string) {
        try {
            Thread.sleep(200);
            do {
                return this.a.a(file, string);
                break;
            } while (true);
        }
        catch (InterruptedException var3_3) {
            return this.a.a(file, string);
        }
    }

    @Override
    public void a(Uri uri) {
    }

    @Override
    public boolean a() {
        return false;
    }

    @Override
    public Uri b() {
        return this.a.b();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public List<j> c() {
        try {
            Thread.sleep(100);
            do {
                return this.a.c();
                break;
            } while (true);
        }
        catch (InterruptedException var1_1) {
            return this.a.c();
        }
    }
}

