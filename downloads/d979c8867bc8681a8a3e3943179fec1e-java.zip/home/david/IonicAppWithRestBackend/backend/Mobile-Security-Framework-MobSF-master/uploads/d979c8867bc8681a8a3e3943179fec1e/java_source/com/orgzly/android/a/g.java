/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.orgzly.android.a;

import android.net.Uri;
import com.orgzly.android.a.j;
import java.io.File;
import java.util.List;

public interface g {
    public j a(Uri var1, File var2);

    public j a(Uri var1, String var2);

    public j a(File var1, String var2);

    public void a(Uri var1);

    public boolean a();

    public Uri b();

    public List<j> c();

    public String toString();
}

