/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 */
package com.orgzly.android.a;

import android.net.Uri;

public class i {
    protected Uri a;
    protected Uri b;

    public i(Uri uri, Uri uri2) {
        this.a = uri;
        this.b = uri2;
    }

    public Uri a() {
        return this.a;
    }

    public Uri b() {
        return this.b;
    }

    public String toString() {
        return this.b.toString();
    }
}

