/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.net.Uri$Builder
 */
package com.orgzly.android.a;

import android.net.Uri;
import com.orgzly.android.a.i;

public class j
extends i {
    private String c;
    private long d;

    public j(Uri uri, Uri uri2, String string, long l2) {
        super(uri, uri2);
        this.c = string;
        this.d = l2;
    }

    public String c() {
        return this.c;
    }

    public long d() {
        return this.d;
    }

    @Override
    public String toString() {
        return this.b.buildUpon().appendQueryParameter("revision", this.c).appendQueryParameter("mtime", String.valueOf(this.d)).build().toString();
    }
}

