/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android;

public class b {
    private final a a;
    private final String b;
    private final long c;

    public b(a a2, String string) {
        this(a2, string, System.currentTimeMillis());
    }

    public b(a a2, String string, long l2) {
        this.a = a2;
        this.b = string;
        this.c = l2;
    }

    public a a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public long c() {
        return this.c;
    }

    public String toString() {
        return "[" + this.getClass().getSimpleName() + " " + (Object)((Object)this.a) + " | " + this.b + " | " + this.c + "]";
    }

    public static enum a {
        a,
        b,
        c;
        

        private a() {
        }
    }

}

