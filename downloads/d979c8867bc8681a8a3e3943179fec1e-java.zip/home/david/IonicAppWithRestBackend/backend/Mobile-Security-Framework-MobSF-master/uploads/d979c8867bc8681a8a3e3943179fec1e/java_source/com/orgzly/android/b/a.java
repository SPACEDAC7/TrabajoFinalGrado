/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.orgzly.android.b;

import android.content.Context;
import android.support.design.widget.Snackbar;
import android.support.v4.c.d;
import android.view.View;
import com.orgzly.android.ui.b;

public class a {
    private static String a(int n2) {
        switch (n2) {
            default: {
                throw new IllegalArgumentException("Unknown permission for request code " + n2);
            }
            case 1: {
                return "android.permission.WRITE_EXTERNAL_STORAGE";
            }
            case 2: {
                return "android.permission.WRITE_EXTERNAL_STORAGE";
            }
            case 3: 
        }
        return "android.permission.WRITE_EXTERNAL_STORAGE";
    }

    public static boolean a(Context context, int n2) {
        if (d.a(context, a.a(n2)) != 0) {
            return true;
        }
        return false;
    }

    public static boolean a(final b b2, int n2) {
        String string = a.a(n2);
        int n3 = a.b(n2);
        if (a.a((Context)b2, n2)) {
            if (android.support.v4.b.a.a(b2, string)) {
                b2.a(Snackbar.a(b2.findViewById(2131689588), n3, 8000).a(2131230939, new View.OnClickListener(){

                    public void onClick(View view) {
                        com.orgzly.android.ui.c.a.b(b2);
                    }
                }));
                return false;
            }
            android.support.v4.b.a.a(b2, new String[]{string}, n2);
            return false;
        }
        return true;
    }

    private static int b(int n2) {
        switch (n2) {
            default: {
                throw new IllegalArgumentException("Unknown rationale for request code " + n2);
            }
            case 1: {
                return 2131230904;
            }
            case 2: {
                return 2131230903;
            }
            case 3: 
        }
        return 2131230905;
    }

}

