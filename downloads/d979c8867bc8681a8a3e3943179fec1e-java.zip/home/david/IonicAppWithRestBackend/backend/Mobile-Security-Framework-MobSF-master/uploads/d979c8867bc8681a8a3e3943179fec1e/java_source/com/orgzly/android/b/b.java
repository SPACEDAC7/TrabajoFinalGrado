/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.b;

import java.util.AbstractList;
import java.util.Arrays;
import java.util.List;

public class b<T>
extends AbstractList {
    private List<T> a;

    public b(T[] arrT) {
        this.a = Arrays.asList(arrT);
    }

    private int a(int n2) {
        while (n2 < 0) {
            n2 += this.a.size();
        }
        return n2 % this.a.size();
    }

    @Override
    public T get(int n2) {
        if (this.a.size() == 0) {
            throw new IndexOutOfBoundsException("Empty array");
        }
        n2 = this.a(n2);
        return this.a.get(n2);
    }

    @Override
    public int indexOf(Object object) {
        return this.a.indexOf(object);
    }

    @Override
    public int size() {
        return this.a.size();
    }
}

