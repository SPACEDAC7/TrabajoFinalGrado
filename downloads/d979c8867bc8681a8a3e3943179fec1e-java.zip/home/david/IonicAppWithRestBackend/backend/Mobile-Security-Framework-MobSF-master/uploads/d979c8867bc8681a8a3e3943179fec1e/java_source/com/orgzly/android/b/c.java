/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.b;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

public class c {
    public static final a a = a.a;
    private InputStream b;
    private boolean c = false;
    private String d;

    public static c a(InputStream inputStream) {
        c c2 = new c();
        c2.b = inputStream;
        return c2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b() {
        if (!this.c) {
            switch (a) {
                default: {
                    break;
                }
                case a: {
                    this.c();
                }
            }
        }
        this.c = true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void c() {
        var5_1 = new byte[4096];
        var4_2 = new a.a.a.c(null);
        try {
            var3_6 = new BufferedInputStream(this.b);
            ** GOTO lbl12
        }
        catch (Throwable var3_7) {
            var2_11 = null;
            ** GOTO lbl49
            catch (IOException var4_5) {
                var3_6 = null;
                ** GOTO lbl-1000
            }
lbl12: // 1 sources:
            do {
                var2_11 = var3_6;
                try {
                    try {
                        var1_10 = var3_6.read(var5_1);
                        if (var1_10 > 0) {
                            var2_11 = var3_6;
                            if (!var4_2.a()) {
                                var2_11 = var3_6;
                                var4_2.a(var5_1, 0, var1_10);
                                continue;
                            }
                        }
                        ** GOTO lbl34
                    }
                    catch (IOException var4_3) lbl-1000: // 2 sources:
                    {
                        var2_11 = var3_6;
                        var4_4.printStackTrace();
                        if (var3_6 == null) return;
                        try {
                            var3_6.close();
                            return;
                        }
                        catch (IOException var2_13) {
                            var2_13.printStackTrace();
                            return;
                        }
lbl34: // 1 sources:
                        if (var3_6 != null) {
                            try {
                                var3_6.close();
                            }
                            catch (IOException var2_12) {
                                var2_12.printStackTrace();
                            }
                        }
                        var4_2.c();
                        var2_11 = var4_2.b();
                        if (var2_11 != null) {
                            this.d = var2_11;
                        }
                        var4_2.d();
                        return;
                    }
                }
                catch (Throwable var3_9) {}
                break;
            } while (true);
lbl49: // 2 sources:
            if (var2_11 == null) throw var3_8;
            try {
                var2_11.close();
            }
            catch (IOException var2_14) {
                var2_14.printStackTrace();
                throw var3_8;
            }
            throw var3_8;
        }
    }

    public String a() {
        this.b();
        return this.d;
    }

    public static enum a {
        a;
        

        private a() {
        }
    }

}

