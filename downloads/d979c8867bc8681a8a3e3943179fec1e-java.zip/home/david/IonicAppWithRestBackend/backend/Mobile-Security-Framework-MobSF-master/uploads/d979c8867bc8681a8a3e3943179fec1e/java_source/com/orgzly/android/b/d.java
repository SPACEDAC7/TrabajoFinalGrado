/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.b;

import java.io.IOException;

public class d {
    public static IOException a(Exception exception, String string) {
        if (exception.getCause() != null) {
            return new IOException(string + ": " + exception.getCause());
        }
        return new IOException(string + ": " + exception.toString());
    }
}

