/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.widget.TextView
 */
package com.orgzly.android.b;

import android.net.Uri;
import android.support.design.widget.TextInputLayout;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.security.MessageDigest;

public class e {
    public static int a(String string) {
        int n2 = 0;
        if (string == null) {
            return 0;
        }
        int n3 = 1;
        while ((n2 = string.indexOf("\n", n2)) != -1) {
            ++n3;
            ++n2;
        }
        return n3;
    }

    public static String a(File object) {
        int n2;
        StringBuffer stringBuffer = new StringBuffer();
        object = new BufferedReader(new FileReader((File)object));
        char[] arrc = new char[1024];
        while ((n2 = object.read(arrc)) != -1) {
            stringBuffer.append(String.valueOf(arrc, 0, n2));
        }
        object.close();
        return stringBuffer.toString();
    }

    public static void a(TextView textView, final TextInputLayout textInputLayout) {
        textView.addTextChangedListener(new TextWatcher(){

            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
                textInputLayout.setError(null);
            }

            public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
            }
        });
    }

    public static void a(File object, File object2) {
        int n2;
        object = new FileInputStream((File)object);
        object2 = new FileOutputStream((File)object2);
        byte[] arrby = new byte[1024];
        while ((n2 = object.read(arrby)) > 0) {
            object2.write(arrby, 0, n2);
        }
        object.close();
        object2.close();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(File object, OutputStream outputStream) {
        object = new FileInputStream((File)object);
        try {
            int n2;
            byte[] arrby = new byte[1024];
            while ((n2 = object.read(arrby, 0, arrby.length)) != -1) {
                outputStream.write(arrby, 0, n2);
            }
            return;
        }
        finally {
            object.close();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(InputStream inputStream, File object) {
        object = new FileOutputStream((File)object);
        try {
            int n2;
            byte[] arrby = new byte[1024];
            while ((n2 = inputStream.read(arrby, 0, arrby.length)) != -1) {
                object.write(arrby, 0, n2);
            }
            return;
        }
        finally {
            object.close();
        }
    }

    public static void a(String string, File object) {
        object = new PrintWriter((File)object);
        try {
            object.write(string);
            return;
        }
        finally {
            object.close();
        }
    }

    private static boolean a(char c2) {
        if (c2 >= 'A' && c2 <= 'F' || c2 >= 'a' && c2 <= 'f' || c2 >= '0' && c2 <= '9') {
            return true;
        }
        return false;
    }

    private static boolean a(char c2, String string) {
        if (c2 >= 'A' && c2 <= 'Z' || c2 >= 'a' && c2 <= 'z' || c2 >= '0' && c2 <= '9' || "_-!.~'()*".indexOf(c2) != -1 || string != null && string.indexOf(c2) != -1) {
            return true;
        }
        return false;
    }

    public static String b(String string) {
        return "\u201c" + string + "\u201d";
    }

    public static long c(String arrby) {
        long l2;
        int n2;
        long l3;
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
            messageDigest.update(arrby.getBytes("UTF-8"));
            arrby = messageDigest.digest();
            n2 = 0;
            l3 = 0;
        }
        catch (Exception var0_1) {
            l2 = 0;
            var0_1.printStackTrace();
        }
        do {
            l2 = l3;
            if (n2 < 8) {
                byte by = arrby[n2];
                l2 = by & 255;
                ++n2;
                l3 = l3 << 8 | l2;
                continue;
            }
            break;
            break;
        } while (true);
        return l2;
    }

    /*
     * Enabled aggressive block sorting
     */
    static boolean d(String string) {
        boolean bl2 = false;
        int n2 = 0;
        for (int i2 = 0; i2 < string.length(); ++i2) {
            char c2 = string.charAt(i2);
            if (!e.a(c2, "/%")) {
                return true;
            }
            if (n2 > 0 && !e.a(c2)) {
                return true;
            }
            if (c2 == '%') {
                n2 = 2;
                continue;
            }
            --n2;
        }
        if (n2 <= 0) return bl2;
        return true;
    }

    public static String e(String string) {
        int n2 = string.indexOf(":");
        String string2 = string;
        if (n2 != -1) {
            string2 = string;
            if (e.d(string.substring(n2 + 1))) {
                string2 = string.substring(0, n2 + 1) + Uri.encode((String)string.substring(n2 + 1), (String)"/");
            }
        }
        return string2;
    }

}

