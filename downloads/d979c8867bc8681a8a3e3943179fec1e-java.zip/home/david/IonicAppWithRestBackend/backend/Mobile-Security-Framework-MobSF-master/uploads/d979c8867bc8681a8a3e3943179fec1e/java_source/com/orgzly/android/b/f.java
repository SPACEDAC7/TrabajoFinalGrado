/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.SpannableStringBuilder
 *  android.text.style.URLSpan
 */
package com.orgzly.android.b;

import android.text.SpannableStringBuilder;
import android.text.style.URLSpan;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class f {
    public static SpannableStringBuilder a(String string) {
        string = new SpannableStringBuilder((CharSequence)string);
        f.a((SpannableStringBuilder)string, "((https?|mailto|tel|voicemail|geo|sms|smsto|mms|mmsto):[^]\\s]+)", true);
        f.a((SpannableStringBuilder)string, "(([^]]+))", false);
        f.b((SpannableStringBuilder)string, "((https?|mailto|tel|voicemail|geo|sms|smsto|mms|mmsto):[^]\\s]+)", true);
        f.c((SpannableStringBuilder)string, "((https?|mailto|tel|voicemail|geo|sms|smsto|mms|mmsto):\\S+)", true);
        return string;
    }

    private static void a(SpannableStringBuilder spannableStringBuilder, String string, int n2, int n3) {
        spannableStringBuilder.setSpan((Object)new URLSpan(string), n2, n3, 17);
    }

    private static void a(SpannableStringBuilder spannableStringBuilder, String object, boolean bl2) {
        Pattern pattern = Pattern.compile("\\[\\[" + (String)object + "\\]\\[([^]]+)\\]\\]");
        object = pattern.matcher((CharSequence)spannableStringBuilder);
        while (object.find()) {
            String string = object.group(1);
            String string2 = object.group(3);
            spannableStringBuilder.replace(object.start(), object.end(), (CharSequence)string2);
            if (bl2) {
                f.a(spannableStringBuilder, string, object.start(), object.start() + string2.length());
            }
            object = pattern.matcher((CharSequence)spannableStringBuilder);
        }
    }

    private static void b(SpannableStringBuilder spannableStringBuilder, String object, boolean bl2) {
        Pattern pattern = Pattern.compile("\\[\\[" + (String)object + "\\]\\]");
        object = pattern.matcher((CharSequence)spannableStringBuilder);
        while (object.find()) {
            String string = object.group(1);
            spannableStringBuilder.replace(object.start(), object.end(), (CharSequence)string);
            if (bl2) {
                f.a(spannableStringBuilder, string, object.start(), object.start() + string.length());
            }
            object = pattern.matcher((CharSequence)spannableStringBuilder);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void c(SpannableStringBuilder spannableStringBuilder, String object, boolean bl2) {
        if (bl2) {
            object = Pattern.compile((String)object).matcher((CharSequence)spannableStringBuilder);
            while (object.find()) {
                String string = object.group(1);
                if (((URLSpan[])spannableStringBuilder.getSpans(object.start(), object.start() + 1, (Class)URLSpan.class)).length != 0) continue;
                f.a(spannableStringBuilder, string, object.start(), object.end());
            }
        }
    }
}

