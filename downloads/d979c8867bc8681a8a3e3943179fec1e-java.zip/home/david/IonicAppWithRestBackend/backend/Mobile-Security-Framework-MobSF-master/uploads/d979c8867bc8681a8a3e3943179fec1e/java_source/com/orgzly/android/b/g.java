/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.format.DateFormat
 */
package com.orgzly.android.b;

import android.content.Context;
import android.text.format.DateFormat;
import com.orgzly.a.a.a;
import com.orgzly.a.a.d;
import com.orgzly.a.a.e;
import java.util.Calendar;
import java.util.Date;

public class g {
    private Context a;
    private java.text.DateFormat b;
    private java.text.DateFormat c;

    public g(Context context) {
        this.a = context;
        this.b = DateFormat.getDateFormat((Context)this.a);
        this.c = DateFormat.getTimeFormat((Context)this.a);
    }

    public String a(a a2) {
        return a2.j();
    }

    public String a(d d2) {
        if (d2.b() != null) {
            return d2.a().j() + " \u2014 " + d2.b().j();
        }
        return d2.a().j();
    }

    public String b(a a2) {
        return this.b.format(a2.a().getTime());
    }

    public String c(a a2) {
        return this.c.format(a2.a().getTime());
    }

    public String d(a a2) {
        return a2.g().toString();
    }
}

