/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.b;

import java.util.NoSuchElementException;
import java.util.StringTokenizer;

public class h
extends StringTokenizer {
    private String a;
    private String b = "\t\n\r";
    private boolean c = false;
    private boolean d = false;
    private StringBuilder e;
    private boolean f = false;
    private int g = 0;
    private int h = 0;

    public h(String string, String string2, boolean bl2, boolean bl3) {
        super("");
        this.a = string;
        this.d = bl2;
        this.c = bl3;
        if (string2 != null) {
            this.b = string2;
        }
        if (this.b.indexOf(39) >= 0 || this.b.indexOf(34) >= 0) {
            throw new IllegalArgumentException("Can't use quotes as delimiters: " + this.b);
        }
        if (this.a.length() > 1024) {
            this.e = new StringBuilder(512);
            return;
        }
        this.e = new StringBuilder(this.a.length() / 2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String a(String string) {
        if (string == null) {
            return null;
        }
        CharSequence charSequence = string;
        if (string.length() < 2) return charSequence;
        char c2 = string.charAt(0);
        charSequence = string;
        if (c2 != string.charAt(string.length() - 1)) return charSequence;
        if (c2 != '\"') {
            charSequence = string;
            if (c2 != '\'') return charSequence;
        }
        charSequence = new StringBuilder(string.length() - 2);
        synchronized (charSequence) {
            int n2 = 1;
            c2 = '\u0000';
            while (n2 < string.length() - 1) {
                char c3 = string.charAt(n2);
                if (c3 == '\\' && c2 == '\u0000') {
                    c2 = '\u0001';
                } else {
                    charSequence.append(c3);
                    c2 = '\u0000';
                }
                ++n2;
            }
            return charSequence.toString();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String a(String string, String string2) {
        if (string == null) {
            return null;
        }
        if (string.length() == 0) {
            return "\"\"";
        }
        int n2 = 0;
        do {
            String string3 = string;
            if (n2 >= string.length()) return string3;
            char c2 = string.charAt(n2);
            if (c2 == '\"' || c2 == '\\' || c2 == '\'' || string2.indexOf(c2) >= 0) {
                StringBuilder stringBuilder = new StringBuilder(string.length() + 8);
                h.a(stringBuilder, string);
                return stringBuilder.toString();
            }
            ++n2;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(StringBuilder stringBuilder, String string) {
        synchronized (stringBuilder) {
            stringBuilder.append('\"');
            int n2 = 0;
            do {
                if (n2 >= string.length()) {
                    stringBuilder.append('\"');
                    return;
                }
                char c2 = string.charAt(n2);
                if (c2 == '\"') {
                    stringBuilder.append("\\\"");
                } else if (c2 == '\\') {
                    stringBuilder.append("\\\\");
                } else {
                    stringBuilder.append(c2);
                }
                ++n2;
            } while (true);
        }
    }

    @Override
    public int countTokens() {
        return -1;
    }

    @Override
    public boolean hasMoreElements() {
        return this.hasMoreTokens();
    }

    @Override
    public boolean hasMoreTokens() {
        if (this.f) {
            return true;
        }
        this.h = this.g;
        a a2 = a.a;
        boolean bl2 = false;
        block6 : while (this.g < this.a.length()) {
            String string = this.a;
            int n2 = this.g;
            this.g = n2 + 1;
            char c2 = string.charAt(n2);
            switch (.a[a2.ordinal()]) {
                default: {
                    continue block6;
                }
                case 1: {
                    if (this.b.indexOf(c2) >= 0) {
                        if (!this.d) continue block6;
                        this.e.append(c2);
                        this.f = true;
                        continue block6;
                    }
                    if (c2 == '\'') {
                        if (this.c) {
                            this.e.append(c2);
                        }
                        a2 = a.c;
                        continue block6;
                    }
                    if (c2 == '\"') {
                        if (this.c) {
                            this.e.append(c2);
                        }
                        a2 = a.d;
                        continue block6;
                    }
                    this.e.append(c2);
                    this.f = true;
                    a2 = a.b;
                    continue block6;
                }
                case 2: {
                    this.f = true;
                    if (this.b.indexOf(c2) >= 0) {
                        if (this.d) {
                            --this.g;
                        }
                        return this.f;
                    }
                    if (c2 == '\'') {
                        if (this.c) {
                            this.e.append(c2);
                        }
                        a2 = a.c;
                        continue block6;
                    }
                    if (c2 == '\"') {
                        if (this.c) {
                            this.e.append(c2);
                        }
                        a2 = a.d;
                        continue block6;
                    }
                    this.e.append(c2);
                    continue block6;
                }
                case 3: {
                    this.f = true;
                    if (bl2) {
                        this.e.append(c2);
                        bl2 = false;
                        continue block6;
                    }
                    if (c2 == '\'') {
                        if (this.c) {
                            this.e.append(c2);
                        }
                        a2 = a.b;
                        continue block6;
                    }
                    if (c2 == '\\') {
                        if (this.c) {
                            this.e.append(c2);
                        }
                        bl2 = true;
                        continue block6;
                    }
                    this.e.append(c2);
                    continue block6;
                }
                case 4: 
            }
            this.f = true;
            if (bl2) {
                this.e.append(c2);
                bl2 = false;
                continue;
            }
            if (c2 == '\"') {
                if (this.c) {
                    this.e.append(c2);
                }
                a2 = a.b;
                continue;
            }
            if (c2 == '\\') {
                if (this.c) {
                    this.e.append(c2);
                }
                bl2 = true;
                continue;
            }
            this.e.append(c2);
        }
        return this.f;
    }

    @Override
    public Object nextElement() {
        return this.nextToken();
    }

    @Override
    public String nextToken() {
        if (!this.hasMoreTokens() || this.e == null) {
            throw new NoSuchElementException();
        }
        String string = this.e.toString();
        this.e.setLength(0);
        this.f = false;
        return string;
    }

    @Override
    public String nextToken(String string) {
        this.b = string;
        this.g = this.h;
        this.e.setLength(0);
        this.f = false;
        return this.nextToken();
    }

    private static enum a {
        a,
        b,
        c,
        d;
        

        private a() {
        }
    }

}

