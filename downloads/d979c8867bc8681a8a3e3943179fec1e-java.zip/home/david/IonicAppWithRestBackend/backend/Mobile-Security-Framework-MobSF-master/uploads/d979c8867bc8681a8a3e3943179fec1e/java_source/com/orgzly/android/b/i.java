/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.text.Spannable
 *  android.text.SpannableString
 *  android.text.Spanned
 *  android.text.TextUtils
 *  android.widget.MultiAutoCompleteTextView
 *  android.widget.MultiAutoCompleteTextView$Tokenizer
 */
package com.orgzly.android.b;

import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.widget.MultiAutoCompleteTextView;

public class i
implements MultiAutoCompleteTextView.Tokenizer {
    public int findTokenEnd(CharSequence charSequence, int n2) {
        int n3 = charSequence.length();
        while (n2 < n3) {
            if (charSequence.charAt(n2) == ' ') {
                return n2;
            }
            ++n2;
        }
        return n3;
    }

    public int findTokenStart(CharSequence charSequence, int n2) {
        int n3;
        int n4 = n2;
        do {
            n3 = n4;
            if (n4 <= 0) break;
            n3 = n4;
            if (charSequence.charAt(n4 - 1) == ' ') break;
            --n4;
        } while (true);
        while (n3 < n2 && charSequence.charAt(n3) == ' ') {
            ++n3;
        }
        return n3;
    }

    public CharSequence terminateToken(CharSequence charSequence) {
        int n2;
        for (n2 = charSequence.length(); n2 > 0 && charSequence.charAt(n2 - 1) == ' '; --n2) {
        }
        if (n2 > 0 && charSequence.charAt(n2 - 1) == ' ') {
            return charSequence;
        }
        if (charSequence instanceof Spanned) {
            SpannableString spannableString = new SpannableString((CharSequence)(charSequence + " "));
            TextUtils.copySpansFrom((Spanned)((Spanned)charSequence), (int)0, (int)charSequence.length(), (Class)Object.class, (Spannable)spannableString, (int)0);
            return spannableString;
        }
        return charSequence + " ";
    }
}

