/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.net.Uri$Builder
 */
package com.orgzly.android.b;

import android.net.Uri;
import com.orgzly.android.c;
import java.util.Iterator;
import java.util.List;

public class j {
    public static Uri a(Uri uri) {
        Object object = null;
        if (uri.getPathSegments().size() > 0) {
            object = uri.getPathSegments().subList(0, uri.getPathSegments().size() - 1);
        }
        uri = new Uri.Builder().scheme(uri.getScheme()).authority(uri.getAuthority());
        if (object != null) {
            object = object.iterator();
            while (object.hasNext()) {
                uri.appendPath((String)object.next());
            }
        }
        return uri.build();
    }

    public static Uri a(Uri uri, String string) {
        string = c.a(string, c.b(uri.getLastPathSegment()).b());
        return j.a(uri).buildUpon().appendPath(string).build();
    }

    public static Uri a(String string, String arrstring) {
        string = new Uri.Builder().scheme(string);
        arrstring = arrstring.split("/+", -1);
        int n2 = arrstring.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            string.appendPath(arrstring[i2]);
        }
        return string.build();
    }

    public static String a(String string) {
        return Uri.decode((String)string);
    }

    public static String b(Uri uri) {
        return j.a(uri.toString());
    }
}

