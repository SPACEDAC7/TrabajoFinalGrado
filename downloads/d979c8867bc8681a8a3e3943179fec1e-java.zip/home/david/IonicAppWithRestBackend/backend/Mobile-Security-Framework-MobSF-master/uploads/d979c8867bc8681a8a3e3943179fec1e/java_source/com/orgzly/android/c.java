/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 */
package com.orgzly.android;

import android.content.Context;
import android.net.Uri;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class c {
    private static final Pattern a = Pattern.compile("(.*)\\.(org)(\\.txt)?$");
    private static final Pattern b = Pattern.compile("^\\.#.*");
    private final String c;
    private final String d;
    private final a e;

    private c(String string, String string2, a a2) {
        this.c = string;
        this.d = string2;
        this.e = a2;
    }

    public static String a(Context object, Uri uri) {
        object = android.support.v4.h.a.a((Context)object, uri);
        if ("content".equals(uri.getScheme()) && object != null) {
            return object.b();
        }
        return uri.getLastPathSegment();
    }

    public static String a(String string, a a2) {
        if (a2 == a.a) {
            return string + ".org";
        }
        throw new IllegalArgumentException("Unsupported format " + (Object)((Object)a2));
    }

    public static boolean a(String string) {
        if (a.matcher(string).matches() && !b.matcher(string).matches()) {
            return true;
        }
        return false;
    }

    public static c b(String string) {
        Matcher matcher;
        if (string != null && (matcher = a.matcher(string)).find()) {
            String string2 = matcher.group(1);
            if (matcher.group(2).equals("org")) {
                return new c(string, string2, a.a);
            }
        }
        throw new IllegalArgumentException("Unsupported book file name " + string);
    }

    public String a() {
        return this.d;
    }

    public a b() {
        return this.e;
    }

    public static enum a {
        a;
        

        private a() {
        }
    }

}

