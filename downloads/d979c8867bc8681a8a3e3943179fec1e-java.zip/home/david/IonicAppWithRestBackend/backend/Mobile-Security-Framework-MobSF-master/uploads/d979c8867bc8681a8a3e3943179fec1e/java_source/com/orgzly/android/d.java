/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android;

public class d {
    private String a;
    private String b;

    public d(String string, String string2) {
        this.a = string;
        this.b = string2;
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }
}

