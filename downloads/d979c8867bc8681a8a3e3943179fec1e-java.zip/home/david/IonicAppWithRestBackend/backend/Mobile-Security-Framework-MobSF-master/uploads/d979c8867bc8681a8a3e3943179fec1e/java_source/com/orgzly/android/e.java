/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.util.Log
 */
package com.orgzly.android;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import com.orgzly.android.a;
import com.orgzly.android.c;
import java.io.File;
import java.io.IOException;

public class e {
    private static final String a = e.class.getName();
    private Context b;

    public e(Context context) {
        this.b = context;
    }

    private File a(String object) {
        object = new File(this.b.getExternalCacheDir(), (String)object);
        if (!object.isDirectory() && !object.mkdirs()) {
            throw new IOException("Failed creating directory " + object);
        }
        return object;
    }

    public static void a(File file) {
        if (file.isDirectory()) {
            String[] arrstring = file.list();
            int n2 = arrstring.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                e.a(new File(file, arrstring[i2]));
            }
        }
        if (!file.delete()) {
            Log.e((String)a, (String)("Failed deleting " + file));
        }
    }

    public static boolean a(Context context) {
        if (Build.VERSION.SDK_INT >= 21 && context.getExternalCacheDirs().length > 1 && context.getExternalCacheDirs()[1] != null) {
            return true;
        }
        return false;
    }

    private File b() {
        if (!this.c()) {
            throw new IOException("External storage directory not available for writing");
        }
        File file = Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_DOWNLOADS);
        if (!file.isDirectory() && !file.mkdirs()) {
            throw new IOException("Failed creating directory " + file);
        }
        return file;
    }

    private File b(String object) {
        object = new File(this.b.getCacheDir(), (String)object);
        if (!object.isDirectory() && !object.mkdirs()) {
            throw new IOException("Failed creating directory " + object);
        }
        return object;
    }

    private boolean c() {
        return "mounted".equals(Environment.getExternalStorageState());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public File a() {
        File file = this.c() ? this.a("tmp") : this.b("tmp");
        try {
            return File.createTempFile("notebook.", ".tmp", file);
        }
        catch (IOException var2_3) {
            throw new IOException("Failed creating temporary file in " + file + ": " + var2_3.getMessage());
        }
    }

    public File a(a a2, c.a a3) {
        return new File(this.b(), c.a(a2.c(), a3));
    }
}

