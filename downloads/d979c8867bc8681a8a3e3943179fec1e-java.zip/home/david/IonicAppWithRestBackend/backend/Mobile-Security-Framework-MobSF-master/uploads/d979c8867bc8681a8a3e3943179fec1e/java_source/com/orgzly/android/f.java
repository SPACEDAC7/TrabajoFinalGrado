/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android;

import com.orgzly.a.c;
import com.orgzly.android.g;

public class f {
    private long a;
    private c b = new c();
    private g c = new g();
    private int d;
    private boolean e;

    public static f a(long l2) {
        f f2 = new f();
        g g2 = f2.a();
        g2.c(l2);
        g2.b(0);
        g2.d(1);
        g2.e(2);
        return f2;
    }

    public g a() {
        return this.c;
    }

    public void a(int n2) {
        this.d = n2;
    }

    public void a(c c2) {
        this.b = c2;
    }

    public void a(g g2) {
        this.c = g2;
    }

    public void a(boolean bl2) {
        this.e = bl2;
    }

    public c b() {
        return this.b;
    }

    public void b(long l2) {
        this.a = l2;
    }

    public long c() {
        return this.a;
    }

    public int d() {
        return this.d;
    }

    public boolean e() {
        return this.e;
    }

    public String toString() {
        return String.format("[%d-%d]  L:%d  Desc:%d  Folded:%s  FoldedUnder:%d  Id: %d", this.c.g(), this.c.h(), this.c.e(), this.c.d(), this.e(), this.c.a(), this.a);
    }
}

