/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android;

public class g {
    private long a;
    private long b;
    private long c;
    private int d;
    private int e;
    private long f;
    private long g;
    private boolean h;

    public long a() {
        return this.f;
    }

    public void a(int n2) {
        this.e = n2;
    }

    public void a(long l2) {
        this.f = l2;
    }

    public void a(boolean bl2) {
        this.h = bl2;
    }

    public long b() {
        return this.g;
    }

    public void b(int n2) {
        this.d = n2;
    }

    public void b(long l2) {
        this.g = l2;
    }

    public void c(long l2) {
        this.a = l2;
    }

    public boolean c() {
        return this.h;
    }

    public int d() {
        return this.e;
    }

    public void d(long l2) {
        this.b = l2;
    }

    public int e() {
        return this.d;
    }

    public void e(long l2) {
        this.c = l2;
    }

    public long f() {
        return this.a;
    }

    public long g() {
        return this.b;
    }

    public long h() {
        return this.c;
    }

    public String toString() {
        return String.format("[%d-%d Lvl:%d Desc:%d Under:%d]", this.b, this.c, this.d, this.e, this.f);
    }
}

