/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android;

import java.util.Set;

public class h {
    private long a;
    private int b;
    private Set<Long> c;

    public h(long l2, Set<Long> set) {
        this.a = l2;
        this.b = set.size();
        this.c = set;
    }

    public int a() {
        return this.b;
    }

    public long b() {
        return this.a;
    }

    public String toString() {
        return this.getClass().getSimpleName() + "[" + this.a + " with " + this.b + " notes]";
    }
}

