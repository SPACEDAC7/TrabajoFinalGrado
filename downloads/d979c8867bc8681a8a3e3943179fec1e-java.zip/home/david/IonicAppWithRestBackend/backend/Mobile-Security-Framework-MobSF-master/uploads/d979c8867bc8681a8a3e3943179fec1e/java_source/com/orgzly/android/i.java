/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 */
package com.orgzly.android;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.b.ah;
import android.support.v4.b.ay;
import com.orgzly.android.ui.ShareActivity;

public class i {
    public static final String a = i.class.getName();

    public static void a(Context context) {
        Intent intent = new Intent(context, (Class)ShareActivity.class);
        intent.setAction("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT", "");
        ay ay2 = ay.a(context);
        ay2.a(ShareActivity.class);
        ay2.a(intent);
        intent = ay2.a(0, 134217728);
        intent = new ah.d(context).a(true).a(2130837601).a(context.getString(2131230871)).a((PendingIntent)intent).b(-2).a();
        ((NotificationManager)context.getSystemService("notification")).notify(1, (Notification)intent);
    }

    public static void b(Context context) {
        ((NotificationManager)context.getSystemService("notification")).cancel(1);
    }
}

