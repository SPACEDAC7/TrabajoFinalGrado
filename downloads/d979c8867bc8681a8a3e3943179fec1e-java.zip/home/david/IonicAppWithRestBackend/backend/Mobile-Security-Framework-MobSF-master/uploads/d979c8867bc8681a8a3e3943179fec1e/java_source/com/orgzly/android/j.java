/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android;

import com.orgzly.a.a.c;
import com.orgzly.android.b.h;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class j {
    private a a;
    private a b;
    private Set<String> c = new LinkedHashSet<String>();
    private String d;
    private Set<String> e = new TreeSet<String>();
    private Set<String> f = new TreeSet<String>();
    private Set<String> g = new TreeSet<String>();
    private String h;
    private String i;
    private Set<String> j = new TreeSet<String>();
    private List<b> k = new ArrayList<b>();

    public j() {
    }

    public j(String object) {
        String string = object;
        if (object == null) {
            string = "";
        }
        object = new h(string, " ", false, true);
        while (object.hasMoreTokens()) {
            string = object.nextToken();
            if (string.startsWith("s.")) {
                if (string.length() <= 2) continue;
                this.a = a.a(string.substring(2).toLowerCase());
                continue;
            }
            if (string.startsWith("d.")) {
                if (string.length() <= 2) continue;
                this.b = a.a(string.substring(2).toLowerCase());
                continue;
            }
            if (string.startsWith("p.")) {
                if (string.length() <= 2) continue;
                this.h = string.substring(2).toLowerCase();
                continue;
            }
            if (string.startsWith("i.")) {
                if (string.length() <= 2) continue;
                this.i = string.substring(2).toUpperCase();
                continue;
            }
            if (string.startsWith(".i.")) {
                if (string.length() <= 3) continue;
                this.j.add(string.substring(3).toUpperCase());
                continue;
            }
            if (string.startsWith("b.")) {
                if (string.length() <= 2) continue;
                this.d = h.a(string.substring(2));
                continue;
            }
            if (string.startsWith(".b.")) {
                if (string.length() <= 3) continue;
                this.e.add(h.a(string.substring(3)));
                continue;
            }
            if (string.startsWith("tn.")) {
                if (string.length() <= 3) continue;
                this.f.add(string.substring(3));
                continue;
            }
            if (string.startsWith("t.")) {
                if (string.length() <= 2) continue;
                this.g.add(string.substring(2));
                continue;
            }
            if (string.startsWith(".o.")) {
                if (string.length() <= 3) continue;
                string = string.substring(3);
                this.k.add(new b(string, false));
                continue;
            }
            if (string.startsWith("o.")) {
                if (string.length() <= 2) continue;
                string = string.substring(2);
                this.k.add(new b(string, true));
                continue;
            }
            this.c.add(string);
        }
    }

    public void a(String string) {
        this.d = string;
    }

    public boolean a() {
        if (this.a != null) {
            return true;
        }
        return false;
    }

    public a b() {
        return this.a;
    }

    public boolean c() {
        if (this.b != null) {
            return true;
        }
        return false;
    }

    public a d() {
        return this.b;
    }

    public Set<String> e() {
        return this.c;
    }

    public Set<String> f() {
        return this.f;
    }

    public boolean g() {
        if (!this.f.isEmpty()) {
            return true;
        }
        return false;
    }

    public Set<String> h() {
        return this.g;
    }

    public boolean i() {
        if (!this.g.isEmpty()) {
            return true;
        }
        return false;
    }

    public String j() {
        return this.h;
    }

    public boolean k() {
        if (this.h != null) {
            return true;
        }
        return false;
    }

    public String l() {
        return this.i;
    }

    public boolean m() {
        if (this.i != null) {
            return true;
        }
        return false;
    }

    public Set<String> n() {
        return this.j;
    }

    public boolean o() {
        if (!this.j.isEmpty()) {
            return true;
        }
        return false;
    }

    public String p() {
        return this.d;
    }

    public boolean q() {
        if (this.d != null) {
            return true;
        }
        return false;
    }

    public Set<String> r() {
        return this.e;
    }

    public boolean s() {
        if (!this.e.isEmpty()) {
            return true;
        }
        return false;
    }

    public boolean t() {
        if (this.k.size() > 0) {
            return true;
        }
        return false;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.q()) {
            stringBuilder.append("b.").append(h.a(this.d, " "));
        }
        if (this.s()) {
            for (String object2 : this.e) {
                stringBuilder.append(" .b.").append(h.a(object2, " "));
            }
        }
        if (this.i != null) {
            stringBuilder.append(" i.").append(this.i.toLowerCase());
        }
        if (!this.j.isEmpty()) {
            for (String string : this.j) {
                stringBuilder.append(" .i.").append(string.toLowerCase());
            }
        }
        if (this.h != null) {
            stringBuilder.append(" p.").append(this.h.toLowerCase());
        }
        if (!this.f.isEmpty()) {
            for (String string : this.f) {
                stringBuilder.append(" tn.").append(string);
            }
        }
        if (!this.g.isEmpty()) {
            for (String string : this.g) {
                stringBuilder.append(" t.").append(string);
            }
        }
        if (this.a()) {
            stringBuilder.append(" s.").append(this.a.toString());
        }
        if (this.c()) {
            stringBuilder.append(" d.").append(this.b.toString());
        }
        for (String string : this.c) {
            stringBuilder.append(" ").append(string);
        }
        for (b b2 : this.k) {
            stringBuilder.append(" ");
            if (!b2.b) {
                stringBuilder.append(".");
            }
            stringBuilder.append("o.").append(b2.a);
        }
        return stringBuilder.toString().trim();
    }

    public List<b> u() {
        return this.k;
    }

    public static class a
    extends c {
        public static final Pattern a = Pattern.compile("^(\\d+)(h|d|w|m|y)$");

        /*
         * Enabled aggressive block sorting
         */
        public static a a(String object) {
            a a2;
            a a3 = a2 = null;
            if (object == null) return a3;
            {
                if ("today".equals(object = object.toLowerCase()) || "tod".equals(object)) {
                    a3 = new a();
                    a3.a(0);
                    a3.a(c.a.b);
                    return a3;
                } else {
                    if ("tomorrow".equals(object) || "tmrw".equals(object) || "tom".equals(object)) {
                        object = new a();
                        object.a(1);
                        object.a(c.a.b);
                        return object;
                    }
                    object = a.matcher((CharSequence)object);
                    a3 = a2;
                    if (!object.find()) return a3;
                    {
                        a3 = new a();
                        a3.b(object.group(1));
                        a3.c(object.group(2));
                        return a3;
                    }
                }
            }
        }

        @Override
        public String toString() {
            if (this.c == c.a.b && this.b == 0) {
                return "today";
            }
            if (this.c == c.a.b && this.b == 1) {
                return "tomorrow";
            }
            return super.toString();
        }
    }

    public static class b {
        private String a;
        private boolean b;

        b(String string, boolean bl2) {
            this.a = string;
            this.b = bl2;
        }

        public boolean a() {
            return this.b;
        }

        public a b() {
            if ("scheduled".equals(this.a) || "sched".equals(this.a) || "s".equals(this.a)) {
                return a.a;
            }
            if ("deadline".equals(this.a) || "dead".equals(this.a) || "d".equals(this.a)) {
                return a.b;
            }
            if ("priority".equals(this.a) || "prio".equals(this.a) || "pri".equals(this.a) || "p".equals(this.a)) {
                return a.d;
            }
            if ("notebook".equals(this.a) || "book".equals(this.a) || "b".equals(this.a)) {
                return a.c;
            }
            return null;
        }

        public static enum a {
            a,
            b,
            c,
            d;
            

            private a() {
            }
        }

    }

}

