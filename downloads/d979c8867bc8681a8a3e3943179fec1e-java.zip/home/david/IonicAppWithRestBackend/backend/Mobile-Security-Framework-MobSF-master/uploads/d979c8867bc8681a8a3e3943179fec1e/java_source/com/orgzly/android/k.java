/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentUris
 *  android.content.Context
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.net.Uri$Builder
 */
package com.orgzly.android;

import android.content.ContentUris;
import android.content.Context;
import android.content.res.Resources;
import android.net.Uri;
import com.orgzly.a.b;
import com.orgzly.a.b.i;
import com.orgzly.a.c;
import com.orgzly.a.e;
import com.orgzly.android.a.g;
import com.orgzly.android.a.h;
import com.orgzly.android.a.i;
import com.orgzly.android.a.j;
import com.orgzly.android.b;
import com.orgzly.android.c;
import com.orgzly.android.provider.b.d;
import com.orgzly.android.provider.b.f;
import com.orgzly.android.ui.l;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class k {
    private static final String a = k.class.getName();
    private Context b;
    private com.orgzly.android.e c;

    public k(Context context) {
        this.b = context;
        this.c = new com.orgzly.android.e(context);
    }

    private com.orgzly.android.a d(String string) {
        return com.orgzly.android.provider.b.a.a(this.b, new com.orgzly.android.a(string, "", 0, true));
    }

    public int a(long l2, String string) {
        return com.orgzly.android.provider.b.g.a(this.b, l2, string);
    }

    public int a(com.orgzly.android.a a2) {
        return com.orgzly.android.provider.b.a.b(this.b, a2);
    }

    public int a(com.orgzly.android.f f2) {
        return f.a(this.b, f2);
    }

    /*
     * Exception decompiling
     */
    public int a(a var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 8[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    public com.orgzly.android.a a(long l2) {
        return com.orgzly.android.provider.b.a.c(this.b, l2);
    }

    public com.orgzly.android.a a(i object) {
        Object object2 = h.a(this.b, object.a());
        if (object2 == null) {
            throw new IOException("Unsupported repository URL \"" + (Object)object.a() + "\"");
        }
        File file = this.b();
        try {
            object = object2.a(object.b(), file);
            object2 = com.orgzly.android.c.b(com.orgzly.android.c.a(this.b, object.b()));
            object = this.a(object2.a(), object2.b(), file, (j)object);
            return object;
        }
        finally {
            file.delete();
        }
    }

    public com.orgzly.android.a a(String string) {
        return com.orgzly.android.provider.b.a.a(this.b, string);
    }

    public com.orgzly.android.a a(String object, c.a a2, Resources object2, int n2) {
        object2 = object2.openRawResource(n2);
        try {
            object = this.a((String)object, a2, (InputStream)object2);
            return object;
        }
        finally {
            object2.close();
        }
    }

    public com.orgzly.android.a a(String string, c.a a2, File file) {
        return this.a(string, a2, file, null, null);
    }

    public com.orgzly.android.a a(String string, c.a a2, File file, j j2) {
        return this.a(string, a2, file, j2, null);
    }

    public com.orgzly.android.a a(String string, c.a a2, File file, j j2, String string2) {
        string = com.orgzly.android.provider.b.a.a(this.b, string, a2, file, j2, string2);
        return com.orgzly.android.provider.b.a.c(this.b, ContentUris.parseId((Uri)string));
    }

    public com.orgzly.android.a a(String object, c.a a2, InputStream inputStream) {
        File file = this.b();
        try {
            com.orgzly.android.b.e.a(inputStream, file);
            object = this.a((String)object, a2, file);
            return object;
        }
        finally {
            file.delete();
        }
    }

    public com.orgzly.android.a a(String object, String object2, com.orgzly.android.a a2, c.a a3) {
        g g2 = h.a(this.b, (String)object);
        if (g2 == null) {
            throw new IOException("Unsupported repository URL \"" + (String)object + "\"");
        }
        object = this.b();
        this.a(a2, a3, (File)object);
        object2 = g2.a((File)object, (String)object2);
        a2.a((j)object2);
        com.orgzly.android.provider.b.a.a(this.b, a2.a(), (j)object2);
        return a2;
        finally {
            object.delete();
        }
    }

    public com.orgzly.android.b a(com.orgzly.android.sync.a a2) {
        switch (.a[a2.d().ordinal()]) {
            default: {
                return null;
            }
            case 1: {
                return new com.orgzly.android.b(b.a.a, a2.d().a());
            }
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 9: 
            case 10: {
                return new com.orgzly.android.b(b.a.b, a2.d().a());
            }
            case 11: 
            case 12: {
                this.a(a2.c().get(0));
                return new com.orgzly.android.b(b.a.a, a2.d().a(com.orgzly.android.b.j.b(a2.c().get(0).b())));
            }
            case 13: {
                this.a(a2.e());
                return new com.orgzly.android.b(b.a.a, a2.d().a(com.orgzly.android.b.j.b(a2.e().b())));
            }
            case 14: {
                this.a(a2.e());
                return new com.orgzly.android.b(b.a.a, a2.d().a(com.orgzly.android.b.j.b(a2.e().b())));
            }
            case 15: {
                String string = this.e().entrySet().iterator().next().getValue().b().toString();
                this.a(string, com.orgzly.android.c.a(a2.b().c(), c.a.a), a2.b(), c.a.a);
                return new com.orgzly.android.b(b.a.a, a2.d().a(com.orgzly.android.b.j.a(string)));
            }
            case 16: {
                String string = a2.b().f().a().toString();
                this.a(string, com.orgzly.android.c.a(this.b, a2.b().f().b()), a2.b(), c.a.a);
                return new com.orgzly.android.b(b.a.a, a2.d().a(com.orgzly.android.b.j.a(string)));
            }
            case 17: 
        }
        String string = a2.b().g().a().toString();
        this.a(string, com.orgzly.android.c.a(this.b, a2.b().g().b()), a2.b(), c.a.a);
        return new com.orgzly.android.b(b.a.a, a2.d().a(com.orgzly.android.b.j.a(string)));
    }

    public com.orgzly.android.f a(com.orgzly.android.f f2, com.orgzly.android.ui.i object) {
        object = f.a(this.b, f2, (com.orgzly.android.ui.i)object);
        com.orgzly.android.provider.b.a.a(this.b, f2.a().f(), System.currentTimeMillis());
        return object;
    }

    public com.orgzly.android.h a(long l2, long l3, l l4) {
        return f.a(this.b, l2, l3, l4);
    }

    public File a(long l2, c.a a2) {
        com.orgzly.android.a a3 = this.a(l2);
        File file = this.c.a(a3, a2);
        this.a(a3, a2, file);
        return file;
    }

    public List<com.orgzly.android.a> a() {
        return com.orgzly.android.provider.b.a.a(this.b);
    }

    public List<j> a(Map<String, g> object) {
        ArrayList<j> arrayList = new ArrayList<j>();
        Object object2 = object;
        if (object == null) {
            object2 = this.e();
        }
        object = object2.values().iterator();
        while (object.hasNext()) {
            object2 = ((g)object.next()).c().iterator();
            while (object2.hasNext()) {
                arrayList.add((j)object2.next());
            }
        }
        com.orgzly.android.provider.b.b.a(this.b, arrayList);
        return arrayList;
    }

    public void a(long l2, int n2) {
        this.a(f.c(this.b, l2), n2);
    }

    public void a(long l2, com.orgzly.android.d d2) {
        d.a(this.b, l2, d2);
    }

    public void a(long l2, Set<Long> set) {
        com.orgzly.android.provider.b.a.a(this.b, l2, set);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(com.orgzly.android.a a2, c.a object, File object2) {
        Object object3;
        object = object3 = a2.n();
        if (object3 == null) {
            object = Charset.defaultCharset().name();
        }
        object = new PrintWriter((File)object2, (String)object);
        try {
            object2 = com.orgzly.android.prefs.a.q(this.b);
            object3 = com.orgzly.a.b.i.a();
            if (this.b.getString(2131231122).equals(object2)) {
                object3.d = i.a.a;
            } else if (this.b.getString(2131231123).equals(object2)) {
                object3.d = i.a.b;
            } else if (this.b.getString(2131231124).equals(object2)) {
                object3.d = i.a.c;
            }
            object2 = new com.orgzly.a.b.j((com.orgzly.a.b.i)object3);
            object.write(object2.a(a2.b()));
            f.a(this.b, a2.c(), new f.a((PrintWriter)object, (com.orgzly.a.b.j)object2, a2){
                final /* synthetic */ PrintWriter a;
                final /* synthetic */ com.orgzly.a.b.j b;
                final /* synthetic */ com.orgzly.android.a c;

                @Override
                public void a(com.orgzly.android.f f2) {
                    this.a.write(this.b.a(f2.b(), f2.a().e(), this.c.k().b()));
                }
            });
            return;
        }
        finally {
            object.close();
        }
    }

    public void a(com.orgzly.android.a a2, String string) {
        String string2 = a2.c();
        if (this.a(string) != null) {
            throw new IOException("Notebook with that name already exists");
        }
        if (a2.g() != null && a2.f() != null && !a2.g().b().equals((Object)a2.f().b())) {
            string = com.orgzly.android.sync.b.h.toString();
            this.a(a2, string, new com.orgzly.android.b(b.a.b, string));
            return;
        }
        if (a2.f() != null && a2.d()) {
            throw new IOException("Notebook is not synced");
        }
        if (a2.f() != null) {
            j j2 = a2.f();
            j2 = h.a(this.b, j2.a()).a(j2.b(), string);
            a2.a(j2);
            com.orgzly.android.provider.b.a.a(this.b, a2.a(), j2);
        }
        if (com.orgzly.android.provider.b.a.a(this.b, a2.a(), string) != 1) {
            string = this.b.getString(2131231012);
            this.a(a2, null, new com.orgzly.android.b(b.a.b, string));
            throw new IOException(string);
        }
        this.a(a2, null, new com.orgzly.android.b(b.a.a, this.b.getString(2131231133, new Object[]{string2})));
    }

    public void a(com.orgzly.android.a a2, String string, com.orgzly.android.b b2) {
        com.orgzly.android.provider.b.a.a(this.b, a2.a(), string, b2);
    }

    public void a(com.orgzly.android.a a2, boolean bl2) {
        g g2;
        if (bl2 && (g2 = h.a(this.b, a2.g().a())) != null) {
            g2.a(a2.g().b());
        }
        f.b(this.b, a2.a());
        com.orgzly.android.provider.b.a.b(this.b, a2.a());
    }

    public void a(com.orgzly.android.d d2) {
        d.a(this.b, d2);
    }

    public void a(com.orgzly.android.f f2, int n2) {
        String string = f2.b().o();
        AbstractCollection abstractCollection = new ArrayList<String>();
        abstractCollection.add(null);
        abstractCollection.addAll(com.orgzly.android.prefs.a.v(this.b));
        abstractCollection.addAll(com.orgzly.android.prefs.a.x(this.b));
        abstractCollection = new com.orgzly.android.b.b<String>(abstractCollection.toArray(new String[abstractCollection.size()]));
        string = (String)abstractCollection.get(abstractCollection.indexOf(string) + n2);
        abstractCollection = new HashSet();
        abstractCollection.add((String)((Object)Long.valueOf(f2.c())));
        this.a((Set<Long>)((Object)abstractCollection), string);
    }

    public void a(Set<Long> object) {
        object = object.iterator();
        while (object.hasNext()) {
            long l2 = (Long)object.next();
            d.b(this.b, l2);
        }
    }

    public void a(Set<Long> set, com.orgzly.a.a.a a2) {
        f.a(this.b, set, a2);
    }

    public void a(Set<Long> set, String string) {
        f.a(this.b, set, string);
    }

    public com.orgzly.android.a b(String string) {
        return com.orgzly.android.provider.b.a.a(this.b, new com.orgzly.android.a(string));
    }

    public com.orgzly.android.f b(long l2) {
        return f.c(this.b, l2);
    }

    public File b() {
        return this.c.a();
    }

    public void b(long l2, Set<Long> set) {
        com.orgzly.android.provider.b.a.b(this.b, l2, set);
    }

    public void b(com.orgzly.android.a a2) {
        com.orgzly.android.provider.b.a.c(this.b, a2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void b(com.orgzly.android.a a2, String string) {
        if (string == null) {
            com.orgzly.android.provider.b.a.a(this.b, a2.a());
            return;
        }
        String string2 = a2.f() != null ? com.orgzly.android.c.a(this.b, a2.f().b()) : com.orgzly.android.c.a(a2.c(), c.a.a);
        string2 = Uri.parse((String)string).buildUpon().appendPath(string2).build();
        com.orgzly.android.provider.b.a.a(this.b, a2.a(), string, string2.toString());
    }

    public int c(long l2, Set<Long> set) {
        return f.a(this.b, l2, set);
    }

    public Uri c(String string) {
        return com.orgzly.android.provider.b.g.a(this.b, string);
    }

    public List<e> c(long l2) {
        return f.a(this.b, l2);
    }

    public void c() {
        com.orgzly.android.provider.b.c.a(this.b);
        com.orgzly.android.prefs.a.a(this.b, 0);
    }

    public int d(long l2, Set<Long> set) {
        return f.b(this.b, l2, set);
    }

    public Map<String, com.orgzly.android.sync.a> d() {
        Map<String, g> map = com.orgzly.android.provider.b.g.a(this.b);
        Object object = this.a();
        List<j> list = this.a(map);
        object = com.orgzly.android.sync.a.a(this.b, object, list);
        for (com.orgzly.android.sync.a a2 : object.values()) {
            if (a2.b() == null) {
                a2.a(this.d(a2.a()));
            }
            a2.a(map.size());
        }
        return object;
    }

    public String[] d(long l2) {
        return f.d(this.b, l2);
    }

    public Map<String, g> e() {
        return com.orgzly.android.provider.b.g.a(this.b);
    }

    public void e(long l2) {
        f.e(this.b, l2);
    }

    public int f(long l2) {
        return com.orgzly.android.provider.b.g.a(this.b, l2);
    }

    public void g(long l2) {
        d.c(this.b, l2);
    }

    public void h(long l2) {
        d.d(this.b, l2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void i(long l2) {
        Set<String> set = com.orgzly.android.prefs.a.x(this.b);
        if (!set.iterator().hasNext()) return;
        if ((set = set.iterator().next()) == null) return;
        TreeSet<Long> treeSet = new TreeSet<Long>();
        treeSet.add(l2);
        this.a(treeSet, (String)((Object)set));
    }

    public static interface a {
        public void a(int var1, int var2, String var3);
    }

}

