/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android;

import com.orgzly.a.a.a;
import com.orgzly.a.a.d;
import java.util.Set;

public class l {
    private final Set<String> a;
    private final Set<String> b;
    private String c;
    private d d;
    private d e;
    private d f;

    public l(Set<String> set, Set<String> set2) {
        this.a = set;
        this.b = set2;
    }

    public String a() {
        return this.c;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(String string, String string2, d d2, d d3) {
        if (string == null) {
            throw new IllegalArgumentException("Target state cannot be null");
        }
        this.d = d2;
        this.e = d3;
        if (!this.b.contains(string)) {
            this.c = string;
            this.f = null;
            return;
        }
        if (!this.a.contains(string2)) {
            this.c = string;
            this.f = d.a(a.a(false));
            return;
        }
        boolean bl2 = this.d != null && this.d.e();
        boolean bl3 = bl2;
        if (this.e != null) {
            bl3 = bl2;
            if (this.e.e()) {
                bl3 = true;
            }
            if (!bl3) {
                this.c = string;
                this.f = d.a(a.a(false));
                return;
            }
        }
        this.c = string2;
        this.f = null;
    }

    public d b() {
        return this.d;
    }

    public d c() {
        return this.e;
    }

    public d d() {
        return this.f;
    }
}

