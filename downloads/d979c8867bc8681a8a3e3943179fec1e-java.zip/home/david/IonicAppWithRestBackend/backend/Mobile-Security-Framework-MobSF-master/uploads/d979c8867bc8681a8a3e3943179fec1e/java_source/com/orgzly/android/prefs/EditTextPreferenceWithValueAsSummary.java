/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.preference.EditTextPreference
 *  android.util.AttributeSet
 */
package com.orgzly.android.prefs;

import android.content.Context;
import android.preference.EditTextPreference;
import android.util.AttributeSet;

public class EditTextPreferenceWithValueAsSummary
extends EditTextPreference {
    public EditTextPreferenceWithValueAsSummary(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public EditTextPreferenceWithValueAsSummary(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
    }

    public void setText(String string) {
        super.setText(string);
        this.setSummary((CharSequence)string);
    }
}

