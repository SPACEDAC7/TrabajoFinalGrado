/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.preference.ListPreference
 *  android.util.AttributeSet
 */
package com.orgzly.android.prefs;

import android.content.Context;
import android.preference.ListPreference;
import android.util.AttributeSet;

public class ListPreferenceWithValueAsSummary
extends ListPreference {
    public ListPreferenceWithValueAsSummary(Context context) {
        super(context);
    }

    public ListPreferenceWithValueAsSummary(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public void setValue(String string) {
        super.setValue(string);
        this.setSummary(this.getEntry());
    }
}

