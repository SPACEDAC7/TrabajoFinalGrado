/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.AlertDialog
 *  android.app.Dialog
 *  android.content.Context
 *  android.os.Bundle
 *  android.preference.DialogPreference
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.util.AttributeSet
 *  android.view.View
 *  android.widget.Button
 *  android.widget.EditText
 */
package com.orgzly.android.prefs;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.preference.DialogPreference;
import android.support.design.widget.TextInputLayout;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.orgzly.a.f;
import com.orgzly.android.prefs.a;
import com.orgzly.android.prefs.b;
import java.util.HashSet;

public class StatesPreference
extends DialogPreference {
    private TextInputLayout a;
    private EditText b;
    private TextInputLayout c;
    private EditText d;

    @TargetApi(value=21)
    public StatesPreference(Context context) {
        super(context);
        this.setDialogLayoutResource(2130903132);
    }

    public StatesPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.setDialogLayoutResource(2130903132);
    }

    public StatesPreference(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        this.setDialogLayoutResource(2130903132);
    }

    @TargetApi(value=21)
    public StatesPreference(Context context, AttributeSet attributeSet, int n2, int n3) {
        super(context, attributeSet, n2, n3);
        this.setDialogLayoutResource(2130903132);
    }

    private void a() {
        AlertDialog alertDialog = (AlertDialog)this.getDialog();
        if (alertDialog != null && (alertDialog = alertDialog.getButton(-1)) != null) {
            alertDialog.setEnabled(this.b());
        }
    }

    private boolean b() {
        this.a.setError(null);
        this.c.setError(null);
        HashSet<String> hashSet = new HashSet<String>();
        for (String string2 : new com.orgzly.a.c.a(this.b.getText().toString())) {
            if (hashSet.contains(string2)) {
                this.a.setError(this.getContext().getString(2131231009, new Object[]{string2}));
                return false;
            }
            hashSet.add(string2);
        }
        for (String string2 : new com.orgzly.a.c.a(this.d.getText().toString())) {
            if (hashSet.contains(string2)) {
                this.c.setError(this.getContext().getString(2131231009, new Object[]{string2}));
                return false;
            }
            hashSet.add(string2);
        }
        return true;
    }

    public CharSequence getSummary() {
        String string;
        String string2 = string = a.u(this.getContext()).trim();
        if ("|".equals(string)) {
            string2 = this.getContext().getString(2131231039);
        }
        return string2;
    }

    protected void onBindDialogView(View object) {
        super.onBindDialogView((View)object);
        this.b = (EditText)object.findViewById(2131689785);
        this.a = (TextInputLayout)object.findViewById(2131689784);
        this.d = (EditText)object.findViewById(2131689787);
        this.c = (TextInputLayout)object.findViewById(2131689786);
        object = new TextWatcher(){

            public void afterTextChanged(Editable editable) {
                StatesPreference.this.a();
            }

            public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
            }

            public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
            }
        };
        this.b.addTextChangedListener((TextWatcher)object);
        this.d.addTextChangedListener((TextWatcher)object);
        object = new b(a.u(this.getContext()));
        if (object.size() > 0) {
            this.b.setText((CharSequence)((f)object.get(0)).a().toString());
            this.d.setText((CharSequence)((f)object.get(0)).b().toString());
        }
    }

    protected void onDialogClosed(boolean bl2) {
        super.onDialogClosed(bl2);
        if (bl2) {
            String string = new f(new com.orgzly.a.c.a(this.b.getText().toString()), new com.orgzly.a.c.a(this.d.getText().toString())).toString();
            a.b(this.getContext(), string);
            this.setSummary((CharSequence)string);
        }
    }

    protected void showDialog(Bundle bundle) {
        super.showDialog(bundle);
        this.a();
    }

}

