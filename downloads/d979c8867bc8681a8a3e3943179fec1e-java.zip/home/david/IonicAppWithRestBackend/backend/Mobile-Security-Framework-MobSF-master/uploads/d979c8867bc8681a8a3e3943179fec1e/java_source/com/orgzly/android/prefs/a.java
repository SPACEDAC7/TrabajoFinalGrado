/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Resources
 *  android.preference.PreferenceManager
 */
package com.orgzly.android.prefs;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.preference.PreferenceManager;
import com.orgzly.a.f;
import com.orgzly.android.prefs.b;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class a {
    private static Set<String> a;
    private static Set<String> b;

    public static String A(Context context) {
        String string = context.getResources().getString(2131231070);
        return a.E(context).getString(string, null);
    }

    public static int B(Context context) {
        String string = context.getResources().getString(2131231081);
        return a.E(context).getInt(string, 0);
    }

    public static boolean C(Context context) {
        String string = context.getResources().getString(2131231074);
        return a.E(context).getBoolean(string, false);
    }

    public static long D(Context context) {
        String string = context.getResources().getString(2131231080);
        return a.E(context).getLong(string, 0);
    }

    private static SharedPreferences E(Context context) {
        return context.getSharedPreferences("state", 0);
    }

    public static void a(Context context, int n2) {
        String string = context.getResources().getString(2131231081);
        a.E(context).edit().putInt(string, n2).apply();
    }

    public static void a(Context context, Long l2) {
        String string = context.getResources().getString(2131231080);
        a.E(context).edit().putLong(string, l2.longValue()).apply();
    }

    public static void a(Context context, boolean bl2) {
        String string = context.getResources().getString(2131231074);
        a.E(context).edit().putBoolean(string, bl2).apply();
    }

    public static boolean a(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(context.getResources().getString(2131231076), context.getResources().getBoolean(2131427335));
    }

    public static boolean a(Context context, String string) {
        if (string != null && a.x(context).contains(string)) {
            return true;
        }
        return false;
    }

    public static void b(Context context, String string) {
        String string2 = context.getResources().getString(2131231092);
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putString(string2, string).apply();
        a.w(context);
    }

    public static boolean b(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(context.getResources().getString(2131231077), context.getResources().getBoolean(2131427336));
    }

    public static void c(Context context, String string) {
        String string2 = context.getResources().getString(2131231070);
        a.E(context).edit().putString(string2, string).apply();
    }

    public static boolean c(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(context.getResources().getString(2131231078), context.getResources().getBoolean(2131427337));
    }

    public static String d(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231088), context.getResources().getString(2131231062));
    }

    public static boolean e(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(context.getResources().getString(2131231073), context.getResources().getBoolean(2131427334));
    }

    public static String f(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231086), context.getResources().getString(2131231053));
    }

    public static String g(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231087), context.getResources().getString(2131231054));
    }

    public static boolean h(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(context.getResources().getString(2131231068), context.getResources().getBoolean(2131427333));
    }

    public static boolean i(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(context.getResources().getString(2131231072), context.getResources().getBoolean(2131427339));
    }

    public static String j(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231066), context.getResources().getString(2131231050));
    }

    public static boolean k(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(context.getResources().getString(2131231084), context.getResources().getBoolean(2131427341));
    }

    public static String l(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231065), context.getResources().getString(2131231058));
    }

    public static String m(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231082), context.getResources().getString(2131231060));
    }

    public static String n(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231063), context.getResources().getString(2131231057));
    }

    public static String o(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231071), context.getResources().getString(2131231059));
    }

    public static Set<String> p(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getStringSet(context.getResources().getString(2131231069), new HashSet<String>(Arrays.asList(context.getResources().getStringArray(2131623941))));
    }

    public static String q(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231091), context.getResources().getString(2131231055));
    }

    public static boolean r(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(context.getResources().getString(2131231079), context.getResources().getBoolean(2131427338));
    }

    public static boolean s(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(context.getResources().getString(2131231075), context.getResources().getBoolean(2131427340));
    }

    public static String t(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231085), context.getResources().getString(2131231061));
    }

    public static String u(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231092), context.getResources().getString(2131231056));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Set<String> v(Context object) {
        synchronized (a.class) {
            if (a != null) return a;
            a.w((Context)object);
            return a;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void w(Context object) {
        synchronized (a.class) {
            a = new LinkedHashSet<String>();
            b = new LinkedHashSet<String>();
            object = new b(a.u((Context)object)).iterator();
            while (object.hasNext()) {
                f f2 = (f)object.next();
                a.addAll(f2.a());
                b.addAll(f2.b());
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Set<String> x(Context object) {
        synchronized (a.class) {
            if (b != null) return b;
            a.w((Context)object);
            return b;
        }
    }

    public static String y(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231083), context.getResources().getString(2131231052));
    }

    public static String z(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(context.getResources().getString(2131231067), context.getResources().getString(2131231051));
    }
}

