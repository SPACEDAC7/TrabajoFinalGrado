/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.prefs;

import com.orgzly.a.f;
import com.orgzly.a.g;
import java.util.ArrayList;

public class b
extends ArrayList<f> {
    /*
     * Enabled aggressive block sorting
     */
    public b(String arrstring) {
        if (arrstring == null || (arrstring = arrstring.trim()).length() == 0) {
            return;
        }
        arrstring = arrstring.split("\n+");
        int n2 = arrstring.length;
        int n3 = 0;
        while (n3 < n2) {
            this.add(new f(arrstring[n3]));
            ++n3;
        }
    }

    @Override
    public String toString() {
        return g.a(this, "\n");
    }
}

