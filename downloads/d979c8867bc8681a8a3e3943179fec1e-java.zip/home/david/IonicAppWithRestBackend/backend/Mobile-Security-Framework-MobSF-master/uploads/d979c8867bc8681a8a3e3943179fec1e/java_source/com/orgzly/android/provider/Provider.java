/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentProvider
 *  android.content.ContentProviderOperation
 *  android.content.ContentProviderResult
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.UriMatcher
 *  android.database.ContentObserver
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  android.net.Uri
 *  android.test.RenamingDelegatingContext
 *  android.text.TextUtils
 *  android.util.Log
 */
package com.orgzly.android.provider;

import android.content.ContentProvider;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.test.RenamingDelegatingContext;
import android.text.TextUtils;
import android.util.Log;
import com.orgzly.a.a.c;
import com.orgzly.a.b.h;
import com.orgzly.android.j;
import com.orgzly.android.provider.a.b;
import com.orgzly.android.provider.a.c;
import com.orgzly.android.provider.a.d;
import com.orgzly.android.provider.a.e;
import com.orgzly.android.provider.a.g;
import com.orgzly.android.provider.a.h;
import com.orgzly.android.provider.a.i;
import com.orgzly.android.provider.a.j;
import com.orgzly.android.provider.a.k;
import com.orgzly.android.provider.b.f;
import com.orgzly.android.provider.c.l;
import com.orgzly.android.provider.c.m;
import com.orgzly.android.provider.c.o;
import com.orgzly.android.provider.d.b;
import com.orgzly.android.provider.e;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Provider
extends ContentProvider {
    private static final String b = Provider.class.getName();
    private static final com.orgzly.android.provider.g c = new com.orgzly.android.provider.g();
    protected com.orgzly.android.provider.a a;

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int a(SQLiteDatabase sQLiteDatabase, long l2, String string, String string2) {
        long l3 = this.a(sQLiteDatabase, string);
        l3 = this.a(sQLiteDatabase, o.a(sQLiteDatabase, string2), l3);
        string = new ContentValues();
        string.put("book_id", Long.valueOf(l2));
        string.put("rook_id", Long.valueOf(l3));
        l2 = com.orgzly.android.provider.c.a(sQLiteDatabase, "book_links", "book_id=" + l2, null);
        if (l2 != 0) {
            sQLiteDatabase.update("book_links", (ContentValues)string, "_id=" + l2, null);
            do {
                return 1;
                break;
            } while (true);
        }
        sQLiteDatabase.insertOrThrow("book_links", null, (ContentValues)string);
        return 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int a(SQLiteDatabase sQLiteDatabase, long l2, String string, String string2, String string3, long l3) {
        long l4 = this.a(sQLiteDatabase, string);
        l3 = this.a(sQLiteDatabase, this.a(sQLiteDatabase, o.a(sQLiteDatabase, string2), l4), string3, l3);
        string = new ContentValues();
        string.put("book_versioned_rook_id", Long.valueOf(l3));
        string.put("book_id", Long.valueOf(l2));
        l2 = com.orgzly.android.provider.c.a(sQLiteDatabase, "book_syncs", "book_id=" + l2, null);
        if (l2 != 0) {
            sQLiteDatabase.update("book_syncs", (ContentValues)string, "_id=" + l2, null);
            do {
                return 1;
                break;
            } while (true);
        }
        sQLiteDatabase.insertOrThrow("book_syncs", null, (ContentValues)string);
        return 1;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private int a(SQLiteDatabase var1_1, Uri var2_11, ContentValues var3_12, String var4_13, String[] var5_14) {
        switch (Provider.c.a.match((Uri)var2_11)) {
            default: {
                throw new IllegalArgumentException("URI is not recognized: " + var2_11);
            }
            case 17: {
                var8_15 = "db_repos";
                ** GOTO lbl39
            }
            case 1: {
                return m.a(this.getContext(), var1_1, var3_12, var4_13, var5_14);
            }
            case 2: {
                var2_11 = "_id = " + var2_11.getLastPathSegment();
                return m.a(this.getContext(), var1_1, var3_12, (String)var2_11, null);
            }
            case 21: {
                var8_15 = "searches";
                ** GOTO lbl39
            }
            case 22: {
                var8_15 = "searches";
                var4_13 = "_id = " + var2_11.getLastPathSegment();
                var5_14 = null;
                ** GOTO lbl39
            }
            case 23: {
                var6_17 = com.orgzly.android.provider.f.a(var1_1, Long.parseLong((String)var2_11.getPathSegments().get(1)));
                Provider.a(this.getContext(), e.i.a.a());
                return var6_17;
            }
            case 24: {
                var6_18 = com.orgzly.android.provider.f.b(var1_1, Long.parseLong((String)var2_11.getPathSegments().get(1)));
                Provider.a(this.getContext(), e.i.a.a());
                return var6_18;
            }
            case 3: {
                var8_15 = "books";
                ** GOTO lbl39
            }
            case 4: {
                var8_15 = "books";
                var4_13 = "_id = " + var2_11.getLastPathSegment();
                var5_14 = null;
                ** GOTO lbl39
            }
            case 5: {
                var8_15 = "notes";
                this.a(var1_1, var3_12);
lbl39: // 6 sources:
                var6_16 = var1_1.update(var8_15, var3_12, var4_13, var5_14);
                Provider.a(this.getContext(), (Uri)var2_11);
                return var6_16;
            }
            case 12: {
                var4_13 = "_id = " + var2_11.getLastPathSegment();
                this.a(var1_1, var3_12);
                var6_19 = var1_1.update("notes", var3_12, var4_13, null);
                if (var2_11.getQueryParameter("book-id") != null) {
                    com.orgzly.android.provider.c.a(var1_1, Long.parseLong(var2_11.getQueryParameter("book-id")));
                }
                Provider.a(this.getContext(), e.n.a.a());
                Provider.a(this.getContext(), e.b.a.a());
                return var6_19;
            }
            case 7: {
                var6_16 = var7_30 = this.b(var1_1, var3_12.getAsString("note_ids"), var3_12.getAsString("state"));
                if (var7_30 <= 0) return var6_16;
                Provider.a(this.getContext(), e.n.a.a());
                Provider.a(this.getContext(), e.b.a.a());
                return var7_30;
            }
            case 13: {
                try {
                    var6_20 = b.a(var1_1, new c(var3_12));
                    return var6_20;
                }
                finally {
                    Provider.a(this.getContext(), e.n.a.a());
                    Provider.a(this.getContext(), e.b.a.a());
                }
            }
            case 14: {
                try {
                    var6_21 = b.a(var1_1, new h(var3_12));
                    return var6_21;
                }
                finally {
                    Provider.a(this.getContext(), e.n.a.a());
                    Provider.a(this.getContext(), e.b.a.a());
                }
            }
            case 33: {
                try {
                    var6_22 = b.a(var1_1, new e(var3_12));
                    return var6_22;
                }
                finally {
                    Provider.a(this.getContext(), e.n.a.a());
                    Provider.a(this.getContext(), e.b.a.a());
                }
            }
            case 15: {
                try {
                    var6_23 = b.a(var1_1, new i(var3_12));
                    return var6_23;
                }
                finally {
                    Provider.a(this.getContext(), e.n.a.a());
                    Provider.a(this.getContext(), e.b.a.a());
                }
            }
            case 32: {
                try {
                    var6_24 = b.a(var1_1, new com.orgzly.android.provider.a.f(var3_12));
                    return var6_24;
                }
                finally {
                    Provider.a(this.getContext(), e.n.a.a());
                    Provider.a(this.getContext(), e.b.a.a());
                }
            }
            case 16: {
                try {
                    var6_25 = b.a(var1_1, new g(var3_12));
                    return var6_25;
                }
                finally {
                    Provider.a(this.getContext(), e.n.a.a());
                    Provider.a(this.getContext(), e.b.a.a());
                }
            }
            case 31: {
                try {
                    var6_26 = b.a(var1_1, new k(Long.valueOf((String)var2_11.getPathSegments().get(1))));
                    return var6_26;
                }
                finally {
                    Provider.a(this.getContext(), e.n.a.a());
                }
            }
            case 30: {
                try {
                    var6_27 = b.a(var1_1, new d(Long.valueOf((String)var2_11.getPathSegments().get(1))));
                    return var6_27;
                }
                finally {
                    Provider.a(this.getContext(), e.n.a.a());
                }
            }
            case 34: {
                try {
                    var6_28 = b.a(var1_1, new j(Long.valueOf((String)var2_11.getPathSegments().get(1)), var3_12));
                    return var6_28;
                }
                finally {
                    Provider.a(this.getContext(), e.n.a.a());
                }
            }
            case 26: {
                var6_29 = this.c(var1_1, (Uri)var2_11, var3_12);
                Provider.a(this.getContext(), e.b.a.a());
                return var6_29;
            }
            case 18: {
                this.a.a(var1_1);
                Provider.a(this.getContext(), e.b.a.a());
                Provider.a(this.getContext(), e.n.a.a());
                Provider.a(this.getContext(), e.r.a.a());
                Provider.a(this.getContext(), e.i.a.a());
                Provider.a(this.getContext(), e.k.a.a());
                return 0;
            }
            case 19: 
        }
        var1_1 = new RenamingDelegatingContext(this.getContext(), "test_");
        this.a.close();
        this.a = new com.orgzly.android.provider.a((Context)var1_1);
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int a(SQLiteDatabase sQLiteDatabase, Uri uri, String string, String[] arrstring) {
        String string2;
        switch (Provider.c.a.match(uri)) {
            default: {
                throw new IllegalArgumentException("URI is not recognized: " + (Object)uri);
            }
            case 17: {
                string2 = "db_repos";
                break;
            }
            case 1: {
                return m.a(this.getContext(), sQLiteDatabase, string, arrstring);
            }
            case 2: {
                string = "_id = " + uri.getLastPathSegment();
                this.b(sQLiteDatabase, uri.getLastPathSegment());
                return m.a(this.getContext(), sQLiteDatabase, string, null);
            }
            case 21: {
                string2 = "searches";
                break;
            }
            case 22: {
                string2 = "searches";
                string = "_id = " + uri.getLastPathSegment();
                arrstring = null;
                break;
            }
            case 3: {
                string2 = "books";
                break;
            }
            case 4: {
                string2 = "books";
                string = "_id = " + uri.getLastPathSegment();
                arrstring = null;
                break;
            }
            case 5: {
                string2 = "notes";
                break;
            }
            case 27: {
                string2 = "current_versioned_rooks";
                break;
            }
            case 26: {
                int n2 = sQLiteDatabase.delete("book_links", "book_id = " + Long.parseLong((String)uri.getPathSegments().get(1)), null);
                Provider.a(this.getContext(), e.b.a.a());
                return n2;
            }
            case 11: {
                long l2 = Long.parseLong((String)uri.getPathSegments().get(1));
                string2 = "note_properties";
                string = "note_id = " + l2;
                arrstring = null;
            }
        }
        int n3 = sQLiteDatabase.delete(string2, string, arrstring);
        Provider.a(this.getContext(), uri);
        return n3;
    }

    private int a(SQLiteDatabase sQLiteDatabase, String string, String string2, String[] arrstring) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("state", string);
        contentValues.putNull("closed_range_id");
        return sQLiteDatabase.update("notes", contentValues, string2, arrstring);
    }

    private long a(SQLiteDatabase sQLiteDatabase, long l2) {
        com.orgzly.android.f f2 = com.orgzly.android.f.a(l2);
        ContentValues contentValues = new ContentValues();
        f.a(contentValues, f2);
        this.a(sQLiteDatabase, contentValues);
        return sQLiteDatabase.insertOrThrow("notes", null, contentValues);
    }

    private long a(SQLiteDatabase sQLiteDatabase, long l2, long l3) {
        long l4;
        long l5 = l4 = com.orgzly.android.provider.c.a(sQLiteDatabase, "rooks", "rook_url_id=? AND repo_id=?", new String[]{String.valueOf(l2), String.valueOf(l3)});
        if (l4 == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("rook_url_id", Long.valueOf(l2));
            contentValues.put("repo_id", Long.valueOf(l3));
            l5 = sQLiteDatabase.insertOrThrow("rooks", null, contentValues);
        }
        return l5;
    }

    private long a(SQLiteDatabase sQLiteDatabase, long l2, String string, long l3) {
        long l4;
        long l5 = l4 = com.orgzly.android.provider.c.a(sQLiteDatabase, "versioned_rooks", "rook_id=? AND rook_revision=? AND rook_mtime=?", new String[]{String.valueOf(l2), string, String.valueOf(l3)});
        if (l4 == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("rook_id", Long.valueOf(l2));
            contentValues.put("rook_revision", string);
            contentValues.put("rook_mtime", Long.valueOf(l3));
            l5 = sQLiteDatabase.insertOrThrow("versioned_rooks", null, contentValues);
        }
        return l5;
    }

    private long a(SQLiteDatabase sQLiteDatabase, com.orgzly.a.a.a a2) {
        long l2;
        long l3 = l2 = com.orgzly.android.provider.c.a(sQLiteDatabase, "org_timestamps", "string= ?", new String[]{a2.toString()});
        if (l2 == 0) {
            ContentValues contentValues = new ContentValues();
            com.orgzly.android.provider.c.i.a(contentValues, a2);
            l3 = sQLiteDatabase.insertOrThrow("org_timestamps", null, contentValues);
        }
        return l3;
    }

    private long a(SQLiteDatabase sQLiteDatabase, com.orgzly.a.a.d d2) {
        long l2;
        long l3 = 0;
        long l4 = l2 = com.orgzly.android.provider.c.a(sQLiteDatabase, "org_ranges", "string=?", new String[]{d2.toString()});
        if (l2 == 0) {
            ContentValues contentValues = new ContentValues();
            l2 = this.a(sQLiteDatabase, d2.a());
            l4 = l3;
            if (d2.b() != null) {
                l4 = this.a(sQLiteDatabase, d2.b());
            }
            com.orgzly.android.provider.c.h.a(contentValues, d2, l2, l4);
            l4 = sQLiteDatabase.insertOrThrow("org_ranges", null, contentValues);
        }
        return l4;
    }

    private long a(SQLiteDatabase sQLiteDatabase, String string) {
        long l2;
        long l3 = l2 = com.orgzly.android.provider.c.a(sQLiteDatabase, "repos", "repo_url=?", new String[]{string});
        if (l2 == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("repo_url", string);
            contentValues.put("is_repo_active", Integer.valueOf(0));
            l3 = sQLiteDatabase.insertOrThrow("repos", null, contentValues);
        }
        return l3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Cursor a(SQLiteDatabase sQLiteDatabase, String object, String string) {
        com.orgzly.android.j j2 = new com.orgzly.android.j((String)object);
        StringBuilder stringBuilder = new StringBuilder();
        ArrayList<String> arrayList = new ArrayList<String>();
        if (j2.i()) {
            object = new ArrayList<String>();
            for (String string2 : j2.h()) {
                object.add((String)"n1.tags LIKE ?");
                arrayList.add("%" + string2 + "%");
            }
            object = "(select n2.* from notes_view n1 LEFT OUTER JOIN notes_view n2 WHERE " + TextUtils.join((CharSequence)" AND ", object) + " AND  n1." + "book_id" + " = n2." + "book_id" + " AND  n1." + "is_cut" + " = 0 AND n2." + "is_cut" + " = 0 AND (n1." + "is_visible" + " <= n2." + "is_visible" + " and n2." + "parent_position" + " <= n1." + "parent_position" + ") GROUP BY n2._id) n";
        } else {
            object = "notes_view";
        }
        stringBuilder.append("(is_cut = 0 AND level > 0)");
        if (j2.q()) {
            stringBuilder.append(" AND ").append(e.n.b.a).append(" = ?");
            arrayList.add(j2.p());
        }
        if (j2.s()) {
            for (String string2 : j2.r()) {
                stringBuilder.append(" AND ").append(e.n.b.a).append(" != ?");
                arrayList.add(string2);
            }
        }
        if (j2.m()) {
            stringBuilder.append(" AND COALESCE(state, '') = ?");
            arrayList.add(j2.l());
        }
        if (j2.o()) {
            for (String string2 : j2.n()) {
                stringBuilder.append(" AND COALESCE(state, '') != ?");
                arrayList.add(string2);
            }
        }
        for (String string2 : j2.e()) {
            stringBuilder.append(" AND (title LIKE ?");
            arrayList.add("%" + string2 + "%");
            stringBuilder.append(" OR content LIKE ?");
            arrayList.add("%" + string2 + "%");
            stringBuilder.append(" OR tags LIKE ?");
            arrayList.add("%" + string2 + "%");
            stringBuilder.append(")");
        }
        if (j2.a()) {
            Provider.a(stringBuilder, e.n.b.f, j2.b());
        }
        if (j2.c()) {
            Provider.a(stringBuilder, e.n.b.k, j2.d());
        }
        if (j2.k()) {
            String string3 = com.orgzly.android.prefs.a.z(this.getContext());
            stringBuilder.append(" AND lower(coalesce(nullif(priority, ''), ?)) = ?");
            arrayList.add(string3);
            arrayList.add(j2.j());
        }
        if (j2.g()) {
            for (String string4 : j2.f()) {
                stringBuilder.append(" AND tags LIKE ?");
                arrayList.add("%" + string4 + "%");
            }
        }
        return sQLiteDatabase.rawQuery("SELECT * FROM " + object + " WHERE " + stringBuilder.toString() + " ORDER BY " + string, arrayList.toArray(new String[arrayList.size()]));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Uri a(ContentValues var1_1) {
        var6_3 = var1_1.getAsString("book_name");
        var7_4 = var1_1.getAsString("format");
        var8_5 = var1_1.getAsString("file_path");
        var9_6 = var1_1.getAsString("rook_repo_url");
        var10_7 = var1_1.getAsString("rook_url");
        var11_8 = var1_1.getAsString("rook_revision");
        var2_9 = var1_1.containsKey("rook_mtime") != false ? var1_1.getAsLong("rook_mtime") : 0;
        var5_10 = var1_1.getAsString("selected_encoding");
        var4_11 = null;
        if (var5_10 != null) ** GOTO lbl19
        try {
            var4_11 = com.orgzly.android.b.c.a(new FileInputStream(new File(var8_5))).a();
            if (var4_11 == null) {
                var1_1 = "UTF-8";
                Log.w((String)Provider.b, (String)("Encoding for " + var6_3 + " could not be detected, using UTF-8"));
                return this.a(var6_3, var9_6, var10_7, var11_8, var2_9, var7_4, new InputStreamReader((InputStream)new FileInputStream(new File(var8_5)), (String)var1_1), (String)var1_1, var4_11, var5_10);
            } else {
                var1_1 = var4_11;
            }
            return this.a(var6_3, var9_6, var10_7, var11_8, var2_9, var7_4, new InputStreamReader((InputStream)new FileInputStream(new File(var8_5)), (String)var1_1), (String)var1_1, var4_11, var5_10);
lbl19: // 1 sources:
            var1_1 = var5_10;
            return this.a(var6_3, var9_6, var10_7, var11_8, var2_9, var7_4, new InputStreamReader((InputStream)new FileInputStream(new File(var8_5)), (String)var1_1), (String)var1_1, var4_11, var5_10);
        }
        catch (IOException var1_2) {
            var1_2.printStackTrace();
            throw new IllegalArgumentException(var1_2);
        }
    }

    private Uri a(SQLiteDatabase sQLiteDatabase, Uri object, ContentValues contentValues) {
        long l2 = Long.parseLong((String)object.getPathSegments().get(1));
        object = contentValues.getAsString("repo_url");
        String string = contentValues.getAsString("rook_url");
        String string2 = contentValues.getAsString("rook_revision");
        long l3 = contentValues.getAsLong("rook_mtime");
        long l4 = this.a(sQLiteDatabase, (String)object);
        l4 = this.a(sQLiteDatabase, o.a(sQLiteDatabase, string), l4);
        long l5 = this.a(sQLiteDatabase, l4, string2, l3);
        this.a(sQLiteDatabase, l2, (String)object, string);
        this.a(sQLiteDatabase, l2, (String)object, string, string2, l3);
        sQLiteDatabase.rawQuery("DELETE FROM current_versioned_rooks WHERE versioned_rook_id IN (SELECT _id FROM versioned_rooks WHERE rook_id=?)", new String[]{String.valueOf(l4)});
        object = new ContentValues();
        object.put("versioned_rook_id", Long.valueOf(l5));
        sQLiteDatabase.insert("current_versioned_rooks", null, (ContentValues)object);
        return ContentUris.withAppendedId((Uri)e.b.a.a(), (long)l2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Uri a(SQLiteDatabase sQLiteDatabase, Uri uri, ContentValues contentValues, com.orgzly.android.ui.l l2) {
        com.orgzly.android.g g2 = new com.orgzly.android.g();
        long l3 = contentValues.getAsLong("book_id");
        long l4 = 0;
        com.orgzly.android.g g3 = null;
        if (l2 != com.orgzly.android.ui.l.d) {
            l4 = Long.valueOf((String)uri.getPathSegments().get(1));
            g3 = com.orgzly.android.provider.c.f.a(sQLiteDatabase, l4);
        }
        switch (.b[l2.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unsupported placement for new note: " + (Object)((Object)l2));
            }
            case 1: {
                g2.b(g3.e());
                g2.d(g3.g());
                g2.e(g3.g() + 1);
                g2.b(g3.b());
                break;
            }
            case 2: {
                g2.b(g3.e() + 1);
                g2.d(g3.h());
                g2.e(g3.h() + 1);
                g2.b(l4);
                if (!g3.c()) break;
                g2.a(l4);
                break;
            }
            case 3: {
                g2.b(g3.e());
                g2.d(g3.h() + 1);
                g2.e(g3.h() + 2);
                g2.b(g3.b());
                break;
            }
            case 4: {
                l4 = this.b(sQLiteDatabase, l3);
                long l5 = this.c(sQLiteDatabase, l3);
                g2.b(1);
                g2.d(l4);
                g2.e(l4 + 1);
                g2.b(l5);
            }
        }
        switch (.b[l2.ordinal()]) {
            default: {
                break;
            }
            case 1: 
            case 2: 
            case 3: {
                com.orgzly.android.provider.c.a(sQLiteDatabase, 1, g3, l2);
                this.a(sQLiteDatabase, l3, g2.g(), g2.h());
            }
            case 4: {
                com.orgzly.android.provider.d.a(sQLiteDatabase, "notes", "book_id = " + l3 + " AND " + "is_visible" + " = 1", 2, "parent_position");
            }
        }
        g2.c(l3);
        com.orgzly.android.provider.c.f.a(contentValues, g2);
        this.a(sQLiteDatabase, contentValues);
        return ContentUris.withAppendedId((Uri)uri, (long)sQLiteDatabase.insertOrThrow("notes", null, contentValues));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Uri a(SQLiteDatabase sQLiteDatabase, Uri uri, ContentValues contentValues, Set<Uri> object) {
        switch (Provider.c.a.match(uri)) {
            default: {
                throw new IllegalArgumentException("URI is not recognized: " + (Object)uri);
            }
            case 17: {
                object = "db_repos";
                do {
                    return ContentUris.withAppendedId((Uri)uri, (long)sQLiteDatabase.insertOrThrow((String)object, null, contentValues));
                    break;
                } while (true);
            }
            case 1: {
                return ContentUris.withAppendedId((Uri)uri, (long)m.a(this.getContext(), sQLiteDatabase, contentValues.getAsString("repo_url")));
            }
            case 3: {
                long l2 = sQLiteDatabase.insertOrThrow("books", null, contentValues);
                this.a(sQLiteDatabase, l2);
                return ContentUris.withAppendedId((Uri)uri, (long)l2);
            }
            case 21: {
                object = "searches";
                com.orgzly.android.provider.f.a(sQLiteDatabase, contentValues);
                return ContentUris.withAppendedId((Uri)uri, (long)sQLiteDatabase.insertOrThrow((String)object, null, contentValues));
            }
            case 5: {
                return this.a(sQLiteDatabase, uri, contentValues, com.orgzly.android.ui.l.d);
            }
            case 8: {
                return this.a(sQLiteDatabase, uri, contentValues, com.orgzly.android.ui.l.a);
            }
            case 9: {
                return this.a(sQLiteDatabase, uri, contentValues, com.orgzly.android.ui.l.b);
            }
            case 10: {
                return this.a(sQLiteDatabase, uri, contentValues, com.orgzly.android.ui.l.c);
            }
            case 29: {
                long l3 = contentValues.getAsLong("note_id");
                object = contentValues.getAsString("name");
                String string = contentValues.getAsString("value");
                return ContentUris.withAppendedId((Uri)uri, (long)new com.orgzly.android.provider.c.g(l3, (int)contentValues.getAsInteger("position"), new com.orgzly.android.provider.c.j(new com.orgzly.android.provider.c.k((String)object), new l(string))).a(sQLiteDatabase));
            }
            case 20: {
                sQLiteDatabase = this.a(contentValues);
                object.add(e.n.a.a());
                object.add(e.b.a.a());
                return sQLiteDatabase;
            }
            case 27: {
                sQLiteDatabase = this.b(sQLiteDatabase, uri, contentValues);
                object.add(e.b.a.a());
                return sQLiteDatabase;
            }
            case 28: 
        }
        sQLiteDatabase = this.a(sQLiteDatabase, uri, contentValues);
        object.add(e.b.a.a());
        return sQLiteDatabase;
    }

    private Uri a(String string, String string2, String string3, String string4, long l2, String string5, Reader reader, String string6, String string7, String string8) {
        long l3;
        block3 : {
            System.currentTimeMillis();
            string5 = this.a.getWritableDatabase();
            string = this.c((SQLiteDatabase)string5, string);
            l3 = ContentUris.parseId((Uri)string);
            string5.delete("notes", "book_id=" + l3, null);
            reader = new BufferedReader(reader);
            new h.a().a(reader).a(com.orgzly.android.prefs.a.v(this.getContext())).b(com.orgzly.android.prefs.a.x(this.getContext())).a(new com.orgzly.a.b.c((SQLiteDatabase)string5, string6, string7, string8){
                final /* synthetic */ SQLiteDatabase b;
                final /* synthetic */ String c;
                final /* synthetic */ String d;
                final /* synthetic */ String e;

                @Override
                public void a(com.orgzly.a.a a2) {
                    a.a(a2);
                    ContentValues contentValues = new ContentValues();
                    com.orgzly.android.provider.b.a.a(contentValues, a2.a());
                    contentValues.put("preface", a2.b());
                    contentValues.put("used_encoding", this.c);
                    contentValues.put("detected_encoding", this.d);
                    contentValues.put("selected_encoding", this.e);
                    this.b.update("books", contentValues, "_id=" + l3, null);
                }

                @Override
                public void a(com.orgzly.a.b.f object) {
                    a.a((com.orgzly.a.b.d)object);
                    Object object2 = new com.orgzly.android.g();
                    object2.c(l3);
                    object2.d(object.c());
                    object2.e(object.d());
                    object2.b(object.a());
                    object2.a(object.e());
                    object2.a(0);
                    ContentValues contentValues = new ContentValues();
                    com.orgzly.android.provider.c.f.a(contentValues, (com.orgzly.android.g)object2);
                    com.orgzly.android.provider.c.f.a(this.b, contentValues, object.b());
                    long l2 = this.b.insertOrThrow("notes", null, contentValues);
                    object = object.b().p().iterator();
                    int n2 = 0;
                    while (object.hasNext()) {
                        object2 = (com.orgzly.a.e)object.next();
                        new com.orgzly.android.provider.c.g(l2, n2, new com.orgzly.android.provider.c.j(new com.orgzly.android.provider.c.k(object2.a()), new l(object2.b()))).a(this.b);
                        ++n2;
                    }
                }
            }).a().a();
            if (string3 == null) break block3;
            this.a((SQLiteDatabase)string5, l3, string2, string3);
            this.a((SQLiteDatabase)string5, l3, string2, string3, string4, l2);
        }
        com.orgzly.android.provider.c.b((SQLiteDatabase)string5, l3);
        string2 = new ContentValues();
        string2.put("is_dummy", Integer.valueOf(0));
        string5.update("books", (ContentValues)string2, "_id=" + l3, null);
        return string;
        finally {
            reader.close();
        }
    }

    public static void a(Context context, Uri uri) {
        context.getContentResolver().notifyChange(uri, null);
    }

    private void a(SQLiteDatabase sQLiteDatabase, long l2, long l3, long l4) {
        sQLiteDatabase.execSQL("UPDATE notes SET has_children = has_children + 1 WHERE " + com.orgzly.android.provider.c.a(l2, l3, l4));
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(SQLiteDatabase sQLiteDatabase, ContentValues contentValues) {
        String string;
        if (contentValues.containsKey("scheduled_string")) {
            string = contentValues.getAsString("scheduled_string");
            if (!TextUtils.isEmpty((CharSequence)string)) {
                contentValues.put("scheduled_range_id", Long.valueOf(this.a(sQLiteDatabase, com.orgzly.a.a.d.b(string))));
            } else {
                contentValues.putNull("scheduled_range_id");
            }
            contentValues.remove("scheduled_string");
        }
        if (contentValues.containsKey("deadline_string")) {
            string = contentValues.getAsString("deadline_string");
            if (!TextUtils.isEmpty((CharSequence)string)) {
                contentValues.put("deadline_range_id", Long.valueOf(this.a(sQLiteDatabase, com.orgzly.a.a.d.b(string))));
            } else {
                contentValues.putNull("deadline_range_id");
            }
            contentValues.remove("deadline_string");
        }
        if (contentValues.containsKey("closed_string")) {
            string = contentValues.getAsString("closed_string");
            if (!TextUtils.isEmpty((CharSequence)string)) {
                contentValues.put("closed_range_id", Long.valueOf(this.a(sQLiteDatabase, com.orgzly.a.a.d.b(string))));
            } else {
                contentValues.putNull("closed_range_id");
            }
            contentValues.remove("closed_string");
        }
        if (contentValues.containsKey("clock_string")) {
            string = contentValues.getAsString("clock_string");
            if (!TextUtils.isEmpty((CharSequence)string)) {
                contentValues.put("clock_range_id", Long.valueOf(this.a(sQLiteDatabase, com.orgzly.a.a.d.b(string))));
            } else {
                contentValues.putNull("clock_range_id");
            }
            contentValues.remove("clock_string");
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void a(StringBuilder var0, String var1_1, j.a var2_2) {
        var3_3 = new GregorianCalendar();
        switch (.a[var2_2.c().ordinal()]) {
            case 1: {
                var3_3.add(5, var2_2.b());
                ** break;
            }
            case 2: {
                var3_3.add(3, var2_2.b());
                ** break;
            }
            case 3: {
                var3_3.add(2, var2_2.b());
            }
lbl11: // 4 sources:
            default: {
                ** GOTO lbl15
            }
            case 4: 
        }
        var3_3.add(1, var2_2.b());
lbl15: // 2 sources:
        var3_3.add(5, 1);
        var3_3.set(11, 0);
        var3_3.set(12, 0);
        var3_3.set(13, 0);
        var3_3.set(14, 0);
        var0.append(" AND ").append(var1_1).append(" != 0").append(" AND ").append(var1_1).append(" < ").append(var3_3.getTimeInMillis());
    }

    private int b(SQLiteDatabase sQLiteDatabase, long l2) {
        String string = "book_id= " + l2 + " AND " + "is_cut" + " = 0";
        sQLiteDatabase = sQLiteDatabase.query("notes", new String[]{"MAX(parent_position)"}, string, null, null, null, null);
        try {
            if (sQLiteDatabase.moveToFirst()) {
                int n2 = sQLiteDatabase.getInt(0);
                return n2;
            }
            return 0;
        }
        finally {
            sQLiteDatabase.close();
        }
    }

    private int b(SQLiteDatabase sQLiteDatabase, String string) {
        string = "SELECT DISTINCT _id FROM rooks WHERE repo_id = " + string;
        return sQLiteDatabase.delete("book_links", "rook_id IN (" + string + ")", null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int b(SQLiteDatabase sQLiteDatabase, String string, String string2) {
        sQLiteDatabase.beginTransaction();
        string = "_id IN (" + string + ") AND (" + "state" + " IS NULL OR " + "state" + " != ?)";
        String[] arrstring = new String[]{string2};
        com.orgzly.android.provider.c.a(sQLiteDatabase, "_id IN (SELECT DISTINCT book_id FROM notes WHERE " + string + ")", arrstring);
        int n2 = com.orgzly.android.prefs.a.a(this.getContext(), string2) ? this.b(sQLiteDatabase, string2, string, arrstring) : this.a(sQLiteDatabase, string2, string, arrstring);
        sQLiteDatabase.setTransactionSuccessful();
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int b(SQLiteDatabase sQLiteDatabase, String string, String string2, String[] object) {
        string2 = sQLiteDatabase.query("notes_view", new String[]{"_id", b.a.b, b.a.g, "state"}, string2, (String[])object, null, null, null);
        try {
            string2.moveToFirst();
            int n2 = 0;
            while (!string2.isAfterLast()) {
                object = new com.orgzly.android.l(com.orgzly.android.prefs.a.v(this.getContext()), com.orgzly.android.prefs.a.x(this.getContext()));
                object.a(string, string2.getString(3), com.orgzly.a.a.d.a(string2.getString(1)), com.orgzly.a.a.d.a(string2.getString(2)));
                ContentValues contentValues = new ContentValues();
                if (object.a() != null) {
                    contentValues.put("state", object.a());
                } else {
                    contentValues.putNull("state");
                }
                if (object.b() != null) {
                    contentValues.put("scheduled_string", object.b().toString());
                } else {
                    contentValues.putNull("scheduled_string");
                }
                if (object.c() != null) {
                    contentValues.put("deadline_string", object.c().toString());
                } else {
                    contentValues.putNull("deadline_string");
                }
                if (object.d() != null) {
                    contentValues.put("closed_string", object.d().toString());
                } else {
                    contentValues.putNull("closed_string");
                }
                this.a(sQLiteDatabase, contentValues);
                n2 += sQLiteDatabase.update("notes", contentValues, "_id=" + string2.getString(0), null);
                string2.moveToNext();
            }
            return n2;
        }
        finally {
            string2.close();
        }
    }

    private Uri b(SQLiteDatabase sQLiteDatabase, Uri uri, ContentValues contentValues) {
        String string = contentValues.getAsString("repo_url");
        String string2 = contentValues.getAsString("rook_url");
        String string3 = contentValues.getAsString("rook_revision");
        long l2 = contentValues.getAsLong("rook_mtime");
        long l3 = this.a(sQLiteDatabase, string);
        l2 = this.a(sQLiteDatabase, this.a(sQLiteDatabase, o.a(sQLiteDatabase, string2), l3), string3, l2);
        contentValues = new ContentValues();
        contentValues.put("versioned_rook_id", Long.valueOf(l2));
        return ContentUris.withAppendedId((Uri)uri, (long)sQLiteDatabase.insert("current_versioned_rooks", null, contentValues));
    }

    private int c(SQLiteDatabase sQLiteDatabase, Uri object, ContentValues object2) {
        long l2 = Long.parseLong((String)object.getPathSegments().get(1));
        object = object2.getAsString("repo_url");
        object2 = object2.getAsString("rook_url");
        if (object == null || object2 == null) {
            sQLiteDatabase.delete("book_links", "book_id=" + l2, null);
            return 1;
        }
        this.a(sQLiteDatabase, l2, (String)object, (String)object2);
        return 1;
    }

    private long c(SQLiteDatabase sQLiteDatabase, long l2) {
        block2 : {
            int n2;
            sQLiteDatabase = sQLiteDatabase.query("notes", com.orgzly.android.provider.c.a, "book_id= " + l2 + " AND " + "level" + " = 0", null, null, null, null);
            try {
                if (!sQLiteDatabase.moveToFirst()) break block2;
                n2 = sQLiteDatabase.getInt(0);
            }
            catch (Throwable var5_4) {
                sQLiteDatabase.close();
                throw var5_4;
            }
            l2 = n2;
            sQLiteDatabase.close();
            return l2;
        }
        sQLiteDatabase.close();
        return 0;
    }

    private Uri c(SQLiteDatabase sQLiteDatabase, String string) {
        Cursor cursor = sQLiteDatabase.query("books", new String[]{"_id"}, "name=?", new String[]{string}, null, null, null);
        if (cursor.moveToFirst()) {
            sQLiteDatabase = ContentUris.withAppendedId((Uri)e.b.a.a(), (long)cursor.getLong(0));
            return sQLiteDatabase;
        }
        cursor = new ContentValues();
        cursor.put("name", string);
        long l2 = sQLiteDatabase.insertOrThrow("books", null, (ContentValues)cursor);
        return ContentUris.withAppendedId((Uri)e.b.a.a(), (long)l2);
        finally {
            cursor.close();
        }
    }

    public ContentProviderResult[] applyBatch(ArrayList<ContentProviderOperation> arrcontentProviderResult) {
        SQLiteDatabase sQLiteDatabase = this.a.getWritableDatabase();
        sQLiteDatabase.beginTransaction();
        try {
            arrcontentProviderResult = super.applyBatch(arrcontentProviderResult);
            sQLiteDatabase.setTransactionSuccessful();
            return arrcontentProviderResult;
        }
        finally {
            sQLiteDatabase.endTransaction();
        }
    }

    public int bulkInsert(Uri object, ContentValues[] arrcontentValues) {
        SQLiteDatabase sQLiteDatabase2 = this.a.getWritableDatabase();
        HashSet<Uri> hashSet = new HashSet<Uri>();
        hashSet.add((Uri)object);
        sQLiteDatabase2.beginTransaction();
        int n2 = 0;
        do {
            if (n2 >= arrcontentValues.length) break;
            this.a(sQLiteDatabase2, (Uri)object, arrcontentValues[n2], hashSet);
            ++n2;
        } while (true);
        try {
            sQLiteDatabase2.setTransactionSuccessful();
        }
        catch (Throwable var1_2) {
            throw var1_2;
        }
        finally {
            sQLiteDatabase2.endTransaction();
        }
        for (Uri uri : hashSet) {
            Provider.a(this.getContext(), uri);
        }
        return arrcontentValues.length;
    }

    public int delete(Uri uri, String string, String[] arrstring) {
        return this.a(this.a.getWritableDatabase(), uri, string, arrstring);
    }

    public String getType(Uri uri) {
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public Uri insert(Uri uri, ContentValues iterator) {
        SQLiteDatabase sQLiteDatabase = this.a.getWritableDatabase();
        HashSet<Uri> hashSet = new HashSet<Uri>();
        hashSet.add(uri);
        sQLiteDatabase.beginTransaction();
        uri = this.a(sQLiteDatabase, uri, (ContentValues)iterator, (Set<Uri>)hashSet);
        sQLiteDatabase.setTransactionSuccessful();
        for (Uri uri2 : hashSet) {
            Provider.a(this.getContext(), uri2);
        }
        return uri;
        finally {
            sQLiteDatabase.endTransaction();
        }
    }

    public boolean onCreate() {
        this.a = new com.orgzly.android.provider.a(this.getContext());
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public Cursor query(Uri uri, String[] object, String arrstring, String[] object2, String arrstring2) {
        Object object3;
        SQLiteDatabase sQLiteDatabase = this.a.getReadableDatabase();
        switch (Provider.c.a.match(uri)) {
            default: {
                throw new IllegalArgumentException("URI is not recognized: " + (Object)uri);
            }
            case 17: {
                String string = "db_repos";
                object3 = arrstring2;
                arrstring2 = object2;
                object2 = arrstring;
                arrstring = object;
                object = string;
                break;
            }
            case 1: {
                String string = "repos";
                object3 = arrstring2;
                arrstring2 = null;
                object2 = "is_repo_active= 1";
                arrstring = object;
                object = string;
                break;
            }
            case 2: {
                object2 = "repos";
                arrstring = uri.getLastPathSegment();
                object3 = arrstring2;
                arrstring2 = new String[]{arrstring};
                String string = "_id=?";
                arrstring = object;
                object = object2;
                object2 = string;
                break;
            }
            case 5: {
                String string = "notes_view";
                object3 = arrstring2;
                arrstring2 = object2;
                object2 = arrstring;
                arrstring = object;
                object = string;
                break;
            }
            case 6: {
                uri = this.a(sQLiteDatabase, uri.getQuery(), (String)arrstring2);
                uri.setNotificationUri(this.getContext().getContentResolver(), e.n.a.a());
                uri.setNotificationUri(this.getContext().getContentResolver(), e.b.a.a());
                return uri;
            }
            case 25: {
                long l2 = Long.parseLong((String)uri.getPathSegments().get(1));
                object2 = "book_id=" + l2 + " AND " + com.orgzly.android.provider.c.c;
                uri = e.n.a.a();
                String string = "notes_view";
                object3 = arrstring2;
                arrstring2 = null;
                arrstring = object;
                object = string;
                break;
            }
            case 11: {
                long l3 = Long.parseLong((String)uri.getPathSegments().get(1));
                object2 = "note_properties.note_id=" + l3;
                object = "note_properties " + com.orgzly.android.provider.d.a("properties", "tproperties", "_id", "note_properties", "property_id") + com.orgzly.android.provider.d.a("property_names", "tpropertyname", "_id", "tproperties", "name_id") + com.orgzly.android.provider.d.a("property_values", "tpropertyvalue", "_id", "tproperties", "value_id");
                object3 = "position";
                arrstring2 = null;
                arrstring = new String[]{"tpropertyname.name", "tpropertyvalue.value"};
                break;
            }
            case 3: {
                String string = "books_view";
                object3 = arrstring2;
                arrstring2 = object2;
                object2 = arrstring;
                arrstring = object;
                object = string;
                break;
            }
            case 4: {
                object2 = "books_view";
                arrstring = uri.getLastPathSegment();
                object3 = arrstring2;
                arrstring2 = new String[]{arrstring};
                String string = "_id=?";
                arrstring = object;
                object = object2;
                object2 = string;
                break;
            }
            case 21: {
                String string = "searches";
                object3 = arrstring2;
                arrstring2 = object2;
                object2 = arrstring;
                arrstring = object;
                object = string;
                break;
            }
            case 22: {
                object2 = "searches";
                arrstring = uri.getLastPathSegment();
                object3 = arrstring2;
                arrstring2 = new String[]{arrstring};
                String string = "_id=?";
                arrstring = object;
                object = object2;
                object2 = string;
                break;
            }
            case 27: {
                object = "current_versioned_rooks LEFT JOIN versioned_rooks ON (versioned_rooks._id=current_versioned_rooks.versioned_rook_id) LEFT JOIN rooks ON (rooks._id=versioned_rooks.rook_id) LEFT JOIN rook_urls ON (rook_urls._id=rooks.rook_url_id) LEFT JOIN repos ON (repos._id=rooks.repo_id)";
                object3 = arrstring2;
                arrstring2 = object2;
                object2 = arrstring;
                arrstring = new String[]{"repos.repo_url", "rook_urls.rook_url", "versioned_rooks.rook_revision", "versioned_rooks.rook_mtime"};
            }
        }
        object = sQLiteDatabase.query((String)object, arrstring, (String)object2, arrstring2, null, null, (String)object3);
        object.setNotificationUri(this.getContext().getContentResolver(), uri);
        return object;
    }

    public int update(Uri uri, ContentValues contentValues, String string, String[] arrstring) {
        return this.a(this.a.getWritableDatabase(), uri, contentValues, string, arrstring);
    }

    public static class a {
        public static void a(com.orgzly.a.a a2) {
            if (a2.b().length() > 1000000) {
                throw new IOException("Notebook content is too big (" + a2.b().length() + " chars " + 1000000 + " max)");
            }
        }

        public static void a(com.orgzly.a.b.d d2) {
            int n2 = new com.orgzly.a.b.j().a(d2, true).length();
            if (n2 > 1500000) {
                throw new IOException("Note total size is too big (" + n2 + " chars " + 1500000 + " max)");
            }
        }
    }

}

