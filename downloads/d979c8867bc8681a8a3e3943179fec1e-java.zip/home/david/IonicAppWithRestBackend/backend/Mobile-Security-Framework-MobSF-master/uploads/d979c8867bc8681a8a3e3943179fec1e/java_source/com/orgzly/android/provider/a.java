/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteDatabase$CursorFactory
 *  android.database.sqlite.SQLiteOpenHelper
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 */
package com.orgzly.android.provider;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;
import com.orgzly.android.provider.b;
import com.orgzly.android.provider.c.c;
import com.orgzly.android.provider.c.d;
import com.orgzly.android.provider.c.e;
import com.orgzly.android.provider.c.f;
import com.orgzly.android.provider.c.g;
import com.orgzly.android.provider.c.h;
import com.orgzly.android.provider.c.i;
import com.orgzly.android.provider.c.j;
import com.orgzly.android.provider.c.k;
import com.orgzly.android.provider.c.l;
import com.orgzly.android.provider.c.m;
import com.orgzly.android.provider.c.n;
import com.orgzly.android.provider.c.o;
import com.orgzly.android.provider.c.p;
import com.orgzly.android.provider.c.q;

public class a
extends SQLiteOpenHelper {
    private static final String a = a.class.getName();
    private Context b;

    public a(Context context) {
        super(context, "orgzly.db", null, 137);
        this.b = context;
        if (Build.VERSION.SDK_INT >= 16) {
            this.setWriteAheadLoggingEnabled(true);
        }
    }

    private void b(SQLiteDatabase sQLiteDatabase) {
        int n2;
        int n3 = 0;
        String[] arrstring = m.a;
        int n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = com.orgzly.android.provider.c.a.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = f.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = i.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = h.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = p.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = com.orgzly.android.provider.c.b.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = c.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = o.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = n.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = q.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = d.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = e.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = g.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = k.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = l.a;
        n4 = arrstring.length;
        for (n2 = 0; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
        arrstring = j.a;
        n4 = arrstring.length;
        for (n2 = n3; n2 < n4; ++n2) {
            sQLiteDatabase.execSQL(arrstring[n2]);
        }
    }

    private void c(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS repos");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS books");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS notes");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS org_timestamps");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS org_ranges");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS searches");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS book_links");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS book_syncs");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS rook_urls");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS rooks");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS versioned_rooks");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS current_versioned_rooks");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS db_repos");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS note_properties");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS property_names");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS property_values");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS properties");
    }

    private void d(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("DROP VIEW IF EXISTS notes_view");
        sQLiteDatabase.execSQL("DROP VIEW IF EXISTS books_view");
    }

    private void e(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL(com.orgzly.android.provider.d.b.a);
        sQLiteDatabase.execSQL(com.orgzly.android.provider.d.a.a);
    }

    public void a(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.beginTransaction();
        try {
            this.d(sQLiteDatabase);
            this.c(sQLiteDatabase);
            this.onCreate(sQLiteDatabase);
            sQLiteDatabase.setTransactionSuccessful();
            return;
        }
        finally {
            sQLiteDatabase.endTransaction();
        }
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        Log.i((String)a, (String)"Creating database for version 137");
        this.b(sQLiteDatabase);
        this.e(sQLiteDatabase);
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int n2, int n3) {
        Log.i((String)a, (String)("Upgrading database from " + n2 + " to " + n3));
        this.d(sQLiteDatabase);
        b.a(sQLiteDatabase, n2, new Runnable(){

            @Override
            public void run() {
                android.support.v4.c.m.a(a.this.b).a(new Intent("com.orgzly.broadcast.db.upgrade.started"));
            }
        });
        this.e(sQLiteDatabase);
        android.support.v4.c.m.a(this.b).a(new Intent("com.orgzly.broadcast.db.upgrade.ended"));
    }

}

