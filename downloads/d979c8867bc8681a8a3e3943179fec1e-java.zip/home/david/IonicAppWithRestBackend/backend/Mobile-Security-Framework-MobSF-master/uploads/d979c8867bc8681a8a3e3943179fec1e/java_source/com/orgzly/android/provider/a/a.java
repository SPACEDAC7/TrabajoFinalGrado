/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.a;

import android.database.sqlite.SQLiteDatabase;

public interface a {
    public int a(SQLiteDatabase var1);
}

