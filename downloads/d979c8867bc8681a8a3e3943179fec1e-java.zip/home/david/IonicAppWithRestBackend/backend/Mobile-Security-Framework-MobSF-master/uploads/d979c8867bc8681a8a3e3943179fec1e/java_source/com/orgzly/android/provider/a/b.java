/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.a;

import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.a.a;

public class b {
    private static final String a = b.class.getName();

    public static int a(SQLiteDatabase sQLiteDatabase, a a2) {
        System.currentTimeMillis();
        sQLiteDatabase.beginTransaction();
        try {
            int n2 = a2.a(sQLiteDatabase);
            sQLiteDatabase.setTransactionSuccessful();
            return n2;
        }
        finally {
            sQLiteDatabase.endTransaction();
        }
    }
}

