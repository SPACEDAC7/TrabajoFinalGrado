/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.a;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.a.a;

public class c
implements a {
    private long a;
    private String b;

    public c(ContentValues contentValues) {
        this.a = contentValues.getAsLong("book_id");
        this.b = contentValues.getAsString("ids");
    }

    @Override
    public int a(SQLiteDatabase sQLiteDatabase) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("is_cut", Long.valueOf(System.currentTimeMillis()));
        int n2 = sQLiteDatabase.update("notes", contentValues, com.orgzly.android.provider.c.b(this.a, this.b), null);
        com.orgzly.android.provider.c.a(sQLiteDatabase, com.orgzly.android.provider.c.a(this.a, this.b));
        com.orgzly.android.provider.c.a(sQLiteDatabase, this.a);
        return n2;
    }
}

