/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.a;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.a.a;
import com.orgzly.android.provider.c;

public class d
implements a {
    private static final String a = d.class.getName();
    private long b;

    public d(long l2) {
        this.b = l2;
    }

    public static void a(SQLiteDatabase sQLiteDatabase, long l2) {
        String string = "(SELECT min(level) FROM notes WHERE " + c.a(l2) + ")";
        sQLiteDatabase.execSQL("UPDATE notes SET is_under_collapsed = parent_id WHERE " + c.a(l2) + " AND " + "level" + " > " + string);
        sQLiteDatabase.execSQL("UPDATE notes SET is_collapsed = 1 WHERE " + c.a(l2));
    }

    private boolean b(SQLiteDatabase sQLiteDatabase, long l2) {
        block2 : {
            String string = c.a(l2) + " AND " + com.orgzly.android.provider.d.a("is_collapsed");
            sQLiteDatabase = sQLiteDatabase.query("notes", c.b, string, null, null, null, null);
            try {
                if (!sQLiteDatabase.moveToFirst() || (l2 = sQLiteDatabase.getLong(0)) <= 0) break block2;
            }
            catch (Throwable var4_4) {
                sQLiteDatabase.close();
                throw var4_4;
            }
            sQLiteDatabase.close();
            return true;
        }
        sQLiteDatabase.close();
        return false;
    }

    private static void c(SQLiteDatabase sQLiteDatabase, long l2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("is_collapsed", Integer.valueOf(0));
        contentValues.put("is_under_collapsed", Integer.valueOf(0));
        sQLiteDatabase.update("notes", contentValues, "book_id = " + l2, null);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public int a(SQLiteDatabase sQLiteDatabase) {
        if (this.b(sQLiteDatabase, this.b)) {
            d.a(sQLiteDatabase, this.b);
            do {
                return 0;
                break;
            } while (true);
        }
        d.c(sQLiteDatabase, this.b);
        return 0;
    }
}

