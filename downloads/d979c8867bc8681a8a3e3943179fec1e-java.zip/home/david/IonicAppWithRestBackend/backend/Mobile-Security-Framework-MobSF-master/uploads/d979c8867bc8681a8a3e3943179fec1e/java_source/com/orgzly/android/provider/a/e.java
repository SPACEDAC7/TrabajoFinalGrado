/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.a;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.a.a;
import com.orgzly.android.provider.c;

public class e
implements a {
    private long a;
    private String b;

    public e(ContentValues contentValues) {
        this.a = contentValues.getAsLong("book_id");
        this.b = contentValues.getAsString("ids");
    }

    @Override
    public int a(SQLiteDatabase sQLiteDatabase) {
        long l2 = System.currentTimeMillis();
        ContentValues contentValues = new ContentValues();
        contentValues.put("is_cut", Long.valueOf(l2));
        int n2 = sQLiteDatabase.update("notes", contentValues, c.b(this.a, this.b), null);
        c.a(sQLiteDatabase, c.a(this.a, this.b));
        c.a(sQLiteDatabase, this.a);
        sQLiteDatabase.execSQL("DELETE FROM notes WHERE is_cut = " + l2);
        return n2;
    }
}

