/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.a;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.g;
import com.orgzly.android.provider.a.a;
import com.orgzly.android.provider.a.h;
import com.orgzly.android.provider.c;
import com.orgzly.android.ui.l;

public class f
implements a {
    private long a;
    private String b;

    public f(ContentValues contentValues) {
        this.a = contentValues.getAsLong("book_id");
        this.b = contentValues.getAsString("ids");
    }

    private int b(SQLiteDatabase sQLiteDatabase) {
        Cursor cursor;
        g g2;
        long l2;
        block5 : {
            cursor = sQLiteDatabase.query("notes", null, "_id IN (" + this.b + ")", null, null, null, null);
            try {
                if (cursor.moveToFirst()) {
                    g2 = com.orgzly.android.provider.c.f.a(cursor);
                    l2 = c.a(sQLiteDatabase, g2);
                    if (l2 <= 0) {
                        return 0;
                    }
                    break block5;
                }
                return 0;
            }
            finally {
                cursor.close();
            }
        }
        long l3 = System.currentTimeMillis();
        cursor = new ContentValues();
        cursor.put("is_cut", Long.valueOf(l3));
        sQLiteDatabase.update("notes", (ContentValues)cursor, c.c(this.a, g2.g(), g2.h()), null);
        cursor = new ContentValues();
        cursor.put("batch_id", Long.valueOf(l3));
        cursor.put("book_id", Long.valueOf(this.a));
        cursor.put("note_id", Long.valueOf(l2));
        cursor.put("spot", l.b.toString());
        new h((ContentValues)cursor).a(sQLiteDatabase);
        c.a(sQLiteDatabase, this.a);
        return 1;
    }

    @Override
    public int a(SQLiteDatabase sQLiteDatabase) {
        int n2 = this.b(sQLiteDatabase);
        c.a(sQLiteDatabase, this.a);
        return n2;
    }
}

