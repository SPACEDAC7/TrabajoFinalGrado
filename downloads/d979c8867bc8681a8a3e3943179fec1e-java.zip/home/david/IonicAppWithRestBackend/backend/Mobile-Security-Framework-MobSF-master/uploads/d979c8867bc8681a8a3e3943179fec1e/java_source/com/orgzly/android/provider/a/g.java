/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.a;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.a.a;
import com.orgzly.android.provider.a.h;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.c.f;
import com.orgzly.android.ui.l;

public class g
implements a {
    private static final String a = g.class.getName();
    private long b;
    private Long c;
    private int d;

    public g(ContentValues contentValues) {
        this.b = contentValues.getAsLong("book_id");
        this.c = contentValues.getAsLong("ids");
        this.d = contentValues.getAsInteger("direction");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int a(SQLiteDatabase sQLiteDatabase) {
        Cursor cursor;
        long l2;
        long l3;
        com.orgzly.android.g g2;
        Cursor cursor2;
        Object object;
        block10 : {
            g2 = f.a(sQLiteDatabase, this.c);
            l3 = 0;
            cursor = null;
            if (this.d == -1) {
                object = c.a(this.b) + " AND " + "parent_position" + " < " + g2.g();
                cursor = sQLiteDatabase.query("notes", new String[]{"_id", "is_visible", "level"}, (String)object, null, null, null, "parent_position DESC");
                try {
                    if (cursor.moveToFirst()) {
                        l2 = cursor.getLong(0);
                        if (cursor.getLong(2) == (long)g2.e()) {
                            object = l.a;
                            break block10;
                        }
                    }
                    object = null;
                    l2 = 0;
                }
                finally {
                    cursor.close();
                }
            }
            object = c.a(this.b) + " AND " + "is_visible" + " > " + g2.h();
            cursor2 = sQLiteDatabase.query("notes", new String[]{"_id", "is_visible", "level"}, (String)object, null, null, null, "is_visible");
            object = cursor;
            l2 = l3;
            if (!cursor2.moveToFirst()) break block10;
            long l4 = cursor2.getLong(0);
            object = cursor;
            l2 = l3;
            if (cursor2.getLong(2) != (long)g2.e()) break block10;
            object = l.c;
            l2 = l4;
        }
        if (l2 != 0) {
            l3 = System.currentTimeMillis();
            cursor = new ContentValues();
            cursor.put("is_cut", Long.valueOf(l3));
            sQLiteDatabase.update("notes", (ContentValues)cursor, c.c(this.b, g2.g(), g2.h()), null);
            cursor = new ContentValues();
            cursor.put("batch_id", Long.valueOf(l3));
            cursor.put("book_id", Long.valueOf(this.b));
            cursor.put("note_id", Long.valueOf(l2));
            cursor.put("spot", object.toString());
            new h((ContentValues)cursor).a(sQLiteDatabase);
            c.a(sQLiteDatabase, this.b);
        }
        return 0;
        finally {
            cursor2.close();
        }
    }
}

