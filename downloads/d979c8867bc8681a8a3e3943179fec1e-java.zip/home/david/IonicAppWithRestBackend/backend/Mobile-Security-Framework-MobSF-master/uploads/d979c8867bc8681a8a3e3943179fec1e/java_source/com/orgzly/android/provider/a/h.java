/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.a;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.g;
import com.orgzly.android.provider.a.a;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.c.f;
import com.orgzly.android.provider.d;
import com.orgzly.android.ui.l;

public class h
implements a {
    private static final String a = h.class.getName();
    private l b;
    private long c;
    private long d;
    private long e;

    public h(ContentValues contentValues) {
        this.b = l.valueOf(contentValues.getAsString("spot"));
        this.c = contentValues.getAsLong("book_id");
        this.d = contentValues.getAsLong("note_id");
        this.e = contentValues.getAsLong("batch_id");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private g a(SQLiteDatabase object, g g2) {
        g2 = object.query("notes", f.b, c.b(g2.f(), g2.g(), g2.h()), null, null, null, "level, is_visible DESC");
        try {
            object = g2.moveToFirst() ? f.a((Cursor)g2) : null;
            return object;
        }
        finally {
            g2.close();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public int a(SQLiteDatabase sQLiteDatabase) {
        Object object;
        long l2;
        long l3;
        long l4;
        long l5;
        Object object2 = "is_cut = " + this.e;
        object2 = sQLiteDatabase.query("notes", new String[]{"min(is_visible)", "max(parent_position)", "min(level)"}, (String)object2, null, null, null, null);
        if (!object2.moveToFirst()) return 0;
        long l6 = object2.getLong(0);
        long l7 = object2.getLong(1);
        long l8 = object2.getLong(2);
        object2 = f.a(sQLiteDatabase, this.d);
        long l9 = object2.a() != 0 ? object2.a() : 0;
        switch (.a[this.b.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unsupported placement for paste: " + (Object)((Object)this.b));
            }
            finally {
                object2.close();
            }
            case 1: {
                l4 = object2.g();
                l5 = object2.e();
                l2 = object2.b();
                l3 = l9;
                l9 = l2;
                break;
            }
            case 2: {
                object = this.a(sQLiteDatabase, (g)object2);
                if (object != null) {
                    l4 = object.h() + 1;
                    l5 = object.e();
                } else {
                    l4 = 1 + object2.g();
                    l5 = object2.e() + 1;
                }
                if (object2.c()) {
                    l9 = this.d;
                }
                l2 = this.d;
                l3 = l9;
                l9 = l2;
                break;
            }
            case 3: {
                l4 = object2.h();
                l5 = object2.e();
                l2 = object2.b();
                ++l4;
                l3 = l9;
                l9 = l2;
            }
        }
        int n2 = (int)(l7 - l6 + 1);
        l2 = l4 - l6;
        object = c.a(object2.f());
        d.a(sQLiteDatabase, "notes", (String)object + " AND " + "is_visible" + " >= " + l4, n2, "is_visible");
        d.a(sQLiteDatabase, "notes", (String)object + " AND " + "parent_position" + " >= " + l4, n2, "parent_position");
        sQLiteDatabase.execSQL("UPDATE notes SET is_under_collapsed = 0 WHERE is_cut = " + this.e + " AND " + "is_under_collapsed" + " NOT IN (SELECT " + "_id" + " FROM " + "notes" + " WHERE " + "is_cut" + " = " + this.e + ")");
        if (l3 != 0) {
            object = new ContentValues();
            object.put("is_under_collapsed", Long.valueOf(l3));
            sQLiteDatabase.update("notes", (ContentValues)object, "is_cut = " + this.e + " AND " + "is_under_collapsed" + " = 0", null);
        }
        object = new ContentValues();
        object.put("parent_id", Long.valueOf(l9));
        sQLiteDatabase.update("notes", (ContentValues)object, "is_cut = " + this.e + " AND " + "is_visible" + " = " + l6, null);
        object = "is_visible = is_visible + " + l2 + ", " + "parent_position" + " = " + "parent_position" + " + " + l2 + ", " + "level" + " = " + "level" + " + " + (l5 - l8) + ", " + "is_cut" + "= 0, " + "book_id" + "= " + object2.f();
        sQLiteDatabase.execSQL("UPDATE notes SET " + (String)object + " WHERE " + "is_cut" + " = " + this.e);
        c.a(sQLiteDatabase, c.a(object2.f(), new StringBuilder().append("").append(this.d).toString()) + " OR (" + "_id" + " = " + this.d + ")");
        sQLiteDatabase.execSQL("DELETE FROM notes WHERE is_cut != 0");
        c.a(sQLiteDatabase, object2.f());
        return 0;
    }

}

