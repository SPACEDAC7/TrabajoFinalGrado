/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.a;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.g;
import com.orgzly.android.provider.a.a;
import com.orgzly.android.provider.a.h;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.c.f;
import com.orgzly.android.ui.l;

public class i
implements a {
    private long a;
    private String b;

    public i(ContentValues contentValues) {
        this.a = contentValues.getAsLong("book_id");
        this.b = contentValues.getAsString("ids");
    }

    private int b(SQLiteDatabase sQLiteDatabase) {
        g g2;
        Cursor cursor;
        block5 : {
            cursor = sQLiteDatabase.query("notes", null, "_id IN (" + this.b + ")", null, null, null, null);
            try {
                if (cursor.moveToFirst()) {
                    g2 = f.a(cursor);
                    if (g2.e() <= 1 || g2.b() <= 0) {
                        return 0;
                    }
                    break block5;
                }
                return 0;
            }
            finally {
                cursor.close();
            }
        }
        long l2 = System.currentTimeMillis();
        cursor = new ContentValues();
        cursor.put("is_cut", Long.valueOf(l2));
        sQLiteDatabase.update("notes", (ContentValues)cursor, c.c(this.a, g2.g(), g2.h()), null);
        cursor = new ContentValues();
        cursor.put("batch_id", Long.valueOf(l2));
        cursor.put("book_id", Long.valueOf(this.a));
        cursor.put("note_id", Long.valueOf(g2.b()));
        cursor.put("spot", l.c.toString());
        new h((ContentValues)cursor).a(sQLiteDatabase);
        c.a(sQLiteDatabase, this.a);
        return 1;
    }

    @Override
    public int a(SQLiteDatabase sQLiteDatabase) {
        int n2 = this.b(sQLiteDatabase);
        c.a(sQLiteDatabase, this.a);
        return n2;
    }
}

