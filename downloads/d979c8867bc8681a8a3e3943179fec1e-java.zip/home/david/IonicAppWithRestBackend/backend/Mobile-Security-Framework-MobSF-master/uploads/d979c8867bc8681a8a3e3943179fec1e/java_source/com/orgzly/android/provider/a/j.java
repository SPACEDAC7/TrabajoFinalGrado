/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.a;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.a.a;
import com.orgzly.android.provider.a.d;
import com.orgzly.android.provider.c;

public class j
implements a {
    private static final String a = j.class.getName();
    private long b;
    private ContentValues c;

    public j(long l2, ContentValues contentValues) {
        this.b = l2;
        this.c = contentValues;
    }

    @Override
    public int a(SQLiteDatabase sQLiteDatabase) {
        String string;
        long l2;
        d.a(sQLiteDatabase, this.b);
        if (this.c.containsKey("id") && (string = c.a(sQLiteDatabase, this.b, l2 = this.c.getAsLong("id").longValue())) != null) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("is_collapsed", Integer.valueOf(0));
            int n2 = sQLiteDatabase.update("notes", contentValues, "_id IN (" + string + ")", null);
            contentValues = new ContentValues();
            contentValues.put("is_under_collapsed", Integer.valueOf(0));
            sQLiteDatabase.update("notes", contentValues, "is_under_collapsed IN (" + string + ")", null);
            return n2;
        }
        return 0;
    }
}

