/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  android.util.Log
 */
package com.orgzly.android.provider.a;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.orgzly.android.provider.a.a;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.d;

public class k
implements a {
    private static final String a = k.class.getName();
    private long b;

    public k(long l2) {
        this.b = l2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public int a(SQLiteDatabase var1_1) {
        block5 : {
            var10_3 = "_id = " + this.b;
            var10_3 = var1_1.query("notes", new String[]{"is_collapsed", "is_visible", "parent_position", "book_id"}, var10_3, null, null, null, null);
            if (!var10_3.moveToFirst()) break block5;
            var2_4 = var10_3.getInt(0) == 1;
            var4_5 = var10_3.getLong(1);
            var6_6 = var10_3.getLong(2);
            var8_7 = var10_3.getLong(3);
            var10_3.close();
            var10_3 = new ContentValues();
            var3_8 = var2_4 != false ? 0 : 1;
            var10_3.put("is_collapsed", Integer.valueOf(var3_8));
            var1_1.update("notes", (ContentValues)var10_3, "_id = " + this.b, null);
            if (var2_4) {
                var11_9 = new ContentValues();
                var11_9.put("is_under_collapsed", Integer.valueOf(0));
                var10_3 = c.b(var8_7, var4_5, var6_6) + " AND " + "is_under_collapsed" + " = " + this.b;
                return var1_1.update("notes", var11_9, var10_3, null);
            }
            ** GOTO lbl29
        }
        try {
            Log.e((String)k.a, (String)("Failed getting note " + this.b));
            return 0;
        }
        finally {
            var10_3.close();
        }
lbl29: // 1 sources:
        var11_9 = new ContentValues();
        var11_9.put("is_under_collapsed", Long.valueOf(this.b));
        var10_3 = c.b(var8_7, var4_5, var6_6) + " AND " + d.a("is_under_collapsed");
        return var1_1.update("notes", var11_9, var10_3, null);
    }
}

