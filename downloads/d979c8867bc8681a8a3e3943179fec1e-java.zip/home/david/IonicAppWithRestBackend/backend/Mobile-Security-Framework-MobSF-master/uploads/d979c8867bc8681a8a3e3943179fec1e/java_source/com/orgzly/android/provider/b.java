/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  android.text.TextUtils
 */
package com.orgzly.android.provider;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import com.orgzly.android.b.e;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.c.f;
import com.orgzly.android.provider.c.g;
import com.orgzly.android.provider.c.j;
import com.orgzly.android.provider.c.k;
import com.orgzly.android.provider.c.l;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class b {
    private static final String a = b.class.getName();

    private static int a(SQLiteDatabase sQLiteDatabase, a a2) {
        ContentValues contentValues = new ContentValues();
        f.a(contentValues, a2.b);
        return sQLiteDatabase.update("notes", contentValues, "_id = " + a2.a, null);
    }

    public static List<j> a(String object, StringBuilder stringBuilder) {
        ArrayList<j> arrayList = new ArrayList<j>();
        String[] arrstring = Pattern.compile("^\\s*:PROPERTIES:(.*?):END: *\n*(.*)", 32);
        Pattern pattern = Pattern.compile("^:([^:\\s]+):\\s+(.*)\\s*$");
        if ((object = arrstring.matcher((CharSequence)object)).find()) {
            arrstring = object.group(1).split("\n");
            int n2 = arrstring.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                Matcher matcher = pattern.matcher(arrstring[i2].trim());
                if (!matcher.find()) continue;
                arrayList.add(new j(new k(matcher.group(1)), new l(matcher.group(2))));
            }
            stringBuilder.append(object.group(2));
        }
        return arrayList;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void a(SQLiteDatabase sQLiteDatabase) {
        Cursor cursor = sQLiteDatabase.query("notes", new String[]{"_id", "content"}, null, null, null, null, null);
        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                StringBuilder stringBuilder;
                long l2 = cursor.getLong(0);
                Object object = cursor.getString(1);
                if (!TextUtils.isEmpty((CharSequence)object) && (object = b.a((String)object, stringBuilder = new StringBuilder())).size() > 0) {
                    object = object.iterator();
                    while (object.hasNext()) {
                        new g(l2, 0, (j)object.next()).a(sQLiteDatabase);
                    }
                    object = new ContentValues();
                    object.put("content", stringBuilder.toString());
                    object.put("content_line_count", Integer.valueOf(e.a(stringBuilder.toString())));
                    sQLiteDatabase.update("notes", (ContentValues)object, "_id = " + l2, null);
                }
                cursor.moveToNext();
            }
            return;
        }
        finally {
            cursor.close();
        }
    }

    public static void a(SQLiteDatabase sQLiteDatabase, int n2, Runnable arrstring) {
        int n3 = 0;
        String[] arrstring2 = arrstring;
        String[] arrstring3 = arrstring;
        switch (n2) {
            default: {
                return;
            }
            case 130: {
                sQLiteDatabase.execSQL("ALTER TABLE books ADD COLUMN title");
            }
            case 131: {
                sQLiteDatabase.execSQL("ALTER TABLE books ADD COLUMN is_indented INTEGER DEFAULT 0");
                sQLiteDatabase.execSQL("ALTER TABLE books ADD COLUMN used_encoding TEXT");
                sQLiteDatabase.execSQL("ALTER TABLE books ADD COLUMN detected_encoding TEXT");
                sQLiteDatabase.execSQL("ALTER TABLE books ADD COLUMN selected_encoding TEXT");
            }
            case 132: 
            case 133: {
                arrstring2 = arrstring;
                if (arrstring != null) {
                    arrstring.run();
                    arrstring2 = null;
                }
                sQLiteDatabase.execSQL("ALTER TABLE notes ADD COLUMN parent_id");
                sQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS i_notes_is_visible ON notes(is_visible)");
                sQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS i_notes_parent_position ON notes(parent_position)");
                sQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS i_notes_is_collapsed ON notes(is_collapsed)");
                sQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS i_notes_is_under_collapsed ON notes(is_under_collapsed)");
                sQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS i_notes_parent_id ON notes(parent_id)");
                sQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS i_notes_has_children ON notes(has_children)");
                b.b(sQLiteDatabase);
            }
            case 134: {
                b.c(sQLiteDatabase);
                arrstring3 = arrstring2;
            }
            case 135: {
                if (arrstring3 != null) {
                    arrstring3.run();
                }
                arrstring = g.a;
                int n4 = arrstring.length;
                for (n2 = 0; n2 < n4; ++n2) {
                    sQLiteDatabase.execSQL(arrstring[n2]);
                }
                arrstring = k.a;
                n4 = arrstring.length;
                for (n2 = 0; n2 < n4; ++n2) {
                    sQLiteDatabase.execSQL(arrstring[n2]);
                }
                arrstring = l.a;
                n4 = arrstring.length;
                for (n2 = 0; n2 < n4; ++n2) {
                    sQLiteDatabase.execSQL(arrstring[n2]);
                }
                arrstring = j.a;
                n4 = arrstring.length;
                for (n2 = n3; n2 < n4; ++n2) {
                    sQLiteDatabase.execSQL(arrstring[n2]);
                }
                b.a(sQLiteDatabase);
            }
            case 136: 
        }
        b.d(sQLiteDatabase);
    }

    private static void a(SQLiteDatabase sQLiteDatabase, long l2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("level", Integer.valueOf(0));
        contentValues.put("book_id", Long.valueOf(l2));
        contentValues.put("position", Integer.valueOf(0));
        sQLiteDatabase.insertOrThrow("notes", null, contentValues);
        contentValues = sQLiteDatabase.query("notes", null, "book_id = " + l2, null, null, null, "position");
        try {
            b.a(sQLiteDatabase, (Cursor)contentValues);
            return;
        }
        finally {
            contentValues.close();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(SQLiteDatabase sQLiteDatabase, Cursor object) {
        long l2;
        Stack<a> stack = new Stack<a>();
        object.moveToFirst();
        int n2 = -1;
        long l3 = 0;
        do {
            l2 = l3++;
            if (object.isAfterLast()) break;
            a a2 = new a();
            a2.a = object.getLong(object.getColumnIndex("_id"));
            a2.b = f.a((Cursor)object);
            if (n2 < a2.b.e()) {
                a2.b.d(l3);
                stack.push(a2);
            } else {
                a a3;
                l2 = l3++;
                if (n2 == a2.b.e()) {
                    a3 = (a)stack.pop();
                    a3.b.e(l3);
                    b.a(a3.b, 1);
                    b.a(sQLiteDatabase, a3);
                    a2.b.d(++l3);
                    stack.push(a2);
                } else {
                    while (!stack.empty()) {
                        a3 = (a)stack.peek();
                        if (a3.b.e() < a2.b.e()) break;
                        stack.pop();
                        a3.b.e(++l2);
                        b.a(a3.b, 1);
                        b.a(sQLiteDatabase, a3);
                    }
                    l3 = l2 + 1;
                    a2.b.d(l3);
                    stack.push(a2);
                }
            }
            n2 = a2.b.e();
            object.moveToNext();
        } while (true);
        while (!stack.empty()) {
            object = (a)stack.pop();
            object.b.e(++l2);
            b.a(object.b, 1);
            b.a(sQLiteDatabase, (a)object);
        }
        return;
    }

    private static void a(com.orgzly.android.g g2, int n2) {
        g2.a((int)(g2.h() - g2.g() - (long)n2) / (n2 * 2));
    }

    private static void b(SQLiteDatabase sQLiteDatabase) {
        Cursor cursor = sQLiteDatabase.query("books", new String[]{"_id"}, null, null, null, null, null);
        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                long l2 = cursor.getLong(0);
                b.a(sQLiteDatabase, l2);
                c.b(sQLiteDatabase, l2);
                cursor.moveToNext();
            }
        }
        finally {
            cursor.close();
        }
    }

    /*
     * Exception decompiling
     */
    private static void c(SQLiteDatabase var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 4[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void d(SQLiteDatabase var0) {
        var3_3 = var0.query("rook_urls", new String[]{"_id", "rook_url"}, null, null, null, null, null);
        var3_3.moveToFirst();
        {
            catch (Throwable var0_1) {
                var3_3.close();
                throw var0_1;
            }
        }
        while (!var3_3.isAfterLast()) {
            block9 : {
                var1_4 = var3_3.getLong(0);
                var5_6 = var3_3.getString(1);
                if (!var5_6.equals(var4_5 = e.e(var5_6))) {
                    var5_6 = var0.query("rook_urls", new String[]{"_id"}, "rook_url = ?", new String[]{var4_5}, null, null, null);
                    if (var5_6.moveToFirst()) break block9;
                    var6_7 = new ContentValues();
                    var6_7.put("rook_url", var4_5);
                    var0.update("rook_urls", var6_7, "_id = " + var1_4, null);
                }
            }
            var3_3.moveToNext();
            continue;
            finally {
                ** try [egrp 2[TRYBLOCK] [3 : 170->187)] { 
lbl23: // 1 sources:
                var5_6.close();
            }
        }
        var3_3.close();
    }

    private static class a {
        long a;
        com.orgzly.android.g b;

        private a() {
        }
    }

}

