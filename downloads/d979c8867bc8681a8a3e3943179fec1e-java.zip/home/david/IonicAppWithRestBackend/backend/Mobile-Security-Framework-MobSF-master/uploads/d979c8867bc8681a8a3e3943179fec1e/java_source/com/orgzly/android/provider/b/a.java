/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.ContentValues
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.text.TextUtils
 */
package com.orgzly.android.provider.b;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.c.i;
import android.support.v4.c.l;
import android.text.TextUtils;
import com.orgzly.a.b;
import com.orgzly.android.a.j;
import com.orgzly.android.b;
import com.orgzly.android.b.d;
import com.orgzly.android.c;
import com.orgzly.android.provider.e;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class a {
    private static final String a = "is_dummy,MAX(COALESCE(mtime, 0), COALESCE(" + e.b.b.f + ", 0)) DESC, " + "name";

    public static int a(Context context, long l2) {
        return context.getContentResolver().delete(e.a.a.a(l2), null, null);
    }

    public static int a(Context context, long l2, long l3) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("mtime", Long.valueOf(l3));
        return context.getContentResolver().update(ContentUris.withAppendedId((Uri)e.b.a.a(), (long)l2), contentValues, null, null);
    }

    public static int a(Context context, long l2, Long l3, int n2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("book_id", Long.valueOf(l2));
        contentValues.put("ids", l3);
        contentValues.put("direction", Integer.valueOf(n2));
        return context.getContentResolver().update(e.l.a.a(), contentValues, null, null);
    }

    public static int a(Context context, long l2, String string) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", string);
        return context.getContentResolver().update(ContentUris.withAppendedId((Uri)e.b.a.a(), (long)l2), contentValues, null, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static int a(Context context, long l2, String string, com.orgzly.android.b b2) {
        ContentValues contentValues = new ContentValues();
        if (string != null) {
            contentValues.put("sync_status", string);
        } else {
            contentValues.putNull("sync_status");
        }
        contentValues.put("last_action", b2.b());
        contentValues.put("last_action_timestamp", Long.valueOf(b2.c()));
        contentValues.put("last_action_type", b2.a().toString());
        return context.getContentResolver().update(ContentUris.withAppendedId((Uri)e.b.a.a(), (long)l2), contentValues, null, null);
    }

    public static int a(Context context, long l2, String string, String string2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("repo_url", string);
        contentValues.put("rook_url", string2);
        return context.getContentResolver().update(e.a.a.a(l2), contentValues, null, null);
    }

    public static int a(Context context, long l2, Set<Long> set) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("book_id", Long.valueOf(l2));
        contentValues.put("ids", TextUtils.join((CharSequence)",", set));
        return context.getContentResolver().update(e.q.a.a(), contentValues, null, null);
    }

    public static Uri a(Context context, String string, c.a a2, File file, j j2, String string2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("book_name", string);
        contentValues.put("format", a2.toString());
        contentValues.put("file_path", file.getAbsolutePath());
        if (j2 != null) {
            contentValues.put("rook_repo_url", j2.a().toString());
            contentValues.put("rook_url", j2.b().toString());
            contentValues.put("rook_revision", j2.c());
            contentValues.put("rook_mtime", Long.valueOf(j2.d()));
        }
        if (string2 != null) {
            contentValues.put("selected_encoding", string2);
        }
        try {
            context = context.getContentResolver().insert(e.j.a.a(), contentValues);
            return context;
        }
        catch (IllegalArgumentException var0_1) {
            throw d.a(var0_1, "Failed loading book " + string);
        }
    }

    public static com.orgzly.android.a a(Context context, com.orgzly.android.a a2) {
        if (a.b(context, a2.c())) {
            throw new IOException("Can't insert notebook with the same name: " + a2.c());
        }
        ContentValues contentValues = new ContentValues();
        a.a(contentValues, a2);
        try {
            context = context.getContentResolver().insert(e.b.a.a(), contentValues);
            a2.a(ContentUris.parseId((Uri)context));
            return a2;
        }
        catch (Exception var0_1) {
            throw d.a(var0_1, "Failed inserting book " + a2.c());
        }
    }

    public static com.orgzly.android.a a(Context context, String object) {
        context = context.getContentResolver().query(e.b.a.a(), null, "name=?", new String[]{object}, null);
        try {
            if (context.moveToFirst()) {
                object = a.a((Cursor)context);
                return object;
            }
            return null;
        }
        finally {
            context.close();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static com.orgzly.android.a a(Cursor cursor) {
        boolean bl2 = true;
        Object object = cursor.getString(cursor.getColumnIndexOrThrow("name"));
        Object object2 = cursor.getString(cursor.getColumnIndexOrThrow("preface"));
        long l2 = cursor.getLong(cursor.getColumnIndexOrThrow("mtime"));
        boolean bl3 = cursor.getInt(cursor.getColumnIndexOrThrow("is_dummy")) == 1;
        object = new com.orgzly.android.a((String)object, (String)object2, l2, bl3);
        object.k().a(cursor.getString(cursor.getColumnIndexOrThrow("title")));
        object2 = object.k();
        bl3 = cursor.getInt(cursor.getColumnIndexOrThrow("is_indented")) == 1 ? bl2 : false;
        object2.a(bl3);
        object.a(cursor.getLong(cursor.getColumnIndexOrThrow("_id")));
        object.b(cursor.getString(cursor.getColumnIndexOrThrow("sync_status")));
        object.c(cursor.getString(cursor.getColumnIndexOrThrow("detected_encoding")));
        object.d(cursor.getString(cursor.getColumnIndexOrThrow("selected_encoding")));
        object.e(cursor.getString(cursor.getColumnIndexOrThrow("used_encoding")));
        if (!cursor.isNull(cursor.getColumnIndexOrThrow(e.b.b.b))) {
            object.a(new com.orgzly.android.a.i(Uri.parse((String)cursor.getString(cursor.getColumnIndexOrThrow(e.b.b.a))), Uri.parse((String)cursor.getString(cursor.getColumnIndexOrThrow(e.b.b.b)))));
        }
        if (!cursor.isNull(cursor.getColumnIndexOrThrow(e.b.b.d))) {
            object2 = Uri.parse((String)cursor.getString(cursor.getColumnIndexOrThrow(e.b.b.d)));
            object.a(new j(Uri.parse((String)cursor.getString(cursor.getColumnIndexOrThrow(e.b.b.c))), (Uri)object2, cursor.getString(cursor.getColumnIndexOrThrow(e.b.b.e)), cursor.getLong(cursor.getColumnIndexOrThrow(e.b.b.f))));
        }
        if (!TextUtils.isEmpty((CharSequence)(object2 = cursor.getString(cursor.getColumnIndexOrThrow("last_action"))))) {
            object.a(new com.orgzly.android.b(b.a.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("last_action_type"))), (String)object2, cursor.getLong(cursor.getColumnIndexOrThrow("last_action_timestamp"))));
        }
        return object;
    }

    public static List<com.orgzly.android.a> a(Context context) {
        ArrayList<com.orgzly.android.a> arrayList;
        arrayList = new ArrayList<com.orgzly.android.a>();
        context = context.getContentResolver().query(e.b.a.a(), null, null, null, a.c(context));
        try {
            context.moveToFirst();
            while (!context.isAfterLast()) {
                arrayList.add(a.a((Cursor)context));
                context.moveToNext();
            }
        }
        finally {
            context.close();
        }
        return arrayList;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(ContentValues contentValues, b b2) {
        if (b2.a() != null) {
            contentValues.put("title", b2.a());
        } else {
            contentValues.putNull("title");
        }
        int n2 = b2.b() ? 1 : 0;
        contentValues.put("is_indented", Integer.valueOf(n2));
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(ContentValues contentValues, com.orgzly.android.a a2) {
        contentValues.put("name", a2.c());
        contentValues.put("preface", a2.b());
        contentValues.put("mtime", Long.valueOf(a2.e()));
        int n2 = a2.h() ? 1 : 0;
        contentValues.put("is_dummy", Integer.valueOf(n2));
        if (a2.i() != null) {
            contentValues.put("sync_status", a2.i().toString());
        } else {
            contentValues.putNull("sync_status");
        }
        a.a(contentValues, a2.k());
    }

    public static void a(Context context, long l2, j j2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("repo_url", j2.a().toString());
        contentValues.put("rook_url", j2.b().toString());
        contentValues.put("rook_revision", j2.c());
        contentValues.put("rook_mtime", Long.valueOf(j2.d()));
        context.getContentResolver().insert(e.c.a.a(l2), contentValues);
    }

    public static int b(Context context, long l2, Set<Long> set) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("book_id", Long.valueOf(l2));
        contentValues.put("ids", TextUtils.join((CharSequence)",", set));
        return context.getContentResolver().update(e.h.a.a(), contentValues, null, null);
    }

    public static int b(Context context, com.orgzly.android.a a2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("preface", a2.b());
        contentValues.put("title", a2.k().a());
        contentValues.put("mtime", Long.valueOf(System.currentTimeMillis()));
        return context.getContentResolver().update(ContentUris.withAppendedId((Uri)e.b.a.a(), (long)a2.a()), contentValues, null, null);
    }

    public static l<Cursor> b(Context context) {
        return new i(context, e.b.a.a(), null, null, null, a.c(context));
    }

    public static void b(Context context, long l2) {
        context.getContentResolver().delete(ContentUris.withAppendedId((Uri)e.b.a.a(), (long)l2), null, null);
    }

    public static void b(Context context, long l2, long l3) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", Long.valueOf(l3));
        context.getContentResolver().update(e.b.a.d(l2), contentValues, null, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean b(Context context, String string) {
        context = context.getContentResolver().query(e.b.a.a(), null, "name = ?", new String[]{string}, null);
        try {
            int n2 = context.getCount();
            boolean bl2 = n2 > 0;
            return bl2;
        }
        finally {
            context.close();
        }
    }

    public static com.orgzly.android.a c(Context context, long l2) {
        context = context.getContentResolver().query(e.b.a.a(l2), null, null, null, null);
        try {
            if (context.moveToFirst()) {
                com.orgzly.android.a a2 = a.a((Cursor)context);
                return a2;
            }
            return null;
        }
        finally {
            context.close();
        }
    }

    private static String c(Context context) {
        String string = "is_dummy,LOWER(COALESCE(title, name))";
        if (context.getString(2131231117).equals(com.orgzly.android.prefs.a.f(context))) {
            string = a;
        }
        return string;
    }

    public static void c(Context context, com.orgzly.android.a a2) {
        context.getContentResolver().update(e.b.a.c(a2.a()), null, null, null);
    }
}

