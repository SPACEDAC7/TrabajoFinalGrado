/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentProviderOperation
 *  android.content.ContentProviderOperation$Builder
 *  android.content.ContentProviderResult
 *  android.content.ContentResolver
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.OperationApplicationException
 *  android.net.Uri
 *  android.os.RemoteException
 */
package com.orgzly.android.provider.b;

import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.OperationApplicationException;
import android.net.Uri;
import android.os.RemoteException;
import com.orgzly.android.a.j;
import com.orgzly.android.provider.e;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class b {
    private static void a(ContentValues contentValues, j j2) {
        contentValues.put("repo_url", j2.a().toString());
        contentValues.put("rook_url", j2.b().toString());
        contentValues.put("rook_revision", j2.c());
        contentValues.put("rook_mtime", Long.valueOf(j2.d()));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void a(Context var0, List<j> var1_4) {
        var2_5 = new ArrayList<ContentProviderOperation>();
        var2_5.add(ContentProviderOperation.newDelete((Uri)e.d.a.a()).build());
        var1_4 = var1_4.iterator();
        while (var1_4.hasNext()) {
            var3_6 = (j)var1_4.next();
            var4_7 = new ContentValues();
            b.a(var4_7, var3_6);
            var2_5.add(ContentProviderOperation.newInsert((Uri)e.d.a.a()).withValues(var4_7).build());
        }
        try {
            var0.getContentResolver().applyBatch("com.orgzly", var2_5);
            return;
        }
        catch (RemoteException var0_1) {}
        ** GOTO lbl-1000
        catch (OperationApplicationException var0_3) {}
lbl-1000: // 2 sources:
        {
            var0_2.printStackTrace();
            return;
        }
    }
}

