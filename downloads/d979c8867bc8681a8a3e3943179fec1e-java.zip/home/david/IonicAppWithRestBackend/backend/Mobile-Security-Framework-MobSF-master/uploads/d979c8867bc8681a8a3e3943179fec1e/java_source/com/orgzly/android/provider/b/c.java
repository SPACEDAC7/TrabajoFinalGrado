/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.ContentValues
 *  android.content.Context
 *  android.net.Uri
 */
package com.orgzly.android.provider.b;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import com.orgzly.android.provider.e;

public class c {
    public static void a(Context context) {
        context.getContentResolver().update(e.f.a.a(), null, null, null);
    }
}

