/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.ContentValues
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 */
package com.orgzly.android.provider.b;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.c.i;
import android.support.v4.j.f;
import com.orgzly.android.provider.e;

public class d {
    public static String a = "position, _id";

    public static i a(Context context) {
        return new i(context, e.i.a.a(), null, null, null, a);
    }

    public static f<com.orgzly.android.d> a(Context context, String string) {
        f<com.orgzly.android.d> f2;
        f2 = new f<com.orgzly.android.d>();
        if ((context = context.getContentResolver().query(e.i.a.a(), new String[]{"_id", "name", "search"}, "name LIKE ?", new String[]{string}, null)) != null) {
            try {
                context.moveToFirst();
                while (!context.isAfterLast()) {
                    f2.b(context.getLong(0), new com.orgzly.android.d(context.getString(1), context.getString(2)));
                    context.moveToNext();
                }
            }
            finally {
                context.close();
            }
        }
        return f2;
    }

    public static com.orgzly.android.d a(Context context, long l2) {
        context = context.getContentResolver().query(ContentUris.withAppendedId((Uri)e.i.a.a(), (long)l2), new String[]{"name", "search"}, null, null, null);
        try {
            if (context.moveToFirst()) {
                com.orgzly.android.d d2 = new com.orgzly.android.d(context.getString(0), context.getString(1));
                return d2;
            }
            return null;
        }
        finally {
            context.close();
        }
    }

    public static void a(Context context, long l2, com.orgzly.android.d d2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", d2.a());
        contentValues.put("search", d2.b());
        context.getContentResolver().update(ContentUris.withAppendedId((Uri)e.i.a.a(), (long)l2), contentValues, null, null);
    }

    public static void a(Context context, com.orgzly.android.d d2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", d2.a());
        contentValues.put("search", d2.b());
        context.getContentResolver().insert(e.i.a.a(), contentValues);
    }

    public static void b(Context context, long l2) {
        context.getContentResolver().delete(ContentUris.withAppendedId((Uri)e.i.a.a(), (long)l2), null, null);
    }

    public static void c(Context context, long l2) {
        context.getContentResolver().update(e.i.a.a(l2), null, null, null);
    }

    public static void d(Context context, long l2) {
        context.getContentResolver().update(e.i.a.b(l2), null, null, null);
    }
}

