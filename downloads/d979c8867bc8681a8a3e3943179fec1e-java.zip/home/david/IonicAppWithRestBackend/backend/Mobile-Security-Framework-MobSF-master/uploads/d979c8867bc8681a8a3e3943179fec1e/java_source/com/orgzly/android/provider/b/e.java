/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.ContentValues
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 */
package com.orgzly.android.provider.b;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import com.orgzly.android.a.j;
import com.orgzly.android.provider.e;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class e {
    public static j a(Context context, Uri uri, Uri uri2) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("url", uri2.toString());
        contentValues.put("mtime", Long.valueOf(System.currentTimeMillis()));
        contentValues.put("revision", "MockedRenamedRevision-" + System.currentTimeMillis());
        if (context.getContentResolver().update(e.k.a.a(), contentValues, "url = ?", new String[]{uri.toString()}) != 1) {
            throw new IOException("Failed moving notebook from " + com.orgzly.android.b.j.b(uri) + " to " + com.orgzly.android.b.j.b(uri2));
        }
        return e.b(context, uri2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static j a(Context context, Uri object, Uri uri, File file) {
        context = context.getContentResolver().query(e.k.a.a(), null, "url=?", new String[]{uri.toString()}, null);
        try {
            if (!context.moveToFirst()) {
                throw new IOException("Book " + (Object)uri + " not found in repo");
            }
            if (context.getCount() != 1) {
                throw new IOException("Found " + context.getCount() + " books matching name " + (Object)uri);
            }
            String string = context.getString(context.getColumnIndex("content"));
            String string2 = context.getString(context.getColumnIndex("revision"));
            long l2 = context.getLong(context.getColumnIndex("mtime"));
            com.orgzly.android.b.e.a(string, file);
            object = new j((Uri)object, uri, string2, l2);
            return object;
        }
        finally {
            context.close();
        }
    }

    public static j a(Context context, j j2, String string) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("repo_url", j2.a().toString());
        contentValues.put("url", j2.b().toString());
        contentValues.put("content", string);
        contentValues.put("revision", j2.c());
        contentValues.put("mtime", Long.valueOf(j2.d()));
        contentValues.put("created_at", Long.valueOf(System.currentTimeMillis()));
        if (context.getContentResolver().insert(e.k.a.a(), contentValues) == null) {
            throw new IOException("Inserting repo book to db failed");
        }
        return j2;
    }

    public static j a(Cursor cursor) {
        return new j(Uri.parse((String)cursor.getString(cursor.getColumnIndex("repo_url"))), Uri.parse((String)cursor.getString(cursor.getColumnIndex("url"))), cursor.getString(cursor.getColumnIndex("revision")), cursor.getLong(cursor.getColumnIndex("mtime")));
    }

    public static List<j> a(Context context, Uri uri) {
        ArrayList<j> arrayList;
        context = context.getContentResolver().query(e.k.a.a(), null, "repo_url=?", new String[]{uri.toString()}, null);
        arrayList = new ArrayList<j>();
        try {
            context.moveToFirst();
            while (!context.isAfterLast()) {
                arrayList.add(new j(uri, Uri.parse((String)context.getString(context.getColumnIndex("url"))), context.getString(context.getColumnIndex("revision")), context.getLong(context.getColumnIndex("mtime"))));
                context.moveToNext();
            }
        }
        finally {
            context.close();
        }
        return arrayList;
    }

    private static j b(Context context, Uri object) {
        context = context.getContentResolver().query(e.k.a.a(), null, "url = ?", new String[]{object.toString()}, null);
        try {
            if (context.moveToFirst()) {
                object = e.a((Cursor)context);
                return object;
            }
            return null;
        }
        finally {
            context.close();
        }
    }
}

