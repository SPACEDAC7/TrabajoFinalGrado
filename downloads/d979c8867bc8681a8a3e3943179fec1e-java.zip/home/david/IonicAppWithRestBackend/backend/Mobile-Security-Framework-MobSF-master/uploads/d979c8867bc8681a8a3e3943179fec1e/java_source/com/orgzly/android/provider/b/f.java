/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentProviderOperation
 *  android.content.ContentProviderOperation$Builder
 *  android.content.ContentProviderResult
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.OperationApplicationException
 *  android.content.res.Resources
 *  android.database.Cursor
 *  android.net.Uri
 *  android.net.Uri$Builder
 *  android.os.RemoteException
 *  android.preference.PreferenceManager
 *  android.text.TextUtils
 */
package com.orgzly.android.provider.b;

import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.OperationApplicationException;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.support.v4.c.i;
import android.text.TextUtils;
import com.orgzly.a.a.d;
import com.orgzly.a.e;
import com.orgzly.android.g;
import com.orgzly.android.h;
import com.orgzly.android.j;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.e;
import com.orgzly.android.ui.k;
import com.orgzly.android.ui.l;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

public class f {
    private static final String a = f.class.getName();

    public static int a(Context context, long l2, Set<Long> set) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("book_id", Long.valueOf(l2));
        contentValues.put("ids", TextUtils.join((CharSequence)",", set));
        return context.getContentResolver().update(e.e.a.a(), contentValues, null, null);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static int a(Context var0, com.orgzly.android.f var1_4) {
        var4_5 = new ContentValues();
        f.a((ContentValues)var4_5, var1_4.b());
        var5_6 = ContentUris.withAppendedId((Uri)e.n.a.a(), (long)var1_4.c()).buildUpon().appendQueryParameter("book-id", String.valueOf(var1_4.a().f())).build();
        var3_7 = new ArrayList<ContentProviderOperation>();
        var3_7.add(ContentProviderOperation.newUpdate((Uri)var5_6).withValues((ContentValues)var4_5).build());
        var3_7.add(ContentProviderOperation.newDelete((Uri)e.m.a.a(var1_4.c())).build());
        var4_5 = var1_4.b().p().iterator();
        var2_8 = 0;
        while (var4_5.hasNext()) {
            var5_6 = (e)var4_5.next();
            var6_9 = new ContentValues();
            var6_9.put("note_id", Long.valueOf(var1_4.c()));
            var6_9.put("name", var5_6.a());
            var6_9.put("value", var5_6.b());
            var6_9.put("position", Integer.valueOf(var2_8));
            var3_7.add(ContentProviderOperation.newInsert((Uri)e.m.a.a()).withValues(var6_9).build());
            ++var2_8;
        }
        try {
            var0 = var0.getContentResolver().applyBatch("com.orgzly", var3_7);
        }
        catch (RemoteException var0_1) {}
        return var0[0].count;
        ** GOTO lbl-1000
        catch (OperationApplicationException var0_3) {}
lbl-1000: // 2 sources:
        {
            var0_2.printStackTrace();
            throw new RuntimeException((Throwable)var0_2);
        }
    }

    public static Cursor a(Context context, String string) {
        j j2 = new j();
        if (string != null) {
            j2.a(string);
        }
        return context.getContentResolver().query(e.n.a.a(j2), null, null, null, "is_visible");
    }

    public static i a(Context context, j j2) {
        return new i(context, e.n.a.a(j2), null, null, null, f.b(context, j2));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static com.orgzly.android.f a(Context var0, com.orgzly.android.f var1_4, com.orgzly.android.ui.i var2_5) {
        var4_6 = new ContentValues();
        f.a((ContentValues)var4_6, var1_4);
        var2_5 = var2_5 != null ? e.n.a.a(var2_5) : e.n.a.a();
        var5_7 = new ArrayList<ContentProviderOperation>();
        var5_7.add(ContentProviderOperation.newInsert((Uri)var2_5).withValues((ContentValues)var4_6).build());
        var2_5 = var1_4.b().p().iterator();
        var3_8 = 0;
        while (var2_5.hasNext()) {
            var4_6 = (e)var2_5.next();
            var6_9 = new ContentValues();
            var6_9.put("name", var4_6.a());
            var6_9.put("value", var4_6.b());
            var6_9.put("position", Integer.valueOf(var3_8));
            var5_7.add(ContentProviderOperation.newInsert((Uri)e.m.a.a()).withValues(var6_9).withValueBackReference("note_id", 0).build());
            ++var3_8;
        }
        try {
            var0 = var0.getContentResolver().applyBatch("com.orgzly", var5_7);
        }
        catch (RemoteException var0_1) {}
        var1_4.b(ContentUris.parseId((Uri)var0[0].uri));
        return var1_4;
        ** GOTO lbl-1000
        catch (OperationApplicationException var0_3) {}
lbl-1000: // 2 sources:
        {
            var0_2.printStackTrace();
            throw new RuntimeException((Throwable)var0_2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static com.orgzly.android.f a(Cursor object) {
        long l2 = object.getLong(object.getColumnIndex("_id"));
        boolean bl2 = object.getInt(object.getColumnIndex("is_collapsed")) != 0;
        int n2 = object.getInt(object.getColumnIndex("content_line_count"));
        com.orgzly.a.c c2 = f.b((Cursor)object);
        object = com.orgzly.android.provider.c.f.a((Cursor)object);
        com.orgzly.android.f f2 = new com.orgzly.android.f();
        f2.a(c2);
        f2.b(l2);
        f2.a((g)object);
        f2.a(n2);
        f2.a(bl2);
        return f2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static h a(Context var0) {
        block12 : {
            block11 : {
                var5_2 = var0.getContentResolver().query(e.n.a.a(), new String[]{"MAX(is_cut)"}, null, null, null);
                var2_4 = var5_2.moveToFirst();
                if (var2_4) break block11;
                var5_2.close();
                return null;
            }
            var3_5 = var5_2.getLong(0);
            if (var3_5 == 0) return null;
            var0 = var0.getContentResolver().query(e.n.a.a(), c.a, "is_cut = " + var3_5, null, null);
            var1_6 = var0.getCount();
            ** if (var1_6 != 0) goto lbl-1000
lbl-1000: // 1 sources:
            {
                var0.close();
                return null;
            }
lbl-1000: // 1 sources:
            {
                break block12;
            }
            finally {
                var5_2.close();
            }
        }
        try {
            var5_2 = new HashSet<E>();
            var0.moveToFirst();
            while (var0.isAfterLast() == false) {
                var5_2.add(var0.getLong(0));
                var0.moveToNext();
            }
            return new h(var3_5, (Set<Long>)var5_2);
        }
        catch (Throwable var5_3) {
            throw var5_3;
        }
        finally {
            var0.close();
        }
    }

    public static h a(Context context, long l2, long l3, l l4) {
        h h2 = f.a(context);
        if (h2 != null) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("spot", l4.toString());
            contentValues.put("book_id", Long.valueOf(l2));
            contentValues.put("note_id", Long.valueOf(l3));
            contentValues.put("batch_id", Long.valueOf(h2.b()));
            context.getContentResolver().update(e.p.a.a(), contentValues, null, null);
        }
        return h2;
    }

    public static List<e> a(Context context, long l2) {
        ArrayList<e> arrayList;
        arrayList = new ArrayList<e>();
        context = context.getContentResolver().query(e.m.a.a(l2), null, null, null, null);
        try {
            context.moveToFirst();
            while (!context.isAfterLast()) {
                arrayList.add(new e(context.getString(0), context.getString(1)));
                context.moveToNext();
            }
        }
        finally {
            context.close();
        }
        return arrayList;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(ContentValues contentValues, com.orgzly.a.c c2) {
        contentValues.put("title", c2.a());
        if (c2.g()) {
            contentValues.put("scheduled_string", c2.f().toString());
        } else {
            contentValues.putNull("scheduled_string");
        }
        if (c2.i()) {
            contentValues.put("closed_string", c2.h().toString());
        } else {
            contentValues.putNull("closed_string");
        }
        if (c2.m()) {
            contentValues.put("clock_string", c2.l().toString());
        } else {
            contentValues.putNull("clock_string");
        }
        if (c2.k()) {
            contentValues.put("deadline_string", c2.j().toString());
        } else {
            contentValues.putNull("deadline_string");
        }
        contentValues.put("priority", c2.n());
        contentValues.put("state", c2.o());
        if (c2.c()) {
            contentValues.put("tags", com.orgzly.android.provider.c.f.a(c2.b()));
        } else {
            contentValues.putNull("tags");
        }
        if (c2.e()) {
            contentValues.put("content", c2.d());
            contentValues.put("content_line_count", Integer.valueOf(com.orgzly.android.b.e.a(c2.d())));
            return;
        }
        contentValues.putNull("content");
        contentValues.put("content_line_count", Integer.valueOf(0));
    }

    public static void a(ContentValues contentValues, com.orgzly.android.f f2) {
        contentValues.put("book_id", Long.valueOf(f2.a().f()));
        contentValues.put("is_visible", Long.valueOf(f2.a().g()));
        contentValues.put("parent_position", Long.valueOf(f2.a().h()));
        contentValues.put("level", Integer.valueOf(f2.a().e()));
        contentValues.put("is_collapsed", Boolean.valueOf(f2.e()));
        contentValues.put("has_children", Integer.valueOf(f2.a().d()));
        contentValues.put("is_under_collapsed", Long.valueOf(f2.a().a()));
        contentValues.put("position", Integer.valueOf(0));
        f.a(contentValues, f2.b());
    }

    public static void a(Context context, String string, a a2) {
        string = f.a(context, string);
        try {
            string.moveToFirst();
            while (!string.isAfterLast()) {
                com.orgzly.android.f f2 = f.a((Cursor)string);
                List<e> list = f.a(context, f2.c());
                f2.b().a(list);
                a2.a(f2);
                string.moveToNext();
            }
        }
        finally {
            string.close();
        }
    }

    private static void a(Context object, String string, ArrayList<ContentProviderOperation> arrayList) {
        if ((object = f.b((Context)object, string)) != null) {
            string = new ContentValues();
            string.put("mtime", Long.valueOf(System.currentTimeMillis()));
            arrayList.add(ContentProviderOperation.newUpdate((Uri)e.b.a.a()).withValues((ContentValues)string).withSelection("_id IN (" + (String)object + ")", null).build());
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void a(Context var0, Set<Long> var1_4, com.orgzly.a.a.a var2_5) {
        var3_6 = new ArrayList<ContentProviderOperation>();
        var1_4 = TextUtils.join((CharSequence)",", (Iterable)var1_4);
        var4_7 = new ContentValues();
        if (var2_5 != null) {
            var4_7.put("scheduled_string", d.a(var2_5).toString());
        } else {
            var4_7.putNull("scheduled_string");
        }
        var3_6.add(ContentProviderOperation.newUpdate((Uri)e.n.a.a()).withValues(var4_7).withSelection("_id IN (" + (String)var1_4 + ")", null).build());
        f.a(var0, (String)var1_4, var3_6);
        try {
            var0.getContentResolver().applyBatch("com.orgzly", var3_6);
            return;
        }
        catch (RemoteException var0_1) {}
        ** GOTO lbl-1000
        catch (OperationApplicationException var0_3) {}
lbl-1000: // 2 sources:
        {
            var0_2.printStackTrace();
            throw new RuntimeException((Throwable)var0_2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(Context context, Set<Long> contentValues, String string) {
        String string2 = TextUtils.join((CharSequence)",", (Iterable)contentValues);
        contentValues = new ContentValues();
        contentValues.put("note_ids", string2);
        if (string == null) {
            string = "NOTE";
        }
        contentValues.put("state", string);
        context.getContentResolver().update(e.o.a.a(), contentValues, null, null);
    }

    public static int b(Context context, long l2, Set<Long> set) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("book_id", Long.valueOf(l2));
        contentValues.put("ids", TextUtils.join((CharSequence)",", set));
        return context.getContentResolver().update(e.g.a.a(), contentValues, null, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static com.orgzly.a.c b(Cursor object) {
        com.orgzly.a.c c2 = new com.orgzly.a.c();
        String string = object.getString(object.getColumnIndex("state"));
        if (k.b(string)) {
            c2.e(string);
        } else {
            c2.e(null);
        }
        if ((string = object.getString(object.getColumnIndex("priority"))) != null) {
            c2.d(string);
        }
        c2.a(object.getString(object.getColumnIndex("title")));
        c2.b(object.getString(object.getColumnIndex("content")));
        if (!TextUtils.isEmpty((CharSequence)object.getString(object.getColumnIndex(e.n.b.b)))) {
            c2.a(d.b(object.getString(object.getColumnIndex(e.n.b.b))));
        }
        if (!TextUtils.isEmpty((CharSequence)object.getString(object.getColumnIndex(e.n.b.g)))) {
            c2.c(d.b(object.getString(object.getColumnIndex(e.n.b.g))));
        }
        if (!TextUtils.isEmpty((CharSequence)object.getString(object.getColumnIndex(e.n.b.l)))) {
            c2.b(d.b(object.getString(object.getColumnIndex(e.n.b.l))));
        }
        if (!TextUtils.isEmpty((CharSequence)object.getString(object.getColumnIndex(e.n.b.p)))) {
            c2.d(d.b(object.getString(object.getColumnIndex(e.n.b.p))));
        }
        if (!TextUtils.isEmpty((CharSequence)(object = object.getString(object.getColumnIndex("tags"))))) {
            c2.a(com.orgzly.android.provider.c.f.a((String)object));
        }
        return c2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String b(Context object, j iterator) {
        String string = PreferenceManager.getDefaultSharedPreferences((Context)object).getString(object.getResources().getString(2131231067), object.getResources().getString(2131231051));
        ArrayList<String> arrayList = new ArrayList<String>();
        if (!iterator.t()) {
            arrayList.add(e.n.b.a);
            arrayList.add("COALESCE(priority, '" + string + "')");
            if (iterator.c()) {
                arrayList.add(e.n.b.k);
            }
            if (iterator.a()) {
                arrayList.add(e.n.b.f);
            }
        } else {
            iterator = iterator.u().iterator();
            while (iterator.hasNext()) {
                StringBuilder stringBuilder;
                object = iterator.next();
                if (object.b() == j.b.a.c) {
                    stringBuilder = new StringBuilder().append(e.n.b.a);
                    object = object.a() ? "" : " DESC";
                    arrayList.add(stringBuilder.append((String)object).toString());
                    continue;
                }
                if (object.b() == j.b.a.a) {
                    arrayList.add(e.n.b.f + " IS NULL");
                    stringBuilder = new StringBuilder().append(e.n.b.f);
                    object = object.a() ? "" : " DESC";
                    arrayList.add(stringBuilder.append((String)object).toString());
                    continue;
                }
                if (object.b() == j.b.a.b) {
                    arrayList.add(e.n.b.k + " IS NULL");
                    stringBuilder = new StringBuilder().append(e.n.b.k);
                    object = object.a() ? "" : " DESC";
                    arrayList.add(stringBuilder.append((String)object).toString());
                    continue;
                }
                if (object.b() != j.b.a.d) continue;
                stringBuilder = new StringBuilder().append("COALESCE(priority, '").append(string).append("')");
                object = object.a() ? "" : " DESC";
                arrayList.add(stringBuilder.append((String)object).toString());
            }
        }
        arrayList.add("is_visible");
        return TextUtils.join((CharSequence)", ", arrayList);
    }

    private static String b(Context context, String string) {
        context = context.getContentResolver();
        Uri uri = e.n.a.a();
        string = "_id IN (" + string + ")";
        context = context.query(uri, new String[]{"GROUP_CONCAT(DISTINCT book_id)"}, string, null, null);
        try {
            if (context.moveToFirst()) {
                string = context.getString(0);
                return string;
            }
            return null;
        }
        finally {
            context.close();
        }
    }

    public static void b(Context context, long l2) {
        context.getContentResolver().delete(e.n.a.a(), "book_id=" + l2, null);
    }

    public static com.orgzly.android.f c(Context context, long l2) {
        context = context.getContentResolver().query(e.n.a.a(), null, "_id=" + l2, null, null);
        try {
            if (context.moveToFirst()) {
                com.orgzly.android.f f2 = f.a((Cursor)context);
                return f2;
            }
            throw new NoSuchElementException("Note with id " + l2 + " was not found in " + (Object)e.n.a.a());
        }
        finally {
            context.close();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String[] d(Context context, long l2) {
        HashSet<String> hashSet = new HashSet<String>();
        String string = l2 > 0 ? "book_id = " + l2 : null;
        context = context.getContentResolver().query(e.n.a.a(), new String[]{"DISTINCT tags"}, string, null, null);
        try {
            context.moveToFirst();
            while (!context.isAfterLast()) {
                string = context.getString(0);
                if (!TextUtils.isEmpty((CharSequence)string)) {
                    hashSet.addAll(Arrays.asList(com.orgzly.android.provider.c.f.a(string)));
                }
                context.moveToNext();
            }
            return hashSet.toArray(new String[hashSet.size()]);
        }
        finally {
            context.close();
        }
    }

    public static void e(Context context, long l2) {
        context.getContentResolver().update(e.n.a.b(l2), null, null, null);
    }

    public static interface a {
        public void a(com.orgzly.android.f var1);
    }

}

