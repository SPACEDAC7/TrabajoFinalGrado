/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentProviderOperation
 *  android.content.ContentProviderOperation$Builder
 *  android.content.ContentProviderResult
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.OperationApplicationException
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.RemoteException
 *  android.util.Log
 */
package com.orgzly.android.provider.b;

import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.OperationApplicationException;
import android.database.Cursor;
import android.net.Uri;
import android.os.RemoteException;
import android.util.Log;
import com.orgzly.android.a.h;
import com.orgzly.android.provider.e;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class g {
    private static final String a = g.class.getName();

    public static int a(Context context, long l2) {
        return context.getContentResolver().delete(ContentUris.withAppendedId((Uri)e.r.a.a(), (long)l2), null, null);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static int a(Context var0, long var1_4, String var3_5) {
        var4_6 = new ArrayList<ContentProviderOperation>();
        var4_6.add(ContentProviderOperation.newDelete((Uri)ContentUris.withAppendedId((Uri)e.r.a.a(), (long)var1_4)).build());
        var4_6.add(ContentProviderOperation.newInsert((Uri)e.r.a.a()).withValue("repo_url", (Object)var3_5).build());
        try {
            var0.getContentResolver().applyBatch("com.orgzly", var4_6);
            return 1;
        }
        catch (RemoteException var0_1) {}
        ** GOTO lbl-1000
        catch (OperationApplicationException var0_3) {}
lbl-1000: // 2 sources:
        {
            var0_2.printStackTrace();
            throw new RuntimeException((Throwable)var0_2);
        }
    }

    public static Uri a(Context context, String string) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("repo_url", string);
        return context.getContentResolver().insert(e.r.a.a(), contentValues);
    }

    public static Map<String, com.orgzly.android.a.g> a(Context context) {
        return g.a(context, context.getContentResolver().query(e.r.a.a(), new String[]{"repo_url"}, null, null, null));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static Map<String, com.orgzly.android.a.g> a(Context context, Cursor cursor) {
        HashMap<String, com.orgzly.android.a.g> hashMap = new HashMap<String, com.orgzly.android.a.g>();
        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                String string = cursor.getString(0);
                com.orgzly.android.a.g g2 = h.a(context, string);
                if (g2 != null) {
                    hashMap.put(string, g2);
                } else {
                    Log.e((String)a, (String)("Unsupported repository URL\"" + string + "\""));
                }
                cursor.moveToNext();
            }
            return hashMap;
        }
        finally {
            cursor.close();
        }
    }

    public static String b(Context context, long l2) {
        Object object = ContentUris.withAppendedId((Uri)e.r.a.a(), (long)l2);
        context = context.getContentResolver().query((Uri)object, new String[]{"repo_url"}, null, null, null);
        try {
            if (context.moveToFirst()) {
                object = context.getString(0);
                return object;
            }
            return null;
        }
        finally {
            context.close();
        }
    }
}

