/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.g;
import com.orgzly.android.provider.d;
import com.orgzly.android.ui.l;

public class c {
    public static final String[] a;
    public static final String[] b;
    public static final String c;
    private static final String d;

    static {
        d = c.class.getName();
        a = new String[]{"_id"};
        b = new String[]{"count(*)"};
        c = "((is_cut = 0 AND level > 0) AND " + d.a("is_under_collapsed") + ")";
    }

    public static int a(SQLiteDatabase sQLiteDatabase, long l2) {
        return c.a(sQLiteDatabase, "_id=" + l2, null);
    }

    public static int a(SQLiteDatabase sQLiteDatabase, String string, String[] arrstring) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("mtime", Long.valueOf(System.currentTimeMillis()));
        return sQLiteDatabase.update("books", contentValues, string, arrstring);
    }

    public static long a(SQLiteDatabase sQLiteDatabase, g g2) {
        sQLiteDatabase = sQLiteDatabase.query("notes", a, c.a(g2.f()) + " AND " + "is_visible" + " < " + g2.g() + " AND " + "parent_id" + " = " + g2.b(), null, null, null, "is_visible DESC");
        try {
            if (sQLiteDatabase.moveToFirst()) {
                long l2 = sQLiteDatabase.getLong(0);
                return l2;
            }
            return 0;
        }
        finally {
            sQLiteDatabase.close();
        }
    }

    public static long a(SQLiteDatabase sQLiteDatabase, String string, String string2, String[] arrstring) {
        sQLiteDatabase = sQLiteDatabase.query(string, a, string2, arrstring, null, null, null);
        try {
            if (sQLiteDatabase.moveToFirst()) {
                long l2 = sQLiteDatabase.getLong(0);
                return l2;
            }
            return 0;
        }
        finally {
            sQLiteDatabase.close();
        }
    }

    public static String a(long l2) {
        return "(book_id = " + l2 + " AND " + "(is_cut = 0 AND level > 0)" + ")";
    }

    public static String a(long l2, long l3, long l4) {
        return "(" + c.a(l2) + " AND " + "is_visible" + "< " + l3 + " AND " + l4 + " < " + "parent_position" + ")";
    }

    public static String a(long l2, String string) {
        return "(_id IN (SELECT DISTINCT b._id FROM notes a, notes b WHERE a.book_id = " + l2 + " AND b." + "book_id" + " = " + l2 + " AND a." + "_id" + " IN (" + string + ") AND b." + "is_visible" + " < a." + "is_visible" + " AND a." + "parent_position" + " < b." + "parent_position" + "))";
    }

    public static String a(SQLiteDatabase sQLiteDatabase, long l2, long l3) {
        String string = c.a(l2, String.valueOf(l3));
        sQLiteDatabase = sQLiteDatabase.query("notes", new String[]{"group_concat(_id, ',')"}, string, null, null, null, null);
        try {
            if (sQLiteDatabase.moveToFirst()) {
                string = sQLiteDatabase.getString(0);
                return string;
            }
            return null;
        }
        finally {
            sQLiteDatabase.close();
        }
    }

    public static void a(SQLiteDatabase sQLiteDatabase, String string) {
        string = sQLiteDatabase.query("notes", new String[]{"_id", "is_visible", "parent_position", "book_id"}, string, null, null, null, null);
        try {
            string.moveToFirst();
            while (!string.isAfterLast()) {
                long l2 = string.getLong(0);
                long l3 = string.getLong(1);
                long l4 = string.getLong(2);
                long l5 = string.getLong(3);
                String string2 = "(SELECT count(*) FROM notes WHERE " + c.b(l5, l3, l4) + ")";
                sQLiteDatabase.execSQL("UPDATE notes SET has_children = " + string2 + " WHERE " + "_id" + " = " + l2);
                string.moveToNext();
            }
        }
        finally {
            string.close();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static long[] a(SQLiteDatabase sQLiteDatabase, int n2, g g2, l l2) {
        long l3;
        n2 *= 2;
        String string = c.a(g2.f());
        switch (.a[l2.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unsupported paste relative position " + (Object)((Object)l2));
            }
            case 1: {
                d.a(sQLiteDatabase, "notes", string + " AND " + "is_visible" + " >= " + g2.g(), n2, "is_visible");
                d.a(sQLiteDatabase, "notes", string + " AND " + "parent_position" + " > " + g2.g(), n2, "parent_position");
                l3 = g2.g();
                n2 = g2.e();
                do {
                    return new long[]{l3, n2};
                    break;
                } while (true);
            }
            case 2: {
                d.a(sQLiteDatabase, "notes", string + " AND " + "is_visible" + " > " + g2.h(), n2, "is_visible");
                d.a(sQLiteDatabase, "notes", string + " AND " + "parent_position" + " >= " + g2.h(), n2, "parent_position");
                l3 = g2.h();
                n2 = g2.e() + 1;
                return new long[]{l3, n2};
            }
            case 3: 
        }
        d.a(sQLiteDatabase, "notes", string + " AND " + "is_visible" + " > " + g2.h(), n2, "is_visible");
        d.a(sQLiteDatabase, "notes", string + " AND " + "parent_position" + " > " + g2.h(), n2, "parent_position");
        l3 = 1 + g2.h();
        n2 = g2.e();
        return new long[]{l3, n2};
    }

    public static String b(long l2, long l3, long l4) {
        return "(" + c.a(l2) + " AND " + l3 + " < " + "is_visible" + " AND " + "parent_position" + " < " + l4 + ")";
    }

    public static String b(long l2, String string) {
        return "_id IN (SELECT DISTINCT a._id FROM notes b, notes a WHERE a.book_id = " + l2 + " AND b." + "book_id" + " = " + l2 + " AND b." + "_id" + " IN (" + string + ") AND a." + "is_cut" + " = 0 AND b." + "is_visible" + " <= a." + "is_visible" + " AND a." + "parent_position" + " <= b." + "parent_position" + ")";
    }

    public static void b(SQLiteDatabase sQLiteDatabase, long l2) {
        System.currentTimeMillis();
        String string = "(SELECT _id FROM notes AS n WHERE book_id = " + l2 + " AND n." + "is_visible" + " < " + "notes" + "." + "is_visible" + " AND " + "notes" + "." + "parent_position" + " < n." + "parent_position" + " ORDER BY n." + "is_visible" + " DESC LIMIT 1)";
        sQLiteDatabase.execSQL("UPDATE notes SET parent_id = " + string + " WHERE " + c.a(l2));
    }

    public static String c(long l2, long l3, long l4) {
        return "(" + c.a(l2) + " AND " + l3 + " <= " + "is_visible" + " AND " + "parent_position" + " <= " + l4 + ")";
    }

}

