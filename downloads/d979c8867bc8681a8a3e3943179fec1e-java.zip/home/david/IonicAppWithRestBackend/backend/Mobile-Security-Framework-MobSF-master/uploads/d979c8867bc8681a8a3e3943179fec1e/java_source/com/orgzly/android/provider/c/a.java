/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.provider.c;

public class a {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS books (_id INTEGER PRIMARY KEY AUTOINCREMENT,name UNIQUE,title TEXT,mtime INTEGER,is_dummy INTEGER DEFAULT 0,is_deleted INTEGER DEFAULT 0,preface TEXT,is_indented INTEGER DEFAULT 0,used_encoding TEXT,detected_encoding TEXT,selected_encoding TEXT,sync_status TEXT,last_action_timestamp INTEGER,last_action_type INTEGER,last_action TEXT)", "CREATE INDEX IF NOT EXISTS i_books_name ON books(name)"};
}

