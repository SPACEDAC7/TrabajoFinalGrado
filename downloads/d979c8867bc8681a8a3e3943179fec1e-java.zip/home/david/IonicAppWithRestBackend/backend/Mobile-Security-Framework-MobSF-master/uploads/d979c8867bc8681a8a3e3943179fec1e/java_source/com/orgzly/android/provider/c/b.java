/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.provider.c;

public class b {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS book_links (_id INTEGER PRIMARY KEY AUTOINCREMENT,book_id INTEGER,rook_id INTEGER,UNIQUE(book_id))"};
}

