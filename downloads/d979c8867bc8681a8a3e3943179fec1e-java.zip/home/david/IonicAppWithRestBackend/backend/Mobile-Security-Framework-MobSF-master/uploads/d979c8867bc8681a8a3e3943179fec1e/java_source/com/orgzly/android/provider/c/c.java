/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.provider.c;

public class c {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS book_syncs (_id INTEGER PRIMARY KEY AUTOINCREMENT,book_id INTEGER,book_versioned_rook_id INTEGER,UNIQUE(book_id))"};
}

