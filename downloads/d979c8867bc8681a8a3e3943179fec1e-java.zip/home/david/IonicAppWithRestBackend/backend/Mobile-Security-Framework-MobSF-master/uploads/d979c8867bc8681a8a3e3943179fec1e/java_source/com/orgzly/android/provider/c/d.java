/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.provider.c;

public class d {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS current_versioned_rooks (_id INTEGER PRIMARY KEY AUTOINCREMENT,versioned_rook_id INTEGER)"};
}

