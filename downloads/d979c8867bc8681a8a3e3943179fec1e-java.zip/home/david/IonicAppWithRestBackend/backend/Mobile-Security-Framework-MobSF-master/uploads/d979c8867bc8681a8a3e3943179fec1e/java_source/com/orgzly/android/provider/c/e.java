/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.provider.c;

public class e {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS db_repos (_id INTEGER PRIMARY KEY AUTOINCREMENT, repo_url TEXT NOT NULL, url TEXT NOT NULL, revision TEXT, mtime INTEGER, content TEXT, created_at INTEGER, UNIQUE (repo_url, url) ON CONFLICT REPLACE)"};
}

