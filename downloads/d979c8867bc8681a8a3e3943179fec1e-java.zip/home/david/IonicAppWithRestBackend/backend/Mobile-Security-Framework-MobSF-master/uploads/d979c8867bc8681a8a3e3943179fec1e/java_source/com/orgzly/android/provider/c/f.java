/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  android.text.TextUtils
 */
package com.orgzly.android.provider.c;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import com.orgzly.a.a.a;
import com.orgzly.a.a.d;
import com.orgzly.android.b.e;
import com.orgzly.android.g;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.c.h;
import com.orgzly.android.provider.c.i;
import java.util.List;

public class f {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS notes (_id INTEGER PRIMARY KEY AUTOINCREMENT,book_id INTEGER NOT NULL,position INTEGER NOT NULL,is_visible INTEGER,parent_position INTEGER,level INTEGER NOT NULL,parent_id INTEGER,has_children INTEGER,is_collapsed INTEGER,is_under_collapsed INTEGER,is_cut INTEGER NOT NULL DEFAULT 0,title TEXT NOT NULL DEFAULT '',tags TEXT,state TEXT,priority TEXT,content TEXT,content_line_count INTEGER,scheduled_range_id INTEGER,deadline_range_id INTEGER,closed_range_id INTEGER,clock_range_id INTEGER)", "CREATE INDEX IF NOT EXISTS i_notes_title ON notes(title)", "CREATE INDEX IF NOT EXISTS i_notes_tags ON notes(tags)", "CREATE INDEX IF NOT EXISTS i_notes_content ON notes(content)", "CREATE INDEX IF NOT EXISTS i_notes_book_id ON notes(book_id)", "CREATE INDEX IF NOT EXISTS i_notes_is_cut ON notes(is_cut)", "CREATE INDEX IF NOT EXISTS i_notes_is_visible ON notes(is_visible)", "CREATE INDEX IF NOT EXISTS i_notes_parent_position ON notes(parent_position)", "CREATE INDEX IF NOT EXISTS i_notes_is_collapsed ON notes(is_collapsed)", "CREATE INDEX IF NOT EXISTS i_notes_is_under_collapsed ON notes(is_under_collapsed)", "CREATE INDEX IF NOT EXISTS i_notes_parent_id ON notes(parent_id)", "CREATE INDEX IF NOT EXISTS i_notes_has_children ON notes(has_children)"};
    public static String[] b = new String[]{"book_id", "level", "is_visible", "parent_position", "has_children", "is_under_collapsed", "parent_id", "is_collapsed"};

    private static long a(SQLiteDatabase sQLiteDatabase, a a2) {
        long l2;
        long l3 = l2 = c.a(sQLiteDatabase, "org_timestamps", "string= ?", new String[]{a2.toString()});
        if (l2 == 0) {
            ContentValues contentValues = new ContentValues();
            i.a(contentValues, a2);
            l3 = sQLiteDatabase.insertOrThrow("org_timestamps", null, contentValues);
        }
        return l3;
    }

    private static long a(SQLiteDatabase sQLiteDatabase, d d2) {
        long l2;
        long l3 = 0;
        long l4 = l2 = c.a(sQLiteDatabase, "org_ranges", "string=?", new String[]{d2.toString()});
        if (l2 == 0) {
            ContentValues contentValues = new ContentValues();
            l2 = f.a(sQLiteDatabase, d2.a());
            l4 = l3;
            if (d2.b() != null) {
                l4 = f.a(sQLiteDatabase, d2.b());
            }
            h.a(contentValues, d2, l2, l4);
            l4 = sQLiteDatabase.insertOrThrow("org_ranges", null, contentValues);
        }
        return l4;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static g a(Cursor object) {
        long l2 = object.getLong(object.getColumnIndex("book_id"));
        int n2 = object.getInt(object.getColumnIndex("level"));
        long l3 = object.getLong(object.getColumnIndex("is_visible"));
        long l4 = object.getLong(object.getColumnIndex("parent_position"));
        int n3 = object.getInt(object.getColumnIndex("has_children"));
        long l5 = object.getLong(object.getColumnIndex("is_under_collapsed"));
        long l6 = object.getLong(object.getColumnIndex("parent_id"));
        int n4 = object.getInt(object.getColumnIndex("is_collapsed"));
        object = new g();
        object.b(n2);
        object.c(l2);
        object.d(l3);
        object.e(l4);
        object.a(n3);
        object.a(l5);
        object.b(l6);
        boolean bl2 = n4 != 0;
        object.a(bl2);
        return object;
    }

    public static g a(SQLiteDatabase sQLiteDatabase, long l2) {
        sQLiteDatabase = sQLiteDatabase.query("notes", b, "_id = " + l2, null, null, null, null);
        try {
            if (sQLiteDatabase.moveToFirst()) {
                g g2 = f.a((Cursor)sQLiteDatabase);
                return g2;
            }
            throw new IllegalStateException("Failed getting note for id " + l2);
        }
        finally {
            sQLiteDatabase.close();
        }
    }

    public static String a(List list) {
        return TextUtils.join((CharSequence)" ", (Iterable)list);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(ContentValues contentValues, g g2) {
        contentValues.put("book_id", Long.valueOf(g2.f()));
        contentValues.put("level", Integer.valueOf(g2.e()));
        contentValues.put("is_visible", Long.valueOf(g2.g()));
        contentValues.put("parent_position", Long.valueOf(g2.h()));
        contentValues.put("has_children", Integer.valueOf(g2.d()));
        contentValues.put("is_under_collapsed", Long.valueOf(g2.a()));
        contentValues.put("parent_id", Long.valueOf(g2.b()));
        int n2 = g2.c() ? 1 : 0;
        contentValues.put("is_collapsed", Integer.valueOf(n2));
        contentValues.put("position", Integer.valueOf(0));
    }

    public static void a(SQLiteDatabase sQLiteDatabase, ContentValues contentValues, com.orgzly.a.c c2) {
        contentValues.put("title", c2.a());
        contentValues.put("priority", c2.n());
        contentValues.put("state", c2.o());
        if (c2.c()) {
            contentValues.put("tags", f.a(c2.b()));
        }
        if (c2.g()) {
            contentValues.put("scheduled_range_id", Long.valueOf(f.a(sQLiteDatabase, c2.f())));
        }
        if (c2.i()) {
            contentValues.put("closed_range_id", Long.valueOf(f.a(sQLiteDatabase, c2.h())));
        }
        if (c2.m()) {
            contentValues.put("clock_range_id", Long.valueOf(f.a(sQLiteDatabase, c2.l())));
        }
        if (c2.k()) {
            contentValues.put("deadline_range_id", Long.valueOf(f.a(sQLiteDatabase, c2.j())));
        }
        if (c2.e()) {
            contentValues.put("content", c2.d());
            contentValues.put("content_line_count", Integer.valueOf(e.a(c2.d())));
        }
    }

    public static String[] a(String string) {
        return string.split(" ");
    }
}

