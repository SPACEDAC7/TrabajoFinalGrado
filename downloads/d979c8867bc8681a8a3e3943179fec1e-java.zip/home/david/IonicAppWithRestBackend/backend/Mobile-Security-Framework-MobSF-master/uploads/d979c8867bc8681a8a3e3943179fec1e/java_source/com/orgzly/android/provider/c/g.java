/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.c;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.c.j;
import com.orgzly.android.provider.c.r;

public class g
extends r {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS note_properties (_id INTEGER PRIMARY KEY AUTOINCREMENT,note_id INTEGER,position INTEGER,property_id INTEGER,UNIQUE(note_id, position, property_id))", "CREATE INDEX IF NOT EXISTS i_note_properties_note_id ON note_properties(note_id)", "CREATE INDEX IF NOT EXISTS i_note_properties_position ON note_properties(position)", "CREATE INDEX IF NOT EXISTS i_note_properties_property_id ON note_properties(property_id)"};
    public Long b;
    public Integer c;
    public j d;

    public g(Long l2, Integer n2, j j2) {
        this.b = l2;
        this.c = n2;
        this.d = j2;
    }

    public long a(SQLiteDatabase sQLiteDatabase) {
        long l2;
        long l3 = this.d.a(sQLiteDatabase);
        long l4 = l2 = c.a(sQLiteDatabase, "note_properties", "note_id = " + this.b + " AND position = " + this.c + " AND property_id = " + l3, null);
        if (l2 == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("note_id", this.b);
            contentValues.put("position", this.c);
            contentValues.put("property_id", Long.valueOf(l3));
            l4 = sQLiteDatabase.insertOrThrow("note_properties", null, contentValues);
        }
        return l4;
    }
}

