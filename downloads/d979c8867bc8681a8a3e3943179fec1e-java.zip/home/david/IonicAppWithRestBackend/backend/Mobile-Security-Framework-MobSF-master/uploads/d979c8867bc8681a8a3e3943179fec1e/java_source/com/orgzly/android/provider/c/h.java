/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 */
package com.orgzly.android.provider.c;

import android.content.ContentValues;
import com.orgzly.a.a.d;

public class h {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS org_ranges (_id INTEGER PRIMARY KEY AUTOINCREMENT,string TEXT UNIQUE,string_without_brackets TEXT,start_timestamp_id INTEGER,end_timestamp_id INTEGER,difference INTEGER)"};

    public static void a(ContentValues contentValues, d d2, long l2, long l3) {
        contentValues.put("start_timestamp_id", Long.valueOf(l2));
        contentValues.put("string", d2.toString());
        contentValues.put("string_without_brackets", d2.d());
        if (l3 != 0) {
            contentValues.put("end_timestamp_id", Long.valueOf(l3));
            return;
        }
        contentValues.putNull("end_timestamp_id");
    }
}

