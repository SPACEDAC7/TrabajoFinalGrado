/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 */
package com.orgzly.android.provider.c;

import android.content.ContentValues;
import com.orgzly.a.a.a;
import com.orgzly.a.a.b;
import com.orgzly.a.a.c;
import com.orgzly.a.a.e;
import java.util.Calendar;

public class i {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS org_timestamps (_id INTEGER PRIMARY KEY AUTOINCREMENT,string TEXT UNIQUE,string_without_brackets TEXT,is_active INTEGER,repeater_type TEXT,repeater_value INTEGER,repeater_unit TEXT,repeater_at_least_value INTEGER,repeater_at_least_unit TEXT,delay_type TEXT,delay_value INTEGER,delay_unit TEXT,timestamp INTEGER,timestamp_end INTEGER)", "CREATE INDEX IF NOT EXISTS i_org_timestamps_timestamp ON org_timestamps(timestamp)", "CREATE INDEX IF NOT EXISTS i_org_timestamps_timestamp_end ON org_timestamps(timestamp_end)"};

    /*
     * Enabled aggressive block sorting
     */
    public static void a(ContentValues contentValues, a a2) {
        contentValues.put("string", a2.toString());
        contentValues.put("string_without_brackets", a2.j());
        int n2 = a2.b() ? 1 : 0;
        contentValues.put("is_active", Integer.valueOf(n2));
        contentValues.put("timestamp", Long.valueOf(a2.a().getTimeInMillis()));
        if (a2.d()) {
            contentValues.put("timestamp_end", Long.valueOf(a2.e().getTimeInMillis()));
        } else {
            contentValues.putNull("timestamp_end");
        }
        if (a2.f()) {
            contentValues.put("repeater_type", a2.g().a().toString());
            contentValues.put("repeater_value", Integer.valueOf(a2.g().b()));
            contentValues.put("repeater_unit", a2.g().c().toString());
            if (a2.g().d()) {
                contentValues.put("repeater_at_least_value", Integer.valueOf(a2.g().e().b()));
                contentValues.put("repeater_at_least_unit", a2.g().e().c().toString());
            } else {
                contentValues.putNull("repeater_at_least_value");
                contentValues.putNull("repeater_at_least_unit");
            }
        } else {
            contentValues.putNull("repeater_type");
            contentValues.putNull("repeater_value");
            contentValues.putNull("repeater_unit");
            contentValues.putNull("repeater_at_least_value");
            contentValues.putNull("repeater_at_least_unit");
        }
        if (a2.h()) {
            contentValues.put("delay_type", a2.i().a().toString());
            contentValues.put("delay_value", Integer.valueOf(a2.i().b()));
            contentValues.put("delay_unit", a2.i().c().toString());
            return;
        }
        contentValues.putNull("delay_type");
        contentValues.putNull("delay_value");
        contentValues.putNull("delay_unit");
    }
}

