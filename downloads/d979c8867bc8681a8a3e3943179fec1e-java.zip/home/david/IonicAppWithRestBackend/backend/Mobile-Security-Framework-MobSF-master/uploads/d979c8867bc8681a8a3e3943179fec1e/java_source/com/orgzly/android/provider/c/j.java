/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.c;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.c.k;
import com.orgzly.android.provider.c.l;
import com.orgzly.android.provider.c.r;

public class j
extends r {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS properties (_id INTEGER PRIMARY KEY AUTOINCREMENT,name_id INTEGER,value_id INTEGER,UNIQUE(name_id, value_id))", "CREATE INDEX IF NOT EXISTS i_properties_name_id ON properties(name_id)", "CREATE INDEX IF NOT EXISTS i_properties_value_id ON properties(value_id)"};
    public k b;
    public l c;

    public j(k k2, l l2) {
        this.b = k2;
        this.c = l2;
    }

    public long a(SQLiteDatabase sQLiteDatabase) {
        long l2;
        long l3 = this.b.a(sQLiteDatabase);
        long l4 = this.c.a(sQLiteDatabase);
        long l5 = l2 = c.a(sQLiteDatabase, "properties", "name_id = " + l3 + " AND value_id = " + l4, null);
        if (l2 == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("name_id", Long.valueOf(l3));
            contentValues.put("value_id", Long.valueOf(l4));
            l5 = sQLiteDatabase.insertOrThrow("properties", null, contentValues);
        }
        return l5;
    }
}

