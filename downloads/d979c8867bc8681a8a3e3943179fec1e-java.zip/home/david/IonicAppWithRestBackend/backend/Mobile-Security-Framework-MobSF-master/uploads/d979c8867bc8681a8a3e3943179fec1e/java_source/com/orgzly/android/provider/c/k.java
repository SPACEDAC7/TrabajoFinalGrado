/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.c;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.c.r;

public class k
extends r {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS property_names (_id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE)", "CREATE INDEX IF NOT EXISTS i_property_names_name ON property_names(name)"};
    public String b;

    public k(String string) {
        this.b = string;
    }

    public long a(SQLiteDatabase sQLiteDatabase) {
        long l2;
        long l3 = l2 = c.a(sQLiteDatabase, "property_names", "name = ?", new String[]{this.b});
        if (l2 == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("name", this.b);
            l3 = sQLiteDatabase.insertOrThrow("property_names", null, contentValues);
        }
        return l3;
    }
}

