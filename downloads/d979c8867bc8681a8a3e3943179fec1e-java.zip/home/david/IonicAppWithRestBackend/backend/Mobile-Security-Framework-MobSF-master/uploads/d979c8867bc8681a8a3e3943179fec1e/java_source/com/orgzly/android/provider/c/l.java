/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.c;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.c.r;

public class l
extends r {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS property_values (_id INTEGER PRIMARY KEY AUTOINCREMENT,value TEXT UNIQUE)", "CREATE INDEX IF NOT EXISTS i_property_values_value ON property_values(value)"};
    public String b;

    public l(String string) {
        this.b = string;
    }

    public long a(SQLiteDatabase sQLiteDatabase) {
        long l2;
        long l3 = l2 = c.a(sQLiteDatabase, "property_values", "value = ?", new String[]{this.b});
        if (l2 == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("value", this.b);
            l3 = sQLiteDatabase.insertOrThrow("property_values", null, contentValues);
        }
        return l3;
    }
}

