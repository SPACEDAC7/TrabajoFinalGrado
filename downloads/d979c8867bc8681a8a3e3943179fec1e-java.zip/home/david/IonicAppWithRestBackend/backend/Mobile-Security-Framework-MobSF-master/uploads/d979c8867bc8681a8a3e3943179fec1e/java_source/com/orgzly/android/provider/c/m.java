/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.c;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.Provider;
import com.orgzly.android.provider.c;
import com.orgzly.android.provider.e;

public class m {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS repos (_id INTEGER PRIMARY KEY AUTOINCREMENT, repo_url TEXT NOT NULL, is_repo_active INTEGER DEFAULT 1, UNIQUE (repo_url))"};

    public static int a(Context context, SQLiteDatabase sQLiteDatabase, ContentValues contentValues, String string, String[] arrstring) {
        int n2 = sQLiteDatabase.update("repos", contentValues, string, arrstring);
        m.a(context);
        return n2;
    }

    public static int a(Context context, SQLiteDatabase sQLiteDatabase, String string, String[] arrstring) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("is_repo_active", Integer.valueOf(0));
        int n2 = sQLiteDatabase.update("repos", contentValues, string, arrstring);
        m.a(context);
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static long a(Context context, SQLiteDatabase sQLiteDatabase, String string) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("repo_url", string);
        contentValues.put("is_repo_active", Integer.valueOf(1));
        long l2 = c.a(sQLiteDatabase, "repos", "repo_url=?", new String[]{string});
        if (l2 > 0) {
            sQLiteDatabase.update("repos", contentValues, "_id=" + l2, null);
        } else {
            l2 = sQLiteDatabase.insertOrThrow("repos", null, contentValues);
        }
        m.a(context);
        return l2;
    }

    private static void a(Context context) {
        Provider.a(context, e.r.a.a());
        Provider.a(context, e.b.a.a());
    }
}

