/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.provider.c;

public class n {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS rooks (_id INTEGER PRIMARY KEY AUTOINCREMENT,repo_id INTEGER,rook_url_id INTEGER,UNIQUE (repo_id,rook_url_id))"};
}

