/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider.c;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.c;

public class o {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS rook_urls (_id INTEGER PRIMARY KEY AUTOINCREMENT, rook_url TEXT, UNIQUE (rook_url))"};

    public static long a(SQLiteDatabase sQLiteDatabase, String string) {
        long l2;
        long l3 = l2 = c.a(sQLiteDatabase, "rook_urls", "rook_url=?", new String[]{string});
        if (l2 == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("rook_url", string);
            l3 = sQLiteDatabase.insertOrThrow("rook_urls", null, contentValues);
        }
        return l3;
    }
}

