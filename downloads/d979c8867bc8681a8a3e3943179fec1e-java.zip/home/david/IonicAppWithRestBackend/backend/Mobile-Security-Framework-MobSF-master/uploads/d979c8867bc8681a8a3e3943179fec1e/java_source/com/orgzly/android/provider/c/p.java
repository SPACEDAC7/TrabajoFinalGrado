/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.provider.c;

public class p {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS searches (_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, search TEXT NOT NULL, icon INTEGER, group_name TEXT, position INTEGER DEFAULT 1, is_saved INTEGER DEFAULT 0)", "INSERT INTO searches (name, search) VALUES (\"Scheduled\", \"s.today .i.done\")", "INSERT INTO searches (name, search) VALUES (\"To Do\", \"i.todo\")"};
}

