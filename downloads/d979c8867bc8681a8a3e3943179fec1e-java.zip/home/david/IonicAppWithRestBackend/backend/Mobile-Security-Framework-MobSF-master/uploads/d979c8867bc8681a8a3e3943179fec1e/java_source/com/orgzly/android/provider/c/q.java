/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.provider.c;

public class q {
    public static final String[] a = new String[]{"CREATE TABLE IF NOT EXISTS versioned_rooks (_id INTEGER PRIMARY KEY AUTOINCREMENT,rook_id INTEGER,rook_mtime INTEGER,rook_revision)"};
}

