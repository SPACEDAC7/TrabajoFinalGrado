/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.provider.BaseColumns
 */
package com.orgzly.android.provider.c;

import android.provider.BaseColumns;

public abstract class r
implements BaseColumns {
}

