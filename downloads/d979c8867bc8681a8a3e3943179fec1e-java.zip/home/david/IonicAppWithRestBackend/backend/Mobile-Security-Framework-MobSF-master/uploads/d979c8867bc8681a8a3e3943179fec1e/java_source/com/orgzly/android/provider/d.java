/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.database.sqlite.SQLiteDatabase
 *  android.text.TextUtils
 */
package com.orgzly.android.provider;

import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import java.util.ArrayList;

public class d {
    public static String a(String string) {
        return "(" + string + " IS NULL OR " + string + " = 0 )";
    }

    public static String a(String string, String string2, String string3, String string4, String string5) {
        return " LEFT OUTER JOIN " + string + " " + string2 + " ON " + string2 + "." + string3 + " = " + string4 + "." + string5 + " ";
    }

    public static /* varargs */ void a(SQLiteDatabase sQLiteDatabase, String string, String string2, int n2, String ... arrstring) {
        if (arrstring.length == 0) {
            throw new IllegalArgumentException("No fields passed to incrementFields");
        }
        ArrayList<String> arrayList = new ArrayList<String>();
        for (String string3 : arrstring) {
            arrayList.add(string3 + " = " + string3 + " + (" + n2 + ")");
        }
        sQLiteDatabase.execSQL("UPDATE " + string + " SET " + TextUtils.join((CharSequence)", ", arrayList) + " WHERE " + string2);
    }
}

