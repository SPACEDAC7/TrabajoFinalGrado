/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.provider.BaseColumns
 */
package com.orgzly.android.provider.d;

import android.provider.BaseColumns;
import com.orgzly.android.provider.d;

public class a {
    public static final String a = "CREATE VIEW books_view AS SELECT books.*, t_link_rook_repos.repo_url AS " + a.a + ", t_link_rook_urls.rook_url AS " + a.b + ", t_sync_revision_rook_repos.repo_url AS " + a.c + ", t_sync_revision_rook_urls.rook_url AS " + a.d + ", t_sync_revisions.rook_revision AS " + a.e + ", t_sync_revisions.rook_mtime AS " + a.f + " FROM " + "books" + " " + d.a("book_links", "t_links", "book_id", "books", "_id") + d.a("rooks", "t_link_rooks", "_id", "t_links", "rook_id") + d.a("repos", "t_link_rook_repos", "_id", "t_link_rooks", "repo_id") + d.a("rook_urls", "t_link_rook_urls", "_id", "t_link_rooks", "rook_url_id") + d.a("book_syncs", "t_syncs", "book_id", "books", "_id") + d.a("versioned_rooks", "t_sync_revisions", "_id", "t_syncs", "book_versioned_rook_id") + d.a("rooks", "t_sync_revision_rooks", "_id", "t_sync_revisions", "rook_id") + d.a("repos", "t_sync_revision_rook_repos", "_id", "t_sync_revision_rooks", "repo_id") + d.a("rook_urls", "t_sync_revision_rook_urls", "_id", "t_sync_revision_rooks", "rook_url_id") + "";

    public static class a
    implements BaseColumns {
        public static String a = "link_repo_url";
        public static String b = "link_rook_url";
        public static String c = "sync_repo_url";
        public static String d = "sync_rook_url";
        public static String e = "sync_rook_revision";
        public static String f = "sync_rook_mtime";
    }

}

