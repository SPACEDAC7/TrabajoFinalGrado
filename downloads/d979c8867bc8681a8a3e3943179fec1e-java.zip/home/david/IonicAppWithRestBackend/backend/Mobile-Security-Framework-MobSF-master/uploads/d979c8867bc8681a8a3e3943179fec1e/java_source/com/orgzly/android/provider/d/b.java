/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.provider.BaseColumns
 */
package com.orgzly.android.provider.d;

import android.provider.BaseColumns;
import com.orgzly.android.provider.d;

public class b {
    public static final String a = "CREATE VIEW notes_view AS SELECT notes.*, t_scheduled_range.string AS " + a.b + ", t_scheduled_range." + "string_without_brackets" + " AS " + a.c + ", t_scheduled_timestamps_start." + "string" + " AS " + a.d + ", t_scheduled_timestamps_end." + "string" + " AS " + a.e + ", t_scheduled_timestamps_start." + "timestamp" + " AS " + a.f + ", t_deadline_range." + "string" + " AS " + a.g + ", t_deadline_range." + "string_without_brackets" + " AS " + a.h + ", t_deadline_timestamps_start." + "string" + " AS " + a.i + ", t_deadline_timestamps_end." + "string" + " AS " + a.j + ", t_deadline_timestamps_start." + "timestamp" + " AS " + a.k + ", t_closed_range." + "string" + " AS " + a.l + ", t_closed_range." + "string_without_brackets" + " AS " + a.m + ", t_closed_timestamps_start." + "string" + " AS " + a.n + ", t_closed_timestamps_end." + "string" + " AS " + a.o + ", t_clock_range." + "string" + " AS " + a.p + ", t_clock_range." + "string_without_brackets" + " AS " + a.q + ", t_clock_timestamps_start." + "string" + " AS " + a.r + ", t_clock_timestamps_end." + "string" + " AS " + a.s + ", t_books." + "name" + " AS " + a.a + " FROM " + "notes" + " " + d.a("org_ranges", "t_scheduled_range", "_id", "notes", "scheduled_range_id") + d.a("org_timestamps", "t_scheduled_timestamps_start", "_id", "t_scheduled_range", "start_timestamp_id") + d.a("org_timestamps", "t_scheduled_timestamps_end", "_id", "t_scheduled_range", "end_timestamp_id") + d.a("org_ranges", "t_deadline_range", "_id", "notes", "deadline_range_id") + d.a("org_timestamps", "t_deadline_timestamps_start", "_id", "t_deadline_range", "start_timestamp_id") + d.a("org_timestamps", "t_deadline_timestamps_end", "_id", "t_deadline_range", "end_timestamp_id") + d.a("org_ranges", "t_closed_range", "_id", "notes", "closed_range_id") + d.a("org_timestamps", "t_closed_timestamps_start", "_id", "t_closed_range", "start_timestamp_id") + d.a("org_timestamps", "t_closed_timestamps_end", "_id", "t_closed_range", "end_timestamp_id") + d.a("org_ranges", "t_clock_range", "_id", "notes", "clock_range_id") + d.a("org_timestamps", "t_clock_timestamps_start", "_id", "t_clock_range", "start_timestamp_id") + d.a("org_timestamps", "t_clock_timestamps_end", "_id", "t_clock_range", "end_timestamp_id") + d.a("books", "t_books", "_id", "notes", "book_id") + "";

    public static class a
    implements BaseColumns {
        public static String a = "book_name";
        public static String b = "scheduled_range_string";
        public static String c = "scheduled_range_string_without_brackets";
        public static String d = "scheduled_time_string";
        public static String e = "scheduled_time_string";
        public static String f = "scheduled_time_timestamp";
        public static String g = "deadline_range_string";
        public static String h = "deadline_range_string_without_brackets";
        public static String i = "deadline_time_string";
        public static String j = "deadline_time_end_string";
        public static String k = "deadline_time_timestamp";
        public static String l = "closed_range_string";
        public static String m = "closed_range_string_without_brackets";
        public static String n = "closed_time_string";
        public static String o = "closed_time_end_string";
        public static String p = "clock_range_string";
        public static String q = "clock_range_string_without_brackets";
        public static String r = "clock_time_string";
        public static String s = "clock_time_end_string";
    }

}

