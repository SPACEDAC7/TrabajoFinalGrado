/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentUris
 *  android.net.Uri
 *  android.net.Uri$Builder
 *  android.provider.BaseColumns
 */
package com.orgzly.android.provider;

import android.content.ContentUris;
import android.net.Uri;
import android.provider.BaseColumns;
import com.orgzly.android.provider.d.a;
import com.orgzly.android.provider.d.b;

public class e {
    public static final Uri a = Uri.parse((String)"content://com.orgzly");

    public static interface com.orgzly.android.provider.e$a {

        public static class a {
            public static Uri a(long l2) {
                return ContentUris.appendId((Uri.Builder)e.a.buildUpon().appendPath("books"), (long)l2).appendPath("links").build();
            }
        }

    }

    public static interface com.orgzly.android.provider.e$b {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"books");
            }

            public static Uri a(long l2) {
                return ContentUris.withAppendedId((Uri)a.a(), (long)l2);
            }

            public static Uri b(long l2) {
                return a.a(l2).buildUpon().appendPath("notes").build();
            }

            public static Uri c(long l2) {
                return ContentUris.withAppendedId((Uri)a.a(), (long)l2).buildUpon().appendPath("cycle-visibility").build();
            }

            public static Uri d(long l2) {
                return ContentUris.withAppendedId((Uri)a.a(), (long)l2).buildUpon().appendPath("sparse-tree").build();
            }
        }

        public static class b
        extends a.a
        implements BaseColumns {
        }

    }

    public static interface c {

        public static class a {
            public static Uri a(long l2) {
                return ContentUris.appendId((Uri.Builder)e.a.buildUpon().appendPath("books"), (long)l2).appendPath("saved").build();
            }
        }

    }

    public static interface d {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"current-rooks");
            }
        }

    }

    public static interface e {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"cut");
            }
        }

    }

    public static interface f {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"db/recreate");
            }
        }

    }

    public static interface g {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"delete");
            }
        }

    }

    public static interface h {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"demote");
            }
        }

    }

    public static interface i {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"filters");
            }

            public static Uri a(long l2) {
                return ContentUris.withAppendedId((Uri)a.a(), (long)l2).buildUpon().appendPath("up").build();
            }

            public static Uri b(long l2) {
                return ContentUris.withAppendedId((Uri)a.a(), (long)l2).buildUpon().appendPath("down").build();
            }
        }

    }

    public static interface j {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"load-from-file");
            }
        }

    }

    public static interface k {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"db-repos");
            }
        }

    }

    public static interface l {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"move");
            }
        }

    }

    public static interface m {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"notes/properties");
            }

            public static Uri a(long l2) {
                return ContentUris.appendId((Uri.Builder)e.a.buildUpon().appendPath("notes"), (long)l2).appendPath("properties").build();
            }
        }

    }

    public static interface n {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"notes");
            }

            public static Uri a(long l2) {
                return ContentUris.withAppendedId((Uri)a.a(), (long)l2);
            }

            public static Uri a(com.orgzly.android.j j2) {
                return a.a().buildUpon().appendPath("queried").query(j2.toString()).build();
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            public static Uri a(com.orgzly.android.ui.i var0) {
                var1_1 = a.a(var0.b()).buildUpon();
                switch (.a[var0.c().ordinal()]) {
                    case 1: {
                        var1_1.appendPath("above");
                        ** break;
                    }
                    case 2: {
                        var1_1.appendPath("under");
                    }
lbl8: // 3 sources:
                    default: {
                        return var1_1.build();
                    }
                    case 3: 
                }
                var1_1.appendPath("below");
                return var1_1.build();
            }

            public static Uri b(long l2) {
                return a.a(l2).buildUpon().appendPath("toggle-folded-state").build();
            }
        }

        public static class b
        extends b.a
        implements BaseColumns {
        }

    }

    public static interface o {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"notes/state");
            }
        }

    }

    public static interface p {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"paste");
            }
        }

    }

    public static interface q {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"promote");
            }
        }

    }

    public static interface r {

        public static class a {
            public static Uri a() {
                return Uri.withAppendedPath((Uri)e.a, (String)"repos");
            }
        }

    }

}

