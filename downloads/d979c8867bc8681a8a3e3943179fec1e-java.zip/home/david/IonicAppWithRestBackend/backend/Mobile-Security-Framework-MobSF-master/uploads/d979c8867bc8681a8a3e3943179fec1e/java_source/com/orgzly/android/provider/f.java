/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 */
package com.orgzly.android.provider;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.orgzly.android.provider.b.d;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

class f {
    static int a(SQLiteDatabase sQLiteDatabase, long l2) {
        return f.a(sQLiteDatabase, l2, true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static int a(SQLiteDatabase var0, long var1_1, boolean var3_2) {
        block12 : {
            block11 : {
                var0.beginTransaction();
                var12_3 = new HashMap<Long, Integer>();
                var13_5 = new HashMap<Long, Integer>();
                var11_6 = f.a(var0);
                var5_8 = 0;
                try {
                    var11_6.moveToFirst();
                    var4_9 = 1;
lbl10: // 2 sources:
                    if (var11_6.isAfterLast()) break block11;
                    var9_11 = var11_6.getLong(0);
                    var12_3.put(var9_11, var11_6.getInt(1));
                    var13_5.put(var9_11, var4_9);
                    if (var3_2) {
                        if (var9_11 == var1_1 && var5_8 != 0) {
                            var13_5.put(var9_11, var4_9 - 1);
                            var13_5.put(var5_8, var4_9);
                        }
                        break block12;
                    }
                    var7_10 = var5_8;
                    if (var5_8 != 0) {
                        var13_5.put(var9_11, var4_9 - 1);
                        var13_5.put(var5_8, var4_9);
                        var7_10 = 0;
                    }
                    var5_8 = var9_11 == var1_1 ? var9_11 : var7_10;
                }
                catch (Throwable var12_4) {
                    var11_6.close();
                    throw var12_4;
                }
                ++var4_9;
                ** GOTO lbl45
            }
            try {
                var11_6.close();
                f.a(var0, var12_3, var13_5);
                var0.setTransactionSuccessful();
                return 1;
            }
            finally {
                var0.endTransaction();
            }
        }
        ++var4_9;
        var5_8 = var9_11;
lbl45: // 2 sources:
        var11_6.moveToNext();
        ** GOTO lbl10
    }

    private static Cursor a(SQLiteDatabase sQLiteDatabase) {
        String string = d.a;
        return sQLiteDatabase.query("searches", new String[]{"_id", "position"}, null, null, null, null, string);
    }

    static void a(SQLiteDatabase sQLiteDatabase, ContentValues contentValues) {
        sQLiteDatabase = sQLiteDatabase.query("searches", new String[]{"MAX(position)"}, null, null, null, null, null);
        try {
            if (sQLiteDatabase.moveToFirst()) {
                contentValues.put("position", Integer.valueOf(sQLiteDatabase.getInt(0) + 1));
            }
            return;
        }
        finally {
            sQLiteDatabase.close();
        }
    }

    private static void a(SQLiteDatabase sQLiteDatabase, Map<Long, Integer> map, Map<Long, Integer> map2) {
        Iterator<Long> iterator = map2.keySet().iterator();
        while (iterator.hasNext()) {
            long l2 = iterator.next();
            if (map.get(l2).intValue() == map2.get(l2).intValue()) continue;
            sQLiteDatabase.execSQL("UPDATE searches SET position = " + map2.get(l2) + " WHERE " + "_id" + " = " + l2);
        }
    }

    static int b(SQLiteDatabase sQLiteDatabase, long l2) {
        return f.a(sQLiteDatabase, l2, false);
    }
}

