/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.UriMatcher
 */
package com.orgzly.android.provider;

import android.content.UriMatcher;

class g {
    final UriMatcher a = new UriMatcher(-1);

    g() {
        this.a.addURI("com.orgzly", "filters/#/up", 23);
        this.a.addURI("com.orgzly", "filters/#/down", 24);
        this.a.addURI("com.orgzly", "filters/#", 22);
        this.a.addURI("com.orgzly", "filters", 21);
        this.a.addURI("com.orgzly", "repos/#", 2);
        this.a.addURI("com.orgzly", "repos", 1);
        this.a.addURI("com.orgzly", "books/#/notes", 25);
        this.a.addURI("com.orgzly", "books/#/saved", 28);
        this.a.addURI("com.orgzly", "books/#/cycle-visibility", 30);
        this.a.addURI("com.orgzly", "books/#/sparse-tree", 34);
        this.a.addURI("com.orgzly", "books/#", 4);
        this.a.addURI("com.orgzly", "books", 3);
        this.a.addURI("com.orgzly", "books/#/links", 26);
        this.a.addURI("com.orgzly", "current-rooks", 27);
        this.a.addURI("com.orgzly", "notes/queried", 6);
        this.a.addURI("com.orgzly", "notes/#/above", 8);
        this.a.addURI("com.orgzly", "notes/#/under", 9);
        this.a.addURI("com.orgzly", "notes/#/below", 10);
        this.a.addURI("com.orgzly", "notes/state", 7);
        this.a.addURI("com.orgzly", "notes/#/toggle-folded-state", 31);
        this.a.addURI("com.orgzly", "notes/#", 12);
        this.a.addURI("com.orgzly", "notes", 5);
        this.a.addURI("com.orgzly", "notes/properties", 29);
        this.a.addURI("com.orgzly", "notes/#/properties", 11);
        this.a.addURI("com.orgzly", "db-repos", 17);
        this.a.addURI("com.orgzly", "db/recreate", 18);
        this.a.addURI("com.orgzly", "db/test", 19);
        this.a.addURI("com.orgzly", "cut", 13);
        this.a.addURI("com.orgzly", "paste", 14);
        this.a.addURI("com.orgzly", "delete", 33);
        this.a.addURI("com.orgzly", "promote", 15);
        this.a.addURI("com.orgzly", "demote", 32);
        this.a.addURI("com.orgzly", "move", 16);
        this.a.addURI("com.orgzly", "load-from-file", 20);
    }
}

