/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.os.Binder
 *  android.os.IBinder
 */
package com.orgzly.android.sync;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.IBinder;
import android.support.v4.c.m;
import com.orgzly.android.a.g;
import com.orgzly.android.b;
import com.orgzly.android.k;
import com.orgzly.android.sync.c;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public class SyncService
extends Service {
    public static final String a = SyncService.class.getName();
    private c b = new c();
    private k c;
    private b d;
    private final IBinder e;

    public SyncService() {
        this.e = new a();
    }

    private boolean a(Collection<g> object) {
        object = object.iterator();
        while (object.hasNext()) {
            if (!((g)object.next()).a()) continue;
            return true;
        }
        return false;
    }

    private boolean b() {
        int n2;
        NetworkInfo networkInfo = ((ConnectivityManager)this.getSystemService("connectivity")).getActiveNetworkInfo();
        if (networkInfo != null && ((n2 = networkInfo.getType()) == 1 || n2 == 0)) {
            return true;
        }
        return false;
    }

    private boolean b(Collection<g> object) {
        object = object.iterator();
        while (object.hasNext()) {
            if (!"file".equals(((g)object.next()).b().getScheme())) continue;
            return true;
        }
        return false;
    }

    public void a() {
        Intent intent = new Intent("com.orgzly.broadcast.sync").putExtra("type", this.b.a.name()).putExtra("message", this.b.b).putExtra("total_books", this.b.c).putExtra("current_book", this.b.d);
        m.a((Context)this).a(intent);
    }

    public IBinder onBind(Intent intent) {
        return this.e;
    }

    public void onCreate() {
        this.c = new k((Context)this);
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public int onStartCommand(Intent intent, int n2, int n3) {
        if (this.d != null) {
            this.b.a(c.a.c, null, this.b.d, this.b.c);
            this.a();
            this.d.cancel(false);
            return super.onStartCommand(intent, n2, n3);
        }
        Map<String, g> map = this.c.e();
        if (map.size() == 0) {
            this.b.a(c.a.j, this.getString(2131231038), 0, 0);
            this.a();
            this.stopSelf();
            return super.onStartCommand(intent, n2, n3);
        }
        if (this.a(map.values()) && !this.b()) {
            this.b.a(c.a.j, this.getString(2131231037), 0, 0);
            this.a();
            this.stopSelf();
            return super.onStartCommand(intent, n2, n3);
        }
        if (this.b(map.values()) && com.orgzly.android.b.a.a((Context)this, 3)) {
            this.b.a(c.a.g, null, 0, 0);
            this.a();
            this.stopSelf();
            return super.onStartCommand(intent, n2, n3);
        }
        this.d = new b();
        this.d.execute((Object[])new Void[0]);
        return super.onStartCommand(intent, n2, n3);
    }

    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    public class a
    extends Binder {
        public SyncService a() {
            return SyncService.this;
        }
    }

    private class b
    extends AsyncTask<Void, Object, Exception> {
        private b() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected /* varargs */ Exception a(Void ... map) {
            int n2 = 0;
            try {
                map = SyncService.this.c.d();
                if (map.size() == 0) {
                    return new IOException("No notebooks found");
                }
            }
            catch (Exception var1_2) {
                var1_2.printStackTrace();
                return var1_2;
            }
            SyncService.this.b.a(c.a.d, null, 0, map.size());
            SyncService.this.a();
            for (com.orgzly.android.sync.a a22 : map.values()) {
                SyncService.this.c.a(a22.b(), null, new com.orgzly.android.b(b.a.c, SyncService.this.getString(2131230949)));
            }
            Iterator<com.orgzly.android.sync.a> iterator = map.values().iterator();
            while (iterator.hasNext()) {
                com.orgzly.android.sync.a a22;
                a22 = iterator.next();
                if (this.isCancelled()) {
                    SyncService.this.c.a(a22.b(), null, new com.orgzly.android.b(b.a.a, SyncService.this.getString(2131230764)));
                } else {
                    SyncService.this.b.a(c.a.e, a22.a(), n2, map.size());
                    SyncService.this.a();
                    try {
                        com.orgzly.android.b b2 = SyncService.this.c.a(a22);
                        SyncService.this.c.a(a22.b(), a22.d().toString(), b2);
                    }
                    catch (Exception var5_7) {
                        var5_7.printStackTrace();
                        SyncService.this.c.a(a22.b(), null, new com.orgzly.android.b(b.a.b, var5_7.getMessage()));
                    }
                    SyncService.this.b.a(c.a.f, a22.a(), n2 + 1, map.size());
                    SyncService.this.a();
                }
                ++n2;
            }
            return null;
        }

        protected void a(Exception exception) {
            SyncService.this.b.a(c.a.h, SyncService.this.getString(2131230764), 0, 0);
            SyncService.this.a();
            SyncService.this.d = null;
            SyncService.this.stopSelf();
        }

        /*
         * Enabled aggressive block sorting
         */
        protected void b(Exception object) {
            if (object != null) {
                object = object.getMessage() != null ? object.getMessage() : object.toString();
                SyncService.this.b.a(c.a.j, (String)object, 0, 0);
            } else {
                SyncService.this.b.a(c.a.i, null, 0, 0);
                long l2 = System.currentTimeMillis();
                com.orgzly.android.prefs.a.a(SyncService.this.getApplicationContext(), l2);
            }
            SyncService.this.a();
            SyncService.this.d = null;
            SyncService.this.stopSelf();
        }

        protected /* synthetic */ Object doInBackground(Object[] arrobject) {
            return this.a((Void[])arrobject);
        }

        protected /* synthetic */ void onCancelled(Object object) {
            this.a((Exception)object);
        }

        protected /* synthetic */ void onPostExecute(Object object) {
            this.b((Exception)object);
        }

        protected void onPreExecute() {
            SyncService.this.b.a(c.a.b, null, 0, 0);
            SyncService.this.a();
        }
    }

}

