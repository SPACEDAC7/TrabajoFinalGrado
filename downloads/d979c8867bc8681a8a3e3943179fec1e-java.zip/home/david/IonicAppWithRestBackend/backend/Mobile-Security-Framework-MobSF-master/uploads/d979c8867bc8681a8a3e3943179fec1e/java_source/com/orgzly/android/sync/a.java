/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 */
package com.orgzly.android.sync;

import android.content.Context;
import android.net.Uri;
import com.orgzly.android.a.i;
import com.orgzly.android.a.j;
import com.orgzly.android.c;
import com.orgzly.android.sync.b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class a {
    private String a;
    private com.orgzly.android.a b;
    private List<j> c = new ArrayList<j>();
    private j d;
    private b e;

    public a(String string) {
        this.a = string;
    }

    private j a(com.orgzly.android.a a2, List<j> object) {
        object = object.iterator();
        while (object.hasNext()) {
            j j2 = (j)object.next();
            if (!a2.g().b().equals((Object)j2.b())) continue;
            return j2;
        }
        return null;
    }

    public static Map<String, a> a(Context context, List<com.orgzly.android.a> object, List<j> object2) {
        Object object3;
        Object object4;
        HashMap<String, a> hashMap = new HashMap<String, a>();
        object = object.iterator();
        while (object.hasNext()) {
            object3 = (com.orgzly.android.a)object.next();
            object4 = new a(object3.c());
            hashMap.put(object3.c(), (a)object4);
            object4.a((com.orgzly.android.a)object3);
        }
        object3 = object2.iterator();
        while (object3.hasNext()) {
            object4 = (j)object3.next();
            String string = c.b(c.a(context, object4.b())).a();
            object = object2 = hashMap.get(string);
            if (object2 == null) {
                object = new a(string);
                hashMap.put(string, (a)object);
            }
            object.a((j)object4);
        }
        return hashMap;
    }

    public String a() {
        return this.a;
    }

    public void a(int n2) {
        if (this.b == null && this.c.size() == 0) {
            throw new IllegalStateException("BookNameGroup does not contain any books");
        }
        if (this.b == null) {
            if (this.c.size() == 1) {
                this.e = b.l;
                return;
            }
            this.e = b.d;
            return;
        }
        if (this.c.size() == 0) {
            if (this.b.h()) {
                this.e = b.g;
                return;
            }
            if (this.b.g() != null) {
                this.e = b.r;
                return;
            }
            if (n2 > 1) {
                this.e = b.e;
                return;
            }
            this.e = b.p;
            return;
        }
        if (this.b.g() != null) {
            j j2 = this.a(this.b, this.c);
            if (j2 == null) {
                this.e = b.f;
                return;
            }
            this.b(j2);
            if (this.b.h()) {
                this.e = b.o;
                return;
            }
            if (this.b.f() == null) {
                this.e = b.j;
                return;
            }
            if (!this.b.f().b().equals((Object)j2.b())) {
                this.e = b.k;
                return;
            }
            if (this.b.f().c().equals(j2.c())) {
                if (this.b.d()) {
                    this.e = b.q;
                    return;
                }
                this.e = b.a;
                return;
            }
            if (this.b.d()) {
                this.e = b.i;
                return;
            }
            this.e = b.n;
            return;
        }
        if (!this.b.h()) {
            this.e = b.b;
            return;
        }
        if (this.c.size() == 1) {
            this.e = b.m;
            return;
        }
        this.e = b.c;
    }

    public void a(j j2) {
        this.c.add(j2);
    }

    public void a(com.orgzly.android.a a2) {
        this.b = a2;
    }

    public com.orgzly.android.a b() {
        return this.b;
    }

    public void b(j j2) {
        this.d = j2;
    }

    public List<j> c() {
        return this.c;
    }

    public b d() {
        return this.e;
    }

    public j e() {
        return this.d;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public String toString() {
        Object object;
        StringBuilder stringBuilder = new StringBuilder().append("[").append(this.getClass().getSimpleName()).append(" ").append(this.a).append(" | ").append((Object)this.e).append(" | Local:");
        if (this.b != null) {
            object = this.b;
            do {
                return stringBuilder.append(object).append(" | Remotes:").append(this.c.size()).append("]").toString();
                break;
            } while (true);
        }
        object = "N/A";
        return stringBuilder.append(object).append(" | Remotes:").append(this.c.size()).append("]").toString();
    }
}

