/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.sync;

public enum b {
    a,
    b,
    c,
    d,
    e,
    f,
    g,
    h,
    i,
    j,
    k,
    l,
    m,
    n,
    o,
    p,
    q,
    r;
    

    private b() {
    }

    public String a() {
        return this.a("");
    }

    public String a(Object object) {
        switch (.a[this.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unknown sync status " + (Object)((Object)this));
            }
            case 1: {
                return "No change";
            }
            case 2: {
                return "Notebook has no link and one or more remote notebooks with the same name exist";
            }
            case 3: {
                return "Notebook has no link and multiple remote notebooks with the same name exist";
            }
            case 4: {
                return "No notebook and multiple remote notebooks with the same name exist";
            }
            case 5: {
                return "Notebook has no link and multiple repositories exist";
            }
            case 6: {
                return "Notebook has link and remote notebook with the same name exists, but link is pointing to a different remote notebook which does not exist";
            }
            case 7: {
                return "Only local dummy exists";
            }
            case 8: {
                return "Linked and synced notebooks have different repositories";
            }
            case 9: {
                return "Both local and remote notebook have been modified";
            }
            case 10: {
                return "Link and remote notebook exist but notebook hasn't been synced before";
            }
            case 11: {
                return "Last synced notebook and latest remote notebook differ";
            }
            case 12: 
            case 13: 
            case 14: 
            case 15: {
                return "Loaded from " + object;
            }
            case 16: 
            case 17: 
            case 18: 
        }
        return "Saved to " + object;
    }

}

