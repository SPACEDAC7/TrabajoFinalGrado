/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.sync;

public class c {
    public a a = a.a;
    public String b = null;
    public int c = 0;
    public int d = 0;

    public void a(a a2, String string, int n2, int n3) {
        this.a = a2;
        this.b = string;
        this.d = n2;
        this.c = n3;
    }

    public static enum a {
        a,
        b,
        c,
        d,
        e,
        f,
        g,
        h,
        i,
        j;
        

        private a() {
        }
    }

}

