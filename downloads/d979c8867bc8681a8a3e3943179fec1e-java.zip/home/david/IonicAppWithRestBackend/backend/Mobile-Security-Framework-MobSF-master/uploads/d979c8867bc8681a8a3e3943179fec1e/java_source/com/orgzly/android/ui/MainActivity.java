/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.DialogInterface$OnDismissListener
 *  android.content.DialogInterface$OnShowListener
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.os.Bundle
 *  android.preference.PreferenceManager
 *  android.text.Editable
 *  android.text.TextUtils
 *  android.text.TextWatcher
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.CheckBox
 *  android.widget.EditText
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  android.widget.TextView$OnEditorActionListener
 */
package com.orgzly.android.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v4.b.r;
import android.support.v4.b.w;
import android.support.v4.k.q;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.view.b;
import android.support.v7.widget.SearchView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.orgzly.android.c;
import com.orgzly.android.d;
import com.orgzly.android.f;
import com.orgzly.android.k;
import com.orgzly.android.ui.ReposActivity;
import com.orgzly.android.ui.a.b;
import com.orgzly.android.ui.b.a;
import com.orgzly.android.ui.b.b;
import com.orgzly.android.ui.b.c;
import com.orgzly.android.ui.b.e;
import com.orgzly.android.ui.b.g;
import com.orgzly.android.ui.b.h;
import com.orgzly.android.ui.b.i;
import com.orgzly.android.ui.b.j;
import com.orgzly.android.ui.b.n;
import com.orgzly.android.ui.b.o;
import com.orgzly.android.ui.l;
import com.orgzly.android.ui.m;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity
extends com.orgzly.android.ui.b
implements com.orgzly.android.ui.a,
b.a,
a.a,
b.a,
c.a,
e.c,
g.a,
h.a,
i.a,
j.a,
n.a,
o.b {
    public static final String p = MainActivity.class.getName();
    private BroadcastReceiver A;
    private BroadcastReceiver B;
    private Bundle C;
    public o q;
    private DrawerLayout r;
    private android.support.v7.app.b s;
    private boolean t = false;
    private CharSequence u;
    private CharSequence v;
    private CharSequence w;
    private com.orgzly.android.ui.c x;
    private android.support.v7.view.b y;
    private AlertDialog z;

    public MainActivity() {
        this.A = new BroadcastReceiver(){

            public void onReceive(Context context, Intent intent) {
                if (MainActivity.this.z != null) {
                    MainActivity.this.z.getButton(-1).setText(2131230927);
                    MainActivity.this.z.getButton(-1).setEnabled(false);
                    MainActivity.this.z.setCancelable(false);
                }
            }
        };
        this.B = new BroadcastReceiver(){

            public void onReceive(Context context, Intent intent) {
                if (MainActivity.this.z != null) {
                    MainActivity.this.z.getButton(-1).setText(2131230900);
                    MainActivity.this.z.getButton(-1).setEnabled(true);
                    MainActivity.this.z.setCancelable(true);
                }
            }
        };
        this.C = null;
    }

    private o A() {
        o o2;
        o o3 = o2 = (o)this.e().a(o.a);
        if (o2 == null) {
            o3 = o.a();
            this.e().a().a(2131689641, o3, o.a).a();
        }
        return o3;
    }

    private void B() {
        if (this.e().a(e.i) == null) {
            this.e().a().a(2131689640, e.Z(), e.i).a();
        }
    }

    private void C() {
        int n2 = com.orgzly.android.prefs.a.B((Context)this);
        if (this.E()) {
            if (!com.orgzly.android.prefs.a.C((Context)this)) {
                this.D();
            }
            if (n2 == 0 && this.r != null) {
                this.r.e(8388611);
                this.t = true;
            }
            this.p();
        }
    }

    private void D() {
        this.q.a("Getting Started with Orgzly", this.getResources(), 2131165184);
    }

    private boolean E() {
        boolean bl2 = false;
        if (58 > com.orgzly.android.prefs.a.B((Context)this)) {
            bl2 = true;
        }
        com.orgzly.android.prefs.a.a((Context)this, 58);
        return bl2;
    }

    private com.orgzly.android.a F() {
        android.support.v4.b.m m2 = this.e().a(a.i);
        if (m2 != null && m2.o()) {
            return ((a)m2).Z();
        }
        return null;
    }

    private void G() {
        if (this.y != null) {
            this.y.c();
        }
    }

    private String a(Uri object) {
        if (com.orgzly.android.c.a((String)(object = com.orgzly.android.c.a((Context)this, (Uri)object)))) {
            return com.orgzly.android.c.b((String)object).a();
        }
        return null;
    }

    private void a(Uri uri, String string, c.a a2) {
        if (com.orgzly.android.provider.b.a.b((Context)this, string)) {
            this.a(this.getString(2131230751, new Object[]{string}));
            return;
        }
        this.q.a(string, a2, uri);
    }

    private void a(Bundle bundle) {
        com.orgzly.android.ui.a.b.a(5, "Notebook Name", null, this.a(Uri.parse((String)bundle.getString("uri"))), null, "Import", "Cancel", bundle).a(this.e(), com.orgzly.android.ui.a.b.aa);
    }

    private void a(Menu menu) {
        menu = menu.findItem(2131689796);
        final SearchView searchView = (SearchView)q.a((MenuItem)menu);
        searchView.setQueryHint(this.getString(2131230934));
        searchView.setOnSearchClickListener(new View.OnClickListener(){

            /*
             * Enabled aggressive block sorting
             */
            public void onClick(View object) {
                searchView.getLayoutParams().width = -1;
                object = MainActivity.this.x.f();
                if (object != null) {
                    searchView.setQuery(object.toString() + " ", false);
                    return;
                } else {
                    object = MainActivity.this.F();
                    if (object == null) return;
                    {
                        com.orgzly.android.j j2 = new com.orgzly.android.j();
                        j2.a(object.c());
                        searchView.setQuery(j2.toString() + " ", false);
                        return;
                    }
                }
            }
        });
        searchView.setOnQueryTextListener(new SearchView.c((MenuItem)menu){
            final /* synthetic */ MenuItem a;

            @Override
            public boolean a(String string) {
                q.c(this.a);
                MainActivity.this.x.a(string);
                return true;
            }

            @Override
            public boolean b(String string) {
                return false;
            }
        });
    }

    private void a(Menu menu, boolean bl2) {
        for (int i2 = 0; i2 < menu.size(); ++i2) {
            menu.getItem(i2).setVisible(bl2);
        }
    }

    private void a(com.orgzly.android.a a2, String string, TextInputLayout textInputLayout) {
        if (!TextUtils.isEmpty((CharSequence)string)) {
            textInputLayout.setError(null);
            this.q.a(a2, string);
            return;
        }
        textInputLayout.setError(this.getString(2131230762));
    }

    private void a(j j2, View view, long l2) {
        j2.ad().b(view, l2);
        this.a(j2.ad(), j2.ab());
    }

    private void a(String string, long l2) {
        this.G();
        long l3 = new k((Context)this).b(l2).a().f();
        this.x.a(l3, l2);
    }

    private void c(String string) {
        View view = this.findViewById(2131689588);
        if (view != null) {
            this.a(Snackbar.a(view, string, 8000).a(2131230924, new View.OnClickListener(){

                public void onClick(View view) {
                    view = new Intent("android.intent.action.VIEW");
                    view.setClass((Context)MainActivity.this, (Class)ReposActivity.class);
                    MainActivity.this.startActivity((Intent)view);
                }
            }));
        }
    }

    private void x() {
        this.r = (DrawerLayout)this.findViewById(2131689587);
        if (this.r != null) {
            this.s = new android.support.v7.app.b(this, this.r, 2131230813, 2131230811){
                private int d;

                /*
                 * Enabled aggressive block sorting
                 */
                @Override
                public void a(View view, float f2) {
                    super.a(view, f2);
                    switch (this.d) {
                        case -1: {
                            if (f2 == 0.0f) {
                                this.d = 0;
                                MainActivity.this.z();
                                return;
                            }
                            if (f2 <= 0.0f) return;
                            {
                                this.d = 1;
                                MainActivity.this.y();
                                return;
                            }
                        }
                        case 0: {
                            if (f2 <= 0.0f) return;
                            {
                                this.d = 1;
                                MainActivity.this.y();
                                return;
                            }
                        }
                        default: {
                            return;
                        }
                        case 1: 
                    }
                    if (f2 != 0.0f) return;
                    {
                        this.d = 0;
                        MainActivity.this.z();
                        return;
                    }
                }
            };
            this.r.a(this.s);
        }
        this.g().a(true);
        this.g().b(true);
        this.q = this.A();
        this.B();
    }

    private void y() {
        this.c_();
        this.g().a(this.w);
        this.g().b((CharSequence)null);
        this.t = true;
        com.orgzly.android.ui.c.a.a(this);
    }

    private void z() {
        this.c_();
        this.g().a(this.u);
        this.g().b(this.v);
        this.t = false;
    }

    @Override
    protected void a() {
        super.a();
        if (this.C != null) {
            this.a(this.C);
            this.C = null;
        }
    }

    @Override
    public void a(int n2, String string, Bundle bundle) {
        switch (n2) {
            default: {
                return;
            }
            case 1: {
                this.q.b(string);
                return;
            }
            case 5: 
        }
        this.a(Uri.parse((String)bundle.getString("uri")), string, c.a.a);
    }

    @Override
    public void a(long l2) {
        long l3 = new k((Context)this).b(l2).a().f();
        this.q.a(l3, l2);
        this.x.b(l3, l2);
    }

    @Override
    public void a(long l2, int n2) {
        this.q.a(l2, n2);
    }

    @Override
    public void a(long l2, long l3, l l4) {
        this.q.a(l2, l3, l4);
    }

    @Override
    public void a(long l2, d d2) {
        this.k();
        this.q.a(l2, d2);
    }

    @Override
    public void a(long l2, Set<Long> set) {
        this.q.a(l2, set);
    }

    @Override
    public void a(long l2, TreeSet<Long> treeSet) {
        this.q.a(l2, treeSet);
    }

    @Override
    public void a(android.support.v4.b.m m2) {
        super.a(m2);
    }

    @Override
    public void a(com.orgzly.android.a a2) {
        this.q.a(a2);
    }

    @Override
    public void a(com.orgzly.android.a a2, IOException iOException) {
        this.a(this.getResources().getString(2131230856, new Object[]{iOException.toString()}));
    }

    @Override
    public void a(d d2) {
        this.k();
        this.q.a(d2);
    }

    @Override
    public void a(f f2) {
        this.k();
        this.q.a(f2);
    }

    @Override
    public void a(f f2, com.orgzly.android.ui.i i2) {
        this.G();
        this.k();
        this.q.a(f2, i2);
    }

    @Override
    public void a(com.orgzly.android.h h2) {
        this.a(this.getResources().getQuantityString(2131755010, h2.a(), new Object[]{h2.a()}));
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(e.d d2) {
        if (d2 instanceof e.b) {
            this.G();
            this.x.b();
            return;
        } else {
            if (d2 instanceof e.f) {
                this.G();
                this.x.a();
                return;
            }
            if (d2 instanceof e.g) {
                this.G();
                this.x.c();
                return;
            }
            if (d2 instanceof e.a) {
                this.x.a(((e.a)d2).a);
                return;
            }
            if (!(d2 instanceof e.e)) return;
            {
                this.x.a(((e.e)d2).a);
                return;
            }
        }
    }

    @Override
    public void a(j j2, View view, int n2, long l2) {
        if (com.orgzly.android.prefs.a.r((Context)this)) {
            this.a(j2, view, l2);
            return;
        }
        if (j2.ad().a() > 0) {
            this.a(j2, view, l2);
            return;
        }
        this.a(j2.aa(), l2);
    }

    @Override
    public void a(com.orgzly.android.ui.i i2) {
        this.G();
        this.x.a(i2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(m m2, b.a a2) {
        if (this.y != null) {
            if (m2.a() != 0) {
                this.y.d();
                return;
            }
            this.y.c();
            return;
        } else {
            if (m2.a() <= 0) return;
            {
                this.y = this.b(a2);
                this.y.d();
                return;
            }
        }
    }

    @Override
    public void a(File file) {
        this.a(this.getString(2131230982, new Object[]{file.getAbsolutePath()}));
    }

    @Override
    public void a(Exception exception) {
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(String string, CharSequence object, CharSequence charSequence, int n2) {
        if (object == null) {
            object = this.w;
        }
        this.u = object;
        this.v = charSequence;
        if (!this.t) {
            this.g().a(this.u);
            this.g().b(this.v);
        }
        com.orgzly.android.ui.c.a.a(this, string);
        object = this.e().a(e.i);
        if (object != null) {
            ((e)object).b(string);
        }
        com.orgzly.android.ui.h.a(this, string, n2);
    }

    @Override
    public void a(Set<Long> set) {
        this.q.a(set);
    }

    @Override
    public void a(Set<Long> set, com.orgzly.a.a.a a2) {
        this.q.a(set, a2);
    }

    @Override
    public void a(Set<Long> set, String string) {
        this.q.a(set, string);
    }

    @Override
    public android.support.v7.view.b b() {
        return this.y;
    }

    @Override
    public void b(long l2) {
        this.q.d(l2);
    }

    @Override
    public void b(long l2, Set<Long> set) {
        this.q.b(l2, set);
    }

    @Override
    public void b(long l2, TreeSet<Long> treeSet) {
        this.q.b(l2, treeSet);
    }

    @Override
    public void b(com.orgzly.android.a a2) {
        this.G();
        this.x.a(a2);
    }

    @Override
    public void b(f f2) {
    }

    @Override
    public void b(final f f2, com.orgzly.android.ui.i i2) {
        i2 = this.findViewById(2131689588);
        if (i2 != null) {
            this.a(Snackbar.a((View)i2, 2131230861, 8000).a(2131230870, new View.OnClickListener(){

                public void onClick(View object) {
                    object = new com.orgzly.android.ui.i(f2.a().f(), f2.c(), l.c);
                    MainActivity.this.x.a((com.orgzly.android.ui.i)object);
                }
            }));
        }
    }

    @Override
    public void b(j j2, View view, int n2, long l2) {
        if (com.orgzly.android.prefs.a.r((Context)this)) {
            this.a(j2.aa(), l2);
            return;
        }
        this.a(j2, view, l2);
    }

    @Override
    public void b(Exception exception) {
        this.a(exception.getMessage());
    }

    @Override
    public void b(String string) {
        if (string != null) {
            this.c(this.getString(2131231149, new Object[]{string}));
        }
    }

    @Override
    public void b(Set<Long> set, com.orgzly.a.a.a a2) {
    }

    @Override
    public void b(Set<Long> set, String string) {
    }

    @Override
    public void c() {
        this.y = null;
    }

    @Override
    public void c(long l2) {
        com.orgzly.android.a a2 = com.orgzly.android.provider.b.a.c((Context)this, l2);
        View view = View.inflate((Context)this, (int)2130903085, (ViewGroup)null);
        DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener((CheckBox)view.findViewById(2131689563), a2){
            final /* synthetic */ CheckBox a;
            final /* synthetic */ com.orgzly.android.a b;

            public void onClick(DialogInterface dialogInterface, int n2) {
                switch (n2) {
                    default: {
                        return;
                    }
                    case -1: 
                }
                boolean bl2 = this.a.isChecked();
                MainActivity.this.q.a(this.b, bl2);
            }
        };
        onClickListener = new AlertDialog.Builder((Context)this).setTitle((CharSequence)("Delete " + com.orgzly.android.b.e.b(a2.c()))).setMessage((CharSequence)"Delete this notebook?").setPositiveButton(2131230900, onClickListener).setNegativeButton(2131230763, onClickListener);
        if (a2.g() != null) {
            onClickListener.setView(view);
        }
        onClickListener.show();
    }

    @Override
    public void c(com.orgzly.android.a a2) {
    }

    @Override
    public void c(f f2) {
        this.c(2131230860);
    }

    @Override
    public void c(Exception exception) {
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void d(int n2) {
        String string = n2 == 0 ? this.getResources().getString(2131230881) : this.getResources().getQuantityString(2131755009, n2, new Object[]{n2});
        this.a(string);
    }

    @Override
    public void d(long l2) {
        Uri uri = null;
        final com.orgzly.android.a a2 = com.orgzly.android.provider.b.a.c((Context)this, l2);
        if (a2 == null) {
            return;
        }
        View view = View.inflate((Context)this, (int)2130903086, (ViewGroup)null);
        Object object = (TextInputLayout)view.findViewById(2131689613);
        final EditText editText = (EditText)view.findViewById(2131689614);
        if (a2.g() != null) {
            uri = a2.g().b();
        }
        object = new DialogInterface.OnClickListener((TextInputLayout)((Object)object)){
            final /* synthetic */ TextInputLayout c;

            public void onClick(DialogInterface dialogInterface, int n2) {
                switch (n2) {
                    default: {
                        return;
                    }
                    case -1: 
                }
                MainActivity.this.a(a2, editText.getText().toString(), this.c);
            }
        };
        view = new AlertDialog.Builder((Context)this).setTitle((CharSequence)this.getString(2131231132, new Object[]{com.orgzly.android.b.e.b(a2.c())})).setPositiveButton(2131231131, (DialogInterface.OnClickListener)object).setNegativeButton(2131230763, (DialogInterface.OnClickListener)object).setView(view);
        editText.setText((CharSequence)a2.c());
        a2 = view.create();
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener((AlertDialog)a2){
            final /* synthetic */ AlertDialog a;

            public boolean onEditorAction(TextView textView, int n2, KeyEvent keyEvent) {
                this.a.getButton(-1).performClick();
                return true;
            }
        });
        a2.setOnShowListener(new DialogInterface.OnShowListener(){

            public void onShow(DialogInterface dialogInterface) {
                com.orgzly.android.ui.c.a.a(this, (View)editText);
            }
        });
        a2.setOnDismissListener(new DialogInterface.OnDismissListener(){

            public void onDismiss(DialogInterface dialogInterface) {
                com.orgzly.android.ui.c.a.a(this);
            }
        });
        if (uri != null) {
            editText.addTextChangedListener(new TextWatcher((AlertDialog)a2){
                final /* synthetic */ AlertDialog a;

                /*
                 * Enabled aggressive block sorting
                 */
                public void afterTextChanged(Editable editable) {
                    Button button = this.a.getButton(-1);
                    boolean bl2 = !TextUtils.isEmpty((CharSequence)editable);
                    button.setEnabled(bl2);
                }

                public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
                }

                public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
                }
            });
        }
        a2.show();
    }

    @Override
    public void d(com.orgzly.android.a a2) {
    }

    @Override
    public void d(f f2) {
        this.k();
    }

    @Override
    public void d(Exception exception) {
        this.a(this.getString(2131231011, new Object[]{exception.getLocalizedMessage()}));
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void e(int n2) {
        String string = n2 == 0 ? this.getResources().getString(2131230880) : this.getResources().getQuantityString(2131755008, n2, new Object[]{n2});
        this.a(string);
    }

    @Override
    public void e(long l2) {
        String string;
        final com.orgzly.android.a a2 = com.orgzly.android.provider.b.a.c((Context)this, l2);
        View view = com.orgzly.android.provider.b.g.a((Context)this);
        if (view.size() == 0) {
            this.c(this.getString(2131230884));
            return;
        }
        Object object = new LinkedHashMap<String, Integer>();
        object.put((String)this.getString(2131230877), 0);
        final Spinner spinner = view.keySet().iterator();
        int n2 = 1;
        while (spinner.hasNext()) {
            string = spinner.next();
            if (view.get(string) instanceof com.orgzly.android.a.a) continue;
            object.put((String)string, n2);
            ++n2;
        }
        view = this.getLayoutInflater().inflate(2130903089, null, false);
        spinner = (Spinner)view.findViewById(2131689623);
        string = new ArrayAdapter(spinner.getContext(), 2130903137, new ArrayList(object.keySet()));
        string.setDropDownViewResource(2130903093);
        spinner.setAdapter((SpinnerAdapter)string);
        if (a2.g() != null && (object = (Integer)object.get(a2.g().a().toString())) != null) {
            spinner.setSelection(object.intValue());
        }
        object = new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface object, int n2) {
                switch (n2) {
                    default: {
                        return;
                    }
                    case -1: 
                }
                object = new k((Context)MainActivity.this);
                String string = (String)spinner.getSelectedItem();
                if (MainActivity.this.getString(2131230877).equals(string)) {
                    object.b(a2, null);
                    return;
                }
                object.b(a2, string);
            }
        };
        new AlertDialog.Builder((Context)this).setTitle((CharSequence)("Link " + com.orgzly.android.b.e.b(a2.c()) + " to repository")).setView(view).setPositiveButton(2131230938, (DialogInterface.OnClickListener)object).setNegativeButton(2131230763, (DialogInterface.OnClickListener)object).show();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void e(com.orgzly.android.a a2) {
        if (!a2.c().equals("Getting Started with Orgzly")) return;
        if (com.orgzly.android.prefs.a.C((Context)this)) {
            this.c(2131230834);
            return;
        }
        com.orgzly.android.prefs.a.a((Context)this, true);
    }

    @Override
    public void e(f f2) {
        this.k();
        this.q.b(f2.a().f(), f2.c());
    }

    @Override
    public void f(long l2) {
        this.q.e(l2);
    }

    @Override
    public void f(com.orgzly.android.a a2) {
        this.c(2131230853);
    }

    @Override
    public void g(long l2) {
        this.q.a(l2);
    }

    @Override
    public void g(com.orgzly.android.a a2) {
        this.k();
        this.q.b(a2);
    }

    @Override
    public void h(final long l2) {
        this.o = new Runnable(){

            @Override
            public void run() {
                MainActivity.this.q.f(l2);
            }
        };
        if (com.orgzly.android.b.a.a(this, 2)) {
            this.o.run();
            this.o = null;
        }
    }

    @Override
    public void i(long l2) {
        this.x.b(l2, 0);
    }

    @Override
    public void j(long l2) {
        this.x.b(l2);
    }

    @Override
    public void k(long l2) {
        this.q.b(l2);
    }

    @Override
    public void l() {
        this.c(2131230859);
    }

    @Override
    public void l(long l2) {
        this.q.c(l2);
    }

    @Override
    public void m() {
        new AlertDialog.Builder((Context)this).setTitle(2131230953).setMessage(2131230952).setPositiveButton(2131231152, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
                MainActivity.this.q.aa();
            }
        }).setNegativeButton(2131230886, null).show();
    }

    @Override
    public void n() {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("*/*");
        this.startActivityForResult(Intent.createChooser((Intent)intent, (CharSequence)this.getString(2131231024)), 0);
    }

    @Override
    public void o() {
        this.D();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void onActivityResult(int n2, int n3, Intent intent) {
        switch (n2) {
            default: {
                return;
            }
            case 0: {
                if (n3 != -1) return;
                intent = intent.getData();
                Bundle bundle = new Bundle();
                bundle.putString("uri", intent.toString());
                this.C = bundle;
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void onBackPressed() {
        if (this.r != null && this.r.g(8388611)) {
            this.r.f(8388611);
            this.t = false;
            return;
        } else {
            android.support.v4.b.m m2 = this.e().a(i.a);
            if (m2 != null && m2 instanceof i && m2.o() && ((i)m2).a()) return;
            {
                super.onBackPressed();
                return;
            }
        }
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.s != null) {
            this.s.a(configuration);
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        CharSequence charSequence;
        super.onCreate(bundle);
        android.support.v4.c.m.a((Context)this).a(this.A, new IntentFilter("com.orgzly.broadcast.db.upgrade.started"));
        android.support.v4.c.m.a((Context)this).a(this.B, new IntentFilter("com.orgzly.broadcast.db.upgrade.ended"));
        PreferenceManager.setDefaultValues((Context)this, (int)2131099648, (boolean)true);
        this.setContentView(2130903067);
        this.w = charSequence = this.getTitle();
        this.u = charSequence;
        this.v = null;
        this.x();
        this.x = new com.orgzly.android.ui.c(this, bundle, this.r);
        if (com.orgzly.android.prefs.a.k((Context)this)) {
            com.orgzly.android.i.a((Context)this);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        this.getMenuInflater().inflate(2131820544, menu);
        this.a(menu);
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        android.support.v4.c.m.a((Context)this).a(this.A);
        android.support.v4.c.m.a((Context)this).a(this.B);
        if (this.r != null && this.s != null) {
            this.r.b(this.s);
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (this.s != null && this.s.a(menuItem)) {
            return true;
        }
        switch (menuItem.getItemId()) {
            default: {
                return super.onOptionsItemSelected(menuItem);
            }
            case 2131689797: {
                this.q.Z();
                return true;
            }
            case 2131689798: 
        }
        this.x.c();
        return true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (this.z != null) {
            this.z.dismiss();
            this.z = null;
        }
    }

    @Override
    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        if (this.s != null) {
            this.s.a();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (this.r != null) {
            boolean bl2 = !this.r.h(8388611);
            this.a(menu, bl2);
        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        this.C();
    }

    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
    }

    @Override
    public void p() {
        if (this.z != null) {
            this.z.dismiss();
        }
        this.z = com.orgzly.android.ui.a.d.a(this);
        this.z.setOnDismissListener(new DialogInterface.OnDismissListener(){

            public void onDismiss(DialogInterface dialogInterface) {
                MainActivity.this.z = null;
            }
        });
        this.z.show();
    }

    @Override
    public void q() {
        DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
                switch (n2) {
                    default: {
                        return;
                    }
                    case -1: 
                }
                MainActivity.this.x.e();
                MainActivity.this.q.Y();
            }
        };
        new AlertDialog.Builder((Context)this).setTitle((CharSequence)"Database").setMessage(2131230767).setPositiveButton(2131230900, onClickListener).setNegativeButton(2131230763, onClickListener).show();
    }

    @Override
    public void r() {
        com.orgzly.android.ui.a.b.a(1, "New Notebook", "Name", null, null, "Create", "Cancel", null).a(this.e(), com.orgzly.android.ui.a.b.aa);
    }

    @Override
    public void s() {
        this.a(this.getResources().getString(2131230883));
    }

    @Override
    public void t() {
    }

    @Override
    public void u() {
        this.k();
    }

    @Override
    public void v() {
        this.x.d();
    }

    @Override
    public void w() {
        this.k();
    }

}

