/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.MenuItem
 */
package com.orgzly.android.ui;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.b.r;
import android.support.v4.b.w;
import android.view.MenuItem;
import com.orgzly.android.a.c;
import com.orgzly.android.a.g;
import com.orgzly.android.a.h;
import com.orgzly.android.b.j;
import com.orgzly.android.k;
import com.orgzly.android.ui.a.b;
import com.orgzly.android.ui.b.a.a;
import com.orgzly.android.ui.b.a.b;
import com.orgzly.android.ui.b.d;
import com.orgzly.android.ui.b.f;
import com.orgzly.android.ui.b.m;
import java.io.File;

public class ReposActivity
extends com.orgzly.android.ui.b
implements b.a,
a.a,
d.a,
f.a,
m.a {
    public static final String p = ReposActivity.class.getName();
    private k q;
    private c r;

    private void a(final long l2, final String string) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                ReposActivity.this.q.a(l2, string);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    private void a(android.support.v4.b.m m2, String string) {
        this.e().a().a((String)null).a(2131689591, m2, string).a();
    }

    private void c(final long l2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                ReposActivity.this.q.f(l2);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    private void e(final String string) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                ReposActivity.this.q.c(string);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    private void p() {
        if (!this.r.a() && this.r.c()) {
            this.c(2131230857);
        }
    }

    @Override
    public void a(int n2, String object, Bundle bundle) {
        object = new File(bundle.getString("directory"), (String)object);
        if (object.mkdir()) {
            object = this.e().a(b.af);
            if (object != null) {
                ((b)object).aa();
            }
            return;
        }
        this.a(this.getResources().getString(2131230815, new Object[]{object.toString()}));
    }

    @Override
    public void a(long l2) {
        this.c(l2);
    }

    @Override
    public void a(long l2, g g2) {
        this.a(l2, g2.b().toString());
        this.k();
    }

    @Override
    public void a(g g2) {
        this.e(g2.b().toString());
        this.k();
    }

    @Override
    public void b(long l2) {
        g g2 = h.a((Context)this, com.orgzly.android.provider.b.g.b((Context)this, l2));
        if (g2 instanceof com.orgzly.android.a.d || g2 instanceof com.orgzly.android.a.f) {
            this.a(f.a(l2), f.a);
            return;
        }
        if (g2 instanceof com.orgzly.android.a.b || g2 instanceof com.orgzly.android.a.a) {
            this.a(d.a(l2), d.a);
            return;
        }
        this.c(2131230862);
    }

    @Override
    public void b(String string) {
        this.e().a().a((String)null).a(2131689591, b.c(string), b.af).a();
    }

    @Override
    public void c(String string) {
        Bundle bundle = new Bundle();
        bundle.putString("directory", string);
        com.orgzly.android.ui.a.b.a(1, "Name", null, null, null, "Create", "Cancel", bundle).a(this.e(), com.orgzly.android.ui.a.b.aa);
    }

    @Override
    public void d(int n2) {
        if (n2 == 2131689835) {
            this.a(f.a(), f.a);
            return;
        }
        if (n2 == 2131689836) {
            this.a(d.a(), d.a);
            return;
        }
        throw new IllegalArgumentException("Unknown repo menu item clicked: " + n2);
    }

    @Override
    public void d(String string) {
        ((d)this.e().a(d.a)).a(j.a("file", string));
        this.e().b();
    }

    @Override
    public void l() {
        this.k();
    }

    @Override
    public boolean m() {
        if (this.r.a()) {
            this.r.b();
            this.c(2131230858);
            return true;
        }
        this.r.a(this);
        return false;
    }

    @Override
    public boolean n() {
        return this.r.a();
    }

    @Override
    public void o() {
        this.e().b();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void onActivityResult(int n2, int n3, Intent intent) {
        switch (n2) {
            default: {
                return;
            }
            case 0: {
                if (n3 != -1) return;
                intent = intent.getData();
                if (Build.VERSION.SDK_INT >= 19) {
                    this.grantUriPermission(this.getPackageName(), (Uri)intent, 1);
                    this.getContentResolver().takePersistableUriPermission((Uri)intent, 3);
                }
                ((d)this.e().a(d.a)).a((Uri)intent);
                return;
            }
        }
    }

    @Override
    protected void onCreate(Bundle object) {
        super.onCreate((Bundle)object);
        this.setContentView(2130903068);
        this.q = new k(this.getApplicationContext());
        this.r = new c(this.getApplicationContext());
        this.g().a(true);
        this.g().a(2131230924);
        if (object == null) {
            object = m.Z();
            this.e().a().a(2131689591, (android.support.v4.b.m)object, m.i).a();
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            default: {
                return super.onOptionsItemSelected(menuItem);
            }
            case 16908332: 
        }
        com.orgzly.android.ui.c.a.a(this);
        super.onBackPressed();
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        this.p();
        com.orgzly.android.ui.c.a.a(this, m.i);
    }

}

