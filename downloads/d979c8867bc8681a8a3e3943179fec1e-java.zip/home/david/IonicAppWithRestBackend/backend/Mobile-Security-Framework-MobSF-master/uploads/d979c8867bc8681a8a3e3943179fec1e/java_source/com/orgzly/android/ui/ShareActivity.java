/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 */
package com.orgzly.android.ui;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.b.m;
import android.support.v4.b.r;
import android.support.v4.b.w;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import com.orgzly.android.b.e;
import com.orgzly.android.f;
import com.orgzly.android.h;
import com.orgzly.android.k;
import com.orgzly.android.ui.b;
import com.orgzly.android.ui.b.i;
import com.orgzly.android.ui.b.o;
import com.orgzly.android.ui.l;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;

public class ShareActivity
extends b
implements i.a,
o.b {
    public static final String p = ShareActivity.class.getName();
    private o q;
    private i r;
    private Spinner s;

    private void a(final Bundle bundle) {
        new AsyncTask<Void, Void, List<com.orgzly.android.a>>(){

            protected /* varargs */ List<com.orgzly.android.a> a(Void ... arrvoid) {
                return ShareActivity.this.m();
            }

            protected void a(List<com.orgzly.android.a> arrayAdapter) {
                arrayAdapter = new ArrayAdapter((Context)ShareActivity.this, 2130903137, arrayAdapter);
                arrayAdapter.setDropDownViewResource(2130903093);
                ShareActivity.this.s.setAdapter((SpinnerAdapter)arrayAdapter);
                if (bundle != null && bundle.containsKey("position")) {
                    ShareActivity.this.s.setSelection(bundle.getInt("position", 0));
                }
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((List)object);
            }
        }.execute((Object[])new Void[0]);
    }

    private void a(Bundle bundle, a a2) {
        if (bundle == null) {
            this.q = o.a();
            this.e().a().a(this.q, o.a).a();
            this.r = i.a(true, 0, 0, l.d, a2.a, a2.b);
            this.e().a().a(2131689593, this.r, i.a).a();
            return;
        }
        this.q = (o)this.e().a(o.a);
        this.r = (i)this.e().a(i.a);
    }

    private void b(Bundle bundle) {
        this.s = (Spinner)this.findViewById(2131689592);
        this.s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> object, View view, int n2, long l2) {
                if (ShareActivity.this.s.getSelectedItem() != null && (object = (com.orgzly.android.a)ShareActivity.this.s.getSelectedItem()) != null && ShareActivity.this.r != null) {
                    ShareActivity.this.r.a((com.orgzly.android.a)object);
                }
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private List<com.orgzly.android.a> m() {
        k k2 = new k((Context)this);
        List<com.orgzly.android.a> list = k2.a();
        if (list.size() != 0) return list;
        try {
            list.add(k2.b("Share"));
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            this.finish();
            return list;
        }
        return list;
    }

    @Override
    public void a(com.orgzly.android.a a2, IOException iOException) {
    }

    @Override
    public void a(f f2) {
    }

    @Override
    public void a(f f2, com.orgzly.android.ui.i i2) {
        this.q.a(f2, i2);
    }

    @Override
    public void a(h h2) {
    }

    @Override
    public void a(File file) {
    }

    @Override
    public void a(Exception exception) {
    }

    @Override
    public void a(String string, CharSequence charSequence, CharSequence charSequence2, int n2) {
    }

    @Override
    public void b(f f2) {
    }

    @Override
    public void b(f f2, com.orgzly.android.ui.i i2) {
        this.finish();
    }

    @Override
    public void b(Exception exception) {
    }

    @Override
    public void b(String string) {
    }

    @Override
    public void b(Set<Long> set, com.orgzly.a.a.a a2) {
    }

    @Override
    public void b(Set<Long> set, String string) {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public a c(Intent intent) {
        a a2 = new a();
        String string = intent.getAction();
        String string2 = intent.getType();
        if (string == null) {
            a2.a = this.getString(2131230940);
        } else if (string2 == null) {
            a2.a = this.getString(2131230942);
        } else if (string.equals("android.intent.action.SEND")) {
            if (string2.startsWith("text/")) {
                if (intent.hasExtra("android.intent.extra.TEXT")) {
                    a2.a = intent.getStringExtra("android.intent.extra.TEXT");
                } else if (intent.hasExtra("android.intent.extra.STREAM")) {
                    Uri uri = (Uri)intent.getParcelableExtra("android.intent.extra.STREAM");
                    a2.a = uri.getLastPathSegment();
                    try {
                        File file = new File(uri.getPath());
                        if (file.length() > 0x200000) {
                            a2.b = "File has " + file.length() + " bytes (refusing to read files larger then " + 0x200000 + " bytes)";
                        }
                        a2.b = e.a(file);
                    }
                    catch (IOException var6_7) {
                        var6_7.printStackTrace();
                        a2.b = "Failed reading the content of " + uri.toString() + ": " + var6_7.toString();
                    }
                }
                if (a2.a != null && a2.b == null && intent.hasExtra("android.intent.extra.SUBJECT")) {
                    a2.b = a2.a;
                    a2.a = intent.getStringExtra("android.intent.extra.SUBJECT");
                }
            } else {
                a2.a = this.getString(2131230943, new Object[]{string2});
            }
        } else if (string.equals("com.google.android.gm.action.AUTO_SEND")) {
            if (string2.startsWith("text/") && intent.hasExtra("android.intent.extra.TEXT")) {
                a2.a = intent.getStringExtra("android.intent.extra.TEXT");
            }
        } else {
            a2.a = this.getString(2131230941, new Object[]{string});
        }
        if (a2.a == null) {
            a2.a = "No text (type " + string2 + " action " + string + ")";
        }
        return a2;
    }

    @Override
    public void c(com.orgzly.android.a a2) {
    }

    @Override
    public void c(f f2) {
    }

    @Override
    public void c(Exception exception) {
    }

    @Override
    public void d(int n2) {
    }

    @Override
    public void d(com.orgzly.android.a a2) {
    }

    @Override
    public void d(f f2) {
        this.finish();
    }

    @Override
    public void d(Exception exception) {
    }

    @Override
    public void e(int n2) {
    }

    @Override
    public void e(com.orgzly.android.a a2) {
    }

    @Override
    public void e(f f2) {
    }

    @Override
    public void f(com.orgzly.android.a a2) {
    }

    @Override
    public void l() {
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130903069);
        this.g().a(2131230871);
        com.orgzly.android.ui.c.a.a(this, null);
        this.a(bundle, this.c(this.getIntent()));
        this.b(bundle);
        this.a(bundle);
    }

    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (this.s != null && this.s.getSelectedItem() != null) {
            bundle.putInt("position", this.s.getSelectedItemPosition());
        }
    }

    @Override
    public void s() {
    }

    @Override
    public void t() {
    }

    private class a {
        String a;
        String b;

        private a() {
        }
    }

}

