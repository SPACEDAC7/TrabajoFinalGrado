/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.ui;

import android.support.v7.view.b;
import com.orgzly.android.ui.m;

public interface a {
    public void a(m var1, b.a var2);

    public b b();

    public void c();
}

