/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.NumberPicker
 *  android.widget.NumberPicker$OnValueChangeListener
 *  android.widget.TextView
 *  android.widget.TimePicker
 *  android.widget.TimePicker$OnTimeChangedListener
 */
package com.orgzly.android.ui.a;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.d;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;
import com.orgzly.a.a.c;
import com.orgzly.a.a.e;

public class a
extends d
implements DialogInterface.OnClickListener,
TimePicker.OnTimeChangedListener {
    private final NumberPicker b;
    private final NumberPicker c;
    private final NumberPicker d;
    private final TextView e;
    private final a f;

    public a(Context context, int n2, a arrstring, String string) {
        super(context);
        this.f = arrstring;
        arrstring = this.getContext();
        context = LayoutInflater.from((Context)arrstring).inflate(2130903087, null);
        this.a((View)context);
        this.a(-1, arrstring.getString(2131230900), this);
        this.a(-2, arrstring.getString(2131230763), this);
        arrstring = this.getContext().getResources().getStringArray(2131623955);
        String[] arrstring2 = this.getContext().getResources().getStringArray(2131623959);
        this.b = (NumberPicker)context.findViewById(2131689617);
        this.b.setMinValue(0);
        this.b.setMaxValue(arrstring.length - 1);
        this.b.setDisplayedValues(arrstring);
        this.b.setOnValueChangedListener(new NumberPicker.OnValueChangeListener(){

            public void onValueChange(NumberPicker numberPicker, int n2, int n3) {
                a.this.b(n3);
            }
        });
        this.c = (NumberPicker)context.findViewById(2131689618);
        this.c.setMinValue(1);
        this.c.setMaxValue(100);
        this.c.setWrapSelectorWheel(false);
        this.d = (NumberPicker)context.findViewById(2131689619);
        this.d.setMinValue(0);
        this.d.setMaxValue(arrstring2.length - 1);
        this.d.setDisplayedValues(arrstring2);
        this.d.setWrapSelectorWheel(false);
        this.e = (TextView)context.findViewById(2131689616);
        this.a(string);
        this.setTitle(2131230916);
    }

    public a(Context context, a a2, String string) {
        this(context, 0, a2, string);
    }

    private void a(String object) {
        object = e.a((String)object);
        this.b.setValue(object.a().ordinal());
        if (this.c.getMaxValue() < object.b()) {
            this.c.setMaxValue(object.b());
            this.c.setWrapSelectorWheel(false);
        }
        this.c.setValue(object.b());
        this.d.setValue(object.c().ordinal());
        this.b(this.b.getValue());
    }

    /*
     * Enabled aggressive block sorting
     */
    private e b() {
        c.a a2;
        e.a a3;
        switch (this.b.getValue()) {
            default: {
                throw new IllegalArgumentException("Unexpected spinner position for current repeater type: " + this.b.getValue());
            }
            case 0: {
                a3 = e.a.a;
                break;
            }
            case 1: {
                a3 = e.a.b;
                break;
            }
            case 2: {
                a3 = e.a.c;
            }
        }
        int n2 = this.c.getValue();
        switch (this.d.getValue()) {
            default: {
                throw new IllegalArgumentException("Unexpected spinner position for current repeater unit: " + this.b.getValue());
            }
            case 0: {
                a2 = c.a.a;
                return e.a(a3, n2, a2);
            }
            case 1: {
                a2 = c.a.b;
                return e.a(a3, n2, a2);
            }
            case 2: {
                a2 = c.a.c;
                return e.a(a3, n2, a2);
            }
            case 3: {
                a2 = c.a.d;
                return e.a(a3, n2, a2);
            }
            case 4: 
        }
        a2 = c.a.e;
        return e.a(a3, n2, a2);
    }

    private void b(int n2) {
        this.e.setText((CharSequence)this.getContext().getResources().getStringArray(2131623956)[n2]);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onClick(DialogInterface object, int n2) {
        switch (n2) {
            case -1: {
                if (this.f != null) {
                    object = this.b();
                    this.f.a((e)object);
                    return;
                }
            }
            default: {
                return;
            }
            case -2: 
        }
        this.cancel();
    }

    public void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.b.setValue(bundle.getInt("type"));
        this.c.setValue(bundle.getInt("value"));
        this.d.setValue(bundle.getInt("unit"));
    }

    public Bundle onSaveInstanceState() {
        Bundle bundle = super.onSaveInstanceState();
        bundle.putInt("type", this.b.getValue());
        bundle.putInt("value", this.c.getValue());
        bundle.putInt("unit", this.d.getValue());
        return bundle;
    }

    public void onTimeChanged(TimePicker timePicker, int n2, int n3) {
    }

    public static interface a {
        public void a(e var1);
    }

}

