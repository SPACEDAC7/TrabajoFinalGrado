/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.os.Bundle
 *  android.text.Editable
 *  android.text.TextUtils
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.TextView
 *  android.widget.TextView$OnEditorActionListener
 */
package com.orgzly.android.ui.a;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.b.l;
import android.support.v4.b.n;
import android.text.Editable;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class b
extends l {
    public static final String aa = b.class.getName();
    private a ab;
    private int ac;
    private String ad;
    private String ae;
    private String af;
    private String ag;
    private String ah;
    private String ai;
    private Bundle aj;

    public static b a(int n2, String string, String string2, String string3, String string4, String string5, String string6, Bundle bundle) {
        b b2 = new b();
        Bundle bundle2 = new Bundle();
        if (string != null) {
            bundle2.putString("title", string);
        }
        if (string2 != null) {
            bundle2.putString("hint", string2);
        }
        if (string3 != null) {
            bundle2.putString("value", string3);
        }
        if (string4 != null) {
            bundle2.putString("description", string4);
        }
        bundle2.putInt("id", n2);
        if (bundle != null) {
            bundle2.putBundle("bundle", bundle);
        }
        bundle2.putString("pos", string5);
        bundle2.putString("neg", string6);
        b2.g(bundle2);
        return b2;
    }

    @Override
    public void a(Context object) {
        super.a((Context)object);
        object = this.j();
        try {
            this.ab = (a)object;
        }
        catch (ClassCastException var2_2) {
            throw new ClassCastException(object.toString() + " must implement " + a.class);
        }
        if (this.g() == null || !this.g().containsKey("title")) {
            throw new IllegalArgumentException(b.class.getSimpleName() + " must have title passed as an argument");
        }
        this.ac = this.g().getInt("id");
        this.ad = this.g().getString("title");
        this.ae = this.g().getString("hint");
        this.af = this.g().getString("value");
        this.ag = this.g().getString("description");
        this.aj = this.g().getBundle("bundle");
        this.ah = this.g().getString("pos");
        this.ai = this.g().getString("neg");
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Dialog c(Bundle bundle) {
        View view = this.j().getLayoutInflater().inflate(2130903088, null, false);
        bundle = (EditText)view.findViewById(2131689621);
        if (this.ae != null) {
            bundle.setHint((CharSequence)this.ae);
        }
        if (this.af != null) {
            bundle.setText((CharSequence)this.af);
        }
        TextView textView = (TextView)view.findViewById(2131689622);
        if (this.ag != null) {
            textView.setText((CharSequence)this.ag);
            textView.setVisibility(0);
        } else {
            textView.setVisibility(8);
        }
        view = new AlertDialog.Builder((Context)this.j()).setTitle((CharSequence)this.ad).setView(view).setPositiveButton((CharSequence)this.ah, new DialogInterface.OnClickListener((EditText)bundle){
            final /* synthetic */ EditText a;

            public void onClick(DialogInterface dialogInterface, int n2) {
                if (!TextUtils.isEmpty((CharSequence)this.a.getText())) {
                    b.this.ab.a(b.this.ac, this.a.getText().toString().trim(), b.this.aj);
                }
                com.orgzly.android.ui.c.a.a(b.this.j());
            }
        }).setNegativeButton((CharSequence)this.ai, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
                com.orgzly.android.ui.c.a.a(b.this.j());
            }
        }).create();
        bundle.setOnEditorActionListener(new TextView.OnEditorActionListener((AlertDialog)view){
            final /* synthetic */ AlertDialog a;

            public boolean onEditorAction(TextView textView, int n2, KeyEvent keyEvent) {
                this.a.getButton(-1).performClick();
                return true;
            }
        });
        com.orgzly.android.ui.c.a.a(this.j(), (View)bundle);
        return view;
    }

    public static interface a {
        public void a(int var1, String var2, Bundle var3);
    }

}

