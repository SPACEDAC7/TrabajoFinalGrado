/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.DatePickerDialog
 *  android.app.DatePickerDialog$OnDateSetListener
 *  android.app.Dialog
 *  android.app.TimePickerDialog
 *  android.app.TimePickerDialog$OnTimeSetListener
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.DatePicker
 *  android.widget.TimePicker
 */
package com.orgzly.android.ui.a;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.b.l;
import android.support.v4.b.m;
import android.support.v4.b.n;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.TimePicker;
import com.orgzly.a.a.a;
import com.orgzly.a.a.e;
import com.orgzly.android.b.g;
import com.orgzly.android.ui.a.a;
import java.util.Calendar;
import java.util.Iterator;
import java.util.TreeSet;

public class c
extends l {
    public static final String aa;
    private static final String ab;
    private TimePickerDialog aA;
    private AlertDialog ac;
    private int ad;
    private TreeSet<Long> ae;
    private a af;
    private Context ag;
    private g ah;
    private CompoundButton ai;
    private Button aj;
    private Button ak;
    private CompoundButton al;
    private Button am;
    private CompoundButton an;
    private Button ao;
    private CompoundButton ap;
    private int aq;
    private int ar;
    private int as;
    private int at;
    private int au;
    private int av;
    private int aw;
    private DatePickerDialog ax;
    private TimePickerDialog ay;
    private com.orgzly.android.ui.a.a az;

    static {
        ab = c.class.getName();
        aa = c.class.getName();
    }

    private void Y() {
        this.aj.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                c.this.ax = new DatePickerDialog(c.this.ag, new DatePickerDialog.OnDateSetListener(){

                    public void onDateSet(DatePicker datePicker, int n2, int n3, int n4) {
                        c.this.aq = n2;
                        c.this.ar = n3;
                        c.this.as = n4;
                        c.this.ab();
                    }
                }, c.this.aq, c.this.ar, c.this.as);
                c.this.ax.show();
            }

        });
        this.ak.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                c.this.ay = new TimePickerDialog(c.this.ag, new TimePickerDialog.OnTimeSetListener(){

                    public void onTimeSet(TimePicker timePicker, int n2, int n3) {
                        c.this.at = n2;
                        c.this.au = n3;
                        c.this.al.setChecked(true);
                        c.this.ab();
                    }
                }, c.this.at, c.this.au, true);
                c.this.ay.show();
            }

        });
        this.am.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                c.this.az = new com.orgzly.android.ui.a.a(c.this.ag, new a.a(){

                    @Override
                    public void a(e e2) {
                        c.this.am.setText((CharSequence)e2.toString());
                        c.this.an.setChecked(true);
                        c.this.ab();
                    }
                }, c.this.am.getText().toString());
                c.this.az.show();
            }

        });
        this.ao.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                c.this.aA = new TimePickerDialog(c.this.ag, new TimePickerDialog.OnTimeSetListener(){

                    public void onTimeSet(TimePicker timePicker, int n2, int n3) {
                        c.this.av = n2;
                        c.this.aw = n3;
                        c.this.ap.setChecked(true);
                        c.this.ab();
                    }
                }, c.this.av, c.this.aw, true);
                c.this.aA.show();
            }

        });
    }

    private void Z() {
        this.ai.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl2) {
                c.this.ab();
            }
        });
        this.al.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl2) {
                c.this.ab();
            }
        });
        this.ap.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl2) {
                c.this.ab();
            }
        });
        this.an.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl2) {
                c.this.ab();
            }
        });
    }

    public static c a(int n2, int n3, long l2, com.orgzly.a.a.a a2) {
        TreeSet<Long> treeSet = new TreeSet<Long>();
        treeSet.add(l2);
        return c.a(n2, n3, treeSet, a2);
    }

    public static c a(int n2, int n3, TreeSet<Long> treeSet, com.orgzly.a.a.a a2) {
        c c2 = new c();
        Bundle bundle = new Bundle();
        bundle.putInt("id", n2);
        bundle.putInt("title", n3);
        bundle.putLongArray("note_ids", c.a(treeSet));
        if (a2 != null) {
            bundle.putString("time", a2.toString());
        }
        c2.g(bundle);
        return c2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(com.orgzly.a.a.a a2) {
        boolean bl2 = true;
        Calendar calendar = a2 != null ? a2.a() : Calendar.getInstance();
        CompoundButton compoundButton = this.ai;
        boolean bl3 = a2 == null || a2.b();
        compoundButton.setChecked(bl3);
        this.aq = calendar.get(1);
        this.ar = calendar.get(2);
        this.as = calendar.get(5);
        compoundButton = this.al;
        bl3 = a2 != null && a2.c() ? bl2 : false;
        compoundButton.setChecked(bl3);
        this.at = calendar.get(11);
        this.au = calendar.get(12);
        this.ap.setChecked(false);
        this.av = calendar.get(11);
        this.aw = calendar.get(12);
        if (a2 != null) {
            this.an.setChecked(a2.f());
            if (a2.f()) {
                this.am.setText((CharSequence)a2.g().toString());
            }
        }
    }

    private static long[] a(TreeSet<Long> object) {
        long[] arrl = new long[object.size()];
        object = object.iterator();
        int n2 = 0;
        while (object.hasNext()) {
            arrl[n2] = (Long)object.next();
            ++n2;
        }
        return arrl;
    }

    private com.orgzly.a.a.a aa() {
        a.a a2 = new a.a().a(this.ai.isChecked()).a(this.aq).b(this.ar).b(this.al.isChecked()).c(this.as).d(this.at).e(this.au);
        if (this.an.isChecked()) {
            e e2 = e.a(this.am.getText().toString());
            a2.c(true);
            a2.a(e2);
        }
        return a2.a();
    }

    private void ab() {
        if (this.ac != null) {
            com.orgzly.a.a.a a2 = this.aa();
            this.aj.setText((CharSequence)this.ah.b(a2));
            this.ak.setText((CharSequence)this.ah.c(a2));
            if (a2.f()) {
                this.am.setText((CharSequence)this.ah.d(a2));
            }
            this.ac.setTitle((CharSequence)this.ah.a(a2));
        }
    }

    private void c(View view) {
        view.findViewById(2131689626).setOnClickListener(new View.OnClickListener(){

            public void onClick(View object) {
                object = Calendar.getInstance();
                c.this.aq = object.get(1);
                c.this.ar = object.get(2);
                c.this.as = object.get(5);
                c.this.ab();
            }
        });
        view.findViewById(2131689625).setOnClickListener(new View.OnClickListener(){

            public void onClick(View object) {
                object = Calendar.getInstance();
                object.add(5, 1);
                c.this.aq = object.get(1);
                c.this.ar = object.get(2);
                c.this.as = object.get(5);
                c.this.ab();
            }
        });
        view.findViewById(2131689627).setOnClickListener(new View.OnClickListener(){

            public void onClick(View object) {
                object = Calendar.getInstance();
                object.set(7, object.getFirstDayOfWeek());
                object.add(5, 7);
                c.this.aq = object.get(1);
                c.this.ar = object.get(2);
                c.this.as = object.get(5);
                c.this.ab();
            }
        });
    }

    private void m(Bundle bundle) {
        if (bundle != null) {
            this.aq = bundle.getInt("year");
            this.ar = bundle.getInt("month");
            this.as = bundle.getInt("day");
            this.al.setChecked(bundle.getBoolean("use_time"));
            this.at = bundle.getInt("hour");
            this.au = bundle.getInt("minute");
            this.an.setChecked(bundle.getBoolean("use_repeat"));
            this.ai.setChecked(bundle.getBoolean("is_active"));
            this.ap.setChecked(bundle.getBoolean("use_end_time"));
            this.av = bundle.getInt("end_time_hour");
            this.aw = bundle.getInt("end_time_minute");
        }
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
    }

    @Override
    public Dialog c(Bundle bundle) {
        this.ah = new g((Context)this.j());
        if (!(this.h() instanceof a)) {
            throw new IllegalStateException("Fragment " + this.h() + " must implement " + a.class);
        }
        this.af = (a)((Object)this.h());
        this.ag = this.j();
        this.ad = this.g().getInt("id");
        this.ae = new TreeSet();
        for (long l2 : this.g().getLongArray("note_ids")) {
            this.ae.add(l2);
        }
        View view = ((LayoutInflater)this.j().getSystemService("layout_inflater")).inflate(2130903090, null, false);
        this.ai = (CompoundButton)view.findViewById(2131689636);
        this.aj = (Button)view.findViewById(2131689628);
        this.ak = (Button)view.findViewById(2131689629);
        this.al = (CompoundButton)view.findViewById(2131689630);
        this.am = (Button)view.findViewById(2131689633);
        this.an = (CompoundButton)view.findViewById(2131689634);
        this.ao = (Button)view.findViewById(2131689631);
        this.ap = (CompoundButton)view.findViewById(2131689632);
        view.findViewById(2131689635).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                c.this.ai.toggle();
            }
        });
        this.a(com.orgzly.a.a.a.b(this.g().getString("time")));
        this.ac = new AlertDialog.Builder(this.ag).setTitle(this.g().getInt("title")).setView(view).setPositiveButton((CharSequence)"Set", new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface object, int n2) {
                if (c.this.af != null) {
                    object = c.this.aa();
                    c.this.af.a(c.this.ad, c.this.ae, (com.orgzly.a.a.a)object);
                }
            }
        }).setNeutralButton((CharSequence)"Clear", new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
                if (c.this.af != null) {
                    c.this.af.a(c.this.ad, c.this.ae);
                }
            }
        }).setNegativeButton((CharSequence)"Cancel", new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
                if (c.this.af != null) {
                    c.this.af.b(c.this.ad, c.this.ae);
                }
            }
        }).create();
        this.c(view);
        this.Y();
        this.Z();
        this.m(bundle);
        this.ab();
        return this.ac;
    }

    @Override
    public void e(Bundle bundle) {
        super.e(bundle);
        bundle.putInt("year", this.aq);
        bundle.putInt("month", this.ar);
        bundle.putInt("day", this.as);
        bundle.putBoolean("use_time", this.al.isChecked());
        bundle.putInt("hour", this.at);
        bundle.putInt("minute", this.au);
        bundle.putBoolean("use_repeat", this.an.isChecked());
        bundle.putBoolean("is_active", this.ai.isChecked());
        bundle.putBoolean("use_end_time", this.ap.isChecked());
        bundle.putInt("end_time_hour", this.av);
        bundle.putInt("end_time_minute", this.aw);
    }

    @Override
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
    }

    public static interface a {
        public void a(int var1, TreeSet<Long> var2);

        public void a(int var1, TreeSet<Long> var2, com.orgzly.a.a.a var3);

        public void b(int var1, TreeSet<Long> var2);
    }

}

