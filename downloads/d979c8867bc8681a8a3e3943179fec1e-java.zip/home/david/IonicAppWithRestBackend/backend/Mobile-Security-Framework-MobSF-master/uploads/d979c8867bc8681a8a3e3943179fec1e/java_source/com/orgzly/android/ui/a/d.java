/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.Html
 *  android.text.Spanned
 *  android.text.method.LinkMovementMethod
 *  android.text.method.MovementMethod
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.TextView
 */
package com.orgzly.android.ui.a;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class d {
    public static AlertDialog a(Activity activity) {
        View view = activity.getLayoutInflater().inflate(2130903091, null, false);
        TextView textView = (TextView)view.findViewById(2131689637);
        textView.setText((CharSequence)d.a(activity.getString(2131230963)));
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView = (TextView)view.findViewById(2131689638);
        textView.setText((CharSequence)d.a(activity.getString(2131230962)));
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        return new AlertDialog.Builder((Context)activity).setTitle(2131230964).setPositiveButton(2131230900, null).setView(view).create();
    }

    private static Spanned a(String string) {
        if (Build.VERSION.SDK_INT >= 24) {
            return Html.fromHtml((String)string, (int)0);
        }
        return Html.fromHtml((String)string);
    }
}

