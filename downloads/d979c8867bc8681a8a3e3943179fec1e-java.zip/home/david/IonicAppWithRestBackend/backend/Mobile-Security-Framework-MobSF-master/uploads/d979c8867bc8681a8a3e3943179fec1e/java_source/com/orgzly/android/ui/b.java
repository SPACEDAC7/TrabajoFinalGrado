/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.Window
 */
package com.orgzly.android.ui;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.b.r;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.e;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import com.orgzly.a;

public class b
extends e {
    private static final String p = b.class.getName();
    protected Snackbar n;
    protected Runnable o;

    private void l() {
        if (this.n != null) {
            this.n.d();
            this.n = null;
        }
    }

    private int m() {
        TypedArray typedArray = this.obtainStyledAttributes(a.a.ColorScheme);
        int n2 = typedArray.getColor(26, 0);
        typedArray.recycle();
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void n() {
        if (Build.VERSION.SDK_INT >= 17) {
            String string = com.orgzly.android.prefs.a.m((Context)this);
            int n2 = 3;
            if (this.getString(2131231112).equals(string)) {
                n2 = 0;
            } else if (this.getString(2131231113).equals(string)) {
                n2 = 1;
            }
            this.getWindow().getDecorView().setLayoutDirection(n2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void o() {
        String string = com.orgzly.android.prefs.a.l((Context)this);
        if (this.getString(2131231106).equals(string)) {
            this.setTheme(2131361961);
        } else if (this.getString(2131231105).equals(string)) {
            this.setTheme(2131361960);
        } else {
            this.setTheme(2131361963);
        }
        string = com.orgzly.android.prefs.a.o((Context)this);
        if (this.getString(2131231109).equals(string)) {
            this.getTheme().applyStyle(2131362018, true);
            return;
        } else {
            if (!this.getString(2131231110).equals(string)) return;
            {
                this.getTheme().applyStyle(2131362019, true);
                return;
            }
        }
    }

    public void a(Snackbar snackbar) {
        this.l();
        DrawerLayout drawerLayout = (DrawerLayout)this.findViewById(2131689587);
        if (drawerLayout != null) {
            drawerLayout.f(8388611);
        }
        this.n = snackbar;
        int n2 = this.m();
        this.n.b().setBackgroundColor(n2);
        this.n.c();
    }

    public void a(String string) {
        View view = this.findViewById(2131689588);
        if (view != null) {
            this.a(Snackbar.a(view, string, 0));
        }
    }

    public void c(int n2) {
        this.a(this.getString(n2));
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        boolean bl2 = super.dispatchTouchEvent(motionEvent);
        if (motionEvent.getAction() == 1) {
            this.l();
        }
        return bl2;
    }

    public void k() {
        this.e().b();
        com.orgzly.android.ui.c.a.a(this);
    }

    @Override
    protected void onCreate(Bundle bundle) {
        this.o();
        this.n();
        super.onCreate(bundle);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void onRequestPermissionsResult(int n2, String[] arrstring, int[] arrn) {
        switch (n2) {
            default: {
                return;
            }
            case 2: {
                if (arrn.length <= 0 || arrn[0] != 0 || this.o == null) return;
                this.o.run();
                this.o = null;
                return;
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}

