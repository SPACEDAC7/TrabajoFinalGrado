/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.database.Cursor
 *  android.graphics.Typeface
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.SystemClock
 *  android.text.TextUtils
 *  android.text.TextUtils$TruncateAt
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.MotionEvent
 *  android.view.SubMenu
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemLongClickListener
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.Spinner
 *  android.widget.TextView
 *  android.widget.ViewFlipper
 */
package com.orgzly.android.ui.b;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.b.aa;
import android.support.v4.b.n;
import android.support.v4.widget.x;
import android.support.v7.view.b;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ViewFlipper;
import com.orgzly.android.k;
import com.orgzly.android.provider.e;
import com.orgzly.android.ui.a.c;
import com.orgzly.android.ui.b.j;
import com.orgzly.android.ui.d;
import com.orgzly.android.ui.f;
import com.orgzly.android.ui.i;
import com.orgzly.android.ui.l;
import com.orgzly.android.ui.m;
import com.orgzly.android.ui.views.GesturedListView;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class a
extends j
implements aa.a<Cursor>,
c.a,
d {
    private static final String ad = a.class.getName();
    private static final int[] ae;
    private static long aj;
    public static final String i;
    private a af;
    private boolean ag = false;
    private com.orgzly.android.a ah;
    private Long ai;
    private View ak;
    private TextView al;
    private View am;
    private x an;
    private String ao;
    private ViewFlipper ap;

    static {
        i = a.class.getName();
        ae = new int[]{2131689801, 2131689809, 2131689810, 2131689808};
    }

    public static a a(long l2, long l3) {
        a a2 = new a();
        Bundle bundle = new Bundle();
        bundle.putLong("bookId", l2);
        bundle.putLong("noteId", l3);
        a2.g(bundle);
        return a2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(Cursor object) {
        this.an.b((Cursor)object);
        if (this.an.getCount() > 0) {
            this.am.setVisibility(8);
        } else {
            this.am.setVisibility(0);
        }
        if (this.ac != null) {
            this.ac.a(this.ab, new b());
            object = this.ac.b();
            if (this.ao != null) {
                object.a((Object)"M");
                object.d();
                this.ao = null;
            }
        }
        this.ah();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(com.orgzly.android.a a2) {
        this.ah = a2;
        n n2 = this.j();
        if (n2 != null) {
            n2.c_();
        }
        if (this.ah != null) {
            this.aj();
        }
        n2 = this.ap;
        int n3 = a2 != null ? 0 : 1;
        n2.setDisplayedChild(n3);
        this.ai();
    }

    @Override
    private void a(final TreeSet<Long> treeSet) {
        new AlertDialog.Builder(this.i()).setTitle(2131230999).setMessage(2131231000).setPositiveButton(2131230787, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
                a.this.af.a((long)a.this.ai, treeSet);
            }
        }).setNegativeButton(2131230763, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
            }
        }).create().show();
    }

    private void ag() {
        if (this.g() == null) {
            throw new IllegalArgumentException("No arguments found to " + a.class.getSimpleName());
        }
        if (!this.g().containsKey("bookId")) {
            throw new IllegalArgumentException(a.class.getSimpleName() + " requires " + "bookId" + " argument passed");
        }
        this.ai = this.g().getLong("bookId");
        if (this.ai <= 0) {
            throw new IllegalArgumentException("Passed argument book id is not valid (" + this.ai + ")");
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void ah() {
        long l2 = this.g().getLong("noteId", 0);
        if (l2 <= 0) return;
        System.currentTimeMillis();
        int n2 = 0;
        while (n2 < this.af().getCount()) {
            if (this.af().getItemId(n2) == l2) {
                this.e(n2);
                this.g().remove("noteId");
                return;
            }
            ++n2;
        }
    }

    private void ai() {
        if (this.af != null) {
            this.af.a(i, com.orgzly.android.a.a(this.ah), com.orgzly.android.a.b(this.ah), this.ab.a());
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void aj() {
        boolean bl2 = !this.a(2131231121).equals(com.orgzly.android.prefs.a.d(this.i()));
        if (!TextUtils.isEmpty((CharSequence)this.ah.b()) && bl2) {
            if (this.ae().getHeaderViewsCount() == 0) {
                this.ae().addHeaderView(this.ak);
            }
            if (this.a(2131231119).equals(com.orgzly.android.prefs.a.d(this.i()))) {
                this.al.setMaxLines(3);
                this.al.setEllipsize(TextUtils.TruncateAt.END);
            } else {
                this.al.setMaxLines(Integer.MAX_VALUE);
                this.al.setEllipsize(null);
            }
            this.al.setText((CharSequence)this.ah.b());
            return;
        } else {
            if (this.ae().getHeaderViewsCount() <= 0) return;
            {
                this.ae().removeHeaderView(this.ak);
                return;
            }
        }
    }

    private void b(l l2) {
        long l3 = this.a(l2);
        this.af.a(new i(this.ai, l3, l2));
    }

    private void c(l l2) {
        long l3 = this.a(l2);
        this.ab.c();
        this.af.a(this.ai, l3, l2);
    }

    private int d(int n2) {
        if (this.ad().a() == 0) {
            Log.e((String)ad, (String)"Trying to move notes up while there are no notes selected");
            return 0;
        }
        return com.orgzly.android.provider.b.a.a(this.i(), (long)this.ai, this.ad().b().first(), n2);
    }

    private void e(final int n2) {
        this.ae().post(new Runnable(){

            @Override
            public void run() {
                a.this.ae().setSelection(n2 + a.this.ae().getHeaderViewsCount());
            }
        });
    }

    public com.orgzly.android.a Z() {
        return this.ah;
    }

    @Override
    public android.support.v4.c.l<Cursor> a(int n2, Bundle bundle) {
        switch (n2) {
            default: {
                throw new IllegalArgumentException("Unknown loader id " + n2);
            }
            case 0: {
                return new android.support.v4.c.i(this.j().getApplicationContext(), e.b.a.a(this.ai), null, null, null, null);
            }
            case 1: 
        }
        return new android.support.v4.c.i(this.j().getApplicationContext(), e.b.a.b(this.ai), null, null, null, "is_visible");
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        viewGroup = layoutInflater.inflate(2130903094, viewGroup, false);
        this.ak = layoutInflater.inflate(2130903112, (ViewGroup)((ListView)viewGroup.findViewById(16908298)), false);
        this.al = (TextView)this.ak.findViewById(2131689744);
        if (this.j() != null && com.orgzly.android.prefs.a.e(this.i())) {
            this.al.setTypeface(Typeface.MONOSPACE);
        }
        this.ap = (ViewFlipper)viewGroup.findViewById(2131689643);
        this.am = viewGroup.findViewById(2131689645);
        return viewGroup;
    }

    @Override
    public Runnable a() {
        if (this.ah != null) {
            return new Runnable(){

                @Override
                public void run() {
                    a.this.af.a(new i(a.this.ai));
                }
            };
        }
        return null;
    }

    @Override
    public void a(int n2, TreeSet<Long> treeSet) {
        switch (n2) {
            default: {
                return;
            }
            case 2131689746: 
            case 2131689806: 
        }
        this.af.a(treeSet, (com.orgzly.a.a.a)null);
    }

    @Override
    public void a(int n2, TreeSet<Long> treeSet, com.orgzly.a.a.a a2) {
        switch (n2) {
            default: {
                return;
            }
            case 2131689746: 
            case 2131689806: 
        }
        this.af.a(treeSet, a2);
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.af = (a)((Object)this.j());
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + a.class);
        }
        try {
            this.ac = (com.orgzly.android.ui.a)((Object)this.j());
            return;
        }
        catch (ClassCastException var1_3) {
            throw new ClassCastException(this.j().toString() + " must implement " + com.orgzly.android.ui.a.class);
        }
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.d(true);
        this.ag();
        if (bundle != null && bundle.getBoolean("actionModeMove", false)) {
            this.ao = "M";
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(android.support.v4.c.l<Cursor> l2) {
        if (!this.ag) return;
        {
            if (l2.n() == 1) {
                this.an.a((Cursor)null);
                return;
            } else {
                if (l2.n() != 0) return;
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(android.support.v4.c.l<Cursor> object, Cursor cursor) {
        if (!this.ag) return;
        {
            if (object.n() == 0) {
                object = null;
                if (cursor.moveToFirst()) {
                    object = com.orgzly.android.provider.b.a.a(cursor);
                }
                this.a((com.orgzly.android.a)object);
                aj = this.ai;
                return;
            } else {
                if (object.n() != 1) return;
                {
                    this.a(cursor);
                    return;
                }
            }
        }
    }

    @Override
    public void a(Menu menu) {
        super.a(menu);
        if (this.ah == null) {
            MenuItem menuItem = menu.findItem(2131689799);
            if (menuItem != null) {
                menuItem.setVisible(false);
            }
            if ((menu = menu.findItem(2131689800)) != null) {
                menu.setVisible(false);
            }
        }
    }

    @Override
    public void a(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(2131820545, menu);
    }

    @Override
    public void a(View view, Bundle bundle) {
        super.a(view, bundle);
        this.ag = true;
        this.ae().setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){

            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int n2, long l2) {
                if (n2 > a.this.ae().getHeaderViewsCount() - 1) {
                    a.this.af.b(a.this, view, n2, l2);
                    return true;
                }
                return false;
            }
        });
        this.ae().setOnItemMenuButtonClickListener(new GesturedListView.b(){

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Override
            public boolean a(int var1_1, long var2_2) {
                switch (var1_1) {
                    case 2131689746: {
                        a.this.a(2131689746, var2_2);
                        ** break;
                    }
                    case 2131689747: {
                        a.a(a.this).a(var2_2, -1);
                        ** break;
                    }
                    case 2131689748: {
                        a.a(a.this).a(var2_2, 1);
                        ** break;
                    }
                    case 2131689749: {
                        a.a(a.this).b(var2_2);
                        ** break;
                    }
                    case 2131689750: {
                        var4_3 = new TreeSet<Long>();
                        var4_3.add(var2_2);
                        a.a(a.this, var4_3);
                        a.this.ab.c();
                        ** break;
                    }
                    case 2131689751: {
                        a.a(a.this).a(new i(a.b(a.this), var2_2, l.a));
                        ** break;
                    }
                    case 2131689752: {
                        a.a(a.this).a(new i(a.b(a.this), var2_2, l.b));
                    }
lbl25: // 8 sources:
                    default: {
                        return false;
                    }
                    case 2131689753: 
                }
                a.a(a.this).a(new i(a.b(a.this), var2_2, l.c));
                return false;
            }
        });
        this.a(null);
        this.ae().addHeaderView(this.ak, (Object)null, true);
        this.ab = new m();
        this.an = new f((Context)this.j(), this.ab, this.ae().getItemMenus(), true);
        this.a((ListAdapter)this.an);
        this.ab.b(bundle);
    }

    @Override
    public void a(ListView listView, View view, int n2, long l2) {
        if (n2 + 1 > listView.getHeaderViewsCount()) {
            this.af.a(this, view, n2, l2);
            return;
        }
        this.af.b(this.ah);
    }

    @Override
    public boolean a(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            default: {
                return super.a(menuItem);
            }
            case 2131689799: {
                this.af.a(this.ah);
                return true;
            }
            case 2131689800: 
        }
        this.af.b(this.ah);
        return true;
    }

    @Override
    public String aa() {
        return i;
    }

    @Override
    public b.a ab() {
        return new b();
    }

    @Override
    public void b() {
        super.b();
        this.af = null;
        this.ac = null;
    }

    @Override
    public void b(int n2, TreeSet<Long> treeSet) {
    }

    @Override
    public void d(Bundle bundle) {
        super.d(bundle);
        this.aa = new k(this.j().getApplicationContext());
        if (aj == this.ai) {
            this.j().f().a(0, null, this);
            this.j().f().a(1, null, this);
            return;
        }
        this.j().f().b(0, null, this);
        this.j().f().b(1, null, this);
    }

    @Override
    public void e() {
        super.e();
        this.ag = false;
    }

    @Override
    public void s() {
        super.s();
        this.ae().dispatchTouchEvent(MotionEvent.obtain((long)SystemClock.uptimeMillis(), (long)SystemClock.uptimeMillis(), (int)3, (float)0.0f, (float)0.0f, (int)0));
    }

    public static interface a
    extends j.a {
        public void a(long var1, long var3, l var5);

        public void a(long var1, Set<Long> var3);

        public void a(long var1, TreeSet<Long> var3);

        public void a(com.orgzly.android.a var1);

        public void b(long var1, Set<Long> var3);

        public void b(long var1, TreeSet<Long> var3);

        public void b(com.orgzly.android.a var1);
    }

    public class b
    implements b.a {
        @Override
        public void a(android.support.v7.view.b b2) {
            a.this.ab.c();
            if (a.this.af() != null) {
                a.this.af().notifyDataSetChanged();
            }
            a.this.ac.c();
            a.this.ai();
        }

        @Override
        public boolean a(android.support.v7.view.b b2, Menu menu) {
            b2.a().inflate(2131820546, menu);
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public boolean a(android.support.v7.view.b b2, MenuItem iterator) {
            switch (iterator.getItemId()) {
                default: {
                    if (iterator.getGroupId() != 1) return false;
                    a.this.af.a(a.this.ab.b(), iterator.getTitle().toString());
                    return true;
                }
                case 2131689802: {
                    a.this.b(l.a);
                    b2.c();
                    return true;
                }
                case 2131689803: {
                    a.this.b(l.b);
                    b2.c();
                    return true;
                }
                case 2131689804: {
                    a.this.b(l.c);
                    b2.c();
                    return true;
                }
                case 2131689808: {
                    b2.a((Object)"M");
                    b2.d();
                    return true;
                }
                case 2131689806: {
                    a.this.c(2131689806, a.this.ab.b());
                    return true;
                }
                case 2131689809: 
                case 2131689814: {
                    TreeSet<Long> treeSet = new TreeSet<Long>();
                    treeSet.addAll(a.this.ab.b());
                    if (iterator.getItemId() == 2131689809) {
                        a.this.af.b((long)a.this.ai, treeSet);
                    } else {
                        a.this.a(treeSet);
                    }
                    a.this.ab.c();
                    b2.c();
                    return true;
                }
                case 2131689811: {
                    a.this.c(l.a);
                    b2.c();
                    return true;
                }
                case 2131689812: {
                    a.this.c(l.b);
                    b2.c();
                    return true;
                }
                case 2131689813: {
                    a.this.c(l.c);
                    b2.c();
                    return true;
                }
                case 2131689817: {
                    a.this.d(-1);
                    return true;
                }
                case 2131689816: {
                    a.this.d(1);
                    return true;
                }
                case 2131689815: {
                    a.this.af.a((long)a.this.ai, (Set<Long>)a.this.ab.b());
                    return true;
                }
                case 2131689818: {
                    a.this.af.b((long)a.this.ai, (Set<Long>)a.this.ab.b());
                    return true;
                }
                case 2131689807: 
            }
            b2 = iterator.getSubMenu();
            if (b2 == null) return true;
            b2.clear();
            iterator = new com.orgzly.android.ui.k((Context)a.this.j(), null).d().iterator();
            while (iterator.hasNext()) {
                b2.add(1, 0, 0, (CharSequence)iterator.next());
            }
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public boolean b(android.support.v7.view.b b2, Menu menu) {
            b2.b(String.valueOf(a.this.ab.a()));
            if ("M".equals(b2.j())) {
                menu.clear();
                b2.a().inflate(2131820547, menu);
            }
            int[] arrn = ae;
            int n2 = arrn.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                MenuItem menuItem = menu.findItem(arrn[i2]);
                if (menuItem == null) continue;
                boolean bl2 = a.this.ab.a() == 1;
                menuItem.setVisible(bl2);
            }
            if (b2.j() != null && a.this.ab.a() > 1) {
                menu.clear();
                b2.a().inflate(2131820546, menu);
                b2.a((Object)null);
            }
            a.this.ai();
            return true;
        }
    }

}

