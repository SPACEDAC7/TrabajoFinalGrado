/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  android.widget.ListView
 *  android.widget.TextView
 */
package com.orgzly.android.ui.b.a;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.b.n;
import android.support.v4.b.z;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

public abstract class a
extends z {
    private static final String af = a.class.getName();
    protected TextView aa;
    protected b[] ab;
    protected String ac;
    protected String ad;
    protected ArrayList<String> ae = new ArrayList();
    private LinearLayout ag;
    protected a i;

    private void c(View view) {
        view.findViewById(2131689597).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                a.this.i.o();
            }
        });
        view.findViewById(2131689598).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                a.this.i.c(a.this.ac);
            }
        });
        view.findViewById(2131689599).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                a.this.i.d(a.this.ac);
            }
        });
    }

    abstract String Z();

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903070, viewGroup, false);
        this.ag = (LinearLayout)layoutInflater.findViewById(2131689595);
        this.a(this.ag);
        this.aa = (TextView)layoutInflater.findViewById(2131689596);
        this.c((View)layoutInflater);
        return layoutInflater;
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.i = (a)((Object)this.j());
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + a.class);
        }
        if (this.g() != null && this.g().containsKey("item")) {
            this.ad = this.g().getString("item");
        }
        if (this.ad == null) {
            this.ad = this.Z();
        }
    }

    abstract void a(LinearLayout var1);

    @Override
    public void a(ListView listView, View view, int n2, long l2) {
        throw new IllegalStateException("Browser implementations must implement onListItemClick");
    }

    @Override
    public void b() {
        super.b();
        this.i = null;
    }

    protected void b(String string) {
        Bundle bundle = new Bundle();
        bundle.putString("item", string);
        this.g(bundle);
    }

    @Override
    public void d(Bundle bundle) {
        super.d(bundle);
        if (bundle != null && bundle.containsKey("item")) {
            this.ad = bundle.getString("item");
        }
    }

    @Override
    public void e(Bundle bundle) {
        super.e(bundle);
        bundle.putString("item", this.ac);
    }

    public static interface a {
        public void c(String var1);

        public void d(String var1);

        public void o();
    }

    protected class b {
        boolean a;
        public String b;
        public int c;
        final /* synthetic */ a d;

        public b(a a2, Integer n2) {
            this.d = a2;
            this.a = false;
            this.c = n2;
            this.a = true;
            this.b = "Up";
        }

        public b(a a2, Integer n2, String string) {
            this.d = a2;
            this.a = false;
            this.c = n2;
            this.a = false;
            this.b = string;
        }

        public String toString() {
            return this.b;
        }
    }

}

