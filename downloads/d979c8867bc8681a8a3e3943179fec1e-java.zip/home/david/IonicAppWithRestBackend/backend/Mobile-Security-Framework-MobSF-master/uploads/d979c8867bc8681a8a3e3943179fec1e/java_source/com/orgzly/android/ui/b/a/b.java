/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.TypedArray
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Environment
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.TextView
 */
package com.orgzly.android.ui.b.a;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.b.n;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.orgzly.a;
import com.orgzly.android.e;
import com.orgzly.android.ui.b.a.a;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class b
extends com.orgzly.android.ui.b.a.a {
    public static final String af;
    private static final String ag;
    private static final FilenameFilter ah;

    static {
        ag = b.class.getName();
        af = b.class.getName();
        ah = new FilenameFilter(){

            @Override
            public boolean accept(File file, String string) {
                if (((file = new File(file, string)).isFile() || file.isDirectory()) && !file.isHidden()) {
                    return true;
                }
                return false;
            }
        };
    }

    private void a(boolean bl2) {
        File[] arrfile;
        File[] arrfile2 = arrfile = this.d(this.ad);
        if (arrfile == null) {
            if (!bl2) {
                return;
            }
            this.ad = this.Z();
            arrfile2 = arrfile = this.d(this.ad);
            if (arrfile == null) {
                this.ad = "/";
                arrfile2 = arrfile = this.d(this.ad);
                if (arrfile == null) {
                    arrfile2 = new File[]{};
                }
            }
        }
        this.a(arrfile2);
        this.ab();
    }

    private void a(File[] object) {
        File file = new File(this.ad);
        object = Arrays.asList(object);
        Collections.sort(object, new a());
        TypedArray typedArray = this.j().obtainStyledAttributes(a.a.Icons);
        this.ab = new a.b[object.size() + 1];
        this.ab[0] = new a.b(this, typedArray.getResourceId(41, 0));
        for (int i2 = 0; i2 < object.size(); ++i2) {
            this.ab[i2 + 1] = new a.b(this, typedArray.getResourceId(43, 0), ((File)object.get(i2)).getName());
            if (!new File(file, ((File)object.get(i2)).getName()).isDirectory()) continue;
            this.ab[i2 + 1].c = typedArray.getResourceId(42, 0);
        }
        typedArray.recycle();
        this.aa.setText((CharSequence)file.getAbsolutePath());
        this.ae.add(this.ac);
        this.ac = this.ad;
    }

    private void ab() {
        ArrayAdapter<a.b> arrayAdapter = new ArrayAdapter<a.b>((Context)this.j(), 2130903108, this.ab){

            public View getView(int n2, View view, ViewGroup viewGroup) {
                View view2 = view;
                if (view == null) {
                    view2 = LayoutInflater.from((Context)this.getContext()).inflate(2130903108, viewGroup, false);
                }
                view = (ImageView)view2.findViewById(2131689716);
                viewGroup = (TextView)view2.findViewById(2131689717);
                view.setImageResource(b.this.ab[n2].c);
                viewGroup.setText((CharSequence)b.this.ab[n2].b);
                return view2;
            }
        };
        this.e_().setAdapter((ListAdapter)arrayAdapter);
    }

    public static b c(String string) {
        b b2 = new b();
        if (string != null) {
            b2.b(string);
        }
        return b2;
    }

    private Button d(int n2) {
        Button button = new Button(this.i());
        button.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(0, -2, 1.0f));
        button.setText(n2);
        return button;
    }

    private File[] d(String object) {
        if (object != null && (object = new File((String)object)).exists()) {
            return object.listFiles(ah);
        }
        return null;
    }

    @Override
    public String Z() {
        File file = Environment.getExternalStorageDirectory();
        boolean bl2 = "mounted".equals(Environment.getExternalStorageState());
        String string = null;
        if (bl2) {
            string = file.getAbsolutePath();
        }
        return string;
    }

    @Override
    void a(final LinearLayout linearLayout) {
        linearLayout.removeAllViews();
        final Button button = this.d(2131231129);
        button.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                b.this.ad = b.this.Z();
                b.this.a(true);
            }
        });
        linearLayout.addView((View)button);
        if (e.a(this.i())) {
            button = this.d(2131231138);
            button.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    if (e.a(b.this.i())) {
                        if (Build.VERSION.SDK_INT >= 21) {
                            view = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
                            b.this.j().startActivityForResult((Intent)view, 0);
                        }
                        b.this.i.o();
                        return;
                    }
                    linearLayout.removeView((View)button);
                    ((com.orgzly.android.ui.b)b.this.j()).c(2131231139);
                }
            });
            linearLayout.addView((View)button);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(ListView object, View view, int n2, long l2) {
        object = (a.b)object.getItemAtPosition(n2);
        if (this.ac == null) {
            Log.e((String)ag, (String)("Clicked on " + object.b + " but there is no current directory set"));
            return;
        }
        if (object.a) {
            object = new File(this.ac);
            if (object.getParentFile() == null) return;
            {
                this.ad = object.getParentFile().getAbsolutePath();
                this.a(false);
                return;
            }
        } else {
            object = new File(this.ac, object.b);
            if (!object.isDirectory()) return;
            {
                this.ad = object.getAbsolutePath();
                this.a(false);
                return;
            }
        }
    }

    public void aa() {
        this.ad = this.ac;
        this.a(false);
    }

    @Override
    public void d(Bundle bundle) {
        super.d(bundle);
        this.a(true);
    }

    @Override
    public void r() {
        super.r();
        com.orgzly.android.b.a.a((com.orgzly.android.ui.b)this.j(), 1);
    }

    class a
    implements Comparator<File> {
        a() {
        }

        public int a(File file, File file2) {
            if (file.isDirectory() && file2.isDirectory() || file.isFile() && file2.isFile()) {
                return String.CASE_INSENSITIVE_ORDER.compare(file.getName(), file2.getName());
            }
            if (file.isDirectory() && file2.isFile()) {
                return -1;
            }
            return 1;
        }

        @Override
        public /* synthetic */ int compare(Object object, Object object2) {
            return this.a((File)object, (File)object2);
        }
    }

}

