/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.graphics.Typeface
 *  android.os.Bundle
 *  android.text.Editable
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.EditText
 */
package com.orgzly.android.ui.b;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.b.m;
import android.support.v4.b.n;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import com.orgzly.android.ui.e;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

public class b
extends m {
    public static final String a;
    private static final String b;
    private long c;
    private com.orgzly.android.a d;
    private EditText e;
    private a f;

    static {
        b = b.class.getName();
        a = b.class.getName();
    }

    public static b a(long l2, String string) {
        b b2 = new b();
        Bundle bundle = new Bundle();
        bundle.putLong("book_id", l2);
        bundle.putString("book_preface", string);
        b2.g(bundle);
        return b2;
    }

    private void a() {
        if (this.f != null) {
            this.f.a(a, com.orgzly.android.a.a(this.d), com.orgzly.android.a.b(this.d), 0);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void a(com.orgzly.android.a var1_1, String var2_6) {
        var1_1.k().a(null);
        var2_6 = new BufferedReader(new StringReader((String)var2_6));
        try {
            try {
                while ((var3_8 = var2_6.readLine()) != null) {
                    var1_1.k().b(var3_8);
                }
                ** GOTO lbl17
            }
            catch (IOException var1_2) {
                var1_2.printStackTrace();
                try {
                    var2_6.close();
                    return;
                }
                catch (IOException var1_4) {
                    var1_4.printStackTrace();
                    return;
                }
lbl17: // 1 sources:
                try {
                    var2_6.close();
                    return;
                }
                catch (IOException var1_3) {
                    var1_3.printStackTrace();
                    return;
                }
            }
        }
        catch (Throwable var1_5) {
            try {
                var2_6.close();
            }
            catch (IOException var2_7) {
                var2_7.printStackTrace();
                throw var1_5;
            }
            throw var1_5;
        }
    }

    private void b(String string) {
        this.d.a(string);
        this.a(this.d, string);
        this.f.g(this.d);
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup object, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903095, (ViewGroup)object, false);
        this.e = (EditText)layoutInflater.findViewById(2131689647);
        object = this.j();
        if (object != null && com.orgzly.android.prefs.a.e(this.i())) {
            this.e.setTypeface(Typeface.MONOSPACE);
        }
        if (object != null) {
            com.orgzly.android.ui.c.a.a((Activity)object, (View)this.e);
        }
        if (this.g() == null) {
            throw new IllegalArgumentException(b.class.getSimpleName() + " has no arguments passed");
        }
        if (!this.g().containsKey("book_id")) {
            throw new IllegalArgumentException(b.class.getSimpleName() + " has no book id passed");
        }
        if (!this.g().containsKey("book_preface")) {
            throw new IllegalArgumentException(b.class.getSimpleName() + " has no book preface passed");
        }
        this.c = this.g().getLong("book_id");
        this.d = com.orgzly.android.provider.b.a.c((Context)this.j(), this.c);
        this.e.setText((CharSequence)this.g().getString("book_preface"));
        return layoutInflater;
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.f = (a)((Object)this.j());
            return;
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + a.class);
        }
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.d(true);
    }

    @Override
    public void a(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(2131820550, menu);
        menu.removeItem(2131689796);
    }

    @Override
    public boolean a(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            default: {
                return super.a(menuItem);
            }
            case 2131689826: {
                this.f.u();
                return true;
            }
            case 2131689827: {
                this.b(this.e.getText().toString());
                return true;
            }
            case 2131689760: 
        }
        this.b("");
        return true;
    }

    @Override
    public void b() {
        super.b();
        this.f = null;
    }

    @Override
    public void r() {
        super.r();
        this.a();
    }

    public static interface a
    extends e {
        public void g(com.orgzly.android.a var1);

        public void u();
    }

}

