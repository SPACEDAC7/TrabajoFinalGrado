/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.database.Cursor
 *  android.os.Bundle
 *  android.text.SpannableStringBuilder
 *  android.text.style.ForegroundColorSpan
 *  android.text.style.StyleSpan
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.AdapterView
 *  android.widget.AdapterView$AdapterContextMenuInfo
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.TextView
 */
package com.orgzly.android.ui.b;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.b.aa;
import android.support.v4.b.n;
import android.support.v4.b.z;
import android.support.v4.c.l;
import android.support.v4.widget.x;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.orgzly.a.b;
import com.orgzly.android.a.i;
import com.orgzly.android.a.j;
import com.orgzly.android.b;
import com.orgzly.android.provider.e;
import com.orgzly.android.ui.d;
import com.orgzly.android.ui.e;
import java.text.DateFormat;
import java.util.Date;

public class c
extends z
implements aa.a<Cursor>,
d {
    private static final String aa = c.class.getName();
    public static final String i = c.class.getName();
    private a ab;
    private x ac;
    private View ad;
    private boolean ae = false;

    public static c Z() {
        return new c();
    }

    private x aa() {
        Object object = e.b.b.a;
        String string = e.b.b.b;
        String string2 = e.b.b.c;
        String string3 = e.b.b.d;
        String string4 = e.b.b.e;
        String string5 = e.b.b.f;
        object = new x((Context)this.j(), 2130903107, null, new String[]{"name", "name", "mtime", "last_action", object, string, string2, string3, string4, string5, "used_encoding", "detected_encoding", "selected_encoding"}, new int[]{2131689691, 2131689692, 2131689695, 2131689715, 2131689697, 2131689698, 2131689701, 2131689703, 2131689707, 2131689705, 2131689713, 2131689711, 2131689709}, 0){

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public void a(View view, Context context, Cursor object) {
                a a2;
                int n2;
                int n3 = 1;
                super.a(view, context, (Cursor)object);
                a a3 = a2 = (a)view.getTag();
                if (a2 == null) {
                    a3 = new a();
                    a3.a = (TextView)view.findViewById(2131689691);
                    a3.b = view.findViewById(2131689690);
                    a3.c = view.findViewById(2131689693);
                    a3.o = (TextView)view.findViewById(2131689692);
                    a3.d = view.findViewById(2131689694);
                    a3.p = (TextView)view.findViewById(2131689695);
                    a3.e = view.findViewById(2131689696);
                    a3.f = view.findViewById(2131689699);
                    a3.g = view.findViewById(2131689702);
                    a3.h = view.findViewById(2131689704);
                    a3.i = view.findViewById(2131689706);
                    a3.j = view.findViewById(2131689714);
                    a3.n = (TextView)view.findViewById(2131689715);
                    a3.k = view.findViewById(2131689712);
                    a3.l = view.findViewById(2131689710);
                    a3.m = view.findViewById(2131689708);
                    view.setTag((Object)a3);
                }
                if ((object = com.orgzly.android.provider.b.a.a((Cursor)object)).k().a() != null) {
                    a3.a.setText((CharSequence)object.k().a());
                    a3.o.setText((CharSequence)object.c());
                    a3.o.setVisibility(0);
                } else {
                    a3.a.setText((CharSequence)object.c());
                    a3.o.setVisibility(8);
                }
                if (object.d()) {
                    a3.b.setVisibility(0);
                } else {
                    a3.b.setVisibility(4);
                }
                if (com.orgzly.android.prefs.a.p(context).contains(c.this.a(2131231098))) {
                    a3.d.setVisibility(0);
                    n2 = 1;
                } else {
                    a3.d.setVisibility(8);
                    n2 = 0;
                }
                if (object.g() != null && com.orgzly.android.prefs.a.p(context).contains(c.this.a(2131231097))) {
                    a3.e.setVisibility(0);
                    n2 = 1;
                } else {
                    a3.e.setVisibility(8);
                }
                if (object.f() != null) {
                    a3.f.setVisibility(0);
                    if (com.orgzly.android.prefs.a.p(context).contains(c.this.a(2131231101))) {
                        a3.g.setVisibility(0);
                        n2 = 1;
                    } else {
                        a3.g.setVisibility(8);
                    }
                    if (com.orgzly.android.prefs.a.p(context).contains(c.this.a(2131231099))) {
                        a3.h.setVisibility(0);
                        n2 = 1;
                    } else {
                        a3.h.setVisibility(8);
                    }
                    if (com.orgzly.android.prefs.a.p(context).contains(c.this.a(2131231100))) {
                        a3.i.setVisibility(0);
                        n2 = 1;
                    } else {
                        a3.i.setVisibility(8);
                    }
                } else {
                    a3.f.setVisibility(8);
                }
                if (object.j() == null || object.j().a() == b.a.a && !com.orgzly.android.prefs.a.p(context).contains(c.this.a(2131231096))) {
                    a3.j.setVisibility(8);
                } else {
                    a3.j.setVisibility(0);
                    a2 = new SpannableStringBuilder();
                    a2.append((CharSequence)DateFormat.getDateTimeInstance().format(new Date(object.j().c())));
                    a2.append((CharSequence)": ");
                    n2 = a2.length();
                    a2.append((CharSequence)object.j().b());
                    if (object.j().a() == b.a.b) {
                        TypedArray typedArray = c.this.j().obtainStyledAttributes(new int[]{2130772177});
                        int n4 = typedArray.getColor(0, 0);
                        typedArray.recycle();
                        a2.setSpan((Object)new ForegroundColorSpan(n4), n2, a2.length(), 33);
                    } else if (object.j().a() == b.a.c) {
                        a2.setSpan((Object)new StyleSpan(1), n2, a2.length(), 33);
                    }
                    a3.n.setText((CharSequence)((Object)a2));
                    n2 = 1;
                }
                if (object.n() != null && com.orgzly.android.prefs.a.p(context).contains(c.this.a(2131231095))) {
                    a3.k.setVisibility(0);
                    n2 = 1;
                } else {
                    a3.k.setVisibility(8);
                }
                if (object.m() != null && com.orgzly.android.prefs.a.p(context).contains(c.this.a(2131231094))) {
                    a3.l.setVisibility(0);
                    n2 = n3;
                } else {
                    a3.l.setVisibility(8);
                }
                if (object.l() != null) {
                    a3.m.setVisibility(0);
                } else {
                    a3.m.setVisibility(8);
                }
                if (object.h()) {
                    view.setAlpha(0.4f);
                } else {
                    view.setAlpha(1.0f);
                }
                if (n2 != 0) {
                    a3.c.setVisibility(0);
                    return;
                }
                a3.c.setVisibility(8);
            }

            class a {
                TextView a;
                View b;
                View c;
                View d;
                View e;
                View f;
                View g;
                View h;
                View i;
                View j;
                View k;
                View l;
                View m;
                TextView n;
                TextView o;
                TextView p;

                a() {
                }
            }

        };
        object.a(new x.b(){

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            @Override
            public boolean a(View view, Cursor cursor, int n2) {
                boolean bl2 = true;
                switch (view.getId()) {
                    default: {
                        return false;
                    }
                    case 2131689713: {
                        if (cursor.isNull(n2)) return bl2;
                        view = (TextView)view;
                        view.setText((CharSequence)cursor.getString(n2));
                        view.append((CharSequence)" used");
                        return true;
                    }
                    case 2131689711: {
                        if (cursor.isNull(n2)) return bl2;
                        view = (TextView)view;
                        view.setText((CharSequence)cursor.getString(n2));
                        view.append((CharSequence)" detected");
                        return true;
                    }
                    case 2131689709: {
                        if (cursor.isNull(n2)) return bl2;
                        view = (TextView)view;
                        view.setText((CharSequence)cursor.getString(n2));
                        view.append((CharSequence)" selected");
                        return true;
                    }
                    case 2131689707: {
                        view = (TextView)view;
                        if (!cursor.isNull(n2)) {
                            view.setText((CharSequence)cursor.getString(n2));
                            return true;
                        }
                        view.setText((CharSequence)"N/A");
                        return true;
                    }
                    case 2131689705: {
                        view = (TextView)view;
                        if (!cursor.isNull(n2) && cursor.getLong(n2) > 0) {
                            view.setText((CharSequence)DateFormat.getDateTimeInstance().format(new Date(cursor.getLong(n2))));
                            return true;
                        }
                        view.setText((CharSequence)"N/A");
                        return true;
                    }
                    case 2131689695: {
                        view = (TextView)view;
                        if (!cursor.isNull(n2) && cursor.getLong(n2) > 0) {
                            view.setText((CharSequence)DateFormat.getDateTimeInstance().format(new Date(cursor.getLong(n2))));
                            return true;
                        }
                        view.setText((CharSequence)"Never modified locally");
                        return true;
                    }
                    case 2131689698: 
                    case 2131689703: 
                }
                view = (TextView)view;
                if (cursor.isNull(n2)) return bl2;
                view.setText((CharSequence)com.orgzly.android.b.j.a(cursor.getString(n2)));
                return true;
            }
        });
        return object;
    }

    private void ab() {
        if (this.ab != null) {
            this.ab.a(i, this.a(2131230895), null, 0);
        }
    }

    @Override
    public l<Cursor> a(int n2, Bundle bundle) {
        return com.orgzly.android.provider.b.a.b((Context)this.j());
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903096, viewGroup, false);
        this.ad = layoutInflater.findViewById(2131689649);
        return layoutInflater;
    }

    @Override
    public Runnable a() {
        return new Runnable(){

            @Override
            public void run() {
                c.this.ab.r();
            }
        };
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.ab = (a)((Object)this.j());
            return;
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + a.class);
        }
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.d(true);
        this.ac = this.aa();
    }

    @Override
    public void a(l<Cursor> l2) {
        if (this.ae) {
            this.ac.a((Cursor)null);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void a(l<Cursor> l2, Cursor cursor) {
        if (!this.ae) return;
        this.ac.b(cursor);
        if (this.ac.getCount() > 0) {
            this.ad.setVisibility(8);
            return;
        }
        this.ad.setVisibility(0);
    }

    @Override
    public void a(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(2131820548, menu);
    }

    @Override
    public void a(View view, Bundle bundle) {
        super.a(view, bundle);
        this.ae = true;
        this.a((View)this.e_());
        this.a((ListAdapter)this.ac);
    }

    @Override
    public void a(ListView listView, View view, int n2, long l2) {
        super.a(listView, view, n2, l2);
        if (this.ab != null) {
            this.ab.i(l2);
        }
    }

    @Override
    public boolean a(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            default: {
                return super.a(menuItem);
            }
            case 2131689819: 
        }
        this.ab.n();
        return true;
    }

    @Override
    public void b() {
        super.b();
        this.ab = null;
    }

    @Override
    public boolean b(MenuItem menuItem) {
        long l2 = ((AdapterView.AdapterContextMenuInfo)menuItem.getMenuInfo()).id;
        switch (menuItem.getItemId()) {
            default: {
                return super.b(menuItem);
            }
            case 2131689820: {
                this.ab.d(l2);
                return true;
            }
            case 2131689821: {
                this.ab.e(l2);
                return true;
            }
            case 2131689823: {
                this.ab.f(l2);
                return true;
            }
            case 2131689822: {
                this.ab.g(l2);
                return true;
            }
            case 2131689824: {
                this.ab.h(l2);
                return true;
            }
            case 2131689825: 
        }
        this.ab.c(l2);
        return true;
    }

    @Override
    public void d(Bundle bundle) {
        super.d(bundle);
        this.j().f().a(2, null, this);
    }

    @Override
    public void e() {
        super.e();
        this.ae = false;
    }

    @Override
    public void i(Bundle bundle) {
        super.i(bundle);
    }

    @Override
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.j().getMenuInflater().inflate(2131820549, (Menu)contextMenu);
    }

    @Override
    public void r() {
        super.r();
        this.j().f().b(2, null, this);
        this.ab();
    }

    public static interface a
    extends e {
        public void c(long var1);

        public void d(long var1);

        public void e(long var1);

        public void f(long var1);

        public void g(long var1);

        public void h(long var1);

        public void i(long var1);

        public void n();

        public void r();
    }

}

