/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Handler
 *  android.text.Editable
 *  android.text.TextUtils
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.EditText
 *  android.widget.TextView
 *  android.widget.TextView$OnEditorActionListener
 */
package com.orgzly.android.ui.b;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TextInputLayout;
import android.support.v4.b.n;
import android.text.Editable;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import com.orgzly.android.a.g;
import com.orgzly.android.a.h;
import com.orgzly.android.b.e;
import com.orgzly.android.ui.b;
import com.orgzly.android.ui.b.l;

public class d
extends l {
    public static final String a;
    private static final String b;
    private a c;
    private Uri d;
    private TextInputLayout e;
    private EditText f;

    static {
        b = d.class.getName();
        a = d.class.getName();
    }

    private void Y() {
        if (this.g() != null && this.g().containsKey("repo_id")) {
            long l2 = this.g().getLong("repo_id");
            this.d = Uri.parse((String)com.orgzly.android.provider.b.g.b((Context)this.j(), l2));
        }
    }

    private void Z() {
        new Handler().postDelayed(new Runnable(){

            @Override
            public void run() {
                d.this.aa();
            }
        }, 100);
    }

    public static d a() {
        return new d();
    }

    public static d a(long l2) {
        d d2 = new d();
        Bundle bundle = new Bundle();
        bundle.putLong("repo_id", l2);
        d2.g(bundle);
        return d2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void aa() {
        String string = !TextUtils.isEmpty((CharSequence)this.f.getText()) ? this.f.getText().toString() : null;
        if (string != null) {
            this.c.b(Uri.parse((String)string).getPath());
            return;
        }
        this.c.b(null);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void ab() {
        if (!com.orgzly.android.b.a.a((b)this.j(), 1)) return;
        String string = this.f.getText().toString().trim();
        if (TextUtils.isEmpty((CharSequence)string)) {
            this.e.setError(this.a(2131230762));
            return;
        }
        this.e.setError(null);
        string = Uri.parse((String)string);
        g g2 = h.a((Context)this.j(), (Uri)string);
        if (g2 == null) {
            this.e.setError(this.a(2131231026, string));
            return;
        }
        if (this.g() != null && this.g().containsKey("repo_id")) {
            long l2 = this.g().getLong("repo_id");
            if (this.c == null) return;
            {
                this.c.a(l2, g2);
                return;
            }
        }
        if (this.c == null) {
            return;
        }
        this.c.a(g2);
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903102, viewGroup, false);
        this.e = (TextInputLayout)layoutInflater.findViewById(2131689674);
        this.f = (EditText)layoutInflater.findViewById(2131689675);
        this.f.setHorizontallyScrolling(false);
        this.f.setMaxLines(3);
        this.f.setOnEditorActionListener(new TextView.OnEditorActionListener(){

            public boolean onEditorAction(TextView textView, int n2, KeyEvent keyEvent) {
                d.this.ab();
                return true;
            }
        });
        e.a((TextView)this.f, this.e);
        layoutInflater.findViewById(2131689673).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (d.this.j() != null) {
                    com.orgzly.android.ui.c.a.a(d.this.j());
                }
                if (com.orgzly.android.b.a.a((b)d.this.j(), 1)) {
                    d.this.Z();
                }
            }
        });
        if (bundle == null && TextUtils.isEmpty((CharSequence)this.f.getText()) && this.d == null) {
            this.Y();
        }
        return layoutInflater;
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.c = (a)((Object)this.j());
            return;
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + a.class);
        }
    }

    public void a(Uri uri) {
        this.d = uri;
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.d(true);
    }

    @Override
    public void a(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(2131820551, menu);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean a(MenuItem menuItem) {
        boolean bl2 = true;
        switch (menuItem.getItemId()) {
            default: {
                return super.a(menuItem);
            }
            case 2131689826: {
                if (this.c == null) return bl2;
                this.c.l();
                return true;
            }
            case 2131689827: 
        }
        this.ab();
        return true;
    }

    @Override
    public void b() {
        super.b();
        this.c = null;
    }

    @Override
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.j().getMenuInflater().inflate(2131820556, (Menu)contextMenu);
    }

    @Override
    public void r() {
        super.r();
        if (this.d != null) {
            this.f.setText((CharSequence)this.d.toString());
            this.d = null;
        }
        com.orgzly.android.b.a.a((b)this.j(), 1);
    }

    public static interface a
    extends l.a {
        public void b(String var1);
    }

}

