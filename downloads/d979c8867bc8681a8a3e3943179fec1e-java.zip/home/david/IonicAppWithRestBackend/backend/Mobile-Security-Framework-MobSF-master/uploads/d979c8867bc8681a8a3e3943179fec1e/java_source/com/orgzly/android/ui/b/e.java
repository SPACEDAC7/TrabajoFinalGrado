/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$OnSharedPreferenceChangeListener
 *  android.content.res.TypedArray
 *  android.database.Cursor
 *  android.graphics.Typeface
 *  android.os.Bundle
 *  android.preference.PreferenceManager
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ArrayAdapter
 *  android.widget.ImageView
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.TextView
 */
package com.orgzly.android.ui.b;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.b.aa;
import android.support.v4.b.m;
import android.support.v4.b.r;
import android.support.v4.b.z;
import android.support.v4.c.l;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.orgzly.a;
import com.orgzly.android.j;
import com.orgzly.android.ui.b.k;
import com.orgzly.android.ui.b.n;
import java.util.ArrayList;
import java.util.List;

public class e
extends z
implements SharedPreferences.OnSharedPreferenceChangeListener,
aa.a<Cursor> {
    private static final String aa = e.class.getName();
    public static final String i = e.class.getName();
    private f ab;
    private final List<e> ac = new ArrayList<e>();
    private b ad;
    private final List<a> ae = new ArrayList<a>();
    private g af;
    private c ag;
    private ArrayAdapter<d> ah;
    private String ai = null;
    private d aj = null;

    public static e Z() {
        return new e();
    }

    private void a(Cursor cursor) {
        this.ac.clear();
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            e e2 = new e(cursor.getString(cursor.getColumnIndex("name")), new j(cursor.getString(cursor.getColumnIndex("search"))).toString());
            this.ac.add(e2);
            cursor.moveToNext();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void aa() {
        this.aj = null;
        Object object = this.j();
        if (object != null && (object = object.e().a(this.ai)) != null) {
            if (k.i.equals(this.ai)) {
                if ((object = ((k)object).Z()) != null) {
                    for (e e2 : this.ac) {
                        if (!object.toString().equals(e2.a)) continue;
                        this.aj = e2;
                    }
                }
            } else if (com.orgzly.android.ui.b.c.i.equals(this.ai)) {
                this.aj = this.ad;
            } else if (com.orgzly.android.ui.b.h.i.equals(this.ai)) {
                this.aj = this.ab;
            } else if (n.b.equals(this.ai)) {
                this.aj = this.af;
            } else if (com.orgzly.android.ui.b.a.i.equals(this.ai) && (object = ((com.orgzly.android.ui.b.a)object).Z()) != null) {
                for (a a2 : this.ae) {
                    if (object.a() != a2.a) continue;
                    this.aj = a2;
                }
            }
            this.ah.notifyDataSetChanged();
        }
    }

    private ArrayAdapter<d> ab() {
        return new ArrayAdapter<d>((Context)this.j(), 2130903109, 2131689721){

            /*
             * Enabled aggressive block sorting
             */
            public View getView(int n2, View object, ViewGroup viewGroup) {
                viewGroup = super.getView(n2, (View)object, viewGroup);
                object = (h)viewGroup.getTag();
                if (object == null) {
                    object = new h();
                    object.a = (ViewGroup)viewGroup.findViewById(2131689718);
                    object.b = (TextView)viewGroup.findViewById(2131689721);
                    object.c = (ImageView)viewGroup.findViewById(2131689720);
                    object.d = (ImageView)viewGroup.findViewById(2131689722);
                    object.e = viewGroup.findViewById(2131689719);
                    viewGroup.setTag(object);
                }
                d d2 = (d)this.getItem(n2);
                TypedArray typedArray = this.getContext().obtainStyledAttributes(a.a.Icons);
                TypedArray typedArray2 = this.getContext().obtainStyledAttributes(a.a.FontSize);
                n2 = typedArray2.getDimensionPixelSize(d2.h, -1);
                if (n2 != -1) {
                    object.b.setTextSize(0, (float)n2);
                }
                if (d2.f != 0) {
                    object.c.setImageResource(typedArray.getResourceId(d2.f, -1));
                    object.c.setVisibility(0);
                } else {
                    object.c.setVisibility(4);
                }
                typedArray.recycle();
                typedArray2.recycle();
                if (d2.e) {
                    object.d.setVisibility(0);
                } else {
                    object.d.setVisibility(4);
                }
                object.b.setTypeface(null, d2.g);
                viewGroup.setAlpha(d2.d);
                if (d2 == e.this.aj) {
                    object.e.setVisibility(0);
                    return viewGroup;
                }
                object.e.setVisibility(4);
                return viewGroup;
            }
        };
    }

    private void ac() {
        this.aa();
        this.ah.clear();
        this.ah.add((Object)this.ab);
        for (d d22 : this.ac) {
            this.ah.add((Object)d22);
        }
        this.ah.add((Object)this.ad);
        for (d d2 : this.ae) {
            this.ah.add((Object)d2);
        }
        this.ah.add((Object)this.af);
    }

    private void b(Cursor cursor) {
        this.ae.clear();
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Object object = cursor.getString(cursor.getColumnIndex("name"));
            long l2 = cursor.getLong(cursor.getColumnIndex("_id"));
            com.orgzly.android.a a2 = com.orgzly.android.provider.b.a.a(cursor);
            if (a2.k().a() != null) {
                object = a2.k().a();
            }
            object = new a((String)object, l2);
            object.e = a2.d();
            if (a2.h()) {
                object.d = 0.4f;
            }
            this.ae.add((a)object);
            cursor.moveToNext();
        }
    }

    @Override
    public l<Cursor> a(int n2, Bundle bundle) {
        switch (n2) {
            default: {
                throw new IllegalArgumentException("Loader id " + n2 + " unexpected");
            }
            case 6: {
                return com.orgzly.android.provider.b.d.a((Context)this.j());
            }
            case 7: 
        }
        return com.orgzly.android.provider.b.a.b((Context)this.j());
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(2130903099, viewGroup, false);
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.ag = (c)((Object)this.j());
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + c.class);
        }
        this.ab = new f();
        this.ad = new b();
        this.af = new g();
    }

    @Override
    public void a(l<Cursor> l2) {
        if (this.ah == null) {
            // empty if block
        }
    }

    @Override
    public void a(l<Cursor> l2, Cursor cursor) {
        if (this.ah == null) {
            return;
        }
        switch (l2.n()) {
            default: {
                return;
            }
            case 6: {
                this.a(cursor);
                this.ac();
                return;
            }
            case 7: 
        }
        this.b(cursor);
        this.ac();
    }

    @Override
    public void a(ListView object, View view, int n2, long l2) {
        if (this.ag != null) {
            object = (d)object.getItemAtPosition(n2);
            this.ag.a((d)object);
        }
    }

    @Override
    public void b() {
        super.b();
        this.ag = null;
    }

    public void b(String string) {
        this.ai = string;
        this.aa();
    }

    @Override
    public void d(Bundle bundle) {
        super.d(bundle);
        this.ah = this.ab();
        this.a((ListAdapter)this.ah);
        if (bundle != null) {
            this.j().f().a(7, null, this);
            this.j().f().a(6, null, this);
            return;
        }
        this.j().f().b(7, null, this);
        this.j().f().b(6, null, this);
    }

    @Override
    public void e() {
        super.e();
        this.a(null);
        this.ah = null;
    }

    public void onSharedPreferenceChanged(SharedPreferences object, String string) {
        object = this.j();
        if (object != null && this.a(2131231086).equals(string)) {
            object.f().b(7, null, this);
        }
    }

    @Override
    public void r() {
        super.r();
        this.j().f().b(7, null, this);
        PreferenceManager.getDefaultSharedPreferences((Context)this.j()).registerOnSharedPreferenceChangeListener((SharedPreferences.OnSharedPreferenceChangeListener)this);
    }

    @Override
    public void s() {
        super.s();
        PreferenceManager.getDefaultSharedPreferences((Context)this.j()).unregisterOnSharedPreferenceChangeListener((SharedPreferences.OnSharedPreferenceChangeListener)this);
    }

    public class a
    extends d {
        public long a;

        a(String string, long l2) {
            super();
            this.c = string;
            this.a = l2;
        }
    }

    public class b
    extends d {
        b() {
            super();
            this.c = e.this.a(2131230895);
            this.f = 2;
            this.h = 4;
        }
    }

    public static interface c {
        public void a(d var1);
    }

    public class d {
        String c;
        float d;
        boolean e;
        int f;
        int g;
        int h;

        public d() {
            this.d = 1.0f;
            this.e = false;
            this.f = 0;
            this.g = 0;
            this.h = 5;
        }

        public String toString() {
            return this.c;
        }
    }

    public class e
    extends d {
        public String a;

        e(String string, String string2) {
            this.c = string;
            this.a = string2;
        }
    }

    public class f
    extends d {
        f() {
            this.c = e.this.a(2131230935);
            this.f = 1;
            this.h = 4;
        }
    }

    public class g
    extends d {
        g() {
            this.c = e.this.a(2131230939);
            this.f = 3;
            this.h = 4;
        }
    }

    private class h {
        ViewGroup a;
        TextView b;
        ImageView c;
        ImageView d;
        View e;

        private h() {
        }
    }

}

