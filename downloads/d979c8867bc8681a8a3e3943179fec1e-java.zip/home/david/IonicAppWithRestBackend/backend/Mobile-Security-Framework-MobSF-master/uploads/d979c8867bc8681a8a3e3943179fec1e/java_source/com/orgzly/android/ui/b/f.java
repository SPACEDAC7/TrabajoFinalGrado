/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.res.TypedArray
 *  android.net.Uri
 *  android.os.Bundle
 *  android.text.Editable
 *  android.text.TextUtils
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.TextView
 *  android.widget.TextView$OnEditorActionListener
 */
package com.orgzly.android.ui.b;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v4.b.n;
import android.text.Editable;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.orgzly.a;
import com.orgzly.android.a.g;
import com.orgzly.android.a.h;
import com.orgzly.android.b.e;
import com.orgzly.android.b.j;
import com.orgzly.android.ui.b.l;

public class f
extends l {
    public static final String a;
    private static final String b;
    private a c;
    private ImageView d;
    private Button e;
    private TextInputLayout f;
    private EditText g;

    static {
        b = f.class.getName();
        a = f.class.getName();
    }

    private void Z() {
        DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
                if (n2 == -1) {
                    f.this.aa();
                }
            }
        };
        new AlertDialog.Builder(this.i()).setTitle(2131230776).setMessage(2131230775).setPositiveButton(2131230956, onClickListener).setNegativeButton(2131230763, onClickListener).show();
    }

    public static f a() {
        return new f();
    }

    public static f a(long l2) {
        f f2 = new f();
        Bundle bundle = new Bundle();
        bundle.putLong("repo_id", l2);
        f2.g(bundle);
        return f2;
    }

    private void aa() {
        if (this.c != null && this.c.m()) {
            this.Y();
        }
    }

    private void ab() {
        if (this.g() != null && this.g().containsKey("repo_id")) {
            long l2 = this.g().getLong("repo_id");
            Uri uri = Uri.parse((String)com.orgzly.android.provider.b.g.b((Context)this.j(), l2));
            this.g.setText((CharSequence)uri.getPath());
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void ac() {
        String string = this.g.getText().toString().trim();
        if (TextUtils.isEmpty((CharSequence)string)) {
            this.f.setError(this.a(2131230762));
            return;
        } else {
            this.f.setError(null);
            string = j.a("dropbox", string);
            g g2 = h.a((Context)this.j(), (Uri)string);
            if (g2 == null) {
                this.f.setError(this.a(2131231026, string));
                return;
            }
            if (this.g() != null && this.g().containsKey("repo_id")) {
                long l2 = this.g().getLong("repo_id");
                if (this.c == null) return;
                {
                    this.c.a(l2, g2);
                    return;
                }
            } else {
                if (this.c == null) return;
                {
                    this.c.a(g2);
                    return;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void Y() {
        Object object = this.j();
        if (this.c != null && object != null) {
            int n2;
            TypedArray typedArray = object.obtainStyledAttributes(a.a.Icons);
            if (this.c.n()) {
                object = this.a(2131230920);
                n2 = typedArray.getResourceId(39, 0);
            } else {
                object = this.a(2131230921);
                n2 = typedArray.getResourceId(38, 0);
            }
            typedArray.recycle();
            this.e.setText((CharSequence)object);
            if (n2 != 0) {
                this.d.setImageResource(n2);
            }
        }
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903103, viewGroup, false);
        this.e = (Button)layoutInflater.findViewById(2131689678);
        this.e.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (f.this.c.n()) {
                    f.this.Z();
                    return;
                }
                f.this.aa();
            }
        });
        this.d = (ImageView)layoutInflater.findViewById(2131689677);
        this.g = (EditText)layoutInflater.findViewById(2131689680);
        this.g.setHorizontallyScrolling(false);
        this.g.setMaxLines(3);
        this.g.setOnEditorActionListener(new TextView.OnEditorActionListener(){

            public boolean onEditorAction(TextView textView, int n2, KeyEvent keyEvent) {
                f.this.ac();
                return true;
            }
        });
        this.ab();
        this.f = (TextInputLayout)layoutInflater.findViewById(2131689679);
        e.a((TextView)this.g, this.f);
        if (this.j() != null) {
            com.orgzly.android.ui.c.a.a(this.j(), (View)this.g);
        }
        return layoutInflater;
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.c = (a)((Object)this.j());
            return;
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + a.class);
        }
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.d(true);
    }

    @Override
    public void a(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(2131820551, menu);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean a(MenuItem menuItem) {
        boolean bl2 = true;
        switch (menuItem.getItemId()) {
            default: {
                return super.a(menuItem);
            }
            case 2131689826: {
                if (this.c == null) return bl2;
                this.c.l();
                return true;
            }
            case 2131689827: 
        }
        this.ac();
        return true;
    }

    @Override
    public void b() {
        super.b();
        this.c = null;
    }

    @Override
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.j().getMenuInflater().inflate(2131820556, (Menu)contextMenu);
    }

    @Override
    public void r() {
        super.r();
        this.Y();
    }

    public static interface a
    extends l.a {
        public boolean m();

        public boolean n();
    }

}

