/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.Editable
 *  android.text.TextUtils
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.EditText
 *  android.widget.ViewFlipper
 */
package com.orgzly.android.ui.b;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v4.b.m;
import android.support.v4.b.n;
import android.support.v4.j.f;
import android.text.Editable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ViewFlipper;
import com.orgzly.android.d;
import com.orgzly.android.ui.e;

public class g
extends m {
    public static final String a;
    private static final String b;
    private a c;
    private ViewFlipper d;
    private TextInputLayout e;
    private EditText f;
    private TextInputLayout g;
    private EditText h;

    static {
        b = g.class.getName();
        a = g.class.getName();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void Y() {
        EditText editText = null;
        if (this.aa()) {
            long l2 = this.g().getLong("id");
            d d2 = com.orgzly.android.provider.b.d.a((Context)this.j(), l2);
            if (d2 != null) {
                this.f.setText((CharSequence)d2.a());
                this.h.setText((CharSequence)d2.b());
                this.d.setDisplayedChild(0);
                editText = this.h;
            } else {
                this.d.setDisplayedChild(1);
            }
        } else {
            editText = this.f;
        }
        if (editText != null && this.j() != null) {
            com.orgzly.android.ui.c.a.a(this.j(), (View)editText);
        }
    }

    private void Z() {
        if (this.aa()) {
            this.c.a(a, this.a(2131230933), null, 0);
            return;
        }
        this.c.a(a, this.a(2131230872), null, 0);
    }

    public static g a() {
        return new g();
    }

    public static g a(long l2) {
        g g2 = new g();
        Bundle bundle = new Bundle();
        bundle.putLong("id", l2);
        g2.g(bundle);
        return g2;
    }

    private boolean aa() {
        if (this.g() != null && this.g().containsKey("id")) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void ab() {
        boolean bl2 = false;
        Object object = this.f.getText().toString();
        String string = this.h.getText().toString();
        boolean bl3 = true;
        if (TextUtils.isEmpty((CharSequence)object)) {
            this.e.setError(this.a(2131230762));
            bl3 = false;
        } else if (this.b((String)object)) {
            this.e.setError(this.a(2131231014));
            bl3 = false;
        } else {
            this.e.setError(null);
        }
        if (TextUtils.isEmpty((CharSequence)string)) {
            this.g.setError(this.a(2131230762));
            bl3 = bl2;
        } else {
            this.g.setError(null);
        }
        if (!bl3) return;
        object = new d((String)object, string);
        if (this.aa()) {
            long l2 = this.g().getLong("id");
            if (this.c == null) return;
            {
                this.c.a(l2, (d)object);
                return;
            }
        }
        if (this.c == null) {
            return;
        }
        this.c.a((d)object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean b(String string) {
        boolean bl2;
        boolean bl3 = false;
        f<d> f2 = com.orgzly.android.provider.b.d.a(this.i(), string);
        if (this.aa()) {
            long l2 = this.g().getLong("id");
            int n2 = 0;
            do {
                bl2 = bl3;
                if (n2 >= f2.b()) return bl2;
                long l3 = f2.b(n2);
                if (string.equalsIgnoreCase(f2.a(l3).a()) && l2 != l3) {
                    return true;
                }
                ++n2;
            } while (true);
        }
        bl2 = bl3;
        if (f2.b() <= 0) return bl2;
        return true;
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903097, viewGroup, false);
        this.d = (ViewFlipper)layoutInflater.findViewById(2131689650);
        this.e = (TextInputLayout)layoutInflater.findViewById(2131689651);
        this.f = (EditText)layoutInflater.findViewById(2131689652);
        this.g = (TextInputLayout)layoutInflater.findViewById(2131689653);
        this.h = (EditText)layoutInflater.findViewById(2131689654);
        this.Y();
        return layoutInflater;
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.c = (a)((Object)this.j());
            return;
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + a.class);
        }
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.d(true);
    }

    @Override
    public void a(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(2131820551, menu);
        menu.removeItem(2131689796);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean a(MenuItem menuItem) {
        boolean bl2 = true;
        switch (menuItem.getItemId()) {
            default: {
                return super.a(menuItem);
            }
            case 2131689826: {
                if (this.c == null) return bl2;
                this.c.w();
                return true;
            }
            case 2131689827: 
        }
        this.ab();
        return true;
    }

    @Override
    public void b() {
        super.b();
        this.c = null;
    }

    @Override
    public void r() {
        super.r();
        this.Z();
    }

    public static interface a
    extends e {
        public void a(long var1, d var3);

        public void a(d var1);

        public void w();
    }

}

