/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  android.os.Bundle
 *  android.view.ActionMode
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.AbsListView
 *  android.widget.AbsListView$MultiChoiceModeListener
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.ViewFlipper
 */
package com.orgzly.android.ui.b;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.b.aa;
import android.support.v4.b.n;
import android.support.v4.b.z;
import android.support.v4.c.l;
import android.support.v4.widget.x;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ViewFlipper;
import com.orgzly.android.ui.d;
import com.orgzly.android.ui.e;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class h
extends z
implements aa.a<Cursor>,
d {
    private static final String aa = h.class.getName();
    public static final String i = h.class.getName();
    private x ab;
    private a ac;
    private boolean ad = false;
    private ViewFlipper ae;

    public static h Z() {
        return new h();
    }

    private void aa() {
        this.ab = new x((Context)this.j(), 2130903110, null, new String[]{"name", "search", "position"}, new int[]{2131689723, 2131689724, 2131689725}, 0);
        this.a((ListAdapter)this.ab);
    }

    private void ab() {
        if (this.ac != null) {
            this.ac.a(i, this.a(2131230935), null, this.e_().getCheckedItemCount());
        }
    }

    @Override
    public l<Cursor> a(int n2, Bundle bundle) {
        return com.orgzly.android.provider.b.d.a((Context)this.j());
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903098, viewGroup, false);
        this.ae = (ViewFlipper)layoutInflater.findViewById(2131689655);
        return layoutInflater;
    }

    @Override
    public Runnable a() {
        return new Runnable(){

            @Override
            public void run() {
                h.this.ac.v();
            }
        };
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.ac = (a)((Object)this.j());
            return;
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + a.class);
        }
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.aa();
    }

    @Override
    public void a(l<Cursor> l2) {
        if (this.ad) {
            this.ab.a((Cursor)null);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void a(l<Cursor> l2, Cursor cursor) {
        if (!this.ad) return;
        this.ab.b(cursor);
        if (this.ab.getCount() > 0) {
            this.ae.setDisplayedChild(0);
            return;
        }
        this.ae.setDisplayedChild(1);
    }

    @Override
    public void a(View view, Bundle bundle) {
        super.a(view, bundle);
        this.ad = true;
        this.e_().setChoiceMode(3);
        this.e_().setMultiChoiceModeListener((AbsListView.MultiChoiceModeListener)new b());
    }

    @Override
    public void a(ListView listView, View view, int n2, long l2) {
        if (this.ac != null) {
            this.ac.j(l2);
        }
    }

    @Override
    public void b() {
        super.b();
        this.ac = null;
    }

    @Override
    public void d(Bundle bundle) {
        super.d(bundle);
        this.j().f().a(5, null, this);
    }

    @Override
    public void e() {
        super.e();
        this.ad = false;
    }

    @Override
    public void r() {
        super.r();
        this.ab();
    }

    public static interface a
    extends e {
        public void a(Set<Long> var1);

        public void j(long var1);

        public void k(long var1);

        public void l(long var1);

        public void v();
    }

    public class b
    implements AbsListView.MultiChoiceModeListener {
        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            TreeSet<Long> treeSet = com.orgzly.android.ui.c.b.a(h.this.e_());
            switch (menuItem.getItemId()) {
                default: {
                    return false;
                }
                case 2131689829: {
                    h.this.ac.k(treeSet.iterator().next());
                    do {
                        return true;
                        break;
                    } while (true);
                }
                case 2131689828: {
                    h.this.ac.l(treeSet.iterator().next());
                    return true;
                }
                case 2131689830: 
            }
            h.this.ac.a(treeSet);
            actionMode.finish();
            return true;
        }

        public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            actionMode.getMenuInflater().inflate(2131820552, menu);
            actionMode.setTitle((CharSequence)String.valueOf(h.this.e_().getCheckedItemCount()));
            return true;
        }

        public void onDestroyActionMode(ActionMode actionMode) {
            h.this.e_().clearChoices();
            h.this.ab();
        }

        /*
         * Enabled aggressive block sorting
         */
        public void onItemCheckedStateChanged(ActionMode actionMode, int n2, long l2, boolean bl2) {
            actionMode.setTitle((CharSequence)String.valueOf(h.this.e_().getCheckedItemCount()));
            if (h.this.e_().getCheckedItemCount() > 1) {
                if (actionMode.getTag() == null) {
                    actionMode.setTag(new Object());
                    actionMode.invalidate();
                }
            } else if (actionMode.getTag() != null) {
                actionMode.setTag((Object)null);
                actionMode.invalidate();
            }
            h.this.ab();
        }

        public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            if (actionMode.getTag() != null) {
                menu.findItem(2131689829).setVisible(false);
                menu.findItem(2131689828).setVisible(false);
                return true;
            }
            menu.findItem(2131689829).setVisible(true);
            menu.findItem(2131689829).setShowAsAction(2);
            menu.findItem(2131689828).setVisible(true);
            menu.findItem(2131689828).setShowAsAction(2);
            return true;
        }
    }

}

