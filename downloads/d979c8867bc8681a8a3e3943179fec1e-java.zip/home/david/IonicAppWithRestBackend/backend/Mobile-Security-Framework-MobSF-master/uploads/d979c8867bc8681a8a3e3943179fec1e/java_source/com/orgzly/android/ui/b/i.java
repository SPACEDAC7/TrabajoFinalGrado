/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.graphics.Typeface
 *  android.os.Bundle
 *  android.text.Editable
 *  android.text.TextUtils
 *  android.text.TextWatcher
 *  android.text.method.LinkMovementMethod
 *  android.text.method.MovementMethod
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.EditText
 *  android.widget.LinearLayout
 *  android.widget.ListAdapter
 *  android.widget.MultiAutoCompleteTextView
 *  android.widget.MultiAutoCompleteTextView$Tokenizer
 *  android.widget.ScrollView
 *  android.widget.Spinner
 *  android.widget.TextView
 *  android.widget.TextView$OnEditorActionListener
 *  android.widget.ToggleButton
 *  android.widget.ViewFlipper
 */
package com.orgzly.android.ui.b;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v4.b.m;
import android.support.v4.b.n;
import android.support.v4.b.r;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.MultiAutoCompleteTextView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.widget.ViewFlipper;
import com.orgzly.a.a.a;
import com.orgzly.a.a.d;
import com.orgzly.a.c;
import com.orgzly.a.e;
import com.orgzly.android.f;
import com.orgzly.android.g;
import com.orgzly.android.k;
import com.orgzly.android.l;
import com.orgzly.android.ui.a.c;
import com.orgzly.android.ui.j;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeSet;

public class i
extends m
implements View.OnClickListener,
c.a {
    public static final String a;
    private static final String b;
    private String aa;
    private f ab;
    private com.orgzly.android.a ac;
    private ScrollView ad;
    private com.orgzly.android.ui.k ae;
    private j af;
    private TextInputLayout ag;
    private EditText ah;
    private MultiAutoCompleteTextView ai;
    private Button aj;
    private Button ak;
    private Button al;
    private LinearLayout am;
    private Button an;
    private ToggleButton ao;
    private EditText ap;
    private TextView aq;
    private ViewFlipper ar;
    private com.orgzly.android.b.g as;
    private boolean at = false;
    private a c;
    private k d;
    private boolean e;
    private long f;
    private long g;
    private com.orgzly.android.ui.l h;
    private String i;

    static {
        b = i.class.getName();
        a = i.class.getName();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void Z() {
        c c2 = this.ab.b();
        this.ae.a(c2.o());
        this.af.a(c2.n());
        this.ah.setText((CharSequence)c2.a());
        if (c2.c()) {
            this.ai.setText((CharSequence)TextUtils.join((CharSequence)" ", c2.b()));
        } else {
            this.ai.setText(null);
        }
        this.a(b.a, (TextView)this.aj, c2.f());
        this.a(b.b, (TextView)this.ak, c2.j());
        this.a(b.c, (TextView)this.al, c2.h());
        this.am.removeAllViews();
        if (c2.q()) {
            Iterator<e> iterator = c2.p().iterator();
            while (iterator.hasNext()) {
                this.a(iterator.next());
            }
        }
        this.ap.setText((CharSequence)c2.d());
        this.aq.setText((CharSequence)com.orgzly.android.b.f.a(c2.d()));
    }

    private long a(f f2) {
        return com.orgzly.android.b.e.c(new com.orgzly.a.b.j().a(f2.b(), f2.a().e(), false));
    }

    public static i a(boolean bl2, long l2, long l3, com.orgzly.android.ui.l l4, String string, String string2) {
        i i2 = new i();
        Bundle bundle = new Bundle();
        bundle.putBoolean("is_new", bl2);
        bundle.putLong("book_id", l2);
        if (l3 > 0) {
            bundle.putLong("note_id", l3);
        }
        bundle.putString("placement", l4.toString());
        if (string != null) {
            bundle.putString("title", string);
        }
        if (string2 != null) {
            bundle.putString("content", string2);
        }
        i2.g(bundle);
        return i2;
    }

    private void a(Context object, f f2, String string) {
        object = new l(com.orgzly.android.prefs.a.v((Context)object), com.orgzly.android.prefs.a.x((Context)object));
        object.a(string, f2.b().o(), f2.b().f(), f2.b().j());
        f2.b().e(object.a());
        f2.b().a(object.b());
        f2.b().c(object.c());
        f2.b().b(object.d());
        this.ae.a(object.a());
        this.a(b.a, (TextView)this.aj, object.b());
        this.a(b.b, (TextView)this.ak, object.c());
        this.a(b.c, (TextView)this.al, object.d());
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(e object) {
        final ViewGroup viewGroup = (ViewGroup)View.inflate((Context)this.j(), (int)2130903116, (ViewGroup)null);
        TextView textView = (TextView)viewGroup.findViewById(2131689614);
        TextView textView2 = (TextView)viewGroup.findViewById(2131689759);
        View view = viewGroup.findViewById(2131689760);
        if (object != null) {
            textView.setText((CharSequence)object.a());
            textView2.setText((CharSequence)object.b());
        } else {
            object = this.j();
            if (object != null) {
                com.orgzly.android.ui.c.a.a((Activity)object, (View)textView);
            }
        }
        view.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                i.this.am.removeView((View)viewGroup);
            }
        });
        this.am.addView((View)viewGroup);
    }

    private void a(b b2, TextView textView, d d2) {
        switch (.a[b2.ordinal()]) {
            default: {
                return;
            }
            case 1: {
                if (d2 != null) {
                    textView.setText((CharSequence)this.as.a(d2));
                    return;
                }
                textView.setText((CharSequence)this.a(2131230930));
                return;
            }
            case 2: {
                if (d2 != null) {
                    textView.setText((CharSequence)this.as.a(d2));
                    textView.setVisibility(0);
                    return;
                }
                textView.setVisibility(8);
                return;
            }
            case 3: 
        }
        if (d2 != null) {
            textView.setText((CharSequence)this.as.a(d2));
            return;
        }
        textView.setText((CharSequence)this.a(2131230786));
    }

    private void aa() {
        c c2 = this.ab.b();
        c2.e(this.ae.a());
        c2.d(this.af.a());
        c2.a(this.ah.getText().toString().replaceAll("\n", " ").trim());
        c2.a(this.ai.getText().toString().split("\\s+"));
        c2.r();
        for (int i2 = 0; i2 < this.am.getChildCount(); ++i2) {
            Object object = this.am.getChildAt(i2);
            CharSequence charSequence = ((TextView)object.findViewById(2131689614)).getText();
            object = ((TextView)object.findViewById(2131689759)).getText();
            if (TextUtils.isEmpty((CharSequence)charSequence)) continue;
            c2.a(new e(charSequence.toString(), object.toString()));
        }
        c2.b(this.ap.getText().toString());
    }

    private void ab() {
        ArrayAdapter arrayAdapter = this.d.d(0);
        arrayAdapter = new ArrayAdapter((Context)this.j(), 2130903093, (Object[])arrayAdapter);
        this.ai.setAdapter((ListAdapter)arrayAdapter);
        this.ai.setTokenizer((MultiAutoCompleteTextView.Tokenizer)new com.orgzly.android.b.i());
    }

    private void ac() {
        if (this.c != null) {
            this.c.a(a, com.orgzly.android.a.a(this.ac), com.orgzly.android.a.b(this.ac), 0);
        }
    }

    private void ad() {
        if (this.g() == null) {
            throw new IllegalArgumentException("No arguments found to " + i.class.getSimpleName());
        }
        this.e = this.g().getBoolean("is_new");
        if (!this.g().containsKey("book_id")) {
            throw new IllegalArgumentException(i.class.getSimpleName() + " requires " + "book_id" + " argument passed");
        }
        this.f = this.g().getLong("book_id");
        if (this.g().containsKey("note_id")) {
            this.g = this.g().getLong("note_id");
            if (this.g <= 0) {
                throw new IllegalArgumentException("Note id is " + this.g);
            }
        }
        this.h = com.orgzly.android.ui.l.valueOf(this.g().getString("placement"));
        this.i = this.g().getString("title");
        this.aa = this.g().getString("content");
    }

    /*
     * Enabled aggressive block sorting
     */
    private void ae() {
        Object object;
        c c2 = this.ab.b();
        if (com.orgzly.android.prefs.a.s(this.i())) {
            object = Calendar.getInstance();
            c2.a(d.a(new a.a().a(true).a(object.get(1)).b(object.get(2)).c(object.get(5)).a()));
        }
        if (com.orgzly.android.ui.k.b((String)(object = com.orgzly.android.prefs.a.t(this.i())))) {
            c2.e((String)object);
        } else {
            c2.e(null);
        }
        if (this.i != null) {
            c2.a(this.i);
        }
        object = new StringBuilder();
        if (com.orgzly.android.prefs.a.i(this.i())) {
            c2.a(new e(com.orgzly.android.prefs.a.j(this.i()), com.orgzly.a.a.a.a(false).toString()));
        }
        if (this.aa != null) {
            if (object.length() > 0) {
                object.append("\n\n");
            }
            object.append(this.aa);
        }
        if (object.length() > 0) {
            c2.b(object.toString());
        }
    }

    private void af() {
        new AlertDialog.Builder(this.i()).setTitle(2131230997).setMessage(2131230998).setPositiveButton(2131230787, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
                i.this.c.e(i.this.ab);
            }
        }).setNegativeButton(2131230763, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
            }
        }).create().show();
    }

    private void ag() {
        this.c.d(this.ab);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void ah() {
        if (this.ab.a().f() == 0) {
            n n2 = this.j();
            if (n2 == null) return;
            {
                ((com.orgzly.android.ui.b)n2).c(2131230887);
                return;
            }
        } else if (this.e) {
            if (!this.ai()) return;
            {
                a a2 = this.c;
                f f2 = this.ab;
                com.orgzly.android.ui.i i2 = this.h != com.orgzly.android.ui.l.d ? new com.orgzly.android.ui.i(this.ab.a().f(), this.g, this.h) : null;
                a2.a(f2, i2);
                return;
            }
        } else {
            if (!this.ai()) return;
            {
                this.c.a(this.ab);
                return;
            }
        }
    }

    private boolean ai() {
        this.aa();
        n n2 = this.j();
        if (TextUtils.isEmpty((CharSequence)this.ab.b().a())) {
            if (n2 != null) {
                this.ag.setError(this.a(2131230762));
            }
            return false;
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void c(Bundle bundle) {
        c c2 = this.ab.b();
        bundle.putString("current_state", c2.o());
        bundle.putString("current_priority", c2.n());
        bundle.putString("current_title", c2.a());
        bundle.putString("current_tags", TextUtils.join((CharSequence)" ", c2.b()));
        if (c2.f() != null) {
            bundle.putString("current_scheduled", c2.f().toString());
        }
        if (c2.j() != null) {
            bundle.putString("current_deadline", c2.j().toString());
        }
        if (c2.h() != null) {
            bundle.putString("current_closed", c2.h().toString());
        }
        if (c2.q()) {
            ArrayList<String> arrayList = new ArrayList<String>();
            for (e e2 : c2.p()) {
                arrayList.add(e2.a());
                arrayList.add(e2.b());
            }
            bundle.putStringArrayList("current_properties", arrayList);
        } else {
            bundle.remove("current_properties");
        }
        bundle.putString("current_content", c2.d());
    }

    /*
     * Enabled aggressive block sorting
     */
    private void m(Bundle bundle) {
        c c2 = this.ab.b();
        c2.e(bundle.getString("current_state"));
        c2.d(bundle.getString("current_priority"));
        c2.a(bundle.getString("current_title"));
        if (bundle.getString("current_tags") != null) {
            c2.a(bundle.getString("current_tags").split("\\s+"));
        } else {
            c2.a(new String[0]);
        }
        if (TextUtils.isEmpty((CharSequence)bundle.getString("current_scheduled"))) {
            c2.a((d)null);
        } else {
            c2.a(d.b(bundle.getString("current_scheduled")));
        }
        if (TextUtils.isEmpty((CharSequence)bundle.getString("current_deadline"))) {
            c2.c((d)null);
        } else {
            c2.c(d.b(bundle.getString("current_deadline")));
        }
        if (TextUtils.isEmpty((CharSequence)bundle.getString("current_closed"))) {
            c2.b((d)null);
        } else {
            c2.b(d.b(bundle.getString("current_closed")));
        }
        c2.r();
        if (bundle.containsKey("current_properties")) {
            ArrayList arrayList = bundle.getStringArrayList("current_properties");
            for (int i2 = 0; i2 < arrayList.size(); i2 += 2) {
                c2.a(new e((String)arrayList.get(i2), (String)arrayList.get(i2 + 1)));
            }
        }
        c2.b(bundle.getString("current_content"));
    }

    public boolean Y() {
        this.aa();
        if (this.a(this.ab) != this.g().getLong("original_note_hash")) {
            return true;
        }
        return false;
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903100, viewGroup, false);
        this.ad = (ScrollView)layoutInflater.findViewById(2131689658);
        this.af = new j((Context)this.j(), (Spinner)layoutInflater.findViewById(2131689659));
        this.ae = new com.orgzly.android.ui.k((Context)this.j(), (Spinner)layoutInflater.findViewById(2131689660));
        this.ae.c().setOnTouchListener(new View.OnTouchListener(){

            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 0) {
                    i.this.at = true;
                }
                return false;
            }
        });
        this.ae.c().setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> object, View view, int n2, long l2) {
                if (i.this.at) {
                    object = object.getItemAtPosition(n2).toString();
                    i.this.a((Context)i.this.j(), i.this.ab, (String)object);
                }
                i.this.at = false;
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.ag = (TextInputLayout)layoutInflater.findViewById(2131689661);
        this.ah = (EditText)layoutInflater.findViewById(2131689662);
        com.orgzly.android.b.e.a((TextView)this.ah, this.ag);
        this.ah.setHorizontallyScrolling(false);
        this.ah.setMaxLines(3);
        this.ah.setOnEditorActionListener(new TextView.OnEditorActionListener(){

            public boolean onEditorAction(TextView textView, int n2, KeyEvent keyEvent) {
                i.this.ah();
                return true;
            }
        });
        this.ai = (MultiAutoCompleteTextView)layoutInflater.findViewById(2131689663);
        this.ai.addTextChangedListener(new TextWatcher(){

            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
            }

            public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
                if (!TextUtils.isEmpty((CharSequence)i.this.ai.getText().toString())) {
                    i.this.ai.setHint((CharSequence)"");
                    return;
                }
                i.this.ai.setHint(2131230828);
            }
        });
        this.aj = (Button)layoutInflater.findViewById(2131689664);
        this.aj.setOnClickListener((View.OnClickListener)this);
        this.ak = (Button)layoutInflater.findViewById(2131689665);
        this.ak.setOnClickListener((View.OnClickListener)this);
        this.al = (Button)layoutInflater.findViewById(2131689666);
        this.al.setOnClickListener((View.OnClickListener)this);
        this.am = (LinearLayout)layoutInflater.findViewById(2131689757);
        this.an = (Button)layoutInflater.findViewById(2131689758);
        this.an.setOnClickListener((View.OnClickListener)this);
        this.ap = (EditText)layoutInflater.findViewById(2131689668);
        this.aq = (TextView)layoutInflater.findViewById(2131689669);
        this.aq.setMovementMethod(LinkMovementMethod.getInstance());
        if (this.j() != null && com.orgzly.android.prefs.a.e(this.i())) {
            this.ap.setTypeface(Typeface.MONOSPACE);
            this.aq.setTypeface(Typeface.MONOSPACE);
        }
        this.ao = (ToggleButton)layoutInflater.findViewById(2131689667);
        this.ao.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl2) {
                if (bl2) {
                    i.this.aq.setVisibility(8);
                    i.this.ap.setVisibility(0);
                    return;
                }
                i.this.ap.setVisibility(8);
                i.this.aq.setText((CharSequence)com.orgzly.android.b.f.a(i.this.ap.getText().toString()));
                i.this.aq.setVisibility(0);
                com.orgzly.android.ui.c.a.a(i.this.j());
            }
        });
        this.ao.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (i.this.ao.isChecked()) {
                    com.orgzly.android.ui.c.a.a(i.this.j(), (View)i.this.ap);
                    return;
                }
                i.this.ad.smoothScrollTo(0, 0);
            }
        });
        this.ar = (ViewFlipper)layoutInflater.findViewById(2131689657);
        return layoutInflater;
    }

    @Override
    public void a(int n2, TreeSet<Long> treeSet) {
        switch (n2) {
            default: {
                return;
            }
            case 2131689664: {
                this.a(b.a, (TextView)this.aj, null);
                this.ab.b().a((d)null);
                return;
            }
            case 2131689665: {
                this.a(b.b, (TextView)this.ak, null);
                this.ab.b().c((d)null);
                return;
            }
            case 2131689666: 
        }
        this.a(b.c, (TextView)this.al, null);
        this.ab.b().b((d)null);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(int n2, TreeSet<Long> object, com.orgzly.a.a.a a2) {
        object = d.a(a2);
        switch (n2) {
            case 2131689664: {
                this.a(b.a, (TextView)this.aj, (d)object);
                this.ab.b().a((d)object);
                return;
            }
            case 2131689665: {
                this.a(b.b, (TextView)this.ak, (d)object);
                this.ab.b().c((d)object);
                object = this.j();
                if (object != null) {
                    ((com.orgzly.android.ui.b)object).c(2131230826);
                    return;
                }
            }
            default: {
                return;
            }
            case 2131689666: 
        }
        this.a(b.c, (TextView)this.al, (d)object);
        this.ab.b().b((d)object);
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.c = (a)((Object)this.j());
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + a.class);
        }
        this.d = new k(this.j().getApplicationContext());
        this.ad();
        this.as = new com.orgzly.android.b.g(this.j().getApplicationContext());
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.d(true);
    }

    @Override
    public void a(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(2131820553, menu);
        menu.removeItem(2131689796);
        if (this.ab == null) {
            menu.removeItem(2131689826);
            menu.removeItem(2131689827);
            menu.removeItem(2131689760);
        }
        if (this.e) {
            menu.removeItem(2131689760);
        }
    }

    @Override
    public void a(View view, Bundle bundle) {
        super.a(view, bundle);
    }

    public void a(com.orgzly.android.a a2) {
        this.ac = a2;
        this.f = a2.a();
        this.ab.a().c(this.f);
        this.g().putLong("book_id", a2.a());
    }

    public boolean a() {
        if (this.ab != null && this.Y()) {
            new AlertDialog.Builder(this.i()).setTitle(2131230891).setMessage(2131230792).setPositiveButton(2131230928, new DialogInterface.OnClickListener(){

                public void onClick(DialogInterface dialogInterface, int n2) {
                    i.this.ah();
                }
            }).setNegativeButton(2131230791, new DialogInterface.OnClickListener(){

                public void onClick(DialogInterface dialogInterface, int n2) {
                    i.this.ag();
                }
            }).setNeutralButton(2131230763, null).create().show();
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean a(MenuItem menuItem) {
        boolean bl2 = true;
        switch (menuItem.getItemId()) {
            default: {
                return super.a(menuItem);
            }
            case 2131689827: {
                this.ah();
                return true;
            }
            case 2131689826: {
                if (this.a()) return bl2;
                this.ag();
                return true;
            }
            case 2131689760: 
        }
        this.af();
        return true;
    }

    @Override
    public void b() {
        super.b();
        this.c = null;
    }

    @Override
    public void b(int n2, TreeSet<Long> treeSet) {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void d(Bundle bundle) {
        super.d(bundle);
        this.ab();
        if (this.f != 0) {
            this.ac = this.d.a(this.f);
        }
        if (this.e) {
            this.ab = new f();
            this.ab.a().c(this.f);
            this.ae();
            this.ar.setDisplayedChild(0);
            this.ao.setChecked(true);
            if (TextUtils.isEmpty((CharSequence)this.i) && TextUtils.isEmpty((CharSequence)this.aa)) {
                com.orgzly.android.ui.c.a.a(this.j(), (View)this.ah);
            }
        } else {
            try {
                this.ab = this.d.b(this.g);
                this.ab.b().a(this.d.c(this.g));
                this.ar.setDisplayedChild(0);
            }
            catch (NoSuchElementException var2_2) {
                this.ab = null;
                this.ar.setDisplayedChild(1);
            }
        }
        if (this.ab != null) {
            if (bundle != null) {
                this.m(bundle);
            }
            this.Z();
        }
        if (!this.g().containsKey("original_note_hash") && this.ab != null) {
            this.g().putLong("original_note_hash", this.a(this.ab));
        }
        if (this.j() != null) {
            this.j().c_();
        }
    }

    @Override
    public void e() {
        super.e();
        this.ar.setDisplayedChild(0);
    }

    @Override
    public void e(Bundle bundle) {
        super.e(bundle);
        if (this.ab != null) {
            this.aa();
            this.c(bundle);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onClick(View object) {
        Object var5_2 = null;
        Object var6_3 = null;
        Object var7_4 = null;
        Object var4_5 = null;
        switch (object.getId()) {
            default: {
                object = var4_5;
                break;
            }
            case 2131689664: {
                long l2 = this.ab.c();
                object = var5_2;
                if (this.ab.b().f() != null) {
                    object = this.ab.b().f().a();
                }
                object = com.orgzly.android.ui.a.c.a(2131689664, 2131230929, l2, (com.orgzly.a.a.a)object);
                break;
            }
            case 2131689665: {
                long l3 = this.ab.c();
                object = var6_3;
                if (this.ab.b().j() != null) {
                    object = this.ab.b().j().a();
                }
                object = com.orgzly.android.ui.a.c.a(2131689665, 2131230785, l3, (com.orgzly.a.a.a)object);
                break;
            }
            case 2131689666: {
                long l4 = this.ab.c();
                object = var7_4;
                if (this.ab.b().h() != null) {
                    object = this.ab.b().h().a();
                }
                object = com.orgzly.android.ui.a.c.a(2131689666, 2131230770, l4, (com.orgzly.a.a.a)object);
                break;
            }
            case 2131689758: {
                this.a((e)null);
                object = var4_5;
            }
        }
        if (object != null) {
            object.a(this, 0);
            object.a(this.j().e(), com.orgzly.android.ui.a.c.aa);
        }
    }

    @Override
    public void r() {
        super.r();
        this.ac();
        this.ae.b(this.j().getApplicationContext());
        this.af.b(this.j().getApplicationContext());
    }

    public static interface a
    extends com.orgzly.android.ui.e {
        public void a(f var1);

        public void a(f var1, com.orgzly.android.ui.i var2);

        public void d(f var1);

        public void e(f var1);
    }

    private static enum b {
        a,
        b,
        c,
        d;
        

        private b() {
        }
    }

}

