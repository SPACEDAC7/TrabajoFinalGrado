/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 *  android.widget.ListAdapter
 *  android.widget.ListView
 */
package com.orgzly.android.ui.b;

import android.os.Bundle;
import android.support.v4.b.n;
import android.support.v4.b.r;
import android.support.v4.b.z;
import android.support.v7.view.b;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.orgzly.a.a.d;
import com.orgzly.a.c;
import com.orgzly.android.f;
import com.orgzly.android.k;
import com.orgzly.android.ui.e;
import com.orgzly.android.ui.i;
import com.orgzly.android.ui.l;
import com.orgzly.android.ui.m;
import com.orgzly.android.ui.views.GesturedListView;
import java.util.Set;
import java.util.TreeSet;

public abstract class j
extends z {
    protected k aa;
    protected m ab;
    protected com.orgzly.android.ui.a ac;

    private com.orgzly.a.a.a a(long l2) {
        f f2 = this.aa.b(l2);
        if (f2.b().g()) {
            return f2.b().f().a();
        }
        return null;
    }

    @Override
    public /* synthetic */ ListAdapter Y() {
        return this.af();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected long a(l object) {
        if (object == l.a) {
            object = this.ab.b().first();
            do {
                return object.longValue();
                break;
            } while (true);
        }
        object = this.ab.b().last();
        return object.longValue();
    }

    protected void a(int n2, long l2) {
        TreeSet<Long> treeSet = new TreeSet<Long>();
        treeSet.add(l2);
        this.c(n2, treeSet);
    }

    public abstract String aa();

    public abstract b.a ab();

    public m ad() {
        return this.ab;
    }

    public GesturedListView ae() {
        return (GesturedListView)super.e_();
    }

    public com.orgzly.android.ui.f af() {
        return (com.orgzly.android.ui.f)super.Y();
    }

    protected void c(int n2, TreeSet<Long> object) {
        com.orgzly.a.a.a a2 = null;
        if (object.size() == 1) {
            a2 = this.a(object.first());
        }
        object = com.orgzly.android.ui.a.c.a(n2, 2131230929, object, a2);
        object.a(this, 0);
        object.a(this.j().e(), com.orgzly.android.ui.a.c.aa);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void e(Bundle bundle) {
        super.e(bundle);
        if (this.ab != null) {
            this.ab.a(bundle);
        }
        if (this.ac != null) {
            boolean bl2 = this.ac.b() != null && "M".equals(this.ac.b().j());
            bundle.putBoolean("actionModeMove", bl2);
        }
    }

    @Override
    public /* synthetic */ ListView e_() {
        return this.ae();
    }

    public static interface a
    extends e {
        public void a(long var1);

        public void a(long var1, int var3);

        public void a(j var1, View var2, int var3, long var4);

        public void a(i var1);

        public void a(Set<Long> var1, com.orgzly.a.a.a var2);

        public void a(Set<Long> var1, String var2);

        public void b(long var1);

        public void b(j var1, View var2, int var3, long var4);
    }

}

