/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.SubMenu
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemLongClickListener
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.Spinner
 *  android.widget.ViewFlipper
 */
package com.orgzly.android.ui.b;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.b.aa;
import android.support.v4.b.n;
import android.support.v4.c.l;
import android.support.v4.widget.x;
import android.support.v7.view.b;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.ViewFlipper;
import com.orgzly.android.ui.a.c;
import com.orgzly.android.ui.b.j;
import com.orgzly.android.ui.f;
import com.orgzly.android.ui.g;
import com.orgzly.android.ui.m;
import com.orgzly.android.ui.views.GesturedListView;
import com.orgzly.android.ui.views.b;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class k
extends j
implements aa.a<Cursor>,
c.a {
    private static final String ad = k.class.getName();
    public static final String i = k.class.getName();
    private x ae;
    private com.orgzly.android.j af;
    private j.a ag;
    private String ah;
    private ViewFlipper ai;

    private void ac() {
        if (this.ag != null) {
            this.ag.a(i, this.a(2131230830), this.af.toString(), this.ab.a());
        }
    }

    private void ag() {
        if (this.g() == null) {
            throw new IllegalArgumentException("No arguments found to " + k.class.getSimpleName());
        }
        this.af = new com.orgzly.android.j(this.g().getString("query"));
    }

    public static k b(String string) {
        k k2 = new k();
        Bundle bundle = new Bundle();
        bundle.putString("query", string);
        bundle.putBoolean("fresh", true);
        k2.g(bundle);
        return k2;
    }

    public com.orgzly.android.j Z() {
        return this.af;
    }

    @Override
    public l<Cursor> a(int n2, Bundle bundle) {
        return com.orgzly.android.provider.b.f.a((Context)this.j(), this.af);
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903101, viewGroup, false);
        this.ai = (ViewFlipper)layoutInflater.findViewById(2131689670);
        return layoutInflater;
    }

    @Override
    public void a(int n2, TreeSet<Long> treeSet) {
        switch (n2) {
            default: {
                return;
            }
            case 2131689746: 
            case 2131689832: 
        }
        this.ag.a(treeSet, (com.orgzly.a.a.a)null);
    }

    @Override
    public void a(int n2, TreeSet<Long> treeSet, com.orgzly.a.a.a a2) {
        switch (n2) {
            default: {
                return;
            }
            case 2131689746: 
            case 2131689832: 
        }
        this.ag.a(treeSet, a2);
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.ag = (j.a)((Object)this.j());
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + j.a.class);
        }
        try {
            this.ac = (com.orgzly.android.ui.a)((Object)this.j());
            return;
        }
        catch (ClassCastException var1_3) {
            throw new ClassCastException(this.j().toString() + " must implement " + com.orgzly.android.ui.a.class);
        }
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.ag();
        if (bundle != null && bundle.getBoolean("actionModeMove", false)) {
            this.ah = "M";
        }
    }

    @Override
    public void a(l<Cursor> l2) {
        if (this.ae == null) {
            return;
        }
        this.ae.a((Cursor)null);
    }

    @Override
    public void a(l<Cursor> object, Cursor cursor) {
        if (this.ae == null) {
            return;
        }
        this.ae.b(cursor);
        this.ac.a(this.ab, new a());
        object = this.ac.b();
        if (this.ah != null) {
            object.a((Object)"M");
            object.d();
            this.ah = null;
        }
        if (this.ae.getCount() > 0) {
            this.ai.setDisplayedChild(0);
            return;
        }
        this.ai.setDisplayedChild(1);
    }

    @Override
    public void a(View view, Bundle bundle) {
        super.a(view, bundle);
        this.ae().setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){

            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int n2, long l2) {
                k.this.ag.b(k.this, view, n2, l2);
                return true;
            }
        });
        this.ae().setOnItemMenuButtonClickListener(new GesturedListView.b(){

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Override
            public boolean a(int var1_1, long var2_2) {
                switch (var1_1) {
                    case 2131689746: {
                        k.this.a(2131689746, var2_2);
                        ** break;
                    }
                    case 2131689747: {
                        k.a(k.this).a(var2_2, -1);
                        ** break;
                    }
                    case 2131689748: {
                        k.a(k.this).a(var2_2, 1);
                        ** break;
                    }
                    case 2131689749: {
                        if (com.orgzly.android.prefs.a.a((Context)k.this.j(), "DONE") == false) return false;
                        var4_3 = new TreeSet<Long>();
                        var4_3.add(var2_2);
                        k.a(k.this).a(var4_3, "DONE");
                    }
lbl16: // 5 sources:
                    default: {
                        return false;
                    }
                    case 2131689754: 
                }
                k.a(k.this).a(var2_2);
                return false;
            }
        });
        this.ab = new m();
        this.ae = new f((Context)this.j(), this.ab, this.ae().getItemMenus(), false);
        this.a((ListAdapter)this.ae);
        this.ab.b(bundle);
    }

    @Override
    public void a(ListView listView, View view, int n2, long l2) {
        this.ag.a(this, view, n2, l2);
    }

    @Override
    public String aa() {
        return i;
    }

    @Override
    public b.a ab() {
        return new a();
    }

    @Override
    public void b() {
        super.b();
        this.ag = null;
        this.ac = null;
    }

    @Override
    public void b(int n2, TreeSet<Long> treeSet) {
    }

    @Override
    public void d(Bundle bundle) {
        super.d(bundle);
        this.aa = new com.orgzly.android.k(this.j().getApplicationContext());
        this.ac.a(this.ab, new a());
        int n2 = g.a(3, this.af.toString());
        this.j().f().a(n2, null, this);
    }

    @Override
    public void e() {
        super.e();
        this.a(null);
        this.ae = null;
    }

    @Override
    public void i(Bundle bundle) {
        super.i(bundle);
    }

    @Override
    public void r() {
        super.r();
        this.ac();
    }

    public class a
    implements b.a {
        @Override
        public void a(android.support.v7.view.b b2) {
            k.this.ab.c();
            if (k.this.af() != null) {
                k.this.af().notifyDataSetChanged();
            }
            k.this.ac.c();
        }

        @Override
        public boolean a(android.support.v7.view.b b2, Menu menu) {
            b2.a().inflate(2131820554, menu);
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public boolean a(android.support.v7.view.b b2, MenuItem iterator) {
            switch (iterator.getItemId()) {
                default: {
                    if (iterator.getGroupId() != 1) return false;
                    {
                        if (k.this.ag == null) return true;
                        {
                            k.this.ag.a(k.this.ab.b(), iterator.getTitle().toString());
                        }
                        return true;
                    }
                }
                case 2131689832: {
                    k.this.c(2131689832, k.this.ab.b());
                    return true;
                }
                case 2131689833: {
                    b2 = iterator.getSubMenu();
                    if (b2 == null) return true;
                    b2.clear();
                    iterator = new com.orgzly.android.ui.k((Context)k.this.j(), null).d().iterator();
                    while (iterator.hasNext()) {
                        b2.add(1, 0, 0, (CharSequence)iterator.next());
                    }
                    break block0;
                }
            }
            return true;
        }

        @Override
        public boolean b(android.support.v7.view.b b2, Menu menu) {
            b2.b(String.valueOf(k.this.ab.a()));
            return true;
        }
    }

}

