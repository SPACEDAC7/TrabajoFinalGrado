/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.ui.b;

import android.support.v4.b.m;
import com.orgzly.android.a.g;

public class l
extends m {

    public static interface a {
        public void a(long var1, g var3);

        public void a(g var1);

        public void l();
    }

}

