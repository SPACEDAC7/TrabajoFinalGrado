/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Handler
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.SubMenu
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.AdapterView
 *  android.widget.AdapterView$AdapterContextMenuInfo
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.TextView
 *  android.widget.ViewFlipper
 */
package com.orgzly.android.ui.b;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.b.aa;
import android.support.v4.b.n;
import android.support.v4.b.z;
import android.support.v4.c.i;
import android.support.v4.c.l;
import android.support.v4.widget.x;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ViewFlipper;
import com.orgzly.android.b.j;
import com.orgzly.android.provider.e;
import com.orgzly.android.ui.b;

public class m
extends z
implements aa.a<Cursor> {
    private static final String aa = m.class.getName();
    public static final String i = m.class.getName();
    private x ab;
    private a ac;
    private ViewFlipper ad;

    public static m Z() {
        return new m();
    }

    private void aa() {
        this.ab = new x((Context)this.j(), 2130903114, null, new String[]{"repo_url"}, new int[]{2131689755}, 0);
        this.ab.a(new x.b(){

            @Override
            public boolean a(View view, Cursor cursor, int n2) {
                switch (view.getId()) {
                    default: {
                        return false;
                    }
                    case 2131689755: 
                }
                if (!cursor.isNull(n2)) {
                    ((TextView)view).setText((CharSequence)j.a(cursor.getString(n2)));
                }
                return true;
            }
        });
        this.a((ListAdapter)this.ab);
    }

    @Override
    public l<Cursor> a(int n2, Bundle bundle) {
        return new i((Context)this.j(), e.r.a.a(), null, null, null, "repo_url");
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903104, viewGroup, false);
        this.ad = (ViewFlipper)layoutInflater.findViewById(2131689681);
        layoutInflater.findViewById(2131689682).setVisibility(8);
        layoutInflater.findViewById(2131689683).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                m.this.ac.d(2131689836);
            }
        });
        return layoutInflater;
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.ac = (a)((Object)this.j());
            return;
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + a.class);
        }
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.d(true);
        this.aa();
    }

    @Override
    public void a(l<Cursor> l2) {
        this.ab.a((Cursor)null);
    }

    @Override
    public void a(l<Cursor> l2, Cursor cursor) {
        this.ab.b(cursor);
        if (this.ab.getCount() > 0) {
            this.ad.setDisplayedChild(0);
            return;
        }
        this.ad.setDisplayedChild(1);
    }

    @Override
    public void a(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(2131820555, menu);
        menu.findItem(2131689834).getSubMenu().removeItem(2131689835);
    }

    @Override
    public void a(View view, Bundle bundle) {
        super.a(view, bundle);
        this.a((View)this.e_());
    }

    @Override
    public void a(ListView listView, View view, int n2, long l2) {
        if (this.ac != null) {
            this.ac.b(l2);
        }
    }

    @Override
    public boolean a(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            default: {
                return super.a(menuItem);
            }
            case 2131689835: {
                this.ac.d(menuItem.getItemId());
                return true;
            }
            case 2131689836: 
        }
        if (com.orgzly.android.b.a.a((b)this.j(), 1)) {
            this.ac.d(menuItem.getItemId());
        }
        return true;
    }

    @Override
    public void b() {
        super.b();
        this.ac = null;
    }

    @Override
    public boolean b(MenuItem menuItem) {
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo)menuItem.getMenuInfo();
        switch (menuItem.getItemId()) {
            default: {
                return super.b(menuItem);
            }
            case 2131689837: 
        }
        this.ac.a(adapterContextMenuInfo.id);
        return true;
    }

    @Override
    public void d(Bundle bundle) {
        super.d(bundle);
        new Handler().postDelayed(new Runnable(){

            @Override
            public void run() {
                m.this.j().f().a(4, null, m.this);
            }
        }, 100);
    }

    @Override
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.j().getMenuInflater().inflate(2131820556, (Menu)contextMenu);
    }

    @Override
    public void r() {
        super.r();
        com.orgzly.android.ui.c.a.a(this.j());
    }

    public static interface a {
        public void a(long var1);

        public void b(long var1);

        public void d(int var1);
    }

}

