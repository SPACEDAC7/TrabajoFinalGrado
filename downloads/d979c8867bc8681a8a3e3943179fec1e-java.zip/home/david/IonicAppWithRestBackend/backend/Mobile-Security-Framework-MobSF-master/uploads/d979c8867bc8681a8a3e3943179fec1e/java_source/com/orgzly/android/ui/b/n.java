/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$OnSharedPreferenceChangeListener
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.preference.Preference
 *  android.preference.Preference$OnPreferenceClickListener
 *  android.preference.PreferenceManager
 *  android.text.TextUtils
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ListView
 */
package com.orgzly.android.ui.b;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import com.orgzly.android.a.g;
import com.orgzly.android.i;
import com.orgzly.android.prefs.ListPreferenceWithValueAsSummary;
import com.orgzly.android.ui.e;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;

public class n
extends com.a.a.a.a
implements SharedPreferences.OnSharedPreferenceChangeListener {
    public static final String a = n.class.getName();
    public static final String b = n.class.getName();
    private static final int[] c = new int[]{2131231071, 2131231065, 2131231082};
    private Preference d;
    private a e;

    public static n Z() {
        return new n();
    }

    private void ab() {
        if (this.e != null) {
            this.e.a(b, this.a(2131230833), null, 0);
        }
    }

    private void ac() {
        Preference preference = this.a(this.a(2131231093));
        preference.setSummary((CharSequence)"1.4.11 (fdroid)");
        preference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener(){

            public boolean onPreferenceClick(Preference preference) {
                if (n.this.e != null) {
                    n.this.e.p();
                }
                return true;
            }
        });
    }

    private void ad() {
        LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>();
        linkedHashSet.add("NOTE");
        linkedHashSet.addAll(com.orgzly.android.prefs.a.v(this.i()));
        Object object = linkedHashSet.toArray(new CharSequence[linkedHashSet.size()]);
        ListPreferenceWithValueAsSummary listPreferenceWithValueAsSummary = (ListPreferenceWithValueAsSummary)this.a(this.a(2131231085));
        listPreferenceWithValueAsSummary.setEntries((CharSequence[])object);
        listPreferenceWithValueAsSummary.setEntryValues((CharSequence[])object);
        object = com.orgzly.android.prefs.a.t(this.i());
        if (linkedHashSet.contains(object)) {
            listPreferenceWithValueAsSummary.setValue((String)object);
            return;
        }
        listPreferenceWithValueAsSummary.setValue("NOTE");
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int n2;
        if ((layoutInflater = super.a(layoutInflater, viewGroup, bundle)) != null) {
            viewGroup = layoutInflater.getContext().obtainStyledAttributes(new int[]{2130772171});
            n2 = viewGroup.getColor(0, -1);
            viewGroup.recycle();
            if (n2 != -1) {
                layoutInflater.setBackgroundColor(n2);
            }
        }
        if (layoutInflater != null && (viewGroup = (ListView)layoutInflater.findViewById(16908298)) != null) {
            n2 = (int)this.k().getDimension(2131296386);
            int n3 = (int)this.k().getDimension(2131296389);
            viewGroup.setPadding(n2, n3, n2, n3);
        }
        return layoutInflater;
    }

    @Override
    public void a(Context context) {
        super.a(context);
        this.e = (a)((Object)this.j());
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.d(2131099648);
        this.d = this.a(this.a(2131231090));
        this.a(this.a(2131231064)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener(){

            public boolean onPreferenceClick(Preference preference) {
                if (n.this.e != null) {
                    n.this.e.q();
                }
                return true;
            }
        });
        this.a(this.a(2131231089)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener(){

            public boolean onPreferenceClick(Preference preference) {
                if (n.this.e != null) {
                    n.this.e.o();
                }
                return true;
            }
        });
        this.ac();
        this.d(true);
        this.ad();
        if (Build.VERSION.SDK_INT < 17) {
            this.a(this.a(2131231082)).setEnabled(false);
        }
    }

    @Override
    public void a(Menu menu, MenuInflater menuInflater) {
        menu.clear();
    }

    public void aa() {
        Map<String, g> map = com.orgzly.android.provider.b.g.a(this.j().getApplicationContext());
        if (map.isEmpty()) {
            this.d.setSummary(2131230885);
            return;
        }
        ArrayList<String> arrayList = new ArrayList<String>();
        map = map.values().iterator();
        while (map.hasNext()) {
            arrayList.add(((g)map.next()).toString());
        }
        Collections.sort(arrayList);
        this.d.setSummary((CharSequence)TextUtils.join((CharSequence)"\n", arrayList));
    }

    @Override
    public void b() {
        super.b();
        this.e = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onSharedPreferenceChanged(SharedPreferences object, String string) {
        Object object2;
        Object object3 = this.j();
        if (this.a(2131231092).equals(string)) {
            com.orgzly.android.prefs.a.w(this.i());
            if (object3 != null) {
                com.orgzly.android.ui.c.a.a((Activity)object3);
            }
            if (this.e != null) {
                this.e.m();
            }
            this.ad();
        }
        if (object3 != null) {
            object2 = c;
            int n2 = object2.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (!string.equals(this.a(object2[i2]))) continue;
                object3.recreate();
                break;
            }
        }
        if (this.a(2131231084).equals(string)) {
            if (com.orgzly.android.prefs.a.k(this.i())) {
                i.a(this.i());
            } else {
                i.b(this.i());
            }
        }
        if (this.a(2131231083).equals(string) && (object3 = com.orgzly.android.prefs.a.z(this.i())).compareToIgnoreCase((String)(object2 = object.getString(string, null))) > 0) {
            ((ListPreferenceWithValueAsSummary)this.a(this.a(2131231067))).setValue((String)object2);
        }
        if (this.a(2131231067).equals(string) && (object3 = com.orgzly.android.prefs.a.y(this.i())).compareToIgnoreCase((String)(object = object.getString(string, null))) < 0) {
            ((ListPreferenceWithValueAsSummary)this.a(this.a(2131231083))).setValue((String)object);
        }
    }

    @Override
    public void r() {
        super.r();
        this.aa();
        PreferenceManager.getDefaultSharedPreferences((Context)this.j()).registerOnSharedPreferenceChangeListener((SharedPreferences.OnSharedPreferenceChangeListener)this);
        this.ab();
    }

    @Override
    public void s() {
        super.s();
        PreferenceManager.getDefaultSharedPreferences((Context)this.j()).unregisterOnSharedPreferenceChangeListener((SharedPreferences.OnSharedPreferenceChangeListener)this);
    }

    public static interface a
    extends e {
        public void m();

        public void o();

        public void p();

        public void q();
    }

}

