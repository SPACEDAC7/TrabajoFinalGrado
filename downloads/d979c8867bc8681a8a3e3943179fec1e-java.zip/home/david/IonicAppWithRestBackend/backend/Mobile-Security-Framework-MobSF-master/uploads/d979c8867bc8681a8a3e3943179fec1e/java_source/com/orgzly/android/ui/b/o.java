/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.ProgressDialog
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.ServiceConnection
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.text.format.DateUtils
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.animation.Animation
 *  android.view.animation.AnimationUtils
 *  android.widget.ProgressBar
 *  android.widget.TextView
 */
package com.orgzly.android.ui.b;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.b.n;
import android.support.v4.c.m;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.orgzly.android.a.g;
import com.orgzly.android.a.j;
import com.orgzly.android.b;
import com.orgzly.android.c;
import com.orgzly.android.d;
import com.orgzly.android.f;
import com.orgzly.android.h;
import com.orgzly.android.k;
import com.orgzly.android.sync.SyncService;
import com.orgzly.android.sync.c;
import com.orgzly.android.ui.i;
import com.orgzly.android.ui.l;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class o
extends android.support.v4.b.m {
    public static final String a;
    private static final String b;
    private boolean c = false;
    private b d;
    private k e;
    private a f;
    private BroadcastReceiver g;
    private ServiceConnection h;

    static {
        b = o.class.getName();
        a = o.class.getName();
    }

    public o() {
        this.g = new BroadcastReceiver(){

            /*
             * Enabled aggressive block sorting
             */
            public void onReceive(Context object, Intent intent) {
                object = new com.orgzly.android.sync.c();
                object.a(c.a.valueOf(intent.getStringExtra("type")), intent.getStringExtra("message"), intent.getIntExtra("current_book", 0), intent.getIntExtra("total_books", 0));
                o.this.f.a((com.orgzly.android.sync.c)object);
                switch (.a[object.a.ordinal()]) {
                    case 1: {
                        if (o.this.d == null) return;
                        {
                            o.this.d.b(object.b);
                            return;
                        }
                    }
                    case 2: {
                        object = o.this.j();
                        if (object == null) return;
                        {
                            com.orgzly.android.b.a.a((com.orgzly.android.ui.b)object, 3);
                            return;
                        }
                    }
                    default: {
                        return;
                    }
                    case 3: 
                }
                if (o.this.d == null) return;
                {
                    o.this.d.b((String)null);
                    return;
                }
            }
        };
        this.h = new ServiceConnection(){

            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                o.this.c = true;
                ((SyncService.a)iBinder).a().a();
                o.this.ae();
            }

            public void onServiceDisconnected(ComponentName componentName) {
                o.this.c = false;
            }
        };
    }

    public static o a() {
        return new o();
    }

    private String ac() {
        Map<String, g> map = this.e.e();
        if (map.size() == 0) {
            throw new IOException(this.a(2131230884));
        }
        if (map.size() == 1) {
            return map.keySet().iterator().next();
        }
        throw new IOException(this.a(2131230867));
    }

    private void ad() {
        Intent intent = new Intent((Context)this.j(), (Class)SyncService.class);
        n n2 = this.j();
        if (n2 != null) {
            n2.bindService(intent, this.h, 1);
        }
    }

    private void ae() {
        n n2;
        if (this.c && (n2 = this.j()) != null) {
            n2.unbindService(this.h);
            this.c = false;
        }
    }

    public void Y() {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.c();
                return null;
            }

            protected void a(Void void_) {
                if (o.this.d != null) {
                    o.this.d.t();
                    return;
                }
                Log.w((String)b, (String)"Listener not set, not calling onDatabaseCleared");
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((Void)object);
            }
        }.execute((Object[])new Void[0]);
    }

    public void Z() {
        Intent intent = new Intent((Context)this.j(), (Class)SyncService.class);
        this.j().startService(intent);
    }

    @Override
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(2130903105, viewGroup, false);
        this.f = new a((View)layoutInflater, this.f);
        return layoutInflater;
    }

    public void a(final long l2) {
        new AsyncTask<Void, Object, Object>(){

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            protected /* varargs */ Object a(Void ... var1_1) {
                var1_1 = com.orgzly.android.provider.b.a.c((Context)o.this.j(), l2);
                if (var1_1 != null) ** GOTO lbl5
                try {
                    throw new IOException(o.this.a(2131230854));
lbl5: // 1 sources:
                    var2_3 = var1_1.g();
                    if (var2_3 == null) {
                        throw new IOException(o.this.a(2131230855));
                    }
                }
                catch (Exception var2_2) {
                    var2_2.printStackTrace();
                    o.c(o.this).a((com.orgzly.android.a)var1_1, null, new com.orgzly.android.b(b.a.b, o.this.a(2131231019, new Object[]{var2_2.getLocalizedMessage()})));
                    return var2_2;
                }
                o.c(o.this).a((com.orgzly.android.a)var1_1, null, new com.orgzly.android.b(b.a.c, o.this.a(2131231020, new Object[]{com.orgzly.android.b.j.b(var2_3.b())})));
                return o.c(o.this).a(var2_3);
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            protected void onPostExecute(Object object) {
                if (o.this.d == null) return;
                if (object instanceof com.orgzly.android.a) {
                    com.orgzly.android.a a2 = (com.orgzly.android.a)object;
                    o.this.e.a(a2, null, new com.orgzly.android.b(b.a.a, o.this.a(2131231018, com.orgzly.android.b.j.b(a2.f().b()))));
                    o.this.d.e((com.orgzly.android.a)object);
                    return;
                }
                o.this.d.c((Exception)object);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final long l2, final int n2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.a(l2, n2);
                return null;
            }

            protected void a(Void void_) {
                if (o.this.d == null) {
                    Log.w((String)b, (String)"Listener not set, not calling onStateChanged");
                }
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((Void)object);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final long l2, final long l3) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                com.orgzly.android.provider.b.a.b(o.this.i(), l2, l3);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final long l2, final long l3, final l l4) {
        new AsyncTask<Void, Void, h>(){

            protected /* varargs */ h a(Void ... arrvoid) {
                return o.this.e.a(l2, l3, l4);
            }

            protected void a(h h2) {
                if (h2 != null) {
                    o.this.d.a(h2);
                    return;
                }
                o.this.d.s();
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((h)object);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final long l2, final d d2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.a(l2, d2);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final long l2, final Set<Long> set) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.a(l2, set);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final long l2, final TreeSet<Long> treeSet) {
        new AsyncTask<Void, Void, Integer>(){

            protected /* varargs */ Integer a(Void ... arrvoid) {
                return o.this.e.d(l2, treeSet);
            }

            protected void a(Integer n2) {
                o.this.d.d(n2);
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((Integer)object);
            }
        }.execute((Object[])new Void[0]);
    }

    @Override
    public void a(Context context) {
        super.a(context);
        try {
            this.d = (b)((Object)this.j());
        }
        catch (ClassCastException var1_2) {
            throw new ClassCastException(this.j().toString() + " must implement " + b.class);
        }
        this.e = new k(context.getApplicationContext());
    }

    @Override
    public void a(Bundle bundle) {
        super.a(bundle);
        this.c(true);
        m.a(this.i()).a(this.g, new IntentFilter("com.orgzly.broadcast.sync"));
    }

    public void a(final com.orgzly.android.a a2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.b(a2);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final com.orgzly.android.a a2, final String string) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                try {
                    o.this.e.a(a2, string);
                    return null;
                }
                catch (Exception var1_2) {
                    var1_2.printStackTrace();
                    o.this.e.a(a2, null, new com.orgzly.android.b(b.a.b, o.this.a(2131231013, var1_2.getLocalizedMessage())));
                    return null;
                }
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final com.orgzly.android.a a2, final boolean bl2) {
        new AsyncTask<Void, Void, Object>(){

            protected /* varargs */ Object a(Void ... arrvoid) {
                try {
                    o.this.e.a(a2, bl2);
                    return null;
                }
                catch (IOException var1_2) {
                    var1_2.printStackTrace();
                    return var1_2;
                }
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected void onPostExecute(Object object) {
                if (o.this.d != null) {
                    if (object == null) {
                        o.this.d.f(a2);
                        return;
                    }
                    o.this.d.a(a2, (IOException)object);
                    return;
                }
                Log.w((String)b, (String)"Listener not set, not calling onBookDeleted");
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final d d2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.a(d2);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final f f2) {
        new AsyncTask<Void, Void, Integer>(){

            protected /* varargs */ Integer a(Void ... arrvoid) {
                return o.this.e.a(f2);
            }

            protected void a(Integer n2) {
                if (n2 == 1) {
                    o.this.d.b(f2);
                    return;
                }
                o.this.d.c(f2);
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((Integer)object);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final f f2, final i i2) {
        new AsyncTask<Void, Void, f>(){

            protected /* varargs */ f a(Void ... arrvoid) {
                return o.this.e.a(f2, i2);
            }

            protected void a(f f22) {
                if (f22 != null) {
                    o.this.d.b(f22, i2);
                    return;
                }
                o.this.d.l();
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((f)object);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final String string, final Resources resources, final int n2) {
        new AsyncTask<Void, Object, Object>(){

            protected /* varargs */ Object a(Void ... object) {
                try {
                    object = o.this.e.a(string, c.a.a, resources, n2);
                    return object;
                }
                catch (IOException var1_2) {
                    var1_2.printStackTrace();
                    return var1_2;
                }
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            protected void onPostExecute(Object object) {
                if (o.this.d == null) return;
                if (object instanceof com.orgzly.android.a) {
                    object = (com.orgzly.android.a)object;
                    o.this.e.a((com.orgzly.android.a)object, null, new com.orgzly.android.b(b.a.a, o.this.a(2131231032, string)));
                    o.this.d.e((com.orgzly.android.a)object);
                    return;
                }
                o.this.d.c((IOException)object);
            }

            protected void onPreExecute() {
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final String string, final c.a a2, final Uri uri) {
        new AsyncTask<Void, Object, Object>(){

            /*
             * Loose catch block
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            protected /* varargs */ Object a(Void ... object) {
                try {
                    object = o.this.j().getContentResolver().openInputStream(uri);
                }
                catch (IOException iOException) {
                    iOException.printStackTrace();
                    return iOException;
                }
                com.orgzly.android.a a22 = o.this.e.a(string, a2, (InputStream)object);
                {
                    catch (Throwable throwable) {
                        object.close();
                        throw throwable;
                    }
                }
                object.close();
                return a22;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            protected void onPostExecute(Object object) {
                if (o.this.d == null) return;
                if (object instanceof com.orgzly.android.a) {
                    com.orgzly.android.a a22 = (com.orgzly.android.a)object;
                    o.this.e.a(a22, null, new com.orgzly.android.b(b.a.a, o.this.a(2131231025)));
                    o.this.d.e((com.orgzly.android.a)object);
                    return;
                }
                o.this.d.c((IOException)object);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final Set<Long> set) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.a(set);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final Set<Long> set, final com.orgzly.a.a.a a2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.a(set, a2);
                return null;
            }

            protected void a(Void void_) {
                if (o.this.d != null) {
                    o.this.d.b(set, a2);
                    return;
                }
                Log.w((String)b, (String)"Listener not set, not calling onScheduledTimeUpdated");
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((Void)object);
            }
        }.execute((Object[])new Void[0]);
    }

    public void a(final Set<Long> set, final String string) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.a(set, string);
                return null;
            }

            protected void a(Void void_) {
                if (o.this.d != null) {
                    o.this.d.b(set, string);
                    return;
                }
                Log.w((String)b, (String)"Listener not set, not calling onStateChanged");
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((Void)object);
            }
        }.execute((Object[])new Void[0]);
    }

    public void aa() {
        new AsyncTask<Void, Object, IOException>(){
            private ProgressDialog b;

            protected IOException a(Void[] arrvoid) {
                try {
                    o.this.e.a(new k.a(){

                        @Override
                        public void a(int n2, int n3, String string) {
                            24.this.publishProgress(new Object[]{n2, n3, string});
                        }
                    });
                    return null;
                }
                catch (IOException var1_2) {
                    return var1_2;
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            protected void a(IOException iOException) {
                try {
                    if (this.b.isShowing()) {
                        this.b.dismiss();
                    }
                }
                catch (Exception var2_2) {}
                if (iOException != null) {
                    new AlertDialog.Builder((Context)o.this.j()).setTitle(2131230816).setMessage((CharSequence)iOException.toString()).setPositiveButton(2131230900, null).show();
                }
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((IOException)object);
            }

            protected void onPreExecute() {
                this.b = new ProgressDialog((Context)o.this.j());
                this.b.setProgressStyle(1);
                this.b.setMessage((CharSequence)o.this.a(2131230958));
                this.b.show();
            }

            protected /* varargs */ void onProgressUpdate(Object ... object) {
                int n2 = (Integer)object[0];
                int n3 = (Integer)object[1];
                object = (String)object[2];
                this.b.setMessage((CharSequence)object);
                if (n3 == 0) {
                    this.b.setIndeterminate(true);
                    return;
                }
                this.b.setIndeterminate(false);
                this.b.setProgress(n2);
                this.b.setMax(n3);
            }

        }.execute((Object[])new Void[0]);
    }

    @Override
    public void b() {
        super.b();
        this.d = null;
    }

    public void b(final long l2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.g(l2);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void b(long l2, long l3) {
        TreeSet<Long> treeSet = new TreeSet<Long>();
        treeSet.add(l3);
        this.a(l2, treeSet);
    }

    public void b(final long l2, final Set<Long> set) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.b(l2, set);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void b(final long l2, final TreeSet<Long> treeSet) {
        new AsyncTask<Void, Void, Integer>(){

            protected /* varargs */ Integer a(Void ... arrvoid) {
                return o.this.e.c(l2, treeSet);
            }

            protected void a(Integer n2) {
                o.this.d.e(n2);
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected /* synthetic */ void onPostExecute(Object object) {
                this.a((Integer)object);
            }
        }.execute((Object[])new Void[0]);
    }

    public void b(final com.orgzly.android.a a2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.a(a2);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void b(final String string) {
        new AsyncTask<Void, Void, Object>(){

            protected /* varargs */ Object a(Void ... object) {
                try {
                    object = o.this.e.b(string);
                    o.this.e.a((com.orgzly.android.a)object, null, new com.orgzly.android.b(b.a.a, o.this.a(2131230995)));
                    return object;
                }
                catch (IOException var1_2) {
                    var1_2.printStackTrace();
                    return var1_2;
                }
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected void onPostExecute(Object object) {
                if (o.this.d != null) {
                    if (object instanceof com.orgzly.android.a) {
                        o.this.d.d((com.orgzly.android.a)object);
                        return;
                    }
                    o.this.d.b((IOException)object);
                    return;
                }
                Log.w((String)b, (String)"Listener not set, not handling createNewBook result");
            }
        }.execute((Object[])new Void[0]);
    }

    @Override
    public void c() {
        super.c();
        this.ad();
    }

    public void c(final long l2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.h(l2);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    @Override
    public void d() {
        super.d();
    }

    public void d(final long l2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                o.this.e.i(l2);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    public void e(final long l2) {
        new AsyncTask<Void, Void, Object>(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            protected /* varargs */ Object a(Void ... object) {
                com.orgzly.android.a a2 = com.orgzly.android.provider.b.a.c((Context)o.this.j(), l2);
                if (a2 == null) {
                    return new IOException(o.this.a(2131230854));
                }
                try {
                    String string;
                    if (a2.g() != null) {
                        object = a2.g();
                        string = object.a().toString();
                        object = c.a(o.this.i(), object.b());
                    } else {
                        string = o.this.ac();
                        object = c.a(a2.c(), c.a.a);
                    }
                    o.this.e.a(a2, null, new com.orgzly.android.b(b.a.c, o.this.a(2131231023, string)));
                    return o.this.e.a(string, (String)object, a2, c.a.a);
                }
                catch (Exception var1_2) {
                    var1_2.printStackTrace();
                    o.this.e.a(a2, null, new com.orgzly.android.b(b.a.b, o.this.a(2131231022, var1_2.getLocalizedMessage())));
                    return var1_2;
                }
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected void onPostExecute(Object object) {
                if (o.this.d != null) {
                    if (object instanceof com.orgzly.android.a) {
                        object = (com.orgzly.android.a)object;
                        o.this.e.a((com.orgzly.android.a)object, null, new com.orgzly.android.b(b.a.a, o.this.a(2131231021, com.orgzly.android.b.j.b(object.f().b()))));
                        o.this.d.c((com.orgzly.android.a)object);
                        return;
                    }
                    o.this.d.a((Exception)object);
                    return;
                }
                Log.w((String)b, (String)"Listener not set, not handling saveBookToRepo result");
            }
        }.execute((Object[])new Void[0]);
    }

    public void f(final long l2) {
        new AsyncTask<Void, Void, Object>(){

            protected /* varargs */ Object a(Void ... object) {
                try {
                    object = o.this.e.a(l2, c.a.a);
                    return object;
                }
                catch (IOException var1_2) {
                    var1_2.printStackTrace();
                    return var1_2;
                }
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }

            protected void onPostExecute(Object object) {
                if (o.this.d != null) {
                    if (object instanceof File) {
                        o.this.d.a((File)object);
                        return;
                    }
                    o.this.d.d((IOException)object);
                    return;
                }
                Log.w((String)b, (String)"Listener not set, not handling exportBook result");
            }
        }.execute((Object[])new Void[0]);
    }

    @Override
    public void t() {
        super.t();
        m.a(this.i()).a(this.g);
    }

    private class a {
        private final Context b;
        private final ProgressBar c;
        private final ViewGroup d;
        private final TextView e;
        private final View f;
        private final Animation g;

        /*
         * Enabled aggressive block sorting
         */
        public a(View view, a a2) {
            this.b = o.this.j().getApplicationContext();
            this.g = AnimationUtils.loadAnimation((Context)this.b, (int)2130968594);
            this.g.setRepeatCount(-1);
            this.c = (ProgressBar)view.findViewById(2131689685);
            this.d = (ViewGroup)view.findViewById(2131689686);
            this.e = (TextView)view.findViewById(2131689688);
            this.f = view.findViewById(2131689687);
            if (a2 != null) {
                this.c.setIndeterminate(a2.c.isIndeterminate());
                this.c.setMax(a2.c.getMax());
                this.c.setProgress(a2.c.getProgress());
                this.c.setVisibility(a2.c.getVisibility());
                this.e.setText(a2.e.getText());
            } else {
                this.c.setVisibility(8);
                this.a();
            }
            this.d.setOnClickListener(new View.OnClickListener(o.this){
                final /* synthetic */ o a;

                public void onClick(View view) {
                    o.this.Z();
                }
            });
        }

        private String a(long l2) {
            return DateUtils.formatDateTime((Context)this.b, (long)l2, (int)65553);
        }

        private void a() {
            long l2 = com.orgzly.android.prefs.a.D(this.b);
            if (l2 > 0) {
                this.e.setText((CharSequence)o.this.a(2131231027, this.a(l2)));
                return;
            }
            this.e.setText(2131230947);
        }

        /*
         * Enabled aggressive block sorting
         */
        private void a(boolean bl2) {
            if (bl2) {
                if (this.f.getAnimation() != null) return;
                {
                    this.f.startAnimation(this.g);
                    return;
                }
            } else {
                if (this.f.getAnimation() == null) return;
                {
                    this.f.clearAnimation();
                    return;
                }
            }
        }

        public void a(com.orgzly.android.sync.c c2) {
            switch (com.orgzly.android.ui.b.o$26.a[c2.a.ordinal()]) {
                default: {
                    return;
                }
                case 4: {
                    this.c.setIndeterminate(true);
                    this.c.setVisibility(0);
                    this.a(true);
                    this.e.setText(2131230949);
                    return;
                }
                case 5: {
                    this.c.setIndeterminate(true);
                    this.c.setVisibility(0);
                    this.a(true);
                    this.e.setText(2131230765);
                    return;
                }
                case 6: {
                    this.c.setIndeterminate(false);
                    this.c.setMax(c2.c);
                    this.c.setProgress(0);
                    this.c.setVisibility(0);
                    this.a(true);
                    this.e.setText(2131230949);
                    return;
                }
                case 7: {
                    this.c.setIndeterminate(false);
                    this.c.setMax(c2.c);
                    this.c.setProgress(c2.d);
                    this.c.setVisibility(0);
                    this.a(true);
                    this.e.setText((CharSequence)o.this.a(2131231148, c2.b));
                    return;
                }
                case 8: {
                    this.c.setIndeterminate(false);
                    this.c.setMax(c2.c);
                    this.c.setProgress(c2.d);
                    this.c.setVisibility(0);
                    this.a(true);
                    this.e.setText(2131230949);
                    return;
                }
                case 9: 
                case 10: {
                    this.c.setVisibility(8);
                    this.a(false);
                    this.a();
                    return;
                }
                case 1: 
                case 3: 
            }
            this.c.setVisibility(8);
            this.a(false);
            this.e.setText((CharSequence)o.this.a(2131231027, c2.b));
        }

    }

    public static interface b {
        public void a(com.orgzly.android.a var1, IOException var2);

        public void a(h var1);

        public void a(File var1);

        public void a(Exception var1);

        public void b(f var1);

        public void b(f var1, i var2);

        public void b(Exception var1);

        public void b(String var1);

        public void b(Set<Long> var1, com.orgzly.a.a.a var2);

        public void b(Set<Long> var1, String var2);

        public void c(com.orgzly.android.a var1);

        public void c(f var1);

        public void c(Exception var1);

        public void d(int var1);

        public void d(com.orgzly.android.a var1);

        public void d(Exception var1);

        public void e(int var1);

        public void e(com.orgzly.android.a var1);

        public void f(com.orgzly.android.a var1);

        public void l();

        public void s();

        public void t();
    }

}

