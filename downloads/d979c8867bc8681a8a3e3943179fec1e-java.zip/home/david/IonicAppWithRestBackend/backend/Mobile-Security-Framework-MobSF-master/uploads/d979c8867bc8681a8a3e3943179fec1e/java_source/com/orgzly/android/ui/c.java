/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 */
package com.orgzly.android.ui;

import android.os.Bundle;
import android.os.Handler;
import android.support.v4.b.m;
import android.support.v4.b.r;
import android.support.v4.b.w;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.e;
import android.util.Log;
import com.orgzly.android.j;
import com.orgzly.android.ui.b.a;
import com.orgzly.android.ui.b.b;
import com.orgzly.android.ui.b.g;
import com.orgzly.android.ui.b.h;
import com.orgzly.android.ui.b.i;
import com.orgzly.android.ui.b.k;
import com.orgzly.android.ui.b.n;
import com.orgzly.android.ui.l;

public class c {
    private static final String a = c.class.getName();
    private final r b;
    private final DrawerLayout c;

    public c(e e2, Bundle bundle, DrawerLayout drawerLayout) {
        this.b = e2.e();
        this.c = drawerLayout;
        if (bundle == null) {
            this.a(false);
        }
    }

    private void a(boolean bl2) {
        if (this.c(com.orgzly.android.ui.b.c.i) != null) {
            return;
        }
        Object object = com.orgzly.android.ui.b.c.Z();
        object = this.b.a().a(4099).a(2131689589, (m)object, com.orgzly.android.ui.b.c.i);
        if (bl2) {
            object.a((String)null);
        }
        object.a();
    }

    private void a(boolean bl2, long l2, long l3, l object) {
        if (l2 <= 0) {
            throw new IllegalArgumentException("Invalid book id (" + l2 + ")");
        }
        object = i.a(bl2, l2, l3, (l)((Object)object), null, null);
        this.b.a().a(4099).a((String)null).a(2131689589, (m)object, i.a).a();
    }

    private void b(com.orgzly.android.a object) {
        object = b.a(object.a(), object.b());
        this.b.a().a(4099).a((String)null).a(2131689589, (m)object, b.a).a();
    }

    private void b(String object) {
        j j2 = this.f();
        if (j2 != null && j2.toString().equals(object)) {
            return;
        }
        object = k.b((String)object);
        this.b.a().a(4099).a((String)null).a(2131689589, (m)object, k.i).a();
    }

    private m c(String object) {
        if ((object = this.b.a((String)object)) != null && object.o()) {
            return object;
        }
        return null;
    }

    private a c(long l2) {
        m m2 = this.b.a(a.i);
        if (m2 != null && m2.o() && (m2 = (a)m2).Z() != null && m2.Z().a() == l2) {
            return m2;
        }
        return null;
    }

    private void c(long l2, long l3) {
        if (this.c(l2) == null) {
            a a2 = a.a(l2, l3);
            this.b.a().a(4099).a((String)null).a(2131689589, a2, a.i).a();
            return;
        }
        Log.w((String)a, (String)("Fragment displaying book " + l2 + " already exists"));
    }

    private void g() {
        if (this.c(h.i) != null) {
            return;
        }
        h h2 = h.Z();
        this.b.a().a(4099).a((String)null).a(2131689589, h2, h.i).a();
    }

    private void h() {
        if (this.c(n.b) != null) {
            return;
        }
        n n2 = n.Z();
        this.b.a().a(4099).a((String)null).a(2131689589, n2, n.b).a();
    }

    public void a() {
        if (this.c != null) {
            this.c.f(8388611);
        }
        new Handler().postDelayed(new Runnable(){

            @Override
            public void run() {
                c.this.g();
            }
        }, 300);
    }

    public void a(final long l2) {
        if (this.c != null) {
            this.c.f(8388611);
        }
        new Handler().postDelayed(new Runnable(){

            @Override
            public void run() {
                c.this.c(l2, 0);
            }
        }, 300);
    }

    public void a(long l2, long l3) {
        this.a(false, l2, l3, l.d);
    }

    public void a(com.orgzly.android.a a2) {
        this.b(a2);
    }

    public void a(com.orgzly.android.ui.i i2) {
        this.a(true, i2.a(), i2.b(), i2.c());
    }

    public void a(final String string) {
        if (this.c != null) {
            this.c.f(8388611);
        }
        new Handler().postDelayed(new Runnable(){

            @Override
            public void run() {
                c.this.b(string);
            }
        }, 300);
    }

    public void b() {
        if (this.c != null) {
            this.c.f(8388611);
        }
        new Handler().postDelayed(new Runnable(){

            @Override
            public void run() {
                c.this.a(true);
            }
        }, 300);
    }

    public void b(long l2) {
        g g2 = g.a(l2);
        this.b.a().a(4099).a((String)null).a(2131689589, g2, g.a).a();
    }

    public void b(long l2, long l3) {
        this.c(l2, l3);
    }

    public void c() {
        if (this.c != null) {
            this.c.f(8388611);
        }
        this.h();
    }

    public void d() {
        g g2 = g.a();
        this.b.a().a(4099).a((String)null).a(2131689589, g2, g.a).a();
    }

    public void e() {
        this.b.a(null, 1);
        this.a(false);
    }

    public j f() {
        m m2 = this.b.a(k.i);
        if (m2 != null && m2.o()) {
            return ((k)m2).Z();
        }
        return null;
    }

}

