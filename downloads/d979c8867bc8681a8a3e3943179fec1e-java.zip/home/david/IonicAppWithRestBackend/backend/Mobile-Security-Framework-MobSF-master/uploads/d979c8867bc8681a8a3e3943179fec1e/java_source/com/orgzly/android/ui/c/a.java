/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.TypedArray
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.IBinder
 *  android.util.Log
 *  android.view.View
 *  android.view.Window
 *  android.view.inputmethod.InputMethodManager
 */
package com.orgzly.android.ui.c;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.support.v7.app.e;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import com.orgzly.android.ui.b.b;
import com.orgzly.android.ui.b.c;
import com.orgzly.android.ui.b.g;
import com.orgzly.android.ui.b.h;
import com.orgzly.android.ui.b.i;
import com.orgzly.android.ui.b.k;
import com.orgzly.android.ui.b.m;
import com.orgzly.android.ui.b.n;

public class a {
    private static final String a = a.class.getName();

    public static void a(Activity activity) {
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View((Context)activity);
        }
        ((InputMethodManager)activity.getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static void a(final Activity activity, final View view) {
        if (view.requestFocus()) {
            new Handler().postDelayed(new Runnable(){

                @Override
                public void run() {
                    ((InputMethodManager)activity.getSystemService("input_method")).showSoftInput(view, 1);
                }
            }, 100);
            return;
        }
        Log.w((String)a, (String)("Can't open keyboard because view " + (Object)view + " failed to get focus in activity " + (Object)activity));
    }

    public static void a(e e2, String object) {
        object = new a((Context)e2, (String)object);
        if (Build.VERSION.SDK_INT >= 21) {
            e2.getWindow().setStatusBarColor(object.a);
        }
        e2.g().a((Drawable)new ColorDrawable(object.b));
    }

    public static void b(Activity activity) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.parse((String)"package:com.orgzly"));
        activity.startActivity(intent);
    }

    public static class a {
        public int a;
        public int b;
        public Drawable c;

        /*
         * Enabled aggressive block sorting
         */
        public a(Context context, String string) {
            int n2;
            int n3;
            int n4 = 2130772166;
            if (n.b.equals(string)) {
                n2 = 2130772167;
                n4 = 2130772168;
                n3 = 0;
            } else if (m.i.equals(string)) {
                n2 = 2130772167;
                n4 = 2130772168;
                n3 = 0;
            } else if (h.i.equals(string)) {
                n3 = 2130772262;
                n2 = 2130772165;
            } else if (g.a.equals(string)) {
                n3 = 0;
                n2 = 2130772165;
            } else if (k.i.equals(string)) {
                n3 = 0;
                n2 = 2130772165;
            } else if (c.i.equals(string)) {
                n3 = 2130772262;
                n4 = 2130772164;
                n2 = 2130772163;
            } else if (com.orgzly.android.ui.b.a.i.equals(string)) {
                n3 = 2130772262;
                n4 = 2130772164;
                n2 = 2130772163;
            } else if (b.a.equals(string)) {
                n3 = 0;
                n4 = 2130772164;
                n2 = 2130772163;
            } else if (i.a.equals(string)) {
                n3 = 0;
                n4 = 2130772164;
                n2 = 2130772163;
            } else {
                n3 = 0;
                n4 = 2130772164;
                n2 = 2130772163;
            }
            context = context.obtainStyledAttributes(new int[]{n2, n4, n3});
            this.a = context.getColor(0, 0);
            this.b = context.getColor(1, 0);
            this.c = context.getDrawable(2);
            context.recycle();
        }
    }

}

