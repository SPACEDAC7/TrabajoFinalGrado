/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseBooleanArray
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ListAdapter
 *  android.widget.ListView
 */
package com.orgzly.android.ui.c;

import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.util.TreeSet;

public class b {
    public static View a(ListView listView, int n2) {
        int n3 = listView.getFirstVisiblePosition();
        int n4 = listView.getChildCount();
        if (n2 < n3 || n2 > n4 + n3 - 1) {
            return listView.getAdapter().getView(n2, null, (ViewGroup)listView);
        }
        return listView.getChildAt(n2 - n3);
    }

    public static TreeSet<Long> a(ListView listView) {
        TreeSet<Long> treeSet = new TreeSet<Long>();
        SparseBooleanArray sparseBooleanArray = listView.getCheckedItemPositions();
        for (int i2 = 0; i2 < sparseBooleanArray.size(); ++i2) {
            if (!sparseBooleanArray.valueAt(i2)) continue;
            treeSet.add(listView.getItemIdAtPosition(sparseBooleanArray.keyAt(i2)));
        }
        return treeSet;
    }

    public static boolean a(ListView listView, long l2) {
        int n2 = listView.getFirstVisiblePosition();
        int n3 = listView.getChildCount();
        for (int i2 = n2; i2 <= n3 + n2 - 1; ++i2) {
            if (listView.getItemIdAtPosition(i2) != l2) continue;
            return true;
        }
        return false;
    }
}

