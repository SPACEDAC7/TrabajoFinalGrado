/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewGroup
 */
package com.orgzly.android.ui.c;

import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class c {
    public static List<View> a(View view, Class class_) {
        ArrayList<View> arrayList = new ArrayList<View>();
        ArrayList<View> arrayList2 = new ArrayList<View>();
        arrayList2.add(view);
        while (!arrayList2.isEmpty()) {
            view = (View)arrayList2.remove(0);
            if (class_.isInstance((Object)view)) {
                arrayList.add(view);
            }
            if (!(view instanceof ViewGroup)) continue;
            view = (ViewGroup)view;
            for (int i2 = 0; i2 < view.getChildCount(); ++i2) {
                arrayList2.add(view.getChildAt(i2));
            }
        }
        return arrayList;
    }
}

