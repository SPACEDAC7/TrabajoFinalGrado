/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.ui;

public interface d {
    public Runnable a();
}

