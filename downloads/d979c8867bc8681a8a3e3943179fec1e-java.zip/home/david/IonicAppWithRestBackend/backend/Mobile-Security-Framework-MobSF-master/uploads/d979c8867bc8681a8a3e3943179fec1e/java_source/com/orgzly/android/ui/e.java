/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.ui;

public interface e {
    public void a(String var1, CharSequence var2, CharSequence var3, int var4);
}

