/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.database.Cursor
 *  android.graphics.Typeface
 *  android.os.AsyncTask
 *  android.text.SpannableString
 *  android.text.TextUtils
 *  android.text.style.AbsoluteSizeSpan
 *  android.text.style.ForegroundColorSpan
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 *  android.widget.ViewFlipper
 */
package com.orgzly.android.ui;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.support.v4.widget.x;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;
import com.orgzly.a.a.d;
import com.orgzly.a.c;
import com.orgzly.android.g;
import com.orgzly.android.k;
import com.orgzly.android.provider.e;
import com.orgzly.android.ui.m;
import com.orgzly.android.ui.o;
import com.orgzly.android.ui.views.b;
import java.util.List;

public class f
extends x {
    private static final String m = f.class.getName();
    private final m n;
    private final b o;
    private final boolean p;
    private final com.orgzly.android.b.g q;
    private final a r;

    public f(Context context, m m2, b b2, boolean bl2) {
        super(context, 2130903111, null, new String[0], new int[0], 0);
        this.n = m2;
        this.o = b2;
        this.p = bl2;
        this.q = new com.orgzly.android.b.g(context);
        this.r = new a();
    }

    private CharSequence a(c c2) {
        return new SpannableString((CharSequence)TextUtils.join((CharSequence)" ", c2.b()));
    }

    /*
     * Exception decompiling
     */
    private CharSequence a(com.orgzly.android.f var1_1, c var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:420)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:219)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:619)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:45)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    private void a(final Context context, final long l2) {
        new AsyncTask<Void, Void, Void>(){

            protected /* varargs */ Void a(Void ... arrvoid) {
                new k(context).e(l2);
                return null;
            }

            protected /* synthetic */ Object doInBackground(Object[] arrobject) {
                return this.a((Void[])arrobject);
            }
        }.execute((Object[])new Void[0]);
    }

    private void a(Context context, ViewGroup viewGroup, int n2) {
        int n3;
        int n4 = 1;
        int n5 = 1;
        if (viewGroup.getChildCount() < n2) {
            for (n3 = 1; n3 <= viewGroup.getChildCount(); ++n3) {
                viewGroup.getChildAt(n3 - 1).setVisibility(0);
            }
            for (n3 = viewGroup.getChildCount() + 1; n3 <= n2; ++n3) {
                View.inflate((Context)context, (int)2130903106, (ViewGroup)viewGroup);
            }
        } else if (n2 < viewGroup.getChildCount()) {
            for (n3 = n4; n3 <= n2; ++n3) {
                viewGroup.getChildAt(n3 - 1).setVisibility(0);
            }
            ++n2;
            while (n2 <= viewGroup.getChildCount()) {
                viewGroup.getChildAt(n2 - 1).setVisibility(8);
                ++n2;
            }
        } else {
            for (n3 = n5; n3 <= viewGroup.getChildCount(); ++n3) {
                viewGroup.getChildAt(n3 - 1).setVisibility(0);
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(Context var1_1, com.orgzly.android.f var2_2, o var3_3) {
        var5_4 = true;
        if (!this.p) ** GOTO lbl-1000
        var4_5 = var2_2.b().e() != false && com.orgzly.android.prefs.a.c(var1_1) != false && com.orgzly.android.prefs.a.a(var1_1) != false;
        if (var2_2.a().d() > 0 || var4_5) {
            if (var2_2.e()) {
                var3_3.s.setText(2131231150);
                var4_5 = var5_4;
            } else {
                var3_3.s.setText(2131231016);
                var4_5 = var5_4;
            }
        } else lbl-1000: // 2 sources:
        {
            var4_5 = false;
        }
        if (var4_5) {
            var3_3.r.setVisibility(0);
            var3_3.s.setVisibility(0);
            return;
        }
        var3_3.r.setVisibility(4);
        var3_3.s.setVisibility(4);
    }

    /*
     * Enabled aggressive block sorting
     */
    private CharSequence b(c c2) {
        SpannableString spannableString = new SpannableString((CharSequence)c2.o());
        c2 = com.orgzly.android.prefs.a.v(this.d).contains(c2.o()) ? this.r.a : (com.orgzly.android.prefs.a.x(this.d).contains(c2.o()) ? this.r.b : this.r.c);
        spannableString.setSpan((Object)c2, 0, spannableString.length(), 0);
        return spannableString;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(Context context, com.orgzly.android.f f2, o o2) {
        if (!this.p) {
            o2.f.setTypeface(Typeface.DEFAULT_BOLD);
            return;
        }
        if (f2.a().d() <= 0) {
            o2.f.setText(2131230990);
            o2.f.setTypeface(Typeface.DEFAULT_BOLD);
            return;
        }
        if (f2.e()) {
            o2.f.setText(2131230991);
        } else {
            o2.f.setText(2131230992);
        }
        o2.f.setTypeface(Typeface.DEFAULT);
    }

    private CharSequence c(c c2) {
        return "#" + c2.n();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public View a(Context arrlayoutParams, Cursor object, ViewGroup viewGroup) {
        int n2;
        int n3;
        viewGroup = super.a((Context)arrlayoutParams, (Cursor)object, viewGroup);
        object = (o)viewGroup.getTag();
        if (object == null) {
            object = new o((View)viewGroup);
            viewGroup.setTag(object);
        }
        String string = com.orgzly.android.prefs.a.g((Context)arrlayoutParams);
        if (arrlayoutParams.getString(2131231114).equals(string)) {
            n2 = (int)arrlayoutParams.getResources().getDimension(2131296404);
            n3 = (int)arrlayoutParams.getResources().getDimension(2131296398);
        } else if (arrlayoutParams.getString(2131231115).equals(string)) {
            n2 = (int)arrlayoutParams.getResources().getDimension(2131296405);
            n3 = (int)arrlayoutParams.getResources().getDimension(2131296399);
        } else {
            n2 = (int)arrlayoutParams.getResources().getDimension(2131296406);
            n3 = (int)arrlayoutParams.getResources().getDimension(2131296400);
        }
        arrlayoutParams = (LinearLayout.LayoutParams[])object.h.getLayoutParams();
        arrlayoutParams.setMargins(arrlayoutParams.leftMargin, n2, arrlayoutParams.rightMargin, 0);
        arrlayoutParams = new LinearLayout.LayoutParams[]{(LinearLayout.LayoutParams)object.i.getLayoutParams(), (LinearLayout.LayoutParams)object.k.getLayoutParams(), (LinearLayout.LayoutParams)object.m.getLayoutParams(), (LinearLayout.LayoutParams)object.o.getLayoutParams()};
        int n4 = arrlayoutParams.length;
        n2 = 0;
        while (n2 < n4) {
            arrlayoutParams[n2].setMargins(0, n3, 0, 0);
            ++n2;
        }
        return viewGroup;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(View view, final Context context, Cursor cursor) {
        final com.orgzly.android.f f2 = com.orgzly.android.provider.b.f.a(cursor);
        c c2 = f2.b();
        o o2 = (o)view.getTag();
        if (this.p) {
            if (f2.a().a() == 0) {
                view.setVisibility(0);
            } else {
                view.setVisibility(8);
            }
        }
        ViewGroup viewGroup = o2.e;
        int n2 = this.p ? f2.a().e() - 1 : 0;
        this.a(context, viewGroup, n2);
        this.a(context, f2, o2);
        this.b(context, f2, o2);
        if (this.p) {
            o2.c.setVisibility(8);
            o2.b.setVisibility(8);
        } else {
            switch (Integer.valueOf(com.orgzly.android.prefs.a.n(context))) {
                default: {
                    break;
                }
                case 0: {
                    o2.b.setVisibility(8);
                    o2.c.setVisibility(8);
                    break;
                }
                case 1: {
                    o2.b.setText((CharSequence)cursor.getString(cursor.getColumnIndex(e.n.b.a)));
                    o2.b.setVisibility(0);
                    o2.c.setVisibility(8);
                    break;
                }
                case 2: {
                    o2.d.setText((CharSequence)cursor.getString(cursor.getColumnIndex(e.n.b.a)));
                    o2.b.setVisibility(8);
                    o2.c.setVisibility(0);
                }
            }
        }
        o2.g.setText(this.a(f2, c2));
        if (c2.e() && com.orgzly.android.prefs.a.a(context) && (!f2.e() || !com.orgzly.android.prefs.a.c(context)) && (this.p || com.orgzly.android.prefs.a.b(context))) {
            if (com.orgzly.android.prefs.a.e(context)) {
                o2.o.setTypeface(Typeface.MONOSPACE);
            }
            o2.o.setText((CharSequence)com.orgzly.android.b.f.a(c2.d()));
            o2.o.setVisibility(0);
        } else {
            o2.o.setVisibility(8);
        }
        if (c2.i() && com.orgzly.android.prefs.a.h(context)) {
            o2.n.setText((CharSequence)this.q.a(c2.h()));
            o2.m.setVisibility(0);
        } else {
            o2.m.setVisibility(8);
        }
        if (c2.k() && com.orgzly.android.prefs.a.h(context)) {
            o2.l.setText((CharSequence)this.q.a(c2.j()));
            o2.k.setVisibility(0);
        } else {
            o2.k.setVisibility(8);
        }
        if (c2.g() && com.orgzly.android.prefs.a.h(context)) {
            o2.j.setText((CharSequence)this.q.a(c2.f()));
            o2.i.setVisibility(0);
        } else {
            o2.i.setVisibility(8);
        }
        if (c2.o() != null && com.orgzly.android.prefs.a.x(context).contains(c2.o())) {
            o2.h.setAlpha(0.45f);
        } else {
            o2.h.setAlpha(1.0f);
        }
        this.o.a(view, f2.c(), o2.p, o2.q);
        this.n.a(view, f2.c());
        o2.r.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                f.this.a(context, f2.c());
            }
        });
    }

    @Override
    public View getView(int n2, View view, ViewGroup viewGroup) {
        return super.getView(n2, view, viewGroup);
    }

    private class a {
        ForegroundColorSpan a;
        ForegroundColorSpan b;
        ForegroundColorSpan c;
        AbsoluteSizeSpan d;
        ForegroundColorSpan e;

        public a() {
            f.this = f.this.d.obtainStyledAttributes(new int[]{2130772178, 2130772179, 2130772180, 2130772231, 2130772184});
            this.a = new ForegroundColorSpan(f.this.getColor(0, 0));
            this.b = new ForegroundColorSpan(f.this.getColor(1, 0));
            this.c = new ForegroundColorSpan(f.this.getColor(2, 0));
            this.d = new AbsoluteSizeSpan(f.this.getDimensionPixelSize(3, 0));
            this.e = new ForegroundColorSpan(f.this.getColor(4, 0));
            f.this.recycle();
        }
    }

}

