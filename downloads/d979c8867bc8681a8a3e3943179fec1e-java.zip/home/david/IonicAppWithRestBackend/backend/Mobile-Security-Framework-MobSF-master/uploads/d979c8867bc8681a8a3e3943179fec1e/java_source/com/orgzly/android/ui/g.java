/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 */
package com.orgzly.android.ui;

import android.util.SparseArray;
import java.util.HashMap;

public class g {
    private static int a = 8;
    private static SparseArray<HashMap<String, Integer>> b = new SparseArray(5);

    public static int a(int n2, String string) {
        Integer n3;
        HashMap<String, Integer> hashMap = (HashMap<String, Integer>)b.get(n2);
        if (hashMap == null) {
            hashMap = new HashMap<String, Integer>();
            b.put(n2, hashMap);
        }
        Integer n4 = n3 = (Integer)hashMap.get(string);
        if (n3 == null) {
            hashMap.put(string, a);
            n2 = a;
            a = n2 + 1;
            n4 = n2;
        }
        return n4;
    }
}

