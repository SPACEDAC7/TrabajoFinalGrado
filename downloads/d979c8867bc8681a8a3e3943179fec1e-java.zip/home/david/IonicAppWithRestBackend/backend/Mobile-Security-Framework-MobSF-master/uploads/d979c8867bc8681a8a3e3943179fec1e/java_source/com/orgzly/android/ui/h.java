/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.orgzly.android.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.b.m;
import android.support.v4.b.n;
import android.support.v4.b.r;
import android.view.View;
import com.orgzly.android.ui.c.a;
import com.orgzly.android.ui.d;

public class h {
    public static void a(n object, String string, int n2) {
        FloatingActionButton floatingActionButton = (FloatingActionButton)object.findViewById(2131689590);
        if (floatingActionButton == null) {
            return;
        }
        Object object2 = object.e().a(string);
        if (object2 == null) {
            floatingActionButton.b();
            return;
        }
        if (n2 > 0) {
            floatingActionButton.b();
            return;
        }
        if (object2 instanceof d) {
            object2 = ((d)object2).a();
            object = new a.a((Context)object, string);
            if (object.c != null && object2 != null) {
                floatingActionButton.a();
                floatingActionButton.setBackgroundTintList(ColorStateList.valueOf((int)object.b));
                floatingActionButton.setImageDrawable(object.c);
                floatingActionButton.setOnClickListener(new View.OnClickListener((Runnable)object2){
                    final /* synthetic */ Runnable a;

                    public void onClick(View view) {
                        this.a.run();
                    }
                });
                return;
            }
            floatingActionButton.b();
            return;
        }
        floatingActionButton.b();
    }

}

