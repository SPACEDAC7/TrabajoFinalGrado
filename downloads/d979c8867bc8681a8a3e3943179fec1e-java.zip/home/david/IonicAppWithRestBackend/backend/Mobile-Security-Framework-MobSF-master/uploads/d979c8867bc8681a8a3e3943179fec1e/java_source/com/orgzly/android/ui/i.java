/*
 * Decompiled with CFR 0_115.
 */
package com.orgzly.android.ui;

import com.orgzly.android.ui.l;

public class i {
    private long a;
    private long b;
    private l c;

    public i(long l2) {
        this.a = l2;
        this.c = l.d;
    }

    public i(long l2, long l3, l l4) {
        this.a = l2;
        this.b = l3;
        this.c = l4;
    }

    public long a() {
        return this.a;
    }

    public long b() {
        return this.b;
    }

    public l c() {
        return this.c;
    }

    public String toString() {
        return "Book#" + this.a + " Note#" + this.b + " Placement#" + (Object)((Object)this.c);
    }
}

