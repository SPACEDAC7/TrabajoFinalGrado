/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.widget.Spinner
 */
package com.orgzly.android.ui;

import android.content.Context;
import android.widget.Spinner;
import com.orgzly.android.prefs.a;
import com.orgzly.android.ui.n;
import java.util.List;

public class j
extends n {
    public j(Context context, Spinner spinner) {
        super(context, spinner);
    }

    public String a() {
        return super.c("\u2014");
    }

    @Override
    protected void a(Context object) {
        this.b.clear();
        object = a.y((Context)object);
        if (object == null || object.length() != 1) {
            throw new IllegalArgumentException("Last priority must be a character, not " + (String)object);
        }
        this.b.add("\u2014");
        for (char c2 = 'A'; c2 <= object.charAt(0); c2 = (char)(c2 + '\u0001')) {
            this.b.add(String.valueOf(c2));
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(String string) {
        if (string == null) {
            string = "\u2014";
        }
        super.a(string);
    }

    public void b(Context context) {
        super.a(context, "\u2014");
    }
}

