/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.widget.Spinner
 */
package com.orgzly.android.ui;

import android.content.Context;
import android.widget.Spinner;
import com.orgzly.android.prefs.a;
import com.orgzly.android.ui.n;
import java.util.Iterator;
import java.util.List;

public class k
extends n {
    public k(Context context, Spinner spinner) {
        super(context, spinner);
    }

    public static boolean b(String string) {
        if (string != null && !string.equals("NOTE")) {
            return true;
        }
        return false;
    }

    public String a() {
        return super.c("NOTE");
    }

    @Override
    protected void a(Context object) {
        this.b.clear();
        this.b.add("NOTE");
        for (String string : a.v((Context)object)) {
            this.b.add(string);
        }
        for (String string2 : a.x((Context)object)) {
            this.b.add(string2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(String string) {
        if (string == null) {
            string = "NOTE";
        }
        super.a(string);
    }

    public void b(Context context) {
        super.a(context, "NOTE");
    }
}

