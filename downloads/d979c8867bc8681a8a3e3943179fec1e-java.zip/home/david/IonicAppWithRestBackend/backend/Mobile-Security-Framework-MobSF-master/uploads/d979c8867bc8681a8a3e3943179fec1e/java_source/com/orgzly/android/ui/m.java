/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 */
package com.orgzly.android.ui;

import android.os.Bundle;
import android.view.View;
import java.util.Iterator;
import java.util.TreeSet;

public class m {
    private TreeSet<Long> a = new TreeSet();

    public int a() {
        return this.a.size();
    }

    public void a(Bundle bundle) {
        if (this.a() > 0) {
            long[] arrl = new long[this.a.size()];
            Iterator<Long> iterator = this.a.iterator();
            int n2 = 0;
            while (iterator.hasNext()) {
                arrl[n2] = iterator.next();
                ++n2;
            }
            bundle.putLongArray("list_of_selected_ids", arrl);
            return;
        }
        bundle.remove("list_of_selected_ids");
    }

    public void a(View view, long l2) {
        if (this.a.contains(l2)) {
            view.setBackgroundResource(2131558452);
            return;
        }
        view.setBackgroundResource(0);
    }

    public boolean a(long l2) {
        return this.a.contains(l2);
    }

    public TreeSet<Long> b() {
        return this.a;
    }

    public void b(long l2) {
        this.a.add(l2);
    }

    public void b(Bundle arrl) {
        this.a.clear();
        if (arrl != null && arrl.containsKey("list_of_selected_ids") && (arrl = arrl.getLongArray("list_of_selected_ids")) != null) {
            for (long l2 : arrl) {
                this.a.add(l2);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void b(View view, long l2) {
        if (this.a(l2)) {
            this.c(l2);
        } else {
            this.b(l2);
        }
        if (view != null) {
            this.a(view, l2);
        }
    }

    public void c() {
        this.a.clear();
    }

    public void c(long l2) {
        this.a.remove(l2);
    }
}

