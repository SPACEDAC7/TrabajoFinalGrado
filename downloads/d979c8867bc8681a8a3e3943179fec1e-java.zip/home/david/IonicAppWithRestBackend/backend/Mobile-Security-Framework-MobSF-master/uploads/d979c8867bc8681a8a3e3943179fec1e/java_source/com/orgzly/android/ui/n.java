/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.widget.ArrayAdapter
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 */
package com.orgzly.android.ui;

import android.content.Context;
import android.support.v7.widget.y;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import java.util.ArrayList;
import java.util.List;

public abstract class n {
    protected Spinner a;
    protected List<String> b;

    /*
     * Enabled aggressive block sorting
     */
    public n(Context context, Spinner spinner) {
        this.a = spinner != null ? spinner : new y(context);
        this.b = new ArrayList<String>();
        this.a(context);
        this.b();
    }

    protected abstract void a(Context var1);

    public void a(Context context, String string) {
        string = this.c(string);
        this.a(context);
        this.b();
        this.a(string);
    }

    protected void a(String string) {
        if (this.b.indexOf(string) == -1) {
            this.a(this.a.getContext());
            this.b.add(string);
            this.b();
        }
        int n2 = this.b.indexOf(string);
        this.a.setSelection(n2);
    }

    protected void b() {
        if (this.a.getContext() == null) {
            throw new IllegalStateException("Spinner's Context is null");
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter(this.a.getContext(), 2130903137, this.b);
        arrayAdapter.setDropDownViewResource(2130903093);
        this.a.setAdapter((SpinnerAdapter)arrayAdapter);
    }

    public Spinner c() {
        return this.a;
    }

    protected String c(String string) {
        String string2;
        block2 : {
            String string3 = (String)this.c().getSelectedItem();
            if (string3 != null) {
                string2 = string3;
                if (!string.equals(string3)) break block2;
            }
            string2 = null;
        }
        return string2;
    }

    public List<String> d() {
        return this.b;
    }
}

