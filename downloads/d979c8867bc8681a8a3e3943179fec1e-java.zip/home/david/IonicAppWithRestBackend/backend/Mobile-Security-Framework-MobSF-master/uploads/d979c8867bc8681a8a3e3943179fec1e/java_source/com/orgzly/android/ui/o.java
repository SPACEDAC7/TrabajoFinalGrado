/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.TextView
 *  android.widget.ViewFlipper
 */
package com.orgzly.android.ui;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ViewFlipper;

public class o {
    private static final String t = o.class.getName();
    public View a;
    public TextView b;
    public View c;
    public TextView d;
    public ViewGroup e;
    public TextView f;
    public TextView g;
    public View h;
    public View i;
    public TextView j;
    public View k;
    public TextView l;
    public View m;
    public TextView n;
    public TextView o;
    public ViewGroup p;
    public ViewFlipper q;
    public View r;
    public TextView s;

    public o(View view) {
        this.a = view.findViewById(2131689726);
        this.b = (TextView)view.findViewById(2131689727);
        this.c = view.findViewById(2131689733);
        this.d = (TextView)view.findViewById(2131689734);
        this.e = (ViewGroup)view.findViewById(2131689742);
        this.f = (TextView)view.findViewById(2131689731);
        this.h = view.findViewById(2131689728);
        this.g = (TextView)view.findViewById(2131689732);
        this.i = view.findViewById(2131689735);
        this.j = (TextView)view.findViewById(2131689736);
        this.k = view.findViewById(2131689737);
        this.l = (TextView)view.findViewById(2131689738);
        this.m = view.findViewById(2131689739);
        this.n = (TextView)view.findViewById(2131689740);
        this.o = (TextView)view.findViewById(2131689741);
        this.p = (ViewGroup)view.findViewById(2131689644);
        this.q = (ViewFlipper)view.findViewById(2131689745);
        this.r = view.findViewById(2131689729);
        this.s = (TextView)view.findViewById(2131689730);
    }
}

