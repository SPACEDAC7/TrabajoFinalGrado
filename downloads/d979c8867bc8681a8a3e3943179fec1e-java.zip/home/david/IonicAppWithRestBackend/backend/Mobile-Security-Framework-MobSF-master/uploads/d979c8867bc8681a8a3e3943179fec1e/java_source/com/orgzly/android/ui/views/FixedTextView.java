/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 */
package com.orgzly.android.ui.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import com.orgzly.android.ui.views.OrgTextView;

public class FixedTextView
extends OrgTextView {
    public FixedTextView(Context context) {
        super(context);
    }

    public FixedTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public FixedTextView(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (this.getSelectionStart() != this.getSelectionEnd() && motionEvent.getActionMasked() == 0) {
            CharSequence charSequence = this.getText();
            this.setText(null);
            this.setText(charSequence);
        }
        return super.dispatchTouchEvent(motionEvent);
    }
}

