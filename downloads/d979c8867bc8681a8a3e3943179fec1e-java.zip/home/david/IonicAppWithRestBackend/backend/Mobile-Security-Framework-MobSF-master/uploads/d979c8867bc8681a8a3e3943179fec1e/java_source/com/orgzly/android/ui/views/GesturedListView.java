/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.drawable.Drawable
 *  android.os.Handler
 *  android.util.AttributeSet
 *  android.view.GestureDetector
 *  android.view.GestureDetector$OnGestureListener
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.ViewConfiguration
 *  android.widget.ListView
 */
package com.orgzly.android.ui.views;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ListView;
import com.orgzly.a;
import java.util.HashMap;

public class GesturedListView
extends ListView
implements GestureDetector.OnGestureListener {
    private static final String a = GesturedListView.class.getName();
    private int b;
    private int c;
    private GestureDetector d;
    private Drawable e;
    private com.orgzly.android.ui.views.b f;
    private boolean g;
    private boolean h;
    private boolean i;
    private int j;

    public GesturedListView(Context context) {
        super(context);
        this.a(null);
    }

    public GesturedListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a(attributeSet);
    }

    public GesturedListView(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        this.a(attributeSet);
    }

    @TargetApi(value=21)
    public GesturedListView(Context context, AttributeSet attributeSet, int n2, int n3) {
        super(context, attributeSet, n2, n3);
        this.a(attributeSet);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int a(float f2, float f3) {
        if (Math.abs(f2) <= Math.abs(f3) || Math.abs(f2) < (float)this.b || Math.abs(f2) > (float)this.c) return 0;
        boolean bl2 = true;
        if (!bl2) return 0;
        if (f2 <= 0.0f) return -1;
        return 1;
    }

    private void a(AttributeSet attributeSet) {
        int n2 = 0;
        this.c = ViewConfiguration.get((Context)this.getContext()).getScaledMaximumFlingVelocity();
        this.b = ViewConfiguration.get((Context)this.getContext()).getScaledMinimumFlingVelocity();
        this.d = new GestureDetector(this.getContext(), (GestureDetector.OnGestureListener)this);
        this.e = this.getSelector();
        HashMap<a, Integer> hashMap = new HashMap<a, Integer>();
        if (attributeSet != null) {
            attributeSet = this.getContext().obtainStyledAttributes(attributeSet, a.a.GesturedListView);
            n2 = attributeSet.getResourceId(0, 0);
            int n3 = attributeSet.getInt(2, -1);
            if (n3 != -1) {
                hashMap.put(a.b, n3);
            }
            if ((n3 = attributeSet.getInt(1, -1)) != -1) {
                hashMap.put(a.a, n3);
            }
            attributeSet.recycle();
        }
        this.f = new com.orgzly.android.ui.views.b(this, hashMap, n2);
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        return super.dispatchTouchEvent(motionEvent);
    }

    public com.orgzly.android.ui.views.b getItemMenus() {
        return this.f;
    }

    public boolean onDown(MotionEvent motionEvent) {
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean onFling(MotionEvent object, MotionEvent motionEvent, float f2, float f3) {
        int n2;
        if (this.i || !this.g || (n2 = this.a(f2, f3)) == 0) {
            return false;
        }
        this.i = true;
        if (this.j != -1) {
            object = n2 == 1 ? a.a : a.b;
            this.f.a(this.j, (a)((Object)object));
            if (this.j == this.getCount() - 1) {
                new Handler().postDelayed(new Runnable(){

                    @Override
                    public void run() {
                        GesturedListView.this.setSelection(GesturedListView.this.j);
                    }
                }, (long)this.getResources().getInteger(2131492871));
            }
        }
        return true;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return super.onInterceptTouchEvent(motionEvent);
    }

    public void onLongPress(MotionEvent motionEvent) {
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3) {
        if (Math.abs(f2) > Math.abs(f3)) {
            if (this.h) return false;
            if (this.g) return false;
            this.g = true;
            this.setSelector(17170445);
            return false;
        }
        if (Math.abs(f2) >= Math.abs(f3)) return false;
        this.h = true;
        return false;
    }

    public void onShowPress(MotionEvent motionEvent) {
    }

    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean onTouchEvent(MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            default: {
                break;
            }
            case 0: {
                this.j = this.pointToPosition((int)motionEvent.getX(), (int)motionEvent.getY());
                this.g = false;
                this.h = false;
                this.i = false;
                this.setSelector(this.e);
            }
        }
        this.d.onTouchEvent(motionEvent);
        boolean bl2 = super.onTouchEvent(motionEvent);
        if (motionEvent.getAction() == 1 || motionEvent.getAction() == 3) {
            this.g = false;
            this.h = false;
        }
        return bl2;
    }

    public boolean performItemClick(View view, int n2, long l2) {
        if (!this.i) {
            return super.performItemClick(view, n2, l2);
        }
        return false;
    }

    public void setOnItemMenuButtonClickListener(b b2) {
        this.f.a(b2);
    }

    public static enum a {
        a,
        b;
        

        private a() {
        }
    }

    public static interface b {
        public boolean a(int var1, long var2);
    }

}

