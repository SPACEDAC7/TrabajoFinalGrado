/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.text.Layout
 *  android.text.Spanned
 *  android.text.style.ClickableSpan
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.view.View
 *  android.widget.TextView
 */
package com.orgzly.android.ui.views;

import android.annotation.TargetApi;
import android.content.Context;
import android.text.Layout;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

public class OrgTextView
extends TextView {
    public static final String a = OrgTextView.class.getName();

    public OrgTextView(Context context) {
        super(context);
    }

    public OrgTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public OrgTextView(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
    }

    @TargetApi(value=21)
    public OrgTextView(Context context, AttributeSet attributeSet, int n2, int n3) {
        super(context, attributeSet, n2, n3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean onTouchEvent(MotionEvent motionEvent) {
        ClickableSpan[] arrclickableSpan = this.getLayout();
        if (arrclickableSpan == null) return super.onTouchEvent(motionEvent);
        int n2 = arrclickableSpan.getOffsetForHorizontal(arrclickableSpan.getLineForVertical((int)motionEvent.getY()), motionEvent.getX());
        if (this.getText() == null || !(this.getText() instanceof Spanned) || (arrclickableSpan = (ClickableSpan[])((Spanned)this.getText()).getSpans(n2, n2, (Class)ClickableSpan.class)).length <= 0) return super.onTouchEvent(motionEvent);
        if (motionEvent.getAction() == 0) {
            return true;
        }
        if (motionEvent.getAction() != 1) return super.onTouchEvent(motionEvent);
        arrclickableSpan[0].onClick((View)this);
        return super.onTouchEvent(motionEvent);
    }
}

