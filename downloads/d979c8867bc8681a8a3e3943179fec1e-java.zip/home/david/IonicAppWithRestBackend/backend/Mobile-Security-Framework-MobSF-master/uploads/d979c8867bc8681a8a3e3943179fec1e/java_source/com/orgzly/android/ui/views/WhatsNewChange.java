/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  android.widget.TextView
 */
package com.orgzly.android.ui.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.orgzly.a;

public class WhatsNewChange
extends LinearLayout {
    public WhatsNewChange(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        attributeSet = context.obtainStyledAttributes(attributeSet, a.a.WhatsNewChange, 0, 0);
        String string = attributeSet.getString(0);
        attributeSet.recycle();
        ((TextView)((LayoutInflater)context.getSystemService("layout_inflater")).inflate(2130903139, (ViewGroup)this, true).findViewById(2131689793)).setText((CharSequence)string);
    }
}

