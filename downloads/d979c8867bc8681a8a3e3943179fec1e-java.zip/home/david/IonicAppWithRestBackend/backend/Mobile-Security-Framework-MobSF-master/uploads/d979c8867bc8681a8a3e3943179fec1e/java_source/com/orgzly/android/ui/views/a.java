/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 *  android.view.animation.Animation
 *  android.view.animation.Animation$AnimationListener
 *  android.view.animation.AnimationSet
 *  android.view.animation.AnimationUtils
 *  android.view.animation.DecelerateInterpolator
 *  android.view.animation.Interpolator
 *  android.view.animation.Transformation
 *  android.widget.ListView
 *  android.widget.ViewFlipper
 */
package com.orgzly.android.ui.views;

import android.content.Context;
import android.content.res.Resources;
import android.support.v4.k.ae;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.Transformation;
import android.widget.ListView;
import android.widget.ViewFlipper;
import com.orgzly.android.ui.c.b;
import com.orgzly.android.ui.views.GesturedListView;
import java.util.HashMap;

class a {
    private static final String a = a.class.getName();
    private static final Interpolator b = new DecelerateInterpolator();
    private static final Interpolator c = new DecelerateInterpolator();
    private final int d;
    private final float e;
    private final long f;
    private final GesturedListView g;
    private ViewGroup h;
    private ViewFlipper i;
    private HashMap<GesturedListView.a, Integer> j;
    private a k;
    private int l;

    public a(long l2, GesturedListView gesturedListView, ViewGroup viewGroup, ViewFlipper viewFlipper, HashMap<GesturedListView.a, Integer> hashMap) {
        this.d = gesturedListView.getResources().getInteger(2131492871);
        this.e = gesturedListView.getResources().getDimension(2131296407);
        this.f = l2;
        this.g = gesturedListView;
        this.h = viewGroup;
        this.i = viewFlipper;
        this.j = hashMap;
    }

    private void a(int n2) {
        if (this.i.getDisplayedChild() != n2) {
            this.i.setDisplayedChild(n2);
        }
    }

    private void a(ViewGroup.MarginLayoutParams marginLayoutParams) {
        this.k = a.a;
        this.h.setVisibility(8);
        marginLayoutParams.height = 0;
        this.h.requestLayout();
        ae.a((View)this.h, false);
    }

    private void c(GesturedListView.a a2) {
        if (this.a()) {
            this.i.setInAnimation(null);
            this.i.setOutAnimation(null);
            return;
        }
        if (a2 == GesturedListView.a.a) {
            this.i.setOutAnimation(this.g.getContext(), 2130968598);
            this.i.setInAnimation(this.g.getContext(), 2130968595);
            return;
        }
        if (a2 == GesturedListView.a.b) {
            this.i.setOutAnimation(this.g.getContext(), 2130968597);
            this.i.setInAnimation(this.g.getContext(), 2130968596);
            return;
        }
        this.i.setInAnimation(null);
        this.i.setOutAnimation(null);
    }

    private void d() {
        this.k = a.b;
        ae.a((View)this.h, true);
        AnimationSet animationSet = new AnimationSet(false);
        animationSet.setAnimationListener(new Animation.AnimationListener(){

            public void onAnimationEnd(Animation animation) {
                a.this.k = a.c;
                ae.a((View)a.this.h, false);
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationStart(Animation animation) {
            }
        });
        Animation animation = AnimationUtils.loadAnimation((Context)this.g.getContext(), (int)2130968592);
        animation.setInterpolator(b);
        animation.setDuration((long)this.d);
        animationSet.addAnimation(animation);
        animation = (ViewGroup.MarginLayoutParams)this.h.getLayoutParams();
        animation.height = 0;
        this.h.setVisibility(0);
        animation = new Animation((ViewGroup.MarginLayoutParams)animation){
            final /* synthetic */ ViewGroup.MarginLayoutParams a;

            protected void applyTransformation(float f2, Transformation transformation) {
                super.applyTransformation(f2, transformation);
                this.a.height = (int)(a.this.e * f2);
                a.this.h.requestLayout();
            }
        };
        animation.setInterpolator(b);
        animation.setDuration((long)this.d);
        animationSet.addAnimation(animation);
        this.h.startAnimation((Animation)animationSet);
    }

    private void d(GesturedListView.a a2) {
        this.l = this.j.get((Object)a2);
        this.a(this.l);
    }

    public void a(ViewGroup viewGroup, ViewFlipper viewFlipper) {
        this.h = viewGroup;
        this.i = viewFlipper;
        switch (.a[this.k.ordinal()]) {
            default: {
                return;
            }
            case 1: {
                this.a(this.l);
                this.h.setVisibility(0);
                return;
            }
            case 3: 
        }
        this.h.setVisibility(8);
    }

    public void a(GesturedListView.a a2) {
        this.c(a2);
        this.d(a2);
        if (this.a()) {
            this.d();
        }
    }

    public boolean a() {
        if (this.h.getVisibility() == 8 && this.h.getAnimation() == null) {
            return true;
        }
        return false;
    }

    public boolean b() {
        if (this.k == a.a) {
            return true;
        }
        return false;
    }

    public boolean b(GesturedListView.a object) {
        if (this.h.getVisibility() == 8) {
            return false;
        }
        if ((object = this.j.get(object)) != null && object.intValue() == this.i.getDisplayedChild()) {
            return true;
        }
        return false;
    }

    public void c() {
        if (this.k == a.d || this.k == a.a) {
            return;
        }
        this.k = a.d;
        ae.a((View)this.h, true);
        final ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.h.getLayoutParams();
        AnimationSet animationSet = new AnimationSet(false);
        animationSet.setAnimationListener(new Animation.AnimationListener(){

            public void onAnimationEnd(Animation animation) {
                a.this.a(marginLayoutParams);
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationStart(Animation animation) {
            }
        });
        Animation animation = AnimationUtils.loadAnimation((Context)this.g.getContext(), (int)2130968593);
        animation.setInterpolator(c);
        animation.setDuration((long)this.d);
        animationSet.addAnimation(animation);
        animation = new Animation(){

            protected void applyTransformation(float f2, Transformation transformation) {
                super.applyTransformation(f2, transformation);
                marginLayoutParams.height = (int)(a.this.e - a.this.e * f2);
                a.this.h.requestLayout();
            }
        };
        animation.setInterpolator(c);
        animation.setDuration((long)this.d);
        animationSet.addAnimation(animation);
        if (b.a((ListView)this.g, this.f)) {
            this.h.startAnimation((Animation)animationSet);
            return;
        }
        this.a(marginLayoutParams);
    }

    private static enum a {
        a,
        b,
        c,
        d;
        

        private a() {
        }
    }

}

