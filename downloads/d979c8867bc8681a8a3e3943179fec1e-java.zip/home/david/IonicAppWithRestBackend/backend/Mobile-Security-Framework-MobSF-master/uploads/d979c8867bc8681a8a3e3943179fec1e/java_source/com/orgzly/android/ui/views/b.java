/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageButton
 *  android.widget.ListView
 *  android.widget.ViewFlipper
 */
package com.orgzly.android.ui.views;

import android.support.v4.j.f;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ViewFlipper;
import com.orgzly.android.ui.c.c;
import com.orgzly.android.ui.views.GesturedListView;
import com.orgzly.android.ui.views.a;
import java.util.HashMap;

public class b {
    private static final String a = b.class.getName();
    private final GesturedListView b;
    private final HashMap<GesturedListView.a, Integer> c;
    private final int d;
    private final f<a> e = new f();
    private GesturedListView.b f;

    public b(GesturedListView gesturedListView, HashMap<GesturedListView.a, Integer> hashMap, int n2) {
        this.b = gesturedListView;
        this.c = hashMap;
        this.d = n2;
    }

    private ViewGroup a(View view) {
        if ((view = (ViewGroup)view.findViewById(this.d)) == null) {
            // empty if block
        }
        return view;
    }

    private void a(View object, final long l2) {
        if ((object = this.a((View)object)) != null) {
            for (final View view : c.a((View)object, ImageButton.class)) {
                view.setOnClickListener(new View.OnClickListener(){

                    public void onClick(View view2) {
                        if (b.this.f != null) {
                            b.this.f.a(view.getId(), l2);
                        }
                    }
                });
            }
        }
    }

    public void a(long l2) {
        for (int i2 = 0; i2 < this.e.b(); ++i2) {
            long l3 = this.e.b(i2);
            if (l3 == l2) continue;
            this.e.a(l3).c();
        }
    }

    public void a(View view, long l2, ViewGroup viewGroup, ViewFlipper viewFlipper) {
        a a2 = this.e.a(l2);
        if (a2 == null) {
            viewGroup.setVisibility(8);
            return;
        }
        if (a2.b()) {
            this.e.b(l2);
            return;
        }
        a2.a(viewGroup, viewFlipper);
        this.a(view, l2);
    }

    public void a(GesturedListView.b b2) {
        this.f = b2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean a(int var1_1, GesturedListView.a var2_2) {
        block3 : {
            var4_3 = false;
            var5_4 = this.b.getItemIdAtPosition(var1_1);
            this.a(var5_4);
            var9_5 = com.orgzly.android.ui.c.b.a((ListView)this.b, var1_1);
            var10_6 = this.a(var9_5);
            var7_8 = var8_7 = null;
            if (var10_6 == null) ** GOTO lbl15
            var1_1 = 0;
            do {
                var7_8 = var8_7;
                if (var1_1 > var10_6.getChildCount()) ** GOTO lbl15
                var7_8 = var10_6.getChildAt(var1_1);
                if (var7_8 instanceof ViewFlipper) {
                    var7_8 = (ViewFlipper)var7_8;
lbl15: // 3 sources:
                    var3_9 = var4_3;
                    if (var7_8 == null) return var3_9;
                    var3_9 = var4_3;
                    if (this.c.get((Object)var2_2) == null) return var3_9;
                    var8_7 = this.e.a(var5_4);
                    if (var8_7 != null) break;
                    var7_8 = new a(var5_4, this.b, var10_6, (ViewFlipper)var7_8, this.c);
                    this.e.b(var5_4, (a)var7_8);
                    break block3;
                }
                ++var1_1;
            } while (true);
            if (var8_7.b(var2_2)) {
                var8_7.c();
                return true;
            }
            var7_8 = var8_7;
        }
        var7_8.a(var2_2);
        this.a(var9_5, var5_4);
        return true;
    }

}

