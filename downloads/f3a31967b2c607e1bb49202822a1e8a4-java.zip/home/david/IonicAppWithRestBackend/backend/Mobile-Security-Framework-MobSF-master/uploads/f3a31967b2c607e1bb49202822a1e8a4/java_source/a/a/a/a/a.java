/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a;

import a.a.a.a.a.c;
import a.a.a.a.a.d;
import a.a.a.a.a.e;
import a.a.a.a.a.f;
import java.io.File;
import java.io.FileFilter;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.LinkedList;

public final class a {
    private static BigInteger a;
    private static BigInteger b;
    private static BigInteger c;
    private static BigInteger d;
    private static BigInteger e;
    private static BigInteger f;

    static {
        BigInteger bigInteger;
        a = bigInteger = BigInteger.valueOf(1024);
        b = bigInteger.multiply(bigInteger);
        c = a.multiply(b);
        d = a.multiply(c);
        e = a.multiply(d);
        a.multiply(e);
        f = BigInteger.valueOf(1024).multiply(BigInteger.valueOf(0x1000000000000000L));
        a.multiply(f);
        Charset.forName("UTF-8");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Collection<File> a(File file, f f2, f linkedList) {
        if (!file.isDirectory()) {
            throw new IllegalArgumentException("Parameter 'directory' is not a directory");
        }
        if (f2 == null) {
            throw new NullPointerException("Parameter 'fileFilter' is null");
        }
        f f3 = e.a(f2, e.a(c.b));
        f2 = linkedList == null ? d.a : e.a(new f[]{linkedList, c.b});
        linkedList = new LinkedList();
        a.a(linkedList, file, e.b(f3, f2), false);
        return linkedList;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void a(Collection<File> collection, File arrfile, f f2, boolean bl) {
        if ((arrfile = arrfile.listFiles(f2)) == null) {
            return;
        }
        int n2 = arrfile.length;
        int n3 = 0;
        while (n3 < n2) {
            File file = arrfile[n3];
            if (file.isDirectory()) {
                if (bl) {
                    collection.add(file);
                }
                a.a(collection, file, f2, bl);
            } else {
                collection.add(file);
            }
            ++n3;
        }
    }
}

