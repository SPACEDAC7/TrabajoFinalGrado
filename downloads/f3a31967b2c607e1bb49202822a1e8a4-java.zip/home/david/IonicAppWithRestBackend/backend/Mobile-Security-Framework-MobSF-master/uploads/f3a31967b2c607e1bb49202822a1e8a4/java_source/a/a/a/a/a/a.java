/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a.a;

import a.a.a.a.a.f;
import java.io.File;

public abstract class a
implements f {
    @Override
    public boolean accept(File file) {
        return this.accept(file.getParentFile(), file.getName());
    }

    @Override
    public boolean accept(File file, String string2) {
        return this.accept(new File(file, string2));
    }

    public String toString() {
        return this.getClass().getSimpleName();
    }
}

