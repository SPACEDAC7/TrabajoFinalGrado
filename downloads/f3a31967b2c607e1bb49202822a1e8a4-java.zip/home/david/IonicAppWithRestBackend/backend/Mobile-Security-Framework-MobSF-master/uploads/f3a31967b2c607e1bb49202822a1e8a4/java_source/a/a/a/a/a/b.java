/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a.a;

import a.a.a.a.a.a;
import a.a.a.a.a.f;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public final class b
extends a
implements Serializable {
    private final List<f> a;

    public b() {
        this.a = new ArrayList<f>();
    }

    public b(List<f> list) {
        if (list == null) {
            this.a = new ArrayList<f>();
            return;
        }
        this.a = new ArrayList<f>(list);
    }

    @Override
    public final boolean accept(File file) {
        if (this.a.isEmpty()) {
            return false;
        }
        Iterator<f> iterator = this.a.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().accept(file)) continue;
            return false;
        }
        return true;
    }

    @Override
    public final boolean accept(File file, String string2) {
        if (this.a.isEmpty()) {
            return false;
        }
        Iterator<f> iterator = this.a.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().accept(file, string2)) continue;
            return false;
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(super.toString());
        stringBuilder.append("(");
        if (this.a != null) {
            for (int i2 = 0; i2 < this.a.size(); ++i2) {
                Object object;
                if (i2 > 0) {
                    stringBuilder.append(",");
                }
                object = (object = this.a.get(i2)) == null ? "null" : object.toString();
                stringBuilder.append((String)object);
            }
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

