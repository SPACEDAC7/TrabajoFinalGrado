/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a.a;

import a.a.a.a.a.a;
import a.a.a.a.a.f;
import java.io.File;
import java.io.Serializable;

public final class c
extends a
implements Serializable {
    public static final f a;
    public static final f b;

    static {
        c c2;
        a = c2 = new c();
        b = c2;
    }

    protected c() {
    }

    @Override
    public final boolean accept(File file) {
        return file.isDirectory();
    }
}

