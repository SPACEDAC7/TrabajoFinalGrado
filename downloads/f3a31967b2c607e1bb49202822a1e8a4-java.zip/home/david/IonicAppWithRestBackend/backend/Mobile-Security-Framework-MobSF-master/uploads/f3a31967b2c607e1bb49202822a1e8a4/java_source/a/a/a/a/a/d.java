/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a.a;

import a.a.a.a.a.f;
import java.io.File;
import java.io.Serializable;

public final class d
implements f,
Serializable {
    public static final f a = new d();

    protected d() {
    }

    @Override
    public final boolean accept(File file) {
        return false;
    }

    @Override
    public final boolean accept(File file, String string2) {
        return false;
    }
}

