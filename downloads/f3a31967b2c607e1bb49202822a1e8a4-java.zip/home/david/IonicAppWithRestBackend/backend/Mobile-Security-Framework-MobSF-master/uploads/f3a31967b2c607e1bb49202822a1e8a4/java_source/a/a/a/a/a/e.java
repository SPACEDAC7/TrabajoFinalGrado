/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a.a;

import a.a.a.a.a.b;
import a.a.a.a.a.c;
import a.a.a.a.a.f;
import a.a.a.a.a.g;
import a.a.a.a.a.h;
import a.a.a.a.a.i;
import java.util.ArrayList;
import java.util.List;

public final class e {
    static {
        e.a(e.a(c.a, e.a("CVS")));
        e.a(e.a(c.a, e.a(".svn")));
    }

    public static f a(f f2) {
        return new h(f2);
    }

    private static f a(String string2) {
        return new g(string2);
    }

    public static /* varargs */ f a(f ... arrf) {
        return new b(e.c(arrf));
    }

    public static /* varargs */ f b(f ... arrf) {
        return new i(e.c(arrf));
    }

    private static /* varargs */ List<f> c(f ... arrf) {
        if (arrf == null) {
            throw new IllegalArgumentException("The filters must not be null");
        }
        ArrayList<f> arrayList = new ArrayList<f>(arrf.length);
        for (int i2 = 0; i2 < arrf.length; ++i2) {
            if (arrf[i2] == null) {
                throw new IllegalArgumentException("The filter[" + i2 + "] is null");
            }
            arrayList.add(arrf[i2]);
        }
        return arrayList;
    }
}

