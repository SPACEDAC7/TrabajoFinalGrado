/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a.a;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;

public interface f
extends FileFilter,
FilenameFilter {
    @Override
    public boolean accept(File var1);

    @Override
    public boolean accept(File var1, String var2);
}

