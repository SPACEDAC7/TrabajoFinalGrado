/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a.a;

import a.a.a.a.a.a;
import a.a.a.a.c;
import java.io.File;
import java.io.Serializable;

public final class g
extends a
implements Serializable {
    private final String[] a;
    private final c b;

    public g(String string2) {
        this(string2, 0);
    }

    private g(String string2, byte by) {
        if (string2 == null) {
            throw new IllegalArgumentException("The wildcard must not be null");
        }
        this.a = new String[]{string2};
        this.b = c.a;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final boolean accept(File object) {
        boolean bl = false;
        object = object.getName();
        String[] arrstring = this.a;
        int n2 = arrstring.length;
        int n3 = 0;
        do {
            boolean bl2 = bl;
            if (n3 >= n2) return bl2;
            String string2 = arrstring[n3];
            if (this.b.a((String)object, string2)) {
                return true;
            }
            ++n3;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final boolean accept(File arrstring, String string2) {
        boolean bl = false;
        arrstring = this.a;
        int n2 = arrstring.length;
        int n3 = 0;
        do {
            boolean bl2 = bl;
            if (n3 >= n2) return bl2;
            String string3 = arrstring[n3];
            if (this.b.a(string2, string3)) {
                return true;
            }
            ++n3;
        } while (true);
    }

    @Override
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(super.toString());
        stringBuilder.append("(");
        if (this.a != null) {
            for (int i2 = 0; i2 < this.a.length; ++i2) {
                if (i2 > 0) {
                    stringBuilder.append(",");
                }
                stringBuilder.append(this.a[i2]);
            }
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

