/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a.a;

import a.a.a.a.a.a;
import a.a.a.a.a.f;
import java.io.File;
import java.io.Serializable;

public final class h
extends a
implements Serializable {
    private final f a;

    public h(f f2) {
        if (f2 == null) {
            throw new IllegalArgumentException("The filter must not be null");
        }
        this.a = f2;
    }

    @Override
    public final boolean accept(File file) {
        if (!this.a.accept(file)) {
            return true;
        }
        return false;
    }

    @Override
    public final boolean accept(File file, String string2) {
        if (!this.a.accept(file, string2)) {
            return true;
        }
        return false;
    }

    @Override
    public final String toString() {
        return super.toString() + "(" + this.a.toString() + ")";
    }
}

