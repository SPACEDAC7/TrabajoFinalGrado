/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a.a;

import a.a.a.a.a.f;
import java.io.File;
import java.io.Serializable;

public final class j
implements f,
Serializable {
    public static final f a = new j();

    protected j() {
    }

    @Override
    public final boolean accept(File file) {
        return true;
    }

    @Override
    public final boolean accept(File file, String string2) {
        return true;
    }
}

