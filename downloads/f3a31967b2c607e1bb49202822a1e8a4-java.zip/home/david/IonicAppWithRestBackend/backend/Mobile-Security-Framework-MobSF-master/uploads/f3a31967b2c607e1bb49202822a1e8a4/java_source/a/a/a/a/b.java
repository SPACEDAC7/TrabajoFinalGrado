/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a;

import java.io.File;

public final class b {
    private static final char a;

    static {
        Character.toString('.');
        a = File.separatorChar;
        b.a();
    }

    static boolean a() {
        if (a == '\\') {
            return true;
        }
        return false;
    }
}

