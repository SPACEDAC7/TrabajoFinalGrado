/*
 * Decompiled with CFR 0_115.
 */
package a.a.a.a;

import a.a.a.a.b;
import java.io.Serializable;

public final class c
implements Serializable {
    public static final c a;
    private final String b;
    private final transient boolean c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = true;
        a = new c("Sensitive", true);
        new c("Insensitive", false);
        if (b.a()) {
            bl = false;
        }
        new c("System", bl);
    }

    private c(String string2, boolean bl) {
        this.b = string2;
        this.c = bl;
    }

    public final boolean a(String string2, String string3) {
        if (string2 == null || string3 == null) {
            throw new NullPointerException("The strings must not be null");
        }
        if (this.c) {
            return string2.equals(string3);
        }
        return string2.equalsIgnoreCase(string3);
    }

    public final String toString() {
        return this.b;
    }
}

