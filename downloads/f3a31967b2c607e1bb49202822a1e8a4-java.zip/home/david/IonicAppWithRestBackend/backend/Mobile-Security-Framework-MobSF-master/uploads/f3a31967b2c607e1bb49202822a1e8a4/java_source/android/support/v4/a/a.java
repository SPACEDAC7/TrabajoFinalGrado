/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.a;

import java.io.PrintWriter;

public final class a<D> {
    private int a;
    private a<D> b;
    private boolean c;
    private boolean d;
    private boolean e;

    public final void a() {
        this.c = true;
        this.e = false;
        this.d = false;
    }

    public final void a(int n2, a<D> a2) {
        if (this.b != null) {
            throw new IllegalStateException("There is already a listener registered");
        }
        this.b = a2;
        this.a = n2;
    }

    public final void a(a<D> a2) {
        if (this.b == null) {
            throw new IllegalStateException("No listener register");
        }
        if (this.b != a2) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        }
        this.b = null;
    }

    public final void a(String string2, PrintWriter printWriter) {
        printWriter.print(string2);
        printWriter.print("mId=");
        printWriter.print(this.a);
        printWriter.print(" mListener=");
        printWriter.println(this.b);
        printWriter.print(string2);
        printWriter.print("mStarted=");
        printWriter.print(this.c);
        printWriter.print(" mContentChanged=");
        printWriter.print(false);
        printWriter.print(" mAbandoned=");
        printWriter.print(this.d);
        printWriter.print(" mReset=");
        printWriter.println(this.e);
    }

    public final void b() {
        this.c = false;
    }

    public final void c() {
        this.d = true;
    }

    public final void d() {
        this.e = true;
        this.c = false;
        this.d = false;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(64);
        android.support.v4.b.a.a(this, stringBuilder);
        stringBuilder.append(" id=");
        stringBuilder.append(this.a);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public static interface a<D> {
    }

}

