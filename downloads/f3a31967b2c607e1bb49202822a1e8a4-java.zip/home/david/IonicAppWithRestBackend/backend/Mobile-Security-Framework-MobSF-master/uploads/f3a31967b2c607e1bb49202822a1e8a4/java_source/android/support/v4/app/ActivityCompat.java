/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package android.support.v4.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.ActivityCompatHoneycomb;

public class ActivityCompat {
    public static boolean invalidateOptionsMenu(Activity activity) {
        if (Build.VERSION.SDK_INT >= 11) {
            ActivityCompatHoneycomb.invalidateOptionsMenu(activity);
            return true;
        }
        return false;
    }

    public static boolean startActivities(Activity activity, Intent[] arrintent) {
        if (Build.VERSION.SDK_INT >= 11) {
            ActivityCompatHoneycomb.startActivities(activity, arrintent);
            return true;
        }
        return false;
    }
}

