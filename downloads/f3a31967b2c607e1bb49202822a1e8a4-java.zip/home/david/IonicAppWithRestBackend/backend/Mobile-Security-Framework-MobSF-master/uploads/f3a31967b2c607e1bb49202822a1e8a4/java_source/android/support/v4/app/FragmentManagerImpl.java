/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Parcelable
 *  android.util.Log
 *  android.util.SparseArray
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.view.animation.AccelerateInterpolator
 *  android.view.animation.AlphaAnimation
 *  android.view.animation.Animation
 *  android.view.animation.Animation$AnimationListener
 *  android.view.animation.AnimationSet
 *  android.view.animation.AnimationUtils
 *  android.view.animation.DecelerateInterpolator
 *  android.view.animation.Interpolator
 *  android.view.animation.ScaleAnimation
 */
package android.support.v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.support.v4.app.BackStackRecord;
import android.support.v4.app.BackStackState;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentManagerState;
import android.support.v4.app.FragmentState;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.LoaderManagerImpl;
import android.support.v4.c.a;
import android.util.Log;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;

final class FragmentManagerImpl
extends FragmentManager {
    static final Interpolator ACCELERATE_CUBIC;
    static final Interpolator ACCELERATE_QUINT;
    static final int ANIM_DUR = 220;
    public static final int ANIM_STYLE_CLOSE_ENTER = 3;
    public static final int ANIM_STYLE_CLOSE_EXIT = 4;
    public static final int ANIM_STYLE_FADE_ENTER = 5;
    public static final int ANIM_STYLE_FADE_EXIT = 6;
    public static final int ANIM_STYLE_OPEN_ENTER = 1;
    public static final int ANIM_STYLE_OPEN_EXIT = 2;
    static boolean DEBUG = false;
    static final Interpolator DECELERATE_CUBIC;
    static final Interpolator DECELERATE_QUINT;
    static final boolean HONEYCOMB;
    static final String TAG = "FragmentManager";
    static final String TARGET_REQUEST_CODE_STATE_TAG = "android:target_req_state";
    static final String TARGET_STATE_TAG = "android:target_state";
    static final String USER_VISIBLE_HINT_TAG = "android:user_visible_hint";
    static final String VIEW_STATE_TAG = "android:view_state";
    ArrayList<Fragment> mActive;
    FragmentActivity mActivity;
    ArrayList<Fragment> mAdded;
    ArrayList<Integer> mAvailBackStackIndices;
    ArrayList<Integer> mAvailIndices;
    ArrayList<BackStackRecord> mBackStack;
    ArrayList<FragmentManager.OnBackStackChangedListener> mBackStackChangeListeners;
    ArrayList<BackStackRecord> mBackStackIndices;
    ArrayList<Fragment> mCreatedMenus;
    int mCurState = 0;
    boolean mDestroyed;
    Runnable mExecCommit;
    boolean mExecutingActions;
    boolean mHavePendingDeferredStart;
    boolean mNeedMenuInvalidate;
    String mNoTransactionsBecause;
    ArrayList<Runnable> mPendingActions;
    SparseArray<Parcelable> mStateArray = null;
    Bundle mStateBundle = null;
    boolean mStateSaved;
    Runnable[] mTmpActions;

    static {
        boolean bl = false;
        DEBUG = false;
        if (Build.VERSION.SDK_INT >= 11) {
            bl = true;
        }
        HONEYCOMB = bl;
        DECELERATE_QUINT = new DecelerateInterpolator(2.5f);
        DECELERATE_CUBIC = new DecelerateInterpolator(1.5f);
        ACCELERATE_QUINT = new AccelerateInterpolator(2.5f);
        ACCELERATE_CUBIC = new AccelerateInterpolator(1.5f);
    }

    FragmentManagerImpl() {
        this.mExecCommit = new Runnable(){

            @Override
            public void run() {
                FragmentManagerImpl.this.execPendingActions();
            }
        };
    }

    private void checkStateLoss() {
        if (this.mStateSaved) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
        if (this.mNoTransactionsBecause != null) {
            throw new IllegalStateException("Can not perform this action inside of " + this.mNoTransactionsBecause);
        }
    }

    static Animation makeFadeAnimation(Context context, float f2, float f3) {
        context = new AlphaAnimation(f2, f3);
        context.setInterpolator(DECELERATE_CUBIC);
        context.setDuration(220);
        return context;
    }

    static Animation makeOpenCloseAnimation(Context context, float f2, float f3, float f4, float f5) {
        context = new AnimationSet(false);
        ScaleAnimation scaleAnimation = new ScaleAnimation(f2, f3, f2, f3, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setInterpolator(DECELERATE_QUINT);
        scaleAnimation.setDuration(220);
        context.addAnimation((Animation)scaleAnimation);
        scaleAnimation = new AlphaAnimation(f4, f5);
        scaleAnimation.setInterpolator(DECELERATE_CUBIC);
        scaleAnimation.setDuration(220);
        context.addAnimation((Animation)scaleAnimation);
        return context;
    }

    public static int reverseTransit(int n2) {
        switch (n2) {
            default: {
                return 0;
            }
            case 4097: {
                return 8194;
            }
            case 8194: {
                return 4097;
            }
            case 4099: 
        }
        return 4099;
    }

    public static int transitToStyleIndex(int n2, boolean bl) {
        switch (n2) {
            default: {
                return -1;
            }
            case 4097: {
                if (bl) {
                    return 1;
                }
                return 2;
            }
            case 8194: {
                if (bl) {
                    return 3;
                }
                return 4;
            }
            case 4099: 
        }
        if (bl) {
            return 5;
        }
        return 6;
    }

    final void addBackStackState(BackStackRecord backStackRecord) {
        if (this.mBackStack == null) {
            this.mBackStack = new ArrayList();
        }
        this.mBackStack.add(backStackRecord);
        this.reportBackStackChanged();
    }

    public final void addFragment(Fragment fragment, boolean bl) {
        if (this.mAdded == null) {
            this.mAdded = new ArrayList();
        }
        if (DEBUG) {
            Log.v((String)"FragmentManager", (String)("add: " + fragment));
        }
        this.makeActive(fragment);
        if (!fragment.mDetached) {
            this.mAdded.add(fragment);
            fragment.mAdded = true;
            fragment.mRemoving = false;
            if (fragment.mHasMenu && fragment.mMenuVisible) {
                this.mNeedMenuInvalidate = true;
            }
            if (bl) {
                this.moveToState(fragment);
            }
        }
    }

    @Override
    public final void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener onBackStackChangedListener) {
        if (this.mBackStackChangeListeners == null) {
            this.mBackStackChangeListeners = new ArrayList();
        }
        this.mBackStackChangeListeners.add(onBackStackChangedListener);
    }

    public final int allocBackStackIndex(BackStackRecord backStackRecord) {
        synchronized (this) {
            block7 : {
                if (this.mAvailBackStackIndices != null && this.mAvailBackStackIndices.size() > 0) break block7;
                if (this.mBackStackIndices == null) {
                    this.mBackStackIndices = new ArrayList();
                }
                int n2 = this.mBackStackIndices.size();
                if (DEBUG) {
                    Log.v((String)"FragmentManager", (String)("Setting back stack index " + n2 + " to " + backStackRecord));
                }
                this.mBackStackIndices.add(backStackRecord);
                return n2;
            }
            int n3 = this.mAvailBackStackIndices.remove(this.mAvailBackStackIndices.size() - 1);
            if (DEBUG) {
                Log.v((String)"FragmentManager", (String)("Adding back stack index " + n3 + " with " + backStackRecord));
            }
            this.mBackStackIndices.set(n3, backStackRecord);
            return n3;
        }
    }

    public final void attachActivity(FragmentActivity fragmentActivity) {
        if (this.mActivity != null) {
            throw new IllegalStateException();
        }
        this.mActivity = fragmentActivity;
    }

    public final void attachFragment(Fragment fragment, int n2, int n3) {
        if (DEBUG) {
            Log.v((String)"FragmentManager", (String)("attach: " + fragment));
        }
        if (fragment.mDetached) {
            fragment.mDetached = false;
            if (!fragment.mAdded) {
                this.mAdded.add(fragment);
                fragment.mAdded = true;
                if (fragment.mHasMenu && fragment.mMenuVisible) {
                    this.mNeedMenuInvalidate = true;
                }
                this.moveToState(fragment, this.mCurState, n2, n3);
            }
        }
    }

    @Override
    public final FragmentTransaction beginTransaction() {
        return new BackStackRecord(this);
    }

    public final void detachFragment(Fragment fragment, int n2, int n3) {
        if (DEBUG) {
            Log.v((String)"FragmentManager", (String)("detach: " + fragment));
        }
        if (!fragment.mDetached) {
            fragment.mDetached = true;
            if (fragment.mAdded) {
                this.mAdded.remove(fragment);
                if (fragment.mHasMenu && fragment.mMenuVisible) {
                    this.mNeedMenuInvalidate = true;
                }
                fragment.mAdded = false;
                this.moveToState(fragment, 1, n2, n3);
            }
        }
    }

    public final void dispatchActivityCreated() {
        this.mStateSaved = false;
        this.moveToState(2, false);
    }

    public final void dispatchConfigurationChanged(Configuration configuration) {
        if (this.mActive != null) {
            for (int i2 = 0; i2 < this.mAdded.size(); ++i2) {
                Fragment fragment = this.mAdded.get(i2);
                if (fragment == null) continue;
                fragment.onConfigurationChanged(configuration);
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean dispatchContextItemSelected(MenuItem menuItem) {
        boolean bl;
        boolean bl2 = bl = false;
        if (this.mActive == null) return bl2;
        int n2 = 0;
        do {
            bl2 = bl;
            if (n2 >= this.mAdded.size()) return bl2;
            Fragment fragment = this.mAdded.get(n2);
            if (fragment != null && !fragment.mHidden && fragment.onContextItemSelected(menuItem)) {
                return true;
            }
            ++n2;
        } while (true);
    }

    public final void dispatchCreate() {
        this.mStateSaved = false;
        this.moveToState(1, false);
    }

    public final boolean dispatchCreateOptionsMenu(Menu object, MenuInflater menuInflater) {
        int n2;
        boolean bl;
        int n3 = 0;
        ArrayList<Fragment> arrayList = null;
        ArrayList<Fragment> arrayList2 = null;
        if (this.mActive != null) {
            n2 = 0;
            boolean bl2 = false;
            do {
                arrayList = arrayList2;
                bl = bl2;
                if (n2 < this.mAdded.size()) {
                    Fragment fragment = this.mAdded.get(n2);
                    arrayList = arrayList2;
                    bl = bl2;
                    if (fragment != null) {
                        arrayList = arrayList2;
                        bl = bl2;
                        if (!fragment.mHidden) {
                            arrayList = arrayList2;
                            bl = bl2;
                            if (fragment.mHasMenu) {
                                arrayList = arrayList2;
                                bl = bl2;
                                if (fragment.mMenuVisible) {
                                    bl = true;
                                    fragment.onCreateOptionsMenu((Menu)object, menuInflater);
                                    arrayList = arrayList2;
                                    if (arrayList2 == null) {
                                        arrayList = new ArrayList<Fragment>();
                                    }
                                    arrayList.add(fragment);
                                }
                            }
                        }
                    }
                    ++n2;
                    bl2 = bl;
                    arrayList2 = arrayList;
                    continue;
                }
                break;
                break;
            } while (true);
        } else {
            bl = false;
        }
        if (this.mCreatedMenus != null) {
            for (n2 = n3; n2 < this.mCreatedMenus.size(); ++n2) {
                object = this.mCreatedMenus.get(n2);
                if (arrayList != null && arrayList.contains(object)) continue;
                object.onDestroyOptionsMenu();
            }
        }
        this.mCreatedMenus = arrayList;
        return bl;
    }

    public final void dispatchDestroy() {
        this.mDestroyed = true;
        this.execPendingActions();
        this.moveToState(0, false);
        this.mActivity = null;
    }

    public final void dispatchLowMemory() {
        if (this.mActive != null) {
            for (int i2 = 0; i2 < this.mAdded.size(); ++i2) {
                Fragment fragment = this.mAdded.get(i2);
                if (fragment == null) continue;
                fragment.onLowMemory();
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean dispatchOptionsItemSelected(MenuItem menuItem) {
        boolean bl;
        boolean bl2 = bl = false;
        if (this.mActive == null) return bl2;
        int n2 = 0;
        do {
            bl2 = bl;
            if (n2 >= this.mAdded.size()) return bl2;
            Fragment fragment = this.mAdded.get(n2);
            if (fragment != null && !fragment.mHidden && fragment.mHasMenu && fragment.mMenuVisible && fragment.onOptionsItemSelected(menuItem)) {
                return true;
            }
            ++n2;
        } while (true);
    }

    public final void dispatchOptionsMenuClosed(Menu menu) {
        if (this.mActive != null) {
            for (int i2 = 0; i2 < this.mAdded.size(); ++i2) {
                Fragment fragment = this.mAdded.get(i2);
                if (fragment == null || fragment.mHidden || !fragment.mHasMenu || !fragment.mMenuVisible) continue;
                fragment.onOptionsMenuClosed(menu);
            }
        }
    }

    public final void dispatchPause() {
        this.moveToState(4, false);
    }

    public final boolean dispatchPrepareOptionsMenu(Menu menu) {
        boolean bl;
        if (this.mActive != null) {
            int n2 = 0;
            boolean bl2 = false;
            do {
                bl = bl2;
                if (n2 < this.mAdded.size()) {
                    Fragment fragment = this.mAdded.get(n2);
                    bl = bl2;
                    if (fragment != null) {
                        bl = bl2;
                        if (!fragment.mHidden) {
                            bl = bl2;
                            if (fragment.mHasMenu) {
                                bl = bl2;
                                if (fragment.mMenuVisible) {
                                    bl = true;
                                    fragment.onPrepareOptionsMenu(menu);
                                }
                            }
                        }
                    }
                    ++n2;
                    bl2 = bl;
                    continue;
                }
                break;
                break;
            } while (true);
        } else {
            bl = false;
        }
        return bl;
    }

    public final void dispatchReallyStop() {
        this.moveToState(2, false);
    }

    public final void dispatchResume() {
        this.mStateSaved = false;
        this.moveToState(5, false);
    }

    public final void dispatchStart() {
        this.mStateSaved = false;
        this.moveToState(4, false);
    }

    public final void dispatchStop() {
        this.mStateSaved = true;
        this.moveToState(3, false);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final void dump(String string2, FileDescriptor object, PrintWriter printWriter, String[] arrstring) {
        void var3_3;
        Object object2;
        Runnable runnable;
        int n2;
        int n3;
        void var4_4;
        int n4 = 0;
        String string3 = string2 + "    ";
        if (this.mActive != null && (n3 = this.mActive.size()) > 0) {
            var3_3.print(string2);
            var3_3.print("Active Fragments in ");
            var3_3.print(Integer.toHexString(System.identityHashCode(this)));
            var3_3.println(":");
            for (n2 = 0; n2 < n3; ++n2) {
                object2 = this.mActive.get(n2);
                var3_3.print(string2);
                var3_3.print("  #");
                var3_3.print(n2);
                var3_3.print(": ");
                var3_3.println(object2);
                if (object2 == null) continue;
                object2.dump(string3, (FileDescriptor)((Object)runnable), (PrintWriter)var3_3, (String[])var4_4);
            }
        }
        if (this.mAdded != null && (n3 = this.mAdded.size()) > 0) {
            var3_3.print(string2);
            var3_3.println("Added Fragments:");
            for (n2 = 0; n2 < n3; ++n2) {
                object2 = this.mAdded.get(n2);
                var3_3.print(string2);
                var3_3.print("  #");
                var3_3.print(n2);
                var3_3.print(": ");
                var3_3.println(object2.toString());
            }
        }
        if (this.mCreatedMenus != null && (n3 = this.mCreatedMenus.size()) > 0) {
            var3_3.print(string2);
            var3_3.println("Fragments Created Menus:");
            for (n2 = 0; n2 < n3; ++n2) {
                object2 = this.mCreatedMenus.get(n2);
                var3_3.print(string2);
                var3_3.print("  #");
                var3_3.print(n2);
                var3_3.print(": ");
                var3_3.println(object2.toString());
            }
        }
        if (this.mBackStack != null && (n3 = this.mBackStack.size()) > 0) {
            var3_3.print(string2);
            var3_3.println("Back Stack:");
            for (n2 = 0; n2 < n3; ++n2) {
                object2 = this.mBackStack.get(n2);
                var3_3.print(string2);
                var3_3.print("  #");
                var3_3.print(n2);
                var3_3.print(": ");
                var3_3.println(object2.toString());
                object2.dump(string3, (FileDescriptor)((Object)runnable), (PrintWriter)var3_3, (String[])var4_4);
            }
        }
        // MONITORENTER : this
        if (this.mBackStackIndices != null && (n3 = this.mBackStackIndices.size()) > 0) {
            var3_3.print(string2);
            var3_3.println("Back Stack Indices:");
            for (n2 = 0; n2 < n3; ++n2) {
                runnable = this.mBackStackIndices.get(n2);
                var3_3.print(string2);
                var3_3.print("  #");
                var3_3.print(n2);
                var3_3.print(": ");
                var3_3.println(runnable);
            }
        }
        if (this.mAvailBackStackIndices != null && this.mAvailBackStackIndices.size() > 0) {
            var3_3.print(string2);
            var3_3.print("mAvailBackStackIndices: ");
            var3_3.println(Arrays.toString(this.mAvailBackStackIndices.toArray()));
        }
        // MONITOREXIT : this
        if (this.mPendingActions != null && (n3 = this.mPendingActions.size()) > 0) {
            var3_3.print(string2);
            var3_3.println("Pending Actions:");
            for (n2 = n4; n2 < n3; ++n2) {
                runnable = this.mPendingActions.get(n2);
                var3_3.print(string2);
                var3_3.print("  #");
                var3_3.print(n2);
                var3_3.print(": ");
                var3_3.println(runnable);
            }
        }
        var3_3.print(string2);
        var3_3.println("FragmentManager misc state:");
        var3_3.print(string2);
        var3_3.print("  mCurState=");
        var3_3.print(this.mCurState);
        var3_3.print(" mStateSaved=");
        var3_3.print(this.mStateSaved);
        var3_3.print(" mDestroyed=");
        var3_3.println(this.mDestroyed);
        if (this.mNeedMenuInvalidate) {
            var3_3.print(string2);
            var3_3.print("  mNeedMenuInvalidate=");
            var3_3.println(this.mNeedMenuInvalidate);
        }
        if (this.mNoTransactionsBecause != null) {
            var3_3.print(string2);
            var3_3.print("  mNoTransactionsBecause=");
            var3_3.println(this.mNoTransactionsBecause);
        }
        if (this.mAvailIndices == null) return;
        if (this.mAvailIndices.size() <= 0) return;
        var3_3.print(string2);
        var3_3.print("  mAvailIndices: ");
        var3_3.println(Arrays.toString(this.mAvailIndices.toArray()));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void enqueueAction(Runnable runnable, boolean bl) {
        if (!bl) {
            this.checkStateLoss();
        }
        synchronized (this) {
            if (this.mActivity == null) {
                throw new IllegalStateException("Activity has been destroyed");
            }
            if (this.mPendingActions == null) {
                this.mPendingActions = new ArrayList();
            }
            this.mPendingActions.add(runnable);
            if (this.mPendingActions.size() == 1) {
                this.mActivity.mHandler.removeCallbacks(this.mExecCommit);
                this.mActivity.mHandler.post(this.mExecCommit);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final boolean execPendingActions() {
        boolean bl;
        block12 : {
            if (this.mExecutingActions) {
                throw new IllegalStateException("Recursive entry to executePendingTransactions");
            }
            if (Looper.myLooper() != this.mActivity.mHandler.getLooper()) {
                throw new IllegalStateException("Must be called from main thread of process");
            }
            bl = false;
            do {
                int n2;
                int n3;
                synchronized (this) {
                    if (this.mPendingActions == null || this.mPendingActions.size() == 0) {
                        // MONITOREXIT [2, 3, 11] lbl9 : MonitorExitStatement: MONITOREXIT : this
                        if (!this.mHavePendingDeferredStart) break block12;
                        n2 = 0;
                        for (n3 = 0; n3 < this.mActive.size(); ++n3) {
                            Fragment fragment = this.mActive.get(n3);
                            int n4 = n2;
                            if (fragment != null) {
                                n4 = n2;
                                if (fragment.mLoaderManager != null) {
                                    n4 = n2 | fragment.mLoaderManager.hasRunningLoaders();
                                }
                            }
                            n2 = n4;
                        }
                        break;
                    }
                    n2 = this.mPendingActions.size();
                    if (this.mTmpActions == null || this.mTmpActions.length < n2) {
                        this.mTmpActions = new Runnable[n2];
                    }
                    this.mPendingActions.toArray(this.mTmpActions);
                    this.mPendingActions.clear();
                    this.mActivity.mHandler.removeCallbacks(this.mExecCommit);
                }
                this.mExecutingActions = true;
                for (n3 = 0; n3 < n2; ++n3) {
                    this.mTmpActions[n3].run();
                    this.mTmpActions[n3] = null;
                }
                this.mExecutingActions = false;
                bl = true;
            } while (true);
            this.mHavePendingDeferredStart = false;
            this.startPendingDeferredFragments();
        }
        return bl;
    }

    @Override
    public final boolean executePendingTransactions() {
        return this.execPendingActions();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final Fragment findFragmentById(int n2) {
        int n3;
        Fragment fragment;
        if (this.mActive == null) return null;
        for (n3 = this.mAdded.size() - 1; n3 >= 0; --n3) {
            fragment = this.mAdded.get(n3);
            if (fragment != null && fragment.mFragmentId == n2) return fragment;
            {
                continue;
            }
        }
        for (n3 = this.mActive.size() - 1; n3 >= 0; --n3) {
            Fragment fragment2 = this.mActive.get(n3);
            if (fragment2 == null) continue;
            fragment = fragment2;
            if (fragment2.mFragmentId != n2) continue;
            return fragment;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final Fragment findFragmentByTag(String string2) {
        int n2;
        Fragment fragment;
        if (this.mActive == null || string2 == null) return null;
        for (n2 = this.mAdded.size() - 1; n2 >= 0; --n2) {
            fragment = this.mAdded.get(n2);
            if (fragment != null && string2.equals(fragment.mTag)) return fragment;
            {
                continue;
            }
        }
        for (n2 = this.mActive.size() - 1; n2 >= 0; --n2) {
            Fragment fragment2 = this.mActive.get(n2);
            if (fragment2 == null) continue;
            fragment = fragment2;
            if (!string2.equals(fragment2.mTag)) continue;
            return fragment;
        }
        return null;
    }

    public final Fragment findFragmentByWho(String string2) {
        if (this.mActive != null && string2 != null) {
            for (int i2 = this.mActive.size() - 1; i2 >= 0; --i2) {
                Fragment fragment = this.mActive.get(i2);
                if (fragment == null || !string2.equals(fragment.mWho)) continue;
                return fragment;
            }
        }
        return null;
    }

    public final void freeBackStackIndex(int n2) {
        synchronized (this) {
            this.mBackStackIndices.set(n2, null);
            if (this.mAvailBackStackIndices == null) {
                this.mAvailBackStackIndices = new ArrayList();
            }
            if (DEBUG) {
                Log.v((String)"FragmentManager", (String)("Freeing back stack index " + n2));
            }
            this.mAvailBackStackIndices.add(n2);
            return;
        }
    }

    @Override
    public final FragmentManager.BackStackEntry getBackStackEntryAt(int n2) {
        return this.mBackStack.get(n2);
    }

    @Override
    public final int getBackStackEntryCount() {
        if (this.mBackStack != null) {
            return this.mBackStack.size();
        }
        return 0;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Fragment getFragment(Bundle object, String string2) {
        Fragment fragment;
        int n2 = object.getInt(string2, -1);
        if (n2 == -1) {
            return null;
        }
        if (n2 >= this.mActive.size()) {
            throw new IllegalStateException("Fragement no longer exists for key " + string2 + ": index " + n2);
        }
        object = fragment = this.mActive.get(n2);
        if (fragment != null) return object;
        throw new IllegalStateException("Fragement no longer exists for key " + string2 + ": index " + n2);
    }

    public final void hideFragment(Fragment fragment, int n2, int n3) {
        if (DEBUG) {
            Log.v((String)"FragmentManager", (String)("hide: " + fragment));
        }
        if (!fragment.mHidden) {
            fragment.mHidden = true;
            if (fragment.mView != null) {
                Animation animation = this.loadAnimation(fragment, n2, true, n3);
                if (animation != null) {
                    fragment.mView.startAnimation(animation);
                }
                fragment.mView.setVisibility(8);
            }
            if (fragment.mAdded && fragment.mHasMenu && fragment.mMenuVisible) {
                this.mNeedMenuInvalidate = true;
            }
            fragment.onHiddenChanged(true);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    final Animation loadAnimation(Fragment fragment, int n2, boolean bl, int n3) {
        Animation animation = fragment.onCreateAnimation(n2, bl, fragment.mNextAnim);
        if (animation != null) {
            return animation;
        }
        if (fragment.mNextAnim != 0) {
            fragment = animation = AnimationUtils.loadAnimation((Context)this.mActivity, (int)fragment.mNextAnim);
            if (animation != null) return fragment;
        }
        if (n2 == 0) {
            return null;
        }
        if ((n2 = FragmentManagerImpl.transitToStyleIndex(n2, bl)) < 0) {
            return null;
        }
        switch (n2) {
            default: {
                n2 = n3;
                if (n3 == 0) {
                    n2 = n3;
                    if (this.mActivity.getWindow() != null) {
                        n2 = this.mActivity.getWindow().getAttributes().windowAnimations;
                    }
                }
                if (n2 != 0) return null;
                return null;
            }
            case 1: {
                return FragmentManagerImpl.makeOpenCloseAnimation((Context)this.mActivity, 1.125f, 1.0f, 0.0f, 1.0f);
            }
            case 2: {
                return FragmentManagerImpl.makeOpenCloseAnimation((Context)this.mActivity, 1.0f, 0.975f, 1.0f, 0.0f);
            }
            case 3: {
                return FragmentManagerImpl.makeOpenCloseAnimation((Context)this.mActivity, 0.975f, 1.0f, 0.0f, 1.0f);
            }
            case 4: {
                return FragmentManagerImpl.makeOpenCloseAnimation((Context)this.mActivity, 1.0f, 1.075f, 1.0f, 0.0f);
            }
            case 5: {
                return FragmentManagerImpl.makeFadeAnimation((Context)this.mActivity, 0.0f, 1.0f);
            }
            case 6: {
                return FragmentManagerImpl.makeFadeAnimation((Context)this.mActivity, 1.0f, 0.0f);
            }
        }
    }

    final void makeActive(Fragment fragment) {
        if (fragment.mIndex >= 0) {
            return;
        }
        if (this.mAvailIndices == null || this.mAvailIndices.size() <= 0) {
            if (this.mActive == null) {
                this.mActive = new ArrayList();
            }
            fragment.setIndex(this.mActive.size());
            this.mActive.add(fragment);
            return;
        }
        fragment.setIndex(this.mAvailIndices.remove(this.mAvailIndices.size() - 1));
        this.mActive.set(fragment.mIndex, fragment);
    }

    final void makeInactive(Fragment fragment) {
        if (fragment.mIndex < 0) {
            return;
        }
        if (DEBUG) {
            Log.v((String)"FragmentManager", (String)("Freeing fragment index " + fragment.mIndex));
        }
        this.mActive.set(fragment.mIndex, null);
        if (this.mAvailIndices == null) {
            this.mAvailIndices = new ArrayList();
        }
        this.mAvailIndices.add(fragment.mIndex);
        this.mActivity.invalidateSupportFragmentIndex(fragment.mIndex);
        fragment.initState();
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final void moveToState(int n2, int n3, int n4, boolean bl) {
        if (this.mActivity == null && n2 != 0) {
            throw new IllegalStateException("No activity");
        }
        if (!bl && this.mCurState == n2) {
            return;
        }
        this.mCurState = n2;
        if (this.mActive == null) return;
        int n5 = 0;
        boolean bl2 = false;
        do {
            if (n5 >= this.mActive.size()) {
                this.startPendingDeferredFragments();
                if (!this.mNeedMenuInvalidate) return;
                if (this.mActivity == null) return;
                if (this.mCurState != 5) return;
                this.mActivity.supportInvalidateOptionsMenu();
                this.mNeedMenuInvalidate = false;
                return;
            }
            Fragment fragment = this.mActive.get(n5);
            boolean bl3 = bl2;
            if (fragment != null) {
                this.moveToState(fragment, n2, n3, n4);
                bl3 = bl2;
                if (fragment.mLoaderManager != null) {
                    bl3 = bl2 | fragment.mLoaderManager.hasRunningLoaders();
                }
            }
            ++n5;
            bl2 = bl3;
        } while (true);
    }

    final void moveToState(int n2, boolean bl) {
        this.moveToState(n2, 0, 0, bl);
    }

    final void moveToState(Fragment fragment) {
        this.moveToState(fragment, this.mCurState, 0, 0);
    }

    /*
     * Exception decompiling
     */
    final void moveToState(Fragment var1_1, int var2_2, int var3_3, int var4_4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.CannotPerformDecode: reachable test BLOCK was exited and re-entered.
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.getFarthestReachableInRange(Misc.java:143)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:385)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    public final void noteStateNotSaved() {
        this.mStateSaved = false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void performPendingDeferredStart(Fragment fragment) {
        if (!fragment.mDeferStart) return;
        if (this.mExecutingActions) {
            this.mHavePendingDeferredStart = true;
            return;
        }
        fragment.mDeferStart = false;
        this.moveToState(fragment, this.mCurState, 0, 0);
    }

    @Override
    public final void popBackStack() {
        this.enqueueAction(new Runnable(){

            @Override
            public void run() {
                FragmentManagerImpl.this.popBackStackState(FragmentManagerImpl.this.mActivity.mHandler, null, -1, 0);
            }
        }, false);
    }

    @Override
    public final void popBackStack(final int n2, final int n3) {
        if (n2 < 0) {
            throw new IllegalArgumentException("Bad id: " + n2);
        }
        this.enqueueAction(new Runnable(){

            @Override
            public void run() {
                FragmentManagerImpl.this.popBackStackState(FragmentManagerImpl.this.mActivity.mHandler, null, n2, n3);
            }
        }, false);
    }

    @Override
    public final void popBackStack(final String string2, final int n2) {
        this.enqueueAction(new Runnable(){

            @Override
            public void run() {
                FragmentManagerImpl.this.popBackStackState(FragmentManagerImpl.this.mActivity.mHandler, string2, -1, n2);
            }
        }, false);
    }

    @Override
    public final boolean popBackStackImmediate() {
        this.checkStateLoss();
        this.executePendingTransactions();
        return this.popBackStackState(this.mActivity.mHandler, null, -1, 0);
    }

    @Override
    public final boolean popBackStackImmediate(int n2, int n3) {
        this.checkStateLoss();
        this.executePendingTransactions();
        if (n2 < 0) {
            throw new IllegalArgumentException("Bad id: " + n2);
        }
        return this.popBackStackState(this.mActivity.mHandler, null, n2, n3);
    }

    @Override
    public final boolean popBackStackImmediate(String string2, int n2) {
        this.checkStateLoss();
        this.executePendingTransactions();
        return this.popBackStackState(this.mActivity.mHandler, string2, -1, n2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final boolean popBackStackState(Handler var1_1, String var2_2, int var3_3, int var4_4) {
        if (this.mBackStack == null) {
            return false;
        }
        if (var2_2 != null || var3_3 >= 0 || (var4_4 & 1) != 0) ** GOTO lbl8
        var3_3 = this.mBackStack.size() - 1;
        if (var3_3 < 0) return false;
        this.mBackStack.remove(var3_3).popFromBackStack(true);
        ** GOTO lbl-1000
lbl8: // 1 sources:
        var5_5 = -1;
        if (var2_2 != null || var3_3 >= 0) {
            for (var6_6 = this.mBackStack.size() - 1; var6_6 >= 0; --var6_6) {
                var1_1 = this.mBackStack.get(var6_6);
                if (var2_2 != null && var2_2.equals(var1_1.getName()) || var3_3 >= 0 && var3_3 == var1_1.mIndex) break;
            }
            if (var6_6 < 0) return false;
            var5_5 = var6_6;
            if ((var4_4 & 1) != 0) {
                var4_4 = var6_6 - 1;
                do {
                    var5_5 = var4_4;
                    if (var4_4 < 0) break;
                    var1_1 = this.mBackStack.get(var4_4);
                    if (var2_2 == null || !var2_2.equals(var1_1.getName())) {
                        var5_5 = var4_4;
                        if (var3_3 < 0) break;
                        var5_5 = var4_4;
                        if (var3_3 != var1_1.mIndex) break;
                    }
                    --var4_4;
                } while (true);
            }
        }
        if (var5_5 == this.mBackStack.size() - 1) return false;
        var1_1 = new ArrayList<E>();
        for (var3_3 = this.mBackStack.size() - 1; var3_3 > var5_5; --var3_3) {
            var1_1.add(this.mBackStack.remove(var3_3));
        }
        var4_4 = var1_1.size() - 1;
        var3_3 = 0;
        do {
            if (var3_3 > var4_4) lbl-1000: // 2 sources:
            {
                this.reportBackStackChanged();
                return true;
            }
            if (FragmentManagerImpl.DEBUG) {
                Log.v((String)"FragmentManager", (String)("Popping back stack state: " + var1_1.get(var3_3)));
            }
            var2_2 = (BackStackRecord)var1_1.get(var3_3);
            var7_7 = var3_3 == var4_4;
            var2_2.popFromBackStack(var7_7);
            ++var3_3;
        } while (true);
    }

    @Override
    public final void putFragment(Bundle bundle, String string2, Fragment fragment) {
        if (fragment.mIndex < 0) {
            throw new IllegalStateException("Fragment " + fragment + " is not currently in the FragmentManager");
        }
        bundle.putInt(string2, fragment.mIndex);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void removeFragment(Fragment fragment, int n2, int n3) {
        int n4 = 0;
        if (DEBUG) {
            Log.v((String)"FragmentManager", (String)("remove: " + fragment + " nesting=" + fragment.mBackStackNesting));
        }
        int n5 = !fragment.isInBackStack() ? 1 : 0;
        if (!fragment.mDetached || n5 != 0) {
            this.mAdded.remove(fragment);
            if (fragment.mHasMenu && fragment.mMenuVisible) {
                this.mNeedMenuInvalidate = true;
            }
            fragment.mAdded = false;
            fragment.mRemoving = true;
            n5 = n5 != 0 ? n4 : 1;
            this.moveToState(fragment, n5, n2, n3);
        }
    }

    @Override
    public final void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener onBackStackChangedListener) {
        if (this.mBackStackChangeListeners != null) {
            this.mBackStackChangeListeners.remove(onBackStackChangedListener);
        }
    }

    final void reportBackStackChanged() {
        if (this.mBackStackChangeListeners != null) {
            for (int i2 = 0; i2 < this.mBackStackChangeListeners.size(); ++i2) {
                this.mBackStackChangeListeners.get(i2).onBackStackChanged();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    final void restoreAllState(Parcelable parcelable, ArrayList<Fragment> object) {
        int n2 = 0;
        if (parcelable != null) {
            parcelable = (FragmentManagerState)parcelable;
            if (parcelable.mActive != null) {
                Object object2;
                Object object3;
                int n3;
                if (object != null) {
                    for (n3 = 0; n3 < object.size(); ++n3) {
                        object3 = (Fragment)object.get(n3);
                        if (DEBUG) {
                            Log.v((String)"FragmentManager", (String)("restoreAllState: re-attaching retained " + object3));
                        }
                        object2 = parcelable.mActive[object3.mIndex];
                        object2.mInstance = object3;
                        object3.mSavedViewState = null;
                        object3.mBackStackNesting = 0;
                        object3.mInLayout = false;
                        object3.mAdded = false;
                        object3.mTarget = null;
                        if (object2.mSavedFragmentState == null) continue;
                        object2.mSavedFragmentState.setClassLoader(this.mActivity.getClassLoader());
                        object3.mSavedViewState = object2.mSavedFragmentState.getSparseParcelableArray("android:view_state");
                    }
                }
                this.mActive = new ArrayList(parcelable.mActive.length);
                if (this.mAvailIndices != null) {
                    this.mAvailIndices.clear();
                }
                for (n3 = 0; n3 < parcelable.mActive.length; ++n3) {
                    object3 = parcelable.mActive[n3];
                    if (object3 != null) {
                        object2 = object3.instantiate(this.mActivity);
                        if (DEBUG) {
                            Log.v((String)"FragmentManager", (String)("restoreAllState: adding #" + n3 + ": " + object2));
                        }
                        this.mActive.add((Fragment)object2);
                        object3.mInstance = null;
                        continue;
                    }
                    if (DEBUG) {
                        Log.v((String)"FragmentManager", (String)("restoreAllState: adding #" + n3 + ": (null)"));
                    }
                    this.mActive.add(null);
                    if (this.mAvailIndices == null) {
                        this.mAvailIndices = new ArrayList();
                    }
                    if (DEBUG) {
                        Log.v((String)"FragmentManager", (String)("restoreAllState: adding avail #" + n3));
                    }
                    this.mAvailIndices.add(n3);
                }
                if (object != null) {
                    for (n3 = 0; n3 < object.size(); ++n3) {
                        object3 = (Fragment)object.get(n3);
                        if (object3.mTargetIndex < 0) continue;
                        if (object3.mTargetIndex < this.mActive.size()) {
                            object3.mTarget = this.mActive.get(object3.mTargetIndex);
                            continue;
                        }
                        Log.w((String)"FragmentManager", (String)("Re-attaching retained fragment " + object3 + " target no longer exists: " + object3.mTargetIndex));
                        object3.mTarget = null;
                    }
                }
                if (parcelable.mAdded == null) {
                    this.mAdded = null;
                } else {
                    this.mAdded = new ArrayList(parcelable.mAdded.length);
                    for (n3 = 0; n3 < parcelable.mAdded.length; ++n3) {
                        object = this.mActive.get(parcelable.mAdded[n3]);
                        if (object == null) {
                            throw new IllegalStateException("No instantiated fragment for index #" + parcelable.mAdded[n3]);
                        }
                        object.mAdded = true;
                        if (DEBUG) {
                            Log.v((String)"FragmentManager", (String)("restoreAllState: making added #" + n3 + ": " + object));
                        }
                        this.mAdded.add((Fragment)object);
                    }
                }
                if (parcelable.mBackStack == null) {
                    this.mBackStack = null;
                    return;
                }
                this.mBackStack = new ArrayList(parcelable.mBackStack.length);
                for (n3 = n2; n3 < parcelable.mBackStack.length; ++n3) {
                    object = parcelable.mBackStack[n3].instantiate(this);
                    if (DEBUG) {
                        Log.v((String)"FragmentManager", (String)("restoreAllState: adding bse #" + n3 + " (index " + object.mIndex + "): " + object));
                    }
                    this.mBackStack.add((BackStackRecord)object);
                    if (object.mIndex < 0) continue;
                    this.setBackStackIndex(object.mIndex, (BackStackRecord)object);
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    final ArrayList<Fragment> retainNonConfig() {
        ArrayList<Fragment> arrayList = null;
        ArrayList<Fragment> arrayList2 = null;
        if (this.mActive == null) return arrayList;
        int n2 = 0;
        do {
            arrayList = arrayList2;
            if (n2 >= this.mActive.size()) {
                return arrayList;
            }
            Fragment fragment = this.mActive.get(n2);
            arrayList = arrayList2;
            if (fragment != null) {
                arrayList = arrayList2;
                if (fragment.mRetainInstance) {
                    arrayList = arrayList2;
                    if (arrayList2 == null) {
                        arrayList = new ArrayList<Fragment>();
                    }
                    arrayList.add(fragment);
                    fragment.mRetaining = true;
                    int n3 = fragment.mTarget != null ? fragment.mTarget.mIndex : -1;
                    fragment.mTargetIndex = n3;
                }
            }
            ++n2;
            arrayList2 = arrayList;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final Parcelable saveAllState() {
        BackStackState[] arrbackStackState = null;
        this.execPendingActions();
        if (HONEYCOMB) {
            this.mStateSaved = true;
        }
        if (this.mActive == null) return null;
        if (this.mActive.size() <= 0) {
            return null;
        }
        int n2 = this.mActive.size();
        FragmentState[] arrfragmentState = new FragmentState[n2];
        int n3 = 0;
        int n4 = 0;
        do {
            if (n3 >= n2) {
                if (!DEBUG) return null;
                Log.v((String)"FragmentManager", (String)"saveAllState: no fragments!");
                return null;
            }
            int[] arrn = this.mActive.get(n3);
            if (arrn != null) {
                BackStackState[] arrbackStackState2;
                arrfragmentState[n3] = arrbackStackState2 = new int[]((Fragment)arrn);
                if (arrn.mState > 0 && arrbackStackState2.mSavedFragmentState == null) {
                    arrbackStackState2.mSavedFragmentState = this.saveFragmentBasicState((Fragment)arrn);
                    if (arrn.mTarget != null) {
                        if (arrn.mTarget.mIndex < 0) {
                            arrn = "Failure saving state: " + arrn + " has target not in fragment manager: " + arrn.mTarget;
                            Log.e((String)"FragmentManager", (String)arrn);
                            this.dump("  ", null, new PrintWriter(new a("FragmentManager")), new String[0]);
                            throw new IllegalStateException((String)arrn);
                        }
                        if (arrbackStackState2.mSavedFragmentState == null) {
                            arrbackStackState2.mSavedFragmentState = new Bundle();
                        }
                        this.putFragment(arrbackStackState2.mSavedFragmentState, "android:target_state", arrn.mTarget);
                        if (arrn.mTargetRequestCode != 0) {
                            arrbackStackState2.mSavedFragmentState.putInt("android:target_req_state", arrn.mTargetRequestCode);
                        }
                    }
                } else {
                    arrbackStackState2.mSavedFragmentState = arrn.mSavedFragmentState;
                }
                if (DEBUG) {
                    Log.v((String)"FragmentManager", (String)("Saved state of " + arrn + ": " + (Object)arrbackStackState2.mSavedFragmentState));
                }
                n4 = 1;
            }
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    final Bundle saveFragmentBasicState(Fragment fragment) {
        Bundle bundle;
        if (this.mStateBundle == null) {
            this.mStateBundle = new Bundle();
        }
        fragment.onSaveInstanceState(this.mStateBundle);
        if (!this.mStateBundle.isEmpty()) {
            bundle = this.mStateBundle;
            this.mStateBundle = null;
        } else {
            bundle = null;
        }
        if (fragment.mView != null) {
            this.saveFragmentViewState(fragment);
        }
        Bundle bundle2 = bundle;
        if (fragment.mSavedViewState != null) {
            bundle2 = bundle;
            if (bundle == null) {
                bundle2 = new Bundle();
            }
            bundle2.putSparseParcelableArray("android:view_state", fragment.mSavedViewState);
        }
        if (!fragment.mUserVisibleHint) {
            bundle2.putBoolean("android:user_visible_hint", fragment.mUserVisibleHint);
        }
        return bundle2;
    }

    @Override
    public final Fragment.SavedState saveFragmentInstanceState(Fragment fragment) {
        Fragment.SavedState savedState = null;
        if (fragment.mIndex < 0) {
            throw new IllegalStateException("Fragment " + fragment + " is not currently in the FragmentManager");
        }
        Fragment.SavedState savedState2 = savedState;
        if (fragment.mState > 0) {
            fragment = this.saveFragmentBasicState(fragment);
            savedState2 = savedState;
            if (fragment != null) {
                savedState2 = new Fragment.SavedState((Bundle)fragment);
            }
        }
        return savedState2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final void saveFragmentViewState(Fragment fragment) {
        if (fragment.mInnerView == null) {
            return;
        }
        if (this.mStateArray == null) {
            this.mStateArray = new SparseArray();
        } else {
            this.mStateArray.clear();
        }
        fragment.mInnerView.saveHierarchyState(this.mStateArray);
        if (this.mStateArray.size() <= 0) return;
        fragment.mSavedViewState = this.mStateArray;
        this.mStateArray = null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void setBackStackIndex(int n2, BackStackRecord backStackRecord) {
        synchronized (this) {
            block14 : {
                int n3;
                if (this.mBackStackIndices == null) {
                    this.mBackStackIndices = new ArrayList();
                }
                if (n2 >= n3) break block14;
                if (DEBUG) {
                    Log.v((String)"FragmentManager", (String)("Setting back stack index " + n2 + " to " + backStackRecord));
                }
                this.mBackStackIndices.set(n2, backStackRecord);
                do {
                    return;
                    break;
                } while (true);
            }
            for (int i2 = n3 = this.mBackStackIndices.size(); i2 < n2; ++i2) {
                this.mBackStackIndices.add(null);
                if (this.mAvailBackStackIndices == null) {
                    this.mAvailBackStackIndices = new ArrayList();
                }
                if (DEBUG) {
                    Log.v((String)"FragmentManager", (String)("Adding available back stack index " + i2));
                }
                this.mAvailBackStackIndices.add(i2);
            }
            try {
                if (DEBUG) {
                    Log.v((String)"FragmentManager", (String)("Adding back stack index " + n2 + " with " + backStackRecord));
                }
                this.mBackStackIndices.add(backStackRecord);
                return;
            }
            catch (Throwable var2_3) {
                throw var2_3;
            }
            finally {
            }
        }
    }

    public final void showFragment(Fragment fragment, int n2, int n3) {
        if (DEBUG) {
            Log.v((String)"FragmentManager", (String)("show: " + fragment));
        }
        if (fragment.mHidden) {
            fragment.mHidden = false;
            if (fragment.mView != null) {
                Animation animation = this.loadAnimation(fragment, n2, true, n3);
                if (animation != null) {
                    fragment.mView.startAnimation(animation);
                }
                fragment.mView.setVisibility(0);
            }
            if (fragment.mAdded && fragment.mHasMenu && fragment.mMenuVisible) {
                this.mNeedMenuInvalidate = true;
            }
            fragment.onHiddenChanged(false);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    final void startPendingDeferredFragments() {
        if (this.mActive == null) {
            return;
        }
        int n2 = 0;
        while (n2 < this.mActive.size()) {
            Fragment fragment = this.mActive.get(n2);
            if (fragment != null) {
                this.performPendingDeferredStart(fragment);
            }
            ++n2;
        }
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("FragmentManager{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append(" in ");
        android.support.v4.b.a.a((Object)this.mActivity, stringBuilder);
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }

}

