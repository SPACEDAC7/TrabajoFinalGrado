/*
 * Decompiled with CFR 0_115.
 */
package android.support.v4.app;

class HCSparseArray<E> {
    private static final Object DELETED = new Object();
    private boolean mGarbage = false;
    private int[] mKeys;
    private int mSize;
    private Object[] mValues;

    public HCSparseArray() {
        this(10);
    }

    public HCSparseArray(int n2) {
        n2 = HCSparseArray.idealIntArraySize(n2);
        this.mKeys = new int[n2];
        this.mValues = new Object[n2];
        this.mSize = 0;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static int binarySearch(int[] arrn, int n2, int n3, int n4) {
        int n5 = n2 - 1;
        int n6 = n2 + n3;
        while (n6 - n5 > 1) {
            int n7 = (n6 + n5) / 2;
            if (arrn[n7] < n4) {
                n5 = n7;
                continue;
            }
            n6 = n7;
        }
        if (n6 == n2 + n3) {
            return ~ (n2 + n3);
        }
        n2 = n6;
        if (arrn[n6] == n4) return n2;
        return ~ n6;
    }

    private void gc() {
        int n2 = this.mSize;
        int[] arrn = this.mKeys;
        Object[] arrobject = this.mValues;
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            Object object = arrobject[i2];
            int n4 = n3;
            if (object != DELETED) {
                if (i2 != n3) {
                    arrn[n3] = arrn[i2];
                    arrobject[n3] = object;
                }
                n4 = n3 + 1;
            }
            n3 = n4;
        }
        this.mGarbage = false;
        this.mSize = n3;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static int idealByteArraySize(int n2) {
        int n3 = 4;
        do {
            int n4 = n2;
            if (n3 >= 32) return n4;
            if (n2 <= (1 << n3) - 12) {
                return (1 << n3) - 12;
            }
            ++n3;
        } while (true);
    }

    static int idealIntArraySize(int n2) {
        return HCSparseArray.idealByteArraySize(n2 << 2) / 4;
    }

    public void append(int n2, E e2) {
        int n3;
        if (this.mSize != 0 && n2 <= this.mKeys[this.mSize - 1]) {
            this.put(n2, e2);
            return;
        }
        if (this.mGarbage && this.mSize >= this.mKeys.length) {
            this.gc();
        }
        if ((n3 = this.mSize) >= this.mKeys.length) {
            int n4 = HCSparseArray.idealIntArraySize(n3 + 1);
            int[] arrn = new int[n4];
            Object[] arrobject = new Object[n4];
            System.arraycopy(this.mKeys, 0, arrn, 0, this.mKeys.length);
            System.arraycopy(this.mValues, 0, arrobject, 0, this.mValues.length);
            this.mKeys = arrn;
            this.mValues = arrobject;
        }
        this.mKeys[n3] = n2;
        this.mValues[n3] = e2;
        this.mSize = n3 + 1;
    }

    public void clear() {
        int n2 = this.mSize;
        Object[] arrobject = this.mValues;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrobject[i2] = null;
        }
        this.mSize = 0;
        this.mGarbage = false;
    }

    public void delete(int n2) {
        if ((n2 = HCSparseArray.binarySearch(this.mKeys, 0, this.mSize, n2)) >= 0 && this.mValues[n2] != DELETED) {
            this.mValues[n2] = DELETED;
            this.mGarbage = true;
        }
    }

    public E get(int n2) {
        return this.get(n2, null);
    }

    public E get(int n2, E e2) {
        if ((n2 = HCSparseArray.binarySearch(this.mKeys, 0, this.mSize, n2)) < 0 || this.mValues[n2] == DELETED) {
            return e2;
        }
        return (E)this.mValues[n2];
    }

    public int indexOfKey(int n2) {
        if (this.mGarbage) {
            this.gc();
        }
        return HCSparseArray.binarySearch(this.mKeys, 0, this.mSize, n2);
    }

    public int indexOfValue(E e2) {
        if (this.mGarbage) {
            this.gc();
        }
        for (int i2 = 0; i2 < this.mSize; ++i2) {
            if (this.mValues[i2] != e2) continue;
            return i2;
        }
        return -1;
    }

    public int keyAt(int n2) {
        if (this.mGarbage) {
            this.gc();
        }
        return this.mKeys[n2];
    }

    public void put(int n2, E e2) {
        int n3 = HCSparseArray.binarySearch(this.mKeys, 0, this.mSize, n2);
        if (n3 >= 0) {
            this.mValues[n3] = e2;
            return;
        }
        int n4 = ~ n3;
        if (n4 < this.mSize && this.mValues[n4] == DELETED) {
            this.mKeys[n4] = n2;
            this.mValues[n4] = e2;
            return;
        }
        n3 = n4;
        if (this.mGarbage) {
            n3 = n4;
            if (this.mSize >= this.mKeys.length) {
                this.gc();
                n3 = ~ HCSparseArray.binarySearch(this.mKeys, 0, this.mSize, n2);
            }
        }
        if (this.mSize >= this.mKeys.length) {
            n4 = HCSparseArray.idealIntArraySize(this.mSize + 1);
            int[] arrn = new int[n4];
            Object[] arrobject = new Object[n4];
            System.arraycopy(this.mKeys, 0, arrn, 0, this.mKeys.length);
            System.arraycopy(this.mValues, 0, arrobject, 0, this.mValues.length);
            this.mKeys = arrn;
            this.mValues = arrobject;
        }
        if (this.mSize - n3 != 0) {
            System.arraycopy(this.mKeys, n3, this.mKeys, n3 + 1, this.mSize - n3);
            System.arraycopy(this.mValues, n3, this.mValues, n3 + 1, this.mSize - n3);
        }
        this.mKeys[n3] = n2;
        this.mValues[n3] = e2;
        ++this.mSize;
    }

    public void remove(int n2) {
        this.delete(n2);
    }

    public void removeAt(int n2) {
        if (this.mValues[n2] != DELETED) {
            this.mValues[n2] = DELETED;
            this.mGarbage = true;
        }
    }

    public void setValueAt(int n2, E e2) {
        if (this.mGarbage) {
            this.gc();
        }
        this.mValues[n2] = e2;
    }

    public int size() {
        if (this.mGarbage) {
            this.gc();
        }
        return this.mSize;
    }

    public E valueAt(int n2) {
        if (this.mGarbage) {
            this.gc();
        }
        return (E)this.mValues[n2];
    }
}

