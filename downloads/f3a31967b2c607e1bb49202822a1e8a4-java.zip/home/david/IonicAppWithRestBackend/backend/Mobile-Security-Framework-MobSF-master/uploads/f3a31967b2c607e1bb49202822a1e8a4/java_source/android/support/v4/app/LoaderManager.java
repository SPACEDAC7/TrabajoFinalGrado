/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 */
package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.a.a;
import android.support.v4.app.LoaderManagerImpl;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class LoaderManager {
    public static void enableDebugLogging(boolean bl) {
        LoaderManagerImpl.DEBUG = bl;
    }

    public abstract void destroyLoader(int var1);

    public abstract void dump(String var1, FileDescriptor var2, PrintWriter var3, String[] var4);

    public abstract <D> a<D> getLoader(int var1);

    public boolean hasRunningLoaders() {
        return false;
    }

    public abstract <D> a<D> initLoader(int var1, Bundle var2, LoaderCallbacks<D> var3);

    public abstract <D> a<D> restartLoader(int var1, Bundle var2, LoaderCallbacks<D> var3);

    public static interface LoaderCallbacks<D> {
        public a<D> onCreateLoader(int var1, Bundle var2);

        public void onLoadFinished(a<D> var1, D var2);

        public void onLoaderReset(a<D> var1);
    }

}

