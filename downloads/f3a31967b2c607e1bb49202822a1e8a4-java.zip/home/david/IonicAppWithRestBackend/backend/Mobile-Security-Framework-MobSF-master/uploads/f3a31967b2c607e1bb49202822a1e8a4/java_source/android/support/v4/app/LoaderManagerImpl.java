/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.util.Log
 */
package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.a.a;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManagerImpl;
import android.support.v4.app.HCSparseArray;
import android.support.v4.app.LoaderManager;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;

class LoaderManagerImpl
extends LoaderManager {
    static boolean DEBUG = false;
    static final String TAG = "LoaderManager";
    FragmentActivity mActivity;
    boolean mCreatingLoader;
    final HCSparseArray<LoaderInfo> mInactiveLoaders = new HCSparseArray();
    final HCSparseArray<LoaderInfo> mLoaders = new HCSparseArray();
    boolean mRetaining;
    boolean mRetainingStarted;
    boolean mStarted;

    static {
        DEBUG = false;
    }

    LoaderManagerImpl(FragmentActivity fragmentActivity, boolean bl) {
        this.mActivity = fragmentActivity;
        this.mStarted = bl;
    }

    private LoaderInfo createAndInstallLoader(int n2, Bundle object, LoaderManager.LoaderCallbacks<Object> loaderCallbacks) {
        try {
            this.mCreatingLoader = true;
            object = this.createLoader(n2, (Bundle)object, loaderCallbacks);
            this.installLoader((LoaderInfo)object);
            return object;
        }
        finally {
            this.mCreatingLoader = false;
        }
    }

    private LoaderInfo createLoader(int n2, Bundle bundle, LoaderManager.LoaderCallbacks<Object> loaderCallbacks) {
        LoaderInfo loaderInfo = new LoaderInfo(n2, bundle, loaderCallbacks);
        loaderInfo.mLoader = loaderCallbacks.onCreateLoader(n2, bundle);
        return loaderInfo;
    }

    @Override
    public void destroyLoader(int n2) {
        int n3;
        LoaderInfo loaderInfo;
        if (this.mCreatingLoader) {
            throw new IllegalStateException("Called while creating a loader");
        }
        if (DEBUG) {
            Log.v((String)"LoaderManager", (String)("destroyLoader in " + this + " of " + n2));
        }
        if ((n3 = this.mLoaders.indexOfKey(n2)) >= 0) {
            loaderInfo = this.mLoaders.valueAt(n3);
            this.mLoaders.removeAt(n3);
            loaderInfo.destroy();
        }
        if ((n2 = this.mInactiveLoaders.indexOfKey(n2)) >= 0) {
            loaderInfo = this.mInactiveLoaders.valueAt(n2);
            this.mInactiveLoaders.removeAt(n2);
            loaderInfo.destroy();
        }
        if (this.mActivity != null && !this.hasRunningLoaders()) {
            this.mActivity.mFragments.startPendingDeferredFragments();
        }
    }

    void doDestroy() {
        int n2;
        if (!this.mRetaining) {
            if (DEBUG) {
                Log.v((String)"LoaderManager", (String)("Destroying Active in " + this));
            }
            for (n2 = this.mLoaders.size() - 1; n2 >= 0; --n2) {
                this.mLoaders.valueAt(n2).destroy();
            }
        }
        if (DEBUG) {
            Log.v((String)"LoaderManager", (String)("Destroying Inactive in " + this));
        }
        for (n2 = this.mInactiveLoaders.size() - 1; n2 >= 0; --n2) {
            this.mInactiveLoaders.valueAt(n2).destroy();
        }
        this.mInactiveLoaders.clear();
    }

    void doReportNextStart() {
        for (int i2 = this.mLoaders.size() - 1; i2 >= 0; --i2) {
            this.mLoaders.valueAt((int)i2).mReportNextStart = true;
        }
    }

    void doReportStart() {
        for (int i2 = this.mLoaders.size() - 1; i2 >= 0; --i2) {
            this.mLoaders.valueAt(i2).reportStart();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void doRetain() {
        if (DEBUG) {
            Log.v((String)"LoaderManager", (String)("Retaining in " + this));
        }
        if (!this.mStarted) {
            RuntimeException runtimeException = new RuntimeException("here");
            runtimeException.fillInStackTrace();
            Log.w((String)"LoaderManager", (String)("Called doRetain when not started: " + this), (Throwable)runtimeException);
            return;
        } else {
            this.mRetaining = true;
            this.mStarted = false;
            for (int i2 = this.mLoaders.size() - 1; i2 >= 0; --i2) {
                this.mLoaders.valueAt(i2).retain();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void doStart() {
        if (DEBUG) {
            Log.v((String)"LoaderManager", (String)("Starting in " + this));
        }
        if (this.mStarted) {
            RuntimeException runtimeException = new RuntimeException("here");
            runtimeException.fillInStackTrace();
            Log.w((String)"LoaderManager", (String)("Called doStart when already started: " + this), (Throwable)runtimeException);
            return;
        } else {
            this.mStarted = true;
            for (int i2 = this.mLoaders.size() - 1; i2 >= 0; --i2) {
                this.mLoaders.valueAt(i2).start();
            }
        }
    }

    void doStop() {
        if (DEBUG) {
            Log.v((String)"LoaderManager", (String)("Stopping in " + this));
        }
        if (!this.mStarted) {
            RuntimeException runtimeException = new RuntimeException("here");
            runtimeException.fillInStackTrace();
            Log.w((String)"LoaderManager", (String)("Called doStop when not started: " + this), (Throwable)runtimeException);
            return;
        }
        for (int i2 = this.mLoaders.size() - 1; i2 >= 0; --i2) {
            this.mLoaders.valueAt(i2).stop();
        }
        this.mStarted = false;
    }

    @Override
    public void dump(String string2, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        String string3;
        int n2;
        LoaderInfo loaderInfo;
        int n3 = 0;
        if (this.mLoaders.size() > 0) {
            printWriter.print(string2);
            printWriter.println("Active Loaders:");
            string3 = string2 + "    ";
            for (n2 = 0; n2 < this.mLoaders.size(); ++n2) {
                loaderInfo = this.mLoaders.valueAt(n2);
                printWriter.print(string2);
                printWriter.print("  #");
                printWriter.print(this.mLoaders.keyAt(n2));
                printWriter.print(": ");
                printWriter.println(loaderInfo.toString());
                loaderInfo.dump(string3, fileDescriptor, printWriter, arrstring);
            }
        }
        if (this.mInactiveLoaders.size() > 0) {
            printWriter.print(string2);
            printWriter.println("Inactive Loaders:");
            string3 = string2 + "    ";
            for (n2 = n3; n2 < this.mInactiveLoaders.size(); ++n2) {
                loaderInfo = this.mInactiveLoaders.valueAt(n2);
                printWriter.print(string2);
                printWriter.print("  #");
                printWriter.print(this.mInactiveLoaders.keyAt(n2));
                printWriter.print(": ");
                printWriter.println(loaderInfo.toString());
                loaderInfo.dump(string3, fileDescriptor, printWriter, arrstring);
            }
        }
    }

    void finishRetain() {
        if (this.mRetaining) {
            if (DEBUG) {
                Log.v((String)"LoaderManager", (String)("Finished Retaining in " + this));
            }
            this.mRetaining = false;
            for (int i2 = this.mLoaders.size() - 1; i2 >= 0; --i2) {
                this.mLoaders.valueAt(i2).finishRetain();
            }
        }
    }

    @Override
    public <D> a<D> getLoader(int n2) {
        if (this.mCreatingLoader) {
            throw new IllegalStateException("Called while creating a loader");
        }
        LoaderInfo loaderInfo = this.mLoaders.get(n2);
        if (loaderInfo != null) {
            if (loaderInfo.mPendingLoader != null) {
                return loaderInfo.mPendingLoader.mLoader;
            }
            return loaderInfo.mLoader;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean hasRunningLoaders() {
        int n2 = this.mLoaders.size();
        int n3 = 0;
        boolean bl = false;
        while (n3 < n2) {
            LoaderInfo loaderInfo = this.mLoaders.valueAt(n3);
            boolean bl2 = loaderInfo.mStarted && !loaderInfo.mDeliveredData;
            bl |= bl2;
            ++n3;
        }
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public <D> a<D> initLoader(int n2, Bundle object, LoaderManager.LoaderCallbacks<D> object2) {
        if (this.mCreatingLoader) {
            throw new IllegalStateException("Called while creating a loader");
        }
        LoaderInfo loaderInfo = this.mLoaders.get(n2);
        if (DEBUG) {
            Log.v((String)"LoaderManager", (String)("initLoader in " + this + ": args=" + object));
        }
        if (loaderInfo == null) {
            object = object2 = this.createAndInstallLoader(n2, (Bundle)object, (LoaderManager.LoaderCallbacks<Object>)object2);
            if (DEBUG) {
                Log.v((String)"LoaderManager", (String)("  Created new loader " + object2));
                object = object2;
            }
        } else {
            if (DEBUG) {
                Log.v((String)"LoaderManager", (String)("  Re-using existing loader " + loaderInfo));
            }
            loaderInfo.mCallbacks = object2;
            object = loaderInfo;
        }
        if (object.mHaveData && this.mStarted) {
            object.callOnLoadFinished(object.mLoader, object.mData);
        }
        return object.mLoader;
    }

    void installLoader(LoaderInfo loaderInfo) {
        this.mLoaders.put(loaderInfo.mId, loaderInfo);
        if (this.mStarted) {
            loaderInfo.start();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public <D> a<D> restartLoader(int var1_1, Bundle var2_2, LoaderManager.LoaderCallbacks<D> var3_3) {
        if (this.mCreatingLoader) {
            throw new IllegalStateException("Called while creating a loader");
        }
        var4_4 = this.mLoaders.get(var1_1);
        if (LoaderManagerImpl.DEBUG) {
            Log.v((String)"LoaderManager", (String)("restartLoader in " + this + ": args=" + (Object)var2_2));
        }
        if (var4_4 == null) return this.createAndInstallLoader((int)var1_1, (Bundle)var2_2, var3_3).mLoader;
        var5_5 = this.mInactiveLoaders.get(var1_1);
        if (var5_5 == null) ** GOTO lbl30
        if (var4_4.mHaveData) {
            if (LoaderManagerImpl.DEBUG) {
                Log.v((String)"LoaderManager", (String)("  Removing last inactive loader: " + var4_4));
            }
            var5_5.mDeliveredData = false;
            var5_5.destroy();
        } else {
            if (!var4_4.mStarted) {
                if (LoaderManagerImpl.DEBUG) {
                    Log.v((String)"LoaderManager", (String)"  Current loader is stopped; replacing");
                }
                this.mLoaders.put(var1_1, null);
                var4_4.destroy();
                return this.createAndInstallLoader((int)var1_1, (Bundle)var2_2, var3_3).mLoader;
            }
            if (var4_4.mPendingLoader != null) {
                if (LoaderManagerImpl.DEBUG) {
                    Log.v((String)"LoaderManager", (String)("  Removing pending loader: " + var4_4.mPendingLoader));
                }
                var4_4.mPendingLoader.destroy();
                var4_4.mPendingLoader = null;
            }
            if (LoaderManagerImpl.DEBUG) {
                Log.v((String)"LoaderManager", (String)"  Enqueuing as new pending loader");
            }
            var4_4.mPendingLoader = this.createLoader(var1_1, var2_2, var3_3);
            return var4_4.mPendingLoader.mLoader;
lbl30: // 1 sources:
            if (LoaderManagerImpl.DEBUG) {
                Log.v((String)"LoaderManager", (String)("  Making last loader inactive: " + var4_4));
            }
        }
        var4_4.mLoader.c();
        this.mInactiveLoaders.put(var1_1, var4_4);
        return this.createAndInstallLoader((int)var1_1, (Bundle)var2_2, var3_3).mLoader;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("LoaderManager{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append(" in ");
        android.support.v4.b.a.a((Object)this.mActivity, stringBuilder);
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }

    void updateActivity(FragmentActivity fragmentActivity) {
        this.mActivity = fragmentActivity;
    }

    final class LoaderInfo
    implements a.a<Object> {
        final Bundle mArgs;
        LoaderManager.LoaderCallbacks<Object> mCallbacks;
        Object mData;
        boolean mDeliveredData;
        boolean mDestroyed;
        boolean mHaveData;
        final int mId;
        boolean mListenerRegistered;
        a<Object> mLoader;
        LoaderInfo mPendingLoader;
        boolean mReportNextStart;
        boolean mRetaining;
        boolean mRetainingStarted;
        boolean mStarted;

        public LoaderInfo(int n2, Bundle bundle, LoaderManager.LoaderCallbacks<Object> loaderCallbacks) {
            this.mId = n2;
            this.mArgs = bundle;
            this.mCallbacks = loaderCallbacks;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        final void callOnLoadFinished(a<Object> a2, Object object) {
            String string2;
            if (this.mCallbacks != null) {
                if (LoaderManagerImpl.this.mActivity != null) {
                    string2 = LoaderManagerImpl.this.mActivity.mFragments.mNoTransactionsBecause;
                    LoaderManagerImpl.this.mActivity.mFragments.mNoTransactionsBecause = "onLoadFinished";
                } else {
                    string2 = null;
                }
                if (LoaderManagerImpl.DEBUG) {
                    StringBuilder stringBuilder = new StringBuilder("  onLoadFinished in ").append(a2).append(": ");
                    StringBuilder stringBuilder2 = new StringBuilder(64);
                    android.support.v4.b.a.a(object, stringBuilder2);
                    stringBuilder2.append("}");
                    Log.v((String)"LoaderManager", (String)stringBuilder.append(stringBuilder2.toString()).toString());
                }
                this.mCallbacks.onLoadFinished(a2, object);
                this.mDeliveredData = true;
            }
            return;
            finally {
                if (LoaderManagerImpl.this.mActivity != null) {
                    LoaderManagerImpl.this.mActivity.mFragments.mNoTransactionsBecause = string2;
                }
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        final void destroy() {
            String string2;
            LoaderInfo loaderInfo = this;
            do {
                if (LoaderManagerImpl.DEBUG) {
                    Log.v((String)"LoaderManager", (String)("  Destroying: " + loaderInfo));
                }
                loaderInfo.mDestroyed = true;
                boolean bl = loaderInfo.mDeliveredData;
                loaderInfo.mDeliveredData = false;
                if (loaderInfo.mCallbacks != null && loaderInfo.mLoader != null && loaderInfo.mHaveData && bl) {
                    if (LoaderManagerImpl.DEBUG) {
                        Log.v((String)"LoaderManager", (String)("  Reseting: " + loaderInfo));
                    }
                    if (loaderInfo.LoaderManagerImpl.this.mActivity != null) {
                        string2 = loaderInfo.LoaderManagerImpl.this.mActivity.mFragments.mNoTransactionsBecause;
                        loaderInfo.LoaderManagerImpl.this.mActivity.mFragments.mNoTransactionsBecause = "onLoaderReset";
                    } else {
                        string2 = null;
                    }
                    loaderInfo.mCallbacks.onLoaderReset(loaderInfo.mLoader);
                }
                loaderInfo.mCallbacks = null;
                loaderInfo.mData = null;
                loaderInfo.mHaveData = false;
                if (loaderInfo.mLoader != null) {
                    if (loaderInfo.mListenerRegistered) {
                        loaderInfo.mListenerRegistered = false;
                        loaderInfo.mLoader.a(loaderInfo);
                    }
                    loaderInfo.mLoader.d();
                }
                if (loaderInfo.mPendingLoader == null) {
                    return;
                }
                loaderInfo = loaderInfo.mPendingLoader;
            } while (true);
            finally {
                if (loaderInfo.LoaderManagerImpl.this.mActivity != null) {
                    loaderInfo.LoaderManagerImpl.this.mActivity.mFragments.mNoTransactionsBecause = string2;
                }
            }
        }

        public final void dump(String object, FileDescriptor object2, PrintWriter printWriter, String[] arrstring) {
            object2 = object;
            object = this;
            do {
                printWriter.print((String)object2);
                printWriter.print("mId=");
                printWriter.print(object.mId);
                printWriter.print(" mArgs=");
                printWriter.println((Object)object.mArgs);
                printWriter.print((String)object2);
                printWriter.print("mCallbacks=");
                printWriter.println(object.mCallbacks);
                printWriter.print((String)object2);
                printWriter.print("mLoader=");
                printWriter.println(object.mLoader);
                if (object.mLoader != null) {
                    object.mLoader.a((String)object2 + "  ", printWriter);
                }
                if (object.mHaveData || object.mDeliveredData) {
                    printWriter.print((String)object2);
                    printWriter.print("mHaveData=");
                    printWriter.print(object.mHaveData);
                    printWriter.print("  mDeliveredData=");
                    printWriter.println(object.mDeliveredData);
                    printWriter.print((String)object2);
                    printWriter.print("mData=");
                    printWriter.println(object.mData);
                }
                printWriter.print((String)object2);
                printWriter.print("mStarted=");
                printWriter.print(object.mStarted);
                printWriter.print(" mReportNextStart=");
                printWriter.print(object.mReportNextStart);
                printWriter.print(" mDestroyed=");
                printWriter.println(object.mDestroyed);
                printWriter.print((String)object2);
                printWriter.print("mRetaining=");
                printWriter.print(object.mRetaining);
                printWriter.print(" mRetainingStarted=");
                printWriter.print(object.mRetainingStarted);
                printWriter.print(" mListenerRegistered=");
                printWriter.println(object.mListenerRegistered);
                if (object.mPendingLoader == null) break;
                printWriter.print((String)object2);
                printWriter.println("Pending Loader ");
                printWriter.print(object.mPendingLoader);
                printWriter.println(":");
                object = object.mPendingLoader;
                object2 = (String)object2 + "  ";
            } while (true);
        }

        final void finishRetain() {
            if (this.mRetaining) {
                if (LoaderManagerImpl.DEBUG) {
                    Log.v((String)"LoaderManager", (String)("  Finished Retaining: " + this));
                }
                this.mRetaining = false;
                if (this.mStarted != this.mRetainingStarted && !this.mStarted) {
                    this.stop();
                }
            }
            if (this.mStarted && this.mHaveData && !this.mReportNextStart) {
                this.callOnLoadFinished(this.mLoader, this.mData);
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public final void onLoadComplete(a<Object> object, Object object2) {
            if (LoaderManagerImpl.DEBUG) {
                Log.v((String)"LoaderManager", (String)("onLoadComplete: " + this));
            }
            if (this.mDestroyed) {
                if (!LoaderManagerImpl.DEBUG) return;
                {
                    Log.v((String)"LoaderManager", (String)"  Ignoring load complete -- destroyed");
                    return;
                }
            } else if (LoaderManagerImpl.this.mLoaders.get(this.mId) != this) {
                if (!LoaderManagerImpl.DEBUG) return;
                {
                    Log.v((String)"LoaderManager", (String)"  Ignoring load complete -- not active");
                    return;
                }
            } else {
                LoaderInfo loaderInfo = this.mPendingLoader;
                if (loaderInfo != null) {
                    if (LoaderManagerImpl.DEBUG) {
                        Log.v((String)"LoaderManager", (String)("  Switching to pending loader: " + loaderInfo));
                    }
                    this.mPendingLoader = null;
                    LoaderManagerImpl.this.mLoaders.put(this.mId, null);
                    this.destroy();
                    LoaderManagerImpl.this.installLoader(loaderInfo);
                    return;
                }
                if (this.mData != object2 || !this.mHaveData) {
                    this.mData = object2;
                    this.mHaveData = true;
                    if (this.mStarted) {
                        this.callOnLoadFinished((a<Object>)object, object2);
                    }
                }
                if ((object = LoaderManagerImpl.this.mInactiveLoaders.get(this.mId)) != null && object != this) {
                    object.mDeliveredData = false;
                    object.destroy();
                    LoaderManagerImpl.this.mInactiveLoaders.remove(this.mId);
                }
                if (LoaderManagerImpl.this.mActivity == null || LoaderManagerImpl.this.hasRunningLoaders()) return;
                {
                    LoaderManagerImpl.this.mActivity.mFragments.startPendingDeferredFragments();
                    return;
                }
            }
        }

        final void reportStart() {
            if (this.mStarted && this.mReportNextStart) {
                this.mReportNextStart = false;
                if (this.mHaveData) {
                    this.callOnLoadFinished(this.mLoader, this.mData);
                }
            }
        }

        final void retain() {
            if (LoaderManagerImpl.DEBUG) {
                Log.v((String)"LoaderManager", (String)("  Retaining: " + this));
            }
            this.mRetaining = true;
            this.mRetainingStarted = this.mStarted;
            this.mStarted = false;
            this.mCallbacks = null;
        }

        /*
         * Enabled aggressive block sorting
         */
        final void start() {
            if (this.mRetaining && this.mRetainingStarted) {
                this.mStarted = true;
                return;
            }
            if (this.mStarted) return;
            this.mStarted = true;
            if (LoaderManagerImpl.DEBUG) {
                Log.v((String)"LoaderManager", (String)("  Starting: " + this));
            }
            if (this.mLoader == null && this.mCallbacks != null) {
                this.mLoader = this.mCallbacks.onCreateLoader(this.mId, this.mArgs);
            }
            if (this.mLoader == null) return;
            {
                if (this.mLoader.getClass().isMemberClass() && !Modifier.isStatic(this.mLoader.getClass().getModifiers())) {
                    throw new IllegalArgumentException("Object returned from onCreateLoader must not be a non-static inner member class: " + this.mLoader);
                }
            }
            if (!this.mListenerRegistered) {
                this.mLoader.a(this.mId, this);
                this.mListenerRegistered = true;
            }
            this.mLoader.a();
        }

        final void stop() {
            if (LoaderManagerImpl.DEBUG) {
                Log.v((String)"LoaderManager", (String)("  Stopping: " + this));
            }
            this.mStarted = false;
            if (!this.mRetaining && this.mLoader != null && this.mListenerRegistered) {
                this.mListenerRegistered = false;
                this.mLoader.a(this);
                this.mLoader.b();
            }
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder(64);
            stringBuilder.append("LoaderInfo{");
            stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
            stringBuilder.append(" #");
            stringBuilder.append(this.mId);
            stringBuilder.append(" : ");
            android.support.v4.b.a.a(this.mLoader, stringBuilder);
            stringBuilder.append("}}");
            return stringBuilder.toString();
        }
    }

}

