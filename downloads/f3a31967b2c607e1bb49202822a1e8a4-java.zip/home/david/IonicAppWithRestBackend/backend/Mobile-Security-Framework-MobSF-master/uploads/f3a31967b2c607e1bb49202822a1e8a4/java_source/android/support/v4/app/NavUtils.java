/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 */
package android.support.v4.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;

public class NavUtils {
    public static final String PARENT_ACTIVITY = "android.support.PARENT_ACTIVITY";
    private static final String TAG = "NavUtils";

    private NavUtils() {
    }

    public static Intent getParentActivityIntent(Activity activity) {
        String string2 = NavUtils.getParentActivityName(activity);
        if (string2 == null) {
            return null;
        }
        return new Intent("android.intent.action.MAIN").setClassName((Context)activity, string2);
    }

    public static Intent getParentActivityIntent(Context context, ComponentName object) throws PackageManager.NameNotFoundException {
        String string2 = NavUtils.getParentActivityName(context, (ComponentName)object);
        if (string2 == null) {
            return null;
        }
        object = string2;
        if (string2.charAt(0) == '.') {
            object = context.getPackageName() + string2;
        }
        return new Intent("android.intent.action.MAIN").setClassName(context, (String)object);
    }

    public static Intent getParentActivityIntent(Context context, Class<?> object) throws PackageManager.NameNotFoundException {
        if ((object = NavUtils.getParentActivityName(context, new ComponentName(context, object))) == null) {
            return null;
        }
        return new Intent("android.intent.action.MAIN").setClassName(context, (String)object);
    }

    public static String getParentActivityName(Activity object) {
        try {
            object = NavUtils.getParentActivityName((Context)object, object.getComponentName());
            return object;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            throw new IllegalArgumentException((Throwable)var0_1);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String getParentActivityName(Context context, ComponentName object) throws PackageManager.NameNotFoundException {
        object = context.getPackageManager().getActivityInfo((ComponentName)object, 128);
        if (object.metaData == null) {
            return null;
        }
        String string2 = object.metaData.getString("android.support.PARENT_ACTIVITY");
        if (string2 == null) {
            return null;
        }
        object = string2;
        if (string2.charAt(0) != '.') return object;
        return context.getPackageName() + string2;
    }

    public static void navigateUpFromSameTask(Activity activity) {
        Intent intent = NavUtils.getParentActivityIntent(activity);
        if (intent == null) {
            throw new IllegalArgumentException("Activity " + activity.getClass().getSimpleName() + " does not have a parent activity name specified. (Did you forget to add the android.support.PARENT_ACTIVITY <meta-data>  element in your manifest?)");
        }
        NavUtils.navigateUpTo(activity, intent);
    }

    public static void navigateUpTo(Activity activity, Intent intent) {
        intent.addFlags(67108864);
        activity.startActivity(intent);
        activity.finish();
    }

    public static boolean shouldUpRecreateTask(Activity object, Intent intent) {
        if ((object = object.getIntent().getAction()) != null && !object.equals("android.intent.action.MAIN")) {
            return true;
        }
        return false;
    }
}

