/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 */
package android.support.v4.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NavUtils;
import android.support.v4.app.TaskStackBuilderHoneycomb;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

public class TaskStackBuilder
implements Iterable<Intent> {
    private static final TaskStackBuilderImpl IMPL = Build.VERSION.SDK_INT >= 11 ? new TaskStackBuilderImplHoneycomb() : new TaskStackBuilderImplBase();
    private static final String TAG = "TaskStackBuilder";
    private final ArrayList<Intent> mIntents = new ArrayList();
    private final Context mSourceContext;

    private TaskStackBuilder(Context context) {
        this.mSourceContext = context;
    }

    public static TaskStackBuilder from(Context context) {
        return new TaskStackBuilder(context);
    }

    public TaskStackBuilder addNextIntent(Intent intent) {
        this.mIntents.add(intent);
        return this;
    }

    public TaskStackBuilder addParentStack(Activity activity) {
        int n2 = this.mIntents.size();
        Intent intent = NavUtils.getParentActivityIntent(activity);
        while (intent != null) {
            this.mIntents.add(n2, intent);
            try {
                intent = NavUtils.getParentActivityIntent((Context)activity, intent.getComponent());
                continue;
            }
            catch (PackageManager.NameNotFoundException var1_2) {
                Log.e((String)"TaskStackBuilder", (String)"Bad ComponentName while traversing activity parent metadata");
                throw new IllegalArgumentException((Throwable)var1_2);
            }
        }
        return this;
    }

    public TaskStackBuilder addParentStack(Class<?> intent) {
        int n2 = this.mIntents.size();
        intent = NavUtils.getParentActivityIntent(this.mSourceContext, intent);
        while (intent != null) {
            try {
                this.mIntents.add(n2, intent);
                intent = NavUtils.getParentActivityIntent(this.mSourceContext, intent.getComponent());
                continue;
            }
            catch (PackageManager.NameNotFoundException var1_2) {
                Log.e((String)"TaskStackBuilder", (String)"Bad ComponentName while traversing activity parent metadata");
                throw new IllegalArgumentException((Throwable)var1_2);
            }
        }
        return this;
    }

    public Intent getIntent(int n2) {
        return this.mIntents.get(n2);
    }

    public int getIntentCount() {
        return this.mIntents.size();
    }

    public PendingIntent getPendingIntent(int n2, int n3) {
        Intent[] arrintent = this.mIntents.toArray((T[])new Intent[this.mIntents.size()]);
        return IMPL.getPendingIntent(this.mSourceContext, arrintent, n2, n3);
    }

    @Override
    public Iterator<Intent> iterator() {
        return this.mIntents.iterator();
    }

    public void startActivities() {
        if (this.mIntents.isEmpty()) {
            throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
        }
        Intent intent = this.mIntents.toArray((T[])new Intent[this.mIntents.size()]);
        intent[0].addFlags(268484608);
        if (!ActivityCompat.startActivities((Activity)this.mSourceContext, (Intent[])intent)) {
            intent = intent[intent.length - 1];
            intent.addFlags(268435456);
            this.mSourceContext.startActivity(intent);
        }
    }

    static interface TaskStackBuilderImpl {
        public PendingIntent getPendingIntent(Context var1, Intent[] var2, int var3, int var4);
    }

    static class TaskStackBuilderImplBase
    implements TaskStackBuilderImpl {
        TaskStackBuilderImplBase() {
        }

        @Override
        public PendingIntent getPendingIntent(Context context, Intent[] intent, int n2, int n3) {
            intent = intent[intent.length - 1];
            intent.addFlags(268435456);
            return PendingIntent.getActivity((Context)context, (int)n2, (Intent)intent, (int)n3);
        }
    }

    static class TaskStackBuilderImplHoneycomb
    implements TaskStackBuilderImpl {
        TaskStackBuilderImplHoneycomb() {
        }

        @Override
        public PendingIntent getPendingIntent(Context context, Intent[] arrintent, int n2, int n3) {
            arrintent[0].addFlags(268468224);
            return TaskStackBuilderHoneycomb.getActivitiesPendingIntent(context, n2, arrintent, n3);
        }
    }

}

