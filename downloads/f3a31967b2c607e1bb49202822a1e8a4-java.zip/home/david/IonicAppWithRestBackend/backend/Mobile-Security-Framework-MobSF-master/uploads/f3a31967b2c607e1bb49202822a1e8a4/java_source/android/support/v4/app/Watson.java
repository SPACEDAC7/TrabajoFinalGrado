/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package android.support.v4.app;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManagerImpl;
import android.view.View;
import com.actionbarsherlock.ActionBarSherlock;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import java.util.ArrayList;

public abstract class Watson
extends FragmentActivity
implements ActionBarSherlock.OnCreatePanelMenuListener,
ActionBarSherlock.OnMenuItemSelectedListener,
ActionBarSherlock.OnPreparePanelListener {
    private static final String TAG = "Watson";
    private ArrayList<Fragment> mCreatedMenus;

    public abstract MenuInflater getSupportMenuInflater();

    public abstract boolean onCreateOptionsMenu(Menu var1);

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean onCreatePanelMenu(int var1_1, Menu var2_2) {
        var5_3 = 0;
        var4_4 = 0;
        if (var1_1 != 0) return (boolean)var5_3;
        var5_3 = this.onCreateOptionsMenu((Menu)var2_2);
        var8_5 = this.getSupportMenuInflater();
        var7_6 = null;
        var6_7 = null;
        if (this.mFragments.mAdded != null) ** GOTO lbl12
        var1_1 = 0;
        var6_7 = var7_6;
        ** GOTO lbl16
lbl12: // 1 sources:
        var3_8 = 0;
        var1_1 = 0;
        do {
            if (var3_8 < this.mFragments.mAdded.size()) ** GOTO lbl19
lbl16: // 2 sources:
            if (this.mCreatedMenus != null) {
                break;
            }
            ** GOTO lbl-1000
lbl19: // 1 sources:
            var7_6 = this.mFragments.mAdded.get(var3_8);
            if (var7_6 != null && !var7_6.mHidden && var7_6.mHasMenu && var7_6.mMenuVisible && var7_6 instanceof OnCreateOptionsMenuListener) {
                ((OnCreateOptionsMenuListener)var7_6).onCreateOptionsMenu((Menu)var2_2, var8_5);
                if (var6_7 == null) {
                    var6_7 = new ArrayList<E>();
                }
                var6_7.add(var7_6);
                var1_1 = 1;
            }
            ++var3_8;
        } while (true);
        var3_8 = var4_4;
        do {
            if (var3_8 >= this.mCreatedMenus.size()) lbl-1000: // 2 sources:
            {
                this.mCreatedMenus = var6_7;
                var5_3 |= var1_1;
                return (boolean)var5_3;
            }
            var2_2 = this.mCreatedMenus.get(var3_8);
            if (var6_7 == null || !var6_7.contains(var2_2)) {
                var2_2.onDestroyOptionsMenu();
            }
            ++var3_8;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean onMenuItemSelected(int n2, MenuItem menuItem) {
        boolean bl;
        boolean bl2 = bl = false;
        if (n2 != 0) return bl2;
        if (this.onOptionsItemSelected(menuItem)) {
            return true;
        }
        bl2 = bl;
        if (this.mFragments.mAdded == null) return bl2;
        n2 = 0;
        do {
            bl2 = bl;
            if (n2 >= this.mFragments.mAdded.size()) return bl2;
            Fragment fragment = this.mFragments.mAdded.get(n2);
            if (fragment != null && !fragment.mHidden && fragment.mHasMenu && fragment.mMenuVisible && fragment instanceof OnOptionsItemSelectedListener && ((OnOptionsItemSelectedListener)((Object)fragment)).onOptionsItemSelected(menuItem)) {
                return true;
            }
            ++n2;
        } while (true);
    }

    public abstract boolean onOptionsItemSelected(MenuItem var1);

    public abstract boolean onPrepareOptionsMenu(Menu var1);

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean onPreparePanel(int n2, View object, Menu menu) {
        int n3 = 0;
        if (n2 != 0) return (boolean)n3;
        n3 = this.onPrepareOptionsMenu(menu);
        if (this.mFragments.mAdded != null) {
            int n4 = 0;
            n2 = 0;
            do {
                if (n4 >= this.mFragments.mAdded.size()) {
                    do {
                        return (boolean)((n3 | n2) & menu.hasVisibleItems());
                        break;
                    } while (true);
                }
                object = this.mFragments.mAdded.get(n4);
                int n5 = n2;
                if (object != null) {
                    n5 = n2;
                    if (!object.mHidden) {
                        n5 = n2;
                        if (object.mHasMenu) {
                            n5 = n2;
                            if (object.mMenuVisible) {
                                n5 = n2;
                                if (object instanceof OnPrepareOptionsMenuListener) {
                                    n5 = 1;
                                    ((OnPrepareOptionsMenuListener)object).onPrepareOptionsMenu(menu);
                                }
                            }
                        }
                    }
                }
                ++n4;
                n2 = n5;
            } while (true);
        }
        n2 = 0;
        return (boolean)((n3 | n2) & menu.hasVisibleItems());
    }

    public static interface OnCreateOptionsMenuListener {
        public void onCreateOptionsMenu(Menu var1, MenuInflater var2);
    }

    public static interface OnOptionsItemSelectedListener {
        public boolean onOptionsItemSelected(MenuItem var1);
    }

    public static interface OnPrepareOptionsMenuListener {
        public void onPrepareOptionsMenu(Menu var1);
    }

}

