/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package android.support.v4.b;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.b.b;
import android.support.v4.b.c;

public final class a {
    public static <T> Parcelable.Creator<T> a(b<T> b2) {
        if (Build.VERSION.SDK_INT >= 13) {
            new c<T>(b2);
        }
        return new a<T>(b2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static void a(Object var0, StringBuilder var1_1) {
        if (var0 == null) {
            var1_1.append("null");
            return;
        }
        var4_2 = var0.getClass().getSimpleName();
        if (var4_2 == null) ** GOTO lbl-1000
        var3_3 = var4_2;
        if (var4_2.length() <= 0) lbl-1000: // 2 sources:
        {
            var4_2 = var0.getClass().getName();
            var2_4 = var4_2.lastIndexOf(46);
            var3_3 = var4_2;
            if (var2_4 > 0) {
                var3_3 = var4_2.substring(var2_4 + 1);
            }
        }
        var1_1.append(var3_3);
        var1_1.append('{');
        var1_1.append(Integer.toHexString(System.identityHashCode(var0)));
    }

    static final class a<T>
    implements Parcelable.Creator<T> {
        private b<T> a;

        public a(b<T> b2) {
            this.a = b2;
        }

        public final T createFromParcel(Parcel parcel) {
            return this.a.a(parcel, null);
        }

        public final T[] newArray(int n2) {
            return this.a.a(n2);
        }
    }

}

