/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 */
package android.support.v4.b;

import android.os.Parcel;

public interface b<T> {
    public T a(Parcel var1, ClassLoader var2);

    public T[] a(int var1);
}

