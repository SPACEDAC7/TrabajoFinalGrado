/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.database.Cursor
 *  android.widget.Filter
 *  android.widget.Filter$FilterResults
 */
package android.support.v4.d;

import android.database.Cursor;
import android.widget.Filter;

final class b
extends Filter {
    private a a;

    b(a a2) {
        this.a = a2;
    }

    public final CharSequence convertResultToString(Object object) {
        return this.a.convertToString((Cursor)object);
    }

    protected final Filter.FilterResults performFiltering(CharSequence charSequence) {
        charSequence = this.a.runQueryOnBackgroundThread(charSequence);
        Filter.FilterResults filterResults = new Filter.FilterResults();
        if (charSequence != null) {
            filterResults.count = charSequence.getCount();
            filterResults.values = charSequence;
            return filterResults;
        }
        filterResults.count = 0;
        filterResults.values = null;
        return filterResults;
    }

    protected final void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
        charSequence = this.a.getCursor();
        if (filterResults.values != null && filterResults.values != charSequence) {
            this.a.changeCursor((Cursor)filterResults.values);
        }
    }

    static interface a {
        public void changeCursor(Cursor var1);

        public CharSequence convertToString(Cursor var1);

        public Cursor getCursor();

        public Cursor runQueryOnBackgroundThread(CharSequence var1);
    }

}

