/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package android.support.v4.d;

import android.graphics.Canvas;
import android.os.Build;
import android.support.v4.d.a;

public final class c {
    private static final b a = Build.VERSION.SDK_INT >= 14 ? new a() : new b(){

        @Override
        public final void a(int n2, int n3) {
        }

        @Override
        public final boolean a() {
            return true;
        }

        @Override
        public final boolean a(Canvas canvas) {
            return false;
        }

        @Override
        public final void b() {
        }
    };

    public static void a(int n2, int n3) {
        a.a(n2, n3);
    }

    public static boolean a() {
        return a.a();
    }

    public static boolean a(Canvas canvas) {
        return a.a(canvas);
    }

    public static void b() {
        a.b();
    }

    static final class a
    implements b {
        a() {
        }

        @Override
        public final void a(int n2, int n3) {
            throw new NullPointerException();
        }

        @Override
        public final boolean a() {
            throw new NullPointerException();
        }

        @Override
        public final boolean a(Canvas canvas) {
            throw new NullPointerException();
        }

        @Override
        public final void b() {
            throw new NullPointerException();
        }
    }

    static interface b {
        public void a(int var1, int var2);

        public boolean a();

        public boolean a(Canvas var1);

        public void b();
    }

}

