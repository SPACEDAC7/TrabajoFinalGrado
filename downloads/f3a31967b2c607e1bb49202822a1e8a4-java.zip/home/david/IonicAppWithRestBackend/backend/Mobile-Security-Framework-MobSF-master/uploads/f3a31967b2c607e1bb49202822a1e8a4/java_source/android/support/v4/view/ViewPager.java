/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.FocusFinder
 *  android.view.KeyEvent
 *  android.view.MotionEvent
 *  android.view.SoundEffectConstants
 *  android.view.VelocityTracker
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.accessibility.AccessibilityEvent
 *  android.view.animation.Interpolator
 */
package android.support.v4.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.c;
import android.support.v4.view.e;
import android.util.AttributeSet;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.Comparator;

public final class ViewPager
extends ViewGroup {
    private static final int[] a = new int[]{16842931};
    private final ArrayList<b> b;
    private int c;
    private int d;
    private boolean e;
    private boolean f;
    private boolean g;
    private boolean h;
    private float i;
    private float j;
    private int k;
    private VelocityTracker l;
    private boolean m;
    private int n;
    private int o;

    static {
        new Comparator<b>(){};
        new Interpolator(){

            public final float getInterpolation(float f2) {
                return f2 * (f2 * f2 * f2 * (f2 -= 1.0f)) + 1.0f;
            }
        };
    }

    private b a(View object) {
        if (this.b.size() < 0) {
            object = this.b.get(0);
            throw new NullPointerException();
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean a(int n2) {
        boolean bl;
        View view;
        View view2 = view = this.findFocus();
        if (view == this) {
            view2 = null;
        }
        if ((view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view2, n2)) != null && view != view2) {
            if (n2 == 17) {
                if (view2 != null) {
                    if (view.getLeft() >= view2.getLeft()) return false;
                }
                bl = view.requestFocus();
            } else {
                if (n2 != 66) return false;
                if (view2 != null) {
                    if (view.getLeft() <= view2.getLeft()) return false;
                }
                bl = view.requestFocus();
            }
        } else {
            if (n2 == 17) return false;
            if (n2 == 1) return false;
            if (n2 == 66) return false;
            if (n2 != 2) return false;
            return false;
        }
        if (!bl) return bl;
        this.playSoundEffect(SoundEffectConstants.getContantForFocusDirection((int)n2));
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean a(View view, boolean bl, int n2, int n3, int n4) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup)view;
            int n5 = view.getScrollX();
            int n6 = view.getScrollY();
            for (int i2 = viewGroup.getChildCount() - 1; i2 >= 0; --i2) {
                View view2 = viewGroup.getChildAt(i2);
                if (n3 + n5 >= view2.getLeft() && n3 + n5 < view2.getRight() && n4 + n6 >= view2.getTop() && n4 + n6 < view2.getBottom() && this.a(view2, true, n2, n3 + n5 - view2.getLeft(), n4 + n6 - view2.getTop())) return true;
                {
                    continue;
                }
            }
        }
        if (!bl || !e.a(view, - n2)) return false;
        return true;
    }

    private void b() {
        if (this.o == 1) {
            return;
        }
        this.o = 1;
    }

    private void c() {
        for (int i2 = 0; i2 < this.b.size(); ++i2) {
            this.b.get(i2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void addFocusables(ArrayList<View> arrayList, int n2, int n3) {
        int n4 = arrayList.size();
        int n5 = this.getDescendantFocusability();
        if (n5 != 393216) {
            for (int i2 = 0; i2 < this.getChildCount(); ++i2) {
                View view = this.getChildAt(i2);
                if (view.getVisibility() != 0 || this.a(view) == null) continue;
                view.addFocusables(arrayList, n2, n3);
            }
        }
        if (n5 == 262144 && n4 != arrayList.size() || !this.isFocusable() || (n3 & 1) == 1 && this.isInTouchMode() && !this.isFocusableInTouchMode() || arrayList == null) {
            return;
        }
        arrayList.add((View)this);
    }

    public final void addTouchables(ArrayList<View> arrayList) {
        for (int i2 = 0; i2 < this.getChildCount(); ++i2) {
            View view = this.getChildAt(i2);
            if (view.getVisibility() != 0 || this.a(view) == null) continue;
            view.addTouchables(arrayList);
        }
    }

    public final void addView(View view, int n2, ViewGroup.LayoutParams layoutParams) {
        if (!this.checkLayoutParams(layoutParams)) {
            layoutParams = this.generateLayoutParams(layoutParams);
        }
        LayoutParams layoutParams2 = (LayoutParams)layoutParams;
        layoutParams2.a |= view instanceof a;
        if (this.e) {
            if (layoutParams2 != null && layoutParams2.a) {
                throw new IllegalStateException("Cannot add pager decor view during layout");
            }
            this.addViewInLayout(view, n2, layoutParams);
            view.measure(this.c, this.d);
            return;
        }
        super.addView(view, n2, layoutParams);
    }

    protected final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof LayoutParams && super.checkLayoutParams(layoutParams)) {
            return true;
        }
        return false;
    }

    public final void computeScroll() {
        throw new NullPointerException();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        boolean bl;
        boolean bl2 = false;
        if (super.dispatchKeyEvent(keyEvent)) return true;
        if (keyEvent.getAction() != 0) return bl2;
        switch (keyEvent.getKeyCode()) {
            default: {
                return bl2;
            }
            case 21: {
                bl = this.a(17);
                break;
            }
            case 22: {
                bl = this.a(66);
                break;
            }
            case 61: {
                if (Build.VERSION.SDK_INT < 11) return bl2;
                if (android.support.v4.view.a.b(keyEvent)) {
                    bl = this.a(2);
                } else {
                    if (!android.support.v4.view.a.a(keyEvent)) return bl2;
                    bl = this.a(1);
                }
            }
        }
        if (!bl) return bl2;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        boolean bl = false;
        int n2 = this.getChildCount();
        int n3 = 0;
        do {
            boolean bl2 = bl;
            if (n3 >= n2) return bl2;
            View view = this.getChildAt(n3);
            if (view.getVisibility() == 0 && this.a(view) != null && view.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                return true;
            }
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void draw(Canvas canvas) {
        super.draw(canvas);
        int n2 = 0;
        int n3 = 0;
        int n4 = e.a((View)this);
        if (n4 != 0) {
            if (n4 == 1) {
                // empty if block
            }
            android.support.v4.d.c.b();
            android.support.v4.d.c.b();
        } else {
            if (!android.support.v4.d.c.a()) {
                n3 = canvas.save();
                n2 = this.getHeight() - this.getPaddingTop() - this.getPaddingBottom();
                canvas.rotate(270.0f);
                canvas.translate((float)(- n2 + this.getPaddingTop()), 0.0f);
                android.support.v4.d.c.a(n2, this.getWidth());
                n2 = android.support.v4.d.c.a(canvas) | false;
                canvas.restoreToCount(n3);
            }
            n3 = n2;
            if (!android.support.v4.d.c.a()) {
                n4 = canvas.save();
                n3 = this.getWidth();
                int n5 = this.getHeight();
                int n6 = this.getPaddingTop();
                int n7 = this.getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float)(- this.getPaddingTop()), (float)(n3 * -1));
                android.support.v4.d.c.a(n5 - n6 - n7, n3);
                n3 = n2 | android.support.v4.d.c.a(canvas);
                canvas.restoreToCount(n4);
            }
        }
        if (n3 != 0) {
            this.invalidate();
        }
    }

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
    }

    protected final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams();
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(this.getContext(), attributeSet);
    }

    protected final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return this.generateDefaultLayoutParams();
    }

    protected final void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    protected final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final boolean onInterceptTouchEvent(MotionEvent var1_1) {
        var7_2 = 0;
        var8_3 = var1_1.getAction() & 255;
        if (var8_3 == 3 || var8_3 == 1) {
            this.g = false;
            this.h = false;
            this.k = -1;
            if (this.l == null) return false;
            this.l.recycle();
            this.l = null;
            return false;
        }
        if (var8_3 != 0) {
            if (this.g) {
                return true;
            }
            if (this.h != false) return false;
        }
        switch (var8_3) {
            case 2: {
                var7_2 = this.k;
                if (var7_2 != -1) {
                    var7_2 = c.a(var1_1, var7_2);
                    var2_4 = c.c(var1_1, var7_2);
                    var3_5 = var2_4 - this.i;
                    var4_6 = Math.abs(var3_5);
                    var5_7 = c.d(var1_1, var7_2);
                    var6_8 = Math.abs(var5_7 - this.j);
                    if (this.a((View)this, false, (int)var3_5, (int)var2_4, (int)var5_7)) {
                        this.i = var2_4;
                        this.j = var5_7;
                        return false;
                    }
                    if (var4_6 > 0.0f && var4_6 > var6_8) {
                        this.g = true;
                        this.b();
                        this.i = var2_4;
                        if (!this.f) {
                            this.f = true;
                            ** break;
                        }
                    } else if (var6_8 > 0.0f) {
                        this.h = true;
                        ** break;
                    }
                }
                ** GOTO lbl53
            }
            case 0: {
                this.i = var1_1.getX();
                this.j = var1_1.getY();
                this.k = c.b(var1_1, 0);
                if (this.o == 2) {
                    this.g = true;
                    this.h = false;
                    this.b();
                    ** break;
                }
                this.c();
                this.g = false;
                this.h = false;
            }
lbl53: // 7 sources:
            default: {
                ** GOTO lbl64
            }
            case 6: 
        }
        var8_3 = c.a(var1_1);
        if (c.b(var1_1, var8_3) == this.k) {
            if (var8_3 == 0) {
                var7_2 = 1;
            }
            this.i = c.c(var1_1, var7_2);
            this.k = c.b(var1_1, var7_2);
            if (this.l != null) {
                this.l.clear();
            }
        }
lbl64: // 6 sources:
        if (this.g != false) return this.g;
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        this.l.addMovement(var1_1);
        return this.g;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final void onLayout(boolean var1_1, int var2_2, int var3_3, int var4_4, int var5_5) {
        this.e = true;
        this.e = false;
        var11_6 = this.getChildCount();
        var12_7 = var4_4 - var2_2;
        var13_8 = var5_5 - var3_3;
        var3_3 = this.getPaddingLeft();
        var2_2 = this.getPaddingTop();
        var6_9 = this.getPaddingRight();
        var4_4 = this.getPaddingBottom();
        var14_10 = this.getScrollX();
        var7_11 = 0;
        var9_12 = 0;
        do {
            if (var9_12 >= var11_6) {
                this.n = var7_11;
                return;
            }
            var16_16 = this.getChildAt(var9_12);
            if (var16_16.getVisibility() == 8) ** GOTO lbl78
            var17_17 = (LayoutParams)var16_16.getLayoutParams();
            if (var17_17.a) {
                var5_5 = var17_17.b;
                var15_15 = var17_17.b;
                switch (var5_5 & 7) {
                    default: {
                        var5_5 = var3_3;
                        var8_13 = var3_3;
                        break;
                    }
                    case 3: {
                        var8_13 = var16_16.getMeasuredWidth();
                        var5_5 = var3_3;
                        var8_13 += var3_3;
                        break;
                    }
                    case 1: {
                        var5_5 = Math.max((var12_7 - var16_16.getMeasuredWidth()) / 2, var3_3);
                        var8_13 = var3_3;
                        break;
                    }
                    case 5: {
                        var8_13 = var16_16.getMeasuredWidth();
                        var5_5 = var6_9 + var16_16.getMeasuredWidth();
                        var10_14 = var12_7 - var6_9 - var8_13;
                        var6_9 = var5_5;
                        var8_13 = var3_3;
                        var5_5 = var10_14;
                    }
                }
                switch (var15_15 & 112) {
                    default: {
                        var10_14 = var2_2;
                        var3_3 = var2_2;
                        var2_2 = var4_4;
                        var4_4 = var10_14;
                        break;
                    }
                    case 48: {
                        var10_14 = var16_16.getMeasuredHeight();
                        var3_3 = var4_4;
                        var4_4 = var2_2;
                        var2_2 = var3_3;
                        var3_3 = var10_14 += var2_2;
                        break;
                    }
                    case 16: {
                        var10_14 = Math.max((var13_8 - var16_16.getMeasuredHeight()) / 2, var2_2);
                        var3_3 = var2_2;
                        var2_2 = var4_4;
                        var4_4 = var10_14;
                        break;
                    }
                    case 80: {
                        var10_14 = var13_8 - var4_4 - var16_16.getMeasuredHeight();
                        var15_15 = var16_16.getMeasuredHeight();
                        var3_3 = var2_2;
                        var2_2 = var4_4 + var15_15;
                        var4_4 = var10_14;
                    }
                }
                var16_16.layout(var5_5, var4_4, var16_16.getMeasuredWidth() + (var5_5 += var14_10), var16_16.getMeasuredHeight() + var4_4);
                var5_5 = var6_9;
                var4_4 = var8_13;
                var6_9 = var2_2;
                var2_2 = ++var7_11;
            } else {
                if (this.a(var16_16) != null) {
                    var16_16.layout(var3_3, var2_2, var16_16.getMeasuredWidth() + var3_3, var16_16.getMeasuredHeight() + var2_2);
                }
lbl78: // 4 sources:
                var5_5 = var7_11;
                var7_11 = var2_2;
                var8_13 = var3_3;
                var2_2 = var5_5;
                var5_5 = var6_9;
                var6_9 = var4_4;
                var3_3 = var7_11;
                var4_4 = var8_13;
            }
            ++var9_12;
            var8_13 = var4_4;
            var7_11 = var2_2;
            var2_2 = var3_3;
            var4_4 = var6_9;
            var6_9 = var5_5;
            var3_3 = var8_13;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final void onMeasure(int var1_1, int var2_2) {
        this.setMeasuredDimension(ViewPager.getDefaultSize((int)0, (int)var1_1), ViewPager.getDefaultSize((int)0, (int)var2_2));
        var1_1 = this.getMeasuredWidth() - this.getPaddingLeft() - this.getPaddingRight();
        var2_2 = this.getMeasuredHeight() - this.getPaddingTop() - this.getPaddingBottom();
        var9_3 = this.getChildCount();
        var3_4 = 0;
        do {
            if (var3_4 >= var9_3) ** GOTO lbl35
            var10_10 = this.getChildAt(var3_4);
            if (var10_10.getVisibility() == 8 || (var11_11 = (LayoutParams)var10_10.getLayoutParams()) == null || !var11_11.a) ** GOTO lbl48
            var5_6 = var11_11.b & 7;
            var4_5 = var11_11.b & 112;
            Log.d((String)"ViewPager", (String)("gravity: " + var11_11.b + " hgrav: " + var5_6 + " vgrav: " + var4_5));
            var8_9 = Integer.MIN_VALUE;
            var7_8 = Integer.MIN_VALUE;
            var4_5 = var4_5 == 48 || var4_5 == 80 ? 1 : 0;
            var5_6 = var5_6 == 3 || var5_6 == 5 ? 1 : 0;
            if (var4_5 != 0) {
                var6_7 = 1073741824;
            } else {
                var6_7 = var8_9;
                if (var5_6 != 0) {
                    var7_8 = 1073741824;
                    var6_7 = var8_9;
                }
            }
            var10_10.measure(View.MeasureSpec.makeMeasureSpec((int)var1_1, (int)var6_7), View.MeasureSpec.makeMeasureSpec((int)var2_2, (int)var7_8));
            if (var4_5 == 0) ** GOTO lbl30
            var4_5 = var2_2 - var10_10.getMeasuredHeight();
            var2_2 = var1_1;
            var1_1 = var4_5;
            ** GOTO lbl51
lbl30: // 1 sources:
            if (var5_6 == 0) ** GOTO lbl48
            var4_5 = var1_1 - var10_10.getMeasuredWidth();
            var1_1 = var2_2;
            var2_2 = var4_5;
            ** GOTO lbl51
lbl35: // 1 sources:
            this.c = View.MeasureSpec.makeMeasureSpec((int)var1_1, (int)1073741824);
            this.d = View.MeasureSpec.makeMeasureSpec((int)var2_2, (int)1073741824);
            this.e = true;
            this.e = false;
            var2_2 = this.getChildCount();
            var1_1 = 0;
            while (var1_1 < var2_2) {
                var10_10 = this.getChildAt(var1_1);
                if (!(var10_10.getVisibility() == 8 || (var11_11 = (LayoutParams)var10_10.getLayoutParams()) != null && var11_11.a)) {
                    var10_10.measure(this.c, this.d);
                }
                ++var1_1;
            }
            return;
lbl48: // 2 sources:
            var4_5 = var1_1;
            var1_1 = var2_2;
            var2_2 = var4_5;
lbl51: // 3 sources:
            var4_5 = var3_4 + 1;
            var3_4 = var2_2;
            var2_2 = var1_1;
            var1_1 = var3_4;
            var3_4 = var4_5;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final boolean onRequestFocusInDescendants(int n2, Rect rect) {
        int n3;
        int n4 = -1;
        int n5 = this.getChildCount();
        if ((n2 & 2) != 0) {
            n4 = 1;
            n3 = 0;
        } else {
            n3 = n5 - 1;
            n5 = -1;
        }
        while (n3 != n5) {
            View view = this.getChildAt(n3);
            if (view.getVisibility() == 0 && this.a(view) != null && view.requestFocus(n2, rect)) {
                return true;
            }
            n3 += n4;
        }
        return false;
    }

    public final void onRestoreInstanceState(Parcelable object) {
        if (!(object instanceof SavedState)) {
            super.onRestoreInstanceState((Parcelable)object);
            return;
        }
        object = (SavedState)((Object)object);
        super.onRestoreInstanceState(object.getSuperState());
        int n2 = object.a;
        Parcelable parcelable = object.b;
        object = object.c;
    }

    public final Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.a = 0;
        return savedState;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final void onSizeChanged(int n2, int n3, int n4, int n5) {
        super.onSizeChanged(n2, n3, n4, n5);
        if (n2 == n4) return;
        if (n4 > 0) {
            n5 = this.getScrollX();
            n3 = n5 / n4;
            this.scrollTo((int)(((float)(n5 % n4) / (float)n4 + (float)n3) * (float)n2), this.getScrollY());
            throw new NullPointerException();
        }
        if ((n2 *= 0) == this.getScrollX()) return;
        this.c();
        this.scrollTo(n2, this.getScrollY());
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() != 0 || motionEvent.getEdgeFlags() != 0) {
            // empty if block
        }
        return false;
    }

    protected final boolean verifyDrawable(Drawable drawable2) {
        if (super.verifyDrawable(drawable2) || drawable2 == null) {
            return true;
        }
        return false;
    }

    public static class LayoutParams
    extends ViewGroup.LayoutParams {
        public boolean a;
        public int b;

        public LayoutParams() {
            super(-1, -1);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            context = context.obtainStyledAttributes(attributeSet, a);
            this.b = context.getInteger(0, 0);
            context.recycle();
        }
    }

    public static class SavedState
    extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = android.support.v4.b.a.a(new android.support.v4.b.b<SavedState>(){

            @Override
            public final /* synthetic */ Object a(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }
        });
        int a;
        Parcelable b;
        ClassLoader c;

        SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel);
            ClassLoader classLoader2 = classLoader;
            if (classLoader == null) {
                classLoader2 = this.getClass().getClassLoader();
            }
            this.a = parcel.readInt();
            this.b = parcel.readParcelable(classLoader2);
            this.c = classLoader2;
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode((Object)this)) + " position=" + this.a + "}";
        }

        public void writeToParcel(Parcel parcel, int n2) {
            super.writeToParcel(parcel, n2);
            parcel.writeInt(this.a);
            parcel.writeParcelable(this.b, n2);
        }

    }

    static interface a {
    }

    static final class b {
        b() {
        }
    }

}

