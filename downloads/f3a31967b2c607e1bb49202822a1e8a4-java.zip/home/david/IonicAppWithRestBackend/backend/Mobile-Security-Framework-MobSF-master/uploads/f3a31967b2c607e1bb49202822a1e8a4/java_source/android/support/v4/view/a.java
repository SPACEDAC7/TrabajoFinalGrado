/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.KeyEvent
 */
package android.support.v4.view;

import android.os.Build;
import android.view.KeyEvent;

public final class a {
    private static c a = Build.VERSION.SDK_INT >= 11 ? new b() : new a();

    public static boolean a(KeyEvent keyEvent) {
        return a.a(keyEvent.getMetaState());
    }

    public static boolean b(KeyEvent keyEvent) {
        return a.b(keyEvent.getMetaState());
    }

    static final class a
    implements c {
        a() {
        }

        /*
         * Enabled aggressive block sorting
         */
        private static int a(int n2, int n3, int n4, int n5) {
            int n6 = 1;
            boolean bl = (n3 & 1) != 0;
            n4 = ((n5 = n4 | n5) & 1) != 0 ? n6 : 0;
            if (bl) {
                if (n4 == 0) return n2 & ~ n5;
                throw new IllegalArgumentException("bad arguments");
            }
            n5 = n2;
            if (n4 == 0) return n5;
            return n2 & ~ n3;
        }

        private static int c(int n2) {
            if ((n2 & 192) != 0) {
                n2 |= 1;
            }
            int n3 = n2;
            if ((n2 & 48) != 0) {
                n3 = n2 | 2;
            }
            return n3 & 247;
        }

        @Override
        public final boolean a(int n2) {
            if (a.a(a.a(a.c(n2) & 247, 1, 64, 128), 2, 16, 32) == 1) {
                return true;
            }
            return false;
        }

        @Override
        public final boolean b(int n2) {
            if ((a.c(n2) & 247) == 0) {
                return true;
            }
            return false;
        }
    }

    static final class b
    implements c {
        b() {
        }

        @Override
        public final boolean a(int n2) {
            return KeyEvent.metaStateHasModifiers((int)n2, (int)1);
        }

        @Override
        public final boolean b(int n2) {
            return KeyEvent.metaStateHasNoModifiers((int)n2);
        }
    }

    static interface c {
        public boolean a(int var1);

        public boolean b(int var1);
    }

}

