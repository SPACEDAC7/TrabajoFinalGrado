/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.MotionEvent
 */
package android.support.v4.view;

import android.support.v4.view.c;
import android.view.MotionEvent;

final class b
implements c.b {
    b() {
    }

    @Override
    public final int a(MotionEvent motionEvent, int n2) {
        if (n2 == 0) {
            return 0;
        }
        return -1;
    }

    @Override
    public final int b(MotionEvent motionEvent, int n2) {
        if (n2 == 0) {
            return 0;
        }
        throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
    }

    @Override
    public final float c(MotionEvent motionEvent, int n2) {
        if (n2 == 0) {
            return motionEvent.getX();
        }
        throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
    }

    @Override
    public final float d(MotionEvent motionEvent, int n2) {
        if (n2 == 0) {
            return motionEvent.getY();
        }
        throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
    }
}

