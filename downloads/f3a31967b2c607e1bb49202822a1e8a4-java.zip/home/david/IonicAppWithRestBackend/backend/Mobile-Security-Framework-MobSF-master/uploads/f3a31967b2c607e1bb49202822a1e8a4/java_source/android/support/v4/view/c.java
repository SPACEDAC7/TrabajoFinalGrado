/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.MotionEvent
 */
package android.support.v4.view;

import android.os.Build;
import android.view.MotionEvent;

public final class c {
    private static b a = Build.VERSION.SDK_INT >= 5 ? new a() : new android.support.v4.view.b();

    public static int a(MotionEvent motionEvent) {
        return motionEvent.getAction() >> 8 & 255;
    }

    public static int a(MotionEvent motionEvent, int n2) {
        return a.a(motionEvent, n2);
    }

    public static int b(MotionEvent motionEvent, int n2) {
        return a.b(motionEvent, n2);
    }

    public static float c(MotionEvent motionEvent, int n2) {
        return a.c(motionEvent, n2);
    }

    public static float d(MotionEvent motionEvent, int n2) {
        return a.d(motionEvent, n2);
    }

    static final class a
    implements b {
        a() {
        }

        @Override
        public final int a(MotionEvent motionEvent, int n2) {
            return motionEvent.findPointerIndex(n2);
        }

        @Override
        public final int b(MotionEvent motionEvent, int n2) {
            return motionEvent.getPointerId(n2);
        }

        @Override
        public final float c(MotionEvent motionEvent, int n2) {
            return motionEvent.getX(n2);
        }

        @Override
        public final float d(MotionEvent motionEvent, int n2) {
            return motionEvent.getY(n2);
        }
    }

    static interface b {
        public int a(MotionEvent var1, int var2);

        public int b(MotionEvent var1, int var2);

        public float c(MotionEvent var1, int var2);

        public float d(MotionEvent var1, int var2);
    }

}

