/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 */
package android.support.v4.view;

import android.os.Build;
import android.view.View;

public final class e {
    private static c a;

    static {
        int n2 = Build.VERSION.SDK_INT;
        a = n2 >= 14 ? new b() : (n2 >= 9 ? new a() : new c());
    }

    public static int a(View view) {
        return a.a(view);
    }

    public static boolean a(View view, int n2) {
        return a.a(view, n2);
    }

    static class a
    extends c {
        a() {
        }

        @Override
        public final int a(View view) {
            return view.getOverScrollMode();
        }
    }

    static final class b
    extends a {
        b() {
        }

        @Override
        public final boolean a(View view, int n2) {
            return view.canScrollHorizontally(n2);
        }
    }

    static class c {
        c() {
        }

        public int a(View view) {
            return 2;
        }

        public boolean a(View view, int n2) {
            return false;
        }
    }

}

