/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.Dialog
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.os.Environment
 *  android.os.StatFs
 *  android.text.format.Formatter
 *  android.util.Log
 *  android.util.SparseBooleanArray
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.AdapterView$OnItemLongClickListener
 *  android.widget.Button
 *  android.widget.Filter
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package braveheart.apps.apkinstaller;

import a.a.a.a.a.f;
import a.a.a.a.a.j;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.text.format.Formatter;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Filter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.SherlockActivity;
import com.actionbarsherlock.view.ActionMode;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.widget.SearchView;
import com.startapp.android.publish.StartAppAd;
import com.startapp.android.publish.StartAppSDK;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class MainActivity
extends SherlockActivity
implements SearchView.OnQueryTextListener {
    private static PackageInfo o;
    List<HashMap<String, String>> a;
    @SuppressLint(value={"SimpleDateFormat"})
    SimpleDateFormat b = new SimpleDateFormat("MM/dd/yyyy");
    SharedPreferences c;
    private TextView d;
    private TextView e;
    private TextView f;
    private ListView g;
    private RelativeLayout h;
    private ProgressBar i;
    private braveheart.apps.apkinstaller.a.a j;
    private long k;
    private long l;
    private ActionMode m;
    private SearchView n;
    private StartAppAd p;

    public MainActivity() {
        this.p = new StartAppAd((Context)this);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String a() {
        Iterator<String> iterator = Arrays.asList("external_sd", "ext_sd", "external", "extSdCard").iterator();
        Object object = null;
        do {
            if (!iterator.hasNext()) {
                if (object == null) break;
                object = new File((String)object);
                do {
                    return object.getAbsolutePath();
                    break;
                } while (true);
            }
            File file = new File("/mnt/", iterator.next());
            if (!file.isDirectory() || !file.canWrite()) continue;
            object = file.getAbsolutePath();
        } while (true);
        object = new File(Environment.getExternalStorageDirectory().getAbsolutePath());
        return object.getAbsolutePath();
    }

    static /* synthetic */ void a(PackageInfo packageInfo) {
        o = packageInfo;
    }

    /*
     * Enabled aggressive block sorting
     */
    static /* synthetic */ void a(MainActivity mainActivity, int n2) {
        mainActivity.j = (braveheart.apps.apkinstaller.a.a)mainActivity.g.getAdapter();
        mainActivity.j.a(n2);
        n2 = mainActivity.j.b() > 0 ? 1 : 0;
        if (n2 != 0) {
            if (mainActivity.m == null) {
                mainActivity.m = mainActivity.startActionMode(new a(mainActivity, 0));
            }
        } else if (n2 == 0 && mainActivity.m != null) {
            mainActivity.m.finish();
        }
        if (mainActivity.m != null) {
            mainActivity.m.setTitle(String.valueOf(String.valueOf(mainActivity.j.b())) + " selected");
        }
    }

    static /* synthetic */ void a(MainActivity mainActivity, long l2) {
        mainActivity.k = l2;
    }

    static /* synthetic */ void a(MainActivity mainActivity, braveheart.apps.apkinstaller.a.a a2) {
        mainActivity.j = a2;
    }

    static /* synthetic */ PackageInfo b() {
        return o;
    }

    static /* synthetic */ void b(MainActivity mainActivity, long l2) {
        mainActivity.l = l2;
    }

    static /* synthetic */ long c() {
        StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
        long l2 = statFs.getBlockSize();
        return (long)statFs.getBlockCount() * l2;
    }

    static /* synthetic */ long d() {
        StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
        long l2 = statFs.getBlockSize();
        return (long)statFs.getAvailableBlocks() * l2;
    }

    static /* synthetic */ void j(MainActivity mainActivity) {
        mainActivity.m = null;
    }

    public void onBackPressed() {
        this.p.onBackPressed();
        super.onBackPressed();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130903062);
        this.c = this.getSharedPreferences("APK_INSTALLER", 0);
        this.a = new ArrayList<HashMap<String, String>>();
        this.i = (ProgressBar)this.findViewById(2130968639);
        this.g = (ListView)this.findViewById(2130968636);
        this.j = new braveheart.apps.apkinstaller.a.a((Context)this, this.a);
        this.g.setAdapter((ListAdapter)this.j);
        new c(this, 0).execute((Object[])new Void[0]);
        this.h = (RelativeLayout)this.findViewById(2130968633);
        this.e = (TextView)this.findViewById(2130968634);
        this.f = (TextView)this.findViewById(2130968635);
        this.d = (TextView)this.findViewById(2130968638);
        this.g.setOnItemClickListener(new AdapterView.OnItemClickListener(this){
            private /* synthetic */ MainActivity a;

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            public final void onItemClick(AdapterView<?> object, View view, int n2, long l2) {
                if (this.a.m != null) {
                    MainActivity.a(this.a, n2);
                    return;
                }
                if (object == null) return;
                object = (String)((HashMap)object.getItemAtPosition(n2)).get("FULL_FILE_PATH");
                try {
                    object = new Intent("android.intent.action.VIEW").setDataAndType(Uri.parse((String)("file:///" + (String)object)), "application/vnd.android.package-archive");
                    this.a.startActivity((Intent)object);
                    return;
                }
                catch (ActivityNotFoundException activityNotFoundException) {
                    return;
                }
            }
        });
        this.g.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(this){
            private /* synthetic */ MainActivity a;

            public final boolean onItemLongClick(AdapterView<?> adapterView, View view, int n2, long l2) {
                MainActivity.a(this.a, n2);
                return true;
            }
        });
        try {
            StartAppSDK.init((Context)this, "108042476", "208357606", true);
        }
        catch (Exception var1_2) {}
        if (!this.c.getBoolean("HAS_RATE", false) && new Random().nextInt(8) + 1 == 7) {
            bundle = new Dialog((Context)this);
            bundle.setContentView(2130903064);
            bundle.setTitle((CharSequence)"Apk Installer!!!");
            ((TextView)bundle.findViewById(2130968641)).setText((CharSequence)"If you find it useful for you, You can use donate version(NO ADS). Thanks for your support!");
            Button button = (Button)bundle.findViewById(2130968643);
            Button button2 = (Button)bundle.findViewById(2130968644);
            Button button3 = (Button)bundle.findViewById(2130968645);
            button.setOnClickListener(new View.OnClickListener(this, (Dialog)bundle){
                private /* synthetic */ MainActivity a;
                private final /* synthetic */ Dialog b;

                public final void onClick(View view) {
                    view = this.a.c.edit();
                    view.putBoolean("HAS_RATE", true);
                    view.commit();
                    this.b.dismiss();
                }
            });
            button2.setOnClickListener(new View.OnClickListener(this, (Dialog)bundle){
                private /* synthetic */ MainActivity a;
                private final /* synthetic */ Dialog b;

                public final void onClick(View view) {
                    view = this.a.c.edit();
                    view.putBoolean("HAS_RATE", true);
                    view.commit();
                    this.a.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)"market://braveheart.apps.apkinstaller.paid")));
                    this.b.dismiss();
                }
            });
            button3.setOnClickListener(new View.OnClickListener(){

                public final void onClick(View view) {
                    Dialog.this.dismiss();
                }
            });
            bundle.show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.n = new SearchView(this.getSupportActionBar().getThemedContext());
        this.n.setQueryHint("Search for applications\u2026");
        this.n.setOnQueryTextListener(this);
        menu.add(0, 0, 0, "Search").setIcon(2130837620).setActionView((View)this.n).setShowAsAction(9);
        menu.add(0, 1, 1, "Feedback").setIcon(2130837621).setShowAsAction(1);
        menu.findItem(0).setOnActionExpandListener(new MenuItem.OnActionExpandListener(this){
            private /* synthetic */ MainActivity a;

            @Override
            public final boolean onMenuItemActionCollapse(MenuItem menuItem) {
                if (this.a.j != null) {
                    this.a.j.getFilter().filter((CharSequence)"");
                }
                return true;
            }

            @Override
            public final boolean onMenuItemActionExpand(MenuItem menuItem) {
                if (this.a.j != null) {
                    this.a.j.getFilter().filter((CharSequence)"");
                }
                return true;
            }
        });
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            default: {
                do {
                    return true;
                    break;
                } while (true);
            }
            case 1: 
        }
        menuItem = new Intent("android.intent.action.SENDTO", Uri.fromParts((String)"mailto", (String)"android.apps.feedback@gmail.com", (String)null));
        menuItem.putExtra("android.intent.extra.SUBJECT", "Feedback");
        this.startActivity(Intent.createChooser((Intent)menuItem, (CharSequence)"Send feedback..."));
        return true;
    }

    @Override
    public void onPause() {
        super.onPause();
        this.p.onPause();
    }

    @Override
    public boolean onQueryTextChange(String string2) {
        if (string2 != null && this.j != null) {
            this.j.getFilter().filter((CharSequence)string2);
        }
        return false;
    }

    @Override
    public boolean onQueryTextSubmit(String string2) {
        return false;
    }

    public void onResume() {
        super.onResume();
        this.p.onResume();
    }

    final class a
    implements ActionMode.Callback {
        private /* synthetic */ MainActivity a;

        private a(MainActivity mainActivity) {
            this.a = mainActivity;
        }

        /* synthetic */ a(MainActivity mainActivity, byte by) {
            this(mainActivity);
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public final boolean onActionItemClicked(ActionMode actionMode, MenuItem object) {
            SparseBooleanArray sparseBooleanArray = this.a.j.c();
            if (object.getTitle() == this.a.getResources().getString(2131296270)) {
                MainActivity.a(this.a, (braveheart.apps.apkinstaller.a.a)this.a.g.getAdapter());
                AlertDialog.Builder builder = new AlertDialog.Builder((Context)this.a);
                builder.setTitle((CharSequence)"Confirm deletion");
                builder.setMessage((CharSequence)"This action cannot be undone! Do you want to countinue?").setCancelable(false).setPositiveButton((CharSequence)"Yes", new DialogInterface.OnClickListener(this, sparseBooleanArray){
                    private /* synthetic */ a a;
                    private final /* synthetic */ SparseBooleanArray b;

                    public final void onClick(DialogInterface dialogInterface, int n2) {
                        n2 = 0;
                        do {
                            if (n2 >= this.b.size()) {
                                new c(this.a.a, 0).execute((Object[])new Void[0]);
                                return;
                            }
                            if (this.b.valueAt(n2)) {
                                new File(this.a.a.j.b(this.b.keyAt(n2)).get("FULL_FILE_PATH")).delete();
                            }
                            ++n2;
                        } while (true);
                    }
                }).setNegativeButton((CharSequence)"No", new DialogInterface.OnClickListener(){

                    public final void onClick(DialogInterface dialogInterface, int n2) {
                        dialogInterface.cancel();
                    }
                });
                builder.create().show();
            }
            if (object.getTitle() == this.a.getResources().getString(2131296271)) {
                for (int i2 = 0; i2 < sparseBooleanArray.size(); ++i2) {
                    if (!sparseBooleanArray.valueAt(i2)) continue;
                    object = this.a.j.b(sparseBooleanArray.keyAt(i2));
                    try {
                        object = new Intent("android.intent.action.VIEW").setDataAndType(Uri.parse((String)("file:///" + (String)object.get("FULL_FILE_PATH"))), "application/vnd.android.package-archive");
                        this.a.startActivity((Intent)object);
                        continue;
                    }
                    catch (ActivityNotFoundException var2_3) {}
                }
            }
            actionMode.finish();
            return false;
        }

        @Override
        public final boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            actionMode.getMenuInflater().inflate(2131427328, menu);
            return true;
        }

        @Override
        public final void onDestroyActionMode(ActionMode actionMode) {
            MainActivity.a(this.a, (braveheart.apps.apkinstaller.a.a)this.a.g.getAdapter());
            this.a.j.a();
            MainActivity.j(this.a);
        }

        @Override
        public final boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            return false;
        }

    }

    public final class b
    implements Comparator<HashMap<String, String>> {
        @Override
        public final /* synthetic */ int compare(Object object, Object object2) {
            object = (HashMap)object;
            return String.valueOf(((HashMap)object2).get("FILE_DATE")).compareTo(String.valueOf(object.get("FILE_DATE")));
        }
    }

    final class c
    extends AsyncTask<Void, HashMap<String, String>, List<HashMap<String, String>>> {
        private /* synthetic */ MainActivity a;

        private c(MainActivity mainActivity) {
            this.a = mainActivity;
        }

        /* synthetic */ c(MainActivity mainActivity, byte by) {
            this(mainActivity);
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @SuppressLint(value={"DefaultLocale"})
        private /* varargs */ List<HashMap<String, String>> a() {
            Object object;
            HashMap<String, String> hashMap;
            block12 : {
                long l2;
                String string2;
                File file;
                try {
                    object = new File(Environment.getExternalStorageDirectory().getAbsolutePath());
                    Log.i((String)"External Path", (String)Environment.getExternalStorageDirectory().getAbsolutePath());
                    Log.i((String)"SD CARD Path", (String)MainActivity.a());
                    object = ((List)a.a.a.a.a.a((File)object, j.a, j.a)).iterator();
                    do {
                        if (!object.hasNext()) {
                            if (MainActivity.a().equals(Environment.getExternalStorageDirectory().getAbsolutePath())) break block12;
                            object = ((List)a.a.a.a.a.a(new File(MainActivity.a()), j.a, j.a)).iterator();
                            break;
                        }
                        file = (File)object.next();
                        if (!file.getName().toLowerCase().endsWith(".apk")) continue;
                        string2 = file.getAbsolutePath();
                        hashMap = new HashMap();
                        hashMap.put("FULL_FILE_PATH", string2);
                        hashMap.put("FILE_NAME", file.getName());
                        hashMap.put("FILE_DATE", this.a.b.format(file.lastModified()));
                        l2 = file.length();
                        hashMap.put("FILE_SIZE", Formatter.formatShortFileSize((Context)this.a, (long)l2));
                        try {
                            MainActivity.a(this.a.getPackageManager().getPackageArchiveInfo(string2, 0));
                            if (MainActivity.b().versionName != null) {
                                hashMap.put("FILE_VERSION", MainActivity.b().versionName.toString());
                            }
                        }
                        catch (NullPointerException var5_7) {}
                        this.publishProgress((Object[])new HashMap[]{hashMap});
                    } while (true);
                }
                catch (Exception var3_2) {
                    return this.a.a;
                }
                while (object.hasNext()) {
                    file = (File)object.next();
                    if (!file.getName().toLowerCase().endsWith(".apk")) continue;
                    string2 = file.getAbsolutePath();
                    hashMap = new HashMap<String, String>();
                    hashMap.put("FULL_FILE_PATH", string2);
                    hashMap.put("FILE_NAME", file.getName());
                    hashMap.put("FILE_DATE", this.a.b.format(file.lastModified()));
                    l2 = file.length();
                    hashMap.put("FILE_SIZE", Formatter.formatShortFileSize((Context)this.a, (long)l2));
                    try {
                        MainActivity.a(this.a.getPackageManager().getPackageArchiveInfo(string2, 0));
                        if (MainActivity.b().versionName != null) {
                            hashMap.put("FILE_VERSION", MainActivity.b().versionName.toString());
                        }
                    }
                    catch (NullPointerException var5_6) {}
                    this.publishProgress((Object[])new HashMap[]{hashMap});
                }
            }
            object = this.a.a;
            hashMap = this.a;
            Collections.sort(object, new b());
            MainActivity.a(this.a, MainActivity.c() - MainActivity.d());
            MainActivity.b(this.a, MainActivity.c());
            return this.a.a;
        }

        /*
         * Exception decompiling
         */
        protected final /* varargs */ /* synthetic */ Object doInBackground(Object ... var1_1) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // java.lang.ArrayIndexOutOfBoundsException: -1
            // java.util.ArrayList.elementData(ArrayList.java:418)
            // java.util.ArrayList.get(ArrayList.java:431)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.VarArgsRewriter.rewriteVarArgsArg(VarArgsRewriter.java:86)
            // org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractMemberFunctionInvokation.rewriteVarArgs(AbstractMemberFunctionInvokation.java:142)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.VarArgsRewriter.rewriteExpression(VarArgsRewriter.java:55)
            // org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn.rewriteExpressions(StructuredReturn.java:90)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.VarArgsRewriter.rewrite(VarArgsRewriter.java:41)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.removeUnnecessaryVarargArrays(Op04StructuredStatement.java:967)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:868)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        /*
         * Enabled aggressive block sorting
         */
        protected final /* synthetic */ void onPostExecute(Object object) {
            if ((object = (List)object) != null) {
                int n2 = object.size();
                if (n2 > 0) {
                    this.a.f.setText((CharSequence)("Total:" + n2 + " apps"));
                    this.a.d.setVisibility(8);
                } else {
                    this.a.d.setVisibility(0);
                }
                this.a.h.setVisibility(0);
                this.a.e.setText((CharSequence)("Storage: " + Formatter.formatFileSize((Context)this.a, (long)this.a.k) + "/" + Formatter.formatFileSize((Context)this.a, (long)(this.a.l - this.a.k))));
                this.a.i.setVisibility(8);
            }
        }

        protected final void onPreExecute() {
            this.a.a.clear();
            this.a.i.setVisibility(0);
        }

        protected final /* varargs */ /* synthetic */ void onProgressUpdate(Object ... arrobject) {
            arrobject = (HashMap[])arrobject;
            try {
                this.a.a.add((HashMap<String, String>)arrobject[0]);
                this.a.j.notifyDataSetChanged();
                return;
            }
            catch (IndexOutOfBoundsException var1_2) {
                return;
            }
        }
    }

}

