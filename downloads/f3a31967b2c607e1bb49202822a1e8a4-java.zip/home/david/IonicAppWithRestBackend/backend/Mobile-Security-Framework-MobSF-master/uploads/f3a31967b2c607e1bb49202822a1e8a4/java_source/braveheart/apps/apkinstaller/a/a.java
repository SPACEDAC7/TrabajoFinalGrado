/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.graphics.Color
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.Html
 *  android.util.SparseBooleanArray
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.BaseAdapter
 *  android.widget.Filter
 *  android.widget.Filter$FilterResults
 *  android.widget.Filterable
 *  android.widget.ImageView
 *  android.widget.TextView
 */
package braveheart.apps.apkinstaller.a;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Html;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

public final class a
extends BaseAdapter
implements Filterable {
    private static PackageInfo e;
    private Context a;
    private List<HashMap<String, String>> b;
    private List<HashMap<String, String>> c;
    private SparseBooleanArray d;

    public a(Context context, List<HashMap<String, String>> list) {
        this.a = context;
        this.b = list;
        this.d = new SparseBooleanArray();
    }

    static /* synthetic */ void a(a a2, List list) {
        a2.b = list;
    }

    private static boolean a(String string2, Context context) {
        context = context.getPackageManager();
        try {
            context.getPackageInfo(string2, 1);
            return true;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            return false;
        }
    }

    static /* synthetic */ void b(a a2, List list) {
        a2.c = list;
    }

    public final void a() {
        this.d = new SparseBooleanArray();
        this.notifyDataSetChanged();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(int n2) {
        boolean bl = !this.d.get(n2);
        if (bl) {
            this.d.put(n2, true);
        } else {
            this.d.delete(n2);
        }
        this.notifyDataSetChanged();
    }

    public final int b() {
        return this.d.size();
    }

    public final HashMap<String, String> b(int n2) {
        return this.b.get(n2);
    }

    public final SparseBooleanArray c() {
        return this.d;
    }

    public final int getCount() {
        return this.b.size();
    }

    public final Filter getFilter() {
        return new Filter(this){
            private /* synthetic */ a a;

            @SuppressLint(value={"DefaultLocale"})
            protected final Filter.FilterResults performFiltering(CharSequence charSequence) {
                Filter.FilterResults filterResults = new Filter.FilterResults();
                ArrayList<HashMap> arrayList = new ArrayList<HashMap>();
                if (this.a.c == null) {
                    a.b(this.a, new ArrayList(this.a.b));
                }
                if (charSequence == null || charSequence.length() == 0) {
                    filterResults.count = this.a.c.size();
                    filterResults.values = this.a.c;
                    return filterResults;
                }
                charSequence = charSequence.toString().toLowerCase();
                int n2 = 0;
                do {
                    if (n2 >= this.a.c.size()) {
                        filterResults.count = arrayList.size();
                        filterResults.values = arrayList;
                        return filterResults;
                    }
                    HashMap hashMap = (HashMap)this.a.c.get(n2);
                    if (((String)hashMap.get("FILE_NAME")).toLowerCase().contains(charSequence)) {
                        arrayList.add(hashMap);
                    }
                    ++n2;
                } while (true);
            }

            protected final void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
                a.a(this.a, (ArrayList)filterResults.values);
                this.a.notifyDataSetChanged();
            }
        };
    }

    public final /* synthetic */ Object getItem(int n2) {
        return this.b(n2);
    }

    public final long getItemId(int n2) {
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @SuppressLint(value={"InflateParams"})
    public final View getView(int n2, View view, ViewGroup viewGroup) {
        a a2;
        String string2 = null;
        viewGroup = view;
        if (view == null) {
            try {
                view = viewGroup = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903061, null);
                a2 = new a(0);
                view = viewGroup;
                a2.a = (ImageView)viewGroup.findViewById(2130968626);
                view = viewGroup;
                a2.b = (TextView)viewGroup.findViewById(2130968627);
                view = viewGroup;
                a2.c = (TextView)viewGroup.findViewById(2130968628);
                view = viewGroup;
                a2.d = (TextView)viewGroup.findViewById(2130968631);
                view = viewGroup;
                a2.e = (TextView)viewGroup.findViewById(2130968632);
                view = viewGroup;
                a2.f = (TextView)viewGroup.findViewById(2130968629);
                view = viewGroup;
                viewGroup.setTag((Object)a2);
            }
            catch (ClassCastException var3_5) {
                viewGroup = view;
            }
        }
        a2 = (a)viewGroup.getTag();
        try {
            PackageInfo packageInfo;
            HashMap<String, String> hashMap = this.b.get(n2);
            String string3 = hashMap.get("FULL_FILE_PATH");
            e = packageInfo = this.a.getPackageManager().getPackageArchiveInfo(string3, 1);
            view = string2;
            if (packageInfo != null) {
                view = a.e.applicationInfo;
                if (Build.VERSION.SDK_INT >= 8) {
                    view.sourceDir = string3;
                    view.publicSourceDir = string3;
                }
                view = view.loadIcon(this.a.getPackageManager());
            }
            string2 = "<FONT COLOR='#bfbf00'>" + hashMap.get("FILE_DATE") + "</FONT>";
            string3 = "<FONT COLOR='#12d604'>" + hashMap.get("FILE_SIZE") + "</FONT>";
            a2.a.setImageDrawable((Drawable)view);
            a2.b.setText((CharSequence)hashMap.get("FILE_NAME"));
            a2.c.setText((CharSequence)Html.fromHtml((String)string2));
            a2.d.setText((CharSequence)Html.fromHtml((String)string3));
            a2.e.setText((CharSequence)hashMap.get("FILE_VERSION"));
            if (a.a(a.e.packageName, this.a)) {
                a2.f.setTextColor(Color.parseColor((String)"#319300"));
                a2.f.setText((CharSequence)"Installed");
            } else {
                a2.f.setTextColor(Color.parseColor((String)"#ff0000"));
                a2.f.setText((CharSequence)"Not Installed");
            }
            n2 = this.d.get(n2) ? -1724598812 : 0;
            viewGroup.setBackgroundColor(n2);
            return viewGroup;
        }
        catch (Exception var2_3) {
            return viewGroup;
        }
    }

    static final class a {
        ImageView a;
        TextView b;
        TextView c;
        TextView d;
        TextView e;
        TextView f;

        private a() {
        }

        /* synthetic */ a(byte by) {
            this();
        }
    }

}

