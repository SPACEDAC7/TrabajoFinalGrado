/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.view.KeyEvent
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 */
package com.actionbarsherlock;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.internal.ActionBarSherlockCompat;
import com.actionbarsherlock.internal.ActionBarSherlockNative;
import com.actionbarsherlock.view.ActionMode;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public abstract class ActionBarSherlock {
    private static final Class<?>[] CONSTRUCTOR_ARGS = new Class[]{Activity.class, Integer.TYPE};
    public static final boolean DEBUG = false;
    public static final int FLAG_DELEGATE = 1;
    private static final HashMap<Implementation, Class<? extends ActionBarSherlock>> IMPLEMENTATIONS = new HashMap();
    protected static final String TAG = "ActionBarSherlock";
    protected final Activity mActivity;
    protected final boolean mIsDelegate;
    protected MenuInflater mMenuInflater;

    static {
        ActionBarSherlock.registerImplementation(ActionBarSherlockCompat.class);
        ActionBarSherlock.registerImplementation(ActionBarSherlockNative.class);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected ActionBarSherlock(Activity activity, int n2) {
        this.mActivity = activity;
        boolean bl = (n2 & 1) != 0;
        this.mIsDelegate = bl;
    }

    public static void registerImplementation(Class<? extends ActionBarSherlock> class_) {
        if (!class_.isAnnotationPresent(Implementation.class)) {
            throw new IllegalArgumentException("Class " + class_.getSimpleName() + " is not annotated with @Implementation");
        }
        if (IMPLEMENTATIONS.containsValue(class_)) {
            return;
        }
        Implementation implementation = (Implementation)class_.getAnnotation(Implementation.class);
        IMPLEMENTATIONS.put(implementation, class_);
    }

    public static boolean unregisterImplementation(Class<? extends ActionBarSherlock> class_) {
        return IMPLEMENTATIONS.values().remove(class_);
    }

    public static ActionBarSherlock wrap(Activity activity) {
        return ActionBarSherlock.wrap(activity, 0);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    public static ActionBarSherlock wrap(Activity var0, int var1_6) {
        block22 : {
            block21 : {
                block20 : {
                    block19 : {
                        block18 : {
                            block17 : {
                                var3_7 = 0;
                                var5_8 = new HashMap<Implementation, Class<? extends ActionBarSherlock>>(ActionBarSherlock.IMPLEMENTATIONS);
                                var6_10 = var5_8.keySet().iterator();
                                do {
                                    if (var6_10.hasNext()) continue;
                                    var2_11 = 0;
lbl7: // 2 sources:
                                    do {
                                        if (var2_11 == 0) ** GOTO lbl14
                                        if (var0.getResources().getDisplayMetrics().densityDpi != 213) break block17;
                                        var2_11 = 1;
lbl11: // 2 sources:
                                        do {
                                            var6_10 = var5_8.keySet().iterator();
lbl13: // 3 sources:
                                            if (var6_10.hasNext()) break block18;
lbl14: // 2 sources:
                                            var6_10 = var5_8.keySet().iterator();
lbl15: // 2 sources:
                                            if (var6_10.hasNext()) break block19;
                                            var2_11 = 0;
lbl17: // 2 sources:
                                            do {
                                                if (var2_11 != 0) {
                                                    var4_12 = Build.VERSION.SDK_INT;
                                                    var6_10 = var5_8.keySet().iterator();
                                                    var2_11 = var3_7;
lbl22: // 4 sources:
                                                    if (var6_10.hasNext()) break block20;
                                                    var6_10 = var5_8.keySet().iterator();
lbl24: // 3 sources:
                                                    if (var6_10.hasNext()) break block21;
                                                }
                                                if (var5_8.size() > 1) {
                                                    throw new IllegalStateException("More than one implementation matches configuration.");
                                                }
                                                break block22;
                                                break;
                                            } while (true);
                                            break;
                                        } while (true);
                                        break;
                                    } while (true);
                                } while (var6_10.next().dpi() != 213);
                                var2_11 = 1;
                                ** while (true)
                            }
                            var2_11 = 0;
                            ** while (true)
                        }
                        var4_12 = var6_10.next().dpi();
                        if ((var2_11 == 0 || var4_12 == 213) && (var2_11 != 0 || var4_12 != 213)) ** GOTO lbl13
                        var6_10.remove();
                        ** GOTO lbl13
                    }
                    if (var6_10.next().api() == -1) ** GOTO lbl15
                    var2_11 = 1;
                    ** while (true)
                }
                var3_7 = var6_10.next().api();
                if (var3_7 <= var4_12) ** GOTO lbl48
                var6_10.remove();
                ** GOTO lbl22
lbl48: // 1 sources:
                if (var3_7 <= var2_11) ** GOTO lbl22
                var2_11 = var3_7;
                ** GOTO lbl22
            }
            if (var6_10.next().api() == var2_11) ** GOTO lbl24
            var6_10.remove();
            ** GOTO lbl24
        }
        if (var5_8.isEmpty()) {
            throw new IllegalStateException("No implementations match configuration.");
        }
        var5_9 = var5_8.values().iterator().next();
        try {
            var0 = var5_9.getConstructor(ActionBarSherlock.CONSTRUCTOR_ARGS).newInstance(new Object[]{var0, var1_6});
            return var0;
        }
        catch (NoSuchMethodException var0_1) {
            throw new RuntimeException(var0_1);
        }
        catch (IllegalArgumentException var0_2) {
            throw new RuntimeException(var0_2);
        }
        catch (InstantiationException var0_3) {
            throw new RuntimeException(var0_3);
        }
        catch (IllegalAccessException var0_4) {
            throw new RuntimeException(var0_4);
        }
        catch (InvocationTargetException var0_5) {
            throw new RuntimeException(var0_5);
        }
    }

    public abstract void addContentView(View var1, ViewGroup.LayoutParams var2);

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean callbackCreateOptionsMenu(Menu menu) {
        boolean bl = true;
        if (this.mActivity instanceof OnCreatePanelMenuListener) {
            return ((OnCreatePanelMenuListener)this.mActivity).onCreatePanelMenu(0, menu);
        }
        if (!(this.mActivity instanceof OnCreateOptionsMenuListener)) return bl;
        return ((OnCreateOptionsMenuListener)this.mActivity).onCreateOptionsMenu(menu);
    }

    protected final boolean callbackOptionsItemSelected(MenuItem menuItem) {
        if (this.mActivity instanceof OnMenuItemSelectedListener) {
            return ((OnMenuItemSelectedListener)this.mActivity).onMenuItemSelected(0, menuItem);
        }
        if (this.mActivity instanceof OnOptionsItemSelectedListener) {
            return ((OnOptionsItemSelectedListener)this.mActivity).onOptionsItemSelected(menuItem);
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean callbackPrepareOptionsMenu(Menu menu) {
        boolean bl = true;
        if (this.mActivity instanceof OnPreparePanelListener) {
            return ((OnPreparePanelListener)this.mActivity).onPreparePanel(0, null, menu);
        }
        if (!(this.mActivity instanceof OnPrepareOptionsMenuListener)) return bl;
        return ((OnPrepareOptionsMenuListener)this.mActivity).onPrepareOptionsMenu(menu);
    }

    public boolean dispatchCloseOptionsMenu() {
        return false;
    }

    public void dispatchConfigurationChanged(Configuration configuration) {
    }

    public abstract boolean dispatchCreateOptionsMenu(android.view.Menu var1);

    public void dispatchDestroy() {
    }

    public abstract void dispatchInvalidateOptionsMenu();

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return false;
    }

    public boolean dispatchMenuOpened(int n2, android.view.Menu menu) {
        return false;
    }

    public boolean dispatchOpenOptionsMenu() {
        return false;
    }

    public abstract boolean dispatchOptionsItemSelected(android.view.MenuItem var1);

    public void dispatchPanelClosed(int n2, android.view.Menu menu) {
    }

    public void dispatchPause() {
    }

    public void dispatchPostCreate(Bundle bundle) {
    }

    public void dispatchPostResume() {
    }

    public abstract boolean dispatchPrepareOptionsMenu(android.view.Menu var1);

    public void dispatchRestoreInstanceState(Bundle bundle) {
    }

    public void dispatchSaveInstanceState(Bundle bundle) {
    }

    public void dispatchStop() {
    }

    public void dispatchTitleChanged(CharSequence charSequence, int n2) {
    }

    public void ensureActionBar() {
    }

    public abstract ActionBar getActionBar();

    /*
     * Enabled aggressive block sorting
     */
    public MenuInflater getMenuInflater() {
        if (this.mMenuInflater != null) return this.mMenuInflater;
        if (this.getActionBar() != null) {
            this.mMenuInflater = new MenuInflater(this.getThemedContext(), (Object)this.mActivity);
            return this.mMenuInflater;
        }
        this.mMenuInflater = new MenuInflater((Context)this.mActivity);
        return this.mMenuInflater;
    }

    protected abstract Context getThemedContext();

    public abstract boolean hasFeature(int var1);

    public abstract boolean requestFeature(int var1);

    public abstract void setContentView(int var1);

    public void setContentView(View view) {
        this.setContentView(view, new ViewGroup.LayoutParams(-1, -1));
    }

    public abstract void setContentView(View var1, ViewGroup.LayoutParams var2);

    public abstract void setProgress(int var1);

    public abstract void setProgressBarIndeterminate(boolean var1);

    public abstract void setProgressBarIndeterminateVisibility(boolean var1);

    public abstract void setProgressBarVisibility(boolean var1);

    public abstract void setSecondaryProgress(int var1);

    public void setTitle(int n2) {
        this.setTitle(this.mActivity.getString(n2));
    }

    public abstract void setTitle(CharSequence var1);

    public abstract void setUiOptions(int var1);

    public abstract void setUiOptions(int var1, int var2);

    public abstract ActionMode startActionMode(ActionMode.Callback var1);

    @Retention(value=RetentionPolicy.RUNTIME)
    @Target(value={ElementType.TYPE})
    public static @interface Implementation {
        public static final int DEFAULT_API = -1;
        public static final int DEFAULT_DPI = -1;

        public int api() default -1;

        public int dpi() default -1;
    }

    public static interface OnActionModeFinishedListener {
        public void onActionModeFinished(ActionMode var1);
    }

    public static interface OnActionModeStartedListener {
        public void onActionModeStarted(ActionMode var1);
    }

    public static interface OnCreateOptionsMenuListener {
        public boolean onCreateOptionsMenu(Menu var1);
    }

    public static interface OnCreatePanelMenuListener {
        public boolean onCreatePanelMenu(int var1, Menu var2);
    }

    public static interface OnMenuItemSelectedListener {
        public boolean onMenuItemSelected(int var1, MenuItem var2);
    }

    public static interface OnOptionsItemSelectedListener {
        public boolean onOptionsItemSelected(MenuItem var1);
    }

    public static interface OnPrepareOptionsMenuListener {
        public boolean onPrepareOptionsMenu(Menu var1);
    }

    public static interface OnPreparePanelListener {
        public boolean onPreparePanel(int var1, View var2, Menu var3);
    }

}

