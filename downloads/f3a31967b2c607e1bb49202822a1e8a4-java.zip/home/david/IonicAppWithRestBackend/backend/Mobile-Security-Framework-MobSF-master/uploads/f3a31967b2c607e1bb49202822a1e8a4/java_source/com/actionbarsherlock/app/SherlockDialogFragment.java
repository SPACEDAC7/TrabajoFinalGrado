/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 */
package com.actionbarsherlock.app;

import android.app.Activity;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Watson;
import android.view.MenuInflater;
import android.view.MenuItem;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.internal.view.menu.MenuItemWrapper;
import com.actionbarsherlock.internal.view.menu.MenuWrapper;
import com.actionbarsherlock.view.Menu;

public class SherlockDialogFragment
extends DialogFragment
implements Watson.OnCreateOptionsMenuListener,
Watson.OnOptionsItemSelectedListener,
Watson.OnPrepareOptionsMenuListener {
    private SherlockFragmentActivity mActivity;

    public SherlockFragmentActivity getSherlockActivity() {
        return this.mActivity;
    }

    @Override
    public void onAttach(Activity activity) {
        if (!(activity instanceof SherlockFragmentActivity)) {
            throw new IllegalStateException(String.valueOf(this.getClass().getSimpleName()) + " must be attached to a SherlockFragmentActivity.");
        }
        this.mActivity = (SherlockFragmentActivity)activity;
        super.onAttach(activity);
    }

    @Override
    public final void onCreateOptionsMenu(android.view.Menu menu, MenuInflater menuInflater) {
        this.onCreateOptionsMenu(new MenuWrapper(menu), this.mActivity.getSupportMenuInflater());
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, com.actionbarsherlock.view.MenuInflater menuInflater) {
    }

    @Override
    public void onDetach() {
        this.mActivity = null;
        super.onDetach();
    }

    @Override
    public final boolean onOptionsItemSelected(MenuItem menuItem) {
        return this.onOptionsItemSelected(new MenuItemWrapper(menuItem));
    }

    @Override
    public boolean onOptionsItemSelected(com.actionbarsherlock.view.MenuItem menuItem) {
        return false;
    }

    @Override
    public final void onPrepareOptionsMenu(android.view.Menu menu) {
        this.onPrepareOptionsMenu(new MenuWrapper(menu));
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
    }
}

