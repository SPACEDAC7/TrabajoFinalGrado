/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ListActivity
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.view.KeyEvent
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 */
package com.actionbarsherlock.app;

import android.app.Activity;
import android.app.ListActivity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import com.actionbarsherlock.ActionBarSherlock;
import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.view.ActionMode;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;

public abstract class SherlockListActivity
extends ListActivity
implements ActionBarSherlock.OnActionModeFinishedListener,
ActionBarSherlock.OnActionModeStartedListener,
ActionBarSherlock.OnCreatePanelMenuListener,
ActionBarSherlock.OnMenuItemSelectedListener,
ActionBarSherlock.OnPreparePanelListener {
    private ActionBarSherlock mSherlock;

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        this.getSherlock().addContentView(view, layoutParams);
    }

    public void closeOptionsMenu() {
        if (!this.getSherlock().dispatchCloseOptionsMenu()) {
            super.closeOptionsMenu();
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (this.getSherlock().dispatchKeyEvent(keyEvent)) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    public View findViewById(int n2) {
        this.getSherlock().ensureActionBar();
        return super.findViewById(n2);
    }

    protected final ActionBarSherlock getSherlock() {
        if (this.mSherlock == null) {
            this.mSherlock = ActionBarSherlock.wrap((Activity)this, 1);
        }
        return this.mSherlock;
    }

    public ActionBar getSupportActionBar() {
        return this.getSherlock().getActionBar();
    }

    public MenuInflater getSupportMenuInflater() {
        return this.getSherlock().getMenuInflater();
    }

    public void invalidateOptionsMenu() {
        this.getSherlock().dispatchInvalidateOptionsMenu();
    }

    @Override
    public void onActionModeFinished(ActionMode actionMode) {
    }

    @Override
    public void onActionModeStarted(ActionMode actionMode) {
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.getSherlock().dispatchConfigurationChanged(configuration);
    }

    public final boolean onCreateOptionsMenu(android.view.Menu menu) {
        return this.getSherlock().dispatchCreateOptionsMenu(menu);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public boolean onCreatePanelMenu(int n2, Menu menu) {
        if (n2 == 0) {
            return this.onCreateOptionsMenu(menu);
        }
        return false;
    }

    protected void onDestroy() {
        this.getSherlock().dispatchDestroy();
        super.onDestroy();
    }

    @Override
    public boolean onMenuItemSelected(int n2, com.actionbarsherlock.view.MenuItem menuItem) {
        if (n2 == 0) {
            return this.onOptionsItemSelected(menuItem);
        }
        return false;
    }

    public final boolean onMenuOpened(int n2, android.view.Menu menu) {
        if (this.getSherlock().dispatchMenuOpened(n2, menu)) {
            return true;
        }
        return super.onMenuOpened(n2, menu);
    }

    public final boolean onOptionsItemSelected(MenuItem menuItem) {
        return this.getSherlock().dispatchOptionsItemSelected(menuItem);
    }

    public boolean onOptionsItemSelected(com.actionbarsherlock.view.MenuItem menuItem) {
        return false;
    }

    public void onPanelClosed(int n2, android.view.Menu menu) {
        this.getSherlock().dispatchPanelClosed(n2, menu);
        super.onPanelClosed(n2, menu);
    }

    protected void onPause() {
        this.getSherlock().dispatchPause();
        super.onPause();
    }

    protected void onPostCreate(Bundle bundle) {
        this.getSherlock().dispatchPostCreate(bundle);
        super.onPostCreate(bundle);
    }

    protected void onPostResume() {
        super.onPostResume();
        this.getSherlock().dispatchPostResume();
    }

    public final boolean onPrepareOptionsMenu(android.view.Menu menu) {
        return this.getSherlock().dispatchPrepareOptionsMenu(menu);
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public boolean onPreparePanel(int n2, View view, Menu menu) {
        if (n2 == 0) {
            return this.onPrepareOptionsMenu(menu);
        }
        return false;
    }

    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.getSherlock().dispatchRestoreInstanceState(bundle);
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.getSherlock().dispatchSaveInstanceState(bundle);
    }

    protected void onStop() {
        this.getSherlock().dispatchStop();
        super.onStop();
    }

    protected void onTitleChanged(CharSequence charSequence, int n2) {
        this.getSherlock().dispatchTitleChanged(charSequence, n2);
        super.onTitleChanged(charSequence, n2);
    }

    public void openOptionsMenu() {
        if (!this.getSherlock().dispatchOpenOptionsMenu()) {
            super.openOptionsMenu();
        }
    }

    public void requestWindowFeature(long l2) {
        this.getSherlock().requestFeature((int)l2);
    }

    public void setContentView(int n2) {
        this.getSherlock().setContentView(n2);
    }

    public void setContentView(View view) {
        this.getSherlock().setContentView(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        this.getSherlock().setContentView(view, layoutParams);
    }

    public void setSupportProgress(int n2) {
        this.getSherlock().setProgress(n2);
    }

    public void setSupportProgressBarIndeterminate(boolean bl) {
        this.getSherlock().setProgressBarIndeterminate(bl);
    }

    public void setSupportProgressBarIndeterminateVisibility(boolean bl) {
        this.getSherlock().setProgressBarIndeterminateVisibility(bl);
    }

    public void setSupportProgressBarVisibility(boolean bl) {
        this.getSherlock().setProgressBarVisibility(bl);
    }

    public void setSupportSecondaryProgress(int n2) {
        this.getSherlock().setSecondaryProgress(n2);
    }

    public ActionMode startActionMode(ActionMode.Callback callback) {
        return this.getSherlock().startActionMode(callback);
    }

    public void supportInvalidateOptionsMenu() {
        this.invalidateOptionsMenu();
    }
}

