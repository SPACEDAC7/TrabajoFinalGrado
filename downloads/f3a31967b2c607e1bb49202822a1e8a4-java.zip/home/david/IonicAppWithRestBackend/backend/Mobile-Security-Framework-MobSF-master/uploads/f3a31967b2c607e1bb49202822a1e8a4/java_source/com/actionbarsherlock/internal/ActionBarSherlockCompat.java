/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.res.AssetManager
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.content.res.XmlResourceParser
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.util.AndroidRuntimeException
 *  android.util.Log
 *  android.util.TypedValue
 *  android.view.ContextThemeWrapper
 *  android.view.KeyCharacterMap
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.MenuItem$OnMenuItemClickListener
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewStub
 *  android.view.Window
 *  android.view.Window$Callback
 *  android.view.animation.Animation
 *  android.view.animation.AnimationUtils
 */
package com.actionbarsherlock.internal;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AndroidRuntimeException;
import android.util.Log;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.actionbarsherlock.ActionBarSherlock;
import com.actionbarsherlock.R;
import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.internal.ResourcesCompat;
import com.actionbarsherlock.internal.app.ActionBarImpl;
import com.actionbarsherlock.internal.view.StandaloneActionMode;
import com.actionbarsherlock.internal.view.menu.ActionMenuPresenter;
import com.actionbarsherlock.internal.view.menu.MenuBuilder;
import com.actionbarsherlock.internal.view.menu.MenuItemImpl;
import com.actionbarsherlock.internal.view.menu.MenuPresenter;
import com.actionbarsherlock.internal.widget.ActionBarContainer;
import com.actionbarsherlock.internal.widget.ActionBarContextView;
import com.actionbarsherlock.internal.widget.ActionBarView;
import com.actionbarsherlock.internal.widget.IcsProgressBar;
import com.actionbarsherlock.view.ActionMode;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.Window;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

@ActionBarSherlock.Implementation(api=7)
public class ActionBarSherlockCompat
extends ActionBarSherlock
implements MenuItem.OnMenuItemClickListener,
MenuBuilder.Callback,
MenuPresenter.Callback,
Window.Callback {
    protected static final int DEFAULT_FEATURES = 0;
    private static final String PANELS_TAG = "sherlock:Panels";
    private ActionBarImpl aActionBar;
    private ActionMode mActionMode;
    private ActionBarContextView mActionModeView;
    private IcsProgressBar mCircularProgressBar;
    private boolean mClosingActionMenu;
    private ViewGroup mContentParent;
    private ViewGroup mDecor;
    private int mFeatures = 0;
    private IcsProgressBar mHorizontalProgressBar;
    private boolean mIsDestroyed = false;
    private boolean mIsTitleReady = false;
    private MenuBuilder mMenu;
    private Bundle mMenuFrozenActionViewState;
    private boolean mMenuIsPrepared;
    private boolean mMenuRefreshContent;
    protected HashMap<android.view.MenuItem, MenuItemImpl> mNativeItemMap;
    private boolean mReserveOverflow;
    private boolean mReserveOverflowSet = false;
    private int mUiOptions = 0;
    private ActionBarView wActionBar;

    public ActionBarSherlockCompat(Activity activity, int n2) {
        super(activity, n2);
    }

    static /* synthetic */ void access$3(ActionBarSherlockCompat actionBarSherlockCompat, ActionMode actionMode) {
        actionBarSherlockCompat.mActionMode = actionMode;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String cleanActivityName(String string2, String string3) {
        if (string3.charAt(0) == '.') {
            return String.valueOf(string2) + string3;
        }
        String string4 = string3;
        if (string3.indexOf(46, 1) != -1) return string4;
        return String.valueOf(string2) + "." + string3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private ViewGroup generateLayout() {
        IcsProgressBar icsProgressBar;
        TypedArray typedArray = this.mActivity.getTheme().obtainStyledAttributes(R.styleable.SherlockTheme);
        if (!typedArray.hasValue(59)) {
            throw new IllegalStateException("You must use Theme.Sherlock, Theme.Sherlock.Light, Theme.Sherlock.Light.DarkActionBar, or a derivative.");
        }
        if (typedArray.getBoolean(58, false)) {
            this.requestFeature(1);
        } else if (typedArray.getBoolean(59, false)) {
            this.requestFeature(8);
        }
        if (typedArray.getBoolean(60, false)) {
            this.requestFeature(9);
        }
        if (typedArray.getBoolean(61, false)) {
            this.requestFeature(10);
        }
        typedArray.recycle();
        int n2 = !this.hasFeature(1) ? (this.hasFeature(9) ? R.layout.abs__screen_action_bar_overlay : R.layout.abs__screen_action_bar) : (this.hasFeature(10) && !this.hasFeature(1) ? R.layout.abs__screen_simple_overlay_action_mode : R.layout.abs__screen_simple);
        typedArray = this.mActivity.getLayoutInflater().inflate(n2, null);
        this.mDecor.addView((View)typedArray, new ViewGroup.LayoutParams(-1, -1));
        typedArray = (ViewGroup)this.mDecor.findViewById(R.id.abs__content);
        if (typedArray == null) {
            throw new RuntimeException("Couldn't find content container view");
        }
        this.mDecor.setId(-1);
        typedArray.setId(16908290);
        if (this.hasFeature(5) && (icsProgressBar = this.getCircularProgressBar(false)) != null) {
            icsProgressBar.setIndeterminate(true);
        }
        return typedArray;
    }

    private IcsProgressBar getCircularProgressBar(boolean bl) {
        if (this.mCircularProgressBar != null) {
            return this.mCircularProgressBar;
        }
        if (this.mContentParent == null && bl) {
            this.installDecor();
        }
        this.mCircularProgressBar = (IcsProgressBar)this.mDecor.findViewById(R.id.abs__progress_circular);
        if (this.mCircularProgressBar != null) {
            this.mCircularProgressBar.setVisibility(4);
        }
        return this.mCircularProgressBar;
    }

    private int getFeatures() {
        return this.mFeatures;
    }

    private IcsProgressBar getHorizontalProgressBar(boolean bl) {
        if (this.mHorizontalProgressBar != null) {
            return this.mHorizontalProgressBar;
        }
        if (this.mContentParent == null && bl) {
            this.installDecor();
        }
        this.mHorizontalProgressBar = (IcsProgressBar)this.mDecor.findViewById(R.id.abs__progress_horizontal);
        if (this.mHorizontalProgressBar != null) {
            this.mHorizontalProgressBar.setVisibility(4);
        }
        return this.mHorizontalProgressBar;
    }

    private void hideProgressBars(IcsProgressBar icsProgressBar, IcsProgressBar icsProgressBar2) {
        int n2 = this.mFeatures;
        Animation animation = AnimationUtils.loadAnimation((Context)this.mActivity, (int)17432577);
        animation.setDuration(1000);
        if ((n2 & 32) != 0 && icsProgressBar2.getVisibility() == 0) {
            icsProgressBar2.startAnimation(animation);
            icsProgressBar2.setVisibility(4);
        }
        if ((n2 & 4) != 0 && icsProgressBar.getVisibility() == 0) {
            icsProgressBar.startAnimation(animation);
            icsProgressBar.setVisibility(4);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void initActionBar() {
        if (this.mDecor == null) {
            this.installDecor();
        }
        if (this.aActionBar != null) return;
        if (!this.hasFeature(8)) return;
        if (this.hasFeature(1)) return;
        if (this.mActivity.isChild()) {
            return;
        }
        this.aActionBar = new ActionBarImpl(this.mActivity, this.mFeatures);
        if (this.mIsDelegate) return;
        this.wActionBar.setWindowTitle(this.mActivity.getTitle());
    }

    private boolean initializePanelMenu() {
        Activity activity = this.mActivity;
        if (this.wActionBar != null) {
            TypedValue typedValue = new TypedValue();
            activity.getTheme().resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
            int n2 = typedValue.resourceId;
            if (n2 != 0) {
                activity = new ContextThemeWrapper((Context)activity, n2);
            }
        }
        this.mMenu = new MenuBuilder((Context)activity);
        this.mMenu.setCallback(this);
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void installDecor() {
        if (this.mDecor == null) {
            this.mDecor = (ViewGroup)this.mActivity.getWindow().getDecorView().findViewById(16908290);
        }
        if (this.mContentParent != null) return;
        var5_1 = null;
        if (this.mDecor.getChildCount() <= 0) ** GOTO lbl11
        var5_1 = new ArrayList<E>(1);
        var2_2 = this.mDecor.getChildCount();
        var1_3 = 0;
        do {
            if (var1_3 < var2_2) ** GOTO lbl15
lbl11: // 2 sources:
            this.mContentParent = this.generateLayout();
            if (var5_1 != null) {
                break;
            }
            ** GOTO lbl-1000
lbl15: // 1 sources:
            var6_4 = this.mDecor.getChildAt(0);
            this.mDecor.removeView(var6_4);
            var5_1.add(var6_4);
            ++var1_3;
        } while (true);
        var5_1 = var5_1.iterator();
        do {
            if (!var5_1.hasNext()) lbl-1000: // 2 sources:
            {
                this.wActionBar = (ActionBarView)this.mDecor.findViewById(R.id.abs__action_bar);
                if (this.wActionBar == null) return;
                this.wActionBar.setWindowCallback(this);
                if (this.wActionBar.getTitle() == null) {
                    this.wActionBar.setWindowTitle(this.mActivity.getTitle());
                }
                if (this.hasFeature(2)) {
                    this.wActionBar.initProgress();
                }
                if (this.hasFeature(5)) {
                    this.wActionBar.initIndeterminateProgress();
                }
                if ((var1_3 = ActionBarSherlockCompat.loadUiOptionsFromManifest(this.mActivity)) != 0) {
                    this.mUiOptions = var1_3;
                }
                var3_5 = (this.mUiOptions & 1) != 0;
                var4_6 = var3_5 != false ? ResourcesCompat.getResources_getBoolean((Context)this.mActivity, R.bool.abs__split_action_bar_is_narrow) : this.mActivity.getTheme().obtainStyledAttributes(R.styleable.SherlockTheme).getBoolean(62, false);
                var5_1 = (ActionBarContainer)this.mDecor.findViewById(R.id.abs__split_action_bar);
                if (var5_1 != null) {
                    this.wActionBar.setSplitView((ActionBarContainer)var5_1);
                    this.wActionBar.setSplitActionBar(var4_6);
                    this.wActionBar.setSplitWhenNarrow(var3_5);
                    this.mActionModeView = (ActionBarContextView)this.mDecor.findViewById(R.id.abs__action_context_bar);
                    this.mActionModeView.setSplitView((ActionBarContainer)var5_1);
                    this.mActionModeView.setSplitActionBar(var4_6);
                    this.mActionModeView.setSplitWhenNarrow(var3_5);
                } else if (var4_6) {
                    Log.e((String)"ActionBarSherlock", (String)"Requested split action bar with incompatible window decor! Ignoring request.");
                }
                this.mDecor.post(new Runnable(){

                    @Override
                    public void run() {
                        if (!ActionBarSherlockCompat.this.mIsDestroyed && !ActionBarSherlockCompat.this.mActivity.isFinishing() && ActionBarSherlockCompat.this.mMenu == null) {
                            ActionBarSherlockCompat.this.dispatchInvalidateOptionsMenu();
                        }
                    }
                });
                return;
            }
            var6_4 = (View)var5_1.next();
            this.mContentParent.addView(var6_4);
        } while (true);
    }

    private boolean isReservingOverflow() {
        if (!this.mReserveOverflowSet) {
            this.mReserveOverflow = ActionMenuPresenter.reserveOverflow((Context)this.mActivity);
            this.mReserveOverflowSet = true;
        }
        return this.mReserveOverflow;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    private static int loadUiOptionsFromManifest(Activity var0) {
        block20 : {
            block17 : {
                block19 : {
                    block18 : {
                        var9_5 = var0.getClass().getName();
                        var10_6 = var0.getApplicationInfo().packageName;
                        var11_7 = var0.createPackageContext(var10_6, 0).getAssets().openXmlResourceParser("AndroidManifest.xml");
                        var2_8 = var11_7.getEventType();
                        var1_9 = 0;
                        do {
                            if (var2_8 == 1) {
                                var2_8 = var1_9;
lbl10: // 2 sources:
                                do {
                                    return var2_8;
                                    break;
                                } while (true);
                            }
                            var3_10 = var1_9;
                            if (var2_8 != 2) break block17;
                            var2_8 = var1_9;
                            var0 = var11_7.getName();
                            var2_8 = var1_9;
                            if (!"application".equals(var0)) ** GOTO lbl32
                            var2_8 = var1_9;
                            var3_10 = var11_7.getAttributeCount();
                            --var3_10;
lbl22: // 2 sources:
                            if (var3_10 >= 0) break;
lbl24: // 4 sources:
                            var2_8 = var11_7.nextToken();
                            continue;
                            break;
                        } while (true);
                        var2_8 = var1_9;
                        if (!"uiOptions".equals(var11_7.getAttributeName(var3_10))) break block18;
                        var2_8 = var1_9;
                        var1_9 = var11_7.getAttributeIntValue(var3_10, 0);
                        ** GOTO lbl24
lbl32: // 1 sources:
                        var2_8 = var1_9;
                        var3_10 = var1_9;
                        if (!"activity".equals(var0)) break block17;
                        var2_8 = var1_9;
                        var3_10 = var11_7.getAttributeCount() - 1;
                        var5_12 = false;
                        var0 = null;
                        var7_14 = null;
lbl40: // 2 sources:
                        if (var3_10 < 0) break block19;
                        var2_8 = var1_9;
                        var12_16 = var11_7.getAttributeName(var3_10);
                        var2_8 = var1_9;
                        if ("uiOptions".equals(var12_16)) {
                            var2_8 = var1_9;
                            var8_15 = var11_7.getAttributeIntValue(var3_10, 0);
                            var4_11 = var5_12;
lbl48: // 3 sources:
                            do {
                                var2_8 = var1_9;
                                if (var8_15 == null) break block20;
                                var2_8 = var1_9;
                                if (var0 == null) break block20;
                                var2_8 = var1_9;
                                var2_8 = var1_9 = var8_15.intValue();
                                break block20;
                                break;
                            } while (true);
                        }
                        var4_11 = var5_12;
                        var8_15 = var7_14;
                        var2_8 = var1_9;
                        if (!"name".equals(var12_16)) ** GOTO lbl48
                        var2_8 = var1_9;
                        var0 = ActionBarSherlockCompat.cleanActivityName(var10_6, var11_7.getAttributeValue(var3_10));
                        var2_8 = var1_9;
                        var6_13 = var9_5.equals(var0);
                        if (var6_13) {
                            var4_11 = true;
                            var8_15 = var7_14;
                            ** continue;
                        }
                        break block19;
                        catch (Exception var0_1) {
                            var2_8 = 0;
lbl71: // 3 sources:
                            do {
                                var0_2.printStackTrace();
                                return var2_8;
                                break;
                            } while (true);
                        }
                        catch (Exception var0_3) {
                            ** GOTO lbl71
                        }
                        catch (Exception var0_4) {
                            var2_8 = var1_9;
                            ** continue;
                        }
                    }
                    --var3_10;
                    ** GOTO lbl22
                }
                var2_8 = var1_9;
                ** while (var5_12)
lbl85: // 1 sources:
                var3_10 = var1_9;
            }
            var1_9 = var3_10;
            ** GOTO lbl24
        }
        --var3_10;
        var1_9 = var2_8;
        var5_12 = var4_11;
        var7_14 = var8_15;
        ** GOTO lbl40
    }

    private void onIntChanged(int n2, int n3) {
        if (n2 == 2 || n2 == 5) {
            this.updateProgressBars(n3);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean preparePanel() {
        boolean bl;
        boolean bl2 = false;
        boolean bl3 = false;
        if (this.mMenuIsPrepared) {
            return true;
        }
        if (this.mMenu == null || this.mMenuRefreshContent) {
            if (this.mMenu == null) {
                bl = bl3;
                if (!this.initializePanelMenu()) return bl;
                bl = bl3;
                if (this.mMenu == null) return bl;
            }
            if (this.wActionBar != null) {
                this.wActionBar.setMenu(this.mMenu, this);
            }
            this.mMenu.stopDispatchingItemsChanged();
            if (!this.callbackCreateOptionsMenu(this.mMenu)) {
                this.mMenu = null;
                bl = bl3;
                if (this.wActionBar == null) return bl;
                this.wActionBar.setMenu(null, this);
                return false;
            }
            this.mMenuRefreshContent = false;
        }
        this.mMenu.stopDispatchingItemsChanged();
        if (this.mMenuFrozenActionViewState != null) {
            this.mMenu.restoreActionViewStates(this.mMenuFrozenActionViewState);
            this.mMenuFrozenActionViewState = null;
        }
        if (!this.callbackPrepareOptionsMenu(this.mMenu)) {
            if (this.wActionBar != null) {
                this.wActionBar.setMenu(null, this);
            }
            this.mMenu.startDispatchingItemsChanged();
            return false;
        }
        KeyCharacterMap keyCharacterMap = KeyCharacterMap.load((int)-1);
        MenuBuilder menuBuilder = this.mMenu;
        bl = bl2;
        if (keyCharacterMap.getKeyboardType() != 1) {
            bl = true;
        }
        menuBuilder.setQwertyMode(bl);
        this.mMenu.startDispatchingItemsChanged();
        this.mMenuIsPrepared = true;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void reopenMenu(boolean bl) {
        if (this.wActionBar == null || !this.wActionBar.isOverflowReserved()) return;
        if (!this.wActionBar.isOverflowMenuShowing() || !bl) {
            if (this.wActionBar.getVisibility() != 0 || !this.callbackPrepareOptionsMenu(this.mMenu)) return;
            this.wActionBar.showOverflowMenu();
            return;
        }
        this.wActionBar.hideOverflowMenu();
    }

    private void setFeatureInt(int n2, int n3) {
        this.updateInt(n2, n3, false);
    }

    private void showProgressBars(IcsProgressBar icsProgressBar, IcsProgressBar icsProgressBar2) {
        int n2 = this.mFeatures;
        if ((n2 & 32) != 0 && icsProgressBar2.getVisibility() == 4) {
            icsProgressBar2.setVisibility(0);
        }
        if ((n2 & 4) != 0 && icsProgressBar.getProgress() < 10000) {
            icsProgressBar.setVisibility(0);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void updateInt(int n2, int n3, boolean bl) {
        if (this.mContentParent == null || (1 << n2 & this.getFeatures()) == 0 && !bl) {
            return;
        }
        this.onIntChanged(n2, n3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void updateProgressBars(int n2) {
        IcsProgressBar icsProgressBar = this.getCircularProgressBar(true);
        IcsProgressBar icsProgressBar2 = this.getHorizontalProgressBar(true);
        int n3 = this.mFeatures;
        if (n2 == -1) {
            if ((n3 & 4) != 0) {
                n2 = icsProgressBar2.getProgress();
                n2 = icsProgressBar2.isIndeterminate() || n2 < 10000 ? 0 : 4;
                icsProgressBar2.setVisibility(n2);
            }
            if ((n3 & 32) == 0) return;
            {
                icsProgressBar.setVisibility(0);
                return;
            }
        } else if (n2 == -2) {
            if ((n3 & 4) != 0) {
                icsProgressBar2.setVisibility(8);
            }
            if ((n3 & 32) == 0) return;
            {
                icsProgressBar.setVisibility(8);
                return;
            }
        } else {
            if (n2 == -3) {
                icsProgressBar2.setIndeterminate(true);
                return;
            }
            if (n2 == -4) {
                icsProgressBar2.setIndeterminate(false);
                return;
            }
            if (n2 >= 0 && n2 <= 10000) {
                icsProgressBar2.setProgress(n2);
                if (n2 < 10000) {
                    this.showProgressBars(icsProgressBar2, icsProgressBar);
                    return;
                }
                this.hideProgressBars(icsProgressBar2, icsProgressBar);
                return;
            }
            if (20000 > n2 || n2 > 30000) return;
            {
                icsProgressBar2.setSecondaryProgress(n2 - 20000);
                this.showProgressBars(icsProgressBar2, icsProgressBar);
                return;
            }
        }
    }

    @Override
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        if (this.mContentParent == null) {
            this.installDecor();
        }
        this.mContentParent.addView(view, layoutParams);
        this.initActionBar();
    }

    void checkCloseActionMenu(com.actionbarsherlock.view.Menu menu) {
        if (this.mClosingActionMenu) {
            return;
        }
        this.mClosingActionMenu = true;
        this.wActionBar.dismissPopupMenus();
        this.mClosingActionMenu = false;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean dispatchCloseOptionsMenu() {
        if (!this.isReservingOverflow() || this.wActionBar == null) {
            return false;
        }
        return this.wActionBar.hideOverflowMenu();
    }

    @Override
    public void dispatchConfigurationChanged(Configuration configuration) {
        if (this.aActionBar != null) {
            this.aActionBar.onConfigurationChanged(configuration);
        }
    }

    @Override
    public boolean dispatchCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public void dispatchDestroy() {
        this.mIsDestroyed = true;
    }

    @Override
    public void dispatchInvalidateOptionsMenu() {
        if (this.mMenu != null) {
            Bundle bundle = new Bundle();
            this.mMenu.saveActionViewStates(bundle);
            if (bundle.size() > 0) {
                this.mMenuFrozenActionViewState = bundle;
            }
            this.mMenu.stopDispatchingItemsChanged();
            this.mMenu.clear();
        }
        this.mMenuRefreshContent = true;
        if (this.wActionBar != null) {
            this.mMenuIsPrepared = false;
            this.preparePanel();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() != 4) return false;
        int n2 = keyEvent.getAction();
        if (this.mActionMode != null) {
            if (n2 != 1) return true;
            {
                this.mActionMode.finish();
            }
            return true;
        }
        if (this.wActionBar == null || !this.wActionBar.hasExpandedActionView()) return false;
        {
            if (n2 != 1) return true;
            {
                this.wActionBar.collapseActionView();
                return true;
            }
        }
    }

    @Override
    public boolean dispatchMenuOpened(int n2, Menu menu) {
        if (n2 == 8 || n2 == 0) {
            if (this.aActionBar != null) {
                this.aActionBar.dispatchMenuVisibilityChanged(true);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean dispatchOpenOptionsMenu() {
        if (!this.isReservingOverflow()) {
            return false;
        }
        return this.wActionBar.showOverflowMenu();
    }

    @Override
    public boolean dispatchOptionsItemSelected(android.view.MenuItem menuItem) {
        throw new IllegalStateException("Native callback invoked. Create a test case and report!");
    }

    @Override
    public void dispatchPanelClosed(int n2, Menu menu) {
        if ((n2 == 8 || n2 == 0) && this.aActionBar != null) {
            this.aActionBar.dispatchMenuVisibilityChanged(false);
        }
    }

    @Override
    public void dispatchPause() {
        if (this.wActionBar != null && this.wActionBar.isOverflowMenuShowing()) {
            this.wActionBar.hideOverflowMenu();
        }
    }

    @Override
    public void dispatchPostCreate(Bundle bundle) {
        if (this.mIsDelegate) {
            this.mIsTitleReady = true;
        }
        if (this.mDecor == null) {
            this.initActionBar();
        }
    }

    @Override
    public void dispatchPostResume() {
        if (this.aActionBar != null) {
            this.aActionBar.setShowHideAnimationEnabled(true);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean dispatchPrepareOptionsMenu(Menu menu) {
        if (this.mActionMode != null) {
            return false;
        }
        this.mMenuIsPrepared = false;
        if (!this.preparePanel()) return false;
        if (this.isReservingOverflow()) return false;
        if (this.mNativeItemMap == null) {
            this.mNativeItemMap = new HashMap();
        } else {
            this.mNativeItemMap.clear();
        }
        if (this.mMenu == null) return false;
        return this.mMenu.bindNativeOverflow(menu, this, this.mNativeItemMap);
    }

    @Override
    public void dispatchRestoreInstanceState(Bundle bundle) {
        this.mMenuFrozenActionViewState = (Bundle)bundle.getParcelable("sherlock:Panels");
    }

    @Override
    public void dispatchSaveInstanceState(Bundle bundle) {
        if (this.mMenu != null) {
            this.mMenuFrozenActionViewState = new Bundle();
            this.mMenu.saveActionViewStates(this.mMenuFrozenActionViewState);
        }
        bundle.putParcelable("sherlock:Panels", (Parcelable)this.mMenuFrozenActionViewState);
    }

    @Override
    public void dispatchStop() {
        if (this.aActionBar != null) {
            this.aActionBar.setShowHideAnimationEnabled(false);
        }
    }

    @Override
    public void dispatchTitleChanged(CharSequence charSequence, int n2) {
        if ((!this.mIsDelegate || this.mIsTitleReady) && this.wActionBar != null) {
            this.wActionBar.setWindowTitle(charSequence);
        }
    }

    @Override
    public void ensureActionBar() {
        if (this.mDecor == null) {
            this.initActionBar();
        }
    }

    @Override
    public ActionBar getActionBar() {
        this.initActionBar();
        return this.aActionBar;
    }

    @Override
    protected Context getThemedContext() {
        return this.aActionBar.getThemedContext();
    }

    @Override
    public boolean hasFeature(int n2) {
        if ((this.mFeatures & 1 << n2) != 0) {
            return true;
        }
        return false;
    }

    @Override
    public void onCloseMenu(MenuBuilder menuBuilder, boolean bl) {
        this.checkCloseActionMenu(menuBuilder);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean onMenuItemClick(android.view.MenuItem menuItem) {
        MenuItemImpl menuItemImpl = this.mNativeItemMap.get((Object)menuItem);
        if (menuItemImpl != null) {
            menuItemImpl.invoke();
            do {
                return true;
                break;
            } while (true);
        }
        Log.e((String)"ActionBarSherlock", (String)("Options item \"" + (Object)menuItem + "\" not found in mapping"));
        return true;
    }

    @Override
    public boolean onMenuItemSelected(int n2, MenuItem menuItem) {
        return this.callbackOptionsItemSelected(menuItem);
    }

    @Override
    public boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
        return this.callbackOptionsItemSelected(menuItem);
    }

    @Override
    public void onMenuModeChange(MenuBuilder menuBuilder) {
        this.reopenMenu(true);
    }

    @Override
    public boolean onOpenSubMenu(MenuBuilder menuBuilder) {
        return true;
    }

    @Override
    public boolean requestFeature(int n2) {
        if (this.mContentParent != null) {
            throw new AndroidRuntimeException("requestFeature() must be called before adding content");
        }
        switch (n2) {
            default: {
                return false;
            }
            case 1: 
            case 2: 
            case 5: 
            case 8: 
            case 9: 
            case 10: 
        }
        this.mFeatures |= 1 << n2;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setContentView(int n2) {
        if (this.mContentParent == null) {
            this.installDecor();
        } else {
            this.mContentParent.removeAllViews();
        }
        this.mActivity.getLayoutInflater().inflate(n2, this.mContentParent);
        Window.Callback callback = this.mActivity.getWindow().getCallback();
        if (callback != null) {
            callback.onContentChanged();
        }
        this.initActionBar();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        if (this.mContentParent == null) {
            this.installDecor();
        } else {
            this.mContentParent.removeAllViews();
        }
        this.mContentParent.addView(view, layoutParams);
        view = this.mActivity.getWindow().getCallback();
        if (view != null) {
            view.onContentChanged();
        }
        this.initActionBar();
    }

    @Override
    public void setProgress(int n2) {
        this.updateInt(2, n2, false);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setProgressBarIndeterminate(boolean bl) {
        int n2 = bl ? -3 : -4;
        this.updateInt(2, n2, false);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setProgressBarIndeterminateVisibility(boolean bl) {
        int n2 = bl ? -1 : -2;
        this.updateInt(5, n2, false);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setProgressBarVisibility(boolean bl) {
        int n2 = bl ? -1 : -2;
        this.updateInt(2, n2, false);
    }

    @Override
    public void setSecondaryProgress(int n2) {
        this.updateInt(2, n2 + 20000, false);
    }

    @Override
    public void setTitle(CharSequence charSequence) {
        this.dispatchTitleChanged(charSequence, 0);
    }

    @Override
    public void setUiOptions(int n2) {
        this.mUiOptions = n2;
    }

    @Override
    public void setUiOptions(int n2, int n3) {
        this.mUiOptions = this.mUiOptions & ~ n3 | n2 & n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public ActionMode startActionMode(ActionMode.Callback callback) {
        if (this.mActionMode != null) {
            this.mActionMode.finish();
        }
        ActionModeCallbackWrapper actionModeCallbackWrapper = new ActionModeCallbackWrapper(callback);
        this.initActionBar();
        ActionMode actionMode = this.aActionBar != null ? this.aActionBar.startActionMode(actionModeCallbackWrapper) : null;
        if (actionMode != null) {
            this.mActionMode = actionMode;
        } else {
            if (this.mActionModeView == null && (actionMode = (ViewStub)this.mDecor.findViewById(R.id.abs__action_mode_bar_stub)) != null) {
                this.mActionModeView = (ActionBarContextView)actionMode.inflate();
            }
            if (this.mActionModeView != null) {
                this.mActionModeView.killMode();
                actionMode = new StandaloneActionMode((Context)this.mActivity, this.mActionModeView, actionModeCallbackWrapper, true);
                if (callback.onCreateActionMode(actionMode, actionMode.getMenu())) {
                    actionMode.invalidate();
                    this.mActionModeView.initForMode(actionMode);
                    this.mActionModeView.setVisibility(0);
                    this.mActionMode = actionMode;
                    this.mActionModeView.sendAccessibilityEvent(32);
                } else {
                    this.mActionMode = null;
                }
            }
        }
        if (this.mActionMode != null && this.mActivity instanceof ActionBarSherlock.OnActionModeStartedListener) {
            ((ActionBarSherlock.OnActionModeStartedListener)this.mActivity).onActionModeStarted(this.mActionMode);
        }
        return this.mActionMode;
    }

    class ActionModeCallbackWrapper
    implements ActionMode.Callback {
        private final ActionMode.Callback mWrapped;

        public ActionModeCallbackWrapper(ActionMode.Callback callback) {
            this.mWrapped = callback;
        }

        @Override
        public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            return this.mWrapped.onActionItemClicked(actionMode, menuItem);
        }

        @Override
        public boolean onCreateActionMode(ActionMode actionMode, com.actionbarsherlock.view.Menu menu) {
            return this.mWrapped.onCreateActionMode(actionMode, menu);
        }

        @Override
        public void onDestroyActionMode(ActionMode actionMode) {
            this.mWrapped.onDestroyActionMode(actionMode);
            if (ActionBarSherlockCompat.this.mActionModeView != null) {
                ActionBarSherlockCompat.this.mActionModeView.setVisibility(8);
                ActionBarSherlockCompat.this.mActionModeView.removeAllViews();
            }
            if (ActionBarSherlockCompat.this.mActivity instanceof ActionBarSherlock.OnActionModeFinishedListener) {
                ((ActionBarSherlock.OnActionModeFinishedListener)ActionBarSherlockCompat.this.mActivity).onActionModeFinished(ActionBarSherlockCompat.this.mActionMode);
            }
            ActionBarSherlockCompat.access$3(ActionBarSherlockCompat.this, null);
        }

        @Override
        public boolean onPrepareActionMode(ActionMode actionMode, com.actionbarsherlock.view.Menu menu) {
            return this.mWrapped.onPrepareActionMode(actionMode, menu);
        }
    }

}

