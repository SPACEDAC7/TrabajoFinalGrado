/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.ActionBar
 *  android.app.Activity
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.util.TypedValue
 *  android.view.ActionMode
 *  android.view.ActionMode$Callback
 *  android.view.ContextThemeWrapper
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.Window
 */
package com.actionbarsherlock.internal;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import com.actionbarsherlock.ActionBarSherlock;
import com.actionbarsherlock.internal.app.ActionBarWrapper;
import com.actionbarsherlock.internal.view.menu.MenuItemWrapper;
import com.actionbarsherlock.internal.view.menu.MenuWrapper;
import com.actionbarsherlock.view.ActionMode;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;

@ActionBarSherlock.Implementation(api=14)
public class ActionBarSherlockNative
extends ActionBarSherlock {
    private ActionBarWrapper mActionBar;
    private ActionModeWrapper mActionMode;
    private MenuWrapper mMenu;

    public ActionBarSherlockNative(Activity activity, int n2) {
        super(activity, n2);
    }

    static /* synthetic */ void access$0(ActionBarSherlockNative actionBarSherlockNative, ActionModeWrapper actionModeWrapper) {
        actionBarSherlockNative.mActionMode = actionModeWrapper;
    }

    private void initActionBar() {
        if (this.mActionBar != null || this.mActivity.getActionBar() == null) {
            return;
        }
        this.mActionBar = new ActionBarWrapper(this.mActivity);
    }

    @Override
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        this.mActivity.getWindow().addContentView(view, layoutParams);
        this.initActionBar();
    }

    @Override
    public boolean dispatchCreateOptionsMenu(android.view.Menu menu) {
        if (this.mMenu == null || menu != this.mMenu.unwrap()) {
            this.mMenu = new MenuWrapper(menu);
        }
        return this.callbackCreateOptionsMenu(this.mMenu);
    }

    @Override
    public void dispatchInvalidateOptionsMenu() {
        this.mActivity.getWindow().invalidatePanelMenu(0);
        if (this.mMenu != null) {
            this.mMenu.invalidate();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean dispatchOptionsItemSelected(MenuItem object) {
        if (this.mMenu == null) {
            if (object.getItemId() != 16908332) {
                throw new IllegalStateException("Non-home action item clicked before onCreateOptionsMenu with ID " + object.getItemId());
            }
            object = new MenuItemWrapper((MenuItem)object);
            do {
                return this.callbackOptionsItemSelected((com.actionbarsherlock.view.MenuItem)object);
                break;
            } while (true);
        }
        object = this.mMenu.findItem((MenuItem)object);
        return this.callbackOptionsItemSelected((com.actionbarsherlock.view.MenuItem)object);
    }

    @Override
    public boolean dispatchPrepareOptionsMenu(android.view.Menu menu) {
        return this.callbackPrepareOptionsMenu(this.mMenu);
    }

    @Override
    public com.actionbarsherlock.app.ActionBar getActionBar() {
        this.initActionBar();
        return this.mActionBar;
    }

    @Override
    protected Context getThemedContext() {
        Activity activity = this.mActivity;
        TypedValue typedValue = new TypedValue();
        this.mActivity.getTheme().resolveAttribute(16843671, typedValue, true);
        if (typedValue.resourceId != 0) {
            return new ContextThemeWrapper((Context)activity, typedValue.resourceId);
        }
        return activity;
    }

    @Override
    public boolean hasFeature(int n2) {
        return this.mActivity.getWindow().hasFeature(n2);
    }

    @Override
    public boolean requestFeature(int n2) {
        return this.mActivity.getWindow().requestFeature(n2);
    }

    @Override
    public void setContentView(int n2) {
        this.mActivity.getWindow().setContentView(n2);
        this.initActionBar();
    }

    @Override
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        this.mActivity.getWindow().setContentView(view, layoutParams);
        this.initActionBar();
    }

    @Override
    public void setProgress(int n2) {
        this.mActivity.setProgress(n2);
    }

    @Override
    public void setProgressBarIndeterminate(boolean bl) {
        this.mActivity.setProgressBarIndeterminate(bl);
    }

    @Override
    public void setProgressBarIndeterminateVisibility(boolean bl) {
        this.mActivity.setProgressBarIndeterminateVisibility(bl);
    }

    @Override
    public void setProgressBarVisibility(boolean bl) {
        this.mActivity.setProgressBarVisibility(bl);
    }

    @Override
    public void setSecondaryProgress(int n2) {
        this.mActivity.setSecondaryProgress(n2);
    }

    @Override
    public void setTitle(CharSequence charSequence) {
        this.mActivity.getWindow().setTitle(charSequence);
    }

    @Override
    public void setUiOptions(int n2) {
        this.mActivity.getWindow().setUiOptions(n2);
    }

    @Override
    public void setUiOptions(int n2, int n3) {
        this.mActivity.getWindow().setUiOptions(n2, n3);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public ActionMode startActionMode(ActionMode.Callback object) {
        if (this.mActionMode != null) {
            this.mActionMode.finish();
        }
        object = object != null ? new ActionModeCallbackWrapper((ActionMode.Callback)object) : null;
        if (this.mActivity.startActionMode((ActionMode.Callback)object) == null) {
            this.mActionMode = null;
        }
        if (this.mActivity instanceof ActionBarSherlock.OnActionModeStartedListener && this.mActionMode != null) {
            ((ActionBarSherlock.OnActionModeStartedListener)this.mActivity).onActionModeStarted(this.mActionMode);
        }
        return this.mActionMode;
    }

    class ActionModeCallbackWrapper
    implements ActionMode.Callback {
        private final ActionMode.Callback mCallback;

        public ActionModeCallbackWrapper(ActionMode.Callback callback) {
            this.mCallback = callback;
        }

        public boolean onActionItemClicked(android.view.ActionMode actionMode, MenuItem menuItem) {
            return this.mCallback.onActionItemClicked(ActionBarSherlockNative.this.mActionMode, ActionBarSherlockNative.this.mActionMode.getMenu().findItem(menuItem));
        }

        public boolean onCreateActionMode(android.view.ActionMode actionMode, android.view.Menu menu) {
            ActionBarSherlockNative.access$0(ActionBarSherlockNative.this, new ActionModeWrapper(actionMode));
            return this.mCallback.onCreateActionMode(ActionBarSherlockNative.this.mActionMode, ActionBarSherlockNative.this.mActionMode.getMenu());
        }

        public void onDestroyActionMode(android.view.ActionMode actionMode) {
            this.mCallback.onDestroyActionMode(ActionBarSherlockNative.this.mActionMode);
            if (ActionBarSherlockNative.this.mActivity instanceof ActionBarSherlock.OnActionModeFinishedListener) {
                ((ActionBarSherlock.OnActionModeFinishedListener)ActionBarSherlockNative.this.mActivity).onActionModeFinished(ActionBarSherlockNative.this.mActionMode);
            }
        }

        public boolean onPrepareActionMode(android.view.ActionMode actionMode, android.view.Menu menu) {
            return this.mCallback.onPrepareActionMode(ActionBarSherlockNative.this.mActionMode, ActionBarSherlockNative.this.mActionMode.getMenu());
        }
    }

    class ActionModeWrapper
    extends ActionMode {
        private final android.view.ActionMode mActionMode;
        private MenuWrapper mMenu;

        ActionModeWrapper(android.view.ActionMode actionMode) {
            this.mMenu = null;
            this.mActionMode = actionMode;
        }

        @Override
        public void finish() {
            this.mActionMode.finish();
        }

        @Override
        public View getCustomView() {
            return this.mActionMode.getCustomView();
        }

        @Override
        public MenuWrapper getMenu() {
            if (this.mMenu == null) {
                this.mMenu = new MenuWrapper(this.mActionMode.getMenu());
            }
            return this.mMenu;
        }

        @Override
        public MenuInflater getMenuInflater() {
            return ActionBarSherlockNative.this.getMenuInflater();
        }

        @Override
        public CharSequence getSubtitle() {
            return this.mActionMode.getSubtitle();
        }

        @Override
        public Object getTag() {
            return this.mActionMode.getTag();
        }

        @Override
        public CharSequence getTitle() {
            return this.mActionMode.getTitle();
        }

        @Override
        public void invalidate() {
            this.mActionMode.invalidate();
            if (this.mMenu != null) {
                this.mMenu.invalidate();
            }
        }

        @Override
        public void setCustomView(View view) {
            this.mActionMode.setCustomView(view);
        }

        @Override
        public void setSubtitle(int n2) {
            this.mActionMode.setSubtitle(n2);
        }

        @Override
        public void setSubtitle(CharSequence charSequence) {
            this.mActionMode.setSubtitle(charSequence);
        }

        @Override
        public void setTag(Object object) {
            this.mActionMode.setTag(object);
        }

        @Override
        public void setTitle(int n2) {
            this.mActionMode.setTitle(n2);
        }

        @Override
        public void setTitle(CharSequence charSequence) {
            this.mActionMode.setTitle(charSequence);
        }
    }

}

