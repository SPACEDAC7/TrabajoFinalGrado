/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.content.res.XmlResourceParser
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.DisplayMetrics
 */
package com.actionbarsherlock.internal;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.os.Build;
import android.util.DisplayMetrics;
import com.actionbarsherlock.R;
import com.actionbarsherlock.internal.ActionBarSherlockCompat;

public final class ResourcesCompat {
    private static final String TAG = "ResourcesCompat";

    private ResourcesCompat() {
    }

    public static boolean getResources_getBoolean(Context context, int n2) {
        float f2;
        if (Build.VERSION.SDK_INT >= 14) {
            return context.getResources().getBoolean(n2);
        }
        context = context.getResources().getDisplayMetrics();
        float f3 = (float)context.widthPixels / context.density;
        float f4 = f2 = (float)context.heightPixels / context.density;
        if (f3 < f2) {
            f4 = f3;
        }
        if (n2 == R.bool.abs__action_bar_embed_tabs) {
            if (f3 >= 480.0f) {
                return true;
            }
            return false;
        }
        if (n2 == R.bool.abs__split_action_bar_is_narrow) {
            if (f3 >= 480.0f) {
                return false;
            }
            return true;
        }
        if (n2 == R.bool.abs__action_bar_expanded_action_views_exclusive) {
            if (f4 >= 600.0f) {
                return false;
            }
            return true;
        }
        if (n2 == R.bool.abs__config_allowActionMenuItemTextWithIcon) {
            if (f3 >= 480.0f) {
                return true;
            }
            return false;
        }
        throw new IllegalArgumentException("Unknown boolean resource ID " + n2);
    }

    public static int getResources_getInteger(Context context, int n2) {
        if (Build.VERSION.SDK_INT >= 13) {
            return context.getResources().getInteger(n2);
        }
        context = context.getResources().getDisplayMetrics();
        float f2 = (float)context.widthPixels / context.density;
        if (n2 == R.integer.abs__max_action_buttons) {
            if (f2 >= 600.0f) {
                return 5;
            }
            if (f2 >= 500.0f) {
                return 4;
            }
            if (f2 >= 360.0f) {
                return 3;
            }
            return 2;
        }
        throw new IllegalArgumentException("Unknown integer resource ID " + n2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    public static int loadLogoFromManifest(Activity var0) {
        block20 : {
            block17 : {
                block19 : {
                    block18 : {
                        var9_5 = var0.getClass().getName();
                        var10_6 = var0.getApplicationInfo().packageName;
                        var11_7 = var0.createPackageContext(var10_6, 0).getAssets().openXmlResourceParser("AndroidManifest.xml");
                        var2_8 = var11_7.getEventType();
                        var1_9 = 0;
                        do {
                            if (var2_8 == 1) {
                                var2_8 = var1_9;
lbl10: // 2 sources:
                                do {
                                    return var2_8;
                                    break;
                                } while (true);
                            }
                            var3_10 = var1_9;
                            if (var2_8 != 2) break block17;
                            var2_8 = var1_9;
                            var0 = var11_7.getName();
                            var2_8 = var1_9;
                            if (!"application".equals(var0)) ** GOTO lbl32
                            var2_8 = var1_9;
                            var3_10 = var11_7.getAttributeCount();
                            --var3_10;
lbl22: // 2 sources:
                            if (var3_10 >= 0) break;
lbl24: // 4 sources:
                            var2_8 = var11_7.nextToken();
                            continue;
                            break;
                        } while (true);
                        var2_8 = var1_9;
                        if (!"logo".equals(var11_7.getAttributeName(var3_10))) break block18;
                        var2_8 = var1_9;
                        var1_9 = var11_7.getAttributeResourceValue(var3_10, 0);
                        ** GOTO lbl24
lbl32: // 1 sources:
                        var2_8 = var1_9;
                        var3_10 = var1_9;
                        if (!"activity".equals(var0)) break block17;
                        var2_8 = var1_9;
                        var3_10 = var11_7.getAttributeCount() - 1;
                        var5_12 = false;
                        var0 = null;
                        var7_14 = null;
lbl40: // 2 sources:
                        if (var3_10 < 0) break block19;
                        var2_8 = var1_9;
                        var12_16 = var11_7.getAttributeName(var3_10);
                        var2_8 = var1_9;
                        if ("logo".equals(var12_16)) {
                            var2_8 = var1_9;
                            var8_15 = var11_7.getAttributeResourceValue(var3_10, 0);
                            var4_11 = var5_12;
lbl48: // 3 sources:
                            do {
                                var2_8 = var1_9;
                                if (var8_15 == null) break block20;
                                var2_8 = var1_9;
                                if (var0 == null) break block20;
                                var2_8 = var1_9;
                                var2_8 = var1_9 = var8_15.intValue();
                                break block20;
                                break;
                            } while (true);
                        }
                        var4_11 = var5_12;
                        var8_15 = var7_14;
                        var2_8 = var1_9;
                        if (!"name".equals(var12_16)) ** GOTO lbl48
                        var2_8 = var1_9;
                        var0 = ActionBarSherlockCompat.cleanActivityName(var10_6, var11_7.getAttributeValue(var3_10));
                        var2_8 = var1_9;
                        var6_13 = var9_5.equals(var0);
                        if (var6_13) {
                            var4_11 = true;
                            var8_15 = var7_14;
                            ** continue;
                        }
                        break block19;
                        catch (Exception var0_1) {
                            var2_8 = 0;
lbl71: // 3 sources:
                            do {
                                var0_2.printStackTrace();
                                return var2_8;
                                break;
                            } while (true);
                        }
                        catch (Exception var0_3) {
                            ** GOTO lbl71
                        }
                        catch (Exception var0_4) {
                            var2_8 = var1_9;
                            ** continue;
                        }
                    }
                    --var3_10;
                    ** GOTO lbl22
                }
                var2_8 = var1_9;
                ** while (var5_12)
lbl85: // 1 sources:
                var3_10 = var1_9;
            }
            var1_9 = var3_10;
            ** GOTO lbl24
        }
        --var3_10;
        var1_9 = var2_8;
        var5_12 = var4_11;
        var7_14 = var8_15;
        ** GOTO lbl40
    }
}

