/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.util.TypedValue
 *  android.view.ContextThemeWrapper
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.Window
 *  android.widget.SpinnerAdapter
 */
package com.actionbarsherlock.internal.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.SpinnerAdapter;
import com.actionbarsherlock.R;
import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.internal.ResourcesCompat;
import com.actionbarsherlock.internal.nineoldandroids.animation.Animator;
import com.actionbarsherlock.internal.nineoldandroids.animation.AnimatorListenerAdapter;
import com.actionbarsherlock.internal.nineoldandroids.animation.AnimatorSet;
import com.actionbarsherlock.internal.nineoldandroids.animation.ObjectAnimator;
import com.actionbarsherlock.internal.nineoldandroids.widget.NineFrameLayout;
import com.actionbarsherlock.internal.view.menu.MenuBuilder;
import com.actionbarsherlock.internal.view.menu.MenuPopupHelper;
import com.actionbarsherlock.internal.view.menu.SubMenuBuilder;
import com.actionbarsherlock.internal.widget.ActionBarContainer;
import com.actionbarsherlock.internal.widget.ActionBarContextView;
import com.actionbarsherlock.internal.widget.ActionBarView;
import com.actionbarsherlock.internal.widget.ScrollingTabContainerView;
import com.actionbarsherlock.view.ActionMode;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class ActionBarImpl
extends ActionBar {
    private static final int CONTEXT_DISPLAY_NORMAL = 0;
    private static final int CONTEXT_DISPLAY_SPLIT = 1;
    private static final int INVALID_POSITION = -1;
    ActionModeImpl mActionMode;
    private ActionBarView mActionView;
    private Activity mActivity;
    private ActionBarContainer mContainerView;
    private NineFrameLayout mContentView;
    private Context mContext;
    private int mContextDisplayMode;
    private ActionBarContextView mContextView;
    private Animator mCurrentModeAnim;
    private Animator mCurrentShowAnim;
    ActionMode mDeferredDestroyActionMode;
    ActionMode.Callback mDeferredModeDestroyCallback;
    final Handler mHandler = new Handler();
    private boolean mHasEmbeddedTabs;
    final Animator.AnimatorListener mHideListener;
    private boolean mLastMenuVisibility;
    private ArrayList<ActionBar.OnMenuVisibilityListener> mMenuVisibilityListeners = new ArrayList();
    private int mSavedTabPosition = -1;
    private TabImpl mSelectedTab;
    private boolean mShowHideAnimationEnabled;
    final Animator.AnimatorListener mShowListener;
    private ActionBarContainer mSplitView;
    private ScrollingTabContainerView mTabScrollView;
    Runnable mTabSelector;
    private ArrayList<TabImpl> mTabs = new ArrayList();
    private Context mThemedContext;
    boolean mWasHiddenBeforeMode;

    public ActionBarImpl(Activity activity, int n2) {
        this.mHideListener = new AnimatorListenerAdapter(){

            @Override
            public void onAnimationEnd(Animator animator) {
                if (ActionBarImpl.this.mContentView != null) {
                    ActionBarImpl.this.mContentView.setTranslationY(0.0f);
                    ActionBarImpl.this.mContainerView.setTranslationY(0.0f);
                }
                if (ActionBarImpl.this.mSplitView != null && ActionBarImpl.this.mContextDisplayMode == 1) {
                    ActionBarImpl.this.mSplitView.setVisibility(8);
                }
                ActionBarImpl.this.mContainerView.setVisibility(8);
                ActionBarImpl.this.mContainerView.setTransitioning(false);
                ActionBarImpl.access$4(ActionBarImpl.this, null);
                ActionBarImpl.this.completeDeferredDestroyActionMode();
            }
        };
        this.mShowListener = new AnimatorListenerAdapter(){

            @Override
            public void onAnimationEnd(Animator animator) {
                ActionBarImpl.access$4(ActionBarImpl.this, null);
                ActionBarImpl.this.mContainerView.requestLayout();
            }
        };
        this.mActivity = activity;
        activity = activity.getWindow().getDecorView();
        this.init((View)activity);
        if ((n2 & 512) == 0) {
            this.mContentView = (NineFrameLayout)activity.findViewById(16908290);
        }
    }

    public ActionBarImpl(Dialog dialog) {
        this.mHideListener = new ;
        this.mShowListener = new ;
        this.init(dialog.getWindow().getDecorView());
    }

    static /* synthetic */ void access$4(ActionBarImpl actionBarImpl, Animator animator) {
        actionBarImpl.mCurrentShowAnim = animator;
    }

    private void cleanupTabs() {
        if (this.mSelectedTab != null) {
            this.selectTab(null);
        }
        this.mTabs.clear();
        if (this.mTabScrollView != null) {
            this.mTabScrollView.removeAllTabs();
        }
        this.mSavedTabPosition = -1;
    }

    private void configureTab(ActionBar.Tab tab, int n2) {
        if ((tab = (TabImpl)tab).getCallback() == null) {
            throw new IllegalStateException("Action Bar Tab must have a Callback");
        }
        tab.setPosition(n2);
        this.mTabs.add(n2, (TabImpl)tab);
        int n3 = this.mTabs.size();
        ++n2;
        while (n2 < n3) {
            this.mTabs.get(n2).setPosition(n2);
            ++n2;
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void ensureTabsExist() {
        int n2 = 0;
        if (this.mTabScrollView != null) {
            return;
        }
        ScrollingTabContainerView scrollingTabContainerView = new ScrollingTabContainerView(this.mContext);
        if (this.mHasEmbeddedTabs) {
            scrollingTabContainerView.setVisibility(0);
            this.mActionView.setEmbeddedTabView(scrollingTabContainerView);
        } else {
            if (this.getNavigationMode() != 2) {
                n2 = 8;
            }
            scrollingTabContainerView.setVisibility(n2);
            this.mContainerView.setTabContainer(scrollingTabContainerView);
        }
        this.mTabScrollView = scrollingTabContainerView;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void init(View view) {
        int n2 = 1;
        this.mContext = view.getContext();
        this.mActionView = (ActionBarView)view.findViewById(R.id.abs__action_bar);
        this.mContextView = (ActionBarContextView)view.findViewById(R.id.abs__action_context_bar);
        this.mContainerView = (ActionBarContainer)view.findViewById(R.id.abs__action_bar_container);
        this.mSplitView = (ActionBarContainer)view.findViewById(R.id.abs__split_action_bar);
        if (this.mActionView == null || this.mContextView == null || this.mContainerView == null) {
            throw new IllegalStateException(String.valueOf(this.getClass().getSimpleName()) + " can only be used with a compatible window decor layout");
        }
        this.mActionView.setContextView(this.mContextView);
        int n3 = this.mActionView.isSplitActionBar() ? 1 : 0;
        this.mContextDisplayMode = n3;
        n3 = this.mContext.getApplicationInfo().targetSdkVersion < 14 ? 1 : 0;
        if ((this.mActionView.getDisplayOptions() & 4) == 0) {
            n2 = 0;
        }
        this.setHomeButtonEnabled((boolean)(n3 | n2));
        this.setHasEmbeddedTabs(ResourcesCompat.getResources_getBoolean(this.mContext, R.bool.abs__action_bar_embed_tabs));
    }

    /*
     * Enabled aggressive block sorting
     */
    private void setHasEmbeddedTabs(boolean bl) {
        Object object;
        boolean bl2 = true;
        this.mHasEmbeddedTabs = bl;
        if (!this.mHasEmbeddedTabs) {
            this.mActionView.setEmbeddedTabView(null);
            this.mContainerView.setTabContainer(this.mTabScrollView);
        } else {
            this.mContainerView.setTabContainer(null);
            this.mActionView.setEmbeddedTabView(this.mTabScrollView);
        }
        boolean bl3 = this.getNavigationMode() == 2;
        if (this.mTabScrollView != null) {
            object = this.mTabScrollView;
            int n2 = bl3 ? 0 : 8;
            object.setVisibility(n2);
        }
        object = this.mActionView;
        bl = !this.mHasEmbeddedTabs && bl3 ? bl2 : false;
        object.setCollapsable(bl);
    }

    @Override
    public void addOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener onMenuVisibilityListener) {
        this.mMenuVisibilityListeners.add(onMenuVisibilityListener);
    }

    @Override
    public void addTab(ActionBar.Tab tab) {
        this.addTab(tab, this.mTabs.isEmpty());
    }

    @Override
    public void addTab(ActionBar.Tab tab, int n2) {
        this.addTab(tab, n2, this.mTabs.isEmpty());
    }

    @Override
    public void addTab(ActionBar.Tab tab, int n2, boolean bl) {
        this.ensureTabsExist();
        this.mTabScrollView.addTab(tab, n2, bl);
        this.configureTab(tab, n2);
        if (bl) {
            this.selectTab(tab);
        }
    }

    @Override
    public void addTab(ActionBar.Tab tab, boolean bl) {
        this.ensureTabsExist();
        this.mTabScrollView.addTab(tab, bl);
        this.configureTab(tab, this.mTabs.size());
        if (bl) {
            this.selectTab(tab);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void animateToMode(boolean bl) {
        int n2 = 8;
        if (bl) {
            this.show(false);
        }
        if (this.mCurrentModeAnim != null) {
            this.mCurrentModeAnim.end();
        }
        Object object = this.mActionView;
        int n3 = bl ? 8 : 0;
        object.animateToVisibility(n3);
        object = this.mContextView;
        n3 = bl ? 0 : 8;
        object.animateToVisibility(n3);
        if (this.mTabScrollView != null && !this.mActionView.hasEmbeddedTabs() && this.mActionView.isCollapsed()) {
            object = this.mTabScrollView;
            n3 = bl ? n2 : 0;
            object.animateToVisibility(n3);
        }
    }

    void completeDeferredDestroyActionMode() {
        if (this.mDeferredModeDestroyCallback != null) {
            this.mDeferredModeDestroyCallback.onDestroyActionMode(this.mDeferredDestroyActionMode);
            this.mDeferredDestroyActionMode = null;
            this.mDeferredModeDestroyCallback = null;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void dispatchMenuVisibilityChanged(boolean bl) {
        if (bl == this.mLastMenuVisibility) {
            return;
        }
        this.mLastMenuVisibility = bl;
        int n2 = this.mMenuVisibilityListeners.size();
        int n3 = 0;
        while (n3 < n2) {
            this.mMenuVisibilityListeners.get(n3).onMenuVisibilityChanged(bl);
            ++n3;
        }
    }

    @Override
    public View getCustomView() {
        return this.mActionView.getCustomNavigationView();
    }

    @Override
    public int getDisplayOptions() {
        return this.mActionView.getDisplayOptions();
    }

    @Override
    public int getHeight() {
        return this.mContainerView.getHeight();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int getNavigationItemCount() {
        switch (this.mActionView.getNavigationMode()) {
            default: {
                return 0;
            }
            case 2: {
                return this.mTabs.size();
            }
            case 1: {
                SpinnerAdapter spinnerAdapter = this.mActionView.getDropdownAdapter();
                if (spinnerAdapter == null) return 0;
                return spinnerAdapter.getCount();
            }
        }
    }

    @Override
    public int getNavigationMode() {
        return this.mActionView.getNavigationMode();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int getSelectedNavigationIndex() {
        switch (this.mActionView.getNavigationMode()) {
            case 2: {
                if (this.mSelectedTab != null) {
                    return this.mSelectedTab.getPosition();
                }
            }
            default: {
                return -1;
            }
            case 1: 
        }
        return this.mActionView.getDropdownSelectedPosition();
    }

    @Override
    public ActionBar.Tab getSelectedTab() {
        return this.mSelectedTab;
    }

    @Override
    public CharSequence getSubtitle() {
        return this.mActionView.getSubtitle();
    }

    @Override
    public ActionBar.Tab getTabAt(int n2) {
        return this.mTabs.get(n2);
    }

    @Override
    public int getTabCount() {
        return this.mTabs.size();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Context getThemedContext() {
        if (this.mThemedContext != null) return this.mThemedContext;
        TypedValue typedValue = new TypedValue();
        this.mContext.getTheme().resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
        int n2 = typedValue.resourceId;
        if (n2 != 0) {
            this.mThemedContext = new ContextThemeWrapper(this.mContext, n2);
            return this.mThemedContext;
        }
        this.mThemedContext = this.mContext;
        return this.mThemedContext;
    }

    @Override
    public CharSequence getTitle() {
        return this.mActionView.getTitle();
    }

    @Override
    public void hide() {
        if (this.mCurrentShowAnim != null) {
            this.mCurrentShowAnim.end();
        }
        if (this.mContainerView.getVisibility() == 8) {
            return;
        }
        if (this.mShowHideAnimationEnabled) {
            this.mContainerView.setAlpha(1.0f);
            this.mContainerView.setTransitioning(true);
            AnimatorSet animatorSet = new AnimatorSet();
            AnimatorSet.Builder builder = animatorSet.play(ObjectAnimator.ofFloat((Object)this.mContainerView, "alpha", 0.0f));
            if (this.mContentView != null) {
                builder.with(ObjectAnimator.ofFloat((Object)this.mContentView, "translationY", 0.0f, - this.mContainerView.getHeight()));
                builder.with(ObjectAnimator.ofFloat((Object)this.mContainerView, "translationY", - this.mContainerView.getHeight()));
            }
            if (this.mSplitView != null && this.mSplitView.getVisibility() == 0) {
                this.mSplitView.setAlpha(1.0f);
                builder.with(ObjectAnimator.ofFloat((Object)this.mSplitView, "alpha", 0.0f));
            }
            animatorSet.addListener(this.mHideListener);
            this.mCurrentShowAnim = animatorSet;
            animatorSet.start();
            return;
        }
        this.mHideListener.onAnimationEnd(null);
    }

    @Override
    public boolean isShowing() {
        if (this.mContainerView.getVisibility() == 0) {
            return true;
        }
        return false;
    }

    @Override
    public ActionBar.Tab newTab() {
        return new TabImpl();
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.setHasEmbeddedTabs(ResourcesCompat.getResources_getBoolean(this.mContext, R.bool.abs__action_bar_embed_tabs));
        if (Build.VERSION.SDK_INT < 8) {
            this.mActionView.onConfigurationChanged(configuration);
            if (this.mContextView != null) {
                this.mContextView.onConfigurationChanged(configuration);
            }
        }
    }

    @Override
    public void removeAllTabs() {
        this.cleanupTabs();
    }

    @Override
    public void removeOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener onMenuVisibilityListener) {
        this.mMenuVisibilityListeners.remove(onMenuVisibilityListener);
    }

    @Override
    public void removeTab(ActionBar.Tab tab) {
        this.removeTabAt(tab.getPosition());
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void removeTabAt(int n2) {
        if (this.mTabScrollView != null) {
            int n3 = this.mSelectedTab != null ? this.mSelectedTab.getPosition() : this.mSavedTabPosition;
            this.mTabScrollView.removeTabAt(n2);
            TabImpl tabImpl = this.mTabs.remove(n2);
            if (tabImpl != null) {
                tabImpl.setPosition(-1);
            }
            int n4 = this.mTabs.size();
            int n5 = n2;
            do {
                if (n5 >= n4) {
                    if (n3 != n2) break;
                    tabImpl = this.mTabs.isEmpty() ? null : this.mTabs.get(Math.max(0, n2 - 1));
                    this.selectTab(tabImpl);
                    return;
                }
                this.mTabs.get(n5).setPosition(n5);
                ++n5;
            } while (true);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void selectTab(ActionBar.Tab tab) {
        int n2 = -1;
        if (this.getNavigationMode() != 2) {
            n2 = tab != null ? tab.getPosition() : -1;
            this.mSavedTabPosition = n2;
            return;
        } else {
            FragmentTransaction fragmentTransaction = null;
            if (this.mActivity instanceof FragmentActivity) {
                fragmentTransaction = ((FragmentActivity)this.mActivity).getSupportFragmentManager().beginTransaction().disallowAddToBackStack();
            }
            if (this.mSelectedTab == tab) {
                if (this.mSelectedTab != null) {
                    this.mSelectedTab.getCallback().onTabReselected(this.mSelectedTab, fragmentTransaction);
                    this.mTabScrollView.animateToTab(tab.getPosition());
                }
            } else {
                ScrollingTabContainerView scrollingTabContainerView = this.mTabScrollView;
                if (tab != null) {
                    n2 = tab.getPosition();
                }
                scrollingTabContainerView.setTabSelected(n2);
                if (this.mSelectedTab != null) {
                    this.mSelectedTab.getCallback().onTabUnselected(this.mSelectedTab, fragmentTransaction);
                }
                this.mSelectedTab = (TabImpl)tab;
                if (this.mSelectedTab != null) {
                    this.mSelectedTab.getCallback().onTabSelected(this.mSelectedTab, fragmentTransaction);
                }
            }
            if (fragmentTransaction == null || fragmentTransaction.isEmpty()) return;
            {
                fragmentTransaction.commit();
                return;
            }
        }
    }

    @Override
    public void setBackgroundDrawable(Drawable drawable2) {
        this.mContainerView.setPrimaryBackground(drawable2);
    }

    @Override
    public void setCustomView(int n2) {
        this.setCustomView(LayoutInflater.from((Context)this.getThemedContext()).inflate(n2, (ViewGroup)this.mActionView, false));
    }

    @Override
    public void setCustomView(View view) {
        this.mActionView.setCustomNavigationView(view);
    }

    @Override
    public void setCustomView(View view, ActionBar.LayoutParams layoutParams) {
        view.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.mActionView.setCustomNavigationView(view);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setDisplayHomeAsUpEnabled(boolean bl) {
        int n2 = bl ? 4 : 0;
        this.setDisplayOptions(n2, 4);
    }

    @Override
    public void setDisplayOptions(int n2) {
        this.mActionView.setDisplayOptions(n2);
    }

    @Override
    public void setDisplayOptions(int n2, int n3) {
        int n4 = this.mActionView.getDisplayOptions();
        this.mActionView.setDisplayOptions(n4 & ~ n3 | n2 & n3);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setDisplayShowCustomEnabled(boolean bl) {
        int n2 = bl ? 16 : 0;
        this.setDisplayOptions(n2, 16);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setDisplayShowHomeEnabled(boolean bl) {
        int n2 = bl ? 2 : 0;
        this.setDisplayOptions(n2, 2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setDisplayShowTitleEnabled(boolean bl) {
        int n2 = bl ? 8 : 0;
        this.setDisplayOptions(n2, 8);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setDisplayUseLogoEnabled(boolean bl) {
        int n2 = bl ? 1 : 0;
        this.setDisplayOptions(n2, 1);
    }

    @Override
    public void setHomeButtonEnabled(boolean bl) {
        this.mActionView.setHomeButtonEnabled(bl);
    }

    @Override
    public void setIcon(int n2) {
        this.mActionView.setIcon(n2);
    }

    @Override
    public void setIcon(Drawable drawable2) {
        this.mActionView.setIcon(drawable2);
    }

    @Override
    public void setListNavigationCallbacks(SpinnerAdapter spinnerAdapter, ActionBar.OnNavigationListener onNavigationListener) {
        this.mActionView.setDropdownAdapter(spinnerAdapter);
        this.mActionView.setCallback(onNavigationListener);
    }

    @Override
    public void setLogo(int n2) {
        this.mActionView.setLogo(n2);
    }

    @Override
    public void setLogo(Drawable drawable2) {
        this.mActionView.setLogo(drawable2);
    }

    /*
     * Exception decompiling
     */
    @Override
    public void setNavigationMode(int var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:486)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public void setSelectedNavigationItem(int n2) {
        switch (this.mActionView.getNavigationMode()) {
            default: {
                throw new IllegalStateException("setSelectedNavigationItem not valid for current navigation mode");
            }
            case 2: {
                this.selectTab(this.mTabs.get(n2));
                return;
            }
            case 1: 
        }
        this.mActionView.setDropdownSelectedPosition(n2);
    }

    public void setShowHideAnimationEnabled(boolean bl) {
        this.mShowHideAnimationEnabled = bl;
        if (!bl && this.mCurrentShowAnim != null) {
            this.mCurrentShowAnim.end();
        }
    }

    @Override
    public void setSplitBackgroundDrawable(Drawable drawable2) {
        if (this.mSplitView != null) {
            this.mSplitView.setSplitBackground(drawable2);
        }
    }

    @Override
    public void setStackedBackgroundDrawable(Drawable drawable2) {
        this.mContainerView.setStackedBackground(drawable2);
    }

    @Override
    public void setSubtitle(int n2) {
        this.setSubtitle(this.mContext.getString(n2));
    }

    @Override
    public void setSubtitle(CharSequence charSequence) {
        this.mActionView.setSubtitle(charSequence);
    }

    @Override
    public void setTitle(int n2) {
        this.setTitle(this.mContext.getString(n2));
    }

    @Override
    public void setTitle(CharSequence charSequence) {
        this.mActionView.setTitle(charSequence);
    }

    @Override
    public void show() {
        this.show(true);
    }

    void show(boolean bl) {
        if (this.mCurrentShowAnim != null) {
            this.mCurrentShowAnim.end();
        }
        if (this.mContainerView.getVisibility() == 0) {
            if (bl) {
                this.mWasHiddenBeforeMode = false;
            }
            return;
        }
        this.mContainerView.setVisibility(0);
        if (this.mShowHideAnimationEnabled) {
            this.mContainerView.setAlpha(0.0f);
            AnimatorSet animatorSet = new AnimatorSet();
            AnimatorSet.Builder builder = animatorSet.play(ObjectAnimator.ofFloat((Object)this.mContainerView, "alpha", 1.0f));
            if (this.mContentView != null) {
                builder.with(ObjectAnimator.ofFloat((Object)this.mContentView, "translationY", - this.mContainerView.getHeight(), 0.0f));
                this.mContainerView.setTranslationY(- this.mContainerView.getHeight());
                builder.with(ObjectAnimator.ofFloat((Object)this.mContainerView, "translationY", 0.0f));
            }
            if (this.mSplitView != null && this.mContextDisplayMode == 1) {
                this.mSplitView.setAlpha(0.0f);
                this.mSplitView.setVisibility(0);
                builder.with(ObjectAnimator.ofFloat((Object)this.mSplitView, "alpha", 1.0f));
            }
            animatorSet.addListener(this.mShowListener);
            this.mCurrentShowAnim = animatorSet;
            animatorSet.start();
            return;
        }
        this.mContainerView.setAlpha(1.0f);
        this.mContainerView.setTranslationY(0.0f);
        this.mShowListener.onAnimationEnd(null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public ActionMode startActionMode(ActionMode.Callback object) {
        boolean bl;
        if (this.mActionMode != null) {
            bl = this.mWasHiddenBeforeMode;
            this.mActionMode.finish();
        } else {
            bl = false;
        }
        this.mContextView.killMode();
        object = new ActionModeImpl((ActionMode.Callback)object);
        if (!object.dispatchOnCreate()) {
            return null;
        }
        bl = !this.isShowing() || bl;
        this.mWasHiddenBeforeMode = bl;
        object.invalidate();
        this.mContextView.initForMode((ActionMode)object);
        this.animateToMode(true);
        if (this.mSplitView != null && this.mContextDisplayMode == 1) {
            this.mSplitView.setVisibility(0);
        }
        this.mContextView.sendAccessibilityEvent(32);
        this.mActionMode = object;
        return object;
    }

    public class ActionModeImpl
    extends ActionMode
    implements MenuBuilder.Callback {
        private ActionMode.Callback mCallback;
        private WeakReference<View> mCustomView;
        private MenuBuilder mMenu;

        public ActionModeImpl(ActionMode.Callback callback) {
            this.mCallback = callback;
            this.mMenu = new MenuBuilder(ActionBarImpl.this.getThemedContext()).setDefaultShowAsAction(1);
            this.mMenu.setCallback(this);
        }

        public boolean dispatchOnCreate() {
            this.mMenu.stopDispatchingItemsChanged();
            try {
                boolean bl = this.mCallback.onCreateActionMode(this, this.mMenu);
                return bl;
            }
            finally {
                this.mMenu.startDispatchingItemsChanged();
            }
        }

        /*
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        @Override
        public void finish() {
            if (ActionBarImpl.this.mActionMode != this) {
                return;
            }
            if (ActionBarImpl.this.mWasHiddenBeforeMode) {
                ActionBarImpl.this.mDeferredDestroyActionMode = this;
                ActionBarImpl.this.mDeferredModeDestroyCallback = this.mCallback;
            } else {
                this.mCallback.onDestroyActionMode(this);
            }
            this.mCallback = null;
            ActionBarImpl.this.animateToMode(false);
            ActionBarImpl.this.mContextView.closeMode();
            ActionBarImpl.this.mActionView.sendAccessibilityEvent(32);
            ActionBarImpl.this.mActionMode = null;
            if (!ActionBarImpl.this.mWasHiddenBeforeMode) return;
            ActionBarImpl.this.hide();
        }

        @Override
        public View getCustomView() {
            if (this.mCustomView != null) {
                return this.mCustomView.get();
            }
            return null;
        }

        @Override
        public Menu getMenu() {
            return this.mMenu;
        }

        @Override
        public MenuInflater getMenuInflater() {
            return new MenuInflater(ActionBarImpl.this.getThemedContext());
        }

        @Override
        public CharSequence getSubtitle() {
            return ActionBarImpl.this.mContextView.getSubtitle();
        }

        @Override
        public CharSequence getTitle() {
            return ActionBarImpl.this.mContextView.getTitle();
        }

        @Override
        public void invalidate() {
            this.mMenu.stopDispatchingItemsChanged();
            try {
                this.mCallback.onPrepareActionMode(this, this.mMenu);
                return;
            }
            finally {
                this.mMenu.startDispatchingItemsChanged();
            }
        }

        public void onCloseMenu(MenuBuilder menuBuilder, boolean bl) {
        }

        public void onCloseSubMenu(SubMenuBuilder subMenuBuilder) {
        }

        @Override
        public boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
            if (this.mCallback != null) {
                return this.mCallback.onActionItemClicked(this, menuItem);
            }
            return false;
        }

        @Override
        public void onMenuModeChange(MenuBuilder menuBuilder) {
            if (this.mCallback == null) {
                return;
            }
            this.invalidate();
            ActionBarImpl.this.mContextView.showOverflowMenu();
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean onSubMenuSelected(SubMenuBuilder subMenuBuilder) {
            boolean bl = true;
            if (this.mCallback == null) {
                return false;
            }
            if (!subMenuBuilder.hasVisibleItems()) return bl;
            new MenuPopupHelper(ActionBarImpl.this.getThemedContext(), subMenuBuilder).show();
            return true;
        }

        @Override
        public void setCustomView(View view) {
            ActionBarImpl.this.mContextView.setCustomView(view);
            this.mCustomView = new WeakReference<View>(view);
        }

        @Override
        public void setSubtitle(int n2) {
            this.setSubtitle(ActionBarImpl.this.mContext.getResources().getString(n2));
        }

        @Override
        public void setSubtitle(CharSequence charSequence) {
            ActionBarImpl.this.mContextView.setSubtitle(charSequence);
        }

        @Override
        public void setTitle(int n2) {
            this.setTitle(ActionBarImpl.this.mContext.getResources().getString(n2));
        }

        @Override
        public void setTitle(CharSequence charSequence) {
            ActionBarImpl.this.mContextView.setTitle(charSequence);
        }
    }

    public class TabImpl
    extends ActionBar.Tab {
        private ActionBar.TabListener mCallback;
        private CharSequence mContentDesc;
        private View mCustomView;
        private Drawable mIcon;
        private int mPosition;
        private Object mTag;
        private CharSequence mText;

        public TabImpl() {
            this.mPosition = -1;
        }

        public ActionBar.TabListener getCallback() {
            return this.mCallback;
        }

        @Override
        public CharSequence getContentDescription() {
            return this.mContentDesc;
        }

        @Override
        public View getCustomView() {
            return this.mCustomView;
        }

        @Override
        public Drawable getIcon() {
            return this.mIcon;
        }

        @Override
        public int getPosition() {
            return this.mPosition;
        }

        @Override
        public Object getTag() {
            return this.mTag;
        }

        @Override
        public CharSequence getText() {
            return this.mText;
        }

        @Override
        public void select() {
            ActionBarImpl.this.selectTab(this);
        }

        @Override
        public ActionBar.Tab setContentDescription(int n2) {
            return this.setContentDescription(ActionBarImpl.this.mContext.getResources().getText(n2));
        }

        @Override
        public ActionBar.Tab setContentDescription(CharSequence charSequence) {
            this.mContentDesc = charSequence;
            if (this.mPosition >= 0) {
                ActionBarImpl.this.mTabScrollView.updateTab(this.mPosition);
            }
            return this;
        }

        @Override
        public ActionBar.Tab setCustomView(int n2) {
            return this.setCustomView(LayoutInflater.from((Context)ActionBarImpl.this.getThemedContext()).inflate(n2, null));
        }

        @Override
        public ActionBar.Tab setCustomView(View view) {
            this.mCustomView = view;
            if (this.mPosition >= 0) {
                ActionBarImpl.this.mTabScrollView.updateTab(this.mPosition);
            }
            return this;
        }

        @Override
        public ActionBar.Tab setIcon(int n2) {
            return this.setIcon(ActionBarImpl.this.mContext.getResources().getDrawable(n2));
        }

        @Override
        public ActionBar.Tab setIcon(Drawable drawable2) {
            this.mIcon = drawable2;
            if (this.mPosition >= 0) {
                ActionBarImpl.this.mTabScrollView.updateTab(this.mPosition);
            }
            return this;
        }

        public void setPosition(int n2) {
            this.mPosition = n2;
        }

        @Override
        public ActionBar.Tab setTabListener(ActionBar.TabListener tabListener) {
            this.mCallback = tabListener;
            return this;
        }

        @Override
        public ActionBar.Tab setTag(Object object) {
            this.mTag = object;
            return this;
        }

        @Override
        public ActionBar.Tab setText(int n2) {
            return this.setText(ActionBarImpl.this.mContext.getResources().getText(n2));
        }

        @Override
        public ActionBar.Tab setText(CharSequence charSequence) {
            this.mText = charSequence;
            if (this.mPosition >= 0) {
                ActionBarImpl.this.mTabScrollView.updateTab(this.mPosition);
            }
            return this;
        }
    }

}

