/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.ActionBar
 *  android.app.ActionBar$LayoutParams
 *  android.app.ActionBar$OnMenuVisibilityListener
 *  android.app.ActionBar$OnNavigationListener
 *  android.app.ActionBar$Tab
 *  android.app.ActionBar$TabListener
 *  android.app.Activity
 *  android.app.FragmentTransaction
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.SpinnerAdapter
 */
package com.actionbarsherlock.internal.app;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SpinnerAdapter;
import com.actionbarsherlock.app.ActionBar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ActionBarWrapper
extends com.actionbarsherlock.app.ActionBar
implements ActionBar.OnMenuVisibilityListener,
ActionBar.OnNavigationListener {
    private final ActionBar mActionBar;
    private final Activity mActivity;
    private FragmentTransaction mFragmentTransaction;
    private Set<ActionBar.OnMenuVisibilityListener> mMenuVisibilityListeners;
    private ActionBar.OnNavigationListener mNavigationListener;

    /*
     * Enabled aggressive block sorting
     */
    public ActionBarWrapper(Activity activity) {
        boolean bl = true;
        this.mMenuVisibilityListeners = new HashSet<ActionBar.OnMenuVisibilityListener>(1);
        this.mActivity = activity;
        this.mActionBar = activity.getActionBar();
        if (this.mActionBar != null) {
            this.mActionBar.addOnMenuVisibilityListener((ActionBar.OnMenuVisibilityListener)this);
            int n2 = this.mActionBar.getDisplayOptions();
            activity = this.mActionBar;
            if ((n2 & 4) == 0) {
                bl = false;
            }
            activity.setHomeButtonEnabled(bl);
        }
    }

    static /* synthetic */ void access$2(ActionBarWrapper actionBarWrapper, FragmentTransaction fragmentTransaction) {
        actionBarWrapper.mFragmentTransaction = fragmentTransaction;
    }

    @Override
    public void addOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener onMenuVisibilityListener) {
        this.mMenuVisibilityListeners.add(onMenuVisibilityListener);
    }

    @Override
    public void addTab(ActionBar.Tab tab) {
        this.mActionBar.addTab(((TabWrapper)tab).mNativeTab);
    }

    @Override
    public void addTab(ActionBar.Tab tab, int n2) {
        this.mActionBar.addTab(((TabWrapper)tab).mNativeTab, n2);
    }

    @Override
    public void addTab(ActionBar.Tab tab, int n2, boolean bl) {
        this.mActionBar.addTab(((TabWrapper)tab).mNativeTab, n2, bl);
    }

    @Override
    public void addTab(ActionBar.Tab tab, boolean bl) {
        this.mActionBar.addTab(((TabWrapper)tab).mNativeTab, bl);
    }

    @Override
    public View getCustomView() {
        return this.mActionBar.getCustomView();
    }

    @Override
    public int getDisplayOptions() {
        return this.mActionBar.getDisplayOptions();
    }

    @Override
    public int getHeight() {
        return this.mActionBar.getHeight();
    }

    @Override
    public int getNavigationItemCount() {
        return this.mActionBar.getNavigationItemCount();
    }

    @Override
    public int getNavigationMode() {
        return this.mActionBar.getNavigationMode();
    }

    @Override
    public int getSelectedNavigationIndex() {
        return this.mActionBar.getSelectedNavigationIndex();
    }

    @Override
    public ActionBar.Tab getSelectedTab() {
        ActionBar.Tab tab = this.mActionBar.getSelectedTab();
        if (tab != null) {
            return (ActionBar.Tab)tab.getTag();
        }
        return null;
    }

    @Override
    public CharSequence getSubtitle() {
        return this.mActionBar.getSubtitle();
    }

    @Override
    public ActionBar.Tab getTabAt(int n2) {
        ActionBar.Tab tab = this.mActionBar.getTabAt(n2);
        if (tab != null) {
            return (ActionBar.Tab)tab.getTag();
        }
        return null;
    }

    @Override
    public int getTabCount() {
        return this.mActionBar.getTabCount();
    }

    @Override
    public Context getThemedContext() {
        return this.mActionBar.getThemedContext();
    }

    @Override
    public CharSequence getTitle() {
        return this.mActionBar.getTitle();
    }

    @Override
    public void hide() {
        this.mActionBar.hide();
    }

    @Override
    public boolean isShowing() {
        return this.mActionBar.isShowing();
    }

    @Override
    public ActionBar.Tab newTab() {
        return new TabWrapper(this.mActionBar.newTab());
    }

    public void onMenuVisibilityChanged(boolean bl) {
        Iterator<ActionBar.OnMenuVisibilityListener> iterator = this.mMenuVisibilityListeners.iterator();
        while (iterator.hasNext()) {
            iterator.next().onMenuVisibilityChanged(bl);
        }
        return;
    }

    public boolean onNavigationItemSelected(int n2, long l2) {
        return this.mNavigationListener.onNavigationItemSelected(n2, l2);
    }

    @Override
    public void removeAllTabs() {
        this.mActionBar.removeAllTabs();
    }

    @Override
    public void removeOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener onMenuVisibilityListener) {
        this.mMenuVisibilityListeners.remove(onMenuVisibilityListener);
    }

    @Override
    public void removeTab(ActionBar.Tab tab) {
        this.mActionBar.removeTab(((TabWrapper)tab).mNativeTab);
    }

    @Override
    public void removeTabAt(int n2) {
        this.mActionBar.removeTabAt(n2);
    }

    @Override
    public void selectTab(ActionBar.Tab tab) {
        this.mActionBar.selectTab(((TabWrapper)tab).mNativeTab);
    }

    @Override
    public void setBackgroundDrawable(Drawable drawable2) {
        this.mActionBar.setBackgroundDrawable(drawable2);
    }

    @Override
    public void setCustomView(int n2) {
        this.mActionBar.setCustomView(n2);
    }

    @Override
    public void setCustomView(View view) {
        this.mActionBar.setCustomView(view);
    }

    @Override
    public void setCustomView(View view, ActionBar.LayoutParams layoutParams) {
        ActionBar.LayoutParams layoutParams2 = new ActionBar.LayoutParams((ViewGroup.LayoutParams)layoutParams);
        layoutParams2.gravity = layoutParams.gravity;
        layoutParams2.bottomMargin = layoutParams.bottomMargin;
        layoutParams2.topMargin = layoutParams.topMargin;
        layoutParams2.leftMargin = layoutParams.leftMargin;
        layoutParams2.rightMargin = layoutParams.rightMargin;
        this.mActionBar.setCustomView(view, layoutParams2);
    }

    @Override
    public void setDisplayHomeAsUpEnabled(boolean bl) {
        this.mActionBar.setDisplayHomeAsUpEnabled(bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setDisplayOptions(int n2) {
        this.mActionBar.setDisplayOptions(n2);
        ActionBar actionBar = this.mActionBar;
        boolean bl = (n2 & 4) != 0;
        actionBar.setHomeButtonEnabled(bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setDisplayOptions(int n2, int n3) {
        this.mActionBar.setDisplayOptions(n2, n3);
        if ((n3 & 4) != 0) {
            ActionBar actionBar = this.mActionBar;
            boolean bl = (n2 & 4) != 0;
            actionBar.setHomeButtonEnabled(bl);
        }
    }

    @Override
    public void setDisplayShowCustomEnabled(boolean bl) {
        this.mActionBar.setDisplayShowCustomEnabled(bl);
    }

    @Override
    public void setDisplayShowHomeEnabled(boolean bl) {
        this.mActionBar.setDisplayShowHomeEnabled(bl);
    }

    @Override
    public void setDisplayShowTitleEnabled(boolean bl) {
        this.mActionBar.setDisplayShowTitleEnabled(bl);
    }

    @Override
    public void setDisplayUseLogoEnabled(boolean bl) {
        this.mActionBar.setDisplayUseLogoEnabled(bl);
    }

    @Override
    public void setHomeButtonEnabled(boolean bl) {
        this.mActionBar.setHomeButtonEnabled(bl);
    }

    @Override
    public void setIcon(int n2) {
        this.mActionBar.setIcon(n2);
    }

    @Override
    public void setIcon(Drawable drawable2) {
        this.mActionBar.setIcon(drawable2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setListNavigationCallbacks(SpinnerAdapter spinnerAdapter, ActionBar.OnNavigationListener object) {
        this.mNavigationListener = object;
        ActionBar actionBar = this.mActionBar;
        object = object != null ? this : null;
        actionBar.setListNavigationCallbacks(spinnerAdapter, (ActionBar.OnNavigationListener)object);
    }

    @Override
    public void setLogo(int n2) {
        this.mActionBar.setLogo(n2);
    }

    @Override
    public void setLogo(Drawable drawable2) {
        this.mActionBar.setLogo(drawable2);
    }

    @Override
    public void setNavigationMode(int n2) {
        this.mActionBar.setNavigationMode(n2);
    }

    @Override
    public void setSelectedNavigationItem(int n2) {
        this.mActionBar.setSelectedNavigationItem(n2);
    }

    @Override
    public void setSplitBackgroundDrawable(Drawable drawable2) {
        this.mActionBar.setSplitBackgroundDrawable(drawable2);
    }

    @Override
    public void setStackedBackgroundDrawable(Drawable drawable2) {
        this.mActionBar.setStackedBackgroundDrawable(drawable2);
    }

    @Override
    public void setSubtitle(int n2) {
        this.mActionBar.setSubtitle(n2);
    }

    @Override
    public void setSubtitle(CharSequence charSequence) {
        this.mActionBar.setSubtitle(charSequence);
    }

    @Override
    public void setTitle(int n2) {
        this.mActionBar.setTitle(n2);
    }

    @Override
    public void setTitle(CharSequence charSequence) {
        this.mActionBar.setTitle(charSequence);
    }

    @Override
    public void show() {
        this.mActionBar.show();
    }

    public class TabWrapper
    extends ActionBar.Tab
    implements ActionBar.TabListener {
        private ActionBar.TabListener mListener;
        final ActionBar.Tab mNativeTab;
        private Object mTag;

        public TabWrapper(ActionBar.Tab tab) {
            this.mNativeTab = tab;
            this.mNativeTab.setTag((Object)this);
        }

        @Override
        public CharSequence getContentDescription() {
            return this.mNativeTab.getContentDescription();
        }

        @Override
        public View getCustomView() {
            return this.mNativeTab.getCustomView();
        }

        @Override
        public Drawable getIcon() {
            return this.mNativeTab.getIcon();
        }

        @Override
        public int getPosition() {
            return this.mNativeTab.getPosition();
        }

        @Override
        public Object getTag() {
            return this.mTag;
        }

        @Override
        public CharSequence getText() {
            return this.mNativeTab.getText();
        }

        public void onTabReselected(ActionBar.Tab object, android.app.FragmentTransaction fragmentTransaction) {
            if (this.mListener != null) {
                object = null;
                if (ActionBarWrapper.this.mActivity instanceof FragmentActivity) {
                    object = ((FragmentActivity)ActionBarWrapper.this.mActivity).getSupportFragmentManager().beginTransaction().disallowAddToBackStack();
                }
                this.mListener.onTabReselected(this, (FragmentTransaction)object);
                if (object != null && !object.isEmpty()) {
                    object.commit();
                }
            }
        }

        public void onTabSelected(ActionBar.Tab tab, android.app.FragmentTransaction fragmentTransaction) {
            if (this.mListener != null) {
                if (ActionBarWrapper.this.mFragmentTransaction == null && ActionBarWrapper.this.mActivity instanceof FragmentActivity) {
                    ActionBarWrapper.access$2(ActionBarWrapper.this, ((FragmentActivity)ActionBarWrapper.this.mActivity).getSupportFragmentManager().beginTransaction().disallowAddToBackStack());
                }
                this.mListener.onTabSelected(this, ActionBarWrapper.this.mFragmentTransaction);
                if (ActionBarWrapper.this.mFragmentTransaction != null) {
                    if (!ActionBarWrapper.this.mFragmentTransaction.isEmpty()) {
                        ActionBarWrapper.this.mFragmentTransaction.commit();
                    }
                    ActionBarWrapper.access$2(ActionBarWrapper.this, null);
                }
            }
        }

        public void onTabUnselected(ActionBar.Tab object, android.app.FragmentTransaction fragmentTransaction) {
            if (this.mListener != null) {
                object = null;
                if (ActionBarWrapper.this.mActivity instanceof FragmentActivity) {
                    object = ((FragmentActivity)ActionBarWrapper.this.mActivity).getSupportFragmentManager().beginTransaction().disallowAddToBackStack();
                    ActionBarWrapper.access$2(ActionBarWrapper.this, (FragmentTransaction)object);
                }
                this.mListener.onTabUnselected(this, (FragmentTransaction)object);
            }
        }

        @Override
        public void select() {
            this.mNativeTab.select();
        }

        @Override
        public ActionBar.Tab setContentDescription(int n2) {
            this.mNativeTab.setContentDescription(n2);
            return this;
        }

        @Override
        public ActionBar.Tab setContentDescription(CharSequence charSequence) {
            this.mNativeTab.setContentDescription(charSequence);
            return this;
        }

        @Override
        public ActionBar.Tab setCustomView(int n2) {
            this.mNativeTab.setCustomView(n2);
            return this;
        }

        @Override
        public ActionBar.Tab setCustomView(View view) {
            this.mNativeTab.setCustomView(view);
            return this;
        }

        @Override
        public ActionBar.Tab setIcon(int n2) {
            this.mNativeTab.setIcon(n2);
            return this;
        }

        @Override
        public ActionBar.Tab setIcon(Drawable drawable2) {
            this.mNativeTab.setIcon(drawable2);
            return this;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public ActionBar.Tab setTabListener(ActionBar.TabListener tabListener) {
            ActionBar.Tab tab = this.mNativeTab;
            TabWrapper tabWrapper = tabListener != null ? this : null;
            tab.setTabListener((ActionBar.TabListener)tabWrapper);
            this.mListener = tabListener;
            return this;
        }

        @Override
        public ActionBar.Tab setTag(Object object) {
            this.mTag = object;
            return this;
        }

        @Override
        public ActionBar.Tab setText(int n2) {
            this.mNativeTab.setText(n2);
            return this;
        }

        @Override
        public ActionBar.Tab setText(CharSequence charSequence) {
            this.mNativeTab.setText(charSequence);
            return this;
        }
    }

}

