/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import android.view.animation.Interpolator;
import java.util.ArrayList;

public abstract class Animator
implements Cloneable {
    ArrayList<AnimatorListener> mListeners = null;

    public void addListener(AnimatorListener animatorListener) {
        if (this.mListeners == null) {
            this.mListeners = new ArrayList();
        }
        this.mListeners.add(animatorListener);
    }

    public void cancel() {
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public Animator clone() {
        Animator animator;
        try {
            animator = (Animator)super.clone();
            if (this.mListeners != null) {
                ArrayList<AnimatorListener> arrayList = this.mListeners;
                animator.mListeners = new ArrayList();
                int n2 = arrayList.size();
                int n3 = 0;
                while (n3 < n2) {
                    animator.mListeners.add(arrayList.get(n3));
                    ++n3;
                }
            }
        }
        catch (CloneNotSupportedException var3_2) {
            throw new AssertionError();
        }
        return animator;
    }

    public void end() {
    }

    public abstract long getDuration();

    public ArrayList<AnimatorListener> getListeners() {
        return this.mListeners;
    }

    public abstract long getStartDelay();

    public abstract boolean isRunning();

    public boolean isStarted() {
        return this.isRunning();
    }

    public void removeAllListeners() {
        if (this.mListeners != null) {
            this.mListeners.clear();
            this.mListeners = null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void removeListener(AnimatorListener animatorListener) {
        if (this.mListeners == null) {
            return;
        }
        this.mListeners.remove(animatorListener);
        if (this.mListeners.size() != 0) return;
        this.mListeners = null;
    }

    public abstract Animator setDuration(long var1);

    public abstract void setInterpolator(Interpolator var1);

    public abstract void setStartDelay(long var1);

    public void setTarget(Object object) {
    }

    public void setupEndValues() {
    }

    public void setupStartValues() {
    }

    public void start() {
    }

    public static interface AnimatorListener {
        public void onAnimationCancel(Animator var1);

        public void onAnimationEnd(Animator var1);

        public void onAnimationRepeat(Animator var1);

        public void onAnimationStart(Animator var1);
    }

}

