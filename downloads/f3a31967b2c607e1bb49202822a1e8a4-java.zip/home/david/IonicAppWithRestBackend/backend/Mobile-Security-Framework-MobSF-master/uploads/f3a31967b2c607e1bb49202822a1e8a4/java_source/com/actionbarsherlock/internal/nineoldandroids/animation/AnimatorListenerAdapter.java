/*
 * Decompiled with CFR 0_115.
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import com.actionbarsherlock.internal.nineoldandroids.animation.Animator;

public abstract class AnimatorListenerAdapter
implements Animator.AnimatorListener {
    @Override
    public void onAnimationCancel(Animator animator) {
    }

    @Override
    public void onAnimationEnd(Animator animator) {
    }

    @Override
    public void onAnimationRepeat(Animator animator) {
    }

    @Override
    public void onAnimationStart(Animator animator) {
    }
}

