/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import android.view.animation.Interpolator;
import com.actionbarsherlock.internal.nineoldandroids.animation.Animator;
import com.actionbarsherlock.internal.nineoldandroids.animation.AnimatorListenerAdapter;
import com.actionbarsherlock.internal.nineoldandroids.animation.ObjectAnimator;
import com.actionbarsherlock.internal.nineoldandroids.animation.ValueAnimator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public final class AnimatorSet
extends Animator {
    private ValueAnimator mDelayAnim = null;
    private long mDuration = -1;
    private boolean mNeedsSort = true;
    private HashMap<Animator, Node> mNodeMap = new HashMap();
    private ArrayList<Node> mNodes = new ArrayList();
    private ArrayList<Animator> mPlayingSet = new ArrayList();
    private AnimatorSetListener mSetListener = null;
    private ArrayList<Node> mSortedNodes = new ArrayList();
    private long mStartDelay = 0;
    private boolean mStarted = false;
    boolean mTerminated = false;

    static /* synthetic */ ArrayList access$4(AnimatorSet animatorSet) {
        return animatorSet.mSortedNodes;
    }

    static /* synthetic */ void access$5(AnimatorSet animatorSet, boolean bl) {
        animatorSet.mStarted = bl;
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void sortNodes() {
        if (!this.mNeedsSort) ** GOTO lbl41
        this.mSortedNodes.clear();
        var5_1 = new ArrayList<ArrayList>();
        var2_3 = this.mNodes.size();
        var1_5 = 0;
        do {
            if (var1_5 >= var2_3) {
                var6_7 = new ArrayList<E>();
lbl9: // 2 sources:
                if (var5_1.size() > 0) break;
                this.mNeedsSort = false;
                if (this.mSortedNodes.size() == this.mNodes.size()) return;
                throw new IllegalStateException("Circular dependencies cannot exist in AnimatorSet");
            }
            var6_7 = this.mNodes.get(var1_5);
            if (var6_7.dependencies == null || var6_7.dependencies.size() == 0) {
                var5_1.add(var6_7);
            }
            ++var1_5;
        } while (true);
        var3_9 = var5_1.size();
        var1_5 = 0;
        block2 : do {
            if (var1_5 < var3_9) ** GOTO lbl26
            var5_1.clear();
            var5_1.addAll(var6_7);
            var6_7.clear();
            ** GOTO lbl9
lbl26: // 1 sources:
            var7_13 = (Node)var5_1.get(var1_5);
            this.mSortedNodes.add(var7_13);
            if (var7_13.nodeDependents == null) ** GOTO lbl-1000
            var4_11 = var7_13.nodeDependents.size();
            var2_3 = 0;
            do {
                if (var2_3 >= var4_11) lbl-1000: // 2 sources:
                {
                    ++var1_5;
                    continue block2;
                }
                var8_14 = var7_13.nodeDependents.get(var2_3);
                var8_14.nodeDependencies.remove(var7_13);
                if (var8_14.nodeDependencies.size() == 0) {
                    var6_7.add(var8_14);
                }
                ++var2_3;
            } while (true);
            break;
        } while (true);
lbl41: // 1 sources:
        var3_10 = this.mNodes.size();
        var1_6 = 0;
        block4 : do {
            if (var1_6 >= var3_10) {
                return;
            }
            var5_2 = this.mNodes.get(var1_6);
            if (var5_2.dependencies == null || var5_2.dependencies.size() <= 0) ** GOTO lbl-1000
            var4_12 = var5_2.dependencies.size();
            var2_4 = 0;
            do {
                if (var2_4 >= var4_12) lbl-1000: // 2 sources:
                {
                    var5_2.done = false;
                    ++var1_6;
                    continue block4;
                }
                var6_8 = var5_2.dependencies.get(var2_4);
                if (var5_2.nodeDependencies == null) {
                    var5_2.nodeDependencies = new ArrayList<E>();
                }
                if (!var5_2.nodeDependencies.contains(var6_8.node)) {
                    var5_2.nodeDependencies.add(var6_8.node);
                }
                ++var2_4;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void cancel() {
        this.mTerminated = true;
        if (this.isStarted() == false) return;
        if (this.mListeners != null) ** GOTO lbl6
        var1_1 = null;
        ** GOTO lbl10
lbl6: // 1 sources:
        var1_1 = (ArrayList)this.mListeners.clone();
        var2_2 = var1_1.iterator();
        do {
            if (var2_2.hasNext()) ** GOTO lbl21
lbl10: // 2 sources:
            if (this.mDelayAnim != null && this.mDelayAnim.isRunning()) {
                this.mDelayAnim.cancel();
            } else if (this.mSortedNodes.size() > 0) {
                var2_2 = this.mSortedNodes.iterator();
                while (var2_2.hasNext()) {
                    ((Node)var2_2.next()).animation.cancel();
                }
            }
            if (var1_1 != null) {
                break;
            }
            ** GOTO lbl-1000
lbl21: // 1 sources:
            ((Animator.AnimatorListener)var2_2.next()).onAnimationCancel(this);
        } while (true);
        var1_1 = var1_1.iterator();
        do {
            if (!var1_1.hasNext()) lbl-1000: // 2 sources:
            {
                this.mStarted = false;
                return;
            }
            ((Animator.AnimatorListener)var1_1.next()).onAnimationEnd(this);
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final AnimatorSet clone() {
        var3_1 = (AnimatorSet)super.clone();
        var3_1.mNeedsSort = true;
        var3_1.mTerminated = false;
        var3_1.mStarted = false;
        var3_1.mPlayingSet = new ArrayList<E>();
        var3_1.mNodeMap = new HashMap<K, V>();
        var3_1.mNodes = new ArrayList<E>();
        var3_1.mSortedNodes = new ArrayList<E>();
        var4_2 = new HashMap<Object, Node>();
        var5_3 = this.mNodes.iterator();
        block0 : do lbl-1000: // 4 sources:
        {
            if (!var5_3.hasNext()) ** GOTO lbl27
            var1_4 = var5_3.next();
            var2_5 = var1_4.clone();
            var4_2.put(var1_4, (Node)var2_5);
            var3_1.mNodes.add((Node)var2_5);
            var3_1.mNodeMap.put(var2_5.animation, (Node)var2_5);
            var2_5.dependencies = null;
            var2_5.tmpDependencies = null;
            var2_5.nodeDependents = null;
            var2_5.nodeDependencies = null;
            var6_6 = var2_5.animation.getListeners();
            if (var6_6 == null) ** GOTO lbl-1000
            var7_7 = var6_6.iterator();
            var1_4 = null;
            ** GOTO lbl40
lbl27: // 1 sources:
            var1_4 = this.mNodes.iterator();
            block1 : do lbl-1000: // 3 sources:
            {
                if (!var1_4.hasNext()) {
                    return var3_1;
                }
                var5_3 = (Node)var1_4.next();
                var2_5 = (Node)var4_2.get(var5_3);
                if (var5_3.dependencies == null) ** GOTO lbl-1000
                var5_3 = var5_3.dependencies.iterator();
                do {
                    if (!var5_3.hasNext()) continue block1;
                    var6_6 = var5_3.next();
                    var2_5.addDependency(new Dependency((Node)var4_2.get(var6_6.node), var6_6.rule));
                } while (true);
                break;
            } while (true);
lbl40: // 1 sources:
            do {
                if (var7_7.hasNext()) ** GOTO lbl48
                if (var1_4 == null) ** GOTO lbl-1000
                var1_4 = var1_4.iterator();
                do {
                    if (!var1_4.hasNext()) continue block0;
                    var6_6.remove((Animator.AnimatorListener)var1_4.next());
                } while (true);
lbl48: // 1 sources:
                var8_8 = (Animator.AnimatorListener)var7_7.next();
                if (!(var8_8 instanceof AnimatorSetListener)) continue;
                var2_5 = var1_4;
                if (var1_4 == null) {
                    var2_5 = new ArrayList<Animator.AnimatorListener>();
                }
                var2_5.add(var8_8);
                var1_4 = var2_5;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void end() {
        this.mTerminated = true;
        if (this.isStarted() == false) return;
        if (this.mSortedNodes.size() == this.mNodes.size()) ** GOTO lbl8
        this.sortNodes();
        var1_1 = this.mSortedNodes.iterator();
        do {
            if (var1_1.hasNext()) ** GOTO lbl13
lbl8: // 2 sources:
            if (this.mDelayAnim != null) {
                this.mDelayAnim.cancel();
            }
            if (this.mSortedNodes.size() > 0) {
                break;
            }
            ** GOTO lbl21
lbl13: // 1 sources:
            var2_2 = var1_1.next();
            if (this.mSetListener == null) {
                this.mSetListener = new AnimatorSetListener(this);
            }
            var2_2.animation.addListener(this.mSetListener);
        } while (true);
        var1_1 = this.mSortedNodes.iterator();
        do {
            if (var1_1.hasNext()) ** GOTO lbl24
lbl21: // 2 sources:
            if (this.mListeners != null) {
                break;
            }
            ** GOTO lbl-1000
lbl24: // 1 sources:
            var1_1.next().animation.end();
        } while (true);
        var1_1 = ((ArrayList)this.mListeners.clone()).iterator();
        do {
            if (!var1_1.hasNext()) lbl-1000: // 2 sources:
            {
                this.mStarted = false;
                return;
            }
            ((Animator.AnimatorListener)var1_1.next()).onAnimationEnd(this);
        } while (true);
    }

    public final ArrayList<Animator> getChildAnimations() {
        ArrayList<Animator> arrayList = new ArrayList<Animator>();
        Iterator<Node> iterator = this.mNodes.iterator();
        while (iterator.hasNext()) {
            arrayList.add(iterator.next().animation);
        }
        return arrayList;
    }

    @Override
    public final long getDuration() {
        return this.mDuration;
    }

    @Override
    public final long getStartDelay() {
        return this.mStartDelay;
    }

    @Override
    public final boolean isRunning() {
        Iterator<Node> iterator = this.mNodes.iterator();
        do {
            if (iterator.hasNext()) continue;
            return false;
        } while (!iterator.next().animation.isRunning());
        return true;
    }

    @Override
    public final boolean isStarted() {
        return this.mStarted;
    }

    public final Builder play(Animator animator) {
        if (animator != null) {
            this.mNeedsSort = true;
            return new Builder(animator);
        }
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void playSequentially(List<Animator> list) {
        if (list == null || list.size() <= 0) return;
        this.mNeedsSort = true;
        if (list.size() == 1) {
            this.play(list.get(0));
            return;
        }
        int n2 = 0;
        while (n2 < list.size() - 1) {
            this.play(list.get(n2)).before(list.get(n2 + 1));
            ++n2;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final /* varargs */ void playSequentially(Animator ... var1_1) {
        var2_2 = 0;
        if (var1_1 == null) return;
        this.mNeedsSort = true;
        if (var1_1.length != 1) ** GOTO lbl9
        this.play(var1_1[0]);
        return;
lbl-1000: // 1 sources:
        {
            this.play(var1_1[var2_2]).before(var1_1[var2_2 + 1]);
            ++var2_2;
lbl9: // 2 sources:
            ** while (var2_2 < var1_1.length - 1)
        }
lbl10: // 1 sources:
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void playTogether(Collection<Animator> object) {
        if (object == null || object.size() <= 0) return;
        this.mNeedsSort = true;
        Iterator iterator = object.iterator();
        object = null;
        while (iterator.hasNext()) {
            Animator animator = (Animator)iterator.next();
            if (object == null) {
                object = this.play(animator);
                continue;
            }
            object.with(animator);
        }
        return;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final /* varargs */ void playTogether(Animator ... arranimator) {
        int n2 = 1;
        if (arranimator == null) return;
        this.mNeedsSort = true;
        Builder builder = this.play(arranimator[0]);
        while (n2 < arranimator.length) {
            builder.with(arranimator[n2]);
            ++n2;
        }
        return;
    }

    @Override
    public final AnimatorSet setDuration(long l2) {
        if (l2 < 0) {
            throw new IllegalArgumentException("duration must be a value of zero or greater");
        }
        Iterator<Node> iterator = this.mNodes.iterator();
        do {
            if (!iterator.hasNext()) {
                this.mDuration = l2;
                return this;
            }
            iterator.next().animation.setDuration(l2);
        } while (true);
    }

    @Override
    public final void setInterpolator(Interpolator interpolator) {
        Iterator<Node> iterator = this.mNodes.iterator();
        while (iterator.hasNext()) {
            iterator.next().animation.setInterpolator(interpolator);
        }
        return;
    }

    @Override
    public final void setStartDelay(long l2) {
        this.mStartDelay = l2;
    }

    @Override
    public final void setTarget(Object object) {
        Iterator<Node> iterator = this.mNodes.iterator();
        while (iterator.hasNext()) {
            Animator animator = iterator.next().animation;
            if (animator instanceof AnimatorSet) {
                ((AnimatorSet)animator).setTarget(object);
                continue;
            }
            if (!(animator instanceof ObjectAnimator)) continue;
            ((ObjectAnimator)animator).setTarget(object);
        }
        return;
    }

    @Override
    public final void setupEndValues() {
        Iterator<Node> iterator = this.mNodes.iterator();
        while (iterator.hasNext()) {
            iterator.next().animation.setupEndValues();
        }
        return;
    }

    @Override
    public final void setupStartValues() {
        Iterator<Node> iterator = this.mNodes.iterator();
        while (iterator.hasNext()) {
            iterator.next().animation.setupStartValues();
        }
        return;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     */
    @Override
    public final void start() {
        block16 : {
            var3_1 = 0;
            this.mTerminated = false;
            this.mStarted = true;
            this.sortNodes();
            var4_2 = this.mSortedNodes.size();
            var1_3 = 0;
            block0 : do {
                if (var1_3 < var4_2) ** GOTO lbl12
                var6_4 = new ArrayList<E>();
                var1_3 = 0;
                ** GOTO lbl16
lbl12: // 1 sources:
                var6_4 = this.mSortedNodes.get(var1_3);
                var7_5 = var6_4.animation.getListeners();
                if (var7_5 == null || var7_5.size() <= 0) ** GOTO lbl-1000
                ** GOTO lbl59
lbl16: // 2 sources:
                if (var1_3 < var4_2) ** GOTO lbl19
                if (this.mStartDelay > 0) ** GOTO lbl26
                ** GOTO lbl31
lbl19: // 1 sources:
                var7_5 = this.mSortedNodes.get(var1_3);
                if (this.mSetListener == null) {
                    this.mSetListener = new AnimatorSetListener(this);
                }
                if (var7_5.dependencies == null || var7_5.dependencies.size() == 0) {
                    var6_4.add(var7_5);
                    break;
                }
                break block16;
lbl26: // 1 sources:
                this.mDelayAnim = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});
                this.mDelayAnim.setDuration(this.mStartDelay);
                this.mDelayAnim.addListener(new AnimatorListenerAdapter((ArrayList)var6_4){
                    boolean canceled;
                    private final /* synthetic */ ArrayList val$nodesToStart;

                    @Override
                    public void onAnimationCancel(Animator animator) {
                        this.canceled = true;
                    }

                    /*
                     * Enabled force condition propagation
                     * Lifted jumps to return sites
                     */
                    @Override
                    public void onAnimationEnd(Animator cloneable) {
                        if (this.canceled) return;
                        int n2 = this.val$nodesToStart.size();
                        int n3 = 0;
                        while (n3 < n2) {
                            Node node = (Node)this.val$nodesToStart.get(n3);
                            node.animation.start();
                            AnimatorSet.this.mPlayingSet.add(node.animation);
                            ++n3;
                        }
                        return;
                    }
                });
                this.mDelayAnim.start();
                ** GOTO lbl34
lbl31: // 1 sources:
                var6_4 = var6_4.iterator();
                do {
                    if (var6_4.hasNext()) ** GOTO lbl37
lbl34: // 2 sources:
                    if (this.mListeners != null) {
                        break;
                    }
                    ** GOTO lbl-1000
lbl37: // 1 sources:
                    var7_5 = (Node)var6_4.next();
                    var7_5.animation.start();
                    this.mPlayingSet.add(var7_5.animation);
                } while (true);
                var6_4 = (ArrayList)this.mListeners.clone();
                var2_7 = var6_4.size();
                var1_3 = 0;
                do {
                    if (var1_3 >= var2_7) lbl-1000: // 2 sources:
                    {
                        if (this.mNodes.size() != 0 || this.mStartDelay != 0) return;
                        {
                            this.mStarted = false;
                            if (this.mListeners == null) return;
                            {
                                var6_4 = (ArrayList)this.mListeners.clone();
                                var2_7 = var6_4.size();
                                break;
                            }
                        }
                    }
                    ((Animator.AnimatorListener)var6_4.get(var1_3)).onAnimationStart(this);
                    ++var1_3;
                } while (true);
                for (var1_3 = var3_1; var1_3 < var2_7; ++var1_3) {
                    ((Animator.AnimatorListener)var6_4.get(var1_3)).onAnimationEnd(this);
                }
                return;
lbl59: // 1 sources:
                var7_5 = new ArrayList<Animator.AnimatorListener>(var7_5).iterator();
                do {
                    if (!var7_5.hasNext()) lbl-1000: // 2 sources:
                    {
                        ++var1_3;
                        continue block0;
                    }
                    var8_6 = (Animator.AnimatorListener)var7_5.next();
                    if (!(var8_6 instanceof DependencyListener) && !(var8_6 instanceof AnimatorSetListener)) continue;
                    var6_4.animation.removeListener((Animator.AnimatorListener)var8_6);
                } while (true);
                break;
            } while (true);
lbl68: // 2 sources:
            do {
                var7_5.animation.addListener(this.mSetListener);
                ++var1_3;
                ** GOTO lbl16
                break;
            } while (true);
        }
        var5_8 = var7_5.dependencies.size();
        var2_7 = 0;
        do {
            if (var2_7 >= var5_8) {
                var7_5.tmpDependencies = (ArrayList)var7_5.dependencies.clone();
                ** continue;
            }
            var8_6 = var7_5.dependencies.get(var2_7);
            var8_6.node.animation.addListener(new DependencyListener(this, (Node)var7_5, var8_6.rule));
            ++var2_7;
        } while (true);
    }

    class AnimatorSetListener
    implements Animator.AnimatorListener {
        private AnimatorSet mAnimatorSet;

        AnimatorSetListener(AnimatorSet animatorSet2) {
            this.mAnimatorSet = animatorSet2;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        public void onAnimationCancel(Animator animator) {
            if (AnimatorSet.this.mTerminated || AnimatorSet.this.mPlayingSet.size() != 0 || AnimatorSet.this.mListeners == null) return;
            int n2 = AnimatorSet.this.mListeners.size();
            int n3 = 0;
            while (n3 < n2) {
                ((Animator.AnimatorListener)AnimatorSet.this.mListeners.get(n3)).onAnimationCancel(this.mAnimatorSet);
                ++n3;
            }
            return;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        @Override
        public void onAnimationEnd(Animator var1_1) {
            var1_1.removeListener(this);
            AnimatorSet.access$2(AnimatorSet.this).remove(var1_1);
            ((Node)AnimatorSet.access$3((AnimatorSet)this.mAnimatorSet).get((Object)var1_1)).done = true;
            if (AnimatorSet.this.mTerminated != false) return;
            var1_2 = AnimatorSet.access$4(this.mAnimatorSet);
            var3_4 = var1_2.size();
            var2_5 = 0;
            do {
                if (var2_5 < var3_4) ** GOTO lbl15
                var2_5 = 1;
                if (var2_5 == 0) return;
                if (AnimatorSet.this.mListeners != null) {
                    break;
                }
                ** GOTO lbl-1000
lbl15: // 1 sources:
                if (!((Node)var1_2.get((int)var2_5)).done) {
                    return;
                }
                ++var2_5;
            } while (true);
            var1_3 = (ArrayList)AnimatorSet.this.mListeners.clone();
            var3_4 = var1_3.size();
            var2_5 = 0;
            do {
                if (var2_5 >= var3_4) lbl-1000: // 2 sources:
                {
                    AnimatorSet.access$5(this.mAnimatorSet, false);
                    return;
                }
                ((Animator.AnimatorListener)var1_3.get(var2_5)).onAnimationEnd(this.mAnimatorSet);
                ++var2_5;
            } while (true);
        }

        @Override
        public void onAnimationRepeat(Animator animator) {
        }

        @Override
        public void onAnimationStart(Animator animator) {
        }
    }

    public class Builder {
        private Node mCurrentNode;

        Builder(Animator animator) {
            this.mCurrentNode = (Node)AnimatorSet.this.mNodeMap.get(animator);
            if (this.mCurrentNode == null) {
                this.mCurrentNode = new Node(animator);
                AnimatorSet.this.mNodeMap.put(animator, this.mCurrentNode);
                AnimatorSet.this.mNodes.add(this.mCurrentNode);
            }
        }

        public Builder after(long l2) {
            ValueAnimator valueAnimator = ValueAnimator.ofFloat(0.0f, 1.0f);
            valueAnimator.setDuration(l2);
            this.after(valueAnimator);
            return this;
        }

        public Builder after(Animator object) {
            Node node;
            Node node2 = node = (Node)AnimatorSet.this.mNodeMap.get(object);
            if (node == null) {
                node2 = new Node((Animator)object);
                AnimatorSet.this.mNodeMap.put(object, node2);
                AnimatorSet.this.mNodes.add(node2);
            }
            object = new Dependency(node2, 1);
            this.mCurrentNode.addDependency((Dependency)object);
            return this;
        }

        public Builder before(Animator animator) {
            Node node;
            Node node2 = node = (Node)AnimatorSet.this.mNodeMap.get(animator);
            if (node == null) {
                node2 = new Node(animator);
                AnimatorSet.this.mNodeMap.put(animator, node2);
                AnimatorSet.this.mNodes.add(node2);
            }
            node2.addDependency(new Dependency(this.mCurrentNode, 1));
            return this;
        }

        public Builder with(Animator animator) {
            Node node;
            Node node2 = node = (Node)AnimatorSet.this.mNodeMap.get(animator);
            if (node == null) {
                node2 = new Node(animator);
                AnimatorSet.this.mNodeMap.put(animator, node2);
                AnimatorSet.this.mNodes.add(node2);
            }
            node2.addDependency(new Dependency(this.mCurrentNode, 0));
            return this;
        }
    }

    static class Dependency {
        static final int AFTER = 1;
        static final int WITH = 0;
        public Node node;
        public int rule;

        public Dependency(Node node, int n2) {
            this.node = node;
            this.rule = n2;
        }
    }

    static class DependencyListener
    implements Animator.AnimatorListener {
        private AnimatorSet mAnimatorSet;
        private Node mNode;
        private int mRule;

        public DependencyListener(AnimatorSet animatorSet, Node node, int n2) {
            this.mAnimatorSet = animatorSet;
            this.mNode = node;
            this.mRule = n2;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        private void startIfReady(Animator var1_1) {
            if (this.mAnimatorSet.mTerminated) {
                return;
            }
            var3_2 = this.mNode.tmpDependencies.size();
            var2_3 = 0;
            do {
                if (var2_3 < var3_2) ** GOTO lbl9
                var1_1 = null;
                ** GOTO lbl13
lbl9: // 1 sources:
                var4_4 = this.mNode.tmpDependencies.get(var2_3);
                if (var4_4.rule == this.mRule && var4_4.node.animation == var1_1) {
                    var1_1.removeListener(this);
                    var1_1 = var4_4;
lbl13: // 2 sources:
                    this.mNode.tmpDependencies.remove(var1_1);
                    if (this.mNode.tmpDependencies.size() != 0) return;
                    this.mNode.animation.start();
                    AnimatorSet.access$2(this.mAnimatorSet).add(this.mNode.animation);
                    return;
                }
                ++var2_3;
            } while (true);
        }

        @Override
        public void onAnimationCancel(Animator animator) {
        }

        @Override
        public void onAnimationEnd(Animator animator) {
            if (this.mRule == 1) {
                this.startIfReady(animator);
            }
        }

        @Override
        public void onAnimationRepeat(Animator animator) {
        }

        @Override
        public void onAnimationStart(Animator animator) {
            if (this.mRule == 0) {
                this.startIfReady(animator);
            }
        }
    }

    static class Node
    implements Cloneable {
        public Animator animation;
        public ArrayList<Dependency> dependencies = null;
        public boolean done = false;
        public ArrayList<Node> nodeDependencies = null;
        public ArrayList<Node> nodeDependents = null;
        public ArrayList<Dependency> tmpDependencies = null;

        public Node(Animator animator) {
            this.animation = animator;
        }

        public void addDependency(Dependency object) {
            if (this.dependencies == null) {
                this.dependencies = new ArrayList();
                this.nodeDependencies = new ArrayList();
            }
            this.dependencies.add((Dependency)object);
            if (!this.nodeDependencies.contains(object.node)) {
                this.nodeDependencies.add(object.node);
            }
            object = object.node;
            if (object.nodeDependents == null) {
                object.nodeDependents = new ArrayList();
            }
            object.nodeDependents.add(this);
        }

        public Node clone() {
            try {
                Node node = (Node)super.clone();
                node.animation = this.animation.clone();
                return node;
            }
            catch (CloneNotSupportedException var1_2) {
                throw new AssertionError();
            }
        }
    }

}

