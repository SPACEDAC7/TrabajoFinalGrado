/*
 * Decompiled with CFR 0_115.
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import com.actionbarsherlock.internal.nineoldandroids.animation.TypeEvaluator;

public class FloatEvaluator
implements TypeEvaluator<Number> {
    @Override
    public Float evaluate(float f2, Number number, Number number2) {
        float f3 = number.floatValue();
        return Float.valueOf(f3 + (number2.floatValue() - f3) * f2);
    }
}

