/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import android.view.animation.Interpolator;
import com.actionbarsherlock.internal.nineoldandroids.animation.Keyframe;
import com.actionbarsherlock.internal.nineoldandroids.animation.KeyframeSet;
import com.actionbarsherlock.internal.nineoldandroids.animation.TypeEvaluator;
import java.util.ArrayList;

class FloatKeyframeSet
extends KeyframeSet {
    private float deltaValue;
    private boolean firstTime = true;
    private float firstValue;
    private float lastValue;

    public /* varargs */ FloatKeyframeSet(Keyframe.FloatKeyframe ... arrfloatKeyframe) {
        super(arrfloatKeyframe);
    }

    @Override
    public FloatKeyframeSet clone() {
        ArrayList arrayList = this.mKeyframes;
        int n2 = this.mKeyframes.size();
        Keyframe.FloatKeyframe[] arrfloatKeyframe = new Keyframe.FloatKeyframe[n2];
        int n3 = 0;
        while (n3 < n2) {
            arrfloatKeyframe[n3] = (Keyframe.FloatKeyframe)((Keyframe)arrayList.get(n3)).clone();
            ++n3;
        }
        return new FloatKeyframeSet(arrfloatKeyframe);
    }

    public float getFloatValue(float f2) {
        int n2 = 1;
        if (this.mNumKeyframes == 2) {
            if (this.firstTime) {
                this.firstTime = false;
                this.firstValue = ((Keyframe.FloatKeyframe)this.mKeyframes.get(0)).getFloatValue();
                this.lastValue = ((Keyframe.FloatKeyframe)this.mKeyframes.get(1)).getFloatValue();
                this.deltaValue = this.lastValue - this.firstValue;
            }
            float f3 = f2;
            if (this.mInterpolator != null) {
                f3 = this.mInterpolator.getInterpolation(f2);
            }
            if (this.mEvaluator == null) {
                return this.firstValue + this.deltaValue * f3;
            }
            return ((Number)this.mEvaluator.evaluate(f3, Float.valueOf(this.firstValue), Float.valueOf(this.lastValue))).floatValue();
        }
        if (f2 <= 0.0f) {
            Keyframe.FloatKeyframe floatKeyframe = (Keyframe.FloatKeyframe)this.mKeyframes.get(0);
            Keyframe.FloatKeyframe floatKeyframe2 = (Keyframe.FloatKeyframe)this.mKeyframes.get(1);
            float f4 = floatKeyframe.getFloatValue();
            float f5 = floatKeyframe2.getFloatValue();
            float f6 = floatKeyframe.getFraction();
            float f7 = floatKeyframe2.getFraction();
            floatKeyframe = floatKeyframe2.getInterpolator();
            float f8 = f2;
            if (floatKeyframe != null) {
                f8 = floatKeyframe.getInterpolation(f2);
            }
            f2 = (f8 - f6) / (f7 - f6);
            if (this.mEvaluator == null) {
                return f2 * (f5 - f4) + f4;
            }
            return ((Number)this.mEvaluator.evaluate(f2, Float.valueOf(f4), Float.valueOf(f5))).floatValue();
        }
        if (f2 >= 1.0f) {
            Keyframe.FloatKeyframe floatKeyframe = (Keyframe.FloatKeyframe)this.mKeyframes.get(this.mNumKeyframes - 2);
            Keyframe.FloatKeyframe floatKeyframe3 = (Keyframe.FloatKeyframe)this.mKeyframes.get(this.mNumKeyframes - 1);
            float f9 = floatKeyframe.getFloatValue();
            float f10 = floatKeyframe3.getFloatValue();
            float f11 = floatKeyframe.getFraction();
            float f12 = floatKeyframe3.getFraction();
            floatKeyframe = floatKeyframe3.getInterpolator();
            float f13 = f2;
            if (floatKeyframe != null) {
                f13 = floatKeyframe.getInterpolation(f2);
            }
            f2 = (f13 - f11) / (f12 - f11);
            if (this.mEvaluator == null) {
                return f2 * (f10 - f9) + f9;
            }
            return ((Number)this.mEvaluator.evaluate(f2, Float.valueOf(f9), Float.valueOf(f10))).floatValue();
        }
        Keyframe.FloatKeyframe floatKeyframe = (Keyframe.FloatKeyframe)this.mKeyframes.get(0);
        while (n2 < this.mNumKeyframes) {
            Keyframe.FloatKeyframe floatKeyframe4 = (Keyframe.FloatKeyframe)this.mKeyframes.get(n2);
            if (f2 < floatKeyframe4.getFraction()) {
                Interpolator interpolator = floatKeyframe4.getInterpolator();
                float f14 = f2;
                if (interpolator != null) {
                    f14 = interpolator.getInterpolation(f2);
                }
                f2 = (f14 - floatKeyframe.getFraction()) / (floatKeyframe4.getFraction() - floatKeyframe.getFraction());
                f14 = floatKeyframe.getFloatValue();
                float f15 = floatKeyframe4.getFloatValue();
                if (this.mEvaluator == null) {
                    return (f15 - f14) * f2 + f14;
                }
                return ((Number)this.mEvaluator.evaluate(f2, Float.valueOf(f14), Float.valueOf(f15))).floatValue();
            }
            ++n2;
            floatKeyframe = floatKeyframe4;
        }
        return ((Number)((Keyframe)this.mKeyframes.get(this.mNumKeyframes - 1)).getValue()).floatValue();
    }

    @Override
    public Object getValue(float f2) {
        return Float.valueOf(this.getFloatValue(f2));
    }
}

