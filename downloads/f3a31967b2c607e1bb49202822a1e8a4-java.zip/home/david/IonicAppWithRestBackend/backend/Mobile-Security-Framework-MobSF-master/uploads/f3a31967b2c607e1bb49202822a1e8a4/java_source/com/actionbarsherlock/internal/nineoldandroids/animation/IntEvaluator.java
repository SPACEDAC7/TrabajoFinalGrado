/*
 * Decompiled with CFR 0_115.
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import com.actionbarsherlock.internal.nineoldandroids.animation.TypeEvaluator;

public class IntEvaluator
implements TypeEvaluator<Integer> {
    @Override
    public Integer evaluate(float f2, Integer n2, Integer n3) {
        int n4 = n2;
        float f3 = n4;
        return (int)((float)(n3 - n4) * f2 + f3);
    }
}

