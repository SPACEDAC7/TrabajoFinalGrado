/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import android.view.animation.Interpolator;
import com.actionbarsherlock.internal.nineoldandroids.animation.Keyframe;
import com.actionbarsherlock.internal.nineoldandroids.animation.KeyframeSet;
import com.actionbarsherlock.internal.nineoldandroids.animation.TypeEvaluator;
import java.util.ArrayList;

class IntKeyframeSet
extends KeyframeSet {
    private int deltaValue;
    private boolean firstTime = true;
    private int firstValue;
    private int lastValue;

    public /* varargs */ IntKeyframeSet(Keyframe.IntKeyframe ... arrintKeyframe) {
        super(arrintKeyframe);
    }

    @Override
    public IntKeyframeSet clone() {
        ArrayList arrayList = this.mKeyframes;
        int n2 = this.mKeyframes.size();
        Keyframe.IntKeyframe[] arrintKeyframe = new Keyframe.IntKeyframe[n2];
        int n3 = 0;
        while (n3 < n2) {
            arrintKeyframe[n3] = (Keyframe.IntKeyframe)((Keyframe)arrayList.get(n3)).clone();
            ++n3;
        }
        return new IntKeyframeSet(arrintKeyframe);
    }

    public int getIntValue(float f2) {
        int n2 = 1;
        if (this.mNumKeyframes == 2) {
            if (this.firstTime) {
                this.firstTime = false;
                this.firstValue = ((Keyframe.IntKeyframe)this.mKeyframes.get(0)).getIntValue();
                this.lastValue = ((Keyframe.IntKeyframe)this.mKeyframes.get(1)).getIntValue();
                this.deltaValue = this.lastValue - this.firstValue;
            }
            float f3 = f2;
            if (this.mInterpolator != null) {
                f3 = this.mInterpolator.getInterpolation(f2);
            }
            if (this.mEvaluator == null) {
                return this.firstValue + (int)((float)this.deltaValue * f3);
            }
            return ((Number)this.mEvaluator.evaluate(f3, this.firstValue, this.lastValue)).intValue();
        }
        if (f2 <= 0.0f) {
            Keyframe.IntKeyframe intKeyframe = (Keyframe.IntKeyframe)this.mKeyframes.get(0);
            Keyframe.IntKeyframe intKeyframe2 = (Keyframe.IntKeyframe)this.mKeyframes.get(1);
            n2 = intKeyframe.getIntValue();
            int n3 = intKeyframe2.getIntValue();
            float f4 = intKeyframe.getFraction();
            float f5 = intKeyframe2.getFraction();
            intKeyframe = intKeyframe2.getInterpolator();
            float f6 = f2;
            if (intKeyframe != null) {
                f6 = intKeyframe.getInterpolation(f2);
            }
            f2 = (f6 - f4) / (f5 - f4);
            if (this.mEvaluator == null) {
                return (int)(f2 * (float)(n3 - n2)) + n2;
            }
            return ((Number)this.mEvaluator.evaluate(f2, n2, n3)).intValue();
        }
        if (f2 >= 1.0f) {
            Keyframe.IntKeyframe intKeyframe = (Keyframe.IntKeyframe)this.mKeyframes.get(this.mNumKeyframes - 2);
            Keyframe.IntKeyframe intKeyframe3 = (Keyframe.IntKeyframe)this.mKeyframes.get(this.mNumKeyframes - 1);
            n2 = intKeyframe.getIntValue();
            int n4 = intKeyframe3.getIntValue();
            float f7 = intKeyframe.getFraction();
            float f8 = intKeyframe3.getFraction();
            intKeyframe = intKeyframe3.getInterpolator();
            float f9 = f2;
            if (intKeyframe != null) {
                f9 = intKeyframe.getInterpolation(f2);
            }
            f2 = (f9 - f7) / (f8 - f7);
            if (this.mEvaluator == null) {
                return (int)(f2 * (float)(n4 - n2)) + n2;
            }
            return ((Number)this.mEvaluator.evaluate(f2, n2, n4)).intValue();
        }
        Keyframe.IntKeyframe intKeyframe = (Keyframe.IntKeyframe)this.mKeyframes.get(0);
        while (n2 < this.mNumKeyframes) {
            Keyframe.IntKeyframe intKeyframe4 = (Keyframe.IntKeyframe)this.mKeyframes.get(n2);
            if (f2 < intKeyframe4.getFraction()) {
                Interpolator interpolator = intKeyframe4.getInterpolator();
                float f10 = f2;
                if (interpolator != null) {
                    f10 = interpolator.getInterpolation(f2);
                }
                f2 = (f10 - intKeyframe.getFraction()) / (intKeyframe4.getFraction() - intKeyframe.getFraction());
                n2 = intKeyframe.getIntValue();
                int n5 = intKeyframe4.getIntValue();
                if (this.mEvaluator == null) {
                    return (int)((float)(n5 - n2) * f2) + n2;
                }
                return ((Number)this.mEvaluator.evaluate(f2, n2, n5)).intValue();
            }
            ++n2;
            intKeyframe = intKeyframe4;
        }
        return ((Number)((Keyframe)this.mKeyframes.get(this.mNumKeyframes - 1)).getValue()).intValue();
    }

    @Override
    public Object getValue(float f2) {
        return this.getIntValue(f2);
    }
}

