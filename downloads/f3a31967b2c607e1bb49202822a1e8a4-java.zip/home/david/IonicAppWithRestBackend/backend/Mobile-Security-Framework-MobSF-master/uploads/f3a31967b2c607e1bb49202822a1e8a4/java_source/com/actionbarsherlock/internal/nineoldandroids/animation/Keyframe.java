/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import android.view.animation.Interpolator;

public abstract class Keyframe
implements Cloneable {
    float mFraction;
    boolean mHasValue = false;
    private Interpolator mInterpolator = null;
    Class mValueType;

    public static Keyframe ofFloat(float f2) {
        return new FloatKeyframe(f2);
    }

    public static Keyframe ofFloat(float f2, float f3) {
        return new FloatKeyframe(f2, f3);
    }

    public static Keyframe ofInt(float f2) {
        return new IntKeyframe(f2);
    }

    public static Keyframe ofInt(float f2, int n2) {
        return new IntKeyframe(f2, n2);
    }

    public static Keyframe ofObject(float f2) {
        return new ObjectKeyframe(f2, null);
    }

    public static Keyframe ofObject(float f2, Object object) {
        return new ObjectKeyframe(f2, object);
    }

    public abstract Keyframe clone();

    public float getFraction() {
        return this.mFraction;
    }

    public Interpolator getInterpolator() {
        return this.mInterpolator;
    }

    public Class getType() {
        return this.mValueType;
    }

    public abstract Object getValue();

    public boolean hasValue() {
        return this.mHasValue;
    }

    public void setFraction(float f2) {
        this.mFraction = f2;
    }

    public void setInterpolator(Interpolator interpolator) {
        this.mInterpolator = interpolator;
    }

    public abstract void setValue(Object var1);

    static class FloatKeyframe
    extends Keyframe {
        float mValue;

        FloatKeyframe(float f2) {
            this.mFraction = f2;
            this.mValueType = Float.TYPE;
        }

        FloatKeyframe(float f2, float f3) {
            this.mFraction = f2;
            this.mValue = f3;
            this.mValueType = Float.TYPE;
            this.mHasValue = true;
        }

        @Override
        public FloatKeyframe clone() {
            FloatKeyframe floatKeyframe = new FloatKeyframe(this.getFraction(), this.mValue);
            floatKeyframe.setInterpolator(this.getInterpolator());
            return floatKeyframe;
        }

        public float getFloatValue() {
            return this.mValue;
        }

        @Override
        public Object getValue() {
            return Float.valueOf(this.mValue);
        }

        @Override
        public void setValue(Object object) {
            if (object != null && object.getClass() == Float.class) {
                this.mValue = ((Float)object).floatValue();
                this.mHasValue = true;
            }
        }
    }

    static class IntKeyframe
    extends Keyframe {
        int mValue;

        IntKeyframe(float f2) {
            this.mFraction = f2;
            this.mValueType = Integer.TYPE;
        }

        IntKeyframe(float f2, int n2) {
            this.mFraction = f2;
            this.mValue = n2;
            this.mValueType = Integer.TYPE;
            this.mHasValue = true;
        }

        @Override
        public IntKeyframe clone() {
            IntKeyframe intKeyframe = new IntKeyframe(this.getFraction(), this.mValue);
            intKeyframe.setInterpolator(this.getInterpolator());
            return intKeyframe;
        }

        public int getIntValue() {
            return this.mValue;
        }

        @Override
        public Object getValue() {
            return this.mValue;
        }

        @Override
        public void setValue(Object object) {
            if (object != null && object.getClass() == Integer.class) {
                this.mValue = (Integer)object;
                this.mHasValue = true;
            }
        }
    }

    static class ObjectKeyframe
    extends Keyframe {
        Object mValue;

        /*
         * Enabled aggressive block sorting
         */
        ObjectKeyframe(float f2, Object class_) {
            this.mFraction = f2;
            this.mValue = class_;
            boolean bl = class_ != null;
            this.mHasValue = bl;
            class_ = this.mHasValue ? class_.getClass() : Object.class;
            this.mValueType = class_;
        }

        @Override
        public ObjectKeyframe clone() {
            ObjectKeyframe objectKeyframe = new ObjectKeyframe(this.getFraction(), this.mValue);
            objectKeyframe.setInterpolator(this.getInterpolator());
            return objectKeyframe;
        }

        @Override
        public Object getValue() {
            return this.mValue;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void setValue(Object object) {
            this.mValue = object;
            boolean bl = object != null;
            this.mHasValue = bl;
        }
    }

}

