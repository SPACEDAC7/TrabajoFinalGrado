/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import android.view.animation.Interpolator;
import com.actionbarsherlock.internal.nineoldandroids.animation.FloatKeyframeSet;
import com.actionbarsherlock.internal.nineoldandroids.animation.IntKeyframeSet;
import com.actionbarsherlock.internal.nineoldandroids.animation.Keyframe;
import com.actionbarsherlock.internal.nineoldandroids.animation.TypeEvaluator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

class KeyframeSet {
    TypeEvaluator mEvaluator;
    Keyframe mFirstKeyframe;
    Interpolator mInterpolator;
    ArrayList<Keyframe> mKeyframes;
    Keyframe mLastKeyframe;
    int mNumKeyframes;

    public /* varargs */ KeyframeSet(Keyframe ... arrkeyframe) {
        this.mNumKeyframes = arrkeyframe.length;
        this.mKeyframes = new ArrayList();
        this.mKeyframes.addAll(Arrays.asList(arrkeyframe));
        this.mFirstKeyframe = this.mKeyframes.get(0);
        this.mLastKeyframe = this.mKeyframes.get(this.mNumKeyframes - 1);
        this.mInterpolator = this.mLastKeyframe.getInterpolator();
    }

    /*
     * Enabled aggressive block sorting
     */
    public static /* varargs */ KeyframeSet ofFloat(float ... arrf) {
        int n2 = arrf.length;
        Keyframe.FloatKeyframe[] arrfloatKeyframe = new Keyframe.FloatKeyframe[java.lang.Math.max(n2, 2)];
        if (n2 == 1) {
            arrfloatKeyframe[0] = (Keyframe.FloatKeyframe)Keyframe.ofFloat(0.0f);
            arrfloatKeyframe[1] = (Keyframe.FloatKeyframe)Keyframe.ofFloat(1.0f, arrf[0]);
            return new FloatKeyframeSet(arrfloatKeyframe);
        } else {
            arrfloatKeyframe[0] = (Keyframe.FloatKeyframe)Keyframe.ofFloat(0.0f, arrf[0]);
            for (int i2 = 1; i2 < n2; ++i2) {
                arrfloatKeyframe[i2] = (Keyframe.FloatKeyframe)Keyframe.ofFloat((float)i2 / (float)(n2 - 1), arrf[i2]);
            }
        }
        return new FloatKeyframeSet(arrfloatKeyframe);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static /* varargs */ KeyframeSet ofInt(int ... arrn) {
        int n2 = arrn.length;
        Keyframe.IntKeyframe[] arrintKeyframe = new Keyframe.IntKeyframe[java.lang.Math.max(n2, 2)];
        if (n2 == 1) {
            arrintKeyframe[0] = (Keyframe.IntKeyframe)Keyframe.ofInt(0.0f);
            arrintKeyframe[1] = (Keyframe.IntKeyframe)Keyframe.ofInt(1.0f, arrn[0]);
            return new IntKeyframeSet(arrintKeyframe);
        } else {
            arrintKeyframe[0] = (Keyframe.IntKeyframe)Keyframe.ofInt(0.0f, arrn[0]);
            for (int i2 = 1; i2 < n2; ++i2) {
                arrintKeyframe[i2] = (Keyframe.IntKeyframe)Keyframe.ofInt((float)i2 / (float)(n2 - 1), arrn[i2]);
            }
        }
        return new IntKeyframeSet(arrintKeyframe);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static /* varargs */ KeyframeSet ofKeyframe(Keyframe ... var0) {
        block10 : {
            var5_1 = 0;
            var6_2 = var0.length;
            var1_3 = 0;
            var4_4 = false;
            var3_5 = false;
            var2_6 = false;
            do {
                if (var1_3 >= var6_2) {
                    if (!var2_6 || var3_5 || var4_4) break;
                    break block10;
                }
                if (var0[var1_3] instanceof Keyframe.FloatKeyframe) {
                    var2_6 = true;
                } else if (var0[var1_3] instanceof Keyframe.IntKeyframe) {
                    var3_5 = true;
                } else {
                    var4_4 = true;
                }
                ++var1_3;
            } while (true);
            ** GOTO lbl30
        }
        var7_7 = new Keyframe.FloatKeyframe[var6_2];
        var1_3 = var5_1;
        do {
            if (var1_3 >= var6_2) {
                return new FloatKeyframeSet(var7_7);
            }
            var7_7[var1_3] = (Keyframe.FloatKeyframe)var0[var1_3];
            ++var1_3;
        } while (true);
lbl30: // 1 sources:
        if (var3_5 == false) return new KeyframeSet(var0);
        if (var2_6 != false) return new KeyframeSet(var0);
        if (var4_4 != false) return new KeyframeSet(var0);
        var7_8 = new Keyframe.IntKeyframe[var6_2];
        var1_3 = 0;
        do {
            if (var1_3 >= var6_2) {
                return new IntKeyframeSet(var7_8);
            }
            var7_8[var1_3] = (Keyframe.IntKeyframe)var0[var1_3];
            ++var1_3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static /* varargs */ KeyframeSet ofObject(Object ... arrobject) {
        int n2 = arrobject.length;
        Keyframe[] arrkeyframe = new Keyframe.ObjectKeyframe[java.lang.Math.max(n2, 2)];
        if (n2 == 1) {
            arrkeyframe[0] = (Keyframe.ObjectKeyframe)Keyframe.ofObject(0.0f);
            arrkeyframe[1] = (Keyframe.ObjectKeyframe)Keyframe.ofObject(1.0f, arrobject[0]);
            return new KeyframeSet(arrkeyframe);
        } else {
            arrkeyframe[0] = (Keyframe.ObjectKeyframe)Keyframe.ofObject(0.0f, arrobject[0]);
            for (int i2 = 1; i2 < n2; ++i2) {
                arrkeyframe[i2] = (Keyframe.ObjectKeyframe)Keyframe.ofObject((float)i2 / (float)(n2 - 1), arrobject[i2]);
            }
        }
        return new KeyframeSet(arrkeyframe);
    }

    public KeyframeSet clone() {
        ArrayList<Keyframe> arrayList = this.mKeyframes;
        int n2 = this.mKeyframes.size();
        Keyframe[] arrkeyframe = new Keyframe[n2];
        int n3 = 0;
        while (n3 < n2) {
            arrkeyframe[n3] = arrayList.get(n3).clone();
            ++n3;
        }
        return new KeyframeSet(arrkeyframe);
    }

    public Object getValue(float f2) {
        if (this.mNumKeyframes == 2) {
            float f3 = f2;
            if (this.mInterpolator != null) {
                f3 = this.mInterpolator.getInterpolation(f2);
            }
            return this.mEvaluator.evaluate(f3, this.mFirstKeyframe.getValue(), this.mLastKeyframe.getValue());
        }
        if (f2 <= 0.0f) {
            Keyframe keyframe = this.mKeyframes.get(1);
            Interpolator interpolator = keyframe.getInterpolator();
            float f4 = f2;
            if (interpolator != null) {
                f4 = interpolator.getInterpolation(f2);
            }
            f2 = this.mFirstKeyframe.getFraction();
            f2 = (f4 - f2) / (keyframe.getFraction() - f2);
            return this.mEvaluator.evaluate(f2, this.mFirstKeyframe.getValue(), keyframe.getValue());
        }
        if (f2 >= 1.0f) {
            Keyframe keyframe = this.mKeyframes.get(this.mNumKeyframes - 2);
            Interpolator interpolator = this.mLastKeyframe.getInterpolator();
            float f5 = f2;
            if (interpolator != null) {
                f5 = interpolator.getInterpolation(f2);
            }
            f2 = keyframe.getFraction();
            f2 = (f5 - f2) / (this.mLastKeyframe.getFraction() - f2);
            return this.mEvaluator.evaluate(f2, keyframe.getValue(), this.mLastKeyframe.getValue());
        }
        Keyframe keyframe = this.mFirstKeyframe;
        int n2 = 1;
        while (n2 < this.mNumKeyframes) {
            Keyframe keyframe2 = this.mKeyframes.get(n2);
            if (f2 < keyframe2.getFraction()) {
                Interpolator interpolator = keyframe2.getInterpolator();
                float f6 = f2;
                if (interpolator != null) {
                    f6 = interpolator.getInterpolation(f2);
                }
                f2 = keyframe.getFraction();
                f2 = (f6 - f2) / (keyframe2.getFraction() - f2);
                return this.mEvaluator.evaluate(f2, keyframe.getValue(), keyframe2.getValue());
            }
            ++n2;
            keyframe = keyframe2;
        }
        return this.mLastKeyframe.getValue();
    }

    public void setEvaluator(TypeEvaluator typeEvaluator) {
        this.mEvaluator = typeEvaluator;
    }

    public String toString() {
        String string2 = " ";
        int n2 = 0;
        while (n2 < this.mNumKeyframes) {
            string2 = String.valueOf(string2) + this.mKeyframes.get(n2).getValue() + "  ";
            ++n2;
        }
        return string2;
    }
}

