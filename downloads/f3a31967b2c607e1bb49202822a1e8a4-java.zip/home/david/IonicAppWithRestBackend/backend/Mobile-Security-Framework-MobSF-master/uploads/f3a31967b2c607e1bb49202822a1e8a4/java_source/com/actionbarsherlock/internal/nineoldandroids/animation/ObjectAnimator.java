/*
 * Decompiled with CFR 0_115.
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import com.actionbarsherlock.internal.nineoldandroids.animation.Animator;
import com.actionbarsherlock.internal.nineoldandroids.animation.PropertyValuesHolder;
import com.actionbarsherlock.internal.nineoldandroids.animation.TypeEvaluator;
import com.actionbarsherlock.internal.nineoldandroids.animation.ValueAnimator;
import java.util.HashMap;

public final class ObjectAnimator
extends ValueAnimator {
    private static final boolean DBG = false;
    private String mPropertyName;
    private Object mTarget;

    public ObjectAnimator() {
    }

    private ObjectAnimator(Object object, String string2) {
        this.mTarget = object;
        this.setPropertyName(string2);
    }

    public static /* varargs */ ObjectAnimator ofFloat(Object object, String string2, float ... arrf) {
        object = new ObjectAnimator(object, string2);
        object.setFloatValues(arrf);
        return object;
    }

    public static /* varargs */ ObjectAnimator ofInt(Object object, String string2, int ... arrn) {
        object = new ObjectAnimator(object, string2);
        object.setIntValues(arrn);
        return object;
    }

    public static /* varargs */ ObjectAnimator ofObject(Object object, String string2, TypeEvaluator typeEvaluator, Object ... arrobject) {
        object = new ObjectAnimator(object, string2);
        object.setObjectValues(arrobject);
        object.setEvaluator(typeEvaluator);
        return object;
    }

    public static /* varargs */ ObjectAnimator ofPropertyValuesHolder(Object object, PropertyValuesHolder ... arrpropertyValuesHolder) {
        ObjectAnimator objectAnimator = new ObjectAnimator();
        objectAnimator.mTarget = object;
        objectAnimator.setValues(arrpropertyValuesHolder);
        return objectAnimator;
    }

    @Override
    final void animateValue(float f2) {
        super.animateValue(f2);
        int n2 = this.mValues.length;
        int n3 = 0;
        while (n3 < n2) {
            this.mValues[n3].setAnimatedValue(this.mTarget);
            ++n3;
        }
        return;
    }

    @Override
    public final ObjectAnimator clone() {
        return (ObjectAnimator)super.clone();
    }

    public final String getPropertyName() {
        return this.mPropertyName;
    }

    public final Object getTarget() {
        return this.mTarget;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    final void initAnimation() {
        if (this.mInitialized) return;
        int n2 = this.mValues.length;
        int n3 = 0;
        do {
            if (n3 >= n2) {
                super.initAnimation();
                return;
            }
            this.mValues[n3].setupSetterAndGetter(this.mTarget);
            ++n3;
        } while (true);
    }

    @Override
    public final ObjectAnimator setDuration(long l2) {
        super.setDuration(l2);
        return this;
    }

    @Override
    public final /* varargs */ void setFloatValues(float ... arrf) {
        if (this.mValues == null || this.mValues.length == 0) {
            this.setValues(PropertyValuesHolder.ofFloat(this.mPropertyName, arrf));
            return;
        }
        super.setFloatValues(arrf);
    }

    @Override
    public final /* varargs */ void setIntValues(int ... arrn) {
        if (this.mValues == null || this.mValues.length == 0) {
            this.setValues(PropertyValuesHolder.ofInt(this.mPropertyName, arrn));
            return;
        }
        super.setIntValues(arrn);
    }

    @Override
    public final /* varargs */ void setObjectValues(Object ... arrobject) {
        if (this.mValues == null || this.mValues.length == 0) {
            this.setValues(PropertyValuesHolder.ofObject(this.mPropertyName, null, arrobject));
            return;
        }
        super.setObjectValues(arrobject);
    }

    public final void setPropertyName(String string2) {
        if (this.mValues != null) {
            PropertyValuesHolder propertyValuesHolder = this.mValues[0];
            String string3 = propertyValuesHolder.getPropertyName();
            propertyValuesHolder.setPropertyName(string2);
            this.mValuesMap.remove(string3);
            this.mValuesMap.put(string2, propertyValuesHolder);
        }
        this.mPropertyName = string2;
        this.mInitialized = false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void setTarget(Object object) {
        if (this.mTarget == object) return;
        Object object2 = this.mTarget;
        this.mTarget = object;
        if (object2 != null && object != null && object2.getClass() == object.getClass()) {
            return;
        }
        this.mInitialized = false;
    }

    @Override
    public final void setupEndValues() {
        this.initAnimation();
        int n2 = this.mValues.length;
        int n3 = 0;
        while (n3 < n2) {
            this.mValues[n3].setupEndValue(this.mTarget);
            ++n3;
        }
        return;
    }

    @Override
    public final void setupStartValues() {
        this.initAnimation();
        int n2 = this.mValues.length;
        int n3 = 0;
        while (n3 < n2) {
            this.mValues[n3].setupStartValue(this.mTarget);
            ++n3;
        }
        return;
    }

    @Override
    public final void start() {
        super.start();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final String toString() {
        String string2;
        String string3 = string2 = "ObjectAnimator@" + Integer.toHexString(this.hashCode()) + ", target " + this.mTarget;
        if (this.mValues == null) return string3;
        int n2 = 0;
        while (n2 < this.mValues.length) {
            string2 = String.valueOf(string2) + "\n    " + this.mValues[n2].toString();
            ++n2;
        }
        return string2;
    }
}

