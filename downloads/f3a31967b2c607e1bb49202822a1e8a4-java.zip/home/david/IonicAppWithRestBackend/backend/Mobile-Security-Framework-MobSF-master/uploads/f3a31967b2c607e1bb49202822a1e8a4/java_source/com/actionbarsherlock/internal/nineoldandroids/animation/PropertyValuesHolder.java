/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import android.util.Log;
import com.actionbarsherlock.internal.nineoldandroids.animation.FloatEvaluator;
import com.actionbarsherlock.internal.nineoldandroids.animation.FloatKeyframeSet;
import com.actionbarsherlock.internal.nineoldandroids.animation.IntEvaluator;
import com.actionbarsherlock.internal.nineoldandroids.animation.IntKeyframeSet;
import com.actionbarsherlock.internal.nineoldandroids.animation.Keyframe;
import com.actionbarsherlock.internal.nineoldandroids.animation.KeyframeSet;
import com.actionbarsherlock.internal.nineoldandroids.animation.TypeEvaluator;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class PropertyValuesHolder
implements Cloneable {
    private static Class[] DOUBLE_VARIANTS;
    private static Class[] FLOAT_VARIANTS;
    private static Class[] INTEGER_VARIANTS;
    private static final TypeEvaluator sFloatEvaluator;
    private static final HashMap<Class, HashMap<String, Method>> sGetterPropertyMap;
    private static final TypeEvaluator sIntEvaluator;
    private static final HashMap<Class, HashMap<String, Method>> sSetterPropertyMap;
    private Object mAnimatedValue;
    private TypeEvaluator mEvaluator;
    private Method mGetter = null;
    KeyframeSet mKeyframeSet = null;
    final ReentrantReadWriteLock mPropertyMapLock = new ReentrantReadWriteLock();
    String mPropertyName;
    Method mSetter = null;
    final Object[] mTmpValueArray = new Object[1];
    Class mValueType;

    static {
        sIntEvaluator = new IntEvaluator();
        sFloatEvaluator = new FloatEvaluator();
        FLOAT_VARIANTS = new Class[]{Float.TYPE, Float.class, Double.TYPE, Integer.TYPE, Double.class, Integer.class};
        INTEGER_VARIANTS = new Class[]{Integer.TYPE, Integer.class, Float.TYPE, Double.TYPE, Float.class, Double.class};
        DOUBLE_VARIANTS = new Class[]{Double.TYPE, Double.class, Float.TYPE, Integer.TYPE, Float.class, Integer.class};
        sSetterPropertyMap = new HashMap();
        sGetterPropertyMap = new HashMap();
    }

    private PropertyValuesHolder(String string2) {
        this.mPropertyName = string2;
    }

    /* synthetic */ PropertyValuesHolder(String string2, PropertyValuesHolder propertyValuesHolder) {
        this(string2);
    }

    static String getMethodName(String string2, String string3) {
        if (string3 == null || string3.length() == 0) {
            return string2;
        }
        char c2 = Character.toUpperCase(string3.charAt(0));
        string3 = string3.substring(1);
        return String.valueOf(string2) + c2 + string3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Method getPropertyFunction(Class class_, String object, Class arrclass) {
        Method method = null;
        String string2 = PropertyValuesHolder.getMethodName((String)object, this.mPropertyName);
        if (arrclass == null) {
            try {
                return class_.getMethod(string2, null);
            }
            catch (NoSuchMethodException var2_3) {
                Log.e((String)"PropertyValuesHolder", (String)(String.valueOf(class_.getSimpleName()) + " - Couldn't find no-arg method for property " + this.mPropertyName + ": " + var2_3));
                return null;
            }
        }
        Class[] arrclass2 = new Class[1];
        arrclass = this.mValueType.equals(Float.class) ? FLOAT_VARIANTS : (this.mValueType.equals(Integer.class) ? INTEGER_VARIANTS : (this.mValueType.equals(Double.class) ? DOUBLE_VARIANTS : new Class[]{this.mValueType}));
        int n2 = arrclass.length;
        int n3 = 0;
        do {
            Class class_2;
            if (n3 >= n2) {
                Log.e((String)"PropertyValuesHolder", (String)("Couldn't find " + (String)object + "ter property " + this.mPropertyName + " for " + class_.getSimpleName() + " with value type " + this.mValueType));
                return method;
            }
            arrclass2[0] = class_2 = arrclass[n3];
            try {
                Method method2;
                method = method2 = class_.getMethod(string2, arrclass2);
                this.mValueType = class_2;
                return method2;
            }
            catch (NoSuchMethodException var7_10) {
                ++n3;
                continue;
            }
            break;
        } while (true);
    }

    public static /* varargs */ PropertyValuesHolder ofFloat(String string2, float ... arrf) {
        return new FloatPropertyValuesHolder(string2, arrf);
    }

    public static /* varargs */ PropertyValuesHolder ofInt(String string2, int ... arrn) {
        return new IntPropertyValuesHolder(string2, arrn);
    }

    public static /* varargs */ PropertyValuesHolder ofKeyframe(String object, Keyframe ... arrkeyframe) {
        KeyframeSet keyframeSet = KeyframeSet.ofKeyframe(arrkeyframe);
        if (keyframeSet instanceof IntKeyframeSet) {
            return new IntPropertyValuesHolder((String)object, (IntKeyframeSet)keyframeSet);
        }
        if (keyframeSet instanceof FloatKeyframeSet) {
            return new FloatPropertyValuesHolder((String)object, (FloatKeyframeSet)keyframeSet);
        }
        object = new PropertyValuesHolder((String)object);
        object.mKeyframeSet = keyframeSet;
        object.mValueType = arrkeyframe[0].getType();
        return object;
    }

    public static /* varargs */ PropertyValuesHolder ofObject(String object, TypeEvaluator typeEvaluator, Object ... arrobject) {
        object = new PropertyValuesHolder((String)object);
        object.setObjectValues(arrobject);
        object.setEvaluator(typeEvaluator);
        return object;
    }

    private void setupGetter(Class class_) {
        this.mGetter = this.setupSetterOrGetter(class_, sGetterPropertyMap, "get", null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Method setupSetterOrGetter(Class genericDeclaration, HashMap<Class, HashMap<String, Method>> hashMap, String hashMap2, Class genericDeclaration2) {
        block5 : {
            Method method;
            block4 : {
                method = null;
                try {
                    this.mPropertyMapLock.writeLock().lock();
                    HashMap<String, Method> hashMap3 = hashMap.get(genericDeclaration);
                    if (hashMap3 != null) {
                        method = hashMap3.get(this.mPropertyName);
                    }
                    if (method != null) break block4;
                    Method method2 = this.getPropertyFunction((Class)genericDeclaration, (String)((Object)hashMap2), (Class)genericDeclaration2);
                    hashMap2 = hashMap3;
                    if (hashMap3 == null) {
                        hashMap2 = new HashMap();
                        hashMap.put((Class)genericDeclaration, hashMap2);
                    }
                    hashMap2.put(this.mPropertyName, (Class)((Object)method2));
                    genericDeclaration = method2;
                    break block5;
                }
                catch (Throwable var1_2) {
                    this.mPropertyMapLock.writeLock().unlock();
                    throw var1_2;
                }
            }
            genericDeclaration = method;
        }
        this.mPropertyMapLock.writeLock().unlock();
        return genericDeclaration;
    }

    private void setupValue(Object object, Keyframe keyframe) {
        try {
            if (this.mGetter == null) {
                this.setupGetter(object.getClass());
            }
            keyframe.setValue(this.mGetter.invoke(object, new Object[0]));
            return;
        }
        catch (InvocationTargetException var1_2) {
            Log.e((String)"PropertyValuesHolder", (String)var1_2.toString());
            return;
        }
        catch (IllegalAccessException var1_3) {
            Log.e((String)"PropertyValuesHolder", (String)var1_3.toString());
            return;
        }
    }

    void calculateValue(float f2) {
        this.mAnimatedValue = this.mKeyframeSet.getValue(f2);
    }

    public PropertyValuesHolder clone() {
        try {
            PropertyValuesHolder propertyValuesHolder = (PropertyValuesHolder)super.clone();
            propertyValuesHolder.mPropertyName = this.mPropertyName;
            propertyValuesHolder.mKeyframeSet = this.mKeyframeSet.clone();
            propertyValuesHolder.mEvaluator = this.mEvaluator;
            return propertyValuesHolder;
        }
        catch (CloneNotSupportedException var1_2) {
            return null;
        }
    }

    Object getAnimatedValue() {
        return this.mAnimatedValue;
    }

    public String getPropertyName() {
        return this.mPropertyName;
    }

    /*
     * Enabled aggressive block sorting
     */
    void init() {
        if (this.mEvaluator == null) {
            TypeEvaluator typeEvaluator = this.mValueType == Integer.class ? sIntEvaluator : (this.mValueType == Float.class ? sFloatEvaluator : null);
            this.mEvaluator = typeEvaluator;
        }
        if (this.mEvaluator != null) {
            this.mKeyframeSet.setEvaluator(this.mEvaluator);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    void setAnimatedValue(Object object) {
        if (this.mSetter == null) return;
        try {
            this.mTmpValueArray[0] = this.getAnimatedValue();
            this.mSetter.invoke(object, this.mTmpValueArray);
            return;
        }
        catch (InvocationTargetException var1_2) {
            Log.e((String)"PropertyValuesHolder", (String)var1_2.toString());
            return;
        }
        catch (IllegalAccessException var1_3) {
            Log.e((String)"PropertyValuesHolder", (String)var1_3.toString());
            return;
        }
    }

    public void setEvaluator(TypeEvaluator typeEvaluator) {
        this.mEvaluator = typeEvaluator;
        this.mKeyframeSet.setEvaluator(typeEvaluator);
    }

    public /* varargs */ void setFloatValues(float ... arrf) {
        this.mValueType = Float.TYPE;
        this.mKeyframeSet = KeyframeSet.ofFloat(arrf);
    }

    public /* varargs */ void setIntValues(int ... arrn) {
        this.mValueType = Integer.TYPE;
        this.mKeyframeSet = KeyframeSet.ofInt(arrn);
    }

    public /* varargs */ void setKeyframes(Keyframe ... arrkeyframe) {
        int n2 = 0;
        int n3 = arrkeyframe.length;
        Keyframe[] arrkeyframe2 = new Keyframe[java.lang.Math.max(n3, 2)];
        this.mValueType = arrkeyframe[0].getType();
        do {
            if (n2 >= n3) {
                this.mKeyframeSet = new KeyframeSet(arrkeyframe2);
                return;
            }
            arrkeyframe2[n2] = arrkeyframe[n2];
            ++n2;
        } while (true);
    }

    public /* varargs */ void setObjectValues(Object ... arrobject) {
        this.mValueType = arrobject[0].getClass();
        this.mKeyframeSet = KeyframeSet.ofObject(arrobject);
    }

    public void setPropertyName(String string2) {
        this.mPropertyName = string2;
    }

    void setupEndValue(Object object) {
        this.setupValue(object, this.mKeyframeSet.mKeyframes.get(this.mKeyframeSet.mKeyframes.size() - 1));
    }

    void setupSetter(Class class_) {
        this.mSetter = this.setupSetterOrGetter(class_, sSetterPropertyMap, "set", this.mValueType);
    }

    void setupSetterAndGetter(Object object) {
        Class class_ = object.getClass();
        if (this.mSetter == null) {
            this.setupSetter(class_);
        }
        Iterator<Keyframe> iterator = this.mKeyframeSet.mKeyframes.iterator();
        while (iterator.hasNext()) {
            Keyframe keyframe = iterator.next();
            if (keyframe.hasValue()) continue;
            if (this.mGetter == null) {
                this.setupGetter(class_);
            }
            try {
                keyframe.setValue(this.mGetter.invoke(object, new Object[0]));
                continue;
            }
            catch (InvocationTargetException var4_5) {
                Log.e((String)"PropertyValuesHolder", (String)var4_5.toString());
                continue;
            }
            catch (IllegalAccessException var4_6) {
                Log.e((String)"PropertyValuesHolder", (String)var4_6.toString());
                continue;
            }
            break;
        }
        return;
    }

    void setupStartValue(Object object) {
        this.setupValue(object, this.mKeyframeSet.mKeyframes.get(0));
    }

    public String toString() {
        return String.valueOf(this.mPropertyName) + ": " + this.mKeyframeSet.toString();
    }

    static class FloatPropertyValuesHolder
    extends PropertyValuesHolder {
        float mFloatAnimatedValue;
        FloatKeyframeSet mFloatKeyframeSet;

        public FloatPropertyValuesHolder(String string2, FloatKeyframeSet floatKeyframeSet) {
            super(string2, null);
            this.mValueType = Float.TYPE;
            this.mKeyframeSet = floatKeyframeSet;
            this.mFloatKeyframeSet = (FloatKeyframeSet)this.mKeyframeSet;
        }

        public /* varargs */ FloatPropertyValuesHolder(String string2, float ... arrf) {
            super(string2, null);
            this.setFloatValues(arrf);
        }

        @Override
        void calculateValue(float f2) {
            this.mFloatAnimatedValue = this.mFloatKeyframeSet.getFloatValue(f2);
        }

        @Override
        public FloatPropertyValuesHolder clone() {
            FloatPropertyValuesHolder floatPropertyValuesHolder = (FloatPropertyValuesHolder)super.clone();
            floatPropertyValuesHolder.mFloatKeyframeSet = (FloatKeyframeSet)floatPropertyValuesHolder.mKeyframeSet;
            return floatPropertyValuesHolder;
        }

        @Override
        Object getAnimatedValue() {
            return Float.valueOf(this.mFloatAnimatedValue);
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        void setAnimatedValue(Object object) {
            if (this.mSetter == null) return;
            try {
                this.mTmpValueArray[0] = Float.valueOf(this.mFloatAnimatedValue);
                this.mSetter.invoke(object, this.mTmpValueArray);
                return;
            }
            catch (InvocationTargetException var1_2) {
                Log.e((String)"PropertyValuesHolder", (String)var1_2.toString());
                return;
            }
            catch (IllegalAccessException var1_3) {
                Log.e((String)"PropertyValuesHolder", (String)var1_3.toString());
                return;
            }
        }

        @Override
        public /* varargs */ void setFloatValues(float ... arrf) {
            super.setFloatValues(arrf);
            this.mFloatKeyframeSet = (FloatKeyframeSet)this.mKeyframeSet;
        }

        @Override
        void setupSetter(Class class_) {
            super.setupSetter(class_);
        }
    }

    static class IntPropertyValuesHolder
    extends PropertyValuesHolder {
        int mIntAnimatedValue;
        IntKeyframeSet mIntKeyframeSet;

        public IntPropertyValuesHolder(String string2, IntKeyframeSet intKeyframeSet) {
            super(string2, null);
            this.mValueType = Integer.TYPE;
            this.mKeyframeSet = intKeyframeSet;
            this.mIntKeyframeSet = (IntKeyframeSet)this.mKeyframeSet;
        }

        public /* varargs */ IntPropertyValuesHolder(String string2, int ... arrn) {
            super(string2, null);
            this.setIntValues(arrn);
        }

        @Override
        void calculateValue(float f2) {
            this.mIntAnimatedValue = this.mIntKeyframeSet.getIntValue(f2);
        }

        @Override
        public IntPropertyValuesHolder clone() {
            IntPropertyValuesHolder intPropertyValuesHolder = (IntPropertyValuesHolder)super.clone();
            intPropertyValuesHolder.mIntKeyframeSet = (IntKeyframeSet)intPropertyValuesHolder.mKeyframeSet;
            return intPropertyValuesHolder;
        }

        @Override
        Object getAnimatedValue() {
            return this.mIntAnimatedValue;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        void setAnimatedValue(Object object) {
            if (this.mSetter == null) return;
            try {
                this.mTmpValueArray[0] = this.mIntAnimatedValue;
                this.mSetter.invoke(object, this.mTmpValueArray);
                return;
            }
            catch (InvocationTargetException var1_2) {
                Log.e((String)"PropertyValuesHolder", (String)var1_2.toString());
                return;
            }
            catch (IllegalAccessException var1_3) {
                Log.e((String)"PropertyValuesHolder", (String)var1_3.toString());
                return;
            }
        }

        @Override
        public /* varargs */ void setIntValues(int ... arrn) {
            super.setIntValues(arrn);
            this.mIntKeyframeSet = (IntKeyframeSet)this.mKeyframeSet;
        }

        @Override
        void setupSetter(Class class_) {
            super.setupSetter(class_);
        }
    }

}

