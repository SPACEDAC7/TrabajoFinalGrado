/*
 * Decompiled with CFR 0_115.
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

public interface TypeEvaluator<T> {
    public T evaluate(float var1, T var2, T var3);
}

