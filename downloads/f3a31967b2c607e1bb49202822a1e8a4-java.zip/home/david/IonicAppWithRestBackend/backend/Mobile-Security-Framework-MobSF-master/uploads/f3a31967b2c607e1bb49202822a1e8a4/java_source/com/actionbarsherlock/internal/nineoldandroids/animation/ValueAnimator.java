/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  android.util.AndroidRuntimeException
 *  android.view.animation.AccelerateDecelerateInterpolator
 *  android.view.animation.AnimationUtils
 *  android.view.animation.Interpolator
 *  android.view.animation.LinearInterpolator
 */
package com.actionbarsherlock.internal.nineoldandroids.animation;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AndroidRuntimeException;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import com.actionbarsherlock.internal.nineoldandroids.animation.Animator;
import com.actionbarsherlock.internal.nineoldandroids.animation.PropertyValuesHolder;
import com.actionbarsherlock.internal.nineoldandroids.animation.TypeEvaluator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class ValueAnimator
extends Animator {
    static final int ANIMATION_FRAME = 1;
    static final int ANIMATION_START = 0;
    private static final long DEFAULT_FRAME_DELAY = 10;
    public static final int INFINITE = -1;
    public static final int RESTART = 1;
    public static final int REVERSE = 2;
    static final int RUNNING = 1;
    static final int SEEKED = 2;
    static final int STOPPED = 0;
    private static ThreadLocal<AnimationHandler> sAnimationHandler = new ThreadLocal();
    private static final ThreadLocal<ArrayList<ValueAnimator>> sAnimations = new ThreadLocal<ArrayList<ValueAnimator>>(){

        @Override
        protected ArrayList<ValueAnimator> initialValue() {
            return new ArrayList<ValueAnimator>();
        }
    };
    private static final Interpolator sDefaultInterpolator;
    private static final ThreadLocal<ArrayList<ValueAnimator>> sDelayedAnims;
    private static final ThreadLocal<ArrayList<ValueAnimator>> sEndingAnims;
    private static long sFrameDelay;
    private static final ThreadLocal<ArrayList<ValueAnimator>> sPendingAnimations;
    private static final ThreadLocal<ArrayList<ValueAnimator>> sReadyAnims;
    private float mCurrentFraction = 0.0f;
    private int mCurrentIteration = 0;
    private long mDelayStartTime;
    private long mDuration = 300;
    boolean mInitialized = false;
    private Interpolator mInterpolator = sDefaultInterpolator;
    private boolean mPlayingBackwards = false;
    int mPlayingState = 0;
    private int mRepeatCount = 0;
    private int mRepeatMode = 1;
    private boolean mRunning = false;
    long mSeekTime = -1;
    private long mStartDelay = 0;
    long mStartTime;
    private boolean mStarted = false;
    private boolean mStartedDelay = false;
    private ArrayList<AnimatorUpdateListener> mUpdateListeners = null;
    PropertyValuesHolder[] mValues;
    HashMap<String, PropertyValuesHolder> mValuesMap;

    static {
        sPendingAnimations = new ThreadLocal<ArrayList<ValueAnimator>>(){

            @Override
            protected ArrayList<ValueAnimator> initialValue() {
                return new ArrayList<ValueAnimator>();
            }
        };
        sDelayedAnims = new ThreadLocal<ArrayList<ValueAnimator>>(){

            @Override
            protected ArrayList<ValueAnimator> initialValue() {
                return new ArrayList<ValueAnimator>();
            }
        };
        sEndingAnims = new ThreadLocal<ArrayList<ValueAnimator>>(){

            @Override
            protected ArrayList<ValueAnimator> initialValue() {
                return new ArrayList<ValueAnimator>();
            }
        };
        sReadyAnims = new ThreadLocal<ArrayList<ValueAnimator>>(){

            @Override
            protected ArrayList<ValueAnimator> initialValue() {
                return new ArrayList<ValueAnimator>();
            }
        };
        sDefaultInterpolator = new AccelerateDecelerateInterpolator();
        sFrameDelay = 10;
    }

    static /* synthetic */ void access$10(ValueAnimator valueAnimator, boolean bl) {
        valueAnimator.mRunning = bl;
    }

    static /* synthetic */ void access$11(ValueAnimator valueAnimator) {
        valueAnimator.endAnimation();
    }

    static /* synthetic */ long access$12() {
        return sFrameDelay;
    }

    static /* synthetic */ ThreadLocal access$2() {
        return sAnimations;
    }

    static /* synthetic */ ThreadLocal access$3() {
        return sDelayedAnims;
    }

    static /* synthetic */ ThreadLocal access$4() {
        return sPendingAnimations;
    }

    static /* synthetic */ long access$5(ValueAnimator valueAnimator) {
        return valueAnimator.mStartDelay;
    }

    static /* synthetic */ void access$6(ValueAnimator valueAnimator) {
        valueAnimator.startAnimation();
    }

    static /* synthetic */ ThreadLocal access$7() {
        return sReadyAnims;
    }

    static /* synthetic */ ThreadLocal access$8() {
        return sEndingAnims;
    }

    static /* synthetic */ boolean access$9(ValueAnimator valueAnimator, long l2) {
        return valueAnimator.delayedAnimationFrame(l2);
    }

    public static void clearAllAnimations() {
        sAnimations.get().clear();
        sPendingAnimations.get().clear();
        sDelayedAnims.get().clear();
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean delayedAnimationFrame(long l2) {
        if (!this.mStartedDelay) {
            this.mStartedDelay = true;
            this.mDelayStartTime = l2;
            return false;
        } else {
            long l3 = l2 - this.mDelayStartTime;
            if (l3 <= this.mStartDelay) return false;
            {
                this.mStartTime = l2 - (l3 - this.mStartDelay);
                this.mPlayingState = 1;
                return true;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void endAnimation() {
        sAnimations.get().remove(this);
        sPendingAnimations.get().remove(this);
        sDelayedAnims.get().remove(this);
        this.mPlayingState = 0;
        if (this.mRunning && this.mListeners != null) {
            ArrayList arrayList = (ArrayList)this.mListeners.clone();
            int n2 = arrayList.size();
            for (int i2 = 0; i2 < n2; ++i2) {
                ((Animator.AnimatorListener)arrayList.get(i2)).onAnimationEnd(this);
            }
        }
        this.mRunning = false;
        this.mStarted = false;
    }

    public static int getCurrentAnimationsCount() {
        return sAnimations.get().size();
    }

    public static long getFrameDelay() {
        return sFrameDelay;
    }

    public static /* varargs */ ValueAnimator ofFloat(float ... arrf) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setFloatValues(arrf);
        return valueAnimator;
    }

    public static /* varargs */ ValueAnimator ofInt(int ... arrn) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setIntValues(arrn);
        return valueAnimator;
    }

    public static /* varargs */ ValueAnimator ofObject(TypeEvaluator typeEvaluator, Object ... arrobject) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setObjectValues(arrobject);
        valueAnimator.setEvaluator(typeEvaluator);
        return valueAnimator;
    }

    public static /* varargs */ ValueAnimator ofPropertyValuesHolder(PropertyValuesHolder ... arrpropertyValuesHolder) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setValues(arrpropertyValuesHolder);
        return valueAnimator;
    }

    public static void setFrameDelay(long l2) {
        sFrameDelay = l2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void start(boolean bl) {
        AnimationHandler animationHandler;
        Object object;
        if (Looper.myLooper() == null) {
            throw new AndroidRuntimeException("Animators may only be run on Looper threads");
        }
        this.mPlayingBackwards = bl;
        this.mCurrentIteration = 0;
        this.mPlayingState = 0;
        this.mStarted = true;
        this.mStartedDelay = false;
        sPendingAnimations.get().add(this);
        if (this.mStartDelay == 0) {
            this.setCurrentPlayTime(this.getCurrentPlayTime());
            this.mPlayingState = 0;
            this.mRunning = true;
            if (this.mListeners != null) {
                object = (ArrayList)this.mListeners.clone();
                int n2 = object.size();
                for (int i2 = 0; i2 < n2; ++i2) {
                    ((Animator.AnimatorListener)object.get(i2)).onAnimationStart(this);
                }
            }
        }
        object = animationHandler = sAnimationHandler.get();
        if (animationHandler == null) {
            object = new AnimationHandler();
            sAnimationHandler.set((AnimationHandler)((Object)object));
        }
        object.sendEmptyMessage(0);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void startAnimation() {
        this.initAnimation();
        sAnimations.get().add(this);
        if (this.mStartDelay <= 0 || this.mListeners == null) return;
        ArrayList arrayList = (ArrayList)this.mListeners.clone();
        int n2 = arrayList.size();
        int n3 = 0;
        while (n3 < n2) {
            ((Animator.AnimatorListener)arrayList.get(n3)).onAnimationStart(this);
            ++n3;
        }
        return;
    }

    public void addUpdateListener(AnimatorUpdateListener animatorUpdateListener) {
        if (this.mUpdateListeners == null) {
            this.mUpdateListeners = new ArrayList();
        }
        this.mUpdateListeners.add(animatorUpdateListener);
    }

    /*
     * Enabled aggressive block sorting
     */
    void animateValue(float f2) {
        this.mCurrentFraction = f2 = this.mInterpolator.getInterpolation(f2);
        int n2 = this.mValues.length;
        int n3 = 0;
        do {
            if (n3 >= n2) {
                if (this.mUpdateListeners == null) return;
                {
                    break;
                }
            }
            this.mValues[n3].calculateValue(f2);
            ++n3;
        } while (true);
        n2 = this.mUpdateListeners.size();
        n3 = 0;
        while (n3 < n2) {
            this.mUpdateListeners.get(n3).onAnimationUpdate(this);
            ++n3;
        }
        return;
    }

    /*
     * Exception decompiling
     */
    boolean animationFrame(long var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:486)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public void cancel() {
        if (this.mPlayingState == 0 && !ValueAnimator.sPendingAnimations.get().contains(this)) {
            if (ValueAnimator.sDelayedAnims.get().contains(this) == false) return;
        }
        if (!this.mRunning || this.mListeners == null) ** GOTO lbl-1000
        var1_1 = ((ArrayList)this.mListeners.clone()).iterator();
        do {
            if (!var1_1.hasNext()) lbl-1000: // 2 sources:
            {
                this.endAnimation();
                return;
            }
            ((Animator.AnimatorListener)var1_1.next()).onAnimationCancel(this);
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     */
    @Override
    public ValueAnimator clone() {
        var3_1 = (ValueAnimator)super.clone();
        if (this.mUpdateListeners == null) ** GOTO lbl-1000
        var4_2 = this.mUpdateListeners;
        var3_1.mUpdateListeners = new ArrayList<E>();
        var2_3 = var4_2.size();
        var1_4 = 0;
        do {
            if (var1_4 >= var2_3) lbl-1000: // 2 sources:
            {
                var3_1.mSeekTime = -1;
                var3_1.mPlayingBackwards = false;
                var3_1.mCurrentIteration = 0;
                var3_1.mInitialized = false;
                var3_1.mPlayingState = 0;
                var3_1.mStartedDelay = false;
                var4_2 = this.mValues;
                if (var4_2 == null) return var3_1;
                {
                    var2_3 = var4_2.length;
                    var3_1.mValues = new PropertyValuesHolder[var2_3];
                    var3_1.mValuesMap = new HashMap<K, V>(var2_3);
                    break;
                }
            }
            var3_1.mUpdateListeners.add(var4_2.get(var1_4));
            ++var1_4;
        } while (true);
        for (var1_4 = 0; var1_4 < var2_3; ++var1_4) {
            var3_1.mValues[var1_4] = var5_5 = var4_2[var1_4].clone();
            var3_1.mValuesMap.put(var5_5.getPropertyName(), var5_5);
        }
        return var3_1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void end() {
        if (!sAnimations.get().contains(this) && !sPendingAnimations.get().contains(this)) {
            this.mStartedDelay = false;
            this.startAnimation();
        } else if (!this.mInitialized) {
            this.initAnimation();
        }
        if (this.mRepeatCount > 0 && (this.mRepeatCount & 1) == 1) {
            this.animateValue(0.0f);
        } else {
            this.animateValue(1.0f);
        }
        this.endAnimation();
    }

    public float getAnimatedFraction() {
        return this.mCurrentFraction;
    }

    public Object getAnimatedValue() {
        if (this.mValues != null && this.mValues.length > 0) {
            return this.mValues[0].getAnimatedValue();
        }
        return null;
    }

    public Object getAnimatedValue(String object) {
        if ((object = this.mValuesMap.get(object)) != null) {
            return object.getAnimatedValue();
        }
        return null;
    }

    public long getCurrentPlayTime() {
        if (!this.mInitialized || this.mPlayingState == 0) {
            return 0;
        }
        return AnimationUtils.currentAnimationTimeMillis() - this.mStartTime;
    }

    @Override
    public long getDuration() {
        return this.mDuration;
    }

    public Interpolator getInterpolator() {
        return this.mInterpolator;
    }

    public int getRepeatCount() {
        return this.mRepeatCount;
    }

    public int getRepeatMode() {
        return this.mRepeatMode;
    }

    @Override
    public long getStartDelay() {
        return this.mStartDelay;
    }

    public PropertyValuesHolder[] getValues() {
        return this.mValues;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    void initAnimation() {
        if (this.mInitialized) return;
        int n2 = this.mValues.length;
        int n3 = 0;
        do {
            if (n3 >= n2) {
                this.mInitialized = true;
                return;
            }
            this.mValues[n3].init();
            ++n3;
        } while (true);
    }

    @Override
    public boolean isRunning() {
        boolean bl;
        boolean bl2 = bl = true;
        if (this.mPlayingState != 1) {
            bl2 = bl;
            if (!this.mRunning) {
                bl2 = false;
            }
        }
        return bl2;
    }

    @Override
    public boolean isStarted() {
        return this.mStarted;
    }

    public void removeAllUpdateListeners() {
        if (this.mUpdateListeners == null) {
            return;
        }
        this.mUpdateListeners.clear();
        this.mUpdateListeners = null;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void removeUpdateListener(AnimatorUpdateListener animatorUpdateListener) {
        if (this.mUpdateListeners == null) {
            return;
        }
        this.mUpdateListeners.remove(animatorUpdateListener);
        if (this.mUpdateListeners.size() != 0) return;
        this.mUpdateListeners = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void reverse() {
        boolean bl = !this.mPlayingBackwards;
        this.mPlayingBackwards = bl;
        if (this.mPlayingState == 1) {
            long l2 = AnimationUtils.currentAnimationTimeMillis();
            long l3 = this.mStartTime;
            this.mStartTime = l2 - (this.mDuration - (l2 - l3));
            return;
        }
        this.start(true);
    }

    public void setCurrentPlayTime(long l2) {
        this.initAnimation();
        long l3 = AnimationUtils.currentAnimationTimeMillis();
        if (this.mPlayingState != 1) {
            this.mSeekTime = l2;
            this.mPlayingState = 2;
        }
        this.mStartTime = l3 - l2;
        this.animationFrame(l3);
    }

    @Override
    public ValueAnimator setDuration(long l2) {
        if (l2 < 0) {
            throw new IllegalArgumentException("Animators cannot have negative duration: " + l2);
        }
        this.mDuration = l2;
        return this;
    }

    public void setEvaluator(TypeEvaluator typeEvaluator) {
        if (typeEvaluator != null && this.mValues != null && this.mValues.length > 0) {
            this.mValues[0].setEvaluator(typeEvaluator);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public /* varargs */ void setFloatValues(float ... arrf) {
        if (arrf == null || arrf.length == 0) {
            return;
        }
        if (this.mValues == null || this.mValues.length == 0) {
            this.setValues(PropertyValuesHolder.ofFloat("", arrf));
        } else {
            this.mValues[0].setFloatValues(arrf);
        }
        this.mInitialized = false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public /* varargs */ void setIntValues(int ... arrn) {
        if (arrn == null || arrn.length == 0) {
            return;
        }
        if (this.mValues == null || this.mValues.length == 0) {
            this.setValues(PropertyValuesHolder.ofInt("", arrn));
        } else {
            this.mValues[0].setIntValues(arrn);
        }
        this.mInitialized = false;
    }

    @Override
    public void setInterpolator(Interpolator interpolator) {
        if (interpolator != null) {
            this.mInterpolator = interpolator;
            return;
        }
        this.mInterpolator = new LinearInterpolator();
    }

    /*
     * Enabled aggressive block sorting
     */
    public /* varargs */ void setObjectValues(Object ... arrobject) {
        if (arrobject == null || arrobject.length == 0) {
            return;
        }
        if (this.mValues == null || this.mValues.length == 0) {
            this.setValues(PropertyValuesHolder.ofObject("", null, arrobject));
        } else {
            this.mValues[0].setObjectValues(arrobject);
        }
        this.mInitialized = false;
    }

    public void setRepeatCount(int n2) {
        this.mRepeatCount = n2;
    }

    public void setRepeatMode(int n2) {
        this.mRepeatMode = n2;
    }

    @Override
    public void setStartDelay(long l2) {
        this.mStartDelay = l2;
    }

    public /* varargs */ void setValues(PropertyValuesHolder ... arrpropertyValuesHolder) {
        int n2 = arrpropertyValuesHolder.length;
        this.mValues = arrpropertyValuesHolder;
        this.mValuesMap = new HashMap(n2);
        int n3 = 0;
        do {
            if (n3 >= n2) {
                this.mInitialized = false;
                return;
            }
            PropertyValuesHolder propertyValuesHolder = arrpropertyValuesHolder[n3];
            this.mValuesMap.put(propertyValuesHolder.getPropertyName(), propertyValuesHolder);
            ++n3;
        } while (true);
    }

    @Override
    public void start() {
        this.start(false);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public String toString() {
        String string2;
        String string3 = string2 = "ValueAnimator@" + Integer.toHexString(this.hashCode());
        if (this.mValues == null) return string3;
        int n2 = 0;
        while (n2 < this.mValues.length) {
            string2 = String.valueOf(string2) + "\n    " + this.mValues[n2].toString();
            ++n2;
        }
        return string2;
    }

    public static interface AnimatorUpdateListener {
        public void onAnimationUpdate(ValueAnimator var1);
    }

}

