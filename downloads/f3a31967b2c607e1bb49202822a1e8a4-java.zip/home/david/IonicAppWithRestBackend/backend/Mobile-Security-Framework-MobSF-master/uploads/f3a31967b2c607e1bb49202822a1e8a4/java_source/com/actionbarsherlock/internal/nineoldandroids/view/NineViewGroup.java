/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.animation.Animation
 */
package com.actionbarsherlock.internal.nineoldandroids.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import com.actionbarsherlock.internal.nineoldandroids.view.animation.AnimatorProxy;

public abstract class NineViewGroup
extends ViewGroup {
    private final AnimatorProxy mProxy;

    /*
     * Enabled aggressive block sorting
     */
    public NineViewGroup(Context object) {
        super((Context)object);
        object = AnimatorProxy.NEEDS_PROXY ? AnimatorProxy.wrap((View)this) : null;
        this.mProxy = object;
    }

    /*
     * Enabled aggressive block sorting
     */
    public NineViewGroup(Context object, AttributeSet attributeSet) {
        super((Context)object, attributeSet);
        object = AnimatorProxy.NEEDS_PROXY ? AnimatorProxy.wrap((View)this) : null;
        this.mProxy = object;
    }

    /*
     * Enabled aggressive block sorting
     */
    public NineViewGroup(Context object, AttributeSet attributeSet, int n2) {
        super((Context)object, attributeSet, n2);
        object = AnimatorProxy.NEEDS_PROXY ? AnimatorProxy.wrap((View)this) : null;
        this.mProxy = object;
    }

    public float getAlpha() {
        if (AnimatorProxy.NEEDS_PROXY) {
            return this.mProxy.getAlpha();
        }
        return super.getAlpha();
    }

    public float getTranslationX() {
        if (AnimatorProxy.NEEDS_PROXY) {
            return this.mProxy.getTranslationX();
        }
        return super.getTranslationX();
    }

    public float getTranslationY() {
        if (AnimatorProxy.NEEDS_PROXY) {
            return this.mProxy.getTranslationY();
        }
        return super.getTranslationY();
    }

    public void setAlpha(float f2) {
        if (AnimatorProxy.NEEDS_PROXY) {
            this.mProxy.setAlpha(f2);
            return;
        }
        super.setAlpha(f2);
    }

    public void setTranslationX(float f2) {
        if (AnimatorProxy.NEEDS_PROXY) {
            this.mProxy.setTranslationX(f2);
            return;
        }
        super.setTranslationX(f2);
    }

    public void setTranslationY(float f2) {
        if (AnimatorProxy.NEEDS_PROXY) {
            this.mProxy.setTranslationY(f2);
            return;
        }
        super.setTranslationY(f2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setVisibility(int n2) {
        if (this.mProxy != null) {
            if (n2 == 8) {
                this.clearAnimation();
            } else if (n2 == 0) {
                this.setAnimation((Animation)this.mProxy);
            }
        }
        super.setVisibility(n2);
    }
}

