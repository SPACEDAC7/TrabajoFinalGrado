/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.RectF
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.FloatMath
 *  android.view.View
 *  android.view.ViewParent
 *  android.view.animation.Animation
 *  android.view.animation.Transformation
 */
package com.actionbarsherlock.internal.nineoldandroids.view.animation;

import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Build;
import android.util.FloatMath;
import android.view.View;
import android.view.ViewParent;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

public final class AnimatorProxy
extends Animation {
    public static final boolean NEEDS_PROXY;
    private static final WeakHashMap<View, AnimatorProxy> PROXIES;
    private final RectF mAfter = new RectF();
    private float mAlpha = 1.0f;
    private final RectF mBefore = new RectF();
    private float mScaleX = 1.0f;
    private float mScaleY = 1.0f;
    private final Matrix mTempMatrix = new Matrix();
    private float mTranslationX;
    private float mTranslationY;
    private final WeakReference<View> mView;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = Build.VERSION.SDK_INT < 11;
        NEEDS_PROXY = bl;
        PROXIES = new WeakHashMap();
    }

    private AnimatorProxy(View view) {
        this.setDuration(0);
        this.setFillAfter(true);
        view.setAnimation((Animation)this);
        this.mView = new WeakReference<View>(view);
    }

    private void computeRect(RectF rectF, View view) {
        float f2;
        rectF.set(0.0f, 0.0f, (float)view.getWidth(), (float)view.getHeight());
        Matrix matrix = this.mTempMatrix;
        matrix.reset();
        this.transformMatrix(matrix, view);
        this.mTempMatrix.mapRect(rectF);
        rectF.offset((float)view.getLeft(), (float)view.getTop());
        if (rectF.right < rectF.left) {
            f2 = rectF.right;
            rectF.right = rectF.left;
            rectF.left = f2;
        }
        if (rectF.bottom < rectF.top) {
            f2 = rectF.top;
            rectF.top = rectF.bottom;
            rectF.bottom = f2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void invalidateAfterUpdate() {
        View view;
        View view2 = this.mView.get();
        if (view2 == null || (view = (View)view2.getParent()) == null) {
            return;
        }
        view2.setAnimation((Animation)this);
        RectF rectF = this.mAfter;
        this.computeRect(rectF, view2);
        rectF.union(this.mBefore);
        view.invalidate((int)FloatMath.floor((float)rectF.left), (int)FloatMath.floor((float)rectF.top), (int)FloatMath.ceil((float)rectF.right), (int)FloatMath.ceil((float)rectF.bottom));
    }

    private void prepareForUpdate() {
        View view = this.mView.get();
        if (view != null) {
            this.computeRect(this.mBefore, view);
        }
    }

    private void transformMatrix(Matrix matrix, View view) {
        float f2 = view.getWidth();
        float f3 = view.getHeight();
        float f4 = this.mScaleX;
        float f5 = this.mScaleY;
        if (f4 != 1.0f || f5 != 1.0f) {
            f2 = (f4 * f2 - f2) / 2.0f;
            f3 = (f5 * f3 - f3) / 2.0f;
            matrix.postScale(f4, f5);
            matrix.postTranslate(- f2, - f3);
        }
        matrix.postTranslate(this.mTranslationX, this.mTranslationY);
    }

    public static AnimatorProxy wrap(View view) {
        AnimatorProxy animatorProxy;
        AnimatorProxy animatorProxy2 = animatorProxy = PROXIES.get((Object)view);
        if (animatorProxy == null) {
            animatorProxy2 = new AnimatorProxy(view);
            PROXIES.put(view, animatorProxy2);
        }
        return animatorProxy2;
    }

    protected final void applyTransformation(float f2, Transformation transformation) {
        View view = this.mView.get();
        if (view != null) {
            transformation.setAlpha(this.mAlpha);
            this.transformMatrix(transformation.getMatrix(), view);
        }
    }

    public final float getAlpha() {
        return this.mAlpha;
    }

    public final float getScaleX() {
        return this.mScaleX;
    }

    public final float getScaleY() {
        return this.mScaleY;
    }

    public final int getScrollX() {
        View view = this.mView.get();
        if (view == null) {
            return 0;
        }
        return view.getScrollX();
    }

    public final int getScrollY() {
        View view = this.mView.get();
        if (view == null) {
            return 0;
        }
        return view.getScrollY();
    }

    public final float getTranslationX() {
        return this.mTranslationX;
    }

    public final float getTranslationY() {
        return this.mTranslationY;
    }

    public final void reset() {
    }

    public final void setAlpha(float f2) {
        if (this.mAlpha != f2) {
            this.mAlpha = f2;
            View view = this.mView.get();
            if (view != null) {
                view.invalidate();
            }
        }
    }

    public final void setScaleX(float f2) {
        if (this.mScaleX != f2) {
            this.prepareForUpdate();
            this.mScaleX = f2;
            this.invalidateAfterUpdate();
        }
    }

    public final void setScaleY(float f2) {
        if (this.mScaleY != f2) {
            this.prepareForUpdate();
            this.mScaleY = f2;
            this.invalidateAfterUpdate();
        }
    }

    public final void setScrollX(int n2) {
        View view = this.mView.get();
        if (view != null) {
            view.scrollTo(n2, view.getScrollY());
        }
    }

    public final void setScrollY(int n2) {
        View view = this.mView.get();
        if (view != null) {
            view.scrollTo(view.getScrollY(), n2);
        }
    }

    public final void setTranslationX(float f2) {
        if (this.mTranslationX != f2) {
            this.prepareForUpdate();
            this.mTranslationX = f2;
            this.invalidateAfterUpdate();
        }
    }

    public final void setTranslationY(float f2) {
        if (this.mTranslationY != f2) {
            this.prepareForUpdate();
            this.mTranslationY = f2;
            this.invalidateAfterUpdate();
        }
    }
}

