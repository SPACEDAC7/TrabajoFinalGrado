/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.animation.Animation
 *  android.widget.FrameLayout
 */
package com.actionbarsherlock.internal.nineoldandroids.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import com.actionbarsherlock.internal.nineoldandroids.view.animation.AnimatorProxy;

public class NineFrameLayout
extends FrameLayout {
    private final AnimatorProxy mProxy;

    /*
     * Enabled aggressive block sorting
     */
    public NineFrameLayout(Context object, AttributeSet attributeSet) {
        super((Context)object, attributeSet);
        object = AnimatorProxy.NEEDS_PROXY ? AnimatorProxy.wrap((View)this) : null;
        this.mProxy = object;
    }

    public float getAlpha() {
        if (AnimatorProxy.NEEDS_PROXY) {
            return this.mProxy.getAlpha();
        }
        return super.getAlpha();
    }

    public float getTranslationY() {
        if (AnimatorProxy.NEEDS_PROXY) {
            return this.mProxy.getTranslationY();
        }
        return super.getTranslationY();
    }

    public void setAlpha(float f2) {
        if (AnimatorProxy.NEEDS_PROXY) {
            this.mProxy.setAlpha(f2);
            return;
        }
        super.setAlpha(f2);
    }

    public void setTranslationY(float f2) {
        if (AnimatorProxy.NEEDS_PROXY) {
            this.mProxy.setTranslationY(f2);
            return;
        }
        super.setTranslationY(f2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setVisibility(int n2) {
        if (this.mProxy != null) {
            if (n2 == 8) {
                this.clearAnimation();
            } else if (n2 == 0) {
                this.setAnimation((Animation)this.mProxy);
            }
        }
        super.setVisibility(n2);
    }
}

