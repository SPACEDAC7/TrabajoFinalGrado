/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.ActionProvider
 *  android.view.SubMenu
 *  android.view.View
 */
package com.actionbarsherlock.internal.view;

import android.content.Context;
import android.view.View;
import com.actionbarsherlock.internal.view.menu.SubMenuWrapper;
import com.actionbarsherlock.view.ActionProvider;
import com.actionbarsherlock.view.SubMenu;

public class ActionProviderWrapper
extends android.view.ActionProvider {
    private final ActionProvider mProvider;

    public ActionProviderWrapper(ActionProvider actionProvider) {
        super(null);
        this.mProvider = actionProvider;
    }

    public boolean hasSubMenu() {
        return this.mProvider.hasSubMenu();
    }

    public View onCreateActionView() {
        return this.mProvider.onCreateActionView();
    }

    public boolean onPerformDefaultAction() {
        return this.mProvider.onPerformDefaultAction();
    }

    public void onPrepareSubMenu(android.view.SubMenu subMenu) {
        this.mProvider.onPrepareSubMenu(new SubMenuWrapper(subMenu));
    }

    public ActionProvider unwrap() {
        return this.mProvider;
    }
}

