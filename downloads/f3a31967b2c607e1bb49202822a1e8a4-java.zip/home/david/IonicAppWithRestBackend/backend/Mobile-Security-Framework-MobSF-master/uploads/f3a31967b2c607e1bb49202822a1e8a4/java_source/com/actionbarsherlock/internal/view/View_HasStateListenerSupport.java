/*
 * Decompiled with CFR 0_115.
 */
package com.actionbarsherlock.internal.view;

import com.actionbarsherlock.internal.view.View_OnAttachStateChangeListener;

public interface View_HasStateListenerSupport {
    public void addOnAttachStateChangeListener(View_OnAttachStateChangeListener var1);

    public void removeOnAttachStateChangeListener(View_OnAttachStateChangeListener var1);
}

