/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.actionbarsherlock.internal.view;

import android.view.View;

public interface View_OnAttachStateChangeListener {
    public void onViewAttachedToWindow(View var1);

    public void onViewDetachedFromWindow(View var1);
}

