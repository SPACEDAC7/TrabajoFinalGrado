/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.view.KeyEvent
 */
package com.actionbarsherlock.internal.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import com.actionbarsherlock.internal.view.menu.ActionMenuItem;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.SubMenu;
import java.util.ArrayList;
import java.util.List;

public class ActionMenu
implements Menu {
    private Context mContext;
    private boolean mIsQwerty;
    private ArrayList<ActionMenuItem> mItems;

    public ActionMenu(Context context) {
        this.mContext = context;
        this.mItems = new ArrayList();
    }

    private int findItemIndex(int n2) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n3 = arrayList.size();
        int n4 = 0;
        while (n4 < n3) {
            if (arrayList.get(n4).getItemId() == n2) {
                return n4;
            }
            ++n4;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    private ActionMenuItem findItemWithShortcut(int n2, KeyEvent object) {
        boolean bl = this.mIsQwerty;
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n3 = arrayList.size();
        int n4 = 0;
        while (n4 < n3) {
            object = arrayList.get(n4);
            char c2 = bl ? object.getAlphabeticShortcut() : object.getNumericShortcut();
            if (n2 == c2) return object;
            ++n4;
        }
        return null;
    }

    @Override
    public MenuItem add(int n2) {
        return this.add(0, 0, 0, n2);
    }

    @Override
    public MenuItem add(int n2, int n3, int n4, int n5) {
        return this.add(n2, n3, n4, this.mContext.getResources().getString(n5));
    }

    @Override
    public MenuItem add(int n2, int n3, int n4, CharSequence object) {
        object = new ActionMenuItem(this.getContext(), n2, n3, 0, n4, (CharSequence)object);
        this.mItems.add(n4, (ActionMenuItem)object);
        return object;
    }

    @Override
    public MenuItem add(CharSequence charSequence) {
        return this.add(0, 0, 0, charSequence);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int addIntentOptions(int n2, int n3, int n4, ComponentName object, Intent[] arrintent, Intent intent, int n5, MenuItem[] arrmenuItem) {
        PackageManager packageManager = this.mContext.getPackageManager();
        List list = packageManager.queryIntentActivityOptions((ComponentName)object, arrintent, intent, 0);
        int n6 = list != null ? list.size() : 0;
        if ((n5 & 1) == 0) {
            this.removeGroup(n2);
        }
        n5 = 0;
        while (n5 < n6) {
            ResolveInfo resolveInfo = (ResolveInfo)list.get(n5);
            object = resolveInfo.specificIndex < 0 ? intent : arrintent[resolveInfo.specificIndex];
            object = new Intent((Intent)object);
            object.setComponent(new ComponentName(resolveInfo.activityInfo.applicationInfo.packageName, resolveInfo.activityInfo.name));
            object = this.add(n2, n3, n4, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent((Intent)object);
            if (arrmenuItem != null && resolveInfo.specificIndex >= 0) {
                arrmenuItem[resolveInfo.specificIndex] = object;
            }
            ++n5;
        }
        return n6;
    }

    @Override
    public SubMenu addSubMenu(int n2) {
        return null;
    }

    @Override
    public SubMenu addSubMenu(int n2, int n3, int n4, int n5) {
        return null;
    }

    @Override
    public SubMenu addSubMenu(int n2, int n3, int n4, CharSequence charSequence) {
        return null;
    }

    @Override
    public SubMenu addSubMenu(CharSequence charSequence) {
        return null;
    }

    @Override
    public void clear() {
        this.mItems.clear();
    }

    @Override
    public void close() {
    }

    @Override
    public MenuItem findItem(int n2) {
        return this.mItems.get(this.findItemIndex(n2));
    }

    public Context getContext() {
        return this.mContext;
    }

    @Override
    public MenuItem getItem(int n2) {
        return this.mItems.get(n2);
    }

    @Override
    public boolean hasVisibleItems() {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n2 = arrayList.size();
        int n3 = 0;
        while (n3 < n2) {
            if (arrayList.get(n3).isVisible()) {
                return true;
            }
            ++n3;
        }
        return false;
    }

    @Override
    public boolean isShortcutKey(int n2, KeyEvent keyEvent) {
        if (this.findItemWithShortcut(n2, keyEvent) != null) {
            return true;
        }
        return false;
    }

    @Override
    public boolean performIdentifierAction(int n2, int n3) {
        if ((n2 = this.findItemIndex(n2)) < 0) {
            return false;
        }
        return this.mItems.get(n2).invoke();
    }

    @Override
    public boolean performShortcut(int n2, KeyEvent object, int n3) {
        if ((object = this.findItemWithShortcut(n2, (KeyEvent)object)) == null) {
            return false;
        }
        return object.invoke();
    }

    @Override
    public void removeGroup(int n2) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n3 = arrayList.size();
        int n4 = 0;
        while (n4 < n3) {
            if (arrayList.get(n4).getGroupId() == n2) {
                arrayList.remove(n4);
                --n3;
                continue;
            }
            ++n4;
        }
        return;
    }

    @Override
    public void removeItem(int n2) {
        this.mItems.remove(this.findItemIndex(n2));
    }

    @Override
    public void setGroupCheckable(int n2, boolean bl, boolean bl2) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n3 = arrayList.size();
        int n4 = 0;
        while (n4 < n3) {
            ActionMenuItem actionMenuItem = arrayList.get(n4);
            if (actionMenuItem.getGroupId() == n2) {
                actionMenuItem.setCheckable(bl);
                actionMenuItem.setExclusiveCheckable(bl2);
            }
            ++n4;
        }
        return;
    }

    @Override
    public void setGroupEnabled(int n2, boolean bl) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n3 = arrayList.size();
        int n4 = 0;
        while (n4 < n3) {
            ActionMenuItem actionMenuItem = arrayList.get(n4);
            if (actionMenuItem.getGroupId() == n2) {
                actionMenuItem.setEnabled(bl);
            }
            ++n4;
        }
        return;
    }

    @Override
    public void setGroupVisible(int n2, boolean bl) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n3 = arrayList.size();
        int n4 = 0;
        while (n4 < n3) {
            ActionMenuItem actionMenuItem = arrayList.get(n4);
            if (actionMenuItem.getGroupId() == n2) {
                actionMenuItem.setVisible(bl);
            }
            ++n4;
        }
        return;
    }

    @Override
    public void setQwertyMode(boolean bl) {
        this.mIsQwerty = bl;
    }

    @Override
    public int size() {
        return this.mItems.size();
    }
}

