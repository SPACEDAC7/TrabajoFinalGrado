/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.View
 */
package com.actionbarsherlock.internal.view.menu;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.ContextMenu;
import android.view.View;
import com.actionbarsherlock.view.ActionProvider;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.SubMenu;

public class ActionMenuItem
implements MenuItem {
    private static final int CHECKABLE = 1;
    private static final int CHECKED = 2;
    private static final int ENABLED = 16;
    private static final int EXCLUSIVE = 4;
    private static final int HIDDEN = 8;
    private MenuItem.OnMenuItemClickListener mClickListener;
    private Context mContext;
    private int mFlags = 16;
    private final int mGroup;
    private Drawable mIconDrawable;
    private final int mId;
    private Intent mIntent;
    private final int mOrdering;
    private char mShortcutAlphabeticChar;
    private char mShortcutNumericChar;
    private CharSequence mTitle;
    private CharSequence mTitleCondensed;

    public ActionMenuItem(Context context, int n2, int n3, int n4, int n5, CharSequence charSequence) {
        this.mContext = context;
        this.mId = n3;
        this.mGroup = n2;
        this.mOrdering = n5;
        this.mTitle = charSequence;
    }

    @Override
    public boolean collapseActionView() {
        return false;
    }

    @Override
    public boolean expandActionView() {
        return false;
    }

    @Override
    public ActionProvider getActionProvider() {
        return null;
    }

    @Override
    public View getActionView() {
        return null;
    }

    @Override
    public char getAlphabeticShortcut() {
        return this.mShortcutAlphabeticChar;
    }

    @Override
    public int getGroupId() {
        return this.mGroup;
    }

    @Override
    public Drawable getIcon() {
        return this.mIconDrawable;
    }

    @Override
    public Intent getIntent() {
        return this.mIntent;
    }

    @Override
    public int getItemId() {
        return this.mId;
    }

    @Override
    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    @Override
    public char getNumericShortcut() {
        return this.mShortcutNumericChar;
    }

    @Override
    public int getOrder() {
        return this.mOrdering;
    }

    @Override
    public SubMenu getSubMenu() {
        return null;
    }

    @Override
    public CharSequence getTitle() {
        return this.mTitle;
    }

    @Override
    public CharSequence getTitleCondensed() {
        return this.mTitleCondensed;
    }

    @Override
    public boolean hasSubMenu() {
        return false;
    }

    public boolean invoke() {
        if (this.mClickListener != null && this.mClickListener.onMenuItemClick(this)) {
            return true;
        }
        if (this.mIntent != null) {
            this.mContext.startActivity(this.mIntent);
            return true;
        }
        return false;
    }

    @Override
    public boolean isActionViewExpanded() {
        return false;
    }

    @Override
    public boolean isCheckable() {
        if ((this.mFlags & 1) != 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isChecked() {
        if ((this.mFlags & 2) != 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isEnabled() {
        if ((this.mFlags & 16) != 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isVisible() {
        if ((this.mFlags & 8) == 0) {
            return true;
        }
        return false;
    }

    @Override
    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    @Override
    public MenuItem setActionView(int n2) {
        throw new UnsupportedOperationException();
    }

    @Override
    public MenuItem setActionView(View view) {
        throw new UnsupportedOperationException();
    }

    @Override
    public MenuItem setAlphabeticShortcut(char c2) {
        this.mShortcutAlphabeticChar = c2;
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public MenuItem setCheckable(boolean bl) {
        int n2 = this.mFlags;
        int n3 = bl ? 1 : 0;
        this.mFlags = n3 | n2 & -2;
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public MenuItem setChecked(boolean bl) {
        int n2 = this.mFlags;
        int n3 = bl ? 2 : 0;
        this.mFlags = n3 | n2 & -3;
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public MenuItem setEnabled(boolean bl) {
        int n2 = this.mFlags;
        int n3 = bl ? 16 : 0;
        this.mFlags = n3 | n2 & -17;
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    public ActionMenuItem setExclusiveCheckable(boolean bl) {
        int n2 = this.mFlags;
        int n3 = bl ? 4 : 0;
        this.mFlags = n3 | n2 & -5;
        return this;
    }

    @Override
    public MenuItem setIcon(int n2) {
        this.mIconDrawable = this.mContext.getResources().getDrawable(n2);
        return this;
    }

    @Override
    public MenuItem setIcon(Drawable drawable2) {
        this.mIconDrawable = drawable2;
        return this;
    }

    @Override
    public MenuItem setIntent(Intent intent) {
        this.mIntent = intent;
        return this;
    }

    @Override
    public MenuItem setNumericShortcut(char c2) {
        this.mShortcutNumericChar = c2;
        return this;
    }

    @Override
    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        return this;
    }

    @Override
    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.mClickListener = onMenuItemClickListener;
        return this;
    }

    @Override
    public MenuItem setShortcut(char c2, char c3) {
        this.mShortcutNumericChar = c2;
        this.mShortcutAlphabeticChar = c3;
        return this;
    }

    @Override
    public void setShowAsAction(int n2) {
    }

    @Override
    public MenuItem setShowAsActionFlags(int n2) {
        this.setShowAsAction(n2);
        return this;
    }

    @Override
    public MenuItem setTitle(int n2) {
        this.mTitle = this.mContext.getResources().getString(n2);
        return this;
    }

    @Override
    public MenuItem setTitle(CharSequence charSequence) {
        this.mTitle = charSequence;
        return this;
    }

    @Override
    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.mTitleCondensed = charSequence;
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public MenuItem setVisible(boolean bl) {
        int n2 = this.mFlags;
        int n3 = bl ? 0 : 8;
        this.mFlags = n3 | n2 & 8;
        return this;
    }
}

