/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.SparseBooleanArray
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewConfiguration
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.widget.ImageButton
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 */
package com.actionbarsherlock.internal.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import com.actionbarsherlock.R;
import com.actionbarsherlock.internal.ResourcesCompat;
import com.actionbarsherlock.internal.view.View_HasStateListenerSupport;
import com.actionbarsherlock.internal.view.View_OnAttachStateChangeListener;
import com.actionbarsherlock.internal.view.menu.ActionMenuItemView;
import com.actionbarsherlock.internal.view.menu.ActionMenuView;
import com.actionbarsherlock.internal.view.menu.BaseMenuPresenter;
import com.actionbarsherlock.internal.view.menu.MenuBuilder;
import com.actionbarsherlock.internal.view.menu.MenuItemImpl;
import com.actionbarsherlock.internal.view.menu.MenuPopupHelper;
import com.actionbarsherlock.internal.view.menu.MenuPresenter;
import com.actionbarsherlock.internal.view.menu.MenuView;
import com.actionbarsherlock.internal.view.menu.SubMenuBuilder;
import com.actionbarsherlock.view.ActionProvider;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.SubMenu;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ActionMenuPresenter
extends BaseMenuPresenter
implements ActionProvider.SubUiVisibilityListener {
    private final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
    private ActionButtonSubmenu mActionButtonPopup;
    private int mActionItemWidthLimit;
    private boolean mExpandedActionViewsExclusive;
    private int mMaxItems;
    private boolean mMaxItemsSet;
    private int mMinCellSize;
    int mOpenSubMenuId;
    private View mOverflowButton;
    private OverflowPopup mOverflowPopup;
    final PopupPresenterCallback mPopupPresenterCallback;
    private OpenOverflowRunnable mPostedOpenRunnable;
    private boolean mReserveOverflow;
    private boolean mReserveOverflowSet;
    private View mScrapActionButtonView;
    private boolean mStrictWidthLimit;
    private int mWidthLimit;
    private boolean mWidthLimitSet;

    public ActionMenuPresenter(Context context) {
        super(context, R.layout.abs__action_menu_layout, R.layout.abs__action_menu_item_layout);
        this.mPopupPresenterCallback = new PopupPresenterCallback();
    }

    static /* synthetic */ void access$1(ActionMenuPresenter actionMenuPresenter, OverflowPopup overflowPopup) {
        actionMenuPresenter.mOverflowPopup = overflowPopup;
    }

    static /* synthetic */ void access$3(ActionMenuPresenter actionMenuPresenter, ActionButtonSubmenu actionButtonSubmenu) {
        actionMenuPresenter.mActionButtonPopup = actionButtonSubmenu;
    }

    static /* synthetic */ void access$4(ActionMenuPresenter actionMenuPresenter, OpenOverflowRunnable openOverflowRunnable) {
        actionMenuPresenter.mPostedOpenRunnable = openOverflowRunnable;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private View findViewForItem(MenuItem menuItem) {
        ViewGroup viewGroup = (ViewGroup)this.mMenuView;
        if (viewGroup == null) {
            return null;
        }
        int n2 = viewGroup.getChildCount();
        int n3 = 0;
        while (n3 < n2) {
            View view = viewGroup.getChildAt(n3);
            if (view instanceof MenuView.ItemView) {
                View view2 = view;
                if (((MenuView.ItemView)view).getItemData() == menuItem) return view2;
            }
            ++n3;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean reserveOverflow(Context context) {
        if (Build.VERSION.SDK_INT < 14) {
            if (Build.VERSION.SDK_INT >= 11) return true;
            return false;
        }
        if (HasPermanentMenuKey.get(context)) return false;
        return true;
    }

    @Override
    public void bindItemView(MenuItemImpl object, MenuView.ItemView itemView) {
        itemView.initialize((MenuItemImpl)object, 0);
        object = (ActionMenuView)this.mMenuView;
        ((ActionMenuItemView)itemView).setItemInvoker((MenuBuilder.ItemInvoker)object);
    }

    public boolean dismissPopupMenus() {
        return this.hideOverflowMenu() | this.hideSubMenus();
    }

    @Override
    public boolean filterLeftoverView(ViewGroup viewGroup, int n2) {
        if (viewGroup.getChildAt(n2) == this.mOverflowButton) {
            return false;
        }
        return super.filterLeftoverView(viewGroup, n2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public boolean flagActionItems() {
        block34 : {
            var14_1 = this.mMenu.getVisibleItems();
            var9_2 = var14_1.size();
            var1_3 = this.mMaxItems;
            var8_4 = this.mActionItemWidthLimit;
            var10_5 = View.MeasureSpec.makeMeasureSpec((int)0, (int)0);
            var15_6 = (ViewGroup)this.mMenuView;
            var3_7 = 0;
            var4_8 = 0;
            var5_9 = 0;
            var2_10 = 0;
            do {
                if (var2_10 < var9_2) ** GOTO lbl31
                var2_10 = var1_3;
                if (!this.mReserveOverflow) ** GOTO lbl19
                if (var5_9 != 0) ** GOTO lbl-1000
                var2_10 = var1_3;
                if (var3_7 + var4_8 > var1_3) lbl-1000: // 2 sources:
                {
                    var2_10 = var1_3 - 1;
                }
lbl19: // 4 sources:
                var2_10 -= var3_7;
                var16_11 = this.mActionButtonGroups;
                var16_11.clear();
                if (this.mStrictWidthLimit) {
                    var1_3 = var8_4 / this.mMinCellSize;
                    var3_7 = this.mMinCellSize;
                    var4_8 = this.mMinCellSize;
                    var6_12 = var8_4 % var3_7 / var1_3 + var4_8;
                    break;
                }
                var6_12 = 0;
                var1_3 = 0;
                break;
lbl31: // 1 sources:
                var16_11 = var14_1.get(var2_10);
                if (var16_11.requiresActionButton()) {
                    ++var3_7;
                } else if (var16_11.requestsActionButton()) {
                    ++var4_8;
                } else {
                    var5_9 = 1;
                }
                if (this.mExpandedActionViewsExclusive && var16_11.isActionViewExpanded()) {
                    var1_3 = 0;
                }
                ++var2_10;
            } while (true);
            var5_9 = 0;
            var7_13 = 0;
            var3_7 = var1_3;
            var1_3 = var2_10;
            var4_8 = var8_4;
            var2_10 = var5_9;
            block1 : do {
                if (var7_13 >= var9_2) {
                    return true;
                }
                var17_17 = var14_1.get(var7_13);
                if (var17_17.requiresActionButton()) {
                    var18_18 = this.getItemView(var17_17, this.mScrapActionButtonView, var15_6);
                    if (this.mScrapActionButtonView == null) {
                        this.mScrapActionButtonView = var18_18;
                    }
                    if (this.mStrictWidthLimit) {
                        var5_9 = var3_7 - ActionMenuView.measureChildForCells((View)var18_18, var6_12, var3_7, var10_5, 0);
                    } else {
                        var18_18.measure(var10_5, var10_5);
                        var5_9 = var3_7;
                    }
                    var3_7 = var18_18.getMeasuredWidth();
                    if (var2_10 == 0) {
                        var2_10 = var3_7;
                    }
                    if ((var8_4 = var17_17.getGroupId()) != 0) {
                        var16_11.put(var8_4, true);
                    }
                    var17_17.setIsActionButton(true);
                    var3_7 = var4_8 - var3_7;
                    var4_8 = var1_3;
                    var1_3 = var5_9;
                } else {
                    if (var17_17.requestsActionButton()) {
                        var11_14 = var17_17.getGroupId();
                        var13_16 = var16_11.get(var11_14);
                        var12_15 = !(var1_3 <= 0 && var13_16 == false || var4_8 <= 0 || this.mStrictWidthLimit != false && var3_7 <= 0) ? 1 : 0;
                        if (var12_15 != 0) {
                            var18_18 = this.getItemView(var17_17, this.mScrapActionButtonView, var15_6);
                            if (this.mScrapActionButtonView == null) {
                                this.mScrapActionButtonView = var18_18;
                            }
                            if (this.mStrictWidthLimit) {
                                var8_4 = ActionMenuView.measureChildForCells((View)var18_18, var6_12, var3_7, var10_5, 0);
                                var3_7 = var5_9 = var3_7 - var8_4;
                                if (var8_4 == 0) {
                                    var12_15 = 0;
                                    var3_7 = var5_9;
                                }
                            } else {
                                var18_18.measure(var10_5, var10_5);
                            }
                            var8_4 = var18_18.getMeasuredWidth();
                            var4_8 -= var8_4;
                            var5_9 = var2_10;
                            if (var2_10 == 0) {
                                var5_9 = var8_4;
                            }
                            if (this.mStrictWidthLimit) {
                                var2_10 = var4_8 >= 0 ? 1 : 0;
                                var12_15 &= var2_10;
                                var2_10 = var3_7;
                                var3_7 = var5_9;
                            } else {
                                var2_10 = var4_8 + var5_9 > 0 ? 1 : 0;
                                var12_15 &= var2_10;
                                var2_10 = var3_7;
                                var3_7 = var5_9;
                            }
                        } else {
                            var5_9 = var3_7;
                            var3_7 = var2_10;
                            var2_10 = var5_9;
                        }
                        if (var12_15 != 0 && var11_14 != 0) {
                            var16_11.put(var11_14, true);
                            break;
                        }
                        if (!var13_16) break;
                        var16_11.put(var11_14, false);
                        var8_4 = 0;
                        break block34;
                    }
                    var5_9 = var1_3;
                    var1_3 = var3_7;
                    var3_7 = var4_8;
                    var4_8 = var5_9;
                }
lbl118: // 3 sources:
                do {
                    var8_4 = var7_13 + 1;
                    var5_9 = var3_7;
                    var7_13 = var4_8;
                    var3_7 = var1_3;
                    var4_8 = var5_9;
                    var1_3 = var7_13;
                    var7_13 = var8_4;
                    continue block1;
                    break;
                } while (true);
                break;
            } while (true);
            do {
                var5_9 = var1_3;
                if (var12_15 != 0) {
                    var5_9 = var1_3 - 1;
                }
                var17_17.setIsActionButton((boolean)var12_15);
                var8_4 = var3_7;
                var3_7 = var4_8;
                var4_8 = var5_9;
                var1_3 = var2_10;
                var2_10 = var8_4;
                ** continue;
                break;
            } while (true);
        }
        do {
            if (var8_4 >= var7_13) ** continue;
            var18_18 = var14_1.get(var8_4);
            var5_9 = var1_3;
            if (var18_18.getGroupId() == var11_14) {
                var5_9 = var1_3;
                if (var18_18.isActionButton()) {
                    var5_9 = var1_3 + 1;
                }
                var18_18.setIsActionButton(false);
            }
            ++var8_4;
            var1_3 = var5_9;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public View getItemView(MenuItemImpl object, View view, ViewGroup viewGroup) {
        View view2 = object.getActionView();
        if (view2 == null || object.hasCollapsibleActionView()) {
            view2 = view;
            if (!(view instanceof ActionMenuItemView)) {
                view2 = null;
            }
            view2 = super.getItemView((MenuItemImpl)object, view2, viewGroup);
        }
        int n2 = object.isActionViewExpanded() ? 8 : 0;
        view2.setVisibility(n2);
        object = (ActionMenuView)viewGroup;
        view = view2.getLayoutParams();
        if (!object.checkLayoutParams((ViewGroup.LayoutParams)view)) {
            view2.setLayoutParams((ViewGroup.LayoutParams)object.generateLayoutParams((ViewGroup.LayoutParams)view));
        }
        return view2;
    }

    @Override
    public MenuView getMenuView(ViewGroup object) {
        object = super.getMenuView((ViewGroup)object);
        ((ActionMenuView)object).setPresenter(this);
        return object;
    }

    public boolean hideOverflowMenu() {
        if (this.mPostedOpenRunnable != null && this.mMenuView != null) {
            ((View)this.mMenuView).removeCallbacks((Runnable)this.mPostedOpenRunnable);
            this.mPostedOpenRunnable = null;
            return true;
        }
        OverflowPopup overflowPopup = this.mOverflowPopup;
        if (overflowPopup != null) {
            overflowPopup.dismiss();
            return true;
        }
        return false;
    }

    public boolean hideSubMenus() {
        if (this.mActionButtonPopup != null) {
            this.mActionButtonPopup.dismiss();
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void initForMenu(Context context, MenuBuilder menuBuilder) {
        super.initForMenu(context, menuBuilder);
        menuBuilder = context.getResources();
        if (!this.mReserveOverflowSet) {
            this.mReserveOverflow = ActionMenuPresenter.reserveOverflow(this.mContext);
        }
        if (!this.mWidthLimitSet) {
            this.mWidthLimit = menuBuilder.getDisplayMetrics().widthPixels / 2;
        }
        if (!this.mMaxItemsSet) {
            this.mMaxItems = ResourcesCompat.getResources_getInteger(context, R.integer.abs__max_action_buttons);
        }
        int n2 = this.mWidthLimit;
        if (this.mReserveOverflow) {
            if (this.mOverflowButton == null) {
                this.mOverflowButton = new OverflowMenuButton(this.mSystemContext);
                int n3 = View.MeasureSpec.makeMeasureSpec((int)0, (int)0);
                this.mOverflowButton.measure(n3, n3);
            }
            n2 -= this.mOverflowButton.getMeasuredWidth();
        } else {
            this.mOverflowButton = null;
        }
        this.mActionItemWidthLimit = n2;
        this.mMinCellSize = (int)(56.0f * menuBuilder.getDisplayMetrics().density);
        this.mScrapActionButtonView = null;
    }

    public boolean isOverflowMenuShowing() {
        if (this.mOverflowPopup != null && this.mOverflowPopup.isShowing()) {
            return true;
        }
        return false;
    }

    public boolean isOverflowReserved() {
        return this.mReserveOverflow;
    }

    @Override
    public void onCloseMenu(MenuBuilder menuBuilder, boolean bl) {
        this.dismissPopupMenus();
        super.onCloseMenu(menuBuilder, bl);
    }

    public void onConfigurationChanged(Configuration configuration) {
        if (!this.mMaxItemsSet) {
            this.mMaxItems = ResourcesCompat.getResources_getInteger(this.mContext, R.integer.abs__max_action_buttons);
            if (this.mMenu != null) {
                this.mMenu.onItemsChanged(true);
            }
        }
    }

    @Override
    public void onRestoreInstanceState(Parcelable object) {
        object = (SavedState)object;
        if (object.openSubMenuId > 0 && (object = this.mMenu.findItem(object.openSubMenuId)) != null) {
            this.onSubMenuSelected((SubMenuBuilder)object.getSubMenu());
        }
    }

    @Override
    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState();
        savedState.openSubMenuId = this.mOpenSubMenuId;
        return savedState;
    }

    @Override
    public boolean onSubMenuSelected(SubMenuBuilder subMenuBuilder) {
        SubMenuBuilder subMenuBuilder2;
        block4 : {
            if (!subMenuBuilder.hasVisibleItems()) {
                return false;
            }
            subMenuBuilder2 = subMenuBuilder;
            do {
                if (subMenuBuilder2.getParentMenu() == this.mMenu) {
                    View view;
                    subMenuBuilder2 = view = this.findViewForItem(subMenuBuilder2.getItem());
                    if (view == null) {
                        if (this.mOverflowButton != null) break;
                        return false;
                    }
                    break block4;
                }
                subMenuBuilder2 = (SubMenuBuilder)subMenuBuilder2.getParentMenu();
            } while (true);
            subMenuBuilder2 = this.mOverflowButton;
        }
        this.mOpenSubMenuId = subMenuBuilder.getItem().getItemId();
        this.mActionButtonPopup = new ActionButtonSubmenu(this.mContext, subMenuBuilder);
        this.mActionButtonPopup.setAnchorView((View)subMenuBuilder2);
        this.mActionButtonPopup.show();
        super.onSubMenuSelected(subMenuBuilder);
        return true;
    }

    @Override
    public void onSubUiVisibilityChanged(boolean bl) {
        if (bl) {
            super.onSubMenuSelected(null);
            return;
        }
        this.mMenu.close(false);
    }

    public void setExpandedActionViewsExclusive(boolean bl) {
        this.mExpandedActionViewsExclusive = bl;
    }

    public void setItemLimit(int n2) {
        this.mMaxItems = n2;
        this.mMaxItemsSet = true;
    }

    public void setReserveOverflow(boolean bl) {
        this.mReserveOverflow = bl;
        this.mReserveOverflowSet = true;
    }

    public void setWidthLimit(int n2, boolean bl) {
        this.mWidthLimit = n2;
        this.mStrictWidthLimit = bl;
        this.mWidthLimitSet = true;
    }

    @Override
    public boolean shouldIncludeItem(int n2, MenuItemImpl menuItemImpl) {
        return menuItemImpl.isActionButton();
    }

    public boolean showOverflowMenu() {
        if (this.mReserveOverflow && !this.isOverflowMenuShowing() && this.mMenu != null && this.mMenuView != null && this.mPostedOpenRunnable == null && !this.mMenu.getNonActionItems().isEmpty()) {
            this.mPostedOpenRunnable = new OpenOverflowRunnable(new OverflowPopup(this.mContext, this.mMenu, this.mOverflowButton, true));
            ((View)this.mMenuView).post((Runnable)this.mPostedOpenRunnable);
            super.onSubMenuSelected(null);
            return true;
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public void updateMenuView(boolean var1_1) {
        block11 : {
            var3_2 = 1;
            var4_3 = 0;
            super.updateMenuView(var1_1);
            if (this.mMenu == null) ** GOTO lbl-1000
            var6_4 = this.mMenu.getActionItems();
            var5_5 = var6_4.size();
            var2_6 = 0;
            do {
                if (var2_6 >= var5_5) lbl-1000: // 2 sources:
                {
                    var6_4 = this.mMenu != null ? this.mMenu.getNonActionItems() : null;
                    var2_6 = var4_3;
                    if (this.mReserveOverflow) {
                        var2_6 = var4_3;
                        if (var6_4 != null) {
                            var2_6 = var6_4.size();
                            if (var2_6 != 1) break;
                            var2_6 = ((MenuItemImpl)var6_4.get(0)).isActionViewExpanded() ? 0 : 1;
                        }
                    }
                    break block11;
                }
                var7_7 = var6_4.get(var2_6).getActionProvider();
                if (var7_7 != null) {
                    var7_7.setSubUiVisibilityListener(this);
                }
                ++var2_6;
            } while (true);
            var2_6 = var2_6 > 0 ? var3_2 : 0;
        }
        if (var2_6 != 0) {
            if (this.mOverflowButton == null) {
                this.mOverflowButton = new OverflowMenuButton(this.mSystemContext);
            }
            if ((var6_4 = (ViewGroup)this.mOverflowButton.getParent()) != this.mMenuView) {
                if (var6_4 != null) {
                    var6_4.removeView(this.mOverflowButton);
                }
                var6_4 = (ActionMenuView)this.mMenuView;
                var6_4.addView(this.mOverflowButton, (ViewGroup.LayoutParams)var6_4.generateOverflowButtonLayoutParams());
            }
        } else if (this.mOverflowButton != null && this.mOverflowButton.getParent() == this.mMenuView) {
            ((ViewGroup)this.mMenuView).removeView(this.mOverflowButton);
        }
        ((ActionMenuView)this.mMenuView).setOverflowReserved(this.mReserveOverflow);
    }

    class ActionButtonSubmenu
    extends MenuPopupHelper {
        /*
         * Enabled aggressive block sorting
         */
        public ActionButtonSubmenu(Context context, SubMenuBuilder subMenuBuilder) {
            boolean bl;
            super(context, subMenuBuilder);
            if (!((MenuItemImpl)subMenuBuilder.getItem()).isActionButton()) {
                context = ((ActionMenuPresenter)Object.this).mOverflowButton == null ? (View)Object.this.mMenuView : ((ActionMenuPresenter)Object.this).mOverflowButton;
                this.setAnchorView((View)context);
            }
            this.setCallback(Object.this.mPopupPresenterCallback);
            int n2 = subMenuBuilder.size();
            int n3 = 0;
            do {
                if (n3 >= n2) {
                    bl = false;
                    break;
                }
                Object.this = subMenuBuilder.getItem(n3);
                if (Object.this.isVisible() && Object.this.getIcon() != null) {
                    bl = true;
                    break;
                }
                ++n3;
            } while (true);
            this.setForceShowIcon(bl);
        }

        @Override
        public void onDismiss() {
            super.onDismiss();
            ActionMenuPresenter.access$3(Object.this, null);
            Object.this.mOpenSubMenuId = 0;
        }
    }

    static class HasPermanentMenuKey {
        private HasPermanentMenuKey() {
        }

        public static boolean get(Context context) {
            return ViewConfiguration.get((Context)context).hasPermanentMenuKey();
        }
    }

    class OpenOverflowRunnable
    implements Runnable {
        private OverflowPopup mPopup;

        public OpenOverflowRunnable(OverflowPopup overflowPopup) {
            this.mPopup = overflowPopup;
        }

        @Override
        public void run() {
            ActionMenuPresenter.this.mMenu.changeMenuMode();
            View view = (View)ActionMenuPresenter.this.mMenuView;
            if (view != null && view.getWindowToken() != null && this.mPopup.tryShow()) {
                ActionMenuPresenter.access$1(ActionMenuPresenter.this, this.mPopup);
            }
            ActionMenuPresenter.access$4(ActionMenuPresenter.this, null);
        }
    }

    class OverflowMenuButton
    extends ImageButton
    implements View_HasStateListenerSupport,
    ActionMenuView.ActionMenuChildView {
        private final Set<View_OnAttachStateChangeListener> mListeners;

        public OverflowMenuButton(Context context) {
            super(context, null, R.attr.actionOverflowButtonStyle);
            this.mListeners = new HashSet<View_OnAttachStateChangeListener>();
            this.setClickable(true);
            this.setFocusable(true);
            this.setVisibility(0);
            this.setEnabled(true);
        }

        @Override
        public void addOnAttachStateChangeListener(View_OnAttachStateChangeListener view_OnAttachStateChangeListener) {
            this.mListeners.add(view_OnAttachStateChangeListener);
        }

        @Override
        public boolean needsDividerAfter() {
            return false;
        }

        @Override
        public boolean needsDividerBefore() {
            return false;
        }

        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            Iterator<View_OnAttachStateChangeListener> iterator = this.mListeners.iterator();
            while (iterator.hasNext()) {
                iterator.next().onViewAttachedToWindow((View)this);
            }
            return;
        }

        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            Iterator<View_OnAttachStateChangeListener> iterator = this.mListeners.iterator();
            do {
                if (!iterator.hasNext()) {
                    if (ActionMenuPresenter.this.mOverflowPopup != null) {
                        ActionMenuPresenter.this.mOverflowPopup.dismiss();
                    }
                    return;
                }
                iterator.next().onViewDetachedFromWindow((View)this);
            } while (true);
        }

        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            this.playSoundEffect(0);
            ActionMenuPresenter.this.showOverflowMenu();
            return true;
        }

        @Override
        public void removeOnAttachStateChangeListener(View_OnAttachStateChangeListener view_OnAttachStateChangeListener) {
            this.mListeners.remove(view_OnAttachStateChangeListener);
        }
    }

    class OverflowPopup
    extends MenuPopupHelper {
        public OverflowPopup(Context context, MenuBuilder menuBuilder, View view, boolean bl) {
            super(context, menuBuilder, view, bl);
            this.setCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
        }

        @Override
        public void onDismiss() {
            super.onDismiss();
            ActionMenuPresenter.this.mMenu.close();
            ActionMenuPresenter.access$1(ActionMenuPresenter.this, null);
        }
    }

    static class SavedState
    implements Parcelable {
        public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>(){

            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public SavedState[] newArray(int n2) {
                return new SavedState[n2];
            }
        };
        public int openSubMenuId;

        SavedState() {
        }

        SavedState(Parcel parcel) {
            this.openSubMenuId = parcel.readInt();
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int n2) {
            parcel.writeInt(this.openSubMenuId);
        }

    }

}

