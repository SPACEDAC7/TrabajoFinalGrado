/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.Canvas
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 *  android.view.accessibility.AccessibilityEvent
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 */
package com.actionbarsherlock.internal.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import com.actionbarsherlock.internal.view.menu.ActionMenuItemView;
import com.actionbarsherlock.internal.view.menu.ActionMenuPresenter;
import com.actionbarsherlock.internal.view.menu.MenuBuilder;
import com.actionbarsherlock.internal.view.menu.MenuItemImpl;
import com.actionbarsherlock.internal.view.menu.MenuView;
import com.actionbarsherlock.internal.widget.IcsLinearLayout;
import com.actionbarsherlock.view.MenuItem;

public class ActionMenuView
extends IcsLinearLayout
implements MenuBuilder.ItemInvoker,
MenuView {
    static final int GENERATED_ITEM_PADDING = 4;
    private static final boolean IS_FROYO;
    static final int MIN_CELL_SIZE = 56;
    private boolean mFirst = true;
    private boolean mFormatItems;
    private int mFormatItemsWidth;
    private int mGeneratedItemPadding;
    private MenuBuilder mMenu;
    private int mMinCellSize;
    private ActionMenuPresenter mPresenter;
    private boolean mReserveOverflow;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = Build.VERSION.SDK_INT >= 8;
        IS_FROYO = bl;
    }

    public ActionMenuView(Context context) {
        this(context, null);
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.setBaselineAligned(false);
        float f2 = context.getResources().getDisplayMetrics().density;
        this.mMinCellSize = (int)(56.0f * f2);
        this.mGeneratedItemPadding = (int)(f2 * 4.0f);
    }

    /*
     * Enabled aggressive block sorting
     */
    static int measureChildForCells(View view, int n2, int n3, int n4, int n5) {
        boolean bl = false;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        n4 = View.MeasureSpec.makeMeasureSpec((int)(View.MeasureSpec.getSize((int)n4) - n5), (int)View.MeasureSpec.getMode((int)n4));
        if (n3 > 0) {
            view.measure(View.MeasureSpec.makeMeasureSpec((int)(n2 * n3), (int)Integer.MIN_VALUE), n4);
            n5 = view.getMeasuredWidth();
            n3 = n5 / n2;
            if (n5 % n2 != 0) {
                ++n3;
            }
        } else {
            n3 = 0;
        }
        ActionMenuItemView actionMenuItemView = view instanceof ActionMenuItemView ? (ActionMenuItemView)view : null;
        boolean bl2 = bl;
        if (!layoutParams.isOverflowButton) {
            bl2 = bl;
            if (actionMenuItemView != null) {
                bl2 = bl;
                if (actionMenuItemView.hasText()) {
                    bl2 = true;
                }
            }
        }
        layoutParams.expandable = bl2;
        layoutParams.cellsUsed = n3;
        view.measure(View.MeasureSpec.makeMeasureSpec((int)(n3 * n2), (int)1073741824), n4);
        return n3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void onMeasureExactFormat(int var1_1, int var2_2) {
        var17_3 = View.MeasureSpec.getMode((int)var2_2);
        var1_1 = View.MeasureSpec.getSize((int)var1_1);
        var16_4 = View.MeasureSpec.getSize((int)var2_2);
        var6_5 = this.getPaddingLeft();
        var7_6 = this.getPaddingRight();
        var21_7 = this.getPaddingTop() + this.getPaddingBottom();
        var18_8 = var1_1 - (var6_5 + var7_6);
        var1_1 = var18_8 / this.mMinCellSize;
        var6_5 = this.mMinCellSize;
        if (var1_1 == 0) {
            this.setMeasuredDimension(var18_8, 0);
            return;
        }
        var19_9 = this.mMinCellSize + var18_8 % var6_5 / var1_1;
        var6_5 = 0;
        var10_10 = 0;
        var9_11 = 0;
        var11_12 = 0;
        var8_13 = 0;
        var22_14 = 0;
        var20_15 = this.getChildCount();
        var12_16 = 0;
        do {
            if (var12_16 >= var20_15) break;
            var29_21 = this.getChildAt(var12_16);
            if (var29_21.getVisibility() != 8) {
                var28_20 = var29_21 instanceof ActionMenuItemView;
                ++var11_12;
                if (var28_20) {
                    var29_21.setPadding(this.mGeneratedItemPadding, 0, this.mGeneratedItemPadding, 0);
                }
                var30_22 = (LayoutParams)var29_21.getLayoutParams();
                var30_22.expanded = false;
                var30_22.extraPixels = 0;
                var30_22.cellsUsed = 0;
                var30_22.expandable = false;
                var30_22.leftMargin = 0;
                var30_22.rightMargin = 0;
                var28_20 = var28_20 != false && ((ActionMenuItemView)var29_21).hasText() != false;
                var30_22.preventEdgeOffset = var28_20;
                var7_6 = var30_22.isOverflowButton != false ? 1 : var1_1;
                var14_18 = ActionMenuView.measureChildForCells((View)var29_21, var19_9, var7_6, var2_2, var21_7);
                var10_10 = Math.max(var10_10, var14_18);
                var7_6 = var30_22.expandable != false ? var9_11 + 1 : var9_11;
                if (var30_22.isOverflowButton) {
                    var8_13 = 1;
                }
                var13_17 = var1_1 - var14_18;
                var9_11 = Math.max(var6_5, var29_21.getMeasuredHeight());
                if (var14_18 == 1) {
                    var24_19 = 1 << var12_16;
                    var1_1 = var9_11;
                    var9_11 = var7_6;
                    var14_18 = var8_13;
                    var22_14 = var24_19 | var22_14;
                    var6_5 = var10_10;
                    var8_13 = var13_17;
                    var7_6 = var1_1;
                    var10_10 = var14_18;
                    var1_1 = var11_12;
                } else {
                    var1_1 = var11_12;
                    var6_5 = var10_10;
                    var11_12 = var9_11;
                    var9_11 = var7_6;
                    var10_10 = var8_13;
                    var7_6 = var11_12;
                    var8_13 = var13_17;
                }
            } else {
                var13_17 = var11_12;
                var7_6 = var6_5;
                var11_12 = var1_1;
                var6_5 = var10_10;
                var1_1 = var13_17;
                var10_10 = var8_13;
                var8_13 = var11_12;
            }
            ++var12_16;
            var11_12 = var1_1;
            var1_1 = var8_13;
            var8_13 = var10_10;
            var10_10 = var6_5;
            var6_5 = var7_6;
        } while (true);
        var13_17 = var8_13 != 0 && var11_12 == 2 ? 1 : 0;
        var2_2 = 0;
        var12_16 = var1_1;
        var1_1 = var2_2;
        block1 : do {
            var26_24 = var22_14;
            if (var9_11 <= 0) ** GOTO lbl95
            if (var12_16 <= 0) ** GOTO lbl94
            var2_2 = Integer.MAX_VALUE;
            var24_19 = 0;
            var7_6 = 0;
            var14_18 = 0;
            ** GOTO lbl158
lbl94: // 1 sources:
            var26_24 = var22_14;
lbl95: // 3 sources:
            do {
                block39 : {
                    var2_2 = var8_13 == 0 && var11_12 == 1 ? 1 : 0;
                    if (var12_16 <= 0 || var26_24 == 0 || var12_16 >= var11_12 - 1 && var2_2 == 0 && var10_10 <= 1) ** GOTO lbl116
                    var4_26 = var5_25 = (float)Long.bitCount(var26_24);
                    if (var2_2 != 0) ** GOTO lbl-1000
                    var3_27 = var5_25;
                    if ((1 & var26_24) != 0) {
                        var3_27 = var5_25;
                        if (!((LayoutParams)this.getChildAt((int)0).getLayoutParams()).preventEdgeOffset) {
                            var3_27 = var5_25 - 0.5f;
                        }
                    }
                    var4_26 = var3_27;
                    if (((long)(1 << var20_15 - 1) & var26_24) == 0) ** GOTO lbl-1000
                    var4_26 = var3_27;
                    if (!((LayoutParams)this.getChildAt((int)(var20_15 - 1)).getLayoutParams()).preventEdgeOffset) {
                        var3_27 -= 0.5f;
                    } else lbl-1000: // 3 sources:
                    {
                        var3_27 = var4_26;
                    }
                    var2_2 = var3_27 > 0.0f ? (int)((float)(var12_16 * var19_9) / var3_27) : 0;
                    var7_6 = 0;
                    do {
                        if (var7_6 < var20_15) ** GOTO lbl119
lbl116: // 2 sources:
                        if (var1_1 != 0) {
                            break;
                        }
                        ** GOTO lbl-1000
lbl119: // 1 sources:
                        if (((long)(1 << var7_6) & var26_24) != 0) {
                            var29_21 = this.getChildAt(var7_6);
                            var30_22 = (LayoutParams)var29_21.getLayoutParams();
                            if (var29_21 instanceof ActionMenuItemView) {
                                var30_22.extraPixels = var2_2;
                                var30_22.expanded = true;
                                if (var7_6 == 0 && !var30_22.preventEdgeOffset) {
                                    var30_22.leftMargin = (- var2_2) / 2;
                                }
                                var1_1 = 1;
                            } else if (var30_22.isOverflowButton) {
                                var30_22.extraPixels = var2_2;
                                var30_22.expanded = true;
                                var30_22.rightMargin = (- var2_2) / 2;
                                var1_1 = 1;
                            } else {
                                if (var7_6 != 0) {
                                    var30_22.leftMargin = var2_2 / 2;
                                }
                                if (var7_6 != var20_15 - 1) {
                                    var30_22.rightMargin = var2_2 / 2;
                                }
                            }
                        }
                        ++var7_6;
                    } while (true);
                    var2_2 = View.MeasureSpec.makeMeasureSpec((int)(var16_4 - var21_7), (int)var17_3);
                    var1_1 = 0;
                    do {
                        if (var1_1 >= var20_15) lbl-1000: // 2 sources:
                        {
                            if (var17_3 == 1073741824) break;
                            break block39;
                        }
                        var29_21 = this.getChildAt(var1_1);
                        var30_22 = (LayoutParams)var29_21.getLayoutParams();
                        if (var30_22.expanded) {
                            var7_6 = var30_22.cellsUsed;
                            var29_21.measure(View.MeasureSpec.makeMeasureSpec((int)(var30_22.extraPixels + var7_6 * var19_9), (int)1073741824), var2_2);
                        }
                        ++var1_1;
                    } while (true);
                    var6_5 = var16_4;
                }
                this.setMeasuredDimension(var18_8, var6_5);
                return;
                break;
            } while (true);
lbl158: // 1 sources:
            do {
                if (var14_18 >= var20_15) {
                    var26_24 = var22_14 |= var24_19;
                    if (var7_6 > var12_16) ** continue;
                    break;
                }
                var29_21 = (LayoutParams)this.getChildAt(var14_18).getLayoutParams();
                if (!var29_21.expandable) ** GOTO lbl-1000
                if (var29_21.cellsUsed < var2_2) {
                    var7_6 = var29_21.cellsUsed;
                    var24_19 = 1 << var14_18;
                    var2_2 = 1;
                } else if (var29_21.cellsUsed == var2_2) {
                    var24_19 |= (long)(1 << var14_18);
                    var15_23 = var7_6 + 1;
                    var7_6 = var2_2;
                    var2_2 = var15_23;
                } else lbl-1000: // 2 sources:
                {
                    var15_23 = var2_2;
                    var2_2 = var7_6;
                    var7_6 = var15_23;
                }
                var15_23 = var14_18 + 1;
                var14_18 = var7_6;
                var7_6 = var2_2;
                var2_2 = var14_18;
                var14_18 = var15_23;
            } while (true);
            var1_1 = var12_16;
            var7_6 = 0;
            do {
                if (var7_6 >= var20_15) {
                    var2_2 = 1;
                    var12_16 = var1_1;
                    var1_1 = var2_2;
                    continue block1;
                }
                var29_21 = this.getChildAt(var7_6);
                var30_22 = (LayoutParams)var29_21.getLayoutParams();
                if (((long)(1 << var7_6) & var24_19) == 0) {
                    if (var30_22.cellsUsed == var2_2 + 1) {
                        var22_14 |= (long)(1 << var7_6);
                    }
                } else {
                    if (var13_17 != 0 && var30_22.preventEdgeOffset && var1_1 == 1) {
                        var29_21.setPadding(this.mGeneratedItemPadding + var19_9, 0, this.mGeneratedItemPadding, 0);
                    }
                    ++var30_22.cellsUsed;
                    var30_22.expanded = true;
                    --var1_1;
                }
                ++var7_6;
            } while (true);
            break;
        } while (true);
    }

    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams != null && layoutParams instanceof LayoutParams) {
            return true;
        }
        return false;
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    protected LayoutParams generateDefaultLayoutParams() {
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.gravity = 16;
        return layoutParams;
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(this.getContext(), attributeSet);
    }

    protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams object) {
        if (object instanceof LayoutParams) {
            object = new LayoutParams((LayoutParams)((Object)object));
            if (object.gravity <= 0) {
                object.gravity = 16;
            }
            return object;
        }
        return this.generateDefaultLayoutParams();
    }

    public LayoutParams generateOverflowButtonLayoutParams() {
        LinearLayout.LayoutParams layoutParams = this.generateDefaultLayoutParams();
        layoutParams.isOverflowButton = true;
        return layoutParams;
    }

    @Override
    public int getWindowAnimations() {
        return 0;
    }

    @Override
    protected boolean hasDividerBeforeChildAt(int n2) {
        boolean bl = false;
        if (n2 == 0) {
            return false;
        }
        View view = this.getChildAt(n2 - 1);
        View view2 = this.getChildAt(n2);
        boolean bl2 = bl;
        if (n2 < this.getChildCount()) {
            bl2 = bl;
            if (view instanceof ActionMenuChildView) {
                bl2 = ((ActionMenuChildView)view).needsDividerAfter() | false;
            }
        }
        if (n2 > 0 && view2 instanceof ActionMenuChildView) {
            return ((ActionMenuChildView)view2).needsDividerBefore() | bl2;
        }
        return bl2;
    }

    @Override
    public void initialize(MenuBuilder menuBuilder) {
        this.mMenu = menuBuilder;
    }

    @Override
    public boolean invokeItem(MenuItemImpl menuItemImpl) {
        return this.mMenu.performItemAction(menuItemImpl, 0);
    }

    public boolean isExpandedFormat() {
        return this.mFormatItems;
    }

    public boolean isOverflowReserved() {
        return this.mReserveOverflow;
    }

    public void onConfigurationChanged(Configuration configuration) {
        if (IS_FROYO) {
            super.onConfigurationChanged(configuration);
        }
        this.mPresenter.updateMenuView(false);
        if (this.mPresenter != null && this.mPresenter.isOverflowMenuShowing()) {
            this.mPresenter.hideOverflowMenu();
            this.mPresenter.showOverflowMenu();
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.mPresenter.dismissPopupMenus();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (!IS_FROYO && this.mFirst) {
            this.mFirst = false;
            this.requestLayout();
            return;
        }
        super.onDraw(canvas);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void onLayout(boolean var1_1, int var2_2, int var3_3, int var4_4, int var5_5) {
        if (!this.mFormatItems) {
            super.onLayout(var1_1, var2_2, var3_3, var4_4, var5_5);
            return;
        }
        var11_6 = this.getChildCount();
        var10_7 = (var3_3 + var5_5) / 2;
        var3_3 = 0;
        var6_8 = var4_4 - var2_2 - this.getPaddingRight() - this.getPaddingLeft();
        var5_5 = 0;
        var7_9 = 0;
        do {
            if (var7_9 < var11_6) ** GOTO lbl21
            if (var11_6 == 1 && var5_5 == 0) {
                var13_13 = this.getChildAt(0);
                var3_3 = var13_13.getMeasuredWidth();
                var5_5 = var13_13.getMeasuredHeight();
                var2_2 = (var4_4 - var2_2) / 2 - var3_3 / 2;
                var4_4 = var10_7 - var5_5 / 2;
                var13_13.layout(var2_2, var4_4, var3_3 + var2_2, var5_5 + var4_4);
                return;
            }
            ** GOTO lbl44
lbl21: // 1 sources:
            var13_13 = this.getChildAt(var7_9);
            if (var13_13.getVisibility() == 8) ** GOTO lbl61
            var14_14 = (LayoutParams)var13_13.getLayoutParams();
            if (var14_14.isOverflowButton) {
                var5_5 = var13_13.getMeasuredWidth();
                this.hasDividerBeforeChildAt(var7_9);
                var8_10 = var13_13.getMeasuredHeight();
                var9_11 = this.getWidth() - this.getPaddingRight() - var14_14.rightMargin;
                var12_12 = var10_7 - var8_10 / 2;
                var13_13.layout(var9_11 - var5_5, var12_12, var9_11, var8_10 + var12_12);
                var8_10 = var6_8 - var5_5;
                var6_8 = 1;
                var5_5 = var3_3;
                var3_3 = var8_10;
            } else {
                var8_10 = var13_13.getMeasuredWidth();
                var9_11 = var14_14.leftMargin;
                var8_10 = var6_8 - (var14_14.rightMargin + (var8_10 + var9_11));
                var9_11 = var3_3 + 1;
                var6_8 = var5_5;
                var3_3 = var8_10;
                var5_5 = var9_11;
            }
            ** GOTO lbl66
lbl44: // 1 sources:
            var2_2 = var5_5 != 0 ? 0 : 1;
            var2_2 = (var2_2 = var3_3 - var2_2) > 0 ? var6_8 / var2_2 : 0;
            var4_4 = Math.max(0, var2_2);
            var2_2 = this.getPaddingLeft();
            var3_3 = 0;
            while (var3_3 < var11_6) {
                var13_13 = this.getChildAt(var3_3);
                var14_14 = (LayoutParams)var13_13.getLayoutParams();
                if (var13_13.getVisibility() != 8 && !var14_14.isOverflowButton) {
                    var5_5 = var13_13.getMeasuredWidth();
                    var6_8 = var13_13.getMeasuredHeight();
                    var7_9 = var10_7 - var6_8 / 2;
                    var13_13.layout(var2_2, var7_9, (var2_2 += var14_14.leftMargin) + var5_5, var6_8 + var7_9);
                    var2_2 = var14_14.rightMargin + var5_5 + var4_4 + var2_2;
                }
                ++var3_3;
            }
            return;
lbl61: // 1 sources:
            var8_10 = var3_3;
            var9_11 = var5_5;
            var3_3 = var6_8;
            var5_5 = var8_10;
            var6_8 = var9_11;
lbl66: // 3 sources:
            var8_10 = var7_9 + 1;
            var7_9 = var6_8;
            var6_8 = var3_3;
            var3_3 = var5_5;
            var5_5 = var7_9;
            var7_9 = var8_10;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onMeasure(int n2, int n3) {
        boolean bl = this.mFormatItems;
        boolean bl2 = View.MeasureSpec.getMode((int)n2) == 1073741824;
        this.mFormatItems = bl2;
        if (bl != this.mFormatItems) {
            this.mFormatItemsWidth = 0;
        }
        int n4 = View.MeasureSpec.getMode((int)n2);
        if (this.mFormatItems && this.mMenu != null && n4 != this.mFormatItemsWidth) {
            this.mFormatItemsWidth = n4;
            this.mMenu.onItemsChanged(true);
        }
        if (this.mFormatItems) {
            this.onMeasureExactFormat(n2, n3);
            return;
        }
        super.onMeasure(n2, n3);
    }

    public void setOverflowReserved(boolean bl) {
        this.mReserveOverflow = bl;
    }

    public void setPresenter(ActionMenuPresenter actionMenuPresenter) {
        this.mPresenter = actionMenuPresenter;
    }

    public static interface ActionMenuChildView {
        public boolean needsDividerAfter();

        public boolean needsDividerBefore();
    }

    public static class LayoutParams
    extends LinearLayout.LayoutParams {
        public int cellsUsed;
        public boolean expandable;
        public boolean expanded;
        public int extraPixels;
        public boolean isOverflowButton;
        public boolean preventEdgeOffset;

        public LayoutParams(int n2, int n3) {
            super(n2, n3);
            this.isOverflowButton = false;
        }

        public LayoutParams(int n2, int n3, boolean bl) {
            super(n2, n3);
            this.isOverflowButton = bl;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(LayoutParams layoutParams) {
            super((ViewGroup.MarginLayoutParams)layoutParams);
            this.isOverflowButton = layoutParams.isOverflowButton;
        }
    }

}

