/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.util.SparseArray
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.KeyCharacterMap
 *  android.view.KeyCharacterMap$KeyData
 *  android.view.KeyEvent
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.MenuItem$OnMenuItemClickListener
 *  android.view.SubMenu
 *  android.view.View
 */
package com.actionbarsherlock.internal.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import com.actionbarsherlock.R;
import com.actionbarsherlock.internal.view.menu.MenuItemImpl;
import com.actionbarsherlock.internal.view.menu.MenuPresenter;
import com.actionbarsherlock.internal.view.menu.SubMenuBuilder;
import com.actionbarsherlock.view.ActionProvider;
import com.actionbarsherlock.view.Menu;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class MenuBuilder
implements Menu {
    private static final String ACTION_VIEW_STATES_KEY = "android:menu:actionviewstates";
    private static final String EXPANDED_ACTION_VIEW_ID = "android:menu:expandedactionview";
    private static final String PRESENTER_KEY = "android:menu:presenters";
    private static final int[] sCategoryToOrder;
    private ArrayList<MenuItemImpl> mActionItems;
    private Callback mCallback;
    private final Context mContext;
    private ContextMenu.ContextMenuInfo mCurrentMenuInfo;
    private int mDefaultShowAsAction = 0;
    private MenuItemImpl mExpandedItem;
    Drawable mHeaderIcon;
    CharSequence mHeaderTitle;
    View mHeaderView;
    private boolean mIsActionItemsStale;
    private boolean mIsClosing = false;
    private boolean mIsVisibleItemsStale;
    private ArrayList<MenuItemImpl> mItems;
    private boolean mItemsChangedWhileDispatchPrevented = false;
    private ArrayList<MenuItemImpl> mNonActionItems;
    private boolean mOptionalIconsVisible = false;
    private CopyOnWriteArrayList<WeakReference<MenuPresenter>> mPresenters = new CopyOnWriteArrayList();
    private boolean mPreventDispatchingItemsChanged = false;
    private boolean mQwertyMode;
    private final Resources mResources;
    private boolean mShortcutsVisible;
    private ArrayList<MenuItemImpl> mTempShortcutItemList = new ArrayList();
    private ArrayList<MenuItemImpl> mVisibleItems;

    static {
        int[] arrn = new int[6];
        arrn[0] = 1;
        arrn[1] = 4;
        arrn[2] = 5;
        arrn[3] = 3;
        arrn[4] = 2;
        sCategoryToOrder = arrn;
    }

    public MenuBuilder(Context context) {
        this.mContext = context;
        this.mResources = context.getResources();
        this.mItems = new ArrayList();
        this.mVisibleItems = new ArrayList();
        this.mIsVisibleItemsStale = true;
        this.mActionItems = new ArrayList();
        this.mNonActionItems = new ArrayList();
        this.mIsActionItemsStale = true;
        this.setShortcutsVisibleInner(true);
    }

    private com.actionbarsherlock.view.MenuItem addInternal(int n2, int n3, int n4, CharSequence object) {
        int n5 = MenuBuilder.getOrdering(n4);
        object = new MenuItemImpl(this, n2, n3, n4, n5, (CharSequence)object, this.mDefaultShowAsAction);
        if (this.mCurrentMenuInfo != null) {
            object.setMenuInfo(this.mCurrentMenuInfo);
        }
        this.mItems.add(MenuBuilder.findInsertIndex(this.mItems, n5), (MenuItemImpl)object);
        this.onItemsChanged(true);
        return object;
    }

    private void dispatchPresenterUpdate(boolean bl) {
        if (this.mPresenters.isEmpty()) {
            return;
        }
        this.stopDispatchingItemsChanged();
        Iterator<WeakReference<MenuPresenter>> iterator = this.mPresenters.iterator();
        do {
            if (!iterator.hasNext()) {
                this.startDispatchingItemsChanged();
                return;
            }
            WeakReference<MenuPresenter> weakReference = iterator.next();
            MenuPresenter menuPresenter = weakReference.get();
            if (menuPresenter == null) {
                this.mPresenters.remove(weakReference);
                continue;
            }
            menuPresenter.updateMenuView(bl);
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void dispatchRestoreInstanceState(Bundle bundle) {
        if ((bundle = bundle.getSparseParcelableArray("android:menu:presenters")) != null && !this.mPresenters.isEmpty()) {
            for (Parcelable parcelable : this.mPresenters) {
                MenuPresenter menuPresenter = parcelable.get();
                if (menuPresenter == null) {
                    this.mPresenters.remove((Object)parcelable);
                    continue;
                }
                int n2 = menuPresenter.getId();
                if (n2 <= 0 || (parcelable = (Parcelable)bundle.get(n2)) == null) continue;
                menuPresenter.onRestoreInstanceState(parcelable);
            }
        }
    }

    private void dispatchSaveInstanceState(Bundle bundle) {
        if (this.mPresenters.isEmpty()) {
            return;
        }
        SparseArray sparseArray = new SparseArray();
        Iterator<WeakReference<MenuPresenter>> iterator = this.mPresenters.iterator();
        do {
            if (!iterator.hasNext()) {
                bundle.putSparseParcelableArray("android:menu:presenters", sparseArray);
                return;
            }
            Parcelable parcelable = iterator.next();
            MenuPresenter menuPresenter = parcelable.get();
            if (menuPresenter == null) {
                this.mPresenters.remove((Object)parcelable);
                continue;
            }
            int n2 = menuPresenter.getId();
            if (n2 <= 0 || (parcelable = menuPresenter.onSaveInstanceState()) == null) continue;
            sparseArray.put(n2, (Object)parcelable);
        } while (true);
    }

    private boolean dispatchSubMenuSelected(SubMenuBuilder subMenuBuilder) {
        if (this.mPresenters.isEmpty()) {
            return false;
        }
        Iterator<WeakReference<MenuPresenter>> iterator = this.mPresenters.iterator();
        boolean bl = false;
        while (iterator.hasNext()) {
            WeakReference<MenuPresenter> weakReference = iterator.next();
            MenuPresenter menuPresenter = weakReference.get();
            if (menuPresenter == null) {
                this.mPresenters.remove(weakReference);
                continue;
            }
            if (bl) continue;
            bl = menuPresenter.onSubMenuSelected(subMenuBuilder);
        }
        return bl;
    }

    private static int findInsertIndex(ArrayList<MenuItemImpl> arrayList, int n2) {
        int n3 = arrayList.size() - 1;
        while (n3 >= 0) {
            if (arrayList.get(n3).getOrdering() <= n2) {
                return n3 + 1;
            }
            --n3;
        }
        return 0;
    }

    private static int getOrdering(int n2) {
        int n3 = n2 >> 16;
        if (n3 < 0 || n3 >= sCategoryToOrder.length) {
            throw new IllegalArgumentException("order does not contain a valid category.");
        }
        return sCategoryToOrder[n3] << 16 | 65535 & n2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void removeItemAtInt(int n2, boolean bl) {
        if (n2 < 0) return;
        if (n2 >= this.mItems.size()) {
            return;
        }
        this.mItems.remove(n2);
        if (!bl) return;
        this.onItemsChanged(true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void setHeaderInternal(int n2, CharSequence charSequence, int n3, Drawable drawable2, View view) {
        Resources resources = this.getResources();
        if (view != null) {
            this.mHeaderView = view;
            this.mHeaderTitle = null;
            this.mHeaderIcon = null;
        } else {
            if (n2 > 0) {
                this.mHeaderTitle = resources.getText(n2);
            } else if (charSequence != null) {
                this.mHeaderTitle = charSequence;
            }
            if (n3 > 0) {
                this.mHeaderIcon = resources.getDrawable(n3);
            } else if (drawable2 != null) {
                this.mHeaderIcon = drawable2;
            }
            this.mHeaderView = null;
        }
        this.onItemsChanged(false);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void setShortcutsVisibleInner(boolean bl) {
        boolean bl2 = true;
        bl = bl && this.mResources.getConfiguration().keyboard != 1 && this.mResources.getBoolean(R.bool.abs__config_showMenuShortcutsWhenKeyboardPresent) ? bl2 : false;
        this.mShortcutsVisible = bl;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem add(int n2) {
        return this.addInternal(0, 0, 0, this.mResources.getString(n2));
    }

    @Override
    public com.actionbarsherlock.view.MenuItem add(int n2, int n3, int n4, int n5) {
        return this.addInternal(n2, n3, n4, this.mResources.getString(n5));
    }

    @Override
    public com.actionbarsherlock.view.MenuItem add(int n2, int n3, int n4, CharSequence charSequence) {
        return this.addInternal(n2, n3, n4, charSequence);
    }

    @Override
    public com.actionbarsherlock.view.MenuItem add(CharSequence charSequence) {
        return this.addInternal(0, 0, 0, charSequence);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int addIntentOptions(int n2, int n3, int n4, ComponentName object, Intent[] arrintent, Intent intent, int n5, com.actionbarsherlock.view.MenuItem[] arrmenuItem) {
        PackageManager packageManager = this.mContext.getPackageManager();
        List list = packageManager.queryIntentActivityOptions((ComponentName)object, arrintent, intent, 0);
        int n6 = list != null ? list.size() : 0;
        if ((n5 & 1) == 0) {
            this.removeGroup(n2);
        }
        n5 = 0;
        while (n5 < n6) {
            ResolveInfo resolveInfo = (ResolveInfo)list.get(n5);
            object = resolveInfo.specificIndex < 0 ? intent : arrintent[resolveInfo.specificIndex];
            object = new Intent((Intent)object);
            object.setComponent(new ComponentName(resolveInfo.activityInfo.applicationInfo.packageName, resolveInfo.activityInfo.name));
            object = this.add(n2, n3, n4, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent((Intent)object);
            if (arrmenuItem != null && resolveInfo.specificIndex >= 0) {
                arrmenuItem[resolveInfo.specificIndex] = object;
            }
            ++n5;
        }
        return n6;
    }

    public void addMenuPresenter(MenuPresenter menuPresenter) {
        this.mPresenters.add(new WeakReference<MenuPresenter>(menuPresenter));
        menuPresenter.initForMenu(this.mContext, this);
        this.mIsActionItemsStale = true;
    }

    @Override
    public com.actionbarsherlock.view.SubMenu addSubMenu(int n2) {
        return this.addSubMenu(0, 0, 0, this.mResources.getString(n2));
    }

    @Override
    public com.actionbarsherlock.view.SubMenu addSubMenu(int n2, int n3, int n4, int n5) {
        return this.addSubMenu(n2, n3, n4, this.mResources.getString(n5));
    }

    @Override
    public com.actionbarsherlock.view.SubMenu addSubMenu(int n2, int n3, int n4, CharSequence object) {
        object = (MenuItemImpl)this.addInternal(n2, n3, n4, (CharSequence)object);
        SubMenuBuilder subMenuBuilder = new SubMenuBuilder(this.mContext, this, (MenuItemImpl)object);
        object.setSubMenu(subMenuBuilder);
        return subMenuBuilder;
    }

    @Override
    public com.actionbarsherlock.view.SubMenu addSubMenu(CharSequence charSequence) {
        return this.addSubMenu(0, 0, 0, charSequence);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean bindNativeOverflow(android.view.Menu var1_1, MenuItem.OnMenuItemClickListener var2_2, HashMap<MenuItem, MenuItemImpl> var3_3) {
        var6_4 = this.getNonActionItems();
        if (var6_4 == null) return false;
        if (var6_4.size() == 0) {
            return false;
        }
        var1_1.clear();
        var7_6 = var6_4.iterator();
        var4_7 = false;
        block0 : do {
            var5_5 = var4_7;
            if (var7_6.hasNext() == false) return var5_5;
            var8_8 = var7_6.next();
            if (!var8_8.isVisible()) continue;
            if (var8_8.hasSubMenu()) ** GOTO lbl16
            var6_4 = var1_1.add(var8_8.getGroupId(), var8_8.getItemId(), var8_8.getOrder(), var8_8.getTitle());
            ** GOTO lbl21
lbl16: // 1 sources:
            var6_4 = var1_1.addSubMenu(var8_8.getGroupId(), var8_8.getItemId(), var8_8.getOrder(), var8_8.getTitle());
            var9_9 = ((SubMenuBuilder)var8_8.getSubMenu()).getVisibleItems().iterator();
            do {
                if (!var9_9.hasNext()) {
                    var6_4 = var6_4.getItem();
lbl21: // 2 sources:
                    var6_4.setIcon(var8_8.getIcon());
                    var6_4.setOnMenuItemClickListener(var2_2);
                    var6_4.setEnabled(var8_8.isEnabled());
                    var6_4.setIntent(var8_8.getIntent());
                    var6_4.setNumericShortcut(var8_8.getNumericShortcut());
                    var6_4.setAlphabeticShortcut(var8_8.getAlphabeticShortcut());
                    var6_4.setTitleCondensed(var8_8.getTitleCondensed());
                    var6_4.setCheckable(var8_8.isCheckable());
                    var6_4.setChecked(var8_8.isChecked());
                    if (var8_8.isExclusiveCheckable()) {
                        var1_1.setGroupCheckable(var8_8.getGroupId(), true, true);
                    }
                    var3_3.put((MenuItem)var6_4, var8_8);
                    var4_7 = true;
                    continue block0;
                }
                var10_10 = var9_9.next();
                var11_11 = var6_4.add(var10_10.getGroupId(), var10_10.getItemId(), var10_10.getOrder(), var10_10.getTitle());
                var11_11.setIcon(var10_10.getIcon());
                var11_11.setOnMenuItemClickListener(var2_2);
                var11_11.setEnabled(var10_10.isEnabled());
                var11_11.setIntent(var10_10.getIntent());
                var11_11.setNumericShortcut(var10_10.getNumericShortcut());
                var11_11.setAlphabeticShortcut(var10_10.getAlphabeticShortcut());
                var11_11.setTitleCondensed(var10_10.getTitleCondensed());
                var11_11.setCheckable(var10_10.isCheckable());
                var11_11.setChecked(var10_10.isChecked());
                if (var10_10.isExclusiveCheckable()) {
                    var6_4.setGroupCheckable(var10_10.getGroupId(), true, true);
                }
                var3_3.put(var11_11, var10_10);
            } while (true);
            break;
        } while (true);
    }

    public void changeMenuMode() {
        if (this.mCallback != null) {
            this.mCallback.onMenuModeChange(this);
        }
    }

    @Override
    public void clear() {
        if (this.mExpandedItem != null) {
            this.collapseItemActionView(this.mExpandedItem);
        }
        this.mItems.clear();
        this.onItemsChanged(true);
    }

    public void clearAll() {
        this.mPreventDispatchingItemsChanged = true;
        this.clear();
        this.clearHeader();
        this.mPreventDispatchingItemsChanged = false;
        this.mItemsChangedWhileDispatchPrevented = false;
        this.onItemsChanged(true);
    }

    public void clearHeader() {
        this.mHeaderIcon = null;
        this.mHeaderTitle = null;
        this.mHeaderView = null;
        this.onItemsChanged(false);
    }

    @Override
    public void close() {
        this.close(true);
    }

    final void close(boolean bl) {
        if (this.mIsClosing) {
            return;
        }
        this.mIsClosing = true;
        Iterator<WeakReference<MenuPresenter>> iterator = this.mPresenters.iterator();
        do {
            if (!iterator.hasNext()) {
                this.mIsClosing = false;
                return;
            }
            WeakReference<MenuPresenter> weakReference = iterator.next();
            MenuPresenter menuPresenter = weakReference.get();
            if (menuPresenter == null) {
                this.mPresenters.remove(weakReference);
                continue;
            }
            menuPresenter.onCloseMenu(this, bl);
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean collapseItemActionView(MenuItemImpl menuItemImpl) {
        boolean bl;
        boolean bl2 = bl = false;
        if (this.mPresenters.isEmpty()) return bl2;
        if (this.mExpandedItem != menuItemImpl) {
            return bl;
        }
        this.stopDispatchingItemsChanged();
        Iterator<WeakReference<MenuPresenter>> iterator = this.mPresenters.iterator();
        bl = false;
        while (iterator.hasNext()) {
            WeakReference<MenuPresenter> weakReference = iterator.next();
            MenuPresenter menuPresenter = weakReference.get();
            if (menuPresenter == null) {
                this.mPresenters.remove(weakReference);
                continue;
            }
            bl = bl2 = menuPresenter.collapseItemActionView(this, menuItemImpl);
            if (bl2) break;
            bl = bl2;
        }
        this.startDispatchingItemsChanged();
        bl2 = bl;
        if (!bl) return bl2;
        this.mExpandedItem = null;
        return bl;
    }

    boolean dispatchMenuItemSelected(MenuBuilder menuBuilder, com.actionbarsherlock.view.MenuItem menuItem) {
        if (this.mCallback != null && this.mCallback.onMenuItemSelected(menuBuilder, menuItem)) {
            return true;
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean expandItemActionView(MenuItemImpl var1_1) {
        var3_2 = false;
        if (this.mPresenters.isEmpty()) {
            return var3_2;
        }
        this.stopDispatchingItemsChanged();
        var4_3 = this.mPresenters.iterator();
        var2_4 = false;
        do {
            if (!var4_3.hasNext()) ** GOTO lbl-1000
            var5_5 = var4_3.next();
            var6_6 = var5_5.get();
            if (var6_6 == null) {
                this.mPresenters.remove(var5_5);
                continue;
            }
            var2_4 = var3_2 = var6_6.expandItemActionView(this, var1_1);
            if (var3_2) lbl-1000: // 2 sources:
            {
                this.startDispatchingItemsChanged();
                var3_2 = var2_4;
                if (var2_4 == false) return var3_2;
                this.mExpandedItem = var1_1;
                return var2_4;
            }
            var2_4 = var3_2;
        } while (true);
    }

    public int findGroupIndex(int n2) {
        return this.findGroupIndex(n2, 0);
    }

    public int findGroupIndex(int n2, int n3) {
        int n4 = this.size();
        int n5 = n3;
        if (n3 < 0) {
            n5 = 0;
        }
        while (n5 < n4) {
            if (this.mItems.get(n5).getGroupId() == n2) {
                return n5;
            }
            ++n5;
        }
        return -1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public com.actionbarsherlock.view.MenuItem findItem(int n2) {
        int n3 = this.size();
        int n4 = 0;
        while (n4 < n3) {
            MenuItemImpl menuItemImpl;
            com.actionbarsherlock.view.MenuItem menuItem = menuItemImpl = this.mItems.get(n4);
            if (menuItemImpl.getItemId() == n2) return menuItem;
            if (menuItemImpl.hasSubMenu()) {
                com.actionbarsherlock.view.MenuItem menuItem2;
                menuItem = menuItem2 = menuItemImpl.getSubMenu().findItem(n2);
                if (menuItem2 != null) return menuItem;
            }
            ++n4;
        }
        return null;
    }

    public int findItemIndex(int n2) {
        int n3 = this.size();
        int n4 = 0;
        while (n4 < n3) {
            if (this.mItems.get(n4).getItemId() == n2) {
                return n4;
            }
            ++n4;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    MenuItemImpl findItemWithShortcutForKey(int n2, KeyEvent object) {
        ArrayList<MenuItemImpl> arrayList = this.mTempShortcutItemList;
        arrayList.clear();
        this.findItemsWithShortcutForKey(arrayList, n2, (KeyEvent)object);
        if (arrayList.isEmpty()) {
            return null;
        }
        int n3 = object.getMetaState();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        object.getKeyData(keyData);
        int n4 = arrayList.size();
        if (n4 == 1) {
            return arrayList.get(0);
        }
        boolean bl = this.isQwertyMode();
        int n5 = 0;
        while (n5 < n4) {
            MenuItemImpl menuItemImpl = arrayList.get(n5);
            char c2 = bl ? menuItemImpl.getAlphabeticShortcut() : menuItemImpl.getNumericShortcut();
            if (c2 == keyData.meta[0]) {
                object = menuItemImpl;
                if ((n3 & 2) == 0) return object;
            }
            if (c2 == keyData.meta[2]) {
                object = menuItemImpl;
                if ((n3 & 2) != 0) return object;
            }
            if (bl && c2 == '\b') {
                object = menuItemImpl;
                if (n2 == 67) return object;
            }
            ++n5;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    void findItemsWithShortcutForKey(List<MenuItemImpl> list, int n2, KeyEvent keyEvent) {
        boolean bl = this.isQwertyMode();
        int n3 = keyEvent.getMetaState();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        if (!keyEvent.getKeyData(keyData) && n2 != 67) {
            return;
        }
        int n4 = this.mItems.size();
        int n5 = 0;
        while (n5 < n4) {
            MenuItemImpl menuItemImpl = this.mItems.get(n5);
            if (menuItemImpl.hasSubMenu()) {
                ((MenuBuilder)((Object)menuItemImpl.getSubMenu())).findItemsWithShortcutForKey(list, n2, keyEvent);
            }
            char c2 = bl ? menuItemImpl.getAlphabeticShortcut() : menuItemImpl.getNumericShortcut();
            if ((n3 & 5) == 0 && c2 != '\u0000' && (c2 == keyData.meta[0] || c2 == keyData.meta[2] || bl && c2 == '\b' && n2 == 67) && menuItemImpl.isEnabled()) {
                list.add(menuItemImpl);
            }
            ++n5;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void flagActionItems() {
        block6 : {
            if (!this.mIsActionItemsStale) {
                return;
            }
            var3_1 = this.mPresenters.iterator();
            var1_2 = 0;
            do {
                if (!var3_1.hasNext()) {
                    if (var1_2 == 0) break;
                    this.mActionItems.clear();
                    this.mNonActionItems.clear();
                    var3_1 = this.getVisibleItems();
                    var2_5 = var3_1.size();
                    break block6;
                }
                var4_3 = var3_1.next();
                var5_4 = var4_3.get();
                if (var5_4 == null) {
                    this.mPresenters.remove(var4_3);
                    continue;
                }
                var1_2 = var5_4.flagActionItems() | var1_2;
            } while (true);
            this.mActionItems.clear();
            this.mNonActionItems.clear();
            this.mNonActionItems.addAll(this.getVisibleItems());
            ** GOTO lbl32
        }
        for (var1_2 = 0; var1_2 < var2_5; ++var1_2) {
            var4_3 = (MenuItemImpl)var3_1.get(var1_2);
            if (var4_3.isActionButton()) {
                this.mActionItems.add((MenuItemImpl)var4_3);
                continue;
            }
            this.mNonActionItems.add((MenuItemImpl)var4_3);
        }
lbl32: // 2 sources:
        this.mIsActionItemsStale = false;
    }

    ArrayList<MenuItemImpl> getActionItems() {
        this.flagActionItems();
        return this.mActionItems;
    }

    protected String getActionViewStatesKey() {
        return "android:menu:actionviewstates";
    }

    public Context getContext() {
        return this.mContext;
    }

    public MenuItemImpl getExpandedItem() {
        return this.mExpandedItem;
    }

    public Drawable getHeaderIcon() {
        return this.mHeaderIcon;
    }

    public CharSequence getHeaderTitle() {
        return this.mHeaderTitle;
    }

    public View getHeaderView() {
        return this.mHeaderView;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem getItem(int n2) {
        return this.mItems.get(n2);
    }

    ArrayList<MenuItemImpl> getNonActionItems() {
        this.flagActionItems();
        return this.mNonActionItems;
    }

    boolean getOptionalIconsVisible() {
        return this.mOptionalIconsVisible;
    }

    Resources getResources() {
        return this.mResources;
    }

    public MenuBuilder getRootMenu() {
        return this;
    }

    ArrayList<MenuItemImpl> getVisibleItems() {
        if (!this.mIsVisibleItemsStale) {
            return this.mVisibleItems;
        }
        this.mVisibleItems.clear();
        int n2 = this.mItems.size();
        int n3 = 0;
        do {
            if (n3 >= n2) {
                this.mIsVisibleItemsStale = false;
                this.mIsActionItemsStale = true;
                return this.mVisibleItems;
            }
            MenuItemImpl menuItemImpl = this.mItems.get(n3);
            if (menuItemImpl.isVisible()) {
                this.mVisibleItems.add(menuItemImpl);
            }
            ++n3;
        } while (true);
    }

    @Override
    public boolean hasVisibleItems() {
        int n2 = this.size();
        int n3 = 0;
        while (n3 < n2) {
            if (this.mItems.get(n3).isVisible()) {
                return true;
            }
            ++n3;
        }
        return false;
    }

    boolean isQwertyMode() {
        return this.mQwertyMode;
    }

    @Override
    public boolean isShortcutKey(int n2, KeyEvent keyEvent) {
        if (this.findItemWithShortcutForKey(n2, keyEvent) != null) {
            return true;
        }
        return false;
    }

    public boolean isShortcutsVisible() {
        return this.mShortcutsVisible;
    }

    void onItemActionRequestChanged(MenuItemImpl menuItemImpl) {
        this.mIsActionItemsStale = true;
        this.onItemsChanged(true);
    }

    void onItemVisibleChanged(MenuItemImpl menuItemImpl) {
        this.mIsVisibleItemsStale = true;
        this.onItemsChanged(true);
    }

    void onItemsChanged(boolean bl) {
        if (!this.mPreventDispatchingItemsChanged) {
            if (bl) {
                this.mIsVisibleItemsStale = true;
                this.mIsActionItemsStale = true;
            }
            this.dispatchPresenterUpdate(bl);
            return;
        }
        this.mItemsChangedWhileDispatchPrevented = true;
    }

    @Override
    public boolean performIdentifierAction(int n2, int n3) {
        return this.performItemAction(this.findItem(n2), n3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean performItemAction(com.actionbarsherlock.view.MenuItem object, int n2) {
        Object object2 = (MenuItemImpl)object;
        if (object2 == null) return false;
        if (!object2.isEnabled()) {
            return false;
        }
        boolean bl = object2.invoke();
        if (object2.hasCollapsibleActionView()) {
            boolean bl2;
            bl = bl2 = object2.expandActionView() | bl;
            if (!bl2) return bl;
            this.close(true);
            return bl2;
        }
        if (object.hasSubMenu()) {
            boolean bl3;
            this.close(false);
            object2 = (SubMenuBuilder)object.getSubMenu();
            object = object.getActionProvider();
            if (object != null && object.hasSubMenu()) {
                object.onPrepareSubMenu((com.actionbarsherlock.view.SubMenu)object2);
            }
            bl = bl3 = this.dispatchSubMenuSelected((SubMenuBuilder)object2) | bl;
            if (bl3) return bl;
            this.close(true);
            return bl3;
        }
        if ((n2 & 1) != 0) return bl;
        this.close(true);
        return bl;
    }

    @Override
    public boolean performShortcut(int n2, KeyEvent object, int n3) {
        object = this.findItemWithShortcutForKey(n2, (KeyEvent)object);
        boolean bl = false;
        if (object != null) {
            bl = this.performItemAction((com.actionbarsherlock.view.MenuItem)object, n3);
        }
        if ((n3 & 2) != 0) {
            this.close(true);
        }
        return bl;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void removeGroup(int n2) {
        int n3 = this.findGroupIndex(n2);
        if (n3 < 0) return;
        int n4 = this.mItems.size();
        int n5 = 0;
        do {
            if (n5 >= n4 - n3 || this.mItems.get(n3).getGroupId() != n2) {
                this.onItemsChanged(true);
                return;
            }
            this.removeItemAtInt(n3, false);
            ++n5;
        } while (true);
    }

    @Override
    public void removeItem(int n2) {
        this.removeItemAtInt(this.findItemIndex(n2), true);
    }

    public void removeItemAt(int n2) {
        this.removeItemAtInt(n2, true);
    }

    public void removeMenuPresenter(MenuPresenter menuPresenter) {
        Iterator<WeakReference<MenuPresenter>> iterator = this.mPresenters.iterator();
        while (iterator.hasNext()) {
            WeakReference<MenuPresenter> weakReference = iterator.next();
            MenuPresenter menuPresenter2 = weakReference.get();
            if (menuPresenter2 != null && menuPresenter2 != menuPresenter) continue;
            this.mPresenters.remove(weakReference);
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void restoreActionViewStates(Bundle object) {
        block6 : {
            if (object != null) {
                SparseArray sparseArray = object.getSparseParcelableArray(this.getActionViewStatesKey());
                if (Build.VERSION.SDK_INT >= 11 || sparseArray != null) {
                    int n2 = this.size();
                    int n3 = 0;
                    do {
                        if (n3 >= n2) {
                            n3 = object.getInt("android:menu:expandedactionview");
                            if (n3 <= 0 || (object = this.findItem(n3)) == null) break;
                            break block6;
                        }
                        com.actionbarsherlock.view.MenuItem menuItem = this.getItem(n3);
                        View view = menuItem.getActionView();
                        if (view != null && view.getId() != -1) {
                            view.restoreHierarchyState(sparseArray);
                        }
                        if (menuItem.hasSubMenu()) {
                            ((SubMenuBuilder)menuItem.getSubMenu()).restoreActionViewStates((Bundle)object);
                        }
                        ++n3;
                    } while (true);
                }
            }
            return;
        }
        object.expandActionView();
    }

    public void restorePresenterStates(Bundle bundle) {
        this.dispatchRestoreInstanceState(bundle);
    }

    public void saveActionViewStates(Bundle bundle) {
        int n2 = this.size();
        int n3 = 0;
        SparseArray sparseArray = null;
        do {
            if (n3 >= n2) {
                if (sparseArray != null) {
                    bundle.putSparseParcelableArray(this.getActionViewStatesKey(), sparseArray);
                }
                return;
            }
            com.actionbarsherlock.view.MenuItem menuItem = this.getItem(n3);
            View view = menuItem.getActionView();
            SparseArray sparseArray2 = sparseArray;
            if (view != null) {
                sparseArray2 = sparseArray;
                if (view.getId() != -1) {
                    SparseArray sparseArray3 = sparseArray;
                    if (sparseArray == null) {
                        sparseArray3 = new SparseArray();
                    }
                    view.saveHierarchyState(sparseArray3);
                    sparseArray2 = sparseArray3;
                    if (menuItem.isActionViewExpanded()) {
                        bundle.putInt("android:menu:expandedactionview", menuItem.getItemId());
                        sparseArray2 = sparseArray3;
                    }
                }
            }
            if (menuItem.hasSubMenu()) {
                ((SubMenuBuilder)menuItem.getSubMenu()).saveActionViewStates(bundle);
            }
            ++n3;
            sparseArray = sparseArray2;
        } while (true);
    }

    public void savePresenterStates(Bundle bundle) {
        this.dispatchSaveInstanceState(bundle);
    }

    public void setCallback(Callback callback) {
        this.mCallback = callback;
    }

    public void setCurrentMenuInfo(ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.mCurrentMenuInfo = contextMenuInfo;
    }

    public MenuBuilder setDefaultShowAsAction(int n2) {
        this.mDefaultShowAsAction = n2;
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    void setExclusiveItemChecked(com.actionbarsherlock.view.MenuItem menuItem) {
        int n2 = menuItem.getGroupId();
        int n3 = this.mItems.size();
        int n4 = 0;
        while (n4 < n3) {
            MenuItemImpl menuItemImpl = this.mItems.get(n4);
            if (menuItemImpl.getGroupId() == n2 && menuItemImpl.isExclusiveCheckable() && menuItemImpl.isCheckable()) {
                boolean bl = menuItemImpl == menuItem;
                menuItemImpl.setCheckedInt(bl);
            }
            ++n4;
        }
        return;
    }

    @Override
    public void setGroupCheckable(int n2, boolean bl, boolean bl2) {
        int n3 = this.mItems.size();
        int n4 = 0;
        while (n4 < n3) {
            MenuItemImpl menuItemImpl = this.mItems.get(n4);
            if (menuItemImpl.getGroupId() == n2) {
                menuItemImpl.setExclusiveCheckable(bl2);
                menuItemImpl.setCheckable(bl);
            }
            ++n4;
        }
        return;
    }

    @Override
    public void setGroupEnabled(int n2, boolean bl) {
        int n3 = this.mItems.size();
        int n4 = 0;
        while (n4 < n3) {
            MenuItemImpl menuItemImpl = this.mItems.get(n4);
            if (menuItemImpl.getGroupId() == n2) {
                menuItemImpl.setEnabled(bl);
            }
            ++n4;
        }
        return;
    }

    @Override
    public void setGroupVisible(int n2, boolean bl) {
        int n3 = this.mItems.size();
        int n4 = 0;
        boolean bl2 = false;
        do {
            if (n4 >= n3) {
                if (bl2) {
                    this.onItemsChanged(true);
                }
                return;
            }
            MenuItemImpl menuItemImpl = this.mItems.get(n4);
            if (menuItemImpl.getGroupId() == n2 && menuItemImpl.setVisibleInt(bl)) {
                bl2 = true;
            }
            ++n4;
        } while (true);
    }

    protected MenuBuilder setHeaderIconInt(int n2) {
        this.setHeaderInternal(0, null, n2, null, null);
        return this;
    }

    protected MenuBuilder setHeaderIconInt(Drawable drawable2) {
        this.setHeaderInternal(0, null, 0, drawable2, null);
        return this;
    }

    protected MenuBuilder setHeaderTitleInt(int n2) {
        this.setHeaderInternal(n2, null, 0, null, null);
        return this;
    }

    protected MenuBuilder setHeaderTitleInt(CharSequence charSequence) {
        this.setHeaderInternal(0, charSequence, 0, null, null);
        return this;
    }

    protected MenuBuilder setHeaderViewInt(View view) {
        this.setHeaderInternal(0, null, 0, null, view);
        return this;
    }

    void setOptionalIconsVisible(boolean bl) {
        this.mOptionalIconsVisible = bl;
    }

    @Override
    public void setQwertyMode(boolean bl) {
        this.mQwertyMode = bl;
        this.onItemsChanged(false);
    }

    public void setShortcutsVisible(boolean bl) {
        if (this.mShortcutsVisible == bl) {
            return;
        }
        this.setShortcutsVisibleInner(bl);
        this.onItemsChanged(false);
    }

    @Override
    public int size() {
        return this.mItems.size();
    }

    public void startDispatchingItemsChanged() {
        this.mPreventDispatchingItemsChanged = false;
        if (this.mItemsChangedWhileDispatchPrevented) {
            this.mItemsChangedWhileDispatchPrevented = false;
            this.onItemsChanged(true);
        }
    }

    public void stopDispatchingItemsChanged() {
        if (!this.mPreventDispatchingItemsChanged) {
            this.mPreventDispatchingItemsChanged = true;
            this.mItemsChangedWhileDispatchPrevented = false;
        }
    }

    public static interface Callback {
        public boolean onMenuItemSelected(MenuBuilder var1, com.actionbarsherlock.view.MenuItem var2);

        public void onMenuModeChange(MenuBuilder var1);
    }

    public static interface ItemInvoker {
        public boolean invokeItem(MenuItemImpl var1);
    }

}

