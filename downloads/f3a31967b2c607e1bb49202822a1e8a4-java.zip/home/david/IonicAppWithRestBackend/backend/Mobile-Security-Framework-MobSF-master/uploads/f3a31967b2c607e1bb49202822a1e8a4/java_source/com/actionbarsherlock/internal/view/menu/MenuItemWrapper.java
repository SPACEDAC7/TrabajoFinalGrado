/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.graphics.drawable.Drawable
 *  android.view.ActionProvider
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.MenuItem
 *  android.view.MenuItem$OnActionExpandListener
 *  android.view.MenuItem$OnMenuItemClickListener
 *  android.view.SubMenu
 *  android.view.View
 */
package com.actionbarsherlock.internal.view.menu;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import com.actionbarsherlock.internal.view.ActionProviderWrapper;
import com.actionbarsherlock.internal.view.menu.SubMenuWrapper;
import com.actionbarsherlock.internal.widget.CollapsibleActionViewWrapper;
import com.actionbarsherlock.view.CollapsibleActionView;
import com.actionbarsherlock.view.MenuItem;

public class MenuItemWrapper
implements MenuItem.OnMenuItemClickListener,
com.actionbarsherlock.view.MenuItem {
    private MenuItem.OnActionExpandListener mActionExpandListener = null;
    private MenuItem.OnMenuItemClickListener mMenuItemClickListener = null;
    private MenuItem.OnActionExpandListener mNativeActionExpandListener = null;
    private final MenuItem mNativeItem;
    private com.actionbarsherlock.view.SubMenu mSubMenu = null;

    public MenuItemWrapper(MenuItem menuItem) {
        if (menuItem == null) {
            throw new IllegalStateException("Wrapped menu item cannot be null.");
        }
        this.mNativeItem = menuItem;
    }

    @Override
    public boolean collapseActionView() {
        return this.mNativeItem.collapseActionView();
    }

    @Override
    public boolean expandActionView() {
        return this.mNativeItem.expandActionView();
    }

    @Override
    public com.actionbarsherlock.view.ActionProvider getActionProvider() {
        ActionProvider actionProvider = this.mNativeItem.getActionProvider();
        if (actionProvider != null && actionProvider instanceof ActionProviderWrapper) {
            return ((ActionProviderWrapper)actionProvider).unwrap();
        }
        return null;
    }

    @Override
    public View getActionView() {
        View view;
        View view2 = view = this.mNativeItem.getActionView();
        if (view instanceof CollapsibleActionViewWrapper) {
            view2 = ((CollapsibleActionViewWrapper)view).unwrap();
        }
        return view2;
    }

    @Override
    public char getAlphabeticShortcut() {
        return this.mNativeItem.getAlphabeticShortcut();
    }

    @Override
    public int getGroupId() {
        return this.mNativeItem.getGroupId();
    }

    @Override
    public Drawable getIcon() {
        return this.mNativeItem.getIcon();
    }

    @Override
    public Intent getIntent() {
        return this.mNativeItem.getIntent();
    }

    @Override
    public int getItemId() {
        return this.mNativeItem.getItemId();
    }

    @Override
    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.mNativeItem.getMenuInfo();
    }

    @Override
    public char getNumericShortcut() {
        return this.mNativeItem.getNumericShortcut();
    }

    @Override
    public int getOrder() {
        return this.mNativeItem.getOrder();
    }

    @Override
    public com.actionbarsherlock.view.SubMenu getSubMenu() {
        if (this.hasSubMenu() && this.mSubMenu == null) {
            this.mSubMenu = new SubMenuWrapper(this.mNativeItem.getSubMenu());
        }
        return this.mSubMenu;
    }

    @Override
    public CharSequence getTitle() {
        return this.mNativeItem.getTitle();
    }

    @Override
    public CharSequence getTitleCondensed() {
        return this.mNativeItem.getTitleCondensed();
    }

    @Override
    public boolean hasSubMenu() {
        return this.mNativeItem.hasSubMenu();
    }

    @Override
    public boolean isActionViewExpanded() {
        return this.mNativeItem.isActionViewExpanded();
    }

    @Override
    public boolean isCheckable() {
        return this.mNativeItem.isCheckable();
    }

    @Override
    public boolean isChecked() {
        return this.mNativeItem.isChecked();
    }

    @Override
    public boolean isEnabled() {
        return this.mNativeItem.isEnabled();
    }

    @Override
    public boolean isVisible() {
        return this.mNativeItem.isVisible();
    }

    public boolean onMenuItemClick(MenuItem menuItem) {
        if (this.mMenuItemClickListener != null) {
            return this.mMenuItemClickListener.onMenuItemClick(this);
        }
        return false;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setActionProvider(com.actionbarsherlock.view.ActionProvider actionProvider) {
        this.mNativeItem.setActionProvider((ActionProvider)new ActionProviderWrapper(actionProvider));
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setActionView(int n2) {
        View view;
        this.mNativeItem.setActionView(n2);
        if (n2 != 0 && (view = this.mNativeItem.getActionView()) instanceof CollapsibleActionView) {
            this.mNativeItem.setActionView((View)new CollapsibleActionViewWrapper(view));
        }
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setActionView(View view) {
        Object object = view;
        if (view != null) {
            object = view;
            if (view instanceof CollapsibleActionView) {
                object = new CollapsibleActionViewWrapper(view);
            }
        }
        this.mNativeItem.setActionView((View)object);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setAlphabeticShortcut(char c2) {
        this.mNativeItem.setAlphabeticShortcut(c2);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setCheckable(boolean bl) {
        this.mNativeItem.setCheckable(bl);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setChecked(boolean bl) {
        this.mNativeItem.setChecked(bl);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setEnabled(boolean bl) {
        this.mNativeItem.setEnabled(bl);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setIcon(int n2) {
        this.mNativeItem.setIcon(n2);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setIcon(Drawable drawable2) {
        this.mNativeItem.setIcon(drawable2);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setIntent(Intent intent) {
        this.mNativeItem.setIntent(intent);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setNumericShortcut(char c2) {
        this.mNativeItem.setNumericShortcut(c2);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.mActionExpandListener = onActionExpandListener;
        if (this.mNativeActionExpandListener == null) {
            this.mNativeActionExpandListener = new MenuItem.OnActionExpandListener(){

                public boolean onMenuItemActionCollapse(MenuItem menuItem) {
                    if (MenuItemWrapper.this.mActionExpandListener != null) {
                        return MenuItemWrapper.this.mActionExpandListener.onMenuItemActionCollapse(MenuItemWrapper.this);
                    }
                    return false;
                }

                public boolean onMenuItemActionExpand(MenuItem menuItem) {
                    if (MenuItemWrapper.this.mActionExpandListener != null) {
                        return MenuItemWrapper.this.mActionExpandListener.onMenuItemActionExpand(MenuItemWrapper.this);
                    }
                    return false;
                }
            };
            this.mNativeItem.setOnActionExpandListener(this.mNativeActionExpandListener);
        }
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.mMenuItemClickListener = onMenuItemClickListener;
        this.mNativeItem.setOnMenuItemClickListener((MenuItem.OnMenuItemClickListener)this);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setShortcut(char c2, char c3) {
        this.mNativeItem.setShortcut(c2, c3);
        return this;
    }

    @Override
    public void setShowAsAction(int n2) {
        this.mNativeItem.setShowAsAction(n2);
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setShowAsActionFlags(int n2) {
        this.mNativeItem.setShowAsActionFlags(n2);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setTitle(int n2) {
        this.mNativeItem.setTitle(n2);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setTitle(CharSequence charSequence) {
        this.mNativeItem.setTitle(charSequence);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setTitleCondensed(CharSequence charSequence) {
        this.mNativeItem.setTitleCondensed(charSequence);
        return this;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem setVisible(boolean bl) {
        this.mNativeItem.setVisible(bl);
        return this;
    }

}

