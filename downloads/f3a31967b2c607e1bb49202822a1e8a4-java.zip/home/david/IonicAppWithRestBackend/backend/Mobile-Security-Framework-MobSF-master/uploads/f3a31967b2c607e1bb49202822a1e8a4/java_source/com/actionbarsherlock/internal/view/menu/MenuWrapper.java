/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.view.KeyEvent
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.SubMenu
 */
package com.actionbarsherlock.internal.view.menu;

import android.content.ComponentName;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import com.actionbarsherlock.internal.view.menu.MenuItemWrapper;
import com.actionbarsherlock.internal.view.menu.SubMenuWrapper;
import com.actionbarsherlock.view.Menu;
import java.util.Map;
import java.util.WeakHashMap;

public class MenuWrapper
implements Menu {
    private final WeakHashMap<MenuItem, com.actionbarsherlock.view.MenuItem> mNativeMap = new WeakHashMap();
    private final android.view.Menu mNativeMenu;

    public MenuWrapper(android.view.Menu menu) {
        this.mNativeMenu = menu;
    }

    private com.actionbarsherlock.view.MenuItem addInternal(MenuItem menuItem) {
        MenuItemWrapper menuItemWrapper = new MenuItemWrapper(menuItem);
        this.mNativeMap.put(menuItem, menuItemWrapper);
        return menuItemWrapper;
    }

    private com.actionbarsherlock.view.SubMenu addInternal(SubMenu subMenu) {
        SubMenuWrapper subMenuWrapper = new SubMenuWrapper(subMenu);
        subMenu = subMenu.getItem();
        com.actionbarsherlock.view.MenuItem menuItem = subMenuWrapper.getItem();
        this.mNativeMap.put((MenuItem)subMenu, menuItem);
        return subMenuWrapper;
    }

    @Override
    public com.actionbarsherlock.view.MenuItem add(int n2) {
        return this.addInternal(this.mNativeMenu.add(n2));
    }

    @Override
    public com.actionbarsherlock.view.MenuItem add(int n2, int n3, int n4, int n5) {
        return this.addInternal(this.mNativeMenu.add(n2, n3, n4, n5));
    }

    @Override
    public com.actionbarsherlock.view.MenuItem add(int n2, int n3, int n4, CharSequence charSequence) {
        return this.addInternal(this.mNativeMenu.add(n2, n3, n4, charSequence));
    }

    @Override
    public com.actionbarsherlock.view.MenuItem add(CharSequence charSequence) {
        return this.addInternal(this.mNativeMenu.add(charSequence));
    }

    @Override
    public int addIntentOptions(int n2, int n3, int n4, ComponentName componentName, Intent[] arrintent, Intent intent, int n5, com.actionbarsherlock.view.MenuItem[] arrmenuItem) {
        if (arrmenuItem != null) {
            MenuItem[] arrmenuItem2 = new MenuItem[arrmenuItem.length];
            n3 = this.mNativeMenu.addIntentOptions(n2, n3, n4, componentName, arrintent, intent, n5, arrmenuItem2);
            n2 = 0;
            n4 = arrmenuItem.length;
            do {
                if (n2 >= n4) {
                    return n3;
                }
                arrmenuItem[n2] = new MenuItemWrapper(arrmenuItem2[n2]);
                ++n2;
            } while (true);
        }
        return this.mNativeMenu.addIntentOptions(n2, n3, n4, componentName, arrintent, intent, n5, null);
    }

    @Override
    public com.actionbarsherlock.view.SubMenu addSubMenu(int n2) {
        return this.addInternal(this.mNativeMenu.addSubMenu(n2));
    }

    @Override
    public com.actionbarsherlock.view.SubMenu addSubMenu(int n2, int n3, int n4, int n5) {
        return this.addInternal(this.mNativeMenu.addSubMenu(n2, n3, n4, n5));
    }

    @Override
    public com.actionbarsherlock.view.SubMenu addSubMenu(int n2, int n3, int n4, CharSequence charSequence) {
        return this.addInternal(this.mNativeMenu.addSubMenu(n2, n3, n4, charSequence));
    }

    @Override
    public com.actionbarsherlock.view.SubMenu addSubMenu(CharSequence charSequence) {
        return this.addInternal(this.mNativeMenu.addSubMenu(charSequence));
    }

    @Override
    public void clear() {
        this.mNativeMap.clear();
        this.mNativeMenu.clear();
    }

    @Override
    public void close() {
        this.mNativeMenu.close();
    }

    @Override
    public com.actionbarsherlock.view.MenuItem findItem(int n2) {
        return this.findItem(this.mNativeMenu.findItem(n2));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public com.actionbarsherlock.view.MenuItem findItem(MenuItem menuItem) {
        com.actionbarsherlock.view.MenuItem menuItem2;
        if (menuItem == null) {
            return null;
        }
        com.actionbarsherlock.view.MenuItem menuItem3 = menuItem2 = this.mNativeMap.get((Object)menuItem);
        if (menuItem2 != null) return menuItem3;
        return this.addInternal(menuItem);
    }

    @Override
    public com.actionbarsherlock.view.MenuItem getItem(int n2) {
        return this.findItem(this.mNativeMenu.getItem(n2));
    }

    @Override
    public boolean hasVisibleItems() {
        return this.mNativeMenu.hasVisibleItems();
    }

    public void invalidate() {
        if (this.mNativeMap.isEmpty()) {
            return;
        }
        WeakHashMap<MenuItem, com.actionbarsherlock.view.MenuItem> weakHashMap = new WeakHashMap<MenuItem, com.actionbarsherlock.view.MenuItem>(this.mNativeMap.size());
        int n2 = 0;
        do {
            if (n2 >= this.mNativeMenu.size()) {
                this.mNativeMap.clear();
                this.mNativeMap.putAll(weakHashMap);
                return;
            }
            MenuItem menuItem = this.mNativeMenu.getItem(n2);
            weakHashMap.put(menuItem, this.mNativeMap.get((Object)menuItem));
            ++n2;
        } while (true);
    }

    @Override
    public boolean isShortcutKey(int n2, KeyEvent keyEvent) {
        return this.mNativeMenu.isShortcutKey(n2, keyEvent);
    }

    @Override
    public boolean performIdentifierAction(int n2, int n3) {
        return this.mNativeMenu.performIdentifierAction(n2, n3);
    }

    @Override
    public boolean performShortcut(int n2, KeyEvent keyEvent, int n3) {
        return this.mNativeMenu.performShortcut(n2, keyEvent, n3);
    }

    @Override
    public void removeGroup(int n2) {
        int n3 = 0;
        do {
            if (n3 >= this.mNativeMenu.size()) {
                this.mNativeMenu.removeGroup(n2);
                return;
            }
            MenuItem menuItem = this.mNativeMenu.getItem(n3);
            if (menuItem.getGroupId() == n2) {
                this.mNativeMap.remove((Object)menuItem);
            }
            ++n3;
        } while (true);
    }

    @Override
    public void removeItem(int n2) {
        this.mNativeMap.remove((Object)this.mNativeMenu.findItem(n2));
        this.mNativeMenu.removeItem(n2);
    }

    @Override
    public void setGroupCheckable(int n2, boolean bl, boolean bl2) {
        this.mNativeMenu.setGroupCheckable(n2, bl, bl2);
    }

    @Override
    public void setGroupEnabled(int n2, boolean bl) {
        this.mNativeMenu.setGroupEnabled(n2, bl);
    }

    @Override
    public void setGroupVisible(int n2, boolean bl) {
        this.mNativeMenu.setGroupVisible(n2, bl);
    }

    @Override
    public void setQwertyMode(boolean bl) {
        this.mNativeMenu.setQwertyMode(bl);
    }

    @Override
    public int size() {
        return this.mNativeMenu.size();
    }

    public android.view.Menu unwrap() {
        return this.mNativeMenu;
    }
}

