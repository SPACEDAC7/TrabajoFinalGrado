/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.SubMenu
 *  android.view.View
 */
package com.actionbarsherlock.internal.view.menu;

import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.View;
import com.actionbarsherlock.internal.view.menu.MenuItemWrapper;
import com.actionbarsherlock.internal.view.menu.MenuWrapper;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.SubMenu;

public class SubMenuWrapper
extends MenuWrapper
implements SubMenu {
    private MenuItem mItem = null;
    private final android.view.SubMenu mNativeSubMenu;

    public SubMenuWrapper(android.view.SubMenu subMenu) {
        super((Menu)subMenu);
        this.mNativeSubMenu = subMenu;
    }

    @Override
    public void clearHeader() {
        this.mNativeSubMenu.clearHeader();
    }

    @Override
    public MenuItem getItem() {
        if (this.mItem == null) {
            this.mItem = new MenuItemWrapper(this.mNativeSubMenu.getItem());
        }
        return this.mItem;
    }

    @Override
    public SubMenu setHeaderIcon(int n2) {
        this.mNativeSubMenu.setHeaderIcon(n2);
        return this;
    }

    @Override
    public SubMenu setHeaderIcon(Drawable drawable2) {
        this.mNativeSubMenu.setHeaderIcon(drawable2);
        return this;
    }

    @Override
    public SubMenu setHeaderTitle(int n2) {
        this.mNativeSubMenu.setHeaderTitle(n2);
        return this;
    }

    @Override
    public SubMenu setHeaderTitle(CharSequence charSequence) {
        this.mNativeSubMenu.setHeaderTitle(charSequence);
        return this;
    }

    @Override
    public SubMenu setHeaderView(View view) {
        this.mNativeSubMenu.setHeaderView(view);
        return this;
    }

    @Override
    public SubMenu setIcon(int n2) {
        this.mNativeSubMenu.setIcon(n2);
        return this;
    }

    @Override
    public SubMenu setIcon(Drawable drawable2) {
        this.mNativeSubMenu.setIcon(drawable2);
        return this;
    }
}

