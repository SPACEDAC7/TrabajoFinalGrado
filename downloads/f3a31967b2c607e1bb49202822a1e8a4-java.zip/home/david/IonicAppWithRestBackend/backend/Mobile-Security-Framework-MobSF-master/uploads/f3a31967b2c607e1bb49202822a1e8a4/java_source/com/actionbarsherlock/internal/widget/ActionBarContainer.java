/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.actionbarsherlock.R;
import com.actionbarsherlock.internal.nineoldandroids.widget.NineFrameLayout;
import com.actionbarsherlock.internal.widget.ActionBarView;
import com.actionbarsherlock.internal.widget.IcsColorDrawable;
import com.actionbarsherlock.internal.widget.ScrollingTabContainerView;

public class ActionBarContainer
extends NineFrameLayout {
    private ActionBarView mActionBarView;
    private Drawable mBackground;
    private boolean mIsSplit;
    private boolean mIsStacked;
    private boolean mIsTransitioning;
    private Drawable mSplitBackground;
    private Drawable mStackedBackground;
    private View mTabContainer;

    public ActionBarContainer(Context context) {
        this(context, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.setBackgroundDrawable(null);
        context = context.obtainStyledAttributes(attributeSet, R.styleable.SherlockActionBar);
        this.mBackground = context.getDrawable(2);
        this.mStackedBackground = context.getDrawable(12);
        if (this.mStackedBackground instanceof ColorDrawable && Build.VERSION.SDK_INT < 11) {
            this.mStackedBackground = new IcsColorDrawable((ColorDrawable)this.mStackedBackground);
        }
        if (this.getId() == R.id.abs__split_action_bar) {
            this.mIsSplit = true;
            this.mSplitBackground = context.getDrawable(3);
        }
        context.recycle();
        boolean bl = this.mIsSplit ? this.mSplitBackground == null : this.mBackground == null && this.mStackedBackground == null;
        this.setWillNotDraw(bl);
    }

    public View getTabContainer() {
        return this.mTabContainer;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onDraw(Canvas canvas) {
        if (this.getWidth() == 0 || this.getHeight() == 0) return;
        if (this.mIsSplit) {
            if (this.mSplitBackground == null) return;
            {
                this.mSplitBackground.draw(canvas);
                return;
            }
        }
        if (this.mBackground != null) {
            this.mBackground.draw(canvas);
        }
        if (this.mStackedBackground == null || !this.mIsStacked) {
            return;
        }
        this.mStackedBackground.draw(canvas);
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.mActionBarView = (ActionBarView)this.findViewById(R.id.abs__action_bar);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (!this.mIsTransitioning && !super.onInterceptTouchEvent(motionEvent)) {
            return false;
        }
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void onLayout(boolean var1_1, int var2_2, int var3_3, int var4_4, int var5_5) {
        block8 : {
            var6_6 = 1;
            var9_7 = false;
            super.onLayout(var1_1, var2_2, var3_3, var4_4, var5_5);
            var3_3 = this.mTabContainer != null && this.mTabContainer.getVisibility() != 8 ? 1 : 0;
            if (this.mTabContainer == null || this.mTabContainer.getVisibility() == 8) ** GOTO lbl16
            var5_5 = this.getMeasuredHeight();
            var7_8 = this.mTabContainer.getMeasuredHeight();
            if ((this.mActionBarView.getDisplayOptions() & 2) == 0) ** GOTO lbl11
            this.mTabContainer.layout(var2_2, var5_5 - var7_8, var4_4, var5_5);
            ** GOTO lbl16
lbl11: // 1 sources:
            var8_9 = this.getChildCount();
            var5_5 = 0;
            do {
                if (var5_5 >= var8_9) {
                    this.mTabContainer.layout(var2_2, 0, var4_4, var7_8);
lbl16: // 3 sources:
                    if (!this.mIsSplit) break;
                    if (this.mSplitBackground == null) return;
                    this.mSplitBackground.setBounds(0, 0, this.getMeasuredWidth(), this.getMeasuredHeight());
                    var2_2 = var6_6;
                    break block8;
                }
                var10_10 = this.getChildAt(var5_5);
                if (var10_10 != this.mTabContainer && !this.mActionBarView.isCollapsed()) {
                    var10_10.offsetTopAndBottom(var7_8);
                }
                ++var5_5;
            } while (true);
            if (this.mBackground != null) {
                this.mBackground.setBounds(this.mActionBarView.getLeft(), this.mActionBarView.getTop(), this.mActionBarView.getRight(), this.mActionBarView.getBottom());
                var2_2 = 1;
            } else {
                var2_2 = 0;
            }
            var1_1 = var9_7;
            if (var3_3 != 0) {
                var1_1 = var9_7;
                if (this.mStackedBackground != null) {
                    var1_1 = true;
                }
            }
            this.mIsStacked = var1_1;
            if (var1_1) {
                this.mStackedBackground.setBounds(this.mTabContainer.getLeft(), this.mTabContainer.getTop(), this.mTabContainer.getRight(), this.mTabContainer.getBottom());
                var2_2 = var6_6;
            }
        }
        if (var2_2 == 0) return;
        this.invalidate();
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void onMeasure(int n2, int n3) {
        super.onMeasure(n2, n3);
        if (this.mActionBarView == null) {
            return;
        }
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)this.mActionBarView.getLayoutParams();
        if (this.mActionBarView.isCollapsed()) {
            n2 = 0;
        } else {
            n2 = this.mActionBarView.getMeasuredHeight();
            int n4 = layoutParams.topMargin;
            n2 = layoutParams.bottomMargin + (n2 + n4);
        }
        if (this.mTabContainer == null) return;
        if (this.mTabContainer.getVisibility() == 8) return;
        if (View.MeasureSpec.getMode((int)n3) != Integer.MIN_VALUE) return;
        n3 = View.MeasureSpec.getSize((int)n3);
        this.setMeasuredDimension(this.getMeasuredWidth(), Math.min(n2 + this.mTabContainer.getMeasuredHeight(), n3));
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable2) {
        this.mBackground = drawable2;
        this.invalidate();
    }

    public void setSplitBackground(Drawable drawable2) {
        this.mSplitBackground = drawable2;
        this.invalidate();
    }

    public void setStackedBackground(Drawable drawable2) {
        this.mStackedBackground = drawable2;
        this.invalidate();
    }

    public void setTabContainer(ScrollingTabContainerView scrollingTabContainerView) {
        if (this.mTabContainer != null) {
            this.removeView(this.mTabContainer);
        }
        this.mTabContainer = scrollingTabContainerView;
        if (scrollingTabContainerView != null) {
            this.addView((View)scrollingTabContainerView);
            ViewGroup.LayoutParams layoutParams = scrollingTabContainerView.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            scrollingTabContainerView.setAllowCollapse(false);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setTransitioning(boolean bl) {
        this.mIsTransitioning = bl;
        int n2 = bl ? 393216 : 262144;
        this.setDescendantFocusability(n2);
    }
}

