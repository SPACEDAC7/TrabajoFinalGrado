/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.drawable.Drawable
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 *  android.view.ViewParent
 *  android.view.accessibility.AccessibilityEvent
 *  android.view.animation.DecelerateInterpolator
 *  android.view.animation.Interpolator
 *  android.widget.LinearLayout
 *  android.widget.TextView
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.actionbarsherlock.R;
import com.actionbarsherlock.internal.nineoldandroids.animation.Animator;
import com.actionbarsherlock.internal.nineoldandroids.animation.AnimatorSet;
import com.actionbarsherlock.internal.nineoldandroids.animation.ObjectAnimator;
import com.actionbarsherlock.internal.nineoldandroids.view.animation.AnimatorProxy;
import com.actionbarsherlock.internal.nineoldandroids.widget.NineLinearLayout;
import com.actionbarsherlock.internal.view.menu.ActionMenuPresenter;
import com.actionbarsherlock.internal.view.menu.ActionMenuView;
import com.actionbarsherlock.internal.view.menu.MenuBuilder;
import com.actionbarsherlock.internal.view.menu.MenuPresenter;
import com.actionbarsherlock.internal.view.menu.MenuView;
import com.actionbarsherlock.internal.widget.AbsActionBarView;
import com.actionbarsherlock.internal.widget.ActionBarContainer;
import com.actionbarsherlock.view.ActionMode;
import com.actionbarsherlock.view.Menu;

public class ActionBarContextView
extends AbsActionBarView
implements Animator.AnimatorListener {
    private static final int ANIMATE_IDLE = 0;
    private static final int ANIMATE_IN = 1;
    private static final int ANIMATE_OUT = 2;
    private boolean mAnimateInOnLayout;
    private int mAnimationMode;
    private NineLinearLayout mClose;
    private Animator mCurrentAnimation;
    private View mCustomView;
    private Drawable mSplitBackground;
    private CharSequence mSubtitle;
    private int mSubtitleStyleRes;
    private TextView mSubtitleView;
    private CharSequence mTitle;
    private LinearLayout mTitleLayout;
    private int mTitleStyleRes;
    private TextView mTitleView;

    public ActionBarContextView(Context context) {
        this(context, null);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.actionModeStyle);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        context = context.obtainStyledAttributes(attributeSet, R.styleable.SherlockActionMode, n2, 0);
        this.setBackgroundDrawable(context.getDrawable(2));
        this.mTitleStyleRes = context.getResourceId(0, 0);
        this.mSubtitleStyleRes = context.getResourceId(1, 0);
        this.mContentHeight = context.getLayoutDimension(4, 0);
        this.mSplitBackground = context.getDrawable(3);
        context.recycle();
    }

    private void finishAnimation() {
        Animator animator = this.mCurrentAnimation;
        if (animator != null) {
            this.mCurrentAnimation = null;
            animator.end();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void initTitle() {
        TextView textView;
        int n2;
        block7 : {
            int n3 = 8;
            boolean bl = true;
            if (this.mTitleLayout == null) {
                LayoutInflater.from((Context)this.getContext()).inflate(R.layout.abs__action_bar_title_item, (ViewGroup)this);
                this.mTitleLayout = (LinearLayout)this.getChildAt(this.getChildCount() - 1);
                this.mTitleView = (TextView)this.mTitleLayout.findViewById(R.id.abs__action_bar_title);
                this.mSubtitleView = (TextView)this.mTitleLayout.findViewById(R.id.abs__action_bar_subtitle);
                if (this.mTitleStyleRes != 0) {
                    this.mTitleView.setTextAppearance(this.mContext, this.mTitleStyleRes);
                }
                if (this.mSubtitleStyleRes != 0) {
                    this.mSubtitleView.setTextAppearance(this.mContext, this.mSubtitleStyleRes);
                }
            }
            this.mTitleView.setText(this.mTitle);
            this.mSubtitleView.setText(this.mSubtitle);
            n2 = TextUtils.isEmpty((CharSequence)this.mTitle) ? 0 : 1;
            if (TextUtils.isEmpty((CharSequence)this.mSubtitle)) {
                bl = false;
            }
            textView = this.mSubtitleView;
            int n4 = bl ? 0 : 8;
            textView.setVisibility(n4);
            textView = this.mTitleLayout;
            if (n2 == 0) {
                n2 = n3;
                if (!bl) break block7;
            }
            n2 = 0;
        }
        textView.setVisibility(n2);
        if (this.mTitleLayout.getParent() == null) {
            this.addView((View)this.mTitleLayout);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Animator makeInAnimation() {
        int n2;
        this.mClose.setTranslationX(- this.mClose.getWidth() - ((ViewGroup.MarginLayoutParams)this.mClose.getLayoutParams()).leftMargin);
        Object object = ObjectAnimator.ofFloat((Object)this.mClose, "translationX", 0.0f);
        object.setDuration(200);
        object.addListener(this);
        object.setInterpolator((Interpolator)new DecelerateInterpolator());
        AnimatorSet animatorSet = new AnimatorSet();
        object = animatorSet.play((Animator)object);
        if (this.mMenuView == null || (n2 = this.mMenuView.getChildCount()) <= 0) return animatorSet;
        int n3 = n2 - 1;
        n2 = 0;
        while (n3 >= 0) {
            Object object2 = AnimatorProxy.wrap(this.mMenuView.getChildAt(n3));
            object2.setScaleY(0.0f);
            object2 = ObjectAnimator.ofFloat(object2, "scaleY", 0.0f, 1.0f);
            object2.setDuration(100);
            object2.setStartDelay(n2 * 70);
            object.with((Animator)object2);
            --n3;
            ++n2;
        }
        return animatorSet;
    }

    private Animator makeOutAnimation() {
        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat((Object)this.mClose, "translationX", - this.mClose.getWidth() - ((ViewGroup.MarginLayoutParams)this.mClose.getLayoutParams()).leftMargin);
        objectAnimator.setDuration(200);
        objectAnimator.addListener(this);
        objectAnimator.setInterpolator((Interpolator)new DecelerateInterpolator());
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(objectAnimator);
        if (this.mMenuView != null) {
            this.mMenuView.getChildCount();
        }
        return animatorSet;
    }

    public void closeMode() {
        if (this.mAnimationMode == 2) {
            return;
        }
        if (this.mClose == null) {
            this.killMode();
            return;
        }
        this.finishAnimation();
        this.mAnimationMode = 2;
        this.mCurrentAnimation = this.makeOutAnimation();
        this.mCurrentAnimation.start();
    }

    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(this.getContext(), attributeSet);
    }

    public CharSequence getSubtitle() {
        return this.mSubtitle;
    }

    public CharSequence getTitle() {
        return this.mTitle;
    }

    @Override
    public boolean hideOverflowMenu() {
        if (this.mActionMenuPresenter != null) {
            return this.mActionMenuPresenter.hideOverflowMenu();
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void initForMode(ActionMode object) {
        if (this.mClose == null) {
            this.mClose = (NineLinearLayout)LayoutInflater.from((Context)this.mContext).inflate(R.layout.abs__action_mode_close_item, (ViewGroup)this, false);
            this.addView((View)this.mClose);
        } else if (this.mClose.getParent() == null) {
            this.addView((View)this.mClose);
        }
        this.mClose.findViewById(R.id.abs__action_mode_close_button).setOnClickListener(new View.OnClickListener((ActionMode)object){
            private final /* synthetic */ ActionMode val$mode;

            public void onClick(View view) {
                this.val$mode.finish();
            }
        });
        object = (MenuBuilder)object.getMenu();
        if (this.mActionMenuPresenter != null) {
            this.mActionMenuPresenter.dismissPopupMenus();
        }
        this.mActionMenuPresenter = new ActionMenuPresenter(this.mContext);
        this.mActionMenuPresenter.setReserveOverflow(true);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        if (!this.mSplitActionBar) {
            object.addMenuPresenter(this.mActionMenuPresenter);
            this.mMenuView = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
            this.mMenuView.setBackgroundDrawable(null);
            this.addView((View)this.mMenuView, layoutParams);
        } else {
            this.mActionMenuPresenter.setWidthLimit(this.getContext().getResources().getDisplayMetrics().widthPixels, true);
            this.mActionMenuPresenter.setItemLimit(Integer.MAX_VALUE);
            layoutParams.width = -1;
            layoutParams.height = this.mContentHeight;
            object.addMenuPresenter(this.mActionMenuPresenter);
            this.mMenuView = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
            this.mMenuView.setBackgroundDrawable(this.mSplitBackground);
            this.mSplitView.addView((View)this.mMenuView, layoutParams);
        }
        this.mAnimateInOnLayout = true;
    }

    @Override
    public boolean isOverflowMenuShowing() {
        if (this.mActionMenuPresenter != null) {
            return this.mActionMenuPresenter.isOverflowMenuShowing();
        }
        return false;
    }

    public void killMode() {
        this.finishAnimation();
        this.removeAllViews();
        if (this.mSplitView != null) {
            this.mSplitView.removeView((View)this.mMenuView);
        }
        this.mCustomView = null;
        this.mMenuView = null;
        this.mAnimateInOnLayout = false;
    }

    @Override
    public void onAnimationCancel(Animator animator) {
    }

    @Override
    public void onAnimationEnd(Animator animator) {
        if (this.mAnimationMode == 2) {
            this.killMode();
        }
        this.mAnimationMode = 0;
    }

    @Override
    public void onAnimationRepeat(Animator animator) {
    }

    @Override
    public void onAnimationStart(Animator animator) {
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.mActionMenuPresenter != null) {
            this.mActionMenuPresenter.hideOverflowMenu();
            this.mActionMenuPresenter.hideSubMenus();
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 32) {
            accessibilityEvent.setClassName((CharSequence)this.getClass().getName());
            accessibilityEvent.setPackageName((CharSequence)this.getContext().getPackageName());
            accessibilityEvent.setContentDescription(this.mTitle);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onLayout(boolean bl, int n2, int n3, int n4, int n5) {
        int n6 = this.getPaddingLeft();
        int n7 = this.getPaddingTop();
        int n8 = n5 - n3 - this.getPaddingTop() - this.getPaddingBottom();
        if (this.mClose != null && this.mClose.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.mClose.getLayoutParams();
            n3 = n6 + marginLayoutParams.leftMargin;
            n5 = this.positionChild((View)this.mClose, n3, n7, n8);
            n3 = n5 = marginLayoutParams.rightMargin + (n3 + n5);
            if (this.mAnimateInOnLayout) {
                this.mAnimationMode = 1;
                this.mCurrentAnimation = this.makeInAnimation();
                this.mCurrentAnimation.start();
                this.mAnimateInOnLayout = false;
                n3 = n5;
            }
        } else {
            n3 = n6;
        }
        n5 = n3;
        if (this.mTitleLayout != null) {
            n5 = n3;
            if (this.mCustomView == null) {
                n5 = n3 + this.positionChild((View)this.mTitleLayout, n3, n7, n8);
            }
        }
        if (this.mCustomView != null) {
            this.positionChild(this.mCustomView, n5, n7, n8);
        }
        n3 = this.getPaddingRight();
        if (this.mMenuView != null) {
            this.positionChildInverse((View)this.mMenuView, n4 - n2 - n3, n7, n8);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onMeasure(int n2, int n3) {
        ViewGroup.MarginLayoutParams marginLayoutParams;
        int n4 = 1073741824;
        int n5 = 0;
        if (View.MeasureSpec.getMode((int)n2) != 1073741824) {
            throw new IllegalStateException(String.valueOf(this.getClass().getSimpleName()) + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        }
        if (View.MeasureSpec.getMode((int)n3) == 0) {
            throw new IllegalStateException(String.valueOf(this.getClass().getSimpleName()) + " can only be used with android:layout_height=\"wrap_content\"");
        }
        int n6 = View.MeasureSpec.getSize((int)n2);
        int n7 = this.mContentHeight > 0 ? this.mContentHeight : View.MeasureSpec.getSize((int)n3);
        int n8 = this.getPaddingTop() + this.getPaddingBottom();
        n3 = n6 - this.getPaddingLeft() - this.getPaddingRight();
        int n9 = n7 - n8;
        int n10 = View.MeasureSpec.makeMeasureSpec((int)n9, (int)Integer.MIN_VALUE);
        n2 = n3;
        if (this.mClose != null) {
            n2 = this.measureChildView((View)this.mClose, n3, n10, 0);
            marginLayoutParams = (ViewGroup.MarginLayoutParams)this.mClose.getLayoutParams();
            n3 = marginLayoutParams.leftMargin;
            n2 -= marginLayoutParams.rightMargin + n3;
        }
        n3 = n2;
        if (this.mMenuView != null) {
            n3 = n2;
            if (this.mMenuView.getParent() == this) {
                n3 = this.measureChildView((View)this.mMenuView, n2, n10, 0);
            }
        }
        n2 = n3;
        if (this.mTitleLayout != null) {
            n2 = n3;
            if (this.mCustomView == null) {
                n2 = this.measureChildView((View)this.mTitleLayout, n3, n10, 0);
            }
        }
        if (this.mCustomView != null) {
            marginLayoutParams = this.mCustomView.getLayoutParams();
            n3 = marginLayoutParams.width != -2 ? 1073741824 : Integer.MIN_VALUE;
            n10 = n2;
            if (marginLayoutParams.width >= 0) {
                n10 = Math.min(marginLayoutParams.width, n2);
            }
            n2 = marginLayoutParams.height != -2 ? n4 : Integer.MIN_VALUE;
            n4 = marginLayoutParams.height >= 0 ? Math.min(marginLayoutParams.height, n9) : n9;
            this.mCustomView.measure(View.MeasureSpec.makeMeasureSpec((int)n10, (int)n3), View.MeasureSpec.makeMeasureSpec((int)n4, (int)n2));
        }
        if (this.mContentHeight > 0) {
            this.setMeasuredDimension(n6, n7);
            return;
        }
        n10 = this.getChildCount();
        n2 = 0;
        n3 = n5;
        do {
            if (n3 >= n10) {
                this.setMeasuredDimension(n6, n2);
                return;
            }
            n7 = this.getChildAt(n3).getMeasuredHeight() + n8;
            if (n7 > n2) {
                n2 = n7;
            }
            ++n3;
        } while (true);
    }

    @Override
    public void setContentHeight(int n2) {
        this.mContentHeight = n2;
    }

    public void setCustomView(View view) {
        if (this.mCustomView != null) {
            this.removeView(this.mCustomView);
        }
        this.mCustomView = view;
        if (this.mTitleLayout != null) {
            this.removeView((View)this.mTitleLayout);
            this.mTitleLayout = null;
        }
        if (view != null) {
            this.addView(view);
        }
        this.requestLayout();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setSplitActionBar(boolean bl) {
        if (this.mSplitActionBar != bl) {
            if (this.mActionMenuPresenter != null) {
                ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
                if (!bl) {
                    this.mMenuView = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
                    this.mMenuView.setBackgroundDrawable(null);
                    ViewGroup viewGroup = (ViewGroup)this.mMenuView.getParent();
                    if (viewGroup != null) {
                        viewGroup.removeView((View)this.mMenuView);
                    }
                    this.addView((View)this.mMenuView, layoutParams);
                } else {
                    this.mActionMenuPresenter.setWidthLimit(this.getContext().getResources().getDisplayMetrics().widthPixels, true);
                    this.mActionMenuPresenter.setItemLimit(Integer.MAX_VALUE);
                    layoutParams.width = -1;
                    layoutParams.height = this.mContentHeight;
                    this.mMenuView = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
                    this.mMenuView.setBackgroundDrawable(this.mSplitBackground);
                    ViewGroup viewGroup = (ViewGroup)this.mMenuView.getParent();
                    if (viewGroup != null) {
                        viewGroup.removeView((View)this.mMenuView);
                    }
                    this.mSplitView.addView((View)this.mMenuView, layoutParams);
                }
            }
            super.setSplitActionBar(bl);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        this.mSubtitle = charSequence;
        this.initTitle();
    }

    public void setTitle(CharSequence charSequence) {
        this.mTitle = charSequence;
        this.initTitle();
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override
    public boolean showOverflowMenu() {
        if (this.mActionMenuPresenter != null) {
            return this.mActionMenuPresenter.showOverflowMenu();
        }
        return false;
    }

}

