/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$ConstantState
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  android.view.View$MeasureSpec
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.view.accessibility.AccessibilityEvent
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 */
package com.actionbarsherlock.internal.widget;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.actionbarsherlock.R;
import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.internal.ResourcesCompat;
import com.actionbarsherlock.internal.view.menu.ActionMenuItem;
import com.actionbarsherlock.internal.view.menu.ActionMenuPresenter;
import com.actionbarsherlock.internal.view.menu.ActionMenuView;
import com.actionbarsherlock.internal.view.menu.MenuBuilder;
import com.actionbarsherlock.internal.view.menu.MenuItemImpl;
import com.actionbarsherlock.internal.view.menu.MenuPresenter;
import com.actionbarsherlock.internal.view.menu.MenuView;
import com.actionbarsherlock.internal.view.menu.SubMenuBuilder;
import com.actionbarsherlock.internal.widget.AbsActionBarView;
import com.actionbarsherlock.internal.widget.ActionBarContainer;
import com.actionbarsherlock.internal.widget.ActionBarContextView;
import com.actionbarsherlock.internal.widget.IcsAdapterView;
import com.actionbarsherlock.internal.widget.IcsLinearLayout;
import com.actionbarsherlock.internal.widget.IcsProgressBar;
import com.actionbarsherlock.internal.widget.IcsSpinner;
import com.actionbarsherlock.internal.widget.ScrollingTabContainerView;
import com.actionbarsherlock.view.CollapsibleActionView;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.Window;
import java.util.List;

public class ActionBarView
extends AbsActionBarView {
    private static final int DEFAULT_CUSTOM_GRAVITY = 19;
    public static final int DISPLAY_DEFAULT = 0;
    private static final int DISPLAY_RELAYOUT_MASK = 31;
    private static final String TAG = "ActionBarView";
    private ActionBar.OnNavigationListener mCallback;
    private ActionBarContextView mContextView;
    private View mCustomNavView;
    private int mDisplayOptions = -1;
    View mExpandedActionView;
    private final View.OnClickListener mExpandedActionViewUpListener;
    private HomeView mExpandedHomeLayout;
    private ExpandedActionViewMenuPresenter mExpandedMenuPresenter;
    private HomeView mHomeLayout;
    private Drawable mIcon;
    private boolean mIncludeTabs;
    private int mIndeterminateProgressStyle;
    private IcsProgressBar mIndeterminateProgressView;
    private boolean mIsCollapsable;
    private boolean mIsCollapsed;
    private int mItemPadding;
    private IcsLinearLayout mListNavLayout;
    private Drawable mLogo;
    private ActionMenuItem mLogoNavItem;
    private final IcsAdapterView.OnItemSelectedListener mNavItemSelectedListener;
    private int mNavigationMode;
    private MenuBuilder mOptionsMenu;
    private int mProgressBarPadding;
    private int mProgressStyle;
    private IcsProgressBar mProgressView;
    private IcsSpinner mSpinner;
    private SpinnerAdapter mSpinnerAdapter;
    private CharSequence mSubtitle;
    private int mSubtitleStyleRes;
    private TextView mSubtitleView;
    private ScrollingTabContainerView mTabScrollView;
    private CharSequence mTitle;
    private LinearLayout mTitleLayout;
    private int mTitleStyleRes;
    private View mTitleUpView;
    private TextView mTitleView;
    private final View.OnClickListener mUpClickListener;
    private boolean mUserTitle;
    Window.Callback mWindowCallback;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public ActionBarView(Context context, AttributeSet attributeSet) {
        int n2;
        super(context, attributeSet);
        this.mNavItemSelectedListener = new IcsAdapterView.OnItemSelectedListener(){

            public void onItemSelected(IcsAdapterView icsAdapterView, View view, int n2, long l2) {
                if (ActionBarView.this.mCallback != null) {
                    ActionBarView.this.mCallback.onNavigationItemSelected(n2, l2);
                }
            }

            public void onNothingSelected(IcsAdapterView icsAdapterView) {
            }
        };
        this.mExpandedActionViewUpListener = new View.OnClickListener(){

            public void onClick(View object) {
                object = ActionBarView.access$1((ActionBarView)ActionBarView.this).mCurrentExpandedItem;
                if (object != null) {
                    object.collapseActionView();
                }
            }
        };
        this.mUpClickListener = new View.OnClickListener(){

            public void onClick(View view) {
                ActionBarView.this.mWindowCallback.onMenuItemSelected(0, ActionBarView.this.mLogoNavItem);
            }
        };
        this.setBackgroundResource(0);
        attributeSet = context.obtainStyledAttributes(attributeSet, R.styleable.SherlockActionBar, R.attr.actionBarStyle, 0);
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        PackageManager packageManager = context.getPackageManager();
        this.mNavigationMode = attributeSet.getInt(6, 0);
        this.mTitle = attributeSet.getText(8);
        this.mSubtitle = attributeSet.getText(9);
        this.mLogo = attributeSet.getDrawable(11);
        if (this.mLogo == null) {
            if (Build.VERSION.SDK_INT < 11) {
                if (context instanceof Activity && (n2 = ResourcesCompat.loadLogoFromManifest((Activity)context)) != 0) {
                    this.mLogo = context.getResources().getDrawable(n2);
                }
            } else {
                if (context instanceof Activity) {
                    try {
                        this.mLogo = packageManager.getActivityLogo(((Activity)context).getComponentName());
                    }
                    catch (PackageManager.NameNotFoundException var6_6) {
                        Log.e((String)"ActionBarView", (String)"Activity component name not found!", (Throwable)var6_6);
                    }
                }
                if (this.mLogo == null) {
                    this.mLogo = applicationInfo.loadLogo(packageManager);
                }
            }
        }
        this.mIcon = attributeSet.getDrawable(10);
        if (this.mIcon == null) {
            if (context instanceof Activity) {
                try {
                    this.mIcon = packageManager.getActivityIcon(((Activity)context).getComponentName());
                }
                catch (PackageManager.NameNotFoundException var6_7) {
                    Log.e((String)"ActionBarView", (String)"Activity component name not found!", (Throwable)var6_7);
                }
            }
            if (this.mIcon == null) {
                this.mIcon = applicationInfo.loadIcon(packageManager);
            }
        }
        applicationInfo = LayoutInflater.from((Context)context);
        n2 = attributeSet.getResourceId(14, R.layout.abs__action_bar_home);
        this.mHomeLayout = (HomeView)applicationInfo.inflate(n2, (ViewGroup)this, false);
        this.mExpandedHomeLayout = (HomeView)applicationInfo.inflate(n2, (ViewGroup)this, false);
        this.mExpandedHomeLayout.setUp(true);
        this.mExpandedHomeLayout.setOnClickListener(this.mExpandedActionViewUpListener);
        this.mExpandedHomeLayout.setContentDescription(this.getResources().getText(R.string.abs__action_bar_up_description));
        this.mTitleStyleRes = attributeSet.getResourceId(0, 0);
        this.mSubtitleStyleRes = attributeSet.getResourceId(1, 0);
        this.mProgressStyle = attributeSet.getResourceId(15, 0);
        this.mIndeterminateProgressStyle = attributeSet.getResourceId(16, 0);
        this.mProgressBarPadding = attributeSet.getDimensionPixelOffset(17, 0);
        this.mItemPadding = attributeSet.getDimensionPixelOffset(18, 0);
        this.setDisplayOptions(attributeSet.getInt(7, 0));
        n2 = attributeSet.getResourceId(13, 0);
        if (n2 != 0) {
            this.mCustomNavView = applicationInfo.inflate(n2, (ViewGroup)this, false);
            this.mNavigationMode = 0;
            this.setDisplayOptions(this.mDisplayOptions | 16);
        }
        this.mContentHeight = attributeSet.getLayoutDimension(4, 0);
        attributeSet.recycle();
        this.mLogoNavItem = new ActionMenuItem(context, 0, 16908332, 0, 0, this.mTitle);
        this.mHomeLayout.setOnClickListener(this.mUpClickListener);
        this.mHomeLayout.setClickable(true);
        this.mHomeLayout.setFocusable(true);
    }

    static /* synthetic */ ExpandedActionViewMenuPresenter access$1(ActionBarView actionBarView) {
        return actionBarView.mExpandedMenuPresenter;
    }

    private void configPresenters(MenuBuilder menuBuilder) {
        if (menuBuilder != null) {
            menuBuilder.addMenuPresenter(this.mActionMenuPresenter);
            menuBuilder.addMenuPresenter(this.mExpandedMenuPresenter);
            return;
        }
        this.mActionMenuPresenter.initForMenu(this.mContext, null);
        this.mExpandedMenuPresenter.initForMenu(this.mContext, null);
        this.mActionMenuPresenter.updateMenuView(true);
        this.mExpandedMenuPresenter.updateMenuView(true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void initTitle() {
        boolean bl = true;
        if (this.mTitleLayout == null) {
            this.mTitleLayout = (LinearLayout)LayoutInflater.from((Context)this.getContext()).inflate(R.layout.abs__action_bar_title_item, (ViewGroup)this, false);
            this.mTitleView = (TextView)this.mTitleLayout.findViewById(R.id.abs__action_bar_title);
            this.mSubtitleView = (TextView)this.mTitleLayout.findViewById(R.id.abs__action_bar_subtitle);
            this.mTitleUpView = this.mTitleLayout.findViewById(R.id.abs__up);
            this.mTitleLayout.setOnClickListener(this.mUpClickListener);
            if (this.mTitleStyleRes != 0) {
                this.mTitleView.setTextAppearance(this.mContext, this.mTitleStyleRes);
            }
            if (this.mTitle != null) {
                this.mTitleView.setText(this.mTitle);
            }
            if (this.mSubtitleStyleRes != 0) {
                this.mSubtitleView.setTextAppearance(this.mContext, this.mSubtitleStyleRes);
            }
            if (this.mSubtitle != null) {
                this.mSubtitleView.setText(this.mSubtitle);
                this.mSubtitleView.setVisibility(0);
            }
            boolean bl2 = (this.mDisplayOptions & 4) != 0;
            boolean bl3 = (this.mDisplayOptions & 2) != 0;
            View view = this.mTitleUpView;
            int n2 = !bl3 ? (bl2 ? 0 : 4) : 8;
            view.setVisibility(n2);
            view = this.mTitleLayout;
            if (!bl2 || bl3) {
                bl = false;
            }
            view.setEnabled(bl);
        }
        this.addView((View)this.mTitleLayout);
        if (this.mExpandedActionView != null || TextUtils.isEmpty((CharSequence)this.mTitle) && TextUtils.isEmpty((CharSequence)this.mSubtitle)) {
            this.mTitleLayout.setVisibility(8);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void setTitleImpl(CharSequence charSequence) {
        int n2 = 0;
        this.mTitle = charSequence;
        if (this.mTitleView != null) {
            this.mTitleView.setText(charSequence);
            int n3 = this.mExpandedActionView == null && (this.mDisplayOptions & 8) != 0 && (!TextUtils.isEmpty((CharSequence)this.mTitle) || !TextUtils.isEmpty((CharSequence)this.mSubtitle)) ? 1 : 0;
            LinearLayout linearLayout = this.mTitleLayout;
            n3 = n3 != 0 ? n2 : 8;
            linearLayout.setVisibility(n3);
        }
        if (this.mLogoNavItem != null) {
            this.mLogoNavItem.setTitle(charSequence);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void collapseActionView() {
        if (this.mExpandedMenuPresenter == null) {
            return;
        }
        MenuItemImpl menuItemImpl = this.mExpandedMenuPresenter.mCurrentExpandedItem;
        if (menuItemImpl != null) {
            menuItemImpl.collapseActionView();
        }
    }

    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ActionBar.LayoutParams(19);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ActionBar.LayoutParams(this.getContext(), attributeSet);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        ViewGroup.LayoutParams layoutParams2 = layoutParams;
        if (layoutParams == null) {
            layoutParams2 = this.generateDefaultLayoutParams();
        }
        return layoutParams2;
    }

    public View getCustomNavigationView() {
        return this.mCustomNavView;
    }

    public int getDisplayOptions() {
        return this.mDisplayOptions;
    }

    public SpinnerAdapter getDropdownAdapter() {
        return this.mSpinnerAdapter;
    }

    public int getDropdownSelectedPosition() {
        return this.mSpinner.getSelectedItemPosition();
    }

    public int getNavigationMode() {
        return this.mNavigationMode;
    }

    public CharSequence getSubtitle() {
        return this.mSubtitle;
    }

    public CharSequence getTitle() {
        return this.mTitle;
    }

    public boolean hasEmbeddedTabs() {
        return this.mIncludeTabs;
    }

    public boolean hasExpandedActionView() {
        if (this.mExpandedMenuPresenter != null && this.mExpandedMenuPresenter.mCurrentExpandedItem != null) {
            return true;
        }
        return false;
    }

    public void initIndeterminateProgress() {
        this.mIndeterminateProgressView = new IcsProgressBar(this.mContext, null, 0, this.mIndeterminateProgressStyle);
        this.mIndeterminateProgressView.setId(R.id.abs__progress_circular);
        this.addView((View)this.mIndeterminateProgressView);
    }

    public void initProgress() {
        this.mProgressView = new IcsProgressBar(this.mContext, null, 0, this.mProgressStyle);
        this.mProgressView.setId(R.id.abs__progress_horizontal);
        this.mProgressView.setMax(10000);
        this.addView((View)this.mProgressView);
    }

    public boolean isCollapsed() {
        return this.mIsCollapsed;
    }

    public boolean isSplitActionBar() {
        return this.mSplitActionBar;
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.mTitleView = null;
        this.mSubtitleView = null;
        this.mTitleUpView = null;
        if (this.mTitleLayout != null && this.mTitleLayout.getParent() == this) {
            this.removeView((View)this.mTitleLayout);
        }
        this.mTitleLayout = null;
        if ((this.mDisplayOptions & 8) != 0) {
            this.initTitle();
        }
        if (this.mTabScrollView != null && this.mIncludeTabs) {
            configuration = this.mTabScrollView.getLayoutParams();
            if (configuration != null) {
                configuration.width = -2;
                configuration.height = -1;
            }
            this.mTabScrollView.setAllowCollapse(true);
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.mActionMenuPresenter != null) {
            this.mActionMenuPresenter.hideOverflowMenu();
            this.mActionMenuPresenter.hideSubMenus();
        }
    }

    protected void onFinishInflate() {
        ViewParent viewParent;
        super.onFinishInflate();
        this.addView((View)this.mHomeLayout);
        if (this.mCustomNavView != null && (this.mDisplayOptions & 16) != 0 && (viewParent = this.mCustomNavView.getParent()) != this) {
            if (viewParent instanceof ViewGroup) {
                ((ViewGroup)viewParent).removeView(this.mCustomNavView);
            }
            this.addView(this.mCustomNavView);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void onLayout(boolean var1_1, int var2_2, int var3_3, int var4_4, int var5_5) {
        var6_6 = this.getPaddingLeft();
        var8_7 = this.getPaddingTop();
        var9_8 = var5_5 - var3_3 - this.getPaddingTop() - this.getPaddingBottom();
        if (var9_8 <= 0) {
            return;
        }
        var11_9 = this.mExpandedActionView != null ? this.mExpandedHomeLayout : this.mHomeLayout;
        if (var11_9.getVisibility() != 8) {
            var3_3 = var11_9.getLeftOffset();
            var5_5 = this.positionChild((View)var11_9, var6_6 + var3_3, var8_7, var9_8) + var3_3 + var6_6;
        } else {
            var5_5 = var6_6;
        }
        var6_6 = var5_5;
        if (this.mExpandedActionView != null) ** GOTO lbl40
        var7_10 = this.mTitleLayout != null && this.mTitleLayout.getVisibility() != 8 && (this.mDisplayOptions & 8) != 0 ? 1 : 0;
        var3_3 = var5_5;
        if (var7_10 != 0) {
            var3_3 = var5_5 + this.positionChild((View)this.mTitleLayout, var5_5, var8_7, var9_8);
        }
        switch (this.mNavigationMode) {
            default: {
                var6_6 = var3_3;
                break;
            }
            case 0: {
                ** GOTO lbl41
            }
            case 1: {
                var6_6 = var3_3;
                if (this.mListNavLayout == null) break;
                var5_5 = var3_3;
                if (var7_10 != 0) {
                    var5_5 = var3_3 + this.mItemPadding;
                }
                var3_3 = var5_5 + (this.positionChild((View)this.mListNavLayout, var5_5, var8_7, var9_8) + this.mItemPadding);
                ** GOTO lbl41
            }
            case 2: {
                var6_6 = var3_3;
                if (this.mTabScrollView == null) break;
                var5_5 = var3_3;
                if (var7_10 != 0) {
                    var5_5 = var3_3 + this.mItemPadding;
                }
                var3_3 = var5_5 + (this.positionChild((View)this.mTabScrollView, var5_5, var8_7, var9_8) + this.mItemPadding);
                ** GOTO lbl41
            }
        }
lbl40: // 4 sources:
        var3_3 = var6_6;
lbl41: // 4 sources:
        var2_2 = var4_4 = var4_4 - var2_2 - this.getPaddingRight();
        if (this.mMenuView != null) {
            var2_2 = var4_4;
            if (this.mMenuView.getParent() == this) {
                this.positionChildInverse((View)this.mMenuView, var4_4, var8_7, var9_8);
                var2_2 = var4_4 - this.mMenuView.getMeasuredWidth();
            }
        }
        if (this.mIndeterminateProgressView != null && this.mIndeterminateProgressView.getVisibility() != 8) {
            this.positionChildInverse(this.mIndeterminateProgressView, var2_2, var8_7, var9_8);
            var2_2 -= this.mIndeterminateProgressView.getMeasuredWidth();
        }
        var11_9 = this.mExpandedActionView != null ? this.mExpandedActionView : ((this.mDisplayOptions & 16) != 0 && this.mCustomNavView != null ? this.mCustomNavView : null);
        if (var11_9 != null) {
            var12_11 = var11_9.getLayoutParams();
            var12_11 = var12_11 instanceof ActionBar.LayoutParams != false ? (ActionBar.LayoutParams)var12_11 : null;
            var5_5 = var12_11 != null ? var12_11.gravity : 19;
            var10_12 = var11_9.getMeasuredWidth();
            if (var12_11 != null) {
                var4_4 = var12_11.leftMargin;
                var8_7 = var12_11.rightMargin;
                var7_10 = var12_11.topMargin;
                var6_6 = var12_11.bottomMargin;
                var8_7 = var2_2 - var8_7;
                var4_4 = var3_3 + var4_4;
            } else {
                var7_10 = 0;
                var6_6 = 0;
                var4_4 = var3_3;
                var8_7 = var2_2;
            }
            if ((var3_3 = var5_5 & 7) == 1) {
                var2_2 = (this.getRight() - this.getLeft() - var10_12) / 2;
                if (var2_2 < var4_4) {
                    var3_3 = 3;
                } else if (var2_2 + var10_12 > var8_7) {
                    var3_3 = 5;
                }
            } else if (var5_5 == -1) {
                var3_3 = 3;
            }
            var2_2 = var9_8 = 0;
            switch (var3_3) {
                default: {
                    var2_2 = var9_8;
                    break;
                }
                case 1: {
                    var2_2 = (this.getRight() - this.getLeft() - var10_12) / 2;
                    break;
                }
                case 3: {
                    var2_2 = var4_4;
                }
                case 2: 
                case 4: {
                    break;
                }
                case 5: {
                    var2_2 = var8_7 - var10_12;
                }
            }
            var3_3 = var5_5 & 112;
            if (var5_5 == -1) {
                var3_3 = 16;
            }
            var4_4 = 0;
            switch (var3_3) {
                default: {
                    var3_3 = var4_4;
                    break;
                }
                case 16: {
                    var3_3 = this.getPaddingTop();
                    var3_3 = (this.getBottom() - this.getTop() - this.getPaddingBottom() - var3_3 - var11_9.getMeasuredHeight()) / 2;
                    break;
                }
                case 48: {
                    var3_3 = this.getPaddingTop() + var7_10;
                    break;
                }
                case 80: {
                    var3_3 = this.getHeight() - this.getPaddingBottom() - var11_9.getMeasuredHeight() - var6_6;
                }
            }
            var11_9.layout(var2_2, var3_3, var11_9.getMeasuredWidth() + var2_2, var11_9.getMeasuredHeight() + var3_3);
        }
        if (this.mProgressView == null) return;
        this.mProgressView.bringToFront();
        var2_2 = this.mProgressView.getMeasuredHeight() / 2;
        this.mProgressView.layout(this.mProgressBarPadding, - var2_2, this.mProgressBarPadding + this.mProgressView.getMeasuredWidth(), var2_2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void onMeasure(int var1_1, int var2_2) {
        var11_3 = this.getChildCount();
        if (!this.mIsCollapsable) ** GOTO lbl21
        var4_4 = 0;
        var3_5 = 0;
        do {
            if (var3_5 >= var11_3) {
                if (var4_4 != 0) break;
                this.setMeasuredDimension(0, 0);
                this.mIsCollapsed = true;
                return;
            }
            var15_7 = this.getChildAt(var3_5);
            var5_6 = var4_4;
            if (var15_7.getVisibility() == 8) ** GOTO lbl18
            if (var15_7 != this.mMenuView) ** GOTO lbl-1000
            var5_6 = var4_4;
            if (this.mMenuView.getChildCount() != 0) lbl-1000: // 2 sources:
            {
                var5_6 = var4_4 + 1;
            }
lbl18: // 4 sources:
            ++var3_5;
            var4_4 = var5_6;
        } while (true);
lbl21: // 2 sources:
        this.mIsCollapsed = false;
        if (View.MeasureSpec.getMode((int)var1_1) != 1073741824) {
            throw new IllegalStateException(String.valueOf(this.getClass().getSimpleName()) + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        }
        if (View.MeasureSpec.getMode((int)var2_2) != Integer.MIN_VALUE) {
            throw new IllegalStateException(String.valueOf(this.getClass().getSimpleName()) + " can only be used with android:layout_height=\"wrap_content\"");
        }
        var12_8 = View.MeasureSpec.getSize((int)var1_1);
        var5_6 = this.mContentHeight > 0 ? this.mContentHeight : View.MeasureSpec.getSize((int)var2_2);
        var13_9 = this.getPaddingTop() + this.getPaddingBottom();
        var1_1 = this.getPaddingLeft();
        var2_2 = this.getPaddingRight();
        var10_10 = var5_6 - var13_9;
        var7_11 = View.MeasureSpec.makeMeasureSpec((int)var10_10, (int)Integer.MIN_VALUE);
        var2_2 = var12_8 - var1_1 - var2_2;
        var6_12 = var2_2 / 2;
        var15_7 = this.mExpandedActionView != null ? this.mExpandedHomeLayout : this.mHomeLayout;
        if (var15_7.getVisibility() != 8) {
            var16_13 = var15_7.getLayoutParams();
            var1_1 = var16_13.width < 0 ? View.MeasureSpec.makeMeasureSpec((int)var2_2, (int)Integer.MIN_VALUE) : View.MeasureSpec.makeMeasureSpec((int)var16_13.width, (int)1073741824);
            var15_7.measure(var1_1, View.MeasureSpec.makeMeasureSpec((int)var10_10, (int)1073741824));
            var1_1 = var15_7.getMeasuredWidth();
            var1_1 = var15_7.getLeftOffset() + var1_1;
            var2_2 = Math.max(0, var2_2 - var1_1);
            var1_1 = Math.max(0, var2_2 - var1_1);
        } else {
            var1_1 = var6_12;
        }
        var4_4 = var2_2;
        var3_5 = var6_12;
        if (this.mMenuView != null) {
            var4_4 = var2_2;
            var3_5 = var6_12;
            if (this.mMenuView.getParent() == this) {
                var4_4 = this.measureChildView((View)this.mMenuView, var2_2, var7_11, 0);
                var3_5 = Math.max(0, var6_12 - this.mMenuView.getMeasuredWidth());
            }
        }
        var2_2 = var4_4;
        var6_12 = var3_5;
        if (this.mIndeterminateProgressView != null) {
            var2_2 = var4_4;
            var6_12 = var3_5;
            if (this.mIndeterminateProgressView.getVisibility() != 8) {
                var2_2 = this.measureChildView(this.mIndeterminateProgressView, var4_4, var7_11, 0);
                var6_12 = Math.max(0, var3_5 - this.mIndeterminateProgressView.getMeasuredWidth());
            }
        }
        var3_5 = this.mTitleLayout != null && this.mTitleLayout.getVisibility() != 8 && (this.mDisplayOptions & 8) != 0 ? 1 : 0;
        if (this.mExpandedActionView != null) ** GOTO lbl78
        switch (this.mNavigationMode) {
            case 1: {
                if (this.mListNavLayout == null) break;
                var4_4 = var3_5 != 0 ? this.mItemPadding << 1 : this.mItemPadding;
                var2_2 = Math.max(0, var2_2 - var4_4);
                var4_4 = Math.max(0, var1_1 - var4_4);
                this.mListNavLayout.measure(View.MeasureSpec.makeMeasureSpec((int)var2_2, (int)Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec((int)var10_10, (int)1073741824));
                var7_11 = this.mListNavLayout.getMeasuredWidth();
                var1_1 = Math.max(0, var2_2 - var7_11);
                var2_2 = Math.max(0, var4_4 - var7_11);
                ** GOTO lbl88
            }
            case 2: {
                if (this.mTabScrollView == null) break;
                var4_4 = var3_5 != 0 ? this.mItemPadding << 1 : this.mItemPadding;
            }
        }
lbl78: // 4 sources:
        var4_4 = var1_1;
        var1_1 = var2_2;
        var2_2 = var4_4;
        ** GOTO lbl88
        var2_2 = Math.max(0, var2_2 - var4_4);
        var4_4 = Math.max(0, var1_1 - var4_4);
        this.mTabScrollView.measure(View.MeasureSpec.makeMeasureSpec((int)var2_2, (int)Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec((int)var10_10, (int)1073741824));
        var7_11 = this.mTabScrollView.getMeasuredWidth();
        var1_1 = Math.max(0, var2_2 - var7_11);
        var2_2 = Math.max(0, var4_4 - var7_11);
lbl88: // 3 sources:
        var15_7 = this.mExpandedActionView != null ? this.mExpandedActionView : ((this.mDisplayOptions & 16) != 0 && this.mCustomNavView != null ? this.mCustomNavView : null);
        var4_4 = var1_1;
        if (var15_7 != null) {
            var17_14 = this.generateLayoutParams(var15_7.getLayoutParams());
            var16_13 = var17_14 instanceof ActionBar.LayoutParams != false ? (ActionBar.LayoutParams)var17_14 : null;
            var4_4 = 0;
            var8_15 = 0;
            if (var16_13 != null) {
                var4_4 = var16_13.leftMargin;
                var4_4 = var16_13.rightMargin + var4_4;
                var8_15 = var16_13.topMargin + var16_13.bottomMargin;
            }
            var7_11 = this.mContentHeight > 0 && var17_14.height != -2 ? 1073741824 : Integer.MIN_VALUE;
            var9_16 = var10_10;
            if (var17_14.height >= 0) {
                var9_16 = Math.min(var17_14.height, var10_10);
            }
            var14_17 = Math.max(0, var9_16 - var8_15);
            var8_15 = var17_14.width != -2 ? 1073741824 : Integer.MIN_VALUE;
            var9_16 = var17_14.width >= 0 ? Math.min(var17_14.width, var1_1) : var1_1;
            var10_10 = Math.max(0, var9_16 - var4_4);
            var9_16 = var16_13 != null ? var16_13.gravity : 19;
            var6_12 = (var9_16 & 7) == 1 && var17_14.width == -1 ? Math.min(var2_2, var6_12) << 1 : var10_10;
            var15_7.measure(View.MeasureSpec.makeMeasureSpec((int)var6_12, (int)var8_15), View.MeasureSpec.makeMeasureSpec((int)var14_17, (int)var7_11));
            var4_4 = var1_1 - (var15_7.getMeasuredWidth() + var4_4);
        }
        if (this.mExpandedActionView == null && var3_5 != 0) {
            this.measureChildView((View)this.mTitleLayout, var4_4, View.MeasureSpec.makeMeasureSpec((int)this.mContentHeight, (int)1073741824), 0);
            Math.max(0, var2_2 - this.mTitleLayout.getMeasuredWidth());
        }
        if (this.mContentHeight <= 0) ** GOTO lbl117
        this.setMeasuredDimension(var12_8, var5_6);
        ** GOTO lbl122
lbl117: // 1 sources:
        var1_1 = 0;
        var2_2 = 0;
        do {
            if (var2_2 >= var11_3) {
                this.setMeasuredDimension(var12_8, var1_1);
lbl122: // 2 sources:
                if (this.mContextView != null) {
                    this.mContextView.setContentHeight(this.getMeasuredHeight());
                }
                if (this.mProgressView == null) return;
                if (this.mProgressView.getVisibility() == 8) return;
                this.mProgressView.measure(View.MeasureSpec.makeMeasureSpec((int)(var12_8 - (this.mProgressBarPadding << 1)), (int)1073741824), View.MeasureSpec.makeMeasureSpec((int)this.getMeasuredHeight(), (int)Integer.MIN_VALUE));
                return;
            }
            var3_5 = this.getChildAt(var2_2).getMeasuredHeight() + var13_9;
            if (var3_5 > var1_1) {
                var1_1 = var3_5;
            }
            ++var2_2;
        } while (true);
    }

    public void onRestoreInstanceState(Parcelable object) {
        MenuItem menuItem;
        object = (SavedState)((Object)object);
        super.onRestoreInstanceState(object.getSuperState());
        if (object.expandedMenuItemId != 0 && this.mExpandedMenuPresenter != null && this.mOptionsMenu != null && (menuItem = this.mOptionsMenu.findItem(object.expandedMenuItemId)) != null) {
            menuItem.expandActionView();
        }
        if (object.isOverflowOpen) {
            this.postShowOverflowMenu();
        }
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        if (this.mExpandedMenuPresenter != null && this.mExpandedMenuPresenter.mCurrentExpandedItem != null) {
            savedState.expandedMenuItemId = this.mExpandedMenuPresenter.mCurrentExpandedItem.getItemId();
        }
        savedState.isOverflowOpen = this.isOverflowMenuShowing();
        return savedState;
    }

    public void setCallback(ActionBar.OnNavigationListener onNavigationListener) {
        this.mCallback = onNavigationListener;
    }

    public void setCollapsable(boolean bl) {
        this.mIsCollapsable = bl;
    }

    public void setContextView(ActionBarContextView actionBarContextView) {
        this.mContextView = actionBarContextView;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setCustomNavigationView(View view) {
        boolean bl = (this.mDisplayOptions & 16) != 0;
        if (this.mCustomNavView != null && bl) {
            this.removeView(this.mCustomNavView);
        }
        this.mCustomNavView = view;
        if (this.mCustomNavView != null && bl) {
            this.addView(this.mCustomNavView);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setDisplayOptions(int n2) {
        int n3 = 8;
        int n4 = -1;
        boolean bl = true;
        if (this.mDisplayOptions != -1) {
            n4 = this.mDisplayOptions ^ n2;
        }
        this.mDisplayOptions = n2;
        if ((n4 & 31) != 0) {
            boolean bl2;
            Drawable drawable2;
            boolean bl3 = (n2 & 2) != 0;
            int n5 = bl3 && this.mExpandedActionView == null ? 0 : 8;
            this.mHomeLayout.setVisibility(n5);
            if ((n4 & 4) != 0) {
                bl2 = (n2 & 4) != 0;
                this.mHomeLayout.setUp(bl2);
                if (bl2) {
                    this.setHomeButtonEnabled(true);
                }
            }
            if ((n4 & 1) != 0) {
                n5 = this.mLogo != null && (n2 & 1) != 0 ? 1 : 0;
                HomeView homeView = this.mHomeLayout;
                drawable2 = n5 != 0 ? this.mLogo : this.mIcon;
                homeView.setIcon(drawable2);
            }
            if ((n4 & 8) != 0) {
                if ((n2 & 8) != 0) {
                    this.initTitle();
                } else {
                    this.removeView((View)this.mTitleLayout);
                }
            }
            if (this.mTitleLayout != null && (n4 & 6) != 0) {
                boolean bl4 = (this.mDisplayOptions & 4) != 0;
                drawable2 = this.mTitleUpView;
                n5 = n3;
                if (!bl3) {
                    n5 = bl4 ? 0 : 4;
                }
                drawable2.setVisibility(n5);
                drawable2 = this.mTitleLayout;
                bl2 = !bl3 && bl4 ? bl : false;
                drawable2.setEnabled(bl2);
            }
            if ((n4 & 16) != 0 && this.mCustomNavView != null) {
                if ((n2 & 16) != 0) {
                    this.addView(this.mCustomNavView);
                } else {
                    this.removeView(this.mCustomNavView);
                }
            }
            this.requestLayout();
        } else {
            this.invalidate();
        }
        if (!this.mHomeLayout.isEnabled()) {
            this.mHomeLayout.setContentDescription(null);
            return;
        }
        if ((n2 & 4) != 0) {
            this.mHomeLayout.setContentDescription(this.mContext.getResources().getText(R.string.abs__action_bar_up_description));
            return;
        }
        this.mHomeLayout.setContentDescription(this.mContext.getResources().getText(R.string.abs__action_bar_home_description));
    }

    public void setDropdownAdapter(SpinnerAdapter spinnerAdapter) {
        this.mSpinnerAdapter = spinnerAdapter;
        if (this.mSpinner != null) {
            this.mSpinner.setAdapter(spinnerAdapter);
        }
    }

    public void setDropdownSelectedPosition(int n2) {
        this.mSpinner.setSelection(n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setEmbeddedTabView(ScrollingTabContainerView scrollingTabContainerView) {
        if (this.mTabScrollView != null) {
            this.removeView((View)this.mTabScrollView);
        }
        this.mTabScrollView = scrollingTabContainerView;
        boolean bl = scrollingTabContainerView != null;
        this.mIncludeTabs = bl;
        if (this.mIncludeTabs && this.mNavigationMode == 2) {
            this.addView((View)this.mTabScrollView);
            ViewGroup.LayoutParams layoutParams = this.mTabScrollView.getLayoutParams();
            layoutParams.width = -2;
            layoutParams.height = -1;
            scrollingTabContainerView.setAllowCollapse(true);
        }
    }

    public void setHomeButtonEnabled(boolean bl) {
        this.mHomeLayout.setEnabled(bl);
        this.mHomeLayout.setFocusable(bl);
        if (!bl) {
            this.mHomeLayout.setContentDescription(null);
            return;
        }
        if ((this.mDisplayOptions & 4) != 0) {
            this.mHomeLayout.setContentDescription(this.mContext.getResources().getText(R.string.abs__action_bar_up_description));
            return;
        }
        this.mHomeLayout.setContentDescription(this.mContext.getResources().getText(R.string.abs__action_bar_home_description));
    }

    public void setIcon(int n2) {
        this.setIcon(this.mContext.getResources().getDrawable(n2));
    }

    public void setIcon(Drawable drawable2) {
        this.mIcon = drawable2;
        if (drawable2 != null && ((this.mDisplayOptions & 1) == 0 || this.mLogo == null)) {
            this.mHomeLayout.setIcon(drawable2);
        }
    }

    public void setLogo(int n2) {
        this.setLogo(this.mContext.getResources().getDrawable(n2));
    }

    public void setLogo(Drawable drawable2) {
        this.mLogo = drawable2;
        if (drawable2 != null && (this.mDisplayOptions & 1) != 0) {
            this.mHomeLayout.setIcon(drawable2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setMenu(Menu object, MenuPresenter.Callback callback) {
        ViewGroup viewGroup;
        if (object == this.mOptionsMenu) {
            return;
        }
        if (this.mOptionsMenu != null) {
            this.mOptionsMenu.removeMenuPresenter(this.mActionMenuPresenter);
            this.mOptionsMenu.removeMenuPresenter(this.mExpandedMenuPresenter);
        }
        this.mOptionsMenu = object = (MenuBuilder)object;
        if (this.mMenuView != null && (viewGroup = (ViewGroup)this.mMenuView.getParent()) != null) {
            viewGroup.removeView((View)this.mMenuView);
        }
        if (this.mActionMenuPresenter == null) {
            this.mActionMenuPresenter = new ActionMenuPresenter(this.mContext);
            this.mActionMenuPresenter.setCallback(callback);
            this.mActionMenuPresenter.setId(R.id.abs__action_menu_presenter);
            this.mExpandedMenuPresenter = new ExpandedActionViewMenuPresenter();
        }
        callback = new ViewGroup.LayoutParams(-2, -1);
        if (!this.mSplitActionBar) {
            this.mActionMenuPresenter.setExpandedActionViewsExclusive(ResourcesCompat.getResources_getBoolean(this.getContext(), R.bool.abs__action_bar_expanded_action_views_exclusive));
            this.configPresenters((MenuBuilder)object);
            object = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
            viewGroup = (ViewGroup)object.getParent();
            if (viewGroup != null && viewGroup != this) {
                viewGroup.removeView((View)object);
            }
            this.addView((View)object, (ViewGroup.LayoutParams)callback);
        } else {
            this.mActionMenuPresenter.setExpandedActionViewsExclusive(false);
            this.mActionMenuPresenter.setWidthLimit(this.getContext().getResources().getDisplayMetrics().widthPixels, true);
            this.mActionMenuPresenter.setItemLimit(Integer.MAX_VALUE);
            callback.width = -1;
            this.configPresenters((MenuBuilder)object);
            object = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
            if (this.mSplitView != null) {
                viewGroup = (ViewGroup)object.getParent();
                if (viewGroup != null && viewGroup != this.mSplitView) {
                    viewGroup.removeView((View)object);
                }
                object.setVisibility(this.getAnimatedVisibility());
                this.mSplitView.addView((View)object, (ViewGroup.LayoutParams)callback);
            } else {
                object.setLayoutParams((ViewGroup.LayoutParams)callback);
            }
        }
        this.mMenuView = object;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void setNavigationMode(int var1_1) {
        var2_2 = this.mNavigationMode;
        if (var1_1 == var2_2) return;
        switch (var2_2) {
            case 1: {
                if (this.mListNavLayout != null) {
                    this.removeView((View)this.mListNavLayout);
                }
            }
            default: {
                ** GOTO lbl12
            }
            case 2: 
        }
        if (this.mTabScrollView != null && this.mIncludeTabs) {
            this.removeView((View)this.mTabScrollView);
        }
lbl12: // 4 sources:
        switch (var1_1) {
            case 1: {
                if (this.mSpinner == null) {
                    this.mSpinner = new IcsSpinner(this.mContext, null, R.attr.actionDropDownStyle);
                    this.mListNavLayout = (IcsLinearLayout)LayoutInflater.from((Context)this.mContext).inflate(R.layout.abs__action_bar_tab_bar_view, null);
                    var3_3 = new LinearLayout.LayoutParams(-2, -1);
                    var3_3.gravity = 17;
                    this.mListNavLayout.addView((View)this.mSpinner, (ViewGroup.LayoutParams)var3_3);
                }
                if (this.mSpinner.getAdapter() != this.mSpinnerAdapter) {
                    this.mSpinner.setAdapter(this.mSpinnerAdapter);
                }
                this.mSpinner.setOnItemSelectedListener(this.mNavItemSelectedListener);
                this.addView((View)this.mListNavLayout);
            }
            default: {
                break;
            }
            case 2: {
                if (this.mTabScrollView == null || !this.mIncludeTabs) break;
                this.addView((View)this.mTabScrollView);
            }
        }
        this.mNavigationMode = var1_1;
        this.requestLayout();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void setSplitActionBar(boolean bl) {
        if (this.mSplitActionBar != bl) {
            Object object;
            if (this.mMenuView != null) {
                object = (ViewGroup)this.mMenuView.getParent();
                if (object != null) {
                    object.removeView((View)this.mMenuView);
                }
                if (bl) {
                    if (this.mSplitView != null) {
                        this.mSplitView.addView((View)this.mMenuView);
                    }
                } else {
                    this.addView((View)this.mMenuView);
                }
            }
            if (this.mSplitView != null) {
                object = this.mSplitView;
                int n2 = bl ? 0 : 8;
                object.setVisibility(n2);
            }
            super.setSplitActionBar(bl);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setSubtitle(CharSequence charSequence) {
        int n2 = 0;
        this.mSubtitle = charSequence;
        if (this.mSubtitleView != null) {
            this.mSubtitleView.setText(charSequence);
            TextView textView = this.mSubtitleView;
            int n3 = charSequence != null ? 0 : 8;
            textView.setVisibility(n3);
            n3 = this.mExpandedActionView == null && (this.mDisplayOptions & 8) != 0 && (!TextUtils.isEmpty((CharSequence)this.mTitle) || !TextUtils.isEmpty((CharSequence)this.mSubtitle)) ? 1 : 0;
            charSequence = this.mTitleLayout;
            n3 = n3 != 0 ? n2 : 8;
            charSequence.setVisibility(n3);
        }
    }

    public void setTitle(CharSequence charSequence) {
        this.mUserTitle = true;
        this.setTitleImpl(charSequence);
    }

    public void setWindowCallback(Window.Callback callback) {
        this.mWindowCallback = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        if (!this.mUserTitle) {
            this.setTitleImpl(charSequence);
        }
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public static class HomeView
    extends FrameLayout {
        private ImageView mIconView;
        private View mUpView;
        private int mUpWidth;

        public HomeView(Context context) {
            this(context, null);
        }

        public HomeView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public boolean dispatchHoverEvent(MotionEvent motionEvent) {
            return this.onHoverEvent(motionEvent);
        }

        public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            this.onPopulateAccessibilityEvent(accessibilityEvent);
            return true;
        }

        public int getLeftOffset() {
            if (this.mUpView.getVisibility() == 8) {
                return this.mUpWidth;
            }
            return 0;
        }

        protected void onFinishInflate() {
            this.mUpView = this.findViewById(R.id.abs__up);
            this.mIconView = (ImageView)this.findViewById(R.id.abs__home);
        }

        protected void onLayout(boolean bl, int n2, int n3, int n4, int n5) {
            FrameLayout.LayoutParams layoutParams;
            int n6 = 0;
            int n7 = (n5 - n3) / 2;
            n3 = n6;
            n5 = n2;
            if (this.mUpView.getVisibility() != 8) {
                layoutParams = (FrameLayout.LayoutParams)this.mUpView.getLayoutParams();
                n5 = this.mUpView.getMeasuredHeight();
                n3 = this.mUpView.getMeasuredWidth();
                n6 = n7 - n5 / 2;
                this.mUpView.layout(0, n6, n3, n5 + n6);
                n5 = layoutParams.leftMargin;
                n3 = layoutParams.rightMargin + (n5 + n3);
                n5 = n2 + n3;
            }
            layoutParams = (FrameLayout.LayoutParams)this.mIconView.getLayoutParams();
            n2 = this.mIconView.getMeasuredHeight();
            n6 = this.mIconView.getMeasuredWidth();
            n4 = (n4 - n5) / 2;
            n4 = Math.max(layoutParams.topMargin, n7 - n2 / 2);
            this.mIconView.layout(n3, n4, n6 + (n3 += Math.max(layoutParams.leftMargin, n4 - n6 / 2)), n2 + n4);
        }

        /*
         * Exception decompiling
         */
        protected void onMeasure(int var1_1, int var2_2) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:486)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:65)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:425)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:129)
            // org.benf.cfr.reader.Main.main(Main.java:181)
            throw new IllegalStateException("Decompilation failed");
        }

        public void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            CharSequence charSequence;
            if (Build.VERSION.SDK_INT >= 14) {
                super.onPopulateAccessibilityEvent(accessibilityEvent);
            }
            if (!TextUtils.isEmpty((CharSequence)(charSequence = this.getContentDescription()))) {
                accessibilityEvent.getText().add(charSequence);
            }
        }

        public void setIcon(Drawable drawable2) {
            this.mIconView.setImageDrawable(drawable2);
        }

        /*
         * Enabled aggressive block sorting
         */
        public void setUp(boolean bl) {
            View view = this.mUpView;
            int n2 = bl ? 0 : 8;
            view.setVisibility(n2);
        }
    }

}

