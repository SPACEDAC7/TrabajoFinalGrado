/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.AttributeSet
 *  android.widget.Button
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.Button;
import java.util.Locale;

public class CapitalizingButton
extends Button {
    private static final boolean IS_GINGERBREAD;
    private static final int[] R_styleable_Button;
    private static final int R_styleable_Button_textAppearance = 0;
    private static final int[] R_styleable_TextAppearance;
    private static final int R_styleable_TextAppearance_textAllCaps = 0;
    private static final boolean SANS_ICE_CREAM;
    private boolean mAllCaps;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = Build.VERSION.SDK_INT < 14;
        SANS_ICE_CREAM = bl;
        bl = Build.VERSION.SDK_INT >= 9;
        IS_GINGERBREAD = bl;
        R_styleable_Button = new int[]{16842804};
        R_styleable_TextAppearance = new int[]{16843660};
    }

    public CapitalizingButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        attributeSet = context.obtainStyledAttributes(attributeSet, R_styleable_Button);
        int n2 = attributeSet.getResourceId(0, -1);
        attributeSet.recycle();
        if (n2 != -1 && (context = context.obtainStyledAttributes(n2, R_styleable_TextAppearance)) != null) {
            this.mAllCaps = context.getBoolean(0, true);
            context.recycle();
        }
    }

    public void setTextCompat(CharSequence charSequence) {
        if (SANS_ICE_CREAM && this.mAllCaps && charSequence != null) {
            if (IS_GINGERBREAD) {
                try {
                    this.setText((CharSequence)charSequence.toString().toUpperCase(Locale.ROOT));
                    return;
                }
                catch (NoSuchFieldError var2_2) {
                    this.setText((CharSequence)charSequence.toString().toUpperCase());
                    return;
                }
            }
            this.setText((CharSequence)charSequence.toString().toUpperCase());
            return;
        }
        this.setText(charSequence);
    }
}

