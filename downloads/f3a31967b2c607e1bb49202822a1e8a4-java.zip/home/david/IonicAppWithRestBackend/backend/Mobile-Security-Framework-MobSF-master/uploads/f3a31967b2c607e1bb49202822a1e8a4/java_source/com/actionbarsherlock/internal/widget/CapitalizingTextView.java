/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.AttributeSet
 *  android.widget.TextView
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.TextView;
import java.util.Locale;

public class CapitalizingTextView
extends TextView {
    private static final boolean IS_GINGERBREAD;
    private static final int[] R_styleable_TextView;
    private static final int R_styleable_TextView_textAllCaps = 0;
    private static final boolean SANS_ICE_CREAM;
    private boolean mAllCaps;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = Build.VERSION.SDK_INT < 14;
        SANS_ICE_CREAM = bl;
        bl = Build.VERSION.SDK_INT >= 9;
        IS_GINGERBREAD = bl;
        R_styleable_TextView = new int[]{16843660};
    }

    public CapitalizingTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public CapitalizingTextView(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        context = context.obtainStyledAttributes(attributeSet, R_styleable_TextView, n2, 0);
        this.mAllCaps = context.getBoolean(0, true);
        context.recycle();
    }

    public void setTextCompat(CharSequence charSequence) {
        if (SANS_ICE_CREAM && this.mAllCaps && charSequence != null) {
            if (IS_GINGERBREAD) {
                try {
                    this.setText((CharSequence)charSequence.toString().toUpperCase(Locale.ROOT));
                    return;
                }
                catch (NoSuchFieldError var2_2) {
                    this.setText((CharSequence)charSequence.toString().toUpperCase());
                    return;
                }
            }
            this.setText((CharSequence)charSequence.toString().toUpperCase());
            return;
        }
        this.setText(charSequence);
    }
}

