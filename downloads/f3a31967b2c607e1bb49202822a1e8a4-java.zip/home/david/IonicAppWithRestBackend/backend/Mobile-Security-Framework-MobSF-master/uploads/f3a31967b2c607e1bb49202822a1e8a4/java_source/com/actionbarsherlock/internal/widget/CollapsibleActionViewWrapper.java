/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.CollapsibleActionView
 *  android.view.View
 *  android.widget.FrameLayout
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.view.CollapsibleActionView;
import android.view.View;
import android.widget.FrameLayout;

public class CollapsibleActionViewWrapper
extends FrameLayout
implements CollapsibleActionView {
    private final com.actionbarsherlock.view.CollapsibleActionView child;

    public CollapsibleActionViewWrapper(View view) {
        super(view.getContext());
        this.child = (com.actionbarsherlock.view.CollapsibleActionView)view;
        this.addView(view);
    }

    public void onActionViewCollapsed() {
        this.child.onActionViewCollapsed();
    }

    public void onActionViewExpanded() {
        this.child.onActionViewExpanded();
    }

    public View unwrap() {
        return this.getChildAt(0);
    }
}

