/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 */
package com.actionbarsherlock.internal.widget;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;

public class IcsColorDrawable
extends Drawable {
    private int color;
    private final Paint paint = new Paint();

    public IcsColorDrawable(int n2) {
        this.color = n2;
    }

    public IcsColorDrawable(ColorDrawable colorDrawable) {
        Bitmap bitmap = Bitmap.createBitmap((int)1, (int)1, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        colorDrawable.draw(new Canvas(bitmap));
        this.color = bitmap.getPixel(0, 0);
        bitmap.recycle();
    }

    public void draw(Canvas canvas) {
        if (this.color >>> 24 != 0) {
            this.paint.setColor(this.color);
            canvas.drawRect(this.getBounds(), this.paint);
        }
    }

    public int getOpacity() {
        return this.color >>> 24;
    }

    public void setAlpha(int n2) {
        if (n2 != this.color >>> 24) {
            this.color = this.color & 16777215 | n2 << 24;
            this.invalidateSelf();
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
    }
}

