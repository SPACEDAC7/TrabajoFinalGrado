/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.actionbarsherlock.internal.nineoldandroids.widget.NineLinearLayout;
import com.actionbarsherlock.internal.widget.IcsColorDrawable;

public class IcsLinearLayout
extends NineLinearLayout {
    private static final int LinearLayout_divider = 0;
    private static final int LinearLayout_dividerPadding = 2;
    private static final int LinearLayout_showDividers = 1;
    private static final int[] R_styleable_LinearLayout = new int[]{16843049, 16843561, 16843562};
    public static final int SHOW_DIVIDER_BEGINNING = 1;
    public static final int SHOW_DIVIDER_END = 4;
    public static final int SHOW_DIVIDER_MIDDLE = 2;
    public static final int SHOW_DIVIDER_NONE = 0;
    private Drawable mDivider;
    private int mDividerHeight;
    private int mDividerPadding;
    private int mDividerWidth;
    private int mShowDividers;

    public IcsLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        context = context.obtainStyledAttributes(attributeSet, R_styleable_LinearLayout);
        this.setDividerDrawable(context.getDrawable(0));
        this.mShowDividers = context.getInt(1, 0);
        this.mDividerPadding = context.getDimensionPixelSize(2, 0);
        context.recycle();
    }

    /*
     * Enabled aggressive block sorting
     */
    void drawDividersHorizontal(Canvas canvas) {
        int n2 = this.getChildCount();
        int n3 = 0;
        do {
            View view;
            if (n3 >= n2) {
                if (this.hasDividerBeforeChildAt(n2)) {
                    view = this.getChildAt(n2 - 1);
                    n3 = view == null ? this.getWidth() - this.getPaddingRight() - this.mDividerWidth : view.getRight();
                    this.drawVerticalDivider(canvas, n3);
                }
                return;
            }
            view = this.getChildAt(n3);
            if (view != null && view.getVisibility() != 8 && this.hasDividerBeforeChildAt(n3)) {
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
                this.drawVerticalDivider(canvas, view.getLeft() - layoutParams.leftMargin);
            }
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    void drawDividersVertical(Canvas canvas) {
        int n2 = this.getChildCount();
        int n3 = 0;
        do {
            View view;
            if (n3 >= n2) {
                if (this.hasDividerBeforeChildAt(n2)) {
                    view = this.getChildAt(n2 - 1);
                    n3 = view == null ? this.getHeight() - this.getPaddingBottom() - this.mDividerHeight : view.getBottom();
                    this.drawHorizontalDivider(canvas, n3);
                }
                return;
            }
            view = this.getChildAt(n3);
            if (view != null && view.getVisibility() != 8 && this.hasDividerBeforeChildAt(n3)) {
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
                this.drawHorizontalDivider(canvas, view.getTop() - layoutParams.topMargin);
            }
            ++n3;
        } while (true);
    }

    void drawHorizontalDivider(Canvas canvas, int n2) {
        this.mDivider.setBounds(this.getPaddingLeft() + this.mDividerPadding, n2, this.getWidth() - this.getPaddingRight() - this.mDividerPadding, this.mDividerHeight + n2);
        this.mDivider.draw(canvas);
    }

    void drawVerticalDivider(Canvas canvas, int n2) {
        this.mDivider.setBounds(n2, this.getPaddingTop() + this.mDividerPadding, this.mDividerWidth + n2, this.getHeight() - this.getPaddingBottom() - this.mDividerPadding);
        this.mDivider.draw(canvas);
    }

    public int getDividerPadding() {
        return this.mDividerPadding;
    }

    public int getDividerWidth() {
        return this.mDividerWidth;
    }

    public int getShowDividers() {
        return this.mShowDividers;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected boolean hasDividerBeforeChildAt(int n2) {
        int n3;
        if (n2 == 0) {
            if ((this.mShowDividers & 1) == 0) return false;
            return true;
        }
        if (n2 == this.getChildCount()) {
            if ((this.mShowDividers & 4) != 0) return true;
            return false;
        }
        if ((this.mShowDividers & 2) == 0) return false;
        do {
            if ((n3 = n2 - 1) < 0) {
                return false;
            }
            n2 = n3;
        } while (this.getChildAt(n3).getVisibility() == 8);
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void measureChildWithMargins(View view, int n2, int n3, int n4, int n5) {
        int n6;
        int n7 = this.indexOfChild(view);
        int n8 = this.getOrientation();
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        if (this.hasDividerBeforeChildAt(n7)) {
            if (n8 == 1) {
                layoutParams.topMargin = this.mDividerHeight;
            } else {
                layoutParams.leftMargin = this.mDividerWidth;
            }
        }
        if (n7 == (n6 = this.getChildCount()) - 1 && this.hasDividerBeforeChildAt(n6)) {
            if (n8 == 1) {
                layoutParams.bottomMargin = this.mDividerHeight;
            } else {
                layoutParams.rightMargin = this.mDividerWidth;
            }
        }
        super.measureChildWithMargins(view, n2, n3, n4, n5);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onDraw(Canvas canvas) {
        if (this.mDivider != null) {
            if (this.getOrientation() == 1) {
                this.drawDividersVertical(canvas);
            } else {
                this.drawDividersHorizontal(canvas);
            }
        }
        super.onDraw(canvas);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setDividerDrawable(Drawable drawable2) {
        if (drawable2 == this.mDivider) {
            return;
        }
        Drawable drawable3 = drawable2;
        if (drawable2 instanceof ColorDrawable) {
            drawable3 = drawable2;
            if (Build.VERSION.SDK_INT < 11) {
                drawable3 = new IcsColorDrawable((ColorDrawable)drawable2);
            }
        }
        this.mDivider = drawable3;
        if (drawable3 != null) {
            this.mDividerWidth = drawable3.getIntrinsicWidth();
            this.mDividerHeight = drawable3.getIntrinsicHeight();
        } else {
            this.mDividerWidth = 0;
            this.mDividerHeight = 0;
        }
        boolean bl = drawable3 == null;
        this.setWillNotDraw(bl);
        this.requestLayout();
    }

    public void setDividerPadding(int n2) {
        this.mDividerPadding = n2;
    }

    public void setShowDividers(int n2) {
        if (n2 != this.mShowDividers) {
            this.requestLayout();
            this.invalidate();
        }
        this.mShowDividers = n2;
    }
}

