/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.database.DataSetObserver
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.ContextThemeWrapper
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.widget.AbsListView
 *  android.widget.AbsListView$LayoutParams
 *  android.widget.AbsListView$OnScrollListener
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.PopupWindow
 *  android.widget.PopupWindow$OnDismissListener
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import com.actionbarsherlock.R;
import com.actionbarsherlock.internal.widget.PopupWindowCompat;

public class IcsListPopupWindow {
    private static final int EXPAND_LIST_TIMEOUT = 250;
    public static final int POSITION_PROMPT_ABOVE = 0;
    public static final int POSITION_PROMPT_BELOW = 1;
    private ListAdapter mAdapter;
    private Context mContext;
    private View mDropDownAnchorView;
    private int mDropDownHeight = -2;
    private int mDropDownHorizontalOffset;
    private DropDownListView mDropDownList;
    private Drawable mDropDownListHighlight;
    private int mDropDownVerticalOffset;
    private boolean mDropDownVerticalOffsetSet;
    private int mDropDownWidth = -2;
    private Handler mHandler;
    private final ListSelectorHider mHideSelector;
    private AdapterView.OnItemClickListener mItemClickListener;
    private AdapterView.OnItemSelectedListener mItemSelectedListener;
    private int mListItemExpandMaximum = Integer.MAX_VALUE;
    private boolean mModal;
    private DataSetObserver mObserver;
    private final PopupWindowCompat mPopup;
    private int mPromptPosition = 0;
    private View mPromptView;
    private final ResizePopupRunnable mResizePopupRunnable;
    private final PopupScrollListener mScrollListener;
    private Rect mTempRect;
    private final PopupTouchInterceptor mTouchInterceptor;

    public IcsListPopupWindow(Context context) {
        this(context, null, R.attr.listPopupWindowStyle);
    }

    public IcsListPopupWindow(Context context, AttributeSet attributeSet, int n2) {
        this.mResizePopupRunnable = new ResizePopupRunnable();
        this.mTouchInterceptor = new PopupTouchInterceptor();
        this.mScrollListener = new PopupScrollListener();
        this.mHideSelector = new ListSelectorHider();
        this.mHandler = new Handler();
        this.mTempRect = new Rect();
        this.mContext = context;
        this.mPopup = new PopupWindowCompat(context, attributeSet, n2);
        this.mPopup.setInputMethodMode(1);
    }

    /*
     * Enabled aggressive block sorting
     */
    public IcsListPopupWindow(Context context, AttributeSet attributeSet, int n2, int n3) {
        this.mResizePopupRunnable = new ResizePopupRunnable();
        this.mTouchInterceptor = new PopupTouchInterceptor();
        this.mScrollListener = new PopupScrollListener();
        this.mHideSelector = new ListSelectorHider();
        this.mHandler = new Handler();
        this.mTempRect = new Rect();
        this.mContext = context;
        this.mPopup = Build.VERSION.SDK_INT < 11 ? new PopupWindowCompat((Context)new ContextThemeWrapper(context, n3), attributeSet, n2) : new PopupWindowCompat(context, attributeSet, n2, n3);
        this.mPopup.setInputMethodMode(1);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private int buildDropDown() {
        var6_1 = true;
        if (this.mDropDownList != null) ** GOTO lbl38
        var8_2 = this.mContext;
        var5_4 = this.mModal == false;
        this.mDropDownList = new DropDownListView(var8_2, var5_4);
        if (this.mDropDownListHighlight != null) {
            this.mDropDownList.setSelector(this.mDropDownListHighlight);
        }
        this.mDropDownList.setAdapter(this.mAdapter);
        this.mDropDownList.setOnItemClickListener(this.mItemClickListener);
        this.mDropDownList.setFocusable(true);
        this.mDropDownList.setFocusableInTouchMode(true);
        this.mDropDownList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> object, View view, int n2, long l2) {
                if (n2 != -1 && (object = IcsListPopupWindow.this.mDropDownList) != null) {
                    DropDownListView.access$0((DropDownListView)((Object)object), false);
                }
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.mDropDownList.setOnScrollListener((AbsListView.OnScrollListener)this.mScrollListener);
        if (this.mItemSelectedListener != null) {
            this.mDropDownList.setOnItemSelectedListener(this.mItemSelectedListener);
        }
        var7_5 = this.mDropDownList;
        var9_6 = this.mPromptView;
        if (var9_6 == null) ** GOTO lbl48
        var8_2 = new LinearLayout(var8_2);
        var8_2.setOrientation(1);
        var10_7 = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        switch (this.mPromptPosition) {
            case 1: {
                var8_2.addView((View)var7_5, (ViewGroup.LayoutParams)var10_7);
                var8_2.addView(var9_6);
                break;
            }
            case 0: {
                var8_2.addView(var9_6);
                var8_2.addView((View)var7_5, (ViewGroup.LayoutParams)var10_7);
                break;
            }
        }
        var9_6.measure(View.MeasureSpec.makeMeasureSpec((int)this.mDropDownWidth, (int)Integer.MIN_VALUE), 0);
        var7_5 = (LinearLayout.LayoutParams)var9_6.getLayoutParams();
        var1_8 = var9_6.getMeasuredHeight();
        var2_9 = var7_5.topMargin;
        var1_8 = var7_5.bottomMargin + (var1_8 + var2_9);
        var7_5 = var8_2;
        ** GOTO lbl49
lbl38: // 1 sources:
        this.mPopup.getContentView();
        var7_5 = this.mPromptView;
        if (var7_5 != null) {
            var8_3 = (LinearLayout.LayoutParams)var7_5.getLayoutParams();
            var1_8 = var7_5.getMeasuredHeight();
            var2_9 = var8_3.topMargin;
            var1_8 = var8_3.bottomMargin + (var1_8 + var2_9);
        } else {
            var1_8 = 0;
        }
        ** GOTO lbl50
lbl48: // 1 sources:
        var1_8 = 0;
lbl49: // 2 sources:
        this.mPopup.setContentView((View)var7_5);
lbl50: // 3 sources:
        if ((var7_5 = this.mPopup.getBackground()) != null) {
            var7_5.getPadding(this.mTempRect);
            var2_9 = this.mTempRect.top;
            var3_10 = this.mTempRect.bottom;
            if (!this.mDropDownVerticalOffsetSet) {
                this.mDropDownVerticalOffset = - this.mTempRect.top;
            }
            var2_9 += var3_10;
        } else {
            var2_9 = 0;
        }
        var5_4 = this.mPopup.getInputMethodMode() == 2 ? var6_1 : false;
        var3_10 = this.getMaxAvailableHeight(this.mDropDownAnchorView, this.mDropDownVerticalOffset, var5_4);
        if (this.mDropDownHeight == -1) {
            return var3_10 + var2_9;
        }
        var4_11 = this.measureHeightOfChildren(0, 0, -1, var3_10 - var1_8, -1);
        var3_10 = var1_8;
        if (var4_11 <= 0) return var4_11 + var3_10;
        var3_10 = var1_8 + var2_9;
        return var4_11 + var3_10;
    }

    private int getMaxAvailableHeight(View view, int n2, boolean bl) {
        Rect rect = new Rect();
        view.getWindowVisibleDisplayFrame(rect);
        int[] arrn = new int[2];
        view.getLocationOnScreen(arrn);
        int n3 = rect.bottom;
        if (bl) {
            n3 = view.getContext().getResources().getDisplayMetrics().heightPixels;
        }
        n2 = n3 = Math.max(n3 - (arrn[1] + view.getHeight()) - n2, arrn[1] - rect.top + n2);
        if (this.mPopup.getBackground() != null) {
            this.mPopup.getBackground().getPadding(this.mTempRect);
            n2 = n3 - (this.mTempRect.top + this.mTempRect.bottom);
        }
        return n2;
    }

    private boolean isInputMethodNotNeeded() {
        if (this.mPopup.getInputMethodMode() == 2) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int measureHeightOfChildren(int n2, int n3, int n4, int n5, int n6) {
        int n7 = 0;
        ListAdapter listAdapter = this.mAdapter;
        if (listAdapter == null) {
            return this.mDropDownList.getListPaddingTop() + this.mDropDownList.getListPaddingBottom();
        }
        int n8 = this.mDropDownList.getListPaddingTop() + this.mDropDownList.getListPaddingBottom();
        int n9 = this.mDropDownList.getDividerHeight() > 0 && this.mDropDownList.getDivider() != null ? this.mDropDownList.getDividerHeight() : 0;
        int n10 = n8;
        int n11 = n7;
        int n12 = n3;
        int n13 = n4;
        if (n4 == -1) {
            n13 = listAdapter.getCount() - 1;
            n12 = n3;
            n11 = n7;
            n10 = n8;
        }
        while (n12 <= n13) {
            listAdapter = this.mAdapter.getView(n12, null, (ViewGroup)this.mDropDownList);
            if (this.mDropDownList.getCacheColorHint() != 0) {
                listAdapter.setDrawingCacheBackgroundColor(this.mDropDownList.getCacheColorHint());
            }
            this.measureScrapChild((View)listAdapter, n12, n2);
            n3 = n10;
            if (n12 > 0) {
                n3 = n10 + n9;
            }
            if ((n4 = listAdapter.getMeasuredHeight() + n3) >= n5) {
                if (n6 < 0) return n5;
                if (n12 <= n6) return n5;
                if (n11 <= 0) return n5;
                if (n4 != n5) return n11;
                return n5;
            }
            n3 = n6 >= 0 && n12 >= n6 ? n4 : n11;
            ++n12;
            n10 = n4;
            n11 = n3;
        }
        return n10;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void measureScrapChild(View view, int n2, int n3) {
        AbsListView.LayoutParams layoutParams;
        AbsListView.LayoutParams layoutParams2 = layoutParams = (AbsListView.LayoutParams)view.getLayoutParams();
        if (layoutParams == null) {
            layoutParams2 = new AbsListView.LayoutParams(-1, -2, 0);
            view.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
        }
        n3 = ViewGroup.getChildMeasureSpec((int)n3, (int)(this.mDropDownList.getPaddingLeft() + this.mDropDownList.getPaddingRight()), (int)layoutParams2.width);
        n2 = layoutParams2.height;
        n2 = n2 > 0 ? View.MeasureSpec.makeMeasureSpec((int)n2, (int)1073741824) : View.MeasureSpec.makeMeasureSpec((int)0, (int)0);
        view.measure(n3, n2);
    }

    public void clearListSelection() {
        DropDownListView dropDownListView = this.mDropDownList;
        if (dropDownListView != null) {
            DropDownListView.access$0(dropDownListView, true);
            dropDownListView.requestLayout();
        }
    }

    public void dismiss() {
        ViewParent viewParent;
        this.mPopup.dismiss();
        if (this.mPromptView != null && (viewParent = this.mPromptView.getParent()) instanceof ViewGroup) {
            ((ViewGroup)viewParent).removeView(this.mPromptView);
        }
        this.mPopup.setContentView(null);
        this.mDropDownList = null;
        this.mHandler.removeCallbacks((Runnable)this.mResizePopupRunnable);
    }

    public ListView getListView() {
        return this.mDropDownList;
    }

    public boolean isShowing() {
        return this.mPopup.isShowing();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setAdapter(ListAdapter listAdapter) {
        if (this.mObserver == null) {
            this.mObserver = new PopupDataSetObserver();
        } else if (this.mAdapter != null) {
            this.mAdapter.unregisterDataSetObserver(this.mObserver);
        }
        this.mAdapter = listAdapter;
        if (this.mAdapter != null) {
            listAdapter.registerDataSetObserver(this.mObserver);
        }
        if (this.mDropDownList != null) {
            this.mDropDownList.setAdapter(this.mAdapter);
        }
    }

    public void setAnchorView(View view) {
        this.mDropDownAnchorView = view;
    }

    public void setBackgroundDrawable(Drawable drawable2) {
        this.mPopup.setBackgroundDrawable(drawable2);
    }

    public void setContentWidth(int n2) {
        Drawable drawable2 = this.mPopup.getBackground();
        if (drawable2 != null) {
            drawable2.getPadding(this.mTempRect);
            this.mDropDownWidth = this.mTempRect.left + this.mTempRect.right + n2;
            return;
        }
        this.mDropDownWidth = n2;
    }

    public void setHorizontalOffset(int n2) {
        this.mDropDownHorizontalOffset = n2;
    }

    public void setInputMethodMode(int n2) {
        this.mPopup.setInputMethodMode(n2);
    }

    public void setModal(boolean bl) {
        this.mModal = true;
        this.mPopup.setFocusable(bl);
    }

    public void setOnDismissListener(PopupWindow.OnDismissListener onDismissListener) {
        this.mPopup.setOnDismissListener(onDismissListener);
    }

    public void setOnItemClickListener(AdapterView.OnItemClickListener onItemClickListener) {
        this.mItemClickListener = onItemClickListener;
    }

    public void setPromptPosition(int n2) {
        this.mPromptPosition = n2;
    }

    public void setSelection(int n2) {
        DropDownListView dropDownListView = this.mDropDownList;
        if (this.isShowing() && dropDownListView != null) {
            DropDownListView.access$0(dropDownListView, false);
            dropDownListView.setSelection(n2);
            if (dropDownListView.getChoiceMode() != 0) {
                dropDownListView.setItemChecked(n2, true);
            }
        }
    }

    public void setVerticalOffset(int n2) {
        this.mDropDownVerticalOffset = n2;
        this.mDropDownVerticalOffsetSet = true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void show() {
        int n2 = 0;
        int n3 = 0;
        int n4 = -1;
        int n5 = this.buildDropDown();
        boolean bl = this.isInputMethodNotNeeded();
        if (this.mPopup.isShowing()) {
            int n6 = this.mDropDownWidth == -1 ? -1 : (this.mDropDownWidth == -2 ? this.mDropDownAnchorView.getWidth() : this.mDropDownWidth);
            if (this.mDropDownHeight == -1) {
                if (!bl) {
                    n5 = -1;
                }
                if (bl) {
                    PopupWindowCompat popupWindowCompat = this.mPopup;
                    n3 = this.mDropDownWidth == -1 ? n4 : 0;
                    popupWindowCompat.setWindowLayoutMode(n3, 0);
                } else {
                    PopupWindowCompat popupWindowCompat = this.mPopup;
                    if (this.mDropDownWidth == -1) {
                        n3 = -1;
                    }
                    popupWindowCompat.setWindowLayoutMode(n3, -1);
                }
            } else if (this.mDropDownHeight != -2) {
                n5 = this.mDropDownHeight;
            }
            this.mPopup.setOutsideTouchable(true);
            this.mPopup.update(this.mDropDownAnchorView, this.mDropDownHorizontalOffset, this.mDropDownVerticalOffset, n6, n5);
            return;
        } else {
            int n7;
            if (this.mDropDownWidth == -1) {
                n7 = -1;
            } else if (this.mDropDownWidth == -2) {
                this.mPopup.setWidth(this.mDropDownAnchorView.getWidth());
                n7 = 0;
            } else {
                this.mPopup.setWidth(this.mDropDownWidth);
                n7 = 0;
            }
            if (this.mDropDownHeight == -1) {
                n5 = -1;
            } else if (this.mDropDownHeight == -2) {
                this.mPopup.setHeight(n5);
                n5 = n2;
            } else {
                this.mPopup.setHeight(this.mDropDownHeight);
                n5 = n2;
            }
            this.mPopup.setWindowLayoutMode(n7, n5);
            this.mPopup.setOutsideTouchable(true);
            this.mPopup.setTouchInterceptor((View.OnTouchListener)this.mTouchInterceptor);
            this.mPopup.showAsDropDown(this.mDropDownAnchorView, this.mDropDownHorizontalOffset, this.mDropDownVerticalOffset);
            this.mDropDownList.setSelection(-1);
            if (!this.mModal || this.mDropDownList.isInTouchMode()) {
                this.clearListSelection();
            }
            if (this.mModal) return;
            {
                this.mHandler.post((Runnable)this.mHideSelector);
                return;
            }
        }
    }

    static class DropDownListView
    extends ListView {
        private boolean mHijackFocus;
        private boolean mListSelectionHidden;

        public DropDownListView(Context context, boolean bl) {
            super(context, null, R.attr.dropDownListViewStyle);
            this.mHijackFocus = bl;
            this.setCacheColorHint(0);
        }

        static /* synthetic */ void access$0(DropDownListView dropDownListView, boolean bl) {
            dropDownListView.mListSelectionHidden = bl;
        }

        public boolean hasFocus() {
            if (!this.mHijackFocus && !super.hasFocus()) {
                return false;
            }
            return true;
        }

        public boolean hasWindowFocus() {
            if (!this.mHijackFocus && !super.hasWindowFocus()) {
                return false;
            }
            return true;
        }

        public boolean isFocused() {
            if (!this.mHijackFocus && !super.isFocused()) {
                return false;
            }
            return true;
        }

        public boolean isInTouchMode() {
            if (!(this.mHijackFocus && this.mListSelectionHidden || super.isInTouchMode())) {
                return false;
            }
            return true;
        }
    }

}

