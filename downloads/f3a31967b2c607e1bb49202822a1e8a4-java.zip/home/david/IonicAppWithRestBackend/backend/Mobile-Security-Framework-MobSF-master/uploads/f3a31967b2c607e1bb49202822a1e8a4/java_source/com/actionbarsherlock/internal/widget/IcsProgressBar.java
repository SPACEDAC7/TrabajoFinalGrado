/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.graphics.BitmapShader
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.drawable.Animatable
 *  android.graphics.drawable.AnimationDrawable
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.ClipDrawable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$Callback
 *  android.graphics.drawable.LayerDrawable
 *  android.graphics.drawable.ShapeDrawable
 *  android.graphics.drawable.shapes.RoundRectShape
 *  android.graphics.drawable.shapes.Shape
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.SystemClock
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  android.view.ViewDebug
 *  android.view.ViewDebug$ExportedProperty
 *  android.view.accessibility.AccessibilityEvent
 *  android.view.accessibility.AccessibilityManager
 *  android.view.animation.AlphaAnimation
 *  android.view.animation.AnimationUtils
 *  android.view.animation.Interpolator
 *  android.view.animation.LinearInterpolator
 *  android.view.animation.Transformation
 *  android.widget.RemoteViews
 *  android.widget.RemoteViews$RemoteView
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewDebug;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.Transformation;
import android.widget.RemoteViews;

@RemoteViews.RemoteView
public class IcsProgressBar
extends View {
    private static final int ANIMATION_RESOLUTION = 200;
    private static final boolean IS_HONEYCOMB;
    private static final int MAX_LEVEL = 10000;
    private static final int[] ProgressBar;
    private static final int ProgressBar_animationResolution = 14;
    private static final int ProgressBar_indeterminate = 5;
    private static final int ProgressBar_indeterminateBehavior = 10;
    private static final int ProgressBar_indeterminateDrawable = 7;
    private static final int ProgressBar_indeterminateDuration = 9;
    private static final int ProgressBar_indeterminateOnly = 6;
    private static final int ProgressBar_interpolator = 13;
    private static final int ProgressBar_max = 2;
    private static final int ProgressBar_maxHeight = 1;
    private static final int ProgressBar_maxWidth = 0;
    private static final int ProgressBar_minHeight = 12;
    private static final int ProgressBar_minWidth = 11;
    private static final int ProgressBar_progress = 3;
    private static final int ProgressBar_progressDrawable = 8;
    private static final int ProgressBar_secondaryProgress = 4;
    private static final int TIMEOUT_SEND_ACCESSIBILITY_EVENT = 200;
    private AccessibilityEventSender mAccessibilityEventSender;
    private AccessibilityManager mAccessibilityManager;
    private AlphaAnimation mAnimation;
    private int mAnimationResolution;
    private int mBehavior;
    private Drawable mCurrentDrawable;
    private int mDuration;
    private boolean mInDrawing;
    private boolean mIndeterminate;
    private Drawable mIndeterminateDrawable;
    private int mIndeterminateRealLeft;
    private int mIndeterminateRealTop;
    private Interpolator mInterpolator;
    private long mLastDrawTime;
    private int mMax;
    int mMaxHeight;
    int mMaxWidth;
    int mMinHeight;
    int mMinWidth;
    private boolean mNoInvalidate;
    private boolean mOnlyIndeterminate;
    private int mProgress;
    private Drawable mProgressDrawable;
    private RefreshProgressRunnable mRefreshProgressRunnable;
    Bitmap mSampleTile;
    private int mSecondaryProgress;
    private boolean mShouldStartAnimationDrawable;
    private Transformation mTransformation;
    private long mUiThreadId;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = Build.VERSION.SDK_INT >= 11;
        IS_HONEYCOMB = bl;
        ProgressBar = new int[]{16843039, 16843040, 16843062, 16843063, 16843064, 16843065, 16843066, 16843067, 16843068, 16843069, 16843070, 16843071, 16843072, 16843073, 16843546};
    }

    public IcsProgressBar(Context context) {
        this(context, null);
    }

    public IcsProgressBar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842871);
    }

    public IcsProgressBar(Context context, AttributeSet attributeSet, int n2) {
        this(context, attributeSet, n2, 0);
    }

    /*
     * Enabled aggressive block sorting
     */
    public IcsProgressBar(Context context, AttributeSet attributeSet, int n2, int n3) {
        boolean bl = false;
        super(context, attributeSet, n2);
        this.mUiThreadId = Thread.currentThread().getId();
        this.initProgressBar();
        attributeSet = context.obtainStyledAttributes(attributeSet, ProgressBar, n2, n3);
        this.mNoInvalidate = true;
        Drawable drawable2 = attributeSet.getDrawable(8);
        if (drawable2 != null) {
            this.setProgressDrawable(this.tileify(drawable2, false));
        }
        this.mDuration = attributeSet.getInt(9, this.mDuration);
        this.mMinWidth = attributeSet.getDimensionPixelSize(11, this.mMinWidth);
        this.mMaxWidth = attributeSet.getDimensionPixelSize(0, this.mMaxWidth);
        this.mMinHeight = attributeSet.getDimensionPixelSize(12, this.mMinHeight);
        this.mMaxHeight = attributeSet.getDimensionPixelSize(1, this.mMaxHeight);
        this.mBehavior = attributeSet.getInt(10, this.mBehavior);
        n2 = attributeSet.getResourceId(13, 17432587);
        if (n2 > 0) {
            this.setInterpolator(context, n2);
        }
        this.setMax(attributeSet.getInt(2, this.mMax));
        this.setProgress(attributeSet.getInt(3, this.mProgress));
        this.setSecondaryProgress(attributeSet.getInt(4, this.mSecondaryProgress));
        drawable2 = attributeSet.getDrawable(7);
        if (drawable2 != null) {
            this.setIndeterminateDrawable(this.tileifyIndeterminate(drawable2));
        }
        this.mOnlyIndeterminate = attributeSet.getBoolean(6, this.mOnlyIndeterminate);
        this.mNoInvalidate = false;
        if (this.mOnlyIndeterminate || attributeSet.getBoolean(5, this.mIndeterminate)) {
            bl = true;
        }
        this.setIndeterminate(bl);
        this.mAnimationResolution = attributeSet.getInteger(14, 200);
        attributeSet.recycle();
        this.mAccessibilityManager = (AccessibilityManager)context.getSystemService("accessibility");
    }

    static /* synthetic */ void access$1(IcsProgressBar icsProgressBar, RefreshProgressRunnable refreshProgressRunnable) {
        icsProgressBar.mRefreshProgressRunnable = refreshProgressRunnable;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void doRefreshProgress(int n2, int n3, boolean bl, boolean bl2) {
        synchronized (this) {
            float f2 = this.mMax > 0 ? (float)n3 / (float)this.mMax : 0.0f;
            Drawable drawable2 = this.mCurrentDrawable;
            if (drawable2 == null) {
                this.invalidate();
            } else {
                Drawable drawable3 = null;
                if (drawable2 instanceof LayerDrawable) {
                    drawable3 = ((LayerDrawable)drawable2).findDrawableByLayerId(n2);
                }
                n3 = (int)(10000.0f * f2);
                if (drawable3 != null) {
                    drawable2 = drawable3;
                }
                drawable2.setLevel(n3);
            }
            if (bl2 && n2 == 16908301) {
                this.onProgressRefresh(f2, bl);
            }
            return;
        }
    }

    private void initProgressBar() {
        this.mMax = 100;
        this.mProgress = 0;
        this.mSecondaryProgress = 0;
        this.mIndeterminate = false;
        this.mOnlyIndeterminate = false;
        this.mDuration = 4000;
        this.mBehavior = 1;
        this.mMinWidth = 24;
        this.mMaxWidth = 48;
        this.mMinHeight = 24;
        this.mMaxHeight = 48;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void refreshProgress(int n2, int n3, boolean bl) {
        synchronized (this) {
            if (this.mUiThreadId == Thread.currentThread().getId()) {
                this.doRefreshProgress(n2, n3, bl, true);
            } else {
                RefreshProgressRunnable refreshProgressRunnable;
                if (this.mRefreshProgressRunnable != null) {
                    refreshProgressRunnable = this.mRefreshProgressRunnable;
                    this.mRefreshProgressRunnable = null;
                    refreshProgressRunnable.setup(n2, n3, bl);
                } else {
                    refreshProgressRunnable = new RefreshProgressRunnable(n2, n3, bl);
                }
                this.post((Runnable)refreshProgressRunnable);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void scheduleAccessibilityEventSender() {
        if (this.mAccessibilityEventSender == null) {
            this.mAccessibilityEventSender = new AccessibilityEventSender();
        } else {
            this.removeCallbacks((Runnable)this.mAccessibilityEventSender);
        }
        this.postDelayed((Runnable)this.mAccessibilityEventSender, 200);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Drawable tileify(Drawable bitmap, boolean bl) {
        Bitmap bitmap2;
        int n2 = 0;
        if (!(bitmap instanceof LayerDrawable)) {
            bitmap2 = bitmap;
            if (!(bitmap instanceof BitmapDrawable)) return bitmap2;
            {
                bitmap2 = ((BitmapDrawable)bitmap).getBitmap();
                if (this.mSampleTile == null) {
                    this.mSampleTile = bitmap2;
                }
                bitmap = new ShapeDrawable(this.getDrawableShape());
                bitmap2 = new BitmapShader(bitmap2, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP);
                bitmap.getPaint().setShader((Shader)bitmap2);
                if (!bl) return bitmap;
                return new ClipDrawable((Drawable)bitmap, 3, 1);
            }
        } else {
            bitmap = (LayerDrawable)bitmap;
            int n3 = bitmap.getNumberOfLayers();
            bitmap2 = new Drawable[n3];
            int n4 = 0;
            do {
                if (n4 >= n3) {
                    bitmap2 = new LayerDrawable((Drawable[])bitmap2);
                    break;
                }
                int n5 = bitmap.getId(n4);
                Drawable drawable2 = bitmap.getDrawable(n4);
                bl = n5 == 16908301 || n5 == 16908303;
                bitmap2[n4] = this.tileify(drawable2, bl);
                ++n4;
            } while (true);
            for (n4 = n2; n4 < n3; ++n4) {
                bitmap2.setId(n4, bitmap.getId(n4));
            }
        }
        return bitmap2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Drawable tileifyIndeterminate(Drawable drawable2) {
        Drawable drawable3 = drawable2;
        if (!(drawable2 instanceof AnimationDrawable)) return drawable3;
        drawable2 = (AnimationDrawable)drawable2;
        int n2 = drawable2.getNumberOfFrames();
        drawable3 = new AnimationDrawable();
        drawable3.setOneShot(drawable2.isOneShot());
        int n3 = 0;
        do {
            if (n3 >= n2) {
                drawable3.setLevel(10000);
                return drawable3;
            }
            Drawable drawable4 = this.tileify(drawable2.getFrame(n3), true);
            drawable4.setLevel(10000);
            drawable3.addFrame(drawable4, drawable2.getDuration(n3));
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void updateDrawableBounds(int n2, int n3) {
        int n4 = n2 - this.getPaddingRight() - this.getPaddingLeft();
        int n5 = n3 - this.getPaddingBottom() - this.getPaddingTop();
        if (this.mIndeterminateDrawable != null) {
            float f2;
            float f3;
            int n6;
            int n7;
            if (this.mOnlyIndeterminate && !(this.mIndeterminateDrawable instanceof AnimationDrawable) && (f2 = (float)(n7 = this.mIndeterminateDrawable.getIntrinsicWidth()) / (float)(n6 = this.mIndeterminateDrawable.getIntrinsicHeight())) != (f3 = (float)n2 / (float)n3)) {
                if (f3 > f2) {
                    n3 = (int)(f2 * (float)n3);
                    n7 = (n2 - n3) / 2;
                    n3 += n7;
                    n2 = n5;
                    n4 = 0;
                    n5 = n7;
                } else {
                    f3 = n2;
                    n2 = (int)(1.0f / f2 * f3);
                    n5 = (n3 - n2) / 2;
                    n3 = n4;
                    n2 += n5;
                    n4 = n5;
                    n5 = 0;
                }
            } else {
                n7 = 0;
                n3 = n4;
                n2 = n5;
                n4 = 0;
                n5 = n7;
            }
            this.mIndeterminateDrawable.setBounds(0, 0, n3 - n5, n2 - n4);
            this.mIndeterminateRealLeft = n5;
            this.mIndeterminateRealTop = n4;
        } else {
            n2 = n5;
            n3 = n4;
        }
        if (this.mProgressDrawable != null) {
            this.mProgressDrawable.setBounds(0, 0, n3, n2);
        }
    }

    private void updateDrawableState() {
        int[] arrn = this.getDrawableState();
        if (this.mProgressDrawable != null && this.mProgressDrawable.isStateful()) {
            this.mProgressDrawable.setState(arrn);
        }
        if (this.mIndeterminateDrawable != null && this.mIndeterminateDrawable.isStateful()) {
            this.mIndeterminateDrawable.setState(arrn);
        }
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        this.updateDrawableState();
    }

    Drawable getCurrentDrawable() {
        return this.mCurrentDrawable;
    }

    Shape getDrawableShape() {
        return new RoundRectShape(new float[]{5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f}, null, null);
    }

    public Drawable getIndeterminateDrawable() {
        return this.mIndeterminateDrawable;
    }

    public Interpolator getInterpolator() {
        return this.mInterpolator;
    }

    @ViewDebug.ExportedProperty(category="progress")
    public int getMax() {
        synchronized (this) {
            int n2 = this.mMax;
            return n2;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @ViewDebug.ExportedProperty(category="progress")
    public int getProgress() {
        synchronized (this) {
            block6 : {
                boolean bl = this.mIndeterminate;
                if (!bl) break block6;
                return 0;
            }
            int n2 = this.mProgress;
            return n2;
        }
    }

    public Drawable getProgressDrawable() {
        return this.mProgressDrawable;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @ViewDebug.ExportedProperty(category="progress")
    public int getSecondaryProgress() {
        synchronized (this) {
            block6 : {
                boolean bl = this.mIndeterminate;
                if (!bl) break block6;
                return 0;
            }
            int n2 = this.mSecondaryProgress;
            return n2;
        }
    }

    public final void incrementProgressBy(int n2) {
        synchronized (this) {
            this.setProgress(this.mProgress + n2);
            return;
        }
    }

    public final void incrementSecondaryProgressBy(int n2) {
        synchronized (this) {
            this.setSecondaryProgress(this.mSecondaryProgress + n2);
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void invalidateDrawable(Drawable drawable2) {
        if (this.mInDrawing) return;
        if (this.verifyDrawable(drawable2)) {
            drawable2 = drawable2.getBounds();
            int n2 = this.getScrollX() + this.getPaddingLeft();
            int n3 = this.getScrollY() + this.getPaddingTop();
            this.invalidate(drawable2.left + n2, drawable2.top + n3, n2 + drawable2.right, drawable2.bottom + n3);
            return;
        }
        super.invalidateDrawable(drawable2);
    }

    @ViewDebug.ExportedProperty(category="progress")
    public boolean isIndeterminate() {
        synchronized (this) {
            boolean bl = this.mIndeterminate;
            return bl;
        }
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        if (this.mProgressDrawable != null) {
            this.mProgressDrawable.jumpToCurrentState();
        }
        if (this.mIndeterminateDrawable != null) {
            this.mIndeterminateDrawable.jumpToCurrentState();
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.mIndeterminate) {
            this.startAnimation();
        }
    }

    protected void onDetachedFromWindow() {
        if (this.mIndeterminate) {
            this.stopAnimation();
        }
        if (this.mRefreshProgressRunnable != null) {
            this.removeCallbacks((Runnable)this.mRefreshProgressRunnable);
        }
        if (this.mAccessibilityEventSender != null) {
            this.removeCallbacks((Runnable)this.mAccessibilityEventSender);
        }
        super.onDetachedFromWindow();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onDraw(Canvas canvas) {
        synchronized (this) {
            super.onDraw(canvas);
            Drawable drawable2 = this.mCurrentDrawable;
            if (drawable2 != null) {
                block9 : {
                    canvas.save();
                    canvas.translate((float)(this.getPaddingLeft() + this.mIndeterminateRealLeft), (float)(this.getPaddingTop() + this.mIndeterminateRealTop));
                    long l2 = this.getDrawingTime();
                    if (this.mAnimation != null) {
                        this.mAnimation.getTransformation(l2, this.mTransformation);
                        float f2 = this.mTransformation.getAlpha();
                        this.mInDrawing = true;
                        drawable2.setLevel((int)(f2 * 10000.0f));
                        if (SystemClock.uptimeMillis() - this.mLastDrawTime < (long)this.mAnimationResolution) break block9;
                        this.mLastDrawTime = SystemClock.uptimeMillis();
                        this.postInvalidateDelayed((long)this.mAnimationResolution);
                    }
                }
                drawable2.draw(canvas);
                canvas.restore();
                if (this.mShouldStartAnimationDrawable && drawable2 instanceof Animatable) {
                    ((Animatable)drawable2).start();
                    this.mShouldStartAnimationDrawable = false;
                }
            }
            return;
            finally {
                this.mInDrawing = false;
            }
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setItemCount(this.mMax);
        accessibilityEvent.setCurrentItemIndex(this.mProgress);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onMeasure(int n2, int n3) {
        int n4 = 0;
        synchronized (this) {
            int n5;
            Drawable drawable2 = this.mCurrentDrawable;
            if (drawable2 != null) {
                n5 = Math.max(this.mMinWidth, Math.min(this.mMaxWidth, drawable2.getIntrinsicWidth()));
                n4 = Math.max(this.mMinHeight, Math.min(this.mMaxHeight, drawable2.getIntrinsicHeight()));
            } else {
                n5 = 0;
            }
            this.updateDrawableState();
            n5 += this.getPaddingLeft() + this.getPaddingRight();
            n4 += this.getPaddingTop() + this.getPaddingBottom();
            if (IS_HONEYCOMB) {
                this.setMeasuredDimension(View.resolveSizeAndState((int)n5, (int)n2, (int)0), View.resolveSizeAndState((int)n4, (int)n3, (int)0));
            } else {
                this.setMeasuredDimension(View.resolveSize((int)n5, (int)n2), View.resolveSize((int)n4, (int)n3));
            }
            return;
        }
    }

    void onProgressRefresh(float f2, boolean bl) {
        if (this.mAccessibilityManager.isEnabled()) {
            this.scheduleAccessibilityEventSender();
        }
    }

    public void onRestoreInstanceState(Parcelable object) {
        object = (SavedState)((Object)object);
        super.onRestoreInstanceState(object.getSuperState());
        this.setProgress(object.progress);
        this.setSecondaryProgress(object.secondaryProgress);
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.progress = this.mProgress;
        savedState.secondaryProgress = this.mSecondaryProgress;
        return savedState;
    }

    protected void onSizeChanged(int n2, int n3, int n4, int n5) {
        this.updateDrawableBounds(n2, n3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected void onVisibilityChanged(View view, int n2) {
        super.onVisibilityChanged(view, n2);
        if (!this.mIndeterminate) return;
        if (n2 == 8 || n2 == 4) {
            this.stopAnimation();
            return;
        }
        this.startAnimation();
    }

    public void postInvalidate() {
        if (!this.mNoInvalidate) {
            super.postInvalidate();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setIndeterminate(boolean bl) {
        synchronized (this) {
            if (!(this.mOnlyIndeterminate && this.mIndeterminate || bl == this.mIndeterminate)) {
                this.mIndeterminate = bl;
                if (bl) {
                    this.mCurrentDrawable = this.mIndeterminateDrawable;
                    this.startAnimation();
                } else {
                    this.mCurrentDrawable = this.mProgressDrawable;
                    this.stopAnimation();
                }
            }
            return;
        }
    }

    public void setIndeterminateDrawable(Drawable drawable2) {
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback)this);
        }
        this.mIndeterminateDrawable = drawable2;
        if (this.mIndeterminate) {
            this.mCurrentDrawable = drawable2;
            this.postInvalidate();
        }
    }

    public void setInterpolator(Context context, int n2) {
        this.setInterpolator(AnimationUtils.loadInterpolator((Context)context, (int)n2));
    }

    public void setInterpolator(Interpolator interpolator) {
        this.mInterpolator = interpolator;
    }

    public void setMax(int n2) {
        synchronized (this) {
            int n3 = n2;
            if (n2 < 0) {
                n3 = 0;
            }
            if (n3 != this.mMax) {
                this.mMax = n3;
                this.postInvalidate();
                if (this.mProgress > n3) {
                    this.mProgress = n3;
                }
                this.refreshProgress(16908301, this.mProgress, false);
            }
            return;
        }
    }

    public void setProgress(int n2) {
        synchronized (this) {
            this.setProgress(n2, false);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void setProgress(int n2, boolean bl) {
        synchronized (this) {
            boolean bl2 = this.mIndeterminate;
            if (!bl2) {
                if (n2 < 0) {
                    n2 = 0;
                }
                int n3 = n2;
                if (n2 > this.mMax) {
                    n3 = this.mMax;
                }
                if (n3 != this.mProgress) {
                    this.mProgress = n3;
                    this.refreshProgress(16908301, this.mProgress, bl);
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setProgressDrawable(Drawable drawable2) {
        boolean bl;
        if (this.mProgressDrawable != null && drawable2 != this.mProgressDrawable) {
            this.mProgressDrawable.setCallback(null);
            bl = true;
        } else {
            bl = false;
        }
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback)this);
            int n2 = drawable2.getMinimumHeight();
            if (this.mMaxHeight < n2) {
                this.mMaxHeight = n2;
                this.requestLayout();
            }
        }
        this.mProgressDrawable = drawable2;
        if (!this.mIndeterminate) {
            this.mCurrentDrawable = drawable2;
            this.postInvalidate();
        }
        if (bl) {
            this.updateDrawableBounds(this.getWidth(), this.getHeight());
            this.updateDrawableState();
            this.doRefreshProgress(16908301, this.mProgress, false, false);
            this.doRefreshProgress(16908303, this.mSecondaryProgress, false, false);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setSecondaryProgress(int n2) {
        int n3 = 0;
        synchronized (this) {
            boolean bl = this.mIndeterminate;
            if (!bl) {
                if (n2 < 0) {
                    n2 = n3;
                }
                n3 = n2;
                if (n2 > this.mMax) {
                    n3 = this.mMax;
                }
                if (n3 != this.mSecondaryProgress) {
                    this.mSecondaryProgress = n3;
                    this.refreshProgress(16908303, this.mSecondaryProgress, false);
                }
            }
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void setVisibility(int n2) {
        if (this.getVisibility() == n2) return;
        super.setVisibility(n2);
        if (!this.mIndeterminate) return;
        if (n2 == 8 || n2 == 4) {
            this.stopAnimation();
            return;
        }
        this.startAnimation();
    }

    /*
     * Enabled aggressive block sorting
     */
    void startAnimation() {
        if (this.getVisibility() != 0) {
            return;
        }
        if (this.mIndeterminateDrawable instanceof Animatable) {
            this.mShouldStartAnimationDrawable = true;
            this.mAnimation = null;
        } else {
            if (this.mInterpolator == null) {
                this.mInterpolator = new LinearInterpolator();
            }
            this.mTransformation = new Transformation();
            this.mAnimation = new AlphaAnimation(0.0f, 1.0f);
            this.mAnimation.setRepeatMode(this.mBehavior);
            this.mAnimation.setRepeatCount(-1);
            this.mAnimation.setDuration((long)this.mDuration);
            this.mAnimation.setInterpolator(this.mInterpolator);
            this.mAnimation.setStartTime(-1);
        }
        this.postInvalidate();
    }

    void stopAnimation() {
        this.mAnimation = null;
        this.mTransformation = null;
        if (this.mIndeterminateDrawable instanceof Animatable) {
            ((Animatable)this.mIndeterminateDrawable).stop();
            this.mShouldStartAnimationDrawable = false;
        }
        this.postInvalidate();
    }

    protected boolean verifyDrawable(Drawable drawable2) {
        if (drawable2 != this.mProgressDrawable && drawable2 != this.mIndeterminateDrawable && !super.verifyDrawable(drawable2)) {
            return false;
        }
        return true;
    }

    class RefreshProgressRunnable
    implements Runnable {
        private boolean mFromUser;
        private int mId;
        private int mProgress;

        RefreshProgressRunnable(int n2, int n3, boolean bl) {
            this.mId = n2;
            this.mProgress = n3;
            this.mFromUser = bl;
        }

        @Override
        public void run() {
            IcsProgressBar.this.doRefreshProgress(this.mId, this.mProgress, this.mFromUser, true);
            IcsProgressBar.access$1(IcsProgressBar.this, this);
        }

        public void setup(int n2, int n3, boolean bl) {
            this.mId = n2;
            this.mProgress = n3;
            this.mFromUser = bl;
        }
    }

}

