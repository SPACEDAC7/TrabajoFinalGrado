/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.res.TypedArray
 *  android.database.DataSetObserver
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.SpinnerAdapter
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SpinnerAdapter;
import com.actionbarsherlock.R;
import com.actionbarsherlock.internal.widget.IcsAbsSpinner;
import com.actionbarsherlock.internal.widget.IcsListPopupWindow;

public class IcsSpinner
extends IcsAbsSpinner
implements DialogInterface.OnClickListener {
    private static final int MAX_ITEMS_MEASURED = 15;
    public static final int MODE_DROPDOWN = 1;
    private boolean mDisableChildrenWhenDisabled;
    int mDropDownWidth;
    private int mGravity;
    private SpinnerPopup mPopup;
    private DropDownAdapter mTempAdapter;
    private Rect mTempRect = new Rect();

    public IcsSpinner(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.actionDropDownStyle);
    }

    public IcsSpinner(Context object, AttributeSet attributeSet, int n2) {
        super((Context)object, attributeSet, n2);
        TypedArray typedArray = object.obtainStyledAttributes(attributeSet, R.styleable.SherlockSpinner, n2, 0);
        object = new DropdownPopup((Context)object, attributeSet, n2);
        this.mDropDownWidth = typedArray.getLayoutDimension(4, -2);
        object.setBackgroundDrawable(typedArray.getDrawable(2));
        n2 = typedArray.getDimensionPixelOffset(6, 0);
        if (n2 != 0) {
            object.setVerticalOffset(n2);
        }
        if ((n2 = typedArray.getDimensionPixelOffset(5, 0)) != 0) {
            object.setHorizontalOffset(n2);
        }
        this.mPopup = object;
        this.mGravity = typedArray.getInt(0, 17);
        this.mPopup.setPromptText(typedArray.getString(3));
        this.mDisableChildrenWhenDisabled = true;
        typedArray.recycle();
        if (this.mTempAdapter != null) {
            this.mPopup.setAdapter(this.mTempAdapter);
            this.mTempAdapter = null;
        }
    }

    private View makeAndAddView(int n2) {
        View view;
        if (!this.mDataChanged && (view = this.mRecycler.get(n2)) != null) {
            this.setUpChild(view);
            return view;
        }
        view = this.mAdapter.getView(n2, null, (ViewGroup)this);
        this.setUpChild(view);
        return view;
    }

    private void setUpChild(View view) {
        ViewGroup.LayoutParams layoutParams;
        ViewGroup.LayoutParams layoutParams2 = layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            layoutParams2 = this.generateDefaultLayoutParams();
        }
        this.addViewInLayout(view, 0, layoutParams2);
        view.setSelected(this.hasFocus());
        if (this.mDisableChildrenWhenDisabled) {
            view.setEnabled(this.isEnabled());
        }
        int n2 = ViewGroup.getChildMeasureSpec((int)this.mHeightMeasureSpec, (int)(this.mSpinnerPadding.top + this.mSpinnerPadding.bottom), (int)layoutParams2.height);
        view.measure(ViewGroup.getChildMeasureSpec((int)this.mWidthMeasureSpec, (int)(this.mSpinnerPadding.left + this.mSpinnerPadding.right), (int)layoutParams2.width), n2);
        n2 = this.mSpinnerPadding.top + (this.getMeasuredHeight() - this.mSpinnerPadding.bottom - this.mSpinnerPadding.top - view.getMeasuredHeight()) / 2;
        int n3 = view.getMeasuredHeight();
        view.layout(0, n2, view.getMeasuredWidth(), n3 + n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public int getBaseline() {
        View view;
        int n2 = -1;
        View view2 = null;
        if (this.getChildCount() > 0) {
            view = this.getChildAt(0);
        } else {
            view = view2;
            if (this.mAdapter != null) {
                view = view2;
                if (this.mAdapter.getCount() > 0) {
                    view = this.makeAndAddView(0);
                    this.mRecycler.put(0, view);
                    this.removeAllViewsInLayout();
                }
            }
        }
        int n3 = n2;
        if (view == null) return n3;
        int n4 = view.getBaseline();
        n3 = n2;
        if (n4 < 0) return n3;
        return view.getTop() + n4;
    }

    public CharSequence getPrompt() {
        return this.mPopup.getHintText();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    void layout(int n2, boolean bl) {
        n2 = this.mSpinnerPadding.left;
        int n3 = this.getRight() - this.getLeft() - this.mSpinnerPadding.left - this.mSpinnerPadding.right;
        if (this.mDataChanged) {
            this.handleDataChanged();
        }
        if (this.mItemCount == 0) {
            this.resetList();
            return;
        }
        if (this.mNextSelectedPosition >= 0) {
            this.setSelectedPositionInt(this.mNextSelectedPosition);
        }
        this.recycleAllViews();
        this.removeAllViewsInLayout();
        this.mFirstPosition = this.mSelectedPosition;
        View view = this.makeAndAddView(this.mSelectedPosition);
        int n4 = view.getMeasuredWidth();
        switch (this.mGravity & 7) {
            case 1: {
                n2 = n2 + n3 / 2 - n4 / 2;
            }
            default: {
                break;
            }
            case 5: {
                n2 = n2 + n3 - n4;
            }
        }
        view.offsetLeftAndRight(n2);
        this.mRecycler.clear();
        this.invalidate();
        this.checkSelectionChanged();
        this.mDataChanged = false;
        this.mNeedSync = false;
        this.setNextSelectedPositionInt(this.mSelectedPosition);
    }

    int measureContentWidth(SpinnerAdapter spinnerAdapter, Drawable drawable2) {
        if (spinnerAdapter == null) {
            return 0;
        }
        int n2 = View.MeasureSpec.makeMeasureSpec((int)0, (int)0);
        int n3 = View.MeasureSpec.makeMeasureSpec((int)0, (int)0);
        int n4 = Math.max(0, this.getSelectedItemPosition());
        int n5 = Math.min(spinnerAdapter.getCount(), n4 + 15);
        int n6 = Math.max(0, n4 - (15 - (n5 - n4)));
        View view = null;
        int n7 = 0;
        n4 = 0;
        do {
            if (n6 >= n5) {
                if (drawable2 == null) break;
                drawable2.getPadding(this.mTempRect);
                return this.mTempRect.left + this.mTempRect.right + n7;
            }
            int n8 = spinnerAdapter.getItemViewType(n6);
            if (n8 != n4) {
                view = null;
                n4 = n8;
            }
            if ((view = spinnerAdapter.getView(n6, view, (ViewGroup)this)).getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(n2, n3);
            n7 = Math.max(n7, view.getMeasuredWidth());
            ++n6;
        } while (true);
        return n7;
    }

    public void onClick(DialogInterface dialogInterface, int n2) {
        this.setSelection(n2);
        dialogInterface.dismiss();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.mPopup != null && this.mPopup.isShowing()) {
            this.mPopup.dismiss();
        }
    }

    @Override
    protected void onLayout(boolean bl, int n2, int n3, int n4, int n5) {
        super.onLayout(bl, n2, n3, n4, n5);
        this.mInLayout = true;
        this.layout(0, false);
        this.mInLayout = false;
    }

    @Override
    protected void onMeasure(int n2, int n3) {
        super.onMeasure(n2, n3);
        if (this.mPopup != null && View.MeasureSpec.getMode((int)n2) == Integer.MIN_VALUE) {
            this.setMeasuredDimension(Math.min(Math.max(this.getMeasuredWidth(), this.measureContentWidth(this.getAdapter(), this.getBackground())), View.MeasureSpec.getSize((int)n2)), this.getMeasuredHeight());
        }
    }

    public boolean performClick() {
        boolean bl;
        boolean bl2 = bl = super.performClick();
        if (!bl) {
            bl2 = bl = true;
            if (!this.mPopup.isShowing()) {
                this.mPopup.show();
                bl2 = bl;
            }
        }
        return bl2;
    }

    @Override
    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        super.setAdapter(spinnerAdapter);
        if (this.mPopup != null) {
            this.mPopup.setAdapter(new DropDownAdapter(spinnerAdapter));
            return;
        }
        this.mTempAdapter = new DropDownAdapter(spinnerAdapter);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void setEnabled(boolean bl) {
        super.setEnabled(bl);
        if (!this.mDisableChildrenWhenDisabled) return;
        int n2 = this.getChildCount();
        int n3 = 0;
        while (n3 < n2) {
            this.getChildAt(n3).setEnabled(bl);
            ++n3;
        }
        return;
    }

    public void setGravity(int n2) {
        if (this.mGravity != n2) {
            int n3 = n2;
            if ((n2 & 7) == 0) {
                n3 = n2 | 3;
            }
            this.mGravity = n3;
            this.requestLayout();
        }
    }

    @Override
    public void setOnItemClickListener(AdapterView.OnItemClickListener onItemClickListener) {
        throw new RuntimeException("setOnItemClickListener cannot be used with a spinner.");
    }

    public void setPrompt(CharSequence charSequence) {
        this.mPopup.setPromptText(charSequence);
    }

    public void setPromptId(int n2) {
        this.setPrompt(this.getContext().getText(n2));
    }

    static class DropDownAdapter
    implements ListAdapter,
    SpinnerAdapter {
        private SpinnerAdapter mAdapter;
        private ListAdapter mListAdapter;

        public DropDownAdapter(SpinnerAdapter spinnerAdapter) {
            this.mAdapter = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                this.mListAdapter = (ListAdapter)spinnerAdapter;
            }
        }

        public boolean areAllItemsEnabled() {
            ListAdapter listAdapter = this.mListAdapter;
            if (listAdapter != null) {
                return listAdapter.areAllItemsEnabled();
            }
            return true;
        }

        public int getCount() {
            if (this.mAdapter == null) {
                return 0;
            }
            return this.mAdapter.getCount();
        }

        public View getDropDownView(int n2, View view, ViewGroup viewGroup) {
            if (this.mAdapter == null) {
                return null;
            }
            return this.mAdapter.getDropDownView(n2, view, viewGroup);
        }

        public Object getItem(int n2) {
            if (this.mAdapter == null) {
                return null;
            }
            return this.mAdapter.getItem(n2);
        }

        public long getItemId(int n2) {
            if (this.mAdapter == null) {
                return -1;
            }
            return this.mAdapter.getItemId(n2);
        }

        public int getItemViewType(int n2) {
            return 0;
        }

        public View getView(int n2, View view, ViewGroup viewGroup) {
            return this.getDropDownView(n2, view, viewGroup);
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            if (this.mAdapter != null && this.mAdapter.hasStableIds()) {
                return true;
            }
            return false;
        }

        public boolean isEmpty() {
            if (this.getCount() == 0) {
                return true;
            }
            return false;
        }

        public boolean isEnabled(int n2) {
            ListAdapter listAdapter = this.mListAdapter;
            if (listAdapter != null) {
                return listAdapter.isEnabled(n2);
            }
            return true;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.mAdapter != null) {
                this.mAdapter.registerDataSetObserver(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.mAdapter != null) {
                this.mAdapter.unregisterDataSetObserver(dataSetObserver);
            }
        }
    }

    class DropdownPopup
    extends IcsListPopupWindow
    implements SpinnerPopup {
        private ListAdapter mAdapter;
        private CharSequence mHintText;

        public DropdownPopup(Context context, AttributeSet attributeSet, int n2) {
            super(context, attributeSet, 0, n2);
            this.setAnchorView((View)IcsSpinner.this);
            this.setModal(true);
            this.setPromptPosition(0);
            this.setOnItemClickListener(new AdapterView.OnItemClickListener(){

                public void onItemClick(AdapterView adapterView, View view, int n2, long l2) {
                    DropdownPopup.this.IcsSpinner.this.setSelection(n2);
                    DropdownPopup.this.dismiss();
                }
            });
        }

        @Override
        public CharSequence getHintText() {
            return this.mHintText;
        }

        @Override
        public void setAdapter(ListAdapter listAdapter) {
            super.setAdapter(listAdapter);
            this.mAdapter = listAdapter;
        }

        @Override
        public void setPromptText(CharSequence charSequence) {
            this.mHintText = charSequence;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void show() {
            int n2;
            int n3 = IcsSpinner.this.getPaddingLeft();
            if (IcsSpinner.this.mDropDownWidth == -2) {
                n2 = IcsSpinner.this.getWidth();
                int n4 = IcsSpinner.this.getPaddingRight();
                this.setContentWidth(Math.max(IcsSpinner.this.measureContentWidth((SpinnerAdapter)this.mAdapter, IcsSpinner.this.getBackground()), n2 - n3 - n4));
            } else if (IcsSpinner.this.mDropDownWidth == -1) {
                this.setContentWidth(IcsSpinner.this.getWidth() - n3 - IcsSpinner.this.getPaddingRight());
            } else {
                this.setContentWidth(IcsSpinner.this.mDropDownWidth);
            }
            Drawable drawable2 = IcsSpinner.this.getBackground();
            n2 = 0;
            if (drawable2 != null) {
                drawable2.getPadding(IcsSpinner.this.mTempRect);
                n2 = - IcsSpinner.access$0((IcsSpinner)IcsSpinner.this).left;
            }
            this.setHorizontalOffset(n2 + n3);
            this.setInputMethodMode(2);
            super.show();
            this.getListView().setChoiceMode(1);
            this.setSelection(IcsSpinner.this.getSelectedItemPosition());
        }

    }

    static interface SpinnerPopup {
        public void dismiss();

        public CharSequence getHintText();

        public boolean isShowing();

        public void setAdapter(ListAdapter var1);

        public void setPromptText(CharSequence var1);

        public void show();
    }

}

