/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 *  android.view.View
 *  android.widget.TextView
 *  android.widget.Toast
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.actionbarsherlock.R;

public class IcsToast
extends Toast {
    public static final int LENGTH_LONG = 1;
    public static final int LENGTH_SHORT = 0;
    private static final String TAG = "Toast";

    public IcsToast(Context context) {
        super(context);
    }

    public static Toast makeText(Context context, int n2, int n3) {
        return IcsToast.makeText(context, context.getResources().getString(n2), n3);
    }

    public static Toast makeText(Context context, CharSequence charSequence, int n2) {
        if (Build.VERSION.SDK_INT >= 14) {
            return Toast.makeText((Context)context, (CharSequence)charSequence, (int)n2);
        }
        IcsToast icsToast = new IcsToast(context);
        icsToast.setDuration(n2);
        context = new TextView(context);
        context.setText(charSequence);
        context.setTextColor(-1);
        context.setGravity(17);
        context.setBackgroundResource(R.drawable.abs__toast_frame);
        icsToast.setView((View)context);
        return icsToast;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setText(CharSequence charSequence) {
        if (Build.VERSION.SDK_INT >= 14) {
            super.setText(charSequence);
            return;
        }
        if (this.getView() == null) return;
        try {
            ((TextView)this.getView()).setText(charSequence);
            return;
        }
        catch (ClassCastException var1_2) {
            Log.e((String)"Toast", (String)"This Toast was not created with IcsToast.makeText", (Throwable)var1_2);
            return;
        }
    }
}

