/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.actionbarsherlock.internal.widget;

import android.view.View;

final class IcsView {
    private IcsView() {
    }

    public static int getMeasuredStateInt(View view) {
        return view.getMeasuredWidth() & -16777216 | view.getMeasuredHeight() >> 16 & -256;
    }
}

