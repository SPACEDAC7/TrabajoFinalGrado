/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.IBinder
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewTreeObserver
 *  android.view.ViewTreeObserver$OnScrollChangedListener
 *  android.widget.PopupWindow
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.os.IBinder;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.PopupWindow;
import java.lang.reflect.Field;

public class PopupWindowCompat
extends PopupWindow {
    private static final ViewTreeObserver.OnScrollChangedListener NOP;
    private static final Field superListenerField;
    private ViewTreeObserver.OnScrollChangedListener mSuperScrollListener;
    private ViewTreeObserver mViewTreeObserver;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        Field field;
        field = null;
        try {
            Field field2;
            field = field2 = PopupWindow.class.getDeclaredField("mOnScrollChangedListener");
            field2.setAccessible(true);
            field = field2;
        }
        catch (NoSuchFieldException var1_2) {}
        superListenerField = field;
        NOP = new ViewTreeObserver.OnScrollChangedListener(){

            public void onScrollChanged() {
            }
        };
    }

    public PopupWindowCompat() {
        this.init();
    }

    public PopupWindowCompat(int n2, int n3) {
        super(n2, n3);
        this.init();
    }

    public PopupWindowCompat(Context context) {
        super(context);
        this.init();
    }

    public PopupWindowCompat(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init();
    }

    public PopupWindowCompat(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        this.init();
    }

    public PopupWindowCompat(Context context, AttributeSet attributeSet, int n2, int n3) {
        super(context, attributeSet, n2, n3);
        this.init();
    }

    public PopupWindowCompat(View view) {
        super(view);
        this.init();
    }

    public PopupWindowCompat(View view, int n2, int n3) {
        super(view, n2, n3);
        this.init();
    }

    public PopupWindowCompat(View view, int n2, int n3, boolean bl) {
        super(view, n2, n3, bl);
        this.init();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void init() {
        if (superListenerField == null) return;
        try {
            this.mSuperScrollListener = (ViewTreeObserver.OnScrollChangedListener)superListenerField.get((Object)this);
            superListenerField.set((Object)this, (Object)NOP);
            return;
        }
        catch (Exception var1_1) {
            this.mSuperScrollListener = null;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void registerListener(View view) {
        if (this.mSuperScrollListener != null) {
            view = view.getWindowToken() != null ? view.getViewTreeObserver() : null;
            if (view == this.mViewTreeObserver) return;
            if (this.mViewTreeObserver != null && this.mViewTreeObserver.isAlive()) {
                this.mViewTreeObserver.removeOnScrollChangedListener(this.mSuperScrollListener);
            }
            this.mViewTreeObserver = view;
            if (view != null) {
                view.addOnScrollChangedListener(this.mSuperScrollListener);
            }
        }
    }

    private void unregisterListener() {
        if (this.mSuperScrollListener != null && this.mViewTreeObserver != null) {
            if (this.mViewTreeObserver.isAlive()) {
                this.mViewTreeObserver.removeOnScrollChangedListener(this.mSuperScrollListener);
            }
            this.mViewTreeObserver = null;
        }
    }

    public void dismiss() {
        super.dismiss();
        this.unregisterListener();
    }

    public void showAsDropDown(View view, int n2, int n3) {
        super.showAsDropDown(view, n2, n3);
        this.registerListener(view);
    }

    public void showAtLocation(View view, int n2, int n3, int n4) {
        super.showAtLocation(view, n2, n3, n4);
        this.unregisterListener();
    }

    public void update(View view, int n2, int n3) {
        super.update(view, n2, n3);
        this.registerListener(view);
    }

    public void update(View view, int n2, int n3, int n4, int n5) {
        super.update(view, n2, n3, n4, n5);
        this.registerListener(view);
    }

}

