/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 */
package com.actionbarsherlock.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.actionbarsherlock.internal.widget.IcsLinearLayout;

public class TabsLinearLayout
extends IcsLinearLayout {
    private static final int LinearLayout_measureWithLargestChild = 0;
    private static final int[] R_styleable_LinearLayout = new int[]{16843476};
    private boolean mUseLargestChild;

    public TabsLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        context = context.obtainStyledAttributes(attributeSet, R_styleable_LinearLayout);
        this.mUseLargestChild = context.getBoolean(0, false);
        context.recycle();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void useLargestChildHorizontal() {
        int n2 = this.getChildCount();
        int n3 = 0;
        int n4 = 0;
        do {
            if (n3 >= n2) break;
            n4 = Math.max(this.getChildAt(n3).getMeasuredWidth(), n4);
            ++n3;
        } while (true);
        int n5 = 0;
        n3 = 0;
        do {
            if (n5 >= n2) {
                this.setMeasuredDimension(this.getPaddingLeft() + this.getPaddingRight() + n3, this.getMeasuredHeight());
                return;
            }
            View view = this.getChildAt(n5);
            if (view != null && view.getVisibility() != 8) {
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
                if (layoutParams.weight > 0.0f) {
                    view.measure(View.MeasureSpec.makeMeasureSpec((int)n4, (int)1073741824), View.MeasureSpec.makeMeasureSpec((int)view.getMeasuredHeight(), (int)1073741824));
                    n3 += n4;
                } else {
                    n3 += view.getMeasuredWidth();
                }
                int n6 = layoutParams.leftMargin;
                n3 = layoutParams.rightMargin + n6 + n3;
            }
            ++n5;
        } while (true);
    }

    public boolean isMeasureWithLargestChildEnabled() {
        return this.mUseLargestChild;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void onMeasure(int n2, int n3) {
        super.onMeasure(n2, n3);
        if (this.getChildCount() <= 2) {
            return;
        }
        n2 = View.MeasureSpec.getMode((int)n2);
        if (!this.mUseLargestChild) return;
        if (n2 != 0) return;
        if (this.getOrientation() != 0) return;
        this.useLargestChildHorizontal();
    }

    public void setMeasureWithLargestChildEnabled(boolean bl) {
        this.mUseLargestChild = bl;
    }
}

