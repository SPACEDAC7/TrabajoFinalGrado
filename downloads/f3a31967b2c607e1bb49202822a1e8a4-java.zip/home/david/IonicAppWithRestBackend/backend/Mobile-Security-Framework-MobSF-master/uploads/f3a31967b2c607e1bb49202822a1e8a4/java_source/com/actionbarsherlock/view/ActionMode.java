/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.actionbarsherlock.view;

import android.view.View;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;

public abstract class ActionMode {
    private Object mTag;

    public abstract void finish();

    public abstract View getCustomView();

    public abstract Menu getMenu();

    public abstract MenuInflater getMenuInflater();

    public abstract CharSequence getSubtitle();

    public Object getTag() {
        return this.mTag;
    }

    public abstract CharSequence getTitle();

    public abstract void invalidate();

    public boolean isUiFocusable() {
        return true;
    }

    public abstract void setCustomView(View var1);

    public abstract void setSubtitle(int var1);

    public abstract void setSubtitle(CharSequence var1);

    public void setTag(Object object) {
        this.mTag = object;
    }

    public abstract void setTitle(int var1);

    public abstract void setTitle(CharSequence var1);

    public static interface Callback {
        public boolean onActionItemClicked(ActionMode var1, MenuItem var2);

        public boolean onCreateActionMode(ActionMode var1, Menu var2);

        public void onDestroyActionMode(ActionMode var1);

        public boolean onPrepareActionMode(ActionMode var1, Menu var2);
    }

}

