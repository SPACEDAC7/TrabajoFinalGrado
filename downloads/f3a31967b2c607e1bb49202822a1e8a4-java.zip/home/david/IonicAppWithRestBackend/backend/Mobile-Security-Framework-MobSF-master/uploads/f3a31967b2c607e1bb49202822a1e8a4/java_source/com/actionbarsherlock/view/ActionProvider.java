/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 */
package com.actionbarsherlock.view;

import android.content.Context;
import android.view.View;
import com.actionbarsherlock.view.SubMenu;

public abstract class ActionProvider {
    private SubUiVisibilityListener mSubUiVisibilityListener;

    public ActionProvider(Context context) {
    }

    public boolean hasSubMenu() {
        return false;
    }

    public abstract View onCreateActionView();

    public boolean onPerformDefaultAction() {
        return false;
    }

    public void onPrepareSubMenu(SubMenu subMenu) {
    }

    public void setSubUiVisibilityListener(SubUiVisibilityListener subUiVisibilityListener) {
        this.mSubUiVisibilityListener = subUiVisibilityListener;
    }

    public void subUiVisibilityChanged(boolean bl) {
        if (this.mSubUiVisibilityListener != null) {
            this.mSubUiVisibilityListener.onSubUiVisibilityChanged(bl);
        }
    }

    public static interface SubUiVisibilityListener {
        public void onSubUiVisibilityChanged(boolean var1);
    }

}

