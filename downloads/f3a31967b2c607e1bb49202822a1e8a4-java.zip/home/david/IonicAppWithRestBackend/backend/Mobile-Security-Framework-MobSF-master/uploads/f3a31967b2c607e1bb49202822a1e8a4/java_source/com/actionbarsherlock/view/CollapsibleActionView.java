/*
 * Decompiled with CFR 0_115.
 */
package com.actionbarsherlock.view;

public interface CollapsibleActionView {
    public void onActionViewCollapsed();

    public void onActionViewExpanded();
}

