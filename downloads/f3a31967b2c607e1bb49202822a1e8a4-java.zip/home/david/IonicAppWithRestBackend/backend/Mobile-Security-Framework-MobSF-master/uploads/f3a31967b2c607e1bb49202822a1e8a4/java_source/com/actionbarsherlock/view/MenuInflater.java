/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.util.TypedValue
 *  android.view.InflateException
 *  android.view.View
 *  org.xmlpull.v1.XmlPullParser
 *  org.xmlpull.v1.XmlPullParserException
 */
package com.actionbarsherlock.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.InflateException;
import android.view.View;
import com.actionbarsherlock.R;
import com.actionbarsherlock.internal.view.menu.MenuItemImpl;
import com.actionbarsherlock.view.ActionProvider;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.actionbarsherlock.view.SubMenu;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class MenuInflater {
    private static final Class<?>[] ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE;
    private static final Class<?>[] ACTION_VIEW_CONSTRUCTOR_SIGNATURE;
    private static final String LOG_TAG = "MenuInflater";
    private static final int NO_ID = 0;
    private static final String XML_GROUP = "group";
    private static final String XML_ITEM = "item";
    private static final String XML_MENU = "menu";
    private final Object[] mActionProviderConstructorArguments;
    private final Object[] mActionViewConstructorArguments;
    private Context mContext;
    private Object mRealOwner;

    static {
        Class[] arrclass = new Class[]{Context.class};
        ACTION_VIEW_CONSTRUCTOR_SIGNATURE = arrclass;
        ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE = arrclass;
    }

    public MenuInflater(Context context) {
        this.mContext = context;
        this.mRealOwner = context;
        this.mActionProviderConstructorArguments = this.mActionViewConstructorArguments = new Object[]{context};
    }

    public MenuInflater(Context context, Object object) {
        this.mContext = context;
        this.mRealOwner = object;
        this.mActionProviderConstructorArguments = this.mActionViewConstructorArguments = new Object[]{context};
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void parseMenu(XmlPullParser var1_1, AttributeSet var2_2, Menu var3_3) throws XmlPullParserException, IOException {
        block18 : {
            var9_4 = new MenuState((Menu)var3_3);
            var4_5 = var1_1.getEventType();
            do {
                if (var4_5 == 2) {
                    var3_3 = var1_1.getName();
                    if (var3_3.equals("menu") == false) throw new RuntimeException("Expecting menu, got " + (String)var3_3);
                    var4_5 = var1_1.next();
                    break block18;
                }
                var4_5 = var5_6 = var1_1.next();
            } while (var5_6 != 1);
            var4_5 = var5_6;
        }
        var3_3 = null;
        var7_7 = 0;
        var6_8 = var4_5;
        var5_6 = 0;
        var4_5 = var7_7;
        block6 : do {
            if (var5_6 != 0) {
                return;
            }
            switch (var6_8) {
                case 2: {
                    if (var4_5 == 0) {
                        var8_9 = var1_1.getName();
                        if (var8_9.equals("group")) {
                            var9_4.readGroup(var2_2);
                            ** break;
                        }
                        if (var8_9.equals("item")) {
                            var9_4.readItem(var2_2);
                            ** break;
                        }
                        if (var8_9.equals("menu")) {
                            this.parseMenu(var1_1, var2_2, var9_4.addSubMenuItem());
                            ** break;
                        }
                        var3_3 = var8_9;
                        var4_5 = 1;
                        ** break;
                    }
                    ** GOTO lbl57
                }
                case 3: {
                    var8_9 = var1_1.getName();
                    if (var4_5 != 0 && var8_9.equals(var3_3)) {
                        var3_3 = null;
                        var4_5 = 0;
                        ** break;
                    }
                    if (var8_9.equals("group")) {
                        var9_4.resetGroup();
                        ** break;
                    }
                    if (!var8_9.equals("item")) ** GOTO lbl55
                    if (!var9_4.hasAddedItem()) {
                        if (MenuState.access$0(var9_4) != null && MenuState.access$0(var9_4).hasSubMenu()) {
                            var9_4.addSubMenuItem();
                            ** break;
                        }
                        var9_4.addItem();
                        ** break;
                    }
                    ** GOTO lbl57
lbl55: // 1 sources:
                    if (var8_9.equals("menu")) {
                        var5_6 = 1;
                    }
                }
lbl57: // 14 sources:
                default: {
                    var6_8 = var1_1.next();
                    continue block6;
                }
                case 1: 
            }
            break;
        } while (true);
        throw new RuntimeException("Unexpected end of document");
    }

    /*
     * Exception decompiling
     */
    public void inflate(int var1_1, Menu var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[CATCHBLOCK]], but top level block is 5[CATCHBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    static class InflatedOnMenuItemClickListener
    implements MenuItem.OnMenuItemClickListener {
        private static final Class<?>[] PARAM_TYPES = new Class[]{MenuItem.class};
        private Method mMethod;
        private Object mRealOwner;

        public InflatedOnMenuItemClickListener(Object object, String string2) {
            this.mRealOwner = object;
            Class class_ = object.getClass();
            try {
                this.mMethod = class_.getMethod(string2, PARAM_TYPES);
                return;
            }
            catch (Exception var1_2) {
                string2 = new InflateException("Couldn't resolve menu item onClick handler " + string2 + " in class " + class_.getName());
                string2.initCause((Throwable)var1_2);
                throw string2;
            }
        }

        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            try {
                if (this.mMethod.getReturnType() == Boolean.TYPE) {
                    return (Boolean)this.mMethod.invoke(this.mRealOwner, menuItem);
                }
                this.mMethod.invoke(this.mRealOwner, menuItem);
                return true;
            }
            catch (Exception var1_2) {
                throw new RuntimeException(var1_2);
            }
        }
    }

    class MenuState {
        private static final int defaultGroupId = 0;
        private static final int defaultItemCategory = 0;
        private static final int defaultItemCheckable = 0;
        private static final boolean defaultItemChecked = false;
        private static final boolean defaultItemEnabled = true;
        private static final int defaultItemId = 0;
        private static final int defaultItemOrder = 0;
        private static final boolean defaultItemVisible = true;
        private int groupCategory;
        private int groupCheckable;
        private boolean groupEnabled;
        private int groupId;
        private int groupOrder;
        private boolean groupVisible;
        private ActionProvider itemActionProvider;
        private String itemActionProviderClassName;
        private String itemActionViewClassName;
        private int itemActionViewLayout;
        private boolean itemAdded;
        private char itemAlphabeticShortcut;
        private int itemCategoryOrder;
        private int itemCheckable;
        private boolean itemChecked;
        private boolean itemEnabled;
        private int itemIconResId;
        private int itemId;
        private String itemListenerMethodName;
        private char itemNumericShortcut;
        private int itemShowAsAction;
        private CharSequence itemTitle;
        private CharSequence itemTitleCondensed;
        private boolean itemVisible;
        private Menu menu;

        public MenuState(Menu menu) {
            this.menu = menu;
            this.resetGroup();
        }

        static /* synthetic */ ActionProvider access$0(MenuState menuState) {
            return menuState.itemActionProvider;
        }

        private char getShortcut(String string2) {
            if (string2 == null) {
                return '\u0000';
            }
            return string2.charAt(0);
        }

        private <T> T newInstance(String string2, Class<?>[] object, Object[] arrobject) {
            try {
                object = MenuInflater.this.mContext.getClassLoader().loadClass(string2).getConstructor(object).newInstance(arrobject);
            }
            catch (Exception var2_3) {
                Log.w((String)"MenuInflater", (String)("Cannot instantiate class: " + string2), (Throwable)var2_3);
                return null;
            }
            return (T)object;
        }

        /*
         * Enabled aggressive block sorting
         */
        private void setItem(MenuItem menuItem) {
            boolean bl = true;
            MenuItem menuItem2 = menuItem.setChecked(this.itemChecked).setVisible(this.itemVisible).setEnabled(this.itemEnabled);
            boolean bl2 = this.itemCheckable > 0;
            menuItem2.setCheckable(bl2).setTitleCondensed(this.itemTitleCondensed).setIcon(this.itemIconResId).setAlphabeticShortcut(this.itemAlphabeticShortcut).setNumericShortcut(this.itemNumericShortcut);
            if (this.itemShowAsAction >= 0) {
                menuItem.setShowAsAction(this.itemShowAsAction);
            }
            if (this.itemListenerMethodName != null) {
                if (MenuInflater.this.mContext.isRestricted()) {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
                menuItem.setOnMenuItemClickListener(new InflatedOnMenuItemClickListener(MenuInflater.this.mRealOwner, this.itemListenerMethodName));
            }
            if (this.itemCheckable >= 2) {
                if (menuItem instanceof MenuItemImpl) {
                    ((MenuItemImpl)menuItem).setExclusiveCheckable(true);
                } else {
                    this.menu.setGroupCheckable(this.groupId, true, true);
                }
            }
            if (this.itemActionViewClassName != null) {
                menuItem.setActionView((View)this.newInstance(this.itemActionViewClassName, ACTION_VIEW_CONSTRUCTOR_SIGNATURE, MenuInflater.this.mActionViewConstructorArguments));
            } else {
                bl = false;
            }
            if (this.itemActionViewLayout > 0) {
                if (!bl) {
                    menuItem.setActionView(this.itemActionViewLayout);
                } else {
                    Log.w((String)"MenuInflater", (String)"Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                }
            }
            if (this.itemActionProvider != null) {
                menuItem.setActionProvider(this.itemActionProvider);
            }
        }

        public void addItem() {
            this.itemAdded = true;
            this.setItem(this.menu.add(this.groupId, this.itemId, this.itemCategoryOrder, this.itemTitle));
        }

        public SubMenu addSubMenuItem() {
            this.itemAdded = true;
            SubMenu subMenu = this.menu.addSubMenu(this.groupId, this.itemId, this.itemCategoryOrder, this.itemTitle);
            this.setItem(subMenu.getItem());
            return subMenu;
        }

        public boolean hasAddedItem() {
            return this.itemAdded;
        }

        public void readGroup(AttributeSet attributeSet) {
            attributeSet = MenuInflater.this.mContext.obtainStyledAttributes(attributeSet, R.styleable.SherlockMenuGroup);
            this.groupId = attributeSet.getResourceId(1, 0);
            this.groupCategory = attributeSet.getInt(3, 0);
            this.groupOrder = attributeSet.getInt(4, 0);
            this.groupCheckable = attributeSet.getInt(5, 0);
            this.groupVisible = attributeSet.getBoolean(2, true);
            this.groupEnabled = attributeSet.getBoolean(0, true);
            attributeSet.recycle();
        }

        /*
         * Enabled aggressive block sorting
         */
        public void readItem(AttributeSet object) {
            int n2;
            int n3 = 1;
            TypedArray typedArray = MenuInflater.this.mContext.obtainStyledAttributes((AttributeSet)object, R.styleable.SherlockMenuItem);
            this.itemId = typedArray.getResourceId(2, 0);
            this.itemCategoryOrder = typedArray.getInt(5, this.groupCategory) & -65536 | typedArray.getInt(6, this.groupOrder) & 65535;
            this.itemTitle = typedArray.getText(7);
            this.itemTitleCondensed = typedArray.getText(8);
            this.itemIconResId = typedArray.getResourceId(0, 0);
            this.itemAlphabeticShortcut = this.getShortcut(typedArray.getString(9));
            this.itemNumericShortcut = this.getShortcut(typedArray.getString(10));
            if (typedArray.hasValue(11)) {
                n2 = typedArray.getBoolean(11, false) ? 1 : 0;
                this.itemCheckable = n2;
            } else {
                this.itemCheckable = this.groupCheckable;
            }
            this.itemChecked = typedArray.getBoolean(3, false);
            this.itemVisible = typedArray.getBoolean(4, this.groupVisible);
            this.itemEnabled = typedArray.getBoolean(1, this.groupEnabled);
            object = new TypedValue();
            typedArray.getValue(13, (TypedValue)object);
            n2 = object.type == 17 ? object.data : -1;
            this.itemShowAsAction = n2;
            this.itemListenerMethodName = typedArray.getString(12);
            this.itemActionViewLayout = typedArray.getResourceId(14, 0);
            object = new TypedValue();
            typedArray.getValue(15, (TypedValue)object);
            object = object.type == 3 ? object.string.toString() : null;
            this.itemActionViewClassName = object;
            object = new TypedValue();
            typedArray.getValue(16, (TypedValue)object);
            object = object.type == 3 ? object.string.toString() : null;
            this.itemActionProviderClassName = object;
            n2 = this.itemActionProviderClassName != null ? n3 : 0;
            if (n2 != 0 && this.itemActionViewLayout == 0 && this.itemActionViewClassName == null) {
                this.itemActionProvider = (ActionProvider)this.newInstance(this.itemActionProviderClassName, ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE, MenuInflater.this.mActionProviderConstructorArguments);
            } else {
                if (n2 != 0) {
                    Log.w((String)"MenuInflater", (String)"Ignoring attribute 'actionProviderClass'. Action view already specified.");
                }
                this.itemActionProvider = null;
            }
            typedArray.recycle();
            this.itemAdded = false;
        }

        public void resetGroup() {
            this.groupId = 0;
            this.groupCategory = 0;
            this.groupOrder = 0;
            this.groupCheckable = 0;
            this.groupVisible = true;
            this.groupEnabled = true;
        }
    }

}

