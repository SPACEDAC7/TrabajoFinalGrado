/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.graphics.drawable.Drawable
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.View
 */
package com.actionbarsherlock.view;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.ContextMenu;
import android.view.View;
import com.actionbarsherlock.view.ActionProvider;
import com.actionbarsherlock.view.SubMenu;

public interface MenuItem {
    public static final int SHOW_AS_ACTION_ALWAYS = 2;
    public static final int SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW = 8;
    public static final int SHOW_AS_ACTION_IF_ROOM = 1;
    public static final int SHOW_AS_ACTION_NEVER = 0;
    public static final int SHOW_AS_ACTION_WITH_TEXT = 4;

    public boolean collapseActionView();

    public boolean expandActionView();

    public ActionProvider getActionProvider();

    public View getActionView();

    public char getAlphabeticShortcut();

    public int getGroupId();

    public Drawable getIcon();

    public Intent getIntent();

    public int getItemId();

    public ContextMenu.ContextMenuInfo getMenuInfo();

    public char getNumericShortcut();

    public int getOrder();

    public SubMenu getSubMenu();

    public CharSequence getTitle();

    public CharSequence getTitleCondensed();

    public boolean hasSubMenu();

    public boolean isActionViewExpanded();

    public boolean isCheckable();

    public boolean isChecked();

    public boolean isEnabled();

    public boolean isVisible();

    public MenuItem setActionProvider(ActionProvider var1);

    public MenuItem setActionView(int var1);

    public MenuItem setActionView(View var1);

    public MenuItem setAlphabeticShortcut(char var1);

    public MenuItem setCheckable(boolean var1);

    public MenuItem setChecked(boolean var1);

    public MenuItem setEnabled(boolean var1);

    public MenuItem setIcon(int var1);

    public MenuItem setIcon(Drawable var1);

    public MenuItem setIntent(Intent var1);

    public MenuItem setNumericShortcut(char var1);

    public MenuItem setOnActionExpandListener(OnActionExpandListener var1);

    public MenuItem setOnMenuItemClickListener(OnMenuItemClickListener var1);

    public MenuItem setShortcut(char var1, char var2);

    public void setShowAsAction(int var1);

    public MenuItem setShowAsActionFlags(int var1);

    public MenuItem setTitle(int var1);

    public MenuItem setTitle(CharSequence var1);

    public MenuItem setTitleCondensed(CharSequence var1);

    public MenuItem setVisible(boolean var1);

    public static interface OnActionExpandListener {
        public boolean onMenuItemActionCollapse(MenuItem var1);

        public boolean onMenuItemActionExpand(MenuItem var1);
    }

    public static interface OnMenuItemClickListener {
        public boolean onMenuItemClick(MenuItem var1);
    }

}

