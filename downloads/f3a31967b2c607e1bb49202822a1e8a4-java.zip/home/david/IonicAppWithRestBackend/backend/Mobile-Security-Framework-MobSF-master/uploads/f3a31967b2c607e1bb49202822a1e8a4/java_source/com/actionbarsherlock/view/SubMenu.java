/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  android.view.View
 */
package com.actionbarsherlock.view;

import android.graphics.drawable.Drawable;
import android.view.View;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;

public interface SubMenu
extends Menu {
    public void clearHeader();

    public MenuItem getItem();

    public SubMenu setHeaderIcon(int var1);

    public SubMenu setHeaderIcon(Drawable var1);

    public SubMenu setHeaderTitle(int var1);

    public SubMenu setHeaderTitle(CharSequence var1);

    public SubMenu setHeaderView(View var1);

    public SubMenu setIcon(int var1);

    public SubMenu setIcon(Drawable var1);
}

