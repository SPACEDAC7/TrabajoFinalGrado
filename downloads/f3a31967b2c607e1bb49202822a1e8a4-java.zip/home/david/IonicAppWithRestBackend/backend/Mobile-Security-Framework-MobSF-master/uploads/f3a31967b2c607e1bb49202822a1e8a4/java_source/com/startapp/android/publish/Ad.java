/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 */
package com.startapp.android.publish;

import android.content.Context;
import android.os.Handler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.adinformation.b;
import com.startapp.android.publish.d.p;
import com.startapp.android.publish.g.h;
import com.startapp.android.publish.g.k;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;
import java.io.Serializable;

public abstract class Ad
implements Serializable {
    private static boolean init = false;
    private static final long serialVersionUID = 1;
    b adInfoOverride = b.a();
    protected transient Context context;
    protected String errorMessage = null;
    protected Serializable extraData = null;
    protected AdPreferences.Placement placement = AdPreferences.Placement.INAPP_FULL_SCREEN;
    private AdState state = AdState.UN_INITIALIZED;

    static {
        init = false;
    }

    public Ad(Context context) {
        this.context = context;
    }

    public b getAdInfoOverride() {
        return this.adInfoOverride;
    }

    public Context getContext() {
        return this.context;
    }

    public String getErrorMessage() {
        return this.errorMessage;
    }

    public Serializable getExtraData() {
        return this.extraData;
    }

    public AdState getState() {
        return this.state;
    }

    public boolean isReady() {
        if (this.state == AdState.READY) {
            return true;
        }
        return false;
    }

    @Deprecated
    public boolean load() {
        return this.load(new AdPreferences(), null);
    }

    @Deprecated
    public boolean load(AdEventListener adEventListener) {
        return this.load(new AdPreferences(), adEventListener);
    }

    @Deprecated
    public boolean load(AdPreferences adPreferences) {
        return this.load(adPreferences, null);
    }

    @Deprecated
    public boolean load(AdPreferences adPreferences, AdEventListener adEventListener) {
        return this.load(adPreferences, adEventListener, true);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected boolean load(final AdPreferences adPreferences, AdEventListener object, boolean bl) {
        boolean bl2;
        Object object2 = new WebView(this.context);
        h.b(this.context, "User-Agent", object2.getSettings().getUserAgentString());
        if (!init) {
            r.c(this.context);
            k.a(this.context);
            init = true;
        }
        r.a(this.context, adPreferences);
        object2 = "";
        if (adPreferences.getPublisherId() == null || "".equals(adPreferences.getPublisherId()) || adPreferences.getProductId() == null || "".equals(adPreferences.getProductId())) {
            object2 = "publisher ID and/or product ID were not set.";
            bl2 = true;
        } else {
            bl2 = false;
        }
        if (this.state != AdState.UN_INITIALIZED) {
            object2 = "load() was already called.";
            bl2 = true;
        }
        if (!r.a(this.context)) {
            object2 = "network not available.";
            bl2 = true;
            if (!bl2) {
                this.setState(AdState.PROCESSING);
                object = new p((AdEventListener)object){
                    final /* synthetic */ AdEventListener b;

                    @Override
                    public void onFailedLoadingMeta() {
                        Ad.this.loadAds(adPreferences, this.b);
                    }

                    @Override
                    public void onFinishLoadingMeta() {
                        Ad.this.loadAds(adPreferences, this.b);
                    }
                };
                MetaData.getInstance().loadFromServer(this.context, adPreferences, bl, (p)object);
                return true;
            }
        }
        this.setErrorMessage("Ad wasn't loaded: " + (String)object2);
        if (object != null) {
            new Handler().post(new Runnable((AdEventListener)object){
                final /* synthetic */ AdEventListener a;

                @Override
                public void run() {
                    this.a.onFailedToReceiveAd(Ad.this);
                }
            });
        }
        return false;
    }

    protected abstract void loadAds(AdPreferences var1, AdEventListener var2);

    public void setAdInfoOverride(b b2) {
        this.adInfoOverride = b2;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public void setErrorMessage(String string2) {
        this.errorMessage = string2;
    }

    public void setExtraData(Serializable serializable) {
        this.extraData = serializable;
    }

    public void setState(AdState adState) {
        this.state = adState;
    }

    @Deprecated
    public boolean show() {
        return false;
    }

    public static enum AdState {
        UN_INITIALIZED,
        PROCESSING,
        READY;
        

        private AdState() {
        }
    }

}

