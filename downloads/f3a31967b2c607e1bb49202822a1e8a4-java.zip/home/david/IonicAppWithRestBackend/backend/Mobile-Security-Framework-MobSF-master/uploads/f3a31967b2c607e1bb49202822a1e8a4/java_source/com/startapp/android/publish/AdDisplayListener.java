/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish;

import com.startapp.android.publish.Ad;

public interface AdDisplayListener {
    public void adClicked(Ad var1);

    public void adDisplayed(Ad var1);

    public void adHidden(Ad var1);
}

