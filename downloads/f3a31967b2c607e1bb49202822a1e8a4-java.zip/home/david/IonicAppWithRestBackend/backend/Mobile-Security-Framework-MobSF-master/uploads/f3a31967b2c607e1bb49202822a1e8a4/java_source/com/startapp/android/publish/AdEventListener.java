/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish;

import com.startapp.android.publish.Ad;

public interface AdEventListener {
    public void onFailedToReceiveAd(Ad var1);

    public void onReceiveAd(Ad var1);
}

