/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.KeyEvent
 *  android.view.Window
 */
package com.startapp.android.publish;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Window;
import com.startapp.android.publish.c.b;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;

public class AppWallActivity
extends Activity {
    private b a;

    private void a() {
        int n2 = this.getIntent().getIntExtra("placement", 0);
        this.a = b.a(this, this.getIntent(), AdPreferences.Placement.getByIndex(n2));
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (this.getIntent().getBooleanExtra("fullscreen", false)) {
            this.requestWindowFeature(1);
            this.getWindow().setFlags(1024, 1024);
        }
        j.a("AppWallActivity", 2, "AppWallActivity::onCreate");
        this.a();
        this.a.a(bundle);
    }

    protected void onDestroy() {
        j.a("AppWallActivity", 2, "AppWallActivity::onDestroy");
        this.a.m();
        r.a(this, false);
        super.onDestroy();
    }

    public boolean onKeyDown(int n2, KeyEvent keyEvent) {
        if (!this.a.a(n2, keyEvent)) {
            return super.onKeyDown(n2, keyEvent);
        }
        return true;
    }

    protected void onPause() {
        j.a("AppWallActivity", 2, "AppWallActivity::onPause");
        super.onPause();
        this.a.k();
        r.b((Context)this);
    }

    protected void onResume() {
        j.a("AppWallActivity", 2, "AppWallActivity::onResume");
        super.onResume();
        this.a.l();
    }
}

