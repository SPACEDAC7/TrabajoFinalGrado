/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.graphics.Bitmap
 *  android.net.Uri
 *  android.os.Bundle
 *  android.webkit.WebChromeClient
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 */
package com.startapp.android.publish;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.startapp.android.publish.g.j;

public class AppWallDelegateActivity
extends Activity {
    private boolean a;

    public void onConfigurationChanged(Configuration configuration) {
        j.a(2, "AppWallActivity::onConfigurationChanged orientation - [" + configuration.orientation + "]");
        super.onConfigurationChanged(configuration);
    }

    protected void onCreate(Bundle object) {
        super.onCreate((Bundle)object);
        object = this.getIntent();
        this.a = object.getBooleanExtra("smartRedirect", true);
        object = object.getStringExtra("clickUrl");
        WebView webView = new WebView(this.getApplicationContext());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient((WebViewClient)new a());
        webView.loadUrl((String)object);
    }

    protected void onDestroy() {
        j.a(2, "AppWallActivity::onDestroy");
        super.onDestroy();
    }

    protected void onPause() {
        j.a(2, "AppWallActivity::onPause");
        super.onPause();
    }

    protected void onRestart() {
        j.a(2, "AppWallActivity::onRestart");
        super.onRestart();
    }

    protected void onResume() {
        j.a(2, "AppWallActivity::onResume");
        super.onResume();
    }

    class a
    extends WebViewClient {
        private a() {
        }

        public void onPageFinished(WebView webView, String string2) {
            j.a(2, "MyWebViewClient::onPageFinished - [" + string2 + "]");
            super.onPageFinished(webView, string2);
        }

        public void onPageStarted(WebView webView, String string2, Bitmap bitmap) {
            j.a(2, "MyWebViewClient::onPageStarted - [" + string2 + "]");
            super.onPageStarted(webView, string2, bitmap);
        }

        public void onReceivedError(WebView webView, int n2, String string2, String string3) {
            super.onReceivedError(webView, n2, string2, string3);
            AppWallDelegateActivity.this.finish();
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean shouldOverrideUrlLoading(WebView webView, String string2) {
            j.a(2, "MyWebViewClient::shouldOverrideUrlLoading - [" + string2 + "]");
            String string3 = string2.toLowerCase();
            boolean bl = string3.startsWith("market") || string3.startsWith("http://play.google.com") || string3.startsWith("https://play.google.com");
            if (!bl && AppWallDelegateActivity.this.a) {
                return false;
            }
            string2 = new Intent("android.intent.action.VIEW", Uri.parse((String)string2));
            string2.addFlags(76021760);
            AppWallDelegateActivity.this.startActivity((Intent)string2);
            if (webView != null) {
                webView.destroy();
            }
            AppWallDelegateActivity.this.finish();
            return true;
        }
    }

}

