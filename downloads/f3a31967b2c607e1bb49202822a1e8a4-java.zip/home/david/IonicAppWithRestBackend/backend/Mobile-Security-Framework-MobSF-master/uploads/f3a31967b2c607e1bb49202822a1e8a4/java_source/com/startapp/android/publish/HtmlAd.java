/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish;

import android.content.Context;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.d;
import com.startapp.android.publish.d.g;
import com.startapp.android.publish.model.AdPreferences;

@Deprecated
public class HtmlAd
extends d {
    public HtmlAd(Context context) {
        super(context);
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
        new g(this.context, this, adPreferences, adEventListener).c();
    }
}

