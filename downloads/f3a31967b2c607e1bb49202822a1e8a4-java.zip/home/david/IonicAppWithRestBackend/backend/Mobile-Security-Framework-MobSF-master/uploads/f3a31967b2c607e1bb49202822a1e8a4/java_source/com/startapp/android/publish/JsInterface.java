/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.text.TextUtils
 *  android.webkit.JavascriptInterface
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.startapp.android.publish;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import android.webkit.JavascriptInterface;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.r;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

public class JsInterface {
    private Runnable clickCallback = null;
    private Runnable closeCallback = null;
    private Context mContext;
    private boolean processed = false;

    public JsInterface(Context context, Runnable runnable) {
        this.closeCallback = runnable;
        this.mContext = context;
    }

    public JsInterface(Context context, Runnable runnable, Runnable runnable2) {
        this(context, runnable);
        this.clickCallback = runnable2;
    }

    @JavascriptInterface
    public void closeAd() {
        if (this.processed) {
            return;
        }
        this.processed = true;
        this.closeCallback.run();
    }

    @JavascriptInterface
    public void openApp(String string2, String string3, String object) {
        if (string2 != null && !TextUtils.isEmpty((CharSequence)string2)) {
            r.b(this.mContext, string2);
        }
        string2 = this.mContext.getPackageManager().getLaunchIntentForPackage(string3);
        if (object != null) {
            try {
                string3 = new JSONObject((String)object);
                object = string3.keys();
                while (object.hasNext()) {
                    String string4 = String.valueOf(object.next());
                    string2.putExtra(string4, String.valueOf(string3.get(string4)));
                }
            }
            catch (JSONException var2_3) {
                j.a(6, "Couldn't parse intent details json!", (Throwable)var2_3);
            }
        }
        this.mContext.startActivity((Intent)string2);
        if (this.clickCallback != null) {
            this.clickCallback.run();
        }
    }
}

