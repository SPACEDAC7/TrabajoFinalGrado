/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish;

import java.io.Serializable;

public class SDKAdPreferences
implements Serializable {
    private static final long serialVersionUID = 1;
    private Integer age = null;
    private Gender gender = null;

    public Integer getAge() {
        return this.age;
    }

    public Gender getGender() {
        return this.gender;
    }

    public SDKAdPreferences setAge(int n2) {
        this.age = n2;
        return this;
    }

    public SDKAdPreferences setGender(Gender gender) {
        this.gender = gender;
        return this;
    }

    public String toString() {
        return "SDKAdPreferences [gender=" + (Object)((Object)this.gender) + ", age=" + this.age + "]";
    }

    public static enum Gender {
        MALE("m"),
        FEMALE("f");
        
        private String gender;

        private Gender(String string3) {
            this.gender = string3;
        }

        public static Gender parseString(String string2) {
            for (Gender gender : Gender.values()) {
                if (!gender.getGender().equals(string2)) continue;
                return gender;
            }
            return null;
        }

        public final String getGender() {
            return this.gender;
        }

        public final String toString() {
            return this.getGender();
        }
    }

}

