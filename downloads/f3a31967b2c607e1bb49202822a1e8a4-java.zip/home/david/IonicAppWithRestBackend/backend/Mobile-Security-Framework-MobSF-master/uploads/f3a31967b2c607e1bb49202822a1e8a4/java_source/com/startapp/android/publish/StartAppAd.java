/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Bundle
 */
package com.startapp.android.publish;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdDisplayListener;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.AppWallActivity;
import com.startapp.android.publish.StartAppSDK;
import com.startapp.android.publish.a.h;
import com.startapp.android.publish.a.i;
import com.startapp.android.publish.a.m;
import com.startapp.android.publish.c;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;
import com.startapp.android.publish.slider.b;
import com.startapp.android.publish.splash.SplashConfig;
import com.startapp.android.publish.splash.SplashHideListener;
import java.io.Serializable;
import java.util.Random;

public class StartAppAd
extends Ad {
    private static final String TAG = "StartAppAd";
    private static final long serialVersionUID = 1;
    private static boolean testMode = false;
    private c ad = null;
    private AdMode adMode = AdMode.AUTOMATIC;
    private AdDisplayListener callback = null;
    private BroadcastReceiver callbackBroadcastReceiver;
    private boolean forceFullpage = false;
    private boolean forceOfferWall2D = false;
    private boolean forceOfferWall3D = false;
    private boolean forceOverlay = false;

    public StartAppAd(Context context) {
        super(context);
        this.callbackBroadcastReceiver = new BroadcastReceiver(){

            /*
             * Enabled aggressive block sorting
             */
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals("com.startapp.android.OnClickCallback")) {
                    StartAppAd.this.callback.adClicked(StartAppAd.this);
                } else {
                    if (StartAppAd.this.callback != null) {
                        StartAppAd.this.callback.adHidden(StartAppAd.this);
                    }
                    context.unregisterReceiver((BroadcastReceiver)this);
                }
                StartAppAd.this.ad = null;
            }
        };
    }

    private void createFullpageSelection() {
        int n2 = MetaData.getInstance().getFullscreenOverlayProbability();
        if ((new Random().nextInt(100) < n2 || this.forceFullpage) && !this.forceOverlay) {
            this.ad = new com.startapp.android.publish.a.c(this.context);
            return;
        }
        this.ad = new com.startapp.android.publish.a.j(this.context);
    }

    private void createOfferwallSelection() {
        int n2 = MetaData.getInstance().getProbability3D();
        if ((new Random().nextInt(100) < n2 || this.forceOfferWall3D) && !this.forceOfferWall2D) {
            this.ad = new h(this.context);
            return;
        }
        this.ad = new i(this.context);
    }

    public static void init(Context context, String string2, String string3) {
        StartAppSDK.init(context, string2, string3);
    }

    private void registerBroadcastReceiver(String string2) {
        this.context.getApplicationContext().registerReceiver(this.callbackBroadcastReceiver, new IntentFilter(string2));
    }

    private void setAdMode(AdMode adMode) {
        this.adMode = adMode;
    }

    public static void showSlider(Activity activity) {
        new b(activity);
    }

    public static void showSlider(Activity activity, AdPreferences adPreferences) {
        new b(activity, adPreferences);
    }

    public static void showSplash(Activity activity, Bundle bundle) {
        StartAppAd.showSplash(activity, bundle, new SplashConfig());
    }

    public static void showSplash(Activity activity, Bundle bundle, AdPreferences adPreferences) {
        StartAppAd.showSplash(activity, bundle, new SplashConfig(), adPreferences);
    }

    public static void showSplash(Activity activity, Bundle bundle, SplashConfig splashConfig) {
        StartAppAd.showSplash(activity, bundle, splashConfig, new AdPreferences());
    }

    public static void showSplash(Activity activity, Bundle bundle, SplashConfig splashConfig, AdPreferences adPreferences) {
        StartAppAd.showSplash(activity, bundle, splashConfig, adPreferences, null);
    }

    public static void showSplash(final Activity activity, Bundle object, SplashConfig splashConfig, AdPreferences adPreferences, final SplashHideListener splashHideListener) {
        if (object == null) {
            splashConfig.setDefaults((Context)activity);
            r.a(activity, true);
            object = new Intent((Context)activity, (Class)AppWallActivity.class);
            object.putExtra("SplashConfig", (Serializable)splashConfig);
            object.putExtra("AdPreference", (Serializable)adPreferences);
            object.putExtra("testMode", testMode);
            object.putExtra("fullscreen", r.a(activity));
            object.putExtra("placement", AdPreferences.Placement.INAPP_SPLASH.getIndex());
            object.addFlags(1140883456);
            activity.startActivity((Intent)object);
            object = new BroadcastReceiver(){

                public final void onReceive(Context context, Intent intent) {
                    r.a(activity, false);
                    if (splashHideListener != null) {
                        splashHideListener.splashHidden();
                    }
                    try {
                        activity.getApplicationContext().unregisterReceiver((BroadcastReceiver)this);
                        return;
                    }
                    catch (Exception var1_2) {
                        j.a(6, "StartAppAd::showSplash::onReceive - [" + var1_2.getClass() + "]");
                        return;
                    }
                }
            };
            activity.getApplicationContext().registerReceiver((BroadcastReceiver)object, new IntentFilter("com.startapp.android.splashHidden"));
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void close() {
        if (this.callbackBroadcastReceiver != null) {
            try {
                this.context.unregisterReceiver(this.callbackBroadcastReceiver);
            }
            catch (IllegalArgumentException var1_1) {}
        }
        Intent intent = new Intent("com.startapp.android.CloseAdActivity");
        this.context.sendBroadcast(intent);
    }

    protected String getLauncherName() {
        if (this.ad != null) {
            return this.ad.getLauncherName();
        }
        return r.e(this.getContext());
    }

    @Override
    public Ad.AdState getState() {
        if (this.ad != null) {
            return this.ad.getState();
        }
        return Ad.AdState.UN_INITIALIZED;
    }

    @Override
    public boolean isReady() {
        boolean bl = false;
        if (this.ad != null) {
            bl = this.ad.isReady();
        }
        return bl;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Deprecated
    @Override
    public boolean load(AdPreferences var1_1, AdEventListener var2_2) {
        if (this.adMode == AdMode.AUTOMATIC && this.ad != null && this.ad.isReady()) {
            if (var2_2 == null) return true;
            var2_2.onReceiveAd(this);
            return true;
        }
        r.a(this.context, var1_1);
        var4_3 = null;
        if (var2_2 != null) {
            var4_3 = new a(var2_2);
        }
        switch (.a[this.adMode.ordinal()]) {
            case 1: {
                var3_4 = MetaData.getInstance().getHtml3DProbability();
                if (new Random().nextInt(100) < var3_4) {
                    this.createFullpageSelection();
                    ** break;
                }
                this.createOfferwallSelection();
                ** break;
            }
            case 2: {
                this.ad = new com.startapp.android.publish.a.c(this.context);
                ** break;
            }
            case 3: {
                this.ad = new com.startapp.android.publish.a.j(this.context);
            }
lbl22: // 5 sources:
            default: {
                ** GOTO lbl26
            }
            case 4: 
        }
        this.createOfferwallSelection();
lbl26: // 2 sources:
        j.a(4, "ad Type: [" + this.ad.getClass().toString() + "]");
        return this.ad.load(var1_1, var4_3);
    }

    public void loadAd() {
        this.loadAd(AdMode.AUTOMATIC, new AdPreferences(), null);
    }

    public void loadAd(AdEventListener adEventListener) {
        this.loadAd(AdMode.AUTOMATIC, new AdPreferences(), adEventListener);
    }

    public void loadAd(AdMode adMode) {
        this.loadAd(adMode, new AdPreferences(), null);
    }

    public void loadAd(AdMode adMode, AdEventListener adEventListener) {
        this.loadAd(adMode, new AdPreferences(), adEventListener);
    }

    public void loadAd(AdMode adMode, AdPreferences adPreferences) {
        this.loadAd(adMode, adPreferences, null);
    }

    public void loadAd(AdMode adMode, AdPreferences adPreferences, AdEventListener adEventListener) {
        this.adMode = adMode;
        this.load(adPreferences, adEventListener);
    }

    public void loadAd(AdPreferences adPreferences) {
        this.loadAd(AdMode.AUTOMATIC, adPreferences, null);
    }

    public void loadAd(AdPreferences adPreferences, AdEventListener adEventListener) {
        this.loadAd(AdMode.AUTOMATIC, adPreferences, adEventListener);
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
    }

    public void loadSplash(AdPreferences adPreferences, AdEventListener adEventListener) {
        this.ad = new m(this.context);
        this.ad.load(adPreferences, adEventListener);
    }

    public void onBackPressed() {
        if (this.showAd()) {
            StartAppSDK.getInstance().onBackPressed();
            return;
        }
        j.a("StartAppAd", 3, "Could not display StartAppAd onBackPressed");
    }

    public void onPause() {
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onRestoreInstanceState(Bundle bundle) {
        int n2 = bundle.getInt("AdMode");
        this.adMode = AdMode.AUTOMATIC;
        if (n2 == 1) {
            this.adMode = AdMode.FULLPAGE;
        } else if (n2 == 2) {
            this.adMode = AdMode.OFFERWALL;
        } else if (n2 == 3) {
            this.adMode = AdMode.OVERLAY;
        }
        this.load();
    }

    public void onResume() {
        if (!this.isReady()) {
            this.loadAd();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void onSaveInstanceState(Bundle var1_1) {
        var2_2 = 0;
        switch (.a[this.adMode.ordinal()]) {
            case 2: {
                var2_2 = 1;
                ** break;
            }
            case 4: {
                var2_2 = 2;
            }
lbl8: // 3 sources:
            default: {
                ** GOTO lbl12
            }
            case 3: 
        }
        var2_2 = 3;
lbl12: // 2 sources:
        var1_1.putInt("AdMode", var2_2);
    }

    @Deprecated
    @Override
    public boolean show() {
        return this.show(null);
    }

    @Deprecated
    public boolean show(AdDisplayListener adDisplayListener) {
        boolean bl = false;
        this.callback = adDisplayListener;
        boolean bl2 = bl;
        if (this.ad != null) {
            bl2 = bl;
            if (this.ad.show()) {
                bl2 = true;
            }
        }
        if (this.callback != null && bl2) {
            this.callback.adDisplayed(this);
            this.registerBroadcastReceiver("com.startapp.android.HideDisplayBroadcastListener");
            this.registerBroadcastReceiver("com.startapp.android.OnClickCallback");
        }
        return bl2;
    }

    public boolean showAd() {
        return this.showAd(null);
    }

    public boolean showAd(AdDisplayListener adDisplayListener) {
        return this.show(adDisplayListener);
    }

    public static enum AdMode {
        AUTOMATIC,
        FULLPAGE,
        OFFERWALL,
        OVERLAY;
        

        private AdMode() {
        }
    }

    class a
    implements AdEventListener {
        private boolean b;
        private AdEventListener c;
        private boolean d;

        public a(AdEventListener adEventListener) {
            this.b = false;
            this.c = null;
            this.d = false;
            this.c = adEventListener;
        }

        @Override
        public void onFailedToReceiveAd(Ad ad) {
            if (!this.d) {
                this.c.onFailedToReceiveAd(StartAppAd.this);
            }
            this.d = true;
        }

        @Override
        public void onReceiveAd(Ad ad) {
            if (!this.b) {
                this.b = true;
                this.c.onReceiveAd(StartAppAd.this);
            }
        }
    }

}

