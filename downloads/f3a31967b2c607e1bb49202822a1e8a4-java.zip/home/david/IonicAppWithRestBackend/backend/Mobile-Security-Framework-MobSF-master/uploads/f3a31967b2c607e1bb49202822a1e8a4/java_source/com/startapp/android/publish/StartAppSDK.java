/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.Process
 */
package com.startapp.android.publish;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.os.Process;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.SDKAdPreferences;
import com.startapp.android.publish.a.k;
import com.startapp.android.publish.b;
import com.startapp.android.publish.d.p;
import com.startapp.android.publish.g.h;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.o;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.gson.Gson;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;
import com.startapp.android.publish.model.SdkDownloadRequest;
import java.util.HashMap;

public class StartAppSDK {
    private SDKAdPreferences a;
    private boolean b;
    private boolean c = false;
    private long d;
    private Application e = null;
    private k f = null;
    private HashMap<Integer, Integer> g = new HashMap();
    private boolean h = false;
    private Object i;
    private boolean j = false;
    private AdEventListener k;

    private StartAppSDK() {
        this.k = new AdEventListener(){

            @Override
            public void onFailedToReceiveAd(Ad ad) {
                StartAppSDK.this.h = false;
            }

            @Override
            public void onReceiveAd(Ad ad) {
                StartAppSDK.this.h = false;
            }
        };
    }

    private void a(final Context context) {
        boolean bl = h.a(context, "shared_prefs_first_init", true);
        j.a("StartAppSDK", 3, "First Initialization: [" + bl + "]");
        if (bl) {
            j.a("StartAppSDK", 3, "Sending Download Event");
            new Thread(new Runnable(){

                @Override
                public void run() {
                    Process.setThreadPriority((int)10);
                    try {
                        SdkDownloadRequest sdkDownloadRequest = new SdkDownloadRequest();
                        AdPreferences adPreferences = new AdPreferences();
                        r.a(context, adPreferences);
                        sdkDownloadRequest.fillApplicationDetails(context, adPreferences);
                        com.startapp.android.publish.f.a.a(context, b.a(b.a.d), sdkDownloadRequest, null);
                        return;
                    }
                    catch (o var1_2) {
                        j.a(6, "Error occured while sending download event", var1_2);
                        return;
                    }
                }
            }).start();
            h.b(context, "shared_prefs_first_init", false);
        }
    }

    private void a(Context context, String object, String string2, SDKAdPreferences sDKAdPreferences, boolean bl) {
        MetaData.init(context);
        if (!this.j) {
            this.j = true;
            j.a("StartAppSDK", 3, "Initialize StartAppSDK with DevID:[" + (String)object + "], AppID:[" + string2 + "]");
            r.b(context, (String)object, string2);
            this.a = sDKAdPreferences;
            h.b(context, "shared_prefs_sdk_ad_prefs", new Gson().toJson(sDKAdPreferences));
            this.a(context);
        }
        object = new AdPreferences();
        r.a(context, (AdPreferences)object);
        MetaData.getInstance().loadFromServer(context, (AdPreferences)object, false, null);
        this.a(context, bl);
        if (context instanceof Activity && this.isReturnAdsEnabled()) {
            this.registerApplicationLifeCycle((Activity)context);
        }
    }

    private void a(Context context, boolean bl) {
        this.b = false;
        if (com.startapp.android.publish.g.b.b()) {
            this.b = bl;
            j.a("StartAppSDK", 3, "Return Ads: [" + bl + "]");
            return;
        }
        j.a("StartAppSDK", 6, "Cannot activate return ads - api lower than 14");
    }

    private void a(boolean bl) {
        this.b = bl;
    }

    private boolean a() {
        if (System.currentTimeMillis() - this.d > MetaData.getInstance().getReturnAdMinBackgroundTime()) {
            return true;
        }
        return false;
    }

    public static StartAppSDK getInstance() {
        return a;
    }

    public static void init(Context context, String string2, String string3) {
        StartAppSDK.init(context, string2, string3, new SDKAdPreferences());
    }

    public static void init(Context context, String string2, String string3, SDKAdPreferences sDKAdPreferences) {
        StartAppSDK.getInstance().a(context, string2, string3, sDKAdPreferences, true);
    }

    public static void init(Context context, String string2, String string3, SDKAdPreferences sDKAdPreferences, boolean bl) {
        StartAppSDK.getInstance().a(context, string2, string3, sDKAdPreferences, bl);
    }

    public static void init(Context context, String string2, String string3, boolean bl) {
        StartAppSDK.init(context, string2, string3, new SDKAdPreferences(), bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    public SDKAdPreferences getSDKAdPrefs(Context object) {
        if (this.a != null) return this.a;
        if ((object = h.a((Context)object, "shared_prefs_sdk_ad_prefs", "")).equals("")) {
            this.a = new SDKAdPreferences();
            return this.a;
        }
        this.a = (SDKAdPreferences)new Gson().fromJson((String)object, SDKAdPreferences.class);
        return this.a;
    }

    public boolean isReturnAdsEnabled() {
        return this.b;
    }

    public void loadReturnAd() {
        this.loadReturnAd(new AdPreferences());
    }

    public void loadReturnAd(AdPreferences adPreferences) {
        if (this.f != null && this.isReturnAdsEnabled() && !MetaData.getInstance().isDisableReturnAd() && !this.h) {
            this.h = true;
            this.f.load(adPreferences, this.k);
        }
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
        if (bundle != null) {
            this.c = true;
            if (this.f == null) {
                this.f = com.startapp.android.publish.b.a.a().a((Context)activity);
            }
            return;
        }
        this.c = false;
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        if (this.f != null) {
            com.startapp.android.publish.b.a.a().a((Context)activity, this.f);
        }
    }

    public void onActivityStarted(Activity activity) {
        j.a("StartAppSDK", 3, "onActivityStarted [" + activity.getClass().getName() + "]");
        if (this.f == null) {
            this.f = new k(activity.getApplicationContext());
        }
        if (this.c && !MetaData.getInstance().isDisableReturnAd()) {
            this.c = false;
            if (this.a()) {
                this.f.show();
            }
            this.loadReturnAd();
        }
        if (this.g.get(activity.hashCode()) == null) {
            Integer n2 = new Integer(0);
            this.loadReturnAd();
            int n3 = n2;
            this.g.put(activity.hashCode(), n3 + 1);
            j.a("StartAppSDK", 3, "Activity Added:[" + activity.getClass().getName() + "]");
            return;
        }
        j.a("StartAppSDK", 3, "Activity [" + activity.getClass().getName() + "] already exists");
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onActivityStopped(Activity activity) {
        j.a("StartAppSDK", 3, "onActivityStopped [" + activity.getClass().getName() + "]");
        Integer n2 = this.g.get(activity.hashCode());
        if (n2 == null) {
            j.a("StartAppSDK", 3, "Activity hadn't been found:[" + activity.getClass().getName() + "]");
            return;
        }
        if ((n2 = Integer.valueOf(n2 - 1)) == 0) {
            this.g.remove(activity.hashCode());
        } else {
            this.g.put(activity.hashCode(), n2);
        }
        j.a("StartAppSDK", 3, "Activity removed:[" + activity.getClass().getName() + "]");
        if (this.g.size() == 0) {
            this.loadReturnAd();
            this.c = true;
            this.d = System.currentTimeMillis();
        }
    }

    public void onBackPressed() {
        this.c = false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void registerApplicationLifeCycle(Activity activity) {
        this.e = activity.getApplication();
        try {
            if (this.i != null && this.e != null) {
                com.startapp.android.publish.g.b.a(this.e, this.i);
                j.a("StartAppSDK", 3, "Unregistered LifeCycle Callbacks");
            }
        }
        catch (Exception var1_2) {}
        j.a("StartAppSDK", 3, "Registring LifeCycle Callbacks");
        this.i = com.startapp.android.publish.g.b.a(this.e);
    }

    static class a {
        private static final StartAppSDK a = new StartAppSDK();
    }

}

