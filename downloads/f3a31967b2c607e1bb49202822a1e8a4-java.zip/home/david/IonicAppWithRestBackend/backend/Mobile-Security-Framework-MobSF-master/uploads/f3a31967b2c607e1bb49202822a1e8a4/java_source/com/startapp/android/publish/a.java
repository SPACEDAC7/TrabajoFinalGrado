/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish;

import java.io.Serializable;

public class a
implements Serializable {
    private static final long serialVersionUID = 1;
    private int adAttempt = 0;
    private boolean appPresence = false;
    private boolean isShown = true;
    private int minAppVersion = 0;
    private String packageName;
    private String trackingUrl;

    public a(String string2, String string3, int n2, int n3) {
        this.trackingUrl = string2;
        this.packageName = string3;
        this.adAttempt = n2;
        this.minAppVersion = n3;
    }

    public String a() {
        return this.trackingUrl;
    }

    public void a(String string2) {
        this.trackingUrl = string2;
    }

    public void a(boolean bl) {
        this.isShown = bl;
    }

    public String b() {
        return this.packageName;
    }

    public void b(boolean bl) {
        this.appPresence = bl;
    }

    public boolean c() {
        return this.isShown;
    }

    public boolean d() {
        return this.appPresence;
    }

    public int e() {
        return this.minAppVersion;
    }
}

