/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.a;

import android.content.Context;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.d;
import com.startapp.android.publish.d.f;
import com.startapp.android.publish.model.AdPreferences;

public class b
extends d {
    private static final long serialVersionUID = 1;
    private int offset = 0;

    public b(Context context) {
        super(context);
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
        new f(this.context, this, this.offset, adPreferences, adEventListener).c();
        ++this.offset;
    }
}

