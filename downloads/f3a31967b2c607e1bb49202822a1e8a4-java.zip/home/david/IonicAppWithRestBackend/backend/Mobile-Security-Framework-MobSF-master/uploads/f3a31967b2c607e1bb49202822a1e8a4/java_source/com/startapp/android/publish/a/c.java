/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.a;

import android.content.Context;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.d;
import com.startapp.android.publish.a.e;
import com.startapp.android.publish.d.g;
import com.startapp.android.publish.model.AdPreferences;

public class c
extends e {
    private static final long serialVersionUID = 1;

    public c(Context context) {
        super(context);
        this.setPlacement(AdPreferences.Placement.INAPP_FULL_SCREEN);
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
        new g(this.context, this, adPreferences, adEventListener).c();
    }
}

