/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.a;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.a;
import com.startapp.android.publish.adinformation.AdInformationPositions;
import com.startapp.android.publish.adinformation.b;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import java.util.List;

public abstract class d
extends Ad {
    protected static String launcherName = null;
    private static final long serialVersionUID = 1;
    private String adId = null;
    private List<a> apps;
    private int height;
    private String htmlUuid = "";
    public boolean[] smartRedirect = new boolean[]{false};
    private String[] trackingClickUrls = new String[]{""};
    public String[] trackingUrls = new String[]{""};
    private int width;

    public d(Context context) {
        super(context);
        if (launcherName == null) {
            this.initDefaultLauncherName();
        }
    }

    private void initDefaultLauncherName() {
        launcherName = r.e(this.getContext());
    }

    private void setAdInfoEnableOverride(String string2) {
        boolean bl = Boolean.parseBoolean(string2);
        this.getAdInfoOverride().a(bl);
    }

    private void setAdInfoPositionOverrid(String string2) {
        this.getAdInfoOverride().a(AdInformationPositions.Position.getByName(string2));
    }

    /*
     * Enabled aggressive block sorting
     */
    private void setSmartRedirect(String arrstring) {
        arrstring = arrstring.split(",");
        this.smartRedirect = new boolean[arrstring.length];
        int n2 = 0;
        while (n2 < arrstring.length) {
            this.smartRedirect[n2] = arrstring[n2].compareTo("true") == 0;
            ++n2;
        }
    }

    private void setTrackingClickUrl(String string2) {
        this.trackingClickUrls = string2.split(",");
    }

    private void setTrackingUrls(String string2) {
        this.trackingUrls = string2.split(",");
    }

    public List<a> getApps() {
        return this.apps;
    }

    public int getHeight() {
        return this.height;
    }

    public String getHtml() {
        return com.startapp.android.publish.b.a.a().b(this.htmlUuid);
    }

    public String getHtmlUuid() {
        return this.htmlUuid;
    }

    protected String getLauncherName() {
        return launcherName;
    }

    public AdPreferences.Placement getPlacement() {
        return this.placement;
    }

    public boolean getSmartRedirect(int n2) {
        if (n2 < 0 || n2 >= this.smartRedirect.length) {
            return false;
        }
        return this.smartRedirect[n2];
    }

    public boolean[] getSmartRedirect() {
        return this.smartRedirect;
    }

    public String[] getTrackingClickUrls() {
        return this.trackingClickUrls;
    }

    public String getTrackingUrls(int n2) {
        if (n2 < 0 || n2 >= this.trackingUrls.length) {
            return null;
        }
        return this.trackingUrls[n2];
    }

    public String[] getTrackingUrls() {
        return this.trackingUrls;
    }

    public int getWidth() {
        return this.width;
    }

    public String gtAdId() {
        if (this.adId == null) {
            this.adId = r.a(this.getHtml(), "@adId@", "@adId@");
        }
        return this.adId;
    }

    public void setApps(List<a> list) {
        this.apps = list;
    }

    public void setHeight(int n2) {
        this.height = n2;
    }

    public void setHtml(String arrbl) {
        this.htmlUuid = com.startapp.android.publish.b.a.a().a((String)arrbl);
        String string2 = r.a((String)arrbl, "@smartRedirect@", "@smartRedirect@");
        if (string2 != null) {
            this.setSmartRedirect(string2);
        }
        if ((string2 = r.a((String)arrbl, "@trackingClickUrl@", "@trackingClickUrl@")) != null) {
            this.setTrackingClickUrl(string2);
        }
        if ((string2 = r.a((String)arrbl, "@tracking@", "@tracking@")) != null) {
            this.setTrackingUrls(string2);
        }
        if ((string2 = r.a((String)arrbl, "@adInfoEnable@", "@adInfoEnable@")) != null) {
            this.setAdInfoEnableOverride(string2);
        }
        if ((arrbl = r.a((String)arrbl, "@adInfoPosition@", "@adInfoPosition@")) != null) {
            this.setAdInfoPositionOverrid((String)arrbl);
        }
        if (this.smartRedirect.length < this.trackingUrls.length) {
            j.a(6, "Error in smartRedirect array in HTML");
            arrbl = new boolean[this.trackingUrls.length];
            int n2 = 0;
            do {
                if (n2 >= this.smartRedirect.length) break;
                arrbl[n2] = this.smartRedirect[n2];
                ++n2;
            } while (true);
            for (int i2 = n2; i2 < this.trackingUrls.length; ++i2) {
                arrbl[i2] = false;
            }
            this.smartRedirect = arrbl;
        }
    }

    public void setPlacement(AdPreferences.Placement placement) {
        this.placement = placement;
    }

    public void setSize(int n2, int n3) {
        this.setWidth(n2);
        this.setHeight(n3);
    }

    public void setWidth(int n2) {
        this.width = n2;
    }
}

