/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.content.res.Resources
 */
package com.startapp.android.publish.a;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import com.startapp.android.publish.AppWallActivity;
import com.startapp.android.publish.a.d;
import com.startapp.android.publish.a.m;
import com.startapp.android.publish.adinformation.b;
import com.startapp.android.publish.c;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import java.io.Serializable;

public abstract class e
extends d
implements c {
    private static final long serialVersionUID = 1;

    public e(Context context) {
        super(context);
    }

    @Override
    public String getLauncherName() {
        return super.getLauncherName();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean show() {
        boolean bl = false;
        boolean bl2 = bl;
        if (!r.a(this.context)) return bl2;
        bl2 = bl;
        if (!this.isReady()) return bl2;
        bl2 = bl;
        if (this.getHtml() == null) return bl2;
        bl2 = this.context instanceof Activity ? r.a((Activity)this.context) : false;
        Intent intent = new Intent(this.context, (Class)AppWallActivity.class);
        intent.putExtra("fileUrl", "exit.html");
        String[] arrstring = this.getTrackingUrls();
        String string2 = r.b();
        for (int i2 = 0; i2 < arrstring.length; ++i2) {
            arrstring[i2] = arrstring[i2] + string2;
        }
        intent.putExtra("tracking", arrstring);
        intent.putExtra("trackingClickUrl", this.getTrackingClickUrls());
        intent.putExtra("htmlUuid", this.getHtmlUuid());
        intent.putExtra("smartRedirect", this.smartRedirect);
        intent.putExtra("placement", this.placement.getIndex());
        intent.putExtra("adInfoOverride", (Serializable)this.getAdInfoOverride());
        intent.putExtra("fullscreen", bl2);
        intent.putExtra("orientation", this.context.getResources().getConfiguration().orientation);
        if (this instanceof m) {
            intent.putExtra("isSplash", true);
        }
        intent.putExtra("position", r.c());
        intent.addFlags(344457216);
        this.context.startActivity(intent);
        return true;
    }
}

