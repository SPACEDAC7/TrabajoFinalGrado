/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.a;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.model.AdDetails;
import java.util.List;

public abstract class f
extends Ad {
    private static final long serialVersionUID = 1;
    private List<AdDetails> adsDetails = null;

    public f(Context context) {
        super(context);
    }

    public List<AdDetails> a() {
        return this.adsDetails;
    }

    public void a(List<AdDetails> list) {
        this.adsDetails = list;
    }
}

