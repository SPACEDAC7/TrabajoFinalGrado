/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.a;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.f;
import com.startapp.android.publish.d.i;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.nativead.NativeAdPreferences;

public class g
extends f {
    private static final long serialVersionUID = 1;
    private NativeAdPreferences config;

    public g(Context context, NativeAdPreferences nativeAdPreferences) {
        super(context);
        this.config = nativeAdPreferences;
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
        new i(this.context, this, adPreferences, adEventListener, this.config).c();
    }
}

