/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 */
package com.startapp.android.publish.a;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.f;
import com.startapp.android.publish.adinformation.b;
import com.startapp.android.publish.c;
import com.startapp.android.publish.d.k;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.list3d.List3DActivity;
import com.startapp.android.publish.list3d.e;
import com.startapp.android.publish.model.AdPreferences;
import java.io.Serializable;

public class h
extends f
implements c {
    private static String a = null;
    private static final long serialVersionUID = 1;

    public h(Context context) {
        super(context);
        if (a == null) {
            this.b();
        }
    }

    private void b() {
        Object object = new Intent();
        object.setAction("android.intent.action.MAIN");
        object.addCategory("android.intent.category.HOME");
        object = this.context.getPackageManager().resolveActivity((Intent)object, 0);
        if (object != null && object.activityInfo != null) {
            a = object = object.activityInfo.packageName;
            if (object != null) {
                a = a.toLowerCase();
            }
        }
    }

    @Override
    public String getLauncherName() {
        return a;
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
        new k(this.context, this, adPreferences, adEventListener).c();
    }

    @Override
    public boolean show() {
        boolean bl = false;
        boolean bl2 = false;
        boolean bl3 = bl;
        if (r.a(this.context)) {
            bl3 = bl;
            if (this.isReady()) {
                e.a.a(r.b());
                bl3 = bl2;
                if (this.context instanceof Activity) {
                    bl3 = r.a((Activity)this.context);
                }
                Intent intent = new Intent(this.context, (Class)List3DActivity.class);
                intent.putExtra("adInfoOverride", (Serializable)this.getAdInfoOverride());
                intent.putExtra("fullscreen", bl3);
                intent.addFlags(344457216);
                this.context.startActivity(intent);
                bl3 = true;
            }
        }
        return bl3;
    }
}

