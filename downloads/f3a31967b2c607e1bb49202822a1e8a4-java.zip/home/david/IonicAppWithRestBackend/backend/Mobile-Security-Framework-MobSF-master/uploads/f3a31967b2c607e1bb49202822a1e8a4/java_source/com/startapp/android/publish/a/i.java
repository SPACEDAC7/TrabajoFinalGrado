/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.a;

import android.content.Context;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.e;
import com.startapp.android.publish.d.j;
import com.startapp.android.publish.model.AdPreferences;

public class i
extends e {
    private static final long serialVersionUID = 1;

    public i(Context context) {
        super(context);
        this.setPlacement(AdPreferences.Placement.INAPP_OFFER_WALL);
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
        new j(this.context, this, adPreferences, adEventListener).c();
    }
}

