/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.a;

import android.content.Context;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.d;
import com.startapp.android.publish.a.e;
import com.startapp.android.publish.d.l;
import com.startapp.android.publish.model.AdPreferences;

public class j
extends e {
    private static final long serialVersionUID = 1;

    public j(Context context) {
        super(context);
        this.setPlacement(AdPreferences.Placement.INAPP_OVERLAY);
    }

    @Override
    public void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
        new l(this.context, this, adPreferences, adEventListener).c();
    }
}

