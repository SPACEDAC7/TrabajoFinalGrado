/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.a;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.d;
import com.startapp.android.publish.a.e;
import com.startapp.android.publish.d.m;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;

public class k
extends e {
    private static final long serialVersionUID = 1;
    private long lastLoadTime;

    public k(Context context) {
        super(context);
        this.setPlacement(AdPreferences.Placement.INAPP_RETURN);
    }

    private boolean a() {
        if (System.currentTimeMillis() - this.lastLoadTime > MetaData.getInstance().getAdCacheTtl()) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean load(AdPreferences adPreferences, final AdEventListener adEventListener) {
        if (this.isReady()) {
            if (!this.a()) {
                if (adEventListener != null) {
                    adEventListener.onReceiveAd(this);
                }
                return true;
            }
            j.a("ReturnAd", 3, "Reloading return ad - Cache TTL has passed");
        } else {
            j.a("ReturnAd", 3, "Loading return ad");
        }
        r.a(this.context, adPreferences);
        this.setState(Ad.AdState.UN_INITIALIZED);
        return super.load(adPreferences, new AdEventListener(){

            @Override
            public void onFailedToReceiveAd(Ad ad) {
                j.a("ReturnAd", 3, "Return Ad Failed to Load");
                if (adEventListener != null) {
                    adEventListener.onFailedToReceiveAd(ad);
                }
            }

            @Override
            public void onReceiveAd(Ad ad) {
                k.this.lastLoadTime = System.currentTimeMillis();
                j.a("ReturnAd", 3, "Return Ad Loaded");
                if (adEventListener != null) {
                    adEventListener.onReceiveAd(ad);
                }
            }
        }, true);
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
        new m(this.context, this, adPreferences, adEventListener).c();
    }

    @Override
    public boolean show() {
        if (!this.a()) {
            boolean bl = super.show();
            this.setState(Ad.AdState.UN_INITIALIZED);
            return bl;
        }
        j.a("ReturnAd", 3, "Return Ad not shown - Cache TTL has passed");
        return false;
    }

}

