/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 */
package com.startapp.android.publish.a;

import android.app.Activity;
import android.content.Context;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.f;
import com.startapp.android.publish.d.n;
import com.startapp.android.publish.model.AdDetails;
import com.startapp.android.publish.model.AdPreferences;
import java.util.List;

public class l
extends f {
    private static final long serialVersionUID = 1;
    private List<AdDetails> adsDetails = null;

    public l(Activity activity) {
        super((Context)activity);
    }

    @Override
    public List<AdDetails> a() {
        return this.adsDetails;
    }

    public void a(AdPreferences adPreferences, AdEventListener adEventListener) {
        this.load(adPreferences, adEventListener);
    }

    @Override
    public void a(List<AdDetails> list) {
        this.adsDetails = list;
    }

    @Override
    public boolean load(AdPreferences adPreferences, AdEventListener adEventListener) {
        boolean bl = false;
        if (!super.load(adPreferences, adEventListener, false)) {
            bl = true;
        }
        return bl;
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
        new n((Activity)this.context, this, adPreferences, adEventListener).c();
    }
}

