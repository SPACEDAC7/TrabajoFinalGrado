/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.a;

import android.content.Context;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.e;
import com.startapp.android.publish.d.o;
import com.startapp.android.publish.model.AdPreferences;

public class m
extends e {
    private static final long serialVersionUID = 1;

    public m(Context context) {
        super(context);
        this.setPlacement(AdPreferences.Placement.INAPP_OVERLAY);
    }

    @Deprecated
    @Override
    public boolean load(AdPreferences adPreferences, AdEventListener adEventListener) {
        return super.load(adPreferences, adEventListener, false);
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
        new o(this.context, this, adPreferences, adEventListener).c();
    }
}

