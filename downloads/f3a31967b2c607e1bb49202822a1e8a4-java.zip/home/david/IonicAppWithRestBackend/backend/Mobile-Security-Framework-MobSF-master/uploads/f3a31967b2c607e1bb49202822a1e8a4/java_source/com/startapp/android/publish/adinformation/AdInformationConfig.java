/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.adinformation;

import android.content.Context;
import com.startapp.android.publish.adinformation.AdInformationPositions;
import com.startapp.android.publish.adinformation.d;
import com.startapp.android.publish.adinformation.e;
import com.startapp.android.publish.g.h;
import com.startapp.android.publish.model.AdPreferences;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AdInformationConfig
implements Serializable {
    private static final long serialVersionUID = 1;
    private List<d> ImageResources = new ArrayList<d>();
    protected HashMap<AdPreferences.Placement, AdInformationPositions.Position> Positions = new HashMap();
    private e SimpleToken = new e();
    private transient HashMap<ImageResourceType, d> a = new HashMap();
    private String dialogUrl = "http://d1byvlfiet2h9q.cloudfront.net/InApp/resources/adInformationDialog3.html";
    private boolean enabled = true;
    private float fatFingersFactor = 200.0f;

    private AdInformationConfig() {
    }

    public static AdInformationConfig a() {
        AdInformationConfig adInformationConfig = new AdInformationConfig();
        AdInformationConfig.a(adInformationConfig);
        return adInformationConfig;
    }

    public static void a(AdInformationConfig adInformationConfig) {
        adInformationConfig.h();
        adInformationConfig.g();
    }

    public AdInformationPositions.Position a(AdPreferences.Placement placement) {
        AdInformationPositions.Position position;
        AdInformationPositions.Position position2 = position = this.Positions.get((Object)placement);
        if (position == null) {
            position2 = AdInformationPositions.Position.BOTTOM_LEFT;
            this.Positions.put(placement, position2);
        }
        return position2;
    }

    public d a(ImageResourceType imageResourceType) {
        return this.a.get((Object)imageResourceType);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(Context context, boolean bl) {
        bl = !bl;
        h.b(context, "userDisabledAdInformation", bl);
    }

    protected void a(ImageResourceType imageResourceType, d d2) {
        this.a.put(imageResourceType, d2);
    }

    public boolean a(Context context) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!h.a(context, "userDisabledAdInformation", false).booleanValue()) {
            bl2 = bl;
            if (this.b()) {
                bl2 = true;
            }
        }
        return bl2;
    }

    public boolean b() {
        return this.enabled;
    }

    public float c() {
        return this.fatFingersFactor / 100.0f;
    }

    public String d() {
        return this.dialogUrl;
    }

    public e e() {
        return this.SimpleToken;
    }

    public void f() {
        for (d d2 : this.ImageResources) {
            this.a(ImageResourceType.getByName(d2.a()), d2);
            d2.d();
        }
    }

    protected void g() {
        for (ImageResourceType imageResourceType : ImageResourceType.values()) {
            if (this.a.get((Object)imageResourceType) != null) continue;
            throw new IllegalArgumentException("AdInformation error in ImageResource [" + (Object)((Object)imageResourceType) + "] cannot be found in MetaData");
        }
    }

    protected void h() {
        for (ImageResourceType imageResourceType : ImageResourceType.values()) {
            d d2;
            d d3 = d2 = this.a.get((Object)imageResourceType);
            if (d2 == null) {
                d3 = d.c(imageResourceType.name());
                this.a.put(imageResourceType, d3);
                this.ImageResources.add(d3);
            }
            d3.a(imageResourceType.getDefaultWidth());
            d3.b(imageResourceType.getDefaultHeight());
            d3.a(imageResourceType.name().toLowerCase() + ".png");
        }
    }

    public static enum ImageResourceType {
        INFO_S(17, 14),
        INFO_EX_S(88, 14),
        INFO_L(25, 21),
        INFO_EX_L(130, 21);
        
        private int height;
        private int width;

        private ImageResourceType(int n3, int n4) {
            this.width = n3;
            this.height = n4;
        }

        public static ImageResourceType getByName(String string2) {
            ImageResourceType imageResourceType = INFO_S;
            ImageResourceType[] arrimageResourceType = ImageResourceType.values();
            for (int i2 = 0; i2 < arrimageResourceType.length; ++i2) {
                if (arrimageResourceType[i2].name().toLowerCase().compareTo(string2.toLowerCase()) != 0) continue;
                imageResourceType = arrimageResourceType[i2];
            }
            return imageResourceType;
        }

        public final int getDefaultHeight() {
            return this.height;
        }

        public final int getDefaultWidth() {
            return this.width;
        }
    }

}

