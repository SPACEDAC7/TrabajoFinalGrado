/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.webkit.JavascriptInterface
 */
package com.startapp.android.publish.adinformation;

import android.webkit.JavascriptInterface;

public class AdInformationJsInterface {
    private Runnable acceptCallback = null;
    private Runnable declineCallback = null;
    private boolean processed = false;

    public AdInformationJsInterface(Runnable runnable, Runnable runnable2) {
        this.acceptCallback = runnable;
        this.declineCallback = runnable2;
    }

    @JavascriptInterface
    public void accept() {
        if (this.processed) {
            return;
        }
        this.processed = true;
        this.acceptCallback.run();
    }

    @JavascriptInterface
    public void decline() {
        if (this.processed) {
            return;
        }
        this.processed = true;
        this.declineCallback.run();
    }
}

