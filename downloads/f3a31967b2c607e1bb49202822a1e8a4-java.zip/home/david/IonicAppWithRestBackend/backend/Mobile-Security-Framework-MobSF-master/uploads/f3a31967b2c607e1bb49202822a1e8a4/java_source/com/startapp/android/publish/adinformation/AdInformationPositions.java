/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 */
package com.startapp.android.publish.adinformation;

import android.widget.RelativeLayout;

public class AdInformationPositions {
    protected static final String a = Position.BOTTOM_LEFT.name();

    public static enum Position {
        TOP_LEFT(1, new int[]{10, 9}, -1),
        TOP_RIGHT(2, new int[]{10, 11}, 1),
        BOTTOM_LEFT(3, new int[]{12, 9}, -1),
        BOTTOM_RIGHT(4, new int[]{12, 11}, 1);
        
        private int animationMultiplier;
        private int index;
        private int[] rules;

        private Position(int n3, int[] arrn, int n4) {
            this.rules = arrn;
            this.animationMultiplier = n4;
            this.index = n3;
        }

        public static Position getByIndex(long l2) {
            Position position = BOTTOM_LEFT;
            Position[] arrposition = Position.values();
            for (int i2 = 0; i2 < arrposition.length; ++i2) {
                if ((long)arrposition[i2].getIndex() != l2) continue;
                position = arrposition[i2];
            }
            return position;
        }

        public static Position getByName(String string2) {
            Position position = BOTTOM_LEFT;
            Position[] arrposition = Position.values();
            for (int i2 = 0; i2 < arrposition.length; ++i2) {
                if (arrposition[i2].name().toLowerCase().compareTo(string2.toLowerCase()) != 0) continue;
                position = arrposition[i2];
            }
            return position;
        }

        public final void addRules(RelativeLayout.LayoutParams layoutParams) {
            for (int i2 = 0; i2 < this.rules.length; ++i2) {
                layoutParams.addRule(this.rules[i2]);
            }
        }

        public final int getAnimationStartMultiplier() {
            return this.animationMultiplier;
        }

        public final int getIndex() {
            return this.index;
        }
    }

}

