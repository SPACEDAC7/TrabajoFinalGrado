/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.content.Context
 *  android.graphics.Point
 *  android.os.Handler
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.webkit.WebChromeClient
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 */
package com.startapp.android.publish.adinformation;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Point;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import com.startapp.android.publish.adinformation.AdInformationConfig;
import com.startapp.android.publish.adinformation.AdInformationJsInterface;
import com.startapp.android.publish.adinformation.AdInformationPositions;
import com.startapp.android.publish.adinformation.c;
import com.startapp.android.publish.adinformation.e;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;

public class a
implements View.OnClickListener {
    private Context a;
    private c b;
    private RelativeLayout c;
    private WebView d;
    private Dialog e = null;
    private AdPreferences.Placement f;
    private RelativeLayout g;
    private Handler h = new Handler();
    private a i = a.a;
    private boolean j = false;
    private com.startapp.android.publish.adinformation.b k;
    private AdInformationConfig l;
    private e m;
    private Runnable n;
    private Runnable o;

    public a(Context context, b b2, AdPreferences.Placement placement, com.startapp.android.publish.adinformation.b b3) {
        this.n = new Runnable(){

            @Override
            public void run() {
                a.this.c();
                a.this.m.a(a.this.a, true);
                a.this.l.a(a.this.a, true);
                a.this.a(false);
            }
        };
        this.o = new Runnable(){

            @Override
            public void run() {
                a.this.c();
                a.this.m.a(a.this.a, false);
                a.this.l.a(a.this.a, true);
                a.this.a(false);
            }
        };
        this.a = context;
        this.f = placement;
        this.k = b3;
        this.l = this.a();
        this.m = this.l.e();
        this.b = new c(context, b2, placement, b3);
        this.b.setOnInfoClickListener(this);
    }

    private AdInformationConfig a() {
        return MetaData.getInstance().getAdInformationConfig();
    }

    public static AdInformationConfig a(Context context) {
        return MetaData.getInstance().getAdInformationConfig();
    }

    private void a(ViewGroup viewGroup, Point point) {
        this.j = true;
        this.e = new Dialog(this.a);
        this.e.requestWindowFeature(1);
        this.e.setContentView((View)viewGroup);
        viewGroup = new WindowManager.LayoutParams();
        viewGroup.copyFrom(this.e.getWindow().getAttributes());
        viewGroup.width = (int)((float)point.x * 0.9f);
        viewGroup.height = (int)((float)point.y * 0.85f);
        this.e.show();
        this.e.getWindow().setAttributes((WindowManager.LayoutParams)viewGroup);
    }

    private void a(boolean bl) {
        if (!this.f.isInterstitial() && this.a instanceof Activity) {
            r.a((Activity)this.a, bl);
        }
    }

    private com.startapp.android.publish.adinformation.b b() {
        return this.k;
    }

    private void b(final ViewGroup viewGroup, Point point) {
        this.j = true;
        point = new RelativeLayout.LayoutParams((int)((float)point.x * 0.9f), (int)((float)point.y * 0.85f));
        point.addRule(13);
        this.h.post(new Runnable((RelativeLayout.LayoutParams)point){
            final /* synthetic */ RelativeLayout.LayoutParams b;

            @Override
            public void run() {
                a.this.c.addView((View)viewGroup, (ViewGroup.LayoutParams)this.b);
            }
        });
    }

    private void c() {
        this.j = false;
        switch (.a[this.i.ordinal()]) {
            default: {
                return;
            }
            case 1: {
                this.h.post(new Runnable(){

                    @Override
                    public void run() {
                        a.this.c.removeView((View)a.this.g);
                    }
                });
                return;
            }
            case 2: 
        }
        this.e.dismiss();
    }

    private void d() {
        String string2 = r.a(this.a, null);
        if (string2 != null) {
            this.d.loadUrl("javascript:window.onload=function(){document.getElementById('titlePlacement').innerText='" + string2 + "';}");
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(RelativeLayout relativeLayout) {
        boolean bl = this.b().e() ? this.b().b() : this.a().a(this.a);
        if (bl) {
            this.c = relativeLayout;
            relativeLayout = new RelativeLayout.LayoutParams(-2, -2);
            if (this.b().d()) {
                this.b().c().addRules((RelativeLayout.LayoutParams)relativeLayout);
            } else {
                this.a().a(this.f).addRules((RelativeLayout.LayoutParams)relativeLayout);
            }
            this.c.addView((View)this.b, (ViewGroup.LayoutParams)relativeLayout);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void onClick(View view) {
        if (!this.m.a(this.a)) return;
        this.a(true);
        this.g = new RelativeLayout(this.a);
        this.d = new WebView(this.a);
        this.d.setWebViewClient(new WebViewClient());
        this.d.setWebChromeClient(new WebChromeClient());
        this.d.getSettings().setJavaScriptEnabled(true);
        this.d.setHorizontalScrollBarEnabled(false);
        this.d.setVerticalScrollBarEnabled(false);
        this.d.loadUrl(this.l.d());
        this.d.addJavascriptInterface((Object)new AdInformationJsInterface(this.n, this.o), "startappwall");
        WindowManager windowManager = (WindowManager)this.a.getSystemService("window");
        view = new Point(1, 1);
        com.startapp.android.publish.g.b.a(windowManager, (Point)view);
        windowManager = new RelativeLayout.LayoutParams(-1, -1);
        windowManager.addRule(13);
        this.d.setPadding(0, 0, 0, 0);
        windowManager.setMargins(0, 0, 0, 0);
        this.g.addView((View)this.d, (ViewGroup.LayoutParams)windowManager);
        this.d();
        switch (.a[this.i.ordinal()]) {
            default: {
                return;
            }
            case 1: {
                this.b((ViewGroup)this.g, (Point)view);
                return;
            }
            case 2: 
        }
        this.a((ViewGroup)this.g, (Point)view);
    }

    public static enum a {
        a,
        b;
        

        private a() {
        }
    }

    public static enum b {
        a(AdInformationConfig.ImageResourceType.INFO_S, AdInformationConfig.ImageResourceType.INFO_EX_S),
        b(AdInformationConfig.ImageResourceType.INFO_L, AdInformationConfig.ImageResourceType.INFO_EX_L);
        
        private AdInformationConfig.ImageResourceType infoExtendedType;
        private AdInformationConfig.ImageResourceType infoType;

        private b(AdInformationConfig.ImageResourceType imageResourceType, AdInformationConfig.ImageResourceType imageResourceType2) {
            this.infoType = imageResourceType;
            this.infoExtendedType = imageResourceType2;
        }

        public final AdInformationConfig.ImageResourceType a() {
            return this.infoType;
        }

        public final AdInformationConfig.ImageResourceType b() {
            return this.infoExtendedType;
        }
    }

}

