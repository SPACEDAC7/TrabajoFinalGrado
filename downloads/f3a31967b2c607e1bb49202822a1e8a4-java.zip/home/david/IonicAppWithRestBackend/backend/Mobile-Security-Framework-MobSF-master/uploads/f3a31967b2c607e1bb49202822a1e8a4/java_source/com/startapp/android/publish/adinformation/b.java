/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.adinformation;

import com.startapp.android.publish.adinformation.AdInformationPositions;
import java.io.Serializable;

public class b
implements Serializable {
    private static final long serialVersionUID = 1;
    private boolean enable = true;
    private boolean enableOverride = false;
    private AdInformationPositions.Position position = AdInformationPositions.Position.getByName(AdInformationPositions.a);
    private boolean positionOverride = false;

    private b() {
    }

    public static b a() {
        return new b();
    }

    public void a(AdInformationPositions.Position position) {
        this.position = position;
        if (position != null) {
            this.positionOverride = true;
            return;
        }
        this.positionOverride = false;
    }

    public void a(boolean bl) {
        this.enable = bl;
        this.enableOverride = true;
    }

    public boolean b() {
        return this.enable;
    }

    public AdInformationPositions.Position c() {
        return this.position;
    }

    public boolean d() {
        return this.positionOverride;
    }

    public boolean e() {
        return this.enableOverride;
    }
}

