/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.os.Handler
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.animation.Animation
 *  android.view.animation.Animation$AnimationListener
 *  android.view.animation.TranslateAnimation
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 */
package com.startapp.android.publish.adinformation;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.startapp.android.publish.adinformation.AdInformationConfig;
import com.startapp.android.publish.adinformation.AdInformationPositions;
import com.startapp.android.publish.adinformation.a;
import com.startapp.android.publish.adinformation.b;
import com.startapp.android.publish.adinformation.d;
import com.startapp.android.publish.g.q;
import com.startapp.android.publish.model.AdPreferences;

public class c
extends RelativeLayout {
    private ImageView a;
    private ImageView b;
    private RelativeLayout c;
    private View.OnClickListener d;
    private View.OnClickListener e;
    private AdInformationConfig f;
    private d g;
    private d h;
    private a.b i;
    private AdPreferences.Placement j;
    private boolean k;
    private Handler l;
    private Runnable m;
    private AdInformationPositions.Position n;

    public c(Context context, a.b b2, AdPreferences.Placement placement, b b3) {
        super(context);
        this.d = new View.OnClickListener(){

            public void onClick(View view) {
                c.this.b();
            }
        };
        this.e = null;
        this.i = a.b.b;
        this.k = false;
        this.l = new Handler();
        this.m = new Runnable(){

            @Override
            public void run() {
                if (c.this.k) {
                    c.this.k = false;
                    c.this.c();
                }
            }
        };
        this.j = placement;
        this.a(b2, b3);
    }

    private void a() {
        this.c.setOnClickListener(this.d);
        this.c.removeView((View)this.b);
        com.startapp.android.publish.g.b.a((View)this.b, (View)this.a);
    }

    private void b() {
        this.c.setOnClickListener(this.e);
        d d2 = this.f.a(this.i.a());
        d d3 = this.f.a(this.i.b());
        this.c.getLayoutParams().width = q.a(this.getContext(), d3.b());
        this.c.getLayoutParams().height = q.a(this.getContext(), (int)((float)d3.c() * this.f.c()));
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(q.a(this.getContext(), d3.b()), q.a(this.getContext(), d3.c()));
        layoutParams.setMargins(0, 0, 0, 0);
        this.b.setPadding(0, 0, 0, 0);
        this.n.addRules(layoutParams);
        int n2 = d3.b();
        int n3 = d2.b();
        int n4 = this.n.getAnimationStartMultiplier();
        d2 = new TranslateAnimation(0, (float)q.a(this.getContext(), n4 * (n2 - n3)), 0, 0.0f, 0, 0.0f, 0, 0.0f);
        d2.setDuration(800);
        this.c.addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
        this.a.setVisibility(8);
        this.b.startAnimation((Animation)d2);
        this.k = true;
        this.l.removeCallbacks(this.m);
        this.l.postDelayed(this.m, 4000);
    }

    private void c() {
        int n2 = this.h.b();
        int n3 = this.g.b();
        int n4 = this.n.getAnimationStartMultiplier();
        TranslateAnimation translateAnimation = new TranslateAnimation(0, 0.0f, 0, (float)q.a(this.getContext(), n4 * (n2 - n3)), 0, 0.0f, 0, 0.0f);
        translateAnimation.setDuration(800);
        translateAnimation.setFillAfter(true);
        translateAnimation.setAnimationListener(new Animation.AnimationListener(){

            public void onAnimationEnd(Animation animation) {
                c.this.a();
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationStart(Animation animation) {
            }
        });
        this.b.startAnimation((Animation)translateAnimation);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a(a.b b2, b b3) {
        this.setSize(b2);
        this.f = a.a(this.getContext());
        this.g = this.f.a(b2.a());
        this.h = this.f.a(b2.b());
        this.n = b3.d() ? b3.c() : this.f.a(this.j);
        this.a = new ImageView(this.getContext());
        this.a.setContentDescription((CharSequence)"info");
        this.a.setId(1475346433);
        this.b = new ImageView(this.getContext());
        this.b.setContentDescription((CharSequence)"infoExtended");
        this.b.setId(1475346434);
        this.a.setImageBitmap(this.g.a(this.getContext()));
        this.b.setImageBitmap(this.h.a(this.getContext()));
        this.c = new RelativeLayout(this.getContext());
        b2 = new RelativeLayout.LayoutParams(q.a(this.getContext(), (int)((float)this.g.b() * this.f.c())), q.a(this.getContext(), (int)((float)this.g.c() * this.f.c())));
        this.c.setBackgroundColor(0);
        b3 = new RelativeLayout.LayoutParams(q.a(this.getContext(), this.g.b()), q.a(this.getContext(), this.g.c()));
        b3.setMargins(0, 0, 0, 0);
        this.a.setPadding(0, 0, 0, 0);
        this.n.addRules((RelativeLayout.LayoutParams)b3);
        this.c.addView((View)this.a, (ViewGroup.LayoutParams)b3);
        this.a();
        this.addView((View)this.c, (ViewGroup.LayoutParams)b2);
    }

    protected void setOnInfoClickListener(final View.OnClickListener onClickListener) {
        this.e = new View.OnClickListener(){

            public void onClick(View view) {
                c.this.k = false;
                c.this.l.removeCallbacks(c.this.m);
                c.this.c();
                onClickListener.onClick(view);
            }
        };
    }

    public void setSize(a.b b2) {
        this.i = b2;
    }

}

