/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 */
package com.startapp.android.publish.adinformation;

import android.content.Context;
import android.graphics.Bitmap;
import com.startapp.android.publish.g.e;
import com.startapp.android.publish.g.f;
import java.io.Serializable;

public class d
implements Serializable {
    private static final long serialVersionUID = 1;
    private transient Bitmap a;
    private transient Bitmap b;
    private transient Bitmap c = null;
    private int height = 1;
    private String imageFallbackUrl = "";
    private String imageUrl = "";
    private String name;
    private int width = 1;

    private d() {
    }

    public static d c(String string2) {
        d d2 = new d();
        d2.b(string2);
        return d2;
    }

    public Bitmap a(Context context) {
        if (this.c == null) {
            this.c = this.e();
            if (this.c == null) {
                this.c = this.b(context);
            }
        }
        return this.c;
    }

    public String a() {
        return this.name;
    }

    public void a(int n2) {
        this.width = n2;
    }

    protected void a(Bitmap bitmap) {
        this.a = bitmap;
        if (bitmap != null) {
            this.c = bitmap;
        }
    }

    public void a(String string2) {
        this.imageFallbackUrl = string2;
    }

    public int b() {
        return this.width;
    }

    protected Bitmap b(Context context) {
        if (this.b == null) {
            this.b = e.a(context, this.f());
        }
        return this.b;
    }

    public void b(int n2) {
        this.height = n2;
    }

    protected void b(String string2) {
        this.name = string2;
    }

    public int c() {
        return this.height;
    }

    protected void d() {
        this.a((Bitmap)null);
        new f(this.imageUrl, new f.a(){

            @Override
            public void a(Bitmap bitmap, int n2) {
                d.this.a(bitmap);
            }
        }, 0).a();
    }

    protected Bitmap e() {
        return this.a;
    }

    protected String f() {
        return this.imageFallbackUrl;
    }

}

