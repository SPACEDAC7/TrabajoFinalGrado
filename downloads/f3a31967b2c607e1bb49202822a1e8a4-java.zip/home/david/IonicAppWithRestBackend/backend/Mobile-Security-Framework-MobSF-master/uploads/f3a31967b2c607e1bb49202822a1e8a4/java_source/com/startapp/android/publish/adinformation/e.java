/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.adinformation;

import android.content.Context;
import com.startapp.android.publish.g.h;
import java.io.Serializable;

public class e
implements Serializable {
    private static final long serialVersionUID = 1;
    private boolean enabled = true;

    /*
     * Enabled aggressive block sorting
     */
    public void a(Context context, boolean bl) {
        bl = !bl;
        h.b(context, "userDisabledSimpleToken", bl);
    }

    public boolean a() {
        return this.enabled;
    }

    public boolean a(Context context) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!h.a(context, "userDisabledSimpleToken", false).booleanValue()) {
            bl2 = bl;
            if (this.a()) {
                bl2 = true;
            }
        }
        return bl2;
    }
}

