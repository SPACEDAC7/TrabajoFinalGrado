/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish;

import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.MetaData;

public class b {
    public static final int AD_INFORMATION_EXTENDED_ID = 1475346434;
    public static final int AD_INFORMATION_ID = 1475346433;
    public static final Boolean DEBUG;
    public static final int LIST_3D_CLOSE_BUTTON_ID = 1475346435;
    public static final String META_DATA_HOST = "http://init.startappexchange.com/1.3/";
    public static final String OVERRIDE_HOST;
    public static final int STARTAPP_AD_MAIN_LAYOUT_ID = 1475346432;
    public static final String a;
    public static final String b;

    static {
        OVERRIDE_HOST = null;
        DEBUG = false;
        a = r.a();
        b = new String(new byte[]{99, 111, 109, 46, 97, 110, 100, 114, 111, 105, 100, 46, 118, 101, 110, 100, 105, 110, 103});
    }

    public static Boolean a() {
        return DEBUG;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String a(a object) {
        String string2;
        Object var2_1 = null;
        switch (.a[object.ordinal()]) {
            default: {
                string2 = null;
                object = var2_1;
                do {
                    return (String)object + string2;
                    break;
                } while (true);
            }
            case 1: {
                string2 = "gethtmlad";
                object = MetaData.getInstance().getAdPlatformHost();
                return (String)object + string2;
            }
            case 2: {
                string2 = "getads";
                object = MetaData.getInstance().getAdPlatformHost();
                return (String)object + string2;
            }
            case 3: {
                string2 = "getadsmetadata";
                if (OVERRIDE_HOST != null) {
                    object = OVERRIDE_HOST;
                    return (String)object + string2;
                }
                object = "http://init.startappexchange.com/1.3/";
                return (String)object + string2;
            }
            case 4: 
        }
        string2 = "trackdownload";
        object = MetaData.getInstance().getAdPlatformHost();
        return (String)object + string2;
    }

    public static enum a {
        a,
        b,
        c,
        d;
        

        private a() {
        }
    }

}

