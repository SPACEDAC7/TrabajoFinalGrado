/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.b;

import android.content.Context;
import com.startapp.android.publish.a.k;
import com.startapp.android.publish.g.i;
import com.startapp.android.publish.g.j;
import java.io.Serializable;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

public class a {
    private static a a = new a();
    private Map<String, String> b = new WeakHashMap<String, String>();

    private a() {
    }

    public static a a() {
        return a;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public k a(Context context) {
        k k2 = (k)i.a(context, "filename_return_ad", k.class);
        if (k2 == null) return k2;
        String string2 = (String)i.a(context, "filename_return_ad_html", String.class);
        if (string2 == null) return null;
        this.a(string2, k2.getHtmlUuid());
        k2.setContext(context);
        return k2;
    }

    public String a(String string2) {
        return this.a(string2, UUID.randomUUID().toString());
    }

    public String a(String string2, String string3) {
        j.a("AdCacheManager", 3, "cache size: " + this.b.size() + " - adding key " + string3);
        j.a("AdCacheManager", 3, "html:\n" + string2);
        this.b.put(string3, string2);
        return string3.toString();
    }

    public void a(Context context, k k2) {
        i.a(context, "filename_return_ad", k2);
        i.a(context, "filename_return_ad_html", (Serializable)((Object)k2.getHtml()));
    }

    public String b(String string2) {
        return this.b.get(string2);
    }

    public String c(String string2) {
        j.a("AdCacheManager", 3, "cache size: " + this.b.size() + " - removing " + string2);
        return this.b.remove(string2);
    }
}

