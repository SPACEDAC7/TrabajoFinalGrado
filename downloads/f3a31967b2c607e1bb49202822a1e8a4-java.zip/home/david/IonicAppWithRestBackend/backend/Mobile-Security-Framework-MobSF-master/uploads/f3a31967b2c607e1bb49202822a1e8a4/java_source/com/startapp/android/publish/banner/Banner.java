/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Color
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 */
package com.startapp.android.publish.banner;

import android.content.Context;
import android.graphics.Color;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.startapp.android.publish.banner.BannerOptions;
import com.startapp.android.publish.banner.banner3d.Banner3D;
import com.startapp.android.publish.banner.bannerstandard.BannerStandard;
import com.startapp.android.publish.d.p;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.q;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;
import java.util.Random;

public class Banner
extends FrameLayout {
    private static final int BANNER_3D_ID = 159868227;
    private static final int BANNER_REG_ID = 159868226;
    private static final String TAG = "StartAppWall.Banner";
    private boolean bFirstTime = true;
    private boolean bVisible = true;
    private Banner3D banner3D;
    private BannerStandard bannerHtml;
    private BannerOptions options;
    private BType type = null;

    public Banner(Context context) {
        super(context);
        this.init(null);
    }

    public Banner(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init(null);
    }

    public Banner(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        this.init(null);
    }

    public Banner(Context context, AdPreferences adPreferences) {
        super(context);
        this.init(adPreferences);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void init(AdPreferences object) {
        if (this.isInEditMode()) {
            this.setMinimumWidth(q.a(this.getContext(), 300));
            this.setMinimumHeight(q.a(this.getContext(), 50));
            this.setBackgroundColor(Color.rgb((int)169, (int)169, (int)169));
            object = new TextView(this.getContext());
            object.setText((CharSequence)"StartApp Banner");
            object.setTextColor(-16777216);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 17;
            this.addView((View)object, (ViewGroup.LayoutParams)layoutParams);
            return;
        }
        if (object == null) {
            this.banner3D = new Banner3D(this.getContext(), false);
            this.bannerHtml = new BannerStandard(this.getContext(), false);
        } else {
            this.banner3D = new Banner3D(this.getContext(), false, (AdPreferences)object);
            this.bannerHtml = new BannerStandard(this.getContext(), false, (AdPreferences)object);
        }
        this.setVisibility(8);
        object = new p(){

            @Override
            public void onFailedLoadingMeta() {
                Banner.this.init_step2();
            }

            @Override
            public void onFinishLoadingMeta() {
                Banner.this.init_step2();
            }
        };
        AdPreferences adPreferences = new AdPreferences();
        r.a(this.getContext(), adPreferences);
        MetaData.getInstance().loadFromServer(this.getContext(), adPreferences, true, (p)object);
    }

    private void init_step2() {
        this.banner3D.setId(159868227);
        this.bannerHtml.setId(159868226);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        this.addView((View)this.bannerHtml, (ViewGroup.LayoutParams)layoutParams);
        this.addView((View)this.banner3D, (ViewGroup.LayoutParams)layoutParams);
        this.options = MetaData.getInstance().getBannerOptions();
        this.postDelayed(new Runnable(){

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public void run() {
                if (Banner.this.bFirstTime) {
                    int n2 = Banner.this.options.i();
                    int n3 = new Random().nextInt(100);
                    Banner.this.type = BType.REGULAR;
                    if (n3 < n2) {
                        Banner.this.type = BType.THREED;
                    }
                    j.a(3, "StartAppWall.BannerProbability [" + n3 + "\\" + n2 + "]");
                }
                switch (.$SwitchMap$com$startapp$android$publish$banner$Banner$BType[Banner.this.type.ordinal()]) {
                    case 1: {
                        j.a(3, "StartAppWall.BannerDisplaying REGULAR");
                        Banner.this.banner3D.hideBanner();
                        Banner.this.bannerHtml.load();
                    }
                    default: {
                        break;
                    }
                    case 2: {
                        j.a(3, "StartAppWall.BannerDisplaying 3D");
                        Banner.this.bannerHtml.hideBanner();
                        if (Banner.this.bFirstTime) {
                            Banner.this.banner3D.load();
                            break;
                        }
                        Banner.this.banner3D.showBanner();
                    }
                }
                Banner.this.bFirstTime = false;
                if (Banner.this.bVisible) {
                    Banner.this.showBanner();
                }
            }
        }, 50);
    }

    public void hideBanner() {
        this.setVisibility(8);
        this.bVisible = false;
    }

    protected void onRestoreInstanceState(Parcelable object) {
        if (!(object instanceof SavedState)) {
            super.onRestoreInstanceState((Parcelable)object);
            return;
        }
        object = (SavedState)((Object)object);
        this.type = object.type;
        this.bFirstTime = object.bFirstTime;
        super.onRestoreInstanceState(object.getSuperState());
    }

    protected Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.bFirstTime = this.bFirstTime;
        savedState.type = this.type;
        return savedState;
    }

    public void showBanner() {
        this.setVisibility(0);
        this.bVisible = true;
    }

    static enum BType {
        THREED,
        REGULAR;
        

        private BType() {
        }
    }

    static class SavedState
    extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>(){

            public final SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public final SavedState[] newArray(int n2) {
                return new SavedState[n2];
            }
        };
        public boolean bFirstTime;
        public BType type;

        private SavedState(Parcel parcel) {
            super(parcel);
            int n2 = parcel.readInt();
            this.type = BType.REGULAR;
            if (n2 == 2) {
                this.type = BType.THREED;
            }
            n2 = parcel.readInt();
            this.bFirstTime = false;
            if (n2 == 1) {
                this.bFirstTime = true;
            }
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int n2) {
            int n3 = 1;
            super.writeToParcel(parcel, n2);
            n2 = 0;
            if (this.bFirstTime) {
                n2 = 1;
            }
            if (this.type == BType.THREED) {
                n3 = 2;
            }
            parcel.writeInt(n3);
            parcel.writeInt(n2);
        }

    }

}

