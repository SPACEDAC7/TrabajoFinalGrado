/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.banner;

import java.io.Serializable;

public class BannerOptions
implements Serializable {
    private static final Effect a = Effect.ROTATE_3D;
    private static final long serialVersionUID = 1;
    private int adsNumber = 4;
    private int delayFaceTime = 5000;
    private Effect effect = a;
    private int height = 50;
    private float heightRatio = 1.0f;
    private int htmlAdsNumber = 10;
    private float minScale = 0.88f;
    private int probability3D = 90;
    private int refreshRate = 30000;
    private boolean rotateThroughOnStart = true;
    private int rotateThroughSpeedMult = 2;
    private int scalePower = 4;
    private int stepSize = 5;
    private int timeBetweenFrames = 25;
    private int width = 300;
    private float widthRatio = 1.0f;

    public int a() {
        return this.timeBetweenFrames;
    }

    public void a(int n2, int n3) {
        this.width = n2;
        this.height = n3;
    }

    public int b() {
        return this.stepSize;
    }

    public int c() {
        return this.delayFaceTime;
    }

    public int d() {
        return this.width;
    }

    public int e() {
        return this.height;
    }

    public boolean equals(Object object) {
        boolean bl = false;
        object = (BannerOptions)object;
        boolean bl2 = bl;
        if (object.f() == this.f()) {
            bl2 = bl;
            if (object.g() == this.g()) {
                bl2 = bl;
                if (object.c() == this.c()) {
                    bl2 = bl;
                    if (object.e() == this.e()) {
                        bl2 = bl;
                        if (object.b() == this.b()) {
                            bl2 = bl;
                            if (object.a() == this.a()) {
                                bl2 = bl;
                                if (object.d() == this.d()) {
                                    bl2 = bl;
                                    if (object.h() == this.h()) {
                                        bl2 = bl;
                                        if (object.i() == this.i()) {
                                            bl2 = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return bl2;
    }

    public int f() {
        return this.adsNumber;
    }

    public int g() {
        return this.htmlAdsNumber;
    }

    public int h() {
        return this.refreshRate;
    }

    public int i() {
        return this.probability3D;
    }

    public float j() {
        return this.widthRatio;
    }

    public float k() {
        return this.heightRatio;
    }

    public float l() {
        return this.minScale;
    }

    public int m() {
        return this.scalePower;
    }

    public Effect n() {
        return this.effect;
    }

    public boolean o() {
        return this.rotateThroughOnStart;
    }

    public int p() {
        return this.rotateThroughSpeedMult;
    }

    public static enum Effect {
        ROTATE_3D(1),
        EXCHANGE(2),
        FLY_IN(3);
        
        private int index;

        private Effect(int n3) {
            this.index = n3;
        }

        public static Effect getByIndex(int n2) {
            Effect effect = ROTATE_3D;
            Effect[] arreffect = Effect.values();
            for (int i2 = 0; i2 < arreffect.length; ++i2) {
                if (arreffect[i2].getIndex() != n2) continue;
                effect = arreffect[i2];
            }
            return effect;
        }

        public static Effect getByName(String string2) {
            Effect effect = ROTATE_3D;
            Effect[] arreffect = Effect.values();
            for (int i2 = 0; i2 < arreffect.length; ++i2) {
                if (arreffect[i2].name().toLowerCase().compareTo(string2.toLowerCase()) != 0) continue;
                effect = arreffect[i2];
            }
            return effect;
        }

        public final int getIndex() {
            return this.index;
        }

        public final int getRotationMultiplier() {
            return (int)Math.pow(2.0, this.index - 1);
        }
    }

}

