/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Camera
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 */
package com.startapp.android.publish.banner.banner3d;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Camera;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.a;
import com.startapp.android.publish.a.f;
import com.startapp.android.publish.adinformation.a;
import com.startapp.android.publish.adinformation.b;
import com.startapp.android.publish.banner.BannerOptions;
import com.startapp.android.publish.banner.banner3d.Banner3DFace;
import com.startapp.android.publish.banner.banner3d.Banner3DSize;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.q;
import com.startapp.android.publish.model.AdDetails;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Banner3D
extends RelativeLayout
implements AdEventListener {
    private static final String TAG = "StartAppWall.Banner3D";
    private static final int TIMEOUT_RESTORE = 200;
    private AdPreferences adPreferences;
    private a ads;
    private List<AdDetails> adsItems;
    private boolean animation = false;
    private boolean attachedToWindow = false;
    private Camera camera = null;
    private int currentBannerIndex = 0;
    private boolean defaultLoad = true;
    private List<Banner3DFace> faces;
    private boolean firstRotation = true;
    private boolean firstRotationFinished = false;
    private boolean loaded = false;
    private boolean loading = false;
    private Runnable mAutoRotation;
    private Matrix matrix = null;
    private BannerOptions options;
    private b overrides;
    private Paint paint = null;
    private boolean rotating = true;
    private float rotation = 45.0f;
    private float startY = 0.0f;
    private boolean touchDown = false;
    private boolean visible = true;

    public Banner3D(Context context) {
        super(context);
        this.mAutoRotation = new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Override
            public void run() {
                if (!Banner3D.this.loaded) return;
                if (Banner3D.this.faces.size() == 0) {
                    return;
                }
                if (Banner3D.this.visible && Banner3D.this.isShown()) {
                    ((Banner3DFace)Banner3D.this.faces.get(Banner3D.this.getCurrentBannerIndex())).a(Banner3D.this.getContext());
                }
                if (Banner3D.this.rotating) {
                    Banner3D banner3D = Banner3D.this;
                    int n2 = Banner3D.this.getBannerOptions().b();
                    int n3 = !Banner3D.this.firstRotationFinished ? Banner3D.this.options.p() : 1;
                    banner3D.rotate(n3 * n2);
                }
                if (Banner3D.this.rotation > (float)(90 - Banner3D.this.getBannerOptions().b()) && Banner3D.this.rotation < (float)(Banner3D.this.getBannerOptions().b() + 90) && !Banner3D.this.firstRotation) {
                    Banner3D.this.postDelayed((Runnable)this, (long)Banner3D.this.getBannerOptions().c());
                } else {
                    Banner3D.this.postDelayed((Runnable)this, (long)Banner3D.this.getBannerOptions().a());
                }
                if (Banner3D.this.getNextBannerIndex() != 0) return;
                Banner3D.this.firstRotation = false;
            }
        };
        this.init();
    }

    public Banner3D(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mAutoRotation = new ;
        this.init();
    }

    public Banner3D(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        this.mAutoRotation = new ;
        this.init();
    }

    public Banner3D(Context context, boolean bl) {
        this(context, bl, new AdPreferences());
    }

    public Banner3D(Context context, boolean bl, AdPreferences adPreferences) {
        super(context);
        this.mAutoRotation = new ;
        this.defaultLoad = bl;
        this.adPreferences = adPreferences;
        this.init();
    }

    private void addAdInformationLayout() {
        RelativeLayout relativeLayout = new RelativeLayout(this.getContext());
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((int)((float)this.getSuggestedMinimumWidth() * this.options.j()), (int)((float)this.getSuggestedMinimumHeight() * this.options.k()));
        layoutParams.addRule(13);
        this.addView((View)relativeLayout, (ViewGroup.LayoutParams)layoutParams);
        new com.startapp.android.publish.adinformation.a(this.getContext(), a.b.a, AdPreferences.Placement.INAPP_BANNER, this.overrides).a(relativeLayout);
    }

    private void drawFace(Canvas canvas, Bitmap bitmap, int n2, int n3, int n4, int n5, float f2, float f3) {
        if (this.camera == null) {
            this.camera = new Camera();
        }
        this.camera.save();
        this.camera.translate(0.0f, 0.0f, (float)n5);
        this.camera.rotateX(f3);
        this.camera.translate(0.0f, 0.0f, (float)(- n5));
        if (this.matrix == null) {
            this.matrix = new Matrix();
        }
        this.camera.getMatrix(this.matrix);
        this.camera.restore();
        this.matrix.preTranslate((float)(- n4), (float)(- n5));
        this.matrix.postScale(f2, f2);
        this.matrix.postTranslate((float)(n3 + n4), (float)(n2 + n5));
        canvas.drawBitmap(bitmap, this.matrix, this.paint);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void drawFrame(Canvas canvas) {
        int n2 = (int)((float)q.a(this.getContext(), this.options.d()) * this.options.j());
        int n3 = (int)((float)q.a(this.getContext(), this.options.e()) * this.options.k());
        int n4 = (this.getWidth() - n2) / 2;
        int n5 = (this.getHeight() - n3) / 2;
        float f2 = this.options.l() + (float)Math.pow(Math.abs(this.rotation - 45.0f) / 45.0f, this.options.m()) * (1.0f - this.options.l());
        if (!this.firstRotationFinished) {
            f2 = this.options.l();
        }
        Bitmap bitmap = this.getPreviousBitmap();
        Bitmap bitmap2 = this.getCurrentBitmap();
        if (bitmap2 == null || bitmap == null) return;
        try {
            if (this.rotation < 45.0f) {
                if (this.rotation > 3.0f) {
                    this.drawFace(canvas, bitmap2, n5, n4, n2 / 2, n3 / 2, f2, (this.rotation - 90.0f) * (float)this.options.n().getRotationMultiplier());
                }
                this.drawFace(canvas, bitmap, n5, n4, n2 / 2, n3 / 2, f2, this.rotation * (float)this.options.n().getRotationMultiplier());
                return;
            }
            if (this.rotation < 87.0f) {
                this.drawFace(canvas, bitmap, n5, n4, n2 / 2, n3 / 2, f2, this.rotation * (float)this.options.n().getRotationMultiplier());
            }
            this.drawFace(canvas, bitmap2, n5, n4, n2 / 2, n3 / 2, f2, (this.rotation - 90.0f) * (float)this.options.n().getRotationMultiplier());
            if (this.firstRotation) return;
            this.firstRotationFinished = true;
            return;
        }
        catch (Exception var1_2) {
            j.a(6, "Exception onDraw Banner3D");
        }
    }

    private BannerOptions getBannerOptions() {
        return this.options;
    }

    private int getCurrentBannerIndex() {
        return this.currentBannerIndex;
    }

    private Bitmap getCurrentBitmap() {
        return this.faces.get(this.getCurrentBannerIndex()).b();
    }

    private int getNextBannerIndex() {
        return (this.currentBannerIndex + 1) % this.getTotalBaners();
    }

    private Bitmap getPreviousBitmap() {
        int n2 = this.getCurrentBannerIndex();
        int n3 = this.faces.size();
        int n4 = this.faces.size();
        return this.faces.get((n2 - 1 + n3) % n4).b();
    }

    private int getTotalBaners() {
        return this.faces.size();
    }

    private void init() {
        if (!this.isInEditMode()) {
            this.initRuntime();
            return;
        }
        this.initDebug();
    }

    private void initDebug() {
        this.setMinimumWidth(q.a(this.getContext(), 300));
        this.setMinimumHeight(q.a(this.getContext(), 50));
        this.setBackgroundColor(Color.rgb((int)169, (int)169, (int)169));
        TextView textView = new TextView(this.getContext());
        textView.setText((CharSequence)"StartApp Banner3D");
        textView.setTextColor(-16777216);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(13);
        this.addView((View)textView, (ViewGroup.LayoutParams)layoutParams);
    }

    private void initFaces(List<AdDetails> object) {
        this.faces = new ArrayList<Banner3DFace>();
        object = object.iterator();
        while (object.hasNext()) {
            AdDetails adDetails = (AdDetails)object.next();
            this.faces.add(new Banner3DFace(this.getContext(), (ViewGroup)this, adDetails, this.getBannerOptions()));
        }
        this.currentBannerIndex = 0;
    }

    private void initRuntime() {
        if (!this.loading) {
            this.options = MetaData.getInstance().getBannerOptions();
            this.adsItems = new ArrayList<AdDetails>();
            this.adPreferences = new AdPreferences();
            this.overrides = b.a();
            this.faces = new ArrayList<Banner3DFace>();
            this.loading = true;
            this.setBackgroundColor(0);
            this.postDelayed(new Runnable(){

                @Override
                public void run() {
                    if (Banner3D.this.defaultLoad) {
                        Banner3D.this.load();
                    }
                }
            }, 200);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void loadBanners(List<AdDetails> iterator) {
        this.adsItems = iterator;
        if (iterator != null) {
            if (!this.setBannerSize()) {
                j.a(6, "StartAppWall.Banner3DError in banner screen size");
                this.setVisibility(8);
                return;
            }
            this.setMinimumWidth(q.a(this.getContext(), this.options.d()));
            this.setMinimumHeight(q.a(this.getContext(), this.options.e()));
            if (this.faces == null || this.faces.size() == 0) {
                this.initFaces((List<AdDetails>)((Object)iterator));
            } else {
                iterator = this.faces.iterator();
                while (iterator.hasNext()) {
                    iterator.next().a(this.getContext(), this.getBannerOptions(), (ViewGroup)this);
                }
            }
            this.addAdInformationLayout();
            if (this.paint == null) {
                this.paint = new Paint();
                this.paint.setAntiAlias(true);
                this.paint.setFilterBitmap(true);
            }
            if (!this.animation) {
                this.animation = true;
                this.startRotation();
            }
            if (this.visible) {
                this.setVisibility(0);
            }
        }
    }

    private void nextBanner() {
        this.currentBannerIndex = (this.currentBannerIndex + 1) % this.getTotalBaners();
    }

    private void prevBanner() {
        this.currentBannerIndex = (this.currentBannerIndex - 1 + this.getTotalBaners()) % this.getTotalBaners();
    }

    private void rotate(float f2) {
        this.rotation += f2;
        if (this.rotation >= 90.0f) {
            this.nextBanner();
            this.rotation -= 90.0f;
        }
        if (this.rotation <= 0.0f) {
            this.prevBanner();
            this.rotation += 90.0f;
        }
        this.invalidate();
    }

    private boolean setBannerSize() {
        return Banner3DSize.a(this.getContext(), this.getParent(), this.getBannerOptions());
    }

    private void startRotation() {
        if (this.attachedToWindow) {
            this.removeCallbacks(this.mAutoRotation);
            this.post(this.mAutoRotation);
        }
    }

    public void hideBanner() {
        this.visible = false;
        this.setVisibility(8);
    }

    public void load() {
        if (!this.loaded) {
            this.ads = new a(this.getContext());
            if (this.adPreferences == null) {
                this.adPreferences = new AdPreferences();
            }
            this.ads.load(this.adPreferences, this);
            this.loading = false;
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.attachedToWindow = true;
        if (this.options == null || !this.options.o()) {
            this.firstRotation = false;
            this.firstRotationFinished = true;
        }
        this.startRotation();
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.attachedToWindow = false;
        this.removeCallbacks(this.mAutoRotation);
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.isInEditMode() && this.visible) {
            this.drawFrame(canvas);
        }
    }

    @Override
    public void onFailedToReceiveAd(Ad ad) {
    }

    @Override
    public void onReceiveAd(Ad ad) {
        this.loaded = true;
        this.overrides = this.ads.getAdInfoOverride();
        this.loadBanners(((f)ad).a());
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onRestoreInstanceState(Parcelable object) {
        if (!(object instanceof SavedState)) {
            super.onRestoreInstanceState((Parcelable)object);
            return;
        }
        object = (SavedState)((Object)object);
        this.visible = object.bIsVisible;
        if (this.visible) {
            this.adsItems = object.getDetails();
            this.rotation = object.getRotation();
            this.firstRotation = object.isFirstRotation();
            this.currentBannerIndex = object.getCurrentImage();
            Banner3DFace[] arrbanner3DFace = object.faces;
            this.faces = new ArrayList<Banner3DFace>();
            if (arrbanner3DFace != null) {
                for (int i2 = 0; i2 < arrbanner3DFace.length; ++i2) {
                    this.faces.add(arrbanner3DFace[i2]);
                }
            }
            this.loaded = object.loaded;
            this.loading = object.loading;
            this.defaultLoad = object.bDefaultLoad;
            this.overrides = object.overrides;
            this.options = object.options;
            this.adPreferences = object.adPreferences;
            if (this.adsItems.size() == 0) {
                this.defaultLoad = true;
                this.init();
            } else {
                this.post(new Runnable(){

                    @Override
                    public void run() {
                        Banner3D.this.loadBanners(Banner3D.this.adsItems);
                    }
                });
            }
        }
        super.onRestoreInstanceState(object.getSuperState());
    }

    protected Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.bIsVisible = this.visible;
        savedState.setDetails(this.adsItems);
        savedState.setRotation(this.rotation);
        savedState.setFirstRotation(this.firstRotation);
        savedState.setCurrentImage(this.currentBannerIndex);
        savedState.options = this.options;
        savedState.adPreferences = this.adPreferences;
        savedState.faces = new Banner3DFace[this.faces.size()];
        savedState.loaded = this.loaded;
        savedState.loading = this.loading;
        savedState.overrides = this.overrides;
        for (int i2 = 0; i2 < this.faces.size(); ++i2) {
            savedState.faces[i2] = this.faces.get(i2);
        }
        return savedState;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean onTouchEvent(MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0: {
                this.touchDown = true;
                this.startY = motionEvent.getY();
                return true;
            }
            case 2: {
                if (this.startY - motionEvent.getY() < 10.0f) return true;
                {
                    this.touchDown = false;
                    this.startY = motionEvent.getY();
                    return true;
                }
            }
            default: {
                return true;
            }
            case 1: 
        }
        if (!this.touchDown) return true;
        {
            if (this.rotation < 45.0f) {
                this.prevBanner();
            }
            this.touchDown = false;
            this.rotating = false;
            this.postDelayed(new Runnable(){

                @Override
                public void run() {
                    Banner3D.this.rotating = true;
                }
            }, 5000);
            this.faces.get(this.getCurrentBannerIndex()).b(this.getContext());
            return true;
        }
    }

    public void showBanner() {
        this.visible = true;
        this.setVisibility(0);
    }

    static class SavedState
    extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>(){

            public final SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public final SavedState[] newArray(int n2) {
                return new SavedState[n2];
            }
        };
        public AdPreferences adPreferences;
        public boolean bDefaultLoad;
        public boolean bIsVisible;
        private int currentImage;
        private AdDetails[] details;
        public Banner3DFace[] faces;
        private int firstRotation;
        public boolean loaded;
        public boolean loading;
        public BannerOptions options;
        public b overrides;
        private float rotation;

        private SavedState(Parcel parcel) {
            super(parcel);
            if (parcel.readInt() == 1) {
                int n2;
                this.bIsVisible = true;
                this.currentImage = parcel.readInt();
                this.rotation = parcel.readFloat();
                this.firstRotation = parcel.readInt();
                Parcelable[] arrparcelable = parcel.readParcelableArray(AdDetails.class.getClassLoader());
                if (arrparcelable != null) {
                    this.details = new AdDetails[arrparcelable.length];
                    System.arraycopy(arrparcelable, 0, this.details, 0, arrparcelable.length);
                }
                int n3 = parcel.readInt();
                this.loaded = false;
                if (n3 == 1) {
                    this.loaded = true;
                }
                n3 = parcel.readInt();
                this.loading = false;
                if (n3 == 1) {
                    this.loading = true;
                }
                n3 = parcel.readInt();
                this.bDefaultLoad = false;
                if (n3 == 1) {
                    this.bDefaultLoad = true;
                }
                if ((n2 = parcel.readInt()) > 0) {
                    this.faces = new Banner3DFace[n2];
                    for (n3 = 0; n3 < n2; ++n3) {
                        this.faces[n3] = (Banner3DFace)parcel.readParcelable(Banner3DFace.class.getClassLoader());
                    }
                }
                this.overrides = (b)parcel.readSerializable();
                this.options = (BannerOptions)parcel.readSerializable();
                this.adPreferences = (AdPreferences)parcel.readSerializable();
                return;
            }
            this.bIsVisible = false;
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public int describeContents() {
            return 0;
        }

        public int getCurrentImage() {
            return this.currentImage;
        }

        public List<AdDetails> getDetails() {
            return Arrays.asList(this.details);
        }

        public float getRotation() {
            return this.rotation;
        }

        public boolean isFirstRotation() {
            if (this.firstRotation == 1) {
                return true;
            }
            return false;
        }

        public void setCurrentImage(int n2) {
            this.currentImage = n2;
        }

        public void setDetails(List<AdDetails> list) {
            this.details = new AdDetails[list.size()];
            for (int i2 = 0; i2 < list.size(); ++i2) {
                this.details[i2] = list.get(i2);
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public void setFirstRotation(boolean bl) {
            int n2 = bl ? 1 : 0;
            this.firstRotation = n2;
        }

        public void setRotation(float f2) {
            this.rotation = f2;
        }

        /*
         * Enabled aggressive block sorting
         */
        public void writeToParcel(Parcel parcel, int n2) {
            int n3 = 1;
            int n4 = 0;
            super.writeToParcel(parcel, n2);
            if (!this.bIsVisible) {
                parcel.writeInt(0);
                return;
            }
            parcel.writeInt(1);
            parcel.writeInt(this.currentImage);
            parcel.writeFloat(this.rotation);
            parcel.writeInt(this.firstRotation);
            parcel.writeParcelableArray(this.details, n2);
            int n5 = this.loaded ? 1 : 0;
            parcel.writeInt(n5);
            n5 = this.loading ? 1 : 0;
            parcel.writeInt(n5);
            n5 = this.bDefaultLoad ? n3 : 0;
            parcel.writeInt(n5);
            parcel.writeInt(this.faces.length);
            n5 = n4;
            do {
                if (n5 >= this.faces.length) {
                    parcel.writeSerializable((Serializable)this.overrides);
                    parcel.writeSerializable((Serializable)this.options);
                    parcel.writeSerializable((Serializable)this.adPreferences);
                    return;
                }
                parcel.writeParcelable((Parcelable)this.faces[n5], n2);
                ++n5;
            } while (true);
        }

    }

}

