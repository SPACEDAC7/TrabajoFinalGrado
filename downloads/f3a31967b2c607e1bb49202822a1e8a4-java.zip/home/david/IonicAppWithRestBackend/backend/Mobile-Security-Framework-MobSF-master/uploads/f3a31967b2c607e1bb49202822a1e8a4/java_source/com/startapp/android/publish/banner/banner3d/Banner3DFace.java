/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.Point
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 */
package com.startapp.android.publish.banner.banner3d;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Point;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.startapp.android.publish.banner.BannerOptions;
import com.startapp.android.publish.banner.banner3d.a;
import com.startapp.android.publish.g.f;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.q;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdDetails;

public class Banner3DFace
implements Parcelable,
f.a {
    public static final Parcelable.Creator<Banner3DFace> CREATOR = new Parcelable.Creator<Banner3DFace>(){

        public final Banner3DFace a(Parcel parcel) {
            return new Banner3DFace(parcel);
        }

        public final Banner3DFace[] a(int n2) {
            return new Banner3DFace[n2];
        }

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return this.a(parcel);
        }

        public final /* synthetic */ Object[] newArray(int n2) {
            return this.a(n2);
        }
    };
    private AdDetails a;
    private Point b;
    private Bitmap c = null;
    private Bitmap d = null;
    private Boolean e = false;
    private a f = null;

    public Banner3DFace(Context context, ViewGroup viewGroup, AdDetails adDetails, BannerOptions bannerOptions) {
        this.a = adDetails;
        this.a(context, bannerOptions, viewGroup);
    }

    public Banner3DFace(Parcel parcel) {
        this.a = (AdDetails)parcel.readParcelable(AdDetails.class.getClassLoader());
        this.b = new Point(1, 1);
        this.b.x = parcel.readInt();
        this.b.y = parcel.readInt();
        this.c = (Bitmap)parcel.readParcelable(Bitmap.class.getClassLoader());
        this.d = (Bitmap)parcel.readParcelable(Bitmap.class.getClassLoader());
        boolean[] arrbl = new boolean[1];
        parcel.readBooleanArray(arrbl);
        this.e = arrbl[0];
    }

    private Bitmap a(View view) {
        view.measure(view.getMeasuredWidth(), view.getMeasuredHeight());
        Bitmap bitmap = Bitmap.createBitmap((int)view.getMeasuredWidth(), (int)view.getMeasuredHeight(), (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        view.draw(canvas);
        return bitmap;
    }

    private void c() {
        this.d = this.a((View)this.f);
        if (this.b.x > 0 && this.b.y > 0) {
            this.d = Bitmap.createScaledBitmap((Bitmap)this.d, (int)this.b.x, (int)this.b.y, (boolean)false);
        }
    }

    public AdDetails a() {
        return this.a;
    }

    public void a(Context context) {
        if (!this.e.booleanValue()) {
            j.a(3, "Sending Impression: [" + this.a().getTitle() + "]");
            r.b(context, this.a().getTrackingUrl());
            this.e = true;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(Context context, BannerOptions bannerOptions, ViewGroup viewGroup) {
        int n2 = q.a(context, bannerOptions.e() - 5);
        this.b = new Point((int)((float)q.a(context, bannerOptions.d()) * bannerOptions.j()), (int)((float)q.a(context, bannerOptions.e()) * bannerOptions.k()));
        this.f = new a(context, new Point(bannerOptions.d(), bannerOptions.e()));
        this.f.setText(this.a().getTitle());
        this.f.setRating(this.a().getRating());
        this.f.setDescription(this.a().getDescription());
        this.f.setButtonText(this.a.isCPE());
        if (this.c != null) {
            this.f.a(this.c, n2, n2);
        } else {
            this.f.a(17301651, n2, n2);
            new f(this.a().getImageUrl(), this, 0).a();
            j.a(3, " Banner Face Image Async Request: [" + this.a().getTitle() + "]");
        }
        context = new RelativeLayout.LayoutParams(this.b.x, this.b.y);
        context.addRule(13);
        viewGroup.addView((View)this.f, (ViewGroup.LayoutParams)context);
        this.f.setVisibility(8);
        this.c();
    }

    @Override
    public void a(Bitmap bitmap, int n2) {
        if (bitmap != null && this.f != null) {
            this.c = bitmap;
            this.f.setImage(bitmap);
            this.c();
        }
    }

    public Bitmap b() {
        return this.d;
    }

    public void b(Context context) {
        String string2 = this.a().getIntentPackageName();
        if (string2 != null && !"null".equals(string2) && !TextUtils.isEmpty((CharSequence)string2)) {
            r.a(string2, this.a().getIntentDetails(), this.a().getClickUrl(), context);
            return;
        }
        if (this.a().isSmartRedirect()) {
            r.a(context, this.a().getClickUrl(), this.a().getTrackingClickUrl(), 4000);
            return;
        }
        r.a(context, this.a().getClickUrl(), this.a().getTrackingClickUrl());
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeParcelable((Parcelable)this.a(), n2);
        parcel.writeInt(this.b.x);
        parcel.writeInt(this.b.y);
        parcel.writeParcelable((Parcelable)this.c, n2);
        parcel.writeParcelable((Parcelable)this.b(), n2);
        parcel.writeBooleanArray(new boolean[]{this.e});
    }

}

