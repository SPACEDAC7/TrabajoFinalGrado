/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.graphics.Point
 *  android.view.View
 *  android.view.ViewParent
 *  android.view.Window
 *  android.view.WindowManager
 */
package com.startapp.android.publish.banner.banner3d;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.view.View;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import com.startapp.android.publish.banner.Banner;
import com.startapp.android.publish.banner.BannerOptions;
import com.startapp.android.publish.banner.a;
import com.startapp.android.publish.g.b;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.q;

public class Banner3DSize {
    public static boolean a(Context object, ViewParent arrsize, BannerOptions bannerOptions) {
        j.a(3, "============== Optimize Size ==========");
        object = Banner3DSize.b((Context)object, (ViewParent)arrsize, bannerOptions);
        arrsize = Size.values();
        int n2 = arrsize.length;
        boolean bl = false;
        for (int i2 = 0; i2 < n2; ++i2) {
            Size size = arrsize[i2];
            boolean bl2 = bl;
            if (size.getSize().a() <= object.a()) {
                bl2 = bl;
                if (size.getSize().b() <= object.b()) {
                    j.a(3, "BannerSize [" + size.getSize().a() + "," + size.getSize().b() + "]");
                    bannerOptions.a(size.getSize().a(), size.getSize().b());
                    bl2 = true;
                }
            }
            bl = bl2;
        }
        if (!bl) {
            bannerOptions.a(0, 0);
        }
        j.a(3, "============== Optimize Size [" + bl + "] ==========");
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static a b(Context context, ViewParent viewParent, BannerOptions bannerOptions) {
        Point point = new Point();
        point.x = bannerOptions.d();
        point.y = bannerOptions.e();
        j.a(3, "=============== set Application Size ===========");
        if (context instanceof Activity) {
            j.a(3, "Context is Activity");
            bannerOptions = ((Activity)context).getWindow().getDecorView();
            try {
                viewParent = (View)viewParent;
                if (viewParent instanceof Banner) {
                    j.a(3, "Parent is instance of Wrapper Banner");
                    viewParent = (View)viewParent.getParent();
                }
                point.x = q.b(context, viewParent.getMeasuredWidth() - viewParent.getPaddingLeft() - viewParent.getPaddingRight() + 1);
                point.y = q.b(context, viewParent.getMeasuredHeight() - viewParent.getPaddingBottom() - viewParent.getPaddingTop() + 1);
            }
            catch (Exception var1_2) {
                point.x = q.b(context, bannerOptions.getMeasuredWidth());
                point.y = q.b(context, bannerOptions.getMeasuredHeight());
                j.a(3, "Exception occoured");
            }
        } else {
            j.a(3, "Context not Activity, get max win size");
            viewParent = (WindowManager)context.getSystemService("window");
            if (viewParent != null) {
                b.a(context, (WindowManager)viewParent, point);
            }
        }
        j.a(3, "============ exit Application Size [" + point.x + "," + point.y + "] =========");
        return new a(point.x, point.y);
    }

    public static enum Size {
        XXSMALL(new a(280, 50)),
        XSMALL(new a(300, 50)),
        SMALL(new a(320, 50)),
        MEDIUM(new a(468, 60)),
        LARGE(new a(728, 90)),
        XLARGE(new a(1024, 90));
        
        private a convertedSize = null;
        private a size;

        private Size(a a2) {
            this.size = a2;
        }

        public final a getConvertedSize(Context context) {
            if (this.convertedSize == null) {
                this.convertedSize = new a(q.a(context, this.getSize().a()), q.a(context, this.getSize().b()));
            }
            return this.convertedSize;
        }

        public final a getSize() {
            return this.size;
        }
    }

}

