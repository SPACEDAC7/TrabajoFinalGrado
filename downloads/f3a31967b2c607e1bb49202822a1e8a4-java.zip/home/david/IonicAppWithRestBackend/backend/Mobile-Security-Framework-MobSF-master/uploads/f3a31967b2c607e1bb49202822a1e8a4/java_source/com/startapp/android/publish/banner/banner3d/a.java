/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.EmbossMaskFilter
 *  android.graphics.LinearGradient
 *  android.graphics.MaskFilter
 *  android.graphics.Paint
 *  android.graphics.Point
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.GradientDrawable
 *  android.graphics.drawable.GradientDrawable$Orientation
 *  android.graphics.drawable.ShapeDrawable
 *  android.graphics.drawable.shapes.RoundRectShape
 *  android.graphics.drawable.shapes.Shape
 *  android.text.TextUtils
 *  android.text.TextUtils$TruncateAt
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 */
package com.startapp.android.publish.banner.banner3d;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.EmbossMaskFilter;
import android.graphics.LinearGradient;
import android.graphics.MaskFilter;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.startapp.android.publish.banner.banner3d.Banner3DSize;
import com.startapp.android.publish.g.m;
import com.startapp.android.publish.g.q;
import com.startapp.android.publish.model.MetaData;
import java.util.Set;

public class a
extends RelativeLayout {
    private TextView a;
    private TextView b;
    private ImageView c;
    private m d;
    private TextView e;
    private Point f;

    public a(Context context, Point point) {
        super(context);
        this.f = point;
        this.a();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a() {
        var9_1 = this.getContext();
        var8_2 = this.getTemplateBySize();
        this.setBackgroundDrawable((Drawable)new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{MetaData.getInstance().getItemGradientTop(), MetaData.getInstance().getItemGradientBottom()}));
        this.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
        var1_3 = q.a((Context)var9_1, 2);
        var2_4 = q.a((Context)var9_1, 3);
        q.a((Context)var9_1, 4);
        var3_5 = q.a((Context)var9_1, 5);
        var4_6 = q.a((Context)var9_1, 6);
        var5_7 = q.a((Context)var9_1, 8);
        q.a((Context)var9_1, 10);
        var6_8 = q.a((Context)var9_1, 20);
        q.a((Context)var9_1, 84);
        var7_9 = q.a((Context)var9_1, 90);
        this.setPadding(var3_5, 0, var3_5, 0);
        this.setTag((Object)this);
        this.c = new ImageView((Context)var9_1);
        this.c.setId(1);
        var10_10 = new RelativeLayout.LayoutParams(var7_9, var7_9);
        var10_10.addRule(15);
        this.c.setLayoutParams((ViewGroup.LayoutParams)var10_10);
        this.a = new TextView((Context)var9_1);
        this.a.setId(2);
        var10_10 = new RelativeLayout.LayoutParams(-2, -2);
        var10_10.addRule(1, 1);
        var10_10.addRule(14);
        this.a.setLayoutParams((ViewGroup.LayoutParams)var10_10);
        this.a.setTextColor(MetaData.getInstance().getItemTitleTextColor().intValue());
        switch (.a[var8_2.ordinal()]) {
            case 1: 
            case 2: {
                this.a.setTextSize(17.0f);
                this.a.setPadding(var2_4, 0, 0, var1_3);
                var10_10.width = q.a(this.getContext(), (int)((double)this.f.x * 0.55));
                ** break;
            }
            case 3: {
                this.a.setTextSize(17.0f);
                this.a.setPadding(var2_4, 0, 0, var1_3);
                var10_10.width = q.a(this.getContext(), (int)((double)this.f.x * 0.65));
            }
lbl39: // 3 sources:
            default: {
                ** GOTO lbl44
            }
            case 4: 
            case 5: 
        }
        this.a.setTextSize(22.0f);
        this.a.setPadding(var2_4, 0, 0, var3_5);
lbl44: // 2 sources:
        this.a.setSingleLine(true);
        this.a.setEllipsize(TextUtils.TruncateAt.END);
        q.a(this.a, MetaData.getInstance().getItemTitleTextDecoration());
        this.b = new TextView((Context)var9_1);
        this.b.setId(3);
        var10_10 = new RelativeLayout.LayoutParams(-1, -2);
        var10_10.addRule(1, 1);
        var10_10.addRule(3, 2);
        var10_10.setMargins(0, 0, 0, var3_5);
        this.b.setLayoutParams((ViewGroup.LayoutParams)var10_10);
        this.b.setTextColor(MetaData.getInstance().getItemDescriptionTextColor().intValue());
        this.b.setTextSize(18.0f);
        this.b.setMaxLines(2);
        this.b.setLines(2);
        this.b.setSingleLine(false);
        this.b.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        this.b.setHorizontallyScrolling(true);
        this.b.setPadding(var2_4, 0, 0, 0);
        this.d = new m(this.getContext());
        this.d.setId(5);
        var11_11 = new RelativeLayout.LayoutParams(-2, -2);
        switch (.a[var8_2.ordinal()]) {
            case 1: 
            case 2: 
            case 3: {
                var11_11.addRule(1, 1);
                var11_11.addRule(8, 1);
            }
            default: {
                break;
            }
            case 4: 
            case 5: {
                var11_11.addRule(1, 2);
                var10_10.width = q.a(this.getContext(), (int)((double)this.f.x * 0.6));
            }
        }
        var11_11.setMargins(var2_4, var5_7, var2_4, 0);
        this.d.setLayoutParams((ViewGroup.LayoutParams)var11_11);
        this.e = new TextView((Context)var9_1);
        var9_1 = new RelativeLayout.LayoutParams(-2, -2);
        switch (.a[var8_2.ordinal()]) {
            case 1: 
            case 2: 
            case 3: {
                this.e.setTextSize(13.0f);
                var9_1.addRule(1, 2);
                var9_1.addRule(15);
                ** break;
            }
            case 4: {
                var9_1.addRule(1, 3);
                var9_1.addRule(15);
                var9_1.setMargins(var6_8, 0, 0, 0);
                this.e.setTextSize(26.0f);
            }
lbl89: // 3 sources:
            default: {
                ** GOTO lbl96
            }
            case 5: 
        }
        var9_1.addRule(1, 3);
        var9_1.addRule(15);
        var9_1.setMargins(var6_8 * 7, 0, 0, 0);
        this.e.setTextSize(26.0f);
lbl96: // 2 sources:
        this.e.setPadding(var4_6, var4_6, var4_6, var4_6);
        this.e.setLayoutParams((ViewGroup.LayoutParams)var9_1);
        this.setButtonText(false);
        this.e.setTextColor(-1);
        this.e.setTypeface(null, 1);
        this.e.setId(4);
        this.e.setShadowLayer(2.5f, -3.0f, 3.0f, -9013642);
        var9_1 = new ShapeDrawable((Shape)new RoundRectShape(new float[]{10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f}, null, null)){

            protected void onDraw(Shape shape, Canvas canvas, Paint paint) {
                paint.setShader((Shader)new LinearGradient(0.0f, 0.0f, 0.0f, shape.getHeight(), -4466580, -11363070, Shader.TileMode.REPEAT));
                paint.setMaskFilter((MaskFilter)new EmbossMaskFilter(new float[]{1.0f, 1.0f, 1.0f}, 0.4f, 5.0f, 3.0f));
                super.onDraw(shape, canvas, paint);
            }
        };
        this.e.setBackgroundDrawable((Drawable)var9_1);
        this.addView((View)this.c);
        this.addView((View)this.a);
        switch (.a[var8_2.ordinal()]) {
            case 1: 
            case 2: 
            case 3: {
                this.addView((View)this.e);
            }
            default: {
                break;
            }
            case 4: 
            case 5: {
                this.addView((View)this.e);
                this.addView((View)this.b);
            }
        }
        this.addView((View)this.d);
    }

    /*
     * Enabled aggressive block sorting
     */
    private String[] a(String string2) {
        String[] arrstring;
        int n2;
        int n3;
        int n4;
        block3 : {
            n2 = 55;
            arrstring = new String[2];
            if (string2.length() <= 55) {
                arrstring[0] = string2;
                arrstring[1] = null;
                return arrstring;
            }
            char[] arrc = string2.substring(0, 55).toCharArray();
            n4 = arrc.length - 1;
            for (n3 = n4 - 1; n3 > 0; --n3) {
                if (arrc[n3] != ' ') continue;
                n4 = 1;
                break block3;
            }
            n3 = n4;
            n4 = 0;
        }
        if (n4 == 0) {
            n3 = n2;
        }
        arrstring[0] = string2.substring(0, n3);
        arrstring[1] = string2.substring(n3 + 1, string2.length());
        return arrstring;
    }

    private a getTemplateBySize() {
        a a2 = a.b;
        if (this.f.x > Banner3DSize.Size.SMALL.getSize().a() || this.f.y > Banner3DSize.Size.SMALL.getSize().b()) {
            a2 = a.c;
        }
        if (this.f.x > Banner3DSize.Size.MEDIUM.getSize().a() || this.f.y > Banner3DSize.Size.MEDIUM.getSize().b()) {
            a2 = a.d;
        }
        if (this.f.x > Banner3DSize.Size.LARGE.getSize().a() || this.f.y > Banner3DSize.Size.LARGE.getSize().b()) {
            a2 = a.e;
        }
        return a2;
    }

    public void a(int n2, int n3, int n4) {
        this.c.setImageResource(n2);
        ViewGroup.LayoutParams layoutParams = this.c.getLayoutParams();
        layoutParams.width = n3;
        layoutParams.height = n4;
        this.c.setLayoutParams(layoutParams);
    }

    public void a(Bitmap bitmap, int n2, int n3) {
        this.c.setImageBitmap(bitmap);
        bitmap = this.c.getLayoutParams();
        bitmap.width = n2;
        bitmap.height = n3;
        this.c.setLayoutParams((ViewGroup.LayoutParams)bitmap);
    }

    public void setButtonText(boolean bl) {
        if (bl) {
            this.e.setText((CharSequence)"OPEN");
            return;
        }
        this.e.setText((CharSequence)"DOWNLOAD");
    }

    public void setDescription(String string2) {
        if (string2 != null && string2.compareTo("") != 0) {
            Object object = this.a(string2);
            String string3 = object[0];
            String string4 = "";
            if (object[1] != null) {
                string4 = this.a(object[1])[0];
            }
            object = string4;
            if (string2.length() >= 110) {
                object = string4 + "...";
            }
            this.b.setText((CharSequence)(string3 + "\n" + (String)object));
        }
    }

    public void setImage(Bitmap bitmap) {
        this.c.setImageBitmap(bitmap);
    }

    public void setRating(float f2) {
        this.d.setRating(f2);
    }

    public void setText(String string2) {
        this.a.setText((CharSequence)string2);
    }

    static enum a {
        a,
        b,
        c,
        d,
        e;
        

        private a() {
        }
    }

}

