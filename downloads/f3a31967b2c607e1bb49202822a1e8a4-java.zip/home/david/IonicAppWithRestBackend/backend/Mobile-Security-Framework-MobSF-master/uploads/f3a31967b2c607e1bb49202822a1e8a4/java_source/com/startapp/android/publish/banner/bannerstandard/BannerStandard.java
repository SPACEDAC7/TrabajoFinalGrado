/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.graphics.Color
 *  android.graphics.Point
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnLongClickListener
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.view.Window
 *  android.view.WindowManager
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 */
package com.startapp.android.publish.banner.bannerstandard;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.JsInterface;
import com.startapp.android.publish.a.b;
import com.startapp.android.publish.adinformation.a;
import com.startapp.android.publish.banner.Banner;
import com.startapp.android.publish.banner.BannerOptions;
import com.startapp.android.publish.banner.a;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.q;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;
import java.util.Timer;
import java.util.TimerTask;

public class BannerStandard
extends RelativeLayout
implements AdEventListener {
    private static final int ID_WEBVIEW = 159868225;
    private static final String TAG = "StartAppWall.BannerHtml";
    private static final int TIMEOUT_RESTART = 50;
    private static final int TIMEOUT_SMART_REDIRECT = 5000;
    private b adHtml;
    private RelativeLayout adInformationContatiner = null;
    private com.startapp.android.publish.adinformation.a adInformationLayout = null;
    private AdPreferences adPreferences;
    private boolean attachedToWindow = false;
    private boolean defaultLoad = true;
    private boolean loaded = false;
    private BannerOptions options;
    private String prevAdId = "";
    private boolean sentImpression = false;
    private a size;
    private Task task;
    private Timer timer = new Timer();
    private boolean visible = true;
    private WebView webView;

    public BannerStandard(Context context) {
        super(context);
        this.task = new Task();
        this.init();
    }

    public BannerStandard(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.task = new Task();
        this.init();
    }

    public BannerStandard(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        this.task = new Task();
        this.init();
    }

    public BannerStandard(Context context, boolean bl) {
        super(context);
        this.task = new Task();
        this.defaultLoad = bl;
        this.init();
    }

    public BannerStandard(Context context, boolean bl, AdPreferences adPreferences) {
        super(context);
        this.task = new Task();
        this.defaultLoad = bl;
        this.adPreferences = adPreferences;
        this.init();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void addAdInformationLayout() {
        RelativeLayout.LayoutParams layoutParams;
        layoutParams = new RelativeLayout.LayoutParams(this.getSuggestedMinimumWidth(), this.getSuggestedMinimumHeight());
        layoutParams.addRule(13);
        if (this.adInformationLayout == null && this.adInformationContatiner == null) {
            this.adInformationContatiner = new RelativeLayout(this.getContext());
            this.adInformationLayout = new com.startapp.android.publish.adinformation.a(this.getContext(), a.b.a, AdPreferences.Placement.INAPP_BANNER, this.adHtml.getAdInfoOverride());
            this.adInformationLayout.a(this.adInformationContatiner);
        }
        try {
            ViewGroup viewGroup = (ViewGroup)this.adInformationContatiner.getParent();
            if (viewGroup != null) {
                viewGroup.removeView((View)this.adInformationContatiner);
            }
        }
        catch (Exception var2_3) {}
        this.addView((View)this.adInformationContatiner, (ViewGroup.LayoutParams)layoutParams);
    }

    private void cancelReloadTask() {
        if (!this.isInEditMode()) {
            this.task.cancel();
            this.timer.cancel();
            this.task = null;
            this.timer = null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Point getAvailableSize() {
        Point point = new Point();
        Context context = this.getContext();
        if (context instanceof Activity) {
            View view = ((Activity)context).getWindow().getDecorView();
            try {
                View view2;
                context = view2 = (View)this.getParent();
                if (view2 instanceof Banner) {
                    context = (View)view2.getParent();
                }
                point.x = q.b(this.getContext(), context.getMeasuredWidth() - context.getPaddingLeft() - context.getPaddingRight() + 1);
                point.y = q.b(this.getContext(), context.getMeasuredHeight() - context.getPaddingBottom() - context.getPaddingTop() + 1);
            }
            catch (Exception var1_3) {
                point.x = q.b(this.getContext(), view.getMeasuredWidth());
                point.y = q.b(this.getContext(), view.getMeasuredHeight());
            }
        } else {
            WindowManager windowManager = (WindowManager)this.getContext().getSystemService("window");
            point.x = 300;
            point.y = 50;
            if (windowManager != null && context != null) {
                com.startapp.android.publish.g.b.a(context, windowManager, point);
            }
        }
        j.a(3, "StartAppWall.BannerHtml============ exit Application Size [" + point.x + "," + point.y + "] =========");
        return point;
    }

    private void init() {
        if (!this.isInEditMode()) {
            this.webView = new WebView(this.getContext());
            this.options = new BannerOptions();
            if (this.adPreferences == null) {
                this.adPreferences = new AdPreferences();
            }
            this.size = new a(300, 50);
            this.adHtml = new b(this.getContext());
            this.webView.setId(159868225);
            this.setVisibility(8);
            this.webView.setBackgroundColor(0);
            this.webView.setHorizontalScrollBarEnabled(false);
            this.webView.getSettings().setJavaScriptEnabled(true);
            this.webView.setVerticalScrollBarEnabled(false);
            this.webView.setOnTouchListener(new View.OnTouchListener(){

                public boolean onTouch(View view, MotionEvent motionEvent) {
                    if (motionEvent.getAction() == 2) {
                        return true;
                    }
                    return false;
                }
            });
            this.webView.setOnLongClickListener(new View.OnLongClickListener(){

                public boolean onLongClick(View view) {
                    return true;
                }
            });
            this.webView.setLongClickable(false);
            this.options = MetaData.getInstance().getBannerOptions();
            this.postDelayed(new Runnable(){

                /*
                 * Enabled aggressive block sorting
                 */
                @Override
                public void run() {
                    j.a(3, "StartAppWall.BannerHtmlInitializing BannerHtml");
                    int n2 = q.a(BannerStandard.this.getContext(), BannerStandard.this.size.a());
                    int n3 = q.a(BannerStandard.this.getContext(), BannerStandard.this.size.b());
                    BannerStandard.this.setMinimumWidth(n2);
                    BannerStandard.this.setMinimumHeight(n3);
                    BannerStandard.this.webView.addJavascriptInterface((Object)new JsInterface(BannerStandard.this.getContext(), new Runnable(){

                        @Override
                        public void run() {
                        }
                    }), "startappwall");
                    BannerStandard.this.webView.setWebViewClient((WebViewClient)new MyWebViewClient());
                    if (!BannerStandard.this.loaded) {
                        if (BannerStandard.this.defaultLoad) {
                            BannerStandard.this.load();
                        }
                    } else {
                        j.a(3, "StartAppWall.BannerHtmlBannerHTML already Loaded");
                        BannerStandard.this.onReceiveAd(BannerStandard.this.adHtml);
                    }
                    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(n2, n3);
                    layoutParams.addRule(13);
                    BannerStandard.this.addView((View)BannerStandard.this.webView, (ViewGroup.LayoutParams)layoutParams);
                }

            }, 50);
            return;
        }
        this.setMinimumWidth(q.a(this.getContext(), 300));
        this.setMinimumHeight(q.a(this.getContext(), 50));
        this.setBackgroundColor(Color.rgb((int)169, (int)169, (int)169));
        TextView textView = new TextView(this.getContext());
        textView.setText((CharSequence)"StartApp Standard Banner");
        textView.setTextColor(-16777216);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(13);
        this.addView((View)textView, (ViewGroup.LayoutParams)layoutParams);
    }

    private void loadHtml() {
        r.a(this.webView, this.adHtml.getHtml());
    }

    private void makeImpression() {
        if (!this.sentImpression && this.visible) {
            r.a(this.getContext(), this.adHtml.getTrackingUrls());
            this.sentImpression = true;
        }
    }

    private void reload() {
        j.a(3, "StartAppWall.BannerHtmlLoading from network");
        this.sentImpression = false;
        if (this.adPreferences == null) {
            this.adPreferences = new AdPreferences();
        }
        Point point = this.getAvailableSize();
        this.adHtml.setState(Ad.AdState.UN_INITIALIZED);
        this.adHtml.setSize(point.x, point.y);
        this.adHtml.load(this.adPreferences, this);
    }

    private void scheduleReloadTask() {
        if (!this.attachedToWindow || this.isInEditMode()) {
            return;
        }
        if (this.task != null) {
            this.task.cancel();
        }
        if (this.timer != null) {
            this.timer.cancel();
        }
        this.task = new Task();
        this.timer = new Timer();
        this.timer.scheduleAtFixedRate((TimerTask)this.task, this.options.h(), (long)this.options.h());
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean setSize(int n2, int n3) {
        Point point = this.getAvailableSize();
        if (point.x >= n2 && point.y >= n3) {
            this.size.a(n2, n3);
            n2 = q.a(this.getContext(), this.size.a());
            n3 = q.a(this.getContext(), this.size.b());
            this.setMinimumWidth(n2);
            this.setMinimumHeight(n3);
            point = this.webView.getLayoutParams();
            if (point == null) {
                point = new RelativeLayout.LayoutParams(n2, n3);
            } else {
                point.width = n2;
                point.height = n3;
            }
            this.webView.setLayoutParams((ViewGroup.LayoutParams)point);
            return true;
        }
        Point point2 = new Point(0, 0);
        point = this.webView.getLayoutParams();
        if (point == null) {
            point = new RelativeLayout.LayoutParams(point2.x, point2.y);
        } else {
            point.width = point2.x;
            point.height = point2.y;
        }
        this.webView.setLayoutParams((ViewGroup.LayoutParams)point);
        return false;
    }

    public void hideBanner() {
        this.visible = false;
        this.setVisibility(8);
    }

    public void load() {
        this.scheduleReloadTask();
        this.reload();
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.attachedToWindow = true;
        this.scheduleReloadTask();
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.attachedToWindow = false;
        this.cancelReloadTask();
    }

    @Override
    public void onFailedToReceiveAd(Ad ad) {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void onReceiveAd(Ad object) {
        j.a(3, "StartAppWall.BannerHtmlHtml Ad Recievied OK");
        this.removeView((View)this.adInformationContatiner);
        if (this.adHtml != null && this.adHtml.getHtml() != null && this.adHtml.getHtml().compareTo("") != 0) {
            object = r.a(this.adHtml.getHtml(), "@adId@", "@adId@");
            if (object == null || this.prevAdId == null || this.prevAdId.compareTo((String)object) != 0) {
                this.prevAdId = object;
                this.loadHtml();
                object = r.a(this.adHtml.getHtml(), "@width@", "@width@");
                String string2 = r.a(this.adHtml.getHtml(), "@height@", "@height@");
                try {
                    if (this.setSize(Integer.parseInt((String)object), Integer.parseInt(string2))) {
                        this.loaded = true;
                        this.addAdInformationLayout();
                        this.makeImpression();
                    }
                }
                catch (NumberFormatException var1_2) {
                    j.a(6, "StartAppWall.BannerHtmlError Casting width & height from HTML");
                }
            } else {
                this.addAdInformationLayout();
                this.makeImpression();
            }
        } else {
            j.a(6, "StartAppWall.BannerHtmlNo Banner recieved");
        }
        if (this.loaded) {
            if (this.visible) {
                this.setVisibility(0);
            }
            j.a(3, "StartAppWall.BannerHtmlDone Loading HTML Banner");
        }
    }

    public void showBanner() {
        this.visible = true;
        this.setVisibility(0);
    }

    class MyWebViewClient
    extends WebViewClient {
        private MyWebViewClient() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public boolean shouldOverrideUrlLoading(WebView object, String string2) {
            Context context = null;
            object = null;
            if (string2.contains("index=")) {
                try {
                    int n2 = r.a(string2);
                    if (BannerStandard.this.adHtml.getSmartRedirect(n2)) {
                        context = BannerStandard.this.getContext();
                        if (n2 < BannerStandard.this.adHtml.getTrackingClickUrls().length) {
                            object = BannerStandard.this.adHtml.getTrackingClickUrls()[n2];
                        }
                        r.a(context, string2, (String)object, 5000);
                    }
                    Context context2 = BannerStandard.this.getContext();
                    object = context;
                    if (n2 < BannerStandard.this.adHtml.getTrackingClickUrls().length) {
                        object = BannerStandard.this.adHtml.getTrackingClickUrls()[n2];
                    }
                    r.a(context2, string2, (String)object);
                }
                catch (Exception var1_2) {
                    j.a(6, "Error while trying parsing index from url");
                    return false;
                }
            } else if (BannerStandard.this.adHtml.getSmartRedirect(0)) {
                r.a(BannerStandard.this.getContext(), string2, BannerStandard.this.adHtml.getTrackingClickUrls()[0], 5000);
            } else {
                r.a(BannerStandard.this.getContext(), string2, BannerStandard.this.adHtml.getTrackingClickUrls()[0]);
            }
            BannerStandard.this.webView.stopLoading();
            return true;
        }
    }

    class Task
    extends TimerTask {
        private Task() {
        }

        @Override
        public void run() {
            BannerStandard.this.post(new Runnable(){

                @Override
                public void run() {
                    if (BannerStandard.this.isShown()) {
                        j.a(3, "StartAppWall.BannerHtmlREFRESH");
                        BannerStandard.this.reload();
                    }
                }
            });
        }

    }

}

