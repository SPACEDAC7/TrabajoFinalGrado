/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish;

import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.model.AdPreferences;

public interface c {
    public String getLauncherName();

    public Ad.AdState getState();

    public boolean isReady();

    public boolean load(AdPreferences var1, AdEventListener var2);

    public boolean show();
}

