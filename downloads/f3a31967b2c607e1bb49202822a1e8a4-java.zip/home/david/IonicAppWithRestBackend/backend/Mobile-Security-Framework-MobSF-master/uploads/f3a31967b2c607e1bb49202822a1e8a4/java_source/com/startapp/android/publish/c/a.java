/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.c;

import com.startapp.android.publish.c.c;

public class a
extends c {
}

