/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.KeyEvent
 */
package com.startapp.android.publish.c;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import com.startapp.android.publish.c.a;
import com.startapp.android.publish.c.d;
import com.startapp.android.publish.c.e;
import com.startapp.android.publish.c.f;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.model.AdPreferences;
import java.io.Serializable;

public abstract class b {
    private Intent a;
    private Activity b;
    private boolean[] c;
    private String d;
    private String[] e;
    private String[] f;
    private String g;
    private AdPreferences.Placement h;
    private boolean i;
    private com.startapp.android.publish.adinformation.b j;
    private int k;

    /*
     * Enabled aggressive block sorting
     */
    public static b a(Activity object, Intent intent, AdPreferences.Placement placement) {
        b b2;
        switch (.a[placement.ordinal()]) {
            default: {
                b2 = new a();
                break;
            }
            case 1: {
                b2 = new d();
                break;
            }
            case 2: 
            case 3: {
                b2 = new e();
                break;
            }
            case 4: {
                b2 = new f();
            }
        }
        b2.a = intent;
        b2.b = object;
        b2.d = intent.getStringExtra("position");
        b2.e = intent.getStringArrayExtra("tracking");
        b2.f = intent.getStringArrayExtra("trackingClickUrl");
        b2.a(intent.getBooleanArrayExtra("smartRedirect"));
        object = intent.getStringExtra("htmlUuid");
        if (object != null) {
            b2.g = com.startapp.android.publish.b.a.a().c((String)object);
        }
        b2.i = intent.getBooleanExtra("isSplash", false);
        b2.j = (com.startapp.android.publish.adinformation.b)intent.getSerializableExtra("adInfoOverride");
        b2.k = intent.getIntExtra("orientation", 1);
        b2.h = placement;
        if (b2.c() == null) {
            b2.a(new boolean[]{true});
        }
        j.a("GenericMode", 3, "Placement=[" + (Object)((Object)b2.h()) + "]");
        return b2;
    }

    private void a(int n2) {
        this.k = n2;
    }

    private void a(Activity activity) {
        this.b = activity;
    }

    private void a(Intent intent) {
        this.a = intent;
    }

    private void a(com.startapp.android.publish.adinformation.b b2) {
        this.j = b2;
    }

    private void a(AdPreferences.Placement placement) {
        this.h = placement;
    }

    private void a(String string2) {
        this.d = string2;
    }

    private void a(boolean bl) {
        this.i = bl;
    }

    private void a(String[] arrstring) {
        this.e = arrstring;
    }

    private void b(String string2) {
        this.g = string2;
    }

    private void b(String[] arrstring) {
        this.f = arrstring;
    }

    public Intent a() {
        return this.a;
    }

    public abstract void a(Bundle var1);

    protected void a(boolean[] arrbl) {
        this.c = arrbl;
    }

    public abstract boolean a(int var1, KeyEvent var2);

    public Activity b() {
        return this.b;
    }

    protected boolean[] c() {
        return this.c;
    }

    protected String d() {
        return this.g;
    }

    protected String e() {
        return this.d;
    }

    protected String[] f() {
        return this.e;
    }

    protected String[] g() {
        return this.f;
    }

    protected AdPreferences.Placement h() {
        return this.h;
    }

    protected com.startapp.android.publish.adinformation.b i() {
        return this.j;
    }

    protected int j() {
        return this.k;
    }

    public abstract void k();

    public abstract void l();

    public abstract void m();

}

