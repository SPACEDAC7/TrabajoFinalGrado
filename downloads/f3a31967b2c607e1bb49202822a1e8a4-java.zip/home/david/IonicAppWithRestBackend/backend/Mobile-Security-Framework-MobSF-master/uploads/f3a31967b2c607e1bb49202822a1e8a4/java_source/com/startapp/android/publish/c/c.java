/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.view.KeyEvent
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnLongClickListener
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.Window
 *  android.webkit.WebChromeClient
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 */
package com.startapp.android.publish.c;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import com.startapp.android.publish.JsInterface;
import com.startapp.android.publish.adinformation.a;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;

public class c
extends com.startapp.android.publish.c.b {
    protected WebView a;
    protected com.startapp.android.publish.adinformation.a b = null;
    protected BroadcastReceiver c;
    protected Runnable d;
    private int e;
    private a f = null;

    public c() {
        this.c = new BroadcastReceiver(){

            public void onReceive(Context context, Intent intent) {
                c.this.n();
            }
        };
        this.d = new Runnable(){

            @Override
            public void run() {
                c.this.b().runOnUiThread(new Runnable(){

                    @Override
                    public void run() {
                        c.this.b().finish();
                    }
                });
            }

        };
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(String string2, int n2) {
        Activity activity = this.b();
        String string3 = n2 < this.g().length ? this.g()[n2] : null;
        r.a((Context)activity, string2, string3, 5000, new Runnable(){

            @Override
            public void run() {
                c.this.b().finish();
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(String string2, int n2) {
        Object object = new Intent("com.startapp.android.OnClickCallback");
        this.b().sendBroadcast((Intent)object);
        Activity activity = this.b();
        object = n2 < this.g().length ? this.g()[n2] : null;
        r.a((Context)activity, string2, (String)object);
        this.b().finish();
    }

    private void o() {
        r.a(this.b(), this.j(), true);
    }

    @Override
    public void a(Bundle bundle) {
        this.e = this.b().getResources().getConfiguration().orientation;
        this.b().registerReceiver(this.c, new IntentFilter("com.startapp.android.CloseAdActivity"));
        this.b().requestWindowFeature(1);
        this.o();
    }

    public void a(WebView webView) {
        webView.setOnTouchListener(new View.OnTouchListener(){

            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 2) {
                    return true;
                }
                return false;
            }
        });
    }

    protected void a(RelativeLayout relativeLayout) {
        this.b = new com.startapp.android.publish.adinformation.a((Context)this.b(), a.b.b, this.h(), this.i());
        this.b.a(relativeLayout);
    }

    @Override
    public boolean a(int n2, KeyEvent keyEvent) {
        return false;
    }

    protected void b(WebView webView) {
    }

    @Override
    public void k() {
        if (this.e == this.b().getResources().getConfiguration().orientation) {
            Intent intent = new Intent("com.startapp.android.HideDisplayBroadcastListener");
            this.b().sendBroadcast(intent);
        }
        this.n();
    }

    @Override
    public void l() {
        RelativeLayout relativeLayout = new RelativeLayout((Context)this.b());
        relativeLayout.setContentDescription((CharSequence)"StartApp Ad");
        relativeLayout.setId(1475346432);
        this.b().setContentView((View)relativeLayout);
        this.a = new WebView(this.b().getApplicationContext());
        this.a.setBackgroundColor(-16777216);
        this.b().getWindow().getDecorView().findViewById(16908290).setBackgroundColor(7829367);
        this.a.setVerticalScrollBarEnabled(false);
        this.a.setHorizontalScrollBarEnabled(false);
        this.a.getSettings().setJavaScriptEnabled(true);
        com.startapp.android.publish.g.b.a(this.a);
        this.a.setWebChromeClient(new WebChromeClient());
        this.a.setOnLongClickListener(new View.OnLongClickListener(){

            public boolean onLongClick(View view) {
                return true;
            }
        });
        this.a.setLongClickable(false);
        this.a.addJavascriptInterface((Object)new JsInterface((Context)this.b(), this.d, this.d), "startappwall");
        r.a((Context)this.b(), this.f());
        this.a(this.a);
        r.a(this.a, this.d());
        this.a.setWebViewClient((WebViewClient)new b());
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        relativeLayout.addView((View)this.a, (ViewGroup.LayoutParams)layoutParams);
        this.a(relativeLayout);
        this.f = null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void m() {
        if (this.f != null) {
            try {
                this.b().unregisterReceiver((BroadcastReceiver)this.f);
            }
            catch (Exception var1_1) {
                j.a(6, "AppWallActivity::onDestroy - [" + var1_1.getClass() + "]");
            }
        }
        if (this.c != null) {
            try {
                this.b().unregisterReceiver(this.c);
            }
            catch (Exception var1_2) {}
        }
        this.c = null;
        this.f = null;
    }

    protected void n() {
        this.b().finish();
    }

    public static class a
    extends BroadcastReceiver {
        private Activity a;

        public void onReceive(Context context, Intent intent) {
            j.a(2, "DismissActivityBroadcastReceiver::onReceive - action = [" + intent.getAction() + "]");
            if (this.a != null) {
                this.a.finish();
            }
        }
    }

    class b
    extends WebViewClient {
        private b() {
        }

        public void onPageFinished(WebView webView, String string2) {
            c.this.b(webView);
            c.this.a.loadUrl("javascript:gClientInterface.setMode('" + c.this.e() + "')");
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String string2) {
            j.a(2, "MyWebViewClient::shouldOverrideUrlLoading - [" + string2 + "]");
            if (string2.contains("index=")) {
                try {
                    int n2 = r.a(string2);
                    if (c.this.c()[n2]) {
                        c.this.a(string2, n2);
                    }
                    c.this.b(string2, n2);
                }
                catch (Exception var1_2) {
                    j.a(6, "Error while trying parsing index from url");
                    return false;
                }
            } else if (c.this.c()[0]) {
                c.this.a(string2, 0);
            } else {
                c.this.b(string2, 0);
            }
            return true;
        }
    }

}

