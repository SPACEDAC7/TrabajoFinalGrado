/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.webkit.WebView
 */
package com.startapp.android.publish.c;

import android.webkit.WebView;
import com.startapp.android.publish.c.c;

public class d
extends c {
    @Override
    public void a(WebView webView) {
    }
}

