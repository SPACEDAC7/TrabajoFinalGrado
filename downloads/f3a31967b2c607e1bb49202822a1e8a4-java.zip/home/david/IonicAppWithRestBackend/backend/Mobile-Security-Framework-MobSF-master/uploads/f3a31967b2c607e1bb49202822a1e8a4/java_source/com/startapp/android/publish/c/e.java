/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.os.Handler
 *  android.webkit.WebView
 */
package com.startapp.android.publish.c;

import android.app.Activity;
import android.os.Handler;
import android.webkit.WebView;
import com.startapp.android.publish.c.c;

public class e
extends c {
    @Override
    public void a(WebView webView) {
        super.a(webView);
        if (this.e().equals("interstitial")) {
            webView.setBackgroundColor(0);
        }
    }

    @Override
    protected void b(final WebView webView) {
        new Handler().postDelayed(new Runnable(){

            @Override
            public void run() {
                webView.setBackgroundColor(0);
            }
        }, 1000);
    }

    @Override
    public void k() {
        super.k();
        this.b().overridePendingTransition(0, 0);
    }

}

