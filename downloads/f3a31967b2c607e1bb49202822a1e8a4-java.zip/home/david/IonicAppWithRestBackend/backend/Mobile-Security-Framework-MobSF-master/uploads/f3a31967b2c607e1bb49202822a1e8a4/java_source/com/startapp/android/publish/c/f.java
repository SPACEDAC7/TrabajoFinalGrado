/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.KeyEvent
 *  android.widget.Toast
 */
package com.startapp.android.publish.c;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.Toast;
import com.startapp.android.publish.c.b;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.splash.SplashConfig;
import com.startapp.android.publish.splash.a;
import java.io.Serializable;

public class f
extends b {
    private SplashConfig a = null;
    private a b;
    private boolean c = false;
    private boolean d = false;

    @Override
    public void a(Bundle bundle) {
        j.a("SplashMode", 3, "onCreate");
        this.a = (SplashConfig)this.a().getSerializableExtra("SplashConfig");
        if (this.a != null) {
            this.b().requestWindowFeature(1);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean a(int n2, KeyEvent keyEvent) {
        j.a("SplashMode", 3, "onKeyDown");
        if (this.c) {
            if (n2 == 25) {
                if (!this.d) {
                    this.d = true;
                    this.b.b();
                    Toast.makeText((Context)this.b(), (CharSequence)"Test Mode", (int)0).show();
                    return true;
                }
            } else if (n2 == 24 && this.d) {
                this.b().finish();
                return true;
            }
        }
        if (n2 == 4) return true;
        return false;
    }

    @Override
    public void k() {
        j.a("SplashMode", 3, "onPause");
        if (this.b != null) {
            this.b.c();
        }
    }

    @Override
    public void l() {
        j.a("SplashMode", 3, "onResume");
        if (this.a != null) {
            AdPreferences adPreferences;
            AdPreferences adPreferences2 = adPreferences = (AdPreferences)this.a().getSerializableExtra("AdPreference");
            if (adPreferences == null) {
                adPreferences2 = new AdPreferences();
            }
            this.c = this.a().getBooleanExtra("testMode", false);
            this.b = new a(this.b(), this.a, adPreferences2);
            this.b.a((Bundle)null);
        }
    }

    @Override
    public void m() {
        j.a("SplashMode", 3, "onDestroy");
    }
}

