/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Process
 *  android.text.TextUtils
 */
package com.startapp.android.publish.d;

import android.content.Context;
import android.os.Process;
import android.text.TextUtils;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.r;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class a {
    private List<com.startapp.android.publish.a> a;
    private Context b;
    private List<String> c = new ArrayList<String>();

    public a(Context context, List<com.startapp.android.publish.a> list) {
        this.a = list;
        this.b = context;
    }

    private List<String> a(List<String> list, String string2, String string3) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (int i2 = 0; i2 < list.size(); i2 += 5) {
            List<String> list2 = list.subList(i2, Math.min(i2 + 5, list.size()));
            arrayList.add("http://www.startappexchange.com/tracking/adImpression?" + TextUtils.join((CharSequence)"&", list2) + "&isShown=" + string2 + "&appPresence=" + string3);
        }
        j.a(3, "newUrlList size = " + arrayList.size());
        return arrayList;
    }

    private void c() {
        this.d();
        for (int i2 = 0; i2 < this.c.size(); ++i2) {
            String string2 = this.c.get(i2);
            if (string2.length() == 0) continue;
            r.b(this.b, string2);
        }
    }

    private void d() {
        j.a(3, "in getDParameter()");
        ArrayList<String> arrayList = new ArrayList<String>();
        ArrayList<String> arrayList2 = new ArrayList<String>();
        for (com.startapp.android.publish.a a2 : this.a) {
            if (a2.c()) continue;
            String string2 = a2.a().split("tracking/adImpression[?]d=")[1];
            if (a2.d()) {
                arrayList.add("d=" + string2);
                continue;
            }
            arrayList2.add("d=" + string2);
        }
        j.a(3, "appPresence tracking size = " + arrayList.size() + " normal size = " + arrayList2.size());
        if (!arrayList.isEmpty()) {
            this.c.addAll(this.a(arrayList, "false", "true"));
        }
        if (!arrayList2.isEmpty()) {
            this.c.addAll(this.a(arrayList2, "false", "false"));
        }
    }

    public void a() {
        new Thread(new Runnable(){

            @Override
            public void run() {
                Process.setThreadPriority((int)10);
                a.this.b();
            }
        }).start();
    }

    protected Boolean b() {
        j.a(3, "in doInBackground handler");
        this.c();
        return true;
    }

}

