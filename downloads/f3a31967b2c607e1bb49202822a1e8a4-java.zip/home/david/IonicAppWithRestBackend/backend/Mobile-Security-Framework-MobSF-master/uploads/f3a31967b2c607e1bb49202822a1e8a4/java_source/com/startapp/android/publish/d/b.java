/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 *  android.text.TextUtils
 *  android.webkit.WebChromeClient
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 */
package com.startapp.android.publish.d;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a;
import com.startapp.android.publish.adinformation.AdInformationConfig;
import com.startapp.android.publish.adinformation.e;
import com.startapp.android.publish.b;
import com.startapp.android.publish.d.d;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.o;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.BaseRequest;
import com.startapp.android.publish.model.GetAdRequest;
import com.startapp.android.publish.model.MetaData;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public abstract class b
extends d {
    private Set<String> g = new HashSet<String>();
    private List<a> h = new ArrayList<a>();
    private int i = 0;
    private boolean j;
    private Handler k = new Handler();

    public b(Context context, Ad ad, AdPreferences adPreferences, AdEventListener adEventListener, AdPreferences.Placement placement, boolean bl) {
        super(context, ad, adPreferences, adEventListener, placement);
        this.j = bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Boolean a(List<a> object) {
        int n2;
        Iterator iterator = object.iterator();
        boolean bl = false;
        while (iterator.hasNext()) {
            a a2 = (a)iterator.next();
            boolean bl2 = a2.b().startsWith("!");
            object = bl2 ? a2.b().substring(1) : a2.b();
            boolean bl3 = b.a(this.a, (String)object, a2.e());
            n2 = !bl2 && bl3 || bl2 && !bl3 ? 1 : 0;
            if (n2 != 0) {
                j.a(3, "in isAppPresent, skipAd is true");
                a2.b(bl3);
                bl3 = this.i == 0;
                if (bl3 && !bl2) {
                    this.g.add(a2.b());
                    bl = bl3;
                } else {
                    bl = bl3;
                    if (!bl3) {
                        bl = bl3;
                        if (a2.a() != null) {
                            a2.a(a2.a() + "&isShown=" + a2.c() + "&appPresence=" + a2.d());
                            bl = bl3;
                        }
                    }
                }
            }
            this.h.add(a2);
        }
        if (!bl) {
            return bl;
        }
        n2 = 0;
        while (n2 < this.h.size()) {
            this.h.get(n2).a(false);
            ++n2;
        }
        return bl;
    }

    /*
     * Exception decompiling
     */
    private List<a> b(String var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl37 : AssignmentSimple: var2_7 = var1_1.length > var3_8 ? java.lang.Integer.valueOf((java.lang.String)var1_1[var3_8]).intValue() : 0;

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:584)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    protected Object a() {
        Object object = this.e();
        if (this.g.size() == 0) {
            this.g.add(this.a.getPackageName());
        }
        object.setPackagesExclude(this.g);
        if (this.i > 0) {
            object.setEngInclude(false);
            if (MetaData.getInstance().getAdInformationConfig().e().a(this.a)) {
                r.c(this.a);
            }
        }
        try {
            object = com.startapp.android.publish.f.a.a(this.a, com.startapp.android.publish.b.a(b.a.a), (BaseRequest)object, null);
            return object;
        }
        catch (o var1_2) {
            j.a(6, "Unable to handle GetHtmlAdService command!!!!", var1_2);
            this.f = var1_2.getMessage();
            return null;
        }
    }

    @Override
    protected void a(Boolean bl) {
        super.a(bl);
        j.a(4, "Html onPostExecute, result=[" + bl + "]");
        this.a((boolean)bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a(boolean bl) {
        if (bl) {
            if (this.j) {
                final WebView webView = new WebView(this.a);
                webView.setWebChromeClient(new WebChromeClient());
                webView.setWebViewClient(new WebViewClient(){

                    public void onPageFinished(WebView webView, String string2) {
                        super.onPageFinished(webView, string2);
                        j.a(4, "onPageFinished url=[" + string2 + "]");
                        b.this.k.removeCallbacksAndMessages((Object)null);
                        b.this.k.post(new Runnable(){

                            @Override
                            public void run() {
                                if (b.this.d != null) {
                                    b.this.d.onReceiveAd(b.this.b);
                                }
                            }
                        });
                    }

                    public void onReceivedError(final WebView webView, int n2, final String string2, String string3) {
                        super.onReceivedError(webView, n2, string2, string3);
                        j.a(6, "onReceivedError failingUrl=[" + string3 + "], description=[" + string2 + "]");
                        b.this.k.removeCallbacksAndMessages((Object)null);
                        b.this.k.post(new Runnable(){

                            @Override
                            public void run() {
                                webView.destroy();
                                b.this.b.setErrorMessage(string2);
                                if (b.this.d != null) {
                                    b.this.d.onFailedToReceiveAd(b.this.b);
                                }
                            }
                        });
                    }

                    public boolean shouldOverrideUrlLoading(WebView webView, String string2) {
                        j.a(4, "shouldOverrideUrlLoading url=[" + string2 + "]");
                        return super.shouldOverrideUrlLoading(webView, string2);
                    }

                });
                r.a(webView, ((com.startapp.android.publish.a.d)this.b).getHtml());
                this.k.postDelayed(new Runnable(){

                    @Override
                    public void run() {
                        webView.destroy();
                        if (b.this.d != null) {
                            b.this.d.onReceiveAd(b.this.b);
                        }
                    }
                }, 10000);
                return;
            } else {
                if (this.d == null) return;
                {
                    if (bl) {
                        this.d.onReceiveAd(this.b);
                        return;
                    }
                    this.d.onFailedToReceiveAd(this.b);
                    return;
                }
            }
        } else {
            j.a(6, "Html onPostExecute failed error=[" + this.f + "]");
            if (this.d == null) return;
            {
                this.d.onFailedToReceiveAd(this.b);
                return;
            }
        }
    }

    @Override
    protected boolean a(Object object) {
        j.a(4, "Handle Html Response");
        this.h = new ArrayList<a>();
        object = (String)object;
        if (TextUtils.isEmpty((CharSequence)object)) {
            if (this.f == null) {
                this.f = "Empty Ad";
            }
            return false;
        }
        if (!this.a(this.b((String)object)).booleanValue()) {
            ((com.startapp.android.publish.a.d)this.b).setApps(this.h);
            return this.a((String)object);
        }
        return this.b();
    }

    protected boolean a(String string2) {
        ((com.startapp.android.publish.a.d)this.b).setHtml(string2);
        return true;
    }

    protected boolean b() {
        j.a(3, "At least one package is present. sending another request to AdPlatform");
        ++this.i;
        new com.startapp.android.publish.d.a(this.a, this.h).a();
        return this.d();
    }

}

