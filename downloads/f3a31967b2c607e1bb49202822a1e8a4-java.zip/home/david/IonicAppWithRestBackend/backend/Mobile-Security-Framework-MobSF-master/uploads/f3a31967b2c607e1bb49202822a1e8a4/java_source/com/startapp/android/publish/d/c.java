/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.d;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a;
import com.startapp.android.publish.a.f;
import com.startapp.android.publish.b;
import com.startapp.android.publish.d.d;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.o;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdDetails;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.BaseRequest;
import com.startapp.android.publish.model.GetAdRequest;
import com.startapp.android.publish.model.GetAdResponse;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public abstract class c
extends d {
    private int g = 0;
    private Set<String> h = new HashSet<String>();

    public c(Context context, Ad ad, AdPreferences adPreferences, AdEventListener adEventListener, AdPreferences.Placement placement) {
        super(context, ad, adPreferences, adEventListener, placement);
    }

    private boolean b() {
        ++this.g;
        return this.d();
    }

    @Override
    protected Object a() {
        boolean bl = false;
        Object object = this.e();
        if (this.h.size() == 0) {
            this.h.add(this.a.getPackageName());
        }
        if (this.g > 0) {
            object.setEngInclude(false);
        }
        object.setPackagesExclude(this.h);
        if (this.g == 0) {
            bl = true;
        }
        object.setEngInclude(bl);
        try {
            object = (GetAdResponse)com.startapp.android.publish.f.a.a(this.a, b.a(b.a.b), (BaseRequest)object, null, GetAdResponse.class);
            return object;
        }
        catch (o var2_3) {
            j.a("AppPresence", 6, "Unable to handle GetAdsSetService command!!!!", var2_3);
            this.f = var2_3.getMessage();
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected List<AdDetails> a(List<AdDetails> iterator) {
        int n2;
        ArrayList<AdDetails> arrayList = new ArrayList<AdDetails>();
        ArrayList<AdDetails> arrayList2 = new ArrayList<AdDetails>();
        ArrayList<a> arrayList3 = new ArrayList<a>();
        ArrayList<a> arrayList4 = new ArrayList<a>();
        j.a("AppPresence", 3, "in getAdsToDisplay");
        Iterator iterator2 = iterator.iterator();
        boolean bl = false;
        while (iterator2.hasNext()) {
            AdDetails adDetails = (AdDetails)iterator2.next();
            a a2 = new a(adDetails.getTrackingUrl(), adDetails.getAppPresencePackage(), this.g, adDetails.getMinAppVersion());
            n2 = adDetails.getAppPresencePackage() != null && adDetails.getAppPresencePackage().startsWith("!") ? 1 : 0;
            String string2 = n2 != 0 ? adDetails.getAppPresencePackage().substring(1) : adDetails.getAppPresencePackage();
            boolean bl2 = c.a(this.a, string2, adDetails.getMinAppVersion());
            boolean bl3 = bl2 && n2 == 0 || !bl2 && n2 != 0;
            arrayList3.add(a2);
            if (bl3) {
                a2.b(bl2);
                a2.a(false);
                if (n2 == 0) {
                    arrayList2.add(adDetails);
                    arrayList4.add(a2);
                }
                this.h.add(adDetails.getPackageName());
                j.a("AppPresence", 3, "App Presence:[" + adDetails.getPackageName() + "]");
                bl = true;
                continue;
            }
            arrayList.add(adDetails);
            j.a("AppPresence", 3, "App Not Presence:[" + adDetails.getPackageName() + "]");
        }
        if (arrayList.size() < 5 && (iterator.size() != 1 || this.g > 0)) {
            n2 = Math.min(5 - arrayList.size(), arrayList2.size());
            arrayList.addAll(arrayList2.subList(0, n2));
            iterator = arrayList4.subList(0, n2).iterator();
            while (iterator.hasNext()) {
                ((a)iterator.next()).a(true);
            }
        }
        if (bl) {
            r.c(this.a);
            new com.startapp.android.publish.d.a(this.a, arrayList3).a();
        }
        return arrayList;
    }

    protected abstract void a(Ad var1);

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected void a(Boolean bl) {
        super.a(bl);
        if (!bl.booleanValue()) {
            return;
        }
        this.a((f)this.b);
        if (this.d == null) return;
        this.d.onReceiveAd(this.b);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected boolean a(Object object) {
        GetAdResponse getAdResponse = (GetAdResponse)object;
        if (object == null) {
            this.f = "Empty Response";
            j.a("AppPresence", 6, "Error Empty Response");
            return false;
        }
        if (!getAdResponse.isValidResponse()) {
            this.f = getAdResponse.getErrorMessage();
            j.a("AppPresence", 6, "Error msg = [" + this.f + "]");
            return false;
        }
        object = (f)this.b;
        List<AdDetails> list = this.a(getAdResponse.getAdsDetails());
        object.a(list);
        object.setAdInfoOverride(getAdResponse.getAdInfoOverride());
        boolean bl = getAdResponse.getAdsDetails() != null && getAdResponse.getAdsDetails().size() > 0;
        if (!bl) {
            this.f = "Empty Response";
        }
        boolean bl2 = bl;
        if (list.size() != 0) return bl2;
        bl2 = bl;
        if (this.g != 0) return bl2;
        j.a("AppPresence", 3, "Packages exists - another request");
        return this.b();
    }
}

