/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Process
 */
package com.startapp.android.publish.d;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.GetAdRequest;

public abstract class d {
    protected final Context a;
    protected final Ad b;
    protected final AdPreferences c;
    protected final AdEventListener d;
    protected AdPreferences.Placement e;
    protected String f = null;

    public d(Context context, Ad ad, AdPreferences adPreferences, AdEventListener adEventListener, AdPreferences.Placement placement) {
        this.a = context;
        this.b = ad;
        this.c = adPreferences;
        this.d = adEventListener;
        this.e = placement;
    }

    protected static boolean a(Context context, String string2, int n2) {
        boolean bl = false;
        context = context.getPackageManager();
        try {
            int n3 = context.getPackageInfo((String)string2, (int)128).versionCode;
            if (n3 >= n2) {
                bl = true;
            }
            return bl;
        }
        catch (PackageManager.NameNotFoundException var0_1) {
            return false;
        }
    }

    protected abstract Object a();

    /*
     * Enabled aggressive block sorting
     */
    protected void a(Boolean bl) {
        Ad ad = this.b;
        Ad.AdState adState = bl != false ? Ad.AdState.READY : Ad.AdState.UN_INITIALIZED;
        ad.setState(adState);
        if (!bl.booleanValue()) {
            this.b.setErrorMessage(this.f);
            if (this.d != null) {
                this.d.onFailedToReceiveAd(this.b);
            }
        }
    }

    protected abstract boolean a(Object var1);

    public void c() {
        new Thread(new Runnable(){

            @Override
            public void run() {
                Process.setThreadPriority((int)10);
                final Boolean bl = d.this.d();
                new Handler(Looper.getMainLooper()).post(new Runnable(){

                    @Override
                    public void run() {
                        d.this.a(bl);
                    }
                });
            }

        }).start();
    }

    protected Boolean d() {
        return this.a(this.a());
    }

    protected GetAdRequest e() {
        GetAdRequest getAdRequest = new GetAdRequest();
        getAdRequest.fillApplicationDetails(this.a, this.c);
        getAdRequest.fillAdPreferences(this.a, this.c, this.e, r.d(this.a));
        return getAdRequest;
    }

}

