/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.d;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.a;
import com.startapp.android.publish.banner.BannerOptions;
import com.startapp.android.publish.d.c;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.GetAdRequest;
import com.startapp.android.publish.model.MetaData;

public class e
extends c {
    public e(Context context, a a2, AdPreferences adPreferences, AdEventListener adEventListener) {
        super(context, a2, adPreferences, adEventListener, AdPreferences.Placement.INAPP_BANNER);
    }

    @Override
    protected void a(Ad ad) {
    }

    @Override
    protected GetAdRequest e() {
        GetAdRequest getAdRequest = super.e();
        getAdRequest.setAdsNumber(MetaData.getInstance().getBannerOptions().f());
        return getAdRequest;
    }
}

