/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.d;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.d;
import com.startapp.android.publish.banner.BannerOptions;
import com.startapp.android.publish.d.b;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.GetAdRequest;
import com.startapp.android.publish.model.MetaData;

public class f
extends b {
    private int g = 0;

    public f(Context context, d d2, int n2, AdPreferences adPreferences, AdEventListener adEventListener) {
        super(context, d2, adPreferences, adEventListener, AdPreferences.Placement.INAPP_BANNER, false);
        this.g = n2;
    }

    @Override
    protected void a(Boolean bl) {
        super.a(bl);
        j.a(4, "Html onPostExecute, result=[" + bl + "]");
    }

    @Override
    protected boolean a(String string2) {
        ((d)this.b).setHtml(string2);
        return true;
    }

    @Override
    protected GetAdRequest e() {
        d d2 = (d)this.b;
        GetAdRequest getAdRequest = super.e();
        getAdRequest.setWidth(d2.getWidth());
        getAdRequest.setHeight(d2.getHeight());
        getAdRequest.setOffset(this.g);
        getAdRequest.setAdsNumber(MetaData.getInstance().getBannerOptions().g());
        return getAdRequest;
    }
}

