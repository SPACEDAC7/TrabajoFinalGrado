/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Process
 */
package com.startapp.android.publish.d;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import com.startapp.android.publish.b;
import com.startapp.android.publish.f.a;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.o;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.BaseRequest;
import com.startapp.android.publish.model.MetaData;
import com.startapp.android.publish.model.MetaDataRequest;

public class h {
    private final Context a;
    private final AdPreferences b;
    private MetaData c = null;

    public h(Context context, AdPreferences adPreferences) {
        this.a = context;
        this.b = adPreferences;
    }

    public void a() {
        new Thread(new Runnable(){

            @Override
            public void run() {
                Process.setThreadPriority((int)10);
                final Boolean bl = h.this.b();
                new Handler(Looper.getMainLooper()).post(new Runnable(){

                    @Override
                    public void run() {
                        h.this.a(bl);
                    }
                });
            }

        }).start();
    }

    protected void a(Boolean bl) {
        if (bl.booleanValue() && this.c != null && this.a != null) {
            MetaData.update(this.a, this.c);
            return;
        }
        MetaData.failedLoading();
    }

    protected Boolean b() {
        j.a(3, "Loading MetaData");
        MetaDataRequest metaDataRequest = new MetaDataRequest();
        metaDataRequest.fillApplicationDetails(this.a, this.b);
        try {
            j.a(3, "Networking MetaData");
            this.c = (MetaData)a.a(this.a, b.a(b.a.c), (BaseRequest)metaDataRequest, null, MetaData.class);
            return Boolean.TRUE;
        }
        catch (o var1_2) {
            j.a(6, "Unable to handle GetMetaData command!!!!", var1_2);
            return Boolean.FALSE;
        }
    }

}

