/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.d;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.d.c;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.GetAdRequest;
import com.startapp.android.publish.nativead.NativeAdPreferences;

public class i
extends c {
    private NativeAdPreferences g;

    public i(Context context, Ad ad, AdPreferences adPreferences, AdEventListener adEventListener, NativeAdPreferences nativeAdPreferences) {
        super(context, ad, adPreferences, adEventListener, AdPreferences.Placement.INAPP_NATIVE);
        this.g = nativeAdPreferences;
    }

    @Override
    protected void a(Ad ad) {
    }

    @Override
    protected GetAdRequest e() {
        GetAdRequest getAdRequest = super.e();
        getAdRequest.setAdsNumber(this.g.getAdsNumber());
        getAdRequest.setWidth(this.g.getImageSize().getWidth());
        getAdRequest.setHeight(this.g.getImageSize().getHeight());
        return getAdRequest;
    }
}

