/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.d;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.i;
import com.startapp.android.publish.d.b;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.GetAdRequest;
import com.startapp.android.publish.model.MetaData;

public class j
extends b {
    public j(Context context, i i2, AdPreferences adPreferences, AdEventListener adEventListener) {
        super(context, i2, adPreferences, adEventListener, AdPreferences.Placement.INAPP_OFFER_WALL, true);
    }

    @Override
    protected GetAdRequest e() {
        GetAdRequest getAdRequest = super.e();
        getAdRequest.setAdsNumber(MetaData.getInstance().getMaxAds());
        return getAdRequest;
    }
}

