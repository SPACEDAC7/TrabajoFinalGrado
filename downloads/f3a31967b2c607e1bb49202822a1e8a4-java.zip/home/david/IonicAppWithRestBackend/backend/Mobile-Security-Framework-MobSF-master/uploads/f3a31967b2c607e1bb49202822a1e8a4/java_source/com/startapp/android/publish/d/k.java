/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.d;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.h;
import com.startapp.android.publish.d.c;
import com.startapp.android.publish.list3d.e;
import com.startapp.android.publish.model.AdDetails;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.GetAdRequest;
import com.startapp.android.publish.model.MetaData;
import java.util.Iterator;
import java.util.List;

public class k
extends c {
    public k(Context context, h h2, AdPreferences adPreferences, AdEventListener adEventListener) {
        super(context, h2, adPreferences, adEventListener, AdPreferences.Placement.INAPP_OFFER_WALL);
    }

    @Override
    protected void a(Ad iterator) {
        iterator = ((h)((Object)iterator)).a();
        e.a.a();
        if (iterator != null) {
            iterator = iterator.iterator();
            while (iterator.hasNext()) {
                AdDetails adDetails = (AdDetails)iterator.next();
                e.a.a(adDetails);
            }
        }
    }

    @Override
    protected GetAdRequest e() {
        GetAdRequest getAdRequest = super.e();
        getAdRequest.setAdsNumber(MetaData.getInstance().getMaxAds());
        return getAdRequest;
    }
}

