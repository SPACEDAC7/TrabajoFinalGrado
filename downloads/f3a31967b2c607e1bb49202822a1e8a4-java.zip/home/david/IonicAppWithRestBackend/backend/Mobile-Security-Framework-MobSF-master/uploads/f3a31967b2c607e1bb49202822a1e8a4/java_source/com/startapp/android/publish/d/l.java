/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.d;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.d;
import com.startapp.android.publish.d.b;
import com.startapp.android.publish.model.AdPreferences;

public class l
extends b {
    public l(Context context, d d2, AdPreferences adPreferences, AdEventListener adEventListener) {
        super(context, d2, adPreferences, adEventListener, AdPreferences.Placement.INAPP_OVERLAY, true);
    }
}

