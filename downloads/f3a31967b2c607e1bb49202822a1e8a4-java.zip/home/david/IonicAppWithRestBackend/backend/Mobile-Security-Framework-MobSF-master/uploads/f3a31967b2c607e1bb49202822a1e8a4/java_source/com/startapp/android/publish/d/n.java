/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 */
package com.startapp.android.publish.d;

import android.app.Activity;
import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.l;
import com.startapp.android.publish.b;
import com.startapp.android.publish.d.c;
import com.startapp.android.publish.f.a;
import com.startapp.android.publish.g.h;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.o;
import com.startapp.android.publish.model.AdDetails;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.BaseRequest;
import com.startapp.android.publish.model.BaseResponse;
import com.startapp.android.publish.model.GetAdRequest;
import com.startapp.android.publish.model.GetAdResponse;
import java.util.List;

public class n
extends c {
    private Activity g;

    public n(Activity activity, l l2, AdPreferences adPreferences, AdEventListener adEventListener) {
        super((Context)activity, l2, adPreferences, adEventListener, AdPreferences.Placement.DEVICE_SIDEBAR);
        this.g = activity;
    }

    @Override
    protected /* synthetic */ Object a() {
        return this.b();
    }

    @Override
    protected void a(Ad ad) {
    }

    @Override
    protected void a(Boolean bl) {
        super.a(bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected boolean a(Object object) {
        GetAdResponse getAdResponse = (GetAdResponse)object;
        if (object == null) {
            j.a(6, "Error Empty Response");
            return false;
        }
        if (!getAdResponse.isValidResponse()) {
            this.f = getAdResponse.getErrorMessage();
            j.a(6, "Error msg = [" + this.f + "]");
            return false;
        }
        object = (l)this.b;
        object.a(getAdResponse.getAdsDetails());
        object.setAdInfoOverride(getAdResponse.getAdInfoOverride());
        boolean bl = getAdResponse.getAdsDetails() != null && getAdResponse.getAdsDetails().size() > 0;
        if (!bl) {
            this.f = "Empty Response";
            return bl;
        }
        h.b((Context)this.g, "slideEvent", false);
        h.b((Context)this.g, "trackingEvent", false);
        h.b((Context)this.g, "trackingUrl", null);
        return bl;
    }

    protected BaseResponse b() {
        Object object = super.e();
        object.setAdsNumber(10);
        try {
            object = (GetAdResponse)a.a(this.a, b.a(b.a.b), (BaseRequest)object, null, GetAdResponse.class);
            return object;
        }
        catch (o var1_2) {
            j.a(6, "Unable to handle GetSearchBoxService!!!!", var1_2);
            this.f = var1_2.getMessage();
            return null;
        }
    }
}

