/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.d;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.m;
import com.startapp.android.publish.d.b;
import com.startapp.android.publish.model.AdPreferences;

public class o
extends b {
    public o(Context context, m m2, AdPreferences adPreferences, AdEventListener adEventListener) {
        super(context, m2, adPreferences, adEventListener, AdPreferences.Placement.INAPP_SPLASH, true);
    }
}

