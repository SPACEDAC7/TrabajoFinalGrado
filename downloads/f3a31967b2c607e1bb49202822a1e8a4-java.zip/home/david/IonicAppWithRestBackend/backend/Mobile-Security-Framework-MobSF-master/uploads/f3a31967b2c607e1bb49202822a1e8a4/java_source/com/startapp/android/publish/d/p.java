/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.d;

public interface p {
    public void onFailedLoadingMeta();

    public void onFinishLoadingMeta();
}

