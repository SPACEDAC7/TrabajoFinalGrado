/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.a;

import com.startapp.android.publish.e.a.a.b;
import com.startapp.android.publish.e.a.a.c;
import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.List;

public class a {
    private final int a;
    private final int b;

    public a(int n2, int n3) {
        this.a = n2;
        this.b = n3;
    }

    private void a(ByteBuffer arrl, c c2) {
        arrl = this.a((ByteBuffer)arrl, c2.a());
        int n2 = arrl.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            c2.a(arrl[i2]);
        }
    }

    private long[] a(ByteBuffer byteBuffer, long l2) {
        long[] arrl = new long[this.a];
        l2 /= (long)this.a;
        long l3 = b.a(byteBuffer, byteBuffer.position(), byteBuffer.remaining(), 0);
        long l4 = b.a(byteBuffer, byteBuffer.position(), byteBuffer.remaining(), l3);
        for (int i2 = 0; i2 < this.a; ++i2) {
            arrl[i2] = (long)i2 * l2 + Math.abs(((long)i2 * l4 + l3) % l2);
        }
        return arrl;
    }

    public c a(List<String> object) {
        c c2 = new c(this.a * this.b);
        object = object.iterator();
        while (object.hasNext()) {
            this.a(ByteBuffer.wrap(((String)object.next()).getBytes()), c2);
        }
        return c2;
    }
}

