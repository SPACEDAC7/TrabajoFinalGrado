/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.a;

import java.nio.ByteBuffer;

public class b {
    /*
     * Enabled aggressive block sorting
     */
    public static long a(ByteBuffer byteBuffer, int n2, int n3, long l2) {
        int n4;
        long l3;
        l2 = 0xFFFFFFFFL & l2 ^ -4132994306676758123L * (long)n3;
        for (n4 = 0; n4 < n3 >> 3; ++n4) {
            int n5 = n4 << 3;
            l3 = (((long)byteBuffer.get(n2 + n5) & 255) + (((long)byteBuffer.get(n2 + n5 + 1) & 255) << 8) + (((long)byteBuffer.get(n2 + n5 + 2) & 255) << 16) + (((long)byteBuffer.get(n2 + n5 + 3) & 255) << 24) + (((long)byteBuffer.get(n2 + n5 + 4) & 255) << 32) + (((long)byteBuffer.get(n2 + n5 + 5) & 255) << 40) + (((long)byteBuffer.get(n2 + n5 + 6) & 255) << 48) + (((long)byteBuffer.get(n5 + n2 + 7) & 255) << 56)) * -4132994306676758123L;
            l2 = (l2 ^ (l3 ^ l3 >>> 47) * -4132994306676758123L) * -4132994306676758123L;
        }
        n4 = n3 & 7;
        l3 = l2;
        long l4 = l2;
        long l5 = l2;
        long l6 = l2;
        long l7 = l2;
        long l8 = l2;
        long l9 = l2;
        switch (n4) {
            default: {
                l3 = l2;
            }
            case 0: {
                break;
            }
            case 7: {
                l4 = l2 ^ (long)byteBuffer.get(n2 + n3 - n4 + 6) << 48;
            }
            case 6: {
                l5 = l4 ^ (long)byteBuffer.get(n2 + n3 - n4 + 5) << 40;
            }
            case 5: {
                l6 = l5 ^ (long)byteBuffer.get(n2 + n3 - n4 + 4) << 32;
            }
            case 4: {
                l7 = l6 ^ (long)byteBuffer.get(n2 + n3 - n4 + 3) << 24;
            }
            case 3: {
                l8 = l7 ^ (long)byteBuffer.get(n2 + n3 - n4 + 2) << 16;
            }
            case 2: {
                l9 = l8 ^ (long)byteBuffer.get(n2 + n3 - n4 + 1) << 8;
            }
            case 1: {
                l3 = (l9 ^ (long)byteBuffer.get(n2 + n3 - n4)) * -4132994306676758123L;
            }
        }
        l2 = (l3 ^ l3 >>> 47) * -4132994306676758123L;
        return l2 ^ l2 >>> 47;
    }
}

