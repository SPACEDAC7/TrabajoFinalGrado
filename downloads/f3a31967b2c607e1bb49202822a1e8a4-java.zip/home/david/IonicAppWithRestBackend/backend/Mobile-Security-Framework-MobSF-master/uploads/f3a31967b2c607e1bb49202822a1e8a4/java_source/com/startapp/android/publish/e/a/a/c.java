/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.a;

import java.io.Serializable;

public class c
implements Serializable {
    static final /* synthetic */ boolean a;
    private static final long serialVersionUID = -901334831550831262L;
    private final long[][] bits;
    private final int pageCount;
    private int wlen;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !c.class.desiredAssertionStatus();
        a = bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    public c(long l2) {
        int n2 = 0;
        this.wlen = this.d(l2);
        int n3 = this.wlen % 4096;
        int n4 = this.wlen / 4096;
        int n5 = n3 == 0 ? 0 : 1;
        this.pageCount = n5 + n4;
        this.bits = new long[this.pageCount][];
        for (n5 = n2; n5 < n4; ++n5) {
            this.bits[n5] = new long[4096];
        }
        if (n3 != 0) {
            this.bits[this.bits.length - 1] = new long[n3];
        }
    }

    private int b(long l2) {
        int n2 = (int)(l2 >> 6);
        if (n2 >= this.wlen) {
            this.c(1 + l2);
            this.wlen = n2 + 1;
        }
        return n2;
    }

    private void b(int n2) {
        if (!a && n2 > this.wlen) {
            throw new AssertionError((Object)"Growing of paged bitset is not supported");
        }
    }

    private void c(long l2) {
        this.b(this.d(l2));
    }

    private int d(long l2) {
        return (int)((l2 - 1 >>> 6) + 1);
    }

    long a() {
        return (long)this.wlen << 6;
    }

    void a(long l2) {
        int n2 = this.b(l2);
        int n3 = (int)l2;
        long[] arrl = this.bits[n2 / 4096];
        arrl[n2 %= 4096] = 1 << (n3 & 63) | arrl[n2];
    }

    public long[] a(int n2) {
        return this.bits[n2];
    }

    public int b() {
        return this.wlen;
    }

    public int c() {
        return this.pageCount;
    }
}

