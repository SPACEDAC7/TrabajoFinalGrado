/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.c;

import com.startapp.android.publish.e.a.c.b;
import com.startapp.android.publish.e.a.c.f;

public class a
extends b {
    static final byte[] a = new byte[]{13, 10};
    private static final byte[] d = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47};
    private static final byte[] e = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95};
    private static final byte[] f = new byte[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, 62, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, 63, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51};
    private final byte[] g;
    private final byte[] h;
    private final byte[] i;
    private final int j;
    private final int k;

    public a() {
        this(0);
    }

    public a(int n2) {
        this(n2, a);
    }

    public a(int n2, byte[] arrby) {
        this(n2, arrby, false);
    }

    /*
     * Enabled aggressive block sorting
     */
    public a(int n2, byte[] arrby, boolean bl) {
        int n3 = arrby == null ? 0 : arrby.length;
        super(3, 4, n2, n3);
        this.h = f;
        if (arrby != null) {
            if (this.c(arrby)) {
                arrby = f.a(arrby);
                throw new IllegalArgumentException("lineSeparator must not contain base64 characters: [" + (String)arrby + "]");
            }
            if (n2 > 0) {
                this.k = arrby.length + 4;
                this.i = new byte[arrby.length];
                System.arraycopy(arrby, 0, this.i, 0, arrby.length);
            } else {
                this.k = 4;
                this.i = null;
            }
        } else {
            this.k = 4;
            this.i = null;
        }
        this.j = this.k - 1;
        arrby = bl ? e : d;
        this.g = arrby;
    }

    public a(boolean bl) {
        this(76, a, bl);
    }

    public static String a(byte[] arrby) {
        return f.a(a.a(arrby, false));
    }

    public static byte[] a(byte[] arrby, boolean bl) {
        return a.a(arrby, bl, false);
    }

    public static byte[] a(byte[] arrby, boolean bl, boolean bl2) {
        return a.a(arrby, bl, bl2, Integer.MAX_VALUE);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static byte[] a(byte[] arrby, boolean bl, boolean bl2, int n2) {
        if (arrby == null || arrby.length == 0) {
            return arrby;
        }
        a a2 = bl ? new a(bl2) : new a(0, a, bl2);
        long l2 = a2.d(arrby);
        if (l2 > (long)n2) {
            throw new IllegalArgumentException("Input array too big, the output array would be bigger (" + l2 + ") than the specified maximum size of " + n2);
        }
        return a2.b(arrby);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    void a(byte[] arrby, int n2, int n3, b.a a2) {
        if (a2.f) {
            return;
        }
        if (n3 < 0) {
            a2.f = true;
            if (a2.h == 0) {
                if (this.c == 0) return;
            }
            arrby = this.a(this.k, a2);
            n2 = a2.d;
            switch (a2.h) {
                default: {
                    throw new IllegalStateException("Impossible modulus " + a2.h);
                }
                case 1: {
                    n3 = a2.d;
                    a2.d = n3 + 1;
                    arrby[n3] = this.g[a2.a >> 2 & 63];
                    n3 = a2.d;
                    a2.d = n3 + 1;
                    arrby[n3] = this.g[a2.a << 4 & 63];
                    if (this.g == d) {
                        n3 = a2.d;
                        a2.d = n3 + 1;
                        arrby[n3] = 61;
                        n3 = a2.d;
                        a2.d = n3 + 1;
                        arrby[n3] = 61;
                    }
                }
                case 0: {
                    break;
                }
                case 2: {
                    n3 = a2.d;
                    a2.d = n3 + 1;
                    arrby[n3] = this.g[a2.a >> 10 & 63];
                    n3 = a2.d;
                    a2.d = n3 + 1;
                    arrby[n3] = this.g[a2.a >> 4 & 63];
                    n3 = a2.d;
                    a2.d = n3 + 1;
                    arrby[n3] = this.g[a2.a << 2 & 63];
                    if (this.g != d) break;
                    n3 = a2.d;
                    a2.d = n3 + 1;
                    arrby[n3] = 61;
                }
            }
            n3 = a2.g;
            a2.g = a2.d - n2 + n3;
            if (this.c <= 0) return;
            if (a2.g <= 0) return;
            System.arraycopy(this.i, 0, arrby, a2.d, this.i.length);
            a2.d += this.i.length;
            return;
        }
        int n4 = 0;
        while (n4 < n3) {
            int n5;
            byte[] arrby2 = this.a(this.k, a2);
            a2.h = (a2.h + 1) % 3;
            int n6 = n5 = arrby[n2];
            if (n5 < 0) {
                n6 = n5 + 256;
            }
            a2.a = n6 + (a2.a << 8);
            if (a2.h == 0) {
                n6 = a2.d;
                a2.d = n6 + 1;
                arrby2[n6] = this.g[a2.a >> 18 & 63];
                n6 = a2.d;
                a2.d = n6 + 1;
                arrby2[n6] = this.g[a2.a >> 12 & 63];
                n6 = a2.d;
                a2.d = n6 + 1;
                arrby2[n6] = this.g[a2.a >> 6 & 63];
                n6 = a2.d;
                a2.d = n6 + 1;
                arrby2[n6] = this.g[a2.a & 63];
                a2.g += 4;
                if (this.c > 0 && this.c <= a2.g) {
                    System.arraycopy(this.i, 0, arrby2, a2.d, this.i.length);
                    a2.d += this.i.length;
                    a2.g = 0;
                }
            }
            ++n4;
            ++n2;
        }
    }

    @Override
    protected boolean a(byte by) {
        if (by >= 0 && by < this.h.length && this.h[by] != -1) {
            return true;
        }
        return false;
    }
}

