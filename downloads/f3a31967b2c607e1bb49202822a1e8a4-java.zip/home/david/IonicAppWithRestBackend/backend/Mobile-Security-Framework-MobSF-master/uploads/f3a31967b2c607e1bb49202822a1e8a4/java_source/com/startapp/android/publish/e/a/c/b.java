/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.c;

import java.util.Arrays;

public abstract class b {
    private final int a;
    protected final byte b;
    protected final int c;
    private final int d;
    private final int e;

    /*
     * Enabled aggressive block sorting
     */
    protected b(int n2, int n3, int n4, int n5) {
        int n6 = 0;
        this.b = 61;
        this.a = n2;
        this.d = n3;
        n2 = n4 > 0 && n5 > 0 ? 1 : 0;
        if (n2 != 0) {
            n6 = n4 / n3 * n3;
        }
        this.c = n6;
        this.e = n5;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private byte[] b(a a2) {
        if (a2.c == null) {
            a2.c = new byte[this.a()];
            a2.d = 0;
            a2.e = 0;
            do {
                return a2.c;
                break;
            } while (true);
        }
        byte[] arrby = new byte[a2.c.length << 1];
        System.arraycopy(a2.c, 0, arrby, 0, a2.c.length);
        a2.c = arrby;
        return a2.c;
    }

    protected int a() {
        return 8192;
    }

    int a(a a2) {
        if (a2.c != null) {
            return a2.d - a2.e;
        }
        return 0;
    }

    abstract void a(byte[] var1, int var2, int var3, a var4);

    protected abstract boolean a(byte var1);

    protected byte[] a(int n2, a a2) {
        if (a2.c == null || a2.c.length < a2.d + n2) {
            return this.b(a2);
        }
        return a2.c;
    }

    int b(byte[] arrby, int n2, int n3, a a2) {
        if (a2.c != null) {
            n3 = Math.min(this.a(a2), n3);
            System.arraycopy(a2.c, a2.e, arrby, n2, n3);
            a2.e += n3;
            if (a2.e >= a2.d) {
                a2.c = null;
            }
            return n3;
        }
        if (a2.f) {
            return -1;
        }
        return 0;
    }

    public byte[] b(byte[] arrby) {
        if (arrby == null || arrby.length == 0) {
            return arrby;
        }
        a a2 = new a();
        this.a(arrby, 0, arrby.length, a2);
        this.a(arrby, 0, -1, a2);
        arrby = new byte[a2.d - a2.e];
        this.b(arrby, 0, arrby.length, a2);
        return arrby;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean c(byte[] arrby) {
        if (arrby == null) {
            return false;
        }
        int n2 = arrby.length;
        int n3 = 0;
        while (n3 < n2) {
            byte by = arrby[n3];
            if (61 == by || this.a(by)) {
                return true;
            }
            ++n3;
        }
        return false;
    }

    public long d(byte[] arrby) {
        long l2;
        long l3 = l2 = (long)((arrby.length + this.a - 1) / this.a) * (long)this.d;
        if (this.c > 0) {
            l3 = l2 + ((long)this.c + l2 - 1) / (long)this.c * (long)this.e;
        }
        return l3;
    }

    static class a {
        int a;
        long b;
        byte[] c;
        int d;
        int e;
        boolean f;
        int g;
        int h;

        a() {
        }

        public String toString() {
            return String.format("%s[buffer=%s, currentLinePos=%s, eof=%s, ibitWorkArea=%s, lbitWorkArea=%s, modulus=%s, pos=%s, readPos=%s]", this.getClass().getSimpleName(), Arrays.toString(this.c), this.g, this.f, this.a, this.b, this.h, this.d, this.e);
        }
    }

}

