/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.c;

import java.nio.charset.Charset;

public class c {
    public static final Charset a = Charset.forName("ISO-8859-1");
    public static final Charset b = Charset.forName("US-ASCII");
    public static final Charset c = Charset.forName("UTF-16");
    public static final Charset d = Charset.forName("UTF-16BE");
    public static final Charset e = Charset.forName("UTF-16LE");
    public static final Charset f = Charset.forName("UTF-8");
}

