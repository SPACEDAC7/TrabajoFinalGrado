/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.c;

import com.startapp.android.publish.e.a.c.e;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;

public class d {
    public static final char a = File.separatorChar;
    public static final String b;

    static {
        e e2 = new e(4);
        PrintWriter printWriter = new PrintWriter(e2);
        printWriter.println();
        b = e2.toString();
        printWriter.close();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void a(Closeable closeable) {
        if (closeable == null) return;
        try {
            closeable.close();
            return;
        }
        catch (IOException var0_1) {
            return;
        }
    }

    public static void a(OutputStream outputStream) {
        d.a((Closeable)outputStream);
    }
}

