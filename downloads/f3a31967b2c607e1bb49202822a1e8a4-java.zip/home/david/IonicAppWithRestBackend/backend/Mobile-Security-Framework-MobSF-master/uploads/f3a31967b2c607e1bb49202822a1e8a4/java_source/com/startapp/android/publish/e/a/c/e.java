/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.c;

import java.io.Serializable;
import java.io.Writer;

public class e
extends Writer
implements Serializable {
    private static final long serialVersionUID = -8956169446715407818L;
    private final StringBuilder builder;

    public e() {
        this.builder = new StringBuilder();
    }

    public e(int n2) {
        this.builder = new StringBuilder(n2);
    }

    @Override
    public Writer append(char c2) {
        this.builder.append(c2);
        return this;
    }

    @Override
    public Writer append(CharSequence charSequence) {
        this.builder.append(charSequence);
        return this;
    }

    @Override
    public Writer append(CharSequence charSequence, int n2, int n3) {
        this.builder.append(charSequence, n2, n3);
        return this;
    }

    @Override
    public void close() {
    }

    @Override
    public void flush() {
    }

    public String toString() {
        return this.builder.toString();
    }

    @Override
    public void write(String string2) {
        if (string2 != null) {
            this.builder.append(string2);
        }
    }

    @Override
    public void write(char[] arrc, int n2, int n3) {
        if (arrc != null) {
            this.builder.append(arrc, n2, n3);
        }
    }
}

