/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.c;

import com.startapp.android.publish.e.a.c.c;
import java.nio.charset.Charset;

public class f {
    public static String a(byte[] arrby) {
        return f.a(arrby, c.f);
    }

    private static String a(byte[] arrby, Charset charset) {
        if (arrby == null) {
            return null;
        }
        return new String(arrby, charset);
    }
}

