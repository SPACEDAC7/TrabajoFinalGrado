/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.d;

import com.startapp.android.publish.e.a.c.d;
import com.startapp.android.publish.e.a.d.c;
import com.startapp.android.publish.e.a.d.e;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

public class a
implements e {
    private final c a;

    public a(c c2) {
        this.a = c2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public String a(String var1_1) {
        var3_7 = new ByteArrayOutputStream();
        var2_8 = new GZIPOutputStream(var3_7);
        var2_8.write(var1_1.getBytes());
        d.a(var2_8);
        var1_1 = com.startapp.android.publish.e.a.c.a.a(var3_7.toByteArray());
        var1_1 = this.a.a(var1_1);
        d.a(var2_8);
        return var1_1;
        catch (Exception var1_2) {
            var2_8 = null;
            ** GOTO lbl21
            catch (Throwable var1_3) {
                var2_8 = null;
                ** GOTO lbl18
                catch (Throwable var1_5) {}
lbl18: // 2 sources:
                d.a(var2_8);
                throw var1_4;
            }
            catch (Exception var1_6) {}
lbl21: // 2 sources:
            d.a(var2_8);
            return "";
        }
    }
}

