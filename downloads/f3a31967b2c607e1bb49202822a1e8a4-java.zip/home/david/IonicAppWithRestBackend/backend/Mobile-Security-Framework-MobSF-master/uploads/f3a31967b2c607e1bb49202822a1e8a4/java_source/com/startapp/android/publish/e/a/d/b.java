/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.d;

import com.startapp.android.publish.e.a.d.e;

public class b
implements e {
    @Override
    public String a(String string2) {
        return string2;
    }
}

