/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.d;

import com.startapp.android.publish.e.a.d.c;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class d
implements c {
    private final Pattern a = Pattern.compile("\\+");
    private final Pattern b = Pattern.compile("/");
    private final Pattern c = Pattern.compile("=");
    private final Pattern d = Pattern.compile("_");
    private final Pattern e = Pattern.compile("\\*");
    private final Pattern f = Pattern.compile("#");

    @Override
    public String a(String string2) {
        string2 = this.a.matcher(string2).replaceAll("_");
        string2 = this.b.matcher(string2).replaceAll("*");
        return this.c.matcher(string2).replaceAll("#");
    }
}

