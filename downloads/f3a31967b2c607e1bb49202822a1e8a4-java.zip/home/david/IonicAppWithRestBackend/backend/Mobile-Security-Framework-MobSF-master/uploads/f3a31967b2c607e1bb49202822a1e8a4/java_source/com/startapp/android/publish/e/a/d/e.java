/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.d;

public interface e {
    public String a(String var1);
}

