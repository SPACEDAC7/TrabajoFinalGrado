/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.e;

import com.startapp.android.publish.e.a.a.c;
import com.startapp.android.publish.e.a.e.d;
import java.io.DataInput;

public class a
extends d {
    private final int a;
    private final int b;

    public a(int n2, int n3) {
        this.a = n2;
        this.b = n3;
    }

    @Override
    protected c a(DataInput dataInput) {
        c c2 = new c(this.a * this.b);
        this.a(dataInput, c2, c2.b());
        return c2;
    }
}

