/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.e;

class c {
    c() {
    }

    private boolean b(String string2) {
        if (string2.length() % 2 != 0) {
            return true;
        }
        return false;
    }

    String a(byte[] arrby) {
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = arrby.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            stringBuilder.append(String.format("%02x", arrby[i2] & 255));
        }
        return stringBuilder.toString();
    }

    byte[] a(String arrc) {
        if (this.b((String)arrc)) {
            return null;
        }
        byte[] arrby = new byte[arrc.length() / 2];
        arrc = arrc.toCharArray();
        for (int i2 = 0; i2 < arrc.length; i2 += 2) {
            StringBuilder stringBuilder = new StringBuilder(2);
            stringBuilder.append(arrc[i2]).append(arrc[i2 + 1]);
            arrby[i2 / 2] = (byte)Integer.parseInt(stringBuilder.toString(), 16);
        }
        return arrby;
    }
}

