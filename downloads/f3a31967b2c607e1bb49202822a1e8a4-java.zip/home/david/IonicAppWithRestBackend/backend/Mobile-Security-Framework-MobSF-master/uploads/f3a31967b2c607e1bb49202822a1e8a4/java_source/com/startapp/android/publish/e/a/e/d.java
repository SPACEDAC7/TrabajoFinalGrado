/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.e;

import com.startapp.android.publish.e.a.e.c;
import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.InputStream;

public abstract class d {
    private final c a = new c();

    protected abstract com.startapp.android.publish.e.a.a.c a(DataInput var1);

    public com.startapp.android.publish.e.a.a.c a(String object) {
        try {
            object = this.a(this.a(this.a.a((String)object)));
            return object;
        }
        catch (Exception var1_2) {
            return null;
        }
    }

    protected DataInput a(byte[] arrby) {
        return new DataInputStream(new ByteArrayInputStream(arrby));
    }

    protected void a(DataInput dataInput, com.startapp.android.publish.e.a.a.c c2, long l2) {
        int n2 = c2.c();
        for (int i2 = 0; i2 < n2; ++i2) {
            long l3;
            block3 : {
                long[] arrl = c2.a(i2);
                for (int i3 = 0; i3 < 4096; ++i3) {
                    long l4;
                    l3 = l4 = l2 - 1;
                    if (l2 > 0) {
                        arrl[i3] = dataInput.readLong();
                        l2 = l4;
                        continue;
                    }
                    break block3;
                }
                l3 = l2;
            }
            l2 = l3;
        }
    }
}

