/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.e;

import com.startapp.android.publish.e.a.a.c;
import com.startapp.android.publish.e.a.e.d;
import java.io.DataInput;
import java.io.IOException;

public class e
extends d {
    private void b(DataInput dataInput) {
        try {
            dataInput.readInt();
            return;
        }
        catch (IOException var1_2) {
            throw new RuntimeException("problem incrementInputStreamForBackwordCompatability", var1_2);
        }
    }

    @Override
    protected c a(DataInput dataInput) {
        long l2 = dataInput.readInt();
        c c2 = new c(l2 << 6);
        this.a(dataInput, c2, l2);
        return c2;
    }

    @Override
    protected DataInput a(byte[] object) {
        object = super.a((byte[])object);
        this.b((DataInput)object);
        return object;
    }
}

