/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.f;

import com.startapp.android.publish.e.a.a.c;
import com.startapp.android.publish.e.a.d.e;
import com.startapp.android.publish.e.a.e.b;

public class a {
    private final b a;
    private final e b;
    private final String c;

    public a(b b2, e e2, String string2) {
        this.a = b2;
        this.b = e2;
        this.c = string2;
    }

    public String a(c object, long l2) {
        try {
            object = this.a.a((c)object);
            object = "" + l2 + "-" + this.c + "-" + this.b.a((String)object);
            return object;
        }
        catch (Throwable var1_2) {
            return null;
        }
    }
}

