/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.f;

public class b {
}

