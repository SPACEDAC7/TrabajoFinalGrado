/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.g;

public enum a {
    a("0", 1, 720),
    b("3.0", 1, 720){}
    ,
    c("4", 3, 3500);
    
    private final int numberOfHashes;
    private final int sizeOfBucket;
    private final String version;

    private a(String string3, int n3, int n4) {
        this.version = string3;
        this.numberOfHashes = n3;
        this.sizeOfBucket = n4;
    }

    public String a() {
        return this.version;
    }

    public int b() {
        return this.numberOfHashes;
    }

    public int c() {
        return this.sizeOfBucket;
    }

}

