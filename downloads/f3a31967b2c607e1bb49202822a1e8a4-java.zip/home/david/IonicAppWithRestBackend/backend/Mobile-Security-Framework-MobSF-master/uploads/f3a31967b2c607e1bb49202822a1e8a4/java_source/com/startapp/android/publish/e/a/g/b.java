/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.g;

import com.startapp.android.publish.e.a.a.a;
import com.startapp.android.publish.e.a.d.e;

abstract class b {
    b() {
    }

    abstract e a();

    abstract a b();
}

