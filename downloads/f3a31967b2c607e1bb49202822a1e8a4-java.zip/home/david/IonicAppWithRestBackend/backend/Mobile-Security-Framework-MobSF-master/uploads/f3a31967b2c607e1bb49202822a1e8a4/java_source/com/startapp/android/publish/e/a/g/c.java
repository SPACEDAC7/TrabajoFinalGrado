/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.g;

import com.startapp.android.publish.e.a.g.a;
import com.startapp.android.publish.e.a.g.b;
import com.startapp.android.publish.e.a.g.d;
import com.startapp.android.publish.e.a.g.e;
import com.startapp.android.publish.e.a.g.f;
import java.util.HashMap;
import java.util.Map;

public class c {
    private final Map<a, b> a = new HashMap<a, b>();

    public c() {
        this.a.put(a.a, new f());
        this.a.put(a.b, new e());
        this.a.put(a.c, new d());
    }

    public com.startapp.android.publish.e.a.a.a a(a a2) {
        return this.a.get((Object)a2).b();
    }

    public com.startapp.android.publish.e.a.d.e b(a a2) {
        return this.a.get((Object)a2).a();
    }
}

