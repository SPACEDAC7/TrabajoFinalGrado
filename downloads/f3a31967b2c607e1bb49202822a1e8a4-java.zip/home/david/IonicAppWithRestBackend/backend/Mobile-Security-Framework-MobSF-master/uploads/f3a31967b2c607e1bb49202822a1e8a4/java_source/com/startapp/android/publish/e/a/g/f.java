/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.e.a.g;

import com.startapp.android.publish.e.a.e.d;
import com.startapp.android.publish.e.a.e.e;
import com.startapp.android.publish.e.a.g.a;
import com.startapp.android.publish.e.a.g.b;

class f
extends b {
    private final com.startapp.android.publish.e.a.d.e a = new com.startapp.android.publish.e.a.d.b();
    private final d b = new e();
    private final com.startapp.android.publish.e.a.a.a c = new com.startapp.android.publish.e.a.a.a(a.a.b(), a.a.c());

    f() {
    }

    @Override
    com.startapp.android.publish.e.a.d.e a() {
        return this.a;
    }

    @Override
    com.startapp.android.publish.e.a.a.a b() {
        return this.c;
    }
}

