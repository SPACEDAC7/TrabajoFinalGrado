/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.f;

import android.content.Context;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.l;
import com.startapp.android.publish.g.o;
import com.startapp.android.publish.gson.Gson;
import com.startapp.android.publish.model.BaseRequest;
import com.startapp.android.publish.model.BaseResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class a {
    public static <T extends BaseResponse> T a(Context object, String string2, BaseRequest baseRequest, Map<String, String> map, Class<T> class_) {
        StringBuilder stringBuilder = new StringBuilder();
        a.a((Context)object, string2, baseRequest, map, stringBuilder);
        try {
            object = (BaseResponse)new Gson().fromJson(stringBuilder.toString(), class_);
        }
        catch (Exception var0_1) {
            throw new o("Failed parsing the JSON response to " + class_.getName(), var0_1);
        }
        return (T)object;
    }

    public static String a(Context context, String string2, BaseRequest baseRequest, Map<String, String> map) {
        StringBuilder stringBuilder = new StringBuilder();
        a.a(context, string2, baseRequest, map, stringBuilder);
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static Map<String, String> a(Context object, Map<String, String> object2) {
        HashMap<String, String> hashMap;
        hashMap = object2;
        if (object2 == null) {
            hashMap = new HashMap<String, String>();
        }
        object = com.startapp.android.publish.g.a.a((Context)object);
        try {
            object = object2 = URLEncoder.encode((String)object, "UTF-8");
        }
        catch (UnsupportedEncodingException var1_2) {}
        hashMap.put("device-id", (String)object);
        hashMap.put("Accept-Language", Locale.getDefault().toString());
        return hashMap;
    }

    private static void a(Context context, String object, BaseRequest baseRequest, Map<String, String> map, StringBuilder stringBuilder) {
        String string2 = object;
        if (baseRequest != null) {
            string2 = (String)object + baseRequest.getRequestString();
        }
        j.a("Transport", 3, "Sending get to URL: " + string2);
        object = a.a(context, map);
        boolean bl = false;
        int n2 = 1;
        while (!bl) {
            try {
                l.a(context, string2, object, stringBuilder);
                bl = true;
                continue;
            }
            catch (o var2_3) {
                if (var2_3.a() && n2 < 3) {
                    ++n2;
                    continue;
                }
                throw var2_3;
            }
        }
    }

    public static boolean a(Context context, String string2, Map<String, String> map) {
        a.a(context, string2, null, map, null);
        return true;
    }
}

