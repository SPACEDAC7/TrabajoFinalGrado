/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Looper
 *  android.os.Parcel
 */
package com.startapp.android.publish.g;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Parcel;
import com.startapp.android.publish.g.j;
import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;

public final class a {
    public static String a(Context object) {
        try {
            object = a.b((Context)object);
            if (!object.b()) {
                return object.a();
            }
            return "1";
        }
        catch (Exception var0_1) {
            StackTraceElement[] arrstackTraceElement = var0_1.getStackTrace();
            j.a(3, "Error getting advertising id. stackTrace:");
            for (int i2 = 0; i2 < arrstackTraceElement.length; ++i2) {
                j.a(3, arrstackTraceElement[i2].toString());
            }
            return "0";
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static a b(Context context) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            throw new IllegalStateException("Cannot be called from the main thread");
        }
        context.getPackageManager().getPackageInfo("com.android.vending", 0);
        b b2 = new b();
        Object object = new Intent("com.google.android.gms.ads.identifier.service.START");
        object.setPackage("com.google.android.gms");
        if (!context.getApplicationContext().bindService((Intent)object, (ServiceConnection)b2, 1)) throw new IOException("Google Play connection failed");
        try {
            object = new c(b2.a());
            object = new a(object.a(), object.a(true));
            return object;
        }
        catch (Exception var2_4) {
            throw var2_4;
        }
        finally {
            context.getApplicationContext().unbindService((ServiceConnection)b2);
        }
    }

    public static final class a {
        private final String a;
        private final boolean b;

        a(String string2, boolean bl) {
            this.a = string2;
            this.b = bl;
        }

        public final String a() {
            return this.a;
        }

        public final boolean b() {
            return this.b;
        }
    }

    static final class b
    implements ServiceConnection {
        boolean a = false;
        private final LinkedBlockingQueue<IBinder> b = new LinkedBlockingQueue(1);

        private b() {
        }

        public final IBinder a() {
            if (this.a) {
                throw new IllegalStateException();
            }
            this.a = true;
            return this.b.take();
        }

        public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            try {
                this.b.put(iBinder);
                return;
            }
            catch (InterruptedException var1_2) {
                return;
            }
        }

        public final void onServiceDisconnected(ComponentName componentName) {
        }
    }

    static final class c
    implements IInterface {
        private IBinder a;

        public c(IBinder iBinder) {
            this.a = iBinder;
        }

        public final String a() {
            Parcel parcel = Parcel.obtain();
            Parcel parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                this.a.transact(1, parcel, parcel2, 0);
                parcel2.readException();
                String string2 = parcel2.readString();
                return string2;
            }
            finally {
                parcel2.recycle();
                parcel.recycle();
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public final boolean a(boolean bl) {
            boolean bl2 = true;
            Parcel parcel = Parcel.obtain();
            Parcel parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                int n2 = bl ? 1 : 0;
                parcel.writeInt(n2);
                this.a.transact(2, parcel, parcel2, 0);
                parcel2.readException();
                n2 = parcel2.readInt();
                bl = n2 != 0 ? bl2 : false;
                return bl;
            }
            finally {
                parcel2.recycle();
                parcel.recycle();
            }
        }

        public final IBinder asBinder() {
            return this.a;
        }
    }

}

