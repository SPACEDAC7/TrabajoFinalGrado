/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.graphics.Point
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.provider.Settings
 *  android.provider.Settings$Global
 *  android.provider.Settings$Secure
 *  android.provider.Settings$SettingNotFoundException
 *  android.view.Display
 *  android.view.View
 *  android.view.View$OnAttachStateChangeListener
 *  android.view.ViewPropertyAnimator
 *  android.view.WindowManager
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 */
package com.startapp.android.publish.g;

import android.animation.Animator;
import android.app.Activity;
import android.app.Application;
import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Display;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.startapp.android.publish.StartAppSDK;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.q;

public class b {
    private static Object a = null;

    /*
     * Enabled aggressive block sorting
     */
    public static int a(int n2, int n3) {
        switch (n2) {
            case 1: {
                if (Build.VERSION.SDK_INT > 8 && (n3 == 1 || n3 == 2)) {
                    return 9;
                }
            }
            default: {
                return 1;
            }
            case 2: 
        }
        if (Build.VERSION.SDK_INT <= 8) {
            return 0;
        }
        if (n3 != 0 && n3 != 1) {
            return 8;
        }
        return 0;
    }

    public static Object a(Application application) {
        Application.ActivityLifecycleCallbacks activityLifecycleCallbacks = new Application.ActivityLifecycleCallbacks(){

            public final void onActivityCreated(Activity activity, Bundle bundle) {
                j.a("ApiUtil", 3, "onActivityCreated [" + activity.getClass().getName() + "]");
                StartAppSDK.getInstance().onActivityCreated(activity, bundle);
            }

            public final void onActivityDestroyed(Activity activity) {
                j.a("ApiUtil", 3, "onActivityDestroyed [" + activity.getClass().getName() + "]");
            }

            public final void onActivityPaused(Activity activity) {
                j.a("ApiUtil", 3, "onActivityPaused [" + activity.getClass().getName() + "]");
            }

            public final void onActivityResumed(Activity activity) {
                j.a("ApiUtil", 3, "onActivityResumed [" + activity.getClass().getName() + "]");
            }

            public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
                j.a("ApiUtil", 3, "onActivitySaveInstanceState [" + activity.getClass().getName() + "]");
                StartAppSDK.getInstance().onActivitySaveInstanceState(activity, bundle);
            }

            public final void onActivityStarted(Activity activity) {
                j.a("ApiUtil", 3, "onActivityStarted [" + activity.getClass().getName() + "]");
                StartAppSDK.getInstance().onActivityStarted(activity);
            }

            public final void onActivityStopped(Activity activity) {
                j.a("ApiUtil", 3, "onActivityStopped [" + activity.getClass().getName() + "]");
                StartAppSDK.getInstance().onActivityStopped(activity);
            }
        };
        application.registerActivityLifecycleCallbacks(activityLifecycleCallbacks);
        return activityLifecycleCallbacks;
    }

    public static void a(Activity activity) {
        if (Build.VERSION.SDK_INT >= 9) {
            activity.setRequestedOrientation(7);
            return;
        }
        activity.setRequestedOrientation(1);
    }

    public static void a(Activity activity, int n2) {
        activity.setRequestedOrientation(b.a(n2, activity.getWindowManager().getDefaultDisplay().getRotation()));
    }

    public static void a(Application application, Object object) {
        application.unregisterActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)object);
    }

    public static void a(Context context, WindowManager windowManager, Point point) {
        if (Build.VERSION.SDK_INT >= 13) {
            windowManager.getDefaultDisplay().getSize(point);
            return;
        }
        point.x = q.b(context, windowManager.getDefaultDisplay().getWidth());
        point.y = q.b(context, windowManager.getDefaultDisplay().getHeight());
    }

    public static void a(View view, float f2) {
        view.setAlpha(f2);
    }

    public static void a(View view, long l2) {
        view.animate().alpha(1.0f).setDuration(l2).setListener(null);
    }

    public static void a(View view, final View view2) {
        if (Build.VERSION.SDK_INT > 11) {
            view.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){

                public final void onViewAttachedToWindow(View view) {
                }

                public final void onViewDetachedFromWindow(View view) {
                    view.removeOnAttachStateChangeListener((View.OnAttachStateChangeListener)this);
                    view2.setVisibility(0);
                }
            });
            return;
        }
        view2.setVisibility(0);
    }

    public static void a(WindowManager windowManager, Point point) {
        if (Build.VERSION.SDK_INT >= 13) {
            windowManager.getDefaultDisplay().getSize(point);
            return;
        }
        point.x = windowManager.getDefaultDisplay().getWidth();
        point.y = windowManager.getDefaultDisplay().getHeight();
    }

    public static void a(WebView webView) {
        if (Build.VERSION.SDK_INT >= 17) {
            webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        }
    }

    public static boolean a() {
        if (Build.VERSION.SDK_INT >= 12) {
            return true;
        }
        return false;
    }

    public static boolean a(Context context) {
        block6 : {
            boolean bl;
            block5 : {
                bl = true;
                if (Build.VERSION.SDK_INT >= 17) break block5;
                if (Settings.Secure.getInt((ContentResolver)context.getContentResolver(), (String)"install_non_market_apps") == 1) {
                    return true;
                }
                break block6;
            }
            try {
                int n2 = Settings.Global.getInt((ContentResolver)context.getContentResolver(), (String)"install_non_market_apps");
                if (n2 != 1) {
                    return false;
                }
            }
            catch (Settings.SettingNotFoundException var0_1) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public static void b(Activity activity) {
        if (Build.VERSION.SDK_INT >= 9) {
            activity.setRequestedOrientation(6);
            return;
        }
        activity.setRequestedOrientation(0);
    }

    public static boolean b() {
        if (Build.VERSION.SDK_INT >= 14) {
            return true;
        }
        return false;
    }

}

