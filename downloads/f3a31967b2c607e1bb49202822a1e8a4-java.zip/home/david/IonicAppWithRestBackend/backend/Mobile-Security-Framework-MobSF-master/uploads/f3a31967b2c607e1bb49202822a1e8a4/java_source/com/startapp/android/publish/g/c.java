/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.g;

import com.startapp.android.publish.g.d;
import com.startapp.android.publish.g.j;
import java.net.URLEncoder;
import java.security.MessageDigest;

public class c {
    public static final byte[] a = new byte[]{10, 30, 84, 95, 101, 32, 0, 14, 15, 80, 36, 84, 64, 82, 84, 64, 80, 80, 65, 78, 84, 73, 70, 82, 65, 85, 68, 75, 69, 89, 1, 2, 3, 8, 15, 42, 10, 51, 44, 32};
    public static final String b = new String(new byte[]{38, 116, 115, 61});
    public static final String c = new String(new byte[]{38, 116, 115, 104, 61});
    public static final String d = new String(new byte[]{77, 68, 53});
    public static final String e = new String(new byte[]{85, 84, 70, 45, 56});

    public static String a() {
        a.hashCode();
        System.currentTimeMillis();
        String string2 = new Long(System.currentTimeMillis()).toString();
        return b + string2 + c + c.a(string2);
    }

    private static String a(String object) {
        object.getBytes();
        byte[] arrby = a;
        object = c.a(object.getBytes(), new String(a).substring(a[0], a[1]).getBytes());
        try {
            object = URLEncoder.encode(d.a(MessageDigest.getInstance(d).digest((byte[])object), 3), e);
            return object;
        }
        catch (Exception var0_1) {
            j.a(6, "error", var0_1);
            return "";
        }
    }

    private static byte[] a(byte[] arrby, byte[] arrby2) {
        byte[] arrby3 = new byte[arrby.length];
        for (int i2 = 0; i2 < arrby.length; ++i2) {
            arrby3[i2] = (byte)(arrby[i2] ^ arrby2[i2 % arrby2.length]);
        }
        return arrby3;
    }
}

