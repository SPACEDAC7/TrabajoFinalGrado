/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.g;

import java.io.UnsupportedEncodingException;

public class d {
    static final /* synthetic */ boolean a;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !d.class.desiredAssertionStatus();
        a = bl;
    }

    private d() {
    }

    public static String a(byte[] object, int n2) {
        try {
            object = new String(d.b((byte[])object, n2), "US-ASCII");
            return object;
        }
        catch (UnsupportedEncodingException var0_1) {
            throw new AssertionError(var0_1);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static byte[] a(byte[] arrby, int n2, int n3, int n4) {
        b b2 = new b(n4, null);
        int n5 = n3 / 3 << 2;
        if (b2.d) {
            n4 = n5;
            if (n3 % 3 > 0) {
                n4 = n5 + 4;
            }
        } else {
            n4 = n5;
            switch (n3 % 3) {
                case 0: {
                    break;
                }
                default: {
                    n4 = n5;
                    break;
                }
                case 1: {
                    n4 = n5 + 2;
                    break;
                }
                case 2: {
                    n4 = n5 + 3;
                }
            }
        }
        n5 = n4;
        if (b2.e) {
            n5 = n4;
            if (n3 > 0) {
                int n6 = (n3 - 1) / 57;
                n5 = b2.f ? 2 : 1;
                n5 = n4 + n5 * (n6 + 1);
            }
        }
        b2.a = new byte[n5];
        b2.a(arrby, n2, n3, true);
        if (!a && b2.b != n5) {
            throw new AssertionError();
        }
        return b2.a;
    }

    public static byte[] b(byte[] arrby, int n2) {
        return d.a(arrby, 0, arrby.length, n2);
    }

    static abstract class a {
        public byte[] a;
        public int b;

        a() {
        }
    }

    static class b
    extends a {
        static final /* synthetic */ boolean g;
        private static final byte[] h;
        private static final byte[] i;
        int c;
        public final boolean d;
        public final boolean e;
        public final boolean f;
        private final byte[] j;
        private int k;
        private final byte[] l;

        /*
         * Enabled aggressive block sorting
         */
        static {
            boolean bl = !d.class.desiredAssertionStatus();
            g = bl;
            h = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47};
            i = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95};
        }

        /*
         * Enabled aggressive block sorting
         */
        public b(int n2, byte[] arrby) {
            boolean bl = true;
            this.a = arrby;
            boolean bl2 = (n2 & 1) == 0;
            this.d = bl2;
            bl2 = (n2 & 2) == 0;
            this.e = bl2;
            bl2 = (n2 & 4) != 0 ? bl : false;
            this.f = bl2;
            arrby = (n2 & 8) == 0 ? h : i;
            this.l = arrby;
            this.j = new byte[2];
            this.c = 0;
            n2 = this.e ? 19 : -1;
            this.k = n2;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        public boolean a(byte[] var1_1, int var2_2, int var3_3, boolean var4_4) {
            var10_5 = this.l;
            var11_6 = this.a;
            var6_7 = 0;
            var5_8 = this.k;
            var9_9 = var3_3 + var2_2;
            switch (this.c) {
                case 0: {
                    var7_10 = -1;
                    var3_3 = var2_2;
                    var2_2 = var7_10;
                    ** GOTO lbl34
                }
                case 1: {
                    if (var2_2 + 2 > var9_9) break;
                    var7_10 = this.j[0];
                    var3_3 = var2_2 + 1;
                    var2_2 = var1_1[var2_2];
                    var8_11 = var1_1[var3_3];
                    this.c = 0;
                    var2_2 = (var7_10 & 255) << 16 | (var2_2 & 255) << 8 | var8_11 & 255;
                    ++var3_3;
                    ** GOTO lbl34
                }
                case 2: {
                    if (var2_2 + 1 > var9_9) break;
                    var7_10 = this.j[0];
                    var8_11 = this.j[1];
                    var3_3 = var2_2 + 1;
                    var2_2 = var1_1[var2_2];
                    this.c = 0;
                    var2_2 = (var7_10 & 255) << 16 | (var8_11 & 255) << 8 | var2_2 & 255;
                    ** GOTO lbl34
                }
            }
            var7_10 = -1;
            var3_3 = var2_2;
            var2_2 = var7_10;
lbl34: // 4 sources:
            if (var2_2 != -1) {
                var11_6[0] = var10_5[var2_2 >> 18 & 63];
                var11_6[1] = var10_5[var2_2 >> 12 & 63];
                var11_6[2] = var10_5[var2_2 >> 6 & 63];
                var6_7 = 4;
                var11_6[3] = var10_5[var2_2 & 63];
                if (--var5_8 == 0) {
                    var2_2 = var6_7;
                    if (this.f) {
                        var2_2 = 5;
                        var11_6[4] = 13;
                    }
                    var6_7 = var2_2 + 1;
                    var11_6[var2_2] = 10;
                    var5_8 = 19;
                    var2_2 = var6_7;
                } else {
                    var2_2 = 4;
                }
            } else {
                var2_2 = var6_7;
            }
            while (var3_3 + 3 <= var9_9) {
                var6_7 = (var1_1[var3_3] & 255) << 16 | (var1_1[var3_3 + 1] & 255) << 8 | var1_1[var3_3 + 2] & 255;
                var11_6[var2_2] = var10_5[var6_7 >> 18 & 63];
                var11_6[var2_2 + 1] = var10_5[var6_7 >> 12 & 63];
                var11_6[var2_2 + 2] = var10_5[var6_7 >> 6 & 63];
                var11_6[var2_2 + 3] = var10_5[var6_7 & 63];
                var3_3 += 3;
                var2_2 += 4;
                if (--var5_8 != 0) continue;
                if (this.f) {
                    var5_8 = var2_2 + 1;
                    var11_6[var2_2] = 13;
                    var2_2 = var5_8;
                }
                var5_8 = var2_2 + 1;
                var11_6[var2_2] = 10;
                var6_7 = 19;
                var2_2 = var5_8;
                var5_8 = var6_7;
            }
            if (var4_4) {
                if (var3_3 - this.c == var9_9 - 1) {
                    if (this.c > 0) {
                        var1_1 = this.j;
                        var6_7 = 1;
                        var7_10 = var1_1[0];
                    } else {
                        var7_10 = var1_1[var3_3];
                        ++var3_3;
                        var6_7 = 0;
                    }
                    var7_10 = (var7_10 & 255) << 4;
                    this.c -= var6_7;
                    var8_11 = var2_2 + 1;
                    var11_6[var2_2] = var10_5[var7_10 >> 6 & 63];
                    var6_7 = var8_11 + 1;
                    var11_6[var8_11] = var10_5[var7_10 & 63];
                    var2_2 = var6_7;
                    if (this.d) {
                        var7_10 = var6_7 + 1;
                        var11_6[var6_7] = 61;
                        var2_2 = var7_10 + 1;
                        var11_6[var7_10] = 61;
                    }
                    var6_7 = var2_2;
                    if (this.e) {
                        var6_7 = var2_2;
                        if (this.f) {
                            var11_6[var2_2] = 13;
                            var6_7 = var2_2 + 1;
                        }
                        var11_6[var6_7] = 10;
                        ++var6_7;
                    }
                    var7_10 = var3_3;
                } else if (var3_3 - this.c == var9_9 - 2) {
                    if (this.c > 1) {
                        var12_12 = this.j;
                        var6_7 = 1;
                        var7_10 = var12_12[0];
                    } else {
                        var7_10 = var1_1[var3_3];
                        ++var3_3;
                        var6_7 = 0;
                    }
                    if (this.c > 0) {
                        var8_11 = this.j[var6_7];
                        ++var6_7;
                    } else {
                        var8_11 = var1_1[var3_3];
                        ++var3_3;
                    }
                    var7_10 = (var8_11 & 255) << 2 | (var7_10 & 255) << 10;
                    this.c -= var6_7;
                    var6_7 = var2_2 + 1;
                    var11_6[var2_2] = var10_5[var7_10 >> 12 & 63];
                    var8_11 = var6_7 + 1;
                    var11_6[var6_7] = var10_5[var7_10 >> 6 & 63];
                    var2_2 = var8_11 + 1;
                    var11_6[var8_11] = var10_5[var7_10 & 63];
                    if (this.d) {
                        var6_7 = var2_2 + 1;
                        var11_6[var2_2] = 61;
                        var2_2 = var6_7;
                    }
                    var6_7 = var2_2;
                    if (this.e) {
                        var6_7 = var2_2;
                        if (this.f) {
                            var11_6[var2_2] = 13;
                            var6_7 = var2_2 + 1;
                        }
                        var11_6[var6_7] = 10;
                        ++var6_7;
                    }
                    var7_10 = var3_3;
                } else {
                    var7_10 = var3_3;
                    var6_7 = var2_2;
                    if (this.e) {
                        var7_10 = var3_3;
                        var6_7 = var2_2;
                        if (var2_2 > 0) {
                            var7_10 = var3_3;
                            var6_7 = var2_2;
                            if (var5_8 != 19) {
                                if (this.f) {
                                    var6_7 = var2_2 + 1;
                                    var11_6[var2_2] = 13;
                                    var2_2 = var6_7;
                                }
                                var6_7 = var2_2 + 1;
                                var11_6[var2_2] = 10;
                                var7_10 = var3_3;
                            }
                        }
                    }
                }
                if (!b.g && this.c != 0) {
                    throw new AssertionError();
                }
                var8_11 = var6_7;
                if (!b.g) {
                    var8_11 = var6_7;
                    if (var7_10 != var9_9) {
                        throw new AssertionError();
                    }
                }
            } else if (var3_3 == var9_9 - 1) {
                var10_5 = this.j;
                var6_7 = this.c;
                this.c = var6_7 + 1;
                var10_5[var6_7] = var1_1[var3_3];
                var8_11 = var2_2;
            } else {
                var8_11 = var2_2;
                if (var3_3 == var9_9 - 2) {
                    var10_5 = this.j;
                    var6_7 = this.c;
                    this.c = var6_7 + 1;
                    var10_5[var6_7] = var1_1[var3_3];
                    var10_5 = this.j;
                    var6_7 = this.c;
                    this.c = var6_7 + 1;
                    var10_5[var6_7] = var1_1[var3_3 + 1];
                    var8_11 = var2_2;
                }
            }
            this.b = var8_11;
            this.k = var5_8;
            return true;
        }
    }

}

