/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.util.DisplayMetrics
 */
package com.startapp.android.publish.g;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.DisplayMetrics;
import com.startapp.android.publish.g.n;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class e {
    private static final Map<String, Bitmap> a = new HashMap<String, Bitmap>();

    public static Bitmap a(Context context, String string2) {
        Bitmap bitmap;
        Bitmap bitmap2 = bitmap = e.a(context, string2, false);
        if (bitmap == null) {
            bitmap2 = e.a(context, string2, true);
        }
        return bitmap2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Bitmap a(Context var0, String var1_9, boolean var2_11) {
        var5_12 = null;
        var4_13 = e.a.get(var1_9);
        if (var4_13 != null) {
            return var4_13;
        }
        n.a(var0, var2_11);
        var4_13 = new FileInputStream(var0.getFilesDir().getPath() + "/" + (String)var1_9);
        var5_12 = BitmapFactory.decodeStream((InputStream)var4_13);
        var6_14 = var0.getResources();
        var3_15 = var0.getResources() != null ? var6_14.getDisplayMetrics().densityDpi : 160;
        var5_12.setDensity(var3_15);
        e.a.put((String)var1_9, var5_12);
        try {
            var4_13.close();
            return var5_12;
        }
        catch (IOException var0_1) {
            return var5_12;
        }
        catch (Exception var0_2) {
            return null;
            catch (Throwable var0_4) {
                var1_9 = var5_12;
                ** GOTO lbl26
                catch (Throwable var0_7) {
                    var1_9 = var4_13;
                }
lbl26: // 2 sources:
                if (var1_9 == null) throw var0_5;
                try {
                    var1_9.close();
                }
                catch (IOException var1_10) {
                    throw var0_5;
                }
                throw var0_5;
            }
            catch (Exception var0_8) {
                var0_3 = var4_13;
            }
            if (var0_3 == null) return null;
            try {
                var0_3.close();
                return null;
            }
            catch (IOException var0_6) {
                return null;
            }
        }
    }
}

