/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Process
 */
package com.startapp.android.publish.g;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import com.startapp.android.publish.g.g;

public class f {
    private String a;
    private a b;
    private int c;

    public f(String string2, a a2, int n2) {
        this.a = string2;
        this.b = a2;
        this.c = n2;
    }

    public void a() {
        new Thread(new Runnable(){

            @Override
            public void run() {
                Process.setThreadPriority((int)10);
                final Bitmap bitmap = g.a(f.this.a);
                new Handler(Looper.getMainLooper()).post(new Runnable(){

                    @Override
                    public void run() {
                        if (f.this.b != null) {
                            f.this.b.a(bitmap, f.this.c);
                        }
                    }
                });
            }

        }).start();
    }

    public static interface a {
        public void a(Bitmap var1, int var2);
    }

}

