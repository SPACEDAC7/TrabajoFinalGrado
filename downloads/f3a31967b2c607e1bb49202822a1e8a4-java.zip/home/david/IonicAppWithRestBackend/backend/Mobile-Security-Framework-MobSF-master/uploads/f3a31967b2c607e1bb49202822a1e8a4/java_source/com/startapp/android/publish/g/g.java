/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 */
package com.startapp.android.publish.g;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.BufferedInputStream;
import java.io.FilterInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class g {
    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Bitmap a(String var0) {
        var2_2 = null;
        var1_4 = null;
        var0 = (HttpURLConnection)new URL((String)var0).openConnection();
        var0.connect();
        var2_2 = var0.getInputStream();
        var3_9 = new BufferedInputStream((InputStream)var2_2);
        var1_4 = BitmapFactory.decodeStream((InputStream)new a((InputStream)var2_2));
        var3_9.close();
        var2_2.close();
        if (var0 == null) return var1_4;
        var0.disconnect();
        return var1_4;
        catch (Exception var0_1) {
            var0 = null;
lbl19: // 3 sources:
            do {
                var2_2 = var0;
                if (var1_4 == null) return var2_2;
                var1_4.disconnect();
                return var0;
                break;
            } while (true);
        }
        catch (Throwable var1_5) {
            var0 = var2_2;
lbl26: // 2 sources:
            do {
                if (var0 == null) throw var1_6;
                var0.disconnect();
                throw var1_6;
                break;
            } while (true);
        }
        catch (Throwable var1_7) {
            ** continue;
        }
        {
            catch (Exception var1_8) {
                var2_2 = null;
                var1_4 = var0;
                var0 = var2_2;
                ** GOTO lbl19
            }
            catch (Exception var2_3) {
                var2_2 = var0;
                var0 = var1_4;
                var1_4 = var2_2;
                ** continue;
            }
        }
    }

    static class a
    extends FilterInputStream {
        public a(InputStream inputStream) {
            super(inputStream);
        }

        @Override
        public long skip(long l2) {
            long l3 = 0;
            while (l3 < l2) {
                long l4;
                long l5 = l4 = this.in.skip(l2 - l3);
                if (l4 == 0) {
                    if (this.read() < 0) break;
                    l5 = 1;
                }
                l3 = l5 + l3;
            }
            return l3;
        }
    }

}

