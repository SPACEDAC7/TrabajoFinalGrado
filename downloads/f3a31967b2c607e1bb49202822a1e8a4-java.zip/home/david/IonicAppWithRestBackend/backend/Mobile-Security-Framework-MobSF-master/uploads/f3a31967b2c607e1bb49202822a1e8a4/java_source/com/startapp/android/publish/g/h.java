/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 */
package com.startapp.android.publish.g;

import android.content.Context;
import android.content.SharedPreferences;

public class h {
    private static SharedPreferences a = null;

    private static SharedPreferences a(Context context) {
        if (a == null) {
            a = context.getApplicationContext().getSharedPreferences("com.startapp.android.publish", 0);
        }
        return a;
    }

    public static Boolean a(Context context, String string2, Boolean bl) {
        return h.a(context).getBoolean(string2, bl.booleanValue());
    }

    public static String a(Context context, String string2, String string3) {
        return h.a(context).getString(string2, string3);
    }

    public static void b(Context context, String string2, Boolean bl) {
        h.a(context).edit().putBoolean(string2, bl.booleanValue()).commit();
    }

    public static void b(Context context, String string2, String string3) {
        h.a(context).edit().putString(string2, string3).commit();
    }
}

