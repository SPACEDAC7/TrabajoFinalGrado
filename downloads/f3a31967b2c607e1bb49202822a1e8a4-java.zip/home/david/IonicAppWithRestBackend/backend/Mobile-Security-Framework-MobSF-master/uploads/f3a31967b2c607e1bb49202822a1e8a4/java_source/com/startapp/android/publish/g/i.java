/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.g;

import android.content.Context;
import com.startapp.android.publish.g.j;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;
import java.io.OutputStream;
import java.io.Serializable;

public class i {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static <T> T a(Context var0, String var1_1, Class<T> var2_14) {
        var1_1 = new ObjectInputStream(new FileInputStream(new File(var0.getCacheDir(), (String)var1_1)));
        var0 = var1_1.readObject();
        var1_1.close();
        return (T)var0;
        catch (FileNotFoundException var1_2) {
            var0 = null;
            ** GOTO lbl29
            catch (OptionalDataException var1_4) {
                var0 = null;
                ** GOTO lbl26
                catch (ClassNotFoundException var1_6) {
                    var0 = null;
                    ** GOTO lbl23
                    catch (IOException var1_8) {
                        var0 = null;
                        ** GOTO lbl20
                        catch (IOException var1_10) {}
lbl20: // 2 sources:
                        j.a(6, "IO Exception", (Throwable)var1_9);
                        return (T)var0;
                    }
                    catch (ClassNotFoundException var1_11) {}
lbl23: // 2 sources:
                    j.a(6, "Class Not Found Exception", (Throwable)var1_7);
                    return (T)var0;
                }
                catch (OptionalDataException var1_12) {}
lbl26: // 2 sources:
                j.a(6, "Optional Data Exception", (Throwable)var1_5);
                return (T)var0;
            }
            catch (FileNotFoundException var1_13) {}
lbl29: // 2 sources:
            j.a(6, "File not found", (Throwable)var1_3);
            return (T)var0;
        }
    }

    public static void a(Context object, String string2, Serializable serializable) {
        try {
            object = new ObjectOutputStream(new FileOutputStream(new File(object.getCacheDir(), string2)));
            object.writeObject(serializable);
            object.close();
            return;
        }
        catch (FileNotFoundException var0_1) {
            j.a(6, "File not found", var0_1);
            return;
        }
        catch (IOException var0_2) {
            j.a(6, "IO exception", var0_2);
            return;
        }
    }
}

