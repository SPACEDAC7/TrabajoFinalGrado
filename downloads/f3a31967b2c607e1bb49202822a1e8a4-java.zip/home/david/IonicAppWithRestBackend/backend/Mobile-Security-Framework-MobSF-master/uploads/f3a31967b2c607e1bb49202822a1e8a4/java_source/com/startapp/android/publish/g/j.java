/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.startapp.android.publish.g;

import android.util.Log;
import com.startapp.android.publish.b;

public class j {
    public static void a(int n2, String string2) {
        if (b.a().booleanValue()) {
            j.a(null, n2, string2, null);
        }
    }

    public static void a(int n2, String string2, Throwable throwable) {
        j.a(null, n2, string2, throwable);
    }

    public static void a(String string2, int n2, String string3) {
        if (b.a().booleanValue()) {
            j.a(string2, n2, string3, null);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(String string2, int n2, String string3, Throwable throwable) {
        string2 = string2 == null ? "" : "." + string2;
        if (b.a() == false) return;
        StringBuffer stringBuffer = new StringBuffer(string3);
        if (stringBuffer.length() <= 4000) {
            j.b("startapp" + string2, n2, string3, throwable);
            return;
        }
        j.b("startapp" + string2, n2, "sb.length = " + stringBuffer.length(), throwable);
        int n3 = stringBuffer.length() / 4000;
        int n4 = 0;
        while (n4 <= n3) {
            int n5 = (n4 + 1) * 4000;
            if (n5 >= stringBuffer.length()) {
                j.b("startapp" + string2, n2, "" + n4 + "/" + n3 + ":" + stringBuffer.substring(n4 * 4000), null);
            } else {
                j.b("startapp" + string2, n2, "" + n4 + "/" + n3 + ":" + stringBuffer.substring(n4 * 4000, n5), null);
            }
            ++n4;
        }
    }

    private static void b(String string2, int n2, String string3, Throwable throwable) {
        switch (n2) {
            default: {
                return;
            }
            case 2: {
                Log.v((String)string2, (String)string3, (Throwable)throwable);
                return;
            }
            case 3: {
                Log.d((String)string2, (String)string3, (Throwable)throwable);
                return;
            }
            case 6: {
                Log.e((String)string2, (String)string3, (Throwable)throwable);
                return;
            }
            case 4: 
        }
        Log.i((String)string2, (String)string3, (Throwable)throwable);
    }
}

