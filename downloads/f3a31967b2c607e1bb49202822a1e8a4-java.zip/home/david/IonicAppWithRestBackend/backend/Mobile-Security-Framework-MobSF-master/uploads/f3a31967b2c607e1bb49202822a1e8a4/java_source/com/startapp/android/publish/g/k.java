/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.telephony.PhoneStateListener
 *  android.telephony.SignalStrength
 *  android.telephony.TelephonyManager
 */
package com.startapp.android.publish.g;

import android.content.Context;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import com.startapp.android.publish.g.l;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class k {
    private static k a = null;
    private Context b;
    private String c = "e106";
    private PhoneStateListener d;

    private k(Context context) {
        this.d = new PhoneStateListener(){

            public void onSignalStrengthsChanged(SignalStrength signalStrength) {
                try {
                    Method method = SignalStrength.class.getMethod("getLevel", null);
                    k.this.c = Integer.toString((Integer)method.invoke((Object)signalStrength, null));
                    return;
                }
                catch (NoSuchMethodException var1_2) {
                    k.this.c = "e104";
                    return;
                }
                catch (IllegalAccessException var1_3) {
                    k.this.c = "e105";
                    return;
                }
                catch (IllegalArgumentException var1_4) {
                    k.this.c = "e105";
                    return;
                }
                catch (InvocationTargetException var1_5) {
                    k.this.c = "e105";
                    return;
                }
            }
        };
        this.b = context.getApplicationContext();
        ((TelephonyManager)context.getSystemService("phone")).listen(this.d, 256);
    }

    public static k a() {
        return a;
    }

    public static void a(Context context) {
        if (a == null) {
            a = new k(context);
        }
    }

    public String a(String string2) {
        if (string2.toLowerCase().compareTo("WIFI".toLowerCase()) == 0) {
            return l.b(this.b);
        }
        return this.c;
    }

}

