/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.net.wifi.WifiInfo
 *  android.net.wifi.WifiManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.telephony.TelephonyManager
 */
package com.startapp.android.publish.g;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.telephony.TelephonyManager;
import com.startapp.android.publish.g.h;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;

public class l {
    static {
        if (Build.VERSION.SDK_INT < 8) {
            System.setProperty("http.keepAlive", "false");
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String a(Context context) {
        Object object = (ConnectivityManager)context.getSystemService("connectivity");
        if (object == null) return "e100";
        if ((object = object.getActiveNetworkInfo()) == null || !object.isConnected()) return "e102";
        if ((object = object.getTypeName()).toLowerCase().compareTo("WIFI".toLowerCase()) == 0) {
            return "WIFI";
        }
        if (object.toLowerCase().compareTo("MOBILE".toLowerCase()) != 0) return "e100";
        if ((context = (TelephonyManager)context.getSystemService("phone")) == null) return "e101";
        return Integer.toString(context.getNetworkType());
    }

    /*
     * Enabled aggressive block sorting
     */
    private static HttpURLConnection a(Context object, String object2, byte[] arrby, Map<String, String> map) {
        object2 = (HttpURLConnection)new URL((String)object2).openConnection();
        object2.addRequestProperty("Cache-Control", "no-cache");
        object = h.a((Context)object, "User-Agent", "-1");
        if (object.compareTo("-1") != 0) {
            object2.addRequestProperty("User-Agent", (String)object);
        }
        if (arrby != null) {
            object2.setRequestMethod("POST");
            object2.setDoOutput(true);
            object2.setFixedLengthStreamingMode(arrby.length);
            object2.setRequestProperty("Content-Type", "application/json");
        } else {
            object2.setRequestMethod("GET");
        }
        object2.setRequestProperty("Accept", "application/json;text/html;text/plain");
        object2.setReadTimeout(10000);
        object2.setConnectTimeout(10000);
        return object2;
    }

    /*
     * Exception decompiling
     */
    public static boolean a(Context var0, String var1_3, Map<String, String> var2_5, StringBuilder var3_6) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[TRYBLOCK]], but top level block is 19[SIMPLE_IF_TAKEN]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2869)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:817)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:129)
        // org.benf.cfr.reader.Main.main(Main.java:181)
        throw new IllegalStateException("Decompilation failed");
    }

    public static String b(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager)context.getSystemService("connectivity");
        if (connectivityManager != null) {
            if ((connectivityManager = connectivityManager.getActiveNetworkInfo()) != null && connectivityManager.isConnected()) {
                if (connectivityManager.getTypeName().compareTo("WIFI") == 0) {
                    if (context.checkCallingOrSelfPermission("android.permission.ACCESS_WIFI_STATE") == 0) {
                        return Integer.toString(WifiManager.calculateSignalLevel((int)((WifiManager)context.getSystemService("wifi")).getConnectionInfo().getRssi(), (int)5));
                    }
                    return "e105";
                }
                return "e103";
            }
            return "e102";
        }
        return "e100";
    }
}

