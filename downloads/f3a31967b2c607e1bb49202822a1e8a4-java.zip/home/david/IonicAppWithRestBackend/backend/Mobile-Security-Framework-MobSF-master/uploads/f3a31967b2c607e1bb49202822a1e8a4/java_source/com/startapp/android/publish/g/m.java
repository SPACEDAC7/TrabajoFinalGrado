/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 */
package com.startapp.android.publish.g;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.startapp.android.publish.g.e;
import com.startapp.android.publish.g.q;

public class m
extends LinearLayout {
    public m(Context context) {
        super(context);
    }

    private void a(String string2) {
        int n2 = q.a(this.getContext(), 2);
        int n3 = q.a(this.getContext(), 5);
        ImageView imageView = new ImageView(this.getContext());
        imageView.setImageBitmap(e.a(this.getContext(), string2));
        imageView.setPadding(n2, 0, 0, n3);
        this.addView((View)imageView);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setRating(float f2) {
        int n2;
        int n3 = 1;
        int n4 = 0;
        this.removeAllViews();
        f2 = (float)Math.round(f2 * 2.0f) / 2.0f;
        int n5 = (int)Math.floor(f2);
        boolean bl = f2 - (float)n5 == 0.5f;
        if (!bl) {
            n3 = 0;
        }
        for (n2 = 0; n2 < n5; ++n2) {
            this.a("filled_star.png");
        }
        n2 = n4;
        if (bl) {
            this.a("half_star.png");
            n2 = n4;
        }
        while (n2 < 5 - n5 - n3) {
            this.a("empty_star.png");
            ++n2;
        }
        return;
    }
}

