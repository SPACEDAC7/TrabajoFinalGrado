/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.g;

public class o
extends Exception {
    private static final long serialVersionUID = 1;
    private boolean retry = false;

    public o() {
    }

    public o(String string2, Throwable throwable) {
        this(string2, throwable, false);
    }

    public o(String string2, Throwable throwable, boolean bl) {
        super(string2, throwable);
        this.retry = bl;
    }

    public boolean a() {
        return this.retry;
    }
}

