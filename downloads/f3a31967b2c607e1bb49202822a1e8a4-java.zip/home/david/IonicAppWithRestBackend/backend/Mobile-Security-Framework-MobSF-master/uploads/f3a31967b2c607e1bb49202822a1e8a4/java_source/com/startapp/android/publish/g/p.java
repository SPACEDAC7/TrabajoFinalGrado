/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package com.startapp.android.publish.g;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import com.startapp.android.publish.b;
import com.startapp.android.publish.e.a.b.a;
import com.startapp.android.publish.g.j;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class p {
    private static boolean a = false;

    public static String a(Context object) {
        j.a("SimpleToken", 3, "createSimpleToken entered");
        object = new a().a(p.b((Context)object));
        j.a("SimpleToken", 3, "simpleToken : [" + (String)object + "]");
        return object;
    }

    private static List<PackageInfo> a(List<PackageInfo> list) {
        if (list.size() <= 100) {
            return list;
        }
        if (Build.VERSION.SDK_INT >= 9) {
            Collections.sort(list, new Comparator<PackageInfo>(){

                public final int a(PackageInfo packageInfo, PackageInfo packageInfo2) {
                    long l2 = packageInfo.firstInstallTime;
                    long l3 = packageInfo2.firstInstallTime;
                    if (l2 > l3) {
                        return -1;
                    }
                    if (l2 == l3) {
                        return 0;
                    }
                    return 1;
                }

                @Override
                public final /* synthetic */ int compare(Object object, Object object2) {
                    return this.a((PackageInfo)object, (PackageInfo)object2);
                }
            });
        }
        return list.subList(0, 100);
    }

    private static boolean a(PackageInfo packageInfo) {
        if ((packageInfo.applicationInfo.flags & 1) != 0 || (packageInfo.applicationInfo.flags & 128) != 0) {
            return true;
        }
        return false;
    }

    public static List<String> b(Context object) {
        j.a("SimpleToken", 3, "getPackageList entered");
        Object object2 = p.c((Context)object);
        object = new ArrayList();
        object2 = p.a(object2).iterator();
        while (object2.hasNext()) {
            object.add(((PackageInfo)object2.next()).packageName);
        }
        if (a) {
            object.add(0, b.b);
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static List<PackageInfo> c(Context list) {
        j.a("SimpleToken", 3, "getPackages entered");
        Iterator iterator = list.getPackageManager();
        list = new ArrayList();
        new ArrayList();
        try {}
        catch (RuntimeException var1_2) {
            j.a("SimpleToken", 6, "Could not complete getInstalledPackages", var1_2);
            return list;
        }
        iterator = iterator.getInstalledPackages(8192);
        a = false;
        iterator = iterator.iterator();
        while (iterator.hasNext()) {
            PackageInfo packageInfo = (PackageInfo)iterator.next();
            if (!p.a(packageInfo)) {
                list.add(packageInfo);
                continue;
            }
            if (!packageInfo.packageName.equals(b.b)) continue;
            a = true;
        }
        return list;
    }

}

