/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Typeface
 *  android.util.DisplayMetrics
 *  android.widget.TextView
 */
package com.startapp.android.publish.g;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.util.DisplayMetrics;
import android.widget.TextView;
import java.util.Set;

public class q {
    public static int a(Context context, int n2) {
        return (int)(context.getResources().getDisplayMetrics().density * (float)n2 + 0.5f);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(TextView textView, Set<String> set) {
        if (set.contains("UNDERLINE")) {
            textView.setPaintFlags(textView.getPaintFlags() | 8);
        }
        int n2 = 0;
        if (set.contains("BOLD") && set.contains("ITALIC")) {
            n2 = 3;
        } else if (set.contains("BOLD")) {
            n2 = 1;
        } else if (set.contains("ITALIC")) {
            n2 = 2;
        }
        textView.setTypeface(null, n2);
    }

    public static int b(Context context, int n2) {
        float f2 = context.getResources().getDisplayMetrics().density;
        return (int)(((float)n2 - 0.5f) / f2);
    }
}

