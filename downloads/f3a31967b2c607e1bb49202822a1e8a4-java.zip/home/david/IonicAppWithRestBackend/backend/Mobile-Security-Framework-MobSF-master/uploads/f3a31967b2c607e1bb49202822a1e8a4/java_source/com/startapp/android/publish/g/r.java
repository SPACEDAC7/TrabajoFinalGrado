/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ResolveInfo
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.content.res.Resources$NotFoundException
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.net.Uri
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.webkit.WebChromeClient
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.startapp.android.publish.g;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.startapp.android.publish.adinformation.AdInformationConfig;
import com.startapp.android.publish.adinformation.e;
import com.startapp.android.publish.g.b;
import com.startapp.android.publish.g.c;
import com.startapp.android.publish.g.h;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.o;
import com.startapp.android.publish.g.p;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;
import com.startapp.android.publish.model.NameValueObject;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;

public class r {
    private static Map<Activity, Integer> a = new WeakHashMap<Activity, Integer>();
    private static ThreadPoolExecutor b = new ThreadPoolExecutor(1, 4, 0, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>());
    private static ProgressDialog c;
    private static boolean d;

    static {
        d = false;
    }

    public static int a(Context context, int n2) {
        return (int)(context.getResources().getDisplayMetrics().density * (float)n2 + 0.5f);
    }

    public static int a(String arrstring) {
        arrstring = arrstring.split("&");
        return Integer.parseInt(arrstring[arrstring.length - 1].split("=")[1]);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String a() {
        Object object;
        Object object2 = null;
        Object object3 = "";
        try {
            object2 = object = r.i();
        }
        catch (Exception var0_2) {
            object3 = "0";
        }
        object = object3;
        if (object3.compareTo("0") != 0) {
            block6 : {
                object = object2.getProperty("inapp.version");
                if (object != null) {
                    object3 = object;
                    if (!"".equals(object)) break block6;
                }
                object3 = "0";
            }
            object = object3;
            if ("${project.version}".equals(object3)) {
                object = "0";
            }
        }
        object3 = (String)object + r.d();
        j.a(3, "SDK version: [" + (String)object3 + "]");
        return object3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String a(Context object, String string2) {
        try {
            return object.getResources().getString(object.getApplicationInfo().labelRes);
        }
        catch (Resources.NotFoundException var2_4) {
            PackageManager packageManager = object.getPackageManager();
            Object var2_5 = null;
            try {
                object = packageManager.getApplicationInfo(object.getApplicationInfo().packageName, 0);
            }
            catch (PackageManager.NameNotFoundException var0_1) {
                object = var2_5;
            }
            if (object != null) {
                object = packageManager.getApplicationLabel((ApplicationInfo)object);
                return (String)object;
            }
            object = string2;
            return (String)object;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String a(String string2, String string3, String string4) {
        int n2;
        int n3;
        if (string2 == null || string3 == null || string4 == null || (n2 = string2.indexOf(string3)) == -1 || (n3 = string2.indexOf(string4, string3.length() + n2)) == -1) {
            return null;
        }
        return string2.substring(string3.length() + n2, n3);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(Activity activity, int n2, boolean bl) {
        if (bl) {
            if (!a.containsKey((Object)activity)) {
                a.put(activity, activity.getRequestedOrientation());
            }
            b.a(activity, n2);
            return;
        } else {
            if (!a.containsKey((Object)activity)) return;
            {
                activity.setRequestedOrientation(a.get((Object)activity).intValue());
                a.remove((Object)activity);
                return;
            }
        }
    }

    public static void a(Activity activity, boolean bl) {
        r.a(activity, activity.getResources().getConfiguration().orientation, bl);
    }

    public static void a(Context object, Intent intent) {
        for (ResolveInfo resolveInfo : object.getPackageManager().queryIntentActivities(intent, 0)) {
            if (!resolveInfo.activityInfo.packageName.equalsIgnoreCase(com.startapp.android.publish.b.b)) continue;
            intent.setComponent(new ComponentName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name));
        }
    }

    public static void a(Context object, AdPreferences adPreferences) {
        String string2 = h.a((Context)object, "shared_prefs_devId", null);
        object = h.a((Context)object, "shared_prefs_appId", null);
        if (adPreferences.getPublisherId() == null) {
            adPreferences.setPublisherId(string2);
        }
        if (adPreferences.getProductId() == null) {
            adPreferences.setProductId((String)object);
        }
        if (!(adPreferences.getProductId() != null && adPreferences.getPublisherId() != null || d)) {
            d = true;
            Log.e((String)"StartApp", (String)"Integration Error - Developer ID and/or App ID is missing");
        }
    }

    private static final void a(Context context, String string2, int n2, Runnable runnable) {
        context.sendBroadcast(new Intent("com.startapp.android.OnClickCallback"));
        if (context instanceof Activity) {
            r.a((Activity)context, true);
        }
        final WebView webView = new WebView(context);
        if (c == null && context instanceof Activity && !((Activity)context).isFinishing()) {
            ProgressDialog progressDialog;
            c = progressDialog = ProgressDialog.show((Context)context, (CharSequence)null, (CharSequence)"Loading....", (boolean)false, (boolean)false, (DialogInterface.OnCancelListener)new DialogInterface.OnCancelListener(){

                public final void onCancel(DialogInterface dialogInterface) {
                    webView.stopLoading();
                }
            });
            progressDialog.setCancelable(false);
        }
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient((WebViewClient)new a(context, n2, c, string2, runnable));
        webView.loadUrl(string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static final void a(Context context, String string2, String string3) {
        if (string3 != null && !string3.equals("")) {
            r.e(context, string3);
        }
        string3 = new Intent("android.intent.action.VIEW");
        StringBuilder stringBuilder = new StringBuilder().append(string2);
        string2 = MetaData.getInstance().isDisableTwoClicks() ? c.a() : "";
        string3.setData(Uri.parse((String)stringBuilder.append(string2).toString()));
        context.startActivity((Intent)string3);
    }

    public static final void a(Context context, String string2, String string3, int n2) {
        r.a(context, string2, string3, n2, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static final void a(Context context, String string2, String string3, int n2, Runnable runnable) {
        void var3_4;
        void var4_5;
        if (string3 != null && !string3.equals("")) {
            r.e(context, string3);
        }
        StringBuilder stringBuilder = new StringBuilder().append(string2);
        string2 = MetaData.getInstance().isDisableTwoClicks() ? c.a() : "";
        r.a(context, stringBuilder.append(string2).toString(), (int)var3_4, (Runnable)var4_5);
    }

    public static void a(Context context, String[] arrstring) {
        if (arrstring != null) {
            for (int i2 = 0; i2 < arrstring.length; ++i2) {
                j.a(3, "Sending Impression: [" + arrstring[i2] + "]");
                r.b(context, arrstring[i2]);
            }
        }
    }

    public static void a(WebView webView, String string2) {
        try {
            webView.loadDataWithBaseURL("http://www.startappexchange.com", string2, "text/html", "utf-8", null);
            return;
        }
        catch (Exception var0_1) {
            j.a(6, "StartAppWall.UtilError while encoding html");
            return;
        }
    }

    public static void a(String string2, String string3, String object, Context context) {
        r.e(context, (String)object);
        string2 = context.getPackageManager().getLaunchIntentForPackage(string2);
        if (string3 != null) {
            try {
                string3 = new JSONObject(string3);
                object = string3.keys();
                while (object.hasNext()) {
                    String string4 = String.valueOf(object.next());
                    string2.putExtra(string4, String.valueOf(string3.get(string4)));
                }
            }
            catch (JSONException var1_2) {
                j.a(6, "Couldn't parse intent details json!", (Throwable)var1_2);
            }
        }
        context.startActivity((Intent)string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(List<NameValueObject> list, String string2, Object object, boolean bl) {
        if (bl && object == null) {
            throw new o("Required key: [" + string2 + "] is missing", null);
        }
        if (object == null) return;
        try {
            NameValueObject nameValueObject = new NameValueObject();
            nameValueObject.setName(string2);
            nameValueObject.setValue(URLEncoder.encode(object.toString(), "UTF-8"));
            list.add(nameValueObject);
            return;
        }
        catch (UnsupportedEncodingException var0_1) {
            if (!bl) return;
            throw new o("failed encoding value: [" + object + "]", var0_1);
        }
    }

    public static void a(List<NameValueObject> list, String object, Set<String> set, boolean bl) {
        if (bl && set == null) {
            throw new o("Required key: [" + (String)object + "] is missing", null);
        }
        if (set != null) {
            NameValueObject nameValueObject = new NameValueObject();
            nameValueObject.setName((String)object);
            object = new HashSet();
            for (String string2 : set) {
                try {
                    object.add(URLEncoder.encode(string2, "UTF-8"));
                }
                catch (UnsupportedEncodingException var6_7) {}
            }
            if (bl && object.size() == 0) {
                throw new o("failed encoding value: [" + set + "]", null);
            }
            nameValueObject.setValueSet((Set<String>)object);
            list.add(nameValueObject);
        }
    }

    public static boolean a(Activity activity) {
        boolean bl = activity.getTheme().obtainStyledAttributes(new int[]{16843277}).getBoolean(0, false);
        if ((activity.getWindow().getAttributes().flags & 1024) != 0) {
            return true;
        }
        return bl;
    }

    public static boolean a(Context context) {
        if (com.startapp.android.publish.b.OVERRIDE_HOST != null) {
            return true;
        }
        if ((context = ((ConnectivityManager)context.getSystemService("connectivity")).getActiveNetworkInfo()) != null && context.isConnected()) {
            return true;
        }
        return false;
    }

    public static String b() {
        return "&position=" + r.c();
    }

    public static final void b(Context context) {
        r.g(context);
    }

    public static void b(Context context, String string2) {
        r.e(context, string2);
    }

    public static void b(Context context, String string2, String string3) {
        h.b(context, "shared_prefs_devId", string2.trim());
        h.b(context, "shared_prefs_appId", string3.trim());
    }

    private static boolean b(String string2) {
        try {
            Class.forName(string2);
            return true;
        }
        catch (ClassNotFoundException var0_1) {
            return false;
        }
        catch (Exception var0_2) {
            return false;
        }
    }

    public static String c() {
        StackTraceElement[] arrstackTraceElement = new Throwable().getStackTrace();
        for (int i2 = 0; i2 < 8; ++i2) {
            if (arrstackTraceElement[i2].getMethodName().compareTo("doHome") == 0) {
                return "home";
            }
            if (arrstackTraceElement[i2].getMethodName().compareTo("onBackPressed") != 0) continue;
            return "back";
        }
        return "interstitial";
    }

    public static void c(Context context) {
        h.b(context, "shared_prefs_simple_token", p.a(context));
    }

    public static void c(Context context, String string2) {
        r.e(context, string2);
    }

    private static String d() {
        if (r.g()) {
            return "_Unity";
        }
        if (r.h()) {
            return "_Cordova";
        }
        if (r.e()) {
            return "_AdMob";
        }
        if (r.f()) {
            return "_MoPub";
        }
        return "";
    }

    public static String d(Context context) {
        StringBuffer stringBuffer = new StringBuffer();
        if (MetaData.getInstance().getAdInformationConfig().e().a(context)) {
            stringBuffer.append(h.a(context, "shared_prefs_simple_token", ""));
        }
        return stringBuffer.toString();
    }

    public static void d(Context context, String string2) {
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse((String)string2));
        intent.addFlags(344457216);
        r.a(context, intent);
        try {
            context.startActivity(intent);
            return;
        }
        catch (Exception var0_1) {
            j.a(6, "Cannot find activity to handle url: [" + string2 + "]");
            return;
        }
    }

    public static String e(Context object) {
        String string2 = "";
        Intent intent = new Intent();
        intent.setAction("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        intent = object.getPackageManager().resolveActivity(intent, 0);
        object = string2;
        if (intent != null) {
            object = string2;
            if (intent.activityInfo != null) {
                object = string2 = intent.activityInfo.packageName;
                if (string2 != null) {
                    object = string2.toLowerCase();
                }
            }
        }
        return object;
    }

    private static void e(final Context context, final String string2) {
        if (!string2.equals("")) {
            b.execute(new Runnable(){

                @Override
                public final void run() {
                    try {
                        com.startapp.android.publish.f.a.a(context, string2 + c.a(), null);
                        return;
                    }
                    catch (o var1_1) {
                        j.a(6, "Error sending tracking message", var1_1);
                        return;
                    }
                }
            });
        }
    }

    private static boolean e() {
        return r.b("com.startapp.android.mediation.admob.StartAppCustomEvent");
    }

    private static boolean f() {
        return r.b("com.startapp.android.mediation.mopub.StartAppCustomEventInterstitial");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void g(Context context) {
        if (context != null && context instanceof Activity) {
            r.a((Activity)context, false);
        }
        if (c == null) {
            return;
        }
        context = c;
        synchronized (context) {
            boolean bl;
            if (c != null && (bl = c.isShowing())) {
                try {
                    c.cancel();
                }
                catch (Exception var2_2) {
                    j.a(6, "Error while cancelling progress", var2_2);
                }
                c = null;
            }
            return;
        }
    }

    private static boolean g() {
        return r.b("com.apperhand.unity.wrapper.InAppWrapper");
    }

    private static boolean h() {
        return r.b("org.apache.cordova.CordovaPlugin");
    }

    private static Properties i() {
        Properties properties = new Properties();
        try {
            properties.load(r.class.getClassLoader().getResourceAsStream("startapp.properties"));
            return properties;
        }
        catch (Exception var1_1) {
            properties.load(r.class.getClassLoader().getResourceAsStream("assets/startapp.properties"));
            return properties;
        }
    }

    static class a
    extends WebViewClient {
        private String a = "";
        private boolean b = false;
        private boolean c = false;
        private int d;
        private ProgressDialog e;
        private Runnable f;
        private boolean g = false;
        private Context h;

        public a(Context context, int n2, ProgressDialog progressDialog, String string2, Runnable runnable) {
            this.h = context;
            this.d = n2;
            this.e = progressDialog;
            this.a = string2;
            this.f = runnable;
        }

        private void a() {
            new Thread(new Runnable(){

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                @Override
                public void run() {
                    try {
                        Thread.sleep(a.this.d);
                    }
                    catch (InterruptedException var1_1) {}
                    if (!a.this.b) {
                        a.this.g = true;
                        r.g(a.this.h);
                        r.d(a.this.h, a.this.a);
                        if (a.this.f != null) {
                            a.this.f.run();
                        }
                    }
                }
            }).start();
        }

        public void onPageFinished(WebView webView, String string2) {
            j.a(2, "MyWebViewClient::onPageFinished - [" + string2 + "]");
            super.onPageFinished(webView, string2);
        }

        public void onPageStarted(WebView webView, String string2, Bitmap bitmap) {
            j.a(2, "MyWebViewClient::onPageStarted - [" + string2 + "]");
            super.onPageStarted(webView, string2, bitmap);
            if (!this.c) {
                this.a();
                this.c = true;
            }
        }

        public void onReceivedError(WebView webView, int n2, String string2, String string3) {
            j.a(2, "MyWebViewClient::onReceivedError - [" + string2 + "], [" + string3 + "]");
            super.onReceivedError(webView, n2, string2, string3);
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public boolean shouldOverrideUrlLoading(WebView object, String string2) {
            j.a(2, "MyWebViewClient::shouldOverrideUrlLoading - [" + string2 + "]");
            try {
                this.a = string2;
                object = string2.toLowerCase();
                if (!object.startsWith("market") && !object.startsWith("http://play.google.com") && !object.startsWith("https://play.google.com")) return false;
                boolean bl = true;
                if (!bl) return false;
                if (this.g) return true;
                this.b = true;
                r.g(this.h);
                r.d(this.h, string2);
                if (this.f != null) {
                    this.f.run();
                }
                do {
                    return true;
                    break;
                } while (true);
            }
            catch (Exception var1_2) {
                j.a(6, "StartAppWall.UtilExcpetion - view to attached to window - Load Progress");
                return true;
            }
        }

    }

}

