/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

import com.startapp.android.publish.gson.FieldAttributes;

public interface ExclusionStrategy {
    public boolean shouldSkipClass(Class<?> var1);

    public boolean shouldSkipField(FieldAttributes var1);
}

