/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

import java.lang.reflect.Field;

public interface FieldNamingStrategy {
    public String translateName(Field var1);
}

