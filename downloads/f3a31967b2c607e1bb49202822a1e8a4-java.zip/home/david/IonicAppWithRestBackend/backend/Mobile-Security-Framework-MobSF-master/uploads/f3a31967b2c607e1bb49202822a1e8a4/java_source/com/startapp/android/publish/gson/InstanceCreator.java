/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

import java.lang.reflect.Type;

public interface InstanceCreator<T> {
    public T createInstance(Type var1);
}

