/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

import com.startapp.android.publish.gson.JsonDeserializationContext;
import com.startapp.android.publish.gson.JsonElement;
import java.lang.reflect.Type;

public interface JsonDeserializer<T> {
    public T deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3);
}

