/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

import com.startapp.android.publish.gson.JsonElement;

public final class JsonNull
extends JsonElement {
    public static final JsonNull INSTANCE = new JsonNull();

    @Override
    final JsonNull deepCopy() {
        return INSTANCE;
    }

    public final boolean equals(Object object) {
        if (this == object || object instanceof JsonNull) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return JsonNull.class.hashCode();
    }
}

