/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

import com.startapp.android.publish.gson.JsonArray;
import com.startapp.android.publish.gson.JsonElement;
import com.startapp.android.publish.gson.JsonNull;
import com.startapp.android.publish.gson.JsonPrimitive;
import com.startapp.android.publish.gson.internal.LinkedTreeMap;
import java.util.Map;
import java.util.Set;

public final class JsonObject
extends JsonElement {
    private final LinkedTreeMap<String, JsonElement> members = new LinkedTreeMap();

    private JsonElement createJsonElement(Object object) {
        if (object == null) {
            return JsonNull.INSTANCE;
        }
        return new JsonPrimitive(object);
    }

    public final void add(String string2, JsonElement jsonElement) {
        JsonElement jsonElement2 = jsonElement;
        if (jsonElement == null) {
            jsonElement2 = JsonNull.INSTANCE;
        }
        this.members.put(string2, jsonElement2);
    }

    public final void addProperty(String string2, Boolean bl) {
        this.add(string2, this.createJsonElement(bl));
    }

    public final void addProperty(String string2, Character c2) {
        this.add(string2, this.createJsonElement(c2));
    }

    public final void addProperty(String string2, Number number) {
        this.add(string2, this.createJsonElement(number));
    }

    public final void addProperty(String string2, String string3) {
        this.add(string2, this.createJsonElement(string3));
    }

    @Override
    final JsonObject deepCopy() {
        JsonObject jsonObject = new JsonObject();
        for (Map.Entry<String, JsonElement> entry : this.members.entrySet()) {
            jsonObject.add(entry.getKey(), entry.getValue().deepCopy());
        }
        return jsonObject;
    }

    public final Set<Map.Entry<String, JsonElement>> entrySet() {
        return this.members.entrySet();
    }

    public final boolean equals(Object object) {
        if (object == this || object instanceof JsonObject && ((JsonObject)object).members.equals(this.members)) {
            return true;
        }
        return false;
    }

    public final JsonElement get(String string2) {
        return this.members.get(string2);
    }

    public final JsonArray getAsJsonArray(String string2) {
        return (JsonArray)this.members.get(string2);
    }

    public final JsonObject getAsJsonObject(String string2) {
        return (JsonObject)this.members.get(string2);
    }

    public final JsonPrimitive getAsJsonPrimitive(String string2) {
        return (JsonPrimitive)this.members.get(string2);
    }

    public final boolean has(String string2) {
        return this.members.containsKey(string2);
    }

    public final int hashCode() {
        return this.members.hashCode();
    }

    public final JsonElement remove(String string2) {
        return this.members.remove(string2);
    }
}

