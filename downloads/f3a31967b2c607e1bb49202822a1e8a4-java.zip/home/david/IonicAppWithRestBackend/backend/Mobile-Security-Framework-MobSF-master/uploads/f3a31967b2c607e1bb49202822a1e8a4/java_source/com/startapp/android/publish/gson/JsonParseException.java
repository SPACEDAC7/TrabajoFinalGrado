/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

public class JsonParseException
extends RuntimeException {
    static final long serialVersionUID = -4086729973971783390L;

    public JsonParseException(String string2) {
        super(string2);
    }

    public JsonParseException(String string2, Throwable throwable) {
        super(string2, throwable);
    }

    public JsonParseException(Throwable throwable) {
        super(throwable);
    }
}

