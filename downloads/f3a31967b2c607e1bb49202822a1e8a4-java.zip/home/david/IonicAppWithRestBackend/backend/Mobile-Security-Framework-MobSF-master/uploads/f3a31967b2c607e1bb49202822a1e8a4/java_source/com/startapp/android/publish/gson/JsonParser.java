/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

import com.startapp.android.publish.gson.JsonElement;
import com.startapp.android.publish.gson.JsonIOException;
import com.startapp.android.publish.gson.JsonParseException;
import com.startapp.android.publish.gson.JsonSyntaxException;
import com.startapp.android.publish.gson.internal.Streams;
import com.startapp.android.publish.gson.stream.JsonReader;
import com.startapp.android.publish.gson.stream.JsonToken;
import com.startapp.android.publish.gson.stream.MalformedJsonException;
import java.io.Closeable;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

public final class JsonParser {
    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final JsonElement parse(JsonReader jsonReader) {
        boolean bl = jsonReader.isLenient();
        jsonReader.setLenient(true);
        try {
            JsonElement jsonElement = Streams.parse(jsonReader);
            return jsonElement;
        }
        catch (StackOverflowError var3_4) {
            throw new JsonParseException("Failed parsing JSON source: " + jsonReader + " to Json", var3_4);
        }
        catch (OutOfMemoryError var3_6) {
            throw new JsonParseException("Failed parsing JSON source: " + jsonReader + " to Json", var3_6);
        }
        finally {
            jsonReader.setLenient(bl);
        }
    }

    public final JsonElement parse(Reader closeable) {
        JsonElement jsonElement;
        try {
            closeable = new JsonReader((Reader)closeable);
            jsonElement = this.parse((JsonReader)closeable);
            if (!jsonElement.isJsonNull() && closeable.peek() != JsonToken.END_DOCUMENT) {
                throw new JsonSyntaxException("Did not consume the entire document.");
            }
        }
        catch (MalformedJsonException var1_2) {
            throw new JsonSyntaxException(var1_2);
        }
        catch (IOException var1_3) {
            throw new JsonIOException(var1_3);
        }
        catch (NumberFormatException var1_4) {
            throw new JsonSyntaxException(var1_4);
        }
        return jsonElement;
    }

    public final JsonElement parse(String string2) {
        return this.parse(new StringReader(string2));
    }
}

