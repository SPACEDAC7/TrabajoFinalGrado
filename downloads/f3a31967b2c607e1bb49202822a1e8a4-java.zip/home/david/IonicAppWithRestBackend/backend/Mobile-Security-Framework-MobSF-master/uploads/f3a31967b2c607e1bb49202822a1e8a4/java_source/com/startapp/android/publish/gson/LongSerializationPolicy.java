/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

import com.startapp.android.publish.gson.JsonElement;
import com.startapp.android.publish.gson.JsonPrimitive;

public enum LongSerializationPolicy {
    DEFAULT{

        @Override
        public final JsonElement serialize(Long l2) {
            return new JsonPrimitive(l2);
        }
    }
    ,
    STRING{

        @Override
        public final JsonElement serialize(Long l2) {
            return new JsonPrimitive(String.valueOf(l2));
        }
    };
    

    private LongSerializationPolicy() {
    }

    public abstract JsonElement serialize(Long var1);

}

