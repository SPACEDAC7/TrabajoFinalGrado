/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

import com.startapp.android.publish.gson.Gson;
import com.startapp.android.publish.gson.JsonDeserializationContext;
import com.startapp.android.publish.gson.JsonDeserializer;
import com.startapp.android.publish.gson.JsonElement;
import com.startapp.android.publish.gson.JsonSerializationContext;
import com.startapp.android.publish.gson.JsonSerializer;
import com.startapp.android.publish.gson.TypeAdapter;
import com.startapp.android.publish.gson.TypeAdapterFactory;
import com.startapp.android.publish.gson.internal.$Gson$Preconditions;
import com.startapp.android.publish.gson.internal.Streams;
import com.startapp.android.publish.gson.reflect.TypeToken;
import com.startapp.android.publish.gson.stream.JsonReader;
import com.startapp.android.publish.gson.stream.JsonWriter;
import java.lang.reflect.Type;

final class TreeTypeAdapter<T>
extends TypeAdapter<T> {
    private TypeAdapter<T> delegate;
    private final JsonDeserializer<T> deserializer;
    private final Gson gson;
    private final JsonSerializer<T> serializer;
    private final TypeAdapterFactory skipPast;
    private final TypeToken<T> typeToken;

    private TreeTypeAdapter(JsonSerializer<T> jsonSerializer, JsonDeserializer<T> jsonDeserializer, Gson gson, TypeToken<T> typeToken, TypeAdapterFactory typeAdapterFactory) {
        this.serializer = jsonSerializer;
        this.deserializer = jsonDeserializer;
        this.gson = gson;
        this.typeToken = typeToken;
        this.skipPast = typeAdapterFactory;
    }

    private TypeAdapter<T> delegate() {
        TypeAdapter<T> typeAdapter = this.delegate;
        if (typeAdapter != null) {
            return typeAdapter;
        }
        this.delegate = typeAdapter = this.gson.getDelegateAdapter(this.skipPast, this.typeToken);
        return typeAdapter;
    }

    public static TypeAdapterFactory newFactory(TypeToken<?> typeToken, Object object) {
        return new SingleTypeFactory(object, typeToken, false, null);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static TypeAdapterFactory newFactoryWithMatchRawType(TypeToken<?> typeToken, Object object) {
        boolean bl;
        if (typeToken.getType() == typeToken.getRawType()) {
            bl = true;
            do {
                return new SingleTypeFactory(object, typeToken, bl, null);
                break;
            } while (true);
        }
        bl = false;
        return new SingleTypeFactory(object, typeToken, bl, null);
    }

    public static TypeAdapterFactory newTypeHierarchyFactory(Class<?> class_, Object object) {
        return new SingleTypeFactory(object, null, false, class_);
    }

    @Override
    public final T read(JsonReader object) {
        if (this.deserializer == null) {
            return this.delegate().read((JsonReader)object);
        }
        if ((object = Streams.parse((JsonReader)object)).isJsonNull()) {
            return null;
        }
        return this.deserializer.deserialize((JsonElement)object, this.typeToken.getType(), this.gson.deserializationContext);
    }

    @Override
    public final void write(JsonWriter jsonWriter, T t) {
        if (this.serializer == null) {
            this.delegate().write(jsonWriter, t);
            return;
        }
        if (t == null) {
            jsonWriter.nullValue();
            return;
        }
        Streams.write(this.serializer.serialize(t, this.typeToken.getType(), this.gson.serializationContext), jsonWriter);
    }

    static class SingleTypeFactory
    implements TypeAdapterFactory {
        private final JsonDeserializer<?> deserializer;
        private final TypeToken<?> exactType;
        private final Class<?> hierarchyType;
        private final boolean matchRawType;
        private final JsonSerializer<?> serializer;

        /*
         * Enabled aggressive block sorting
         */
        private SingleTypeFactory(Object object, TypeToken<?> typeToken, boolean bl, Class<?> class_) {
            JsonSerializer jsonSerializer = object instanceof JsonSerializer ? (JsonSerializer)object : null;
            this.serializer = jsonSerializer;
            object = object instanceof JsonDeserializer ? (JsonDeserializer)object : null;
            this.deserializer = object;
            boolean bl2 = this.serializer != null || this.deserializer != null;
            $Gson$Preconditions.checkArgument(bl2);
            this.exactType = typeToken;
            this.matchRawType = bl;
            this.hierarchyType = class_;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
            if (this.exactType != null) {
                if (this.exactType.equals(typeToken) || this.matchRawType && this.exactType.getType() == typeToken.getRawType()) {
                    return new TreeTypeAdapter(this.serializer, this.deserializer, gson, typeToken, this);
                }
                return null;
            }
            boolean bl = this.hierarchyType.isAssignableFrom(typeToken.getRawType());
            if (bl) {
                return new TreeTypeAdapter(this.serializer, this.deserializer, gson, typeToken, this);
            }
            return null;
        }
    }

}

