/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson;

import com.startapp.android.publish.gson.JsonElement;
import com.startapp.android.publish.gson.JsonIOException;
import com.startapp.android.publish.gson.internal.bind.JsonTreeReader;
import com.startapp.android.publish.gson.internal.bind.JsonTreeWriter;
import com.startapp.android.publish.gson.stream.JsonReader;
import com.startapp.android.publish.gson.stream.JsonToken;
import com.startapp.android.publish.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

public abstract class TypeAdapter<T> {
    public final T fromJson(Reader reader) {
        return this.read(new JsonReader(reader));
    }

    public final T fromJson(String string2) {
        return this.fromJson(new StringReader(string2));
    }

    public final T fromJsonTree(JsonElement jsonElement) {
        try {
            jsonElement = this.read(new JsonTreeReader(jsonElement));
        }
        catch (IOException var1_2) {
            throw new JsonIOException(var1_2);
        }
        return (T)jsonElement;
    }

    public final TypeAdapter<T> nullSafe() {
        return new TypeAdapter<T>(){

            @Override
            public T read(JsonReader jsonReader) {
                if (jsonReader.peek() == JsonToken.NULL) {
                    jsonReader.nextNull();
                    return null;
                }
                return TypeAdapter.this.read(jsonReader);
            }

            @Override
            public void write(JsonWriter jsonWriter, T t) {
                if (t == null) {
                    jsonWriter.nullValue();
                    return;
                }
                TypeAdapter.this.write(jsonWriter, t);
            }
        };
    }

    public abstract T read(JsonReader var1);

    public final String toJson(T t) {
        StringWriter stringWriter = new StringWriter();
        this.toJson(stringWriter, t);
        return stringWriter.toString();
    }

    public final void toJson(Writer writer, T t) {
        this.write(new JsonWriter(writer), t);
    }

    public final JsonElement toJsonTree(T object) {
        try {
            JsonTreeWriter jsonTreeWriter = new JsonTreeWriter();
            this.write(jsonTreeWriter, object);
            object = jsonTreeWriter.get();
            return object;
        }
        catch (IOException var1_2) {
            throw new JsonIOException(var1_2);
        }
    }

    public abstract void write(JsonWriter var1, T var2);

}

