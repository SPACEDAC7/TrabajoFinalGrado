/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson.internal;

import com.startapp.android.publish.gson.internal.$Gson$Preconditions;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;

public final class $Gson$Types {
    static final Type[] EMPTY_TYPE_ARRAY = new Type[0];

    private $Gson$Types() {
    }

    public static GenericArrayType arrayOf(Type type) {
        return new GenericArrayTypeImpl(type);
    }

    public static Type canonicalize(Type type) {
        if (type instanceof Class) {
            if ((type = (Class)type).isArray()) {
                type = new GenericArrayTypeImpl($Gson$Types.canonicalize(type.getComponentType()));
            }
            return type;
        }
        if (type instanceof ParameterizedType) {
            type = (ParameterizedType)type;
            return new ParameterizedTypeImpl(type.getOwnerType(), type.getRawType(), type.getActualTypeArguments());
        }
        if (type instanceof GenericArrayType) {
            return new GenericArrayTypeImpl(((GenericArrayType)type).getGenericComponentType());
        }
        if (type instanceof WildcardType) {
            type = (WildcardType)type;
            return new WildcardTypeImpl(type.getUpperBounds(), type.getLowerBounds());
        }
        return type;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void checkNotPrimitive(Type type) {
        boolean bl = !(type instanceof Class) || !((Class)type).isPrimitive();
        $Gson$Preconditions.checkArgument(bl);
    }

    private static Class<?> declaringClassOf(TypeVariable<?> typeVariable) {
        if ((typeVariable = typeVariable.getGenericDeclaration()) instanceof Class) {
            return (Class)((Object)typeVariable);
        }
        return null;
    }

    static boolean equal(Object object, Object object2) {
        if (object == object2 || object != null && object.equals(object2)) {
            return true;
        }
        return false;
    }

    public static boolean equals(Type type, Type type2) {
        Type type3 = type;
        type = type2;
        do {
            if (type3 == type) {
                return true;
            }
            if (type3 instanceof Class) {
                return type3.equals(type);
            }
            if (type3 instanceof ParameterizedType) {
                if (!(type instanceof ParameterizedType)) {
                    return false;
                }
                type2 = (ParameterizedType)type3;
                type = (ParameterizedType)type;
                if ($Gson$Types.equal(type2.getOwnerType(), type.getOwnerType()) && type2.getRawType().equals(type.getRawType()) && Arrays.equals(type2.getActualTypeArguments(), type.getActualTypeArguments())) {
                    return true;
                }
                return false;
            }
            if (!(type3 instanceof GenericArrayType)) break;
            if (!(type instanceof GenericArrayType)) {
                return false;
            }
            type2 = (GenericArrayType)type3;
            type = (GenericArrayType)type;
            type3 = type2.getGenericComponentType();
            type = type.getGenericComponentType();
        } while (true);
        if (type3 instanceof WildcardType) {
            if (!(type instanceof WildcardType)) {
                return false;
            }
            type2 = (WildcardType)type3;
            type = (WildcardType)type;
            if (Arrays.equals(type2.getUpperBounds(), type.getUpperBounds()) && Arrays.equals(type2.getLowerBounds(), type.getLowerBounds())) {
                return true;
            }
            return false;
        }
        if (type3 instanceof TypeVariable) {
            if (!(type instanceof TypeVariable)) {
                return false;
            }
            type2 = (TypeVariable)type3;
            type = (TypeVariable)type;
            if (type2.getGenericDeclaration() == type.getGenericDeclaration() && type2.getName().equals(type.getName())) {
                return true;
            }
            return false;
        }
        return false;
    }

    public static Type getArrayComponentType(Type type) {
        if (type instanceof GenericArrayType) {
            return ((GenericArrayType)type).getGenericComponentType();
        }
        return ((Class)type).getComponentType();
    }

    public static Type getCollectionElementType(Type type, Class<?> type2) {
        type = type2 = $Gson$Types.getSupertype(type, type2, Collection.class);
        if (type2 instanceof WildcardType) {
            type = ((WildcardType)type2).getUpperBounds()[0];
        }
        if (type instanceof ParameterizedType) {
            return ((ParameterizedType)type).getActualTypeArguments()[0];
        }
        return Object.class;
    }

    /*
     * Enabled aggressive block sorting
     */
    static Type getGenericSupertype(Type object, Class<?> class_, Class<?> class_2) {
        Object object2 = class_;
        class_ = object;
        object = object2;
        block0 : while (class_2 != object) {
            if (class_2.isInterface()) {
                object2 = object.getInterfaces();
                int n2 = object2.length;
                for (int i2 = 0; i2 < n2; ++i2) {
                    if (object2[i2] == class_2) {
                        return object.getGenericInterfaces()[i2];
                    }
                    if (!class_2.isAssignableFrom(object2[i2])) continue;
                    class_ = object.getGenericInterfaces()[i2];
                    object = object2[i2];
                    continue block0;
                }
            }
            class_ = class_2;
            if (object.isInterface()) break;
            do {
                class_ = class_2;
                if (object == Object.class) break block0;
                class_ = object.getSuperclass();
                if (class_ == class_2) {
                    return object.getGenericSuperclass();
                }
                if (class_2.isAssignableFrom(class_)) {
                    object2 = object.getGenericSuperclass();
                    object = class_;
                    class_ = object2;
                    continue block0;
                }
                object = class_;
            } while (true);
        }
        return class_;
    }

    public static Type[] getMapKeyAndValueTypes(Type type, Class<?> class_) {
        if (type == Properties.class) {
            return new Type[]{String.class, String.class};
        }
        if ((type = $Gson$Types.getSupertype(type, class_, Map.class)) instanceof ParameterizedType) {
            return ((ParameterizedType)type).getActualTypeArguments();
        }
        return new Type[]{Object.class, Object.class};
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Class<?> getRawType(Type type) {
        String string2;
        do {
            if (type instanceof Class) {
                return (Class)type;
            }
            if (type instanceof ParameterizedType) {
                type = ((ParameterizedType)type).getRawType();
                $Gson$Preconditions.checkArgument(type instanceof Class);
                return (Class)type;
            }
            if (type instanceof GenericArrayType) {
                return Array.newInstance($Gson$Types.getRawType(((GenericArrayType)type).getGenericComponentType()), 0).getClass();
            }
            if (type instanceof TypeVariable) {
                return Object.class;
            }
            if (!(type instanceof WildcardType)) break;
            type = ((WildcardType)type).getUpperBounds()[0];
        } while (true);
        if (type == null) {
            string2 = "null";
            do {
                throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + type + "> is of type " + string2);
                break;
            } while (true);
        }
        string2 = type.getClass().getName();
        throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + type + "> is of type " + string2);
    }

    static Type getSupertype(Type type, Class<?> class_, Class<?> class_2) {
        $Gson$Preconditions.checkArgument(class_2.isAssignableFrom(class_));
        return $Gson$Types.resolve(type, class_, $Gson$Types.getGenericSupertype(type, class_, class_2));
    }

    private static int hashCodeOrZero(Object object) {
        if (object != null) {
            return object.hashCode();
        }
        return 0;
    }

    private static int indexOf(Object[] arrobject, Object object) {
        for (int i2 = 0; i2 < arrobject.length; ++i2) {
            if (!object.equals(arrobject[i2])) continue;
            return i2;
        }
        throw new NoSuchElementException();
    }

    public static /* varargs */ ParameterizedType newParameterizedTypeWithOwner(Type type, Type type2, Type ... arrtype) {
        return new ParameterizedTypeImpl(type, type2, arrtype);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Type resolve(Type type, Class<?> class_, Type object) {
        Object object2 = object;
        while (object2 instanceof TypeVariable) {
            object = $Gson$Types.resolveTypeVariable(type, class_, object2 = (TypeVariable)object2);
            if (object == object2) return object;
            {
                object2 = object;
                continue;
            }
        }
        if (object2 instanceof Class && ((Class)object2).isArray()) {
            object = (Class)object2;
            object2 = object.getComponentType();
            if (object2 == (type = $Gson$Types.resolve(type, class_, object2))) return object;
            return $Gson$Types.arrayOf(type);
        }
        if (object2 instanceof GenericArrayType) {
            object = (GenericArrayType)object2;
            object2 = object.getGenericComponentType();
            if (object2 == (type = $Gson$Types.resolve(type, class_, object2))) return object;
            return $Gson$Types.arrayOf(type);
        }
        if (object2 instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType)object2;
            object = parameterizedType.getOwnerType();
            Type type2 = $Gson$Types.resolve(type, class_, object);
            boolean bl = type2 != object;
            object2 = parameterizedType.getActualTypeArguments();
            int n2 = object2.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                Type type3 = $Gson$Types.resolve(type, class_, object2[i2]);
                boolean bl2 = bl;
                object = object2;
                if (type3 != object2[i2]) {
                    bl2 = bl;
                    object = object2;
                    if (!bl) {
                        object = (Type[])object2.clone();
                        bl2 = true;
                    }
                    object[i2] = type3;
                }
                bl = bl2;
                object2 = object;
            }
            object = parameterizedType;
            if (!bl) return object;
            return $Gson$Types.newParameterizedTypeWithOwner(type2, parameterizedType.getRawType(), (Type[])object2);
        }
        object = object2;
        if (!(object2 instanceof WildcardType)) return object;
        object2 = (WildcardType)object2;
        Type[] arrtype = object2.getLowerBounds();
        Type[] arrtype2 = object2.getUpperBounds();
        if (arrtype.length == 1) {
            type = $Gson$Types.resolve(type, class_, arrtype[0]);
            object = object2;
            if (type == arrtype[0]) return object;
            return $Gson$Types.supertypeOf(type);
        }
        object = object2;
        if (arrtype2.length != 1) return object;
        type = $Gson$Types.resolve(type, class_, arrtype2[0]);
        object = object2;
        if (type != arrtype2[0]) return $Gson$Types.subtypeOf(type);
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    static Type resolveTypeVariable(Type type, Class<?> class_, TypeVariable<?> typeVariable) {
        Class class_2 = $Gson$Types.declaringClassOf(typeVariable);
        if (class_2 == null || !((type = $Gson$Types.getGenericSupertype(type, class_, class_2)) instanceof ParameterizedType)) {
            return typeVariable;
        }
        int n2 = $Gson$Types.indexOf(class_2.getTypeParameters(), typeVariable);
        return ((ParameterizedType)type).getActualTypeArguments()[n2];
    }

    public static WildcardType subtypeOf(Type type) {
        Type[] arrtype = EMPTY_TYPE_ARRAY;
        return new WildcardTypeImpl(new Type[]{type}, arrtype);
    }

    public static WildcardType supertypeOf(Type type) {
        return new WildcardTypeImpl(new Type[]{Object.class}, new Type[]{type});
    }

    public static String typeToString(Type type) {
        if (type instanceof Class) {
            return ((Class)type).getName();
        }
        return type.toString();
    }

    static final class GenericArrayTypeImpl
    implements Serializable,
    GenericArrayType {
        private static final long serialVersionUID = 0;
        private final Type componentType;

        public GenericArrayTypeImpl(Type type) {
            this.componentType = $Gson$Types.canonicalize(type);
        }

        public final boolean equals(Object object) {
            if (object instanceof GenericArrayType && $Gson$Types.equals(this, (GenericArrayType)object)) {
                return true;
            }
            return false;
        }

        @Override
        public final Type getGenericComponentType() {
            return this.componentType;
        }

        public final int hashCode() {
            return this.componentType.hashCode();
        }

        public final String toString() {
            return $Gson$Types.typeToString(this.componentType) + "[]";
        }
    }

    static final class ParameterizedTypeImpl
    implements Serializable,
    ParameterizedType {
        private static final long serialVersionUID = 0;
        private final Type ownerType;
        private final Type rawType;
        private final Type[] typeArguments;

        /*
         * Enabled aggressive block sorting
         */
        public /* varargs */ ParameterizedTypeImpl(Type type, Type type2, Type ... arrtype) {
            boolean bl = true;
            int n2 = 0;
            if (type2 instanceof Class) {
                Class class_ = (Class)type2;
                boolean bl2 = type != null || class_.getEnclosingClass() == null;
                $Gson$Preconditions.checkArgument(bl2);
                bl2 = bl;
                if (type != null) {
                    bl2 = class_.getEnclosingClass() != null ? bl : false;
                }
                $Gson$Preconditions.checkArgument(bl2);
            }
            type = type == null ? null : $Gson$Types.canonicalize(type);
            this.ownerType = type;
            this.rawType = $Gson$Types.canonicalize(type2);
            this.typeArguments = (Type[])arrtype.clone();
            while (n2 < this.typeArguments.length) {
                $Gson$Preconditions.checkNotNull(this.typeArguments[n2]);
                $Gson$Types.checkNotPrimitive(this.typeArguments[n2]);
                this.typeArguments[n2] = $Gson$Types.canonicalize(this.typeArguments[n2]);
                ++n2;
            }
            return;
        }

        public final boolean equals(Object object) {
            if (object instanceof ParameterizedType && $Gson$Types.equals(this, (ParameterizedType)object)) {
                return true;
            }
            return false;
        }

        @Override
        public final Type[] getActualTypeArguments() {
            return (Type[])this.typeArguments.clone();
        }

        @Override
        public final Type getOwnerType() {
            return this.ownerType;
        }

        @Override
        public final Type getRawType() {
            return this.rawType;
        }

        public final int hashCode() {
            return Arrays.hashCode(this.typeArguments) ^ this.rawType.hashCode() ^ $Gson$Types.hashCodeOrZero(this.ownerType);
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder((this.typeArguments.length + 1) * 30);
            stringBuilder.append($Gson$Types.typeToString(this.rawType));
            if (this.typeArguments.length == 0) {
                return stringBuilder.toString();
            }
            stringBuilder.append("<").append($Gson$Types.typeToString(this.typeArguments[0]));
            for (int i2 = 1; i2 < this.typeArguments.length; ++i2) {
                stringBuilder.append(", ").append($Gson$Types.typeToString(this.typeArguments[i2]));
            }
            return stringBuilder.append(">").toString();
        }
    }

    static final class WildcardTypeImpl
    implements Serializable,
    WildcardType {
        private static final long serialVersionUID = 0;
        private final Type lowerBound;
        private final Type upperBound;

        /*
         * Enabled aggressive block sorting
         */
        public WildcardTypeImpl(Type[] arrtype, Type[] arrtype2) {
            boolean bl = true;
            boolean bl2 = arrtype2.length <= 1;
            $Gson$Preconditions.checkArgument(bl2);
            bl2 = arrtype.length == 1;
            $Gson$Preconditions.checkArgument(bl2);
            if (arrtype2.length != 1) {
                $Gson$Preconditions.checkNotNull(arrtype[0]);
                $Gson$Types.checkNotPrimitive(arrtype[0]);
                this.lowerBound = null;
                this.upperBound = $Gson$Types.canonicalize(arrtype[0]);
                return;
            }
            $Gson$Preconditions.checkNotNull(arrtype2[0]);
            $Gson$Types.checkNotPrimitive(arrtype2[0]);
            bl2 = arrtype[0] == Object.class ? bl : false;
            $Gson$Preconditions.checkArgument(bl2);
            this.lowerBound = $Gson$Types.canonicalize(arrtype2[0]);
            this.upperBound = Object.class;
        }

        public final boolean equals(Object object) {
            if (object instanceof WildcardType && $Gson$Types.equals(this, (WildcardType)object)) {
                return true;
            }
            return false;
        }

        @Override
        public final Type[] getLowerBounds() {
            if (this.lowerBound != null) {
                return new Type[]{this.lowerBound};
            }
            return $Gson$Types.EMPTY_TYPE_ARRAY;
        }

        @Override
        public final Type[] getUpperBounds() {
            return new Type[]{this.upperBound};
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public final int hashCode() {
            int n2;
            if (this.lowerBound != null) {
                n2 = this.lowerBound.hashCode() + 31;
                do {
                    return n2 ^ this.upperBound.hashCode() + 31;
                    break;
                } while (true);
            }
            n2 = 1;
            return n2 ^ this.upperBound.hashCode() + 31;
        }

        public final String toString() {
            if (this.lowerBound != null) {
                return "? super " + $Gson$Types.typeToString(this.lowerBound);
            }
            if (this.upperBound == Object.class) {
                return "?";
            }
            return "? extends " + $Gson$Types.typeToString(this.upperBound);
        }
    }

}

