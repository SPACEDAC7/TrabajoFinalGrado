/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson.internal;

import com.startapp.android.publish.gson.ExclusionStrategy;
import com.startapp.android.publish.gson.FieldAttributes;
import com.startapp.android.publish.gson.Gson;
import com.startapp.android.publish.gson.TypeAdapter;
import com.startapp.android.publish.gson.TypeAdapterFactory;
import com.startapp.android.publish.gson.annotations.Expose;
import com.startapp.android.publish.gson.annotations.Since;
import com.startapp.android.publish.gson.annotations.Until;
import com.startapp.android.publish.gson.reflect.TypeToken;
import com.startapp.android.publish.gson.stream.JsonReader;
import com.startapp.android.publish.gson.stream.JsonWriter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class Excluder
implements TypeAdapterFactory,
Cloneable {
    public static final Excluder DEFAULT = new Excluder();
    private static final double IGNORE_VERSIONS = -1.0;
    private List<ExclusionStrategy> deserializationStrategies = Collections.emptyList();
    private int modifiers = 136;
    private boolean requireExpose;
    private List<ExclusionStrategy> serializationStrategies = Collections.emptyList();
    private boolean serializeInnerClasses = true;
    private double version = -1.0;

    private boolean isAnonymousOrLocal(Class<?> class_) {
        if (!Enum.class.isAssignableFrom(class_) && (class_.isAnonymousClass() || class_.isLocalClass())) {
            return true;
        }
        return false;
    }

    private boolean isInnerClass(Class<?> class_) {
        if (class_.isMemberClass() && !this.isStatic(class_)) {
            return true;
        }
        return false;
    }

    private boolean isStatic(Class<?> class_) {
        if ((class_.getModifiers() & 8) != 0) {
            return true;
        }
        return false;
    }

    private boolean isValidSince(Since since) {
        if (since != null && since.value() > this.version) {
            return false;
        }
        return true;
    }

    private boolean isValidUntil(Until until) {
        if (until != null && until.value() <= this.version) {
            return false;
        }
        return true;
    }

    private boolean isValidVersion(Since since, Until until) {
        if (this.isValidSince(since) && this.isValidUntil(until)) {
            return true;
        }
        return false;
    }

    protected final Excluder clone() {
        try {
            Excluder excluder = (Excluder)super.clone();
            return excluder;
        }
        catch (CloneNotSupportedException var1_2) {
            throw new AssertionError();
        }
    }

    @Override
    public final <T> TypeAdapter<T> create(final Gson gson, final TypeToken<T> typeToken) {
        Class<T> class_ = typeToken.getRawType();
        final boolean bl = this.excludeClass(class_, true);
        final boolean bl2 = this.excludeClass(class_, false);
        if (!bl && !bl2) {
            return null;
        }
        return new TypeAdapter<T>(){
            private TypeAdapter<T> delegate;

            private TypeAdapter<T> delegate() {
                TypeAdapter<T> typeAdapter = this.delegate;
                if (typeAdapter != null) {
                    return typeAdapter;
                }
                this.delegate = typeAdapter = gson.getDelegateAdapter(Excluder.this, typeToken);
                return typeAdapter;
            }

            @Override
            public T read(JsonReader jsonReader) {
                if (bl2) {
                    jsonReader.skipValue();
                    return null;
                }
                return this.delegate().read(jsonReader);
            }

            @Override
            public void write(JsonWriter jsonWriter, T t) {
                if (bl) {
                    jsonWriter.nullValue();
                    return;
                }
                this.delegate().write(jsonWriter, t);
            }
        };
    }

    public final Excluder disableInnerClassSerialization() {
        Excluder excluder = this.clone();
        excluder.serializeInnerClasses = false;
        return excluder;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean excludeClass(Class<?> class_, boolean bl) {
        if (this.version != -1.0 && !this.isValidVersion((Since)class_.getAnnotation(Since.class), (Until)class_.getAnnotation(Until.class))) {
            return true;
        }
        if (!this.serializeInnerClasses && this.isInnerClass(class_)) {
            return true;
        }
        if (this.isAnonymousOrLocal(class_)) {
            return true;
        }
        List<ExclusionStrategy> list = bl ? this.serializationStrategies : this.deserializationStrategies;
        list = list.iterator();
        do {
            if (list.hasNext()) continue;
            return false;
        } while (!((ExclusionStrategy)list.next()).shouldSkipClass(class_));
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean excludeField(Field object, boolean bl) {
        List<ExclusionStrategy> list;
        if ((this.modifiers & object.getModifiers()) != 0) {
            return true;
        }
        if (this.version != -1.0 && !this.isValidVersion((Since)object.getAnnotation(Since.class), (Until)object.getAnnotation(Until.class))) {
            return true;
        }
        if (object.isSynthetic()) {
            return true;
        }
        if (this.requireExpose && ((list = (Expose)object.getAnnotation(Expose.class)) == null || (bl ? !list.serialize() : !list.deserialize()))) {
            return true;
        }
        if (!this.serializeInnerClasses && this.isInnerClass(object.getType())) {
            return true;
        }
        if (this.isAnonymousOrLocal(object.getType())) {
            return true;
        }
        list = bl ? this.serializationStrategies : this.deserializationStrategies;
        if (!list.isEmpty()) {
            object = new FieldAttributes((Field)object);
            list = list.iterator();
            while (list.hasNext()) {
                if (!((ExclusionStrategy)list.next()).shouldSkipField((FieldAttributes)object)) continue;
                return true;
            }
        }
        return false;
    }

    public final Excluder excludeFieldsWithoutExposeAnnotation() {
        Excluder excluder = this.clone();
        excluder.requireExpose = true;
        return excluder;
    }

    public final Excluder withExclusionStrategy(ExclusionStrategy exclusionStrategy, boolean bl, boolean bl2) {
        Excluder excluder = this.clone();
        if (bl) {
            excluder.serializationStrategies = new ArrayList<ExclusionStrategy>(this.serializationStrategies);
            excluder.serializationStrategies.add(exclusionStrategy);
        }
        if (bl2) {
            excluder.deserializationStrategies = new ArrayList<ExclusionStrategy>(this.deserializationStrategies);
            excluder.deserializationStrategies.add(exclusionStrategy);
        }
        return excluder;
    }

    public final /* varargs */ Excluder withModifiers(int ... arrn) {
        Excluder excluder = this.clone();
        excluder.modifiers = 0;
        int n2 = arrn.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            excluder.modifiers = arrn[i2] | excluder.modifiers;
        }
        return excluder;
    }

    public final Excluder withVersion(double d2) {
        Excluder excluder = this.clone();
        excluder.version = d2;
        return excluder;
    }

}

