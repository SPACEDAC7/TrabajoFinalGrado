/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson.internal;

import com.startapp.android.publish.gson.stream.JsonReader;

public abstract class JsonReaderInternalAccess {
    public static JsonReaderInternalAccess INSTANCE;

    public abstract void promoteNameToValue(JsonReader var1);
}

