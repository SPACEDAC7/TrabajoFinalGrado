/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson.internal;

import java.math.BigDecimal;

public final class LazilyParsedNumber
extends Number {
    private final String value;

    public LazilyParsedNumber(String string2) {
        this.value = string2;
    }

    private Object writeReplace() {
        return new BigDecimal(this.value);
    }

    @Override
    public final double doubleValue() {
        return Double.parseDouble(this.value);
    }

    @Override
    public final float floatValue() {
        return Float.parseFloat(this.value);
    }

    @Override
    public final int intValue() {
        try {
            int n2 = Integer.parseInt(this.value);
            return n2;
        }
        catch (NumberFormatException var4_2) {
            long l2;
            try {
                l2 = Long.parseLong(this.value);
            }
            catch (NumberFormatException var4_3) {
                return new BigDecimal(this.value).intValue();
            }
            return (int)l2;
        }
    }

    @Override
    public final long longValue() {
        try {
            long l2 = Long.parseLong(this.value);
            return l2;
        }
        catch (NumberFormatException var3_2) {
            return new BigDecimal(this.value).longValue();
        }
    }

    public final String toString() {
        return this.value;
    }
}

