/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson.internal;

import java.io.Serializable;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

public final class LinkedTreeMap<K, V>
extends AbstractMap<K, V>
implements Serializable {
    static final /* synthetic */ boolean $assertionsDisabled;
    private static final Comparator<Comparable> NATURAL_ORDER;
    Comparator<? super K> comparator;
    private LinkedTreeMap<K, V> entrySet;
    final Node<K, V> header = new Node();
    private LinkedTreeMap<K, V> keySet;
    int modCount = 0;
    Node<K, V> root;
    int size = 0;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !LinkedTreeMap.class.desiredAssertionStatus();
        $assertionsDisabled = bl;
        NATURAL_ORDER = new Comparator<Comparable>(){

            @Override
            public final int compare(Comparable comparable, Comparable comparable2) {
                return comparable.compareTo(comparable2);
            }
        };
    }

    public LinkedTreeMap() {
        this(NATURAL_ORDER);
    }

    /*
     * Enabled aggressive block sorting
     */
    public LinkedTreeMap(Comparator<? super K> comparator) {
        void var1_2;
        if (comparator == null) {
            Comparator<Comparable> comparator2 = NATURAL_ORDER;
        }
        this.comparator = var1_2;
    }

    private boolean equal(Object object, Object object2) {
        if (object == object2 || object != null && object.equals(object2)) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void rebalance(Node<K, V> node, boolean bl) {
        while (node != null) {
            Node node2;
            Node node3 = node.left;
            Node node4 = node.right;
            int n2 = node3 != null ? node3.height : 0;
            int n3 = node4 != null ? node4.height : 0;
            int n4 = n2 - n3;
            if (n4 == -2) {
                node3 = node4.left;
                node2 = node4.right;
                n2 = node2 != null ? node2.height : 0;
                n3 = node3 != null ? node3.height : 0;
                if ((n2 = n3 - n2) == -1 || n2 == 0 && !bl) {
                    this.rotateLeft(node);
                } else {
                    if (!$assertionsDisabled && n2 != 1) {
                        throw new AssertionError();
                    }
                    this.rotateRight(node4);
                    this.rotateLeft(node);
                }
                if (bl) return;
            } else if (n4 == 2) {
                node4 = node3.left;
                node2 = node3.right;
                n2 = node2 != null ? node2.height : 0;
                n3 = node4 != null ? node4.height : 0;
                if ((n2 = n3 - n2) == 1 || n2 == 0 && !bl) {
                    this.rotateRight(node);
                } else {
                    if (!$assertionsDisabled && n2 != -1) {
                        throw new AssertionError();
                    }
                    this.rotateLeft(node3);
                    this.rotateRight(node);
                }
                if (bl) {
                    return;
                }
            } else if (n4 == 0) {
                node.height = n2 + 1;
                if (bl) {
                    return;
                }
            } else {
                if (!$assertionsDisabled && n4 != -1 && n4 != 1) {
                    throw new AssertionError();
                }
                node.height = Math.max(n2, n3) + 1;
                if (!bl) return;
            }
            node = node.parent;
        }
    }

    private void replaceInParent(Node<K, V> node, Node<K, V> node2) {
        Node node3 = node.parent;
        node.parent = null;
        if (node2 != null) {
            node2.parent = node3;
        }
        if (node3 != null) {
            if (node3.left == node) {
                node3.left = node2;
                return;
            }
            if (!$assertionsDisabled && node3.right != node) {
                throw new AssertionError();
            }
            node3.right = node2;
            return;
        }
        this.root = node2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void rotateLeft(Node<K, V> node) {
        int n2 = 0;
        Node node2 = node.left;
        Node node3 = node.right;
        Node node4 = node3.left;
        Node node5 = node3.right;
        node.right = node4;
        if (node4 != null) {
            node4.parent = node;
        }
        this.replaceInParent(node, node3);
        node3.left = node;
        node.parent = node3;
        int n3 = node2 != null ? node2.height : 0;
        int n4 = node4 != null ? node4.height : 0;
        n4 = node.height = Math.max(n3, n4) + 1;
        n3 = n2;
        if (node5 != null) {
            n3 = node5.height;
        }
        node3.height = Math.max(n4, n3) + 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void rotateRight(Node<K, V> node) {
        Node node2;
        int n2 = 0;
        Node node3 = node.left;
        Node node4 = node.right;
        Node node5 = node3.left;
        node.left = node2 = node3.right;
        if (node2 != null) {
            node2.parent = node;
        }
        this.replaceInParent(node, node3);
        node3.right = node;
        node.parent = node3;
        int n3 = node4 != null ? node4.height : 0;
        int n4 = node2 != null ? node2.height : 0;
        n4 = node.height = Math.max(n3, n4) + 1;
        n3 = n2;
        if (node5 != null) {
            n3 = node5.height;
        }
        node3.height = Math.max(n4, n3) + 1;
    }

    private Object writeReplace() {
        return new LinkedHashMap(this);
    }

    @Override
    public final void clear() {
        Node<K, V> node;
        this.root = null;
        this.size = 0;
        ++this.modCount;
        node.prev = node = this.header;
        node.next = node;
    }

    @Override
    public final boolean containsKey(Object object) {
        if (this.findByObject(object) != null) {
            return true;
        }
        return false;
    }

    @Override
    public final Set<Map.Entry<K, V>> entrySet() {
        LinkedTreeMap<K, V> linkedTreeMap = this.entrySet;
        if (linkedTreeMap != null) {
            return linkedTreeMap;
        }
        this.entrySet = linkedTreeMap = new EntrySet();
        return linkedTreeMap;
    }

    /*
     * Enabled aggressive block sorting
     */
    final Node<K, V> find(K node, boolean bl) {
        int n2;
        Node<K, V> node2;
        Node<K, V> node3 = null;
        Comparator<K> comparator = this.comparator;
        Node<K, V> node4 = this.root;
        if (node4 == null) {
            n2 = 0;
        } else {
            Comparable comparable = comparator == NATURAL_ORDER ? (Comparable)((Object)node) : null;
            do {
                if ((n2 = comparable != null ? comparable.compareTo(node4.key) : comparator.compare(node, node4.key)) == 0) {
                    return node4;
                }
                node2 = n2 < 0 ? node4.left : node4.right;
                if (node2 == null) break;
                node4 = node2;
            } while (true);
        }
        node2 = node3;
        if (!bl) return node2;
        node2 = this.header;
        if (node4 == null) {
            if (comparator == NATURAL_ORDER && !(node instanceof Comparable)) {
                throw new ClassCastException(node.getClass().getName() + " is not Comparable");
            }
            this.root = node = new Node<Node<K, V>, V>(node4, node, node2, node2.prev);
        } else {
            node = new Node<Node<K, V>, V>(node4, node, node2, node2.prev);
            if (n2 < 0) {
                node4.left = node;
            } else {
                node4.right = node;
            }
            this.rebalance(node4, true);
        }
        ++this.size;
        ++this.modCount;
        return node;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    final Node<K, V> findByEntry(Map.Entry<?, ?> entry) {
        Node<K, V> node = this.findByObject(entry.getKey());
        if (node == null || !this.equal(node.value, entry.getValue())) return null;
        return node;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    final Node<K, V> findByObject(Object object) {
        Node<Object, V> node = null;
        if (object == null) return node;
        try {
            return this.find(object, false);
        }
        catch (ClassCastException classCastException) {
            return null;
        }
    }

    @Override
    public final V get(Object node) {
        if ((node = this.findByObject(node)) != null) {
            return node.value;
        }
        return null;
    }

    @Override
    public final Set<K> keySet() {
        LinkedTreeMap<K, V> linkedTreeMap = this.keySet;
        if (linkedTreeMap != null) {
            return linkedTreeMap;
        }
        this.keySet = linkedTreeMap = new KeySet();
        return linkedTreeMap;
    }

    @Override
    public final V put(K object, V v) {
        if (object == null) {
            throw new NullPointerException("key == null");
        }
        object = this.find(object, true);
        Object v2 = object.value;
        object.value = v;
        return v2;
    }

    @Override
    public final V remove(Object node) {
        if ((node = this.removeInternalByKey(node)) != null) {
            return node.value;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    final void removeInternal(Node<K, V> node, boolean bl) {
        int n2 = 0;
        if (bl) {
            node.prev.next = node.next;
            node.next.prev = node.prev;
        }
        Node node2 = node.left;
        Node node3 = node.right;
        Node node4 = node.parent;
        if (node2 != null && node3 != null) {
            int n3;
            node2 = node2.height > node3.height ? node2.last() : node3.first();
            this.removeInternal(node2, false);
            node3 = node.left;
            if (node3 != null) {
                n3 = node3.height;
                node2.left = node3;
                node3.parent = node2;
                node.left = null;
            } else {
                n3 = 0;
            }
            if ((node3 = node.right) != null) {
                n2 = node3.height;
                node2.right = node3;
                node3.parent = node2;
                node.right = null;
            }
            node2.height = Math.max(n3, n2) + 1;
            this.replaceInParent(node, node2);
            return;
        }
        if (node2 != null) {
            this.replaceInParent(node, node2);
            node.left = null;
        } else if (node3 != null) {
            this.replaceInParent(node, node3);
            node.right = null;
        } else {
            this.replaceInParent(node, null);
        }
        this.rebalance(node4, false);
        --this.size;
        ++this.modCount;
    }

    final Node<K, V> removeInternalByKey(Object node) {
        if ((node = this.findByObject(node)) != null) {
            this.removeInternal(node, true);
        }
        return node;
    }

    @Override
    public final int size() {
        return this.size;
    }

    class EntrySet
    extends AbstractSet<Map.Entry<K, V>> {
        EntrySet() {
        }

        @Override
        public void clear() {
            LinkedTreeMap.this.clear();
        }

        @Override
        public boolean contains(Object object) {
            if (object instanceof Map.Entry && LinkedTreeMap.this.findByEntry((Map.Entry)object) != null) {
                return true;
            }
            return false;
        }

        @Override
        public Iterator<Map.Entry<K, V>> iterator() {
            return new LinkedTreeMap<K, V>(){

                public Map.Entry<K, V> next() {
                    return this.nextNode();
                }
            };
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public boolean remove(Object node) {
            if (!(node instanceof Map.Entry) || (node = LinkedTreeMap.this.findByEntry(node)) == null) {
                return false;
            }
            LinkedTreeMap.this.removeInternal(node, true);
            return true;
        }

        @Override
        public int size() {
            return LinkedTreeMap.this.size;
        }

    }

    class KeySet
    extends AbstractSet<K> {
        KeySet() {
        }

        @Override
        public void clear() {
            LinkedTreeMap.this.clear();
        }

        @Override
        public boolean contains(Object object) {
            return LinkedTreeMap.this.containsKey(object);
        }

        @Override
        public Iterator<K> iterator() {
            return new LinkedTreeMap<K, V>(){

                public K next() {
                    return this.nextNode().key;
                }
            };
        }

        @Override
        public boolean remove(Object object) {
            if (LinkedTreeMap.this.removeInternalByKey(object) != null) {
                return true;
            }
            return false;
        }

        @Override
        public int size() {
            return LinkedTreeMap.this.size;
        }

    }

    abstract class LinkedTreeMapIterator<T>
    implements Iterator<T> {
        int expectedModCount;
        Node<K, V> lastReturned;
        Node<K, V> next;

        private LinkedTreeMapIterator() {
            this.next = LinkedTreeMap.this.header.next;
            this.lastReturned = null;
            this.expectedModCount = LinkedTreeMap.this.modCount;
        }

        @Override
        public final boolean hasNext() {
            if (this.next != LinkedTreeMap.this.header) {
                return true;
            }
            return false;
        }

        final Node<K, V> nextNode() {
            Node<K, V> node = this.next;
            if (node == LinkedTreeMap.this.header) {
                throw new NoSuchElementException();
            }
            if (LinkedTreeMap.this.modCount != this.expectedModCount) {
                throw new ConcurrentModificationException();
            }
            this.next = node.next;
            this.lastReturned = node;
            return node;
        }

        @Override
        public final void remove() {
            if (this.lastReturned == null) {
                throw new IllegalStateException();
            }
            LinkedTreeMap.this.removeInternal(this.lastReturned, true);
            this.lastReturned = null;
            this.expectedModCount = LinkedTreeMap.this.modCount;
        }
    }

    static final class Node<K, V>
    implements Map.Entry<K, V> {
        int height;
        final K key;
        Node<K, V> left;
        Node<K, V> next;
        Node<K, V> parent;
        Node<K, V> prev;
        Node<K, V> right;
        V value;

        Node() {
            this.key = null;
            this.prev = this;
            this.next = this;
        }

        Node(Node<K, V> node, K k2, Node<K, V> node2, Node<K, V> node3) {
            this.parent = node;
            this.key = k2;
            this.height = 1;
            this.next = node2;
            this.prev = node3;
            node3.next = this;
            node2.prev = this;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final boolean equals(Object object) {
            boolean bl;
            boolean bl2 = bl = false;
            if (!(object instanceof Map.Entry)) return bl2;
            object = (Map.Entry)object;
            if (this.key == null) {
                bl2 = bl;
                if (object.getKey() != null) return bl2;
            } else {
                bl2 = bl;
                if (!this.key.equals(object.getKey())) return bl2;
            }
            if (this.value == null) {
                bl2 = bl;
                if (object.getValue() != null) return bl2;
                return true;
            } else {
                bl2 = bl;
                if (!this.value.equals(object.getValue())) return bl2;
            }
            return true;
        }

        public final Node<K, V> first() {
            Node<K, V> node = this.left;
            Node<K, V> node2 = this;
            while (node != null) {
                Node<K, V> node3 = node.left;
                node2 = node;
                node = node3;
            }
            return node2;
        }

        @Override
        public final K getKey() {
            return this.key;
        }

        @Override
        public final V getValue() {
            return this.value;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final int hashCode() {
            int n2 = 0;
            int n3 = this.key == null ? 0 : this.key.hashCode();
            if (this.value == null) {
                return n3 ^ n2;
            }
            n2 = this.value.hashCode();
            return n3 ^ n2;
        }

        public final Node<K, V> last() {
            Node<K, V> node = this.right;
            Node<K, V> node2 = this;
            while (node != null) {
                Node<K, V> node3 = node.right;
                node2 = node;
                node = node3;
            }
            return node2;
        }

        @Override
        public final V setValue(V v) {
            V v2 = this.value;
            this.value = v;
            return v2;
        }

        public final String toString() {
            return this.key + "=" + this.value;
        }
    }

}

