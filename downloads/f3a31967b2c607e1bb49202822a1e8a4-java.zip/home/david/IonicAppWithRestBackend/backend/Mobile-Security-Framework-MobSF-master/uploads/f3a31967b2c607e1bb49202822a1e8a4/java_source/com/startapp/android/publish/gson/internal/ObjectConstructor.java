/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson.internal;

public interface ObjectConstructor<T> {
    public T construct();
}

