/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson.internal;

import com.startapp.android.publish.gson.JsonElement;
import com.startapp.android.publish.gson.JsonIOException;
import com.startapp.android.publish.gson.JsonNull;
import com.startapp.android.publish.gson.JsonSyntaxException;
import com.startapp.android.publish.gson.TypeAdapter;
import com.startapp.android.publish.gson.internal.bind.TypeAdapters;
import com.startapp.android.publish.gson.stream.JsonReader;
import com.startapp.android.publish.gson.stream.JsonToken;
import com.startapp.android.publish.gson.stream.JsonWriter;
import com.startapp.android.publish.gson.stream.MalformedJsonException;
import java.io.EOFException;
import java.io.IOException;
import java.io.Writer;

public final class Streams {
    public static JsonElement parse(JsonReader object) {
        boolean bl = true;
        object.peek();
        bl = false;
        try {
            object = TypeAdapters.JSON_ELEMENT.read((JsonReader)object);
            return object;
        }
        catch (EOFException var0_1) {
            if (bl) {
                return JsonNull.INSTANCE;
            }
            throw new JsonSyntaxException(var0_1);
        }
        catch (MalformedJsonException var0_2) {
            throw new JsonSyntaxException(var0_2);
        }
        catch (IOException var0_3) {
            throw new JsonIOException(var0_3);
        }
        catch (NumberFormatException var0_4) {
            throw new JsonSyntaxException(var0_4);
        }
    }

    public static void write(JsonElement jsonElement, JsonWriter jsonWriter) {
        TypeAdapters.JSON_ELEMENT.write(jsonWriter, jsonElement);
    }

    public static Writer writerForAppendable(Appendable appendable) {
        if (appendable instanceof Writer) {
            return (Writer)appendable;
        }
        return new AppendableWriter(appendable);
    }

    static final class AppendableWriter
    extends Writer {
        private final Appendable appendable;
        private final CurrentWrite currentWrite = new CurrentWrite();

        private AppendableWriter(Appendable appendable) {
            this.appendable = appendable;
        }

        @Override
        public final void close() {
        }

        @Override
        public final void flush() {
        }

        @Override
        public final void write(int n2) {
            this.appendable.append((char)n2);
        }

        @Override
        public final void write(char[] arrc, int n2, int n3) {
            this.currentWrite.chars = arrc;
            this.appendable.append(this.currentWrite, n2, n2 + n3);
        }

        static class CurrentWrite
        implements CharSequence {
            char[] chars;

            CurrentWrite() {
            }

            @Override
            public char charAt(int n2) {
                return this.chars[n2];
            }

            @Override
            public int length() {
                return this.chars.length;
            }

            @Override
            public CharSequence subSequence(int n2, int n3) {
                return new String(this.chars, n2, n3 - n2);
            }
        }

    }

}

