/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson.internal.bind;

import com.startapp.android.publish.gson.Gson;
import com.startapp.android.publish.gson.JsonElement;
import com.startapp.android.publish.gson.JsonPrimitive;
import com.startapp.android.publish.gson.JsonSyntaxException;
import com.startapp.android.publish.gson.TypeAdapter;
import com.startapp.android.publish.gson.TypeAdapterFactory;
import com.startapp.android.publish.gson.internal.$Gson$Types;
import com.startapp.android.publish.gson.internal.ConstructorConstructor;
import com.startapp.android.publish.gson.internal.JsonReaderInternalAccess;
import com.startapp.android.publish.gson.internal.ObjectConstructor;
import com.startapp.android.publish.gson.internal.bind.TypeAdapterRuntimeTypeWrapper;
import com.startapp.android.publish.gson.internal.bind.TypeAdapters;
import com.startapp.android.publish.gson.reflect.TypeToken;
import com.startapp.android.publish.gson.stream.JsonReader;
import com.startapp.android.publish.gson.stream.JsonToken;
import com.startapp.android.publish.gson.stream.JsonWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class MapTypeAdapterFactory
implements TypeAdapterFactory {
    private final boolean complexMapKeySerialization;
    private final ConstructorConstructor constructorConstructor;

    public MapTypeAdapterFactory(ConstructorConstructor constructorConstructor, boolean bl) {
        this.constructorConstructor = constructorConstructor;
        this.complexMapKeySerialization = bl;
    }

    private TypeAdapter<?> getKeyAdapter(Gson gson, Type type) {
        if (type == Boolean.TYPE || type == Boolean.class) {
            return TypeAdapters.BOOLEAN_AS_STRING;
        }
        return gson.getAdapter(TypeToken.get(type));
    }

    @Override
    public final <T> TypeAdapter<T> create(Gson gson, TypeToken<T> object) {
        Type[] arrtype = object.getType();
        if (!Map.class.isAssignableFrom(object.getRawType())) {
            return null;
        }
        arrtype = $Gson$Types.getMapKeyAndValueTypes((Type)arrtype, $Gson$Types.getRawType((Type)arrtype));
        TypeAdapter typeAdapter = this.getKeyAdapter(gson, arrtype[0]);
        TypeAdapter typeAdapter2 = gson.getAdapter(TypeToken.get(arrtype[1]));
        object = this.constructorConstructor.get(object);
        return new Adapter(gson, arrtype[0], typeAdapter, arrtype[1], typeAdapter2, object);
    }

    final class Adapter<K, V>
    extends TypeAdapter<Map<K, V>> {
        private final ObjectConstructor<? extends Map<K, V>> constructor;
        private final TypeAdapter<K> keyTypeAdapter;
        private final TypeAdapter<V> valueTypeAdapter;

        public Adapter(Gson gson, Type type, TypeAdapter<K> typeAdapter, Type type2, TypeAdapter<V> typeAdapter2, ObjectConstructor<? extends Map<K, V>> objectConstructor) {
            this.keyTypeAdapter = new TypeAdapterRuntimeTypeWrapper<K>(gson, typeAdapter, type);
            this.valueTypeAdapter = new TypeAdapterRuntimeTypeWrapper<V>(gson, typeAdapter2, type2);
            this.constructor = objectConstructor;
        }

        private String keyToString(JsonElement jsonElement) {
            if (jsonElement.isJsonPrimitive()) {
                if ((jsonElement = jsonElement.getAsJsonPrimitive()).isNumber()) {
                    return String.valueOf(jsonElement.getAsNumber());
                }
                if (jsonElement.isBoolean()) {
                    return Boolean.toString(jsonElement.getAsBoolean());
                }
                if (jsonElement.isString()) {
                    return jsonElement.getAsString();
                }
                throw new AssertionError();
            }
            if (jsonElement.isJsonNull()) {
                return "null";
            }
            throw new AssertionError();
        }

        @Override
        public final Map<K, V> read(JsonReader jsonReader) {
            JsonToken jsonToken = jsonReader.peek();
            if (jsonToken == JsonToken.NULL) {
                jsonReader.nextNull();
                return null;
            }
            Map<JsonToken, V> map = this.constructor.construct();
            if (jsonToken == JsonToken.BEGIN_ARRAY) {
                jsonReader.beginArray();
                while (jsonReader.hasNext()) {
                    jsonReader.beginArray();
                    jsonToken = this.keyTypeAdapter.read(jsonReader);
                    if (map.put(jsonToken, this.valueTypeAdapter.read(jsonReader)) != null) {
                        throw new JsonSyntaxException("duplicate key: " + (Object)((Object)jsonToken));
                    }
                    jsonReader.endArray();
                }
                jsonReader.endArray();
                return map;
            }
            jsonReader.beginObject();
            while (jsonReader.hasNext()) {
                JsonReaderInternalAccess.INSTANCE.promoteNameToValue(jsonReader);
                jsonToken = this.keyTypeAdapter.read(jsonReader);
                if (map.put(jsonToken, this.valueTypeAdapter.read(jsonReader)) == null) continue;
                throw new JsonSyntaxException("duplicate key: " + (Object)((Object)jsonToken));
            }
            jsonReader.endObject();
            return map;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public final void write(JsonWriter jsonWriter, Map<K, V> iterator) {
            int n2 = 0;
            int n3 = 0;
            if (iterator == null) {
                jsonWriter.nullValue();
                return;
            }
            if (!MapTypeAdapterFactory.this.complexMapKeySerialization) {
                jsonWriter.beginObject();
                iterator = iterator.entrySet().iterator();
                do {
                    if (!iterator.hasNext()) {
                        jsonWriter.endObject();
                        return;
                    }
                    Map.Entry entry = iterator.next();
                    jsonWriter.name(String.valueOf(entry.getKey()));
                    this.valueTypeAdapter.write(jsonWriter, entry.getValue());
                } while (true);
            }
            ArrayList<JsonElement> arrayList = new ArrayList<JsonElement>(iterator.size());
            ArrayList arrayList2 = new ArrayList(iterator.size());
            iterator = iterator.entrySet().iterator();
            int n4 = 0;
            while (iterator.hasNext()) {
                Map.Entry entry = iterator.next();
                JsonElement jsonElement = this.keyTypeAdapter.toJsonTree(entry.getKey());
                arrayList.add(jsonElement);
                arrayList2.add(entry.getValue());
                int n5 = jsonElement.isJsonArray() || jsonElement.isJsonObject() ? 1 : 0;
                n4 = n5 | n4;
            }
            jsonWriter.beginObject();
            n4 = n2;
            do {
                if (n4 >= arrayList.size()) {
                    jsonWriter.endObject();
                    return;
                }
                jsonWriter.name(this.keyToString((JsonElement)arrayList.get(n4)));
                this.valueTypeAdapter.write(jsonWriter, arrayList2.get(n4));
                ++n4;
            } while (true);
        }
    }

}

