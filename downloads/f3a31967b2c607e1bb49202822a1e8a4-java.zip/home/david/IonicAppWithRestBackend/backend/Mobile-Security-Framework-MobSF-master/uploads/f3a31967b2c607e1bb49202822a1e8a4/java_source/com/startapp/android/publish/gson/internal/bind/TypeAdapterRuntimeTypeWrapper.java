/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.gson.internal.bind;

import com.startapp.android.publish.gson.Gson;
import com.startapp.android.publish.gson.TypeAdapter;
import com.startapp.android.publish.gson.internal.bind.ReflectiveTypeAdapterFactory;
import com.startapp.android.publish.gson.reflect.TypeToken;
import com.startapp.android.publish.gson.stream.JsonReader;
import com.startapp.android.publish.gson.stream.JsonWriter;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

final class TypeAdapterRuntimeTypeWrapper<T>
extends TypeAdapter<T> {
    private final Gson context;
    private final TypeAdapter<T> delegate;
    private final Type type;

    TypeAdapterRuntimeTypeWrapper(Gson gson, TypeAdapter<T> typeAdapter, Type type) {
        this.context = gson;
        this.delegate = typeAdapter;
        this.type = type;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Type getRuntimeTypeIfMoreSpecific(Type class_, Object object) {
        Class class_2 = class_;
        if (object == null) return class_2;
        if (class_ == Object.class) return object.getClass();
        if (class_ instanceof TypeVariable) return object.getClass();
        class_2 = class_;
        if (!(class_ instanceof Class)) return class_2;
        return object.getClass();
    }

    @Override
    public final T read(JsonReader jsonReader) {
        return this.delegate.read(jsonReader);
    }

    @Override
    public final void write(JsonWriter jsonWriter, T t) {
        Object object = this.delegate;
        Object object2 = this.getRuntimeTypeIfMoreSpecific(this.type, t);
        if (object2 != this.type) {
            object = object2 = this.context.getAdapter(TypeToken.get((Type)object2));
            if (object2 instanceof ReflectiveTypeAdapterFactory.Adapter) {
                object = object2;
                if (!(this.delegate instanceof ReflectiveTypeAdapterFactory.Adapter)) {
                    object = this.delegate;
                }
            }
        }
        object.write(jsonWriter, t);
    }
}

