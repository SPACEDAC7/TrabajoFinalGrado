/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.view.animation.AnimationUtils
 */
package com.startapp.android.publish.list3d;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.animation.AnimationUtils;

public abstract class Dynamics
implements Parcelable {
    protected float a;
    protected float b;
    protected float c = Float.MAX_VALUE;
    protected float d = -3.4028235E38f;
    protected long e = 0;

    public Dynamics() {
    }

    public Dynamics(Parcel parcel) {
        this.a = parcel.readFloat();
        this.b = parcel.readFloat();
        this.c = parcel.readFloat();
        this.d = parcel.readFloat();
        this.e = AnimationUtils.currentAnimationTimeMillis();
    }

    public float a() {
        return this.a;
    }

    public void a(double d2) {
        this.a = (float)((double)this.a * d2);
    }

    public void a(float f2) {
        this.c = f2;
    }

    public void a(float f2, float f3, long l2) {
        this.b = f3;
        this.a = f2;
        this.e = l2;
    }

    protected abstract void a(int var1);

    /*
     * Enabled aggressive block sorting
     */
    public void a(long l2) {
        int n2 = 50;
        if (this.e != 0) {
            int n3 = (int)(l2 - this.e);
            if (n3 <= 50) {
                n2 = n3;
            }
            this.a(n2);
        }
        this.e = l2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean a(float f2, float f3) {
        boolean bl = Math.abs(this.b) < f2;
        if (this.a - f3 >= this.c) return false;
        boolean bl2 = this.a + f3 > this.d;
        if (!bl) return false;
        if (bl2) {
            return true;
        }
        return false;
    }

    public float b() {
        return this.b;
    }

    public void b(float f2) {
        this.d = f2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected float c() {
        float f2 = 0.0f;
        if (this.a > this.c) {
            return this.c - this.a;
        }
        if (this.a >= this.d) return f2;
        return this.d - this.a;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "Position: [" + this.a + "], Velocity:[" + this.b + "], MaxPos: [" + this.c + "], mMinPos: [" + this.d + "] LastTime:[" + this.e + "]";
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeFloat(this.a);
        parcel.writeFloat(this.b);
        parcel.writeFloat(this.c);
        parcel.writeFloat(this.d);
    }
}

