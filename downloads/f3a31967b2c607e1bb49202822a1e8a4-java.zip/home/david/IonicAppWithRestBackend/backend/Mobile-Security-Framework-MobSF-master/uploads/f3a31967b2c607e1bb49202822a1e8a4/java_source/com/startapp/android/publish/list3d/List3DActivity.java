/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.GradientDrawable
 *  android.graphics.drawable.GradientDrawable$Orientation
 *  android.os.Bundle
 *  android.os.Handler
 *  android.text.TextUtils
 *  android.text.TextUtils$TruncateAt
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.Window
 *  android.webkit.WebView
 *  android.widget.Adapter
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.ImageButton
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 */
package com.startapp.android.publish.list3d;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebView;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.startapp.android.publish.adinformation.a;
import com.startapp.android.publish.g.q;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.list3d.Dynamics;
import com.startapp.android.publish.list3d.ListItem;
import com.startapp.android.publish.list3d.SimpleDynamics;
import com.startapp.android.publish.list3d.b;
import com.startapp.android.publish.list3d.c;
import com.startapp.android.publish.list3d.d;
import com.startapp.android.publish.list3d.e;
import com.startapp.android.publish.list3d.f;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;
import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class List3DActivity
extends Activity
implements f {
    private c a;
    private ProgressDialog b = null;
    private WebView c = null;
    private List<ListItem> d;
    private int e;
    private BroadcastReceiver f;

    public List3DActivity() {
        this.f = new BroadcastReceiver(){

            public void onReceive(Context context, Intent intent) {
                List3DActivity.this.finish();
            }
        };
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public void a(int n2) {
        int n3 = this.a.getFirstItemPosition();
        Object object = this.a.getChildAt(n2 - n3);
        if (object == null) {
            return;
        }
        object = (d)object.getTag();
        if (e.a == null) return;
        if (e.a.b() == null) return;
        if (n2 >= e.a.b().size()) return;
        ListItem listItem = e.a.b().get(n2);
        Bitmap bitmap = e.a.a(n2, listItem.a(), listItem.g());
        object.b().setImageBitmap(bitmap);
        object.b().requestLayout();
        object.a(listItem.n());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void finish() {
        synchronized (this) {
            if (this.f != null) {
                this.unregisterReceiver(this.f);
                this.f = null;
            }
        }
        super.finish();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onCreate(Bundle object) {
        super.onCreate((Bundle)object);
        if (this.getIntent().getBooleanExtra("fullscreen", false)) {
            this.requestWindowFeature(1);
            this.getWindow().setFlags(1024, 1024);
        }
        this.registerReceiver(this.f, new IntentFilter("com.startapp.android.CloseAdActivity"));
        this.e = this.getResources().getConfiguration().orientation;
        r.a(this, true);
        boolean bl = this.getIntent().getBooleanExtra("overlay", false);
        this.requestWindowFeature(1);
        int n2 = MetaData.getInstance().getBackgroundGradientTop();
        int n3 = MetaData.getInstance().getBackgroundGradientBottom();
        this.a = new c((Context)this, null);
        object = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{n2, n3});
        this.a.setBackgroundDrawable((Drawable)object);
        this.d = e.a.b();
        if (this.d == null) {
            this.finish();
            return;
        }
        object = "";
        if (bl) {
            this.registerReceiver(this.a.a, new IntentFilter("com.startapp.android.Activity3DGetValues"));
        } else {
            this.a.a();
            this.a.setHint(true);
            this.a.setFade(true);
            object = "back";
        }
        object = new b((Context)this, this.d, (String)object);
        e e2 = e.a;
        bl = !bl;
        e2.a(this, bl);
        this.a.setAdapter((Adapter)object);
        this.a.setDynamics(new SimpleDynamics(0.9f, 0.6f));
        this.a.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            private void a(String string2, String string3, String string4, String string5) {
                r.a(string2, string3, string4, (Context)List3DActivity.this);
                List3DActivity.this.finish();
            }

            /*
             * Enabled aggressive block sorting
             */
            public void onItemClick(AdapterView<?> object, View object2, int n2, long l2) {
                object = ((ListItem)List3DActivity.this.d.get(n2)).b();
                object2 = ((ListItem)List3DActivity.this.d.get(n2)).d();
                boolean bl = ((ListItem)List3DActivity.this.d.get(n2)).j();
                String string2 = ((ListItem)List3DActivity.this.d.get(n2)).m();
                String string3 = ((ListItem)List3DActivity.this.d.get(n2)).l();
                if (string2 != null && !TextUtils.isEmpty((CharSequence)string2)) {
                    this.a(string2, string3, (String)object, (String)object2);
                    return;
                }
                if (TextUtils.isEmpty((CharSequence)object)) return;
                {
                    if (!bl) {
                        r.a((Context)List3DActivity.this, (String)object, (String)object2);
                        List3DActivity.this.finish();
                        return;
                    }
                }
                r.a((Context)List3DActivity.this, (String)object, (String)object2, 5000);
            }
        });
        e2 = new RelativeLayout((Context)this);
        e2.setContentDescription((CharSequence)"StartApp Ad");
        e2.setId(1475346432);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        object = new RelativeLayout.LayoutParams(-1, -1);
        LinearLayout linearLayout = new LinearLayout((Context)this);
        linearLayout.setOrientation(1);
        e2.addView((View)linearLayout, (ViewGroup.LayoutParams)object);
        RelativeLayout relativeLayout = new RelativeLayout((Context)this);
        relativeLayout.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -2));
        relativeLayout.setBackgroundColor(MetaData.getInstance().getTitleBackgroundColor().intValue());
        linearLayout.addView((View)relativeLayout);
        object = new TextView((Context)this);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(13);
        object.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
        object.setPadding(0, q.a((Context)this, 2), 0, q.a((Context)this, 5));
        object.setTextColor(MetaData.getInstance().getTitleTextColor().intValue());
        object.setTextSize((float)MetaData.getInstance().getTitleTextSize().intValue());
        object.setSingleLine(true);
        object.setEllipsize(TextUtils.TruncateAt.END);
        object.setText((CharSequence)MetaData.getInstance().getTitleContent());
        object.setShadowLayer(2.5f, -2.0f, 2.0f, -11513776);
        q.a((TextView)object, MetaData.getInstance().getTitleTextDecoration());
        relativeLayout.addView((View)object);
        layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(11);
        layoutParams2.addRule(15);
        Bitmap bitmap = com.startapp.android.publish.g.e.a((Context)this, "close_button.png");
        if (bitmap != null) {
            object = new ImageButton((Context)this, null, 16973839);
            ((ImageButton)object).setImageBitmap(Bitmap.createScaledBitmap((Bitmap)bitmap, (int)q.a((Context)this, 36), (int)q.a((Context)this, 36), (boolean)true));
        } else {
            object = new TextView((Context)this);
            ((TextView)object).setText((CharSequence)"   x   ");
            ((TextView)object).setTextSize(20.0f);
        }
        object.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
        object.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                List3DActivity.this.finish();
            }
        });
        object.setContentDescription((CharSequence)"x");
        object.setId(1475346435);
        relativeLayout.addView((View)object);
        object = new View((Context)this);
        object.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, q.a((Context)this, 2)));
        object.setBackgroundColor(MetaData.getInstance().getTitleLineColor().intValue());
        linearLayout.addView((View)object);
        object = new LinearLayout.LayoutParams(-1, 0);
        object.weight = 1.0f;
        this.a.setLayoutParams((ViewGroup.LayoutParams)object);
        linearLayout.addView((View)this.a);
        object = new LinearLayout((Context)this);
        relativeLayout = new LinearLayout.LayoutParams(-1, -2);
        relativeLayout.gravity = 80;
        object.setLayoutParams((ViewGroup.LayoutParams)relativeLayout);
        object.setBackgroundColor(MetaData.getInstance().getPoweredByBackgroundColor().intValue());
        object.setGravity(17);
        linearLayout.addView((View)object);
        linearLayout = new TextView((Context)this);
        linearLayout.setTextColor(MetaData.getInstance().getPoweredByTextColor().intValue());
        linearLayout.setPadding(0, q.a((Context)this, 2), 0, q.a((Context)this, 5));
        linearLayout.setText((CharSequence)"Powered By ");
        linearLayout.setTextSize(16.0f);
        object.addView((View)linearLayout);
        linearLayout = new ImageView((Context)this);
        linearLayout.setImageBitmap(com.startapp.android.publish.g.e.a((Context)this, "logo.png"));
        object.addView((View)linearLayout);
        object = (com.startapp.android.publish.adinformation.b)this.getIntent().getSerializableExtra("adInfoOverride");
        new a((Context)this, a.b.b, AdPreferences.Placement.INAPP_OFFER_WALL, (com.startapp.android.publish.adinformation.b)object).a((RelativeLayout)e2);
        this.setContentView((View)e2, (ViewGroup.LayoutParams)layoutParams);
        new Handler().postDelayed(new Runnable(){

            @Override
            public void run() {
                Intent intent = new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS");
                List3DActivity.this.sendBroadcast(intent);
            }
        }, 500);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onDestroy() {
        if (this.b != null) {
            ProgressDialog progressDialog = this.b;
            synchronized (progressDialog) {
                if (this.b != null) {
                    this.b.dismiss();
                    this.b = null;
                }
            }
        }
        if (this.c != null) {
            this.c.stopLoading();
        }
        e.a.a(null, true);
        r.a(this, false);
        super.onDestroy();
    }

    protected void onPause() {
        super.onPause();
        if (this.e == this.getResources().getConfiguration().orientation) {
            this.sendBroadcast(new Intent("com.startapp.android.HideDisplayBroadcastListener"));
        }
        this.finish();
    }

}

