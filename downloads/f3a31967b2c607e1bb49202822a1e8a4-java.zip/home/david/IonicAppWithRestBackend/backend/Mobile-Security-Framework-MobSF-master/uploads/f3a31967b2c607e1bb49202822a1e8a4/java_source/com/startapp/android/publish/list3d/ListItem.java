/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.startapp.android.publish.list3d;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import com.startapp.android.publish.model.AdDetails;

public class ListItem
implements Parcelable {
    public static final Parcelable.Creator<ListItem> CREATOR = new Parcelable.Creator<ListItem>(){

        public final ListItem a(Parcel parcel) {
            return new ListItem(parcel);
        }

        public final ListItem[] a(int n2) {
            return new ListItem[n2];
        }

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return this.a(parcel);
        }

        public final /* synthetic */ Object[] newArray(int n2) {
            return this.a(n2);
        }
    };
    private String a = "";
    private String b = "";
    private String c = "";
    private String d = "";
    private String e = "";
    private String f = "";
    private String g = "";
    private float h = 0.0f;
    private boolean i = false;
    private Drawable j = null;
    private String k;
    private String l;
    private String m = "";

    /*
     * Enabled aggressive block sorting
     */
    public ListItem(Parcel parcel) {
        this.j = parcel.readInt() == 1 ? new BitmapDrawable((Bitmap)Bitmap.CREATOR.createFromParcel(parcel)) : null;
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
        this.d = parcel.readString();
        this.e = parcel.readString();
        this.f = parcel.readString();
        this.g = parcel.readString();
        this.h = parcel.readFloat();
        this.i = parcel.readInt() == 1;
        this.m = parcel.readString();
        this.l = parcel.readString();
        this.k = parcel.readString();
    }

    public ListItem(AdDetails adDetails) {
        this.a = adDetails.getAdId();
        this.b = adDetails.getClickUrl();
        this.c = adDetails.getTrackingUrl();
        this.d = adDetails.getTrackingClickUrl();
        this.e = adDetails.getTitle();
        this.f = adDetails.getDescription();
        this.g = adDetails.getImageUrl();
        this.h = adDetails.getRating();
        this.i = adDetails.isSmartRedirect();
        this.j = null;
        this.m = adDetails.getTemplate();
        this.k = adDetails.getIntentDetails();
        this.l = adDetails.getIntentPackageName();
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public String c() {
        return this.c;
    }

    public String d() {
        return this.d;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        return this.e;
    }

    public String f() {
        return this.f;
    }

    public String g() {
        return this.g;
    }

    public Drawable h() {
        return this.j;
    }

    public float i() {
        return this.h;
    }

    public boolean j() {
        return this.i;
    }

    public String k() {
        return this.m;
    }

    public String l() {
        return this.k;
    }

    public String m() {
        return this.l;
    }

    public boolean n() {
        if (this.l != null) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void writeToParcel(Parcel parcel, int n2) {
        if (this.h() != null) {
            parcel.writeParcelable((Parcelable)((BitmapDrawable)this.h()).getBitmap(), n2);
            parcel.writeInt(1);
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeString(this.f);
        parcel.writeString(this.g);
        parcel.writeFloat(this.h);
        n2 = this.i ? 1 : 0;
        parcel.writeInt(n2);
        parcel.writeString(this.m);
        parcel.writeString(this.l);
        parcel.writeString(this.k);
    }

}

