/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.os.AsyncTask
 */
package com.startapp.android.publish.list3d;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import com.startapp.android.publish.g.g;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.list3d.f;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

public class a {
    HashSet<String> a = new HashSet();
    Hashtable<String, Bitmap> b = new Hashtable();
    Set<String> c = new HashSet<String>();
    f d;
    int e = 0;
    ConcurrentLinkedQueue<b> f = new ConcurrentLinkedQueue();

    /*
     * Enabled aggressive block sorting
     */
    public Bitmap a(int n2, String string2, String string3) {
        Bitmap bitmap = this.b.get(string2);
        if (bitmap != null) {
            return bitmap;
        }
        if (this.c.contains(string2)) return null;
        this.c.add(string2);
        if (this.e >= 15) {
            this.f.add(new b(n2, string2, string3));
            return null;
        }
        ++this.e;
        new a(n2, string2, string3).execute((Object[])new Void[0]);
        return null;
    }

    public void a() {
        this.c.clear();
        this.e = 0;
        this.f.clear();
        this.a.clear();
    }

    public void a(Context context, String string2, String string3) {
        if (this.a.contains(string3)) {
            return;
        }
        this.a.add(string3);
        r.b(context, string3);
    }

    public void a(f f2, boolean bl) {
        this.d = f2;
        if (bl) {
            this.a();
        }
    }

    public void b() {
        if (!this.f.isEmpty()) {
            b b2 = this.f.poll();
            new a(b2.a, b2.b, b2.c).execute((Object[])new Void[0]);
        }
    }

    class a
    extends AsyncTask<Void, Void, Bitmap> {
        int a;
        String b;
        String c;

        public a(int n2, String string2, String string3) {
            this.a = -1;
            this.a = n2;
            this.b = string2;
            this.c = string3;
        }

        protected /* varargs */ Bitmap a(Void ... arrvoid) {
            return g.a(this.c);
        }

        protected void a(Bitmap bitmap) {
            a a2 = a.this;
            --a2.e;
            if (bitmap != null) {
                a.this.b.put(this.b, bitmap);
                if (a.this.d != null) {
                    a.this.d.a(this.a);
                }
                a.this.b();
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] arrobject) {
            return this.a((Void[])arrobject);
        }

        protected /* synthetic */ void onPostExecute(Object object) {
            this.a((Bitmap)object);
        }
    }

    class b {
        int a;
        String b;
        String c;

        public b(int n2, String string2, String string3) {
            this.a = n2;
            this.b = string2;
            this.c = string3;
        }
    }

}

