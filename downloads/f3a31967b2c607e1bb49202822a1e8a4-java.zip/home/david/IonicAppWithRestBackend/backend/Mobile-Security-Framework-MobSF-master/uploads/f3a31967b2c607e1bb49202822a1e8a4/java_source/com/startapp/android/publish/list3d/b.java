/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ArrayAdapter
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.startapp.android.publish.list3d;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.startapp.android.publish.g.m;
import com.startapp.android.publish.list3d.ListItem;
import com.startapp.android.publish.list3d.d;
import com.startapp.android.publish.list3d.e;
import com.startapp.android.publish.model.MetaData;
import com.startapp.android.publish.model.MetaDataStyle;
import java.util.List;

public class b
extends ArrayAdapter<ListItem> {
    public b(Context context, List<ListItem> list, String string2) {
        super(context, 0, list);
    }

    /*
     * Enabled aggressive block sorting
     */
    public View getView(int n2, View view, ViewGroup object) {
        if (view == null) {
            object = new d(this.getContext());
            view = object.a();
        } else {
            object = (d)view.getTag();
        }
        ListItem listItem = (ListItem)this.getItem(n2);
        object.a(MetaData.getInstance().getTemplate(listItem.k()));
        object.c().setText((CharSequence)listItem.e());
        object.d().setText((CharSequence)listItem.f());
        Bitmap bitmap = e.a.a(n2, listItem.a(), listItem.g());
        if (bitmap == null) {
            object.b().setImageResource(17301651);
        } else {
            object.b().setImageBitmap(bitmap);
        }
        object.e().setRating(listItem.i());
        object.a(listItem.n());
        e.a.a(this.getContext(), listItem.a(), listItem.c());
        return view;
    }
}

