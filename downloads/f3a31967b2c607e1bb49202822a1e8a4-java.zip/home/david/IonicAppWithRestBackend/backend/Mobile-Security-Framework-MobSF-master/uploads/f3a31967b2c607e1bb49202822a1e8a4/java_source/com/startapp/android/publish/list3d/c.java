/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Bitmap
 *  android.graphics.Camera
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.ColorFilter
 *  android.graphics.LightingColorFilter
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.os.Parcelable
 *  android.util.AttributeSet
 *  android.view.KeyEvent
 *  android.view.MotionEvent
 *  android.view.VelocityTracker
 *  android.view.View
 *  android.view.ViewConfiguration
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.animation.AnimationUtils
 *  android.widget.Adapter
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemLongClickListener
 */
package com.startapp.android.publish.list3d;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Camera;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LightingColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Adapter;
import android.widget.AdapterView;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.list3d.Dynamics;
import com.startapp.android.publish.list3d.ListItem;
import com.startapp.android.publish.list3d.b;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class c
extends AdapterView<Adapter> {
    private boolean A = false;
    private boolean B = false;
    public BroadcastReceiver a;
    private String b = "List3DView";
    private Adapter c;
    private int d = 0;
    private int e;
    private int f;
    private int g;
    private int h;
    private int i;
    private int j;
    private int k;
    private int l;
    private VelocityTracker m;
    private Dynamics n;
    private Runnable o;
    private final LinkedList<View> p = new LinkedList();
    private Runnable q;
    private Rect r;
    private Camera s;
    private Matrix t;
    private Paint u;
    private int v = Integer.MIN_VALUE;
    private float w = 0.0f;
    private boolean x = false;
    private boolean y = false;
    private boolean z = false;

    public c(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = new BroadcastReceiver(){

            public void onReceive(Context context, Intent object) {
                int n2 = object.getIntExtra("getHeight", c.this.getHeight());
                double d2 = (double)c.this.getHeight() / (double)n2;
                j.a(3, c.this.b + "Updating Position with Ratio: [" + d2 + "]");
                c.this.d = object.getIntExtra("mTouchState", c.this.d);
                c.this.e = object.getIntExtra("mTouchStartX", c.this.e);
                c.this.f = object.getIntExtra("mTouchStartY", c.this.f);
                c.this.j = object.getIntExtra("mListRotation", c.this.j);
                c.this.k = (int)((double)object.getIntExtra("mFirstItemPosition", c.this.k) * d2);
                c.g(c.this);
                c.this.l = (int)((double)object.getIntExtra("mLastItemPosition", c.this.l) * d2);
                c.i(c.this);
                c.this.h = (int)((double)object.getIntExtra("mListTop", c.this.h) * d2);
                c.this.g = (int)((double)object.getIntExtra("mListTopStart", c.this.g) * d2);
                c.this.i = (int)((double)object.getIntExtra("mListTopOffset", c.this.i) * d2);
                c.this.n = (Dynamics)object.getParcelableExtra("mDynamics");
                c.this.w = object.getFloatExtra("mLastVelocity", c.this.w);
                c.this.n.a(d2);
                object = object.getParcelableArrayListExtra("list");
                object = new b(c.this.getContext(), (List<ListItem>)object, "home");
                c.this.setAdapter((Adapter)object);
                c.this.x = true;
                c.this.y = true;
                c.this.a(c.this.w, true);
                context.unregisterReceiver((BroadcastReceiver)this);
            }
        };
    }

    private int a(int n2, int n3) {
        if (this.r == null) {
            this.r = new Rect();
        }
        for (int i2 = 0; i2 < this.getChildCount(); ++i2) {
            this.getChildAt(i2).getHitRect(this.r);
            if (!this.r.contains(n2, n3)) continue;
            return i2;
        }
        return -1;
    }

    private int a(View view) {
        return (int)((float)view.getMeasuredHeight() * 0.35000002f / 2.0f);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private LightingColorFilter a(float f2) {
        int n2 = 255;
        double d2 = Math.cos(3.141592653589793 * (double)f2 / 180.0);
        int n3 = (int)(d2 * 200.0) + 55;
        int n4 = (int)(Math.pow(d2, 200.0) * 70.0);
        int n5 = n3;
        if (n3 > 255) {
            n5 = 255;
        }
        if (n4 > 255) {
            do {
                return new LightingColorFilter(Color.rgb((int)n5, (int)n5, (int)n5), Color.rgb((int)n2, (int)n2, (int)n2));
                break;
            } while (true);
        }
        n2 = n4;
        return new LightingColorFilter(Color.rgb((int)n5, (int)n5, (int)n5), Color.rgb((int)n2, (int)n2, (int)n2));
    }

    private void a(float f2, boolean bl) {
        if (this.m == null && !bl) {
            return;
        }
        if (this.m != null) {
            this.m.recycle();
        }
        this.m = null;
        this.removeCallbacks(this.q);
        if (this.o == null) {
            this.o = new Runnable(){

                /*
                 * Enabled aggressive block sorting
                 * Lifted jumps to return sites
                 */
                @Override
                public void run() {
                    if (c.this.n == null) {
                        return;
                    }
                    View view = c.this.getChildAt(0);
                    if (view != null) {
                        c.this.g = c.this.b(view) - c.this.i;
                        c.this.n.a(AnimationUtils.currentAnimationTimeMillis());
                        c.this.a((int)c.this.n.a() - c.this.g);
                    }
                    if (c.this.n.a(0.5f, 0.4f)) return;
                    c.this.postDelayed((Runnable)this, 16);
                }
            };
        }
        if (this.n != null) {
            if (!bl) {
                this.n.a(this.h, f2, AnimationUtils.currentAnimationTimeMillis());
            }
            this.post(this.o);
        }
        this.d = 0;
    }

    private void a(int n2) {
        this.h = this.g + n2;
        this.j = (- this.h * 270) / this.getHeight();
        this.f();
        this.requestLayout();
    }

    private void a(Canvas canvas, Bitmap bitmap, int n2, int n3, int n4, int n5, float f2, float f3) {
        if (this.s == null) {
            this.s = new Camera();
        }
        this.s.save();
        this.s.translate(0.0f, 0.0f, (float)n5);
        this.s.rotateX(f3);
        this.s.translate(0.0f, 0.0f, (float)(- n5));
        if (this.t == null) {
            this.t = new Matrix();
        }
        this.s.getMatrix(this.t);
        this.s.restore();
        this.t.preTranslate((float)(- n4), (float)(- n5));
        this.t.postScale(f2, f2);
        this.t.postTranslate((float)(n3 + n4), (float)(n2 + n5));
        if (this.u == null) {
            this.u = new Paint();
            this.u.setAntiAlias(true);
            this.u.setFilterBitmap(true);
        }
        this.u.setColorFilter((ColorFilter)this.a(f3));
        canvas.drawBitmap(bitmap, this.t, this.u);
    }

    private void a(MotionEvent motionEvent) {
        this.removeCallbacks(this.o);
        this.e = (int)motionEvent.getX();
        this.f = (int)motionEvent.getY();
        this.g = this.b(this.getChildAt(0)) - this.i;
        this.g();
        this.m = VelocityTracker.obtain();
        this.m.addMovement(motionEvent);
        this.d = 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(View view, int n2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            layoutParams = new ViewGroup.LayoutParams(-2, -2);
        }
        n2 = n2 == 1 ? 0 : -1;
        view.setDrawingCacheEnabled(true);
        this.addViewInLayout(view, n2, layoutParams, true);
        view.measure((int)((float)this.getWidth() * 0.85f) | 1073741824, 0);
    }

    private int b(View view) {
        return view.getTop() - this.a(view);
    }

    private void b(float f2) {
        this.a(f2, false);
    }

    private void b(int n2) {
        View view = this.getChildAt(n2);
        n2 = this.k + n2;
        long l2 = this.c.getItemId(n2);
        AdapterView.OnItemLongClickListener onItemLongClickListener = this.getOnItemLongClickListener();
        if (onItemLongClickListener != null) {
            onItemLongClickListener.onItemLongClick((AdapterView)this, view, n2, l2);
        }
    }

    private void b(int n2, int n3) {
        if ((n2 = this.a(n2, n3)) != -1) {
            View view = this.getChildAt(n2);
            this.performItemClick(view, n2, this.c.getItemId(n2 += this.k));
        }
    }

    private boolean b(MotionEvent motionEvent) {
        int n2 = (int)motionEvent.getX();
        int n3 = (int)motionEvent.getY();
        if (n2 < this.e - 10 || n2 > this.e + 10 || n3 < this.f - 10 || n3 > this.f + 10) {
            this.removeCallbacks(this.q);
            this.d = 2;
            return true;
        }
        return false;
    }

    private int c(View view) {
        return view.getBottom() + this.a(view);
    }

    private void c(int n2) {
        int n3;
        View view;
        int n4 = n3 = this.getChildCount();
        if (this.l != this.c.getCount() - 1) {
            n4 = n3;
            if (n3 > 1) {
                view = this.getChildAt(0);
                do {
                    n4 = n3;
                    if (view == null) break;
                    n4 = n3--;
                    if (this.c(view) + n2 >= 0) break;
                    this.removeViewInLayout(view);
                    this.p.addLast(view);
                    ++this.k;
                    this.i += this.d(view);
                    if (n3 > 1) {
                        view = this.getChildAt(0);
                        continue;
                    }
                    view = null;
                } while (true);
            }
        }
        if (this.k != 0 && n4 > 1) {
            view = this.getChildAt(n4 - 1);
            while (view != null && this.b(view) + n2 > this.getHeight()) {
                this.removeViewInLayout(view);
                this.p.addLast(view);
                --this.l;
                if (--n4 > 1) {
                    view = this.getChildAt(n4 - 1);
                    continue;
                }
                view = null;
            }
        }
    }

    private void c(int n2, int n3) {
        while (n2 + n3 < this.getHeight() && this.l < this.c.getCount() - 1) {
            ++this.l;
            View view = this.c.getView(this.l, this.getCachedView(), (ViewGroup)this);
            this.a(view, 0);
            n2 += this.d(view);
        }
    }

    private int d(View view) {
        return view.getMeasuredHeight() + this.a(view) * 2;
    }

    private void d(int n2) {
        this.c(this.c(this.getChildAt(this.getChildCount() - 1)), n2);
        this.d(this.b(this.getChildAt(0)), n2);
    }

    private void d(int n2, int n3) {
        while (n2 + n3 > 0 && this.k > 0) {
            --this.k;
            View view = this.c.getView(this.k, this.getCachedView(), (ViewGroup)this);
            this.a(view, 1);
            int n4 = this.d(view);
            n2 -= n4;
            this.i -= n4;
        }
    }

    private boolean d() {
        return com.startapp.android.publish.g.b.a();
    }

    private void e() {
        if (!this.B) {
            this.B = true;
            this.dispatchTouchEvent(MotionEvent.obtain((long)System.currentTimeMillis(), (long)System.currentTimeMillis(), (int)0, (float)0.0f, (float)0.0f, (int)0));
            this.postDelayed(new Runnable(){

                @Override
                public void run() {
                    MotionEvent motionEvent = MotionEvent.obtain((long)System.currentTimeMillis(), (long)System.currentTimeMillis(), (int)2, (float)0.0f, (float)-20.0f, (int)0);
                    c.this.dispatchTouchEvent(motionEvent);
                    motionEvent = MotionEvent.obtain((long)System.currentTimeMillis(), (long)System.currentTimeMillis(), (int)1, (float)0.0f, (float)-20.0f, (int)0);
                    c.this.dispatchTouchEvent(motionEvent);
                }
            }, 5);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void f() {
        int n2;
        int n3 = this.j % 90;
        n3 = n3 < 45 ? (- this.j - n3) * this.getHeight() / 270 : (- this.j + 90 - n3) * this.getHeight() / 270;
        if (this.v == Integer.MIN_VALUE && this.l == this.c.getCount() - 1 && this.c(this.getChildAt(this.getChildCount() - 1)) < this.getHeight()) {
            this.v = n3;
        }
        if (n3 > 0) {
            n2 = 0;
        } else {
            n2 = n3;
            if (n3 < this.v) {
                n2 = this.v;
            }
        }
        this.n.a((float)n2);
        this.n.b(n2);
    }

    static /* synthetic */ int g(c c2) {
        int n2 = c2.k;
        c2.k = n2 - 1;
        return n2;
    }

    private void g() {
        if (this.q == null) {
            this.q = new Runnable(){

                @Override
                public void run() {
                    int n2;
                    if (c.this.d == 1 && (n2 = c.this.a(c.this.e, c.this.f)) != -1) {
                        c.this.b(n2);
                    }
                }
            };
        }
        this.postDelayed(this.q, (long)ViewConfiguration.getLongPressTimeout());
    }

    private View getCachedView() {
        if (this.p.size() != 0) {
            return this.p.removeFirst();
        }
        return null;
    }

    private void h() {
        int n2 = this.h;
        int n3 = this.i + n2;
        float f2 = this.getWidth();
        float f3 = 1.0f / ((float)this.getHeight() * 0.9f);
        for (n2 = 0; n2 < this.getChildCount(); ++n2) {
            View view = this.getChildAt(n2);
            int n4 = (int)((double)(0.0f * f2) * Math.sin(6.283185307179586 * (double)f3 * (double)n3));
            int n5 = view.getMeasuredWidth();
            int n6 = view.getMeasuredHeight();
            int n7 = this.a(view);
            int n8 = n3 + n7;
            view.layout(n4, n8, n5 + (n4 += (this.getWidth() - n5) / 2), n8 + n6);
            n3 += n7 * 2 + n6;
        }
    }

    static /* synthetic */ int i(c c2) {
        int n2 = c2.l;
        c2.l = n2 - 1;
        return n2;
    }

    public void a() {
        this.x = true;
    }

    public boolean b() {
        return this.A;
    }

    public boolean c() {
        return this.z;
    }

    public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        return super.dispatchKeyShortcutEvent(keyEvent);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean drawChild(Canvas canvas, View view, long l2) {
        Bitmap bitmap = view.getDrawingCache();
        if (bitmap == null) {
            return super.drawChild(canvas, view, l2);
        }
        int n2 = view.getTop();
        int n3 = view.getLeft();
        int n4 = view.getWidth();
        int n5 = view.getHeight();
        n4 /= 2;
        float f2 = this.getHeight() / 2;
        f2 = ((float)(n2 + (n5 /= 2)) - f2) / f2;
        float f3 = (float)(1.0 - 0.15000000596046448 * (1.0 - Math.cos(f2)));
        if ((f2 = ((float)this.j - f2 * 20.0f) % 90.0f) < 0.0f) {
            f2 += 90.0f;
        }
        if (f2 < 45.0f) {
            this.a(canvas, bitmap, n2, n3, n4, n5, f3, f2 - 90.0f);
            this.a(canvas, bitmap, n2, n3, n4, n5, f3, f2);
            do {
                return false;
                break;
            } while (true);
        }
        this.a(canvas, bitmap, n2, n3, n4, n5, f3, f2);
        this.a(canvas, bitmap, n2, n3, n4, n5, f3, f2 - 90.0f);
        return false;
    }

    public Adapter getAdapter() {
        return this.c;
    }

    public int getFirstItemPosition() {
        return this.k;
    }

    public int getLastItemPosition() {
        return this.l;
    }

    public View getSelectedView() {
        return null;
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.removeCallbacks(this.o);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onLayout(boolean bl, int n2, int n3, int n4, int n5) {
        super.onLayout(bl, n2, n3, n4, n5);
        if (!this.x || this.c == null) {
            return;
        }
        if (this.getChildCount() == 0) {
            if (this.b()) {
                this.h = this.getHeight() / 3;
            }
            this.l = !this.y ? -1 : this.k++;
            this.c(this.h, 0);
        } else {
            n2 = this.h + this.i - this.b(this.getChildAt(0));
            this.c(n2);
            this.d(n2);
        }
        this.h();
        if (this.b()) {
            this.e();
        }
        this.invalidate();
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean onTouchEvent(MotionEvent motionEvent) {
        float f2 = 0.0f;
        if (this.getChildCount() == 0) {
            return false;
        }
        switch (motionEvent.getAction()) {
            default: {
                this.a(0.0f, false);
                return true;
            }
            case 0: {
                if (this.d()) {
                    com.startapp.android.publish.g.b.a((View)this, 1500);
                }
                this.a(motionEvent);
                return true;
            }
            case 2: {
                if (this.d == 1) {
                    this.b(motionEvent);
                }
                if (this.d != 2) return true;
                this.m.addMovement(motionEvent);
                this.a((int)motionEvent.getY() - this.f);
                return true;
            }
            case 1: 
        }
        if (this.d == 1) {
            this.b((int)motionEvent.getX(), (int)motionEvent.getY());
        } else if (this.d == 2) {
            this.m.addMovement(motionEvent);
            this.m.computeCurrentVelocity(1000);
            this.w = f2 = this.m.getYVelocity();
        }
        this.a(f2, false);
        return true;
    }

    public void setAdapter(Adapter adapter) {
        if (this.d() && this.c()) {
            com.startapp.android.publish.g.b.a((View)this, 0.0f);
        }
        this.c = adapter;
        this.removeAllViewsInLayout();
        this.requestLayout();
    }

    public void setDynamics(Dynamics dynamics) {
        if (this.n != null) {
            dynamics.a(this.n.a(), this.n.b(), AnimationUtils.currentAnimationTimeMillis());
        }
        this.n = dynamics;
    }

    public void setFade(boolean bl) {
        this.z = bl;
    }

    public void setHint(boolean bl) {
        this.A = bl;
    }

    public void setSelection(int n2) {
        throw new UnsupportedOperationException("Not supported");
    }

    public void setTag(String string2) {
        this.b = string2;
    }

}

