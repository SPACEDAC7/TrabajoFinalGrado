/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.EmbossMaskFilter
 *  android.graphics.LinearGradient
 *  android.graphics.MaskFilter
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.GradientDrawable
 *  android.graphics.drawable.GradientDrawable$Orientation
 *  android.graphics.drawable.ShapeDrawable
 *  android.graphics.drawable.shapes.RoundRectShape
 *  android.graphics.drawable.shapes.Shape
 *  android.text.TextUtils
 *  android.text.TextUtils$TruncateAt
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 */
package com.startapp.android.publish.list3d;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.EmbossMaskFilter;
import android.graphics.LinearGradient;
import android.graphics.MaskFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.startapp.android.publish.g.m;
import com.startapp.android.publish.g.q;
import com.startapp.android.publish.model.MetaData;
import com.startapp.android.publish.model.MetaDataStyle;
import java.util.Set;

public class d {
    private RelativeLayout a;
    private ImageView b;
    private TextView c;
    private TextView d;
    private TextView e;
    private m f;
    private MetaDataStyle g = null;

    public d(Context object) {
        object.setTheme(16973829);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -2);
        this.a = new RelativeLayout((Context)object);
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{MetaData.getInstance().getItemGradientTop(), MetaData.getInstance().getItemGradientBottom()});
        this.a.setBackgroundDrawable((Drawable)gradientDrawable);
        this.a.setLayoutParams(layoutParams);
        int n2 = q.a((Context)object, 3);
        int n3 = q.a((Context)object, 4);
        int n4 = q.a((Context)object, 5);
        int n5 = q.a((Context)object, 6);
        int n6 = q.a((Context)object, 10);
        int n7 = q.a((Context)object, 84);
        this.a.setPadding(n6, n2, n6, n2);
        this.a.setTag((Object)this);
        this.b = new ImageView((Context)object);
        this.b.setId(1);
        layoutParams = new RelativeLayout.LayoutParams(n7, n7);
        layoutParams.addRule(15);
        this.b.setLayoutParams(layoutParams);
        this.b.setPadding(0, 0, n5, 0);
        this.c = new TextView((Context)object);
        this.c.setId(2);
        layoutParams = new RelativeLayout.LayoutParams(-1, -2);
        layoutParams.addRule(1, 1);
        layoutParams.addRule(6, 1);
        this.c.setLayoutParams(layoutParams);
        this.c.setPadding(0, 0, 0, n4);
        this.c.setTextColor(MetaData.getInstance().getItemTitleTextColor().intValue());
        this.c.setTextSize((float)MetaData.getInstance().getItemTitleTextSize().intValue());
        this.c.setSingleLine(true);
        this.c.setEllipsize(TextUtils.TruncateAt.END);
        q.a(this.c, MetaData.getInstance().getItemTitleTextDecoration());
        this.d = new TextView((Context)object);
        this.d.setId(3);
        layoutParams = new RelativeLayout.LayoutParams(-1, -2);
        layoutParams.addRule(1, 1);
        layoutParams.addRule(3, 2);
        layoutParams.setMargins(0, 0, 0, n4);
        this.d.setLayoutParams(layoutParams);
        this.d.setTextColor(MetaData.getInstance().getItemDescriptionTextColor().intValue());
        this.d.setTextSize((float)MetaData.getInstance().getItemDescriptionTextSize().intValue());
        this.d.setSingleLine(true);
        this.d.setEllipsize(TextUtils.TruncateAt.END);
        q.a(this.d, MetaData.getInstance().getItemDescriptionTextDecoration());
        this.f = new m((Context)object);
        layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(1, 1);
        layoutParams.addRule(8, 1);
        layoutParams.setMargins(0, 0, 0, - n4);
        this.f.setLayoutParams(layoutParams);
        this.f.setPadding(0, 0, 0, n3);
        this.f.setId(5);
        this.e = new TextView((Context)object);
        object = new RelativeLayout.LayoutParams(-2, -2);
        object.addRule(11);
        object.addRule(8, 1);
        this.e.setLayoutParams((ViewGroup.LayoutParams)object);
        this.a(false);
        this.e.setTextColor(-1);
        this.e.setTextSize(12.0f);
        this.e.setTypeface(null, 1);
        this.e.setPadding(n6, n5, n6, n5);
        this.e.setId(4);
        this.e.setShadowLayer(2.5f, -3.0f, 3.0f, -9013642);
        object = new ShapeDrawable((Shape)new RoundRectShape(new float[]{10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f}, null, null)){

            protected void onDraw(Shape shape, Canvas canvas, Paint paint) {
                paint.setShader((Shader)new LinearGradient(0.0f, 0.0f, shape.getWidth(), 0.0f, -15626493, -15485690, Shader.TileMode.REPEAT));
                paint.setMaskFilter((MaskFilter)new EmbossMaskFilter(new float[]{1.0f, 1.0f, 1.0f}, 0.4f, 5.0f, 3.0f));
                super.onDraw(shape, canvas, paint);
            }
        };
        this.e.setBackgroundDrawable((Drawable)object);
        this.a.addView((View)this.b);
        this.a.addView((View)this.c);
        this.a.addView((View)this.d);
        this.a.addView((View)this.f);
        this.a.addView((View)this.e);
    }

    public RelativeLayout a() {
        return this.a;
    }

    public void a(MetaDataStyle metaDataStyle) {
        if (this.g != metaDataStyle) {
            this.g = metaDataStyle;
            GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{metaDataStyle.getItemGradientTop(), metaDataStyle.getItemGradientBottom()});
            this.a.setBackgroundDrawable((Drawable)gradientDrawable);
            this.c.setTextSize((float)metaDataStyle.getItemTitleTextSize().intValue());
            this.c.setTextColor(metaDataStyle.getItemTitleTextColor().intValue());
            q.a(this.c, metaDataStyle.getItemTitleTextDecoration());
            this.d.setTextSize((float)metaDataStyle.getItemDescriptionTextSize().intValue());
            this.d.setTextColor(metaDataStyle.getItemDescriptionTextColor().intValue());
            q.a(this.d, metaDataStyle.getItemDescriptionTextDecoration());
        }
    }

    public void a(boolean bl) {
        if (bl) {
            this.e.setText((CharSequence)"Open");
            return;
        }
        this.e.setText((CharSequence)"Download");
    }

    public ImageView b() {
        return this.b;
    }

    public TextView c() {
        return this.c;
    }

    public TextView d() {
        return this.d;
    }

    public m e() {
        return this.f;
    }

}

