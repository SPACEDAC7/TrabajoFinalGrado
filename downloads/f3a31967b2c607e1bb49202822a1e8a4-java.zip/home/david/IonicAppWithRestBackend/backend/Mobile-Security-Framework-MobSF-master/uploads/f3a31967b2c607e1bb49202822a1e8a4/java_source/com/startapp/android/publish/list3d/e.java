/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.os.Parcelable
 */
package com.startapp.android.publish.list3d;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Parcelable;
import com.startapp.android.publish.list3d.ListItem;
import com.startapp.android.publish.list3d.a;
import com.startapp.android.publish.list3d.f;
import com.startapp.android.publish.model.AdDetails;
import java.util.ArrayList;
import java.util.List;

public enum e {
    a;
    
    private a imagesManager = new a();
    private List<ListItem> listItems;
    private String queryPosition = "";

    private e() {
    }

    public final Bitmap a(int n2, String string2, String string3) {
        return this.imagesManager.a(n2, string2, string3);
    }

    public final void a() {
        this.listItems = new ArrayList<ListItem>();
        this.queryPosition = "";
    }

    public final void a(Context context, String string2, String string3) {
        this.imagesManager.a(context, string2, string3 + this.queryPosition);
    }

    public final void a(f f2, boolean bl) {
        this.imagesManager.a(f2, bl);
    }

    public final void a(AdDetails parcelable) {
        parcelable = new ListItem((AdDetails)parcelable);
        this.listItems.add((ListItem)parcelable);
        this.imagesManager.a(this.listItems.size() - 1, parcelable.a(), parcelable.g());
    }

    public final void a(String string2) {
        this.queryPosition = string2;
    }

    public final List<ListItem> b() {
        return this.listItems;
    }
}

