/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.list3d;

public interface f {
    public void a(int var1);
}

