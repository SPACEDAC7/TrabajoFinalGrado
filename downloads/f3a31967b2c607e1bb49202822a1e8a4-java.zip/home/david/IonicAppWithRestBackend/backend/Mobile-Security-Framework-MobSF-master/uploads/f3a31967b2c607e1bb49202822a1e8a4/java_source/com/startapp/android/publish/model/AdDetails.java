/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.startapp.android.publish.model;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;

public class AdDetails
implements Parcelable,
Serializable {
    public static final Parcelable.Creator<AdDetails> CREATOR = new Parcelable.Creator<AdDetails>(){

        public final AdDetails createFromParcel(Parcel parcel) {
            return new AdDetails(parcel);
        }

        public final AdDetails[] newArray(int n2) {
            return new AdDetails[n2];
        }
    };
    private static final long serialVersionUID = 1;
    private String adId;
    private String appPresencePackage;
    private String category;
    private String clickUrl;
    private String description;
    private String imageUrl;
    private String installs;
    private String intentDetails;
    private String intentPackageName;
    private int minAppVersion;
    private String packageName;
    private float rating = 5.0f;
    private boolean smartRedirect;
    private String template;
    private String title;
    private String trackingClickUrl;
    private String trackingUrl;

    public AdDetails() {
    }

    public AdDetails(Parcel parcel) {
        this.adId = parcel.readString();
        this.clickUrl = parcel.readString();
        this.trackingUrl = parcel.readString();
        this.trackingClickUrl = parcel.readString();
        this.title = parcel.readString();
        this.description = parcel.readString();
        this.imageUrl = parcel.readString();
        this.rating = parcel.readFloat();
        int n2 = parcel.readInt();
        this.smartRedirect = false;
        if (n2 == 1) {
            this.smartRedirect = true;
        }
        this.template = parcel.readString();
        this.packageName = parcel.readString();
        this.appPresencePackage = parcel.readString();
        this.intentPackageName = parcel.readString();
        this.intentDetails = parcel.readString();
        this.minAppVersion = parcel.readInt();
        this.installs = parcel.readString();
        this.category = parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public String getAdId() {
        return this.adId;
    }

    public String getAppPresencePackage() {
        return this.appPresencePackage;
    }

    public String getCategory() {
        return this.category;
    }

    public String getClickUrl() {
        return this.clickUrl;
    }

    public String getDescription() {
        return this.description;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }

    public String getInstalls() {
        return this.installs;
    }

    public String getIntentDetails() {
        return this.intentDetails;
    }

    public String getIntentPackageName() {
        return this.intentPackageName;
    }

    public int getMinAppVersion() {
        return this.minAppVersion;
    }

    public String getPackageName() {
        return this.packageName;
    }

    public float getRating() {
        return this.rating;
    }

    public String getTemplate() {
        return this.template;
    }

    public String getTitle() {
        return this.title;
    }

    public String getTrackingClickUrl() {
        return this.trackingClickUrl;
    }

    public String getTrackingUrl() {
        return this.trackingUrl;
    }

    public boolean isCPE() {
        if (this.intentPackageName != null) {
            return true;
        }
        return false;
    }

    public boolean isSmartRedirect() {
        return this.smartRedirect;
    }

    public void setMinAppVersion(int n2) {
        this.minAppVersion = n2;
    }

    public String toString() {
        return "AdDetails [adId=" + this.adId + ", clickUrl=" + this.clickUrl + ", trackingUrl=" + this.trackingUrl + ", trackingClickUrl=" + this.trackingClickUrl + ", title=" + this.title + ", description=" + this.description + ", imageUrl=" + this.imageUrl + ", rating=" + this.rating + ", smartRedirect=" + this.smartRedirect + ", template=" + this.template + ", packageName=" + this.packageName + ", appPresencePackage=" + this.appPresencePackage + ", intentDetails=" + this.intentDetails + ", intentPackageName=" + this.intentPackageName + ", minAppVersion=" + this.minAppVersion + ", Installs=" + this.installs + ", Category=" + this.category + "]";
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.adId);
        parcel.writeString(this.clickUrl);
        parcel.writeString(this.trackingUrl);
        parcel.writeString(this.trackingClickUrl);
        parcel.writeString(this.title);
        parcel.writeString(this.description);
        parcel.writeString(this.imageUrl);
        parcel.writeFloat(this.rating);
        n2 = 0;
        if (this.smartRedirect) {
            n2 = 1;
        }
        parcel.writeInt(n2);
        parcel.writeString(this.template);
        parcel.writeString(this.packageName);
        parcel.writeString(this.appPresencePackage);
        parcel.writeString(this.intentPackageName);
        parcel.writeString(this.intentDetails);
        parcel.writeInt(this.minAppVersion);
        parcel.writeString(this.installs);
        parcel.writeString(this.category);
    }

}

