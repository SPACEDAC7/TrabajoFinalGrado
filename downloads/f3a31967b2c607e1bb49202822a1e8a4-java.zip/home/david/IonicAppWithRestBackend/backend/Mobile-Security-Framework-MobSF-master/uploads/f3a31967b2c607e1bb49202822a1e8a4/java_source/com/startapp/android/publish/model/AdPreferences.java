/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.model;

import android.content.Context;
import com.startapp.android.publish.SDKAdPreferences;
import com.startapp.android.publish.StartAppSDK;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class AdPreferences
implements Serializable {
    public static final String TYPE_APP_WALL = "APP_WALL";
    public static final String TYPE_BANNER = "BANNER";
    public static final String TYPE_INAPP_EXIT = "INAPP_EXIT";
    public static final String TYPE_SCRINGO_TOOLBAR = "SCRINGO_TOOLBAR";
    public static final String TYPE_TEXT = "TEXT";
    private static final long serialVersionUID = 1;
    private String adTag = null;
    protected String advertiserId = null;
    private Integer age = null;
    private Set<String> categories = null;
    private Set<String> categoriesExclude = null;
    protected String country = null;
    private SDKAdPreferences.Gender gender = null;
    private String keywords = null;
    private Double latitude = null;
    private Double longitude = null;
    private String productId = null;
    private String publisherId = null;
    protected String template = null;
    private boolean testMode = false;
    protected String type = null;

    public AdPreferences() {
    }

    public AdPreferences(AdPreferences adPreferences) {
        this.publisherId = adPreferences.publisherId;
        this.productId = adPreferences.productId;
        this.testMode = adPreferences.testMode;
        this.longitude = adPreferences.longitude;
        this.latitude = adPreferences.latitude;
        this.keywords = adPreferences.keywords;
        this.adTag = adPreferences.adTag;
        this.categories = adPreferences.categories;
        this.categoriesExclude = adPreferences.categoriesExclude;
    }

    @Deprecated
    public AdPreferences(String string2, String string3) {
        this.publisherId = string2;
        this.productId = string3;
    }

    @Deprecated
    public AdPreferences(String string2, String string3, String string4) {
        this.publisherId = string2;
        this.productId = string3;
    }

    public AdPreferences addCategory(String string2) {
        if (this.categories == null) {
            this.categories = new HashSet<String>();
        }
        this.categories.add(string2);
        return this;
    }

    public AdPreferences addCategoryExclude(String string2) {
        if (this.categoriesExclude == null) {
            this.categoriesExclude = new HashSet<String>();
        }
        this.categoriesExclude.add(string2);
        return this;
    }

    public String getAdTag() {
        return this.adTag;
    }

    public Integer getAge(Context context) {
        if (this.age == null) {
            return StartAppSDK.getInstance().getSDKAdPrefs(context).getAge();
        }
        return this.age;
    }

    public Set<String> getCategories() {
        return this.categories;
    }

    public Set<String> getCategoriesExclude() {
        return this.categoriesExclude;
    }

    public SDKAdPreferences.Gender getGender(Context context) {
        if (this.gender == null) {
            return StartAppSDK.getInstance().getSDKAdPrefs(context).getGender();
        }
        return this.gender;
    }

    public String getKeywords() {
        return this.keywords;
    }

    public Double getLatitude() {
        return this.latitude;
    }

    public Double getLongitude() {
        return this.longitude;
    }

    public String getProductId() {
        return this.productId;
    }

    public String getPublisherId() {
        return this.publisherId;
    }

    public boolean isSimpleToken() {
        return true;
    }

    public boolean isTestMode() {
        return this.testMode;
    }

    public AdPreferences setAdTag(String string2) {
        this.adTag = string2;
        return this;
    }

    public AdPreferences setAge(Integer n2) {
        this.age = n2;
        return this;
    }

    public AdPreferences setGender(SDKAdPreferences.Gender gender) {
        this.gender = gender;
        return this;
    }

    public AdPreferences setKeywords(String string2) {
        this.keywords = string2;
        return this;
    }

    public AdPreferences setLatitude(double d2) {
        this.latitude = d2;
        return this;
    }

    public AdPreferences setLongitude(double d2) {
        this.longitude = d2;
        return this;
    }

    @Deprecated
    public AdPreferences setProductId(String string2) {
        this.productId = string2;
        return this;
    }

    @Deprecated
    public AdPreferences setPublisherId(String string2) {
        this.publisherId = string2;
        return this;
    }

    public AdPreferences setTestMode(boolean bl) {
        this.testMode = bl;
        return this;
    }

    public String toString() {
        return "AdPreferences [publisherId=" + this.publisherId + ", productId=" + this.productId + ", testMode=" + this.testMode + ", longitude=" + this.longitude + ", latitude=" + this.latitude + ", keywords=" + this.keywords + ", adTag=" + this.adTag + ", categories=" + this.categories + ", categoriesExclude=" + this.categoriesExclude + "]";
    }

    public static enum Placement {
        INAPP_FULL_SCREEN(1),
        INAPP_BANNER(2),
        INAPP_OFFER_WALL(3),
        INAPP_SPLASH(4),
        INAPP_OVERLAY(5),
        INAPP_NATIVE(6),
        DEVICE_SIDEBAR(7),
        INAPP_RETURN(8);
        
        private int index;

        private Placement(int n3) {
            this.index = n3;
        }

        public static Placement getByIndex(int n2) {
            Placement placement = INAPP_FULL_SCREEN;
            Placement[] arrplacement = Placement.values();
            for (int i2 = 0; i2 < arrplacement.length; ++i2) {
                if (arrplacement[i2].getIndex() != n2) continue;
                placement = arrplacement[i2];
            }
            return placement;
        }

        public final int getIndex() {
            return this.index;
        }

        public final boolean isInterstitial() {
            if (this == INAPP_FULL_SCREEN || this == INAPP_OFFER_WALL || this == INAPP_SPLASH || this == INAPP_OVERLAY) {
                return true;
            }
            return false;
        }
    }

}

