/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.telephony.TelephonyManager
 *  android.util.DisplayMetrics
 */
package com.startapp.android.publish.model;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import com.startapp.android.publish.b;
import com.startapp.android.publish.g.a;
import com.startapp.android.publish.g.k;
import com.startapp.android.publish.g.l;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.NameValueObject;
import com.startapp.android.publish.model.NameValueSerializer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public abstract class BaseRequest
implements NameValueSerializer {
    private static final String OS = "android";
    private String deviceVersion;
    private int height;
    private String isp;
    private String ispName;
    private String locale;
    private String manufacturer;
    private String model;
    private String networkType;
    private String os = "android";
    private String packageId;
    private Map<String, String> parameters = new HashMap<String, String>();
    private String productId;
    private String publisherId;
    private int sdkId = 3;
    private String sdkVersion = b.a;
    private String signalLevel;
    private String subProductId;
    private String subPublisherId;
    private Boolean unknownSourcesAllowed;
    private String userAdvertisingId;
    private int width;

    private void setNetworkType(Context context) {
        this.networkType = l.a(context);
    }

    private void setSignalLevel(String string2) {
        this.signalLevel = "e106";
        k k2 = k.a();
        if (k2 != null) {
            this.signalLevel = k2.a(string2);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void fillApplicationDetails(Context context, AdPreferences adPreferences) {
        this.setPublisherId(adPreferences.getPublisherId());
        this.setProductId(adPreferences.getProductId());
        this.setUserAdvertisingId(a.a(context));
        this.setPackageId(context.getPackageName());
        this.setManufacturer(Build.MANUFACTURER);
        this.setModel(Build.MODEL);
        this.setDeviceVersion(Integer.toString(Build.VERSION.SDK_INT));
        this.setLocale(context.getResources().getConfiguration().locale.toString());
        this.setWidth(context.getResources().getDisplayMetrics().widthPixels);
        this.setHeight(context.getResources().getDisplayMetrics().heightPixels);
        this.setNetworkType(context);
        this.setSignalLevel(this.getNetworkType());
        this.setUnknownSourcesAllowed(com.startapp.android.publish.g.b.a(context));
        try {
            context = (TelephonyManager)context.getSystemService("phone");
            if (context == null) return;
        }
        catch (Exception var1_2) {
            return;
        }
        this.setIsp(context.getSimOperator());
        this.setIspName(context.getSimOperatorName());
    }

    public String getDeviceVersion() {
        return this.deviceVersion;
    }

    public int getHeight() {
        return this.height;
    }

    public String getIsp() {
        return this.isp;
    }

    public String getIspName() {
        return this.ispName;
    }

    public String getLocale() {
        return this.locale;
    }

    public String getManufacturer() {
        return this.manufacturer;
    }

    public String getModel() {
        return this.model;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public List<NameValueObject> getNameValueMap() {
        ArrayList<NameValueObject> arrayList = new ArrayList<NameValueObject>();
        r.a(arrayList, "publisherId", (Object)this.publisherId, true);
        r.a(arrayList, "productId", (Object)this.productId, true);
        r.a(arrayList, "os", (Object)this.os, true);
        r.a(arrayList, "sdkVersion", (Object)this.sdkVersion, false);
        r.a(arrayList, "packageId", (Object)this.packageId, false);
        r.a(arrayList, "userAdvertisingId", (Object)this.userAdvertisingId, false);
        r.a(arrayList, "model", (Object)this.model, false);
        r.a(arrayList, "manufacturer", (Object)this.manufacturer, false);
        r.a(arrayList, "deviceVersion", (Object)this.deviceVersion, false);
        r.a(arrayList, "locale", (Object)this.locale, false);
        r.a(arrayList, "isp", (Object)this.isp, false);
        r.a(arrayList, "ispName", (Object)this.ispName, false);
        r.a(arrayList, "subPublisherId", (Object)this.subPublisherId, false);
        r.a(arrayList, "subProductId", (Object)this.subProductId, false);
        r.a(arrayList, "grid", (Object)this.getNetworkType(), false);
        r.a(arrayList, "silev", (Object)this.getSignalLevel(), false);
        String string2 = this.isUnknownSourcesAllowed() == null ? null : this.isUnknownSourcesAllowed().toString();
        r.a(arrayList, "outsource", (Object)string2, false);
        r.a(arrayList, "width", (Object)String.valueOf(this.width), false);
        r.a(arrayList, "height", (Object)String.valueOf(this.height), false);
        r.a(arrayList, "sdkId", (Object)String.valueOf(this.sdkId), true);
        return arrayList;
    }

    public String getNetworkType() {
        return this.networkType;
    }

    public String getOs() {
        return this.os;
    }

    public String getPackageId() {
        return this.packageId;
    }

    public Map<String, String> getParameters() {
        return this.parameters;
    }

    public String getProductId() {
        return this.productId;
    }

    public String getPublisherId() {
        return this.publisherId;
    }

    public String getRequestString() {
        StringBuilder stringBuilder = new StringBuilder();
        List<NameValueObject> list = this.getNameValueMap();
        if (list == null) {
            return stringBuilder.toString();
        }
        stringBuilder.append('?');
        for (NameValueObject nameValueObject : list) {
            Object object;
            if (nameValueObject.getValue() != null) {
                stringBuilder.append(nameValueObject.getName()).append('=').append(nameValueObject.getValue()).append('&');
                continue;
            }
            if (nameValueObject.getValueSet() == null || (object = nameValueObject.getValueSet()) == null) continue;
            object = object.iterator();
            while (object.hasNext()) {
                String string2 = (String)object.next();
                stringBuilder.append(nameValueObject.getName()).append('=').append(string2).append('&');
            }
        }
        if (stringBuilder.length() != 0) {
            stringBuilder.deleteCharAt(stringBuilder.length() - 1);
        }
        return stringBuilder.toString().replace("+", "%20");
    }

    public String getSdkVersion() {
        return this.sdkVersion;
    }

    public String getSignalLevel() {
        return this.signalLevel;
    }

    public String getSubProductId() {
        return this.subProductId;
    }

    public String getSubPublisherId() {
        return this.subPublisherId;
    }

    public String getUserAdvertisingId() {
        return this.userAdvertisingId;
    }

    public int getWidth() {
        return this.width;
    }

    public Boolean isUnknownSourcesAllowed() {
        return this.unknownSourcesAllowed;
    }

    public void setDeviceVersion(String string2) {
        this.deviceVersion = string2;
    }

    public void setHeight(int n2) {
        this.height = n2;
    }

    public void setIsp(String string2) {
        this.isp = string2;
    }

    public void setIspName(String string2) {
        this.ispName = string2;
    }

    public void setLocale(String string2) {
        this.locale = string2;
    }

    public void setManufacturer(String string2) {
        this.manufacturer = string2;
    }

    public void setModel(String string2) {
        this.model = string2;
    }

    public void setPackageId(String string2) {
        this.packageId = string2;
    }

    public void setParameters(Map<String, String> map) {
        this.parameters = map;
    }

    public void setProductId(String string2) {
        this.productId = string2;
    }

    public void setPublisherId(String string2) {
        this.publisherId = string2;
    }

    public void setSdkVersion(String string2) {
        this.sdkVersion = string2;
    }

    public void setSubProductId(String string2) {
        this.subProductId = string2;
    }

    public void setSubPublisherId(String string2) {
        this.subPublisherId = string2;
    }

    public void setUnknownSourcesAllowed(Boolean bl) {
        this.unknownSourcesAllowed = bl;
    }

    public void setUserAdvertisingId(String string2) {
        this.userAdvertisingId = string2;
    }

    public void setWidth(int n2) {
        this.width = n2;
    }

    public String toString() {
        return "BaseRequest [parameters=" + this.parameters + "]";
    }
}

