/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public abstract class BaseResponse
implements Serializable {
    private static final long serialVersionUID = 1;
    private String errorMessage = null;
    protected Map<String, String> parameters = new HashMap<String, String>();
    private boolean validResponse = true;

    public String getErrorMessage() {
        return this.errorMessage;
    }

    public Map<String, String> getParameters() {
        return this.parameters;
    }

    public boolean isValidResponse() {
        return this.validResponse;
    }

    public void setErrorMessage(String string2) {
        this.errorMessage = string2;
    }

    public void setParameters(Map<String, String> map) {
        this.parameters = map;
    }

    public void setValidResponse(boolean bl) {
        this.validResponse = bl;
    }

    public String toString() {
        return "BaseResponse [parameters=" + this.parameters + ", validResponse=" + this.validResponse + ", errorMessage=" + this.errorMessage + "]";
    }
}

