/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.model;

import android.content.Context;
import com.startapp.android.publish.SDKAdPreferences;
import com.startapp.android.publish.adinformation.AdInformationConfig;
import com.startapp.android.publish.adinformation.e;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.BaseRequest;
import com.startapp.android.publish.model.MetaData;
import com.startapp.android.publish.model.NameValueObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GetAdRequest
extends BaseRequest {
    private String adTag;
    private int adsNumber = 1;
    private String advertiserId = null;
    private Integer age;
    private Set<String> categories = null;
    private Set<String> categoriesExclude = null;
    private String country = null;
    private boolean engInclude = true;
    private SDKAdPreferences.Gender gender;
    private String keywords;
    private Double latitude;
    private Double longitude;
    private int offset = 0;
    private Set<String> packagesExclude = null;
    private AdPreferences.Placement placement;
    private String simpleToken;
    private String template;
    private boolean testMode;
    private String type = null;

    public void addCategory(String string2) {
        if (this.categories == null) {
            this.categories = new HashSet<String>();
        }
        this.categories.add(string2);
    }

    public void addCategoryExclude(String string2) {
        if (this.categoriesExclude == null) {
            this.categoriesExclude = new HashSet<String>();
        }
        this.categoriesExclude.add(string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void fillAdPreferences(Context context, AdPreferences adPreferences, AdPreferences.Placement placement, String string2) {
        this.placement = placement;
        this.simpleToken = MetaData.getInstance().getAdInformationConfig().e().a(context) && adPreferences.isSimpleToken() ? string2 : "";
        this.longitude = adPreferences.getLongitude();
        this.latitude = adPreferences.getLatitude();
        this.age = adPreferences.getAge(context);
        this.gender = adPreferences.getGender(context);
        this.keywords = adPreferences.getKeywords();
        this.adTag = adPreferences.getAdTag();
        this.testMode = adPreferences.isTestMode();
        this.categories = adPreferences.getCategories();
        this.categoriesExclude = adPreferences.getCategoriesExclude();
        this.setCountry(adPreferences.country);
        this.setAdvertiser(adPreferences.advertiserId);
        this.setTemplate(adPreferences.template);
        this.setType(adPreferences.type);
    }

    public String getAdTag() {
        return this.adTag;
    }

    public int getAdsNumber() {
        return this.adsNumber;
    }

    public String getAdvertiserId() {
        return this.advertiserId;
    }

    public int getAge() {
        return this.age;
    }

    public Set<String> getCategories() {
        return this.categories;
    }

    public Set<String> getCategoriesExclude() {
        return this.categoriesExclude;
    }

    public String getCountry() {
        return this.country;
    }

    public SDKAdPreferences.Gender getGender() {
        return this.gender;
    }

    public String getKeywords() {
        return this.keywords;
    }

    public double getLatitude() {
        return this.latitude;
    }

    public double getLongitude() {
        return this.longitude;
    }

    @Override
    public List<NameValueObject> getNameValueMap() {
        List<NameValueObject> list;
        List<NameValueObject> list2 = list = super.getNameValueMap();
        if (list == null) {
            list2 = new ArrayList<NameValueObject>();
        }
        r.a(list2, "placement", (Object)this.placement.name(), true);
        r.a(list2, "testMode", (Object)Boolean.toString(this.testMode), false);
        r.a(list2, "longitude", this.longitude, false);
        r.a(list2, "latitude", this.latitude, false);
        r.a(list2, "gender", (Object)this.gender, false);
        r.a(list2, "age", this.age, false);
        r.a(list2, "keywords", (Object)this.keywords, false);
        r.a(list2, "adTag", (Object)this.adTag, false);
        r.a(list2, "template", (Object)this.template, false);
        r.a(list2, "adsNumber", (Object)Integer.toString(this.adsNumber), false);
        r.a(list2, "category", this.categories, false);
        r.a(list2, "categoryExclude", this.categoriesExclude, false);
        r.a(list2, "packageExclude", this.packagesExclude, false);
        r.a(list2, "offset", (Object)Integer.toString(this.offset), false);
        r.a(list2, "token", (Object)this.simpleToken, false);
        r.a(list2, "engInclude", (Object)Boolean.toString(this.engInclude), false);
        if (!MetaData.getInstance().isDisableTwoClicks()) {
            r.a(list2, "twoClicks", (Object)Boolean.toString(true), false);
        }
        if (this.getCountry() != null) {
            r.a(list2, "country", (Object)this.getCountry(), false);
        }
        if (this.getAdvertiserId() != null) {
            r.a(list2, "advertiserId", (Object)this.getAdvertiserId(), false);
        }
        if (this.getType() != null) {
            r.a(list2, "type", (Object)this.getType(), false);
        }
        return list2;
    }

    public int getOffset() {
        return this.offset;
    }

    public Set<String> getPackagesExclude() {
        return this.packagesExclude;
    }

    public AdPreferences.Placement getPlacement() {
        return this.placement;
    }

    public String getSimpleToken() {
        return this.simpleToken;
    }

    public String getTemplate() {
        return this.template;
    }

    public String getType() {
        return this.type;
    }

    public boolean isEngInclude() {
        return this.engInclude;
    }

    public boolean isTestMode() {
        return this.testMode;
    }

    public void setAdTag(String string2) {
        this.adTag = string2;
    }

    public void setAdsNumber(int n2) {
        this.adsNumber = n2;
    }

    public void setAdvertiser(String string2) {
        this.advertiserId = string2;
    }

    public void setAge(int n2) {
        this.age = n2;
    }

    public void setCategories(Set<String> set) {
        this.categories = set;
    }

    public void setCategoriesExclude(Set<String> set) {
        this.categoriesExclude = set;
    }

    public void setCountry(String string2) {
        this.country = string2;
    }

    public void setEngInclude(boolean bl) {
        this.engInclude = bl;
    }

    public void setGender(SDKAdPreferences.Gender gender) {
        this.gender = gender;
    }

    public void setKeywords(String string2) {
        this.keywords = string2;
    }

    public void setLatitude(double d2) {
        this.latitude = d2;
    }

    public void setLongitude(double d2) {
        this.longitude = d2;
    }

    public void setOffset(int n2) {
        this.offset = n2;
    }

    public void setPackagesExclude(Set<String> set) {
        this.packagesExclude = set;
    }

    public void setPlacement(AdPreferences.Placement placement) {
        this.placement = placement;
    }

    public void setSimpleToken(String string2) {
        this.simpleToken = string2;
    }

    public void setTemplate(String string2) {
        this.template = string2;
    }

    public void setTestMode(boolean bl) {
        this.testMode = bl;
    }

    public void setType(String string2) {
        this.type = string2;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("GetAdRequest [");
        stringBuilder.append("placement=" + (Object)((Object)this.placement));
        stringBuilder.append(", testMode=" + this.testMode);
        stringBuilder.append(", longitude=" + this.longitude);
        stringBuilder.append(", latitude=" + this.latitude);
        stringBuilder.append(", gender=" + (Object)((Object)this.gender));
        stringBuilder.append(", age=" + this.age);
        stringBuilder.append(", keywords=" + this.keywords);
        stringBuilder.append(", adTag=" + this.adTag);
        stringBuilder.append(", template=" + this.template);
        stringBuilder.append(", adsNumber=" + this.adsNumber);
        stringBuilder.append(", offset=" + this.offset);
        stringBuilder.append(", categories=" + this.categories);
        stringBuilder.append(", categoriesExclude=" + this.categoriesExclude);
        stringBuilder.append(", packagesExclude=" + this.packagesExclude);
        stringBuilder.append(", simpleToken=" + this.simpleToken);
        stringBuilder.append(", engInclude=" + this.engInclude);
        stringBuilder.append(", country=" + this.country);
        stringBuilder.append(", advertiserId=" + this.advertiserId);
        stringBuilder.append(", type=" + this.type);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

