/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.model;

import com.startapp.android.publish.adinformation.b;
import com.startapp.android.publish.model.AdDetails;
import com.startapp.android.publish.model.BaseResponse;
import java.util.List;

public class GetAdResponse
extends BaseResponse {
    private static final long serialVersionUID = 1;
    private b adInfoOverrides = b.a();
    private List<AdDetails> adsDetails;
    private String productId;
    private String publisherId;

    public b getAdInfoOverride() {
        return this.adInfoOverrides;
    }

    public List<AdDetails> getAdsDetails() {
        return this.adsDetails;
    }

    public String getProductId() {
        return this.productId;
    }

    public String getPublisherId() {
        return this.publisherId;
    }

    public void setAdsDetails(List<AdDetails> list) {
        this.adsDetails = list;
    }

    public void setProductId(String string2) {
        this.productId = string2;
    }

    public void setPublisherId(String string2) {
        this.publisherId = string2;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("GetAdResponse [");
        stringBuilder.append("publisherId=" + this.publisherId);
        stringBuilder.append(", productId=" + this.productId);
        stringBuilder.append(", adsDetails=" + this.adsDetails);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

