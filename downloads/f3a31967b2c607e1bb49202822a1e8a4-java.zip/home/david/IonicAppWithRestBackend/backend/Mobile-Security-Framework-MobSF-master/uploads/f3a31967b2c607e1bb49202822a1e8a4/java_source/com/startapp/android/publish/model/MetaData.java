/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 */
package com.startapp.android.publish.model;

import android.content.Context;
import android.content.SharedPreferences;
import com.startapp.android.publish.adinformation.AdInformationConfig;
import com.startapp.android.publish.b;
import com.startapp.android.publish.banner.BannerOptions;
import com.startapp.android.publish.d.h;
import com.startapp.android.publish.d.p;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.gson.Gson;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.BaseResponse;
import com.startapp.android.publish.model.MetaDataStyle;
import com.startapp.android.publish.splash.SplashConfig;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class MetaData
extends BaseResponse {
    public static final long DEFAULT_AD_CACHE_TTL = 172800;
    public static final String DEFAULT_AD_CLICK_URL = "http://www.startappexchange.com/tracking/adClick";
    public static final String DEFAULT_AD_PLATFORM_HOST = "http://www.startappexchange.com/1.3/";
    public static final int DEFAULT_BG_BOTTOM = -14606047;
    public static final int DEFAULT_BG_TOP = -14606047;
    public static final boolean DEFAULT_DISABLE_RETURN_AD = false;
    public static final boolean DEFAULT_DISABLE_TWO_CLICKS = false;
    public static final int DEFAULT_FULLSCREEN_OVERLAY_PROBABILITY = 50;
    public static final int DEFAULT_HOME_PROBABILITY_3D = 80;
    public static final int DEFAULT_HTML_3D_PROBABILITY_3D = 50;
    public static final int DEFAULT_MAX_ADS = 10;
    public static final long DEFAULT_METADATA_TTL = 86400;
    public static final Integer DEFAULT_POWERED_BY_BG;
    public static final Integer DEFAULT_POWERED_BY_TEXT_COLOR;
    public static final int DEFAULT_PROBABILITY_3D = 80;
    public static final long DEFAULT_RETURN_AD_MIN_BACKGROUND_TIME = 300;
    public static final int DEFAULT_TITLE_BG = -14803426;
    public static final String DEFAULT_TITLE_CONTENT = "Free Apps of the day";
    public static final Integer DEFAULT_TITLE_LINE_COLOR;
    public static final Integer DEFAULT_TITLE_TEXT_COLOR;
    public static final Set<String> DEFAULT_TITLE_TEXT_DECORATION;
    public static final Integer DEFAULT_TITLE_TEXT_SIZE;
    public static final String KEY_METADATA = "metaData";
    public static final String TEXT_DECORATION_BOLD = "BOLD";
    public static final String TEXT_DECORATION_ITALIC = "ITALIC";
    public static final String TEXT_DECORATION_UNDERLINE = "UNDERLINE";
    private static transient MetaData instance;
    private static transient Object lock;
    private static final long serialVersionUID = 1;
    private AdInformationConfig AdInformation = AdInformationConfig.a();
    private BannerOptions BannerOptions = new BannerOptions();
    private SplashConfig SplashConfig = new SplashConfig();
    private long adCacheTTL = 172800;
    private String adClickURL = "http://www.startappexchange.com/tracking/adClick";
    private String adPlatformHost = "http://www.startappexchange.com/1.3/";
    private Integer backgroundGradientBottom = -14606047;
    private Integer backgroundGradientTop = -14606047;
    private boolean disableReturnAd = false;
    private boolean disableTwoClicks = false;
    private Integer fullpageOfferWallProbability = 50;
    private Integer fullpageOverlayProbability = 50;
    private Integer homeProbability3D = 80;
    private Integer itemDescriptionTextColor = MetaDataStyle.DEFAULT_ITEM_DESC_TEXT_COLOR;
    private Set<String> itemDescriptionTextDecoration = MetaDataStyle.DEFAULT_ITEM_DESC_TEXT_DECORATION;
    private Integer itemDescriptionTextSize = MetaDataStyle.DEFAULT_ITEM_DESC_TEXT_SIZE;
    private Integer itemGradientBottom = -8750199;
    private Integer itemGradientTop = -14014151;
    private Integer itemTitleTextColor = MetaDataStyle.DEFAULT_ITEM_TITLE_TEXT_COLOR;
    private Set<String> itemTitleTextDecoration = MetaDataStyle.DEFAULT_ITEM_TITLE_TEXT_DECORATION;
    private Integer itemTitleTextSize = MetaDataStyle.DEFAULT_ITEM_TITLE_TEXT_SIZE;
    private long lastUpdate = 0;
    private transient boolean loading = false;
    private Integer maxAds = 10;
    private transient List<p> metaDataListeners = new ArrayList<p>();
    private Long metaDataTTL = 86400;
    private Integer poweredByBackgroundColor = DEFAULT_POWERED_BY_BG;
    private Integer poweredByTextColor = DEFAULT_POWERED_BY_TEXT_COLOR;
    private Integer probability3D = 80;
    private long returnAdMinBackgroundTime = 300;
    private HashMap<String, MetaDataStyle> templates = new HashMap();
    private Integer titleBackgroundColor = -14803426;
    private String titleContent = "Free Apps of the day";
    private Integer titleLineColor = DEFAULT_TITLE_LINE_COLOR;
    private Integer titleTextColor = DEFAULT_TITLE_TEXT_COLOR;
    private Set<String> titleTextDecoration = DEFAULT_TITLE_TEXT_DECORATION;
    private Integer titleTextSize = DEFAULT_TITLE_TEXT_SIZE;
    private String version = "";

    static {
        instance = new MetaData();
        lock = new Object();
        DEFAULT_TITLE_TEXT_SIZE = 18;
        DEFAULT_TITLE_TEXT_COLOR = -1;
        DEFAULT_TITLE_TEXT_DECORATION = new HashSet<String>(Arrays.asList("BOLD"));
        DEFAULT_TITLE_LINE_COLOR = -16777216;
        DEFAULT_POWERED_BY_BG = -14803426;
        DEFAULT_POWERED_BY_TEXT_COLOR = -1;
    }

    private MetaData() {
        this.getAdInformationConfig().f();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void failedLoading() {
        Object object = lock;
        synchronized (object) {
            if (MetaData.getInstance().metaDataListeners != null) {
                Iterator<p> iterator = MetaData.getInstance().metaDataListeners.iterator();
                while (iterator.hasNext()) {
                    iterator.next().onFailedLoadingMeta();
                }
                MetaData.getInstance().metaDataListeners.clear();
            }
            MetaData.getInstance().loading = false;
            return;
        }
    }

    public static MetaData getInstance() {
        return instance;
    }

    public static Object getLock() {
        return lock;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void init(Context object) {
        object = object.getSharedPreferences("com.startapp.android.publish", 0);
        instance = (object = (MetaData)new Gson().fromJson(object.getString("metaData", ""), MetaData.class)) != null ? object : new Object();
        MetaData.getInstance().getAdInformationConfig().f();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void update(Context object, MetaData object2) {
        Object object3 = lock;
        synchronized (object3) {
            object2.setVersion(b.a);
            object2.metaDataListeners = MetaData.getInstance().metaDataListeners;
            instance = object2;
            if (b.DEBUG.booleanValue()) {
                j.a(3, "MetaData received:");
                j.a(3, new Gson().toJson(object2));
            }
            AdInformationConfig.a(MetaData.getInstance().AdInformation);
            MetaData.getInstance().lastUpdate = System.currentTimeMillis();
            object = object.getSharedPreferences("com.startapp.android.publish", 0).edit();
            object2 = new Gson().toJson(MetaData.getInstance());
            object.putString("metaData", (String)object2);
            object.commit();
            j.a(3, "MetaData saved:");
            j.a(3, (String)object2);
            MetaData.getInstance().getAdInformationConfig().f();
            if (MetaData.getInstance().metaDataListeners != null) {
                object = MetaData.getInstance().metaDataListeners.iterator();
                while (object.hasNext()) {
                    ((p)object.next()).onFinishLoadingMeta();
                }
                MetaData.getInstance().metaDataListeners.clear();
            }
            MetaData.getInstance().loading = false;
            return;
        }
    }

    public void addMetaDataListener(p p2) {
        this.metaDataListeners.add(p2);
    }

    public long getAdCacheTtl() {
        return TimeUnit.SECONDS.toMillis(this.adCacheTTL);
    }

    public String getAdClickUrl() {
        return this.adClickURL;
    }

    public AdInformationConfig getAdInformationConfig() {
        return this.AdInformation;
    }

    public String getAdPlatformHost() {
        if (b.OVERRIDE_HOST != null) {
            return b.OVERRIDE_HOST;
        }
        return this.adPlatformHost;
    }

    public int getBackgroundGradientBottom() {
        return this.backgroundGradientBottom;
    }

    public int getBackgroundGradientTop() {
        return this.backgroundGradientTop;
    }

    public BannerOptions getBannerOptions() {
        return this.BannerOptions;
    }

    public int getFullscreenOverlayProbability() {
        return this.fullpageOverlayProbability;
    }

    public int getHomeProbability3D() {
        return this.homeProbability3D;
    }

    public int getHtml3DProbability() {
        return this.fullpageOfferWallProbability;
    }

    public Integer getItemDescriptionTextColor() {
        return this.itemDescriptionTextColor;
    }

    public Set<String> getItemDescriptionTextDecoration() {
        return this.itemDescriptionTextDecoration;
    }

    public Integer getItemDescriptionTextSize() {
        return this.itemDescriptionTextSize;
    }

    public int getItemGradientBottom() {
        return this.itemGradientBottom;
    }

    public int getItemGradientTop() {
        return this.itemGradientTop;
    }

    public Integer getItemTitleTextColor() {
        return this.itemTitleTextColor;
    }

    public Set<String> getItemTitleTextDecoration() {
        return this.itemTitleTextDecoration;
    }

    public Integer getItemTitleTextSize() {
        return this.itemTitleTextSize;
    }

    public int getMaxAds() {
        return this.maxAds;
    }

    public Integer getPoweredByBackgroundColor() {
        return this.poweredByBackgroundColor;
    }

    public Integer getPoweredByTextColor() {
        return this.poweredByTextColor;
    }

    public int getProbability3D() {
        return this.probability3D;
    }

    public long getReturnAdMinBackgroundTime() {
        return TimeUnit.SECONDS.toMillis(this.returnAdMinBackgroundTime);
    }

    public SplashConfig getSplashConfig() {
        return this.SplashConfig;
    }

    public MetaDataStyle getTemplate(String string2) {
        return this.templates.get(string2);
    }

    public Integer getTitleBackgroundColor() {
        return this.titleBackgroundColor;
    }

    public String getTitleContent() {
        return this.titleContent;
    }

    public Integer getTitleLineColor() {
        return this.titleLineColor;
    }

    public Integer getTitleTextColor() {
        return this.titleTextColor;
    }

    public Set<String> getTitleTextDecoration() {
        return this.titleTextDecoration;
    }

    public Integer getTitleTextSize() {
        return this.titleTextSize;
    }

    public boolean isDisableReturnAd() {
        return this.disableReturnAd;
    }

    public boolean isDisableTwoClicks() {
        return this.disableTwoClicks;
    }

    public boolean isLoading() {
        return this.loading;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean isReady() {
        boolean bl = System.currentTimeMillis() - this.lastUpdate < TimeUnit.SECONDS.toMillis(this.metaDataTTL);
        boolean bl2 = b.a.equals(this.version);
        if (bl && bl2) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void loadFromServer(Context context, AdPreferences adPreferences, boolean bl, p p2) {
        void var3_3;
        void var4_4;
        if (var3_3 == false && var4_4 != null) {
            var4_4.onFinishLoadingMeta();
        }
        Object object = lock;
        synchronized (object) {
            if (!MetaData.getInstance().isReady()) {
                if (!MetaData.getInstance().isLoading()) {
                    void var2_2;
                    this.loading = true;
                    new h(context, (AdPreferences)var2_2).a();
                }
                if (var3_3 == false || var4_4 == null) return;
                {
                    MetaData.getInstance().addMetaDataListener((p)var4_4);
                }
                return;
            } else {
                // MONITOREXIT [1, 5] lbl13 : MonitorExitStatement: MONITOREXIT : var5_5
                if (var3_3 == false || var4_4 == null) return;
                {
                    var4_4.onFinishLoadingMeta();
                    return;
                }
            }
        }
    }

    public void setVersion(String string2) {
        this.version = string2;
    }
}

