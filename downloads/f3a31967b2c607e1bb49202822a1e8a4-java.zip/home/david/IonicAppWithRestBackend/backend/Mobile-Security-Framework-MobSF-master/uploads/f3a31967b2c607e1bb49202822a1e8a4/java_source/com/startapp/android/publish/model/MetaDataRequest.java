/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.model;

import com.startapp.android.publish.model.BaseRequest;

public class MetaDataRequest
extends BaseRequest {
}

