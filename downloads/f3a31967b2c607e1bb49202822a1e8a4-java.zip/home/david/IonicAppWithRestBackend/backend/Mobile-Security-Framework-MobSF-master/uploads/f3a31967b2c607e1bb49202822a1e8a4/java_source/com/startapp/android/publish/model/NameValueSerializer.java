/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.model;

import com.startapp.android.publish.model.NameValueObject;
import java.util.List;

public interface NameValueSerializer {
    public List<NameValueObject> getNameValueMap();
}

