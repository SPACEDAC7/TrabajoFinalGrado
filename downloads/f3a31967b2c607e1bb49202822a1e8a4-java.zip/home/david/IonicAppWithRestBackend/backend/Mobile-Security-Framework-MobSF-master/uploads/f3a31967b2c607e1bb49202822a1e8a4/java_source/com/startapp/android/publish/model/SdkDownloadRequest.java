/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.model;

import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.BaseRequest;
import com.startapp.android.publish.model.NameValueObject;
import java.util.ArrayList;
import java.util.List;

public class SdkDownloadRequest
extends BaseRequest {
    private static final String PLACEMENT = "INAPP_DOWNLOAD";

    @Override
    public List<NameValueObject> getNameValueMap() {
        List<NameValueObject> list;
        List<NameValueObject> list2 = list = super.getNameValueMap();
        if (list == null) {
            list2 = new ArrayList<NameValueObject>();
        }
        r.a(list2, "placement", (Object)"INAPP_DOWNLOAD", true);
        return list2;
    }
}

