/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.os.Handler
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.startapp.android.publish.nativead;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import com.startapp.android.publish.g.f;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdDetails;
import com.startapp.android.publish.nativead.NativeAdInterface;
import com.startapp.android.publish.nativead.NativeAdPreferences;
import com.startapp.android.publish.nativead.StartAppNativeAd;

public class NativeAdDetails
implements Parcelable,
f.a,
NativeAdInterface {
    public static final Parcelable.Creator<NativeAdDetails> CREATOR = new Parcelable.Creator<NativeAdDetails>(){

        public final NativeAdDetails a(Parcel parcel) {
            return new NativeAdDetails(parcel);
        }

        public final NativeAdDetails[] a(int n2) {
            return new NativeAdDetails[n2];
        }

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return this.a(parcel);
        }

        public final /* synthetic */ Object[] newArray(int n2) {
            return this.a(n2);
        }
    };
    private AdDetails a;
    private int b;
    private Bitmap c;
    private boolean d = false;
    private a e;

    public NativeAdDetails(Parcel parcel) {
        if (parcel.readInt() == 1) {
            this.a = (AdDetails)parcel.readParcelable(AdDetails.class.getClassLoader());
        }
        if (parcel.readInt() == 1) {
            this.a((Bitmap)parcel.readParcelable(Bitmap.class.getClassLoader()));
        }
        int n2 = parcel.readInt();
        this.d = false;
        if (n2 == 1) {
            this.d = true;
        }
        this.b = parcel.readInt();
    }

    public NativeAdDetails(AdDetails adDetails, NativeAdPreferences nativeAdPreferences, int n2, a a2) {
        j.a("StartAppNativeAd", 3, "Initializiang SingleAd [" + n2 + "]");
        this.a = adDetails;
        this.b = n2;
        this.e = a2;
        if (nativeAdPreferences.isAutoBitmapDownload()) {
            new f(this.getImageUrl(), this, n2).a();
            return;
        }
        this.a();
    }

    private void a() {
        new Handler().post(new Runnable(){

            @Override
            public void run() {
                j.a("StartAppNativeAd", 3, "SingleAd [" + NativeAdDetails.this.b + "] Loaded");
                if (NativeAdDetails.this.e != null) {
                    NativeAdDetails.this.e.onNativeAdDetailsLoaded(NativeAdDetails.this.b);
                }
            }
        });
    }

    private void a(Bitmap bitmap) {
        this.c = bitmap;
    }

    @Override
    public void a(Bitmap bitmap, int n2) {
        this.c = bitmap;
        this.a();
    }

    public int describeContents() {
        return 0;
    }

    @Override
    public StartAppNativeAd.b getCampaignAction() {
        StartAppNativeAd.b b2;
        StartAppNativeAd.b b3 = b2 = StartAppNativeAd.b.b;
        if (this.a != null) {
            b3 = b2;
            if (this.a.isCPE()) {
                b3 = StartAppNativeAd.b.a;
            }
        }
        return b3;
    }

    @Override
    public String getCategory() {
        String string2 = "";
        if (this.a != null) {
            string2 = this.a.getCategory();
        }
        return string2;
    }

    @Override
    public String getDescription() {
        String string2 = "";
        if (this.a != null) {
            string2 = this.a.getDescription();
        }
        return string2;
    }

    @Override
    public Bitmap getImageBitmap() {
        return this.c;
    }

    @Override
    public String getImageUrl() {
        String string2 = "http://www.dummy.com";
        if (this.a != null) {
            string2 = this.a.getImageUrl();
        }
        return string2;
    }

    @Override
    public String getInstalls() {
        String string2 = "";
        if (this.a != null) {
            string2 = this.a.getInstalls();
        }
        return string2;
    }

    @Override
    public String getPackacgeName() {
        String string2 = "";
        if (this.a != null) {
            string2 = this.a.getPackageName();
        }
        return string2;
    }

    @Override
    public float getRating() {
        float f2 = 5.0f;
        if (this.a != null) {
            f2 = this.a.getRating();
        }
        return f2;
    }

    @Override
    public String getTitle() {
        String string2 = "";
        if (this.a != null) {
            string2 = this.a.getTitle();
        }
        return string2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void sendClick(Context context) {
        if (this.a == null) return;
        switch (.a[this.getCampaignAction().ordinal()]) {
            default: {
                return;
            }
            case 1: {
                if (this.a.isSmartRedirect()) {
                    r.a(context, this.a.getClickUrl(), this.a.getTrackingClickUrl(), 5000);
                    return;
                }
                r.a(context, this.a.getClickUrl(), this.a.getTrackingClickUrl());
                return;
            }
            case 2: 
        }
        r.a(this.getPackacgeName(), this.a.getIntentDetails(), this.a.getClickUrl(), context);
    }

    @Override
    public void sendImpression(Context context) {
        if (!this.d) {
            this.d = true;
            if (this.a == null) {
                return;
            }
            j.a("StartAppNativeAd", 3, "Sending Impression for [" + this.b + "]");
            r.b(context, this.a.getTrackingUrl());
            return;
        }
        j.a("StartAppNativeAd", 3, "Already sent impression for [" + this.b + "]");
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("         Title: [" + this.getTitle() + "]\n");
        stringBuffer.append("         Description: [" + this.getDescription().substring(0, 30) + "]...\n");
        stringBuffer.append("         Rating: [" + this.getRating() + "]\n");
        stringBuffer.append("         Installs: [" + this.getInstalls() + "]\n");
        stringBuffer.append("         Category: [" + this.getCategory() + "]\n");
        stringBuffer.append("         PackageName: [" + this.getPackacgeName() + "]\n");
        stringBuffer.append("         CampaginAction: [" + (Object)((Object)this.getCampaignAction()) + "]\n");
        return stringBuffer.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void writeToParcel(Parcel parcel, int n2) {
        int n3 = 0;
        int n4 = this.a != null ? 1 : 0;
        int n5 = this.getImageBitmap() != null ? 1 : 0;
        if (this.d) {
            n3 = 1;
        }
        parcel.writeInt(n4);
        if (n4 == 1) {
            parcel.writeParcelable((Parcelable)this.a, n2);
        }
        parcel.writeInt(n5);
        if (n5 == 1) {
            parcel.writeParcelable((Parcelable)this.getImageBitmap(), n2);
        }
        parcel.writeInt(n3);
        parcel.writeInt(this.b);
    }

    public static interface a {
        public void onNativeAdDetailsLoaded(int var1);
    }

}

