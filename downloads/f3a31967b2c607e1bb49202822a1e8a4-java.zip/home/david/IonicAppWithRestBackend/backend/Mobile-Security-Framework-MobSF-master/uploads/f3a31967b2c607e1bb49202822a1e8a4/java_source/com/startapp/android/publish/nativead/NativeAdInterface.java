/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 */
package com.startapp.android.publish.nativead;

import android.content.Context;
import android.graphics.Bitmap;
import com.startapp.android.publish.nativead.StartAppNativeAd;

public interface NativeAdInterface {
    public StartAppNativeAd.b getCampaignAction();

    public String getCategory();

    public String getDescription();

    public Bitmap getImageBitmap();

    public String getImageUrl();

    public String getInstalls();

    public String getPackacgeName();

    public float getRating();

    public String getTitle();

    public void sendClick(Context var1);

    public void sendImpression(Context var1);
}

