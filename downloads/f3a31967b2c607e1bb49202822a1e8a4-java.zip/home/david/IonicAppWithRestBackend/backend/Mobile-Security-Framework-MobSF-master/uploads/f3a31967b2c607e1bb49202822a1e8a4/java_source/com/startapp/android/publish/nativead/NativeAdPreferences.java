/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.nativead;

import com.startapp.android.publish.model.AdPreferences;

public class NativeAdPreferences
extends AdPreferences {
    private static final int DEFAULT_ADS_NUMBER = 1;
    private static final boolean DEFAULT_AUTO_DOWNLOAD_BITMAP = false;
    private static final NativeAdBitmapSize DEFAULT_BITMAP_SIZE;
    private static final boolean DEFAULT_USE_SIMPLE_TOKEN = true;
    private static String EXCEPTION_LOW_ADS_NUMBER;
    private static final long serialVersionUID = 1;
    private int adsNumber = 1;
    private boolean autoBitmapDownload = false;
    private NativeAdBitmapSize bitmapSize = DEFAULT_BITMAP_SIZE;
    private boolean useSimpleToken = true;

    static {
        EXCEPTION_LOW_ADS_NUMBER = "Ads Number must be >= 1";
        DEFAULT_BITMAP_SIZE = NativeAdBitmapSize.SIZE150X150;
    }

    public int getAdsNumber() {
        return this.adsNumber;
    }

    public NativeAdBitmapSize getImageSize() {
        return this.bitmapSize;
    }

    public boolean isAutoBitmapDownload() {
        return this.autoBitmapDownload;
    }

    @Override
    public boolean isSimpleToken() {
        return this.useSimpleToken;
    }

    public NativeAdPreferences setAdsNumber(int n2) {
        if (n2 <= 0) {
            throw new IllegalArgumentException(EXCEPTION_LOW_ADS_NUMBER);
        }
        this.adsNumber = n2;
        return this;
    }

    public NativeAdPreferences setAutoBitmapDownload(boolean bl) {
        this.autoBitmapDownload = bl;
        return this;
    }

    public NativeAdPreferences setImageSize(NativeAdBitmapSize nativeAdBitmapSize) {
        this.bitmapSize = nativeAdBitmapSize;
        return this;
    }

    @Override
    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("\n===== NativeAdConfig =====\n");
        stringBuffer.append("    adsNumber: [" + this.getAdsNumber() + "]\n");
        stringBuffer.append("    autoBitmapDownload: [" + this.isAutoBitmapDownload() + "]\n");
        stringBuffer.append("    bitmapSize: [" + (Object)((Object)this.getImageSize()) + "]\n");
        stringBuffer.append("    useSimpleToken: [" + this.isSimpleToken() + "]\n");
        stringBuffer.append("===== End NativeAdConfig =====");
        return stringBuffer.toString();
    }

    public NativeAdPreferences useSimpleToken(boolean bl) {
        this.useSimpleToken = bl;
        return this;
    }

    public static enum NativeAdBitmapSize {
        SIZE72X72(72, 72),
        SIZE100X100(100, 100),
        SIZE150X150(150, 150),
        SIZE340X340(340, 340);
        
        int height;
        int width;

        private NativeAdBitmapSize(int n3, int n4) {
            this.width = n3;
            this.height = n4;
        }

        public final int getHeight() {
            return this.height;
        }

        public final int getWidth() {
            return this.width;
        }
    }

}

