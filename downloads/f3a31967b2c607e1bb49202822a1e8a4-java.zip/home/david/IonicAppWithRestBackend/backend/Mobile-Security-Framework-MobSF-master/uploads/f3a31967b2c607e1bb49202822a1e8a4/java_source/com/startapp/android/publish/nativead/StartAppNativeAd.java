/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.startapp.android.publish.nativead;

import android.content.Context;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.g;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.model.AdDetails;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.nativead.NativeAdDetails;
import com.startapp.android.publish.nativead.NativeAdPreferences;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class StartAppNativeAd
extends Ad
implements NativeAdDetails.a {
    private static final String TAG = "StartAppNativeAd";
    private a adEventDelegate;
    private List<NativeAdDetails> listNativeAds = new ArrayList<NativeAdDetails>();
    private g nativeAds;
    private NativeAdPreferences preferences;
    private int totalObjectsLoaded = 0;

    public StartAppNativeAd(Context context) {
        super(context);
    }

    private NativeAdPreferences getPreferences() {
        return this.preferences;
    }

    private void initNativeAdList() {
        this.totalObjectsLoaded = 0;
        this.listNativeAds.clear();
        for (int i2 = 0; i2 < this.getPreferences().getAdsNumber(); ++i2) {
            NativeAdDetails nativeAdDetails = new NativeAdDetails(this.nativeAds.a().get(i2), this.getPreferences(), i2, this);
            this.listNativeAds.add(nativeAdDetails);
        }
    }

    private void onNativeAdLoaded() {
        j.a("StartAppNativeAd", 3, "Ad Loaded successfully");
        if (this.adEventDelegate != null) {
            j.a("StartAppNativeAd", 3, "Calling original RecienedAd callback");
            AdEventListener adEventListener = this.adEventDelegate.a();
            if (adEventListener != null) {
                adEventListener.onReceiveAd(this);
            }
        }
    }

    private void setPreferences(NativeAdPreferences nativeAdPreferences) {
        this.preferences = nativeAdPreferences;
    }

    public ArrayList<NativeAdDetails> getNativeAds() {
        ArrayList<NativeAdDetails> arrayList = new ArrayList<NativeAdDetails>();
        Iterator<NativeAdDetails> iterator = this.listNativeAds.iterator();
        while (iterator.hasNext()) {
            arrayList.add(iterator.next());
        }
        return arrayList;
    }

    public int getNumberOfAds() {
        return this.getPreferences().getAdsNumber();
    }

    public boolean loadAd() {
        return this.loadAd(new NativeAdPreferences(), null);
    }

    public boolean loadAd(AdEventListener adEventListener) {
        return this.loadAd(new NativeAdPreferences(), adEventListener);
    }

    public boolean loadAd(NativeAdPreferences nativeAdPreferences) {
        return this.loadAd(nativeAdPreferences, null);
    }

    public boolean loadAd(NativeAdPreferences nativeAdPreferences, AdEventListener adEventListener) {
        j.a("StartAppNativeAd", 3, "Start loading StartAppNativeAd");
        this.adEventDelegate = new a(adEventListener);
        j.a("StartAppNativeAd", 3, "Cofigurtaion: " + this.preferences);
        this.setPreferences(nativeAdPreferences);
        this.nativeAds = new g(this.context, this.getPreferences());
        return this.nativeAds.load(nativeAdPreferences, this.adEventDelegate);
    }

    @Override
    protected void loadAds(AdPreferences adPreferences, AdEventListener adEventListener) {
    }

    @Override
    public void onNativeAdDetailsLoaded(int n2) {
        ++this.totalObjectsLoaded;
        if (this.totalObjectsLoaded == this.getPreferences().getAdsNumber()) {
            this.onNativeAdLoaded();
        }
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("\n===== StartAppNativeAd =====\n");
        for (int i2 = 0; i2 < this.getNumberOfAds(); ++i2) {
            stringBuffer.append(this.listNativeAds.get(i2));
        }
        stringBuffer.append("===== End StartAppNativeAd =====");
        return stringBuffer.toString();
    }

    class a
    implements AdEventListener {
        private AdEventListener b;

        public a(AdEventListener adEventListener) {
            this.b = null;
            this.b = adEventListener;
        }

        public AdEventListener a() {
            return this.b;
        }

        @Override
        public void onFailedToReceiveAd(Ad ad) {
            j.a("StartAppNativeAd", 3, "NativeAd Failed to load");
            if (this.b != null) {
                this.b.onFailedToReceiveAd(StartAppNativeAd.this);
                this.b = null;
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void onReceiveAd(Ad ad) {
            j.a("StartAppNativeAd", 3, "NativeAd Received");
            if (StartAppNativeAd.this.nativeAds != null && StartAppNativeAd.this.nativeAds.a() != null) {
                StartAppNativeAd.this.preferences.setAdsNumber(StartAppNativeAd.this.nativeAds.a().size());
            } else {
                StartAppNativeAd.this.preferences.setAdsNumber(0);
            }
            StartAppNativeAd.this.initNativeAdList();
        }
    }

    public static enum b {
        a,
        b;
        

        private b() {
        }
    }

}

