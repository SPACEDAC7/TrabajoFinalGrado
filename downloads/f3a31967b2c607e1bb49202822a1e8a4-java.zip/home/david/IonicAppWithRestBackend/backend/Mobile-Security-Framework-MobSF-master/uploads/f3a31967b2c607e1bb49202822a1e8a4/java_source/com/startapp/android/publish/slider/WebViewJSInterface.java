/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  android.webkit.JavascriptInterface
 */
package com.startapp.android.publish.slider;

import android.content.Context;
import android.text.TextUtils;
import android.webkit.JavascriptInterface;
import com.startapp.android.publish.g.h;
import com.startapp.android.publish.slider.a;
import java.util.ArrayList;

public class WebViewJSInterface {
    private Context mContext;
    private String trackingUrl;

    public WebViewJSInterface(Context context) {
        this.mContext = context;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void megreTackingUrls(String arrstring) {
        ArrayList<String> arrayList = new ArrayList<String>();
        if (arrstring == null) return;
        if ((arrstring = arrstring.split(",")).length == 1) {
            this.trackingUrl = arrstring[0];
            return;
        }
        arrstring[0].split("tracking/adImpression")[0] + "tracking/adImpression";
        for (String string2 : arrstring) {
            arrayList.add("d=" + string2.split("tracking/adImpression[?]d=")[1]);
        }
        this.trackingUrl = "http://www.startappexchange.com/tracking/adImpression?" + TextUtils.join((CharSequence)"&", arrayList);
    }

    /*
     * Enabled aggressive block sorting
     */
    private String substringBetween(String string2, String string3, String string4) {
        int n2;
        int n3;
        if (string2 == null || string3 == null || string4 == null || (n3 = string2.indexOf(string3)) == -1 || (n2 = string2.indexOf(string4, string3.length() + n3)) == -1) {
            return null;
        }
        return string2.substring(string3.length() + n3, n2);
    }

    public String getTrackingUrl() {
        return this.trackingUrl;
    }

    @JavascriptInterface
    public void processHTML(String string2) {
        this.megreTackingUrls(this.substringBetween(string2, "@tracking@", "@tracking@"));
        if (this.trackingUrl != null) {
            h.b(this.mContext, "trackingUrl", this.trackingUrl);
        }
    }

    @JavascriptInterface
    public void processServerEvent(String string2) {
        if (h.a(this.mContext, "slideEvent", false).booleanValue() && !h.a(this.mContext, "trackingEvent", false).booleanValue()) {
            this.megreTackingUrls(this.substringBetween(string2, "@tracking@", "@tracking@"));
            if (this.trackingUrl != null) {
                h.b(this.mContext, "trackingUrl", this.trackingUrl);
                new a(this.mContext).a("");
            }
        }
    }
}

