/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Process
 */
package com.startapp.android.publish.slider;

import android.content.Context;
import android.os.Process;
import com.startapp.android.publish.g.c;
import com.startapp.android.publish.g.h;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.o;

public class a {
    private Context a;

    public a(Context context) {
        this.a = context;
    }

    private boolean b(String string2) {
        if (string2 != null) {
            try {
                com.startapp.android.publish.f.a.a(this.a, string2 + c.a(), null);
                return true;
            }
            catch (o var1_2) {
                j.a(6, "Unable to send tracking event in GetSearchBoxService!!!!", var1_2);
            }
        }
        return false;
    }

    protected /* varargs */ Boolean a(String ... object) {
        if (!h.a(this.a, "slideEvent", true).booleanValue() && object != null && object.length > 0) {
            h.b(this.a, "slideEvent", this.b(object[0]));
        }
        if (!h.a(this.a, "trackingEvent", true).booleanValue()) {
            object = h.a(this.a, "trackingUrl", null);
            h.b(this.a, "trackingEvent", this.b((String)object));
        }
        return true;
    }

    public void a(final String string2) {
        new Thread(new Runnable(){

            @Override
            public void run() {
                Process.setThreadPriority((int)10);
                a.this.a(new String[]{string2});
            }
        }).start();
    }

}

