/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Paint
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.IBinder
 *  android.view.KeyEvent
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.animation.Animation
 *  android.view.animation.Animation$AnimationListener
 *  android.view.animation.TranslateAnimation
 *  android.view.inputmethod.InputMethodManager
 *  android.webkit.WebChromeClient
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.ImageButton
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 */
package com.startapp.android.publish.slider;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.a.l;
import com.startapp.android.publish.adinformation.a;
import com.startapp.android.publish.g.c;
import com.startapp.android.publish.g.e;
import com.startapp.android.publish.g.h;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.AdDetails;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.model.MetaData;
import com.startapp.android.publish.slider.WebViewJSInterface;
import com.startapp.android.publish.slider.sliding.DrawerLayout;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class b {
    private static boolean i = false;
    private Activity a;
    private WebView b;
    private DrawerLayout c;
    private Handler d = new Handler();
    private l e;
    private int f = 0;
    private Handler g = new Handler();
    private com.startapp.android.publish.adinformation.b h = com.startapp.android.publish.adinformation.b.a();

    public b(Activity activity) {
        this(activity, new AdPreferences());
    }

    public b(Activity activity, AdPreferences adPreferences) {
        j.a("Slider", 3, "new Slider Created");
        this.a = activity;
        this.e = new l(activity);
        this.e.a(adPreferences, new AdEventListener(){

            @Override
            public void onFailedToReceiveAd(Ad ad) {
                j.a("Slider", 6, "Error loading Slider");
            }

            @Override
            public void onReceiveAd(Ad ad) {
                j.a("Slider", 3, "Slider loaded");
                b.this.b();
                b.this.d();
            }
        });
    }

    private void b() {
        this.b = new WebView((Context)this.a()){

            /*
             * Enabled aggressive block sorting
             */
            public boolean onKeyDown(int n2, KeyEvent keyEvent) {
                if (keyEvent.getAction() != 0) return super.onKeyDown(n2, keyEvent);
                switch (n2) {
                    default: {
                        return super.onKeyDown(n2, keyEvent);
                    }
                    case 4: 
                }
                if (b.this.b != null && b.this.b.canGoBack()) {
                    b.this.b.goBack();
                    return true;
                }
                if (b.this.c == null) return true;
                b.this.c.b();
                return true;
            }
        };
        this.b.setOnTouchListener(new View.OnTouchListener(){

            public boolean onTouch(View view, MotionEvent motionEvent) {
                b.this.c.requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
        Object object = new WebViewJSInterface((Context)this.a);
        this.b.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
        this.b.getSettings().setJavaScriptEnabled(true);
        this.b.addJavascriptInterface(object, "HTMLOUT");
        this.b.setWebChromeClient(new WebChromeClient());
        this.b.setHorizontalScrollBarEnabled(false);
        this.b.setVerticalScrollBarEnabled(true);
        if (Build.VERSION.SDK_INT > 10) {
            this.b.setLayerType(1, null);
        }
        this.b.setWebViewClient((WebViewClient)new a());
        object = this.e.a().get(0).getClickUrl() + this.c() + "&ver=" + com.startapp.android.publish.b.a;
        j.a(3, "Slider URL: " + (String)object);
        this.b.loadUrl((String)object);
    }

    private String c() {
        String string2 = r.d((Context)this.a());
        if (string2 != null && !"".equals(string2)) {
            return "&token=" + string2;
        }
        return "";
    }

    /*
     * Enabled aggressive block sorting
     */
    private void d() {
        if (r.a((Context)this.a())) {
            ViewGroup viewGroup = (ViewGroup)this.a.findViewById(16908290);
            View view = viewGroup.getChildAt(0);
            viewGroup.removeView(view);
            this.c = new DrawerLayout((Context)this.a());
            final RelativeLayout relativeLayout = new RelativeLayout((Context)this.a);
            relativeLayout.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
            relativeLayout.addView(view);
            view = new ImageButton((Context)this.a);
            if (Build.VERSION.SDK_INT >= 16) {
                view.setBackground(null);
            } else {
                view.setBackgroundDrawable(null);
            }
            view.setPadding(0, 0, r.a((Context)this.a, 10), 0);
            Object object = new RelativeLayout.LayoutParams(-2, -2);
            object.addRule(15);
            view.setLayoutParams((ViewGroup.LayoutParams)object);
            view.setImageBitmap(e.a((Context)this.a, "tab_side.png"));
            object = new TranslateAnimation(1, 0.0f, 1, 0.0f, 1, -0.07f, 1, 0.07f);
            TranslateAnimation translateAnimation = new TranslateAnimation(1, 0.0f, 1, 0.0f, 1, 0.07f, 1, -0.07f);
            object.setDuration(40);
            translateAnimation.setDuration(40);
            new Runnable((ImageButton)view, (TranslateAnimation)object){
                final /* synthetic */ ImageButton a;
                final /* synthetic */ TranslateAnimation b;

                @Override
                public void run() {
                    this.a.startAnimation((Animation)this.b);
                }
            };
            object.setAnimationListener(new Animation.AnimationListener((ImageButton)view, translateAnimation){
                final /* synthetic */ ImageButton a;
                final /* synthetic */ TranslateAnimation b;

                public void onAnimationEnd(Animation animation) {
                    this.a.startAnimation((Animation)this.b);
                }

                public void onAnimationRepeat(Animation animation) {
                }

                public void onAnimationStart(Animation animation) {
                }
            });
            translateAnimation.setAnimationListener(new Animation.AnimationListener((ImageButton)view, (TranslateAnimation)object){
                final /* synthetic */ ImageButton a;
                final /* synthetic */ TranslateAnimation b;

                public void onAnimationEnd(Animation animation) {
                    b.e(b.this);
                    if (b.this.f > 12) {
                        b.this.f = 0;
                        return;
                    }
                    this.a.startAnimation((Animation)this.b);
                }

                public void onAnimationRepeat(Animation animation) {
                }

                public void onAnimationStart(Animation animation) {
                }
            });
            relativeLayout.addView(view);
            if (!i) {
                i = true;
                this.g.postDelayed(new Runnable((ImageButton)view, (TranslateAnimation)object){
                    final /* synthetic */ ImageButton a;
                    final /* synthetic */ TranslateAnimation b;

                    @Override
                    public void run() {
                        this.a.startAnimation((Animation)this.b);
                    }
                }, 15000);
            }
            object = new DrawerLayout.c(-1, -1);
            this.c.setLayoutParams((ViewGroup.LayoutParams)object);
            this.c.addView((View)relativeLayout);
            relativeLayout = new RelativeLayout((Context)this.a());
            object = new DrawerLayout.c(r.a((Context)this.a, 290), -1);
            object.a = 3;
            relativeLayout.setLayoutParams((ViewGroup.LayoutParams)object);
            relativeLayout.addView((View)this.b);
            this.c.addView((View)relativeLayout);
            viewGroup.addView((View)this.c);
            new com.startapp.android.publish.adinformation.a((Context)this.a, a.b.b, AdPreferences.Placement.DEVICE_SIDEBAR, this.h).a(relativeLayout);
            view.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    b.this.c.h((View)relativeLayout);
                }
            });
            this.c.setDrawerListener(new DrawerLayout.b(){

                @Override
                public void a(int n2) {
                }

                @Override
                public void a(View view) {
                    b.this.e();
                }

                @Override
                public void a(View view, float f2) {
                }

                @Override
                public void b(View view) {
                    ((InputMethodManager)b.this.a().getSystemService("input_method")).hideSoftInputFromWindow(b.this.b.getWindowToken(), 0);
                }
            });
        }
    }

    static /* synthetic */ int e(b b2) {
        int n2 = b2.f;
        b2.f = n2 + 1;
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void e() {
        l l2 = this.e;
        if (h.a((Context)this.a(), "trackingUrl", null) == null) {
            try {
                this.b.loadUrl("javascript:window.HTMLOUT.processHTML(document.getElementById('SearchResults').innerHTML);");
            }
            catch (Throwable var2_2) {
                j.a("Slider", 6, "Error reading SearchResults div ", var2_2);
            }
        }
        new com.startapp.android.publish.slider.a((Context)this.a).a(l2.a().get(0).getTrackingUrl());
    }

    public Activity a() {
        return this.a;
    }

    class a
    extends WebViewClient {
        private a() {
        }

        public void onPageFinished(WebView webView, String string2) {
            j.a("Slider", 2, "MyWebViewClient::onPageFinished - [" + string2 + "]");
            super.onPageFinished(webView, string2);
        }

        public void onPageStarted(WebView webView, String string2, Bitmap bitmap) {
            j.a("Slider", 2, "MyWebViewClient::onPageStarted - [" + string2 + "]");
            super.onPageStarted(webView, string2, bitmap);
        }

        public void onReceivedError(WebView webView, int n2, String string2, final String string3) {
            b.this.b.loadUrl("file://" + b.this.a().getFilesDir().getPath() + "/error.html");
            j.a("Slider", 2, "MyWebViewClient::onReceivedError - [" + string2 + "], [" + string3 + "]");
            b.this.d.postDelayed(new Runnable(){

                @Override
                public void run() {
                    b.this.b.loadUrl(string3);
                }
            }, 5000);
            super.onReceivedError(webView, n2, string2, string3);
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public boolean shouldOverrideUrlLoading(WebView object, String string2) {
            String string3;
            j.a("Slider", 2, "MyWebViewClient::shouldOverrideUrlLoading - [" + string2 + "]");
            string3 = string2.toLowerCase();
            String string4 = b.this.e.a().get(0).getClickUrl();
            object = "searchmobileonline";
            try {
                object = string4 = new URL(string4).getHost();
            }
            catch (MalformedURLException var3_5) {}
            if (string3.contains((CharSequence)object)) {
                return false;
            }
            if (string3.contains(MetaData.getInstance().getAdClickUrl().toLowerCase())) {
                r.a((Context)b.this.a(), string2 + c.a(), null, 5000);
                return true;
            }
            r.d((Context)b.this.a(), string2);
            return true;
        }

    }

}

