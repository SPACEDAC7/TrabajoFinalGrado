/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.os.SystemClock
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.KeyEvent
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 *  android.view.accessibility.AccessibilityEvent
 */
package com.startapp.android.publish.slider.sliding;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import com.startapp.android.publish.slider.sliding.b.f;
import com.startapp.android.publish.slider.sliding.b.h;
import com.startapp.android.publish.slider.sliding.b.l;
import com.startapp.android.publish.slider.sliding.b.q;
import com.startapp.android.publish.slider.sliding.c;

public class DrawerLayout
extends ViewGroup {
    private static final int[] a = new int[]{16842931};
    private int b;
    private int c = -1728053248;
    private float d;
    private Paint e = new Paint();
    private final com.startapp.android.publish.slider.sliding.c f;
    private final com.startapp.android.publish.slider.sliding.c g;
    private final d h;
    private final d i;
    private int j;
    private boolean k;
    private boolean l = true;
    private int m;
    private int n;
    private boolean o;
    private boolean p;
    private b q;
    private float r;
    private float s;
    private Drawable t;
    private Drawable u;

    public DrawerLayout(Context context) {
        this(context, null);
    }

    public DrawerLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public DrawerLayout(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        float f2 = this.getResources().getDisplayMetrics().density;
        this.b = (int)(64.0f * f2 + 0.5f);
        this.h = new d(3);
        this.i = new d(5);
        this.f = com.startapp.android.publish.slider.sliding.c.a(this, 0.5f, this.h);
        this.f.a(1);
        this.f.a(f2 *= 400.0f);
        this.h.a(this.f);
        this.g = com.startapp.android.publish.slider.sliding.c.a(this, 0.5f, this.i);
        this.g.a(2);
        this.g.a(f2);
        this.i.a(this.g);
        this.setFocusableInTouchMode(true);
        l.a((View)this, new a());
        q.a(this, false);
    }

    static String b(int n2) {
        if ((n2 & 3) == 3) {
            return "LEFT";
        }
        if ((n2 & 5) == 5) {
            return "RIGHT";
        }
        return Integer.toHexString(n2);
    }

    private boolean e() {
        int n2 = this.getChildCount();
        for (int i2 = 0; i2 < n2; ++i2) {
            if (!((c)this.getChildAt((int)i2).getLayoutParams()).c) continue;
            return true;
        }
        return false;
    }

    private boolean f() {
        if (this.g() != null) {
            return true;
        }
        return false;
    }

    private View g() {
        int n2 = this.getChildCount();
        for (int i2 = 0; i2 < n2; ++i2) {
            View view = this.getChildAt(i2);
            if (!this.g(view) || !this.j(view)) continue;
            return view;
        }
        return null;
    }

    private static boolean k(View view) {
        boolean bl = false;
        view = view.getBackground();
        boolean bl2 = bl;
        if (view != null) {
            bl2 = bl;
            if (view.getOpacity() == -1) {
                bl2 = true;
            }
        }
        return bl2;
    }

    public int a(View view) {
        int n2 = this.e(view);
        if (n2 == 3) {
            return this.m;
        }
        if (n2 == 5) {
            return this.n;
        }
        return 0;
    }

    View a() {
        int n2 = this.getChildCount();
        for (int i2 = 0; i2 < n2; ++i2) {
            View view = this.getChildAt(i2);
            if (!((c)view.getLayoutParams()).d) continue;
            return view;
        }
        return null;
    }

    View a(int n2) {
        int n3 = this.getChildCount();
        for (int i2 = 0; i2 < n3; ++i2) {
            View view = this.getChildAt(i2);
            if ((this.e(view) & 7) != (n2 & 7)) continue;
            return view;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(int n2, int n3) {
        com.startapp.android.publish.slider.sliding.c c2;
        if ((n3 = com.startapp.android.publish.slider.sliding.b.d.a(n3, l.b((View)this))) == 3) {
            this.m = n2;
        } else if (n3 == 5) {
            this.n = n2;
        }
        if (n2 != 0) {
            c2 = n3 == 3 ? this.f : this.g;
            c2.e();
        }
        switch (n2) {
            case 2: {
                c2 = this.a(n3);
                if (c2 == null) return;
                {
                    this.h((View)c2);
                    return;
                }
            }
            default: {
                return;
            }
            case 1: 
        }
        c2 = this.a(n3);
        if (c2 == null) return;
        {
            this.i((View)c2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void a(int n2, int n3, View view) {
        int n4 = 1;
        int n5 = this.f.a();
        int n6 = this.g.a();
        n2 = n4;
        if (n5 != 1) {
            n2 = n6 == 1 ? n4 : (n5 == 2 || n6 == 2 ? 2 : 0);
        }
        if (view != null && n3 == 0) {
            c c2 = (c)view.getLayoutParams();
            if (c2.b == 0.0f) {
                this.b(view);
            } else if (c2.b == 1.0f) {
                this.c(view);
            }
        }
        if (n2 != this.j) {
            this.j = n2;
            if (this.q != null) {
                this.q.a(n2);
            }
        }
    }

    void a(View view, float f2) {
        if (this.q != null) {
            this.q.a(view, f2);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    void a(boolean var1_1) {
        var5_2 = this.getChildCount();
        var3_3 = 0;
        var2_4 = 0;
        do {
            if (var3_3 >= var5_2) {
                this.h.a();
                this.i.a();
                if (var2_4 == 0) return;
                this.invalidate();
                return;
            }
            var6_6 = this.getChildAt(var3_3);
            var7_7 = (c)var6_6.getLayoutParams();
            var4_5 = var2_4;
            if (!this.g(var6_6)) ** GOTO lbl22
            if (!var1_1) ** GOTO lbl-1000
            var4_5 = var2_4;
            if (var7_7.c) lbl-1000: // 2 sources:
            {
                var4_5 = var6_6.getWidth();
                var2_4 = this.a(var6_6, 3) ? (var2_4 |= this.f.a(var6_6, - var4_5, var6_6.getTop())) : (var2_4 |= this.g.a(var6_6, this.getWidth(), var6_6.getTop()));
                var7_7.c = false;
                var4_5 = var2_4;
            }
lbl22: // 4 sources:
            ++var3_3;
            var2_4 = var4_5;
        } while (true);
    }

    boolean a(View view, int n2) {
        if ((this.e(view) & n2) == n2) {
            return true;
        }
        return false;
    }

    public void b() {
        this.a(false);
    }

    void b(View view) {
        c c2 = (c)view.getLayoutParams();
        if (c2.d) {
            c2.d = false;
            if (this.q != null) {
                this.q.b(view);
            }
            this.sendAccessibilityEvent(32);
        }
    }

    void b(View view, float f2) {
        c c2 = (c)view.getLayoutParams();
        if (f2 == c2.b) {
            return;
        }
        c2.b = f2;
        this.a(view, f2);
    }

    void c() {
        if (!this.p) {
            long l2 = SystemClock.uptimeMillis();
            MotionEvent motionEvent = MotionEvent.obtain((long)l2, (long)l2, (int)3, (float)0.0f, (float)0.0f, (int)0);
            int n2 = this.getChildCount();
            for (int i2 = 0; i2 < n2; ++i2) {
                this.getChildAt(i2).dispatchTouchEvent(motionEvent);
            }
            motionEvent.recycle();
            this.p = true;
        }
    }

    void c(View view) {
        c c2 = (c)view.getLayoutParams();
        if (!c2.d) {
            c2.d = true;
            if (this.q != null) {
                this.q.a(view);
            }
            view.sendAccessibilityEvent(32);
        }
    }

    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof c && super.checkLayoutParams(layoutParams)) {
            return true;
        }
        return false;
    }

    public void computeScroll() {
        int n2 = this.getChildCount();
        float f2 = 0.0f;
        for (int i2 = 0; i2 < n2; ++i2) {
            f2 = Math.max(f2, ((c)this.getChildAt((int)i2).getLayoutParams()).b);
        }
        this.d = f2;
        if (this.f.a(true) | this.g.a(true)) {
            l.a((View)this);
        }
    }

    float d(View view) {
        return ((c)view.getLayoutParams()).b;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected boolean drawChild(Canvas var1_1, View var2_2, long var3_3) {
        var12_4 = this.getHeight();
        var15_5 = this.f(var2_2);
        var7_6 = 0;
        var10_7 = 0;
        var6_8 = this.getWidth();
        var13_9 = var1_1.save();
        var8_10 = var6_8;
        if (!var15_5) ** GOTO lbl31
        var14_11 = this.getChildCount();
        var7_6 = var10_7;
        for (var9_12 = 0; var9_12 < var14_11; ++var9_12) {
            var17_14 = this.getChildAt(var9_12);
            if (var17_14 == var2_2 || var17_14.getVisibility() != 0 || !DrawerLayout.k(var17_14) || !this.g(var17_14) || var17_14.getHeight() < var12_4) ** GOTO lbl-1000
            if (this.a(var17_14, 3)) {
                var8_10 = var17_14.getRight();
                if (var8_10 > var7_6) {
                    var7_6 = var8_10;
                }
                var10_7 = var7_6;
                var8_10 = var6_8;
            } else {
                var8_10 = var11_13 = var17_14.getLeft();
                var10_7 = var7_6;
                if (var11_13 >= var6_8) lbl-1000: // 2 sources:
                {
                    var8_10 = var6_8;
                    var10_7 = var7_6;
                }
            }
            var6_8 = var8_10;
            var7_6 = var10_7;
        }
        var1_1.clipRect(var7_6, 0, var6_8, this.getHeight());
        var8_10 = var6_8;
lbl31: // 2 sources:
        var16_15 = super.drawChild(var1_1, var2_2, var3_3);
        var1_1.restoreToCount(var13_9);
        if (this.d > 0.0f && var15_5) {
            var6_8 = (int)((float)((this.c & -16777216) >>> 24) * this.d);
            var9_12 = this.c;
            this.e.setColor(var6_8 << 24 | var9_12 & 16777215);
            var1_1.drawRect((float)var7_6, 0.0f, (float)var8_10, (float)this.getHeight(), this.e);
            return var16_15;
        }
        if (this.t != null && this.a(var2_2, 3)) {
            var6_8 = this.t.getIntrinsicWidth();
            var7_6 = var2_2.getRight();
            var8_10 = this.f.b();
            var5_16 = Math.max(0.0f, Math.min((float)var7_6 / (float)var8_10, 1.0f));
            this.t.setBounds(var7_6, var2_2.getTop(), var6_8 + var7_6, var2_2.getBottom());
            this.t.setAlpha((int)(255.0f * var5_16));
            this.t.draw(var1_1);
            return var16_15;
        }
        if (this.u == null) return var16_15;
        if (this.a(var2_2, 5) == false) return var16_15;
        var6_8 = this.u.getIntrinsicWidth();
        var7_6 = var2_2.getLeft();
        var8_10 = this.getWidth();
        var9_12 = this.g.b();
        var5_17 = Math.max(0.0f, Math.min((float)(var8_10 - var7_6) / (float)var9_12, 1.0f));
        this.u.setBounds(var7_6 - var6_8, var2_2.getTop(), var7_6, var2_2.getBottom());
        this.u.setAlpha((int)(255.0f * var5_17));
        this.u.draw(var1_1);
        return var16_15;
    }

    int e(View view) {
        return com.startapp.android.publish.slider.sliding.b.d.a(((c)view.getLayoutParams()).a, l.b(view));
    }

    boolean f(View view) {
        if (((c)view.getLayoutParams()).a == 0) {
            return true;
        }
        return false;
    }

    boolean g(View view) {
        if ((com.startapp.android.publish.slider.sliding.b.d.a(((c)view.getLayoutParams()).a, l.b(view)) & 7) != 0) {
            return true;
        }
        return false;
    }

    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new c(-1, -1);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new c(this.getContext(), attributeSet);
    }

    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof c) {
            return new c((c)layoutParams);
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new c((ViewGroup.MarginLayoutParams)layoutParams);
        }
        return new c(layoutParams);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void h(View object) {
        if (!this.g((View)object)) {
            throw new IllegalArgumentException("View " + object + " is not a sliding drawer");
        }
        if (this.l) {
            object = (c)object.getLayoutParams();
            object.b = 1.0f;
            object.d = true;
        } else if (this.a((View)object, 3)) {
            this.f.a((View)object, 0, object.getTop());
        } else {
            this.g.a((View)object, this.getWidth() - object.getWidth(), object.getTop());
        }
        this.invalidate();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void i(View object) {
        if (!this.g((View)object)) {
            throw new IllegalArgumentException("View " + object + " is not a sliding drawer");
        }
        if (this.l) {
            object = (c)object.getLayoutParams();
            object.b = 0.0f;
            object.d = false;
        } else if (this.a((View)object, 3)) {
            this.f.a((View)object, - object.getWidth(), object.getTop());
        } else {
            this.g.a((View)object, this.getWidth(), object.getTop());
        }
        this.invalidate();
    }

    public boolean j(View view) {
        if (!this.g(view)) {
            throw new IllegalArgumentException("View " + (Object)view + " is not a drawer");
        }
        if (((c)view.getLayoutParams()).b > 0.0f) {
            return true;
        }
        return false;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.l = true;
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.l = true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean onInterceptTouchEvent(MotionEvent var1_1) {
        var5_2 = false;
        var4_3 = h.a(var1_1);
        var6_4 = this.f.a(var1_1);
        var7_5 = this.g.a(var1_1);
        switch (var4_3) {
            case 0: {
                var2_6 = var1_1.getX();
                var3_7 = var1_1.getY();
                this.r = var2_6;
                this.s = var3_7;
                var4_3 = this.d > 0.0f && this.f(this.f.e((int)var2_6, (int)var3_7)) != false ? 1 : 0;
            }
            case 2: {
                if (!this.f.d(3)) break;
                this.h.a();
                this.i.a();
                var4_3 = 0;
                ** GOTO lbl26
            }
            case 1: 
            case 3: {
                this.a(true);
                this.o = false;
                this.p = false;
            }
        }
        var4_3 = 0;
        ** GOTO lbl26
        this.o = false;
        this.p = false;
lbl26: // 3 sources:
        if ((var6_4 | var7_5) != false) return true;
        if (var4_3 != 0) return true;
        if (this.e() != false) return true;
        if (this.p == false) return var5_2;
        return true;
    }

    public boolean onKeyDown(int n2, KeyEvent keyEvent) {
        if (n2 == 4 && this.f()) {
            f.a(keyEvent);
            return true;
        }
        return super.onKeyDown(n2, keyEvent);
    }

    public boolean onKeyUp(int n2, KeyEvent keyEvent) {
        if (n2 == 4) {
            keyEvent = this.g();
            if (keyEvent != null && this.a((View)keyEvent) == 0) {
                this.b();
            }
            if (keyEvent != null) {
                return true;
            }
            return false;
        }
        return super.onKeyUp(n2, keyEvent);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onLayout(boolean bl, int n2, int n3, int n4, int n5) {
        this.k = true;
        int n6 = n4 - n2;
        int n7 = this.getChildCount();
        n4 = 0;
        do {
            if (n4 >= n7) {
                this.k = false;
                this.l = false;
                return;
            }
            View view = this.getChildAt(n4);
            if (view.getVisibility() != 8) {
                c c2 = (c)view.getLayoutParams();
                if (this.f(view)) {
                    view.layout(c2.leftMargin, c2.topMargin, c2.leftMargin + view.getMeasuredWidth(), c2.topMargin + view.getMeasuredHeight());
                } else {
                    float f2;
                    int n8;
                    int n9 = view.getMeasuredWidth();
                    int n10 = view.getMeasuredHeight();
                    if (this.a(view, 3)) {
                        n2 = - n9;
                        n8 = (int)((float)n9 * c2.b) + n2;
                        f2 = (float)(n9 + n8) / (float)n9;
                    } else {
                        n8 = n6 - (int)((float)n9 * c2.b);
                        f2 = (float)(n6 - n8) / (float)n9;
                    }
                    boolean bl2 = f2 != c2.b;
                    switch (c2.a & 112) {
                        default: {
                            view.layout(n8, c2.topMargin, n9 + n8, n10);
                            break;
                        }
                        case 80: {
                            n2 = n5 - n3;
                            view.layout(n8, n2 - c2.bottomMargin - view.getMeasuredHeight(), n9 + n8, n2 - c2.bottomMargin);
                            break;
                        }
                        case 16: {
                            int n11 = n5 - n3;
                            int n12 = (n11 - n10) / 2;
                            if (n12 < c2.topMargin) {
                                n2 = c2.topMargin;
                            } else {
                                n2 = n12;
                                if (n12 + n10 > n11 - c2.bottomMargin) {
                                    n2 = n11 - c2.bottomMargin - n10;
                                }
                            }
                            view.layout(n8, n2, n9 + n8, n10 + n2);
                        }
                    }
                    if (bl2) {
                        this.b(view, f2);
                    }
                    n2 = c2.b > 0.0f ? 0 : 4;
                    if (view.getVisibility() != n2) {
                        view.setVisibility(n2);
                    }
                }
            }
            ++n4;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void onMeasure(int var1_1, int var2_2) {
        var6_3 = 300;
        var9_4 = View.MeasureSpec.getMode((int)var1_1);
        var8_5 = View.MeasureSpec.getMode((int)var2_2);
        var5_6 = View.MeasureSpec.getSize((int)var1_1);
        var7_7 = View.MeasureSpec.getSize((int)var2_2);
        if (var9_4 != 1073741824) ** GOTO lbl9
        var4_8 = var5_6;
        if (var8_5 == 1073741824) ** GOTO lbl-1000
lbl9: // 2 sources:
        if (this.isInEditMode() == false) throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
        var3_9 = var5_6;
        if (var9_4 != Integer.MIN_VALUE) {
            var3_9 = var5_6;
            if (var9_4 == 0) {
                var3_9 = 300;
            }
        }
        var4_8 = var3_9;
        if (var8_5 == Integer.MIN_VALUE) ** GOTO lbl-1000
        var4_8 = var3_9;
        if (var8_5 == 0) {
            var4_8 = var3_9;
            var3_9 = var6_3;
        } else lbl-1000: // 3 sources:
        {
            var3_9 = var7_7;
        }
        this.setMeasuredDimension(var4_8, var3_9);
        var6_3 = this.getChildCount();
        var5_6 = 0;
        while (var5_6 < var6_3) {
            var10_10 = this.getChildAt(var5_6);
            if (var10_10.getVisibility() != 8) {
                var11_11 = (c)var10_10.getLayoutParams();
                if (this.f(var10_10)) {
                    var10_10.measure(View.MeasureSpec.makeMeasureSpec((int)(var4_8 - var11_11.leftMargin - var11_11.rightMargin), (int)1073741824), View.MeasureSpec.makeMeasureSpec((int)(var3_9 - var11_11.topMargin - var11_11.bottomMargin), (int)1073741824));
                } else {
                    if (this.g(var10_10) == false) throw new IllegalStateException("Child " + (Object)var10_10 + " at index " + var5_6 + " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
                    var7_7 = this.e(var10_10) & 7;
                    if ((var7_7 & 0) != 0) {
                        throw new IllegalStateException("Child drawer has absolute gravity " + DrawerLayout.b(var7_7) + " but this DrawerLayout already has a drawer view along that edge");
                    }
                    var10_10.measure(DrawerLayout.getChildMeasureSpec((int)var1_1, (int)(this.b + var11_11.leftMargin + var11_11.rightMargin), (int)var11_11.width), DrawerLayout.getChildMeasureSpec((int)var2_2, (int)(var11_11.topMargin + var11_11.bottomMargin), (int)var11_11.height));
                }
            }
            ++var5_6;
        }
    }

    protected void onRestoreInstanceState(Parcelable object) {
        View view;
        object = (SavedState)((Object)object);
        super.onRestoreInstanceState(object.getSuperState());
        if (object.a != 0 && (view = this.a(object.a)) != null) {
            this.h(view);
        }
        this.a(object.b, 3);
        this.a(object.c, 5);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected Parcelable onSaveInstanceState() {
        var3_1 = new SavedState(super.onSaveInstanceState());
        var2_2 = this.getChildCount();
        var1_3 = 0;
        do {
            if (var1_3 >= var2_2) ** GOTO lbl11
            var4_4 = this.getChildAt(var1_3);
            if (this.g((View)var4_4)) {
                var4_4 = (c)var4_4.getLayoutParams();
                if (var4_4.d) {
                    var3_1.a = var4_4.a;
lbl11: // 2 sources:
                    var3_1.b = this.m;
                    var3_1.c = this.n;
                    return var3_1;
                }
            }
            ++var1_3;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean onTouchEvent(MotionEvent var1_1) {
        this.f.b(var1_1);
        this.g.b(var1_1);
        switch (var1_1.getAction() & 255) {
            default: {
                return true;
            }
            case 0: {
                var2_2 = var1_1.getX();
                var3_4 = var1_1.getY();
                this.r = var2_2;
                this.s = var3_4;
                this.o = false;
                this.p = false;
                return true;
            }
            case 1: {
                var3_5 = var1_1.getX();
                var2_3 = var1_1.getY();
                var1_1 = this.f.e((int)var3_5, (int)var2_3);
                if (var1_1 == null || !this.f((View)var1_1) || (var3_5 -= this.r) * var3_5 + (var2_3 -= this.s) * var2_3 >= (float)((var4_6 = this.f.d()) * var4_6) || (var1_1 = this.a()) == null) break;
                var5_7 = this.a((View)var1_1) == 2;
                ** GOTO lbl27
            }
            case 3: {
                this.a(true);
                this.o = false;
                this.p = false;
                return true;
            }
        }
        var5_7 = true;
lbl27: // 2 sources:
        this.a(var5_7);
        this.o = false;
        return true;
    }

    public void requestDisallowInterceptTouchEvent(boolean bl) {
        if (!this.f.e(1) && !this.g.e(2)) {
            super.requestDisallowInterceptTouchEvent(bl);
        }
        this.o = bl;
        if (bl) {
            this.a(true);
        }
    }

    public void requestLayout() {
        if (!this.k) {
            super.requestLayout();
        }
    }

    public void setDrawerListener(b b2) {
        this.q = b2;
    }

    public void setDrawerLockMode(int n2) {
        this.a(n2, 3);
        this.a(n2, 5);
    }

    public void setScrimColor(int n2) {
        this.c = n2;
        this.invalidate();
    }

    public static class SavedState
    extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>(){

            public final SavedState a(Parcel parcel) {
                return new SavedState(parcel);
            }

            public final SavedState[] a(int n2) {
                return new SavedState[n2];
            }

            public final /* synthetic */ Object createFromParcel(Parcel parcel) {
                return this.a(parcel);
            }

            public final /* synthetic */ Object[] newArray(int n2) {
                return this.a(n2);
            }
        };
        int a = 0;
        int b = 0;
        int c = 0;

        public SavedState(Parcel parcel) {
            super(parcel);
            this.a = parcel.readInt();
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int n2) {
            super.writeToParcel(parcel, n2);
            parcel.writeInt(this.a);
        }

    }

    class a
    extends com.startapp.android.publish.slider.sliding.b.a {
        private final Rect c;

        a() {
            this.c = new Rect();
        }

        private void a(com.startapp.android.publish.slider.sliding.a.a a2, com.startapp.android.publish.slider.sliding.a.a a3) {
            Rect rect = this.c;
            a3.a(rect);
            a2.b(rect);
            a3.c(rect);
            a2.d(rect);
            a2.c(a3.g());
            a2.a(a3.o());
            a2.b(a3.p());
            a2.c(a3.r());
            a2.h(a3.l());
            a2.f(a3.j());
            a2.a(a3.e());
            a2.b(a3.f());
            a2.d(a3.h());
            a2.e(a3.i());
            a2.g(a3.k());
            a2.a(a3.b());
        }

        @Override
        public void a(View view, com.startapp.android.publish.slider.sliding.a.a a2) {
            com.startapp.android.publish.slider.sliding.a.a a3 = com.startapp.android.publish.slider.sliding.a.a.a(a2);
            super.a(view, a3);
            a2.a(view);
            view = l.c(view);
            if (view instanceof View) {
                a2.c(view);
            }
            this.a(a2, a3);
            a3.s();
            int n2 = DrawerLayout.this.getChildCount();
            for (int i2 = 0; i2 < n2; ++i2) {
                view = DrawerLayout.this.getChildAt(i2);
                if (this.a(view)) continue;
                a2.b(view);
            }
        }

        public boolean a(View view) {
            View view2 = DrawerLayout.this.a();
            if (view2 != null && view2 != view) {
                return true;
            }
            return false;
        }

        @Override
        public boolean a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            if (!this.a(view)) {
                return super.a(viewGroup, view, accessibilityEvent);
            }
            return false;
        }
    }

    public static interface b {
        public void a(int var1);

        public void a(View var1);

        public void a(View var1, float var2);

        public void b(View var1);
    }

    public static class c
    extends ViewGroup.MarginLayoutParams {
        public int a = 0;
        float b;
        boolean c;
        boolean d;

        public c(int n2, int n3) {
            super(n2, n3);
        }

        public c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            context = context.obtainStyledAttributes(attributeSet, a);
            this.a = context.getInt(0, 0);
            context.recycle();
        }

        public c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public c(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public c(c c2) {
            super((ViewGroup.MarginLayoutParams)c2);
            this.a = c2.a;
        }
    }

    class d
    extends c.a {
        private final int b;
        private com.startapp.android.publish.slider.sliding.c c;
        private final Runnable d;

        public d(int n2) {
            this.d = new Runnable(){

                @Override
                public void run() {
                    d.this.c();
                }
            };
            this.b = n2;
        }

        private void b() {
            View view;
            int n2 = 3;
            if (this.b == 3) {
                n2 = 5;
            }
            if ((view = DrawerLayout.this.a(n2)) != null) {
                DrawerLayout.this.i(view);
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        private void c() {
            View view;
            int n2 = 0;
            int n3 = this.c.b();
            boolean bl = this.b == 3;
            if (bl) {
                view = DrawerLayout.this.a(3);
                if (view != null) {
                    n2 = - view.getWidth();
                }
                n2 += n3;
            } else {
                view = DrawerLayout.this.a(5);
                n2 = DrawerLayout.this.getWidth() - n3;
            }
            if (view != null && (bl && view.getLeft() < n2 || !bl && view.getLeft() > n2) && DrawerLayout.this.a(view) == 0) {
                c c2 = (c)view.getLayoutParams();
                this.c.a(view, n2, view.getTop());
                c2.c = true;
                DrawerLayout.this.invalidate();
                this.b();
                DrawerLayout.this.c();
            }
        }

        @Override
        public int a(View view) {
            return view.getWidth();
        }

        @Override
        public int a(View view, int n2, int n3) {
            if (DrawerLayout.this.a(view, 3)) {
                return Math.max(- view.getWidth(), Math.min(n2, 0));
            }
            n3 = DrawerLayout.this.getWidth();
            return Math.max(n3 - view.getWidth(), Math.min(n2, n3));
        }

        public void a() {
            DrawerLayout.this.removeCallbacks(this.d);
        }

        @Override
        public void a(int n2) {
            DrawerLayout.this.a(this.b, n2, this.c.c());
        }

        @Override
        public void a(int n2, int n3) {
            DrawerLayout.this.postDelayed(this.d, 160);
        }

        /*
         * Unable to fully structure code
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        public void a(View var1_1, float var2_2, float var3_3) {
            var3_3 = DrawerLayout.this.d(var1_1);
            var6_4 = var1_1.getWidth();
            if (!DrawerLayout.this.a(var1_1, 3)) ** GOTO lbl12
            if (var2_2 > 0.0f || var2_2 == 0.0f && var3_3 > 0.5f) {
                var4_5 = 0;
lbl6: // 5 sources:
                do {
                    this.c.a(var4_5, var1_1.getTop());
                    DrawerLayout.this.invalidate();
                    return;
                    break;
                } while (true);
            }
            var4_5 = - var6_4;
            ** GOTO lbl6
lbl12: // 1 sources:
            var5_6 = DrawerLayout.this.getWidth();
            if (var2_2 < 0.0f) ** GOTO lbl18
            var4_5 = var5_6;
            if (var2_2 != 0.0f) ** GOTO lbl6
            var4_5 = var5_6;
            if (var3_3 >= 0.5f) ** GOTO lbl6
lbl18: // 2 sources:
            var4_5 = var5_6 - var6_4;
            ** while (true)
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void a(View view, int n2, int n3, int n4, int n5) {
            n3 = view.getWidth();
            float f2 = DrawerLayout.this.a(view, 3) ? (float)(n3 + n2) / (float)n3 : (float)(DrawerLayout.this.getWidth() - n2) / (float)n3;
            DrawerLayout.this.b(view, f2);
            n2 = f2 == 0.0f ? 4 : 0;
            view.setVisibility(n2);
            DrawerLayout.this.invalidate();
        }

        public void a(com.startapp.android.publish.slider.sliding.c c2) {
            this.c = c2;
        }

        @Override
        public boolean a(View view, int n2) {
            if (DrawerLayout.this.g(view) && DrawerLayout.this.a(view, this.b) && DrawerLayout.this.a(view) == 0) {
                return true;
            }
            return false;
        }

        @Override
        public int b(View view, int n2, int n3) {
            return view.getTop();
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void b(int n2, int n3) {
            View view = (n2 & 1) == 1 ? DrawerLayout.this.a(3) : DrawerLayout.this.a(5);
            if (view != null && DrawerLayout.this.a(view) == 0) {
                this.c.a(view, n3);
            }
        }

        @Override
        public void b(View view, int n2) {
            ((c)view.getLayoutParams()).c = false;
            this.b();
        }

        @Override
        public boolean b(int n2) {
            return false;
        }

    }

}

