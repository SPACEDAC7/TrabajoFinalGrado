/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.animation.Interpolator
 *  android.widget.Scroller
 */
package com.startapp.android.publish.slider.sliding;

import android.content.Context;
import android.os.Build;
import android.view.animation.Interpolator;
import android.widget.Scroller;

public class a {
    static final a b;
    Object a;

    static {
        int n2 = Build.VERSION.SDK_INT;
        b = n2 >= 14 ? new d() : (n2 >= 9 ? new c() : new b());
    }

    a(Context context, Interpolator interpolator) {
        this.a = b.a(context, interpolator);
    }

    public static a a(Context context, Interpolator interpolator) {
        return new a(context, interpolator);
    }

    public void a(int n2, int n3, int n4, int n5, int n6) {
        b.a(this.a, n2, n3, n4, n5, n6);
    }

    public boolean a() {
        return b.a(this.a);
    }

    public int b() {
        return b.b(this.a);
    }

    public int c() {
        return b.c(this.a);
    }

    public int d() {
        return b.f(this.a);
    }

    public int e() {
        return b.g(this.a);
    }

    public boolean f() {
        return b.d(this.a);
    }

    public void g() {
        b.e(this.a);
    }

    static interface a {
        public Object a(Context var1, Interpolator var2);

        public void a(Object var1, int var2, int var3, int var4, int var5, int var6);

        public boolean a(Object var1);

        public int b(Object var1);

        public int c(Object var1);

        public boolean d(Object var1);

        public void e(Object var1);

        public int f(Object var1);

        public int g(Object var1);
    }

    static class b
    implements a {
        b() {
        }

        @Override
        public Object a(Context context, Interpolator interpolator) {
            if (interpolator != null) {
                return new Scroller(context, interpolator);
            }
            return new Scroller(context);
        }

        @Override
        public void a(Object object, int n2, int n3, int n4, int n5, int n6) {
            ((Scroller)object).startScroll(n2, n3, n4, n5, n6);
        }

        @Override
        public boolean a(Object object) {
            return ((Scroller)object).isFinished();
        }

        @Override
        public int b(Object object) {
            return ((Scroller)object).getCurrX();
        }

        @Override
        public int c(Object object) {
            return ((Scroller)object).getCurrY();
        }

        @Override
        public boolean d(Object object) {
            return ((Scroller)object).computeScrollOffset();
        }

        @Override
        public void e(Object object) {
            ((Scroller)object).abortAnimation();
        }

        @Override
        public int f(Object object) {
            return ((Scroller)object).getFinalX();
        }

        @Override
        public int g(Object object) {
            return ((Scroller)object).getFinalY();
        }
    }

    static class c
    implements a {
        c() {
        }

        @Override
        public Object a(Context context, Interpolator interpolator) {
            return com.startapp.android.publish.slider.sliding.b.a(context, interpolator);
        }

        @Override
        public void a(Object object, int n2, int n3, int n4, int n5, int n6) {
            com.startapp.android.publish.slider.sliding.b.a(object, n2, n3, n4, n5, n6);
        }

        @Override
        public boolean a(Object object) {
            return com.startapp.android.publish.slider.sliding.b.a(object);
        }

        @Override
        public int b(Object object) {
            return com.startapp.android.publish.slider.sliding.b.b(object);
        }

        @Override
        public int c(Object object) {
            return com.startapp.android.publish.slider.sliding.b.c(object);
        }

        @Override
        public boolean d(Object object) {
            return com.startapp.android.publish.slider.sliding.b.d(object);
        }

        @Override
        public void e(Object object) {
            com.startapp.android.publish.slider.sliding.b.e(object);
        }

        @Override
        public int f(Object object) {
            return com.startapp.android.publish.slider.sliding.b.f(object);
        }

        @Override
        public int g(Object object) {
            return com.startapp.android.publish.slider.sliding.b.g(object);
        }
    }

    static class d
    extends c {
        d() {
        }
    }

}

