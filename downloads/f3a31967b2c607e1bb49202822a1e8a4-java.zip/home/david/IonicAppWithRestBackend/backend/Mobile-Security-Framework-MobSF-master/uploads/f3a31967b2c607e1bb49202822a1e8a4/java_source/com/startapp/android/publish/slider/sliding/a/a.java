/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.graphics.Rect
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 */
package com.startapp.android.publish.slider.sliding.a;

import android.graphics.Rect;
import android.os.Build;
import android.view.View;

public class a {
    private static final b a = "JellyBeanMR2".equals(Build.VERSION.CODENAME) ? new d() : (Build.VERSION.SDK_INT >= 16 ? new c() : (Build.VERSION.SDK_INT >= 14 ? new a() : new e()));
    private final Object b;

    public a(Object object) {
        this.b = object;
    }

    public static a a(a a2) {
        return a.a(a.a(a2.b));
    }

    static a a(Object object) {
        if (object != null) {
            return new a(object);
        }
        return null;
    }

    private static String b(int n2) {
        switch (n2) {
            default: {
                return "ACTION_UNKNOWN";
            }
            case 1: {
                return "ACTION_FOCUS";
            }
            case 2: {
                return "ACTION_CLEAR_FOCUS";
            }
            case 4: {
                return "ACTION_SELECT";
            }
            case 8: {
                return "ACTION_CLEAR_SELECTION";
            }
            case 16: {
                return "ACTION_CLICK";
            }
            case 32: {
                return "ACTION_LONG_CLICK";
            }
            case 64: {
                return "ACTION_ACCESSIBILITY_FOCUS";
            }
            case 128: {
                return "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
            }
            case 256: {
                return "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
            }
            case 512: {
                return "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
            }
            case 1024: {
                return "ACTION_NEXT_HTML_ELEMENT";
            }
            case 2048: {
                return "ACTION_PREVIOUS_HTML_ELEMENT";
            }
            case 4096: {
                return "ACTION_SCROLL_FORWARD";
            }
            case 8192: {
                return "ACTION_SCROLL_BACKWARD";
            }
            case 65536: {
                return "ACTION_CUT";
            }
            case 16384: {
                return "ACTION_COPY";
            }
            case 32768: {
                return "ACTION_PASTE";
            }
            case 131072: 
        }
        return "ACTION_SET_SELECTION";
    }

    public Object a() {
        return this.b;
    }

    public void a(int n2) {
        a.a(this.b, n2);
    }

    public void a(Rect rect) {
        a.a(this.b, rect);
    }

    public void a(View view) {
        a.c(this.b, view);
    }

    public void a(CharSequence charSequence) {
        a.c(this.b, charSequence);
    }

    public void a(boolean bl) {
        a.c(this.b, bl);
    }

    public int b() {
        return a.b(this.b);
    }

    public void b(Rect rect) {
        a.c(this.b, rect);
    }

    public void b(View view) {
        a.a(this.b, view);
    }

    public void b(CharSequence charSequence) {
        a.a(this.b, charSequence);
    }

    public void b(boolean bl) {
        a.d(this.b, bl);
    }

    public void c(Rect rect) {
        a.b(this.b, rect);
    }

    public void c(View view) {
        a.b(this.b, view);
    }

    public void c(CharSequence charSequence) {
        a.b(this.b, charSequence);
    }

    public void c(boolean bl) {
        a.g(this.b, bl);
    }

    public boolean c() {
        return a.g(this.b);
    }

    public void d(Rect rect) {
        a.d(this.b, rect);
    }

    public void d(boolean bl) {
        a.h(this.b, bl);
    }

    public boolean d() {
        return a.h(this.b);
    }

    public void e(boolean bl) {
        a.f(this.b, bl);
    }

    public boolean e() {
        return a.k(this.b);
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null) {
            return false;
        }
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (a)object;
        if (this.b == null) {
            if (object.b == null) return true;
            return false;
        }
        if (!this.b.equals(object.b)) return false;
        return true;
    }

    public void f(boolean bl) {
        a.a(this.b, bl);
    }

    public boolean f() {
        return a.l(this.b);
    }

    public void g(boolean bl) {
        a.e(this.b, bl);
    }

    public boolean g() {
        return a.r(this.b);
    }

    public void h(boolean bl) {
        a.b(this.b, bl);
    }

    public boolean h() {
        return a.s(this.b);
    }

    public int hashCode() {
        if (this.b == null) {
            return 0;
        }
        return this.b.hashCode();
    }

    public boolean i() {
        return a.p(this.b);
    }

    public boolean j() {
        return a.i(this.b);
    }

    public boolean k() {
        return a.m(this.b);
    }

    public boolean l() {
        return a.j(this.b);
    }

    public boolean m() {
        return a.n(this.b);
    }

    public boolean n() {
        return a.o(this.b);
    }

    public CharSequence o() {
        return a.e(this.b);
    }

    public CharSequence p() {
        return a.c(this.b);
    }

    public CharSequence q() {
        return a.f(this.b);
    }

    public CharSequence r() {
        return a.d(this.b);
    }

    public void s() {
        a.q(this.b);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(super.toString());
        Rect rect = new Rect();
        this.a(rect);
        stringBuilder.append("; boundsInParent: " + (Object)rect);
        this.c(rect);
        stringBuilder.append("; boundsInScreen: " + (Object)rect);
        stringBuilder.append("; packageName: ").append(this.o());
        stringBuilder.append("; className: ").append(this.p());
        stringBuilder.append("; text: ").append(this.q());
        stringBuilder.append("; contentDescription: ").append(this.r());
        stringBuilder.append("; checkable: ").append(this.c());
        stringBuilder.append("; checked: ").append(this.d());
        stringBuilder.append("; focusable: ").append(this.e());
        stringBuilder.append("; focused: ").append(this.f());
        stringBuilder.append("; selected: ").append(this.i());
        stringBuilder.append("; clickable: ").append(this.j());
        stringBuilder.append("; longClickable: ").append(this.k());
        stringBuilder.append("; enabled: ").append(this.l());
        stringBuilder.append("; password: ").append(this.m());
        stringBuilder.append("; scrollable: " + this.n());
        stringBuilder.append("; [");
        int n2 = this.b();
        while (n2 != 0) {
            int n3 = 1 << Integer.numberOfTrailingZeros(n2);
            int n4 = n2 & ~ n3;
            stringBuilder.append(a.b(n3));
            n2 = n4;
            if (n4 == 0) continue;
            stringBuilder.append(", ");
            n2 = n4;
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    static class a
    extends e {
        a() {
        }

        @Override
        public Object a(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.a(object);
        }

        @Override
        public void a(Object object, int n2) {
            com.startapp.android.publish.slider.sliding.a.b.a(object, n2);
        }

        @Override
        public void a(Object object, Rect rect) {
            com.startapp.android.publish.slider.sliding.a.b.a(object, rect);
        }

        @Override
        public void a(Object object, View view) {
            com.startapp.android.publish.slider.sliding.a.b.a(object, view);
        }

        @Override
        public void a(Object object, CharSequence charSequence) {
            com.startapp.android.publish.slider.sliding.a.b.a(object, charSequence);
        }

        @Override
        public void a(Object object, boolean bl) {
            com.startapp.android.publish.slider.sliding.a.b.a(object, bl);
        }

        @Override
        public int b(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.b(object);
        }

        @Override
        public void b(Object object, Rect rect) {
            com.startapp.android.publish.slider.sliding.a.b.b(object, rect);
        }

        @Override
        public void b(Object object, View view) {
            com.startapp.android.publish.slider.sliding.a.b.b(object, view);
        }

        @Override
        public void b(Object object, CharSequence charSequence) {
            com.startapp.android.publish.slider.sliding.a.b.b(object, charSequence);
        }

        @Override
        public void b(Object object, boolean bl) {
            com.startapp.android.publish.slider.sliding.a.b.b(object, bl);
        }

        @Override
        public CharSequence c(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.c(object);
        }

        @Override
        public void c(Object object, Rect rect) {
            com.startapp.android.publish.slider.sliding.a.b.c(object, rect);
        }

        @Override
        public void c(Object object, View view) {
            com.startapp.android.publish.slider.sliding.a.b.c(object, view);
        }

        @Override
        public void c(Object object, CharSequence charSequence) {
            com.startapp.android.publish.slider.sliding.a.b.c(object, charSequence);
        }

        @Override
        public void c(Object object, boolean bl) {
            com.startapp.android.publish.slider.sliding.a.b.c(object, bl);
        }

        @Override
        public CharSequence d(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.d(object);
        }

        @Override
        public void d(Object object, Rect rect) {
            com.startapp.android.publish.slider.sliding.a.b.d(object, rect);
        }

        @Override
        public void d(Object object, boolean bl) {
            com.startapp.android.publish.slider.sliding.a.b.d(object, bl);
        }

        @Override
        public CharSequence e(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.e(object);
        }

        @Override
        public void e(Object object, boolean bl) {
            com.startapp.android.publish.slider.sliding.a.b.e(object, bl);
        }

        @Override
        public CharSequence f(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.f(object);
        }

        @Override
        public void f(Object object, boolean bl) {
            com.startapp.android.publish.slider.sliding.a.b.f(object, bl);
        }

        @Override
        public boolean g(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.g(object);
        }

        @Override
        public boolean h(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.h(object);
        }

        @Override
        public boolean i(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.i(object);
        }

        @Override
        public boolean j(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.j(object);
        }

        @Override
        public boolean k(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.k(object);
        }

        @Override
        public boolean l(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.l(object);
        }

        @Override
        public boolean m(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.m(object);
        }

        @Override
        public boolean n(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.n(object);
        }

        @Override
        public boolean o(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.o(object);
        }

        @Override
        public boolean p(Object object) {
            return com.startapp.android.publish.slider.sliding.a.b.p(object);
        }

        @Override
        public void q(Object object) {
            com.startapp.android.publish.slider.sliding.a.b.q(object);
        }
    }

    static interface b {
        public Object a(Object var1);

        public void a(Object var1, int var2);

        public void a(Object var1, Rect var2);

        public void a(Object var1, View var2);

        public void a(Object var1, CharSequence var2);

        public void a(Object var1, boolean var2);

        public int b(Object var1);

        public void b(Object var1, Rect var2);

        public void b(Object var1, View var2);

        public void b(Object var1, CharSequence var2);

        public void b(Object var1, boolean var2);

        public CharSequence c(Object var1);

        public void c(Object var1, Rect var2);

        public void c(Object var1, View var2);

        public void c(Object var1, CharSequence var2);

        public void c(Object var1, boolean var2);

        public CharSequence d(Object var1);

        public void d(Object var1, Rect var2);

        public void d(Object var1, boolean var2);

        public CharSequence e(Object var1);

        public void e(Object var1, boolean var2);

        public CharSequence f(Object var1);

        public void f(Object var1, boolean var2);

        public void g(Object var1, boolean var2);

        public boolean g(Object var1);

        public void h(Object var1, boolean var2);

        public boolean h(Object var1);

        public boolean i(Object var1);

        public boolean j(Object var1);

        public boolean k(Object var1);

        public boolean l(Object var1);

        public boolean m(Object var1);

        public boolean n(Object var1);

        public boolean o(Object var1);

        public boolean p(Object var1);

        public void q(Object var1);

        public boolean r(Object var1);

        public boolean s(Object var1);
    }

    static class c
    extends a {
        c() {
        }

        @Override
        public void g(Object object, boolean bl) {
            com.startapp.android.publish.slider.sliding.a.c.a(object, bl);
        }

        @Override
        public void h(Object object, boolean bl) {
            com.startapp.android.publish.slider.sliding.a.c.b(object, bl);
        }

        @Override
        public boolean r(Object object) {
            return com.startapp.android.publish.slider.sliding.a.c.a(object);
        }

        @Override
        public boolean s(Object object) {
            return com.startapp.android.publish.slider.sliding.a.c.b(object);
        }
    }

    static class d
    extends c {
        d() {
        }
    }

    static class e
    implements b {
        e() {
        }

        @Override
        public Object a(Object object) {
            return null;
        }

        @Override
        public void a(Object object, int n2) {
        }

        @Override
        public void a(Object object, Rect rect) {
        }

        @Override
        public void a(Object object, View view) {
        }

        @Override
        public void a(Object object, CharSequence charSequence) {
        }

        @Override
        public void a(Object object, boolean bl) {
        }

        @Override
        public int b(Object object) {
            return 0;
        }

        @Override
        public void b(Object object, Rect rect) {
        }

        @Override
        public void b(Object object, View view) {
        }

        @Override
        public void b(Object object, CharSequence charSequence) {
        }

        @Override
        public void b(Object object, boolean bl) {
        }

        @Override
        public CharSequence c(Object object) {
            return null;
        }

        @Override
        public void c(Object object, Rect rect) {
        }

        @Override
        public void c(Object object, View view) {
        }

        @Override
        public void c(Object object, CharSequence charSequence) {
        }

        @Override
        public void c(Object object, boolean bl) {
        }

        @Override
        public CharSequence d(Object object) {
            return null;
        }

        @Override
        public void d(Object object, Rect rect) {
        }

        @Override
        public void d(Object object, boolean bl) {
        }

        @Override
        public CharSequence e(Object object) {
            return null;
        }

        @Override
        public void e(Object object, boolean bl) {
        }

        @Override
        public CharSequence f(Object object) {
            return null;
        }

        @Override
        public void f(Object object, boolean bl) {
        }

        @Override
        public void g(Object object, boolean bl) {
        }

        @Override
        public boolean g(Object object) {
            return false;
        }

        @Override
        public void h(Object object, boolean bl) {
        }

        @Override
        public boolean h(Object object) {
            return false;
        }

        @Override
        public boolean i(Object object) {
            return false;
        }

        @Override
        public boolean j(Object object) {
            return false;
        }

        @Override
        public boolean k(Object object) {
            return false;
        }

        @Override
        public boolean l(Object object) {
            return false;
        }

        @Override
        public boolean m(Object object) {
            return false;
        }

        @Override
        public boolean n(Object object) {
            return false;
        }

        @Override
        public boolean o(Object object) {
            return false;
        }

        @Override
        public boolean p(Object object) {
            return false;
        }

        @Override
        public void q(Object object) {
        }

        @Override
        public boolean r(Object object) {
            return false;
        }

        @Override
        public boolean s(Object object) {
            return false;
        }
    }

}

