/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.accessibility.AccessibilityNodeInfo
 */
package com.startapp.android.publish.slider.sliding.a;

import android.view.accessibility.AccessibilityNodeInfo;

class c {
    public static void a(Object object, boolean bl) {
        ((AccessibilityNodeInfo)object).setVisibleToUser(bl);
    }

    public static boolean a(Object object) {
        return ((AccessibilityNodeInfo)object).isVisibleToUser();
    }

    public static void b(Object object, boolean bl) {
        ((AccessibilityNodeInfo)object).setAccessibilityFocused(bl);
    }

    public static boolean b(Object object) {
        return ((AccessibilityNodeInfo)object).isAccessibilityFocused();
    }
}

