/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 */
package com.startapp.android.publish.slider.sliding.a;

import android.os.Build;
import android.os.Bundle;
import com.startapp.android.publish.slider.sliding.a.e;
import java.util.ArrayList;
import java.util.List;

public class d {
    private static final a a = Build.VERSION.SDK_INT >= 16 ? new b() : new c();
    private final Object b;

    public d() {
        this.b = a.a(this);
    }

    public d(Object object) {
        this.b = object;
    }

    public com.startapp.android.publish.slider.sliding.a.a a(int n2) {
        return null;
    }

    public Object a() {
        return this.b;
    }

    public List<com.startapp.android.publish.slider.sliding.a.a> a(String string2, int n2) {
        return null;
    }

    public boolean a(int n2, int n3, Bundle bundle) {
        return false;
    }

    static interface a {
        public Object a(d var1);
    }

    static class b
    extends c {
        b() {
        }

        @Override
        public Object a(final d d2) {
            return e.a(new e.a(){

                @Override
                public Object a(int n2) {
                    com.startapp.android.publish.slider.sliding.a.a a2 = d2.a(n2);
                    if (a2 == null) {
                        return null;
                    }
                    return a2.a();
                }

                @Override
                public List<Object> a(String object, int n2) {
                    object = d2.a((String)object, n2);
                    ArrayList<Object> arrayList = new ArrayList<Object>();
                    int n3 = object.size();
                    for (n2 = 0; n2 < n3; ++n2) {
                        arrayList.add(((com.startapp.android.publish.slider.sliding.a.a)object.get(n2)).a());
                    }
                    return arrayList;
                }

                @Override
                public boolean a(int n2, int n3, Bundle bundle) {
                    return d2.a(n2, n3, bundle);
                }
            });
        }

    }

    static class c
    implements a {
        c() {
        }

        @Override
        public Object a(d d2) {
            return null;
        }
    }

}

