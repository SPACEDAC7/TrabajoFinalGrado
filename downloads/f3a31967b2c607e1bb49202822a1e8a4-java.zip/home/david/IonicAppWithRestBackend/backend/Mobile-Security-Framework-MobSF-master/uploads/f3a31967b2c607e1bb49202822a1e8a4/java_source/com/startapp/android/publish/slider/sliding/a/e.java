/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.accessibility.AccessibilityNodeInfo
 *  android.view.accessibility.AccessibilityNodeProvider
 */
package com.startapp.android.publish.slider.sliding.a;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

class e {
    public static Object a(final a a2) {
        return new AccessibilityNodeProvider(){

            public final AccessibilityNodeInfo createAccessibilityNodeInfo(int n2) {
                return (AccessibilityNodeInfo)a2.a(n2);
            }

            public final List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String string2, int n2) {
                return a2.a(string2, n2);
            }

            public final boolean performAction(int n2, int n3, Bundle bundle) {
                return a2.a(n2, n3, bundle);
            }
        };
    }

    static interface a {
        public Object a(int var1);

        public List<Object> a(String var1, int var2);

        public boolean a(int var1, int var2, Bundle var3);
    }

}

