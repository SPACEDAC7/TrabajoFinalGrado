/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.animation.Interpolator
 *  android.widget.OverScroller
 */
package com.startapp.android.publish.slider.sliding;

import android.content.Context;
import android.view.animation.Interpolator;
import android.widget.OverScroller;

class b {
    public static Object a(Context context, Interpolator interpolator) {
        if (interpolator != null) {
            return new OverScroller(context, interpolator);
        }
        return new OverScroller(context);
    }

    public static void a(Object object, int n2, int n3, int n4, int n5, int n6) {
        ((OverScroller)object).startScroll(n2, n3, n4, n5, n6);
    }

    public static boolean a(Object object) {
        return ((OverScroller)object).isFinished();
    }

    public static int b(Object object) {
        return ((OverScroller)object).getCurrX();
    }

    public static int c(Object object) {
        return ((OverScroller)object).getCurrY();
    }

    public static boolean d(Object object) {
        return ((OverScroller)object).computeScrollOffset();
    }

    public static void e(Object object) {
        ((OverScroller)object).abortAnimation();
    }

    public static int f(Object object) {
        return ((OverScroller)object).getFinalX();
    }

    public static int g(Object object) {
        return ((OverScroller)object).getFinalY();
    }
}

