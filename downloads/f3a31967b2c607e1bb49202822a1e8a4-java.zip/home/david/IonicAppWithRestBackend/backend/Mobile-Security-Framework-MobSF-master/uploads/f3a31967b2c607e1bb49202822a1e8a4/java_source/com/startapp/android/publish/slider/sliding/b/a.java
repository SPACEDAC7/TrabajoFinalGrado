/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.accessibility.AccessibilityEvent
 */
package com.startapp.android.publish.slider.sliding.b;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import com.startapp.android.publish.slider.sliding.b.b;
import com.startapp.android.publish.slider.sliding.b.c;

public class a {
    private static final b a = Build.VERSION.SDK_INT >= 16 ? new c() : (Build.VERSION.SDK_INT >= 14 ? new a() : new d());
    private static final Object c = a.a();
    final Object b;

    public a() {
        this.b = a.a(this);
    }

    Object a() {
        return this.b;
    }

    public void a(View view, int n2) {
        a.a(c, view, n2);
    }

    public void a(View view, AccessibilityEvent accessibilityEvent) {
        a.d(c, view, accessibilityEvent);
    }

    public void a(View view, com.startapp.android.publish.slider.sliding.a.a a2) {
        a.a(c, view, a2);
    }

    public boolean a(View view, int n2, Bundle bundle) {
        return a.a(c, view, n2, bundle);
    }

    public boolean a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return a.a(c, viewGroup, view, accessibilityEvent);
    }

    public com.startapp.android.publish.slider.sliding.a.d b(View view) {
        return a.a(c, view);
    }

    public boolean b(View view, AccessibilityEvent accessibilityEvent) {
        return a.a(c, view, accessibilityEvent);
    }

    public void c(View view, AccessibilityEvent accessibilityEvent) {
        a.c(c, view, accessibilityEvent);
    }

    public void d(View view, AccessibilityEvent accessibilityEvent) {
        a.b(c, view, accessibilityEvent);
    }

    static class a
    extends d {
        a() {
        }

        @Override
        public Object a() {
            return com.startapp.android.publish.slider.sliding.b.b.a();
        }

        @Override
        public Object a(final a a2) {
            return com.startapp.android.publish.slider.sliding.b.b.a(new b.a(){

                @Override
                public void a(View view, int n2) {
                    a2.a(view, n2);
                }

                @Override
                public void a(View view, Object object) {
                    a2.a(view, new com.startapp.android.publish.slider.sliding.a.a(object));
                }

                @Override
                public boolean a(View view, AccessibilityEvent accessibilityEvent) {
                    return a2.b(view, accessibilityEvent);
                }

                @Override
                public boolean a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
                    return a2.a(viewGroup, view, accessibilityEvent);
                }

                @Override
                public void b(View view, AccessibilityEvent accessibilityEvent) {
                    a2.d(view, accessibilityEvent);
                }

                @Override
                public void c(View view, AccessibilityEvent accessibilityEvent) {
                    a2.c(view, accessibilityEvent);
                }

                @Override
                public void d(View view, AccessibilityEvent accessibilityEvent) {
                    a2.a(view, accessibilityEvent);
                }
            });
        }

        @Override
        public void a(Object object, View view, int n2) {
            com.startapp.android.publish.slider.sliding.b.b.a(object, view, n2);
        }

        @Override
        public void a(Object object, View view, com.startapp.android.publish.slider.sliding.a.a a2) {
            com.startapp.android.publish.slider.sliding.b.b.a(object, view, a2.a());
        }

        @Override
        public boolean a(Object object, View view, AccessibilityEvent accessibilityEvent) {
            return com.startapp.android.publish.slider.sliding.b.b.a(object, view, accessibilityEvent);
        }

        @Override
        public boolean a(Object object, ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return com.startapp.android.publish.slider.sliding.b.b.a(object, viewGroup, view, accessibilityEvent);
        }

        @Override
        public void b(Object object, View view, AccessibilityEvent accessibilityEvent) {
            com.startapp.android.publish.slider.sliding.b.b.b(object, view, accessibilityEvent);
        }

        @Override
        public void c(Object object, View view, AccessibilityEvent accessibilityEvent) {
            com.startapp.android.publish.slider.sliding.b.b.c(object, view, accessibilityEvent);
        }

        @Override
        public void d(Object object, View view, AccessibilityEvent accessibilityEvent) {
            com.startapp.android.publish.slider.sliding.b.b.d(object, view, accessibilityEvent);
        }

    }

    static interface b {
        public com.startapp.android.publish.slider.sliding.a.d a(Object var1, View var2);

        public Object a();

        public Object a(a var1);

        public void a(Object var1, View var2, int var3);

        public void a(Object var1, View var2, com.startapp.android.publish.slider.sliding.a.a var3);

        public boolean a(Object var1, View var2, int var3, Bundle var4);

        public boolean a(Object var1, View var2, AccessibilityEvent var3);

        public boolean a(Object var1, ViewGroup var2, View var3, AccessibilityEvent var4);

        public void b(Object var1, View var2, AccessibilityEvent var3);

        public void c(Object var1, View var2, AccessibilityEvent var3);

        public void d(Object var1, View var2, AccessibilityEvent var3);
    }

    static class c
    extends a {
        c() {
        }

        @Override
        public com.startapp.android.publish.slider.sliding.a.d a(Object object, View view) {
            if ((object = com.startapp.android.publish.slider.sliding.b.c.a(object, view)) != null) {
                return new com.startapp.android.publish.slider.sliding.a.d(object);
            }
            return null;
        }

        @Override
        public Object a(final a a2) {
            return com.startapp.android.publish.slider.sliding.b.c.a(new c.a(){

                @Override
                public Object a(View object) {
                    if ((object = a2.b((View)object)) != null) {
                        return object.a();
                    }
                    return null;
                }

                @Override
                public void a(View view, int n2) {
                    a2.a(view, n2);
                }

                @Override
                public void a(View view, Object object) {
                    a2.a(view, new com.startapp.android.publish.slider.sliding.a.a(object));
                }

                @Override
                public boolean a(View view, int n2, Bundle bundle) {
                    return a2.a(view, n2, bundle);
                }

                @Override
                public boolean a(View view, AccessibilityEvent accessibilityEvent) {
                    return a2.b(view, accessibilityEvent);
                }

                @Override
                public boolean a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
                    return a2.a(viewGroup, view, accessibilityEvent);
                }

                @Override
                public void b(View view, AccessibilityEvent accessibilityEvent) {
                    a2.d(view, accessibilityEvent);
                }

                @Override
                public void c(View view, AccessibilityEvent accessibilityEvent) {
                    a2.c(view, accessibilityEvent);
                }

                @Override
                public void d(View view, AccessibilityEvent accessibilityEvent) {
                    a2.a(view, accessibilityEvent);
                }
            });
        }

        @Override
        public boolean a(Object object, View view, int n2, Bundle bundle) {
            return com.startapp.android.publish.slider.sliding.b.c.a(object, view, n2, bundle);
        }

    }

    static class d
    implements b {
        d() {
        }

        @Override
        public com.startapp.android.publish.slider.sliding.a.d a(Object object, View view) {
            return null;
        }

        @Override
        public Object a() {
            return null;
        }

        @Override
        public Object a(a a2) {
            return null;
        }

        @Override
        public void a(Object object, View view, int n2) {
        }

        @Override
        public void a(Object object, View view, com.startapp.android.publish.slider.sliding.a.a a2) {
        }

        @Override
        public boolean a(Object object, View view, int n2, Bundle bundle) {
            return false;
        }

        @Override
        public boolean a(Object object, View view, AccessibilityEvent accessibilityEvent) {
            return false;
        }

        @Override
        public boolean a(Object object, ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return true;
        }

        @Override
        public void b(Object object, View view, AccessibilityEvent accessibilityEvent) {
        }

        @Override
        public void c(Object object, View view, AccessibilityEvent accessibilityEvent) {
        }

        @Override
        public void d(Object object, View view, AccessibilityEvent accessibilityEvent) {
        }
    }

}

