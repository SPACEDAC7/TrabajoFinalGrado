/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 */
package com.startapp.android.publish.slider.sliding.b;

import android.os.Build;
import com.startapp.android.publish.slider.sliding.b.e;

public class d {
    static final a a = Build.VERSION.SDK_INT >= 17 ? new c() : new b();

    public static int a(int n2, int n3) {
        return a.a(n2, n3);
    }

    static interface a {
        public int a(int var1, int var2);
    }

    static class b
    implements a {
        b() {
        }

        @Override
        public int a(int n2, int n3) {
            return -8388609 & n2;
        }
    }

    static class c
    implements a {
        c() {
        }

        @Override
        public int a(int n2, int n3) {
            return e.a(n2, n3);
        }
    }

}

