/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.Gravity
 */
package com.startapp.android.publish.slider.sliding.b;

import android.view.Gravity;

class e {
    public static int a(int n2, int n3) {
        return Gravity.getAbsoluteGravity((int)n2, (int)n3);
    }
}

