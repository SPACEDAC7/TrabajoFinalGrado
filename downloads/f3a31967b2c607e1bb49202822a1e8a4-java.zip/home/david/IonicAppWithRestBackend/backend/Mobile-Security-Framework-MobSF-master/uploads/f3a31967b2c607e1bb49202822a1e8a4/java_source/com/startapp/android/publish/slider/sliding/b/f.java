/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.KeyEvent
 */
package com.startapp.android.publish.slider.sliding.b;

import android.os.Build;
import android.view.KeyEvent;
import com.startapp.android.publish.slider.sliding.b.g;

public class f {
    static final d a = Build.VERSION.SDK_INT >= 11 ? new c() : new a();

    public static void a(KeyEvent keyEvent) {
        a.a(keyEvent);
    }

    static class a
    implements d {
        a() {
        }

        @Override
        public void a(KeyEvent keyEvent) {
        }
    }

    static class b
    extends a {
        b() {
        }

        @Override
        public void a(KeyEvent keyEvent) {
            g.a(keyEvent);
        }
    }

    static class c
    extends b {
        c() {
        }
    }

    static interface d {
        public void a(KeyEvent var1);
    }

}

