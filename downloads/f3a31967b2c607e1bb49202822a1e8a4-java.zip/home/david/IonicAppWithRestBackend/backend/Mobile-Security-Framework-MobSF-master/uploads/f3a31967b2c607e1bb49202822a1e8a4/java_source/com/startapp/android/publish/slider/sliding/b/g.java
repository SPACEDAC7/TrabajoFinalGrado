/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.KeyEvent
 */
package com.startapp.android.publish.slider.sliding.b;

import android.view.KeyEvent;

class g {
    public static void a(KeyEvent keyEvent) {
        keyEvent.startTracking();
    }
}

