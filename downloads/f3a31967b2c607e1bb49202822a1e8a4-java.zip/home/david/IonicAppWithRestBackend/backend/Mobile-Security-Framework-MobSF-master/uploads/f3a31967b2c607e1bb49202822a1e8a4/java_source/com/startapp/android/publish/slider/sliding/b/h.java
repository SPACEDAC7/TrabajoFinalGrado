/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.MotionEvent
 */
package com.startapp.android.publish.slider.sliding.b;

import android.os.Build;
import android.view.MotionEvent;
import com.startapp.android.publish.slider.sliding.b.i;

public class h {
    static final c a = Build.VERSION.SDK_INT >= 5 ? new b() : new a();

    public static int a(MotionEvent motionEvent) {
        return motionEvent.getAction() & 255;
    }

    public static int a(MotionEvent motionEvent, int n2) {
        return a.a(motionEvent, n2);
    }

    public static int b(MotionEvent motionEvent) {
        return motionEvent.getAction() >> 8 & 255;
    }

    public static int b(MotionEvent motionEvent, int n2) {
        return a.b(motionEvent, n2);
    }

    public static float c(MotionEvent motionEvent, int n2) {
        return a.c(motionEvent, n2);
    }

    public static int c(MotionEvent motionEvent) {
        return a.a(motionEvent);
    }

    public static float d(MotionEvent motionEvent, int n2) {
        return a.d(motionEvent, n2);
    }

    static class a
    implements c {
        a() {
        }

        @Override
        public int a(MotionEvent motionEvent) {
            return 1;
        }

        @Override
        public int a(MotionEvent motionEvent, int n2) {
            if (n2 == 0) {
                return 0;
            }
            return -1;
        }

        @Override
        public int b(MotionEvent motionEvent, int n2) {
            if (n2 == 0) {
                return 0;
            }
            throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
        }

        @Override
        public float c(MotionEvent motionEvent, int n2) {
            if (n2 == 0) {
                return motionEvent.getX();
            }
            throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
        }

        @Override
        public float d(MotionEvent motionEvent, int n2) {
            if (n2 == 0) {
                return motionEvent.getY();
            }
            throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
        }
    }

    static class b
    implements c {
        b() {
        }

        @Override
        public int a(MotionEvent motionEvent) {
            return i.a(motionEvent);
        }

        @Override
        public int a(MotionEvent motionEvent, int n2) {
            return i.a(motionEvent, n2);
        }

        @Override
        public int b(MotionEvent motionEvent, int n2) {
            return i.b(motionEvent, n2);
        }

        @Override
        public float c(MotionEvent motionEvent, int n2) {
            return i.c(motionEvent, n2);
        }

        @Override
        public float d(MotionEvent motionEvent, int n2) {
            return i.d(motionEvent, n2);
        }
    }

    static interface c {
        public int a(MotionEvent var1);

        public int a(MotionEvent var1, int var2);

        public int b(MotionEvent var1, int var2);

        public float c(MotionEvent var1, int var2);

        public float d(MotionEvent var1, int var2);
    }

}

