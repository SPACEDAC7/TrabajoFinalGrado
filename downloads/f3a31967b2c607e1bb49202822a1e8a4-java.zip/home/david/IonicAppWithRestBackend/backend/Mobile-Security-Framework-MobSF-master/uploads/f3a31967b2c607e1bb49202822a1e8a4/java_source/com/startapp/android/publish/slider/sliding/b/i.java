/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.MotionEvent
 */
package com.startapp.android.publish.slider.sliding.b;

import android.view.MotionEvent;

class i {
    public static int a(MotionEvent motionEvent) {
        return motionEvent.getPointerCount();
    }

    public static int a(MotionEvent motionEvent, int n2) {
        return motionEvent.findPointerIndex(n2);
    }

    public static int b(MotionEvent motionEvent, int n2) {
        return motionEvent.getPointerId(n2);
    }

    public static float c(MotionEvent motionEvent, int n2) {
        return motionEvent.getX(n2);
    }

    public static float d(MotionEvent motionEvent, int n2) {
        return motionEvent.getY(n2);
    }
}

