/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.VelocityTracker
 */
package com.startapp.android.publish.slider.sliding.b;

import android.view.VelocityTracker;

class k {
    public static float a(VelocityTracker velocityTracker, int n2) {
        return velocityTracker.getXVelocity(n2);
    }

    public static float b(VelocityTracker velocityTracker, int n2) {
        return velocityTracker.getYVelocity(n2);
    }
}

