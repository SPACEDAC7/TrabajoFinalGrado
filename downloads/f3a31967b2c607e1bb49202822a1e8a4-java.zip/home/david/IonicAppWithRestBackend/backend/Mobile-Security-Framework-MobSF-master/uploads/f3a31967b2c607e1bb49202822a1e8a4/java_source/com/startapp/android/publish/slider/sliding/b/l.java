/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.view.ViewParent
 */
package com.startapp.android.publish.slider.sliding.b;

import android.os.Build;
import android.view.View;
import android.view.ViewParent;
import com.startapp.android.publish.slider.sliding.b.m;
import com.startapp.android.publish.slider.sliding.b.n;
import com.startapp.android.publish.slider.sliding.b.o;
import com.startapp.android.publish.slider.sliding.b.p;

public class l {
    static final g a;

    static {
        int n2 = Build.VERSION.SDK_INT;
        a = n2 >= 17 ? new f() : (n2 >= 16 ? new e() : (n2 >= 14 ? new d() : (n2 >= 11 ? new c() : (n2 >= 9 ? new b() : new a()))));
    }

    public static void a(View view) {
        a.a(view);
    }

    public static void a(View view, com.startapp.android.publish.slider.sliding.b.a a2) {
        a.a(view, a2);
    }

    public static int b(View view) {
        return a.b(view);
    }

    public static ViewParent c(View view) {
        return a.c(view);
    }

    static class a
    implements g {
        a() {
        }

        long a() {
            return 10;
        }

        @Override
        public void a(View view) {
            view.postInvalidateDelayed(this.a());
        }

        @Override
        public void a(View view, com.startapp.android.publish.slider.sliding.b.a a2) {
        }

        @Override
        public int b(View view) {
            return 0;
        }

        @Override
        public ViewParent c(View view) {
            return view.getParent();
        }
    }

    static class b
    extends a {
        b() {
        }
    }

    static class c
    extends b {
        c() {
        }

        @Override
        long a() {
            return m.a();
        }
    }

    static class d
    extends c {
        d() {
        }

        @Override
        public void a(View view, com.startapp.android.publish.slider.sliding.b.a a2) {
            n.a(view, a2.a());
        }
    }

    static class e
    extends d {
        e() {
        }

        @Override
        public void a(View view) {
            o.a(view);
        }

        @Override
        public ViewParent c(View view) {
            return o.b(view);
        }
    }

    static class f
    extends e {
        f() {
        }

        @Override
        public int b(View view) {
            return p.a(view);
        }
    }

    static interface g {
        public void a(View var1);

        public void a(View var1, com.startapp.android.publish.slider.sliding.b.a var2);

        public int b(View var1);

        public ViewParent c(View var1);
    }

}

