/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 */
package com.startapp.android.publish.slider.sliding.b;

import android.animation.ValueAnimator;

class m {
    static long a() {
        return ValueAnimator.getFrameDelay();
    }
}

