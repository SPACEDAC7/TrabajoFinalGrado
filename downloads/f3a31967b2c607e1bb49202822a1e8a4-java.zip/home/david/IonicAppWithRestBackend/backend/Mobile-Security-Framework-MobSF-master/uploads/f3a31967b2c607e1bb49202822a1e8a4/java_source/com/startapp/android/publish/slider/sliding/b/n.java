/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$AccessibilityDelegate
 */
package com.startapp.android.publish.slider.sliding.b;

import android.view.View;

class n {
    public static void a(View view, Object object) {
        view.setAccessibilityDelegate((View.AccessibilityDelegate)object);
    }
}

