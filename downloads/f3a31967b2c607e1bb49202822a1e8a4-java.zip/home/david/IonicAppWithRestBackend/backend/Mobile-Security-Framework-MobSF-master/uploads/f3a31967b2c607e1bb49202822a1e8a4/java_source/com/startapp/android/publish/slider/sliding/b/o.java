/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewParent
 */
package com.startapp.android.publish.slider.sliding.b;

import android.view.View;
import android.view.ViewParent;

public class o {
    public static void a(View view) {
        view.postInvalidateOnAnimation();
    }

    public static ViewParent b(View view) {
        return view.getParentForAccessibility();
    }
}

