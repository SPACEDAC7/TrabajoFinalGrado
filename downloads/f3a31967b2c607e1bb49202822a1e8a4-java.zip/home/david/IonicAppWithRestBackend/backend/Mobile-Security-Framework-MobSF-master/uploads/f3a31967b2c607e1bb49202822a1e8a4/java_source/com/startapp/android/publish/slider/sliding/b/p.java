/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.startapp.android.publish.slider.sliding.b;

import android.view.View;

class p {
    public static int a(View view) {
        return view.getLayoutDirection();
    }
}

