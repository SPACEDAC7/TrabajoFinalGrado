/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.ViewGroup
 */
package com.startapp.android.publish.slider.sliding.b;

import android.os.Build;
import android.view.ViewGroup;
import com.startapp.android.publish.slider.sliding.b.r;

public class q {
    static final c a;

    static {
        int n2 = Build.VERSION.SDK_INT;
        a = n2 >= 14 ? new b() : (n2 >= 11 ? new a() : new d());
    }

    public static void a(ViewGroup viewGroup, boolean bl) {
        a.a(viewGroup, bl);
    }

    static class a
    extends d {
        a() {
        }

        @Override
        public void a(ViewGroup viewGroup, boolean bl) {
            r.a(viewGroup, bl);
        }
    }

    static class b
    extends a {
        b() {
        }
    }

    static interface c {
        public void a(ViewGroup var1, boolean var2);
    }

    static class d
    implements c {
        d() {
        }

        @Override
        public void a(ViewGroup viewGroup, boolean bl) {
        }
    }

}

