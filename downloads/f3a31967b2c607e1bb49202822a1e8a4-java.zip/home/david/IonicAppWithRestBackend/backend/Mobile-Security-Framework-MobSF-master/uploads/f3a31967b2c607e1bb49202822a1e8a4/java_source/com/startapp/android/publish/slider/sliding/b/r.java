/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 */
package com.startapp.android.publish.slider.sliding.b;

import android.view.ViewGroup;

class r {
    public static void a(ViewGroup viewGroup, boolean bl) {
        viewGroup.setMotionEventSplittingEnabled(bl);
    }
}

