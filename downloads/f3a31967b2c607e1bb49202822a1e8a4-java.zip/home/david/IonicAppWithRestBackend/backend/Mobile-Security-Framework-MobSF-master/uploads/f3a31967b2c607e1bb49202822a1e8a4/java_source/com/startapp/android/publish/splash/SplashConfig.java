/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.res.Resources
 *  android.content.res.Resources$NotFoundException
 *  android.graphics.drawable.Drawable
 *  android.view.InflateException
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 */
package com.startapp.android.publish.splash;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.startapp.android.publish.g.r;
import com.startapp.android.publish.model.MetaData;
import com.startapp.android.publish.splash.b;
import java.io.Serializable;

public class SplashConfig
implements Serializable {
    private static long DEFAULT_MAX_LOAD = 0;
    private static final int INT_EMPTY_VALUE = -1;
    private static final String STRING_EMPTY_VALUE = "";
    private static final MaxAdDisplayTime VALUE_DEFAULT_MAXADDISPLAY;
    private static final long VALUE_DEFAULT_MAXLOAD;
    private static final MinSplashTime VALUE_DEFAULT_MINSPLASHTIME;
    private static final Orientation VALUE_DEFAULT_ORIENTATION;
    private static final Theme VALUE_DEFAULT_THEME;
    private static final long serialVersionUID = 1;
    private String appName = "";
    private int customScreen = -1;
    private MaxAdDisplayTime defaultMaxAdDisplayTime = VALUE_DEFAULT_MAXADDISPLAY;
    private Long defaultMaxLoadTime = VALUE_DEFAULT_MAXLOAD;
    private MinSplashTime defaultMinSplashTime = VALUE_DEFAULT_MINSPLASHTIME;
    private Orientation defaultOrientation = VALUE_DEFAULT_ORIENTATION;
    private Theme defaultTheme = VALUE_DEFAULT_THEME;
    private transient String errMsg = "";
    private transient Drawable logo = null;
    private int logoRes = -1;

    static {
        DEFAULT_MAX_LOAD = 7500;
        VALUE_DEFAULT_THEME = Theme.OCEAN;
        VALUE_DEFAULT_MINSPLASHTIME = MinSplashTime.REGULAR;
        VALUE_DEFAULT_MAXLOAD = DEFAULT_MAX_LOAD;
        VALUE_DEFAULT_MAXADDISPLAY = MaxAdDisplayTime.FOR_EVER;
        VALUE_DEFAULT_ORIENTATION = Orientation.AUTO;
    }

    private static void applyDefaultSplashConfig(SplashConfig splashConfig) {
        SplashConfig splashConfig2 = SplashConfig.getDefaultSplashConfig();
        if (splashConfig.getTheme() == null) {
            splashConfig.setTheme(splashConfig2.getTheme());
        }
        if (splashConfig.getMinSplashTime() == null) {
            splashConfig.setMinSplashTime(splashConfig2.getMinSplashTime());
        }
        if (splashConfig.getMaxLoadAdTimeout() == null) {
            splashConfig.setMaxLoadAdTimeout(splashConfig2.getMaxLoadAdTimeout());
        }
        if (splashConfig.getMaxAdDisplayTime() == null) {
            splashConfig.setMaxAdDisplayTime(splashConfig2.getMaxAdDisplayTime());
        }
        if (splashConfig.getOrientation() == null) {
            splashConfig.setOrientation(splashConfig2.getOrientation());
        }
    }

    public static SplashConfig getDefaultSplashConfig() {
        SplashConfig splashConfig = new SplashConfig();
        splashConfig.setTheme(VALUE_DEFAULT_THEME).setMinSplashTime(VALUE_DEFAULT_MINSPLASHTIME).setMaxLoadAdTimeout(VALUE_DEFAULT_MAXLOAD).setMaxAdDisplayTime(VALUE_DEFAULT_MAXADDISPLAY).setOrientation(VALUE_DEFAULT_ORIENTATION);
        return splashConfig;
    }

    private void setErrorMsg(String string2) {
        this.errMsg = string2;
    }

    private SplashConfig setLogo(Drawable drawable2) {
        this.logo = drawable2;
        return this;
    }

    public String getAppName() {
        return this.appName;
    }

    public int getCustomScreen() {
        return this.customScreen;
    }

    public String getErrorMessage() {
        return this.errMsg;
    }

    protected View getLayout(Context context) {
        switch (this.getTheme()) {
            default: {
                return b.a(context, this);
            }
            case USER_DEFINED: 
        }
        try {
            context = ((LayoutInflater)context.getSystemService("layout_inflater")).inflate(this.getCustomScreen(), null);
            return context;
        }
        catch (Resources.NotFoundException var1_2) {
            throw new Resources.NotFoundException("StartApp: Can't find Custom layout resource");
        }
        catch (InflateException var1_3) {
            throw new InflateException("StartApp: Can't inflate layout in Custom mode, Are you sure layout resource is valid?");
        }
    }

    public Drawable getLogo() {
        return this.logo;
    }

    protected int getLogoResource() {
        return this.logoRes;
    }

    public MaxAdDisplayTime getMaxAdDisplayTime() {
        return this.defaultMaxAdDisplayTime;
    }

    protected Long getMaxLoadAdTimeout() {
        return this.defaultMaxLoadTime;
    }

    public MinSplashTime getMinSplashTime() {
        return this.defaultMinSplashTime;
    }

    public Orientation getOrientation() {
        return this.defaultOrientation;
    }

    protected Theme getTheme() {
        return this.defaultTheme;
    }

    public SplashConfig setAppName(String string2) {
        this.appName = string2;
        return this;
    }

    public SplashConfig setCustomScreen(int n2) {
        this.customScreen = n2;
        return this;
    }

    public void setDefaults(Context object) {
        SplashConfig splashConfig;
        object = splashConfig = MetaData.getInstance().getSplashConfig();
        if (splashConfig == null) {
            object = SplashConfig.getDefaultSplashConfig();
        }
        SplashConfig.applyDefaultSplashConfig((SplashConfig)object);
        if (this.getMaxAdDisplayTime() == null) {
            this.setMaxAdDisplayTime(object.getMaxAdDisplayTime());
        }
        if (this.getMaxLoadAdTimeout() == null) {
            this.setMaxLoadAdTimeout(object.getMaxLoadAdTimeout());
        }
        if (this.getMinSplashTime() == null) {
            this.setMinSplashTime(object.getMinSplashTime());
        }
        if (this.getOrientation() == null) {
            this.setOrientation(object.getOrientation());
        }
        if (this.getTheme() == null) {
            this.setTheme(object.getTheme());
        }
    }

    public SplashConfig setLogo(int n2) {
        this.logoRes = n2;
        return this;
    }

    public SplashConfig setMaxAdDisplayTime(MaxAdDisplayTime maxAdDisplayTime) {
        this.defaultMaxAdDisplayTime = maxAdDisplayTime;
        return this;
    }

    protected SplashConfig setMaxLoadAdTimeout(long l2) {
        this.defaultMaxLoadTime = l2;
        return this;
    }

    public SplashConfig setMinSplashTime(MinSplashTime minSplashTime) {
        this.defaultMinSplashTime = minSplashTime;
        return this;
    }

    public SplashConfig setOrientation(Orientation orientation) {
        this.defaultOrientation = orientation;
        return this;
    }

    public SplashConfig setTheme(Theme theme) {
        this.defaultTheme = theme;
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected boolean validate(Context context) {
        switch (this.getTheme()) {
            default: {
                if (this.getAppName().compareTo("") == 0) {
                    this.setAppName(r.a(context, "Welcome!"));
                }
                if (this.getLogo() != null) return true;
                if (this.getLogoResource() == -1) {
                    this.setLogo(context.getResources().getDrawable(context.getApplicationInfo().icon));
                    return true;
                }
                break;
            }
            case USER_DEFINED: {
                if (this.getCustomScreen() != -1) return true;
                this.errMsg = "StartApp: Exception getting custom screen resource id, make sure it is set";
                return false;
            }
        }
        this.setLogo(context.getResources().getDrawable(this.getLogoResource()));
        return true;
    }

    public static enum MaxAdDisplayTime {
        SHORT(5000),
        LONG(10000),
        FOR_EVER(86400000);
        
        private long index;

        private MaxAdDisplayTime(long l2) {
            this.index = l2;
        }

        public static MaxAdDisplayTime getByIndex(long l2) {
            MaxAdDisplayTime maxAdDisplayTime = SHORT;
            MaxAdDisplayTime[] arrmaxAdDisplayTime = MaxAdDisplayTime.values();
            for (int i2 = 0; i2 < arrmaxAdDisplayTime.length; ++i2) {
                if (arrmaxAdDisplayTime[i2].getIndex() != l2) continue;
                maxAdDisplayTime = arrmaxAdDisplayTime[i2];
            }
            return maxAdDisplayTime;
        }

        public static MaxAdDisplayTime getByName(String string2) {
            MaxAdDisplayTime maxAdDisplayTime = FOR_EVER;
            MaxAdDisplayTime[] arrmaxAdDisplayTime = MaxAdDisplayTime.values();
            for (int i2 = 0; i2 < arrmaxAdDisplayTime.length; ++i2) {
                if (arrmaxAdDisplayTime[i2].name().toLowerCase().compareTo(string2.toLowerCase()) != 0) continue;
                maxAdDisplayTime = arrmaxAdDisplayTime[i2];
            }
            return maxAdDisplayTime;
        }

        public final long getIndex() {
            return this.index;
        }
    }

    public static enum MinSplashTime {
        REGULAR(3000),
        SHORT(2000),
        LONG(5000);
        
        private long index;

        private MinSplashTime(int n3) {
            this.index = n3;
        }

        public static MinSplashTime getByIndex(long l2) {
            MinSplashTime minSplashTime = SHORT;
            MinSplashTime[] arrminSplashTime = MinSplashTime.values();
            for (int i2 = 0; i2 < arrminSplashTime.length; ++i2) {
                if (arrminSplashTime[i2].getIndex() != l2) continue;
                minSplashTime = arrminSplashTime[i2];
            }
            return minSplashTime;
        }

        public static MinSplashTime getByName(String string2) {
            MinSplashTime minSplashTime = LONG;
            MinSplashTime[] arrminSplashTime = MinSplashTime.values();
            for (int i2 = 0; i2 < arrminSplashTime.length; ++i2) {
                if (arrminSplashTime[i2].name().toLowerCase().compareTo(string2.toLowerCase()) != 0) continue;
                minSplashTime = arrminSplashTime[i2];
            }
            return minSplashTime;
        }

        public final long getIndex() {
            return this.index;
        }
    }

    public static enum Orientation {
        PORTRAIT(1),
        LANDSCAPE(2),
        AUTO(3);
        
        private int index;

        private Orientation(int n3) {
            this.index = n3;
        }

        public static Orientation getByIndex(int n2) {
            Orientation orientation = PORTRAIT;
            Orientation[] arrorientation = Orientation.values();
            for (int i2 = 0; i2 < arrorientation.length; ++i2) {
                if (arrorientation[i2].getIndex() != n2) continue;
                orientation = arrorientation[i2];
            }
            return orientation;
        }

        public static Orientation getByName(String string2) {
            Orientation orientation = PORTRAIT;
            Orientation[] arrorientation = Orientation.values();
            for (int i2 = 0; i2 < arrorientation.length; ++i2) {
                if (arrorientation[i2].name().toLowerCase().compareTo(string2.toLowerCase()) != 0) continue;
                orientation = arrorientation[i2];
            }
            return orientation;
        }

        public final int getIndex() {
            return this.index;
        }
    }

    public static enum Theme {
        DEEP_BLUE(1),
        SKY(2),
        ASHEN_SKY(3),
        BLAZE(4),
        GLOOMY(5),
        OCEAN(6),
        USER_DEFINED(0);
        
        private int index;

        private Theme(int n3) {
            this.index = n3;
        }

        public static Theme getByIndex(int n2) {
            Theme theme = DEEP_BLUE;
            Theme[] arrtheme = Theme.values();
            for (int i2 = 0; i2 < arrtheme.length; ++i2) {
                if (arrtheme[i2].getIndex() != n2) continue;
                theme = arrtheme[i2];
            }
            return theme;
        }

        public static Theme getByName(String string2) {
            Theme theme = DEEP_BLUE;
            Theme[] arrtheme = Theme.values();
            for (int i2 = 0; i2 < arrtheme.length; ++i2) {
                if (arrtheme[i2].name().toLowerCase().compareTo(string2.toLowerCase()) != 0) continue;
                theme = arrtheme[i2];
            }
            return theme;
        }

        public final int getIndex() {
            return this.index;
        }
    }

}

