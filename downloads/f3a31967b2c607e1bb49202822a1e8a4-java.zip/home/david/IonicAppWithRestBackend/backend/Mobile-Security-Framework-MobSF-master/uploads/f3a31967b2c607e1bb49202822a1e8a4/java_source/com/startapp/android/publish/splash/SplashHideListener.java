/*
 * Decompiled with CFR 0_115.
 */
package com.startapp.android.publish.splash;

public interface SplashHideListener {
    public void splashHidden();
}

