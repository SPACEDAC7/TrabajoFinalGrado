/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 */
package com.startapp.android.publish.splash;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import com.startapp.android.publish.Ad;
import com.startapp.android.publish.AdDisplayListener;
import com.startapp.android.publish.AdEventListener;
import com.startapp.android.publish.StartAppAd;
import com.startapp.android.publish.g.b;
import com.startapp.android.publish.g.j;
import com.startapp.android.publish.model.AdPreferences;
import com.startapp.android.publish.splash.SplashConfig;

public class a {
    private Activity a;
    private SplashConfig b;
    private Handler c = new Handler();
    private boolean d = false;
    private boolean e = false;
    private boolean f = false;
    private boolean g = false;
    private boolean h = true;
    private boolean i = false;
    private long j = 0;
    private long k = 0;
    private boolean l = false;
    private StartAppAd m;
    private AdPreferences n;
    private Runnable o;
    private AdDisplayListener p;
    private AdEventListener q;

    public a(Activity activity, SplashConfig splashConfig, AdPreferences adPreferences) {
        this.o = new Runnable(){

            @Override
            public void run() {
                if (a.this.e()) {
                    a.this.f();
                    a.this.h();
                }
            }
        };
        this.p = new AdDisplayListener(){

            @Override
            public void adClicked(Ad ad) {
            }

            @Override
            public void adDisplayed(Ad ad) {
            }

            @Override
            public void adHidden(Ad ad) {
                j.a(4, "Splash Screen had been hidden");
                a.this.e = true;
                a.this.g();
            }
        };
        this.q = new AdEventListener(){

            @Override
            public void onFailedToReceiveAd(Ad object) {
                if (a.this.m != null) {
                    j.a(4, "Error receiving Ad");
                    a.this.g = true;
                    object = new Runnable(){

                        @Override
                        public void run() {
                            a.this.g();
                        }
                    };
                    a.this.a((Runnable)object);
                }
            }

            @Override
            public void onReceiveAd(Ad object) {
                j.a(4, "Splash Ad receivied");
                object = new Runnable(){

                    @Override
                    public void run() {
                        if (!a.this.l && a.this.m != null) {
                            j.a(4, "Displaying Splash Ad");
                            a.this.d = true;
                            a.this.m.showAd(a.this.p);
                            a.this.i();
                            a.this.a.finish();
                        }
                    }
                };
                a.this.a((Runnable)object);
            }

        };
        this.a = activity;
        this.b = splashConfig;
        this.n = adPreferences;
    }

    private void a(final Runnable runnable) {
        this.k = SystemClock.elapsedRealtime();
        long l2 = this.b.getMinSplashTime().getIndex() - (this.k - this.j);
        runnable = new Runnable(){

            @Override
            public void run() {
                if (!a.this.f) {
                    a.this.h = false;
                    runnable.run();
                }
            }
        };
        if (l2 > 0) {
            j.a(4, "Delaying Splash for min show time");
            this.c.postDelayed(runnable, l2);
            return;
        }
        this.c.post(runnable);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private boolean d() {
        var3_1 = true;
        var2_2 = true;
        var1_3 = this.a.getResources().getConfiguration().orientation;
        if (this.b.getOrientation() == SplashConfig.Orientation.AUTO) {
            if (var1_3 == 2) {
                this.b.setOrientation(SplashConfig.Orientation.LANDSCAPE);
            } else {
                this.b.setOrientation(SplashConfig.Orientation.PORTRAIT);
            }
        }
        switch (.a[this.b.getOrientation().ordinal()]) {
            default: {
                var2_2 = false;
                ** GOTO lbl22
            }
            case 1: {
                if (var1_3 != 2) break;
                ** GOTO lbl21
            }
            case 2: {
                var2_2 = var1_3 == 1 ? var3_1 : false;
                b.b(this.a);
                ** GOTO lbl22
            }
        }
        var2_2 = false;
lbl21: // 2 sources:
        b.a(this.a);
lbl22: // 3 sources:
        j.a(4, "Set Orientation: [" + this.b.getOrientation().toString() + "]");
        return var2_2;
    }

    private boolean e() {
        j.a(4, "Displaying Splash screen");
        if (!this.b.validate((Context)this.a)) {
            throw new IllegalArgumentException(this.b.getErrorMessage());
        }
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -1);
        this.a.setContentView(this.b.getLayout((Context)this.a), layoutParams);
        return true;
    }

    private void f() {
        j.a(4, "Loading Splash Ad");
        this.m = new StartAppAd((Context)this.a);
        this.j = SystemClock.elapsedRealtime();
        this.m.loadSplash(this.n, this.q);
    }

    private void g() {
        this.k();
        this.a.finish();
    }

    private void h() {
        j.a(4, "Started Splash Loading Timer");
        this.c.postDelayed(new Runnable(){

            @Override
            public void run() {
                if (!(a.this.l || a.this.d || a.this.g)) {
                    j.a(4, "Splash Loading Timer Expired");
                    a.this.m = null;
                    a.this.h = false;
                    a.this.f = true;
                    a.this.g();
                }
            }
        }, this.b.getMaxLoadAdTimeout().longValue());
    }

    private void i() {
        j.a(4, "Started Splash Display Timer");
        this.c.postDelayed(new Runnable(){

            @Override
            public void run() {
                if (!a.this.e) {
                    j.a(4, "Splahs Ad Display Timeout");
                    a.this.a.registerReceiver(new BroadcastReceiver(){

                        public void onReceive(Context context, Intent intent) {
                            context.unregisterReceiver((BroadcastReceiver)this);
                            a.this.g();
                        }
                    }, new IntentFilter("com.startapp.android.CloseAdActivityReply"));
                    a.this.m.close();
                }
            }

        }, this.b.getMaxAdDisplayTime().getIndex());
    }

    private void j() {
        j.a(4, "User Canceled Splash Screen");
        this.k();
    }

    private void k() {
        if (!this.i) {
            this.i = true;
            Intent intent = new Intent("com.startapp.android.splashHidden");
            this.a.sendBroadcast(intent);
        }
    }

    public void a() {
        j.a(4, "========= Splsah Screen Feature =========");
        if (!this.d()) {
            this.c.post(this.o);
            return;
        }
        this.c.postDelayed(this.o, 100);
        j.a(4, "Splash screen orientation is being modified");
    }

    public void a(Bundle bundle) {
        this.a();
    }

    public void b() {
        this.l = true;
    }

    public void c() {
        this.c.removeCallbacks(this.o);
        if (!this.d) {
            this.f = true;
            if (this.h) {
                this.j();
            }
        }
    }

}

