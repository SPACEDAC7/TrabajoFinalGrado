/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Color
 *  android.graphics.Point
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.GradientDrawable
 *  android.graphics.drawable.GradientDrawable$Orientation
 *  android.util.DisplayMetrics
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.webkit.WebView
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 */
package com.startapp.android.publish.splash;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.startapp.android.publish.g.n;
import com.startapp.android.publish.g.q;
import com.startapp.android.publish.splash.SplashConfig;

public class b {
    public static View a(Context context, SplashConfig splashConfig) {
        switch (.a[splashConfig.getTheme().ordinal()]) {
            default: {
                return null;
            }
            case 1: {
                return b.g(context, splashConfig);
            }
            case 2: {
                return b.f(context, splashConfig);
            }
            case 3: {
                return b.e(context, splashConfig);
            }
            case 4: {
                return b.d(context, splashConfig);
            }
            case 5: {
                return b.c(context, splashConfig);
            }
            case 6: 
        }
        return b.b(context, splashConfig);
    }

    private static View b(Context context, SplashConfig splashConfig) {
        context = b.h(context, splashConfig);
        context.setBackgroundDrawable((Drawable)new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-14451558, -7876130}));
        ((TextView)context.findViewById(100)).setTextColor(Color.rgb((int)6, (int)61, (int)82));
        ((TextView)context.findViewById(105)).setTextColor(Color.rgb((int)6, (int)61, (int)82));
        return context;
    }

    private static View c(Context context, SplashConfig splashConfig) {
        context = b.h(context, splashConfig);
        context.setBackgroundColor(Color.rgb((int)47, (int)53, (int)63));
        ((TextView)context.findViewById(100)).setTextColor(Color.rgb((int)51, (int)181, (int)229));
        ((TextView)context.findViewById(105)).setTextColor(Color.rgb((int)122, (int)130, (int)139));
        return context;
    }

    private static View d(Context context, SplashConfig splashConfig) {
        splashConfig = b.h(context, splashConfig);
        int n2 = context.getResources().getDisplayMetrics().widthPixels;
        context = new GradientDrawable(GradientDrawable.Orientation.BL_TR, new int[]{-92376, -40960});
        context.setGradientType(1);
        context.setGradientRadius((float)(n2 / 2));
        splashConfig.setBackgroundDrawable((Drawable)context);
        ((TextView)splashConfig.findViewById(100)).setTextColor(Color.rgb((int)255, (int)255, (int)255));
        ((TextView)splashConfig.findViewById(105)).setTextColor(Color.rgb((int)255, (int)198, (int)151));
        return splashConfig;
    }

    private static View e(Context context, SplashConfig splashConfig) {
        context = b.h(context, splashConfig);
        context.setBackgroundDrawable((Drawable)new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-3881788, -1}));
        ((TextView)context.findViewById(100)).setTextColor(Color.rgb((int)51, (int)51, (int)51));
        ((TextView)context.findViewById(105)).setTextColor(Color.rgb((int)153, (int)153, (int)153));
        return context;
    }

    private static View f(Context context, SplashConfig splashConfig) {
        splashConfig = b.h(context, splashConfig);
        int n2 = context.getResources().getDisplayMetrics().widthPixels;
        context = new GradientDrawable(GradientDrawable.Orientation.BL_TR, new int[]{-921103, -6040347});
        context.setGradientType(1);
        context.setGradientRadius((float)(n2 / 2));
        splashConfig.setBackgroundDrawable((Drawable)context);
        ((TextView)splashConfig.findViewById(100)).setTextColor(Color.rgb((int)51, (int)51, (int)51));
        ((TextView)splashConfig.findViewById(105)).setTextColor(Color.rgb((int)162, (int)172, (int)175));
        return splashConfig;
    }

    private static View g(Context context, SplashConfig splashConfig) {
        context = b.h(context, splashConfig);
        context.setBackgroundDrawable((Drawable)new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-16356182, -15029533, -16356182}));
        ((TextView)context.findViewById(100)).setTextColor(Color.rgb((int)255, (int)255, (int)255));
        ((TextView)context.findViewById(105)).setTextColor(Color.rgb((int)208, (int)210, (int)210));
        return context;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static View h(Context context, SplashConfig splashConfig) {
        int n2;
        int n3;
        int n4;
        int n5;
        RelativeLayout relativeLayout = new RelativeLayout(context);
        relativeLayout.setBackgroundColor(-1);
        RelativeLayout relativeLayout2 = new RelativeLayout(context);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(13);
        relativeLayout.addView((View)relativeLayout2, (ViewGroup.LayoutParams)layoutParams);
        layoutParams = new Point(q.a(context, 150), q.a(context, 28));
        if (splashConfig.getOrientation() == SplashConfig.Orientation.PORTRAIT) {
            n4 = q.a(context, 5);
            n3 = q.a(context, 8);
            n2 = q.a(context, 75);
            n5 = q.a(context, 130);
        } else {
            n4 = q.a(context, 5);
            n3 = q.a(context, 8);
            n2 = q.a(context, 40);
            n5 = q.a(context, 100);
        }
        ImageView imageView = new ImageView(context);
        imageView.setImageDrawable(splashConfig.getLogo());
        imageView.setId(101);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(n5, n5);
        layoutParams2.addRule(10);
        layoutParams2.addRule(14);
        layoutParams2.setMargins(0, 0, 0, n4);
        relativeLayout2.addView((View)imageView, (ViewGroup.LayoutParams)layoutParams2);
        imageView = new TextView(context);
        imageView.setTypeface(n.a(context, "Roboto-Regular.ttf"));
        imageView.setText((CharSequence)splashConfig.getAppName());
        imageView.setId(100);
        imageView.setTextSize(1, 26.0f);
        imageView.setTextColor(Color.rgb((int)255, (int)255, (int)255));
        imageView.setGravity(17);
        splashConfig = new RelativeLayout.LayoutParams(-2, -2);
        splashConfig.addRule(14);
        splashConfig.addRule(3, 101);
        splashConfig.setMargins(0, 0, 0, n2);
        relativeLayout2.addView((View)imageView, (ViewGroup.LayoutParams)splashConfig);
        splashConfig = new WebView(context);
        splashConfig.setId(102);
        layoutParams = new RelativeLayout.LayoutParams(layoutParams.x, layoutParams.y);
        layoutParams.addRule(14);
        layoutParams.addRule(3, 100);
        layoutParams.setMargins(0, 0, 0, n3);
        splashConfig.setBackgroundColor(Color.argb((int)0, (int)0, (int)0, (int)0));
        splashConfig.setVerticalScrollBarEnabled(false);
        splashConfig.setHorizontalScrollBarEnabled(false);
        splashConfig.loadUrl(n.b(context, "loading.html"));
        relativeLayout2.addView((View)splashConfig, (ViewGroup.LayoutParams)layoutParams);
        context = new TextView(context);
        context.setText((CharSequence)"Loading...");
        context.setId(105);
        context.setTextSize(1, 18.0f);
        context.setTextColor(Color.rgb((int)208, (int)210, (int)210));
        context.setGravity(17);
        splashConfig = new RelativeLayout.LayoutParams(-2, -2);
        splashConfig.addRule(14);
        splashConfig.addRule(3, 102);
        splashConfig.setMargins(0, 0, 0, 0);
        relativeLayout2.addView((View)context, (ViewGroup.LayoutParams)splashConfig);
        return relativeLayout;
    }

}

